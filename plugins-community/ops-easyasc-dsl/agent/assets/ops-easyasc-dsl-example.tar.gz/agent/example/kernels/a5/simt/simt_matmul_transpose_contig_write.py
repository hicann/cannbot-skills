"""Cube matmul + SIMT transpose -- contiguous-GM-write variant.

Hybrid kernel: cube computes a @ b.t() into UB, then SIMT writes the
transposed result to GM.  This file pairs the SIMT body with a *coalesced
GM write* layout (out_gm[i] for thread i) at the cost of a *strided UB
read* (stride N).  Compare against simt_matmul_transpose_contig_read.py,
which makes the opposite trade.
"""

import sys

from easyasc.a5 import *


@simt()
def transpose_simt_contig_write(in_ub: Tensor, out_gm: GMTensor, M: Var, N: Var):
    """Decompose the flat thread index into the *output* layout.

    col = i / M, row = i % M, then out_gm[i] = in_ub[row * N + col].
    GM writes are contiguous; UB reads are strided by N.
    """
    total = M * N
    for i in range(simt_thread_id(), total, simt_thread_num()):
        col = i / M
        row = i % M
        out_gm[i] = in_ub[row * N + col]


@kernel()
def simt_matmul_transpose_contig_write_kernel(
    a: GMTensor, b: GMTensor, c_t: GMTensor, m: Var, n: Var, k: Var
):
    l1a = Tensor(DT.float, [m, k], Position.L1)
    l1b = Tensor(DT.float, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)
    out_ub = Tensor(DT.float, [m, n], Position.UB)

    # CvMutex coordinates the cube → vec handover for the UB tile.  Two
    # l0c_to_ub calls (sub_block_id=0 then 1) populate both vec0 and vec1
    # UB views with the full DualMode.SINGLE tile so either sub-block can
    # source the SIMT transpose.  dst_end_pipe=Pipe.V so the V-pipe SIMT
    # task must complete before vec_ready is signalled back to cube.
    cv = CvMutex(flag_id=0, dst_end_pipe=Pipe.V)

    with auto_sync():
        l1a <<= a[:, :]
        l1b <<= b[:, :]
        matmul(l0c, l1a, l1b)
        cv.lock()
        l0c_to_ub(out_ub, l0c, dual_mode=DualMode.SINGLE, sub_block_id=0)
        l0c_to_ub(out_ub, l0c, dual_mode=DualMode.SINGLE, sub_block_id=1)
        cv.ready()
        cv.wait()
        transpose_simt_contig_write(out_ub, c_t, m, n)
        cv.free()

    return c_t


if __name__ == "__main__":
    import torch

    use_cannsim = "--cannsim" in sys.argv[1:]

    M, N, K = 32, 16, 8
    torch.manual_seed(0)
    a = torch.randn((M, K), dtype=torch.float32)
    b = torch.randn((N, K), dtype=torch.float32)
    c_t = torch.zeros((N, M), dtype=torch.float32)

    SHAPE_BINDINGS = {
        0: [0, 2],  # a [M, K]
        1: [1, 2],  # b [N, K]
        2: [1, 0],  # c_t [N, M]
    }

    if use_cannsim:
        actual = OpExec(
            simt_matmul_transpose_contig_write_kernel,
            out_dir="./tmp/simt_matmul_transpose_contig_write_cannsim",
            simulator=False,
            cannsim=True,
        )(a, b, c_t, M, N, K, shape_bindings=SHAPE_BINDINGS)
    else:
        actual = OpExec(
            simt_matmul_transpose_contig_write_kernel,
            out_dir="./tmp/simt_matmul_transpose_contig_write_simulator",
            simulator=True,
        )(a, b, c_t, M, N, K, shape_bindings=SHAPE_BINDINGS)

    expected = (a @ b.t()).t()
    torch.testing.assert_close(actual, expected, rtol=1e-4, atol=1e-4)
    print(f"max_abs_diff={torch.max(torch.abs(actual - expected)).item():.6e}")
