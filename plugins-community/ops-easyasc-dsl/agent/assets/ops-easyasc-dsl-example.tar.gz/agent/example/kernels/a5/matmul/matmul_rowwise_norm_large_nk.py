from easyasc.a5 import *


TILE_M = 64
TILE_N = 256
TILE_K = 128
SPLIT_N = 128
VEC_WIDTH = 64
REGS_PER_ROW = TILE_N // VEC_WIDTH


@vf()
def accumulate_row_sum_vf(src_tile: Tensor, row_sum_dup: Tensor, dst_tile: Tensor, rows: Var):
    row_regs = RegList(DT.float, REGS_PER_ROW)
    sum_reg = Reg(DT.float)
    sum_dup_reg = Reg(DT.float)
    acc_reg = Reg(DT.float)

    for r in range(rows):
        src_row = src_tile[r:r + 1, :]
        dst_row = dst_tile[r:r + 1, :]
        sum_row = row_sum_dup[r:r + 1, :]

        row_regs <<= src_row
        sum_reg <<= row_regs.cadd()
        sum_dup_reg <<= sum_reg.dup()
        acc_reg <<= sum_row
        acc_reg <<= acc_reg + sum_dup_reg
        sum_row <<= acc_reg
        dst_row <<= row_regs
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def normalize_rows_with_sum_vf(src_tile: Tensor, row_sum_dup: Tensor, dst_tile: Tensor, rows: Var):
    row_regs = RegList(DT.float, REGS_PER_ROW)
    denom_reg = Reg(DT.float)

    for r in range(rows):
        src_row = src_tile[r:r + 1, :]
        sum_row = row_sum_dup[r:r + 1, :]
        dst_row = dst_tile[r:r + 1, :]

        row_regs <<= src_row
        denom_reg <<= sum_row
        row_regs <<= row_regs / denom_reg
        dst_row <<= row_regs


@vf()
def zero_row_sum_vf(row_sum_dup: Tensor, rows: Var):
    zero_reg = Reg(DT.float)
    zero_reg <<= 0.0
    for r in range(rows):
        row_sum_dup[r:r + 1, :] <<= zero_reg


@kernel()
def matmul_rowwise_norm_large_nk_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1y = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)
    xbuf = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    outbuf = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    row_sum_ub = Tensor(DT.float, [TILE_M // 2, VEC_WIDTH], Position.UB)

    pass1_cnt = Var(0)
    pass2_cnt = Var(0)
    l1_cnt = Var(0)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    for mt in range(tile_m_begin, tile_m_end):
        m0 = Var(mt * TILE_M)
        valid_m = Min(TILE_M, M - m0)
        half_rows = CeilDiv(valid_m, 2)
        sb_idx = Var(GetSubBlockIdx())
        row_start = Var(m0 + sb_idx * half_rows)
        rows = Min(half_rows, valid_m - sb_idx * half_rows)
        # row_sum_ub is a persistent UB accumulator and must start from 0 per tile-M.
        zero_row_sum_vf(row_sum_ub[0:rows, :], rows)

        with auto_sync():
            # Pass-1: matmul tiles + row-sum accumulation + temporary store to z.
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    l1x[l1_cnt] <<= x[m0:m0 + valid_m, k0:k0 + valid_k]
                    l1y[l1_cnt] <<= y[n0:n0 + valid_n, k0:k0 + valid_k]
                    matmul(l0c[pass1_cnt], l1x[l1_cnt], l1y[l1_cnt], splitn=SPLIT_N, is_init=(k0 == 0))
                    l1_cnt += 1 

                cvmutex.lock()
                xbuf[pass1_cnt] <<= l0c[pass1_cnt]
                cvmutex.ready()

                cvmutex.wait()
                accumulate_row_sum_vf(xbuf[pass1_cnt][0:rows, :], row_sum_ub[0:rows, :], outbuf[pass1_cnt][0:rows, :], rows)
                z[row_start:row_start + rows, n0:n0 + valid_n] <<= outbuf[pass1_cnt][0:rows, 0:valid_n]
                cvmutex.free()
                pass1_cnt += 1

        # Pass-2: normalize temporary z tiles with accumulated row sums.
        bar_all()
        pass2_cnt <<= pass1_cnt
        with auto_sync():
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                xbuf[pass2_cnt][0:rows, 0:valid_n] <<= z[row_start:row_start + rows, n0:n0 + valid_n]
                normalize_rows_with_sum_vf(xbuf[pass2_cnt][0:rows, :], row_sum_ub[0:rows, :], outbuf[pass2_cnt][0:rows, :], rows)
                z[row_start:row_start + rows, n0:n0 + valid_n] <<= outbuf[pass2_cnt][0:rows, 0:valid_n]
                pass2_cnt += 1
    return z


if __name__ == "__main__":
    import torch
    from easyasc.a5 import OpExec

    M = 1280
    N = 2560
    K = 1024
    torch.manual_seed(0)

    x = torch.rand((M, K), dtype=torch.float16)
    y = torch.rand((N, K), dtype=torch.float16)
    z = torch.zeros((M, N), dtype=torch.float32)

    z_gt = x.float() @ y.float().t()
    z_gt = z_gt / torch.sum(z_gt, dim=-1, keepdim=True)

    z_kernel = OpExec(matmul_rowwise_norm_large_nk_kernel, simulator=True)(
        x, y, z, M, N, K, shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1]}
    )

    torch.testing.assert_close(z_kernel, z_gt, rtol=3e-3, atol=3e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z_gt).max().item():.6e}")
