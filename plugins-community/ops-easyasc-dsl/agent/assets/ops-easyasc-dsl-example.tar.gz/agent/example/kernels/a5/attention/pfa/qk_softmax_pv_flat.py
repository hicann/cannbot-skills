"""FLATTENED variant of qk_softmax_pv_pipe: the (M-tile, K-tile) loops are FUSED into ONE linear
`step` loop so the lag-2 software pipeline carries ACROSS M-tile boundaries -- M-tile B's QK ramp-up
overlaps M-tile A's PV drain, removing the per-M-tile ramp/drain bubbles (2 QK-only + 2 PV-only trips
each) that the nested version pays at every M-tile. Requires k_tiles >= 2 (lag-2 needs >=2 K-tiles per
M-tile, and the m%2 state double-buffering needs adjacent M-tiles to differ in parity). To let A's
drain overlap B's ramp, the per-M-tile state (rsum, accum, out, l1q) is double-buffered by M-tile
parity; rmax stays single (only stage1 touches it, and stage1 is strictly serial in step).

Full PFA forward (QK + transposed softmax + PV), KV-major, 2-AIV, LAG-2 lookahead.

Builds on qk_softmax_pipe (KV-major QK = K@Q^T, lane-wise vmax softmax) + the validated PV recipe
from pfa_full_tn128_transpose / pv_probe (P^T [129,64] pack, .nz() column-publish, PV = matmul(l1p.T,
l1v.T)). LAG-2: stage1 (QK+softmax+publish P[n]) runs 2 tiles ahead of stage2 (PV[n-2]+accum), per
the user's "pre-compute 2 QK tiles before PV". Buffers that span the 2-trip gap (l1p, oldw, blkw) are
TBuff(3); p_mutex depth=3. After the K-loop: normalize O/rsum -> bf16 -> GM.

Dense (non-causal). Handles K-tail (N % TILE_N != 0) via softmax_t_tail_vf (select invalid keys to
NEG -> P=0) + l1v zeroing, and M-tail (M % TILE_M != 0) via valid_m/local_rows store-cropping.

MQA + batch: q is [B*MQ, D] with MQ=HQ*SQ query rows per batch (HKV=1: heads flattened along rows,
sharing the batch's KV); k/v are [B*N, D] with N=SKV keys per batch. KV is SHARED across heads but
INDEPENDENT per batch -- so a query tile may straddle head boundaries (when SQ % TILE_M != 0) yet
never batch boundaries; each tile's KV comes from its own batch via kv_base. The (batch, local M-tile)
pairs are linearized to one index for core distribution. dense only (causal masking would break the
cross-head-tile sharing).
"""
import builtins
import math
import os

import torch

from easyasc.a5pr import *

_pyrange = builtins.range

TILE_M = 128                      # query rows per cube block (2 AIV sub-blocks)
ROWS_PER_SB = 64                  # query rows per AIV sub-block (= QLANES)
QLANES = ROWS_PER_SB
TILE_N = 128                      # keys per K-tile
D_HEAD = 128
CHUNKS_D = D_HEAD // 64           # 2 fp32 regs per O row
SOFTMAX_SCALE = 1.0 / math.sqrt(D_HEAD)
NEG_LARGE = -1.0e30
NZ_C0 = 16
HALF = TILE_N // 2                # 64: pair key i with key i+64 (official 2-key pack: 64 VDINTLV/VSSTB)
FRAC_STRIDE = HALF + 1            # 65: ub_p is [65, 128] (2 keys per row, query inner)
UNROLL = 4                        # 4-way unroll: 4 independent max/sum partial chains (recover ILP)
RB_MAX = TILE_N // UNROLL         # 32: max pass over 128 keys
RB_EXP = HALF // UNROLL           # 16: exp pass over 64 pairs (i, i+64)
PRELOAD_N = 2                     # lag-2 lookahead


# ---- softmax / accum / finalize VFs (verbatim from pfa_full_tn128_transpose) --
@vf()
def init_softmax_state_vf(ub_rmax: Tensor, ub_rsum: Tensor):
    neg = Reg(DT.float); zero = Reg(DT.float)
    neg <<= NEG_LARGE; zero <<= 0.0
    ub_rmax[0:1, 0:QLANES] <<= neg
    ub_rsum[0:1, 0:QLANES] <<= zero


@vf()
def softmax_t_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                 ub_old_weight: Tensor):
    """Online softmax over [key=128, query=64] score^T, OFFICIAL single-weight (new_max) scheme:
    P^T = exp(scale*s - new_m) (folds the block weight into P -> accum is just O*old_scale + PV, one
    weight). 2-key pack: pair key i with i+64, deinterleave into one 128-lane reg (64 VDINTLV/VSSTB),
    VSSTB to ub_p[65,128]; published via 2 MTE3 (key-halves). new_m computed BETWEEN the max and exp
    passes so pass 2 exps against the running max directly."""
    sreg = RegList(DT.float, UNROLL); acc = RegList(DT.float, UNROLL); preg = RegList(DT.float, UNROLL)
    h_i = RegList(DT.bfloat16, UNROLL); h_j = RegList(DT.bfloat16, UNROLL)
    pk = Reg(DT.bfloat16); pk_hi = Reg(DT.bfloat16)
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    # pass 1: per-query max over the 128 keys -- 4 independent partial-max chains (on RAW scores), tree-combine
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)            # scale the max ONCE (max(scale*s)=scale*max(s))
    # online max (between passes): new_m = max(block_max, old_m); old_scale = exp(old_m - new_m)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    # pass 2: exp(scale*s - new_m) + per-query sum (4 partial-sum chains) + 2-key pack (i paired with i+HALF)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP, name="ex"):
        for u in unroll(UNROLL):                         # the "i" keys (0..63)
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            h_i[u] <<= preg[u].astype(DT.bfloat16)
        for u in unroll(UNROLL):                         # the "i+64" keys
            sreg[u] <<= ub_score[(rb * UNROLL + u + HALF):(rb * UNROLL + u + HALF) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            h_j[u] <<= preg[u].astype(DT.bfloat16)
        for u in unroll(UNROLL):
            deinterleave(pk, pk_hi, h_i[u], h_j[u])       # pk = [key_i 64q, key_(i+64) 64q]
            reg_to_ub(ub_p[(rb * UNROLL + u) * NZ_C0], pk, FRAC_STRIDE)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    # online sum: new_l = old_l*old_scale + block_sum (block_sum already exp'd against new_m -> no blkw)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_t_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                      ub_old_weight: Tensor, valid_n: Var):
    """Tail variant for a PARTIAL K-tile (valid_n < TILE_N): invalid key rows (n >= valid_n, whose
    QK score is stale/garbage) are select()'d to NEG before the lane-wise max/exp, so they drop out of
    the per-query max and give P=exp(NEG-new_m)=0 (no sum/PV contribution). Non-unrolled (only the last
    K-tile per query-tile uses it); same single-weight new_m scheme + 2-key (i,i+64) pack as the main VF."""
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float)
    h_i = Reg(DT.bfloat16); h_j = Reg(DT.bfloat16); pk = Reg(DT.bfloat16); dummy = Reg(DT.bfloat16)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)   # QLANES if n<valid_n else 0
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)                  # invalid key-row -> all-NEG -> excluded from max
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    block_sum <<= 0.0
    for i in range(HALF):
        cnt_i = Var(QLANES * Min(Max(valid_n - i, 0), 1), dtype=DT.uint32)
        s <<= ub_score[i:i + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_i)
        select(s, s, neg, mask=rowmask)                  # invalid -> NEG -> exp(NEG-new_m)=0
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        h_i <<= e.astype(DT.bfloat16)
        cnt_j = Var(QLANES * Min(Max(valid_n - (i + HALF), 0), 1), dtype=DT.uint32)
        s <<= ub_score[i + HALF:i + HALF + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_j)
        select(s, s, neg, mask=rowmask)
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        h_j <<= e.astype(DT.bfloat16)
        deinterleave(pk, dummy, h_i, h_j)
        reg_to_ub(ub_p[i * NZ_C0], pk, FRAC_STRIDE)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_pv_vf(ub_accum: Tensor, ub_pv: Tensor, ub_old_weight: Tensor):
    """Single-weight online rescale: O[r] = O[r]*old_scale[r] + PV[r] (P already exp'd against the
    running max in softmax, so PV needs no block weight)."""
    acc = RegList(DT.float, CHUNKS_D); pv = RegList(DT.float, CHUNKS_D)
    old_weight = Reg(DT.float)
    for r in range(ROWS_PER_SB):
        old_weight <<= ub_old_weight[0:1, r:r + 1].single()
        acc <<= ub_accum[r:r + 1, 0:D_HEAD]
        pv <<= ub_pv[r:r + 1, 0:D_HEAD]
        acc <<= acc * old_weight
        acc <<= acc + pv
        ub_accum[r:r + 1, 0:D_HEAD] <<= acc
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_pv_first_vf(ub_accum: Tensor, ub_pv: Tensor):
    """First PV block: O = PV (no prior O to rescale; P already exp'd against new_m)."""
    pv = RegList(DT.float, CHUNKS_D)
    for r in range(ROWS_PER_SB):
        pv <<= ub_pv[r:r + 1, 0:D_HEAD]
        ub_accum[r:r + 1, 0:D_HEAD] <<= pv
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def final_div_cast_bf16_vf(ub_accum: Tensor, ub_rsum: Tensor, ub_out: Tensor):
    """O = ub_accum / ub_rsum (per-query), cast fp32 -> bf16."""
    acc = RegList(DT.float, CHUNKS_D); rsum = Reg(DT.float)
    for r in range(ROWS_PER_SB):
        rsum <<= ub_rsum[0:1, r:r + 1].single()
        acc <<= ub_accum[r:r + 1, 0:D_HEAD]
        acc <<= acc / rsum
        ub_out[r:r + 1, 0:D_HEAD] <<= acc
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ---- kernel (LAG-2) ----------------------------------------------------------
@kernel()
def qk_softmax_pv_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor,
                         B: Var, MQ: Var, N: Var, D: Var):
    # MQA + batch (same tensor contract as qk_softmax_pv_pipe): q [B*MQ, D] (MQ=HQ*SQ, heads flattened,
    # KV shared within a batch), k/v [B*N, D] (KV independent per batch). FLATTENED scheduling: one
    # linear `step` loop covers all (M-tile, K-tile) work for this core; stage1 runs at `step`, stage2
    # (PV) lags by PRELOAD_N so the pipeline spans M-tile boundaries.
    cv = CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                 src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, depth=3, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)   # vec P-publish -> cube PV (lag-2)
    pv_mutex = CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)        # cube PV -> vec accum

    l1q = DBuff(DT.bfloat16, [TILE_M, D_HEAD], Position.L1)           # ping-pong by M-tile parity
    l1k = DBuff(DT.bfloat16, [TILE_N, D_HEAD], Position.L1)           # ping-pong by step
    l1v = DBuff(DT.bfloat16, [TILE_N, D_HEAD], Position.L1)
    l1p = TBuff(DT.bfloat16, [TILE_N, TILE_M], Position.L1)            # P^T [key,query], lag-2 ring (wi%3)
    l0c = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)             # QK -> slot0, PV -> slot1 (l0c_cnt)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)    # per sub-block [key=128, query=64]
    ub_p = Tensor(DT.bfloat16, [FRAC_STRIDE, 2 * ROWS_PER_SB], Position.UB)  # [65,128] 2-key pack, single-buffer
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_accum = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)    # O accumulator, double-buffered by M-tile parity
    ub_out = DBuff(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)   # double-buffered by M-tile parity
    ub_rmax = Tensor(DT.float, [1, QLANES], Position.UB)             # single (only stage1, strictly serial in step)
    ub_rsum = DBuff(DT.float, [1, QLANES], Position.UB)              # double-buffered by M-tile parity (finalize lags)
    ub_old_weight = TBuff(DT.float, [1, QLANES], Position.UB)         # oldw ring: softmax[n] -> accum[n] (lag-2, wi%3)

    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)                  # query-tiles per batch (heads flattened)
    k_tiles = CeilDiv(N, TILE_N)
    total_tiles = Var(B * tiles_m_per_b)                 # linearize (batch, local M-tile) -> one index
    tiles_per_core = CeilDiv(total_tiles, GetCubeNum())
    gt_begin = Var(tiles_per_core * GetCubeIdx())
    gt_end = Min(gt_begin + tiles_per_core, total_tiles)
    my_tiles = Var(gt_end - gt_begin)                    # this core's M-tile count
    my_work = Var(my_tiles * k_tiles)                    # this core's stage1 work units (M-tile x K-tile)

    # Zero l1v (both slots) once: a partial K-tile loads only valid_n V rows; invalid keys get P=0 from
    # the tail softmax, but 0*stale could be 0*nan -> nan, so the stale V rows must read as 0.
    set_constant_to_l1(l1v[0].reinterpret(DT.uint8), 0)
    set_constant_to_l1(l1v[1].reinterpret(DT.uint8), 0)

    with auto_sync():
        l0c_cnt = Var(0)                                 # global QK/PV L0C ring (QK then PV each step)
        for step in range(0, my_work + PRELOAD_N):
            if step < my_work:
                # === STAGE 1 @ wi1=step: QK^T -> SPLITN softmax -> P^T publish ===
                wi1 = Var(step)
                m1 = Var(wi1 // k_tiles)                          # local M-tile index (0..my_tiles-1)
                k1 = Var(wi1 % k_tiles)                           # K-tile within the M-tile
                gt1 = Var(gt_begin + m1)
                q_base1 = Var((gt1 // tiles_m_per_b) * MQ)
                kv_base1 = Var((gt1 // tiles_m_per_b) * N)
                m0_1 = Var((gt1 % tiles_m_per_b) * TILE_M)
                valid_m1 = Min(TILE_M, MQ - m0_1)
                n0 = Var(k1 * TILE_N)
                valid_n = Min(TILE_N, N - n0)
                if k1 == 0:                                       # new M-tile: load Q, reset softmax state
                    l1q[m1][0:valid_m1, 0:D] <<= q[q_base1 + m0_1:q_base1 + m0_1 + valid_m1, 0:D]
                    init_softmax_state_vf(ub_rmax, ub_rsum[m1])
                l1k[step][0:valid_n, 0:D] <<= k[kv_base1 + n0:kv_base1 + n0 + valid_n, 0:D]
                matmul(l0c[l0c_cnt], l1k[step], l1q[m1],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
                cv.lock()
                l0c_to_ub(ub_score[step], l0c[l0c_cnt][0:TILE_N, 0:TILE_M],
                          M=TILE_N, N=TILE_M, N_dst=ROWS_PER_SB, M_src=TILE_N,
                          dual_mode=DualMode.SPLITN, sub_block_id=0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_t_tail_vf(ub_score[step], ub_rmax, ub_rsum[m1], ub_p,
                                      ub_old_weight[wi1], valid_n)
                else:
                    softmax_t_vf(ub_score[step], ub_rmax, ub_rsum[m1], ub_p,
                                 ub_old_weight[wi1])
                cv.free()
                p_mutex.lock()
                l1p[wi1][0:HALF, row_begin:row_begin + ROWS_PER_SB] <<= (
                    ub_p.nz()[0:HALF, 0:ROWS_PER_SB])                          # keys 0-63
                l1p[wi1][HALF:TILE_N, row_begin:row_begin + ROWS_PER_SB] <<= (
                    ub_p.nz()[0:HALF, ROWS_PER_SB:2 * ROWS_PER_SB])            # keys 64-127
                p_mutex.ready()
                l0c_cnt += 1

            if step >= PRELOAD_N:
                # === STAGE 2 @ wi2=step-PRELOAD_N (lag-2): PV -> accum, finalize at the M-tile's last K ===
                wi2 = Var(step - PRELOAD_N)
                m2 = Var(wi2 // k_tiles)
                k2 = Var(wi2 % k_tiles)
                gt2 = Var(gt_begin + m2)
                q_base2 = Var((gt2 // tiles_m_per_b) * MQ)
                kv_base2 = Var((gt2 // tiles_m_per_b) * N)
                m0_2 = Var((gt2 % tiles_m_per_b) * TILE_M)
                valid_m2 = Min(TILE_M, MQ - m0_2)
                local_rows2 = Min(ROWS_PER_SB, Max(valid_m2 - row_begin, 0))
                n0_2 = Var(k2 * TILE_N)
                v_rows = Min(TILE_N, N - n0_2)
                l1v[step][0:v_rows, 0:D] <<= v[kv_base2 + n0_2:kv_base2 + n0_2 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c[l0c_cnt][0:TILE_M, 0:D_HEAD], l1p[wi2].T, l1v[step].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)   # no-split: k=128 fits L0
                p_mutex.free()
                pv_mutex.lock()
                l0c_to_ub(ub_pv[step], l0c[l0c_cnt][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()
                if k2 == 0:
                    accum_pv_first_vf(ub_accum[m2], ub_pv[step])
                else:
                    accum_pv_vf(ub_accum[m2], ub_pv[step], ub_old_weight[wi2])
                pv_mutex.free()
                l0c_cnt += 1
                if k2 == k_tiles - 1:                             # M-tile complete: normalize + store
                    final_div_cast_bf16_vf(ub_accum[m2], ub_rsum[m2], ub_out[m2])
                    if local_rows2 > 0:
                        out[q_base2 + m0_2 + row_begin:q_base2 + m0_2 + row_begin + local_rows2, 0:D] <<= (
                            ub_out[m2][0:local_rows2, 0:D])
    return out


# ---- reference / runner ------------------------------------------------------
def _ref_mqa(q, k, v, b_n, hq, sq, skv, bf16_p=False):
    """Per-(batch, head) MQA reference: q is [B*HQ*SQ, D] (batch outer, head, query inner), k/v are
    [B*SKV, D] (each batch has its OWN KV; heads within a batch SHARE it). Each (b,h) attends q[b,h]
    over batch b's KV. bf16_p rounds P to bf16 before PV (matches the kernel's bf16 P^T pack)."""
    qf = q.float(); kf = k.float(); vf = v.float()
    outs = []
    for b in _pyrange(b_n):
        kb = kf[b * skv:(b + 1) * skv]; vb = vf[b * skv:(b + 1) * skv]   # this batch's shared KV
        for h in _pyrange(hq):
            base = b * hq * sq + h * sq
            qh = qf[base:base + sq]                                       # this (b,h)'s queries [SQ, D]
            p = torch.softmax((qh @ kb.t()) * SOFTMAX_SCALE, dim=-1)      # [SQ, SKV]
            if bf16_p:
                p = p.to(torch.bfloat16).float()
            outs.append(p @ vb)                                          # [SQ, D]
    o = torch.cat(outs, dim=0)                                            # [B*HQ*SQ, D]
    return o.to(torch.bfloat16).float() if bf16_p else o


def _err(a, b):
    d = (torch.as_tensor(a).float() - torch.as_tensor(b).float()).abs()
    return d.max().item(), d.mean().item()


def main():
    torch.manual_seed(0)
    H = int(os.environ.get("PV_CORES", "1"))        # query-tiles (1 -> core0, SQ=128)
    KT = int(os.environ.get("PV_KTILES", "4"))      # key-tiles
    B = int(os.environ.get("PV_B", "1"))            # batch (each batch has its own KV)
    HQ = int(os.environ.get("PV_HQ", "1"))          # MQA query heads (HKV=1: all share one KV head)
    SQ = int(os.environ.get("PV_SQ", str(TILE_M * H)))    # per-head query rows; PV_SQ/PV_SKV override for tails
    SKV = int(os.environ.get("PV_SKV", str(TILE_N * KT)))
    MQ = HQ * SQ                                     # per-batch query rows (heads flattened) -> q:[B*MQ, D]
    q = torch.randn((B * MQ, D_HEAD), dtype=torch.float32).to(torch.bfloat16)
    k = torch.randn((B * SKV, D_HEAD), dtype=torch.float32).to(torch.bfloat16)
    v = torch.randn((B * SKV, D_HEAD), dtype=torch.float32).to(torch.bfloat16)
    out = torch.zeros((B * MQ, D_HEAD), dtype=torch.bfloat16)
    mode = os.environ.get("PV_MODE", "sim")
    profile = os.environ.get("PV_PROFILE", "0") == "1"
    d = "./tmp/pfa_replicate_pvflat_" + mode
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, out, B, MQ, SKV, D_HEAD)
    # scalar args index: B=0, MQ=1, N=2, D=3. Flattened row-dim (B*MQ for q/out, B*N for k/v) is a
    # composite -> bind None when B>1 (dynamic); when B==1 it equals MQ/N so bind it for the check.
    sb = {0: [1 if B == 1 else None, 3], 1: [2 if B == 1 else None, 3],
          2: [2 if B == 1 else None, 3], 3: [1 if B == 1 else None, 3]}
    print("MQA+batch: B={} HQ={} HKV=1 SQ={} SKV={} -> q[{}x{}] k/v[{}x{}] MQ={} N={} D={}".format(
        B, HQ, SQ, SKV, B * MQ, D_HEAD, B * SKV, D_HEAD, MQ, SKV, D_HEAD))
    if mode == "sim":
        outs = OpExec(qk_softmax_pv_kernel, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        outs = OpExec(qk_softmax_pv_kernel, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, cannsim=True)(*args, shape_bindings=sb)
    elif mode == "hw":
        outs = OpExec(qk_softmax_pv_kernel, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")
    O = torch.as_tensor(outs).float()
    o_ref = _ref_mqa(q, k, v, B, HQ, SQ, SKV)
    o_ref_bf = _ref_mqa(q, k, v, B, HQ, SQ, SKV, bf16_p=True)
    print("|O| max={:.3f}".format(O.abs().max().item()))
    print("O vs fp32 ref:  max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref.to(torch.bfloat16).float())))
    print("O vs bf16-P ref: max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref_bf)))


if __name__ == "__main__":
    main()
