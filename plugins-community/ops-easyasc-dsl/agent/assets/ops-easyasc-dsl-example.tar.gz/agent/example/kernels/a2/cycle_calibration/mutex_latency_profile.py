import argparse
import os
from typing import Iterable, Tuple

import torch

from easyasc.a2 import *


OUT_ELEMS = 64
DEFAULT_ITERS = (2000, 4000, 8000, 16000)


@kernel()
def mutex_empty_loop_kernel(dummy: GMTensor, out: GMTensor, iters: Var):
    out_ub = Tensor(DT.float, [1, OUT_ELEMS], Position.UB)

    for _ in range(0, iters):
        pass

    with auto_sync():
        dup(out_ub, 0.0)
        out[0:1, 0:OUT_ELEMS] <<= out_ub
    return out


@kernel()
def mutex_cv_loop_kernel(dummy: GMTensor, out: GMTensor, iters: Var):
    out_ub = Tensor(DT.float, [1, OUT_ELEMS], Position.UB)
    cv_mutex = CvMutex(0, 1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.MTE2)

    for _ in range(0, iters):
        cv_mutex.lock()
        cv_mutex.ready()
        cv_mutex.wait()
        cv_mutex.free()

    with auto_sync():
        dup(out_ub, 1.0)
        out[0:1, 0:OUT_ELEMS] <<= out_ub
    return out


@kernel()
def mutex_vc_loop_kernel(dummy: GMTensor, out: GMTensor, iters: Var):
    out_ub = Tensor(DT.float, [1, OUT_ELEMS], Position.UB)
    vc_mutex = VcMutex(1, 1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)

    for _ in range(0, iters):
        vc_mutex.lock()
        vc_mutex.ready()
        vc_mutex.wait()
        vc_mutex.free()

    with auto_sync():
        dup(out_ub, 2.0)
        out[0:1, 0:OUT_ELEMS] <<= out_ub
    return out


def _parse_iters(text: Iterable[str]) -> Tuple[int, ...]:
    values = tuple(int(item) for item in text)
    if not values:
        raise ValueError("at least one iteration count is required")
    for value in values:
        if value <= 0:
            raise ValueError("iteration counts must be positive")
    return values


def _run_one(case_name: str, kernel_func, iters: int, args) -> None:
    dummy = torch.zeros((1, OUT_ELEMS), dtype=torch.float32)
    out = torch.empty((1, OUT_ELEMS), dtype=torch.float32)
    out_dir = os.path.join(args.out_root, f"{case_name}_{iters}")
    actual = OpExec(
        kernel_func,
        out_dir=out_dir,
        cann_path=args.cann_path,
        custom_op_path=args.custom_op_path,
        simulator=args.simulator,
        profile=True,
        gen_only=args.gen_only,
        skip_compile=args.skip_compile,
    )(dummy, out, iters, shape_bindings={0: [None, None], 1: [None, None]})

    if args.simulator:
        expected = {"empty": 0.0, "cv": 1.0, "vc": 2.0}[case_name]
        torch.testing.assert_close(actual, torch.full_like(out, expected), rtol=1e-5, atol=1e-5)
    print(f"case={case_name} iters={iters} out_dir={out_dir}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Generate/profile A2 empty-loop and mutex-only kernels. "
            "Use hardware times at several iteration counts to estimate cross-side mutex latency."
        )
    )
    parser.add_argument("--iters", nargs="+", default=[str(v) for v in DEFAULT_ITERS])
    parser.add_argument("--case", choices=("all", "empty", "cv", "vc"), default="all")
    parser.add_argument("--out-root", default="./tmp/a2_mutex_latency_profile")
    parser.add_argument("--cann-path", default=None)
    parser.add_argument("--custom-op-path", default="./")
    parser.add_argument("--gen-only", action="store_true")
    parser.add_argument("--skip-compile", action="store_true")
    parser.add_argument("--simulator", action="store_true")
    args = parser.parse_args()

    iters_values = _parse_iters(args.iters)
    os.makedirs(args.out_root, exist_ok=True)

    cases = (
        ("empty", mutex_empty_loop_kernel),
        ("cv", mutex_cv_loop_kernel),
        ("vc", mutex_vc_loop_kernel),
    )
    for iters in iters_values:
        for case_name, kernel_func in cases:
            if args.case != "all" and args.case != case_name:
                continue
            _run_one(case_name, kernel_func, iters, args)

    print(
        "Estimate with: cycles=time_us*1800, "
        "delta=(mutex_cycles-empty_cycles), latency ~= slope(delta vs iters)/2.",
        flush=True,
    )


if __name__ == "__main__":
    main()
