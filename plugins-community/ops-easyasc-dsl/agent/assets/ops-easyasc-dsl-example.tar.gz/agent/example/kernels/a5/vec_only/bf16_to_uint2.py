"""A5 vec-only BF16 -> packed uint2 conversion.

Contract:
- input: ``x`` is BF16 ND with fixed shape ``[64, 128]``;
- every input value is exactly one of ``0, 1, 2, 3``;
- output: ``y_carrier`` is uint8 with shape ``[64, 32]``;
- every output byte stores four consecutive uint2 values, with the lower-index
  value in the less-significant bits.
"""

import builtins
import itertools
import os
import sys

import torch

from easyasc.a5 import *


ROWS = 64
COLS = 128
PACKED_COLS = COLS // 4


@vf()
def cast_bf16_to_uint2_vf(src: Tensor, dst: Tensor):
    src_bf16 = Reg(DT.bfloat16, name="src_bf16")
    src_half = Reg(DT.half, name="src_half")
    sparse_u8 = Reg(DT.uint8, name="sparse_u8")
    sparse_u16 = sparse_u8.reinterpret(DT.uint16, name="sparse_u16")
    dense_u8 = Reg(DT.uint8, name="dense_u8")
    dense_u32 = dense_u8.reinterpret(DT.uint32, name="dense_u32")

    shifted6 = Reg(DT.uint32, name="shifted6")
    packed_pairs = Reg(DT.uint32, name="packed_pairs")
    shifted12 = Reg(DT.uint32, name="shifted12")
    packed_quads = Reg(DT.uint32, name="packed_quads")
    packed_quads_u8 = packed_quads.reinterpret(DT.uint8, name="packed_quads_u8")

    mask_b16 = MaskReg(DT.bfloat16, name="mask_b16")
    mask_u8_all = MaskReg(DT.uint8, name="mask_u8_all")
    mask_u32_low32 = MaskReg(DT.uint32, init_mode=MaskType.LOWEST32, name="mask_u32_low32")
    mask_pack4_low32 = MaskReg(DT.uint8, init_mode=MaskType.LOWEST128, name="mask_pack4_low32")

    bf16_to_half_cfg = CastConfig(
        round_mode=RoundMode.TO_EVEN,
        reg_layout=RegLayout.ZERO,
        name="bf16_to_half_rint",
    )
    half_to_u8_cfg = CastConfig(
        round_mode=RoundMode.TO_EVEN,
        reg_layout=RegLayout.ZERO,
        name="half_to_u8_rint",
    )

    src_bf16 <<= src[0]
    cast(src_half, src_bf16, bf16_to_half_cfg, mask_b16)
    cast(sparse_u8, src_half, half_to_u8_cfg, mask_u8_all)

    # half -> uint8 with RegLayout.ZERO places each value in the low byte of a
    # uint16 lane. Native Pack compacts those 128 bytes into the low half.
    pack(dense_u8, sparse_u16, HighLowPart.LOWEST)

    # Each uint32 lane now contains four byte values:
    #   w = a | (b << 8) | (c << 16) | (d << 24), a..d in [0, 3].
    # The two shift/or stages move them to bit positions 0, 2, 4, and 6.
    shiftrs(shifted6, dense_u32, 6, mask=mask_u32_low32)
    vor(packed_pairs, dense_u32, shifted6, mask=mask_u32_low32)
    shiftrs(shifted12, packed_pairs, 12, mask=mask_u32_low32)
    vor(packed_quads, packed_pairs, shifted12, mask=mask_u32_low32)

    # One packed uint2 carrier is now in the low byte of each active uint32
    # lane. PACK4_B32 writes those 32 bytes contiguously to UB.
    dst[0] <<= mask_pack4_low32 * packed_quads_u8.pack4()


@kernel(mode="vec")
def bf16_to_uint2_kernel(x: GMTensor, y_carrier: GMTensor, rows: Var):
    ub_src = Tensor(DT.bfloat16, [1, COLS], Position.UB, name="ub_src")
    ub_dst = Tensor(DT.uint8, [1, PACKED_COLS], Position.UB, name="ub_dst")

    rows_per_vec = CeilDiv(rows, GetVecNum())
    row_begin = Var(rows_per_vec * GetVecIdx())
    row_end = Min(row_begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(row_begin, row_end, name="row"):
            ub_src[:, :] <<= x[row:row + 1, :]
            cast_bf16_to_uint2_vf(ub_src, ub_dst)
            y_carrier[row:row + 1, :] <<= ub_dst

    return y_carrier


def _build_input() -> torch.Tensor:
    # Exhaust all 4^4 possible uint2 quadruples; eight repeats fill [64, 128].
    groups = torch.tensor(list(itertools.product(builtins.range(4), repeat=4)), dtype=torch.bfloat16)
    return groups.repeat(8, 1).reshape(ROWS, COLS).contiguous()


def _pack_uint2_golden(x: torch.Tensor) -> torch.Tensor:
    values = x.to(torch.uint8)
    return (
        values[:, 0::4]
        | (values[:, 1::4] << 2)
        | (values[:, 2::4] << 4)
        | (values[:, 3::4] << 6)
    ).contiguous()


def _run(use_cannsim: bool, gen_only: bool) -> None:
    x = _build_input()
    y = torch.zeros((ROWS, PACKED_COLS), dtype=torch.uint8)
    mode_dir = "cannsim" if use_cannsim else "sim"

    actual = OpExec(
        bf16_to_uint2_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/bf16_to_uint2/custom_opp"),
        out_dir=os.path.abspath(f"tmp/bf16_to_uint2/{mode_dir}"),
    )(x, y, ROWS)

    if gen_only:
        print("bf16_to_uint2 gen_only complete")
        return

    expected = _pack_uint2_golden(x)
    if not torch.equal(actual, expected):
        mismatch = torch.nonzero(actual != expected, as_tuple=False)
        first = mismatch[0].tolist()
        raise AssertionError(
            "packed uint2 mismatch count={} first_index={} actual=0x{:02x} expected=0x{:02x}".format(
                int(mismatch.shape[0]), first, int(actual[tuple(first)].item()), int(expected[tuple(first)].item())
            )
        )

    print("bf16_to_uint2 passed carrier_mismatches=0 checked_bytes={}".format(int(actual.numel())))


if __name__ == "__main__":
    _run(use_cannsim="--cannsim" in sys.argv[1:], gen_only="--gen-only" in sys.argv[1:])
