"""V6 + METADATA scalar-precompute experiment for the scalar-bound hypothesis.

BOARD RESULT (s4099 3-way): NEGATIVE / no-op. scalar is ISSUE-WIDTH bound, not div-unit
bound, so swapping div→GM-load does nothing (meta-8 `aic_scalar_ratio` 0.312→0.312 unchanged). meta-8's
−0.59% is dead-load removal (MTE2), meta-ext's +0.74% is the +3 flag loads. Kept as the falsification
record; the real fixpipe-util ceiling is per-op config-set, not scalar.

V6's steady loop recomputes expensive scalar ops PER step (t//k_tiles, t%k_tiles, mt//tiles_m_per_b,
mt%tiles_m_per_b, plus muls/mins), and again on the lag (PV) side. If scalar is the real silicon bound
(cannsim models scalar 12.9x-parallel, likely optimistic), moving those divisions/mods to a host-
precomputed metadata GM tensor and reading them back with `var <<= meta[0, idx]` (GetValueFrom, GM scalar
load) cuts the scalar work. This is a straight copy of the all-hif8 V6 split-N schedule with
ONLY the per-step / per-lag index scalars replaced by metadata lookups — everything else (buffers,
mutexes, matmuls, VFs) is identical, so a correctness + cannsim/board A/B isolates the scalar effect.

A bulk-to-UB variant was tried but is INFEASIBLE: UB is AIV(vector)-local, so a scalar loaded from UB
(e.g. kt) has no writer on the AIC(cube) side, yet it controls cube-side matmul branches (`if kt==0`)
-> compile-time AIC/AIV side-split error. GM is global (both sides can scalar-load) so GM-direct is the
only viable metadata path.

meta layout: flat int32 [1, total_tasks * META_F], row t = [mt, kt, q_base, kv_base, m0, n0, valid_m,
valid_n] (META_F=8). batch/local_mt were dead loads (q_base/kv_base/m0/n0 already precomputed on host)
and were removed. qm/sm (mt%2, mt%CACHE) stay in-core (cheap bit/small-mod); local_rows stays in-core
(depends on the runtime per-subblock row_begin, not precomputable).
"""
import builtins
import math
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5pr") == "a5":
    from easyasc.a5 import *
else:
    from easyasc.a5pr import *
from easyasc.simulator.config import SimulatorConfig

# Reuse the common VFs and helpers so this file only owns the metadata schedule delta.
import pfa_fd_hif8_probe_common as V6
from pfa_fd_hif8_probe_common import (
    init_softmax_state_vf, softmax_t_scale_vf, softmax_t_scale_tail_vf,
    accum_pv_vf, accum_pv_first_vf, init_accum_vf, final_div_cast_bf16_vf,
    fd_merge_vf, output_cast_vf,
    TILE_M, ROWS_PER_SB, QLANES, TILE_N, D_HEAD, HALF, CHUNKS_D, KROW,
    PRELOAD_N, CACHE, MAX_CORE_COUNT, MAX_FD_WS, SOFTMAX_SCALE,
    fp32_to_hif8, hif8_to_fp32,
)

_pyrange = builtins.range
D_HEAD_ = D_HEAD
META_F = 8  # mt, kt, q_base, kv_base, m0, n0, valid_m, valid_n  (batch/local_mt removed: dead loads)
META_F_EXT = 11  # meta-EXT experiment: [mt, q_base, kv_base, m0, n0, valid_m, valid_n, sm, qm, first_k, last_k]
#                  (also stores the cheap sm=mt%CACHE / qm=mt%2 / first_k=kt==0 / last_k=kt==k_tiles-1;
#                   kt dropped since flags replace all its compares. +3 GM load vs -7 ALU op per step-pair.)


@func()
def _meta_fd_body(q, k, v, out, meta, B, MQ, N, D):
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    cv = CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                 src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    pv_mutex = CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = TBuff(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)

    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_old_weight = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_rmax = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_rsum = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_sum")

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)

    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_blocks = Var(B * tiles_m_per_b)
    total_tasks = Var(total_blocks * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    set_constant_to_l1(l1v[0].reinterpret(DT.uint8), 0)
    set_constant_to_l1(l1v[1].reinterpret(DT.uint8), 0)
    set_constant_to_l1(l1v[2].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mbase = Var(t * META_F)
                # ---- metadata lookups replace: mt//kt via k_tiles, q_base/kv_base muls,
                #      m0/n0 muls, valid_m/valid_n mins ----
                mt = Var(0, DT.int); mt <<= meta[0, mbase + 0]
                kt = Var(0, DT.int); kt <<= meta[0, mbase + 1]
                q_base = Var(0, DT.int); q_base <<= meta[0, mbase + 2]
                kv_base = Var(0, DT.int); kv_base <<= meta[0, mbase + 3]
                m0 = Var(0, DT.int); m0 <<= meta[0, mbase + 4]
                n0 = Var(0, DT.int); n0 <<= meta[0, mbase + 5]
                valid_m = Var(0, DT.int); valid_m <<= meta[0, mbase + 6]
                valid_n = Var(0, DT.int); valid_n <<= meta[0, mbase + 7]
                qm = Var(mt % 2)      # cheap bit-mod, keep in-core
                sm = Var(mt % CACHE)  # cheap small-mod, keep in-core

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                V6._qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_t_scale_tail_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                            ub_old_weight[step], valid_n)
                else:
                    softmax_t_scale_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                       ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                               m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lbase = Var(lag_t * META_F)
                lag_mt = Var(0, DT.int); lag_mt <<= meta[0, lbase + 0]
                lag_kt = Var(0, DT.int); lag_kt <<= meta[0, lbase + 1]
                lag_q_base = Var(0, DT.int); lag_q_base <<= meta[0, lbase + 2]
                lag_kv_base = Var(0, DT.int); lag_kv_base <<= meta[0, lbase + 3]
                lag_m0 = Var(0, DT.int); lag_m0 <<= meta[0, lbase + 4]
                lag_n0 = Var(0, DT.int); lag_n0 <<= meta[0, lbase + 5]
                lag_valid_m = Var(0, DT.int); lag_valid_m <<= meta[0, lbase + 6]
                v_rows = Var(0, DT.int); v_rows <<= meta[0, lbase + 7]  # = valid_n(lag_t)
                sm2 = Var(lag_mt % CACHE)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_kt == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                elif lag == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:
                    accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                merge_fn = fd_merge_vf
                merge_fn(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                         ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


@kernel()
def qk_softmax_pv_v6_meta_kernel(q: GMTensor, k: GMTensor, v: GMTensor, meta: GMTensor,
                                 out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _meta_fd_body(q, k, v, out, meta, B, MQ, N, D)


@func()
def _meta_fd_body_ext(q, k, v, out, meta, B, MQ, N, D):
    # meta-EXT: also precompute the cheap per-row scalars into GM so the loop READS them instead of
    # computing: sm=mt%CACHE, qm=mt%2, first_k=(kt==0), last_k=(kt==k_tiles-1). kt itself is dropped
    # (flags replace every kt compare). Trades +3 GM scalar-loads/step-pair for -7 ALU ops (3 mod +
    # 4 cmp). Everything else is identical to _meta_fd_body. layout META_F_EXT=11:
    #   [mt, q_base, kv_base, m0, n0, valid_m, valid_n, sm, qm, first_k, last_k]
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    cv = CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                 src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    pv_mutex = CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = TBuff(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)

    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_old_weight = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_rmax = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_rsum = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_sum")

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)

    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_blocks = Var(B * tiles_m_per_b)
    total_tasks = Var(total_blocks * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    set_constant_to_l1(l1v[0].reinterpret(DT.uint8), 0)
    set_constant_to_l1(l1v[1].reinterpret(DT.uint8), 0)
    set_constant_to_l1(l1v[2].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mbase = Var(t * META_F_EXT)
                # step reads only what it uses: skip mt (step-unused) + kt/last_k; qm/sm/first_k are loads now
                q_base = Var(0, DT.int); q_base <<= meta[0, mbase + 1]
                kv_base = Var(0, DT.int); kv_base <<= meta[0, mbase + 2]
                m0 = Var(0, DT.int); m0 <<= meta[0, mbase + 3]
                n0 = Var(0, DT.int); n0 <<= meta[0, mbase + 4]
                valid_m = Var(0, DT.int); valid_m <<= meta[0, mbase + 5]
                valid_n = Var(0, DT.int); valid_n <<= meta[0, mbase + 6]
                sm = Var(0, DT.int); sm <<= meta[0, mbase + 7]
                qm = Var(0, DT.int); qm <<= meta[0, mbase + 8]
                first_k = Var(0, DT.int); first_k <<= meta[0, mbase + 9]

                need_q = Var(0, DT.int)
                if first_k > 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                V6._qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_t_scale_tail_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                            ub_old_weight[step], valid_n)
                else:
                    softmax_t_scale_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                       ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                               m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lbase = Var(lag_t * META_F_EXT)
                # lag reads: skip qm (step-only); sm2 = sm(lag row); first_k/last_k replace kt compares
                lag_mt = Var(0, DT.int); lag_mt <<= meta[0, lbase + 0]
                lag_q_base = Var(0, DT.int); lag_q_base <<= meta[0, lbase + 1]
                lag_kv_base = Var(0, DT.int); lag_kv_base <<= meta[0, lbase + 2]
                lag_m0 = Var(0, DT.int); lag_m0 <<= meta[0, lbase + 3]
                lag_n0 = Var(0, DT.int); lag_n0 <<= meta[0, lbase + 4]
                lag_valid_m = Var(0, DT.int); lag_valid_m <<= meta[0, lbase + 5]
                v_rows = Var(0, DT.int); v_rows <<= meta[0, lbase + 6]  # = valid_n(lag_t)
                sm2 = Var(0, DT.int); sm2 <<= meta[0, lbase + 7]
                lag_first_k = Var(0, DT.int); lag_first_k <<= meta[0, lbase + 9]
                lag_last_k = Var(0, DT.int); lag_last_k <<= meta[0, lbase + 10]
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_first_k > 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                elif lag == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:
                    accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_last_k > 0:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_last_k == 0:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                merge_fn = fd_merge_vf
                merge_fn(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                         ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


@kernel()
def qk_softmax_pv_v6_meta_ext_kernel(q: GMTensor, k: GMTensor, v: GMTensor, meta: GMTensor,
                                     out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _meta_fd_body_ext(q, k, v, out, meta, B, MQ, N, D)


def _build_meta(total_tasks, k_tiles, tiles_m_per_b, MQ, SKV):
    m = torch.zeros(1, total_tasks * META_F, dtype=torch.int32)  # flat [1, task*field]; rank-2 for GM scalar-load
    for t in _pyrange(total_tasks):
        mt = t // k_tiles; kt = t % k_tiles
        batch = mt // tiles_m_per_b; local_mt = mt % tiles_m_per_b
        q_base = batch * MQ; kv_base = batch * SKV
        m0 = local_mt * TILE_M; n0 = kt * TILE_N
        valid_m = min(TILE_M, MQ - m0); valid_n = min(TILE_N, SKV - n0)
        m[0, t * META_F:(t + 1) * META_F] = torch.tensor(
            [mt, kt, q_base, kv_base, m0, n0, valid_m, valid_n], dtype=torch.int32)
    return m


def _build_meta_ext(total_tasks, k_tiles, tiles_m_per_b, MQ, SKV):
    m = torch.zeros(1, total_tasks * META_F_EXT, dtype=torch.int32)
    for t in _pyrange(total_tasks):
        mt = t // k_tiles; kt = t % k_tiles
        batch = mt // tiles_m_per_b; local_mt = mt % tiles_m_per_b
        q_base = batch * MQ; kv_base = batch * SKV
        m0 = local_mt * TILE_M; n0 = kt * TILE_N
        valid_m = min(TILE_M, MQ - m0); valid_n = min(TILE_N, SKV - n0)
        sm = mt % CACHE; qm = mt % 2
        first_k = 1 if kt == 0 else 0
        last_k = 1 if kt == k_tiles - 1 else 0
        m[0, t * META_F_EXT:(t + 1) * META_F_EXT] = torch.tensor(
            [mt, q_base, kv_base, m0, n0, valid_m, valid_n, sm, qm, first_k, last_k], dtype=torch.int32)
    return m


def _ref_mqa(qf, kf, vf, b_n, hq, sq, skv, quant_p=False):
    outs = []
    for b in _pyrange(b_n):
        kb = kf[b * skv:(b + 1) * skv]; vb = vf[b * skv:(b + 1) * skv]
        for h in _pyrange(hq):
            base = b * hq * sq + h * sq
            qh = qf[base:base + sq]
            p = torch.softmax((qh @ kb.t()) * SOFTMAX_SCALE, dim=-1)
            if quant_p:
                p = hif8_to_fp32(fp32_to_hif8(p))
            outs.append(p @ vb)
    o = torch.cat(outs, dim=0)
    return o.to(torch.bfloat16).float() if quant_p else o


def _err(a, b):
    d = (torch.as_tensor(a).float() - torch.as_tensor(b).float()).abs()
    return d.max().item(), d.mean().item()


def main():
    meta_mode = os.environ.get("PV_META_MODE", "gm")  # gm = meta-8; ext = meta-11 (also stores sm/qm/flags)
    kern = qk_softmax_pv_v6_meta_ext_kernel if meta_mode == "ext" else qk_softmax_pv_v6_meta_kernel
    build_meta = _build_meta_ext if meta_mode == "ext" else _build_meta
    torch.manual_seed(0)
    B = int(os.environ.get("PV_B", "1"))
    HQ = int(os.environ.get("PV_HQ", "8"))
    SQ = int(os.environ.get("PV_SQ", "257"))
    SKV = int(os.environ.get("PV_SKV", "256"))
    MQ = HQ * SQ
    q_fp32 = torch.randn((B * MQ, D_HEAD), dtype=torch.float32)
    k_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    v_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    q = fp32_to_hif8(q_fp32); k = fp32_to_hif8(k_fp32); v = fp32_to_hif8(v_fp32)
    out = torch.zeros((B * MQ, D_HEAD), dtype=torch.bfloat16)

    tiles_m_per_b = (MQ + TILE_M - 1) // TILE_M
    k_tiles = (SKV + TILE_N - 1) // TILE_N
    total_blocks = B * tiles_m_per_b
    total_tasks = total_blocks * k_tiles
    meta = build_meta(total_tasks, k_tiles, tiles_m_per_b, MQ, SKV)

    mode = os.environ.get("PV_MODE", "sim")
    sim_cores = int(os.environ.get("PV_SIM_CORES", "4"))
    force_1core = os.environ.get("PV_1CORE", "0") == "1"
    if force_1core:
        import easyasc.kernelbase.kernelbase as _kb
        _kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda *a, **k: 1)
    launch_cores = 1 if force_1core else (sim_cores if mode == "sim" else MAX_CORE_COUNT)
    debug = os.environ.get("PV_DEBUG", "0") == "1"
    profile = os.environ.get("PV_PROFILE", "0") == "1"
    ok, max_owners, split_blocks = V6._pairwise_split_ok(total_blocks, k_tiles, launch_cores)
    if not ok:
        raise SystemExit("pairwise split precondition failed: max_owners={}".format(max_owners))

    kern._simulator_config = SimulatorConfig(core_count=(1 if force_1core else sim_cores), execution_timeout_s=3600.0)

    d = os.environ.get("PV_OUT_DIR") or "./tmp/pfa_fd_v6meta_{}_{}".format(meta_mode, mode)
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, meta, out, B, MQ, SKV, D_HEAD)
    sb = {0: [1 if B == 1 else None, 3], 1: [2 if B == 1 else None, 3],
          2: [2 if B == 1 else None, 3], 3: [None, None],
          4: [1 if B == 1 else None, 3]}

    print("V6-META[{}]: B={} HQ={} SQ={} SKV={} blocks={} k_tiles={} tasks={} cores={} split={}".format(
        meta_mode, B, HQ, SQ, SKV, total_blocks, k_tiles, total_tasks, launch_cores, split_blocks))
    if mode == "sim":
        outs = OpExec(kern, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, cannsim=True, debug=debug)(*args, shape_bindings=sb)
    elif mode == "hw":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")

    O = torch.as_tensor(outs).float()
    qf = hif8_to_fp32(q); kf = hif8_to_fp32(k); vf = hif8_to_fp32(v)
    o_ref = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV)
    o_ref_q = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV, quant_p=True)
    print("|O| max={:.3f}".format(O.abs().max().item()))
    print("O vs fp32 ref:     max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref.to(torch.bfloat16).float())))
    print("O vs hif8-P/V ref: max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref_q)))


if __name__ == "__main__":
    main()
