"""On-board PROBE + roundtrip for the MaskReg<->UB overloads (LoadAlign/StoreAlign MaskReg).

STORE decode (board-verified 2026-07-21): a b32 mask (VL=64) stores as the FULL 32-byte
(256-bit) vector-mask register; element-lane i's bit lands at bit position i*elem_size
(LSB-first). e.g. active lanes {0,1,3,7,15,31,63} -> byte0=0b00010001=17, byte1/3/7/15/31=16.

This runner drives one kernel that (1) builds m1 via compare(pat>0), (2) stores m1 to UB and
dumps all 32 bytes (confirms the packing + that exactly 32 bytes are written), (3) loads it
back into m2 via ub_to_mask, (4) uses m2 in select(7,0) so the active lanes reappear as 7 --
validating BOTH directions in a single board build. Run with --run.
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

_ACTIVE = [0, 1, 3, 7, 15, 31, 63]


@vf()
def rt_vf(pat_ub, sa_ub, sel_ub):
    r = Reg(DT.int, name="rt_r"); ub_to_reg_normal(r, pat_ub)
    z = Reg(DT.int, name="rt_z"); dup(z, 0)
    m1 = MaskReg(DT.int, name="rt_m1")
    compare(m1, r, z, CompareMode.GT)               # active iff pat[lane] > 0
    zb = Reg(DT.uint8, name="rt_zb"); dup(zb, 0); reg_to_ub_normal(sa_ub, zb)  # zero 256B
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    mask_to_ub(sa_ub, m1)                           # StoreAlign(sa_ub, m1): 32 mask bytes
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)           # RAW on sa_ub before reloading
    m2 = MaskReg(DT.int, name="rt_m2")
    ub_to_mask(m2, sa_ub)                           # LoadAlign(m2, sa_ub)
    seven = Reg(DT.int, name="rt_sv"); dup(seven, 7)
    zr = Reg(DT.int, name="rt_zr"); dup(zr, 0)
    outr = Reg(DT.int, name="rt_or"); dup(outr, 0)
    select(outr, seven, zr, m2)                     # outr = m2 ? 7 : 0
    reg_to_ub_normal(sel_ub, outr)


@kernel(mode="vec")
def rt_kernel(pat: GMTensor, sa: GMTensor, sel: GMTensor, rows: Var):
    pat_ub = Tensor(DT.int, [1, 64], Position.UB, name="rt_pat")
    sa_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="rt_sa")
    sel_ub = Tensor(DT.int, [1, 64], Position.UB, name="rt_sel")
    with auto_sync():
        pat_ub[:, :] <<= pat[0:1, :]
        rt_vf(pat_ub, sa_ub, sel_ub)
        sa[0:1, :] <<= sa_ub
        sel[0:1, :] <<= sel_ub
    return sa, sel


def main(run):
    pat = torch.zeros(1, 64, dtype=torch.int32)
    pat[0, _ACTIVE] = 1
    sa = torch.zeros(1, 256, dtype=torch.uint8)
    sel = torch.zeros(1, 64, dtype=torch.int32)
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    res = OpExec(rt_kernel, out_dir=os.path.abspath("tmp/maskprobe/rt"),
                 custom_op_path=os.path.abspath("tmp/maskprobe/opp"),
                 **cfg)(pat.contiguous(), sa, sel, 1)
    sa_o, sel_o = (res if isinstance(res, (tuple, list)) else (res, sel))
    sa_o = sa_o.reshape(-1); sel_o = sel_o.reshape(-1)

    # (1) store packing: expected byte pattern for a b32 mask, bit at i*4
    exp = [0] * 32
    for lane in _ACTIVE:  # python list, not range()
        exp[(lane * 4) // 8] |= (1 << ((lane * 4) % 8))
    got32 = sa_o[:32].to(torch.int64).tolist()
    tail_zero = int(sa_o[32:].to(torch.int64).abs().sum())
    print(f"active lanes: {_ACTIVE}")
    print(f"STORE bytes[0:32]: {got32}")
    print(f"STORE expect     : {exp}")
    print(f"STORE match: {got32 == exp}   bytes[32:] all-zero: {tail_zero == 0}")

    # (2) load->select roundtrip: lanes where sel==7 must equal _ACTIVE exactly
    active_back = sorted(int(i) for i in (sel_o == 7).nonzero(as_tuple=True)[0].tolist())
    others_zero = int(sel_o[(sel_o != 7)].abs().sum())
    print(f"LOAD->select active lanes: {active_back}")
    print(f"ROUNDTRIP match: {active_back == _ACTIVE}   non-active all-zero: {others_zero == 0}")
    ok = (got32 == exp) and (tail_zero == 0) and (active_back == _ACTIVE) and (others_zero == 0)
    print("ALL_OK" if ok else "MISMATCH")


if __name__ == "__main__":
    main("--run" in sys.argv[1:])
