"""Shared geometry for the stepwise NCHW conv2d pipeline (a2, fp16).

Spec (--debug, 910B3): x [1, 64, 256, 256] * w [128, 64, 3, 3],
stride 2, dilation 2 -> y [1, 128, 128, 128].
Effective filter is 5x5 (dilated 3x3), so SAME/2 needs pad 2 on every edge:
Ho = (H + 4 - 5) // 2 + 1 = H / 2.

Simulator runs the identical kernels on a shrunk plane (H = W = 32, all
channels kept full-size) so the python golden stays fast.

The H-direction pad rows are baked into the 5HD plane as zero rows (HP = H + 4)
so the compute kernel sees a per-output-row feature map slice with no runtime
pad-top/bottom switch: the Conv2D descriptor only pads left/right.
"""
import sys

DEBUG = "--debug" in sys.argv[1:]

C0 = 16
B = 1
CIN = 64
COUT = 128
KH = KW = 3
STRIDE = 2
DIL = 2
PAD = 2                                  # SAME pad for eff5/s2 (works in all 4 dirs)

H = W = 256 if DEBUG else 32
HO, WO = H // 2, W // 2
M = HO * WO                              # multiple of 16 (W >= 32)
HW = H * W
HP = H + 2 * PAD                         # zero-row padded 5HD height
C1 = CIN // C0                           # 4 (exact, no channel tail)
C1O = COUT // C0                         # 8
K = C1 * KH * KW * C0                    # 576
TILE_K = 96                              # 576 = 6 x 96; 96*128*2B = 24KB <= 32KB L0 slot

N_VEC = 40 if DEBUG else 2
N_CUBE = 20 if DEBUG else 1
