"""Minimal fp32 matmul with a C2/BT bias table (a5/950).

Low-level bias path (no matmul shortcut):
    gm_to_l1 (x, y, bias) -> l1_to_l0 (A, B) + l1_to_bt (bias)
    -> mmad(..., bias=bt)  [C = bias + A@B on the is_init tile]
    -> l0c_to_gm

Validated on both the simulator (default) and CANNSIM. The simulator models BT as
a logical [N] bias vector. For CANNSIM (VM only) force a single AI core (see
_force_single_core) and keep the matrix small -- this kernel does no per-core
partitioning, so 32 cores would redundantly recompute the same tile.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_bt.py             # simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_bt.py --gen-only
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_bt.py --cannsim   # VM only
"""
from easyasc.a5 import *


@kernel()
def matmul_float_bias_bt_kernel(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor,
                                M: Var, N: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l1b = Tensor(DT.float, [1, N], Position.L1)
    bt = Tensor(DT.float, [1, N], Position.BT)
    l0a = Tensor(DT.float, [M, K], Position.L0A)
    l0b = Tensor(DT.float, [N, K], Position.L0B)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        # Bias must land contiguously in L1 (the C2 bias-table load is a flat burst
        # copy). `<<=` would nd2nz-fractalize the [1,N] vector, scattering all but
        # the first fractal -- use a contiguous gm_to_l1_pad instead.
        gm_to_l1_pad(l1b, bias[:, :])
        l1_to_bt(bt, l1b, n=N)
        l1_to_l0(l0a, l1x)
        l1_to_l0(l0b, l1y)
        mmad(l0c, l0a, l0b, M=M, N=N, K=K, is_init=True, bias=bt)
        z[:, :] <<= l0c
    return z


def _force_single_core():
    """Force block_dim=1 so CANNSIM simulates one AI core (much faster). The DSL
    otherwise hardcodes 32 for 950; validation-only, does not touch the repo."""
    import easyasc.kernelbase.kernelbase as kb
    kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda device_type: 1)


if __name__ == "__main__":
    import os
    import sys

    import torch

    # Small + single-core keeps CANNSIM fast.
    M, N, K = 32, 64, 16
    torch.manual_seed(0)
    x = torch.randn((M, K), dtype=torch.float32)
    y = torch.randn((N, K), dtype=torch.float32)
    bias = torch.randn((1, N), dtype=torch.float32)
    z = torch.zeros((M, N), dtype=torch.float32)

    gen_only = "--gen-only" in sys.argv[1:]
    use_cannsim = "--cannsim" in sys.argv[1:]
    z_ref = x @ y.t() + bias

    if not gen_only and not use_cannsim:
        # Default: simulator (models the BT bias table as a logical [N] vector).
        z_out = OpExec(matmul_float_bias_bt_kernel, simulator=True)(x, y, bias, z, M, N, K)
        torch.testing.assert_close(z_out, z_ref, rtol=1e-4, atol=1e-4)
        print("simulator matmul+bias passed max_abs_diff={:.6e}".format(
            float(torch.abs(z_out - z_ref).max().item())))
    else:
        # CANNSIM / codegen path (VM-local build; single core for speed).
        if use_cannsim:
            _force_single_core()
        base = os.environ.get("BIAS_BASE", "./tmp/a5_bias_cannsim")
        out_dir = os.path.join(base, "biaskernel")
        z_out = OpExec(
            matmul_float_bias_bt_kernel,
            simulator=False,
            cannsim=use_cannsim,
            gen_only=gen_only,
            cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
            custom_op_path=os.path.join(base, "custom_opp"),
            out_dir=out_dir,
        )(x, y, bias, z, M, N, K)
        if gen_only:
            print("gen_only complete ->", out_dir)
        else:
            torch.testing.assert_close(z_out, z_ref, rtol=1e-4, atol=1e-4)
            print("cannsim matmul+bias passed max_abs_diff={:.6e}".format(
                float(torch.abs(z_out - z_ref).max().item())))
