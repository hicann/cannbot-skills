from easyasc.a2 import *


@kernel()
def matmul_half_basic_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    l1x = Tensor(DT.half, [m, k], Position.L1)
    l1y = Tensor(DT.half, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)

    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=m, n=n, k=k, is_init=True)
        z[:, :] <<= l0c
    return z


if __name__ == "__main__":
    import os
    import sys
    import torch

    m = 32
    n = 48
    k = 16
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"

    torch.manual_seed(0)
    x = torch.randn((m, k), dtype=torch.float16)
    y = torch.randn((n, k), dtype=torch.float16)
    z = torch.zeros((m, n), dtype=torch.float32)

    exec_kwargs = dict(simulator=True)
    if run:
        exec_kwargs = dict(
            simulator=False,
            debug=True,
            out_dir="./tmp/matmul_half_basic",
            cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        )
    z_kernel = OpExec(matmul_half_basic_kernel, **exec_kwargs)(x, y, z, m, n, k)
    z_ref = x.float() @ y.float().t()
    torch.testing.assert_close(z_kernel, z_ref, rtol=3e-3, atol=3e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
