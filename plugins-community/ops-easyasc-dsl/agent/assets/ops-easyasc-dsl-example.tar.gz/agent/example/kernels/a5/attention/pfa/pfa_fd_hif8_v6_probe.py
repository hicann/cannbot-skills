"""V6 ceiling-probe framework for isolating every pipe/stage's cost.

Systematic ablation of the all-hif8 V6 split-N schedule: each per-step stage is an entry in an
`_Ops` table (real op for `base`, a `_noop` stub for the probe), the two CvMutex are swapped for `_NoOpMutex`
(nocv), and the fd-merge tail is dropped by a separate merge-free body (nomerge). Drop ONE pipe/stage, run
on real HW → makespan(base) − makespan(noX) ≈ stage X's net contribution (its ceiling if fully hidden),
and the pipe-util shift shows what becomes the new bound.

Output is INCORRECT for every probe except `base` (dropping a stage feeds garbage downstream → nan): that
is BY DESIGN — read AVG makespan + the archived op_summary CSV pipe ratios, NOT the error number.

Probes (env `PV_PROBE`):
  base     control = unmodified V6 (correct, ~5.5e-3)
  nocv     _NoOpMutex for cv + pv_mutex (fixpipe↔vec sync) → cube/vec parallel ceiling
  nomerge  merge-free body (drop fd-merge tail)            → fd-merge share of makespan
  nofix    no-op QK-fix + PV-fix (l0c_to_ub)               → fixpipe ceiling
  nomac    no-op QK-mmad + PV-mmad (matmul)                → mac (cube-mmad) ceiling
  nomte2   K/V load shrunk to 1 elem (bandwidth→0)         → mte2 KV-load *bandwidth* ceiling (issue kept)
  novec    no-op softmax + accum + init/final VFs          → vec ceiling
  nopstore no-op P-store (ub→l1 nd2nz, mte3)               → P-chain store ceiling
Dispatch: PV_PROBE=base|nocv|nomerge|nofix|nomac|nomte2|novec|nopstore.

Design note — why a table+two-bodies and NOT one flag-gated body: easyasc's @func rewrites EVERY `if` in the
DECORATED body to `with If(test):`, whose body Python always executes at trace time. So `if flag: return out`
would always fire, and the DSL control flow (`if kt==0` on Vars) only gets rewritten when it is TEXTUALLY
inside the @func — it cannot be factored into a plain helper. Hence: full loop inlined in both bodies; stage
choice via `ops.*` call-dispatch (a call, not an `if`); mutex choice via plain Python (`_real_cv()` vs
`_NoOpMutex()`); merge choice via two bodies. This mirrors how _variant_fd_body passes VFs/dtype as params.
"""
import builtins
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5pr") == "a5":
    from easyasc.a5 import *
else:
    from easyasc.a5pr import *
from easyasc.simulator.config import SimulatorConfig

from pfa_fd_hif8_probe_common import (
    _CacheBuf,
    init_softmax_state_vf, softmax_t_scale_vf, softmax_t_scale_tail_vf,
    accum_pv_vf, accum_pv_first_vf, init_accum_vf, final_div_cast_bf16_vf,
    fd_merge_vf, output_cast_vf, _qk_bridge_splitn, _pairwise_split_ok,
    _ref_mqa, _err,
    TILE_M, ROWS_PER_SB, QLANES, TILE_N, D_HEAD, KROW, CACHE, PRELOAD_N,
    MAX_CORE_COUNT, MAX_FD_WS, fp32_to_hif8, hif8_to_fp32,
)

_pyrange = builtins.range


def _noop(*a, **k):
    """Stage-off stub: args (tensor-view indexing) have no side effect; emits no DSL op."""
    return None


def _mv(dst, src):
    """Real gm->l1 datamove, wrapped so it is a swappable _Ops entry."""
    dst <<= src


def _mv_tiny(dst, src):
    """nomte2 KV-load stub: move a single element instead of the full tile. Bandwidth -> ~0, but the load
    still issues and its gm offset keeps the kt/lag_kt data dependency alive on the cube side (a pure _noop
    prunes kt's only cube consumer -> `Side-split inconsistency on kt`). So nomte2 measures the KV-load
    *bandwidth* ceiling (per-load issue overhead is retained), not a full mte2 removal."""
    dst[0:1, 0:1] <<= src[0:1, 0:1]


class _NoOpMutex:
    """cv/pv_mutex stub for nocv: emits NO sync (proves auto_sync does NOT cover fixpipe->vec)."""
    def lock(self): pass
    def ready(self): pass
    def wait(self): pass
    def free(self): pass


class _Ops:
    """Per-stage op table. Defaults = the real V6 ops; a probe overrides one group with _noop."""
    def __init__(self, kload=_mv, vload=_mv, qk_mmad=None, qk_fix=None, softmax=None,
                 softmax_tail=None, init_state=None, pstore=None, pv_mmad=None, pv_fix=None,
                 init_accum=None, accum_first=None, accum=None, final=None):
        self.kload = kload
        self.vload = vload
        self.qk_mmad = qk_mmad if qk_mmad is not None else matmul
        self.qk_fix = qk_fix if qk_fix is not None else _qk_bridge_splitn
        self.softmax = softmax if softmax is not None else softmax_t_scale_vf
        self.softmax_tail = softmax_tail if softmax_tail is not None else softmax_t_scale_tail_vf
        self.init_state = init_state if init_state is not None else init_softmax_state_vf
        self.pstore = pstore if pstore is not None else ub_to_l1_nd2nz
        self.pv_mmad = pv_mmad if pv_mmad is not None else matmul
        self.pv_fix = pv_fix if pv_fix is not None else l0c_to_ub
        self.init_accum = init_accum if init_accum is not None else init_accum_vf
        self.accum_first = accum_first if accum_first is not None else accum_pv_first_vf
        self.accum = accum if accum is not None else accum_pv_vf
        self.final = final if final is not None else final_div_cast_bf16_vf


def _real_cv():
    return CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                   src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)


def _real_pv():
    return CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)


@func()
def _probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, ops):
    """Full V6 schedule + fd-merge tail; stages routed through `ops` (base=real, probe=one group no-op)."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    p_mutex = VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)

    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_sum")

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)

    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_blocks = Var(B * tiles_m_per_b)
    total_tasks = Var(total_blocks * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    ops.init_state(ub_rmax[sm], ub_rsum[sm])

                ops.kload(l1k[step][0:valid_n, 0:D], k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D])
                ops.qk_mmad(l0c_qk[step], l1k[step], l1q[qm],
                            m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                ops.qk_fix(ub_score[step], l0c_qk[step], 1.0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    ops.softmax_tail(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                     ub_old_weight[step], valid_n)
                else:
                    ops.softmax(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                ops.pstore(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                           m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                sm2 = Var(lag_mt % CACHE)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_local_mt = Var(lag_mt % tiles_m_per_b)
                lag_q_base = Var(lag_batch * MQ)
                lag_kv_base = Var(lag_batch * N)
                lag_m0 = Var(lag_local_mt * TILE_M)
                lag_valid_m = Min(TILE_M, MQ - lag_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                ops.vload(l1v[lag][0:v_rows, 0:D], v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D])
                p_mutex.wait()
                ops.pv_mmad(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                            m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                ops.pv_fix(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                           M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                           dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_kt == 0:
                    ops.init_accum(ub_accum)
                    ops.accum_first(ub_accum, ub_pv[lag])
                elif lag == 0:
                    ops.init_accum(ub_accum)
                    ops.accum_first(ub_accum, ub_pv[lag])
                else:
                    ops.accum(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        ops.final(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                fd_merge_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                            ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


@func()
def _probe_body_nomerge(q, k, v, out, B, MQ, N, D, cv, pv_mutex, ops):
    """Identical to _probe_body up to allvec_ready, then returns immediately (no allvec_wait + no fd-merge).
    makespan(base) − makespan(nomerge) = the fd-merge tail's share. INCORRECT for split blocks by design."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    p_mutex = VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)

    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_sum")

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)

    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_blocks = Var(B * tiles_m_per_b)
    total_tasks = Var(total_blocks * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    ops.init_state(ub_rmax[sm], ub_rsum[sm])

                ops.kload(l1k[step][0:valid_n, 0:D], k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D])
                ops.qk_mmad(l0c_qk[step], l1k[step], l1q[qm],
                            m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                ops.qk_fix(ub_score[step], l0c_qk[step], 1.0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    ops.softmax_tail(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                     ub_old_weight[step], valid_n)
                else:
                    ops.softmax(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                ops.pstore(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                           m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                sm2 = Var(lag_mt % CACHE)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_local_mt = Var(lag_mt % tiles_m_per_b)
                lag_q_base = Var(lag_batch * MQ)
                lag_kv_base = Var(lag_batch * N)
                lag_m0 = Var(lag_local_mt * TILE_M)
                lag_valid_m = Min(TILE_M, MQ - lag_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                ops.vload(l1v[lag][0:v_rows, 0:D], v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D])
                p_mutex.wait()
                ops.pv_mmad(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                            m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                ops.pv_fix(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                           M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                           dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_kt == 0:
                    ops.init_accum(ub_accum)
                    ops.accum_first(ub_accum, ub_pv[lag])
                elif lag == 0:
                    ops.init_accum(ub_accum)
                    ops.accum_first(ub_accum, ub_pv[lag])
                else:
                    ops.accum(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        ops.final(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    return out


_OPS_REAL = _Ops()
_OPS_NOFIX = _Ops(qk_fix=_noop, pv_fix=_noop)
_OPS_NOMAC = _Ops(qk_mmad=_noop, pv_mmad=_noop)
_OPS_NOMTE2 = _Ops(kload=_mv_tiny, vload=_mv_tiny)
_OPS_NOVEC = _Ops(softmax=_noop, softmax_tail=_noop, init_state=_noop,
                  init_accum=_noop, accum_first=_noop, accum=_noop, final=_noop)
_OPS_NOPSTORE = _Ops(pstore=_noop)


@kernel()
def probe_v6_base_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv = _real_cv(); pv_mutex = _real_pv()
    return _probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, _OPS_REAL)


@kernel()
def probe_v6_nocv_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv = _NoOpMutex(); pv_mutex = _NoOpMutex()
    return _probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, _OPS_REAL)


@kernel()
def probe_v6_nomerge_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv = _real_cv(); pv_mutex = _real_pv()
    return _probe_body_nomerge(q, k, v, out, B, MQ, N, D, cv, pv_mutex, _OPS_REAL)


@kernel()
def probe_v6_nofix_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv = _real_cv(); pv_mutex = _real_pv()
    return _probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, _OPS_NOFIX)


@kernel()
def probe_v6_nomac_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv = _real_cv(); pv_mutex = _real_pv()
    return _probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, _OPS_NOMAC)


@kernel()
def probe_v6_nomte2_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv = _real_cv(); pv_mutex = _real_pv()
    return _probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, _OPS_NOMTE2)


@kernel()
def probe_v6_novec_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv = _real_cv(); pv_mutex = _real_pv()
    return _probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, _OPS_NOVEC)


@kernel()
def probe_v6_nopstore_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv = _real_cv(); pv_mutex = _real_pv()
    return _probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, _OPS_NOPSTORE)


_PROBES = {
    "base": probe_v6_base_kernel, "nocv": probe_v6_nocv_kernel, "nomerge": probe_v6_nomerge_kernel,
    "nofix": probe_v6_nofix_kernel, "nomac": probe_v6_nomac_kernel, "nomte2": probe_v6_nomte2_kernel,
    "novec": probe_v6_novec_kernel, "nopstore": probe_v6_nopstore_kernel,
}


def main():
    probe = os.environ.get("PV_PROBE", "base")
    kern = _PROBES[probe]
    torch.manual_seed(0)
    B = int(os.environ.get("PV_B", "1"))
    HQ = int(os.environ.get("PV_HQ", "8"))
    SQ = int(os.environ.get("PV_SQ", "257"))
    SKV = int(os.environ.get("PV_SKV", "256"))
    MQ = HQ * SQ
    q_fp32 = torch.randn((B * MQ, D_HEAD), dtype=torch.float32)
    k_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    v_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    q = fp32_to_hif8(q_fp32); k = fp32_to_hif8(k_fp32); v = fp32_to_hif8(v_fp32)
    out = torch.zeros((B * MQ, D_HEAD), dtype=torch.bfloat16)

    tiles_m_per_b = (MQ + TILE_M - 1) // TILE_M
    k_tiles = (SKV + TILE_N - 1) // TILE_N
    total_blocks = B * tiles_m_per_b

    mode = os.environ.get("PV_MODE", "sim")
    sim_cores = int(os.environ.get("PV_SIM_CORES", "4"))
    force_1core = os.environ.get("PV_1CORE", "0") == "1"
    if force_1core:
        import easyasc.kernelbase.kernelbase as _kb
        _kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda *a, **k: 1)
    launch_cores = 1 if force_1core else (sim_cores if mode == "sim" else MAX_CORE_COUNT)
    debug = os.environ.get("PV_DEBUG", "0") == "1"
    profile = os.environ.get("PV_PROFILE", "0") == "1"
    ok, max_owners, split_blocks = _pairwise_split_ok(total_blocks, k_tiles, launch_cores)
    if not ok:
        raise SystemExit("pairwise split precondition failed: max_owners={}".format(max_owners))

    kern._simulator_config = SimulatorConfig(core_count=(1 if force_1core else sim_cores), execution_timeout_s=3600.0)

    d = os.environ.get("PV_OUT_DIR") or "./tmp/pfa_fd_v6probe_{}_{}".format(probe, mode)
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, out, B, MQ, SKV, D_HEAD)
    sb = {0: [1 if B == 1 else None, 3], 1: [2 if B == 1 else None, 3],
          2: [2 if B == 1 else None, 3], 3: [1 if B == 1 else None, 3]}

    print("V6-PROBE[{}]: B={} HQ={} SQ={} SKV={} blocks={} k_tiles={} cores={} split={}".format(
        probe, B, HQ, SQ, SKV, total_blocks, k_tiles, launch_cores, split_blocks))
    if mode == "sim":
        outs = OpExec(kern, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, cannsim=True, debug=debug)(*args, shape_bindings=sb)
    elif mode == "hw":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")

    O = torch.as_tensor(outs).float()
    qf = hif8_to_fp32(q); kf = hif8_to_fp32(k); vf = hif8_to_fp32(v)
    o_ref = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV)
    print("|O| max={:.3f}  (NOTE: only base is correct; every noX probe is INCORRECT by design)".format(O.abs().max().item()))
    print("O vs fp32 ref:     max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref.to(torch.bfloat16).float())))


if __name__ == "__main__":
    main()
