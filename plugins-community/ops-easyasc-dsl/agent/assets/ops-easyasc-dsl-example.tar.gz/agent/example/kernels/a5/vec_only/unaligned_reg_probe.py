"""Does a register load/store reach an unaligned UB offset?

`ub_to_reg_interleave` documents a 32-byte alignment requirement; the plain
`ub_to_reg_continuous`/`reg_to_ub_continuous` NORMAL path documents none.  The
difference decides whether a staged tile has to pad every row up to a 32-byte
multiple - which costs one DataCopyPad burst per row - or can be staged as one
packed run and addressed at an arbitrary element offset.

Four probes, each with a *runtime* element offset so the address cannot be
folded to an aligned constant:

  ldu.<w>   load  from src[off .. off+VL)  -> aligned dst
  stu.<w>   load  from aligned src         -> store at dst[off .. off+VL)

Run:
- simulator (default): python kernels/a5/vec_only/unaligned_reg_probe.py
- on Ascend950 board:   python kernels/a5/vec_only/unaligned_reg_probe.py --run
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

SRC_F32 = 256
SRC_F16 = 512
OFF_F32 = 3      # 12 bytes: not a multiple of 32
OFF_F16 = 5      # 10 bytes: not a multiple of 32


@vf()
def ldu_f32_vf(src_ub, dst_ub, off: Var):
    v = Reg(DT.float, name="ldu32_v")
    ub_to_reg_normal(v, src_ub[0:1, off:off + 64])
    reg_to_ub_normal(dst_ub[0:1, 0:64], v)


@kernel(mode="vec")
def ldu_f32_kernel(src: GMTensor, out: GMTensor, off: Var):
    src_ub = Tensor(DT.float, [1, SRC_F32], Position.UB, name="ldu32_src")
    dst_ub = Tensor(DT.float, [1, 64], Position.UB, name="ldu32_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        ldu_f32_vf(src_ub, dst_ub, off)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def stu_f32_vf(src_ub, dst_ub, off: Var):
    v = Reg(DT.float, name="stu32_v")
    ub_to_reg_normal(v, src_ub[0:1, 0:64])
    reg_to_ub_normal(dst_ub[0:1, off:off + 64], v)


@kernel(mode="vec")
def stu_f32_kernel(src: GMTensor, out: GMTensor, off: Var):
    src_ub = Tensor(DT.float, [1, SRC_F32], Position.UB, name="stu32_src")
    dst_ub = Tensor(DT.float, [1, SRC_F32], Position.UB, name="stu32_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        dst_ub[:, :] <<= src[0:1, :]
        stu_f32_vf(src_ub, dst_ub, off)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def ldu_f16_vf(src_ub, dst_ub, off: Var):
    native = Reg(DT.half, name="ldu16_n")
    wide = Reg(DT.float, name="ldu16_w")
    to_float = CastConfig(round_mode=RoundMode.NONE, name="ldu16_cast")
    ub_to_reg_unpack(native, src_ub[0:1, off:off + 64])
    cast(wide, native, to_float)
    reg_to_ub_normal(dst_ub[0:1, 0:64], wide)


@kernel(mode="vec")
def ldu_f16_kernel(src: GMTensor, out: GMTensor, off: Var):
    src_ub = Tensor(DT.half, [1, SRC_F16], Position.UB, name="ldu16_src")
    dst_ub = Tensor(DT.float, [1, 64], Position.UB, name="ldu16_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        ldu_f16_vf(src_ub, dst_ub, off)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def stu_f16_vf(src_ub, dst_ub, off: Var):
    v = Reg(DT.half, name="stu16_v")
    ub_to_reg_normal(v, src_ub[0:1, 0:128])
    reg_to_ub_normal(dst_ub[0:1, off:off + 128], v)


@kernel(mode="vec")
def stu_f16_kernel(src: GMTensor, out: GMTensor, off: Var):
    src_ub = Tensor(DT.half, [1, SRC_F16], Position.UB, name="stu16_src")
    dst_ub = Tensor(DT.half, [1, SRC_F16], Position.UB, name="stu16_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        dst_ub[:, :] <<= src[0:1, :]
        stu_f16_vf(src_ub, dst_ub, off)
        out[0:1, :] <<= dst_ub
    return out


def _cases():
    f32 = torch.arange(SRC_F32, dtype=torch.float32).reshape(1, SRC_F32)
    f16 = (torch.arange(SRC_F16, dtype=torch.float32) % 251).to(torch.float16)
    f16 = f16.reshape(1, SRC_F16)

    want_ld32 = f32[0, OFF_F32:OFF_F32 + 64].reshape(1, 64).clone()
    want_st32 = f32.clone()
    want_st32[0, OFF_F32:OFF_F32 + 64] = f32[0, 0:64]
    want_ld16 = f16[0, OFF_F16:OFF_F16 + 64].to(torch.float32).reshape(1, 64)
    want_st16 = f16.clone()
    want_st16[0, OFF_F16:OFF_F16 + 128] = f16[0, 0:128]
    return [
        ("ldu.f32", ldu_f32_kernel, f32, OFF_F32, want_ld32),
        ("stu.f32", stu_f32_kernel, f32, OFF_F32, want_st32),
        ("ldu.f16", ldu_f16_kernel, f16, OFF_F16, want_ld16),
        ("stu.f16", stu_f16_kernel, f16, OFF_F16, want_st16),
    ]


def _opexec(kern, tag, run):
    cfg = dict(simulator=False, debug=False,
               cann_path=os.environ["ASCEND_HOME_PATH"]) if run else dict(simulator=True)
    safe = "".join(c if c.isalnum() else "_" for c in tag)
    return OpExec(kern, out_dir=os.path.abspath("tmp/unaligned/{}".format(safe)),
                  custom_op_path=os.path.abspath("tmp/unaligned/custom_opp"), **cfg)


def main(run, only=None):
    mode = "board" if run else "sim"
    fails, build = [], []
    cases = _cases()
    if only:
        cases = [c for c in cases if c[0] == only]
    for tag, kern, src, off, want in cases:
        try:
            out = torch.zeros_like(want)
            res = _opexec(kern, tag, run)(src.contiguous(), out, off)
            got = res if isinstance(res, torch.Tensor) else res[0]
            got = got.reshape(-1).float()
            ref = want.reshape(-1).float()
            if torch.equal(got, ref):
                print("[{}] {:8s} OK".format(mode, tag))
            else:
                bad = (got != ref).nonzero().flatten()[:8].tolist()
                print("[{}] {:8s} MISMATCH n={} first={} got={} want={}".format(
                    mode, tag, int((got != ref).sum()), bad,
                    got[bad[:4]].tolist(), ref[bad[:4]].tolist()))
                fails.append(tag)
        except Exception as exc:  # noqa: BLE001
            print("[{}] {:8s} BUILD/RUN-FAIL: {}: {}".format(
                mode, tag, type(exc).__name__, str(exc)[:220]))
            build.append(tag)
    print("\n[{}] summary: {}/{} exact; mismatch={}; build/run-fail={}".format(
        mode, len(cases) - len(fails) - len(build), len(cases),
        fails or "-", build or "-"))
    return 1 if (fails or build) else 0


if __name__ == "__main__":
    _run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1"
    _only = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--only=")), None)
    sys.exit(main(_run, only=_only))
