# Stepwise conv2d pipeline (a2 / 910B3)

Four standalone `@kernel` ops that perform a full NCHW conv as the hardware
does: layout in, cube compute, layout out. Each stage is a separate OpExec
launch with plain GM tensors as the contract.

```
x [1, 64, 256, 256] fp16 ──k1──> 5HD [C1*HP*W, 16] ──┐
                                                     k3 conv ──> NZ [C1O*M, 16] fp32 ──k4──> y [1, 128, 128, 128] fp16
w [128, 64, 3, 3]  fp16  ──k2──> [COUT, K=576]    ───┘
```

Conv spec: stride 2, dilation 2, Kh = Kw = 3, effective filter 5x5.
Output `[B, COUT, H/2, W/2]` requires pad 2 on all four edges:
`Ho = (256 + 4 - 5) // 2 + 1 = 128`.

Files: `common.py` (one source of geometry), `transdata_x_to_5hd.py` (k1),
`transdata_w_to_fractal.py` (k2), `conv_compute.py` (k3),
`transdata_out_to_nchw.py` (k4), `run_pipeline.py` (chains all four).
Every file runs the python simulator at H = W = 32 by default and the full
256x256 spec on a 910B3 box with `--debug`.

```
PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python run_pipeline.py          # sim, 32x32
PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python run_pipeline.py --debug  # 910B3, full spec
```

Validated 2026-06-10: simulator max_abs_diff 3.1e-2 (fp16 ulp at |y|~12),
910B3 max_abs_diff 6.25e-2 (full spec); k1/k2/k4 bit-exact, k3 1.6e-4 vs
fp32 torch.

---

## Layout decisions

### 5HD feature map with H pad baked in (k1)

`pack_nc1hwc0` layout: row `((b*C1 + c1)*H + h)*W + w`, col `c0`. We store
`HP = H + 4` rows per (b, c1) plane and place data rows at `+PAD*W`; the top
and bottom `PAD*W` rows are written as zeros by k1 itself.

Why: the conv compute kernel slices a fresh 5-row plane per output row. If
pad rows lived only in the Conv2D descriptor, every ho tile would need a
different pad-top/bottom — a runtime descriptor switch the load3d path doesn't
have. Baked rows make every ho slice geometrically identical: pad stays
`(2, 2, 0, 0)` (left/right only) for all 128 tiles.

W-direction pad stays in the descriptor; left/right padding is identical for
every row, so it is loop-invariant.

CIN = 64 = 4 x C0 exactly: no channel-tail zeroing, all 16 channel rows real
([[load3d channelSize must be full C0 blocks]] is moot here, but keep C0
multiples if you change CIN).

### Weight fractal as a pure column permutation (k2)

`pack_conv_weight` makes `[COUT, K]`, K-order `(c1, kh, kw, c0)`. The flat
OIHW row is `(c1, c0, tap)` (tap = kh*3+kw). Row index (cout) is unchanged —
the conversion permutes 144 columns inside each (cout-block, c1) slab:

1. vnchwconv `[16 couts, 144] -> [144, 16]` — 9 repeats walk the taps.
2. vnchwconv back with the address lists swapped: 16 source rows
   `c0*9 + j` (row stride 9 x 16 = 144 elem), repeat j over taps, landing at
   col `j*16 + c0` — undoes the transpose and the permutation in one pass.

K = 4 x 9 x 16 = 576. The compute kernel stages it `w_l1 <<= wz` (ND -> NZ);
never pre-pack ZN fractals (NZ/ZN grids transpose).

### Conv as 128 strided one-row tiles (k3)

Full 5HD fmap (8.5 MB) can't sit in L1 (512 KB). Each output row ho needs
input rows `[2ho, 2ho+5)` of the padded plane, so one conv2d call gets:

- fm L1 `[C1*5*W, 16]` = 160 KB — `n_burst = C1`, burst `5*W` rows, src
  stride `(HP-5)*W` rows. Base = HP-row `2ho`.
- `h = 5, w = 256` (with the static cap on both dims well under the 32767
  load3d L1-HW limit), one M tile m0 = 0, tile_m = WO = 128, `m_pad = M`.
- `tile_k = 96`: 576 = 6 x 96 (whole-K accumulation in one conv2d call);
  L0 footprint per slot 128x96x2B = 24 KB ≤ 32 KB slot.
- L1 total: 144 KB weights + 160 KB fm.
- L0C `[128, 128]` fp32, NZ store rows `[ho*WO, ho*WO+128)` over `m_pad = M`.

Multicore: contiguous per-core ho blocks (`per_core = ceil(HO/20)`); fm and
L0C are DBuffs — consecutive iterations alternate slots (the per-DBuff depth-2
DEvent assumption), so the next fm load and the previous NZ store overlap the
current mmad. Measured 910B3: 0.0266 ms (plain) -> 0.0230 ms (DBuff).
The vec transdatas use the same idiom (contiguous per-lane unit ranges +
DBuff tiles); strided `% nv` gates remain only for the tiny pad stores.

### NZ fp32 -> NCHW fp16 (k4)

NZ column-block c1o is a `[M, 16]` plane; rows are NCHW columns. Per
(c1o, 512-row chunk): load fp32, `cast` to fp16 (TO_EVEN, matches torch
`.half()`), one vnchwconv batch (32 reps) into `[16, CHUNK]`, store 16 strided
cout rows. fp32 has no vnchwconv (b16 only), so the cast comes first.

---

## Sync & multicore

`auto_sync()` covers everything except one edge (see below). Work split is a
strided unit gate: vec kernels gate `(unit % nv) == GetVecIdx()` with `nv` a
runtime Var (256/32/2048 units over 40 lanes); the conv gates
`ho % N_CUBE == GetCubeIdx()` (Var or static both verified on HW). Units stay
independent: no cross-lane writes overlap; the lone broadcast (weights) is
read-only.

## 910B3 pitfalls hit while bringing this up

Simulator and 20-core sim both passed before any of these; only hardware
exposed them.

1. **dup `count=` under-writes on HW (k1 pad rows).** Counter-mode
   `Duplicate` with the `[n, C0]`-tile stride inference (`dst_blk_stride = 0`)
   executes one repeat: 128 elements, rest untouched (adds/binary ops with the
   same shape are fine — dup-specific). The simulator fills `dst[:count]`
   functionally, hence sim-pass/HW-fail. Fixed 2026-06-11 in the dup stub:
   count-mode defaults are forced to the contiguous blk 1 / rep 8 pattern.
   k1 keeps the equivalent explicit form + the V→MTE3 SEvent ready pair.
2. **Gated DBuff slot reuse races (real cause of all conv failures).**
   auto_sync emits one ready/valid `DEvent` pair (depth 2, valid preset 2)
   per DBuff: two write credits, which is only safe when consecutive writes
   alternate slots. Even gate strides (`ho % 2` const per cube) land every
   active iteration on the SAME slot, so the second preset credit lets MTE2
   overwrite the slot while the previous iteration's img2col reads are still
   in flight → garbage at N_CUBE 2/10/20; N_CUBE 5 (odd) alternates slots and
   satisfies the assumption. The simulator DOES reproduce it once a core runs
   ≥2 same-slot iterations (every ho but each core's last reads the next ho's
   fm); the bring-up sim shape (HO=16, 20 cubes = 1 iter/core) masked it —
   force `iters / cores > 1` in regressions. Var-vs-static `%` gating was a
   red herring. Plain fm/L0C tensors (SEvent depth 1) fix it and cost nothing
   here.

Numerics: conv internals fp16 x fp16 -> fp32; |y| <= ~20 at K = 576,
fp16 output ulp 0.016-0.03, so rtol 3e-3 / atol 3e-3 holds against fp32 torch.
