from easyasc.a5 import *


TILE_M = 128
TILE_N = 128
TILE_K = 128

SHAPE_BINDINGS = {
    0: [2, 0],  # x[K, M]
    1: [2, 1],  # y[K, N]
    2: [0, 1],  # z[M, N]
}


@kernel()
def matmul_kmkn_fp32_out_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x = DBuff(DT.half, [TILE_K, TILE_M], Position.L1)
    l1y = DBuff(DT.half, [TILE_K, TILE_N], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)

    l1_cnt = Var(0)
    l0c_cnt = Var(0)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    l1x[l1_cnt] <<= x[k0:k0 + valid_k, m0:m0 + valid_m]
                    l1y[l1_cnt] <<= y[k0:k0 + valid_k, n0:n0 + valid_n]
                    matmul(l0c[l0c_cnt][:valid_m, :valid_n], l1x[l1_cnt].T, l1y[l1_cnt].T, m=valid_m, n=valid_n, k=valid_k, is_init=(k0 == 0))
                z[m0:m0 + valid_m, n0:n0 + valid_n] <<= l0c[l0c_cnt]
                l1_cnt += 1
                l0c_cnt += 1
    return z


def _check_dim_alignment(m: int, n: int, k: int) -> None:
    if m % 16 != 0:
        raise ValueError(f"M must be divisible by 16 for transpose matmul path, got M={m}")
    if n % 16 != 0:
        raise ValueError(f"N must be divisible by 16 for transpose matmul path, got N={n}")
    if k % 16 != 0:
        raise ValueError(f"K must be divisible by 16 for transpose matmul path, got K={k}")


if __name__ == "__main__":
    import time
    import torch

    M = 5120
    N = 5120
    K = 4096

    for m, n, k in [(128, 128, 128), (256, 128, 128)]:
        _check_dim_alignment(m, n, k)
        torch.manual_seed(0)

        x = torch.randn((k, m), dtype=torch.float16)
        y = torch.randn((k, n), dtype=torch.float16)
        z = torch.zeros((m, n), dtype=torch.float32)

        start = time.time()
        z_kernel = OpExec(matmul_kmkn_fp32_out_kernel, simulator=True)(x, y, z, m, n, k, shape_bindings=SHAPE_BINDINGS)
        sim_time_s = time.time() - start

        start = time.time()
        z_ref = x.float().t() @ y.float()
        ref_time_s = time.time() - start

        torch.testing.assert_close(z_kernel, z_ref, rtol=3e-3, atol=3e-3)
        print(f"shape=(M={m}, N={n}, K={k})")
        print(f"simulator_time_s={sim_time_s:.3f}")
        print(f"reference_time_s={ref_time_s:.3f}")
        print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")

    try:
        _check_dim_alignment(130, 128, 128)
    except ValueError as err:
        print(f"alignment_guard_check=pass ({err})")
