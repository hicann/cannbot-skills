"""A5 hif8 MMAD smoke with uint8 public carriers.

Contract:
- Public inputs are `DT.uint8` carriers because torch has no hif8 dtype.
- The kernel reinterprets the L1/L0 carrier tensors as `DT.hif8`.
- MMAD consumes hif8 L0A/L0B views and writes an fp32 L0C tile.
"""

import os
import sys

import torch

from easyasc.a5 import *


M_VALUE = 32
N_VALUE = 64
K_VALUE = 64
SPLIT_N_VALUE = 32
SPLIT_K_VALUE = 32
CASE_NAMES = (
    "nn_nosplit",
    "nn_splitn",
    "nn_splitk",
    "nt_nosplit",
    "nt_splitn",
    "nt_splitk",
    "tn_nosplit",
    "tn_splitn",
    "tn_splitk",
    "tt_nosplit",
    "tt_splitn",
    "tt_splitk",
)
SHAPE_BINDINGS = {
    0: [0, 2],
    1: [1, 2],
    2: [0, 1],
}


@kernel()
def hif8_carrier_matmul_kernel(x_carrier: GMTensor, y_carrier: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x_carrier = Tensor(DT.uint8, [M, K], Position.L1)
    l1y_carrier = Tensor(DT.uint8, [N, K], Position.L1)
    l0a_carrier = Tensor(DT.uint8, [M, K], Position.L0A)
    l0b_carrier = Tensor(DT.uint8, [N, K], Position.L0B)
    l0c = Tensor(DT.float, [M, N], Position.L0C)

    l1x_hif8 = l1x_carrier.reinterpret(DT.hif8, name="l1x_hif8")
    l1y_hif8 = l1y_carrier.reinterpret(DT.hif8, name="l1y_hif8")
    l0a_hif8 = l0a_carrier.reinterpret(DT.hif8, name="l0a_hif8")
    l0b_hif8 = l0b_carrier.reinterpret(DT.hif8, name="l0b_hif8")

    with auto_sync():
        l1x_carrier <<= x_carrier[:, :]
        l1y_carrier <<= y_carrier[:, :]
        l0a_hif8 <<= l1x_hif8
        l0b_hif8 <<= l1y_hif8
        mmad(l0c, l0a_hif8, l0b_hif8, M=M, N=N, K=K, is_init=True)
        z[:, :] <<= l0c

    return z


@kernel()
def hif8_carrier_matmul_matrix_kernel(
    a_nt_carrier: GMTensor,
    a_t_carrier: GMTensor,
    b_nt_carrier: GMTensor,
    b_t_carrier: GMTensor,
    z_nn_nosplit: GMTensor,
    z_nn_splitn: GMTensor,
    z_nn_splitk: GMTensor,
    z_nt_nosplit: GMTensor,
    z_nt_splitn: GMTensor,
    z_nt_splitk: GMTensor,
    z_tn_nosplit: GMTensor,
    z_tn_splitn: GMTensor,
    z_tn_splitk: GMTensor,
    z_tt_nosplit: GMTensor,
    z_tt_splitn: GMTensor,
    z_tt_splitk: GMTensor,
    dummy: Var,
):
    l1a_nt_carrier = Tensor(DT.uint8, [M_VALUE, K_VALUE], Position.L1)
    l1a_t_carrier = Tensor(DT.uint8, [K_VALUE, M_VALUE], Position.L1)
    l1b_nt_carrier = Tensor(DT.uint8, [N_VALUE, K_VALUE], Position.L1)
    l1b_t_carrier = Tensor(DT.uint8, [K_VALUE, N_VALUE], Position.L1)
    l0c = Tensor(DT.float, [M_VALUE, N_VALUE], Position.L0C)

    l1a_nt_hif8 = l1a_nt_carrier.reinterpret(DT.hif8, name="l1a_nt_hif8")
    l1a_t_hif8 = l1a_t_carrier.reinterpret(DT.hif8, name="l1a_t_hif8")
    l1b_nt_hif8 = l1b_nt_carrier.reinterpret(DT.hif8, name="l1b_nt_hif8")
    l1b_t_hif8 = l1b_t_carrier.reinterpret(DT.hif8, name="l1b_t_hif8")

    with auto_sync():
        l1a_nt_carrier <<= a_nt_carrier[:, :]
        l1a_t_carrier <<= a_t_carrier[:, :]
        l1b_nt_carrier <<= b_nt_carrier[:, :]
        l1b_t_carrier <<= b_t_carrier[:, :]

        matmul(l0c, l1a_nt_hif8, l1b_nt_hif8, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_nn_nosplit[:, :] <<= l0c
        matmul(l0c, l1a_nt_hif8, l1b_nt_hif8, splitn=SPLIT_N_VALUE, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_nn_splitn[:, :] <<= l0c
        matmul(l0c, l1a_nt_hif8, l1b_nt_hif8, splitk=SPLIT_K_VALUE, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_nn_splitk[:, :] <<= l0c

        matmul(l0c, l1a_nt_hif8, l1b_t_hif8.T, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_nt_nosplit[:, :] <<= l0c
        matmul(l0c, l1a_nt_hif8, l1b_t_hif8.T, splitn=SPLIT_N_VALUE, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_nt_splitn[:, :] <<= l0c
        matmul(l0c, l1a_nt_hif8, l1b_t_hif8.T, splitk=SPLIT_K_VALUE, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_nt_splitk[:, :] <<= l0c

        matmul(l0c, l1a_t_hif8.T, l1b_nt_hif8, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_tn_nosplit[:, :] <<= l0c
        matmul(l0c, l1a_t_hif8.T, l1b_nt_hif8, splitn=SPLIT_N_VALUE, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_tn_splitn[:, :] <<= l0c
        matmul(l0c, l1a_t_hif8.T, l1b_nt_hif8, splitk=SPLIT_K_VALUE, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_tn_splitk[:, :] <<= l0c

        matmul(l0c, l1a_t_hif8.T, l1b_t_hif8.T, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_tt_nosplit[:, :] <<= l0c
        matmul(l0c, l1a_t_hif8.T, l1b_t_hif8.T, splitn=SPLIT_N_VALUE, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_tt_splitn[:, :] <<= l0c
        matmul(l0c, l1a_t_hif8.T, l1b_t_hif8.T, splitk=SPLIT_K_VALUE, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        z_tt_splitk[:, :] <<= l0c

    return (
        z_nn_nosplit,
        z_nn_splitn,
        z_nn_splitk,
        z_nt_nosplit,
        z_nt_splitn,
        z_nt_splitk,
        z_tn_nosplit,
        z_tn_splitn,
        z_tn_splitk,
        z_tt_nosplit,
        z_tt_splitn,
        z_tt_splitk,
    )


def _build_inputs() -> tuple:
    torch.manual_seed(11)
    x_fp32 = torch.randn((M_VALUE, K_VALUE), dtype=torch.float32) * 0.75
    y_fp32 = torch.randn((N_VALUE, K_VALUE), dtype=torch.float32) * 0.75
    x_carrier = fp32_to_hif8(x_fp32)
    y_carrier = fp32_to_hif8(y_fp32)
    z = torch.empty((M_VALUE, N_VALUE), dtype=torch.float32)
    expected = hif8_to_fp32(x_carrier) @ hif8_to_fp32(y_carrier).t()
    return x_carrier, y_carrier, z, expected


def _build_matrix_inputs() -> tuple:
    a_nt_carrier, b_nt_carrier, _, expected = _build_inputs()
    a_t_carrier = a_nt_carrier.t().contiguous()
    b_t_carrier = b_nt_carrier.t().contiguous()
    outputs = tuple(torch.empty((M_VALUE, N_VALUE), dtype=torch.float32) for _ in CASE_NAMES)
    return a_nt_carrier, a_t_carrier, b_nt_carrier, b_t_carrier, outputs, expected


def _run(use_cannsim: bool, gen_only: bool) -> None:
    x_carrier, y_carrier, z, expected = _build_inputs()
    actual = OpExec(
        hif8_carrier_matmul_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/hif8_carrier_matmul/custom_opp"),
        out_dir=os.path.abspath("tmp/hif8_carrier_matmul/cannsim" if use_cannsim else "tmp/hif8_carrier_matmul/sim"),
    )(x_carrier, y_carrier, z, M_VALUE, N_VALUE, K_VALUE, shape_bindings=SHAPE_BINDINGS)

    if gen_only:
        print("hif8 carrier matmul gen_only complete")
        return

    torch.testing.assert_close(actual, expected, rtol=2e-3, atol=2e-2)
    print("hif8 carrier matmul passed max_abs_diff={:.6e}".format(float(torch.abs(actual - expected).max().item())))


def _run_matrix(use_cannsim: bool, gen_only: bool) -> None:
    a_nt_carrier, a_t_carrier, b_nt_carrier, b_t_carrier, outputs, expected = _build_matrix_inputs()
    actual = OpExec(
        hif8_carrier_matmul_matrix_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/hif8_carrier_matmul_matrix/custom_opp"),
        out_dir=os.path.abspath("tmp/hif8_carrier_matmul_matrix/cannsim" if use_cannsim else "tmp/hif8_carrier_matmul_matrix/sim"),
    )(a_nt_carrier, a_t_carrier, b_nt_carrier, b_t_carrier, *outputs, 0)

    if gen_only:
        print("hif8 carrier matmul matrix gen_only complete")
        return

    for name, out in zip(CASE_NAMES, actual):
        torch.testing.assert_close(out, expected, rtol=2e-3, atol=2e-2)
        print("hif8 carrier matmul {} passed max_abs_diff={:.6e}".format(name, float(torch.abs(out - expected).max().item())))


if __name__ == "__main__":
    use_cannsim = "--cannsim" in sys.argv[1:]
    gen_only = "--gen-only" in sys.argv[1:]
    if "--single" in sys.argv[1:]:
        _run(use_cannsim, gen_only)
    else:
        _run_matrix(use_cannsim, gen_only)
