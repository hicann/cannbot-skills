# A2 Kernels

Single-file reference kernels targeting the `easyasc.a2` surface, organized by purpose. Run from the repo root with `python kernels/a2/<subdir>/<file>.py`.

## Subdirectories

### `cycle_calibration/` — hardware timing and bandwidth probes

- `mutex_latency_profile.py` — hardware profiling helper for empty-loop, `CvMutex`, and `VcMutex` latency sweeps. Defaults to `OpExec(..., simulator=False, profile=True)`; use `--simulator` only for local sanity.
- `bandwidth_sweep_profile.py` — hardware profiling helper for isolated `gm_to_l1`, `gm_to_ub`, `ub_to_gm`, `l0c_to_gm`, plus a contended all-path sweep. Uses non-overlapping GM regions per cube core / vec lane, prints a final bandwidth table, and defaults to `OpExec(..., simulator=False, profile=True)`.
- `attention_like_bandwidth_profile.py` — hardware profiling helper for an attention-like datamove mix. Compares independent per-core K/V reads against shared K/V reads while keeping workspace in a non-overlapping per-core/per-lane ring and output rows non-overlapping, prints a final bandwidth table, and defaults to `OpExec(..., simulator=False, profile=True)`.

### `attention/` — flash-attn forward + dense backward (11 files)
- `flash_attn_score_pv.py` — `score_j = q@k_j.t()*scale` with delayed `p@v`, double GM bridge, one-tile lookahead
- `flash_attn_full.py` — full flash-attn with running-sum + final divide (triple GM bridge)
- `flash_attn_full_pj_hif8.py` — same math, hif8 probability path
- `flash_attn_full_pj_hif8_commonub.py` — hif8 variant with shared vec-side `DBuff` lineage
- `flash_attn_full_pj_hif8_causal.py` — hif8 + diagonal causal mask
- `flash_attn_full_pj_half_block32_causal.py` — half probability + block-32 diagonal causal baseline
- `flash_attn_full_pj_half_block32_causal_v3.py` — block-32 causal variant with balanced M-tile scheduling, DBuff score/prob scratch, hoisted Q L1 load, and lookahead-3 four-slot queueing
- `flash_attn_full_pj_half_block32_causal_v4.py` — block-32 causal group-N experiment using `[128,512]` score/P workspaces, 32-row vec chunks, and grouped `p @ v`
- `flash_attn_full_pj_half_block32_causal_v2.py` — optimized block-32 causal variant with balanced M-tile scheduling + lookahead-2 queueing
- `attn_backward_dense_total_tail_stage1_prob_dqk_gq_gk_gv_hif8_output_cast.py` — dense attention-backward final (`gq/gk/gv`, bf16 cast)
- `sage2_vnomean_int4.py` — decode-only SageAttention-style int4 Q/K + int8 V path with `qm @ k_smooth`, int8 probability tiles, and final fp32 normalization

### `matmul/` — matmul kernels (4 files)
- `qk_matmul_batched.py` — `qk = q.float() @ k.float().t()` with batched `BH` flatten
- `matmul_fp32_kmkn_splitn.py` — fp32 input `KM @ KN -> MN` with `splitn=64`
- `matmul_half_basic.py` — minimal half-input baseline matmul (no splitn / postprocess)
- `matmul_int4_splitk.py` — signed-int4 packed-carrier input matmul with int32 L0C split-K accumulation

### `vec_only/` — pure-vec kernels (3 files)
- `to_hif8_torch.py` — emulated hif8 round, saturation sentinels
- `sort_rows.py` — per-row `torch.sort(x, dim=-1)`
- `quat_to_rotation.py` — quaternion → 3x3 rotation matrix (`R = quat_to_mat(normalize(r))`), channel-major `[4,N] -> [9,N]` layout

### `basic_operations/` — DSL feature samples
- `dsl_syntax/a2_matmul_subblock.py` — a2 subblock vec writeback sample

## Index for selecting an example

For per-kernel study-for / do-not-copy-when guidance, see `agent/references/examples/kernel-catalog.md`.
