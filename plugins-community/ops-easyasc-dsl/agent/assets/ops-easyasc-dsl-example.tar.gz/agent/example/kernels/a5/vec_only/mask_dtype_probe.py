"""On-board confirmation that the MaskReg store stride generalizes across element sizes.

b32 (stride 4) is already board-verified both directions in mask_probe.py. This runner stores a
b8 (stride 1, dense), b16 (stride 2), and b64 (stride 8) mask in ONE kernel/build and checks each
32-byte dump against the i*S packing model. b64 is included on purpose: GatherB's b64 overload is
broken on this board, so the mask b64 overload must be verified rather than assumed. Run --run.
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

_A8 = [0, 1, 3, 7, 15, 63, 127, 255]
_A16 = [0, 1, 3, 7, 31, 63, 127]
_A64 = [0, 1, 3, 7, 15, 31]


def _store_vf(pat_ub, sa_ub, dt, tag):
    r = Reg(dt, name=f"{tag}_r"); ub_to_reg_normal(r, pat_ub)
    z = Reg(dt, name=f"{tag}_z"); dup(z, 0)
    m = MaskReg(dt, name=f"{tag}_m"); compare(m, r, z, CompareMode.GT)
    zb = Reg(DT.uint8, name=f"{tag}_zb"); dup(zb, 0); reg_to_ub_normal(sa_ub, zb)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    mask_to_ub(sa_ub, m)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)


@vf()
def store_b8(pat_ub, sa_ub):
    _store_vf(pat_ub, sa_ub, DT.int8, "b8")


@vf()
def store_b16(pat_ub, sa_ub):
    _store_vf(pat_ub, sa_ub, DT.int16, "b16")


@vf()
def store_b64(pat_ub, sa_ub):
    _store_vf(pat_ub, sa_ub, DT.int64, "b64")


@kernel(mode="vec")
def dtype_kernel(p8: GMTensor, p16: GMTensor, p64: GMTensor,
                 o8: GMTensor, o16: GMTensor, o64: GMTensor, rows: Var):
    p8_ub = Tensor(DT.int8, [1, 256], Position.UB, name="dk_p8")
    p16_ub = Tensor(DT.int16, [1, 128], Position.UB, name="dk_p16")
    p64_ub = Tensor(DT.int64, [1, 32], Position.UB, name="dk_p64")
    o8_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="dk_o8")
    o16_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="dk_o16")
    o64_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="dk_o64")
    with auto_sync():
        p8_ub[:, :] <<= p8[0:1, :]
        store_b8(p8_ub, o8_ub)
        o8[0:1, :] <<= o8_ub
        p16_ub[:, :] <<= p16[0:1, :]
        store_b16(p16_ub, o16_ub)
        o16[0:1, :] <<= o16_ub
        p64_ub[:, :] <<= p64[0:1, :]
        store_b64(p64_ub, o64_ub)
        o64[0:1, :] <<= o64_ub
    return o8, o16, o64


def _expected(active, s):
    b = [0] * 32
    for lane in active:  # python list, not range()
        pos = lane * s
        b[pos // 8] |= 1 << (pos % 8)
    return b


def main(run):
    p8 = torch.zeros(1, 256, dtype=torch.int8); p8[0, _A8] = 1
    p16 = torch.zeros(1, 128, dtype=torch.int16); p16[0, _A16] = 1
    p64 = torch.zeros(1, 32, dtype=torch.int64); p64[0, _A64] = 1
    o8 = torch.zeros(1, 256, dtype=torch.uint8)
    o16 = torch.zeros(1, 256, dtype=torch.uint8)
    o64 = torch.zeros(1, 256, dtype=torch.uint8)
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    res = OpExec(dtype_kernel, out_dir=os.path.abspath("tmp/maskprobe/dtype"),
                 custom_op_path=os.path.abspath("tmp/maskprobe/opp"),
                 **cfg)(p8.contiguous(), p16.contiguous(), p64.contiguous(), o8, o16, o64, 1)
    g8, g16, g64 = (t.reshape(-1) for t in res)
    ok = True
    for tag, got, active, s in (("b8", g8, _A8, 1), ("b16", g16, _A16, 2), ("b64", g64, _A64, 8)):
        exp = _expected(active, s)
        got32 = got[:32].to(torch.int64).tolist()
        tail = int(got[32:].to(torch.int64).abs().sum())
        match = (got32 == exp) and (tail == 0)
        ok = ok and match
        print(f"{tag}: match={match} tail0={tail == 0}")
        if not match:
            print(f"  got: {got32}")
            print(f"  exp: {exp}")
    print("ALL_OK" if ok else "MISMATCH")


if __name__ == "__main__":
    main("--run" in sys.argv[1:])
