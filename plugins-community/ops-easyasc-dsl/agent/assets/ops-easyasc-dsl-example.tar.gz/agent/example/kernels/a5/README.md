# A5 Kernels

Single-file reference kernels targeting the `easyasc.a5` / general authoring surface, organized by purpose. Run from the repo root with `python kernels/a5/<subdir>/<file>.py`.

## Subdirectories

### `matmul/` — matmul variants (15 files)
Cube-only matmul baselines plus matmul-with-postprocess variants (rowwise norm, blockwise quant, splitk/splitn, half/bf16 outputs, L0C→L1 reuse). Includes the smallest cube → vec mixed pipeline `matmul_abs_add1_vf.py` (`abs(x@y.t)+1`).

### `simt/` — SIMT vec-side samples (5 files)
- `simt_axpy.py` — UB-tiled thread-parallel `out = alpha * x + y`
- `simt_atomic_add.py` — GM-side `out = init; out[i % BINS] += x[i]` with `simt_atomic_add`
- `simt_ub_8kb_probe.py` — CANNSIM probe for SIMT UB read/write accesses at and beyond the 8 KiB boundary
- `simt_matmul_transpose_contig_{read,write}.py` — cube matmul followed by SIMT transpose

### `attention/` — attention algorithms
- `mha_ifa{,_256,_nz,_nz_256,_fp8_scale_256}.py` — single-row decode attention variants
- `flash_attn_full_fp8_causal.py` — multi-row causal flash-attn with fp8 prob tiles
- `test_mla_entire.py` — streamed MLA pipeline
- `pfa/qk_softmax_pv_flat.py` — flat (non-FD) QK-softmax-PV base; transposed-score softmax, NZ column-published `P^T`, `PV = matmul(l1p.T, l1v.T)`
- `pfa/pfa_fd.py` — flash-decoding (stream-K + FD merge) base, bf16 P/V, NZ `ub_p.nz()` P-publish
- `pfa/pfa_fd_qk_e4m3.py` — FD variant with e4m3 Q/K and bf16 P/V
- `pfa/pfa_fd_hif8.py` — all-hif8 stream-K baseline
- `pfa/pfa_fd_v5_qkhif8.py` — hif8 Q/K with BF16 P/V
- `pfa/pfa_fd_v6_allhif8.py` — production all-hif8 path with NZ-direct P publish
- `pfa/v7_allhif8.py` — metadata-driven all-hif8 GQA prefill and FD merge

### `gdn_legacy/` — older GDN building blocks (4 files)
Predecessors of the current `projects/a5/gdn_fwd/` and `projects/a5/gdn_bwd/` systems; kept as topology references.
- `delta_h_state_bridge_v1_c8.py` — aligned `delta_h` baseline with persistent state snapshots
- `delta_h_psudo_state_bridge_c8.py` — pseudo-reference comparison on the same schedule
- `recurrent_state_attn_vec.py` — vec-only recurrent attention state update
- `recompute_wu.py` — `attn @ (k_beta * decay_exp)`

### `conv/` — convolution-shape kernels (1 file)
- `conv2d_relu_n1c2h8w8_fixed.py` — fixed-contract `relu(conv2d(...))` with internal zero-pad + im2col

### `pipeline_patterns/` — small topology-pattern showcases (4 files)
Not real algorithms — small kernels demonstrating one mixed-pipeline shape:
- `vec_cube_abs_sqrt_matmul.py` / `_nz.py` — vec → cube preprocess (ND vs NZ publish)
- `vec_cube_vec_scale2_abs_add1_matmul.py` — vec → cube → vec fusion
- `cube_vec_atomic_add_two_outputs.py` — cube → vec with atomic-add dual sinks

### `utility/` — elementwise / scan / micro / utility (4 files)
- `chunk_row_cumsum.py` — chunked row-recursive cumsum
- `quat_to_rotation.py` — quaternion → 3x3 rotation matrix (vec-only)
- `cov2x2_inverse.py` — 2x2 PSD inverse (vec-only)
- `micro_cast_fp8_pack4_dual.py` — micro-only fp8 cast / pack4

## Where the GDN system project lives

GDN attention kernels form multi-file system projects and live under `projects/a5/gdn_fwd/` and `projects/a5/gdn_bwd/` rather than here. See `projects/a5/gdn_fwd/README.md` and `projects/a5/gdn_bwd/README.md`.

## Index for selecting an example

For per-kernel study-for / do-not-copy-when guidance, see `agent/references/examples/kernel-catalog.md`.
