# Kernels

Single-file reference kernels and DSL learning samples, grouped by device.

For multi-file system projects (e.g. GDN attention), see `projects/`.

## Layout

- `a2/` — single-file kernels targeting the `easyasc.a2` surface
- `a5/` — single-file kernels targeting the `easyasc.a5` surface

Each device folder has its own `README.md` listing the runnable files.

## Running

All scripts require the repository root on `PYTHONPATH`. From the repository
root, export it explicitly before running a nested script:

```bash
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
python kernels/a5/matmul/matmul_float_mmad.py
python kernels/a2/matmul/matmul_half_basic.py
```

## Index for selecting an example

- `tools/select_kernel_example.py --query "<formula or task>"` — programmatic filter
- `agent/references/examples/kernel-index.md` — flat one-line table
- `agent/references/examples/kernel-catalog.md` — per-kernel `study_for` / `do_not_copy_when` notes
