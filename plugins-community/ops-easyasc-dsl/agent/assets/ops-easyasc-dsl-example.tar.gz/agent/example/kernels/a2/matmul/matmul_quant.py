"""matmul + a2/V220 fixpipe scalar quant on store via ``l0c.requant(scale=, offset=)``.

The fixpipe can dequant/requant the L0C result on its way to GM, fusing the
quantization into the matmul store. The quant mode and the 8-bit signedness are
inferred from the (L0C src, GM dst) dtype pair -- nothing else to configure:

  * fp32  L0C -> int8 / uint8 : QF322B8_PRE   (quantize an fp matmul result)
  * int32 L0C -> int8 / uint8 : REQ8          (requantize an int8 matmul accumulator)
  * int32 L0C -> fp16         : DEQF16         (dequantize back to float)

int8 dst -> signed saturation, uint8 dst -> unsigned. ``scale``/``offset`` feed the
deqScalar and may each be a Python constant or a ``Var``.

Validated flow (Ascend910B3): ``s9 = clamp(round_half_to_even(src * scale), -256, 255);
s9 += offset; out = signed ? clamp(s9, -128, 127) : clamp(s9, 0, 255)``. ``scale`` is a
float19 (the top 19 bits of the fp32), so use cleanly representable scales such as
halves/quarters to land exactly. ``offset`` is ignored by DEQF16.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_quant.py            # repo simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_quant.py --debug     # cannsim (on the VM)
"""
from easyasc.a2 import *

# Demo quant params (scale is a float19 on HW, so a half/quarter is represented exactly).
QF_SCALE, QF_OFFSET = 0.5, 8      # QF322B8_PRE : fp32  L0C -> 8-bit
RQ_SCALE, RQ_OFFSET = 0.5, 0      # REQ8        : int32 L0C -> 8-bit
DQ_SCALE = 0.25                   # DEQF16      : int32 L0C -> fp16 (offset unused)


@kernel()
def matmul_quant_fp32_byte(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32 accumulate, quantized to 8-bit on store (QF322B8_PRE).

    Signedness follows the z dtype: int8 -> signed, uint8 -> unsigned (same kernel).
    """
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c.requant(scale=QF_SCALE, offset=QF_OFFSET)
    return z


@kernel()
def matmul_requant_int32_byte(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """int8 @ int8 -> int32 accumulate, requantized to 8-bit on store (REQ8)."""
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l0c = Tensor(DT.int, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c.requant(scale=RQ_SCALE, offset=RQ_OFFSET)
    return z


@kernel()
def matmul_dequant_int32_to_fp16(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """int8 @ int8 -> int32 accumulate, dequantized to fp16 on store (DEQF16)."""
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l0c = Tensor(DT.int, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c.requant(scale=DQ_SCALE)        # offset unused for DEQF16
    return z


if __name__ == "__main__":
    import os
    import struct
    import sys

    import torch

    # Distinct M/N/K per kernel -> no shape_bindings. N >= 16 and a 32-elem row keeps the
    # 8-bit store aligned; K is a multiple of the operand c0 (half 16 / int8 32).
    QF_M, QF_N, QF_K = 16, 32, 48
    RQ_M, RQ_N, RQ_K = 16, 32, 64

    def _fp19(scale):
        u = struct.unpack("<I", struct.pack("<f", float(scale)))[0] & 0xFFFFE000
        return struct.unpack("<f", struct.pack("<I", u))[0]

    def _quant_8bit(acc, signed, scale, offset):
        r = torch.round(acc.float() * _fp19(scale))            # round half to even
        r = torch.clamp(r, -256.0, 255.0) + float(offset)
        lo, hi, dt = (-128.0, 127.0, torch.int8) if signed else (0.0, 255.0, torch.uint8)
        return torch.clamp(r, lo, hi).to(dt)

    def _dequant_fp16(acc, scale):
        return (acc.float() * _fp19(scale)).to(torch.float16)

    torch.manual_seed(0)
    # Small integer-valued inputs keep the fp32/int32 accumulate exact, so the quantized
    # bytes are reproducible bit-for-bit against the reference (and sim == cannsim).
    xf = torch.randint(-3, 4, (QF_M, QF_K)).to(torch.float16)
    yf = torch.randint(-3, 4, (QF_N, QF_K)).to(torch.float16)
    acc_f = xf.float() @ yf.float().t()

    xi = torch.randint(-3, 4, (RQ_M, RQ_K), dtype=torch.int8)
    yi = torch.randint(-3, 4, (RQ_N, RQ_K), dtype=torch.int8)
    acc_i = xi.int() @ yi.int().t()

    # slug, kernel, x, y, M, N, K, out_dtype, reference
    cases = (
        ("qf322b8_int8", matmul_quant_fp32_byte, xf, yf, QF_M, QF_N, QF_K, torch.int8,
         _quant_8bit(acc_f, True, QF_SCALE, QF_OFFSET)),
        ("qf322b8_uint8", matmul_quant_fp32_byte, xf, yf, QF_M, QF_N, QF_K, torch.uint8,
         _quant_8bit(acc_f, False, QF_SCALE, QF_OFFSET)),
        ("req8_int8", matmul_requant_int32_byte, xi, yi, RQ_M, RQ_N, RQ_K, torch.int8,
         _quant_8bit(acc_i, True, RQ_SCALE, RQ_OFFSET)),
        ("deqf16", matmul_dequant_int32_to_fp16, xi, yi, RQ_M, RQ_N, RQ_K, torch.float16,
         _dequant_fp16(acc_i, DQ_SCALE)),
    )

    debug = "--debug" in sys.argv[1:]
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"
    if debug and run:
        raise SystemExit("choose only one of --debug or --run")
    wanted = [a for a in sys.argv[1:] if not a.startswith("-")]   # optional slug filter
    base = os.environ.get("QUANT_BASE", "./tmp/a2_quant_cannsim")
    cann = os.environ.get("ASCEND_HOME_PATH") or ""

    failures = 0
    for slug, kern, xt, yt, M, N, K, odt, ref in cases:
        if wanted and slug not in wanted:
            continue
        z = torch.zeros((M, N), dtype=odt)
        if debug:
            got = OpExec(kern, simulator=False, debug=True, cannsim=True,
                         cann_path=cann, out_dir=os.path.join(base, slug))(xt, yt, z, M, N, K)
        elif run:
            got = OpExec(
                kern,
                simulator=False,
                debug=True,
                cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
                out_dir=os.path.join("./tmp/a2_quant_real_hw", slug),
            )(xt, yt, z, M, N, K)
        else:
            got = OpExec(kern, simulator=True)(xt, yt, z, M, N, K)

        if odt == torch.float16:
            ok = torch.allclose(got, ref, rtol=1e-3, atol=1e-3)
            diff = torch.abs(got.float() - ref.float()).max().item()
        else:
            ok = torch.equal(got, ref)
            diff = int(torch.abs(got.int() - ref.int()).max().item())

        failures += 0 if ok else 1
        print("{:<14} [{}] {} max_abs_diff={}".format(
            slug, "cannsim" if debug else ("real_hw" if run else "sim"), "PASS" if ok else "FAIL", diff))

    if failures:
        raise SystemExit("{} case(s) FAILED".format(failures))
