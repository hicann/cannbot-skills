"""End-to-end sim + on-board validation of the reg-reg (per-lane) variable shifts
``shiftl`` / ``shiftr`` (MicroAPI::ShiftLeft / ShiftRight).

Lane ``i`` shifts ``data[i]`` by ``shift[i]`` (a second Reg), unlike the scalar
``shiftls`` / ``shiftrs``. Right shift is arithmetic for signed dtypes. data and the
per-lane shift amount are host-controlled GM inputs loaded to UB, keeping sim and board
on identical inputs. Golden = torch bitwise shift (arithmetic right shift for signed int).

Run:
- simulator (default): python kernels/a5/vec_only/shift_reg_onboard.py
- on Ascend950 board:   python kernels/a5/vec_only/shift_reg_onboard.py --run
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403


@vf()
def shiftl_i32_vf(data_ub, shift_ub, dst_ub):
    d = Reg(DT.int, name="sl32_d"); ub_to_reg_normal(d, data_ub)
    s = Reg(DT.int, name="sl32_s"); ub_to_reg_normal(s, shift_ub)
    y = Reg(DT.int, name="sl32_y")
    shiftl(y, d, s)
    reg_to_ub_normal(dst_ub, y)


@kernel(mode="vec")
def shiftl_i32_kernel(data: GMTensor, shift: GMTensor, out: GMTensor, rows: Var):
    data_ub = Tensor(DT.int, [1, 64], Position.UB, name="sl32_data")
    shift_ub = Tensor(DT.int, [1, 64], Position.UB, name="sl32_shift")
    dst_ub = Tensor(DT.int, [1, 64], Position.UB, name="sl32_dst")
    with auto_sync():
        data_ub[:, :] <<= data[0:1, :]
        shift_ub[:, :] <<= shift[0:1, :]
        shiftl_i32_vf(data_ub, shift_ub, dst_ub)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def shiftr_i32_vf(data_ub, shift_ub, dst_ub):
    d = Reg(DT.int, name="sr32_d"); ub_to_reg_normal(d, data_ub)
    s = Reg(DT.int, name="sr32_s"); ub_to_reg_normal(s, shift_ub)
    y = Reg(DT.int, name="sr32_y")
    shiftr(y, d, s)
    reg_to_ub_normal(dst_ub, y)


@kernel(mode="vec")
def shiftr_i32_kernel(data: GMTensor, shift: GMTensor, out: GMTensor, rows: Var):
    data_ub = Tensor(DT.int, [1, 64], Position.UB, name="sr32_data")
    shift_ub = Tensor(DT.int, [1, 64], Position.UB, name="sr32_shift")
    dst_ub = Tensor(DT.int, [1, 64], Position.UB, name="sr32_dst")
    with auto_sync():
        data_ub[:, :] <<= data[0:1, :]
        shift_ub[:, :] <<= shift[0:1, :]
        shiftr_i32_vf(data_ub, shift_ub, dst_ub)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def shiftl_i64_vf(data_ub, shift_ub, dst_ub):
    d = Reg(DT.int64, name="sl64_d"); ub_to_reg_normal(d, data_ub)
    s = Reg(DT.int64, name="sl64_s"); ub_to_reg_normal(s, shift_ub)
    y = Reg(DT.int64, name="sl64_y")
    shiftl(y, d, s)
    reg_to_ub_normal(dst_ub, y)


@kernel(mode="vec")
def shiftl_i64_kernel(data: GMTensor, shift: GMTensor, out: GMTensor, rows: Var):
    data_ub = Tensor(DT.int64, [1, 32], Position.UB, name="sl64_data")
    shift_ub = Tensor(DT.int64, [1, 32], Position.UB, name="sl64_shift")
    dst_ub = Tensor(DT.int64, [1, 32], Position.UB, name="sl64_dst")
    with auto_sync():
        data_ub[:, :] <<= data[0:1, :]
        shift_ub[:, :] <<= shift[0:1, :]
        shiftl_i64_vf(data_ub, shift_ub, dst_ub)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def shiftr_i64_vf(data_ub, shift_ub, dst_ub):
    d = Reg(DT.int64, name="sr64_d"); ub_to_reg_normal(d, data_ub)
    s = Reg(DT.int64, name="sr64_s"); ub_to_reg_normal(s, shift_ub)
    y = Reg(DT.int64, name="sr64_y")
    shiftr(y, d, s)
    reg_to_ub_normal(dst_ub, y)


@kernel(mode="vec")
def shiftr_i64_kernel(data: GMTensor, shift: GMTensor, out: GMTensor, rows: Var):
    data_ub = Tensor(DT.int64, [1, 32], Position.UB, name="sr64_data")
    shift_ub = Tensor(DT.int64, [1, 32], Position.UB, name="sr64_shift")
    dst_ub = Tensor(DT.int64, [1, 32], Position.UB, name="sr64_dst")
    with auto_sync():
        data_ub[:, :] <<= data[0:1, :]
        shift_ub[:, :] <<= shift[0:1, :]
        shiftr_i64_vf(data_ub, shift_ub, dst_ub)
        out[0:1, :] <<= dst_ub
    return out


# --------------------------------------------------------------------------- #
def _cases():
    n32 = 64
    d32 = (torch.arange(n32, dtype=torch.int64) * 0x04010203 - 0x60000000).to(torch.int32).reshape(1, -1)
    s32 = (torch.arange(n32, dtype=torch.int64) % 31).to(torch.int32).reshape(1, -1)  # 0..30
    n64 = 32
    d64 = (torch.arange(n64, dtype=torch.int64) * 0x0102030405 - (1 << 44)).reshape(1, -1)
    s64 = (torch.arange(n64, dtype=torch.int64) % 31).reshape(1, -1)  # 0..30
    return [
        ("shl.i32", shiftl_i32_kernel, d32, s32, torch.bitwise_left_shift(d32, s32)),
        ("shr.i32", shiftr_i32_kernel, d32, s32, torch.bitwise_right_shift(d32, s32)),
        ("shl.i64", shiftl_i64_kernel, d64, s64, torch.bitwise_left_shift(d64, s64)),
        ("shr.i64", shiftr_i64_kernel, d64, s64, torch.bitwise_right_shift(d64, s64)),
    ]


def _opexec(kern, tag, run):
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    safe = "".join(c if c.isalnum() else "_" for c in tag)
    return OpExec(kern, out_dir=os.path.abspath(f"tmp/shift_reg/{safe}"),
                  custom_op_path=os.path.abspath("tmp/shift_reg/custom_opp"), **cfg)


def _cmp(mode, tag, got, want, fails):
    got = got.reshape(-1).to(torch.int64)
    want = want.reshape(-1).to(torch.int64)
    if torch.equal(got, want):
        print(f"[{mode}] {tag:10s} OK")
    else:
        bad = (got != want).nonzero().flatten()[:6].tolist()
        print(f"[{mode}] {tag:10s} MISMATCH first_bad={bad} "
              f"got[:6]={got[:6].tolist()} want[:6]={want[:6].tolist()}")
        fails.append(tag)


def main(run, only=None):
    mode = "board" if run else "sim"
    fails, build = [], []
    cases = _cases()
    if only:
        cases = [c for c in cases if c[0] == only]
        if not cases:
            raise SystemExit(f"no case matches --only={only}")
    for tag, kern, data, shift, want in cases:
        try:
            out = torch.zeros_like(want)
            res = _opexec(kern, tag, run)(data.contiguous(), shift.contiguous(), out, 1)
            got = res if isinstance(res, torch.Tensor) else res[0]
            _cmp(mode, tag, got, want, fails)
        except Exception as exc:  # noqa: BLE001
            print(f"[{mode}] {tag:10s} BUILD/RUN-FAIL: {type(exc).__name__}: {str(exc)[:200]}")
            build.append(tag)
    ok = len(cases) - len(fails) - len(build)
    print(f"\n[{mode}] summary: {ok}/{len(cases)} exact; mismatch={fails or '-'}; "
          f"build/run-fail={build or '-'}")
    if fails or build:
        raise AssertionError(f"shift_reg {mode}: mismatch={fails} build_fail={build}")
    print(f"[{mode}] ALL {len(cases)} reg-shift cases match the golden")


if __name__ == "__main__":
    _run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1"
    _only = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--only=")), None)
    main(_run, only=_only)
