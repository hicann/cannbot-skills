"""fp16 transdata NCHW -> NC1HWC0 on a2 vector cores (vnchwconv 16x16 blocks).

Device-side replacement for the host pack_nc1hwc0 packer. x is the flat NCHW
plane [B*C, HW]; y is the 5HD plane [B*C1*HW, 16]. Per (b, c1, hw-chunk) a
zero-padded 16-channel UB tile is transposed with one transdata5hd (repeat ==
CHUNK/16) and only the valid hw rows are stored; channel tails come from the
pre-zeroed tile, so y is exactly the host packer output. B/C/H/W arrive as
Vars over static worst-case caps; chunks loop runtime; B*C1 blocks split over
the 40 vec lanes (GetVecIdx).

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python transdata_nchw_to_5hd_half.py          # python simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python transdata_nchw_to_5hd_half.py --debug  # debug workspace on a 910B3 box
"""
import sys

from easyasc.a2 import *

C0 = 16
DEBUG = "--debug" in sys.argv[1:]
CHUNK = 1024                            # hw elems per tile; repeat = CHUNK/16 = 64
NLANES = 40 if DEBUG else 2


@kernel()
def transdata_nchw_to_5hd_half(x: GMTensor, y: GMTensor,
                               b: Var, c1n: Var, hw: Var, pad_hw: Var):
    # x: flat NCHW padded on host to the full [B, C1*16, pad_hw] grid (channel
    # tail rows and the hw tail are zero), so every (b, c1) block is 16 full
    # bursts with whole-block gaps and no UB pre-zeroing (a V-pipe dup would
    # race the MTE2 load WAW); y keeps exact hw rows per plane.
    src_buf = Tensor(DT.half, [16, CHUNK], Position.UB)
    dst_buf = Tensor(DT.half, [CHUNK, C0], Position.UB)
    chunks = CeilDiv(pad_hw, CHUNK)
    vec_idx = GetVecIdx()
    with auto_sync():
        for blk in range(b * c1n):
            with If(blk % NLANES == vec_idx):
                base = blk * C0 * pad_hw                 # first channel elem in flat x
                out0 = blk * hw                          # first 5HD row in y
                for ck in range(chunks):
                    s = Var(ck * CHUNK)
                    span = Min(pad_hw - s, CHUNK)        # 16-aligned by construction
                    gm_to_ub_pad(src_buf, x[base + s:base + s + 1, :],
                                 n_burst=16, burst_len_element=span,
                                 src_stride_element=pad_hw - span,
                                 dst_stride=(CHUNK - span) // C0)
                    transdata5hd(dst_buf, src_buf, repeat=CHUNK // C0,
                                 src_row_stride=CHUNK, dst_row_stride=C0,
                                 src_rep_stride=1, dst_rep_stride=C0)
                    store = Min(hw - s, CHUNK)           # drop the hw pad rows
                    with If(store > 0):
                        ub_to_gm_pad(y[out0 + s:out0 + s + 1, :], dst_buf,
                                     n_burst=1, burst_len_element=store * C0,
                                     src_stride=0, dst_stride_element=0)
    return y


if __name__ == "__main__":
    import torch

    torch.manual_seed(4)
    B, C, H, W = (2, 32, 56, 56) if DEBUG else (2, 20, 6, 6)
    HW = H * W
    PAD_HW = (HW + 15) // 16 * 16
    C1 = (C + C0 - 1) // C0
    x = torch.randn((B, C, H, W), dtype=torch.float16)
    data = torch.zeros((B, C1 * C0, PAD_HW), dtype=torch.float16)   # channel grid + hw pad
    data[:, :C, :HW] = x.reshape(B, C, HW)
    data = data.reshape(B * C1 * C0 * PAD_HW, 1).contiguous()
    y = torch.zeros((B * C1 * HW, C0), dtype=torch.float16)
    ref = torch.from_numpy(pack_nc1hwc0(x.numpy()))
    got = OpExec(transdata_nchw_to_5hd_half, simulator=not DEBUG, debug=DEBUG)(
        data, y, B, C1, HW, PAD_HW)
    assert torch.equal(got, ref), float((got.float() - ref.float()).abs().max())
    print("transdata_nchw_to_5hd_half {}x{}x{}x{} exact".format(B, C, H, W))
