"""fp16 conv2d via load3d img2col on a5 (950): 3x3, stride 1, same padding.

Same spec as kernels/a2/conv/compute/conv_half_basic.py, ported to a5. On a5,
load3d has no K-direction destination stride, so l1_to_l0a_img2col internally
loops the C0 K-chunks (see easyasc/resources/tensorutils.h L12L0A_IMG2COL a5
branch); the conv2d shortcut and this kernel are otherwise identical to a2.

Runtime-shaped (Var) form: H/W/C/COUT/M_PAD arrive as kernel Vars; the kernel
declares only static worst-case L1/L0 capacities, so one binary serves every
shape that fits. conv2d() covers L1 -> L0 -> mmad -> L0C for one M tile; the
kernel owns GM->L1, the m loop and the L0C->GM NZ store.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python conv_half_basic.py          # python simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python conv_half_basic.py --run     # real Ascend950
"""
from easyasc.a5 import *

C0 = 16
KH = KW = 3
PAD = (1, 1, 1, 1)
TILE_M = 32
# static worst-case capacities (largest shape this binary serves); pairwise
# distinct from every GM dim so OpExec scalar->dim auto-match stays unambiguous
C_MAX, H_MAX, W_MAX, COUT_MAX = 32, 8, 8, 48
C1_MAX = (C_MAX + C0 - 1) // C0
K_MAX = C1_MAX * KH * KW * C0
COUT_P = (COUT_MAX + 15) // 16 * 16
C1O = COUT_P // C0
TILE_K = 144                                    # divides K for every C1 in 1..C1_MAX


@kernel()
def conv_half_basic(data: GMTensor, weight: GMTensor, out: GMTensor,
                    h: Var, w: Var, c: Var, cout: Var, m_pad: Var):
    conv = Conv2D(KH, KW, pad=PAD)
    fm = Tensor(DT.half, [C1_MAX * H_MAX * W_MAX, C0], Position.L1)
    w_l1 = Tensor(DT.half, [COUT_P, K_MAX], Position.L1)
    l0c = Tensor(DT.float, [TILE_M, COUT_P], Position.L0C)
    with auto_sync():
        fm <<= data[:, :]                       # GM staged at worst case; Var c/h/w mask the tail
        w_l1 <<= weight[:, :]
        for m0 in range(0, m_pad, TILE_M):
            conv2d(l0c, fm, w_l1, conv, h=h, w=w, c=c, cout=cout, m0=m0, tile_k=TILE_K)
            l0c_to_gm_nz2nz(out[m0:m0 + TILE_M, :], l0c, m_pad=m_pad)
    return out


if __name__ == "__main__":
    import sys
    import torch
    from easyasc.utils.conv2d import pack_nc1hwc0, pack_conv_weight

    torch.manual_seed(0)
    C, H, W, COUT = 20, H_MAX, W_MAX, 40            # runtime shape < static caps
    HO = H + PAD[2] + PAD[3] - KH + 1
    WO = W + PAD[0] + PAD[1] - KW + 1
    M_PAD = (HO * WO + 15) // 16 * 16
    x = torch.randn((1, C, H, W), dtype=torch.float16)
    w = torch.randn((COUT, C, KH, KW), dtype=torch.float16)
    data = torch.zeros((C1_MAX * H_MAX * W_MAX, C0), dtype=torch.float16)
    data[:(C + C0 - 1) // C0 * H * W] = torch.from_numpy(pack_nc1hwc0(x.numpy()))
    wz = torch.zeros((COUT_P, K_MAX), dtype=torch.float16)
    wk = torch.from_numpy(pack_conv_weight(w.numpy()))
    wz[:wk.shape[0], :wk.shape[1]] = wk
    out = torch.zeros((C1O * M_PAD, C0), dtype=torch.float32)
    ref = torch.nn.functional.conv2d(x.float(), w.float(), padding=1)
    ref = ref.reshape(COUT, HO * WO).t()

    run = "--run" in sys.argv[1:]
    got = OpExec(conv_half_basic, simulator=not run, debug=False)(
        data, wz, out, H, W, C, COUT, M_PAD)
    got = got.reshape(C1O, M_PAD, C0).permute(1, 0, 2).reshape(M_PAD, COUT_P)  # NZ -> ND
    got = got[:HO * WO, :COUT]
    torch.testing.assert_close(got, ref, rtol=3e-3, atol=3e-3)
    print("conv_half_basic max_abs_diff={:.6e}".format(float((got - ref).abs().max())))
