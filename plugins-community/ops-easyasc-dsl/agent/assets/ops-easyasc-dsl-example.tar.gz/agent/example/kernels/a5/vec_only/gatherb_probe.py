"""On-board PROBE for MicroAPI::GatherB (vgatherb) semantics on dav_c310.

Impl facts (kernel_micro_datacopy_impl.h DataCopyGatherBImpl): index MUST be uint32,
src/dst support b8/b16/b32/b64, dispatches to vgatherb(dstReg, baseAddr, index, mask).

Diagnostic: src = ramp 0..511 (a gathered value == the src ELEMENT index it came from),
index = identity arange(64). Pre-fill dst with a sentinel to reveal lanes vgatherb does
NOT write. Dump raw dst + interpret. board-first: run with --run, read the decode.
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

_SENT = 0x7EEEEEEE  # distinctive sentinel for un-written lanes


@vf()
def gbprobe_vf(src_ub, dst_ub, idx_ub):
    idx = Reg(DT.uint32, name="gbp_idx"); ub_to_reg_normal(idx, idx_ub)
    d = Reg(DT.int, name="gbp_d")
    dup(d, _SENT)                       # sentinel: any lane left == _SENT was not written
    ub_to_reg_gatherb(d, src_ub, idx)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gbprobe_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.int, [1, 512], Position.UB, name="gbp_src")   # 64 blocks (32B = 8 int32)
    dst_ub = Tensor(DT.int, [1, 64], Position.UB, name="gbp_dst")    # 8 blocks
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="gbp_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="gbp_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gbprobe_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


def _run_one(tag, src, idx, run):
    out = torch.zeros(1, 64, dtype=torch.int32)
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    res = OpExec(gbprobe_kernel, out_dir=os.path.abspath("tmp/gatherb_probe/k"),
                 custom_op_path=os.path.abspath("tmp/gatherb_probe/opp"),
                 **cfg)(src.contiguous(), idx.contiguous(), out, 1)
    got = (res if isinstance(res, torch.Tensor) else res[0]).reshape(-1).tolist()
    unwritten = [i for i, v in enumerate(got) if (v & 0xFFFFFFFF) == _SENT]
    print(f"\n[{tag}] idx[:16]={idx.reshape(-1)[:16].tolist()}")
    print(f"[{tag}] raw dst = {got}")
    print(f"[{tag}] unwritten lanes (==sentinel): {unwritten if unwritten else 'none'}")


def main(run):
    src = torch.arange(512, dtype=torch.int32).reshape(1, 512)
    # Uniform-per-datablock index: all 8 lanes of out-block d hold the SAME source-block
    # number picks[d]. If out-block d == src-block picks[d], the semantics are confirmed:
    # GatherB fetches a 32B block per out-block, index selects the source block.
    # Hypothesis: out-block i's 32B-aligned BYTE offset is read from index-reg LANE i (i=0..7).
    # lanes 0..7 = [0,32,64,...,224] -> out-block i = src 32B block at byte i*32 = src-block i.
    off = torch.zeros(1, 64, dtype=torch.int32)
    off[0, :8] = torch.arange(8, dtype=torch.int32) * 32
    _run_one("lane_i_byteoff", src, off, run)
    print(f"[lane_i_byteoff] EXPECT if lane-i per-block byte-offset: {torch.arange(64).tolist()}")


if __name__ == "__main__":
    main("--run" in sys.argv[1:])
