"""Basic tail-safe float32 matmul on a5: z = x @ y.t().

Contract (mirrors matmul_torch.matmul_torch):
    x : float32 [M, K]
    y : float32 [N, K]
    z : float32 [M, N]   z = x @ y.t()

Topology: cube-only (single matmul, no vec postprocess).
Tail-safety: each of M, N, K may be arbitrary (not aligned to TILE_*).
Device: a5 (950). Single cube core; multicore partitioning is a separate concern.
"""

from easyasc.a5 import *


TILE_M = 64
TILE_N = 64
TILE_K = 64

SHAPE_BINDINGS = {
    0: [0, 2],  # x[M, K]
    1: [1, 2],  # y[N, K]
    2: [0, 1],  # z[M, N]
}


@kernel()
def matmul_f32_tailsafe_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x = DBuff(DT.float, [TILE_M, TILE_K], Position.L1)
    l1y = DBuff(DT.float, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)

    l1_cnt = Var(0)
    l0c_cnt = Var(0)

    with auto_sync():
        for m0 in range(0, M, TILE_M):
            valid_m = Min(TILE_M, M - m0)
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    l1x[l1_cnt] <<= x[m0:m0 + valid_m, k0:k0 + valid_k]
                    l1y[l1_cnt] <<= y[n0:n0 + valid_n, k0:k0 + valid_k]
                    matmul(
                        l0c[l0c_cnt],
                        l1x[l1_cnt], l1y[l1_cnt],
                        k=valid_k,
                        is_init=(k0 == 0),
                    )
                    l1_cnt += 1
                z[m0:m0 + valid_m, n0:n0 + valid_n] <<= l0c[l0c_cnt][0:valid_m, 0:valid_n]
                l0c_cnt += 1
    return z


if __name__ == "__main__":
    import torch

    # Tail on all three dims: none is aligned to TILE=64.
    M, N, K = 100, 130, 70

    torch.manual_seed(0)
    x = torch.randn((M, K), dtype=torch.float32)
    y = torch.randn((N, K), dtype=torch.float32)
    z = torch.zeros((M, N), dtype=torch.float32)

    z_kernel = OpExec(matmul_f32_tailsafe_kernel, simulator=True)(
        x, y, z, M, N, K, shape_bindings=SHAPE_BINDINGS,
    )
    z_ref = x @ y.t()

    torch.testing.assert_close(z_kernel, z_ref, rtol=1e-4, atol=1e-4)
    print(f"shape=(M={M}, N={N}, K={K})")
    print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
