import argparse
import csv
import os
import re
from typing import Dict, List, Optional, Tuple

import torch

from easyasc.a2 import *


TILE_M = 128
HALF_M = 64
COLS = 128
STATUS_ELEMS = 64
DEFAULT_REPEATS = 256
DEFAULT_SHARED_TILES = 16
DEFAULT_WORKSPACE_SLOTS = 4
DEFAULT_CORE_COUNT = 20
VEC_LANES_PER_CORE = 2
PROFILE_RE = re.compile(r"---- N_TESTS:\s+\d+\s+AVG:\s+([0-9.]+)us")


@kernel()
def attn_bw_empty_kernel(dummy: GMTensor, status: GMTensor, repeats: Var, shared_tiles: Var, workspace_slots: Var):
    status_ub = Tensor(DT.float, [1, STATUS_ELEMS], Position.UB)

    for _ in range(0, repeats):
        pass

    with vec_scope():
        vec_rank = GetCubeIdx() * VEC_LANES_PER_CORE + GetSubBlockIdx()
        with auto_sync():
            dup(status_ub, 0.0)
            status[vec_rank:vec_rank + 1, 0:STATUS_ELEMS] <<= status_ub
    return status


@kernel()
def attn_bw_unique_kv_kernel(
    kv_src: GMTensor, p_src: GMTensor, score_src: GMTensor, pv_src: GMTensor,
    score_out: GMTensor, p_out: GMTensor, pv_out: GMTensor, out: GMTensor,
    repeats: Var, shared_tiles: Var, workspace_slots: Var,
):
    l1k = Tensor(DT.half, [TILE_M, COLS], Position.L1)
    l1v = Tensor(DT.half, [TILE_M, COLS], Position.L1)
    l1p = Tensor(DT.half, [TILE_M, COLS], Position.L1)
    l0c = Tensor(DT.float, [TILE_M, COLS], Position.L0C)
    ub_score = Tensor(DT.float, [HALF_M, COLS], Position.UB)
    ub_p = Tensor(DT.half, [HALF_M, COLS], Position.UB)
    ub_pv = Tensor(DT.float, [HALF_M, COLS], Position.UB)
    ub_out = Tensor(DT.float, [HALF_M, COLS], Position.UB)

    with cube_scope():
        core_rows = TILE_M * repeats
        workspace_core_rows = TILE_M * workspace_slots
        cube_idx = GetCubeIdx()
        k_base = cube_idx * core_rows
        v_base = (GetCubeNum() + cube_idx) * core_rows
        p_base = cube_idx * workspace_core_rows
        score_base = cube_idx * workspace_core_rows
        pv_base = cube_idx * workspace_core_rows
        for rep in range(0, repeats):
            workspace_slot = var_mod(rep, workspace_slots)
            k_row = k_base + rep * TILE_M
            v_row = v_base + rep * TILE_M
            p_row = p_base + workspace_slot * TILE_M
            score_row = score_base + workspace_slot * TILE_M
            pv_row = pv_base + workspace_slot * TILE_M
            gm_to_l1_nd2nz(l1k, kv_src[k_row:k_row + TILE_M, 0:COLS], TILE_M, COLS, COLS, TILE_M)
            l0c_to_gm_nz2nd(score_out[score_row:score_row + TILE_M, 0:COLS], l0c, TILE_M, COLS, COLS, TILE_M)
            gm_to_l1_nd2nz(l1p, p_src[p_row:p_row + TILE_M, 0:COLS], TILE_M, COLS, COLS, TILE_M)
            gm_to_l1_nd2nz(l1v, kv_src[v_row:v_row + TILE_M, 0:COLS], TILE_M, COLS, COLS, TILE_M)
            l0c_to_gm_nz2nd(pv_out[pv_row:pv_row + TILE_M, 0:COLS], l0c, TILE_M, COLS, COLS, TILE_M)

    with vec_scope():
        vec_rows = HALF_M * repeats
        workspace_vec_rows = HALF_M * workspace_slots
        vec_rank = GetCubeIdx() * VEC_LANES_PER_CORE + GetSubBlockIdx()
        vec_workspace_base = vec_rank * workspace_vec_rows
        out_base = vec_rank * vec_rows
        for rep in range(0, repeats):
            workspace_slot = var_mod(rep, workspace_slots)
            workspace_row = vec_workspace_base + workspace_slot * HALF_M
            out_row = out_base + rep * HALF_M
            ub_score <<= score_src[workspace_row:workspace_row + HALF_M, 0:COLS]
            p_out[workspace_row:workspace_row + HALF_M, 0:COLS] <<= ub_p
            ub_pv <<= pv_src[workspace_row:workspace_row + HALF_M, 0:COLS]
            out[out_row:out_row + HALF_M, 0:COLS] <<= ub_out
    return score_out, p_out, pv_out, out


@kernel()
def attn_bw_shared_kv_kernel(
    kv_src: GMTensor, p_src: GMTensor, score_src: GMTensor, pv_src: GMTensor,
    score_out: GMTensor, p_out: GMTensor, pv_out: GMTensor, out: GMTensor,
    repeats: Var, shared_tiles: Var, workspace_slots: Var,
):
    l1k = Tensor(DT.half, [TILE_M, COLS], Position.L1)
    l1v = Tensor(DT.half, [TILE_M, COLS], Position.L1)
    l1p = Tensor(DT.half, [TILE_M, COLS], Position.L1)
    l0c = Tensor(DT.float, [TILE_M, COLS], Position.L0C)
    ub_score = Tensor(DT.float, [HALF_M, COLS], Position.UB)
    ub_p = Tensor(DT.half, [HALF_M, COLS], Position.UB)
    ub_pv = Tensor(DT.float, [HALF_M, COLS], Position.UB)
    ub_out = Tensor(DT.float, [HALF_M, COLS], Position.UB)

    with cube_scope():
        core_rows = TILE_M * repeats
        workspace_core_rows = TILE_M * workspace_slots
        cube_idx = GetCubeIdx()
        p_base = cube_idx * workspace_core_rows
        score_base = cube_idx * workspace_core_rows
        pv_base = cube_idx * workspace_core_rows
        for rep in range(0, repeats):
            shared_slot = var_mod(rep, shared_tiles)
            workspace_slot = var_mod(rep, workspace_slots)
            k_row = shared_slot * TILE_M
            v_row = (shared_tiles + shared_slot) * TILE_M
            p_row = p_base + workspace_slot * TILE_M
            score_row = score_base + workspace_slot * TILE_M
            pv_row = pv_base + workspace_slot * TILE_M
            gm_to_l1_nd2nz(l1k, kv_src[k_row:k_row + TILE_M, 0:COLS], TILE_M, COLS, COLS, TILE_M)
            l0c_to_gm_nz2nd(score_out[score_row:score_row + TILE_M, 0:COLS], l0c, TILE_M, COLS, COLS, TILE_M)
            gm_to_l1_nd2nz(l1p, p_src[p_row:p_row + TILE_M, 0:COLS], TILE_M, COLS, COLS, TILE_M)
            gm_to_l1_nd2nz(l1v, kv_src[v_row:v_row + TILE_M, 0:COLS], TILE_M, COLS, COLS, TILE_M)
            l0c_to_gm_nz2nd(pv_out[pv_row:pv_row + TILE_M, 0:COLS], l0c, TILE_M, COLS, COLS, TILE_M)

    with vec_scope():
        vec_rows = HALF_M * repeats
        workspace_vec_rows = HALF_M * workspace_slots
        vec_rank = GetCubeIdx() * VEC_LANES_PER_CORE + GetSubBlockIdx()
        vec_workspace_base = vec_rank * workspace_vec_rows
        out_base = vec_rank * vec_rows
        for rep in range(0, repeats):
            workspace_slot = var_mod(rep, workspace_slots)
            workspace_row = vec_workspace_base + workspace_slot * HALF_M
            out_row = out_base + rep * HALF_M
            ub_score <<= score_src[workspace_row:workspace_row + HALF_M, 0:COLS]
            p_out[workspace_row:workspace_row + HALF_M, 0:COLS] <<= ub_p
            ub_pv <<= pv_src[workspace_row:workspace_row + HALF_M, 0:COLS]
            out[out_row:out_row + HALF_M, 0:COLS] <<= ub_out
    return score_out, p_out, pv_out, out


def _core_slots(args) -> int:
    return int(args.core_count)


def _vec_slots(args) -> int:
    return int(args.core_count) * VEC_LANES_PER_CORE


def _shape_bindings(*tensors: torch.Tensor) -> Dict[int, List[Optional[int]]]:
    return {idx: [None for _ in tensor.shape] for idx, tensor in enumerate(tensors)}


def _extract_profile_time_us(log_path: str = "r.sh.log") -> Optional[float]:
    if not os.path.exists(log_path):
        return None
    found = None
    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            match = PROFILE_RE.search(line)
            if match is not None:
                found = float(match.group(1))
    return found


def _alloc_half(rows: int, zero: bool) -> torch.Tensor:
    shape = (max(rows, 1), COLS)
    if zero:
        return torch.zeros(shape, dtype=torch.float16)
    return torch.empty(shape, dtype=torch.float16)


def _alloc_float(rows: int, zero: bool) -> torch.Tensor:
    shape = (max(rows, 1), COLS)
    if zero:
        return torch.zeros(shape, dtype=torch.float32)
    return torch.empty(shape, dtype=torch.float32)


def _payload_bytes(case_name: str, args) -> Tuple[int, int, int, int]:
    core_slots = _core_slots(args)
    vec_slots = _vec_slots(args)
    repeats = int(args.repeats)
    shared_tiles = int(args.shared_tiles)
    workspace_slots = int(args.workspace_slots)
    half_cube_tile = TILE_M * COLS * 2
    float_cube_tile = TILE_M * COLS * 4
    half_vec_tile = HALF_M * COLS * 2
    float_vec_tile = HALF_M * COLS * 4

    if case_name == "empty":
        return 0, 0, 0, 0

    logical_shared_kv = 2 * half_cube_tile * repeats * core_slots
    unique_shared_kv = 2 * half_cube_tile * min(repeats, shared_tiles)
    unique_kv = 2 * half_cube_tile * repeats * core_slots
    cube_non_kv = (half_cube_tile + 2 * float_cube_tile) * repeats * core_slots
    vec_non_kv = (2 * float_vec_tile + half_vec_tile + float_vec_tile) * repeats * vec_slots
    logical_total = logical_shared_kv + cube_non_kv + vec_non_kv
    workspace_footprint = (
        (half_cube_tile + 2 * float_cube_tile) * workspace_slots * core_slots
        + (float_vec_tile + half_vec_tile + float_vec_tile) * workspace_slots * vec_slots
    )
    output_footprint = float_vec_tile * repeats * vec_slots
    if case_name == "shared_kv":
        return logical_total, unique_shared_kv, workspace_footprint, output_footprint
    return logical_total, unique_kv, workspace_footprint, output_footprint


def _format_optional_float(value: object, digits: int = 2) -> str:
    if value is None:
        return "-"
    return f"{float(value):.{digits}f}"


def _summary_markdown(results: List[Dict[str, object]]) -> str:
    lines = [
        "| case | repeats | shared tiles | workspace slots | kv footprint MiB | workspace footprint MiB | output footprint MiB | logical MiB | time us | logical GB/s |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for item in results:
        lines.append(
            "| {case} | {repeats} | {shared_tiles} | {workspace_slots} | {kv_footprint_mib} | {workspace_footprint_mib} | {output_footprint_mib} | {logical_mib} | {time_us} | {logical_gb_s} |".format(
                case=item["case"],
                repeats=item["repeats"],
                shared_tiles=item["shared_tiles"],
                workspace_slots=item["workspace_slots"],
                kv_footprint_mib=_format_optional_float(item["kv_footprint_mib"], 3),
                workspace_footprint_mib=_format_optional_float(item["workspace_footprint_mib"], 3),
                output_footprint_mib=_format_optional_float(item["output_footprint_mib"], 3),
                logical_mib=_format_optional_float(item["logical_mib"], 3),
                time_us=_format_optional_float(item["time_us"], 2),
                logical_gb_s=_format_optional_float(item["logical_gb_s"], 2),
            )
        )
    return "\n".join(lines)


def _write_summary(results: List[Dict[str, object]], out_root: str) -> None:
    md_path = os.path.join(out_root, "summary.md")
    csv_path = os.path.join(out_root, "summary.csv")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(_summary_markdown(results) + "\n")
    with open(csv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=(
                "case", "repeats", "shared_tiles", "workspace_slots", "kv_footprint_mib",
                "workspace_footprint_mib", "output_footprint_mib", "logical_mib",
                "time_us", "logical_gb_s", "out_dir",
            ),
        )
        writer.writeheader()
        for item in results:
            writer.writerow(item)
    print(f"\nWrote summary files: {md_path}, {csv_path}", flush=True)


def _run_one(case_name: str, args) -> Dict[str, object]:
    core_slots = _core_slots(args)
    vec_slots = _vec_slots(args)
    repeats = int(args.repeats)
    shared_tiles = int(args.shared_tiles)
    workspace_slots = int(args.workspace_slots)
    out_dir = os.path.join(args.out_root, f"{case_name}_rep{repeats}_shared{shared_tiles}_ws{workspace_slots}")

    if case_name == "empty":
        dummy = _alloc_half(1, zero=args.simulator)
        status = _alloc_float(vec_slots, zero=False)
        actual = OpExec(
            attn_bw_empty_kernel,
            out_dir=out_dir,
            cann_path=args.cann_path,
            custom_op_path=args.custom_op_path,
            simulator=args.simulator,
            profile=True,
            gen_only=args.gen_only,
            skip_compile=args.skip_compile,
        )(dummy, status, repeats, shared_tiles, workspace_slots, shape_bindings=_shape_bindings(dummy, status))
    else:
        core_rows = TILE_M * repeats * core_slots
        workspace_core_rows = TILE_M * workspace_slots * core_slots
        vec_rows = HALF_M * repeats * vec_slots
        workspace_vec_rows = HALF_M * workspace_slots * vec_slots
        if case_name == "shared_kv":
            kv_rows = 2 * shared_tiles * TILE_M
            kernel_func = attn_bw_shared_kv_kernel
        elif case_name == "unique_kv":
            kv_rows = 2 * core_rows
            kernel_func = attn_bw_unique_kv_kernel
        else:
            raise ValueError(f"unknown case: {case_name}")

        kv_src = _alloc_half(kv_rows, zero=args.simulator)
        p_src = _alloc_half(workspace_core_rows, zero=args.simulator)
        score_src = _alloc_float(workspace_vec_rows, zero=args.simulator)
        pv_src = _alloc_float(workspace_vec_rows, zero=args.simulator)
        score_out = _alloc_float(workspace_core_rows, zero=False)
        p_out = _alloc_half(workspace_vec_rows, zero=False)
        pv_out = _alloc_float(workspace_core_rows, zero=False)
        out = _alloc_float(vec_rows, zero=False)
        actual = OpExec(
            kernel_func,
            out_dir=out_dir,
            cann_path=args.cann_path,
            custom_op_path=args.custom_op_path,
            simulator=args.simulator,
            profile=True,
            gen_only=args.gen_only,
            skip_compile=args.skip_compile,
        )(
            kv_src, p_src, score_src, pv_src, score_out, p_out, pv_out, out,
            repeats, shared_tiles, workspace_slots,
            shape_bindings=_shape_bindings(kv_src, p_src, score_src, pv_src, score_out, p_out, pv_out, out),
        )

    if args.simulator:
        if case_name == "empty":
            assert actual.shape[1] == COLS
        else:
            for tensor in actual:
                assert tensor.shape[1] == COLS

    logical_bytes, kv_footprint_bytes, workspace_footprint_bytes, output_footprint_bytes = _payload_bytes(case_name, args)
    time_us = None if args.simulator or args.gen_only else _extract_profile_time_us()
    logical_gb_s = None if not time_us or logical_bytes == 0 else logical_bytes / 1000.0 / time_us
    result = {
        "case": case_name,
        "repeats": repeats,
        "shared_tiles": shared_tiles,
        "workspace_slots": workspace_slots,
        "kv_footprint_mib": kv_footprint_bytes / (1024 * 1024),
        "workspace_footprint_mib": workspace_footprint_bytes / (1024 * 1024),
        "output_footprint_mib": output_footprint_bytes / (1024 * 1024),
        "logical_mib": logical_bytes / (1024 * 1024),
        "time_us": time_us,
        "logical_gb_s": logical_gb_s,
        "out_dir": out_dir,
    }
    print(
        f"case={case_name} repeats={repeats} shared_tiles={shared_tiles} "
        f"workspace_slots={workspace_slots} "
        f"kv_footprint_mib={result['kv_footprint_mib']:.3f} "
        f"workspace_footprint_mib={result['workspace_footprint_mib']:.3f} "
        f"output_footprint_mib={result['output_footprint_mib']:.3f} "
        f"logical_mib={result['logical_mib']:.3f} "
        f"time_us={time_us if time_us is not None else '-'} out_dir={out_dir}",
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Profile an attention-like A2 datamove mix. "
            "unique_kv gives every cube core independent K/V rows; shared_kv makes all cube cores read the same K/V tile per rep. "
            "Workspace and output regions are always non-overlapping."
        )
    )
    parser.add_argument("--repeats", type=int, default=DEFAULT_REPEATS)
    parser.add_argument("--shared-tiles", type=int, default=DEFAULT_SHARED_TILES)
    parser.add_argument("--workspace-slots", type=int, default=DEFAULT_WORKSPACE_SLOTS)
    parser.add_argument("--core-count", type=int, default=DEFAULT_CORE_COUNT)
    parser.add_argument("--case", choices=("all", "empty", "unique_kv", "shared_kv"), default="all")
    parser.add_argument("--out-root", default="./tmp/a2_attention_like_bandwidth_profile")
    parser.add_argument("--cann-path", default=None)
    parser.add_argument("--custom-op-path", default="./")
    parser.add_argument("--gen-only", action="store_true")
    parser.add_argument("--skip-compile", action="store_true")
    parser.add_argument("--simulator", action="store_true")
    args = parser.parse_args()

    if args.repeats <= 0:
        raise ValueError("repeats must be positive")
    if args.shared_tiles <= 0:
        raise ValueError("shared-tiles must be positive")
    if args.workspace_slots <= 0:
        raise ValueError("workspace-slots must be positive")
    if args.core_count <= 0:
        raise ValueError("core-count must be positive")

    os.makedirs(args.out_root, exist_ok=True)
    cases = ("empty", "unique_kv", "shared_kv")
    results = []
    for case_name in cases:
        if args.case != "all" and args.case != case_name:
            continue
        results.append(_run_one(case_name, args))

    if results:
        print("\n" + _summary_markdown(results), flush=True)
        _write_summary(results, args.out_root)

    print(
        "logical MiB counts per-core/per-lane demand. kv footprint MiB is the actual K/V GM source footprint. "
        "workspace footprint MiB is the small non-overlapping per-core/per-lane workspace ring footprint.",
        flush=True,
    )


if __name__ == "__main__":
    main()
