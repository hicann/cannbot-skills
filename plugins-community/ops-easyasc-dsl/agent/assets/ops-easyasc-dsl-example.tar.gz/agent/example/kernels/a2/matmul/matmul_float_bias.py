"""fp32 matmul with a C2/BT bias on a2 (910b): z = x @ y.T + bias.

Uses the matmul() shortcut + the ``<<=`` Layout sugar. The bias is a contiguous
fp32 [1, N] row staged into L1. On a2 the contiguous GM->L1 staging uses the plain
32B-granular DataCopy burst (``gm_to_l1``) -- a2 has no ``DataCopyPad``
(``gm_to_l1_pad``, a5-only) -- which the ``layout=Layout.ND`` ``<<=`` dispatches to
automatically. The shortcut routes the row through the kernel's auto-inserted
BT/C2 double-buffer; splitn stages a fresh per-N-tile slice bias[:, n0:n0+valid_n].
The nosplit and splitk kernels have an explicit static N=64 contract so their
full bias row is provably within one A2 BT slot. The splitn kernel keeps runtime
N and uses a static 32-element tile bound.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias.py            # python simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias.py --debug     # CANNSIM (-r sim) on a VM with CANN
"""
from easyasc.a2 import *


STATIC_BIAS_N = 64


@kernel()
def matmul_float_bias_nosplit(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor,
                              M: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [STATIC_BIAS_N, K], Position.L1)
    l1b = Tensor(DT.float, [1, STATIC_BIAS_N], Position.L1, layout=Layout.ND)
    l0c = Tensor(DT.float, [M, STATIC_BIAS_N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        l1b <<= bias[:, :]  # ND layout -> contiguous gm_to_l1 on a2
        matmul(l0c, l1x, l1y, m=M, n=STATIC_BIAS_N, k=K, is_init=True, bias=l1b)
        z[:, :] <<= l0c
    return z


@kernel()
def matmul_float_bias_splitk(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor,
                             M: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [STATIC_BIAS_N, K], Position.L1)
    l1b = Tensor(DT.float, [1, STATIC_BIAS_N], Position.L1, layout=Layout.ND)
    l0c = Tensor(DT.float, [M, STATIC_BIAS_N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        l1b <<= bias[:, :]
        # splitk stages the full bias row once (added on the is_init K-tile).
        matmul(
            l0c, l1x, l1y, splitk=16, m=M, n=STATIC_BIAS_N, k=K,
            is_init=True, bias=l1b,
        )
        z[:, :] <<= l0c
    return z


@kernel()
def matmul_float_bias_splitn(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor,
                             M: Var, N: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l1b = Tensor(DT.float, [1, N], Position.L1, layout=Layout.ND)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        l1b <<= bias[:, :]
        # splitn stages a fresh per-N-tile bias slice bias[:, n0:n0+valid_n]. On a2 the
        # contiguous float bias row is reinterpreted to int32 inside the shortcut so the
        # column slice uses contiguous NZ addressing (a2 float L1 otherwise slices with
        # ZZ-fractal col0*16). The matmul operands take the L0ZZ2NZ load path as usual.
        matmul(l0c, l1x, l1y, splitn=32, m=M, n=N, k=K, is_init=True, bias=l1b)
        z[:, :] <<= l0c
    return z


if __name__ == "__main__":
    import os
    import sys
    import torch

    # Distinct M/N/K (unambiguous shape inference); N*4 a multiple of 32B (a2 gm_to_l1
    # is 32B-granular). splitn=32 -> 2 N-tiles.
    M, N, K = 32, 64, 48
    torch.manual_seed(0)
    x = torch.randn((M, K), dtype=torch.float32)
    y = torch.randn((N, K), dtype=torch.float32)
    bias = torch.randn((1, N), dtype=torch.float32)
    z_ref = x @ y.t() + bias

    modes = [
        ("nosplit", matmul_float_bias_nosplit, False),
        ("splitk", matmul_float_bias_splitk, False),
        ("splitn", matmul_float_bias_splitn, True),
    ]

    debug = "--debug" in sys.argv[1:]
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"
    if debug and run:
        raise SystemExit("choose only one of --debug or --run")

    if debug:
        # debug + cannsim: generate the debug workspace, emit b.sh/r.sh as `-r sim`,
        # build + run CANNSIM automatically, and read the output back. Run on a VM with
        # CANN; the build out_dir must be VM-local (not an sshfs mount).
        base = os.environ.get("BIAS_BASE", "./tmp/a2_bias_cannsim")
        for name, kern, dynamic_n in modes:
            z = torch.zeros((M, N), dtype=torch.float32)
            out_dir = os.path.join(base, "float_" + name)
            scalar_args = (M, N, K) if dynamic_n else (M, K)
            z_out = OpExec(kern, simulator=False, debug=True, cannsim=True,
                           cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
                           out_dir=out_dir)(x, y, bias, z, *scalar_args)
            ok = torch.allclose(z_out, z_ref, rtol=1e-3, atol=1e-3)
            print("CANNSIM float [{}] {} max_abs_diff={:.6e}".format(
                name, "PASS" if ok else "FAIL", float(torch.abs(z_out - z_ref).max().item())))
    elif run:
        base = os.environ.get("BIAS_BASE", "./tmp/a2_bias_real_hw")
        for name, kern, dynamic_n in modes:
            z = torch.zeros((M, N), dtype=torch.float32)
            out_dir = os.path.join(base, "float_" + name)
            scalar_args = (M, N, K) if dynamic_n else (M, K)
            z_out = OpExec(
                kern,
                simulator=False,
                debug=True,
                cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
                out_dir=out_dir,
            )(x, y, bias, z, *scalar_args)
            ok = torch.allclose(z_out, z_ref, rtol=1e-3, atol=1e-3)
            print("A2 HW float [{}] {} max_abs_diff={:.6e}".format(
                name, "PASS" if ok else "FAIL", float(torch.abs(z_out - z_ref).max().item())))
    else:
        for name, kern, dynamic_n in modes:
            z = torch.zeros((M, N), dtype=torch.float32)
            scalar_args = (M, N, K) if dynamic_n else (M, K)
            z_out = OpExec(kern, simulator=True)(x, y, bias, z, *scalar_args)
            torch.testing.assert_close(z_out, z_ref, rtol=1e-4, atol=1e-4)
            print("a2 sim matmul+bias float [{}] max_abs_diff={:.6e}".format(
                name, float(torch.abs(z_out - z_ref).max().item())))
