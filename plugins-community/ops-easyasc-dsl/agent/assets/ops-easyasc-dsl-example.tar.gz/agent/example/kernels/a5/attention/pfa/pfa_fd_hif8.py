"""Flash-decoding PFA forward, ALL-hif8 Q/K/P/V, FLOAT (fp32) online softmax, bf16 output.

Self-contained all-hif8 member of the stream-K PFA family. Q/K/P/V are quantized to
HiFloat8 (hif8), while the online-softmax state, FD workspaces, accumulation, and output
stay fp32/bf16.

hif8 format details:
  - torch has NO hif8 dtype, so the public Q/K/V GMTensors are DT.uint8 carriers (host-encoded
    with fp32_to_hif8). The kernel reinterprets them to DT.hif8 (GMTensor.reinterpret -- a
    same-byte-width relabel) for the hif8 QK^T / PV matmuls. l1q/l1k/l1v/l1p/ub_p are declared
    DT.hif8 directly (internal buffers, never bound to a torch tensor).
  - the in-VF P^T encode uses CAST_ROUND (RoundMode.AWAY_FROM_ZERO); hif8 encoding accepts only
    CAST_ROUND / CAST_HYBRID.
The hif8 QK/PV matmuls accumulate into fp32 L0C and are a5/950-only. Verified on the Python
simulator (OpExec simulator=True).

hif8 P^T is stored KEY-MAJOR (ND) in UB via reg_to_ub_pack4 and published with
ub_to_l1_nd2nz (column offset = the sub-block query half) to l1p, then PV =
matmul(l1p.T, l1v.T). The online softmax runs in FP32 and self-applies SOFTMAX_SCALE via in-VF
`muls`.

KNOWN ISSUE -- validate with a DENSE shape (e.g. PV_HQ=8), NOT the default PV_HQ=4:
  qk_softmax_pv_fd_* has a PRE-EXISTING sparse-32-core FD schedule bug. When
  total_blocks*k_tiles < launch_cores (work units fewer than cores -- e.g. PV_HQ=4 gives
  9 blocks*2 = 18 < 32, the count cannsim always launches), some cores get zero tiles and the
  prefix/suffix split + cross-core FD partial-merge produces wrong results. It is in the shared
  FD schedule/aggregation (not the softmax VF) and reproduces across the flat FD family.
  4/6/8/16-core sim and any dense shape (PV_HQ>=8: 17/65 blocks) pass.

This keeps the same math contract as qk_softmax_pv_flat.py:
  q   : [B*MQ, D] hif8 (uint8 carrier)   with MQ = HQ*SQ per batch
  k   : [B*N,  D] hif8 (uint8 carrier)   one KV stream per batch, shared by all heads in a batch
  v   : [B*N,  D] hif8 (uint8 carrier)
  out : [B*MQ, D] bf16

Inherited FD schedule (vs qk_softmax_pv_flat.py):
  - work is sharded across the flat (global_m_tile, k_tile) grid instead of only across M tiles
  - each core owns one contiguous flat interval [flat_start, flat_end)
  - if a core boundary lands inside an M tile, that tile is split across two cores only
  - each split tile writes an unnormalized partial (accum, row-max, row-sum) to GM workspace
  - after a vec-wide barrier, two aggregation VFs merge the pair of partials
This assumes the flat interval schedule splits each M tile across at most two cores; the runner
validates that precondition before launch.
"""
import builtins
import math
import os

import torch

from easyasc.a5pr import *
from easyasc.simulator.config import SimulatorConfig

_pyrange = builtins.range

# ---- geometry (copied from qk_softmax_pv_flat; that module is a5pr so we cannot import it) ----
TILE_M = 128
ROWS_PER_SB = 64
QLANES = ROWS_PER_SB
TILE_N = 128
D_HEAD = 128
SOFTMAX_SCALE = 1.0 / math.sqrt(D_HEAD)
HALF = TILE_N // 2
FRAC_STRIDE = HALF + 1
CHUNKS_D = D_HEAD // 64
KROW = QLANES   # 64: pack4 key-major row stride (32-aligned)
# agg_vf's fd_merge_vf / output_cast_vf (inlined below) refer to M_Q / CD verbatim.
M_Q = QLANES
CD = CHUNKS_D

PRELOAD_N = 2
CACHE = PRELOAD_N + 1
MAX_CORE_COUNT = 32
MAX_FD_WS = MAX_CORE_COUNT * 2
UNROLL = 4
RB_MAX = TILE_N // UNROLL
RB_EXP = HALF // UNROLL
NEG_LARGE = -1.0e30


@vf()
def init_softmax_state_vf(ub_rmax: Tensor, ub_rsum: Tensor):
    neg = Reg(DT.float); zero = Reg(DT.float)
    neg <<= NEG_LARGE; zero <<= 0.0
    ub_rmax[0:1, 0:QLANES] <<= neg
    ub_rsum[0:1, 0:QLANES] <<= zero


@vf()
def accum_pv_vf(ub_accum: Tensor, ub_pv: Tensor, ub_old_weight: Tensor):
    acc = RegList(DT.float, CHUNKS_D); pv = RegList(DT.float, CHUNKS_D)
    old_weight = Reg(DT.float)
    for r in range(ROWS_PER_SB):
        old_weight <<= ub_old_weight[0:1, r:r + 1].single()
        acc <<= ub_accum[r:r + 1, 0:D_HEAD]
        pv <<= ub_pv[r:r + 1, 0:D_HEAD]
        acc <<= acc * old_weight
        acc <<= acc + pv
        ub_accum[r:r + 1, 0:D_HEAD] <<= acc
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_pv_first_vf(ub_accum: Tensor, ub_pv: Tensor):
    pv = RegList(DT.float, CHUNKS_D)
    for r in range(ROWS_PER_SB):
        pv <<= ub_pv[r:r + 1, 0:D_HEAD]
        ub_accum[r:r + 1, 0:D_HEAD] <<= pv
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def final_div_cast_bf16_vf(ub_accum: Tensor, ub_rsum: Tensor, ub_out: Tensor):
    acc = RegList(DT.float, CHUNKS_D); rsum = Reg(DT.float)
    for r in range(ROWS_PER_SB):
        rsum <<= ub_rsum[0:1, r:r + 1].single()
        acc <<= ub_accum[r:r + 1, 0:D_HEAD]
        acc <<= acc / rsum
        ub_out[r:r + 1, 0:D_HEAD] <<= acc
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ---- flash-decoding aggregation VFs (inlined from agg_vf.py) ------------------
@vf()
def fd_merge_vf(ub_o0: Tensor, ub_o1: Tensor, ub_m0: Tensor, ub_m1: Tensor,
                ub_s0: Tensor, ub_s1: Tensor, ub_A: Tensor, ub_den: Tensor,
                ub_merged: Tensor):
    """AGG-1: 2-split merge + normalize. Prelude (vectorized 64-lane) precomputes A=exp(m0-m1)
    and den_eff=s0*A+s1; main loop per row does O=(o0*A+o1)/den_eff (6 VLD/2 VMUL/2 VADD/2 VDIV/2 VST)."""
    # --- prelude: vectorized over the 64 query lanes (m/s are [1, 64]) ---
    m0v = Reg(DT.float)
    m1v = Reg(DT.float)
    s0v = Reg(DT.float)
    s1v = Reg(DT.float)
    Av = Reg(DT.float)
    denv = Reg(DT.float)
    m0v <<= ub_m0[0:1, 0:M_Q]
    m1v <<= ub_m1[0:1, 0:M_Q]
    s0v <<= ub_s0[0:1, 0:M_Q]
    s1v <<= ub_s1[0:1, 0:M_Q]
    expsub(Av, m0v, m1v)                          # A = exp(m0 - m1)
    denv <<= s0v * Av                             # s0*A
    denv <<= denv + s1v                           # den_eff = s0*A + s1
    ub_A[0:1, 0:M_Q] <<= Av
    ub_den[0:1, 0:M_Q] <<= denv
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)

    # --- main loop: O = (o0*A + o1) / den_eff, per query row ---
    o0 = RegList(DT.float, CD)
    o1 = RegList(DT.float, CD)
    Ar = Reg(DT.float)
    dr = Reg(DT.float)
    for r in range(M_Q, name="row"):
        Ar <<= ub_A[0:1, r:r + 1].single()        # broadcast A[r]   (RV_VLD)
        dr <<= ub_den[0:1, r:r + 1].single()      # broadcast den[r] (RV_VLD)
        o0 <<= ub_o0[r:r + 1, :]                   # 2 VLD
        o1 <<= ub_o1[r:r + 1, :]                   # 2 VLD
        o0 <<= o0 * Ar                             # o0 *= A  (2 RV_VMUL)
        o0 <<= o0 + o1                             # o0 += o1 (2 RV_VADD)
        o0 <<= o0 / dr                             # o0 /= den_eff (2 RV_VDIV)
        ub_merged[r:r + 1, :] <<= o0               # store fp32 merged O (2 RV_VST)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def output_cast_vf(ub_merged: Tensor, ub_out: Tensor):
    """AGG-2: fp32 -> bf16 cast of the merged O, per D-chunk, then downsample-pack store."""
    regs = RegList(DT.float, CD)
    hregs = RegList(DT.bfloat16, CD)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO,
                     name="o_bf16")
    for r in range(M_Q, name="crow"):
        regs <<= ub_merged[r:r + 1, :]            # 2 VLD
        for c in unroll(CD):
            cast(hregs[c], regs[c], cfg)          # fp32 -> bf16 (RV_VCVT_F2F)
            reg_to_ub_downsample(ub_out[r:r + 1, c * 64:(c + 1) * 64], hregs[c])  # pack 64 bf16 (RV_VST)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


def _err(a, b):
    d = (torch.as_tensor(a).float() - torch.as_tensor(b).float()).abs()
    return d.max().item(), d.mean().item()


def _flat_intervals(total_tasks: int, core_count: int):
    return [
        (total_tasks * c // core_count, total_tasks * (c + 1) // core_count)
        for c in _pyrange(core_count)
    ]


def _pairwise_split_ok(total_blocks: int, k_tiles: int, core_count: int):
    owners = [0] * total_blocks
    for start, end in _flat_intervals(total_blocks * k_tiles, core_count):
        if start >= end:
            continue
        first = start // k_tiles
        last = (end - 1) // k_tiles
        for mb in _pyrange(first, last + 1):
            owners[mb] += 1
    max_owners = max(owners) if owners else 0
    split_blocks = sum(1 for x in owners if x == 2)
    return max_owners <= 2, max_owners, split_blocks


def _ref_mqa(qf, kf, vf, b_n, hq, sq, skv, hif8_p=False):
    """Per-(batch, head) MQA reference over ALREADY-DEQUANTIZED fp32 q/k/v (the exact hif8 values
    the kernel matmul sees). hif8_p rounds P through hif8 (CAST_ROUND) before PV, matching the
    kernel's in-VF hif8 P^T pack."""
    outs = []
    for b in _pyrange(b_n):
        kb = kf[b * skv:(b + 1) * skv]; vb = vf[b * skv:(b + 1) * skv]   # this batch's shared KV
        for h in _pyrange(hq):
            base = b * hq * sq + h * sq
            qh = qf[base:base + sq]                                       # this (b,h)'s queries [SQ, D]
            p = torch.softmax((qh @ kb.t()) * SOFTMAX_SCALE, dim=-1)      # [SQ, SKV]
            if hif8_p:
                p = hif8_to_fp32(fp32_to_hif8(p))                         # round P to hif8
            outs.append(p @ vb)                                          # [SQ, D]
    o = torch.cat(outs, dim=0)                                            # [B*HQ*SQ, D]
    return o.to(torch.bfloat16).float() if hif8_p else o


@vf()
def init_accum_vf(ub_accum: Tensor):
    zero = Reg(DT.float)
    zero <<= 0.0
    for r in range(ROWS_PER_SB):
        ub_accum[r:r + 1, 0:D_HEAD] <<= zero
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_t_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                 ub_old_weight: Tensor):
    """Online softmax, hif8 P^T KEY-CONTIGUOUS ND via reg_to_ub_pack4 (CAST_ROUND encode)."""
    sreg = RegList(DT.float, UNROLL); acc = RegList(DT.float, UNROLL); preg = RegList(DT.float, UNROLL)
    p_hi = RegList(DT.hif8, UNROLL); p_hj = RegList(DT.hif8, UNROLL)
    p_mask4 = MaskReg(DT.hif8, init_mode=MaskType.NONE)
    p_mask4 <<= Var(4 * QLANES, dtype=DT.uint32)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_i")
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP, name="ex"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hi[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u + HALF):(rb * UNROLL + u + HALF) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hj[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            reg_to_ub_pack4(ub_p[(rb * UNROLL + u) * KROW], p_hi[u], mask=p_mask4)
            reg_to_ub_pack4(ub_p[((rb * UNROLL + u) + HALF) * KROW], p_hj[u], mask=p_mask4)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_t_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                      ub_old_weight: Tensor, valid_n: Var):
    """Tail softmax (partial key tile), pack4 key-major hif8 P; invalid keys -> zero P row."""
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float); p_hif8 = Reg(DT.hif8)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    p_mask4 = MaskReg(DT.hif8, init_mode=MaskType.NONE)
    p_mask4 <<= Var(4 * QLANES, dtype=DT.uint32)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_tail_i")
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    block_sum <<= 0.0
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        cast(p_hif8, e, cfg_i)
        reg_to_ub_pack4(ub_p[n * KROW], p_hif8, mask=p_mask4)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def qk_softmax_pv_hif8_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor,
                              B: Var, MQ: Var, N: Var, D: Var):
    # Public Q/K/V are uint8 carriers (torch has no hif8 dtype). Relabel them as hif8 (zero-copy,
    # same byte width) so the QK^T / PV matmuls consume hif8 L0A/L0B.
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    cv = CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                 src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    pv_mutex = CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = TBuff(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)

    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)   # pack4 key-major: row k = key k
    ub_old_weight = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_rmax = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_rsum = TBuff(DT.float, [1, QLANES], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)
    # Dedicated single buffers for the prefix partial state. The full pipe cycles
    # ub_rmax/ub_rsum/ub_accum through slots {0,1,2}=mt%CACHE; since the prefix runs
    # BEFORE the full pipe on the same core, a full-pipe init_softmax_state/init_accum
    # whose slot aliases the prefix slot resets the row-max to -inf (and zeros accum)
    # before the prefix's workspace store has flushed -- a WAR the autosync tracker
    # misses across the literal/runtime TBuff index. Separate buffers remove the alias.
    ub_accum_pfx = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_rmax_pfx = Tensor(DT.float, [1, QLANES], Position.UB)
    ub_rsum_pfx = Tensor(DT.float, [1, QLANES], Position.UB)
    # Same story for the suffix partial: a core may run prefix -> suffix back to back
    # (no full pipe between), and the merge phase reuses ub_accum/ub_rmax[0] right after
    # the barrier. Give the suffix its own buffers too, fully decoupled from both the
    # full pipe's {0,1,2} slots and the prefix buffers.
    ub_rmax_sfx = Tensor(DT.float, [1, QLANES], Position.UB)
    ub_rsum_sfx = Tensor(DT.float, [1, QLANES], Position.UB)

    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_sum")

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)

    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_blocks = Var(B * tiles_m_per_b)
    total_tasks = Var(total_blocks * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))
    prefix_tasks = Var(0, DT.int)
    if my_tasks > 0:
        start_k = Var(flat_start % k_tiles)
        if start_k != 0:
            prefix_tasks <<= Min(k_tiles - start_k, my_tasks)
    pipe_start = Var(flat_start + prefix_tasks)
    pipe_tasks = Var(my_tasks - prefix_tasks)
    suffix_tasks = Var(0, DT.int)
    if pipe_tasks > 0:
        end_k = Var(flat_end % k_tiles)
        if end_k != 0:
            suffix_tasks <<= end_k
    full_tasks = Var(pipe_tasks - suffix_tasks)
    suffix_start = Var(flat_end - suffix_tasks)

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    set_constant_to_l1(l1v[0].reinterpret(DT.uint8), 0)
    set_constant_to_l1(l1v[1].reinterpret(DT.uint8), 0)
    set_constant_to_l1(l1v[2].reinterpret(DT.uint8), 0)
    # l1p NOT pre-zeroed: every published P tile fully covers the [TILE_N, TILE_M] PV-matmul read
    # (both subblocks write their query columns; tail softmax writes 0 for invalid keys). Zeroing on
    # CUBE would race the VEC nd2nz publish (cross-core WAW) and corrupt l1p on cannsim.

    with auto_sync():
        # --- fused single-loop (replaces prefix/full/suffix) ---
        # Pre-compute which M-tile is the boundary prefix / suffix for this core.
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                # === STAGE 1: QK^T + softmax + P^T publish ===
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)

                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                # Q load on the first task of each M-tile for this core
                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                l0c_to_ub(ub_score[step], l0c_qk[step][0:TILE_N, 0:TILE_M],
                          M=TILE_N, N=TILE_M, N_dst=ROWS_PER_SB, M_src=TILE_N,
                          dual_mode=DualMode.SPLITN, sub_block_id=0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_t_tail_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                      ub_old_weight[step], valid_n)
                else:
                    softmax_t_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                 ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                               m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
                p_mutex.ready()

            if step >= PRELOAD_N:
                # === STAGE 2 (lag-2): PV + accum + finalize ===
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                sm2 = Var(lag_mt % CACHE)

                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_local_mt = Var(lag_mt % tiles_m_per_b)
                lag_q_base = Var(lag_batch * MQ)
                lag_kv_base = Var(lag_batch * N)
                lag_m0 = Var(lag_local_mt * TILE_M)
                lag_valid_m = Min(TILE_M, MQ - lag_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                # A core can start in the middle of an M tile when FD splits that
                # tile by K. That first local partial has no prior local accum even
                # though its global K index is nonzero.
                if lag_kt == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                elif lag == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:
                    accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                # M-tile ended for this core?
                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    # Cross-core barrier: gate the merge's GM->UB loads (MTE2) on every core's workspace
    # stores (MTE3). allvec_wait is a true vec-wide barrier, so once it returns all peer
    # partials are visible.
    allvec_wait(7, Pipe.MTE2)

    # The per-vec merge target is data-dependent: not every vec owns a split block
    # (fd_found), and a partial M-tile makes a sub-block empty (fd_rows == 0). Keep these
    # runtime branches OUTSIDE auto_sync and wrap only the branch-free load->merge->store
    # body, so every vec that enters the region runs the identical synced sequence.
    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][:, :] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][:, :] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][:, :] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][:, :] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                # Merge in place into ub_pv[0] (already holds partial-0; fd_merge reads then
                # writes each row, so aliasing o0 and the output is safe).
                fd_merge_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                            ub_rsum[0], ub_rsum[1], ub_old_weight[0], ub_old_weight[1], ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


def main():
    torch.manual_seed(0)
    B = int(os.environ.get("PV_B", "1"))
    HQ = int(os.environ.get("PV_HQ", "4"))
    SQ = int(os.environ.get("PV_SQ", "257"))
    SKV = int(os.environ.get("PV_SKV", "256"))
    MQ = HQ * SQ
    q_fp32 = torch.randn((B * MQ, D_HEAD), dtype=torch.float32)
    k_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    v_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    q = fp32_to_hif8(q_fp32)   # uint8 hif8 carrier (torch has no hif8 dtype)
    k = fp32_to_hif8(k_fp32)
    v = fp32_to_hif8(v_fp32)
    out = torch.zeros((B * MQ, D_HEAD), dtype=torch.bfloat16)

    tiles_m_per_b = (MQ + TILE_M - 1) // TILE_M
    k_tiles = (SKV + TILE_N - 1) // TILE_N
    total_blocks = B * tiles_m_per_b

    mode = os.environ.get("PV_MODE", "sim")
    sim_cores = int(os.environ.get("PV_SIM_CORES", "4"))
    launch_cores = sim_cores if mode == "sim" else MAX_CORE_COUNT
    debug = os.environ.get("PV_DEBUG", "0") == "1"
    profile = os.environ.get("PV_PROFILE", "0") == "1"
    ok, max_owners, split_blocks = _pairwise_split_ok(total_blocks, k_tiles, launch_cores)
    if not ok:
        raise SystemExit(
            "pairwise split precondition failed: total_blocks={} k_tiles={} cores={} max_owners={}".format(
                total_blocks, k_tiles, launch_cores, max_owners
            )
        )

    qk_softmax_pv_hif8_kernel._simulator_config = SimulatorConfig(core_count=sim_cores, execution_timeout_s=3600.0)

    d = "./tmp/pfa_quant_fd_hif8_" + mode
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, out, B, MQ, SKV, D_HEAD)
    sb = {0: [1 if B == 1 else None, 3], 1: [2 if B == 1 else None, 3],
          2: [2 if B == 1 else None, 3], 3: [1 if B == 1 else None, 3]}

    print("FD hif8-QKPV schedule: B={} HQ={} SQ={} SKV={} blocks={} k_tiles={} launch_cores={} split_blocks={}".format(
        B, HQ, SQ, SKV, total_blocks, k_tiles, launch_cores, split_blocks
    ))
    if mode == "sim":
        outs = OpExec(qk_softmax_pv_hif8_kernel, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        outs = OpExec(qk_softmax_pv_hif8_kernel, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, cannsim=True, debug=debug)(*args, shape_bindings=sb)
    elif mode == "hw":
        outs = OpExec(qk_softmax_pv_hif8_kernel, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")

    O = torch.as_tensor(outs).float()
    qf = hif8_to_fp32(q); kf = hif8_to_fp32(k); vf = hif8_to_fp32(v)
    o_ref = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV)
    o_ref_hif8 = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV, hif8_p=True)
    print("|O| max={:.3f}".format(O.abs().max().item()))
    print("O vs fp32 ref:   max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref.to(torch.bfloat16).float())))
    max_abs, mean_abs = _err(O, o_ref_hif8)
    print("O vs hif8-P/V ref: max/mean abs err: {:.3e} {:.3e}".format(max_abs, mean_abs))
    rtol = float(os.environ.get("PV_RTOL", "5e-2"))
    atol = float(os.environ.get("PV_ATOL", "5e-2"))
    torch.testing.assert_close(O, o_ref_hif8, rtol=rtol, atol=atol)
    print("assert_close vs hif8-P/V ref: PASS (rtol={} atol={})".format(rtol, atol))


if __name__ == "__main__":
    main()
