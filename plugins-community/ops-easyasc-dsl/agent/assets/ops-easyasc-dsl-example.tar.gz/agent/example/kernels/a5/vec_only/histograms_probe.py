"""What exactly does ``MicroAPI::Histograms`` count?

The CANN header only says the source is ``uint8``, the destination ``uint16``
and that ``HistogramsType`` picks ``dhistv2`` (FREQUENCY) or ``chistv2``
(ACCUMULATE).  Three things are left unsaid and all three change what a radix
select computes:

* which byte values ``BIN0`` / ``BIN1`` map onto the destination's 128 counters,
* whether ACCUMULATE's prefix is inclusive (``<= bin``) or exclusive (``< bin``),
  and whether it runs over the whole byte range or only the window,
* whether the destination is read-modify-write, i.e. whether looping the
  instruction accumulates a tile.

The probe feeds a known multiset of bytes and dumps all four (mode, bin)
registers, so the answers are read straight off the output.  The input is a
``uint32`` UB buffer whose low byte carries the value; two :func:`pack` calls
bring that byte down to the b8 lane the mask selects, which is the same path a
radix pass uses.

Run:
- simulator (default): python kernels/a5/vec_only/histograms_probe.py
- on Ascend950 board:   python kernels/a5/vec_only/histograms_probe.py --run
"""
import builtins
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

LANES32 = 64      # uint32 lanes per register group
BINS = 128        # counters in a uint16 register
GROUPS = 2        # register groups the probe accumulates over
N = LANES32 * GROUPS


@vf()
def hist_vf(src_ub, out_ub, groups: Var, active: Var):
    word = Reg(DT.uint32, name="hp_word")
    half = Reg(DT.uint16, name="hp_half")
    byte = Reg(DT.uint8, name="hp_byte")
    freq0 = Reg(DT.uint16, name="hp_freq0")
    freq1 = Reg(DT.uint16, name="hp_freq1")
    acc0 = Reg(DT.uint16, name="hp_acc0")
    acc1 = Reg(DT.uint16, name="hp_acc1")
    live = MaskReg(DT.uint8, init_mode=MaskType.NONE, name="hp_live")

    dup(freq0, 0)
    dup(freq1, 0)
    dup(acc0, 0)
    dup(acc1, 0)

    for grp in range(groups, name="hp_grp"):
        off = Var(grp * LANES32, name="hp_off")
        # A fresh counter per group: UpdateMask consumes it, and each group
        # activates the same first `active` b8 lanes.
        lanes = Var(active, dtype=DT.uint32, name="hp_lanes")
        update_mask(live, lanes)
        ub_to_reg(word, src_ub[off])
        # Two packs bring every lane's low byte down to b8 lanes 0..63.
        pack(half, word, HighLowPart.LOWEST)
        pack(byte, half, HighLowPart.LOWEST)
        histograms(freq0, byte, HistBin.BIN0, HistMode.FREQUENCY, mask=live)
        histograms(freq1, byte, HistBin.BIN1, HistMode.FREQUENCY, mask=live)
        histograms(acc0, byte, HistBin.BIN0, HistMode.ACCUMULATE, mask=live)
        histograms(acc1, byte, HistBin.BIN1, HistMode.ACCUMULATE, mask=live)

    reg_to_ub(out_ub[0], freq0)
    reg_to_ub(out_ub[BINS], freq1)
    reg_to_ub(out_ub[2 * BINS], acc0)
    reg_to_ub(out_ub[3 * BINS], acc1)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel(mode="vec")
def hist_kernel(src: GMTensor, out: GMTensor, groups: Var, active: Var):
    src_ub = Tensor(DT.int, [1, N], Position.UB, name="hp_src")
    out_ub = Tensor(DT.int16, [1, 4 * BINS], Position.UB, name="hp_out")
    src_u32 = reinterpret(src_ub, DT.uint32)
    out_u16 = reinterpret(out_ub, DT.uint16)
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        hist_vf(src_u32, out_u16, groups, active)
        out[0:1, :] <<= out_ub
    return out


def reference(values):
    """What the probe should print if the documented model above is right."""
    freq = [0] * 256
    for v in values:
        freq[v] += 1
    incl = [sum(freq[: b + 1]) for b in builtins.range(256)]
    return freq, incl


def main(run):
    mode = "board" if run else "sim"
    # A multiset chosen so every question has a distinct answer: values on both
    # sides of 128, a repeated value, the two range ends, and a gap at 0.
    pattern = ([5] * 7 + [6] + [127] * 3 + [128] * 5 + [200] + [255] * 2
               + [77] * 45)
    assert len(pattern) == LANES32
    values = pattern * GROUPS
    src = torch.tensor([v | (0xA5 << 8) for v in pattern] * GROUPS,
                       dtype=torch.int32).reshape(1, N)
    out = torch.zeros(1, 4 * BINS, dtype=torch.int16)
    cfg = dict(simulator=False, debug=False,
               cann_path=os.environ["ASCEND_HOME_PATH"]) if run else dict(simulator=True)
    res = OpExec(hist_kernel, out_dir=os.path.abspath("tmp/histprobe/k"),
                 custom_op_path=os.path.abspath("tmp/histprobe/opp"),
                 **cfg)(src.contiguous(), out, GROUPS, LANES32)
    got = (res if isinstance(res, torch.Tensor) else res[0]).reshape(-1)
    got = got.to(torch.int32) & 0xFFFF
    # `range` here is the DSL's, not the builtin -- the star import shadows it.
    blocks = [got[i * BINS:(i + 1) * BINS].tolist() for i in builtins.range(4)]
    freq0, freq1, acc0, acc1 = blocks
    ref_freq, ref_incl = reference(values)

    def show(name, block, base):
        live = {base + i: c for i, c in enumerate(block) if c}
        print("[{}] {:6s} nonzero={}".format(mode, name, live))

    show("freq0", freq0, 0)
    show("freq1", freq1, 128)
    print("[{}] acc0  head={} tail={}".format(mode, acc0[:8], acc0[-4:]))
    print("[{}] acc1  head={} tail={}".format(mode, acc1[:4], acc1[-4:]))

    ok_freq = (freq0 == ref_freq[:128] and freq1 == ref_freq[128:])
    ok_incl = (acc0 == ref_incl[:128] and acc1 == ref_incl[128:])
    print("[{}] FREQUENCY matches per-bin count over [128*bin, +128): {}".format(
        mode, ok_freq))
    print("[{}] ACCUMULATE matches inclusive prefix over the whole range: {}".format(
        mode, ok_incl))
    if not ok_incl:
        ref_excl = [0] + ref_incl[:-1]
        print("[{}]   exclusive prefix instead: {}".format(
            mode, acc0 == ref_excl[:128] and acc1 == ref_excl[128:]))
        ref_win = [sum(ref_freq[128:128 + b + 1]) for b in builtins.range(128)]
        print("[{}]   window-local prefix instead: {}".format(
            mode, acc1 == ref_win))
        ref_desc = [sum(ref_freq[b:]) for b in builtins.range(256)]
        print("[{}]   descending (>= bin) instead: {}".format(
            mode, acc0 == ref_desc[:128] and acc1 == ref_desc[128:]))


if __name__ == "__main__":
    main("--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1")
