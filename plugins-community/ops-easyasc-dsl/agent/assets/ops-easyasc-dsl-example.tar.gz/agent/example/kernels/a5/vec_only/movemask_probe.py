"""On-board PROBE: how SetVectorMask (PipeS, outside @vf) maps into a MoveMask<T>() MaskReg
read inside @vf.

The codegen emits SetVectorMask<half, NORMAL>(high, low) (T=half hardcoded); the vf reads
MoveMask<int>() (b32 MaskReg, VL=64). This runner drives several SetVectorMask patterns, each
followed by move_mask_spr into a b32 MaskReg that is stored via mask_to_ub (known byte-granular
i*4 packing) so the active b32 lanes can be decoded. Discriminating case: set_mask(0, 0b10)
(low bit 1) -> if the composite is byte-granular (b32 lane i <- SPR bit 4i) NO lane is hit
(SPR bit 2 sits between lanes 0 and 1); if lane-granular, lane 1 is hit. Run with --run.
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403


@vf()
def mm_vf(out_ub):
    m = MaskReg(DT.int, name="mmv_m")           # b32 MaskReg, VL=64
    move_mask_spr(m)                            # m = MoveMask<int>()
    zb = Reg(DT.uint8, name="mmv_zb"); dup(zb, 0); reg_to_ub_normal(out_ub, zb)  # zero 256B
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    mask_to_ub(out_ub, m)                       # dump m (byte-granular i*4 packing)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)


@kernel(mode="vec")
def mm_kernel(dummy: GMTensor, oc8: GMTensor, ol0: GMTensor, ol1: GMTensor, olf: GMTensor, rows: Var):
    d_ub = Tensor(DT.int, [1, 8], Position.UB, name="mm_dummy")
    oc8_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="mm_oc8")
    ol0_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="mm_ol0")
    ol1_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="mm_ol1")
    olf_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="mm_olf")
    with auto_sync():
        d_ub[:, :] <<= dummy[0:1, :]                                   # satisfy input-tensor requirement
        set_mask_by_count(8); mm_vf(oc8_ub); oc8[0:1, :] <<= oc8_ub    # first 8 (of T=half)
        set_mask(0, 1); mm_vf(ol0_ub); ol0[0:1, :] <<= ol0_ub          # low bit 0
        set_mask(0, 2); mm_vf(ol1_ub); ol1[0:1, :] <<= ol1_ub          # low bit 1 (discriminator)
        set_mask(0, 0xF); mm_vf(olf_ub); olf[0:1, :] <<= olf_ub        # low bits 0..3
        reset_mask()
    return oc8, ol0, ol1, olf


def _active_b32(dump32):
    # MaskReg b32: lane i is bit 4i (LSB-first) of the 32-byte dump
    out = []
    for i in torch.arange(64).tolist():  # host: a5 shadows builtin range()
        pos = i * 4
        if (int(dump32[pos // 8]) >> (pos % 8)) & 1:
            out.append(i)
    return out


def main(run):
    outs = [torch.zeros(1, 256, dtype=torch.uint8) for _ in torch.arange(4).tolist()]  # a5 shadows range
    dummy = torch.zeros(1, 8, dtype=torch.int32)
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    res = OpExec(mm_kernel, out_dir=os.path.abspath("tmp/maskprobe/mm"),
                 custom_op_path=os.path.abspath("tmp/maskprobe/opp"),
                 **cfg)(dummy.contiguous(), *outs, 1)
    labels = ["count=8", "low bit0", "low bit1(discriminator)", "low 0xF"]
    for lbl, t in zip(labels, res):
        d = t.reshape(-1)
        print(f"{lbl:26s} active_b32={_active_b32(d[:32])}   bytes[0:8]={d[:8].to(torch.int64).tolist()}")


if __name__ == "__main__":
    main("--run" in sys.argv[1:])
