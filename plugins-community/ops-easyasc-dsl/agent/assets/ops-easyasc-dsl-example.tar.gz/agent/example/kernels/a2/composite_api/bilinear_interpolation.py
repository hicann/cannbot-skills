"""BilinearInterpolation, decomposed into basic a2 APIs.

The composite AscendC `BilinearInterpolation` intrinsic is a weighted gather-accumulate
(`dst[blk] = sum_iter w(iter) * src0[offset(iter)+blk]`). This kernel reimplements it from
basic a2 primitives so the DSL maps 1:1 onto the underlying instruction sequence:

    gather_block  (AscendC Gatherb)  -- gather the sampled 32B blocks
    brcb                              -- broadcast each weight to a 32B block
    mul (src1 blk_stride=0/rep_stride=1) -- one weight reused across a rep's 8 blocks
    add                               -- accumulate the hRepeat taps per vertical row

Config mirrors the API-doc worked example (mask=128, hRepeat=2, vRepeat=2, repeatMode=false):
src0=[1..512], src1=[2..17], offset=[0,32,...,992] -> dst[0]=389, dst[255]=4096.

See agent/references/composite-api-recipes.md (weighted gather-accumulate recipe).
"""
import os
import sys

import torch

from easyasc.a2 import *

S0 = 512          # src0: 32 blocks of 16 half
OFF = 32          # 32 block byte-offsets (8 per rep x 4 reps)
S1 = 16           # weights
DST = 256         # 2 vertical rows of 128
INNER = 4         # hRepeat * vRepeat gather repeats (8 blocks each)
EPB = 16          # half elements per 32B block


@kernel()
def bilinear_interp(src0_gm: GMTensor, offset_gm: GMTensor, src1_gm: GMTensor,
                    dst_gm: GMTensor, inner_rep: Var):
    src0_ub = Tensor(DT.half, [1, S0], Position.UB)
    off_ub = Tensor(DT.int, [1, OFF], Position.UB)
    src1_ub = Tensor(DT.half, [1, S1], Position.UB)
    gathered = Tensor(DT.half, [1, S0], Position.UB)      # 4 reps x 128
    wbrcb = Tensor(DT.half, [1, S1 * EPB], Position.UB)   # 16 weights -> 16 blocks
    prod = Tensor(DT.half, [1, S0], Position.UB)
    dst_ub = Tensor(DT.half, [1, DST], Position.UB)

    with auto_sync():
        src0_ub <<= src0_gm[:, :]
        off_ub <<= offset_gm[:, :]
        src1_ub <<= src1_gm[:, :]
        off_u32 = reinterpret(off_ub, DT.uint32)

        # 1. gather the sampled blocks: rep r gathers src0 blocks offset[r*8 .. r*8+7].
        #    c220 vgatherb needs uint16 operands for 16-bit data, so reinterpret half <->
        #    uint16 around the block gather (same pattern as element `gather`, which callers
        #    reinterpret to an integer dtype). gathered_u16 aliases `gathered`, so the half
        #    view below sees the gathered bytes. Without this the generated `Gatherb` does not
        #    compile on real HW ("1st parameter maybe need a type '__ubuf__ unsigned short *'").
        gathered_u16 = reinterpret(gathered, DT.uint16)
        src0_u16 = reinterpret(src0_ub, DT.uint16)
        gather_block(gathered_u16, src0_u16, off_u32, repeat=inner_rep)

        # 2. broadcast each weight src1[k] into a full 16-half block
        brcb(wbrcb, src1_ub)

        # 3. prod[rep r, block b] = src1[r] * gathered[r*8+b]
        #    repeatMode=false: one weight per rep reused across its 8 blocks
        #    -> weight operand blk_stride=0 (reuse within rep), rep_stride=1 (advance 1 block/rep)
        mul(prod, wbrcb, gathered, repeat=inner_rep, src1_blk_stride=0, src1_rep_stride=1)

        # 4. accumulate the 2 horizontal taps for each vertical row
        add(dst_ub[:, 0:128], prod[:, 0:128], prod[:, 128:256])
        add(dst_ub[:, 128:256], prod[:, 256:384], prod[:, 384:512])

        # 5. store
        dst_gm[:, :] <<= dst_ub

    return dst_gm


def ref_bilinear():
    # device-faithful half reference (mul then add in half), gather is identity here
    # (sequential offsets), so rep r operates on src0 elements r*128 .. r*128+127.
    src0 = torch.arange(1, S0 + 1, dtype=torch.float16).reshape(INNER, 128)
    w = torch.arange(2, 2 + S1, dtype=torch.float16)[:INNER].reshape(INNER, 1)
    prod = w * src0                       # half mul, [4, 128]
    dst = torch.empty(DST, dtype=torch.float16)
    dst[0:128] = prod[0] + prod[1]        # vertical 0: weights 2,3
    dst[128:256] = prod[2] + prod[3]      # vertical 1: weights 4,5
    return dst.reshape(1, DST)


def check_case(run: bool = False) -> None:
    src0 = torch.arange(1, S0 + 1, dtype=torch.float16).reshape(1, S0)
    offset = (torch.arange(OFF, dtype=torch.int32) * 32).reshape(1, OFF)   # block byte addresses
    src1 = torch.arange(2, 2 + S1, dtype=torch.float16).reshape(1, S1)
    out = torch.zeros(1, DST, dtype=torch.float16)

    exec_kwargs = dict(simulator=True, out_dir="./tmp/bilinear_interp")
    if run:
        exec_kwargs = dict(simulator=False, debug=True, out_dir="./tmp/bilinear_interp",
                           cann_path=os.environ.get("ASCEND_HOME_PATH") or "")

    res = OpExec(bilinear_interp, **exec_kwargs)(src0, offset, src1, out, INNER)
    out_sim = res[0] if isinstance(res, (tuple, list)) else res

    ref = ref_bilinear()
    maxdiff = (out_sim.float() - ref.float()).abs().max().item()
    ok = torch.equal(out_sim, ref) and out_sim[0, 0].item() == 389.0 and out_sim[0, 255].item() == 4096.0
    print("dst[0]={} dst[255]={} max_abs_diff={} match={}".format(
        out_sim[0, 0].item(), out_sim[0, 255].item(), maxdiff, ok))
    if not ok:
        raise AssertionError("bilinear_interp mismatch (expected dst[0]=389, dst[255]=4096)")
    print("PASS")


if __name__ == "__main__":
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"
    check_case(run=run)
