from easyasc.a5 import *


# NOTE:
# This kernel intentionally keeps a fixed contract and is not a generic conv2d template.
# It only supports:
#   x: half  [1, 2, 8, 8]
#   w: half  [2, 2, 3, 3]
#   b: float [1, 2]
#   y: float [1, 2, 8, 8]
# with stride=1 and padding=1.

N = 1
IN_C = 2
IN_H = 8
IN_W = 8
PAD = 1
KSZ = 3

OUT_C = 2
OUT_H = IN_H
OUT_W = IN_W
OUT_P = OUT_H * OUT_W

PADDED_H = IN_H + 2 * PAD
PADDED_W = IN_W + 2 * PAD
RAW_FLAT = N * IN_C * IN_H * IN_W
PAD_FLAT = IN_C * PADDED_H * PADDED_W
KFLAT = IN_C * KSZ * KSZ
KPAD = 32
NPAD = 16
ACT_PAD = 8

TILE_M = 32
HALF_TILE_M = TILE_M // 2
OH_ROWS_PER_VEC = HALF_TILE_M // OUT_W
SPLIT_N = 128


@vf()
def pad_x_nchw_flat_half_vf(src_flat: Tensor, dst_flat: Tensor):
    reg_h = Reg(DT.half)
    zero = Reg(DT.half)
    dup(zero, 0.0)

    for idx in range(PAD_FLAT):
        reg_to_ub_single(dst_flat[idx], zero)

    for c in range(IN_C):
        src_ch_base = c * IN_H * IN_W
        dst_ch_base = c * PADDED_H * PADDED_W + PAD * PADDED_W + PAD
        for ih in range(IN_H):
            src_row = src_ch_base + ih * IN_W
            dst_row = dst_ch_base + ih * PADDED_W
            for iw in range(IN_W):
                ub_to_reg_single(reg_h, src_flat[src_row + iw])
                reg_to_ub_single(dst_flat[dst_row + iw], reg_h)


@vf()
def im2col_padded_nchw_half_vf(src_pad_flat: Tensor, dst_col: Tensor, oh_begin: Var):
    reg_h = Reg(DT.half)
    zero = Reg(DT.half)
    dup(zero, 0.0)

    for oh_rel in range(OH_ROWS_PER_VEC):
        oh = Var(oh_begin + oh_rel)
        for ow in range(OUT_W):
            patch_base = (oh_rel * OUT_W + ow) * KPAD
            for c in range(IN_C):
                ch_base = c * PADDED_H * PADDED_W
                for kh in range(KSZ):
                    row_base = ch_base + (oh + kh) * PADDED_W + ow
                    for kw in range(KSZ):
                        ub_to_reg_single(reg_h, src_pad_flat[row_base + kw])
                        dst_idx = patch_base + c * KSZ * KSZ + kh * KSZ + kw
                        reg_to_ub_single(dst_col[dst_idx], reg_h)
            for tz in range(KFLAT, KPAD):
                reg_to_ub_single(dst_col[patch_base + tz], zero)


@vf()
def bias_relu_pack_rows_vf(src_pc: Tensor, bias: Tensor, dst_rows: Tensor):
    reg_f = Reg(DT.float)
    reg_b = Reg(DT.float)
    zero = Reg(DT.float)
    dup(zero, 0.0)

    for oh_rel in range(OH_ROWS_PER_VEC):
        for ow in range(OUT_W):
            p = oh_rel * OUT_W + ow
            for c in range(OUT_C):
                ub_to_reg_single(reg_f, src_pc[p * ACT_PAD + c])
                ub_to_reg_single(reg_b, bias[c])
                axpy(reg_f, reg_b, 1.0)
                vmax(reg_f, reg_f, zero)
                reg_to_ub_single(dst_rows[(c * OH_ROWS_PER_VEC + oh_rel) * OUT_W + ow], reg_f)


@kernel()
def conv2d_relu_n1c2h8w8_fixed_kernel(x: GMTensor, w: GMTensor, b: GMTensor, y: GMTensor, contract: Var):
    vcmutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    cvmutex = CvMutex(1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    x_flat = x.reshape([1, RAW_FLAT], name="x_flat")
    w_flat = w.reshape([OUT_C, KFLAT], name="w_flat")
    y_flat = y.reshape([OUT_C * OUT_H, OUT_W], name="y_flat")

    x_raw_ub = DBuff(DT.half, [1, RAW_FLAT], Position.UB)
    x_pad_ub = DBuff(DT.half, [1, PAD_FLAT], Position.UB)
    x_col_ub = DBuff(DT.half, [HALF_TILE_M, KPAD], Position.UB)
    preact_ub = DBuff(DT.float, [HALF_TILE_M, ACT_PAD], Position.UB)
    bias_ub = DBuff(DT.float, [1, ACT_PAD], Position.UB)
    out_rows_ub = DBuff(DT.float, [OUT_C * OH_ROWS_PER_VEC, OUT_W], Position.UB)

    l1x = DBuff(DT.half, [TILE_M, KPAD], Position.L1)
    l1w = DBuff(DT.half, [NPAD, KPAD], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, NPAD], Position.L0C)

    x_cnt = Var(0)
    cube_cnt = Var(0)
    post_cnt = Var(0)

    tile_m = CeilDiv(OUT_P, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            row_begin = Var(GetSubBlockIdx() * HALF_TILE_M)
            row_end = Var(row_begin + HALF_TILE_M)
            oh_begin = Var((m0 + row_begin) // OUT_W)

            vcmutex.lock()
            x_raw_ub[x_cnt] <<= x_flat[:, :]
            pad_x_nchw_flat_half_vf(x_raw_ub[x_cnt], x_pad_ub[x_cnt])
            im2col_padded_nchw_half_vf(x_pad_ub[x_cnt], x_col_ub[x_cnt], oh_begin)
            l1x[cube_cnt][row_begin:row_end, 0:KPAD] <<= x_col_ub[x_cnt][0:HALF_TILE_M, 0:KPAD]
            x_cnt += 1
            vcmutex.ready()

            vcmutex.wait()
            l1w[cube_cnt] <<= w_flat[:, :]
            matmul(l0c[cube_cnt], l1x[cube_cnt], l1w[cube_cnt], m=TILE_M, n=OUT_C, k=KFLAT, splitn=SPLIT_N)

            cvmutex.lock()
            preact_ub[post_cnt] <<= l0c[cube_cnt]
            cvmutex.ready()
            vcmutex.free()

            cvmutex.wait()
            bias_ub[post_cnt] <<= b[:, :]
            bias_relu_pack_rows_vf(preact_ub[post_cnt], bias_ub[post_cnt], out_rows_ub[post_cnt])
            y_flat[oh_begin:oh_begin + OH_ROWS_PER_VEC, 0:OUT_W] <<= out_rows_ub[post_cnt][0:OH_ROWS_PER_VEC, 0:OUT_W]
            y_flat[OUT_H + oh_begin:OUT_H + oh_begin + OH_ROWS_PER_VEC, 0:OUT_W] <<= out_rows_ub[post_cnt][
                OH_ROWS_PER_VEC:2 * OH_ROWS_PER_VEC, 0:OUT_W
            ]
            cvmutex.free()

            cube_cnt += 1
            post_cnt += 1

    return y


if __name__ == "__main__":
    import sys
    import torch
    import torch.nn.functional as F

    torch.manual_seed(42)
    use_sim = "--hardware" not in sys.argv

    x = torch.randn((N, IN_C, IN_H, IN_W), dtype=torch.float16)
    w = torch.randn((OUT_C, IN_C, KSZ, KSZ), dtype=torch.float16)
    b = torch.randn((1, OUT_C), dtype=torch.float32)
    y = torch.zeros((N, OUT_C, OUT_H, OUT_W), dtype=torch.float32)

    y_kernel = OpExec(conv2d_relu_n1c2h8w8_fixed_kernel, simulator=use_sim, out_dir="./conv2d_relu_n1c2h8w8_fixed")(
        x, w, b, y, -1
    )
    y_ref = F.relu(F.conv2d(x.float(), w.float(), b.reshape(-1), stride=1, padding=1))

    torch.testing.assert_close(y_kernel, y_ref, rtol=1e-3, atol=1e-3)
    print(f"max_abs_diff={torch.abs(y_kernel - y_ref).max().item():.6e}")
