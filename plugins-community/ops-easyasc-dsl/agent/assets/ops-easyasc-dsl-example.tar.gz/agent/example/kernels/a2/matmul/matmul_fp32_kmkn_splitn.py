import torch


from easyasc.a2 import *


@kernel()
def matmul_fp32_kmkn_splitn_kernel(x, y, z, M, N, K):
    l1x = Tensor(DT.float, [K, M], Position.L1)
    l1y = Tensor(DT.float, [K, N], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)

    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]

        matmul(l0c, l1x.T, l1y.T, splitn=64)

        z[:, :] <<= l0c 

    return z 


if __name__ == "__main__":
    import os
    import sys

    M = 128
    N = 256
    K = 64
    torch.manual_seed(42)
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"

    x = torch.randn(K, M)
    y = torch.randn(K, N)
    z_ref = x.t() @ y
    z_out = torch.zeros(M, N)

    exec_kwargs = dict(simulator=True)
    if run:
        exec_kwargs = dict(
            simulator=False,
            debug=True,
            out_dir="./tmp/matmul_fp32_kmkn_splitn",
            cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        )

    z_kernel = OpExec(matmul_fp32_kmkn_splitn_kernel, **exec_kwargs)(
        x, y, z_out, M, N, K, shape_bindings={0: [2, 0], 1: [2, 1], 2: [0, 1]}
    )

    torch.testing.assert_close(z_kernel.float(), z_ref.float(), rtol=1e-3, atol=1e-3)
    print(f"max_abs_diff={torch.abs(z_kernel.float() - z_ref.float()).max().item():.6e}")
