"""SIMT axpy: out = alpha * x + y over a UB tile.

Codegen + simulator regression sample for the SIMT module on a5.
The kernel handles GM <-> UB DMA; the SIMT body iterates over the tile.
The whole sequence is wrapped in auto_sync(); call_simt declares its UB
read/write sync keys so the autosync pass can schedule MTE2 -> V -> MTE3
ordering without manual bar_all() barriers.

Run by default through the in-process simulator
(`OpExec(..., simulator=True)`).  Pass `--cannsim` on the command line
to switch to the CANNSIM hardware-simulation path instead.
"""

import sys

from easyasc.a5 import *


TILE_ELEMS = 64

# Var args passed to the kernel are (alpha, N).  Bind the second tensor
# dim to scalar index 1 (N), not 0 (alpha).
SHAPE_BINDINGS = {
    0: [None, 1],  # x[1, N]
    1: [None, 1],  # y[1, N]
    2: [None, 1],  # out[1, N]
}


@simt()
def axpy_simt(x_ub: Tensor, y_ub: Tensor, out_ub: Tensor, alpha: Var, n: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out_ub[i] = x_ub[i] * alpha + y_ub[i]


@kernel()
def simt_axpy_kernel(x: GMTensor, y: GMTensor, out: GMTensor, alpha: Var, N: Var):
    x_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    y_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    out_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    n_iter = Var(TILE_ELEMS, DT.int)

    with auto_sync():
        x_ub <<= x[0:1, 0:TILE_ELEMS]
        y_ub <<= y[0:1, 0:TILE_ELEMS]
        axpy_simt(x_ub, y_ub, out_ub, alpha, n_iter)
        out[0:1, 0:TILE_ELEMS] <<= out_ub

    return out


if __name__ == "__main__":
    import torch

    use_cannsim = "--cannsim" in sys.argv[1:]

    N = TILE_ELEMS
    torch.manual_seed(0)
    x = torch.randn((1, N), dtype=torch.float32)
    y = torch.randn((1, N), dtype=torch.float32)
    out = torch.empty_like(x)
    alpha = 2.5

    if use_cannsim:
        actual = OpExec(
            simt_axpy_kernel,
            out_dir="./tmp/simt_axpy_cannsim",
            simulator=False,
            cannsim=True,
        )(x, y, out, alpha, N, shape_bindings=SHAPE_BINDINGS)
    else:
        actual = OpExec(
            simt_axpy_kernel,
            out_dir="./tmp/simt_axpy_simulator",
            simulator=True,
        )(x, y, out, alpha, N, shape_bindings=SHAPE_BINDINGS)

    expected = x * alpha + y
    torch.testing.assert_close(actual, expected, rtol=1e-4, atol=1e-4)
    print(f"max_abs_diff={torch.max(torch.abs(actual - expected)).item():.6e}")
