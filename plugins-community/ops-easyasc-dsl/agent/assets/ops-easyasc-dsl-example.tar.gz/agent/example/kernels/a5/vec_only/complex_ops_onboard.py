"""Commit 2: end-to-end sim + (deferred) on-board smoke for the complex reg ops.

The documented complex-capable reg surface is eight ops -- Add/Sub/Mul/Div,
Adds/Muls, Abs and Duplicate -- for both complex32 (2xfp16, 64 lanes) and
complex64 (2xfp32, 32 lanes). This runner drives each op through the full OpExec
path so the DSL trace, the reg load/store (complex64=8B DIST_NORM, complex32=4B
32-bit, plus the complex32 uint32 numpy surrogate on the sim data path), and the
compute all agree with a torch reference.

Abs is the one op whose output dtype differs from its input: |z| is real, so
complex32 -> half and complex64 -> float.

easyasc's @vf/@kernel specialise on the first-seen argument dtypes, so the two
complex widths need separate kernel objects -- the file therefore carries an
explicit complex64 set and complex32 set (a single dtype's kernels mirror the
int64 runner).

Both paths are validated: sim (default) runs the pure-Python simulator (no C++
codegen); `--run` was validated on the Ascend950 (all 16 ops bit/tol-accurate).
On-board notes:
- the device C++ type is the bare `complex32`/`complex64` (aliases for
  `AscendC::Complex<half>`/`Complex<float>`); complex scalars lower to
  `complex64(re, im)` / `complex32((half)re, (half)im)`.
- abs (complex -> real) runs on-board (the MicroAPI ComplexAbsKernel handles the
  RegTraitNumTwo-src -> RegTraitNumOne-dst half-register layout); the SIM cannot
  model that reg->UB store, so sim skips abs (its compute is covered by
  test_micro_complex_ops.py).
- running all 16 aclnn ops back to back can exhaust device memory on the last one
  (a sequential-harness artifact, not an op bug -- each op is correct in isolation).

Run:
- simulator (default): python kernels/a5/vec_only/complex_ops_onboard.py
- on Ascend950 board:   python kernels/a5/vec_only/complex_ops_onboard.py --run
"""
import builtins
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403  (also shadows builtin `range` with the DSL range)

ROWS = 16
C64_COLS = 32   # 32 complex64 lanes = 256 bytes
C32_COLS = 64   # 64 complex32 lanes = 256 bytes
ADDS_K = 1.5 - 0.5j
MULS_K = 2.0 + 1.0j
DUP_K = 3.0 - 2.0j


# =========================================================================== #
# complex64 kernels (8B, DIST_NORM load/store; |z| -> float)
# =========================================================================== #
@vf()
def c64_arith_vf(ub_a: Tensor, ub_b: Tensor, ub_add: Tensor, ub_sub: Tensor,
                 ub_mul: Tensor, ub_div: Tensor):
    ra = Reg(DT.complex64, name="c64_ar_a"); rb = Reg(DT.complex64, name="c64_ar_b")
    ra <<= ub_a[0]; rb <<= ub_b[0]
    r_add = Reg(DT.complex64, name="c64_ar_add"); r_sub = Reg(DT.complex64, name="c64_ar_sub")
    r_mul = Reg(DT.complex64, name="c64_ar_mul"); r_div = Reg(DT.complex64, name="c64_ar_div")
    add(r_add, ra, rb); sub(r_sub, ra, rb); mul(r_mul, ra, rb); div(r_div, ra, rb)
    ub_add[0] <<= r_add; ub_sub[0] <<= r_sub; ub_mul[0] <<= r_mul; ub_div[0] <<= r_div


@kernel(mode="vec")
def c64_arith_kernel(a: GMTensor, b: GMTensor, o_add: GMTensor, o_sub: GMTensor,
                     o_mul: GMTensor, o_div: GMTensor, rows: Var):
    ub_a = Tensor(DT.complex64, [1, C64_COLS], Position.UB, name="c64_ub_aa")
    ub_b = Tensor(DT.complex64, [1, C64_COLS], Position.UB, name="c64_ub_ab")
    ubs = [Tensor(DT.complex64, [1, C64_COLS], Position.UB, name=f"c64_ub_ar{i}") for i in builtins.range(4)]
    rpv = CeilDiv(rows, GetVecNum()); rb0 = Var(rpv * GetVecIdx()); re0 = Min(rb0 + rpv, rows)
    outs = [o_add, o_sub, o_mul, o_div]
    with auto_sync():
        for r in range(rb0, re0, name="c64_ar_row"):
            ub_a[:, :] <<= a[r:r + 1, :]; ub_b[:, :] <<= b[r:r + 1, :]
            c64_arith_vf(ub_a, ub_b, *ubs)
            for gm, ub in zip(outs, ubs):
                gm[r:r + 1, :] <<= ub
    return o_add, o_sub, o_mul, o_div


@vf()
def c64_scalar_vf(ub_a: Tensor, ub_adds: Tensor, ub_muls: Tensor):
    ra = Reg(DT.complex64, name="c64_sc_a"); ra <<= ub_a[0]
    r_adds = Reg(DT.complex64, name="c64_sc_adds"); r_muls = Reg(DT.complex64, name="c64_sc_muls")
    adds(r_adds, ra, ADDS_K); muls(r_muls, ra, MULS_K)
    ub_adds[0] <<= r_adds; ub_muls[0] <<= r_muls


@kernel(mode="vec")
def c64_scalar_kernel(a: GMTensor, o_adds: GMTensor, o_muls: GMTensor, rows: Var):
    ub_a = Tensor(DT.complex64, [1, C64_COLS], Position.UB, name="c64_ub_sca")
    ub_adds = Tensor(DT.complex64, [1, C64_COLS], Position.UB, name="c64_ub_adds")
    ub_muls = Tensor(DT.complex64, [1, C64_COLS], Position.UB, name="c64_ub_muls")
    rpv = CeilDiv(rows, GetVecNum()); rb0 = Var(rpv * GetVecIdx()); re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="c64_sc_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            c64_scalar_vf(ub_a, ub_adds, ub_muls)
            o_adds[r:r + 1, :] <<= ub_adds; o_muls[r:r + 1, :] <<= ub_muls
    return o_adds, o_muls


@vf()
def c64_abs_vf(ub_a: Tensor, ub_abs: Tensor):
    ra = Reg(DT.complex64, name="c64_ab_a"); ra <<= ub_a[0]
    r_abs = Reg(DT.float, name="c64_ab_r"); abs(r_abs, ra)  # |z| is real (float)
    ub_abs[0] <<= r_abs


@kernel(mode="vec")
def c64_abs_kernel(a: GMTensor, o_abs: GMTensor, rows: Var):
    ub_a = Tensor(DT.complex64, [1, C64_COLS], Position.UB, name="c64_ub_aba")
    ub_abs = Tensor(DT.float, [1, C64_COLS], Position.UB, name="c64_ub_abs")
    rpv = CeilDiv(rows, GetVecNum()); rb0 = Var(rpv * GetVecIdx()); re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="c64_ab_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            c64_abs_vf(ub_a, ub_abs)
            o_abs[r:r + 1, :] <<= ub_abs
    return o_abs


@vf()
def c64_dup_vf(ub_a: Tensor, ub_dup: Tensor):
    ra = Reg(DT.complex64, name="c64_dp_a"); ra <<= ub_a[0]  # load only to satisfy >=1 input rule
    r_dup = Reg(DT.complex64, name="c64_dp_r"); dup(r_dup, DUP_K)
    ub_dup[0] <<= r_dup


@kernel(mode="vec")
def c64_dup_kernel(a: GMTensor, o_dup: GMTensor, rows: Var):
    ub_a = Tensor(DT.complex64, [1, C64_COLS], Position.UB, name="c64_ub_dpa")
    ub_dup = Tensor(DT.complex64, [1, C64_COLS], Position.UB, name="c64_ub_dup")
    rpv = CeilDiv(rows, GetVecNum()); rb0 = Var(rpv * GetVecIdx()); re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="c64_dp_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            c64_dup_vf(ub_a, ub_dup)
            o_dup[r:r + 1, :] <<= ub_dup
    return o_dup


# =========================================================================== #
# complex32 kernels (4B, 32-bit load/store + uint32 numpy surrogate; |z| -> half)
# =========================================================================== #
@vf()
def c32_arith_vf(ub_a: Tensor, ub_b: Tensor, ub_add: Tensor, ub_sub: Tensor,
                 ub_mul: Tensor, ub_div: Tensor):
    ra = Reg(DT.complex32, name="c32_ar_a"); rb = Reg(DT.complex32, name="c32_ar_b")
    ra <<= ub_a[0]; rb <<= ub_b[0]
    r_add = Reg(DT.complex32, name="c32_ar_add"); r_sub = Reg(DT.complex32, name="c32_ar_sub")
    r_mul = Reg(DT.complex32, name="c32_ar_mul"); r_div = Reg(DT.complex32, name="c32_ar_div")
    add(r_add, ra, rb); sub(r_sub, ra, rb); mul(r_mul, ra, rb); div(r_div, ra, rb)
    ub_add[0] <<= r_add; ub_sub[0] <<= r_sub; ub_mul[0] <<= r_mul; ub_div[0] <<= r_div


@kernel(mode="vec")
def c32_arith_kernel(a: GMTensor, b: GMTensor, o_add: GMTensor, o_sub: GMTensor,
                     o_mul: GMTensor, o_div: GMTensor, rows: Var):
    ub_a = Tensor(DT.complex32, [1, C32_COLS], Position.UB, name="c32_ub_aa")
    ub_b = Tensor(DT.complex32, [1, C32_COLS], Position.UB, name="c32_ub_ab")
    ubs = [Tensor(DT.complex32, [1, C32_COLS], Position.UB, name=f"c32_ub_ar{i}") for i in builtins.range(4)]
    rpv = CeilDiv(rows, GetVecNum()); rb0 = Var(rpv * GetVecIdx()); re0 = Min(rb0 + rpv, rows)
    outs = [o_add, o_sub, o_mul, o_div]
    with auto_sync():
        for r in range(rb0, re0, name="c32_ar_row"):
            ub_a[:, :] <<= a[r:r + 1, :]; ub_b[:, :] <<= b[r:r + 1, :]
            c32_arith_vf(ub_a, ub_b, *ubs)
            for gm, ub in zip(outs, ubs):
                gm[r:r + 1, :] <<= ub
    return o_add, o_sub, o_mul, o_div


@vf()
def c32_scalar_vf(ub_a: Tensor, ub_adds: Tensor, ub_muls: Tensor):
    ra = Reg(DT.complex32, name="c32_sc_a"); ra <<= ub_a[0]
    r_adds = Reg(DT.complex32, name="c32_sc_adds"); r_muls = Reg(DT.complex32, name="c32_sc_muls")
    adds(r_adds, ra, ADDS_K); muls(r_muls, ra, MULS_K)
    ub_adds[0] <<= r_adds; ub_muls[0] <<= r_muls


@kernel(mode="vec")
def c32_scalar_kernel(a: GMTensor, o_adds: GMTensor, o_muls: GMTensor, rows: Var):
    ub_a = Tensor(DT.complex32, [1, C32_COLS], Position.UB, name="c32_ub_sca")
    ub_adds = Tensor(DT.complex32, [1, C32_COLS], Position.UB, name="c32_ub_adds")
    ub_muls = Tensor(DT.complex32, [1, C32_COLS], Position.UB, name="c32_ub_muls")
    rpv = CeilDiv(rows, GetVecNum()); rb0 = Var(rpv * GetVecIdx()); re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="c32_sc_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            c32_scalar_vf(ub_a, ub_adds, ub_muls)
            o_adds[r:r + 1, :] <<= ub_adds; o_muls[r:r + 1, :] <<= ub_muls
    return o_adds, o_muls


@vf()
def c32_abs_vf(ub_a: Tensor, ub_abs: Tensor):
    ra = Reg(DT.complex32, name="c32_ab_a"); ra <<= ub_a[0]
    r_abs = Reg(DT.half, name="c32_ab_r"); abs(r_abs, ra)  # |z| is real (half)
    ub_abs[0] <<= r_abs


@kernel(mode="vec")
def c32_abs_kernel(a: GMTensor, o_abs: GMTensor, rows: Var):
    ub_a = Tensor(DT.complex32, [1, C32_COLS], Position.UB, name="c32_ub_aba")
    ub_abs = Tensor(DT.half, [1, C32_COLS], Position.UB, name="c32_ub_abs")
    rpv = CeilDiv(rows, GetVecNum()); rb0 = Var(rpv * GetVecIdx()); re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="c32_ab_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            c32_abs_vf(ub_a, ub_abs)
            o_abs[r:r + 1, :] <<= ub_abs
    return o_abs


@vf()
def c32_dup_vf(ub_a: Tensor, ub_dup: Tensor):
    ra = Reg(DT.complex32, name="c32_dp_a"); ra <<= ub_a[0]  # load only to satisfy >=1 input rule
    r_dup = Reg(DT.complex32, name="c32_dp_r"); dup(r_dup, DUP_K)
    ub_dup[0] <<= r_dup


@kernel(mode="vec")
def c32_dup_kernel(a: GMTensor, o_dup: GMTensor, rows: Var):
    ub_a = Tensor(DT.complex32, [1, C32_COLS], Position.UB, name="c32_ub_dpa")
    ub_dup = Tensor(DT.complex32, [1, C32_COLS], Position.UB, name="c32_ub_dup")
    rpv = CeilDiv(rows, GetVecNum()); rb0 = Var(rpv * GetVecIdx()); re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="c32_dp_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            c32_dup_vf(ub_a, ub_dup)
            o_dup[r:r + 1, :] <<= ub_dup
    return o_dup


# (tag, torch complex dtype, torch real dtype, cols, tol, kernels dict)
_VARIANTS = [
    ("c64", torch.complex64, torch.float32, C64_COLS, 3e-4, {
        "arith": (c64_arith_kernel, ["add", "sub", "mul", "div"]),
        "scalar": (c64_scalar_kernel, ["adds", "muls"]),
        "abs": (c64_abs_kernel, ["abs"]),
        "dup": (c64_dup_kernel, ["dup"]),
    }),
    ("c32", torch.complex32, torch.float16, C32_COLS, 6e-3, {
        "arith": (c32_arith_kernel, ["add", "sub", "mul", "div"]),
        "scalar": (c32_scalar_kernel, ["adds", "muls"]),
        "abs": (c32_abs_kernel, ["abs"]),
        "dup": (c32_dup_kernel, ["dup"]),
    }),
]


# --------------------------------------------------------------------------- #
# Driver
# --------------------------------------------------------------------------- #
def _make_inputs(tcdt, cols):
    torch.manual_seed(0)
    a = (torch.randn(ROWS, cols) + 1j * torch.randn(ROWS, cols)).to(tcdt).contiguous()
    # keep b away from zero so div is well-conditioned
    b = ((torch.randn(ROWS, cols) + 2.5) + 1j * (torch.randn(ROWS, cols) - 2.0)).to(tcdt).contiguous()
    return a, b


def _golden(a, b, trdt):
    a64, b64 = a.to(torch.complex64), b.to(torch.complex64)
    return {
        "add": a64 + b64, "sub": a64 - b64, "mul": a64 * b64, "div": a64 / b64,
        "adds": a64 + ADDS_K, "muls": a64 * MULS_K,
        "abs": torch.abs(a64).to(trdt), "dup": torch.full_like(a64, DUP_K),
    }


def _opexec(kern, tag, fam, run_on_board):
    if run_on_board:
        cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"])
    else:
        cfg = dict(simulator=True)
    return OpExec(kern, out_dir=os.path.abspath(f"tmp/complex_ops/{tag}_{fam}"),
                  custom_op_path=os.path.abspath("tmp/complex_ops/custom_opp"), **cfg)


def _check(mode, name, got, want, tol, fails):
    g = got.to(torch.complex64) if got.is_complex() else got.to(torch.float32)
    w = want.to(torch.complex64) if want.is_complex() else want.to(torch.float32)
    if torch.allclose(g, w, rtol=tol, atol=tol):
        print(f"[{mode}] {name:9s} OK  (max|err|={(g - w).abs().max().item():.2e})")
    else:
        d = (g - w).abs(); idx = torch.argmax(d.flatten()).item()
        print(f"[{mode}] {name:9s} MISMATCH max|err|={d.max().item():.3e} "
              f"got={g.flatten()[idx].item()} want={w.flatten()[idx].item()}")
        fails.append(name)


def check_case(run_on_board):
    mode = "board" if run_on_board else "sim"
    fails, build_fails = [], []
    total = 0

    for tag, tcdt, trdt, cols, tol, kernels in _VARIANTS:
        a, b = _make_inputs(tcdt, cols)
        g = _golden(a, b, trdt)

        def run(fam, kern, names, inputs, out_real=False):
            try:
                odt = trdt if out_real else tcdt
                outs = [torch.zeros((ROWS, cols), dtype=odt) for _ in names]
                res = _opexec(kern, tag, fam, run_on_board)(*inputs, *outs, ROWS)
                if not isinstance(res, (list, tuple)):
                    res = (res,)
                for name, got in zip(names, res):
                    _check(mode, f"{tag}.{name}", got, g[name], tol, fails)
            except Exception as exc:  # noqa: BLE001 -- keep the whole matrix on one failure
                print(f"[{mode}] {tag}.{fam:6s} BUILD/RUN-FAIL: {type(exc).__name__}: {str(exc)[:180]}")
                build_fails.extend(f"{tag}.{n}" for n in names)

        run("arith", *kernels["arith"], (a, b))
        run("scalar", *kernels["scalar"], (a,))
        run("dup", *kernels["dup"], (a,))
        total += 7
        # Abs is complex -> real: |z| half-fills a real register (32 complex64 lanes
        # -> 32 float lanes = 128B of a 256B float register). The on-board MicroAPI
        # ComplexAbsKernel handles this via RegTraitNumTwo-src -> RegTraitNumOne-dst,
        # so abs runs on the board (validated). The pure-Python sim cannot model that
        # reg->UB store layout, so sim skips abs; its compute + dtype pairing are
        # covered by test_micro_complex_ops.py.
        if run_on_board:
            run("abs", *kernels["abs"], (a,), out_real=True)
            total += 1
        else:
            print(f"[{mode}] {tag}.abs      sim-skipped (complex->real half-register store "
                  f"is board-only; validated on-board, compute in test_micro_complex_ops.py)")

    ok = total - len(fails) - len(build_fails)
    print(f"\n[{mode}] summary: {ok}/{total} complex ops within tol; "
          f"value-mismatch={fails or '-'}; build/run-fail={build_fails or '-'}")
    if fails or build_fails:
        raise AssertionError(f"complex ops {mode}: mismatch={fails} build_fail={build_fails}")
    print(f"[{mode}] ALL {total} complex ops within tolerance")


if __name__ == "__main__":
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1"
    check_case(run_on_board=run)
