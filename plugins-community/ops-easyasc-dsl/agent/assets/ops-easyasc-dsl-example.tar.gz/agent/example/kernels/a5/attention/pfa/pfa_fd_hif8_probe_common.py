"""Shared DSL primitives for the retained all-hif8 PFA diagnostic probes.

This module contains no kernel entrypoints, variant dispatch, simulator runner, or
board runner. Probe files import only the common vector functions, bridge helpers,
geometry constants, and reference utilities defined here.
"""
import builtins
import math
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5pr") == "a5":
    from easyasc.a5 import *
else:
    from easyasc.a5pr import *

_pyrange = builtins.range

TILE_M = 128
ROWS_PER_SB = 64
QLANES = ROWS_PER_SB
TILE_N = 128
D_HEAD = 128
SOFTMAX_SCALE = 1.0 / math.sqrt(D_HEAD)
HALF = TILE_N // 2
CHUNKS_D = D_HEAD // 64
KROW = QLANES
M_Q = QLANES
CD = CHUNKS_D

PRELOAD_N = int(os.environ.get("PV_PRELOAD_N", "2"))  # QK-PV pipeline depth (was fixed 2); CACHE tracks it
CACHE = PRELOAD_N + 1
_CacheBuf = QBuff if CACHE >= 4 else TBuff  # l1 K/V/P + softmax-state buffer depth tracks CACHE (TBuff@3, QBuff@4)
MAX_CORE_COUNT = 32
MAX_FD_WS = MAX_CORE_COUNT * 2
UNROLL = 4
RB_MAX = TILE_N // UNROLL      # 32
RB_EXP = HALF // UNROLL        # 16
KREGS = TILE_N // 2            # 64
RB_MAX_H = KREGS // UNROLL     # 16
RB_EXP_H = KREGS // UNROLL     # 16
NEG_LARGE = -1.0e30
NEG_LARGE_H = -60000.0


# =========================== initialization ===========================
@vf()
def init_softmax_state_vf(ub_rmax: Tensor, ub_rsum: Tensor):
    neg = Reg(DT.float); zero = Reg(DT.float)
    neg <<= NEG_LARGE; zero <<= 0.0
    ub_rmax[0:1, 0:QLANES] <<= neg
    ub_rsum[0:1, 0:QLANES] <<= zero


@vf()
def init_softmax_half_vf(ub_rmax: Tensor, ub_rsum: Tensor):
    neg = Reg(DT.half); zero = Reg(DT.half)
    neg <<= NEG_LARGE_H; zero <<= 0.0
    ub_rmax[0:1, 0:TILE_N] <<= neg
    ub_rsum[0:1, 0:TILE_N] <<= zero


# =========================== fp32 online softmax ===========================
@vf()
def softmax_t_scale_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.float, UNROLL); acc = RegList(DT.float, UNROLL); preg = RegList(DT.float, UNROLL)
    p_hi = RegList(DT.hif8, UNROLL); p_hj = RegList(DT.hif8, UNROLL)
    p_mask4 = MaskReg(DT.hif8, init_mode=MaskType.NONE); p_mask4 <<= Var(4 * QLANES, dtype=DT.uint32)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_i")
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP, name="ex"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hi[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u + HALF):(rb * UNROLL + u + HALF) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hj[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            reg_to_ub_pack4(ub_p[(rb * UNROLL + u) * KROW], p_hi[u], mask=p_mask4)
            reg_to_ub_pack4(ub_p[((rb * UNROLL + u) + HALF) * KROW], p_hj[u], mask=p_mask4)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_t_scale_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor, valid_n: Var):
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float); p_hif8 = Reg(DT.hif8)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    p_mask4 = MaskReg(DT.hif8, init_mode=MaskType.NONE); p_mask4 <<= Var(4 * QLANES, dtype=DT.uint32)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_tail_i")
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    block_sum <<= 0.0
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        cast(p_hif8, e, cfg_i)
        reg_to_ub_pack4(ub_p[n * KROW], p_hif8, mask=p_mask4)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# =========================== fp16 online softmax ===========================
@vf()
def softmax_half_scale_vf(ub_h: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.half, UNROLL); acc = RegList(DT.half, UNROLL); preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="ph_hif8")
    neg = Reg(DT.half); block_max = Reg(DT.half); block_sum = Reg(DT.half); t = Reg(DT.half); swap = Reg(DT.half)
    v_pmax = Reg(DT.half); v_nmax = Reg(DT.half); v_oldw = Reg(DT.half)
    v_psum = Reg(DT.half); v_nsum = Reg(DT.half)
    # half-swap gather index [64..127, 0..63] = lane XOR 64, so gather(swap, x, idxu) exchanges the
    # two 64-lane halves (even-key reduce <-> odd-key reduce) for the cross-half vmax/add merge.
    idx16 = Reg(DT.int16); arange(idx16, 0)
    swp64 = Reg(DT.int16); swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)
    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX_H, name="mxh"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u) * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    muls(block_max, block_max, SOFTMAX_SCALE)
    v_pmax <<= ub_rmax[0:1, 0:TILE_N]
    v_nmax <<= block_max.vmax(v_pmax)
    sub(v_oldw, v_pmax, v_nmax); exp(v_oldw, v_oldw)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP_H, name="exh"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u) * TILE_N]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            sub(preg[u], sreg[u], v_nmax)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            reg_to_ub_downsample(ub_p[(rb * UNROLL + u) * TILE_N], p_h[u])
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:TILE_N]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= v_nmax
    ub_rsum[0:1, 0:TILE_N] <<= v_nsum
    ub_old_weight[0:1, 0:TILE_N] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_half_noscale_vf(ub_h: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.half, UNROLL); acc = RegList(DT.half, UNROLL); preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="ph_hif8")
    neg = Reg(DT.half); block_max = Reg(DT.half); block_sum = Reg(DT.half); t = Reg(DT.half); swap = Reg(DT.half)
    v_pmax = Reg(DT.half); v_nmax = Reg(DT.half); v_oldw = Reg(DT.half)
    v_psum = Reg(DT.half); v_nsum = Reg(DT.half)
    # half-swap gather index [64..127, 0..63] = lane XOR 64, so gather(swap, x, idxu) exchanges the
    # two 64-lane halves (even-key reduce <-> odd-key reduce) for the cross-half vmax/add merge.
    idx16 = Reg(DT.int16); arange(idx16, 0)
    swp64 = Reg(DT.int16); swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)
    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX_H, name="mxh"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u) * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    v_pmax <<= ub_rmax[0:1, 0:TILE_N]
    v_nmax <<= block_max.vmax(v_pmax)
    sub(v_oldw, v_pmax, v_nmax); exp(v_oldw, v_oldw)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP_H, name="exh"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u) * TILE_N]
            sub(preg[u], sreg[u], v_nmax)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            reg_to_ub_downsample(ub_p[(rb * UNROLL + u) * TILE_N], p_h[u])
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:TILE_N]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= v_nmax
    ub_rsum[0:1, 0:TILE_N] <<= v_nsum
    ub_old_weight[0:1, 0:TILE_N] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# =========================== PV accum / finalize ===========================
@vf()
def accum_pv_vf(ub_accum: Tensor, ub_pv: Tensor, ub_old_weight: Tensor):
    # acc = acc*old_weight + pv, fused via muldstadd (dst = dst*src0 + src1). Rows unrolled by UNROLL
    # to overlap the per-row load->FMA->store chains; each row is CHUNKS_D 64-lane fp32 regs.
    acc = RegList(DT.float, UNROLL * CHUNKS_D); pv = RegList(DT.float, UNROLL * CHUNKS_D)
    ow = RegList(DT.float, UNROLL)
    for rb in range(ROWS_PER_SB // UNROLL, name="arow"):
        for u in unroll(UNROLL):
            r = rb * UNROLL + u
            ow[u] <<= ub_old_weight[0:1, r:r + 1].single()
            for c in _pyrange(CHUNKS_D):
                k = u * CHUNKS_D + c
                acc[k] <<= ub_accum[r:r + 1, c * 64:(c + 1) * 64]
                pv[k] <<= ub_pv[r:r + 1, c * 64:(c + 1) * 64]
                muldstadd(acc[k], ow[u], pv[k])
                ub_accum[r:r + 1, c * 64:(c + 1) * 64] <<= acc[k]
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_pv_fp16ow_vf(ub_accum: Tensor, ub_pv: Tensor, ub_old_weight: Tensor):
    # fp16 old_weight read per-row as a single-value (.single()) broadcast + scalar cast to float
    # (a scalar cast round-trips exactly, unlike a vector half->float cast). acc = acc*ow + pv fused
    # via muldstadd; rows unrolled by UNROLL to overlap the load->cast->FMA->store chains.
    acc = RegList(DT.float, UNROLL * CHUNKS_D); pv = RegList(DT.float, UNROLL * CHUNKS_D)
    ow_h = RegList(DT.half, UNROLL); ow_f = RegList(DT.float, UNROLL)
    cfg_hf = CastConfig(round_mode=RoundMode.NONE, name="ow_h2f")
    for rb in range(ROWS_PER_SB // UNROLL, name="arow"):
        for u in unroll(UNROLL):
            r = rb * UNROLL + u
            ow_h[u] <<= ub_old_weight[0:1, r:r + 1].single()
            cast(ow_f[u], ow_h[u], cfg_hf)
            for c in _pyrange(CHUNKS_D):
                k = u * CHUNKS_D + c
                acc[k] <<= ub_accum[r:r + 1, c * 64:(c + 1) * 64]
                pv[k] <<= ub_pv[r:r + 1, c * 64:(c + 1) * 64]
                muldstadd(acc[k], ow_f[u], pv[k])
                ub_accum[r:r + 1, c * 64:(c + 1) * 64] <<= acc[k]
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_pv_first_vf(ub_accum: Tensor, ub_pv: Tensor):
    pv = RegList(DT.float, CHUNKS_D)
    for r in range(ROWS_PER_SB):
        pv <<= ub_pv[r:r + 1, 0:D_HEAD]
        ub_accum[r:r + 1, 0:D_HEAD] <<= pv
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def final_div_cast_bf16_vf(ub_accum: Tensor, ub_rsum: Tensor, ub_out: Tensor):
    acc = RegList(DT.float, CHUNKS_D); rsum = Reg(DT.float)
    for r in range(ROWS_PER_SB):
        rsum <<= ub_rsum[0:1, r:r + 1].single()
        acc <<= ub_accum[r:r + 1, 0:D_HEAD]
        acc <<= acc / rsum
        ub_out[r:r + 1, 0:D_HEAD] <<= acc
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def final_div_fp16rsum_vf(ub_accum: Tensor, ub_rsum: Tensor, ub_out: Tensor):
    acc = RegList(DT.float, CHUNKS_D); rsum_h = Reg(DT.half); rsum_f = Reg(DT.float)
    cfg_hf = CastConfig(round_mode=RoundMode.NONE, name="rs_h2f")
    for r in range(ROWS_PER_SB):
        rsum_h <<= ub_rsum[0:1, r:r + 1].single()
        cast(rsum_f, rsum_h, cfg_hf)
        acc <<= ub_accum[r:r + 1, 0:D_HEAD]
        acc <<= acc / rsum_f
        ub_out[r:r + 1, 0:D_HEAD] <<= acc
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def init_accum_vf(ub_accum: Tensor):
    zero = Reg(DT.float)
    zero <<= 0.0
    for r in range(ROWS_PER_SB):
        ub_accum[r:r + 1, 0:D_HEAD] <<= zero
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# =========================== FD aggregation ===========================
@vf()
def fd_merge_vf(ub_o0: Tensor, ub_o1: Tensor, ub_m0: Tensor, ub_m1: Tensor,
                ub_s0: Tensor, ub_s1: Tensor, ub_A: Tensor, ub_den: Tensor, ub_merged: Tensor):
    m0v = Reg(DT.float); m1v = Reg(DT.float); s0v = Reg(DT.float); s1v = Reg(DT.float)
    Av = Reg(DT.float); denv = Reg(DT.float)
    m0v <<= ub_m0[0:1, 0:M_Q]; m1v <<= ub_m1[0:1, 0:M_Q]
    s0v <<= ub_s0[0:1, 0:M_Q]; s1v <<= ub_s1[0:1, 0:M_Q]
    expsub(Av, m0v, m1v)
    denv <<= s0v * Av
    denv <<= denv + s1v
    ub_A[0:1, 0:M_Q] <<= Av
    ub_den[0:1, 0:M_Q] <<= denv
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    o0 = RegList(DT.float, CD); o1 = RegList(DT.float, CD); Ar = Reg(DT.float); dr = Reg(DT.float)
    for r in range(M_Q, name="row"):
        Ar <<= ub_A[0:1, r:r + 1].single()
        dr <<= ub_den[0:1, r:r + 1].single()
        o0 <<= ub_o0[r:r + 1, :]
        o1 <<= ub_o1[r:r + 1, :]
        o0 <<= o0 * Ar
        o0 <<= o0 + o1
        o0 <<= o0 / dr
        ub_merged[r:r + 1, :] <<= o0
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def fd_merge_fp16_vf(ub_o0: Tensor, ub_o1: Tensor, ub_m0: Tensor, ub_m1: Tensor,
                     ub_s0: Tensor, ub_s1: Tensor, ub_A: Tensor, ub_den: Tensor, ub_merged: Tensor):
    # ub_m0/m1/s0/s1 are fp16. A half->float cast of a *vector* of distinct per-lane values mis-lays
    # the lanes (only single-value .single() broadcasts round-trip exactly, as in accum_pv_fp16ow_vf),
    # so compute the rescale weight A = exp(m0-m1) and denominator den = s0*A + s1 PER ROW from
    # single-value casts, all math in float (o0/o1 are float PV partials). ub_A/ub_den unused here.
    o0 = RegList(DT.float, CD); o1 = RegList(DT.float, CD)
    m0h = Reg(DT.half); m1h = Reg(DT.half); s0h = Reg(DT.half); s1h = Reg(DT.half)
    m0f = Reg(DT.float); m1f = Reg(DT.float); s0f = Reg(DT.float); s1f = Reg(DT.float)
    Ar = Reg(DT.float); dr = Reg(DT.float)
    cfg_hf = CastConfig(round_mode=RoundMode.NONE, name="merge_h2f")
    for r in range(M_Q, name="row"):
        m0h <<= ub_m0[0:1, r:r + 1].single(); cast(m0f, m0h, cfg_hf)
        m1h <<= ub_m1[0:1, r:r + 1].single(); cast(m1f, m1h, cfg_hf)
        s0h <<= ub_s0[0:1, r:r + 1].single(); cast(s0f, s0h, cfg_hf)
        s1h <<= ub_s1[0:1, r:r + 1].single(); cast(s1f, s1h, cfg_hf)
        expsub(Ar, m0f, m1f)
        dr <<= s0f * Ar
        dr <<= dr + s1f
        o0 <<= ub_o0[r:r + 1, :]
        o1 <<= ub_o1[r:r + 1, :]
        o0 <<= o0 * Ar
        o0 <<= o0 + o1
        o0 <<= o0 / dr
        ub_merged[r:r + 1, :] <<= o0
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def output_cast_vf(ub_merged: Tensor, ub_out: Tensor):
    regs = RegList(DT.float, CD); hregs = RegList(DT.bfloat16, CD)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="o_bf16")
    for r in range(M_Q, name="crow"):
        regs <<= ub_merged[r:r + 1, :]
        for c in unroll(CD):
            cast(hregs[c], regs[c], cfg)
            reg_to_ub_downsample(ub_out[r:r + 1, c * 64:(c + 1) * 64], hregs[c])
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


def _flat_intervals(total_tasks, core_count):
    return [(total_tasks * c // core_count, total_tasks * (c + 1) // core_count) for c in _pyrange(core_count)]


def _pairwise_split_ok(total_blocks, k_tiles, core_count):
    owners = [0] * total_blocks
    for start, end in _flat_intervals(total_blocks * k_tiles, core_count):
        if start >= end:
            continue
        first = start // k_tiles
        last = (end - 1) // k_tiles
        for mb in _pyrange(first, last + 1):
            owners[mb] += 1
    max_owners = max(owners) if owners else 0
    split_blocks = sum(1 for x in owners if x == 2)
    return max_owners <= 2, max_owners, split_blocks


# =========================== QK L0C->UB bridge (dual-SINGLE vs single-SPLITN; @func param) ===========================
@func()
def _qk_bridge_dual_single(ub_dst, l0c_src, l0c_scale):
    # TWO SINGLE fixpipe copies: vec sub-block 0 reads L0C query-cols [0:64], sub-block 1 reads
    # [64:128]. Requant (scale!=1) and fp32->fp16 downcast ride the SINGLE deqScalar path.
    l0c_to_ub(ub_dst, l0c_src[0:TILE_N, 0:ROWS_PER_SB],
              M=TILE_N, N=ROWS_PER_SB, N_dst=ROWS_PER_SB, M_src=TILE_N,
              dual_mode=DualMode.SINGLE, sub_block_id=0, scale=l0c_scale)
    l0c_to_ub(ub_dst, l0c_src[0:TILE_N, ROWS_PER_SB:TILE_M],
              M=TILE_N, N=ROWS_PER_SB, N_dst=ROWS_PER_SB, M_src=TILE_N,
              dual_mode=DualMode.SINGLE, sub_block_id=1, scale=l0c_scale)


@func()
def _qk_bridge_splitn(ub_dst, l0c_src, l0c_scale):
    # ONE SPLITN fixpipe copy; HW auto-splits N across the 2 vec sub-blocks. Cannot requant, so
    # scale must be 1.0 (plain copy). A/B control to isolate the dual-SINGLE bridge's extra cost.
    l0c_to_ub(ub_dst, l0c_src[0:TILE_N, 0:TILE_M],
              M=TILE_N, N=TILE_M, N_dst=ROWS_PER_SB, M_src=TILE_N,
              dual_mode=DualMode.SPLITN, sub_block_id=0, scale=l0c_scale)


# =========================== host-side references ===========================
def _ref_mqa(qf, kf, vf, b_n, hq, sq, skv, quant_p=False):
    outs = []
    for b in _pyrange(b_n):
        kb = kf[b * skv:(b + 1) * skv]; vb = vf[b * skv:(b + 1) * skv]
        for h in _pyrange(hq):
            base = b * hq * sq + h * sq
            qh = qf[base:base + sq]
            p = torch.softmax((qh @ kb.t()) * SOFTMAX_SCALE, dim=-1)
            if quant_p:
                p = hif8_to_fp32(fp32_to_hif8(p))
            outs.append(p @ vb)
    o = torch.cat(outs, dim=0)
    return o.to(torch.bfloat16).float() if quant_p else o


def _err(a, b):
    d = (torch.as_tensor(a).float() - torch.as_tensor(b).float()).abs()
    return d.max().item(), d.mean().item()
