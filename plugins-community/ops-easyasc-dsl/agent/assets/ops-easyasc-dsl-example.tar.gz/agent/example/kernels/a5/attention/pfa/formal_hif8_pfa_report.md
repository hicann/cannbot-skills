# 正式报告：EasyASC A5 all-hif8 PFA 与官方 BF16 FIA 对比

> **V9 arbitrary-tail update (2026-07-21).** V9 now accepts every positive
> final logical-group length in `1..384`, including a single logical group.
> Separate branch-free FP16 VFs cover partial P0 and partial third-tile maxima;
> absent P beats retain the fixed three-token event phase, while partial PV
> MMADs use the true K. One-core same-slot-reuse simulation passed tails
> `1/127/128/129/255/256/257/383/384` and single-group `N=1/257`. Direct A5
> passed representative tails 1 and 257. The `B=1,HQ=40,SQ=SKV=9360,D=128`
> regression measured `3001.80 us`, within `0.13%` of the prior formal
> `2997.97 us`, with sampled max/mean error `2.808e-3 / 4.788e-4`.
>
> **V9 promotion update (2026-07-20).** The maintained route for
> `B=1,HQ=40,SQ=SKV=9360,D=128` is now `v9_allhif8.py`. It preserves V8's
> logical-384 grouped PV accumulation, uses FP16 two-SINGLE score exports and
> padded paired-key direct-NZ P packing, and rebalances L0C to two QK plus two PV
> slots. Direct A5 selection measured `3002.27 us` average versus paired V8
> `3634.10 us` (`1.210x`), with max/mean error
> `4.211e-3 / 4.857e-4`; the renamed formal file reran at `2997.97 us` with
> identical error.
>
> **V8 promotion update (2026-07-20).** The maintained A5 implementation is now
> `v8_allhif8.py`, the logical-384, lead-two grouped schedule. On direct A5 at
> `B=1,HQ=8,SQ=SKV=4099,D=128`, its selected middle-50 median is `139.5568 us`;
> the original V6 measured `180.645 us` in the same optimization campaign, for
> a `1.294x` speedup. The V6-versus-official measurements below are retained as
> historical baseline analysis and no longer identify the fastest maintained
> EasyASC kernel.
>
> **V8 tail update (2026-07-20).** V8 now accepts final logical-384 groups with
> 129--256 valid keys. At `B=1,HQ=40,SQ=SKV=9360,D=128` (144-key final group),
> paired direct-A5 profiles measured `3625.44 us` versus V6 `4505.45 us`
> (`1.243x`). Its nominal-frequency median was `3490.23 us`, versus official
> BF16 FIA `4433.35 us` (`1.270x`); a 30-row full-shape golden covering every
> FD split measured max/mean error `1.526e-3 / 3.380e-4`.

## 1. 结论

| 项目 | 官方 BF16 FIA | EasyASC 当前 all-hif8 v6 |
|---|---:|---:|
| 实现 | `torch_npu.npu_fused_infer_attention_score` | `kernels/a5/attention/pfa/pfa_fd_v6_allhif8.py` |
| 输入/中间精度 | Q/K/V/O BF16 | Q/K/P/V hif8 carrier，O BF16 |
| 形状 | `B=1,HQ=8,HKV=1,S=4099,D=128` | 同左 |
| 真机平均耗时 | `222.28 us` | `204.61 us` |
| 相对官方 BF16 | baseline | 快 `17.67 us`，延迟降低约 `7.9%`，speedup 约 `1.09x` |

当前 v6 的误差参考是 hif8 carrier 解码后的 FP32 PyTorch reference，不是官方 BF16 kernel 的逐元素等价参考：

| max abs err | mean abs err |
|---:|---:|
| `3.479e-3` | `5.112e-4` |

工程判断如下：

- 当前 all-hif8 v6 可以作为“比官方 BF16 FIA 更快”的性能路线。
- 如果需求更偏稳妥精度，`pfa_fd_v5_qkhif8.py` 仍是更保守的中间路线：只量化 Q/K，P/V 保留 BF16，softmax 仍走 FP32，保留的对照结果为 `208.8 us`、`max abs err=9.77e-4`。
- all-hif8 能赢的前提是当前仓里的 NZ-direct P-store：`pfa_fd_v6_allhif8.py` 不是旧 `ub_to_l1_nd2nz` v6 probe，它的 P-store 路线是 `ub_to_l1_nz`。
- `pfa_fd_hif8_hv2_pair64_nz_probe.py` 验证了“hv2 fp16 softmax + BF16-style NZ P publish”方向，但没有收益：同环境重跑当前 v6 为 `204.61 us`，该 probe 为 `207.27 us`，慢 `2.66 us`，因此作为方向性探索留痕，不扶正。

## 2. 官方 BF16 FIA vs 当前 EasyASC v6

### 2.1 端到端耗时

| 实现 | profiler / runner 证据 | 平均耗时 |
|---|---|---:|
| 官方 FIA BF16 | 50 条 `FusedInferAttentionScore` profiler row | `222.28 us` |
| EasyASC 当前 v6 | `PfaFdV6Allhif8Kernel`，`rows[25:75]` 平均 | `204.61 us` |

EasyASC 当前 v6 比官方 BF16 FIA 快 `17.67 us`。这个结果和此前“官方大约 223us”的背景数一致，但现在已经用同形状官方 `torch_npu` kernel 重新固化为正式 baseline。

### 2.2 Pipe 占用率

| 实现 | AIC MAC | AIC FIX | AIC MTE2 | AIC MTE1 | AIC Scalar | AIV VEC | AIV MTE3 | AIV MTE2 | AIV Scalar | cube util |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 官方 FIA BF16 | `92.7%` | `88.4%` | `85.6%` | `63.9%` | `65.7%` | `81.2%` | `40.2%` | `0.5%` | `47.2%` | `93.3%` |
| EasyASC 当前 v6 | `62.8%` | `93.7%` | `52.2%` | `35.0%` | `39.1%` | `92.1%` | `31.0%` | `0.5%` | `27.5%` | `98.0%` |

对应的 pipe active time 如下。官方 FIA 的时间由 `222.28 us × ratio` 换算；当前 v6 使用 `rows[25:75]` 的 `*_time` 平均值。

| 实现 | AIC MAC | AIC FIX | AIC MTE2 | AIC MTE1 | AIC Scalar | AIV VEC | AIV MTE3 | AIV MTE2 | AIV Scalar |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 官方 FIA BF16 | `206.05 us` | `196.50 us` | `190.27 us` | `142.04 us` | `146.04 us` | `180.49 us` | `89.36 us` | `1.11 us` | `104.92 us` |
| EasyASC 当前 v6 | `128.33 us` | `191.47 us` | `106.71 us` | `71.44 us` | `79.89 us` | `188.20 us` | `63.30 us` | `1.01 us` | `56.17 us` |

直接读法：

- 官方 BF16 FIA 是更均衡的 BF16 高吞吐实现，MAC、MTE2、FIX、AIV VEC 都比较高。
- 当前 all-hif8 v6 明显降低了 GM/L1 侧压力，AIC MTE2 从 `85.6% / 190.27 us` 降到 `52.2% / 106.71 us`，AIC MTE1 从 `63.9% / 142.04 us` 降到 `35.0% / 71.44 us`。
- 当前 v6 的热 pipe 转移到 AIC FIX 与 AIV VEC：FIX `93.7% / 191.47 us`，VEC `92.1% / 188.20 us`。这说明它不是 GM 带宽主导 kernel，而是片上 bridge、softmax、P packing 与 P-store 共同决定上限。
- 当前 v6 的 cube util `98.0%` 高于官方 FIA 的 `93.3%`，但 AIC MAC ratio 更低；这反映的是 schedule 与数据路径差异，不应解读成逐 core 的同构对比。

### 2.3 Q/K hif8 v5：中间路线的 pipe anchor

`pfa_fd_v5_qkhif8.py` 是保留的 variant 5：Q/K 用 hif8，P/V 保留 BF16，softmax 仍走 FP32，QK bridge 是 single-SPLITN，并且 P-store 已经是 direct-NZ + bulk `ub_to_l1_nz`。它不是当前 all-hif8 v6 的直接消融，但它是“只量化 Q/K”的稳妥中间路线，因此需要作为正式比较点保留。

归档的 msprof 记录中，v5 端到端为 `208.8 us`，`max abs err=9.77e-4`。主要 pipe 占用如下；该记录没有保留 AIC scalar 的精确列，因此这里只列已归档 pipe：

| side | pipe | active time | ratio |
|---|---|---:|---:|
| AIC | FIX / `L0C -> UB` | `192 us` | `92%` |
| AIC | MAC | `164 us` | `78%` |
| AIC | MTE2 | `128 us` | `61%` |
| AIC | MTE1 | `108 us` | `52%` |
| AIV | VEC / softmax | `177 us` | `85%` |
| AIV | MTE3 | `80 us` | `38%` |
| AIV | Scalar | `45 us` | `22%` |
| AIV | MTE2 | `1 us` | `0.5%` |

v5 的读法和当前 v6 不同：v5 是 AIC FIX `92%` + AIV VEC `85%` 的双热墙，cube 与 vec 几乎满重叠；它同样不是 GM 带宽主导。后续如果追 v5，方向应是减少 FIX element/op-count 或降低 softmax vec 成本，而不是把 `L0C -> UB` 输出改成 BF16，因为 BF16 downcast 会强迫 dual-SINGLE，保留的 A/B 结果表明 v5 会慢约 `39.6 us`。

## 3. 当前 v6 为什么能赢

当前 all-hif8 v6 的收益主要来自三件事：

1. Q/K/V/P payload 变小后，GM/L1 数据流压力降低。
2. `P` 不再通过碎片化 `ub_to_l1_nd2nz` 发布，而是由当前 v6 的 NZ carrier 走 `ub_to_l1_nz`。
3. score bridge 避免不必要的 dual-SINGLE 形式，减少 FIX pipe op-count 与 setup 暴露。

### 3.1 P-store：从 `ub_to_l1_nd2nz` 改成 `ub_to_l1_nz`

| probe 家族 | P-store 路线 | full | veconly | vecnostore | P-store 自身代价 |
|---|---|---:|---:|---:|---:|
| `nz4/deinterleave` probe | `ub_to_l1_nz` | `202.30 us` | `209.70 us` | `187.29 us` | `22.41 us` |
| 旧 nd2nz probe | `ub_to_l1_nd2nz` | `241.71 us` | `211.77 us` | `151.02 us` | `60.75 us` |

优化点很直接：旧路径让 vec 侧生成 ND 形式的 P，再靠 `ub_to_l1_nd2nz` 做碎片化转换；当前 v6 让 softmax 直接生成 NZ carrier，再用 bulk `ub_to_l1_nz` 发布到 L1。按同一 probe 家族内 `veconly - vecnostore` 计算，P-store 自身代价从约 `60.75 us` 降到约 `22.41 us`。

因此，旧 “v6 vec-only” 数据不能拿来解释当前 v6：旧 probe 的瓶颈是碎片化 `ub_to_l1_nd2nz`，而当前正式 v6 已经换成 `ub_to_l1_nz`。

### 3.2 Clean cube-side：dual-SINGLE 的真实代价约 10-12us

之前的 `purecube` 测试有误导性，因为它仍带着隐藏 vec-lane `P-store`，不能作为“纯 cube bridge”消融。重新补跑的 clean AIC-only probe 去掉了 vec 与 P-store：

| probe | QK bridge | AVG | FirstRun | AIC MAC | AIC FIX | AIC MTE2 | AIC MTE1 | AIC Scalar | cube util |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `cubeonly` | fp32 / single-SPLITN | `127.04 us` | `147.07 us` | `87.8%` | `89.3%` | `75.6%` | `60.3%` | `28.0%` | `98.9%` |
| `cubeonly_hv2` | fp16 dual-SINGLE，scale-in-fix | `138.62 us` | `158.02 us` | `80.5%` | `89.6%` | `69.2%` | `53.1%` | `31.5%` | `98.9%` |
| `cubeonly_hv4` | fp16 dual-SINGLE，downcast-only | `136.95 us` | `155.83 us` | `81.4%` | `89.5%` | `70.1%` | `54.2%` | `31.8%` | `99.0%` |

干净结论：

- 去掉 vec 与 P-store 后，`cubeonly` 回到 `127 us`，与 `qkonly + pvonly` / `phasesplit` 的约 `130 us` 量级一致。
- fp16 dual-SINGLE bridge 在 clean AIC-only 条件下增加约 `9.91-11.58 us`。
- 这与端到端 `v3 -> v6` 中 single-SPLITN 替代 dual-SINGLE 后约 `11.2 us` 的差异一致。

旧 `purecube=208.4 us` 仍有价值，但只能作为“真实交织结构里 P-store/load2d 耦合会把 cube 侧抬高”的结构提醒，不能作为 pure bridge-loss 的定量结论。

### 3.3 hv2 pair64 NZ probe：fp16 softmax + NZ publish 的验证结果

`pfa_fd_hif8_hv2_pair64_nz_probe.py` 测的是一个更具体的问题：是否可以接受 hv2 方案多出来的 `l0c_to_ub`，换取和 BF16 原版类似的两次 bulk `ub_to_l1_nz` 发布。实现上，每个 QK tile 做四次 SINGLE fixpipe 搬运，把 vec0/vec1 看到的 `ub_score` 整理成 `[64,128]`；VF 中用 `idx ^ 64` 完成前后半 gather/max，再 half -> hif8、`deinterleave` 压缩到低半寄存器，最后按 NZ carrier 写 `ub_p` 并用两次 `ub_p.nz()` 发布到 L1。

同一远端、同一同步后的代码和同一 `rows[25:75]` 口径下，每个 pipe 单元格为 `ratio / active-time`：

| 实现 | 平均耗时 | O vs fp32 ref | AIC MAC | AIC FIX | AIC MTE2 | AIC MTE1 | AIC Scalar | AIV VEC | AIV MTE3 | AIV MTE2 | AIV Scalar | cube util |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 当前 v6 rerun | `204.61 us` | `3.479e-3 / 5.112e-4` | `62.8% / 128.33 us` | `93.7% / 191.47 us` | `52.2% / 106.71 us` | `35.0% / 71.44 us` | `39.1% / 79.89 us` | `92.1% / 188.20 us` | `31.0% / 63.30 us` | `0.5% / 1.01 us` | `27.5% / 56.17 us` | `98.03%` |
| hv2 pair64 NZ probe | `207.27 us` | `5.264e-3 / 6.803e-4` | `61.4% / 127.14 us` | `93.9% / 194.25 us` | `50.1% / 103.69 us` | `34.7% / 71.85 us` | `36.4% / 75.32 us` | `72.3% / 149.72 us` | `31.2% / 64.62 us` | `0.5% / 1.03 us` | `23.7% / 48.96 us` | `97.96%` |

读法：

- hv2 pair64 NZ probe 确实把 AIV VEC 压下去了：`92.1% -> 72.3%`，vec active time 少约 `38.5 us`。
- AIC MAC、MTE2、MTE1 与 AIV MTE3 基本没有形成新的收益；AIV scalar 也下降了，但不是主墙。
- 端到端没有赢，因为 hot critical path 仍卡在 AIC FIX；该 probe 的 FIX active time 反而增加约 `2.8 us`，和整体慢 `2.66 us` 基本对齐。
- 因此这个方案证明了“bulk `ub_to_l1_nz` 可以接上”，但也证明了“为此增加四次 SINGLE `l0c_to_ub` 不划算”。后续不能只看 vec 降负，必须同时减少 FIX issue 数。

## 4. 路线比较

| 路线 | 代表实现 | 耗时 | 精度/风险 | 结论 |
|---|---|---:|---|---|
| 官方 BF16 FIA | `torch_npu.npu_fused_infer_attention_score` | `222.28 us` | BF16 高精度 baseline | 正式外部基线 |
| Q/K hif8，P/V BF16 | `pfa_fd_v5_qkhif8.py` | `208.8 us` | `max abs err=9.77e-4` | 稳妥中间路线，已用 NZ P-store |
| arbitrary-tail all-hif8 V9 | `v9_allhif8.py` | `3001.80 us` at s9360 | sampled `max/mean abs err=2.808e-3 / 4.788e-4` | 支持最终逻辑组 `1..384`（含单组）；s9360 当前 A5 正式路线；相对配对 V8 为 `1.210x` |
| 当前 all-hif8 V8 | `v8_allhif8.py` | `139.56 us` | `max/mean abs err=3.418e-3 / 5.141e-4` | 当前 A5 正式路线；与本轮原始 V6 配对为 `1.294x` |
| 历史 all-hif8 V6 | `pfa_fd_v6_allhif8.py` | `204.61 us` | `max/mean abs err=3.479e-3 / 5.112e-4` | 保留为历史 baseline；该行来自早期报告环境 |
| hv2 pair64 NZ 探索 probe | `pfa_fd_hif8_hv2_pair64_nz_probe.py` | `207.27 us` | `max/mean abs err=5.264e-3 / 6.803e-4` | 慢于当前 v6，不扶正 |
| 早期 all-hif8 | v1/v3/v6 early | `250.4 / 251.4 / 240.3 us` | P-store 与 bridge 未解决 | 说明全 hif8 本身不自动赢 |
| fp16 softmax 变体 | v2/v4 | `237.2 / 235.7 us` | `SKV=4099` tail-VF store bug 导致精度崩 | 只证明 pre-NZ all-hif8 下半精度 score export 有潜力，尚不是当前 v6 路线 |
| host metadata v7 | `v7_allhif8.py` | `214.41 us` | compute 与 v6 相同，metadata/FD schedule bubble 更多 | 不作为当前主线 |

读法：

- 如果目标是“马上拿一条稳健性能路线”，Q/K hif8 的 v5 仍然有价值。
- 如果目标是“打官方 BF16 FIA 的时延”，当前 all-hif8 v6 已经做到，但必须明确标注精度路线变化。
- hv2 pair64 NZ probe 虽然仍快过官方 BF16 baseline，但它慢于当前 v6，说明“降低 AIV VEC”本身不是充分条件；FIX issue 增加会直接吃掉收益。
- fp16 softmax 的 v2/v4 归档数据不能直接外推到当前 v6：它们使用不同的 all-hif8/P-store 结构，并且 `SKV=4099` 的 tail-VF store bug 尚未作为正式路线修复。
- 早期 all-hif8 失败不是因为 hif8 没潜力，而是因为 bridge 与 P-store 形式吃掉了收益。

## 5. 设计判断

### 5.1 为什么不是 GM 带宽主导

官方 BF16 FIA 的 AIC MTE2 是 `85.6%`，当前 all-hif8 v6 降到 `52.2%`，但当前 v6 的 FIX 与 VEC 分别达到 `93.7%` 和 `92.1%`。这说明 all-hif8 的关键收益不是单纯“少读 GM”，而是要让片上桥接和 P 发布形式也一起变轻。

如果只是减小 dtype，却引入更多 `l0c_to_ub` issue、更多 vec pack、或更碎的 UB->L1 store，端到端可能不会变快。

### 5.2 FP16 softmax 只能算条件性 lever

fp16 softmax 变体的正面意义，是在早期 all-hif8 结构里证明半精度 score export 能降低 `L0C -> UB` traffic：v2/v4 相对 v1/v3 约快 `5%`，fixpipe ratio 从约 `94%` 降到约 `72%`。这个结论成立的边界很窄：

- v2/v4 在 `SKV=4099` 的精度坏点来自 tail-VF store bug，因此不能作为可交付路线引用；
- 当前 v6 已经换成 nz4/deinterleave P-store，瓶颈结构和早期 V6 不同，旧 `237 us` 结果不能直接预测当前 v6；
- 最新 hv2 pair64 NZ probe 是一次更接近当前 NZ publish 目标的试验，但它慢于当前 v6。

A5 softmax 中关键的 `expsub` 是融合微指令，适合保留 FP32 目的寄存器语义。如果为了全 FP16 vec 把它拆成 `sub + exp + cast/pack`，会增加 AIV VEC 压力。当前更合理的方向是只在不增加 FIX issue、不破坏 NZ P-store 的前提下选择性降低 traffic，而不是全面拆掉融合 micro op。

hv2 pair64 NZ probe 提供了一个反向边界：即使 FP16/hif8 packing 让 AIV VEC 明显下降，只要它以更多 `l0c_to_ub` issue 为代价，端到端仍可能变慢。后续 FP16 化必须同时保持或减少 FIX traffic。

### 5.3 MXFP8 判断只是设计推论

MXFP8 没有在这组 PFA 实验里做真机 A/B，所以它不应作为本报告的实验结论，只能作为后续设计推论。Q/K 是外部输入，MX scale 可以在 host 端预先准备；kernel 内只需要按 MX 物理格式加载 payload 与 scale，并切到 `matmul_mx(...)` / `l1_to_l0_mx` 路线。

P 不同。P 是 kernel 内由 softmax 动态生成的，如果给 P 上 MXFP8，kernel 里还要额外做：

- 每行、每个 K group 的 scale 计算；
- payload 归一化；
- scale byte 物理重排；
- payload 与 scale 一起发布给 PV consume 侧。

这会把已经很热的 vec pipe 再压重。因此对 P 更推荐普通 FP8 / hif8，再配合当前这种 NZ-direct P-store，而不是 MXFP8。这个判断的证据级别低于上面的 v5/v6/probe 真机表，后续若要写成正式结论，需要单独的 MXFP8 P 生成/pack/profile 实验。
