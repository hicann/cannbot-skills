"""matmul + a5/C310 fixpipe scalar quant on store via ``l0c.requant(scale=, offset=)``.

a5 mirror of kernels/a2/matmul/matmul_quant.py: the same three scalar quant modes,
with the mode + 8-bit signedness inferred from the (L0C src, GM dst) dtype pair:

  * fp32  L0C -> int8 / uint8 : QF322B8_PRE   (quantize an fp matmul result)
  * int32 L0C -> int8 / uint8 : REQ8          (requantize an int8 matmul accumulator)
  * int32 L0C -> fp16         : DEQF16         (dequantize back to float)

int8 dst -> signed saturation, uint8 dst -> unsigned. The a5 fixpipe reuses the same
packed deqScalar as a2 (scale float19, offset signed-int9, sign bit); this sample is the
validation that the a2 bit-layout carries over to a5/C310.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_quant.py             # repo simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_quant.py --cannsim    # cannsim (VM only)
"""
from easyasc.a5 import *

# Demo quant params (scale is a float19 on HW, so a half/quarter is represented exactly).
QF_SCALE, QF_OFFSET = 0.5, 8      # QF322B8_PRE : fp32  L0C -> 8-bit
RQ_SCALE, RQ_OFFSET = 0.5, 0      # REQ8        : int32 L0C -> 8-bit
DQ_SCALE = 0.25                   # DEQF16      : int32 L0C -> fp16 (offset unused)
SC_SCALE = 0.5                    # a5-only scaled casts (QF322F16/BF16/F32_PRE, QS322BF16_PRE)


@kernel()
def matmul_quant_fp32_byte(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32 accumulate, quantized to 8-bit on store (QF322B8_PRE)."""
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c.requant(scale=QF_SCALE, offset=QF_OFFSET)
    return z


@kernel()
def matmul_requant_int32_byte(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """int8 @ int8 -> int32 accumulate, requantized to 8-bit on store (REQ8)."""
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l0c = Tensor(DT.int, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c.requant(scale=RQ_SCALE, offset=RQ_OFFSET)
    return z


@kernel()
def matmul_dequant_int32_to_fp16(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """int8 @ int8 -> int32 accumulate, dequantized to fp16 on store (DEQF16)."""
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l0c = Tensor(DT.int, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c.requant(scale=DQ_SCALE)        # offset unused for DEQF16
    return z


# ---- a5-only scalar modes (Group A: scaled casts, no offset) ----
@kernel()
def matmul_scaledcast_fp32(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32 accumulate, scaled-cast on store. The dst dtype picks the mode:
    half -> QF322F16_PRE, bfloat16 -> QF322BF16_PRE, float -> QF322F32_PRE, fp8 e4m3 ->
    QF322FP8_PRE."""
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c.requant(scale=SC_SCALE)
    return z


@kernel()
def matmul_dequant_int32_bf16(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """int8 @ int8 -> int32 accumulate, dequantized to bf16 on store (QS322BF16_PRE)."""
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l0c = Tensor(DT.int, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c.requant(scale=SC_SCALE)
    return z


# ---- a5-only scalar modes (Group B: hif8) ----
# torch has no hifloat8 dtype, so the GM output is a uint8 carrier that the kernel
# reinterprets to hif8 before the fixpipe store. QF322HIF8_PRE rounds nearest-away;
# the _hybrid kernel selects QF322HIF8_PRE_HYBRID via requant(hif8_hybrid=True).
@kernel()
def matmul_quant_fp32_hif8(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32 accumulate, scaled-quantized to hif8 on store (QF322HIF8_PRE)."""
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    zh = z.reinterpret(DT.hif8, name="z_hif8")
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        zh[:, :] <<= l0c.requant(scale=SC_SCALE)
    return z


@kernel()
def matmul_quant_fp32_hif8_hybrid(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32 accumulate, scaled-quantized to hif8 (QF322HIF8_PRE_HYBRID)."""
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    zh = z.reinterpret(DT.hif8, name="z_hif8")
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        zh[:, :] <<= l0c.requant(scale=SC_SCALE, hif8_hybrid=True)
    return z


def _force_single_core():
    """Force block_dim=1 so CANNSIM simulates one AI core (much faster). The DSL
    otherwise hardcodes 32 for 950; validation-only, does not touch the repo."""
    import easyasc.kernelbase.kernelbase as kb
    kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda device_type: 1)


if __name__ == "__main__":
    import os
    import struct
    import sys

    import torch

    # Distinct M/N/K per kernel -> no shape_bindings. N >= 16 and a 32-elem row keeps the
    # 8-bit store aligned; K is a multiple of the operand c0 (half 16 / int8 32).
    QF_M, QF_N, QF_K = 16, 32, 48
    RQ_M, RQ_N, RQ_K = 16, 32, 64

    def _fp19(scale):
        u = struct.unpack("<I", struct.pack("<f", float(scale)))[0] & 0xFFFFE000
        return struct.unpack("<f", struct.pack("<I", u))[0]

    def _quant_8bit(acc, signed, scale, offset):
        r = torch.round(acc.float() * _fp19(scale))            # round half to even
        r = torch.clamp(r, -256.0, 255.0) + float(offset)
        lo, hi, dt = (-128.0, 127.0, torch.int8) if signed else (0.0, 255.0, torch.uint8)
        return torch.clamp(r, lo, hi).to(dt)

    def _dequant_fp16(acc, scale):
        return (acc.float() * _fp19(scale)).to(torch.float16)

    def _scaledcast(acc, scale, dt):
        return (acc.float() * _fp19(scale)).to(dt)

    def _hif8(acc, scale, hybrid):
        from easyasc.dtypehelper.hif8_codec import fp32_to_hif8
        return fp32_to_hif8(acc.float() * _fp19(scale), round_mode=("hybrid" if hybrid else None))

    torch.manual_seed(0)
    # Small integer-valued inputs keep the fp32/int32 accumulate exact, so the quantized
    # bytes are reproducible bit-for-bit against the reference (and sim == cannsim).
    xf = torch.randint(-3, 4, (QF_M, QF_K)).to(torch.float16)
    yf = torch.randint(-3, 4, (QF_N, QF_K)).to(torch.float16)
    acc_f = xf.float() @ yf.float().t()

    xi = torch.randint(-3, 4, (RQ_M, RQ_K), dtype=torch.int8)
    yi = torch.randint(-3, 4, (RQ_N, RQ_K), dtype=torch.int8)
    acc_i = xi.int() @ yi.int().t()

    # slug, kernel, x, y, M, N, K, out_dtype, reference
    cases = (
        ("qf322b8_int8", matmul_quant_fp32_byte, xf, yf, QF_M, QF_N, QF_K, torch.int8,
         _quant_8bit(acc_f, True, QF_SCALE, QF_OFFSET)),
        ("qf322b8_uint8", matmul_quant_fp32_byte, xf, yf, QF_M, QF_N, QF_K, torch.uint8,
         _quant_8bit(acc_f, False, QF_SCALE, QF_OFFSET)),
        ("req8_int8", matmul_requant_int32_byte, xi, yi, RQ_M, RQ_N, RQ_K, torch.int8,
         _quant_8bit(acc_i, True, RQ_SCALE, RQ_OFFSET)),
        ("deqf16", matmul_dequant_int32_to_fp16, xi, yi, RQ_M, RQ_N, RQ_K, torch.float16,
         _dequant_fp16(acc_i, DQ_SCALE)),
        # a5-only scaled casts (Group A)
        ("qf322f16", matmul_scaledcast_fp32, xf, yf, QF_M, QF_N, QF_K, torch.float16,
         _scaledcast(acc_f, SC_SCALE, torch.float16)),
        ("qf322bf16", matmul_scaledcast_fp32, xf, yf, QF_M, QF_N, QF_K, torch.bfloat16,
         _scaledcast(acc_f, SC_SCALE, torch.bfloat16)),
        ("qf322f32", matmul_scaledcast_fp32, xf, yf, QF_M, QF_N, QF_K, torch.float32,
         _scaledcast(acc_f, SC_SCALE, torch.float32)),
        ("qs322bf16", matmul_dequant_int32_bf16, xi, yi, RQ_M, RQ_N, RQ_K, torch.bfloat16,
         _scaledcast(acc_i, SC_SCALE, torch.bfloat16)),
    )
    # a5-only fp8 output (Group B); torch must have float8_e4m3fn to carry it.
    if hasattr(torch, "float8_e4m3fn"):
        cases = cases + (
            ("qf322fp8", matmul_scaledcast_fp32, xf, yf, QF_M, QF_N, QF_K, torch.float8_e4m3fn,
             _scaledcast(acc_f, SC_SCALE, torch.float8_e4m3fn)),
        )
    # a5-only hif8 output (Group B); uint8 carrier, exact bit-for-bit code comparison.
    cases = cases + (
        ("qf322hif8", matmul_quant_fp32_hif8, xf, yf, QF_M, QF_N, QF_K, torch.uint8,
         _hif8(acc_f, SC_SCALE, False)),
        ("qf322hif8_hybrid", matmul_quant_fp32_hif8_hybrid, xf, yf, QF_M, QF_N, QF_K, torch.uint8,
         _hif8(acc_f, SC_SCALE, True)),
    )

    use_cannsim = "--cannsim" in sys.argv[1:]
    wanted = [a for a in sys.argv[1:] if not a.startswith("-")]   # optional slug filter
    base = os.environ.get("QUANT_BASE", "./tmp/a5_quant_cannsim")
    cann = os.environ.get("ASCEND_HOME_PATH") or ""
    if use_cannsim:
        _force_single_core()

    failures = 0
    for slug, kern, xt, yt, M, N, K, odt, ref in cases:
        if wanted and slug not in wanted:
            continue
        z = torch.zeros((M, N), dtype=odt)
        if use_cannsim:
            got = OpExec(kern, simulator=False, cannsim=True, cann_path=cann,
                         custom_op_path=os.path.join(base, slug, "custom_opp"),
                         out_dir=os.path.join(base, slug))(xt, yt, z, M, N, K)
        else:
            got = OpExec(kern, simulator=True)(xt, yt, z, M, N, K)

        float_tols = {torch.float16: 4e-3, torch.bfloat16: 2e-2, torch.float32: 1e-3}
        if hasattr(torch, "float8_e4m3fn"):
            float_tols[torch.float8_e4m3fn] = 7e-2     # e4m3 has 3 mantissa bits
        if odt in float_tols:
            tol = float_tols[odt]
            g, r = got.float(), ref.float()
            ok = torch.allclose(g, r, rtol=tol, atol=tol)
            diff = torch.abs(g - r).max().item()
        else:
            ok = torch.equal(got, ref)
            diff = int(torch.abs(got.int() - ref.int()).max().item())

        failures += 0 if ok else 1
        print("{:<14} [{}] {} max_abs_diff={}".format(
            slug, "cannsim" if use_cannsim else "sim", "PASS" if ok else "FAIL", diff))

    if failures:
        raise SystemExit("{} case(s) FAILED".format(failures))
