"""A whole 4-level MSD radix select inside one vector function.

This is the algorithm the A5 TopK wants instead of sorting every element: the
sort ISA retires about one element per cycle per ladder pass, while a radix pass
costs one register load plus a handful of ALU ops per 64 elements.

The select never leaves the vector unit -- the running prefix and the running
"how many are still needed" both live in registers, so no level round-trips a
scalar through UB.  Each level:

1. bins the level's byte of the monotone ``uint32`` key with ``histograms`` in
   ACCUMULATE mode, which yields the inclusive prefix count directly;
2. picks the boundary bin from that prefix with two register reductions;
3. folds the bin into the prefix and subtracts what it accounted for from the
   remaining count.

After four levels the prefix IS the k-th largest key, so the compaction that
follows is exact: everything strictly greater goes in, and the ties fill the
rest -- and ties are *equal keys*, so which of them is taken does not matter.
That is what makes the candidate buffer exactly ``k`` wide with no data-
dependent bound.

Two details keep it cheap.  Elements outside the current bucket are not masked
out of the histogram; their byte is forced to 0 instead.  That inflates bin 0
only, and the boundary search never reads bin 0's count except as its fallback,
so the answer is unchanged and the b32 -> b8 mask narrowing the masked form
would need is avoided.  And the whole-register reductions land in lane 0, so
every reduced value is broadcast back with a zero-index ``gather`` before it is
used against a full register.

Run:
- simulator (default): python kernels/a5/vec_only/radix_select_probe.py
- on Ascend950 board:   python kernels/a5/vec_only/radix_select_probe.py --run
"""
import builtins
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

GROUP = 64          # fp32/uint32 lanes per register
MAXN = 4096         # elements this probe selects from
MAXK = 512          # candidate slots
LEVELS = ((24, 0x00000000), (16, 0xFF000000),
          (8, 0xFFFF0000), (0, 0xFFFFFF00))


@vf()
def radix_select_vf(keys, cand, cidx, count: Var, k: Var):
    """Select the ``k`` largest of ``count`` float32 keys into ``cand``/``cidx``."""
    fkey = Reg(DT.float, name="rs_fkey")
    ukey = Reg(DT.uint32, name="rs_ukey")
    sbit = Reg(DT.int, name="rs_sbit")
    flip = Reg(DT.uint32, name="rs_flip")
    hi = Reg(DT.uint32, name="rs_hi")
    byte32 = Reg(DT.uint32, name="rs_byte32")
    halfword = Reg(DT.uint16, name="rs_halfword")
    byte = Reg(DT.uint8, name="rs_byte")
    zero32 = Reg(DT.uint32, name="rs_zero32")
    prefix = Reg(DT.uint32, name="rs_prefix")
    bwide = Reg(DT.uint32, name="rs_bwide")
    bidx32 = Reg(DT.uint32, name="rs_bidx32")
    signbit = Reg(DT.uint32, name="rs_signbit")
    bytemask = Reg(DT.uint32, name="rs_bytemask")
    himask = Reg(DT.uint32, name="rs_himask")
    lowmask = Reg(DT.uint32, name="rs_lowmask")
    bidx16 = Reg(DT.uint16, name="rs_bidx16")
    h0 = Reg(DT.uint16, name="rs_h0")
    h1 = Reg(DT.uint16, name="rs_h1")
    total = Reg(DT.uint16, name="rs_total")
    limit = Reg(DT.uint16, name="rs_limit")
    need = Reg(DT.uint16, name="rs_need")
    lane16 = Reg(DT.int16, name="rs_lane16")
    zeros16 = Reg(DT.uint16, name="rs_zeros16")
    big16 = Reg(DT.uint16, name="rs_big16")
    tmp0 = Reg(DT.uint16, name="rs_tmp0")
    tmp1 = Reg(DT.uint16, name="rs_tmp1")
    red0 = Reg(DT.uint16, name="rs_red0")
    red1 = Reg(DT.uint16, name="rs_red1")
    acc16 = Reg(DT.uint16, name="rs_acc16")
    bcount = Reg(DT.uint16, name="rs_bcount")
    inclb = Reg(DT.uint16, name="rs_inclb")
    lo0 = MaskReg(DT.uint16, init_mode=MaskType.NONE, name="rs_lo0")
    lo1 = MaskReg(DT.uint16, init_mode=MaskType.NONE, name="rs_lo1")
    live8 = MaskReg(DT.uint8, init_mode=MaskType.NONE, name="rs_live8")
    keep = MaskReg(DT.uint32, init_mode=MaskType.NONE, name="rs_keep")
    groups = CeilDiv(count, GROUP)
    dup(zero32, 0)
    dup(zeros16, 0)
    dup(bidx32, 0)
    dup(signbit, 0x80000000)
    dup(bytemask, 0xFF)
    dup(lowmask, 0xFFFF)
    dup(bidx16, 0)
    dup(big16, 0xFFFF)
    arange(lane16, 1)
    lanep1 = lane16.reinterpret(DT.uint16, name="rs_lanep1")
    dup(prefix, 0)
    dup(need, Var(k, dtype=DT.uint16, name="rs_k16"))

    # The levels are unrolled at trace time so the byte offset and the
    # high-bit mask are immediates rather than scalar registers.
    for shift, hi_mask in LEVELS:
        dup(h0, 0)
        dup(h1, 0)
        # Level 0 has no high bits: its mask is 0, so the bucket test below is
        # vacuously true and the byte survives.  Emitting it unconditionally
        # keeps the trace free of Python-level branches, which the vf rewriter
        # rejects as compile-time constants.
        dup(himask, hi_mask)
        for grp in range(groups, name="rs_grp_%d" % shift):
            off = Var(grp * GROUP, name="rs_off_%d" % shift)
            lanes = Var(GROUP, dtype=DT.uint32, name="rs_lanes_%d" % shift)
            update_mask(live8, lanes)
            ub_to_reg(fkey, keys[off])
            # float order -> unsigned integer order
            ukey <<= fkey.reinterpret(DT.uint32, name="rs_fbits_%d" % shift)
            sbit <<= fkey.reinterpret(DT.int, name="rs_ibits_%d" % shift)
            shiftrs(sbit, sbit, 31)
            flip <<= sbit.reinterpret(DT.uint32, name="rs_sbitu_%d" % shift)
            vor(flip, flip, signbit)
            vxor(ukey, ukey, flip)
            shiftrs(byte32, ukey, shift)
            vand(byte32, byte32, bytemask)
            # outside the running bucket -> bin 0, which the search ignores
            vand(hi, ukey, himask)
            compare(keep, hi, prefix, CompareMode.EQ)
            select(byte32, byte32, zero32, mask=keep)
            pack(halfword, byte32, HighLowPart.LOWEST)
            pack(byte, halfword, HighLowPart.LOWEST)
            histograms(h0, byte, HistBin.BIN0, HistMode.ACCUMULATE, mask=live8)
            histograms(h1, byte, HistBin.BIN1, HistMode.ACCUMULATE, mask=live8)

        # total = incl[255]: the prefix count never decreases, so its max is
        # its last lane.
        cmax(red1, h1)
        gather(total, red1, bidx16)
        # the largest bin b with #(byte >= b) >= need is popcount(incl <= L)
        sub(limit, total, need)
        compare(lo0, h0, limit, CompareMode.LE)
        compare(lo1, h1, limit, CompareMode.LE)
        # popcount(lo) without a sum-reduce: `incl` never decreases, so the
        # selected lanes are a prefix and the count is the last selected lane
        # index + 1.  A u16 ReduceSum does not exist on dav_c310 (vcadd is
        # u16 -> u32 only), but ReduceMax on u16 does.
        select(tmp0, lanep1, zeros16, mask=lo0)
        select(tmp1, lanep1, zeros16, mask=lo1)
        cmax(red0, tmp0)
        cmax(red1, tmp1)
        # a selected lane in h1 implies all 128 of h0 are selected, so the two
        # window counts simply add.
        add(acc16, red0, red1)
        gather(bcount, acc16, bidx16)
        # incl[b] is the smallest prefix count that is above L
        select(tmp0, big16, h0, mask=lo0)
        select(tmp1, big16, h1, mask=lo1)
        cmin(red0, tmp0)
        cmin(red1, tmp1)
        vmin(acc16, red0, red1)
        gather(inclb, acc16, bidx16)
        # fold the bin into the prefix and drop what it accounted for.
        # The bin count is broadcast across every u16 lane, so a u32 view of
        # the register holds `b | b << 16` in each lane and one AND recovers it
        # -- there is no u16 -> u32 Cast on this part.
        vand(bwide, bcount.reinterpret(DT.uint32, name="rs_bcnt32_%d" % shift),
             lowmask)
        shiftls(bwide, bwide, shift)
        vor(prefix, prefix, bwide)
        sub(tmp0, total, inclb)
        sub(need, need, tmp0)

    # `prefix` is now the k-th largest key; compact around it.
    lane = Reg(DT.int, name="rs_lane")
    idx = Reg(DT.int, name="rs_idx")
    rank = Reg(DT.uint32, name="rs_rank")
    pos = Reg(DT.uint32, name="rs_pos")
    base_gt = Reg(DT.uint32, name="rs_basegt")
    base_eq = Reg(DT.uint32, name="rs_baseeq")
    cnt = Reg(DT.uint32, name="rs_cnt")
    red32 = Reg(DT.uint32, name="rs_red32")
    one32 = Reg(DT.uint32, name="rs_one32")
    needw = Reg(DT.uint32, name="rs_needw")
    gt = MaskReg(DT.uint32, init_mode=MaskType.NONE, name="rs_gt")
    eq = MaskReg(DT.uint32, init_mode=MaskType.NONE, name="rs_eq")
    room = MaskReg(DT.uint32, init_mode=MaskType.NONE, name="rs_room")
    take = MaskReg(DT.uint32, init_mode=MaskType.NONE, name="rs_take")

    dup(one32, 1)
    dup(base_gt, 0)
    # elements strictly above the threshold occupy the first k-need slots
    vand(needw, need.reinterpret(DT.uint32, name="rs_need32"), lowmask)
    sub(base_eq, zero32, needw)
    adds(base_eq, base_eq, k)

    for grp2 in range(groups, name="rs_grp2"):
        off2 = Var(grp2 * GROUP, name="rs_off2")
        ub_to_reg(fkey, keys[off2])
        ukey <<= fkey.reinterpret(DT.uint32, name="rs_fbits2")
        sbit <<= fkey.reinterpret(DT.int, name="rs_ibits2")
        shiftrs(sbit, sbit, 31)
        flip <<= sbit.reinterpret(DT.uint32, name="rs_sbitu2")
        vor(flip, flip, signbit)
        vxor(ukey, ukey, flip)
        arange(lane, 0)
        adds(idx, lane, off2)

        # No predicate: a predicated compare PRESERVES its inactive lanes, so a
        # tail group would inherit the previous group's bits.  The trailing
        # lanes are padded to -inf, whose key is the smallest possible, so an
        # unpredicated compare excludes them anyway.
        compare(gt, ukey, prefix, CompareMode.GT)
        unsqueeze(rank, gt)
        add(pos, rank, base_gt)
        reg_to_ub_scatter(cand, fkey, pos, mask=gt)
        reg_to_ub_scatter(cidx, idx, pos, mask=gt)
        select(cnt, one32, zero32, mask=gt)
        cadd(red32, cnt)
        gather(cnt, red32, bidx32)
        add(base_gt, base_gt, cnt)

        compare(eq, ukey, prefix, CompareMode.EQ)
        unsqueeze(rank, eq)
        add(pos, rank, base_eq)
        compare(room, pos, k, CompareMode.LT)
        mask_and(take, room, eq)
        reg_to_ub_scatter(cand, fkey, pos, mask=take)
        reg_to_ub_scatter(cidx, idx, pos, mask=take)
        select(cnt, one32, zero32, mask=eq)
        cadd(red32, cnt)
        gather(cnt, red32, bidx32)
        add(base_eq, base_eq, cnt)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel(mode="vec")
def radix_kernel(keys: GMTensor, out_val: GMTensor, out_idx: GMTensor,
                 count: Var, k: Var):
    keys_ub = Tensor(DT.float, [1, MAXN], Position.UB, name="rs_keys")
    cand = Tensor(DT.float, [1, MAXK], Position.UB, name="rs_cand")
    cidx = Tensor(DT.int, [1, MAXK], Position.UB, name="rs_cidx")
    with auto_sync():
        keys_ub[:, :] <<= keys[0:1, :]
        radix_select_vf(keys_ub, cand, cidx, count, k)
        out_val[0:1, :] <<= cand
        out_idx[0:1, :] <<= cidx
    return out_val, out_idx


CASES = [
    (1000, 10, "random"),
    (4096, 512, "random"),
    (257, 33, "random"),
    (1000, 10, "narrow"),
    (2048, 64, "ties"),
    (600, 7, "signed"),
]


def make_values(n, k, flavour):
    generator = torch.Generator().manual_seed(n * 31 + k)
    if flavour == "random":
        return torch.randn(n, generator=generator) * 100.0
    if flavour == "narrow":
        return 1.0 + torch.rand(n, generator=generator) * 1e-6
    if flavour == "ties":
        return torch.randint(0, 5, (n,), generator=generator).float()
    return torch.randn(n, generator=generator)


def main(run):
    mode = "board" if run else "sim"
    cfg = dict(simulator=False, debug=False,
               cann_path=os.environ["ASCEND_HOME_PATH"]) if run else dict(simulator=True)
    failures = 0
    for n, k, flavour in CASES:
        values = make_values(n, k, flavour)
        keys = torch.full((1, MAXN), float("-inf"), dtype=torch.float32)
        keys[0, :n] = values
        out_val = torch.zeros(1, MAXK, dtype=torch.float32)
        out_idx = torch.zeros(1, MAXK, dtype=torch.int32)
        try:
            res = OpExec(radix_kernel, out_dir=os.path.abspath("tmp/radixprobe/k"),
                         custom_op_path=os.path.abspath("tmp/radixprobe/opp"),
                         **cfg)(keys.contiguous(), out_val, out_idx, n, k)
            got_v = res[0].reshape(-1)[:k]
            got_i = res[1].reshape(-1)[:k]
        except Exception as error:  # noqa: BLE001
            print("[{}] n={} k={} {} EXC {}: {}".format(
                mode, n, k, flavour, type(error).__name__, str(error)[:300]))
            failures += 1
            continue
        want = torch.topk(values, k=k).values
        # the select is unordered, so compare the sorted multisets
        got_sorted = torch.sort(got_v, descending=True).values
        ok_val = bool(torch.equal(got_sorted, want))
        gathered = values[got_i.to(torch.long).clamp(0, n - 1)]
        ok_idx = bool(torch.equal(gathered, got_v))
        print("[{}] n={:5d} k={:4d} {:7s} values={} indices={}".format(
            mode, n, k, flavour, "ok" if ok_val else "MISMATCH",
            "ok" if ok_idx else "MISMATCH"))
        if not (ok_val and ok_idx):
            failures += 1
            print("      got  head={}".format(got_sorted[:6].tolist()))
            print("      want head={}".format(want[:6].tolist()))
    print("[{}] failures={}".format(mode, failures))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main("--run" in sys.argv[1:]
                  or os.environ.get("EASYASC_RUN_ON_A5") == "1"))
