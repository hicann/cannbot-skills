import builtins
import json
import os
import sys
from typing import Optional, Tuple

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import torch

from easyasc import globvars
from easyasc.a5 import *


# Fixed aligned state-bridge baseline specialized for the C=8 experiment.
BATCH = 2
HEADS = 32
BATCH_HEADS = BATCH * HEADS
CHUNKS = 8
TOKENS = 64
DIM = 128
HALF_TOKENS = TOKENS // 2
HALF_DIM = DIM // 2
FLOAT_REGS_PER_ROW = DIM // 64
SCALAR_COLS = 8
SPLIT_N = 128
TRACE_PATH = os.path.join(REPO_ROOT, "tmp", "delta_h_state_bridge_v1_c8_kernel_trace.json")


def delta_h_true_golden(
    k: torch.Tensor,
    w: torch.Tensor,
    u: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
):
    """
    B: Batch size, H: Num heads, C: Num chunks, L: Chunk size, D: Head dim.
    Assume K = V = D.
    Inputs:
    k.shape: B, H, C, L, D
    w.shape: B, H, C, L, D
    u.shape: B, H, C, L, D
    g.shape: B, H, C, L
    initial_state.shape: B, H, D, D
    """

    B, H, C, L, K = k.shape
    V = u.shape[-1]

    h = k.new_empty(B, H, C, K, V)
    if initial_state is None:
        h_cur = k.new_zeros(B, H, K, V, dtype=torch.float32)
    else:
        h_cur = initial_state.to(torch.float32)

    v_new = u.new_empty(B, H, C, L, V)

    for i_c in builtins.range(C):
        k_chunk = k[:, :, i_c]
        w_chunk = w[:, :, i_c]
        u_chunk = u[:, :, i_c].float()
        h_half = h_cur.to(k.dtype)

        h[:, :, i_c] = h_half
        v_prime = torch.einsum("bntk,bnkv->bntv", w_chunk.float(), h_half.float())
        v_delta = u_chunk - v_prime
        v_new[:, :, i_c] = v_delta.to(u.dtype)

        g_chunk = g[:, :, i_c]
        g_last = g_chunk[:, :, -1]
        factor = torch.exp(g_last.unsqueeze(-1) - g_chunk)
        v_scaled = (v_delta * factor.unsqueeze(-1).to(v_delta.dtype)).to(u.dtype)
        decay = torch.exp(g_last)
        h_cur = h_cur * decay.unsqueeze(-1).unsqueeze(-1)

        delta_h = torch.einsum("bntk,bntv->bnkv", k_chunk.float(), v_scaled.float())
        h_cur = h_cur + delta_h.to(h_cur.dtype)

    final_state = h_cur.to(torch.float32)
    return h, v_new, final_state


@vf()
def cast_state_rows_to_half_vf(
    src_f32: Tensor, dst_f16: Tensor, row_begin: Var, n_loops: Var, half_dim: Var, dim: Var,
):
    reg_f32 = Reg(DT.float)
    src_base = Var(row_begin * dim)
    for i in range(n_loops):
        reg_f32 <<= src_f32[src_base + i * 64]
        dst_f16[i * 64] <<= reg_f32


@vf()
def stage1_postprocess_vf(
    vprime_ub: Tensor, u_ub: Tensor, g_rows_ub: Tensor, g_last_ub: Tensor, v_new_ub: Tensor, v_scaled_ub: Tensor,
    rows_this: Var, dim: Var,
):
    g_last_reg = Reg(DT.float)
    g_row_reg = Reg(DT.float)
    factor_reg = Reg(DT.float)
    u_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    vprime_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    delta_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    scaled_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    g_last_reg <<= g_last_ub[0:1, 0:1].single()
    for r in range(rows_this):
        u_regs <<= u_ub[r:r + 1, 0:DIM]
        vprime_regs <<= vprime_ub[r:r + 1, 0:DIM]
        delta_regs <<= u_regs - vprime_regs
        v_new_ub[r:r + 1, 0:64] <<= delta_regs[0]
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        v_new_ub[r:r + 1, 64:DIM] <<= delta_regs[1]
        vf_barrier(VfPipe.STORE, VfPipe.STORE)

        g_row_reg <<= g_rows_ub[r:r + 1, 0:1].single()
        factor_reg <<= g_last_reg - g_row_reg
        factor_reg <<= factor_reg.exp()
        scaled_regs <<= delta_regs * factor_reg
        v_scaled_ub[r:r + 1, 0:64] <<= scaled_regs[0]
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        v_scaled_ub[r:r + 1, 64:DIM] <<= scaled_regs[1]
        vf_barrier(VfPipe.STORE, VfPipe.STORE)


@vf()
def decay_state_rows_vf(state_rows: Tensor, g_last_ub: Tensor, row_begin: Var, rows_this: Var, dim: Var):
    decay_reg = Reg(DT.float)
    row_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    decay_reg <<= g_last_ub[0:1, 0:1].single()
    decay_reg <<= decay_reg.exp()
    for r in range(rows_this):
        row_idx = Var(row_begin + r)
        row_regs <<= state_rows[row_idx:row_idx + 1, 0:DIM]
        row_regs <<= row_regs * decay_reg
        state_rows[row_idx:row_idx + 1, 0:64] <<= row_regs[0]
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        state_rows[row_idx:row_idx + 1, 64:DIM] <<= row_regs[1]
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)


@vf()
def add_delta_rows_vf(state_rows: Tensor, delta_rows: Tensor, row_begin: Var, rows_this: Var, dim: Var):
    state_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    delta_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    for r in range(rows_this):
        row_idx = Var(row_begin + r)
        state_regs <<= state_rows[row_idx:row_idx + 1, 0:DIM]
        delta_regs <<= delta_rows[r:r + 1, 0:DIM]
        state_regs <<= state_regs + delta_regs
        state_rows[row_idx:row_idx + 1, 0:64] <<= state_regs[0]
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        state_rows[row_idx:row_idx + 1, 64:DIM] <<= state_regs[1]
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)


@kernel()
def delta_h_state_bridge_v1_c8_kernel(
    k: GMTensor, w: GMTensor, u: GMTensor, g: GMTensor, initial_state: GMTensor,
    h_out: GMTensor, v_new_out: GMTensor, final_state_out: GMTensor,
    batch: Var, heads: Var, chunks: Var, tokens: Var, dim: Var, contract: Var,
):
    batch_heads = Var(batch * heads)
    half_tokens = Var(tokens // 2)
    half_dim = Var(dim // 2)

    state_bridge_mutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    stage1_out_mutex = CvMutex(1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    vscaled_bridge_mutex = VcMutex(2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    stage2_out_mutex = CvMutex(3, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    state_load_valid = SEvent(Pipe.MTE2, Pipe.V, name="state_load_valid")

    state_f_ub = Tensor(DT.float, [dim, dim], Position.UB)
    state_h_ub = Tensor(DT.half, [half_dim, dim], Position.UB)
    vprime_ub = Tensor(DT.float, [half_tokens, dim], Position.UB)
    u_ub = Tensor(DT.half, [half_tokens, dim], Position.UB)
    v_new_ub = Tensor(DT.half, [half_tokens, dim], Position.UB)
    v_scaled_ub = Tensor(DT.half, [half_tokens, dim], Position.UB)
    g_rows_ub = Tensor(DT.float, [half_tokens, SCALAR_COLS], Position.UB)
    g_last_ub = Tensor(DT.float, [1, SCALAR_COLS], Position.UB)
    delta_ub = Tensor(DT.float, [half_dim, dim], Position.UB)

    state_h_l1 = Tensor(DT.half, [dim, dim], Position.L1)
    w_l1 = Tensor(DT.half, [tokens, dim], Position.L1)
    k_l1 = Tensor(DT.half, [tokens, dim], Position.L1)
    v_scaled_l1 = Tensor(DT.half, [tokens, dim], Position.L1)

    vprime_l0c = Tensor(DT.float, [tokens, dim], Position.L0C)
    delta_l0c = Tensor(DT.float, [dim, dim], Position.L0C)

    bh_per_core = CeilDiv(batch_heads, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, batch_heads)

    row_begin_d = Var(GetSubBlockIdx() * half_dim)
    row_end_d = Var(row_begin_d + half_dim)
    row_begin_l = Var(GetSubBlockIdx() * half_tokens)
    row_end_l = Var(row_begin_l + half_tokens)
    state_cast_loops = Var(half_dim * dim // 64)

    with auto_sync():
        for bh_idx in range(bh_begin, bh_end):
            b_idx = Var(bh_idx // heads)
            h_idx = Var(bh_idx % heads)
            state_f_ub[row_begin_d:row_end_d, 0:dim] <<= initial_state[b_idx, h_idx, row_begin_d:row_end_d, 0:dim]
            state_load_valid.set()
            state_load_valid.wait()

            for chunk_idx in range(0, chunks):
                state_bridge_mutex.lock()
                cast_state_rows_to_half_vf(
                    state_f_ub,
                    state_h_ub,
                    row_begin_d,
                    state_cast_loops,
                    half_dim,
                    dim,
                )
                state_h_l1[row_begin_d:row_end_d, 0:dim] <<= state_h_ub[0:half_dim, 0:dim]
                state_bridge_mutex.ready()

                h_out[b_idx, h_idx, chunk_idx, row_begin_d:row_end_d, 0:dim] <<= state_h_ub[0:half_dim, 0:dim]
                w_l1[0:tokens, 0:dim] <<= w[b_idx, h_idx, chunk_idx, 0:tokens, 0:dim]
                state_bridge_mutex.wait()
                matmul(vprime_l0c, w_l1, state_h_l1.T, splitn=SPLIT_N)
                state_bridge_mutex.free()

                stage1_out_mutex.lock()
                vprime_ub[0:half_tokens, 0:dim] <<= vprime_l0c
                stage1_out_mutex.ready()

                u_ub[0:half_tokens, 0:dim] <<= u[b_idx, h_idx, chunk_idx, row_begin_l:row_end_l, 0:dim]
                gm_to_ub_pad(
                    g_rows_ub[0:half_tokens, 0:1],
                    g[b_idx, h_idx, chunk_idx, row_begin_l:row_end_l],
                    n_burst=half_tokens,
                    burst_len_element=1,
                    src_stride_element=0,
                )
                g_last_ub[0:1, 0:1] <<= g[b_idx, h_idx, chunk_idx, tokens - 1:tokens]
                stage1_out_mutex.wait()
                stage1_postprocess_vf(vprime_ub, u_ub, g_rows_ub, g_last_ub, v_new_ub, v_scaled_ub, half_tokens, dim)
                stage1_out_mutex.free()

                vscaled_bridge_mutex.lock()
                v_scaled_l1[row_begin_l:row_end_l, 0:dim] <<= v_scaled_ub[0:half_tokens, 0:dim]
                vscaled_bridge_mutex.ready()

                v_new_out[b_idx, h_idx, chunk_idx, row_begin_l:row_end_l, 0:dim] <<= v_new_ub[0:half_tokens, 0:dim]
                decay_state_rows_vf(state_f_ub, g_last_ub, row_begin_d, half_dim, dim)
                k_l1[0:tokens, 0:dim] <<= k[b_idx, h_idx, chunk_idx, 0:tokens, 0:dim]
                vscaled_bridge_mutex.wait()
                matmul(delta_l0c, k_l1.T, v_scaled_l1.T, splitn=SPLIT_N)
                vscaled_bridge_mutex.free()

                stage2_out_mutex.lock()
                delta_ub[0:half_dim, 0:dim] <<= delta_l0c
                stage2_out_mutex.ready()

                stage2_out_mutex.wait()
                add_delta_rows_vf(
                    state_f_ub,
                    delta_ub,
                    row_begin_d,
                    half_dim,
                    dim,
                )
                stage2_out_mutex.free()
            bar_all()
            final_state_out[b_idx, h_idx, row_begin_d:row_end_d, 0:dim] <<= state_f_ub[row_begin_d:row_end_d, 0:dim]
            bar_all()

    return h_out, v_new_out, final_state_out


def _build_inputs() -> Tuple[torch.Tensor, ...]:
    torch.manual_seed(0)

    data_scale = 0.05
    k = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    w = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    u = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    g = torch.log(torch.sigmoid(torch.randn(BATCH, HEADS, CHUNKS, TOKENS, dtype=torch.float32)))
    initial_state = torch.zeros(BATCH, HEADS, DIM, DIM, dtype=torch.float32)
    return k, w, u, g, initial_state


def _trace_final_cycle(trace_path: str) -> float:
    with open(trace_path, "r", encoding="utf-8") as f:
        trace_payload = json.load(f)
    trace_events = trace_payload.get("traceEvents", [])
    timed_events = [event for event in trace_events if event.get("ph") == "X"]
    if not timed_events:
        return 0.0
    return max(float(event.get("ts", 0.0)) + float(event.get("dur", 0.0)) for event in timed_events)


def run_validation(enable_trace: bool = False) -> Tuple[float, float, float, float, str]:
    trace_path = TRACE_PATH
    if enable_trace:
        os.makedirs(os.path.dirname(trace_path), exist_ok=True)

    k, w, u, g, initial_state = _build_inputs()
    h_ref, v_new_ref, final_state_ref = delta_h_true_golden(k, w, u, g, initial_state)

    h_out = torch.empty((BATCH, HEADS, CHUNKS, DIM, DIM), dtype=torch.float16)
    v_new_out = torch.empty((BATCH, HEADS, CHUNKS, TOKENS, DIM), dtype=torch.float16)
    final_state_out = torch.empty((BATCH, HEADS, DIM, DIM), dtype=torch.float32)

    saved_trace_event = getattr(globvars, "trace_event", False)
    globvars.trace_event = False
    try:
        h_kernel, v_new_kernel, final_state_kernel = OpExec(
            delta_h_state_bridge_v1_c8_kernel,
            simulator=True,
            trace=trace_path if enable_trace else None,
        )(
            k, w, u, g, initial_state, h_out, v_new_out, final_state_out,
            BATCH, HEADS, CHUNKS, TOKENS, DIM, -1,
            shape_bindings={
                0: [0, 1, 2, 3, 4],
                1: [0, 1, 2, 3, 4],
                2: [0, 1, 2, 3, 4],
                3: [0, 1, 2, 3],
                4: [0, 1, 4, 4],
                5: [0, 1, 2, 4, 4],
                6: [0, 1, 2, 3, 4],
                7: [0, 1, 4, 4],
            },
        )
    finally:
        globvars.trace_event = saved_trace_event

    torch.testing.assert_close(h_kernel, h_ref, rtol=1e-4, atol=1e-4)
    torch.testing.assert_close(v_new_kernel, v_new_ref, rtol=5e-2, atol=5e-2)
    torch.testing.assert_close(final_state_kernel, final_state_ref, rtol=5e-2, atol=5e-2)

    h_diff = torch.abs(h_kernel - h_ref).max().item()
    v_new_diff = torch.abs(v_new_kernel - v_new_ref).max().item()
    final_state_diff = torch.abs(final_state_kernel - final_state_ref).max().item()
    final_cycle = _trace_final_cycle(trace_path) if enable_trace else 0.0
    return h_diff, v_new_diff, final_state_diff, final_cycle, trace_path


if __name__ == "__main__":
    enable_trace = os.environ.get("DELTA_H_TRACE", "") == "1"
    max_h_diff, max_v_new_diff, max_final_state_diff, final_cycle, trace_path = run_validation(enable_trace=enable_trace)
    print(f"max_h_diff={max_h_diff:.6e}")
    print(f"max_v_new_diff={max_v_new_diff:.6e}")
    print(f"max_final_state_diff={max_final_state_diff:.6e}")
    print(f"final_cycle={final_cycle:.6e}")
    print(f"trace_path={trace_path}")
    print(f"trace_enabled={enable_trace}")
