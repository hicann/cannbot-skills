from easyasc.a5 import *

# Minimal matmul with the GM2L1_DN2NZ transposed load (a5/MTE2 only).
# GM holds A transposed as xt = [K, M]; gm_to_l1_dn2nz loads it as A = [M, K] NZ in L1.
# Three distinct axes (M != K != N) so the transposed-load layout is exercised, not a square.
M = 32
N = 128
K = 64


@kernel()
def matmul_dn2nz_transpose_load_kernel(xt: GMTensor, y: GMTensor, z: GMTensor, m: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= xt.T          # sugar for gm_to_l1_dn2nz(l1x, xt[:, :])
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=m, n=N, k=K, is_init=True)
        z[:, :] <<= l0c
    return z


def _force_single_core():
    """Force block_dim=1 so CANNSIM simulates one AI core (much faster). The DSL
    otherwise hardcodes 32 for 950; validation-only, does not touch the repo."""
    import easyasc.kernelbase.kernelbase as kb
    kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda device_type: 1)


if __name__ == "__main__":
    import os
    import sys

    import torch

    torch.manual_seed(0)
    xt = torch.randn((K, M), dtype=torch.float32)
    y = torch.randn((N, K), dtype=torch.float32)
    z = torch.zeros((M, N), dtype=torch.float32)

    if "--cannsim" in sys.argv[1:]:
        base = os.environ.get("DN2NZ_BASE", "./tmp/a5_dn2nz_cannsim")
        cann = os.environ.get("ASCEND_HOME_PATH") or ""
        _force_single_core()
        z_kernel = OpExec(matmul_dn2nz_transpose_load_kernel, simulator=False, cannsim=True,
                          cann_path=cann, custom_op_path=os.path.join(base, "custom_opp"),
                          out_dir=base)(xt, y, z, M)
    else:
        z_kernel = OpExec(matmul_dn2nz_transpose_load_kernel, simulator=True)(xt, y, z, M)
    z_ref = xt.t() @ y.t()
    torch.testing.assert_close(z_kernel, z_ref, rtol=1e-5, atol=1e-5)
    print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
