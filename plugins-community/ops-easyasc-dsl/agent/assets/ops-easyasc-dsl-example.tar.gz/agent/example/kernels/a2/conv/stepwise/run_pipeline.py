"""Stepwise NCHW conv2d pipeline: 2x transdata in -> conv -> transdata out.

x [B, CIN, H, W] --(k1)--> 5HD --(k3 conv)--> NZ fp32 --(k4)--> y [B, COUT, H/2, W/2]
w [COUT, CIN, 3, 3] --(k2)--> fractal [COUT, K]

Reference: torch conv2d (fp32 math, stride 2, dilation 2, pad 2), cast to fp16.

  PYTHONPATH=<repo> python run_pipeline.py            # python simulator (32x32)
  PYTHONPATH=<repo> python run_pipeline.py --debug    # full 256x256 on a 910B3 box
"""
import torch

from easyasc.a2 import OpExec

from common import (B, C0, C1, C1O, CIN, COUT, DEBUG, DIL, H, HO, HP, HW, K, KH,
                    KW, M, N_CUBE, N_VEC, PAD, STRIDE, W, WO)
from transdata_x_to_5hd import transdata_x_to_5hd
from transdata_w_to_fractal import transdata_w_to_fractal
from conv_compute import conv_compute
from transdata_out_to_nchw import transdata_out_to_nchw


def main():
    torch.manual_seed(11)
    x = torch.randn((B, CIN, H, W), dtype=torch.float16)
    w = torch.randn((COUT, CIN, KH, KW), dtype=torch.float16)

    run = lambda k: OpExec(k, simulator=not DEBUG, debug=DEBUG)

    data = run(transdata_x_to_5hd)(
        x.reshape(B * CIN, HW), torch.zeros((B * C1 * HP * W, C0), dtype=torch.float16), N_VEC)
    wz = run(transdata_w_to_fractal)(
        w.reshape(COUT, CIN * KH * KW), torch.zeros((COUT, K), dtype=torch.float16), N_VEC)
    nz = run(conv_compute)(data, wz, torch.zeros((C1O * M, C0), dtype=torch.float32), N_CUBE)
    y = run(transdata_out_to_nchw)(nz, torch.zeros((COUT, M), dtype=torch.float16), N_VEC)

    y = y.reshape(B, COUT, HO, WO)
    ref = torch.nn.functional.conv2d(x.float(), w.float(), padding=PAD,
                                     stride=STRIDE, dilation=DIL).half()
    assert ref.shape == y.shape, (ref.shape, y.shape)
    torch.testing.assert_close(y.float(), ref.float(), rtol=3e-3, atol=3e-3)
    print("stepwise conv pipeline {}x{}x{}x{} -> {}x{}x{}x{} max_abs_diff={:.6e}".format(
        B, CIN, H, W, B, COUT, HO, WO, float((y.float() - ref.float()).abs().max())))


if __name__ == "__main__":
    main()
