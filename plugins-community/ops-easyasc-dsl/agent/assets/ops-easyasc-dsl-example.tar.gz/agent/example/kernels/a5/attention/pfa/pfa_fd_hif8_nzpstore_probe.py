"""V6 NZ-P-store probes: port v5's "emit softmax P directly in NZ layout + bulk store" to all-hif8 V6.

The baseline V6 diagnostic path writes P into a ROW-MAJOR ub_p[TILE_N, KROW=64]
via `reg_to_ub_pack4`, then stores it with the FRAGMENTED `ub_to_l1_nd2nz` (C++ UB2L1_ND2NZ, blockLen=1 ->
256 bursts of 32B). Board profiling measured the fragmented store at about 88us of V6's cost. v5 dodges it by writing
P straight into an NZ-layout ub_p and doing ONE bulk `ub_to_l1_nz` (blockLen=128). This file ports that to
the all-hif8 kernel (hif8 P, C0=32) in THREE packing techniques, each with the cubeprobe's 3 sub-variants
(full = numerically correct, veconly / vecnostore = profiling-only).

The core transform (replaces the pack/store loop of softmax_t_scale_vf lines 114-116 + the nd2nz store):
  V6's `cast(p_hi[u], preg[u], RegLayout.ZERO)` leaves the 64 valid hif8 P-values SPARSE at register byte
  lanes 0,4,8,...,252 (one hif8 in byte-0 of each 32-bit word). To land them in an NZ ub_p we place, for
  key r and query j, the byte  (j//32)*(129*32) + r*32 + (j%32)  [NZ fractal, M=TILE_N+1=129: a +1 pad row
  per fractal dodges the L1 bank conflict, matching v5's FRAC_STRIDE]. hif8 C0=32.

  ub_p = Tensor(DT.hif8, [TILE_N + 1, ROWS_PER_SB])          # [129, 64], M_src = shape[0] = 129
  store: l1p[..][0:TILE_N, rb:rb+ROWS_PER_SB] <<= ub_p.nz()[0:TILE_N, 0:ROWS_PER_SB]   # bulk ub_to_l1_nz

Three packing approaches (PV_CPROBE=<key>):
  nz1  squeeze(M4) -> reg_to_ub(blk_stride=129, mask=Q).  Squeeze compacts the stride-4 sparse reg to dense
       lanes 0..63; reg_to_ub's _c0_block_indices((j//32)*129*32 + (j%32)) then places each query. No DSL edit.
  nz2  gather(uint8 idx=[0,4,..,252]) -> reg_to_ub(mask=Q).  reg->reg gather compacts the stride-4 reg; same
       strided reg_to_ub as nz1. No DSL edit (gather already accepts hif8 src + uint8 index).
  nz3  squeeze(M4) -> reg_to_ub_scatter(uint16 idx).  Scatter places the 64 dense values directly with a
       per-lane byte index sidx[j] = (j//32)*129*32 + (j%32), masked (mask=Q) to the 64 active lanes so a
       128-lane uint16 index suffices. No DSL edit. (A pure single-op scatter of the raw 256-lane sparse
       reg is INFEASIBLE: byte-granular scatter needs a 256-lane index but only uint8 fits 256 lanes and it
       cannot address the 8KB ub_p; uint16/uint32 word-scatter writes the ZERO-cast padding bytes over
       adjacent NZ queries. So nz3 keeps one compaction and uses scatter only as the placement op.)

Per approach A in {nz1,nz2,nz3}, 3 sub-variants mirror the cubeprobe:
  full_A        full V6 with the 3 swaps (ub_p buffer, softmax VF, bulk store). Numerically correct.
  veconly_A     _veconly_body with the same 3 swaps (AIV-only profiling; garbage values).
  vecnostore_A  _vecnostore_body with only the softmax VF swapped, no store (AIV-only profiling).

Verified on the Python simulator (full_* -> O vs fp32 ref ~5e-3, same as V6's ~5.5e-3, proving the NZ layout).
"""
import builtins
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5pr") == "a5":
    from easyasc.a5 import *
else:
    from easyasc.a5pr import *
from easyasc.simulator.config import SimulatorConfig

from pfa_fd_hif8_probe_common import (
    _CacheBuf,
    init_softmax_state_vf, accum_pv_vf, accum_pv_first_vf, init_accum_vf,
    final_div_cast_bf16_vf, fd_merge_vf, output_cast_vf, _qk_bridge_splitn, _pairwise_split_ok,
    _ref_mqa, _err,
    TILE_M, ROWS_PER_SB, QLANES, TILE_N, D_HEAD, KROW, CACHE, PRELOAD_N, HALF, UNROLL,
    RB_MAX, RB_EXP, SOFTMAX_SCALE, NEG_LARGE,
    MAX_CORE_COUNT, MAX_FD_WS, fp32_to_hif8, hif8_to_fp32,
)

_pyrange = builtins.range

NZ_C0 = 32               # hif8 C0 (32-byte fractal inner dim)
NZ_M = TILE_N + 1        # 129: NZ fractal row stride (M_src), +1 pad row per fractal (bank-conflict dodge)

# ---- nz4 ("deinterleave 4-key") constants ----
SLAB = TILE_N // 4          # 32 keys per slab (4 slabs across TILE_N)
FRAC_STRIDE4 = SLAB + 1     # 33 -- M_src (NZ fractal row stride), +1 pad row/fractal (bank-conflict dodge)
KEYS_PER_GRP = 4            # 4 keys packed per register via the 3-deep deinterleave tree
RB4 = 16                    # rb count for the pack loop (RB4*UNROLL4 = 32 = SLAB M-rows)
UNROLL4 = 2                 # unroll(2), 4 keys/iter, per-iteration regs (real pipelining of the deint chains)
U_TAIL = 4                  # tail inner-loop unroll factor (SLAB % U_TAIL == 0)
_DEINT_U8 = False           # hif8-native deinterleave; flip True if board rejects hif8 (uint8 reinterpret)


def _deint(d0, d1, s0, s1):
    if _DEINT_U8:
        deinterleave(d0.reinterpret(DT.uint8), d1.reinterpret(DT.uint8),
                     s0.reinterpret(DT.uint8), s1.reinterpret(DT.uint8))
    else:
        deinterleave(d0, d1, s0, s1)


# ============================ approach nz1: squeeze(M4) + reg_to_ub(blk_stride=129, mask=Q) ============================
@vf()
def softmax_nz1_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.float, UNROLL); acc = RegList(DT.float, UNROLL); preg = RegList(DT.float, UNROLL)
    p_hi = RegList(DT.hif8, UNROLL); p_hj = RegList(DT.hif8, UNROLL)
    # NZ pack: squeeze the stride-4 sparse hif8 (RegLayout.ZERO) to dense lanes 0..63 (M4), then a strided
    # reg_to_ub (blk_stride=129, mask=Q) lands query j at ub_p byte (j//32)*129*32 + (j%32) [+ base r*32].
    m4 = MaskReg(DT.hif8, init_mode=MaskType.MULTI4)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dpi = Reg(DT.hif8); dpj = Reg(DT.hif8)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_i")
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP, name="ex"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hi[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u + HALF):(rb * UNROLL + u + HALF) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hj[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            squeeze(dpi, p_hi[u], mask=m4)
            reg_to_ub(ub_p[(rb * UNROLL + u) * NZ_C0], dpi, NZ_M, mask=qmask)
            squeeze(dpj, p_hj[u], mask=m4)
            reg_to_ub(ub_p[((rb * UNROLL + u) + HALF) * NZ_C0], dpj, NZ_M, mask=qmask)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_nz1_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor, valid_n: Var):
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float); p_hif8 = Reg(DT.hif8)
    m4 = MaskReg(DT.hif8, init_mode=MaskType.MULTI4)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dp = Reg(DT.hif8)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_tail_i")
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    block_sum <<= 0.0
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        cast(p_hif8, e, cfg_i)
        squeeze(dp, p_hif8, mask=m4)
        reg_to_ub(ub_p[n * NZ_C0], dp, NZ_M, mask=qmask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ============================ approach nz2: reg->reg gather(uint8 idx) + reg_to_ub(mask=Q) ============================
@vf()
def softmax_nz2_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.float, UNROLL); acc = RegList(DT.float, UNROLL); preg = RegList(DT.float, UNROLL)
    p_hi = RegList(DT.hif8, UNROLL); p_hj = RegList(DT.hif8, UNROLL)
    # NZ pack: reg->reg gather with uint8 index [0,4,8,..,252] compacts the stride-4 sparse hif8 to dense
    # lanes 0..63 (dpi[k]=src[4k]); same strided reg_to_ub(blk_stride=129, mask=Q) as nz1 places each query.
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dpi = Reg(DT.hif8); dpj = Reg(DT.hif8)
    g8 = Reg(DT.int8); arange(g8, 0); shiftls(g8, g8, 2)   # [0,4,8,..] mod 256; lanes 0..63 = [0,4,..,252]
    gidx = g8.reinterpret(DT.uint8)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_i")
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP, name="ex"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hi[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u + HALF):(rb * UNROLL + u + HALF) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hj[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            gather(dpi, p_hi[u], gidx)
            reg_to_ub(ub_p[(rb * UNROLL + u) * NZ_C0], dpi, NZ_M, mask=qmask)
            gather(dpj, p_hj[u], gidx)
            reg_to_ub(ub_p[((rb * UNROLL + u) + HALF) * NZ_C0], dpj, NZ_M, mask=qmask)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_nz2_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor, valid_n: Var):
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float); p_hif8 = Reg(DT.hif8)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dp = Reg(DT.hif8)
    g8 = Reg(DT.int8); arange(g8, 0); shiftls(g8, g8, 2)
    gidx = g8.reinterpret(DT.uint8)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_tail_i")
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    block_sum <<= 0.0
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        cast(p_hif8, e, cfg_i)
        gather(dp, p_hif8, gidx)
        reg_to_ub(ub_p[n * NZ_C0], dp, NZ_M, mask=qmask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ============================ approach nz3: squeeze(M4) + reg_to_ub_scatter(uint16 idx) ============================
@func()
def _build_sidx16(sidx16):
    # sidx[j] = (j//32)*129*32 + (j%32) = j + (j//32)*4096  (int16, dense lanes 0..63; 64..127 unused).
    q16 = Reg(DT.int16)
    arange(sidx16, 0)                       # j
    shiftrs(q16, sidx16, 5)                 # j//32
    muls(q16, q16, 4096)                    # (j//32)*4096
    sidx16 <<= sidx16 + q16                 # j + (j//32)*4096


@vf()
def softmax_nz3_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.float, UNROLL); acc = RegList(DT.float, UNROLL); preg = RegList(DT.float, UNROLL)
    p_hi = RegList(DT.hif8, UNROLL); p_hj = RegList(DT.hif8, UNROLL)
    # NZ pack: squeeze the sparse hif8 to dense lanes 0..63, then reg_to_ub_scatter places query j directly
    # at ub_p byte sidx[j] = (j//32)*129*32 + (j%32) [+ base r*32]. mask=Q keeps only 64 active lanes so a
    # 128-lane uint16 index suffices.
    m4 = MaskReg(DT.hif8, init_mode=MaskType.MULTI4)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dpi = Reg(DT.hif8); dpj = Reg(DT.hif8)
    sidx16 = Reg(DT.int16); _build_sidx16(sidx16)
    sidx = sidx16.reinterpret(DT.uint16)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_i")
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP, name="ex"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hi[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u + HALF):(rb * UNROLL + u + HALF) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            cast(p_hj[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            squeeze(dpi, p_hi[u], mask=m4)
            reg_to_ub_scatter(ub_p[(rb * UNROLL + u) * NZ_C0], dpi, sidx, mask=qmask)
            squeeze(dpj, p_hj[u], mask=m4)
            reg_to_ub_scatter(ub_p[((rb * UNROLL + u) + HALF) * NZ_C0], dpj, sidx, mask=qmask)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_nz3_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor, valid_n: Var):
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float); p_hif8 = Reg(DT.hif8)
    m4 = MaskReg(DT.hif8, init_mode=MaskType.MULTI4)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dp = Reg(DT.hif8)
    sidx16 = Reg(DT.int16); _build_sidx16(sidx16)
    sidx = sidx16.reinterpret(DT.uint16)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_tail_i")
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    block_sum <<= 0.0
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        cast(p_hif8, e, cfg_i)
        squeeze(dp, p_hif8, mask=m4)
        reg_to_ub_scatter(ub_p[n * NZ_C0], dp, sidx, mask=qmask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ============================ approach nz4: deinterleave-tree 4-key pack + 4 bulk stores ============================
@vf()
def softmax_nz4_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.float, UNROLL); acc = RegList(DT.float, UNROLL); preg = RegList(DT.float, UNROLL)
    # NZ pack (nz4): pack 4 keys per register with a 3-deep deinterleave tree (fin = [k0|k1|k2|k3] dense,
    # 256 lanes = 8 fractals) + one strided reg_to_ub (blk_stride=33). Key kk lands in fractals 2kk,2kk+1
    # at M-row m; store is 4 bulk UB2L1_NZ transfers (one slab of 32 keys each).
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_i")
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    # exp + nz4 pack: 4 keys (m, m+32, m+64, m+96) -> deinterleave tree -> fin -> one reg_to_ub
    # reuse acc[] (free after block_max) as the 4 per-slab running sums — no separate sacc RegList (register
    # economy: the full-kernel aiv inlines this VF with accum_pv/fd_merge and the deinterleave chain is heavy).
    for kk in _pyrange(KEYS_PER_GRP):
        acc[kk] <<= 0.0
    # shared deint temps: per-iteration regs + higher unroll were board-tested and gave NO speedup — the
    # deint pack is throughput-bound (the deinterleaves themselves), not latency-bound, so shared/unroll2 is best.
    hh = RegList(DT.hif8, KEYS_PER_GRP)             # 4 cast'd keys (stride-4 sparse, RegLayout.ZERO)
    a = Reg(DT.hif8); b = Reg(DT.hif8); fin = Reg(DT.hif8); dmy = Reg(DT.hif8)
    for rb in range(RB4, name="ex"):
        for u in unroll(UNROLL4):
            for kk in _pyrange(KEYS_PER_GRP):
                row = (rb * UNROLL4 + u) + kk * SLAB          # key m + kk*32
                sreg[0] <<= ub_score[row:row + 1, :]
                muls(sreg[0], sreg[0], SOFTMAX_SCALE)
                expsub(preg[0], sreg[0], v_nmax)
                acc[kk] <<= acc[kk] + preg[0]
                cast(hh[kk], preg[0], cfg_i)
            _deint(a,   dmy, hh[0], hh[1])
            _deint(b,   dmy, hh[2], hh[3])
            _deint(fin, dmy, a,     b)
            reg_to_ub(ub_p[(rb * UNROLL4 + u) * NZ_C0], fin, FRAC_STRIDE4)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_nz4_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor, valid_n: Var):
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float); p_hif8 = Reg(DT.hif8)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dp = Reg(DT.hif8)
    g8 = Reg(DT.int8); arange(g8, 0); shiftls(g8, g8, 2)
    gidx = g8.reinterpret(DT.uint8)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_tail_i")
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    block_sum <<= 0.0
    # nested DSL loops (g=slab, m=row) keep this LOOPED, not 128x-unrolled, AND compute the slab base with
    # multiplies only (n = g*SLAB+m, base = g*2112 + m*32) so there is no var_div. A _pyrange here fully
    # unrolled the 128 keys -> 1334-line VF -> the full-kernel aiv spilled 102 vector slots (26KB > 6KB).
    _SLAB_STRIDE = 2 * FRAC_STRIDE4 * NZ_C0          # 2112 = 2 fractals * 33 * 32
    for g in range(KEYS_PER_GRP, name="tg"):
        for m in range(SLAB, name="tm"):
            n = g * SLAB + m
            cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
            s <<= ub_score[n:n + 1, :]
            s <<= s * SOFTMAX_SCALE
            update_mask(rowmask, cnt_n)
            select(s, s, neg, mask=rowmask)
            expsub(e, s, v_nmax)
            block_sum <<= block_sum + e
            cast(p_hif8, e, cfg_i)
            gather(dp, p_hif8, gidx)
            reg_to_ub(ub_p[g * _SLAB_STRIDE + m * NZ_C0], dp, FRAC_STRIDE4, mask=qmask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ============================ full-V6 shared allocation (NZ ub_p; no control flow) ============================
def _alloc_nz(q, k, v):
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")
    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N + 1, ROWS_PER_SB], Position.UB)   # [129,64] NZ, M_src=shape[0]=129
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)
    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_sum")
    return (q_hif8, k_hif8, v_hif8, l1q, l1k, l1v, l1p, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p,
            ub_old_weight, ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out, fd_accum, fd_max, fd_sum)


# ---- full V6 with NZ P-store (softmax VFs passed as @func params: trace-time data, not a constant `if`) ----
@func()
def _full_nz_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, p_mutex, softmax_fn, softmax_tail_fn):
    (q_hif8, k_hif8, v_hif8, l1q, l1k, l1v, l1p, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p, ub_old_weight,
     ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out, fd_accum, fd_max, fd_sum) = _alloc_nz(q, k, v)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_tail_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                    ub_old_weight[step], valid_n)
                else:
                    softmax_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                               ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB] <<= ub_p.nz()[0:TILE_N, 0:ROWS_PER_SB]
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                sm2 = Var(lag_mt % CACHE)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_local_mt = Var(lag_mt % tiles_m_per_b)
                lag_q_base = Var(lag_batch * MQ)
                lag_kv_base = Var(lag_batch * N)
                lag_m0 = Var(lag_local_mt * TILE_M)
                lag_valid_m = Min(TILE_M, MQ - lag_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_kt == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                elif lag == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:
                    accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                fd_merge_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                            ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


# ---- veconly with NZ P-store (AIV-only; garbage values, profiling-only) ----
@func()
def _veconly_nz_body(q, k, v, out, B, MQ, N, D, softmax_fn):
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N + 1, ROWS_PER_SB], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB] <<= ub_p.nz()[0:TILE_N, 0:ROWS_PER_SB]

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_cast_bf16_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


# ---- vecnostore with NZ softmax VF but NO store (AIV-only; profiling-only) ----
@func()
def _vecnostore_nz_body(q, k, v, out, B, MQ, N, D, softmax_fn):
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N + 1, ROWS_PER_SB], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_cast_bf16_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


# =========================== nz4 bodies (ub_p [33,256]; 4 bulk stores) ===========================
def _alloc_nz4(q, k, v):
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")
    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [FRAC_STRIDE4, KEYS_PER_GRP * ROWS_PER_SB], Position.UB)   # [33,256] NZ, M_src=33
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)
    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_sum")
    return (q_hif8, k_hif8, v_hif8, l1q, l1k, l1v, l1p, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p,
            ub_old_weight, ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out, fd_accum, fd_max, fd_sum)


@func()
def _full_nz4_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, p_mutex, softmax_fn, softmax_tail_fn):
    (q_hif8, k_hif8, v_hif8, l1q, l1k, l1v, l1p, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p, ub_old_weight,
     ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out, fd_accum, fd_max, fd_sum) = _alloc_nz4(q, k, v)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_tail_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                    ub_old_weight[step], valid_n)
                else:
                    softmax_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                               ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                for g in _pyrange(KEYS_PER_GRP):
                    l1p[step][g * SLAB:(g + 1) * SLAB, row_begin:row_begin + ROWS_PER_SB] <<= (
                        ub_p.nz()[0:SLAB, g * ROWS_PER_SB:(g + 1) * ROWS_PER_SB]
                    )
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                sm2 = Var(lag_mt % CACHE)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_local_mt = Var(lag_mt % tiles_m_per_b)
                lag_q_base = Var(lag_batch * MQ)
                lag_kv_base = Var(lag_batch * N)
                lag_m0 = Var(lag_local_mt * TILE_M)
                lag_valid_m = Min(TILE_M, MQ - lag_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_kt == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                elif lag == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:
                    accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                fd_merge_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                            ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


@func()
def _veconly_nz4_body(q, k, v, out, B, MQ, N, D, softmax_fn):
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [FRAC_STRIDE4, KEYS_PER_GRP * ROWS_PER_SB], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            for g in _pyrange(KEYS_PER_GRP):
                l1p[step][g * SLAB:(g + 1) * SLAB, row_begin:row_begin + ROWS_PER_SB] <<= (
                    ub_p.nz()[0:SLAB, g * ROWS_PER_SB:(g + 1) * ROWS_PER_SB]
                )

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_cast_bf16_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


@func()
def _vecnostore_nz4_body(q, k, v, out, B, MQ, N, D, softmax_fn):
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [FRAC_STRIDE4, KEYS_PER_GRP * ROWS_PER_SB], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_cast_bf16_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


# =========================== mutex helpers (mirror the cubeprobe's normal mutexes) ===========================
def _cv_normal():
    return CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                   src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)


def _pv_normal():
    return CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)


def _p_normal():
    return VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)


# =========================== 9 kernels (3 approaches x 3 sub-variants) ===========================
@kernel()
def nzp_full_nz1_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _full_nz_body(q, k, v, out, B, MQ, N, D, _cv_normal(), _pv_normal(), _p_normal(),
                         softmax_nz1_vf, softmax_nz1_tail_vf)


@kernel()
def nzp_veconly_nz1_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_nz_body(q, k, v, out, B, MQ, N, D, softmax_nz1_vf)


@kernel()
def nzp_vecnostore_nz1_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_nz_body(q, k, v, out, B, MQ, N, D, softmax_nz1_vf)


@kernel()
def nzp_full_nz2_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _full_nz_body(q, k, v, out, B, MQ, N, D, _cv_normal(), _pv_normal(), _p_normal(),
                         softmax_nz2_vf, softmax_nz2_tail_vf)


@kernel()
def nzp_veconly_nz2_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_nz_body(q, k, v, out, B, MQ, N, D, softmax_nz2_vf)


@kernel()
def nzp_vecnostore_nz2_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_nz_body(q, k, v, out, B, MQ, N, D, softmax_nz2_vf)


@kernel()
def nzp_full_nz3_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _full_nz_body(q, k, v, out, B, MQ, N, D, _cv_normal(), _pv_normal(), _p_normal(),
                         softmax_nz3_vf, softmax_nz3_tail_vf)


@kernel()
def nzp_veconly_nz3_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_nz_body(q, k, v, out, B, MQ, N, D, softmax_nz3_vf)


@kernel()
def nzp_vecnostore_nz3_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_nz_body(q, k, v, out, B, MQ, N, D, softmax_nz3_vf)


@kernel()
def nzp_full_nz4_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _full_nz4_body(q, k, v, out, B, MQ, N, D, _cv_normal(), _pv_normal(), _p_normal(),
                          softmax_nz4_vf, softmax_nz4_tail_vf)


@kernel()
def nzp_veconly_nz4_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_nz4_body(q, k, v, out, B, MQ, N, D, softmax_nz4_vf)


@kernel()
def nzp_vecnostore_nz4_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_nz4_body(q, k, v, out, B, MQ, N, D, softmax_nz4_vf)


_PROBES = {
    "full_nz1": nzp_full_nz1_kernel, "veconly_nz1": nzp_veconly_nz1_kernel, "vecnostore_nz1": nzp_vecnostore_nz1_kernel,
    "full_nz2": nzp_full_nz2_kernel, "veconly_nz2": nzp_veconly_nz2_kernel, "vecnostore_nz2": nzp_vecnostore_nz2_kernel,
    "full_nz3": nzp_full_nz3_kernel, "veconly_nz3": nzp_veconly_nz3_kernel, "vecnostore_nz3": nzp_vecnostore_nz3_kernel,
    "full_nz4": nzp_full_nz4_kernel, "veconly_nz4": nzp_veconly_nz4_kernel, "vecnostore_nz4": nzp_vecnostore_nz4_kernel,
}
_CORRECT = {"full_nz1", "full_nz2", "full_nz3", "full_nz4"}


def main():
    probe = os.environ.get("PV_CPROBE", "full_nz1")
    kern = _PROBES[probe]
    torch.manual_seed(0)
    B = int(os.environ.get("PV_B", "1"))
    HQ = int(os.environ.get("PV_HQ", "8"))
    SQ = int(os.environ.get("PV_SQ", "257"))
    SKV = int(os.environ.get("PV_SKV", "256"))
    MQ = HQ * SQ
    q_fp32 = torch.randn((B * MQ, D_HEAD), dtype=torch.float32)
    k_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    v_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    q = fp32_to_hif8(q_fp32); k = fp32_to_hif8(k_fp32); v = fp32_to_hif8(v_fp32)
    out = torch.zeros((B * MQ, D_HEAD), dtype=torch.bfloat16)

    tiles_m_per_b = (MQ + TILE_M - 1) // TILE_M
    k_tiles = (SKV + TILE_N - 1) // TILE_N
    total_blocks = B * tiles_m_per_b

    mode = os.environ.get("PV_MODE", "sim")
    sim_cores = int(os.environ.get("PV_SIM_CORES", "4"))
    launch_cores = sim_cores if mode == "sim" else MAX_CORE_COUNT
    profile = os.environ.get("PV_PROFILE", "0") == "1"
    ok, max_owners, split_blocks = _pairwise_split_ok(total_blocks, k_tiles, launch_cores)
    if not ok and probe in _CORRECT:
        raise SystemExit("pairwise split precondition failed: max_owners={}".format(max_owners))

    kern._simulator_config = SimulatorConfig(core_count=sim_cores, execution_timeout_s=3600.0)
    d = os.environ.get("PV_OUT_DIR") or "./tmp/pfa_fd_nzpstore_{}_{}".format(probe, mode)
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, out, B, MQ, SKV, D_HEAD)
    sb = {0: [1 if B == 1 else None, 3], 1: [2 if B == 1 else None, 3],
          2: [2 if B == 1 else None, 3], 3: [1 if B == 1 else None, 3]}

    print("NZP-PROBE[{}]: B={} HQ={} SQ={} SKV={} blocks={} k_tiles={} cores={} split={}".format(
        probe, B, HQ, SQ, SKV, total_blocks, k_tiles, launch_cores, split_blocks))
    if mode == "sim":
        outs = OpExec(kern, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, cannsim=True)(*args, shape_bindings=sb)
    elif mode == "hw":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")

    O = torch.as_tensor(outs).float()
    qf = hif8_to_fp32(q); kf = hif8_to_fp32(k); vf = hif8_to_fp32(v)
    o_ref = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV)
    tag = "CORRECT" if probe in _CORRECT else "profiling-only (output not meaningful)"
    print("|O| max={:.3f}  [{}]".format(O.abs().max().item(), tag))
    print("O vs fp32 ref:     max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref.to(torch.bfloat16).float())))


if __name__ == "__main__":
    main()
