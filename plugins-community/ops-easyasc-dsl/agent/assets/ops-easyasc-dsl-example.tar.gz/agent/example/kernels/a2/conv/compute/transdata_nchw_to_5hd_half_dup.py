"""transdata NCHW -> NC1HWC0 (vnchwconv) -- dup-zeroed channel tail variant.

Same op as transdata_nchw_to_5hd_half but the channel tail is zeroed on-chip
with dup instead of GM-side grid padding, so x stays the plain [B*C, pad_hw]
plane. autosync does not order the V-dup -> MTE2-load WAW, so an explicit
SEvent ready/valid pair serializes the pair per chunk (depth-1):
  V:    valid.wait(); dup(0); ready.set()
  MTE2: ready.wait(); load valid rows; valid.set()
The downstream transdata5hd read is autosync RAW as usual.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python transdata_nchw_to_5hd_half_dup.py          # sim
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python transdata_nchw_to_5hd_half_dup.py --debug  # 910B3
"""
import sys

from easyasc.a2 import *

C0 = 16
DEBUG = "--debug" in sys.argv[1:]
CHUNK = 1024
NLANES = 40 if DEBUG else 2


@kernel()
def transdata_nchw_to_5hd_half_dup(x: GMTensor, y: GMTensor,
                                   b: Var, c: Var, hw: Var, pad_hw: Var):
    src_buf = Tensor(DT.half, [16, CHUNK], Position.UB)
    dst_buf = Tensor(DT.half, [CHUNK, C0], Position.UB)
    dup_ready = SEvent(Pipe.V, Pipe.MTE2, name="t5_dup_ready")
    load_valid = SEvent(Pipe.MTE2, Pipe.V, preset=True, name="t5_load_valid")
    c1n = CeilDiv(c, C0)
    chunks = CeilDiv(pad_hw, CHUNK)
    vec_idx = GetVecIdx()
    with auto_sync():
        for blk in range(b * c1n):
            with If(blk % NLANES == vec_idx):
                bb = Var(blk // c1n)
                c1 = Var(blk % c1n)
                cvalid = Min(c - c1 * C0, C0)
                base = (bb * c + c1 * C0) * pad_hw
                out0 = (bb * c1n + c1) * hw
                for ck in range(chunks):
                    s = Var(ck * CHUNK)
                    span = Min(pad_hw - s, CHUNK)
                    load_valid.wait()
                    dup(src_buf, 0.0)
                    dup_ready.set()
                    dup_ready.wait()
                    gm_to_ub_pad(src_buf, x[base + s:base + s + 1, :],
                                 n_burst=cvalid, burst_len_element=span,
                                 src_stride_element=pad_hw - span,
                                 dst_stride=(CHUNK - span) // C0)
                    load_valid.set()
                    transdata5hd(dst_buf, src_buf, repeat=CHUNK // C0,
                                 src_row_stride=CHUNK, dst_row_stride=C0,
                                 src_rep_stride=1, dst_rep_stride=C0)
                    store = Min(hw - s, CHUNK)
                    with If(store > 0):
                        ub_to_gm_pad(y[out0 + s:out0 + s + 1, :], dst_buf,
                                     n_burst=1, burst_len_element=store * C0,
                                     src_stride=0, dst_stride_element=0)
    return y


if __name__ == "__main__":
    import torch

    torch.manual_seed(5)
    B, C, H, W = (2, 20, 56, 56) if DEBUG else (2, 20, 6, 6)
    HW = H * W
    PAD_HW = (HW + 15) // 16 * 16
    C1 = (C + C0 - 1) // C0
    x = torch.randn((B, C, H, W), dtype=torch.float16)
    data = torch.zeros((B * C, PAD_HW), dtype=torch.float16)        # hw pad only
    data[:, :HW] = x.reshape(B * C, HW)
    data = data.reshape(B * C * PAD_HW, 1).contiguous()
    y = torch.zeros((B * C1 * HW, C0), dtype=torch.float16)
    ref = torch.from_numpy(pack_nc1hwc0(x.numpy()))
    got = OpExec(transdata_nchw_to_5hd_half_dup, simulator=not DEBUG, debug=DEBUG)(
        data, y, B, C, HW, PAD_HW)
    assert torch.equal(got, ref), float((got.float() - ref.float()).abs().max())
    print("transdata_nchw_to_5hd_half_dup {}x{}x{}x{} exact".format(B, C, H, W))
