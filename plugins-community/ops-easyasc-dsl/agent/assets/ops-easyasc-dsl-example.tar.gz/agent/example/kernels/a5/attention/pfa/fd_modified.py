"""FIA-faithful GQA prefill with hif8 Q/K — Design A Step 2 (stream-K + Flash-Decode).

Builds on Step 1 (fia_gqa_bf16_designA.py): same FIA-equivalent compute (two-weight
online softmax, lag-2 dispatch/execute, FORWARD-only L1-P ring, bf16-P NZ bridge),
but replaces the Q-owned schedule with FIA's **stream-K + Flash-Decode** schedule
(flow note sections 17/18/23/24):

Q and K are supplied as uint8 carriers containing HiFloat8 (hif8) values and are
reinterpreted to DT.hif8 inside the kernel for the QK^T matmul. V, P, softmax state,
Flash-Decode workspace, and output remain on the original bf16/fp32 path.

P0 (this version):
  * GS1 contiguous M-axis. Locked shape B=1/Hq=8/Hk=1/S=4099/D=128, Hk=1 ⇒ all Hq
    heads share the single KV head, so M = Hq*S1 is one contiguous row axis, K/V are
    [S2, D], out is [M, D] in GS1 (= head*S1 + s1) order. NO per-row head decode.
  * Stream-K: each AIC core owns a contiguous interval [flat_start, flat_end) of the
    flat (m_block-major, s2_tile-inner) task grid. A single m-block's s2 range may be
    split across 2 cores. The (m, s2) of flat index t is m=t//tiles_n, s2=t%tiles_n,
    so the partial first/last blocks fall out automatically.
  * Flash-Decode: the 2 cores owning a split m-block write fp32 partial (unnormalized
    O, row-max, row-sum) to GM workspace instead of finalize+store. After the whole FA
    loop, an AIV-wide barrier (allvec_ready/allvec_wait = official SyncAll), then 2 AIV
    "merge" jobs per split block recombine the partials (max-aware log-sum-exp) → out.
  * Metadata is host-precomputed (build_metadata) and passed as int32 GM tensors; the
    kernel reads per-core / per-lane fields via Var.GetValueFrom (ace_v13 pattern). Two
    configs: a tiny hand-crafted dev split (fast iteration) and the exact section-17
    28-core FIA table (final 4099 run). build_metadata's __main__ self-test reproduces
    section-17's FD_M_IDX + first_fd_ws exactly.

P1 (next): const-trip unroll(4) softmax + fuse divide into last Vec2 (see Step 1 notes).

# --- run ---
#   # metadata self-test
#   PV_SELFTEST=1 PYTHONPATH=. python kernels/a5/attention/pfa/fd_modified.py
#   # dev sim (small shape, fast iteration)
#   PYTHONPATH=. python kernels/a5/attention/pfa/fd_modified.py
#   # fia sim
#   PV_META=fia PYTHONPATH=. python kernels/a5/attention/pfa/fd_modified.py
#   # fia sim with trace
#   PV_META=fia PV_TRACE=1 PYTHONPATH=. python kernels/a5/attention/pfa/fd_modified.py
#   # fia hw (on 950 board)
#   PV_MODE=hw PV_META=fia PYTHONPATH=. python kernels/a5/attention/pfa/fd_modified.py
#   # fia cannsim
#   PV_MODE=cannsim PV_META=fia PYTHONPATH=. python kernels/a5/attention/pfa/fd_modified.py
#   PYTHONPATH=. python kernels/a5/attention/fia_gqa_bf16_designA_step2.py --meta dev --cores 3
#   PYTHONPATH=. python kernels/a5/attention/fia_gqa_bf16_designA_step2.py --meta fia --cores 28 --trace
"""
import builtins
import math

import torch

from easyasc.a5 import *

py_range = builtins.range

TILE_M = 128
TILE_N = 128
D_HEAD = 128
ROWS_SB = TILE_M // 2     # 64 vec sub-block rows
CD = D_HEAD // 64         # 2 fp32 regs cover a 128-col D row
C0 = 16                   # bf16 NZ C0 block
UNROLL_F = 4             # P1 const-trip softmax unroll (ROWS_SB//UNROLL_F runtime iters x unroll(UNROLL_F))

PRELOAD_N = 2             # FIA lag-2
CACHE = PRELOAD_N + 1     # 3-deep task cache

IO_DT = DT.bfloat16
TORCH_IO = torch.bfloat16
TORCH_QK = torch.uint8
NEG_LARGE = -1.0e30

# --- transposed-softmax constants (score^T = K@Q^T -> [key, query]; lane-wise vmax) ---
QLANES = ROWS_SB              # 64 query lanes per fp32 reg (query is the LANE axis after transpose)
HALF = TILE_N // 2            # 64: 2-key pack (key i paired with i+64 -> one 128-lane bf16 reg)
FRAC_STRIDE = HALF + 1        # 65: ub_p [65,128] padded NZ stride (odd -> dodges UB 2^k bank conflict)
RB_MAX = TILE_N // UNROLL_F   # 32: max-pass over 128 keys (4-way unrolled partial-max chains)
RB_EXP = HALF // UNROLL_F     # 16: exp-pass over 64 key-pairs (i, i+64)
SOFTMAX_SCALE = 1.0 / math.sqrt(D_HEAD)

# Metadata field layouts (1-D int32 GM tensors).
FA_NF = 6     # [enable, flat_start, flat_end, tail_ws, head_ws, pad]
FD_NF = 6     # [enable, m_idx, ws_lo, ws_hi, row0, nrows]

# Workspace slot count (= 2 * num_fd_tasks). Set by run_case before tracing.
NWS_GLOBAL = 1


# ============================ host metadata generator ============================
# Section-17 exact 28-core FIA split (m-block-major, s2-inner), for tiles_n = 33.
FA_START_M = [0, 9, 18, 27, 36, 45, 54, 64, 73, 82, 91, 100, 109, 119, 128, 137, 146,
              155, 164, 173, 183, 192, 201, 210, 219, 228, 238, 247]
FA_START_N = [0, 5, 10, 15, 20, 25, 30, 2, 7, 12, 17, 22, 27, 0, 5, 10, 15, 21, 26, 32,
              5, 10, 15, 21, 26, 32, 5, 10]
FA_END_M = [9, 18, 27, 36, 45, 54, 64, 73, 82, 91, 100, 109, 119, 128, 137, 146, 155,
            164, 173, 183, 192, 201, 210, 219, 228, 238, 247, 257]
FA_END_N = [5, 10, 15, 20, 25, 30, 2, 7, 12, 17, 22, 27, 0, 5, 10, 15, 21, 26, 32, 5,
            10, 15, 21, 26, 32, 5, 10, 0]
# section-17 reference for the self-test (derived, not consumed by the kernel):
SEC17_FD_M_IDX = [9, 18, 27, 36, 45, 54, 64, 73, 82, 91, 100, 109, 128, 137, 146, 155,
                  164, 173, 183, 192, 201, 210, 219, 228, 238, 247]
SEC17_FIRST_FD_WS = [0, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 24, 25, 27, 29, 31,
                     33, 35, 37, 39, 41, 43, 45, 47, 49, 51]
FIA_TILES_M = 257
FIA_TILES_N = 33


def fia_intervals(tiles_n):
    """Section-17 per-core flat [start, end) intervals (m-major, s2-inner)."""
    n = len(FA_START_M)
    out = []
    for c in py_range(n):
        fs = FA_START_M[c] * tiles_n + FA_START_N[c]
        if c < n - 1:
            fe = FA_END_M[c] * tiles_n + FA_END_N[c]
        else:
            fe = FIA_TILES_M * tiles_n          # last core ends at the very end (bn2=1)
        out.append((fs, fe))
    return out


def even_intervals(total, num_cores):
    """Generic contiguous near-even flat split (fallback; may land on block edges)."""
    base = total // num_cores
    rem = total % num_cores
    out = []
    cur = 0
    for c in py_range(num_cores):
        cnt = base + (1 if c < rem else 0)
        out.append((cur, cur + cnt))
        cur += cnt
    return out


def staggered_intervals(total, num_cores, tiles_n):
    """Dev split that deliberately nudges interior boundaries OFF block edges so at least
    some m-blocks are s2-split across cores (exercises the Flash-Decode merge path)."""
    bounds = [0]
    for c in py_range(1, num_cores):
        b = total * c // num_cores
        if 0 < b < total and b % tiles_n == 0:        # on a block edge -> nudge to force a split
            b += 1
        bounds.append(b)
    bounds.append(total)
    return [(bounds[i], bounds[i + 1]) for i in py_range(num_cores)]


def even_mblock_intervals(tiles_m, tiles_n, num_cores):
    """Whole-m-block even split: each core owns WHOLE m-blocks (interval aligned to m-block edges,
    flat_start % tiles_n == 0) -> NO s2-split -> NO Flash-Decode needed. The extra m-blocks (rem) go
    to the LAST cores, so for our shape (256 full m-blocks + 1 tiny 24-row M-tail block last) the
    near-even 8/core split lands the cheap tail on the last core (~2.5% imbalance, no FD)."""
    base = tiles_m // num_cores
    rem = tiles_m % num_cores
    out = []
    cur = 0
    for c in py_range(num_cores):
        cnt = base + (1 if c >= num_cores - rem else 0)
        out.append((cur * tiles_n, (cur + cnt) * tiles_n))
        cur += cnt
    return out


def build_metadata(tiles_m, tiles_n, intervals, M, launch_cores=None):
    """Turn per-core flat intervals into (fa_meta, fd_meta, nws, fd_blocks).

    A block mb is *split* iff some core starts strictly inside it (flat_start % tiles_n
    != 0). FD tasks are the sorted split blocks; task j uses workspace slots 2j (head /
    lower-s2 piece, written by the core whose range ENDS at mb) and 2j+1 (tail / upper-s2
    piece, written by the core whose range STARTS at mb). The merge is symmetric in the
    two pieces, so head/tail order does not affect correctness.

    launch_cores: the number of AIC cores the board actually launches (= GetCubeNum;
    hardcoded 32 for the 950 in kernelbase). The work split (`intervals`) may use FEWER
    cores than launch_cores (e.g. FIA's section-17 28-core split on a 32-core board); the
    extra cores 28..launch_cores-1 are emitted DISABLED so they no-op the FA loop but still
    join the AIV-wide FD barrier. fa_meta has launch_cores rows, fd_meta has 2*launch_cores
    rows (lanes beyond the 2*len(intervals) work lanes / beyond the FD tasks are disabled).
    """
    num_work = len(intervals)
    if launch_cores is None:
        launch_cores = num_work
    if launch_cores < num_work:
        raise ValueError(f"launch_cores {launch_cores} < work cores {num_work}")
    split_blocks = sorted({fs // tiles_n for (fs, fe) in intervals
                           if fs < fe and fs % tiles_n != 0})
    blk_to_task = {mb: j for j, mb in enumerate(split_blocks)}
    nws = 2 * len(split_blocks)

    fa = []
    for c in py_range(launch_cores):
        if c >= num_work:
            fa.append([0, 0, 0, -1, -1, 0])         # launched-but-idle core
            continue
        fs, fe = intervals[c]
        if fs >= fe:
            fa.append([0, 0, 0, -1, -1, 0])
            continue
        start_m, start_n = fs // tiles_n, fs % tiles_n
        end_m_excl, end_n_excl = fe // tiles_n, fe % tiles_n
        tail_ws, head_ws = -1, -1
        if start_n != 0:                       # first block is the TAIL piece -> 2j+1
            tail_ws = 2 * blk_to_task[start_m] + 1
        if end_n_excl != 0:                    # last block is the HEAD piece -> 2j
            head_ws = 2 * blk_to_task[end_m_excl]
            if start_n != 0 and start_m == end_m_excl:
                raise ValueError(f"3-way split of block {start_m} not supported")
        fa.append([1, fs, fe, tail_ws, head_ws, 0])

    fd = []
    for aiv in py_range(launch_cores * 2):
        task, row0 = aiv // 2, (aiv % 2) * ROWS_SB
        if task < len(split_blocks):
            mb = split_blocks[task]
            nrows = min(ROWS_SB, M - (mb * TILE_M + row0))
            fd.append([1, mb, 2 * task, 2 * task + 1, row0, nrows] if nrows > 0
                      else [0, 0, 0, 0, 0, 0])
        else:
            fd.append([0, 0, 0, 0, 0, 0])
    return fa, fd, max(1, nws), split_blocks


def _selftest():
    """Reproduce section-17 FD_M_IDX + first_fd_ws from build_metadata."""
    iv = fia_intervals(FIA_TILES_N)
    fa, fd, nws, blocks = build_metadata(FIA_TILES_M, FIA_TILES_N, iv, FIA_TILES_M * TILE_M)
    assert blocks == SEC17_FD_M_IDX, f"FD blocks mismatch:\n got {blocks}\n exp {SEC17_FD_M_IDX}"
    assert nws == 52, f"nws {nws} != 52"
    # first_fd_ws[c] = the smallest ws slot core c writes (min of its tail_ws/head_ws).
    derived = []
    for c, row in enumerate(fa):
        _, _, _, tail_ws, head_ws, _ = row
        used = [w for w in (tail_ws, head_ws) if w >= 0]
        derived.append(min(used) if used else -1)
    assert derived == SEC17_FIRST_FD_WS, f"first_fd_ws mismatch:\n got {derived}\n exp {SEC17_FIRST_FD_WS}"
    # every (m,s2) pair owned by exactly one core; contiguous cover of [0, total)
    total = FIA_TILES_M * FIA_TILES_N
    cover = []
    for (fs, fe) in iv:
        cover.extend(py_range(fs, fe))
    assert cover == list(py_range(total)), "interval cover is not a contiguous partition"
    # 52 FD lanes enabled (26 tasks x 2)
    assert sum(r[0] for r in fd) == 52, f"fd enabled lanes {sum(r[0] for r in fd)} != 52"
    print(f"[selftest PASS] fia: tiles_m={FIA_TILES_M} tiles_n={FIA_TILES_N} cores=28 "
          f"fd_tasks={len(blocks)} nws={nws} fd_lanes=52")

    # fia work=28 padded to launch=32 (real 950 board): cores 28-31 idle, 64 FD lanes (52 active)
    fa32, fd32, nws32, _ = build_metadata(FIA_TILES_M, FIA_TILES_N, iv, FIA_TILES_M * TILE_M, launch_cores=32)
    assert len(fa32) == 32 and len(fd32) == 64, (len(fa32), len(fd32))
    assert fa32[:28] == fa, "padded fa changed the 28 work rows"
    assert all(r == [0, 0, 0, -1, -1, 0] for r in fa32[28:]), fa32[28:]
    assert sum(r[0] for r in fd32) == 52, sum(r[0] for r in fd32)
    assert all(r[0] == 0 for r in fd32[52:]), fd32[52:]
    assert nws32 == 52, nws32
    print(f"[selftest PASS] fia pad: launch=32 work=28 idle=4 fd_lanes(active)=52/64")

    # dev split sanity
    iv3 = [(0, 4), (4, 7), (7, 9)]
    fa3, fd3, nws3, blk3 = build_metadata(3, 3, iv3, 3 * TILE_M)
    assert blk3 == [1, 2], blk3
    assert nws3 == 4, nws3
    assert fa3[0][3:5] == [-1, 0], fa3[0]       # core0: head m1 -> ws0
    assert fa3[1][3:5] == [1, 2], fa3[1]        # core1: tail m1 -> ws1, head m2 -> ws2
    assert fa3[2][3:5] == [3, -1], fa3[2]       # core2: tail m2 -> ws3
    assert [r[0] for r in fd3] == [1, 1, 1, 1, 0, 0], fd3
    print(f"[selftest PASS] dev: cores=3 fd_tasks={len(blk3)} nws={nws3}")


# ============================ vec stages ============================
@vf()
def init_state(ub_rmax: Tensor, ub_rsum: Tensor):
    """rowmax=-inf, rowsum=0 for one m-block's running softmax state (64-wide)."""
    neg = Reg(DT.float)
    zero = Reg(DT.float)
    neg <<= NEG_LARGE
    zero <<= 0.0
    ub_rmax[0:1, 0:ROWS_SB] <<= neg
    ub_rsum[0:1, 0:ROWS_SB] <<= zero


@vf()
def softmax_t_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                 ub_old_weight: Tensor):
    """TRANSPOSED online softmax over [key=128, query=64] score^T, single-weight (new-max) scheme:
    P^T = exp(scale*s - new_m) (block weight folded into P -> accum is just O*old_scale + PV). Lane-wise
    vmax over the 128 key ROWS gives the per-query max directly in lanes (no cmax/EQ-scatter). 2-key pack
    (key i with i+64 -> one 128-lane bf16 reg via deinterleave) -> ub_p[65,128]; new_m between the passes."""
    sreg = RegList(DT.float, UNROLL_F); acc = RegList(DT.float, UNROLL_F); preg = RegList(DT.float, UNROLL_F)
    h_i = RegList(DT.bfloat16, UNROLL_F); h_j = RegList(DT.bfloat16, UNROLL_F)
    pk = Reg(DT.bfloat16); pk_hi = Reg(DT.bfloat16)
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    # pass 1: per-query max over 128 keys (4 independent partial-max chains on RAW scores), tree-combine
    neg <<= NEG_LARGE
    for u in unroll(UNROLL_F):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL_F):
            sreg[u] <<= ub_score[(rb * UNROLL_F + u):(rb * UNROLL_F + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)        # scale the max ONCE (max(scale*s)=scale*max(s))
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)                   # old_scale = exp(old_m - new_m)
    # pass 2: exp(scale*s - new_m) + per-query sum (4 partial-sum chains) + 2-key (i, i+64) pack
    for u in unroll(UNROLL_F):
        acc[u] <<= 0.0
    for rb in range(RB_EXP, name="ex"):
        for u in unroll(UNROLL_F):                   # the "i" keys (0..63)
            sreg[u] <<= ub_score[(rb * UNROLL_F + u):(rb * UNROLL_F + u) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            h_i[u] <<= preg[u].astype(DT.bfloat16)
        for u in unroll(UNROLL_F):                   # the "i+64" keys
            sreg[u] <<= ub_score[(rb * UNROLL_F + u + HALF):(rb * UNROLL_F + u + HALF) + 1, :]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            expsub(preg[u], sreg[u], v_nmax)
            acc[u] <<= acc[u] + preg[u]
            h_j[u] <<= preg[u].astype(DT.bfloat16)
        for u in unroll(UNROLL_F):
            deinterleave(pk, pk_hi, h_i[u], h_j[u])  # pk = [key_i 64q | key_(i+64) 64q]
            reg_to_ub(ub_p[(rb * UNROLL_F + u) * C0], pk, FRAC_STRIDE)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum                    # block_sum already exp'd vs new_m -> no blkw
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_t_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                      ub_old_weight: Tensor, valid_n: Var):
    """TRANSPOSED softmax for a PARTIAL K-tile (valid_n < TILE_N): invalid key ROWS (n >= valid_n,
    stale QK) are select()'d to NEG before the lane-wise max/exp, so they drop out of the per-query
    max and give P=exp(NEG-new_m)=0. Non-unrolled (only the last K-tile per query-tile uses it);
    same single-weight new_m scheme + 2-key (i, i+64) pack as softmax_t_vf."""
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float)
    h_i = Reg(DT.bfloat16); h_j = Reg(DT.bfloat16); pk = Reg(DT.bfloat16); dummy = Reg(DT.bfloat16)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)   # QLANES if n<valid_n else 0
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)                  # invalid key-row -> all-NEG -> excluded from max
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    block_sum <<= 0.0
    for i in range(HALF):
        cnt_i = Var(QLANES * Min(Max(valid_n - i, 0), 1), dtype=DT.uint32)
        s <<= ub_score[i:i + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_i)
        select(s, s, neg, mask=rowmask)
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        h_i <<= e.astype(DT.bfloat16)
        cnt_j = Var(QLANES * Min(Max(valid_n - (i + HALF), 0), 1), dtype=DT.uint32)
        s <<= ub_score[i + HALF:i + HALF + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_j)
        select(s, s, neg, mask=rowmask)
        expsub(e, s, v_nmax)
        block_sum <<= block_sum + e
        h_j <<= e.astype(DT.bfloat16)
        deinterleave(pk, dummy, h_i, h_j)
        reg_to_ub(ub_p[i * C0], pk, FRAC_STRIDE)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_pv_t(ub_accum: Tensor, ub_pv: Tensor, ub_old_w: Tensor, rows: Var):
    """TRANSPOSED single-weight online rescale: O[r] = O[r]*old_scale[r] + PV[r]. P is already exp'd
    against the running max in softmax_t, so PV needs NO block weight (one weight, simpler than the
    two-weight champion). rows = local query rows (const-trip processes all 64; tail rows contained)."""
    acc = RegList(DT.float, CD)
    pv_regs = RegList(DT.float, CD)
    old_w = Reg(DT.float)
    for rb in range(ROWS_SB // UNROLL_F):
        for ru in unroll(UNROLL_F):
            r = rb * UNROLL_F + ru
            old_w <<= ub_old_w[0:1, r:r + 1].single()
            acc <<= ub_accum[r:r + 1, :]
            pv_regs <<= ub_pv[r:r + 1, :]
            acc <<= acc * old_w
            acc <<= acc + pv_regs
            ub_accum[r:r + 1, :] <<= acc


@vf()
def accum_pv_first_t(ub_accum: Tensor, ub_pv: Tensor, rows: Var):
    """First owned K-tile: O = PV (no prior O to rescale; P already exp'd against new_m)."""
    pv_regs = RegList(DT.float, CD)
    for rb in range(ROWS_SB // UNROLL_F):
        for ru in unroll(UNROLL_F):
            r = rb * UNROLL_F + ru
            pv_regs <<= ub_pv[r:r + 1, :]
            ub_accum[r:r + 1, :] <<= pv_regs


@vf()
def finalize(ub_accum: Tensor, ub_rsum: Tensor, ub_out: Tensor, rows: Var):
    """out = accum / rowsum; bf16 cast on store. For non-split (fully owned) m-blocks."""
    regs = RegList(DT.float, CD)
    sum_reg = Reg(DT.float)
    for rb in range(ROWS_SB // UNROLL_F):    # P1 const-unroll
        for ru in unroll(UNROLL_F):
            r = rb * UNROLL_F + ru
            sum_reg <<= ub_rsum[0:1, r:r + 1].single()
            regs <<= ub_accum[r:r + 1, :]
            regs <<= regs / sum_reg
            ub_out[r:r + 1, :] <<= regs


@vf()
def fd_merge_t(ub_o0: Tensor, ub_o1: Tensor, ub_m0: Tensor, ub_m1: Tensor,
               ub_s0: Tensor, ub_s1: Tensor, ub_A: Tensor, ub_den: Tensor, ub_merged: Tensor):
    """2-split merge + normalize, LEAN form (== max-aware): A=exp(m0-m1), den_eff=s0*A+s1 precomputed
    VECTORIZED over the 64 query lanes; main loop O=(o0*A+o1)/den_eff per row."""
    m0v = Reg(DT.float); m1v = Reg(DT.float); s0v = Reg(DT.float); s1v = Reg(DT.float)
    Av = Reg(DT.float); denv = Reg(DT.float)
    m0v <<= ub_m0[0:1, 0:ROWS_SB]
    m1v <<= ub_m1[0:1, 0:ROWS_SB]
    s0v <<= ub_s0[0:1, 0:ROWS_SB]
    s1v <<= ub_s1[0:1, 0:ROWS_SB]
    expsub(Av, m0v, m1v)                          # A = exp(m0 - m1)
    denv <<= s0v * Av
    denv <<= denv + s1v                           # den_eff = s0*A + s1
    ub_A[0:1, 0:ROWS_SB] <<= Av
    ub_den[0:1, 0:ROWS_SB] <<= denv
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    o0 = RegList(DT.float, CD); o1 = RegList(DT.float, CD)
    Ar = Reg(DT.float); dr = Reg(DT.float)
    for r in range(ROWS_SB, name="fdrow"):
        Ar <<= ub_A[0:1, r:r + 1].single()
        dr <<= ub_den[0:1, r:r + 1].single()
        o0 <<= ub_o0[r:r + 1, :]
        o1 <<= ub_o1[r:r + 1, :]
        o0 <<= o0 * Ar
        o0 <<= o0 + o1
        o0 <<= o0 / dr
        ub_merged[r:r + 1, :] <<= o0                # O = (o0*A + o1)/den_eff (fp32)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def output_cast_t(ub_merged: Tensor, ub_out: Tensor):
    """fp32 merged O -> bf16, per D-chunk, downsample-pack store."""
    regs = RegList(DT.float, CD); hregs = RegList(DT.bfloat16, CD)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="fd_o_bf16")
    for r in range(ROWS_SB, name="fdcrow"):
        regs <<= ub_merged[r:r + 1, :]
        for c in unroll(CD):
            cast(hregs[c], regs[c], cfg)
            reg_to_ub_downsample(ub_out[r:r + 1, c * 64:(c + 1) * 64], hregs[c])
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def copy_partial_t(dst_a: Tensor, dst_m: Tensor, dst_s: Tensor,
                   src_a: Tensor, src_m: Tensor, src_s: Tensor):
    """Capture the FD partial state (accum / row-max / row-sum) into DEDICATED fixed buffers via VEC
    reads, BEFORE the GM workspace store. The next m-block's init_state/accum_pv clobber the ring/single
    source buffers (ub_rmax[mt%CACHE] / single ub_accum); routing through a vec read makes that a
    vec-vec WAR on a single/fixed buffer (auto_sync tracks it -> the clobber is ordered after this read),
    and the MTE3 store then reads the stable copy. Root fix for the FD partial-clobber 0.808/NaN
    (the runtime-ring-index WAR the autosync tracker missed)."""
    mv = Reg(DT.float)
    sv = Reg(DT.float)
    mv <<= src_m[0:1, 0:ROWS_SB]
    dst_m[0:1, 0:ROWS_SB] <<= mv
    sv <<= src_s[0:1, 0:ROWS_SB]
    dst_s[0:1, 0:ROWS_SB] <<= sv
    a = RegList(DT.float, CD)
    for r in range(ROWS_SB, name="cprow"):
        a <<= src_a[r:r + 1, :]
        dst_a[r:r + 1, :] <<= a
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ============================ kernel ============================
@kernel()
def fia_gqa_step3_transpose_kernel(q: GMTensor, k: GMTensor, v: GMTensor,
                         fa_meta: GMTensor, fd_meta: GMTensor, out: GMTensor,
                         M: Var, S2: Var, D: Var, scale: Var, tiles_n: Var):
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")

    # Compact sync: start_pipe == end_pipe so each side's wait sits on the SAME pipe as its set
    # (FIA's intra-block handoff). Default start=Pipe.S routed the wait through scalar -> camodel
    # WAIT_FLAG_CUBE/VEC stalls; matching to FIX/V keeps it WAIT_INTRA_BLOCK (vec runs dense).
    qk_mutex = CvMutex(0, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                       src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)   # AIC->AIV BMM1 (BOTH)
    pv_mutex = CvMutex(2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                       src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)   # AIC->AIV BMM2 (BOTH)
    # p (flag 1): FORWARD-only L1-P ring -- raw vec_ready/wait_vec, no backward.
    # flag 6: AIV-wide Flash-Decode barrier (allvec, == official SyncAll).

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = TBuff(IO_DT, [TILE_N, D_HEAD], Position.L1)
    l1p = TBuff(IO_DT, [TILE_N, TILE_M], Position.L1)          # P^T [key=128, query=128], column-published per sub-block
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)   # QK^T [key, query] = [128,128]
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)

    ub_score = DBuff(DT.float, [TILE_N, ROWS_SB], Position.UB)    # score^T per sub-block [key=128, query=64] fp32 (SPLITN)
    ub_pv = DBuff(DT.float, [ROWS_SB, D_HEAD], Position.UB)
    ub_p = Tensor(IO_DT, [FRAC_STRIDE, 2 * ROWS_SB], Position.UB)  # 2-key NZ P^T pack [65,128], single-buffer
    ub_old_w = TBuff(DT.float, [1, 64], Position.UB)
    ub_rmax = TBuff(DT.float, [1, 64], Position.UB)
    ub_rsum = TBuff(DT.float, [1, 64], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_SB, D_HEAD], Position.UB)
    ub_out = Tensor(IO_DT, [ROWS_SB, D_HEAD], Position.UB)

    # Dedicated FD-partial capture buffers (fixed, NOT ring-indexed): copy the partial state here
    # before the GM store so a later m-block's ring/accum clobber can't corrupt the in-flight store.
    ub_accum_pfx = Tensor(DT.float, [ROWS_SB, D_HEAD], Position.UB)
    ub_rmax_pfx = Tensor(DT.float, [1, 64], Position.UB)
    ub_rsum_pfx = Tensor(DT.float, [1, 64], Position.UB)

    # Flash-Decode partial workspace (fp32). nws baked per config.
    fd_accum = split_workspace(DT.float, [NWS_GLOBAL, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [NWS_GLOBAL, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [NWS_GLOBAL, 1, TILE_M], name="fd_sum")

    core = Var(GetCubeIdx())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_SB)

    # --- per-core stream-K metadata (GetValueFrom, ace_v13 pattern) ---
    fa_base = Var(core * FA_NF)
    flat_start = Var(0, DT.int)
    flat_start.GetValueFrom(fa_meta[fa_base + 1:fa_base + 2])
    flat_end = Var(0, DT.int)
    flat_end.GetValueFrom(fa_meta[fa_base + 2:fa_base + 3])
    tail_ws = Var(0, DT.int)
    tail_ws.GetValueFrom(fa_meta[fa_base + 3:fa_base + 4])
    head_ws = Var(0, DT.int)
    head_ws.GetValueFrom(fa_meta[fa_base + 4:fa_base + 5])
    num_tasks = Var(Max(flat_end - flat_start, 0))
    first_block_m = Var(flat_start // tiles_n)
    last_block_m = Var((flat_end - 1) // tiles_n)

    with auto_sync():
        for loop in range(0, num_tasks + PRELOAD_N):
            # ===== current task: BMM1 -> two-weight softmax -> P-NZ -> L1 =====
            if loop < num_tasks:
                c1 = Var(loop % CACHE)
                d1 = Var(loop % 2)
                t1 = Var(flat_start + loop)
                mt1 = Var(t1 // tiles_n)
                s2_1 = Var(t1 % tiles_n)
                cm1 = Var(mt1 % CACHE)
                cq1 = Var(mt1 % 2)

                q_row1 = Var(mt1 * TILE_M)
                valid_m1 = Min(TILE_M, M - q_row1)
                local_m1 = Min(ROWS_SB, Max(valid_m1 - row_begin, 0))
                n_off1 = Var(s2_1 * TILE_N)
                valid_n1 = Min(TILE_N, S2 - n_off1)

                if s2_1 == 0 or loop == 0:                 # m-block start (may begin mid-s2)
                    l1q[cq1][0:valid_m1, 0:D] <<= q_hif8[q_row1:q_row1 + valid_m1, 0:D]
                    init_state(ub_rmax[cm1], ub_rsum[cm1])

                l1k[c1][0:valid_n1, 0:D] <<= k_hif8[n_off1:n_off1 + valid_n1, 0:D]
                # transposed QK: score^T = K @ Q^T -> l0c [key=TILE_N, query=TILE_M]
                matmul(l0c_qk[d1], l1k[c1], l1q[cq1], m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                qk_mutex.lock()
                # SPLITN: split the query (free) axis 64+64 across the two AIV sub-blocks; fp32->fp32 dual-dest
                # (no downcast -> cheap fixpipe, unlike the fp16 SINGLE-mode +82us path).
                l0c_to_ub(ub_score[d1], l0c_qk[d1][0:TILE_N, 0:TILE_M],
                          M=TILE_N, N=TILE_M, N_dst=ROWS_SB, M_src=TILE_N,
                          dual_mode=DualMode.SPLITN, sub_block_id=0)
                qk_mutex.ready()
                qk_mutex.wait()
                if valid_n1 < TILE_N:                          # tail K-tile: mask invalid key ROWS -> P=0
                    softmax_t_tail_vf(ub_score[d1], ub_rmax[cm1], ub_rsum[cm1], ub_p, ub_old_w[c1], valid_n1)
                else:                                          # full K-tile: lane-wise vmax, no mask
                    softmax_t_vf(ub_score[d1], ub_rmax[cm1], ub_rsum[cm1], ub_p, ub_old_w[c1])
                qk_mutex.free()

                # publish P^T into l1p: 2-key pack demux -> keys 0-63 and 64-127, this sub-block's query cols
                l1p[c1][0:HALF, row_begin:row_begin + ROWS_SB] <<= ub_p.nz()[0:HALF, 0:ROWS_SB]
                l1p[c1][HALF:TILE_N, row_begin:row_begin + ROWS_SB] <<= ub_p.nz()[0:HALF, ROWS_SB:2 * ROWS_SB]
                vec_ready(1, Pipe.MTE3)

            # ===== lagged task: BMM2 -> accumulate -> finalize / FD-partial =====
            if loop >= PRELOAD_N:
                lag = Var(loop - PRELOAD_N)
                c2 = Var(lag % CACHE)
                d2 = Var(lag % 2)
                t2 = Var(flat_start + lag)
                mt2 = Var(t2 // tiles_n)
                s2_2 = Var(t2 % tiles_n)
                cm2 = Var(mt2 % CACHE)

                q_row2 = Var(mt2 * TILE_M)
                valid_m2 = Min(TILE_M, M - q_row2)
                local_m2 = Min(ROWS_SB, Max(valid_m2 - row_begin, 0))
                n_off2 = Var(s2_2 * TILE_N)
                valid_n2 = Min(TILE_N, S2 - n_off2)

                l1v[c2][0:valid_n2, 0:D] <<= v[n_off2:n_off2 + valid_n2, 0:D]
                wait_vec(1, Pipe.MTE1)   # L1-P ring: cube waits on its consume pipe (MTE1) -> intra-block, not S/FFTS
                # transposed PV: O[query, D] = P @ V via BOTH operands .T (l1p holds P^T); k=valid_n2 (K-tail)
                matmul(l0c_pv[d2], l1p[c2].T, l1v[c2].T, m=TILE_M, n=D_HEAD, k=valid_n2, is_init=True)

                pv_mutex.lock()
                ub_pv[d2] <<= l0c_pv[d2]                   # SPLITM dual-lane fp32 (each AIV its 64 query rows)
                pv_mutex.ready()
                pv_mutex.wait()
                if s2_2 == 0 or lag == 0:                  # m-block first owned s2: O = PV (single-weight, no rescale)
                    accum_pv_first_t(ub_accum, ub_pv[d2], local_m2)
                else:                                      # O = O*old_scale + PV
                    accum_pv_t(ub_accum, ub_pv[d2], ub_old_w[c2], local_m2)

                if s2_2 == tiles_n - 1 or lag == num_tasks - 1:   # m-block last owned s2
                    if mt2 == first_block_m and tail_ws >= 0:     # tail (upper-s2) partial: no divide
                        if local_m2 > 0:
                            copy_partial_t(ub_accum_pfx, ub_rmax_pfx, ub_rsum_pfx,
                                           ub_accum, ub_rmax[cm2], ub_rsum[cm2])
                            fd_accum[tail_ws, row_begin:row_begin + local_m2, 0:D_HEAD] <<= ub_accum_pfx[0:local_m2, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_m2] <<= ub_rmax_pfx[0:1, 0:local_m2]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_m2] <<= ub_rsum_pfx[0:1, 0:local_m2]
                    elif mt2 == last_block_m and head_ws >= 0:    # head (lower-s2) partial: no divide
                        if local_m2 > 0:
                            copy_partial_t(ub_accum_pfx, ub_rmax_pfx, ub_rsum_pfx,
                                           ub_accum, ub_rmax[cm2], ub_rsum[cm2])
                            fd_accum[head_ws, row_begin:row_begin + local_m2, 0:D_HEAD] <<= ub_accum_pfx[0:local_m2, 0:D_HEAD]
                            fd_max[head_ws, 0:1, row_begin:row_begin + local_m2] <<= ub_rmax_pfx[0:1, 0:local_m2]
                            fd_sum[head_ws, 0:1, row_begin:row_begin + local_m2] <<= ub_rsum_pfx[0:1, 0:local_m2]
                    else:                                         # fully owned: finalize (separate divide) + store
                        finalize(ub_accum, ub_rsum[cm2], ub_out, local_m2)
                        out_row2 = Var(q_row2 + row_begin)
                        if local_m2 > 0:
                            out[out_row2:out_row2 + local_m2, 0:D] <<= ub_out[0:local_m2, 0:D]
                pv_mutex.free()

        # ===== Flash-Decode merge phase (AIV-only) =====
        # Every AIV lane must hit the barrier so the partials are globally visible.
        allvec_ready(6, Pipe.MTE3)
        allvec_wait(6, Pipe.MTE2)   # gate the merge's GM->UB partial loads (MTE2), not scalar (S)

        fd_b = Var(vec * FD_NF)
        fd_en = Var(0, DT.int)
        fd_en.GetValueFrom(fd_meta[fd_b + 0:fd_b + 1])
        if fd_en > 0:
            fd_m = Var(0, DT.int)
            fd_m.GetValueFrom(fd_meta[fd_b + 1:fd_b + 2])
            fd_lo = Var(0, DT.int)
            fd_lo.GetValueFrom(fd_meta[fd_b + 2:fd_b + 3])
            fd_hi = Var(0, DT.int)
            fd_hi.GetValueFrom(fd_meta[fd_b + 3:fd_b + 4])
            fd_row0 = Var(0, DT.int)
            fd_row0.GetValueFrom(fd_meta[fd_b + 4:fd_b + 5])
            fd_nrows = Var(0, DT.int)
            fd_nrows.GetValueFrom(fd_meta[fd_b + 5:fd_b + 6])

            out_base = Var(fd_m * TILE_M)
            # transpose FD: load this AIV's 64-query partial halves; merge full ROWS_SB rows
            # (single-weight lean form via fd_merge_t); cast bf16; store. Reuses ub_pv/ub_rmax/
            # ub_rsum/ub_old_w (free post-loop) -- no extra UB.
            ub_rmax[0][0:1, 0:ROWS_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_SB]
            ub_rmax[1][0:1, 0:ROWS_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_SB]
            ub_rsum[0][0:1, 0:ROWS_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_SB]
            ub_rsum[1][0:1, 0:ROWS_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_SB]
            ub_pv[0][0:ROWS_SB, 0:D_HEAD] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_SB, 0:D_HEAD]
            ub_pv[1][0:ROWS_SB, 0:D_HEAD] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_SB, 0:D_HEAD]
            fd_merge_t(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1], ub_rsum[0], ub_rsum[1],
                       ub_old_w[0], ub_old_w[1], ub_pv[0])
            output_cast_t(ub_pv[0], ub_out)
            if fd_nrows > 0:
                out[out_base + fd_row0:out_base + fd_row0 + fd_nrows, 0:D] <<= ub_out[0:fd_nrows, 0:D]
    return out


# ============================ reference / runner ============================
def _ref(q, k, v):
    # q [Hq, S1, D], k/v [1, S2, D]; GQA broadcast single KV head.
    hq, s1, d = q.shape
    s2 = k.shape[1]
    scale = 1.0 / math.sqrt(d)
    qf = q.float()
    kf = k.float().expand(hq, s2, d)
    vf = v.float().expand(hq, s2, d)
    scores = torch.einsum("hsd,htd->hst", qf, kf) * scale
    m = scores.max(dim=-1, keepdim=True).values
    p = torch.exp(scores - m)
    s = p.sum(dim=-1, keepdim=True)
    o = torch.einsum("hst,htd->hsd", (p / s).to(torch.bfloat16).float(), vf)
    return o            # [Hq, S1, D]


def _cos(a, b):
    import torch.nn.functional as F
    return F.cosine_similarity(a.reshape(1, -1).float(), b.reshape(1, -1).float(), dim=1).item()


def _makespan(trace_path):
    import json
    with open(trace_path, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    timed = [e for e in payload.get("traceEvents", []) if e.get("ph") == "X"]
    return max((float(e.get("ts", 0.0)) + float(e.get("dur", 0.0)) for e in timed), default=0.0)


def main():
    import os
    torch.manual_seed(0)

    mode = os.environ.get("PV_MODE", "sim")
    meta = os.environ.get("PV_META", "dev")
    hq = int(os.environ.get("PV_HQ", "2"))
    s1 = int(os.environ.get("PV_SQ", "192"))
    s2 = int(os.environ.get("PV_SKV", "259"))
    core_count = int(os.environ.get("PV_CORES", "3"))
    launch_env = os.environ.get("PV_LAUNCH", "")
    launch_cores = int(launch_env) if launch_env else None
    trace = os.environ.get("PV_TRACE", "0") == "1"
    selftest = os.environ.get("PV_SELFTEST", "0") == "1"

    if selftest:
        _selftest()
        return

    global NWS_GLOBAL
    if meta in ("fia", "fia32"):
        hq, s1, s2 = 8, 4099, 4099

    M = hq * s1
    tiles_m = (M + TILE_M - 1) // TILE_M
    tiles_n = (s2 + TILE_N - 1) // TILE_N

    if meta == "fia":
        assert tiles_m == FIA_TILES_M and tiles_n == FIA_TILES_N, (tiles_m, tiles_n)
        intervals = fia_intervals(tiles_n)
        if launch_cores is None:
            launch_cores = 32
    elif meta == "fia32":
        if launch_cores is None:
            launch_cores = 32
        intervals = staggered_intervals(tiles_m * tiles_n, launch_cores, tiles_n)
    elif meta == "even":
        nc = launch_cores if launch_cores is not None else core_count
        nc = min(nc, tiles_m)
        intervals = even_mblock_intervals(tiles_m, tiles_n, nc)
    elif core_count == 1:
        intervals = [(0, tiles_m * tiles_n)]
    else:
        intervals = staggered_intervals(tiles_m * tiles_n, core_count, tiles_n)
    if launch_cores is None:
        launch_cores = len(intervals)
    core_count = launch_cores

    fa, fd, nws, blocks = build_metadata(tiles_m, tiles_n, intervals, M, launch_cores=launch_cores)
    NWS_GLOBAL = nws

    q_fp32 = torch.randn(hq, s1, D_HEAD, dtype=torch.float32)
    k_fp32 = torch.randn(1, s2, D_HEAD, dtype=torch.float32)
    v = torch.randn(1, s2, D_HEAD, dtype=TORCH_IO)
    q = fp32_to_hif8(q_fp32).to(TORCH_QK)
    k = fp32_to_hif8(k_fp32).to(TORCH_QK)

    scale = 1.0 / math.sqrt(D_HEAD)
    q_flat = q.reshape(M, D_HEAD).contiguous()
    k_flat = k.reshape(s2, D_HEAD).contiguous()
    v_flat = v.reshape(s2, D_HEAD).contiguous()
    out_flat = torch.zeros(M, D_HEAD, dtype=TORCH_IO)
    fa_t = torch.tensor([x for row in fa for x in row], dtype=torch.int32)
    fd_t = torch.tensor([x for row in fd for x in row], dtype=torch.int32)

    from easyasc.simulator.config import SimulatorConfig
    do_trace = trace and mode == "sim"
    fia_gqa_step3_transpose_kernel._simulator_config = SimulatorConfig(
        core_count=core_count, trace_enabled=do_trace, execution_timeout_s=3600.0)

    tag = f"fia_step3t_qkhif8_{meta}"
    d = f"./tmp/{tag}_{mode}"
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q_flat, k_flat, v_flat, fa_t, fd_t, out_flat, M, s2, D_HEAD, scale, tiles_n)
    sb = {0: [0, 2], 1: [1, 2], 2: [1, 2], 3: [None], 4: [None], 5: [0, 2]}

    work_cores = sum(1 for r in fa if r[0] == 1)
    print(f"[{tag}] Hq={hq} S1={s1} S2={s2} launch={launch_cores} work={work_cores} "
          f"fd_tasks={len(blocks)} nws={nws}", flush=True)

    if mode == "sim":
        tpath = d + "_trace.json" if trace else None
        opx_kw = dict(simulator=True, out_dir=d)
        if trace:
            opx_kw["trace"] = tpath
        out_kf = OpExec(fia_gqa_step3_transpose_kernel, **opx_kw)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        out_kf = OpExec(fia_gqa_step3_transpose_kernel, out_dir=d, cann_path=cann,
                        custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                        simulator=False, cannsim=True)(*args, shape_bindings=sb)
    elif mode == "hw":
        out_kf = OpExec(fia_gqa_step3_transpose_kernel, out_dir=d, cann_path=cann,
                        custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                        simulator=False, debug=False, profile=True)(*args, shape_bindings=sb)
    else:
        raise SystemExit(f"PV_MODE must be sim|cannsim|hw, got {mode}")

    q_ref = hif8_to_fp32(q).reshape(hq, s1, D_HEAD)
    k_ref = hif8_to_fp32(k).reshape(1, s2, D_HEAD)
    ref = _ref(q_ref, k_ref, v)
    out_k = out_kf.reshape(hq, s1, D_HEAD)

    # per-m-block diagnostic
    ref_flat = ref.reshape(M, D_HEAD)
    blockset = set(blocks)
    diag = []
    for mb in py_range(tiles_m):
        r0, r1 = mb * TILE_M, min((mb + 1) * TILE_M, M)
        ma = (out_kf[r0:r1].float() - ref_flat[r0:r1].float()).abs().max().item()
        if ma > 1e-2:
            diag.append(f"m{mb}{'(FD)' if mb in blockset else '(own)'}={ma:.3f}")
    if diag:
        print("  per-block max_abs>1e-2: " + " ".join(diag[:40]))

    cos = _cos(out_k, ref)
    max_abs = (out_k.float() - ref.float()).abs().max().item()
    nan = torch.isnan(out_k).any().item()
    status = "PASS" if (not nan and cos >= 0.999) else "FAIL"
    mk = ""
    if do_trace:
        mk = f" makespan={_makespan(tpath):.0f}cyc"
    print(f"[{status}] cos={cos:.6f} max_abs={max_abs:.3e} nan={nan}{mk}", flush=True)


if __name__ == "__main__":
    main()
