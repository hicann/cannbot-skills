"""Step 4: conv NZ output -> y NCHW (a2 vec, fp32 -> fp16).

out [C1O*M, C0]   NZ fp32 from step 3 (M = HO*WO)
y   [COUT, M]     flat NCHW fp16 (row = cout, col = ho*WO + wo)

Per (c1o, m-chunk): load [CHUNK, 16] fp32 rows, cast to fp16 (RINT = round to
nearest even, matching torch .half()), vnchwconv to [16, CHUNK], store as 16
strided cout rows.

  PYTHONPATH=<repo> python transdata_out_to_nchw.py            # python simulator
  PYTHONPATH=<repo> python transdata_out_to_nchw.py --debug    # 910B3 standalone
"""
from easyasc.a2 import *

from common import B, C0, C1O, COUT, DEBUG, HO, M, N_VEC, WO

CHUNK = min(512, M)                 # cast repeat = CHUNK*16/64 <= 128 <= 255
CHUNKS = M // CHUNK


@kernel()
def transdata_out_to_nchw(out: GMTensor, y: GMTensor, nv: Var):
    # contiguous per-lane unit block + DBuff (slots alternate per iteration).
    src = DBuff(DT.float, [CHUNK, C0], Position.UB)
    mid = DBuff(DT.half, [CHUNK, C0], Position.UB)
    dst = DBuff(DT.half, [16, CHUNK], Position.UB)
    vec_idx = GetVecIdx()
    units = C1O * CHUNKS
    per_lane = (units + N_VEC - 1) // N_VEC
    begin = per_lane * vec_idx
    end = Min(begin + per_lane, units)
    with auto_sync():
        for u in range(begin, end):
            c1o = var_div(u, CHUNKS)
            s = c1o * M + var_mod(u, CHUNKS) * CHUNK
            sb = src[u]
            mb = mid[u]
            db = dst[u]
            sb <<= out[s:s + CHUNK, :]
            cast(mb, sb, round_mode=RoundMode.TO_EVEN)
            transdata5hd(db, mb, repeat=CHUNK // 16,
                         src_row_stride=C0, dst_row_stride=CHUNK,
                         src_rep_stride=16, dst_rep_stride=1)
            y[c1o * C0:c1o * C0 + 16, var_mod(u, CHUNKS) * CHUNK:var_mod(u, CHUNKS) * CHUNK + CHUNK] <<= db
    return y


if __name__ == "__main__":
    import torch

    torch.manual_seed(10)
    nz = torch.randn((C1O * M, C0), dtype=torch.float32)
    y = torch.zeros((COUT, M), dtype=torch.float16)
    ref = nz.reshape(C1O, M, C0).permute(0, 2, 1).reshape(COUT, M).half()
    got = OpExec(transdata_out_to_nchw, simulator=not DEBUG, debug=DEBUG)(nz, y, N_VEC)
    assert torch.equal(got, ref), float((got.float() - ref.float()).abs().max())
    print("transdata_out_to_nchw {}x{}x{} exact".format(COUT, HO, WO))
