"""fp32 matmul with a C2/BT bias table, staged via the `<<=` sugar (a5/950).

Same low-level bias path as matmul_float_bias_bt.py, but the two staging copies
use the `<<=` operator instead of explicit gm_to_l1_pad / l1_to_bt calls:

    l1b = Tensor(..., Position.L1, layout=Layout.ND)   # ND L1 staging buffer
    l1b <<= bias[:, :]   # GM->L1: ND dest dispatches to gm_to_l1_pad (contiguous,
                         #         n_burst/burst_len) -- NOT the nd2nz fractal path
    bt  <<= l1b          # L1->BT: BT<-L1 dispatches to l1_to_bt

A default L1 tensor is NZ, so `l1 <<= gm` still nd2nz-fractalizes as before; only
an ND-layout L1 destination (Layout.ND) routes to the contiguous pad. The bias row
must be contiguous for the flat L1->C2 burst, hence the ND staging buffer.

This emits byte-identical code to the explicit form in matmul_float_bias_bt.py
(verified by gen-diff), so it inherits that kernel's Ascend950 CANNSIM validation.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_sugar.py             # simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_sugar.py --gen-only
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_sugar.py --cannsim   # VM only
"""
from easyasc.a5 import *


@kernel()
def matmul_float_bias_sugar_kernel(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor,
                                   M: Var, N: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    # ND layout => `<<=` from GM lands the bias row contiguously (gm_to_l1_pad).
    l1b = Tensor(DT.float, [1, N], Position.L1, layout=Layout.ND)
    bt = Tensor(DT.float, [1, N], Position.BT)
    l0a = Tensor(DT.float, [M, K], Position.L0A)
    l0b = Tensor(DT.float, [N, K], Position.L0B)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        l1b <<= bias[:, :]   # GM -> L1 (ND, contiguous): gm_to_l1_pad
        bt <<= l1b           # L1 -> BT: l1_to_bt
        l1_to_l0(l0a, l1x)
        l1_to_l0(l0b, l1y)
        mmad(l0c, l0a, l0b, M=M, N=N, K=K, is_init=True, bias=bt)
        z[:, :] <<= l0c
    return z


def _force_single_core():
    """Force block_dim=1 so CANNSIM simulates one AI core (much faster). The DSL
    otherwise hardcodes 32 for 950; validation-only, does not touch the repo."""
    import easyasc.kernelbase.kernelbase as kb
    kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda device_type: 1)


if __name__ == "__main__":
    import os
    import sys

    import torch

    # Small + single-core keeps CANNSIM fast.
    M, N, K = 32, 64, 16
    torch.manual_seed(0)
    x = torch.randn((M, K), dtype=torch.float32)
    y = torch.randn((N, K), dtype=torch.float32)
    bias = torch.randn((1, N), dtype=torch.float32)
    z = torch.zeros((M, N), dtype=torch.float32)

    gen_only = "--gen-only" in sys.argv[1:]
    use_cannsim = "--cannsim" in sys.argv[1:]
    z_ref = x @ y.t() + bias

    if not gen_only and not use_cannsim:
        # Default: simulator (models the BT bias table as a logical [N] vector).
        z_out = OpExec(matmul_float_bias_sugar_kernel, simulator=True)(x, y, bias, z, M, N, K)
        torch.testing.assert_close(z_out, z_ref, rtol=1e-4, atol=1e-4)
        print("simulator matmul+bias (sugar) passed max_abs_diff={:.6e}".format(
            float(torch.abs(z_out - z_ref).max().item())))
    else:
        # CANNSIM / codegen path (VM-local build; single core for speed).
        if use_cannsim:
            _force_single_core()
        base = os.environ.get("BIAS_BASE", "./tmp/a5_bias_cannsim")
        out_dir = os.path.join(base, "biassugar")
        z_out = OpExec(
            matmul_float_bias_sugar_kernel,
            simulator=False,
            cannsim=use_cannsim,
            gen_only=gen_only,
            cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
            custom_op_path=os.path.join(base, "custom_opp"),
            out_dir=out_dir,
        )(x, y, bias, z, M, N, K)
        if gen_only:
            print("gen_only complete ->", out_dir)
        else:
            torch.testing.assert_close(z_out, z_ref, rtol=1e-4, atol=1e-4)
            print("cannsim matmul+bias (sugar) passed max_abs_diff={:.6e}".format(
                float(torch.abs(z_out - z_ref).max().item())))
