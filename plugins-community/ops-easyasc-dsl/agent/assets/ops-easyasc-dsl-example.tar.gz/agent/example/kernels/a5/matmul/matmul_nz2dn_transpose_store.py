from easyasc.a5 import *

# Matmul with a transposed (NZ2DN / COLUMN_MAJOR) fixpipe store (a5/C310 only).
# z = x @ y^T is computed in L0C as [M, N]; `zt <<= l0c.T` writes its TRANSPOSE
# zt = z^T = [N, M] straight to GM, no vector transpose. Three distinct axes
# (M != K != N) so the transpose layout is exercised, not a square.
M = 32
N = 128
K = 64


@kernel()
def matmul_nz2dn_transpose_store_kernel(x: GMTensor, y: GMTensor, zt: GMTensor, m: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=m, n=N, k=K, is_init=True)
        zt[:, :] <<= l0c.T          # NZ2DN: zt is [N, M] = (x @ y^T)^T
    return zt


def _force_single_core():
    """Force block_dim=1 so CANNSIM simulates one AI core (much faster). The DSL
    otherwise hardcodes 32 for 950; validation-only, does not touch the repo."""
    import easyasc.kernelbase.kernelbase as kb
    kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda device_type: 1)


if __name__ == "__main__":
    import os
    import sys

    import torch

    torch.manual_seed(0)
    x = torch.randn((M, K), dtype=torch.float32)
    y = torch.randn((N, K), dtype=torch.float32)
    zt = torch.zeros((N, M), dtype=torch.float32)

    if "--cannsim" in sys.argv[1:]:
        base = os.environ.get("NZ2DN_BASE", "./tmp/a5_nz2dn_cannsim")
        cann = os.environ.get("ASCEND_HOME_PATH") or ""
        _force_single_core()
        zt_kernel = OpExec(matmul_nz2dn_transpose_store_kernel, simulator=False, cannsim=True,
                           cann_path=cann, custom_op_path=os.path.join(base, "custom_opp"),
                           out_dir=base)(x, y, zt, M)
    else:
        zt_kernel = OpExec(matmul_nz2dn_transpose_store_kernel, simulator=True)(x, y, zt, M)
    zt_ref = (x @ y.t()).t().contiguous()          # [N, M]
    torch.testing.assert_close(zt_kernel, zt_ref, rtol=1e-4, atol=1e-4)
    print(f"max_abs_diff={torch.abs(zt_kernel - zt_ref).max().item():.6e}")
