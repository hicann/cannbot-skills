"""SIMT atomic add scatter: out = init; out[i % BINS] += x[i].

This is a small a5 sample for GM-side SIMT atomics.  The output tensor is
intentionally treated as an accumulator: the first SIMT call copies `init`
into `out`, and the second call atomically adds one or more source values into
a shared bin.

Important trap: inside a SIMT body, `simt_block_idx()` is the cube/core id
(`GetCubeIdx()` identity), not the global vec id.  A kernel call still runs on
both vec subblocks per core, so GM-wide sharding must use a global vec id:

1. pass `GetSubBlockIdx()` and compute
   `vec_idx = simt_block_idx() * 2 + sub_block_idx` inside SIMT; or
2. pass `GetVecIdx()` / `GetVecNum()` from the outer kernel and consume them
   directly inside SIMT.

Both variants are shown below.  Do not shard GM atomics directly with
`simt_block_idx()` / `simt_block_num()` unless you intentionally want one
logical SIMT block per cube core rather than per vec participant.

Run by default through the in-process simulator
(`OpExec(..., simulator=True)`).  Pass `--cannsim` on the command line
to switch to the CANNSIM hardware-simulation path instead.
"""

import sys

from easyasc.a5 import *


SHAPE_BINDINGS = {
    0: [0],  # x[N]
    1: [1],  # init[BINS]
    2: [1],  # out[BINS]
}


@simt(num_threads=256)
def copy_bins_from_subblock_simt(
    init: GMTensor, out: GMTensor, bins: Var, sub_block_idx: Var
):
    vec_idx = simt_block_idx() * 2 + sub_block_idx
    vec_num = simt_block_num() * 2
    base = vec_idx * simt_thread_num() + simt_thread_id()
    stride = vec_num * simt_thread_num()
    for i in range(base, bins, stride):
        out[i] = init[i]


@simt(num_threads=256)
def atomic_add_scatter_from_subblock_simt(
    x: GMTensor, out: GMTensor, n: Var, bins: Var, sub_block_idx: Var
):
    vec_idx = simt_block_idx() * 2 + sub_block_idx
    vec_num = simt_block_num() * 2
    base = vec_idx * simt_thread_num() + simt_thread_id()
    stride = vec_num * simt_thread_num()
    for i in range(base, n, stride):
        dst = i % bins
        simt_atomic_add(out[dst], x[i])


@simt(num_threads=256)
def copy_bins_from_vec_idx_simt(
    init: GMTensor, out: GMTensor, bins: Var, vec_idx: Var, vec_num: Var
):
    base = vec_idx * simt_thread_num() + simt_thread_id()
    stride = vec_num * simt_thread_num()
    for i in range(base, bins, stride):
        out[i] = init[i]


@simt(num_threads=256)
def atomic_add_scatter_from_vec_idx_simt(
    x: GMTensor, out: GMTensor, n: Var, bins: Var, vec_idx: Var, vec_num: Var
):
    base = vec_idx * simt_thread_num() + simt_thread_id()
    stride = vec_num * simt_thread_num()
    for i in range(base, n, stride):
        dst = i % bins
        simt_atomic_add(out[dst], x[i])


@kernel()
def simt_atomic_add_kernel(
    x: GMTensor, init: GMTensor, out: GMTensor, N: Var, BINS: Var
):
    with auto_sync():
        sub_block_idx = GetSubBlockIdx()
        copy_bins_from_subblock_simt(init, out, BINS, sub_block_idx)
        # Make the GM initialization visible to every vec block before atomics.
        allvec_ready(0, pipe=Pipe.V)
        allvec_wait(0, pipe=Pipe.V)
        atomic_add_scatter_from_subblock_simt(x, out, N, BINS, sub_block_idx)
    return out


@kernel()
def simt_atomic_add_vecidx_kernel(
    x: GMTensor, init: GMTensor, out: GMTensor, N: Var, BINS: Var
):
    with auto_sync():
        vec_idx = GetVecIdx()
        vec_num = GetVecNum()
        copy_bins_from_vec_idx_simt(init, out, BINS, vec_idx, vec_num)
        # Make the GM initialization visible to every vec block before atomics.
        allvec_ready(0, pipe=Pipe.V)
        allvec_wait(0, pipe=Pipe.V)
        atomic_add_scatter_from_vec_idx_simt(x, out, N, BINS, vec_idx, vec_num)
    return out


if __name__ == "__main__":
    import torch

    use_cannsim = "--cannsim" in sys.argv[1:]

    N, BINS = 4096, 128
    torch.manual_seed(0)
    x = torch.randn((N,), dtype=torch.float32)
    init = torch.full((BINS,), 1.0, dtype=torch.float32)
    out = torch.empty((BINS,), dtype=torch.float32)

    if use_cannsim:
        actual_from_subblock = OpExec(
            simt_atomic_add_kernel,
            out_dir="./tmp/simt_atomic_add_cannsim",
            simulator=False,
            cannsim=True,
        )(x, init, out, N, BINS, shape_bindings=SHAPE_BINDINGS)
        actual_from_vecidx = OpExec(
            simt_atomic_add_vecidx_kernel,
            out_dir="./tmp/simt_atomic_add_vecidx_cannsim",
            simulator=False,
            cannsim=True,
        )(x, init, out, N, BINS, shape_bindings=SHAPE_BINDINGS)
    else:
        actual_from_subblock = OpExec(
            simt_atomic_add_kernel,
            out_dir="./tmp/simt_atomic_add_simulator",
            simulator=True,
        )(x, init, out, N, BINS, shape_bindings=SHAPE_BINDINGS)
        actual_from_vecidx = OpExec(
            simt_atomic_add_vecidx_kernel,
            out_dir="./tmp/simt_atomic_add_vecidx_simulator",
            simulator=True,
        )(x, init, out, N, BINS, shape_bindings=SHAPE_BINDINGS)

    expected = init.clone()
    expected.scatter_add_(0, torch.arange(N, dtype=torch.int64) % BINS, x)
    torch.testing.assert_close(actual_from_subblock, expected, rtol=1e-4, atol=1e-4)
    torch.testing.assert_close(actual_from_vecidx, expected, rtol=1e-4, atol=1e-4)
    subblock_diff = torch.max(torch.abs(actual_from_subblock - expected)).item()
    vecidx_diff = torch.max(torch.abs(actual_from_vecidx - expected)).item()
    print(f"subblock_path_max_abs_diff={subblock_diff:.6e}")
    print(f"vecidx_path_max_abs_diff={vecidx_diff:.6e}")
