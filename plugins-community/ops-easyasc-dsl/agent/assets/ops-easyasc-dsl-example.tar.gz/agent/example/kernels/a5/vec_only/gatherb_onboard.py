"""End-to-end sim + on-board validation of ub_to_reg_gatherb (MicroAPI::GatherB), the
32-byte DataBlock gather.

Board-verified semantics (2026-07-21, gatherb_probe): output DataBlock i (the i-th 32B
slice of dst) is the 32B block at ``src`` byte offset ``index[i]``, where index[i] is read
from index-reg LANE i (uint32, >=0, 32B-aligned). Covered widths: b8/b16/b32/b64. The index
is a host GM input (int, reinterpret->uint32), lanes 0..7 = a block permutation * 32 bytes.

Run:
- simulator (default): python kernels/a5/vec_only/gatherb_onboard.py
- on Ascend950 board:   python kernels/a5/vec_only/gatherb_onboard.py --run
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

_PICKS = [11, 3, 15, 0, 8, 5, 14, 7]  # source-block index for out-block 0..7 (16-block src)


@vf()
def gatherb_b8_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint32, name="gb8_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.int8, name="gb8_d")
    ub_to_reg_gatherb(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gatherb_b8_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.int8, [1, 512], Position.UB, name="gb8_src")   # 16 blocks (32B = 32 int8)
    dst_ub = Tensor(DT.int8, [1, 256], Position.UB, name="gb8_dst")   # 8 blocks
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="gb8_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="gb8_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gatherb_b8_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gatherb_b16_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint32, name="gb16_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.half, name="gb16_d")
    ub_to_reg_gatherb(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gatherb_b16_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.half, [1, 256], Position.UB, name="gb16_src")  # 16 blocks (32B = 16 half)
    dst_ub = Tensor(DT.half, [1, 128], Position.UB, name="gb16_dst")  # 8 blocks
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="gb16_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="gb16_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gatherb_b16_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gatherb_b32_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint32, name="gb32_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.int, name="gb32_d")
    ub_to_reg_gatherb(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gatherb_b32_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.int, [1, 128], Position.UB, name="gb32_src")   # 16 blocks (32B = 8 int32)
    dst_ub = Tensor(DT.int, [1, 64], Position.UB, name="gb32_dst")    # 8 blocks
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="gb32_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="gb32_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gatherb_b32_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gatherb_b64_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint32, name="gb64_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.int64, name="gb64_d")
    ub_to_reg_gatherb(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gatherb_b64_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.int64, [1, 64], Position.UB, name="gb64_src")  # 16 blocks (32B = 4 int64)
    dst_ub = Tensor(DT.int64, [1, 32], Position.UB, name="gb64_dst")  # 8 blocks
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="gb64_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="gb64_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gatherb_b64_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


# --------------------------------------------------------------------------- #
def _idx_tensor(block_elems):
    # index[i] (lane i) = byte offset of out-block i = _PICKS[i] * 32 bytes; rest 0.
    idx = torch.zeros(1, 64, dtype=torch.int32)
    idx[0, :8] = torch.tensor(_PICKS, dtype=torch.int32) * 32
    return idx


def _golden(src_row, block_elems):
    # out-block i = src-block _PICKS[i] = src[_PICKS[i]*block_elems : +block_elems]
    parts = [src_row[p * block_elems:(p + 1) * block_elems] for p in _PICKS]
    return torch.cat(parts).reshape(1, -1)


def _cases():
    cases = []
    # b32 int32
    be = 8
    s = torch.arange(128, dtype=torch.int32)
    cases.append(("gb.b32", gatherb_b32_kernel, s.reshape(1, 128), _idx_tensor(be), _golden(s, be)))
    # b16 half
    be = 16
    s = torch.arange(256, dtype=torch.float32).to(torch.float16)
    cases.append(("gb.b16", gatherb_b16_kernel, s.reshape(1, 256), _idx_tensor(be), _golden(s, be)))
    # b8 int8
    be = 32
    s = (torch.arange(512, dtype=torch.int64) % 127).to(torch.int8)
    cases.append(("gb.b8", gatherb_b8_kernel, s.reshape(1, 512), _idx_tensor(be), _golden(s, be)))
    # NOTE: b64 (gatherb_b64_kernel) is DEFERRED -- on-board it gathers only out-block 0 and
    # leaves out-block>=1 unwritten; its index-lane mapping differs from b8/b16/b32. The kernel
    # is kept above for a future isolated b64 probe.
    return cases


def _opexec(kern, tag, run):
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    safe = "".join(c if c.isalnum() else "_" for c in tag)
    return OpExec(kern, out_dir=os.path.abspath(f"tmp/gatherb/{safe}"),
                  custom_op_path=os.path.abspath("tmp/gatherb/custom_opp"), **cfg)


def _cmp(mode, tag, got, want, fails):
    got = got.reshape(-1); want = want.reshape(-1)
    if got.is_floating_point():
        ok = torch.equal(got.float(), want.float())
    else:
        ok = torch.equal(got.to(torch.int64), want.to(torch.int64))
    if ok:
        print(f"[{mode}] {tag:8s} OK")
    else:
        bad = (got.to(torch.int64) != want.to(torch.int64)).nonzero().flatten()[:6].tolist() \
            if not got.is_floating_point() else (got.float() != want.float()).nonzero().flatten()[:6].tolist()
        print(f"[{mode}] {tag:8s} MISMATCH first_bad={bad} got[:8]={got[:8].tolist()} want[:8]={want[:8].tolist()}")
        fails.append(tag)


def main(run, only=None):
    mode = "board" if run else "sim"
    fails, build = [], []
    cases = _cases()
    if only:
        cases = [c for c in cases if c[0] == only]
        if not cases:
            raise SystemExit(f"no case matches --only={only}")
    for tag, kern, src, idx, want in cases:
        try:
            out = torch.zeros_like(want)
            res = _opexec(kern, tag, run)(src.contiguous(), idx.contiguous(), out, 1)
            got = res if isinstance(res, torch.Tensor) else res[0]
            _cmp(mode, tag, got, want, fails)
        except Exception as exc:  # noqa: BLE001
            print(f"[{mode}] {tag:8s} BUILD/RUN-FAIL: {type(exc).__name__}: {str(exc)[:200]}")
            build.append(tag)
    ok = len(cases) - len(fails) - len(build)
    print(f"\n[{mode}] summary: {ok}/{len(cases)} exact; mismatch={fails or '-'}; build/run-fail={build or '-'}")
    if fails or build:
        raise AssertionError(f"gatherb {mode}: mismatch={fails} build_fail={build}")
    print(f"[{mode}] ALL {len(cases)} GatherB width cases match the golden")


if __name__ == "__main__":
    _run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1"
    _only = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--only=")), None)
    main(_run, only=_only)
