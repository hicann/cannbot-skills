from easyasc.a2 import *

# First MLA implementation for flattened head-major inputs:
# q_*: [HQ * S, D], k_*/v: [HKV * SKV, D], out: [HQ * S, D_NOPE].

TILE_M = 128
TILE_N = 128
TILE_D = 128
HALF_M = TILE_M // 2
HALF_N = TILE_N // 2
# D=512 is handled as four 128-column chunks; one vec sub-block's 64 rows fit in UB.
ACCUM_ROWS = HALF_M

HQ = 8
HKV = 4
Q_PER_KV = HQ // HKV
D_NOPE = 512
D_ROPE = 64
NEG_LARGE = -1.0e30


@func()
def build_suffix_invalid_mask(valid_cols: Var, out_mask: Var):
    signed_mask = Var(-1, DT.int64)
    two_i64 = Var(2, DT.int64)
    for _ in range(0, valid_cols):
        signed_mask <<= signed_mask * two_i64
    out_mask <<= signed_mask


@func()
def mask_score_half_suffix_invalid(score_half: Tensor, valid_cols: Var):
    if valid_cols == 0:
        dup(score_half, NEG_LARGE)
    elif valid_cols < HALF_N:
        suffix_mask = Var(0, DT.uint64)
        build_suffix_invalid_mask(valid_cols, suffix_mask)
        set_mask(0, suffix_mask)
        dup(score_half, NEG_LARGE)
        reset_mask()


@func()
def apply_score_tail_mask(ub_score: Tensor, valid_n: Var):
    left_valid = Min(valid_n, HALF_N)
    right_valid = Max(valid_n - HALF_N, 0)
    mask_score_half_suffix_invalid(ub_score[0:HALF_M, 0:HALF_N], left_valid)
    mask_score_half_suffix_invalid(ub_score[0:HALF_M, HALF_N:TILE_N], right_valid)


@func()
def apply_score_row_tail_mask_after_shift(ub_score: Tensor, valid_rows: Var):
    if valid_rows == 0:
        dup(ub_score, NEG_LARGE)
    elif valid_rows < HALF_M:
        dup(ub_score[valid_rows:HALF_M, 0:TILE_N], NEG_LARGE)


@kernel()
def mla_b1_hq8_hkv4_kernel(
    q_nope: GMTensor,
    q_rope: GMTensor,
    k_nope: GMTensor,
    k_rope: GMTensor,
    v: GMTensor,
    out: GMTensor,
    S: Var,
    SKV: Var,
    scale: Var,
):
    score_ws = split_workspace(DT.float, [GetCubeNum(), 2, TILE_M, TILE_N], name="score_ws")
    p_ws = split_workspace(DT.half, [GetCubeNum(), 2, TILE_M, TILE_N], name="p_ws")
    pv_ws = split_workspace(DT.float, [GetCubeNum(), 2, TILE_M, TILE_D], name="pv_ws")
    accum_ws = split_workspace(DT.float, [GetCubeNum(), 2, D_NOPE // TILE_D, TILE_M, TILE_D], name="accum_ws")

    l1qn = QBuff(DT.half, [TILE_M, TILE_D], Position.L1)
    l1kn = QBuff(DT.half, [TILE_N, TILE_D], Position.L1)
    l1qr = DBuff(DT.half, [TILE_M, D_ROPE], Position.L1)
    l1kr = DBuff(DT.half, [TILE_N, D_ROPE], Position.L1)
    l1p = DBuff(DT.half, [TILE_M, TILE_N], Position.L1)
    l1v = QBuff(DT.half, [TILE_N, TILE_D], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)

    ub_score = DBuff(DT.float, [HALF_M, TILE_N], Position.UB)
    ub_pv = Tensor(DT.float, [ACCUM_ROWS, TILE_D], Position.UB)
    ub_accum = Tensor(DT.float, [ACCUM_ROWS, TILE_D], Position.UB)
    ub_tmp = Tensor(DT.float, [HALF_M, HALF_N], Position.UB)
    ub_max_s = Tensor(DT.float, [1, HALF_M], Position.UB)
    ub_rmax_s = Tensor(DT.float, [1, HALF_M], Position.UB)
    ub_sum_s = Tensor(DT.float, [1, HALF_M], Position.UB)
    ub_rsum_s = Tensor(DT.float, [1, HALF_M], Position.UB)
    ub_zero_s = Tensor(DT.float, [1, HALF_M], Position.UB)
    ub_max = Tensor(DT.float, [HALF_M, 8], Position.UB)
    ub_rowsum = Tensor(DT.float, [ACCUM_ROWS, 8], Position.UB)
    ub_expdiff = Tensor(DT.float, [ACCUM_ROWS, 8], Position.UB)
    ub_p = DBuff(DT.half, [HALF_M, TILE_N], Position.UB)
    expdiff_buf = DBuff(DT.float, [1, HALF_M], Position.UB)

    accum_store_ready = SEvent(Pipe.V, Pipe.MTE3, name="accum_store_ready")
    accum_store_valid = SEvent(Pipe.MTE3, Pipe.V, preset=True, name="accum_store_valid")
    accum_store_done = SEvent(Pipe.MTE3, Pipe.MTE2, name="accum_store_done")
    accum_ws_valid = SEvent(Pipe.MTE3, Pipe.MTE2, name="accum_ws_valid")

    qk_mutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.MTE2)
    p_mutex = VcMutex(1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE2)
    pv_mutex = CvMutex(2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.MTE2)

    l1qk_cnt = Var(0)
    l1pv_cnt = Var(0)
    l1v_cnt = Var(0)
    l0c_cnt = Var(0)
    stage1_cnt = Var(0)
    stage2_cnt = Var(0)

    cube_idx = GetCubeIdx()
    sb = GetSubBlockIdx()
    sb_row = Var(sb * HALF_M)

    tiles_m = CeilDiv(S, TILE_M)
    tiles_n = CeilDiv(SKV, TILE_N)
    total_m = Var(HQ * tiles_m)
    per_core = CeilDiv(total_m, GetCubeNum())
    mt_begin = Var(per_core * cube_idx)
    mt_end = Min(mt_begin + per_core, total_m)

    for gmt in range(mt_begin, mt_end):
        hq = Var(gmt // tiles_m)
        lmt = Var(gmt % tiles_m)
        kvh = Var(hq // Q_PER_KV)
        q_row = Var(hq * S + lmt * TILE_M)
        kv_base = Var(kvh * SKV)
        valid_m = Min(TILE_M, S - lmt * TILE_M)
        local_valid_m = Min(HALF_M, Max(valid_m - sb_row, 0))

        accum_store_valid.wait()
        dup(ub_rmax_s, NEG_LARGE)
        dup(ub_rsum_s, 0.0)
        dup(ub_zero_s, 0.0)
        accum_cnt = Var(0)

        for ni in range(0, tiles_n + 1):
            if ni < tiles_n:
                with auto_sync():
                    n_off = Var(ni * TILE_N)
                    kv_row = Var(kv_base + n_off)
                    valid_n = Min(TILE_N, SKV - n_off)
                    stage1_slot = var_mod(stage1_cnt, 2)
                    ub_score_tile = ub_score[stage1_cnt]
                    ub_p_tile = ub_p[stage1_cnt]

                    l1qn[l1qk_cnt] <<= q_nope[q_row:q_row + valid_m, 0:TILE_D]
                    l1kn[l1qk_cnt] <<= k_nope[kv_row:kv_row + valid_n, 0:TILE_D]
                    matmul(l0c[l0c_cnt], l1qn[l1qk_cnt], l1kn[l1qk_cnt], is_init=True)
                    bar_m()
                    l1qk_cnt += 1

                    for doff in range(TILE_D, D_NOPE, TILE_D):
                        l1qn[l1qk_cnt] <<= q_nope[q_row:q_row + valid_m, doff:doff + TILE_D]
                        l1kn[l1qk_cnt] <<= k_nope[kv_row:kv_row + valid_n, doff:doff + TILE_D]
                        matmul(l0c[l0c_cnt], l1qn[l1qk_cnt], l1kn[l1qk_cnt], is_init=False)
                        bar_m()
                        l1qk_cnt += 1

                    l1qr[l1qk_cnt] <<= q_rope[q_row:q_row + valid_m, 0:D_ROPE]
                    l1kr[l1qk_cnt] <<= k_rope[kv_row:kv_row + valid_n, 0:D_ROPE]
                    matmul(l0c[l0c_cnt], l1qr[l1qk_cnt], l1kr[l1qk_cnt], is_init=False)
                    bar_m()
                    l1qk_cnt += 1

                    qk_mutex.lock()
                    score_ws[cube_idx, stage1_slot, 0:TILE_M, 0:TILE_N] <<= l0c[l0c_cnt]
                    qk_mutex.ready()

                    qk_mutex.wait()
                    ub_score_tile <<= score_ws[cube_idx, stage1_slot, sb_row:sb_row + HALF_M, 0:TILE_N]

                    muls(ub_score_tile, ub_score_tile, scale)
                    if valid_n < TILE_N:
                        apply_score_tail_mask(ub_score_tile, valid_n)
                    vmax(ub_tmp, ub_score_tile[0:HALF_M, 0:HALF_N], ub_score_tile[0:HALF_M, HALF_N:TILE_N])
                    cmax(ub_max_s, ub_tmp)

                    add(expdiff_buf[stage1_slot], ub_rmax_s, ub_zero_s)
                    vmax(ub_rmax_s, ub_rmax_s, ub_max_s)
                    sub(expdiff_buf[stage1_slot], expdiff_buf[stage1_slot], ub_rmax_s)
                    exp(expdiff_buf[stage1_slot], expdiff_buf[stage1_slot])

                    brcb(ub_max, ub_rmax_s, repeat=HALF_M // 8, dst_blk_stride=1, dst_rep_stride=8)
                    sub(ub_score_tile[0:HALF_M, 0:HALF_N], ub_score_tile[0:HALF_M, 0:HALF_N], ub_max)
                    sub(ub_score_tile[0:HALF_M, HALF_N:TILE_N], ub_score_tile[0:HALF_M, HALF_N:TILE_N], ub_max)
                    if local_valid_m < HALF_M:
                        apply_score_row_tail_mask_after_shift(ub_score_tile, local_valid_m)

                    exp(ub_score_tile, ub_score_tile)
                    add(ub_tmp, ub_score_tile[0:HALF_M, 0:HALF_N], ub_score_tile[0:HALF_M, HALF_N:TILE_N])
                    cadd(ub_sum_s, ub_tmp)
                    mul(ub_rsum_s, ub_rsum_s, expdiff_buf[stage1_slot])
                    add(ub_rsum_s, ub_rsum_s, ub_sum_s)

                    cast(ub_p_tile, ub_score_tile)

                    p_mutex.lock()
                    p_ws[cube_idx, stage1_slot, sb_row:sb_row + HALF_M, 0:TILE_N] <<= ub_p_tile
                    p_mutex.ready()
                    qk_mutex.free()

                    l0c_cnt += 1
                    stage1_cnt += 1

            if ni > 0:
                with auto_sync():
                    prev_nt = Var(ni - 1)
                    prev_n_off = Var(prev_nt * TILE_N)
                    prev_valid_n = Min(TILE_N, SKV - prev_n_off)
                    stage2_slot = var_mod(stage2_cnt, 2)
                    accum_read_slot = var_mod(accum_cnt, 2)
                    accum_write_slot = var_mod(accum_cnt + 1, 2)
                    v_row = Var(kv_base + prev_n_off)

                    p_mutex.wait()
                    l1p[l1pv_cnt] <<= p_ws[cube_idx, stage2_slot, 0:TILE_M, 0:TILE_N]
                    p_mutex.free()
                    if accum_cnt > 0:
                        accum_ws_valid.wait()

                    for doff in range(0, D_NOPE, TILE_D):
                        dchunk = Var(doff // TILE_D)
                        pv_slot = var_mod(l1v_cnt, 2)
                        l1v[l1v_cnt] <<= v[v_row:v_row + prev_valid_n, doff:doff + TILE_D]
                        matmul(l0c[l0c_cnt], l1p[l1pv_cnt], l1v[l1v_cnt].T, is_init=True)

                        pv_mutex.lock()
                        pv_ws[cube_idx, pv_slot, 0:TILE_M, 0:TILE_D] <<= l0c[l0c_cnt]
                        pv_mutex.ready()

                        pv_mutex.wait()
                        for row8 in range(0, HALF_M, ACCUM_ROWS):
                            acc_row = Var(sb_row + row8)
                            ub_pv <<= pv_ws[cube_idx, pv_slot, acc_row:acc_row + ACCUM_ROWS, 0:TILE_D]
                            if accum_cnt == 0:
                                dup(ub_accum, 0.0)
                            else:
                                ub_accum <<= accum_ws[
                                    cube_idx,
                                    accum_read_slot,
                                    dchunk,
                                    acc_row:acc_row + ACCUM_ROWS,
                                    0:TILE_D,
                                ]
                            bar_mte2()

                            brcb(
                                ub_expdiff,
                                expdiff_buf[stage2_slot][0:1, row8:row8 + ACCUM_ROWS],
                                repeat=ACCUM_ROWS // 8,
                                dst_blk_stride=1,
                                dst_rep_stride=8,
                            )
                            mul(ub_accum[0:ACCUM_ROWS, 0:HALF_N], ub_accum[0:ACCUM_ROWS, 0:HALF_N], ub_expdiff)
                            mul(ub_accum[0:ACCUM_ROWS, HALF_N:TILE_D], ub_accum[0:ACCUM_ROWS, HALF_N:TILE_D], ub_expdiff)
                            add(ub_accum, ub_accum, ub_pv)
                            accum_store_ready.set()
                            accum_store_ready.wait()
                            accum_ws[cube_idx, accum_write_slot, dchunk, acc_row:acc_row + ACCUM_ROWS, 0:TILE_D] <<= ub_accum
                            accum_store_done.set()
                            accum_store_done.wait()
                        pv_mutex.free()

                        l1v_cnt += 1
                        l0c_cnt += 1

                    accum_ws_valid.set()
                    l1pv_cnt += 1
                    accum_cnt += 1
                    stage2_cnt += 1

        with auto_sync():
            final_accum_slot = var_mod(accum_cnt, 2)
            if accum_cnt > 0:
                accum_ws_valid.wait()
            for doff in range(0, D_NOPE, TILE_D):
                dchunk = Var(doff // TILE_D)
                for row8 in range(0, HALF_M, ACCUM_ROWS):
                    acc_row = Var(sb_row + row8)
                    row_valid = Min(ACCUM_ROWS, Max(local_valid_m - row8, 0))
                    ub_accum <<= accum_ws[cube_idx, final_accum_slot, dchunk, acc_row:acc_row + ACCUM_ROWS, 0:TILE_D]
                    bar_mte2()
                    brcb(
                        ub_rowsum,
                        ub_rsum_s[0:1, row8:row8 + ACCUM_ROWS],
                        repeat=ACCUM_ROWS // 8,
                        dst_blk_stride=1,
                        dst_rep_stride=8,
                    )
                    div(ub_accum[0:ACCUM_ROWS, 0:HALF_N], ub_accum[0:ACCUM_ROWS, 0:HALF_N], ub_rowsum)
                    div(ub_accum[0:ACCUM_ROWS, HALF_N:TILE_D], ub_accum[0:ACCUM_ROWS, HALF_N:TILE_D], ub_rowsum)
                    if row_valid > 0:
                        out_row = Var(q_row + acc_row)
                        accum_store_ready.set()
                        accum_store_ready.wait()
                        out[out_row:out_row + row_valid, doff:doff + TILE_D] <<= ub_accum[0:row_valid, 0:TILE_D]
                        accum_store_done.set()
                        accum_store_done.wait()
        accum_store_valid.set()

    return out


def _ref_mla_streaming(q_nope, q_rope, k_nope, k_rope, v, scale_value=-1.0):
    import builtins
    import math
    import torch

    B, S, Hq, d_nope = q_nope.shape
    d_rope = q_rope.shape[-1]
    Skv = k_nope.shape[1]
    Hkv = k_nope.shape[2]
    groups = Hq // Hkv
    if scale_value <= 0:
        scale_value = 1.0 / math.sqrt(d_nope + d_rope)

    qn = q_nope.float().transpose(1, 2)
    qr = q_rope.float().transpose(1, 2)
    kn = k_nope.float().transpose(1, 2)
    kr = k_rope.float().transpose(1, 2)
    vf = v.float().transpose(1, 2)

    kn = kn.unsqueeze(2).expand(B, Hkv, groups, Skv, d_nope).reshape(B, Hq, Skv, d_nope)
    kr = kr.unsqueeze(2).expand(B, Hkv, groups, Skv, d_rope).reshape(B, Hq, Skv, d_rope)
    vf = vf.unsqueeze(2).expand(B, Hkv, groups, Skv, d_nope).reshape(B, Hq, Skv, d_nope)

    row_max = torch.full((B, Hq, S, 1), NEG_LARGE, dtype=torch.float32)
    row_sum = torch.zeros(B, Hq, S, 1, dtype=torch.float32)
    out = torch.zeros(B, Hq, S, d_nope, dtype=torch.float32)

    for j in builtins.range(0, Skv, TILE_N):
        kn_blk = kn[:, :, j:j + TILE_N, :]
        kr_blk = kr[:, :, j:j + TILE_N, :]
        v_blk = vf[:, :, j:j + TILE_N, :]
        score_j = torch.matmul(qn, kn_blk.transpose(-2, -1))
        score_j = score_j + torch.matmul(qr, kr_blk.transpose(-2, -1))
        score_j = score_j * scale_value

        max_j = score_j.max(dim=-1, keepdim=True).values
        curr_max = torch.maximum(row_max, max_j)
        expdiff = torch.exp(row_max - curr_max)
        row_max = curr_max

        p_j = torch.exp(score_j - row_max)
        row_sum = row_sum * expdiff + p_j.sum(dim=-1, keepdim=True)
        pv_j = torch.matmul(p_j.half().float(), v_blk)
        out = out * expdiff + pv_j

    return (out / row_sum).transpose(1, 2)


if __name__ == "__main__":
    import math
    import os
    import sys
    import torch
    from easyasc.simulator import SimulatorConfig

    torch.manual_seed(42)
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"
    full = "--full" in sys.argv[1:] or os.environ.get("EASYASC_MLA_FULL_SHAPE") == "1"

    def run_case(S_value, SKV_value):
        q_nope = torch.randn(1, S_value, HQ, D_NOPE, dtype=torch.float16)
        q_rope = torch.randn(1, S_value, HQ, D_ROPE, dtype=torch.float16)
        k_nope = torch.randn(1, SKV_value, HKV, D_NOPE, dtype=torch.float16)
        k_rope = torch.randn(1, SKV_value, HKV, D_ROPE, dtype=torch.float16)
        v = k_nope.clone()
        scale_value = 1.0 / math.sqrt(D_NOPE + D_ROPE)
        out_ref = _ref_mla_streaming(q_nope, q_rope, k_nope, k_rope, v, scale_value)

        qn_flat = q_nope.permute(0, 2, 1, 3).reshape(HQ * S_value, D_NOPE).contiguous()
        qr_flat = q_rope.permute(0, 2, 1, 3).reshape(HQ * S_value, D_ROPE).contiguous()
        kn_flat = k_nope.permute(0, 2, 1, 3).reshape(HKV * SKV_value, D_NOPE).contiguous()
        kr_flat = k_rope.permute(0, 2, 1, 3).reshape(HKV * SKV_value, D_ROPE).contiguous()
        v_flat = v.permute(0, 2, 1, 3).reshape(HKV * SKV_value, D_NOPE).contiguous()
        out_flat = torch.zeros(HQ * S_value, D_NOPE, dtype=torch.float32)

        if run:
            out_kernel = OpExec(
                mla_b1_hq8_hkv4_kernel,
                simulator=False,
                debug=True,
                out_dir="./tmp/mla_b1_hq8_hkv4",
                cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
            )(qn_flat, qr_flat, kn_flat, kr_flat, v_flat, out_flat, S_value, SKV_value, scale_value)
        else:
            saved_sim_config = getattr(mla_b1_hq8_hkv4_kernel, "_simulator_config", None)
            mla_b1_hq8_hkv4_kernel._simulator_config = SimulatorConfig(
                core_count=20,
                execution_timeout_s=300.0,
            )
            try:
                out_kernel = OpExec(mla_b1_hq8_hkv4_kernel, simulator=True)(
                    qn_flat, qr_flat, kn_flat, kr_flat, v_flat, out_flat, S_value, SKV_value, scale_value
                )
            finally:
                if saved_sim_config is None:
                    try:
                        delattr(mla_b1_hq8_hkv4_kernel, "_simulator_config")
                    except AttributeError:
                        pass
                else:
                    mla_b1_hq8_hkv4_kernel._simulator_config = saved_sim_config

        out_kernel = out_kernel.reshape(1, HQ, S_value, D_NOPE).transpose(1, 2).contiguous()
        torch.testing.assert_close(out_kernel, out_ref, rtol=2e-2, atol=2e-2)
        print(
            f"shape=(B=1,HQ={HQ},HKV={HKV},S={S_value},SKV={SKV_value},"
            f"nope={D_NOPE},rope={D_ROPE}): "
            f"max_abs_diff={torch.abs(out_kernel - out_ref).max().item():.6e}",
            flush=True,
        )

    shapes = ((128, 256), (257, 260))
    if full:
        shapes = ((1025, 2060),)
    for case in shapes:
        run_case(*case)
