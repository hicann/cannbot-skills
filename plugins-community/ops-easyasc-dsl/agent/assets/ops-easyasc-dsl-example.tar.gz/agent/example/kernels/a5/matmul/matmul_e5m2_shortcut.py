from easyasc.a5 import *


@kernel()
def matmul_e5m2_shortcut_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x = Tensor(DT.e5m2, [M, K], Position.L1)
    l1y = Tensor(DT.e5m2, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)

    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c
    return z


if __name__ == "__main__":
    import torch

    if not hasattr(torch, "float8_e5m2"):
        raise RuntimeError("Current torch build does not support torch.float8_e5m2")

    # K follows float8 C0=32 alignment for cleaner simulator behavior.
    M = 64
    N = 48
    K = 32

    torch.manual_seed(0)
    x = torch.randn((M, K), dtype=torch.float32).to(torch.float8_e5m2)
    y = torch.randn((N, K), dtype=torch.float32).to(torch.float8_e5m2)
    z = torch.zeros((M, N), dtype=torch.float32)

    z_kernel = OpExec(matmul_e5m2_shortcut_kernel, simulator=True)(x, y, z, M, N, K)
    z_ref = x.float() @ y.float().t()
    torch.testing.assert_close(z_kernel, z_ref, rtol=5e-2, atol=1e-1)
    print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
