"""Step 3: conv2d compute kernel via load3d img2col (a2 cube, fp16 -> fp32 NZ).

data [C1*HP*W, C0]    5HD from step 1 (zero pad rows baked, HP = H + 4)
wz   [COUT, K]        fractal ND from step 2, staged once via nd2nz <<=
out  [C1O*M, C0]      NZ fp32, M = HO*WO

Per output row ho: the dilated 5-row input window starts at HP-row ho*2, so
each conv2d call sees a 5-row plane (h=5, pad=(2,2,0,0)) producing exactly
1 x WO outputs (m0 = 0, tile_m = WO); K accumulates fully inside conv2d
(TILE_K = 96, 6 tiles). 20 cores split the ho loop strided; fm DBuff reloads
the 5-row window each iteration (stride-2 windows overlap 3 rows but the
reload keeps the loop body uniform).

  PYTHONPATH=<repo> python conv_compute.py            # python simulator
  PYTHONPATH=<repo> python conv_compute.py --debug    # 910B3 standalone
"""
from easyasc.a2 import *

from common import (B, C0, C1, C1O, CIN, COUT, DEBUG, DIL, H, HO, HP, K, KH, KW,
                    M, N_CUBE, PAD, STRIDE, TILE_K, W, WO)

ROWS = DIL * (KH - 1) + 1               # 5 input rows per output row


@kernel()
def conv_compute(data: GMTensor, wz: GMTensor, out: GMTensor, nc: Var):
    # nc is only the mandatory Var arg; the gate uses static N_CUBE.
    conv = Conv2D(KH, KW, pad=(PAD, PAD, 0, 0), stride=(STRIDE, STRIDE),
                  dilation=(DIL, DIL))
    w_l1 = Tensor(DT.half, [COUT, K], Position.L1)
    # contiguous per-core ho block (not a strided gate): consecutive iterations
    # alternate DBuff slots, which is the assumption behind the per-DBuff
    # depth-2 DEvent credits; the double buffers overlap the next fm load and
    # the previous NZ store with the current mmad.
    fm = DBuff(DT.half, [C1 * ROWS * W, C0], Position.L1)
    l0c = DBuff(DT.float, [WO, COUT], Position.L0C)
    cube_idx = GetCubeIdx()
    per_core = (HO + N_CUBE - 1) // N_CUBE
    begin = per_core * cube_idx
    end = Min(begin + per_core, HO)
    with auto_sync():
        w_l1 <<= wz[:, :]
        for ho in range(begin, end):
            f = fm[ho]
            lc = l0c[ho]
            gm_to_l1(f, data[ho * STRIDE * W:, :],
                     n_burst=C1, burst_len=ROWS * W,
                     src_stride=(HP - ROWS) * W, dst_stride=0)
            conv2d(lc, f, w_l1, conv, h=ROWS, w=W, c=CIN, cout=COUT,
                   m0=0, tile_k=TILE_K)
            l0c_to_gm_nz2nz(out[ho * WO:ho * WO + WO, :], lc, m_pad=M)
    return out


if __name__ == "__main__":
    import torch

    torch.manual_seed(9)
    x = torch.randn((B, CIN, H, W), dtype=torch.float16)
    w = torch.randn((COUT, CIN, KH, KW), dtype=torch.float16)
    xp = torch.nn.functional.pad(x, (0, 0, PAD, PAD))
    data = torch.from_numpy(pack_nc1hwc0(xp.numpy()))
    wz = torch.from_numpy(pack_conv_weight(w.numpy()))
    out = torch.zeros((C1O * M, C0), dtype=torch.float32)
    ref = torch.nn.functional.conv2d(x.float(), w.float(), padding=PAD,
                                     stride=STRIDE, dilation=DIL)
    ref = ref.reshape(COUT, M).t()
    got = OpExec(conv_compute, simulator=not DEBUG, debug=DEBUG)(data, wz, out, N_CUBE)
    got = got.reshape(C1O, M, C0).permute(1, 0, 2).reshape(M, COUT)   # NZ -> ND
    torch.testing.assert_close(got, ref, rtol=3e-3, atol=3e-3)
    print("conv_compute {}x{}x{}x{} max_abs_diff={:.6e}".format(
        B, CIN, H, W, float((got - ref).abs().max())))
