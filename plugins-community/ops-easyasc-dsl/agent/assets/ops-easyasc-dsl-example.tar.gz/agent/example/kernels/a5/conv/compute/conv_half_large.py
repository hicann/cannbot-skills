"""fp16 large-shape conv2d via load3d img2col on a5: the bring-up large case.

Same spec as kernels/a2/conv/compute/conv_half_large.py, ported to a5. Logical conv:
x [N, 32, 64, 64] * w [64, 32, 4, 4], pads (l, r, t, b) = (1, 2, 1, 2) (same-pad,
even filter). The kernel owns the per-batch fmap reload (static plane stride, Var
batch count) and the NZ store; conv2d() covers L1 -> L0 -> mmad -> L0C only
(multi-K-tile inside: K=512 -> 2x256). On a5, l1_to_l0a_img2col loops the C0
K-chunks internally (load3d has no k_dst_stride). The GetCubeIdx==0 gate keeps the
core split single-effective here (MULTICORE=1); other cores idle, no double-write.

In simulator mode the spatial size shrinks (the python golden is slow at M=4096);
--run runs the full 64x64 shape on a real Ascend950.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python conv_half_large.py          # python simulator (16x16)
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python conv_half_large.py --run     # full 64x64 on a real Ascend950
"""
import sys

from easyasc.a5 import *

C0 = 16
RUN = "--run" in sys.argv[1:]
KH = KW = 4
PAD = (1, 2, 1, 2)                      # asymmetric same-pad for even filter
TILE_M = 32
TILE_K = 256
MULTICORE = 1
# static worst-case capacities (full batch/plane this binary serves)
NB_MAX = 2
C_MAX, COUT_MAX = 32, 64
H_MAX = W_MAX = 64 if RUN else 16
C1_MAX = (C_MAX + C0 - 1) // C0
K_MAX = C1_MAX * KH * KW * C0          # 512 -> two 256 K-tiles
M_PAD_MAX = (H_MAX * W_MAX + 15) // 16 * 16      # same-pad keeps HoxWo == HxW
COUT_P = (COUT_MAX + 15) // 16 * 16
C1O = COUT_P // C0
FM_PLANE = C1_MAX * H_MAX * W_MAX      # static per-batch fmap stride (GM rows)


@kernel()
def conv_half_large(data: GMTensor, weight: GMTensor, out: GMTensor,
                    h: Var, w: Var, c: Var, cout: Var, m_pad: Var, nb: Var):
    conv = Conv2D(KH, KW, pad=PAD)
    w_l1 = Tensor(DT.half, [COUT_P, K_MAX], Position.L1)
    fm = Tensor(DT.half, [FM_PLANE, C0], Position.L1)
    l0c = Tensor(DT.float, [TILE_M, COUT_P], Position.L0C)
    cube_idx = GetCubeIdx()
    with auto_sync():
        w_l1 <<= weight[:, :]
        for n in range(nb):                             # weight stays resident; fmap reloads
            fm <<= data[n * FM_PLANE:n * FM_PLANE + FM_PLANE, :]
            for m0 in range(0, m_pad, TILE_M):
                with If(cube_idx == (m0 // TILE_M) % MULTICORE):
                    conv2d(l0c, fm, w_l1, conv, h=h, w=w, c=c, cout=cout,
                           m0=m0, tile_k=TILE_K)
                    row0 = n * C1O * m_pad + m0
                    l0c_to_gm_nz2nz(out[row0:row0 + TILE_M, :], l0c, m_pad=m_pad)
    return out


if __name__ == "__main__":
    import builtins

    import torch
    from easyasc.utils.conv2d import pack_nc1hwc0, pack_conv_weight

    torch.manual_seed(3)
    N_BATCH, C, COUT = NB_MAX, C_MAX, COUT_MAX
    H = W = H_MAX if RUN else 14                         # sim: sub-cap spatial Vars
    HO, WO = H, W                                        # same-pad
    M_PAD = (HO * WO + TILE_M - 1) // TILE_M * TILE_M    # the m loop steps TILE_M
    x = torch.randn((N_BATCH, C, H, W), dtype=torch.float16)
    w = torch.randn((COUT, C, KH, KW), dtype=torch.float16)
    data = torch.zeros((N_BATCH * FM_PLANE, C0), dtype=torch.float16)
    plane = C1_MAX * H * W
    pk = torch.from_numpy(pack_nc1hwc0(x.numpy())).reshape(N_BATCH, plane, C0)
    for n in builtins.range(N_BATCH):
        data[n * FM_PLANE:n * FM_PLANE + plane] = pk[n]
    wz = torch.from_numpy(pack_conv_weight(w.numpy()))
    out = torch.zeros((N_BATCH * C1O * M_PAD, C0), dtype=torch.float32)
    ref = torch.nn.functional.conv2d(
        torch.nn.functional.pad(x.float(), PAD), w.float())
    ref = ref.reshape(N_BATCH, COUT, HO * WO).permute(0, 2, 1)

    # full-cap runtime shape: H/W/COUT collide with GM dims, bind explicitly
    # (scalars: 0=H 1=W 2=C 3=COUT 4=M_PAD 5=NB)
    got = OpExec(conv_half_large, simulator=not RUN, debug=False)(
        data, wz, out, H, W, C, COUT, M_PAD, N_BATCH,
        shape_bindings={0: (None, None), 1: (3, None), 2: (None, None)})
    got = got.reshape(N_BATCH, C1O, M_PAD, C0).permute(0, 2, 1, 3)        # NZ -> ND
    got = got.reshape(N_BATCH, M_PAD, COUT_P)[:, :HO * WO]
    torch.testing.assert_close(got, ref, rtol=3e-3, atol=3e-3)
    print("conv_half_large {}x{} max_abs_diff={:.6e}".format(
        H, W, float((got - ref).abs().max())))
