"""On-board alignment for ``unsqueeze`` (MicroAPI::Unsqueeze, PrefixSumImpl).

Unsqueeze(dst, mask) is an in-place EXCLUSIVE prefix-sum of the mask bits: dst[i] = number of
active mask lanes strictly before lane i (the input dst is ignored). The mask is built on-board
via compare(sel>0). Two cases (sparse + strided) are checked against a host golden; sim and
board must both match. Board-verified 2026-07-21. --run.
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403


@vf()
def unsq_vf(val_ub, sel_ub, out_ub):
    sr = Reg(DT.int, name="uq_sr"); ub_to_reg_normal(sr, sel_ub)
    z = Reg(DT.int, name="uq_z"); dup(z, 0)
    m = MaskReg(DT.int, name="uq_m"); compare(m, sr, z, CompareMode.GT)  # active iff sel>0
    v = Reg(DT.int, name="uq_v"); ub_to_reg_normal(v, val_ub)
    unsqueeze(v, m)                                                      # in-place decompaction
    reg_to_ub_normal(out_ub, v)


@kernel(mode="vec")
def unsq_kernel(val: GMTensor, sel: GMTensor, out: GMTensor, rows: Var):
    val_ub = Tensor(DT.int, [1, 64], Position.UB, name="uq_val")
    sel_ub = Tensor(DT.int, [1, 64], Position.UB, name="uq_sel")
    out_ub = Tensor(DT.int, [1, 64], Position.UB, name="uq_out")
    with auto_sync():
        val_ub[:, :] <<= val[0:1, :]
        sel_ub[:, :] <<= sel[0:1, :]
        unsq_vf(val_ub, sel_ub, out_ub)
        out[0:1, :] <<= out_ub
    return out


def _golden(active):
    # exclusive prefix-sum of the mask bits: g[i] = # active lanes strictly before i
    mask = torch.zeros(64, dtype=torch.int64)
    mask[active] = 1
    g = torch.zeros(64, dtype=torch.int32)
    g[1:] = torch.cumsum(mask, dim=0)[:-1].to(torch.int32)
    return g


def _run_case(active, run, tag):
    val = torch.zeros(1, 64, dtype=torch.int32)
    val[0, :len(active)] = torch.arange(len(active), dtype=torch.int32) * 7 + 11  # ignored by op
    sel = torch.zeros(1, 64, dtype=torch.int32)
    sel[0, active] = 1
    out = torch.zeros(1, 64, dtype=torch.int32)
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    res = OpExec(unsq_kernel, out_dir=os.path.abspath(f"tmp/unsqueeze/{tag}"),
                 custom_op_path=os.path.abspath("tmp/unsqueeze/opp"),
                 **cfg)(val.contiguous(), sel.contiguous(), out, 1)
    got = (res if isinstance(res, torch.Tensor) else res[0]).reshape(-1)
    golden = _golden(active)
    ok = torch.equal(got.to(torch.int32), golden)
    print(f"{tag}: match={ok}")
    if not ok:
        print(f"  active={active}")
        print(f"  got   ={got.to(torch.int64).tolist()}")
        print(f"  golden={golden.to(torch.int64).tolist()}")
    return ok


def main(run):
    ok = True
    ok &= _run_case([1, 3, 4], run, "sparse")
    ok &= _run_case([0, 2, 4, 6, 8, 10], run, "strided")
    print("ALL_OK" if ok else "MISMATCH")


if __name__ == "__main__":
    main("--run" in sys.argv[1:])
