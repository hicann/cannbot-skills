"""V7 all-hif8 GQA prefill — v6's all-hif8 compute grafted onto fd_modified.py's stream-K +
Flash-Decode HOST-METADATA schedule (kernels/a5/attention/pfa_replicate/fd_modified.py format).

Compute (from pfa_fd_v6_allhif8.py):
  * QK-hif8 matmul (K@Q^T -> transposed score^T [key,query]) -> ln16-biased online softmax
    (single-weight new-max; P = 16*exp(s-m) stored in hif8, the x16 self-cancels via rsum/PV in
    O=acc/rsum) -> NZ-direct P-store (3-deep deinterleave 4-key pack + strided reg_to_ub + 4 bulk
    ub_to_l1_nz) -> PV-hif8 matmul -> flash-decode merge across split m-blocks -> bf16 out.

Schedule (from fd_modified.py):
  * Stream-K: host build_metadata() precomputes per-core flat [flat_start,flat_end) intervals over
    the flat (m-block-major, s2-tile-inner) task grid + FD workspace assignment, passed as int32 GM
    tensors (fa_meta/fd_meta), read in-kernel via Var.GetValueFrom. The kernel is core-count agnostic
    (GetCubeNum() drives it); only the host metadata is target-aware: a5pr (28 cores) uses the FIA
    section-17 cost-aware table (fia_intervals); a5 (32 cores) uses staggered stream-K (== fd_modified fia32).
  * Flash-Decode: the 2 cores owning a split m-block write fp32 partial (unnormalized O / row-max /
    row-sum) to GM workspace (WAR-safe via copy_partial_vf -> dodges the ring-index clobber that hits
    the 28-core FIA shape), then an AIV-wide barrier + 2 merge lanes per split block recombine -> out.

Single-batch MQA/GQA (Hk=1): M = Hq*Sq contiguous query rows, K/V = [S2,D] shared. EASYASC_TARGET
selects a5pr|a5.

# --- run ---
#   PV_SELFTEST=1 PYTHONPATH=. python kernels/a5/attention/pfa/v7_allhif8.py            # metadata self-test
#   PYTHONPATH=. python kernels/a5/attention/pfa/v7_allhif8.py                          # dev sim (Hq8/Sq257/Skv256)
#   PV_META=fia PYTHONPATH=. python kernels/a5/attention/pfa/v7_allhif8.py              # fia sim (Hq8/S4099, 28c/32)
#   PV_MODE=hw PV_META=fia PYTHONPATH=. python kernels/a5/attention/pfa/v7_allhif8.py   # fia hw (950 board)
#   PV_MODE=cannsim PV_META=fia PYTHONPATH=. python kernels/a5/attention/pfa/v7_allhif8.py
"""
import builtins
import math
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5pr") == "a5":
    from easyasc.a5 import *  # cannsim uses -s Ascend950 (a5); a5/a5pr differ only in device_type + core_num
else:
    from easyasc.a5pr import *
from easyasc.simulator.config import SimulatorConfig
# fp32_to_hif8 / hif8_to_fp32 (easyasc.dtypehelper.hif8_codec) come in via the a5pr/a5 wildcard above.

_pyrange = builtins.range

# ---- shape / compute constants ----
TILE_M = 128
TILE_N = 128
D_HEAD = 128
ROWS_PER_SB = TILE_M // 2       # 64 vec sub-block query rows (query is the LANE axis after transpose)
QLANES = ROWS_PER_SB
CHUNKS_D = D_HEAD // 64         # 2 fp32 regs cover a 128-col D row
CD = CHUNKS_D
M_Q = QLANES
UNROLL = 4
RB_MAX = TILE_N // UNROLL       # 32: max-pass over 128 keys, 4-way unrolled partial-max chains
SOFTMAX_SCALE = 1.0 / math.sqrt(D_HEAD)
LN16 = math.log(16.0)          # exp-max bias: P=exp(s-(m-ln16))=16*exp(s-m); x16 threads rsum+acc, cancels in O
NEG_LARGE = -1.0e30

PRELOAD_N = int(os.environ.get("PV_PRELOAD_N", "2"))   # QK-PV pipeline depth (FIA lag-2); CACHE tracks it
CACHE = PRELOAD_N + 1
_CacheBuf = QBuff if CACHE >= 4 else TBuff             # l1 K/V/P + softmax-state depth tracks CACHE (TBuff@3, QBuff@4)
MAX_CORE_COUNT = 32

# ---- nz4 ("deinterleave 4-key") hif8 NZ P-store constants ----
NZ_C0 = 32                  # hif8 C0 (32-byte fractal inner dim)
SLAB = TILE_N // 4          # 32 keys per slab (4 slabs across TILE_N)
FRAC_STRIDE4 = SLAB + 1     # 33 -- M_src (NZ fractal row stride), +1 pad row/fractal (bank-conflict dodge)
KEYS_PER_GRP = 4            # 4 keys packed per register via the 3-deep deinterleave tree
RB4 = 16                    # rb count for the pack loop (RB4*UNROLL4 = 32 = SLAB M-rows)
UNROLL4 = 2                 # unroll(2), 4 keys/iter (throughput-bound; higher unroll gave no speedup)
_DEINT_U8 = False           # hif8-native deinterleave; flip True if board rejects hif8 (uint8 reinterpret)

# ---- host metadata field layouts (1-D int32 GM tensors) ----
FA_NF = 6     # per-core:      [enable, flat_start, flat_end, tail_ws, head_ws, pad]
FD_NF = 6     # per-AIV-lane:  [enable, m_idx, ws_lo, ws_hi, row0, nrows]
NWS_GLOBAL = 1   # workspace slot count (= 2 * num_fd_tasks); set by main() before tracing

# Physical AIC core count of the selected device (globvars.core_num): a5=32, a5pr=28. The kernel is
# metadata-driven (GetCubeNum() == DEVICE_CORES at runtime), so ONLY the host metadata generator is
# target-aware -- fa_meta/fd_meta must have exactly DEVICE_CORES / 2*DEVICE_CORES rows. The `fia` shape
# uses the official section-17 cost-aware 28-core table on a5pr; on a5 (32 cores, no official table) it
# falls back to staggered near-even stream-K (== fd_modified fia32; the cheap 24-row M-tail block is
# spread task-wise, ~negligible skew).
DEVICE_CORES = 32 if os.environ.get("EASYASC_TARGET", "a5pr") == "a5" else 28

# ---- section-17 exact 28-core FIA split (m-block-major, s2-inner), for tiles_n = 33 ----
FA_START_M = [0, 9, 18, 27, 36, 45, 54, 64, 73, 82, 91, 100, 109, 119, 128, 137, 146,
              155, 164, 173, 183, 192, 201, 210, 219, 228, 238, 247]
FA_START_N = [0, 5, 10, 15, 20, 25, 30, 2, 7, 12, 17, 22, 27, 0, 5, 10, 15, 21, 26, 32,
              5, 10, 15, 21, 26, 32, 5, 10]
FA_END_M = [9, 18, 27, 36, 45, 54, 64, 73, 82, 91, 100, 109, 119, 128, 137, 146, 155,
            164, 173, 183, 192, 201, 210, 219, 228, 238, 247, 257]
FA_END_N = [5, 10, 15, 20, 25, 30, 2, 7, 12, 17, 22, 27, 0, 5, 10, 15, 21, 26, 32, 5,
            10, 15, 21, 26, 32, 5, 10, 0]
SEC17_FD_M_IDX = [9, 18, 27, 36, 45, 54, 64, 73, 82, 91, 100, 109, 128, 137, 146, 155,
                  164, 173, 183, 192, 201, 210, 219, 228, 238, 247]
SEC17_FIRST_FD_WS = [0, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 24, 25, 27, 29, 31,
                     33, 35, 37, 39, 41, 43, 45, 47, 49, 51]
FIA_TILES_M = 257
FIA_TILES_N = 33


# ============================ host metadata generator ============================
def fia_intervals(tiles_n):
    """Section-17 per-core flat [start, end) intervals (m-major, s2-inner)."""
    n = len(FA_START_M)
    out = []
    for c in _pyrange(n):
        fs = FA_START_M[c] * tiles_n + FA_START_N[c]
        if c < n - 1:
            fe = FA_END_M[c] * tiles_n + FA_END_N[c]
        else:
            fe = FIA_TILES_M * tiles_n          # last core ends at the very end (bn2=1)
        out.append((fs, fe))
    return out


def even_intervals(total, num_cores):
    """Generic contiguous near-even flat split (fallback; may land on block edges)."""
    base = total // num_cores
    rem = total % num_cores
    out = []
    cur = 0
    for c in _pyrange(num_cores):
        cnt = base + (1 if c < rem else 0)
        out.append((cur, cur + cnt))
        cur += cnt
    return out


def staggered_intervals(total, num_cores, tiles_n):
    """Dev split that deliberately nudges interior boundaries OFF block edges so at least some
    m-blocks are s2-split across cores (exercises the Flash-Decode merge path)."""
    bounds = [0]
    for c in _pyrange(1, num_cores):
        b = total * c // num_cores
        if 0 < b < total and b % tiles_n == 0:        # on a block edge -> nudge to force a split
            b += 1
        bounds.append(b)
    bounds.append(total)
    return [(bounds[i], bounds[i + 1]) for i in _pyrange(num_cores)]


def even_mblock_intervals(tiles_m, tiles_n, num_cores):
    """Whole-m-block even split: each core owns WHOLE m-blocks (flat_start % tiles_n == 0) -> NO
    s2-split -> NO Flash-Decode. Extra m-blocks (rem) go to the LAST cores."""
    base = tiles_m // num_cores
    rem = tiles_m % num_cores
    out = []
    cur = 0
    for c in _pyrange(num_cores):
        cnt = base + (1 if c >= num_cores - rem else 0)
        out.append((cur * tiles_n, (cur + cnt) * tiles_n))
        cur += cnt
    return out


def build_metadata(tiles_m, tiles_n, intervals, M, launch_cores=None):
    """Turn per-core flat intervals into (fa_meta, fd_meta, nws, fd_blocks).

    A block mb is *split* iff some core starts strictly inside it (flat_start % tiles_n != 0). FD tasks
    are the sorted split blocks; task j uses workspace slots 2j (head / lower-s2 piece, written by the
    core whose range ENDS at mb) and 2j+1 (tail / upper-s2 piece, written by the core whose range STARTS
    at mb). Merge is symmetric so head/tail order does not affect correctness.

    launch_cores: AIC cores the board launches (= GetCubeNum, 32 for 950). The work split may use FEWER
    cores (e.g. FIA's 28-core split on a 32-core board); extra cores are emitted DISABLED so they no-op
    the FA loop but still join the AIV-wide FD barrier."""
    num_work = len(intervals)
    if launch_cores is None:
        launch_cores = num_work
    if launch_cores < num_work:
        raise ValueError(f"launch_cores {launch_cores} < work cores {num_work}")
    split_blocks = sorted({fs // tiles_n for (fs, fe) in intervals
                           if fs < fe and fs % tiles_n != 0})
    blk_to_task = {mb: j for j, mb in enumerate(split_blocks)}
    nws = 2 * len(split_blocks)

    fa = []
    for c in _pyrange(launch_cores):
        if c >= num_work:
            fa.append([0, 0, 0, -1, -1, 0])         # launched-but-idle core
            continue
        fs, fe = intervals[c]
        if fs >= fe:
            fa.append([0, 0, 0, -1, -1, 0])
            continue
        start_m, start_n = fs // tiles_n, fs % tiles_n
        end_m_excl, end_n_excl = fe // tiles_n, fe % tiles_n
        tail_ws, head_ws = -1, -1
        if start_n != 0:                       # first block is the TAIL piece -> 2j+1
            tail_ws = 2 * blk_to_task[start_m] + 1
        if end_n_excl != 0:                    # last block is the HEAD piece -> 2j
            head_ws = 2 * blk_to_task[end_m_excl]
            if start_n != 0 and start_m == end_m_excl:
                raise ValueError(f"3-way split of block {start_m} not supported")
        fa.append([1, fs, fe, tail_ws, head_ws, 0])

    fd = []
    for aiv in _pyrange(launch_cores * 2):
        task, row0 = aiv // 2, (aiv % 2) * ROWS_PER_SB
        if task < len(split_blocks):
            mb = split_blocks[task]
            nrows = min(ROWS_PER_SB, M - (mb * TILE_M + row0))
            fd.append([1, mb, 2 * task, 2 * task + 1, row0, nrows] if nrows > 0
                      else [0, 0, 0, 0, 0, 0])
        else:
            fd.append([0, 0, 0, 0, 0, 0])
    return fa, fd, max(1, nws), split_blocks


def _selftest():
    """Reproduce section-17 FD_M_IDX + first_fd_ws from build_metadata."""
    iv = fia_intervals(FIA_TILES_N)
    fa, fd, nws, blocks = build_metadata(FIA_TILES_M, FIA_TILES_N, iv, FIA_TILES_M * TILE_M)
    assert blocks == SEC17_FD_M_IDX, f"FD blocks mismatch:\n got {blocks}\n exp {SEC17_FD_M_IDX}"
    assert nws == 52, f"nws {nws} != 52"
    derived = []
    for c, row in enumerate(fa):
        _, _, _, tail_ws, head_ws, _ = row
        used = [w for w in (tail_ws, head_ws) if w >= 0]
        derived.append(min(used) if used else -1)
    assert derived == SEC17_FIRST_FD_WS, f"first_fd_ws mismatch:\n got {derived}\n exp {SEC17_FIRST_FD_WS}"
    total = FIA_TILES_M * FIA_TILES_N
    cover = []
    for (fs, fe) in iv:
        cover.extend(_pyrange(fs, fe))
    assert cover == list(_pyrange(total)), "interval cover is not a contiguous partition"
    assert sum(r[0] for r in fd) == 52, f"fd enabled lanes {sum(r[0] for r in fd)} != 52"
    print(f"[selftest PASS] fia: tiles_m={FIA_TILES_M} tiles_n={FIA_TILES_N} cores=28 "
          f"fd_tasks={len(blocks)} nws={nws} fd_lanes=52")

    fa32, fd32, nws32, _ = build_metadata(FIA_TILES_M, FIA_TILES_N, iv, FIA_TILES_M * TILE_M, launch_cores=32)
    assert len(fa32) == 32 and len(fd32) == 64, (len(fa32), len(fd32))
    assert fa32[:28] == fa, "padded fa changed the 28 work rows"
    assert all(r == [0, 0, 0, -1, -1, 0] for r in fa32[28:]), fa32[28:]
    assert sum(r[0] for r in fd32) == 52, sum(r[0] for r in fd32)
    assert nws32 == 52, nws32
    print(f"[selftest PASS] fia pad: launch=32 work=28 idle=4 fd_lanes(active)=52/64")

    # a5 (32-core, EASYASC_TARGET=a5): staggered near-even stream-K over the fia grid (== fd_modified fia32).
    iv_a5 = staggered_intervals(FIA_TILES_M * FIA_TILES_N, 32, FIA_TILES_N)
    fa_a5, fd_a5, nws_a5, blk_a5 = build_metadata(FIA_TILES_M, FIA_TILES_N, iv_a5, FIA_TILES_M * TILE_M, launch_cores=32)
    cover_a5 = []
    for (fs, fe) in iv_a5:
        cover_a5.extend(_pyrange(fs, fe))
    assert cover_a5 == list(_pyrange(FIA_TILES_M * FIA_TILES_N)), "a5 32-core cover is not a contiguous partition"
    assert len(fa_a5) == 32 and len(fd_a5) == 64, (len(fa_a5), len(fd_a5))
    assert sum(r[0] for r in fa_a5) == 32, "all 32 a5 cores should be enabled (work == launch)"
    assert sum(r[0] for r in fd_a5) == 2 * len(blk_a5), "fd enabled lanes != 2*fd_tasks"
    print(f"[selftest PASS] a5 32-core staggered: work=32 fd_tasks={len(blk_a5)} nws={nws_a5}")

    iv3 = [(0, 4), (4, 7), (7, 9)]
    fa3, fd3, nws3, blk3 = build_metadata(3, 3, iv3, 3 * TILE_M)
    assert blk3 == [1, 2], blk3
    assert nws3 == 4, nws3
    assert fa3[0][3:5] == [-1, 0], fa3[0]       # core0: head m1 -> ws0
    assert fa3[1][3:5] == [1, 2], fa3[1]        # core1: tail m1 -> ws1, head m2 -> ws2
    assert fa3[2][3:5] == [3, -1], fa3[2]       # core2: tail m2 -> ws3
    assert [r[0] for r in fd3] == [1, 1, 1, 1, 0, 0], fd3
    print(f"[selftest PASS] dev: cores=3 fd_tasks={len(blk3)} nws={nws3}")


# ============================ vec stages (all-hif8, from pfa_fd_v6_allhif8.py) ============================
def _deint(d0, d1, s0, s1):
    if _DEINT_U8:
        deinterleave(d0.reinterpret(DT.uint8), d1.reinterpret(DT.uint8),
                     s0.reinterpret(DT.uint8), s1.reinterpret(DT.uint8))
    else:
        deinterleave(d0, d1, s0, s1)


@vf()
def init_softmax_state_vf(ub_rmax: Tensor, ub_rsum: Tensor):
    """rowmax=-inf, rowsum=0 for one m-block's running softmax state (64-wide)."""
    neg = Reg(DT.float); zero = Reg(DT.float)
    neg <<= NEG_LARGE; zero <<= 0.0
    ub_rmax[0:1, 0:QLANES] <<= neg
    ub_rsum[0:1, 0:QLANES] <<= zero


@vf()
def softmax_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    """TRANSPOSED online softmax over [key=128, query=64] score^T, single-weight (new-max) with ln16
    exp-bias -> hif8 P scaled x16. NZ-direct P-store: 4 keys/reg via a 3-deep deinterleave tree
    (fin=[k0|k1|k2|k3] dense, 256 lanes) + one strided reg_to_ub(blk_stride=33); key kk lands in
    fractals 2kk,2kk+1 at M-row m; store is 4 bulk UB2L1_NZ (one 32-key slab each)."""
    sreg = RegList(DT.float, UNROLL); acc = RegList(DT.float, UNROLL); preg = RegList(DT.float, UNROLL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_i")
    neg = Reg(DT.float); block_max = Reg(DT.float); block_sum = Reg(DT.float); t = Reg(DT.float)
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="mx"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_score[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    muls(block_max, block_max, SOFTMAX_SCALE)        # scale the max ONCE (max(scale*s)=scale*max(s))
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)                   # old_scale = exp(old_m - new_m)
    v_nmax_e = Reg(DT.float)
    adds(v_nmax_e, v_nmax, -LN16)                    # exp-only x16 bias; stored/compared running max stays true
    # exp + nz4 pack: reuse acc[] (free after block_max) as the 4 per-slab running sums.
    for kk in _pyrange(KEYS_PER_GRP):
        acc[kk] <<= 0.0
    hh = RegList(DT.hif8, KEYS_PER_GRP)              # 4 cast'd keys (stride-4 sparse, RegLayout.ZERO)
    a = Reg(DT.hif8); b = Reg(DT.hif8); fin = Reg(DT.hif8); dmy = Reg(DT.hif8)
    for rb in range(RB4, name="ex"):
        for u in unroll(UNROLL4):
            for kk in _pyrange(KEYS_PER_GRP):
                row = (rb * UNROLL4 + u) + kk * SLAB          # key m + kk*32
                sreg[0] <<= ub_score[row:row + 1, :]
                muls(sreg[0], sreg[0], SOFTMAX_SCALE)
                expsub(preg[0], sreg[0], v_nmax_e)   # = 16 * exp(s - nmax): rsum (acc) and hif8 P both carry x16
                acc[kk] <<= acc[kk] + preg[0]
                cast(hh[kk], preg[0], cfg_i)
            _deint(a,   dmy, hh[0], hh[1])
            _deint(b,   dmy, hh[2], hh[3])
            _deint(fin, dmy, a,     b)
            reg_to_ub(ub_p[(rb * UNROLL4 + u) * NZ_C0], fin, FRAC_STRIDE4)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum                    # block_sum already exp'd vs new_m -> no blkw
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                    ub_old_weight: Tensor, valid_n: Var):
    """TRANSPOSED softmax for a PARTIAL K-tile (valid_n < TILE_N): invalid key ROWS (n >= valid_n) are
    select()'d to NEG so they drop out of the max and give P=0. Same ln16 x16 bias. nz4 tail pack uses
    gather (hif8-native, unlike sim-only Squeeze). Nested DSL loops (g=slab, m=row) keep it LOOPED (not
    128x-unrolled) and compute the slab base with multiplies only (no var_div) -> no AIV VF stack spill."""
    s = Reg(DT.float); e = Reg(DT.float); neg = Reg(DT.float)
    block_max = Reg(DT.float); block_sum = Reg(DT.float); p_hif8 = Reg(DT.hif8)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dp = Reg(DT.hif8)
    g8 = Reg(DT.int8); arange(g8, 0); shiftls(g8, g8, 2)
    gidx = g8.reinterpret(DT.uint8)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="p_hif8_tail_i")
    v_pmax = Reg(DT.float); v_nmax = Reg(DT.float); v_oldw = Reg(DT.float)
    v_psum = Reg(DT.float); v_nsum = Reg(DT.float)
    block_max <<= NEG_LARGE
    neg <<= NEG_LARGE
    for n in range(TILE_N):
        cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)   # QLANES if n<valid_n else 0
        s <<= ub_score[n:n + 1, :]
        s <<= s * SOFTMAX_SCALE
        update_mask(rowmask, cnt_n)
        select(s, s, neg, mask=rowmask)                  # invalid key-row -> all-NEG -> excluded from max
        block_max <<= block_max.vmax(s)
    v_pmax <<= ub_rmax[0:1, 0:QLANES]
    v_nmax <<= block_max.vmax(v_pmax)
    expsub(v_oldw, v_pmax, v_nmax)
    v_nmax_e = Reg(DT.float)
    adds(v_nmax_e, v_nmax, -LN16)                        # exp-only x16 bias (same as softmax_vf)
    block_sum <<= 0.0
    _SLAB_STRIDE = 2 * FRAC_STRIDE4 * NZ_C0              # 2112 = 2 fractals * 33 * 32
    for g in range(KEYS_PER_GRP, name="tg"):
        for m in range(SLAB, name="tm"):
            n = g * SLAB + m
            cnt_n = Var(QLANES * Min(Max(valid_n - n, 0), 1), dtype=DT.uint32)
            s <<= ub_score[n:n + 1, :]
            s <<= s * SOFTMAX_SCALE
            update_mask(rowmask, cnt_n)
            select(s, s, neg, mask=rowmask)
            expsub(e, s, v_nmax_e)   # = 16 * exp(s - nmax)
            block_sum <<= block_sum + e
            cast(p_hif8, e, cfg_i)
            gather(dp, p_hif8, gidx)
            reg_to_ub(ub_p[g * _SLAB_STRIDE + m * NZ_C0], dp, FRAC_STRIDE4, mask=qmask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:QLANES]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:QLANES] <<= v_nmax
    ub_rsum[0:1, 0:QLANES] <<= v_nsum
    ub_old_weight[0:1, 0:QLANES] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_pv_vf(ub_accum: Tensor, ub_pv: Tensor, ub_old_weight: Tensor):
    """Single-weight online rescale O = O*old_scale + PV, fused via muldstadd (dst = dst*src0 + src1).
    P is already exp'd against the running max in softmax -> PV needs NO block weight. Rows unrolled by
    UNROLL to overlap per-row load->FMA->store; each row is CHUNKS_D 64-lane fp32 regs."""
    acc = RegList(DT.float, UNROLL * CHUNKS_D); pv = RegList(DT.float, UNROLL * CHUNKS_D)
    ow = RegList(DT.float, UNROLL)
    for rb in range(ROWS_PER_SB // UNROLL, name="arow"):
        for u in unroll(UNROLL):
            r = rb * UNROLL + u
            ow[u] <<= ub_old_weight[0:1, r:r + 1].single()
            for c in _pyrange(CHUNKS_D):
                k = u * CHUNKS_D + c
                acc[k] <<= ub_accum[r:r + 1, c * 64:(c + 1) * 64]
                pv[k] <<= ub_pv[r:r + 1, c * 64:(c + 1) * 64]
                muldstadd(acc[k], ow[u], pv[k])
                ub_accum[r:r + 1, c * 64:(c + 1) * 64] <<= acc[k]
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_pv_first_vf(ub_accum: Tensor, ub_pv: Tensor):
    """First owned K-tile of an m-block: O = PV (no prior O to rescale; P already exp'd vs new_m).
    Writes all ROWS_PER_SB rows -> ub_accum is fully initialized (no separate zero pass needed)."""
    pv = RegList(DT.float, CHUNKS_D)
    for r in range(ROWS_PER_SB):
        pv <<= ub_pv[r:r + 1, 0:D_HEAD]
        ub_accum[r:r + 1, 0:D_HEAD] <<= pv
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def final_div_cast_bf16_vf(ub_accum: Tensor, ub_rsum: Tensor, ub_out: Tensor):
    """out = accum / rowsum; bf16 cast on store. For non-split (fully owned) m-blocks. The x16 from the
    ln16 bias is carried by BOTH accum and rsum, so it cancels here (no explicit /16)."""
    acc = RegList(DT.float, CHUNKS_D); rsum = Reg(DT.float)
    for r in range(ROWS_PER_SB):
        rsum <<= ub_rsum[0:1, r:r + 1].single()
        acc <<= ub_accum[r:r + 1, 0:D_HEAD]
        acc <<= acc / rsum
        ub_out[r:r + 1, 0:D_HEAD] <<= acc
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def copy_partial_vf(dst_a: Tensor, dst_m: Tensor, dst_s: Tensor,
                    src_a: Tensor, src_m: Tensor, src_s: Tensor):
    """Capture the FD partial state (accum / row-max / row-sum) into DEDICATED fixed buffers via VEC
    reads, BEFORE the GM workspace store. A later m-block's init_softmax_state / accum_pv clobbers the
    ring source buffers (ub_rmax[mt%CACHE]) / single ub_accum; routing through a vec read makes that a
    vec-vec WAR on a fixed buffer (auto_sync tracks it -> the clobber is ordered after this read), and
    the MTE3 store then reads the stable copy. Root fix for the 28-core FIA FD partial-clobber (the
    runtime-ring-index WAR the autosync tracker misses)."""
    mv = Reg(DT.float); sv = Reg(DT.float)
    mv <<= src_m[0:1, 0:ROWS_PER_SB]
    dst_m[0:1, 0:ROWS_PER_SB] <<= mv
    sv <<= src_s[0:1, 0:ROWS_PER_SB]
    dst_s[0:1, 0:ROWS_PER_SB] <<= sv
    a = RegList(DT.float, CD)
    for r in range(ROWS_PER_SB, name="cprow"):
        a <<= src_a[r:r + 1, :]
        dst_a[r:r + 1, :] <<= a
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def fd_merge_vf(ub_o0: Tensor, ub_o1: Tensor, ub_m0: Tensor, ub_m1: Tensor,
                ub_s0: Tensor, ub_s1: Tensor, ub_A: Tensor, ub_den: Tensor, ub_merged: Tensor):
    """2-split merge + normalize, LEAN (== max-aware): A=exp(m0-m1), den_eff=s0*A+s1 precomputed
    VECTORIZED over the 64 query lanes; main loop O=(o0*A+o1)/den_eff per row. The x16 bias cancels
    (den_eff carries it, o0/o1 carry it)."""
    m0v = Reg(DT.float); m1v = Reg(DT.float); s0v = Reg(DT.float); s1v = Reg(DT.float)
    Av = Reg(DT.float); denv = Reg(DT.float)
    m0v <<= ub_m0[0:1, 0:M_Q]; m1v <<= ub_m1[0:1, 0:M_Q]
    s0v <<= ub_s0[0:1, 0:M_Q]; s1v <<= ub_s1[0:1, 0:M_Q]
    expsub(Av, m0v, m1v)                          # A = exp(m0 - m1)
    denv <<= s0v * Av
    denv <<= denv + s1v                           # den_eff = s0*A + s1
    ub_A[0:1, 0:M_Q] <<= Av
    ub_den[0:1, 0:M_Q] <<= denv
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    o0 = RegList(DT.float, CD); o1 = RegList(DT.float, CD); Ar = Reg(DT.float); dr = Reg(DT.float)
    for r in range(M_Q, name="row"):
        Ar <<= ub_A[0:1, r:r + 1].single()
        dr <<= ub_den[0:1, r:r + 1].single()
        o0 <<= ub_o0[r:r + 1, :]
        o1 <<= ub_o1[r:r + 1, :]
        o0 <<= o0 * Ar
        o0 <<= o0 + o1
        o0 <<= o0 / dr
        ub_merged[r:r + 1, :] <<= o0                # O = (o0*A + o1)/den_eff (fp32)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def output_cast_vf(ub_merged: Tensor, ub_out: Tensor):
    """fp32 merged O -> bf16, per D-chunk, downsample-pack store."""
    regs = RegList(DT.float, CD); hregs = RegList(DT.bfloat16, CD)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="fd_o_bf16")
    for r in range(M_Q, name="crow"):
        regs <<= ub_merged[r:r + 1, :]
        for c in unroll(CD):
            cast(hregs[c], regs[c], cfg)
            reg_to_ub_downsample(ub_out[r:r + 1, c * 64:(c + 1) * 64], hregs[c])
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ============================ kernel ============================
@kernel()
def v7_allhif8_kernel(q: GMTensor, k: GMTensor, v: GMTensor,
                      fa_meta: GMTensor, fd_meta: GMTensor, out: GMTensor,
                      M: Var, S2: Var, D: Var, scale: Var, tiles_n: Var):
    # Compact sync: start_pipe == end_pipe so each side's wait sits on the SAME pipe as its set (FIA's
    # intra-block handoff). QK/PV C<->V mutexes + a FORWARD-only L1-P ring (VcMutex); flag 7 = AIV-wide
    # Flash-Decode barrier (allvec == SyncAll). `scale` arg is unused (VFs use the SOFTMAX_SCALE const).
    cv = CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                 src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)          # AIC->AIV BMM1
    pv_mutex = CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)   # AIC->AIV BMM2
    p_mutex = VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)  # L1-P ring (vec->cube)

    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")
    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)          # P^T [key=128, query=128], per sub-block
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)         # QK^T [key, query]
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)   # score^T per sub-block [key=128, query=64]
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [FRAC_STRIDE4, KEYS_PER_GRP * ROWS_PER_SB], Position.UB)   # [33,256] NZ, M_src=33
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)
    # dedicated FD-partial capture buffers (fixed, NOT ring-indexed): WAR-safe partial store
    ub_accum_pfx = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_rmax_pfx = Tensor(DT.float, [1, QLANES], Position.UB)
    ub_rsum_pfx = Tensor(DT.float, [1, QLANES], Position.UB)
    # Flash-Decode partial workspace (fp32). NWS_GLOBAL baked per config (= 2 * num_fd_tasks).
    fd_accum = split_workspace(DT.float, [NWS_GLOBAL, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [NWS_GLOBAL, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [NWS_GLOBAL, 1, TILE_M], name="fd_sum")

    core = Var(GetCubeIdx())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)

    # --- per-core stream-K metadata (GetValueFrom, ace_v13 pattern) ---
    fa_base = Var(core * FA_NF)
    flat_start = Var(0, DT.int); flat_start.GetValueFrom(fa_meta[fa_base + 1:fa_base + 2])
    flat_end = Var(0, DT.int); flat_end.GetValueFrom(fa_meta[fa_base + 2:fa_base + 3])
    tail_ws = Var(0, DT.int); tail_ws.GetValueFrom(fa_meta[fa_base + 3:fa_base + 4])
    head_ws = Var(0, DT.int); head_ws.GetValueFrom(fa_meta[fa_base + 4:fa_base + 5])
    num_tasks = Var(Max(flat_end - flat_start, 0))
    first_block_m = Var(flat_start // tiles_n)
    last_block_m = Var((flat_end - 1) // tiles_n)

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)   # zero-pad V -> full-k PV matmul (P=0 for tail keys)

    with auto_sync():
        for step in range(0, num_tasks + PRELOAD_N):
            # ===== current task: BMM1 -> ln16 softmax -> nz4 P-NZ -> L1 =====
            if step < num_tasks:
                t = Var(flat_start + step)
                mt = Var(t // tiles_n)
                kt = Var(t % tiles_n)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)
                q_row = Var(mt * TILE_M)
                valid_m = Min(TILE_M, M - q_row)
                n_off = Var(kt * TILE_N)
                valid_n = Min(TILE_N, S2 - n_off)

                if kt == 0 or step == 0:                    # m-block start (may begin mid-s2)
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_row:q_row + valid_m, 0:D]
                    init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[n_off:n_off + valid_n, 0:D]
                # transposed QK: score^T = K @ Q^T -> l0c [key=TILE_N, query=TILE_M]
                matmul(l0c_qk[step], l1k[step], l1q[qm], m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                # SPLITN: split the query (free) axis 64+64 across the 2 AIV sub-blocks; fp32->fp32 (cheap fixpipe)
                l0c_to_ub(ub_score[step], l0c_qk[step][0:TILE_N, 0:TILE_M],
                          M=TILE_N, N=TILE_M, N_dst=ROWS_PER_SB, M_src=TILE_N,
                          dual_mode=DualMode.SPLITN, sub_block_id=0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:                        # tail K-tile: mask invalid key ROWS -> P=0
                    softmax_tail_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step], valid_n)
                else:
                    softmax_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])
                cv.free()

                # publish P^T into l1p: 4 nz4 slabs (32 keys each) -> keys [g*32,(g+1)*32) x this sub-block's cols
                p_mutex.lock()
                for g in _pyrange(KEYS_PER_GRP):
                    l1p[step][g * SLAB:(g + 1) * SLAB, row_begin:row_begin + ROWS_PER_SB] <<= (
                        ub_p.nz()[0:SLAB, g * ROWS_PER_SB:(g + 1) * ROWS_PER_SB])
                p_mutex.ready()

            # ===== lagged task: BMM2 -> accumulate -> finalize / FD-partial =====
            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // tiles_n)
                lag_kt = Var(lag_t % tiles_n)
                sm2 = Var(lag_mt % CACHE)
                lag_q_row = Var(lag_mt * TILE_M)
                lag_valid_m = Min(TILE_M, M - lag_q_row)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, S2 - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_n0:lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                # transposed PV: O[query, D] = P @ V via BOTH .T (l1p holds P^T); full k=TILE_N (tail keys P=0)
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)   # each AIV its 64 query rows
                pv_mutex.ready()
                pv_mutex.wait()
                if lag_kt == 0 or lag == 0:                 # m-block first owned s2: O = PV (no rescale)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:                                       # O = O*old_scale + PV
                    accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == tiles_n - 1 or lag == num_tasks - 1:   # m-block last owned s2
                    if lag_mt == first_block_m and tail_ws >= 0:    # tail (upper-s2) partial: WAR-safe, no divide
                        if local_rows > 0:
                            copy_partial_vf(ub_accum_pfx, ub_rmax_pfx, ub_rsum_pfx,
                                            ub_accum, ub_rmax[sm2], ub_rsum[sm2])
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum_pfx[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax_pfx[0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum_pfx[0:1, 0:local_rows]
                    elif lag_mt == last_block_m and head_ws >= 0:   # head (lower-s2) partial: WAR-safe, no divide
                        if local_rows > 0:
                            copy_partial_vf(ub_accum_pfx, ub_rmax_pfx, ub_rsum_pfx,
                                            ub_accum, ub_rmax[sm2], ub_rsum[sm2])
                            fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum_pfx[0:local_rows, 0:D_HEAD]
                            fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax_pfx[0:1, 0:local_rows]
                            fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum_pfx[0:1, 0:local_rows]
                    else:                                           # fully owned: finalize (divide) + store
                        final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                        out_row = Var(lag_q_row + row_begin)
                        if local_rows > 0:
                            out[out_row:out_row + local_rows, 0:D] <<= ub_out[0:local_rows, 0:D]

        # every AIV lane hits the barrier so the partials are globally visible
        allvec_ready(7, Pipe.MTE3)
    allvec_wait(7, Pipe.MTE2)   # gate the merge's GM->UB partial loads (MTE2), not scalar

    # ===== Flash-Decode merge phase (AIV-only), metadata-driven per lane =====
    fd_b = Var(vec * FD_NF)
    fd_en = Var(0, DT.int); fd_en.GetValueFrom(fd_meta[fd_b + 0:fd_b + 1])
    if fd_en > 0:
        fd_m = Var(0, DT.int); fd_m.GetValueFrom(fd_meta[fd_b + 1:fd_b + 2])
        fd_lo = Var(0, DT.int); fd_lo.GetValueFrom(fd_meta[fd_b + 2:fd_b + 3])
        fd_hi = Var(0, DT.int); fd_hi.GetValueFrom(fd_meta[fd_b + 3:fd_b + 4])
        fd_row0 = Var(0, DT.int); fd_row0.GetValueFrom(fd_meta[fd_b + 4:fd_b + 5])
        fd_nrows = Var(0, DT.int); fd_nrows.GetValueFrom(fd_meta[fd_b + 5:fd_b + 6])
        out_base = Var(fd_m * TILE_M)
        with auto_sync():
            # load this lane's 64-query partial halves; merge full ROWS_PER_SB rows; cast bf16; store.
            ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
            ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
            ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
            ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
            ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
            ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
            fd_merge_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                        ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
            output_cast_vf(ub_pv[0], ub_out)
            if fd_nrows > 0:
                out[out_base + fd_row0:out_base + fd_row0 + fd_nrows, 0:D] <<= ub_out[0:fd_nrows, 0:D]
    return out


# ============================ reference / runner ============================
def _ref(q_hif8, k_hif8, v_hif8, hq, s1):
    """fp32 MQA/GQA (single KV head shared): decode hif8 -> per-head softmax(q@K^T*scale)@V -> [M, D]."""
    qf = hif8_to_fp32(q_hif8).reshape(hq, s1, D_HEAD).float()
    kf = hif8_to_fp32(k_hif8).float()          # [S2, D]
    vf = hif8_to_fp32(v_hif8).float()          # [S2, D]
    outs = []
    for h in _pyrange(hq):
        p = torch.softmax((qf[h] @ kf.t()) * SOFTMAX_SCALE, dim=-1)
        outs.append(p @ vf)
    return torch.cat(outs, dim=0)              # [M, D]


def _err(a, b):
    d = (torch.as_tensor(a).float() - torch.as_tensor(b).float()).abs()
    return d.max().item(), d.mean().item()


def _cos(a, b):
    import torch.nn.functional as F
    return F.cosine_similarity(a.reshape(1, -1).float(), b.reshape(1, -1).float(), dim=1).item()


def main():
    torch.manual_seed(0)
    mode = os.environ.get("PV_MODE", "sim")
    meta = os.environ.get("PV_META", "dev")
    hq = int(os.environ.get("PV_HQ", "8"))
    s1 = int(os.environ.get("PV_SQ", "257"))
    s2 = int(os.environ.get("PV_SKV", "256"))
    core_count = int(os.environ.get("PV_CORES", "4"))
    launch_env = os.environ.get("PV_LAUNCH", "")
    launch_cores = int(launch_env) if launch_env else None
    if os.environ.get("PV_SELFTEST", "0") == "1":
        _selftest()
        return

    global NWS_GLOBAL
    if meta in ("fia", "fia32"):
        hq, s1, s2 = 8, 4099, 4099
    M = hq * s1
    tiles_m = (M + TILE_M - 1) // TILE_M
    tiles_n = (s2 + TILE_N - 1) // TILE_N

    if meta == "fia":
        assert tiles_m == FIA_TILES_M and tiles_n == FIA_TILES_N, (tiles_m, tiles_n)
        if launch_cores is None:
            launch_cores = DEVICE_CORES               # a5pr->28 (section-17), a5->32 (staggered stream-K)
        if launch_cores == 28:
            intervals = fia_intervals(tiles_n)        # section-17 official 28-core (cost-aware: tail block last)
        else:
            # a5 (32 cores): no official cost-aware table -> staggered near-even stream-K, == fd_modified fia32
            # (block-edge nudge guarantees FD coverage; on the fia grid it never fires -> plain near-even).
            intervals = staggered_intervals(tiles_m * tiles_n, launch_cores, tiles_n)
    elif meta == "fia32":
        if launch_cores is None:
            launch_cores = DEVICE_CORES
        intervals = staggered_intervals(tiles_m * tiles_n, launch_cores, tiles_n)
    elif meta == "even":
        nc = launch_cores if launch_cores is not None else core_count
        nc = min(nc, tiles_m)
        intervals = even_mblock_intervals(tiles_m, tiles_n, nc)
    elif core_count == 1:
        intervals = [(0, tiles_m * tiles_n)]
    else:
        intervals = staggered_intervals(tiles_m * tiles_n, core_count, tiles_n)
    if launch_cores is None:
        launch_cores = len(intervals)
    core_count = launch_cores

    fa, fd, nws, blocks = build_metadata(tiles_m, tiles_n, intervals, M, launch_cores=launch_cores)
    NWS_GLOBAL = nws

    q_fp32 = torch.randn(M, D_HEAD, dtype=torch.float32)
    k_fp32 = torch.randn(s2, D_HEAD, dtype=torch.float32)
    v_fp32 = torch.randn(s2, D_HEAD, dtype=torch.float32)
    q = fp32_to_hif8(q_fp32); k = fp32_to_hif8(k_fp32); v = fp32_to_hif8(v_fp32)
    out = torch.zeros(M, D_HEAD, dtype=torch.bfloat16)
    scale = 1.0 / math.sqrt(D_HEAD)
    fa_t = torch.tensor([x for row in fa for x in row], dtype=torch.int32)
    fd_t = torch.tensor([x for row in fd for x in row], dtype=torch.int32)

    v7_allhif8_kernel._simulator_config = SimulatorConfig(core_count=core_count, execution_timeout_s=3600.0)
    tag = f"v7_allhif8_{meta}"
    d = os.environ.get("PV_OUT_DIR") or f"./tmp/{tag}_{mode}"
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, fa_t, fd_t, out, M, s2, D_HEAD, scale, tiles_n)
    # symbols: 0=M, 1=S2, 2=D; fa/fd meta are 1-D (no symbolic dims)
    sb = {0: [0, 2], 1: [1, 2], 2: [1, 2], 3: [None], 4: [None], 5: [0, 2]}

    work_cores = sum(1 for r in fa if r[0] == 1)
    _target = os.environ.get("EASYASC_TARGET", "a5pr")
    print(f"[{tag}] target={_target}({DEVICE_CORES}c) Hq={hq} S1={s1} S2={s2} launch={launch_cores} "
          f"work={work_cores} fd_tasks={len(blocks)} nws={nws} mode={mode}", flush=True)

    if mode == "sim":
        out_kf = OpExec(v7_allhif8_kernel, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        out_kf = OpExec(v7_allhif8_kernel, out_dir=d, cann_path=cann,
                        custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                        simulator=False, cannsim=True)(*args, shape_bindings=sb)
    elif mode == "hw":
        profile = os.environ.get("PV_PROFILE", "0") == "1"
        out_kf = OpExec(v7_allhif8_kernel, out_dir=d, cann_path=cann,
                        custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                        simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit(f"PV_MODE must be sim|cannsim|hw, got {mode}")

    O = torch.as_tensor(out_kf).float()
    ref = _ref(q, k, v, hq, s1)                 # [M, D] fp32
    ref_bf16 = ref.to(torch.bfloat16).float()
    blockset = set(blocks)
    diag = []
    for mb in _pyrange(tiles_m):
        r0, r1 = mb * TILE_M, min((mb + 1) * TILE_M, M)
        ma = (O[r0:r1] - ref_bf16[r0:r1]).abs().max().item()
        if ma > 1e-2:
            diag.append(f"m{mb}{'(FD)' if mb in blockset else '(own)'}={ma:.3f}")
    if diag:
        print("  per-block max_abs>1e-2: " + " ".join(diag[:40]))
    cos = _cos(O, ref)
    mx, mn = _err(O, ref_bf16)
    nan = torch.isnan(O).any().item()
    status = "PASS" if (not nan and cos >= 0.999) else "FAIL"
    print(f"|O| max={O.abs().max().item():.3f}")
    print(f"[{status}] cos={cos:.6f} O-vs-ref max/mean abs={mx:.3e} {mn:.3e} nan={nan}", flush=True)


if __name__ == "__main__":
    main()
