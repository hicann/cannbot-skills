"""int8 @ int8 -> int32 matmul with an int32 C2/BT bias on a2 (910b):
z = x @ y.T + bias, accumulated in int32.

Per the AscendC Mmad datatype tables (table 8 for Atlas A2), int8@int8 matmul
accumulates into int32 and its bias must be int32 -- the stub-level datatype fence
enforces this. The int32 bias is a contiguous [1, N] row staged into L1 with the
32B-granular ``gm_to_l1`` (via the ``layout=Layout.ND`` ``<<=`` sugar) and routed
through the kernel's auto BT/C2 buffer (reinterpreted to int32, since fp32 and int32
are both 4 bytes).

The nosplit kernel has an explicit static N=64 contract so the full bias row is
provably within one A2 BT slot. The splitn kernel keeps runtime N and uses a
static 32-element tile bound.

Note: int8 NZ fractals use c0=32, so K must be a multiple of 32 for a compact [M,K]
L1 operand (otherwise the fractal pads K up to 32 and overflows the L1 tensor).

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_int8_bias.py            # simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_int8_bias.py --debug     # gen -r sim build (VM)
"""
from easyasc.a2 import *


STATIC_BIAS_N = 64


@kernel()
def matmul_int8_bias_kernel(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor,
                            M: Var, K: Var):
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [STATIC_BIAS_N, K], Position.L1)
    l1b = Tensor(DT.int, [1, STATIC_BIAS_N], Position.L1, layout=Layout.ND)
    l0c = Tensor(DT.int, [M, STATIC_BIAS_N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        l1b <<= bias[:, :]
        matmul(l0c, l1x, l1y, m=M, n=STATIC_BIAS_N, k=K, is_init=True, bias=l1b)
        z[:, :] <<= l0c
    return z


@kernel()
def matmul_int8_bias_splitn(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor,
                            M: Var, N: Var, K: Var):
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l1b = Tensor(DT.int, [1, N], Position.L1, layout=Layout.ND)  # int32 bias
    l0c = Tensor(DT.int, [M, N], Position.L0C)                   # int32 accumulator
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        l1b <<= bias[:, :]
        # splitn: an int32 bias row already slices contiguously (NZ) on a2 -- only the
        # *float* path needs the reinterpret trick. The BT slot is reinterpreted to int32.
        matmul(l0c, l1x, l1y, splitn=32, m=M, n=N, k=K, is_init=True, bias=l1b)
        z[:, :] <<= l0c
    return z


if __name__ == "__main__":
    import os
    import sys
    import torch

    # Distinct M/N/K; K a multiple of 32 (int8 c0); N*4 a multiple of 32B.
    M, N, K = 32, 64, 96
    torch.manual_seed(0)
    x = torch.randint(-4, 5, (M, K), dtype=torch.int8)
    y = torch.randint(-4, 5, (N, K), dtype=torch.int8)
    bias = torch.randint(-100, 100, (1, N), dtype=torch.int32)
    z_ref = (x.to(torch.int32) @ y.to(torch.int32).t()) + bias

    modes = [
        ("nosplit", matmul_int8_bias_kernel, False),
        ("splitn", matmul_int8_bias_splitn, True),
    ]

    debug = "--debug" in sys.argv[1:]
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"
    if debug and run:
        raise SystemExit("choose only one of --debug or --run")

    if debug:
        # debug + cannsim: emit b.sh/r.sh as `-r sim`, build + run CANNSIM, read back.
        base = os.environ.get("BIAS_BASE", "./tmp/a2_bias_cannsim")
        for name, kern, dynamic_n in modes:
            z = torch.zeros((M, N), dtype=torch.int32)
            out_dir = os.path.join(base, "int8_" + name)
            scalar_args = (M, N, K) if dynamic_n else (M, K)
            z_out = OpExec(kern, simulator=False, debug=True, cannsim=True,
                           cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
                           out_dir=out_dir)(x, y, bias, z, *scalar_args)
            ok = torch.equal(z_out, z_ref)
            print("CANNSIM int8->int32 [{}] {} max_abs_diff={}".format(
                name, "PASS" if ok else "FAIL", int(torch.abs(z_out - z_ref).max().item())))
    elif run:
        base = os.environ.get("BIAS_BASE", "./tmp/a2_bias_real_hw")
        for name, kern, dynamic_n in modes:
            z = torch.zeros((M, N), dtype=torch.int32)
            out_dir = os.path.join(base, "int8_" + name)
            scalar_args = (M, N, K) if dynamic_n else (M, K)
            z_out = OpExec(
                kern,
                simulator=False,
                debug=True,
                cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
                out_dir=out_dir,
            )(x, y, bias, z, *scalar_args)
            ok = torch.equal(z_out, z_ref)
            print("A2 HW int8->int32 [{}] {} max_abs_diff={}".format(
                name, "PASS" if ok else "FAIL", int(torch.abs(z_out - z_ref).max().item())))
    else:
        for name, kern, dynamic_n in modes:
            z = torch.zeros((M, N), dtype=torch.int32)
            scalar_args = (M, N, K) if dynamic_n else (M, K)
            z_out = OpExec(kern, simulator=True)(x, y, bias, z, *scalar_args)
            torch.testing.assert_close(z_out, z_ref, rtol=0, atol=0)
            print("a2 sim matmul+bias int8->int32 [{}] max_abs_diff={}".format(
                name, int(torch.abs(z_out - z_ref).max().item())))
