import os
import sys

os.environ.setdefault("TORCH_DEVICE_BACKEND_AUTOLOAD", "0")
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../..")))

import torch

from easyasc.a5 import (
    CastConfig, CeilDiv, DT, GMTensor, GetCubeIdx, GetCubeNum, MaskReg,
    MaskType, Min, OpExec, Pipe, Position, Reg, RegLayout, Tensor, Var,
    VcMutex, VfPipe, auto_sync, cast, cmax, div, dup, interleave, kernel,
    matmul_mx, range as asc_range, reg_to_ub, reg_to_ub_pack4,
    reg_to_ub_scatter, shiftrs, ub_to_l1, ub_to_l1_nd2nz, ub_to_reg,
    ub_to_reg_gather, vand, vf, vf_barrier, vmaxs, E8M0_MIN_VALUE,
    e8m0_to_fp32,
)
from easyasc.simulator import SimulatorConfig


M = 32
N = 32
K = 64
GROUP = 32
GROUPS_PER_ROW = K // GROUP
EXP_MASK = 0x7F800000


@vf()
def online_cast_f32_krows_to_mxfp8_e4m3_k64(
    src_f32: Tensor,
    src_u32: Tensor,
    dst_e4m3_u16: Tensor,
    dst_scale_u8: Tensor,
    scale_bits_u32: Tensor,
    scale_bits_f32: Tensor,
    scale_bits_u8: Tensor,
    index_bits_u32: Tensor,
    index_bits_i32: Tensor,
    index_bits_u16: Tensor,
    index_bits_i16: Tensor,
    packed_fp8: Tensor,
    packed_fp8_u8: Tensor,
    pair_bytes_u8: Tensor,
    pair_words_u16: Tensor,
    rows: Var,
    rows_half: Var,
):
    mask_f32_g32 = MaskReg(DT.float, init_mode=MaskType.LOWEST32)
    mask_u32_g32 = MaskReg(DT.uint32, init_mode=MaskType.LOWEST32)
    mask_e4m3_g32 = MaskReg(DT.e4m3, init_mode=MaskType.LOWEST32)
    mask_e4m3_pack32 = MaskReg(DT.e4m3, init_mode=MaskType.LOWEST128)
    mask_u8_g32 = MaskReg(DT.uint8, init_mode=MaskType.LOWEST32)
    mask_u8_pair128 = MaskReg(DT.uint8, init_mode=MaskType.LOWEST128)
    mask_u16_g32 = MaskReg(DT.uint16, init_mode=MaskType.LOWEST32)
    mask_u8_pack64 = MaskReg(DT.uint8, init_mode=MaskType.ALL)

    src_reg = Reg(DT.float)
    norm_reg = Reg(DT.float)
    scale_reg = Reg(DT.float)
    scale_dup_reg = Reg(DT.float)
    fp8_reg = Reg(DT.e4m3)

    src_bits_reg = Reg(DT.uint32)
    exp_mask_reg = Reg(DT.uint32)
    exp_bits_reg = Reg(DT.uint32)
    max_exp_bits_reg = Reg(DT.uint32)
    scale_byte_bits_reg = Reg(DT.uint32)
    packed_scale_reg = Reg(DT.uint8)

    data_index_i32 = Reg(DT.int)
    data_index_u32 = Reg(DT.uint32)
    pair_index_i16 = Reg(DT.int16)
    pair_index_u16 = Reg(DT.uint16)
    packed_even_u8 = Reg(DT.uint8)
    packed_odd_u8 = Reg(DT.uint8)
    pair_lo_u8 = Reg(DT.uint8)
    pair_hi_u8 = Reg(DT.uint8)
    pair_u16_reg = Reg(DT.uint16)

    cfg_zero = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_online_transpose_e4m3")
    exp_mask_reg <<= EXP_MASK

    for p in asc_range(rows_half):
        for g in asc_range(GROUPS_PER_ROW):
            row_even = Var(p * 2)
            row_odd = Var(p * 2 + 1)
            group_base_even = Var(g * GROUP * rows + row_even)
            group_base_odd = Var(g * GROUP * rows + row_odd)
            scale_off_even = Var(row_even * GROUPS_PER_ROW + g)
            scale_off_odd = Var(row_odd * GROUPS_PER_ROW + g)

            data_index_i32.arange(0)
            data_index_i32 <<= data_index_i32 * rows + group_base_even
            reg_to_ub(index_bits_i32, data_index_i32)
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)
            ub_to_reg(data_index_u32, index_bits_u32)

            ub_to_reg_gather(src_reg, src_f32, data_index_u32, mask=mask_f32_g32)
            ub_to_reg_gather(src_bits_reg, src_u32, data_index_u32, mask=mask_u32_g32)
            vand(exp_bits_reg, src_bits_reg, exp_mask_reg, mask=mask_u32_g32)
            cmax(max_exp_bits_reg, exp_bits_reg, mask=mask_u32_g32)

            scale_bits_u32[scale_off_even] <<= max_exp_bits_reg.single_value()
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)
            scale_reg <<= scale_bits_f32[scale_off_even].single()
            vmaxs(scale_reg, scale_reg, E8M0_MIN_VALUE)
            dup(scale_dup_reg, scale_reg)
            div(norm_reg, src_reg, scale_dup_reg, mask=mask_f32_g32)
            cast(fp8_reg, norm_reg, cfg_zero, mask=mask_e4m3_pack32)
            reg_to_ub_pack4(packed_fp8, fp8_reg, mask=mask_e4m3_pack32)
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)
            ub_to_reg(packed_even_u8, packed_fp8_u8, mask=mask_u8_g32)

            vf_barrier(VfPipe.STORE, VfPipe.STORE)
            shiftrs(scale_byte_bits_reg, max_exp_bits_reg, 23)
            scale_bits_u32[scale_off_even] <<= scale_byte_bits_reg.single_value()

            data_index_i32.arange(0)
            data_index_i32 <<= data_index_i32 * rows + group_base_odd
            reg_to_ub(index_bits_i32, data_index_i32)
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)
            ub_to_reg(data_index_u32, index_bits_u32)

            ub_to_reg_gather(src_reg, src_f32, data_index_u32, mask=mask_f32_g32)
            ub_to_reg_gather(src_bits_reg, src_u32, data_index_u32, mask=mask_u32_g32)
            vand(exp_bits_reg, src_bits_reg, exp_mask_reg, mask=mask_u32_g32)
            cmax(max_exp_bits_reg, exp_bits_reg, mask=mask_u32_g32)

            scale_bits_u32[scale_off_odd] <<= max_exp_bits_reg.single_value()
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)
            scale_reg <<= scale_bits_f32[scale_off_odd].single()
            vmaxs(scale_reg, scale_reg, E8M0_MIN_VALUE)
            dup(scale_dup_reg, scale_reg)
            div(norm_reg, src_reg, scale_dup_reg, mask=mask_f32_g32)
            cast(fp8_reg, norm_reg, cfg_zero, mask=mask_e4m3_pack32)
            reg_to_ub_pack4(packed_fp8, fp8_reg, mask=mask_e4m3_pack32)
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)
            ub_to_reg(packed_odd_u8, packed_fp8_u8, mask=mask_u8_g32)

            vf_barrier(VfPipe.STORE, VfPipe.STORE)
            shiftrs(scale_byte_bits_reg, max_exp_bits_reg, 23)
            scale_bits_u32[scale_off_odd] <<= scale_byte_bits_reg.single_value()

            interleave(pair_lo_u8, pair_hi_u8, packed_even_u8, packed_odd_u8)
            reg_to_ub(pair_bytes_u8, pair_lo_u8, mask=mask_u8_pair128)
            pair_base = Var(g * GROUP * rows_half + p)
            pair_index_i16.arange(0)
            pair_index_i16 <<= pair_index_i16 * rows_half + pair_base
            reg_to_ub(index_bits_i16, pair_index_i16)
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)
            ub_to_reg(pair_u16_reg, pair_words_u16, mask=mask_u16_g32)
            ub_to_reg(pair_index_u16, index_bits_u16, mask=mask_u16_g32)
            reg_to_ub_scatter(dst_e4m3_u16, pair_u16_reg, pair_index_u16, mask=mask_u16_g32)

    packed_scale_reg <<= scale_bits_u8[0]
    dst_scale_u8[0] <<= mask_u8_pack64 * packed_scale_reg.pack4()


@kernel()
def float_to_mxfp8_online_cast_transpose_matmul_kernel(x: GMTensor, y: GMTensor, z: GMTensor, dummy: Var):
    vcmutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)

    l1x = Tensor(DT.e4m3, [K, M], Position.L1)
    l1y = Tensor(DT.e4m3, [K, N], Position.L1)
    scale_x = Tensor(DT.uint8, [M, GROUPS_PER_ROW], Position.L1)
    scale_y = Tensor(DT.uint8, [N, GROUPS_PER_ROW], Position.L1)
    l0z = Tensor(DT.float, [M, N], Position.L0C)

    ub_x_f32 = Tensor(DT.float, [K, M], Position.UB)
    ub_y_f32 = Tensor(DT.float, [K, N], Position.UB)
    ub_x_u32 = ub_x_f32.reinterpret(DT.uint32)
    ub_y_u32 = ub_y_f32.reinterpret(DT.uint32)
    ub_x_fp8 = Tensor(DT.e4m3, [K, M], Position.UB)
    ub_y_fp8 = Tensor(DT.e4m3, [K, N], Position.UB)
    ub_x_fp8_u16 = ub_x_fp8.reinterpret(DT.uint16)
    ub_y_fp8_u16 = ub_y_fp8.reinterpret(DT.uint16)

    scale_bits_x_u32 = Tensor(DT.uint32, [M, GROUPS_PER_ROW], Position.UB)
    scale_bits_y_u32 = Tensor(DT.uint32, [N, GROUPS_PER_ROW], Position.UB)
    scale_bits_x_f32 = scale_bits_x_u32.reinterpret(DT.float)
    scale_bits_y_f32 = scale_bits_y_u32.reinterpret(DT.float)
    scale_bits_x_u8 = scale_bits_x_u32.reinterpret(DT.uint8)
    scale_bits_y_u8 = scale_bits_y_u32.reinterpret(DT.uint8)
    ub_scale_x = Tensor(DT.uint8, [M, GROUPS_PER_ROW], Position.UB)
    ub_scale_y = Tensor(DT.uint8, [N, GROUPS_PER_ROW], Position.UB)
    index_bits_u32 = Tensor(DT.uint32, [1, 64], Position.UB)
    index_bits_u16 = Tensor(DT.uint16, [1, 128], Position.UB)
    packed_fp8 = Tensor(DT.e4m3, [1, 64], Position.UB)
    packed_fp8_u8 = packed_fp8.reinterpret(DT.uint8)
    pair_bytes_u8 = Tensor(DT.uint8, [1, 128], Position.UB)
    pair_words_u16 = pair_bytes_u8.reinterpret(DT.uint16)
    index_bits_i32 = index_bits_u32.reinterpret(DT.int)
    index_bits_i16 = index_bits_u16.reinterpret(DT.int16)

    work_items = Var(1)
    items_per_core = CeilDiv(work_items, GetCubeNum())
    item_begin = Var(items_per_core * GetCubeIdx())
    item_end = Min(item_begin + items_per_core, work_items)

    with auto_sync():
        for _item in asc_range(item_begin, item_end):
            vcmutex.lock()
            ub_x_f32[:, :] <<= x[:, :]
            ub_y_f32[:, :] <<= y[:, :]
            online_cast_f32_krows_to_mxfp8_e4m3_k64(
                ub_x_f32, ub_x_u32, ub_x_fp8_u16, ub_scale_x,
                scale_bits_x_u32, scale_bits_x_f32, scale_bits_x_u8,
                index_bits_u32, index_bits_i32, index_bits_u16, index_bits_i16,
                packed_fp8, packed_fp8_u8, pair_bytes_u8, pair_words_u16, M, M // 2,
            )
            online_cast_f32_krows_to_mxfp8_e4m3_k64(
                ub_y_f32, ub_y_u32, ub_y_fp8_u16, ub_scale_y,
                scale_bits_y_u32, scale_bits_y_f32, scale_bits_y_u8,
                index_bits_u32, index_bits_i32, index_bits_u16, index_bits_i16,
                packed_fp8, packed_fp8_u8, pair_bytes_u8, pair_words_u16, N, N // 2,
            )
            ub_to_l1_nd2nz(l1x, ub_x_fp8, m_dst=K, n_dst=M, m_src=K, n_src=M, N_src=M)
            ub_to_l1_nd2nz(l1y, ub_y_fp8, m_dst=K, n_dst=N, m_src=K, n_src=N, N_src=N)
            ub_to_l1(scale_x, ub_scale_x, n_burst=1, burst_len=2, src_stride=0, dst_stride=0)
            ub_to_l1(scale_y, ub_scale_y, n_burst=1, burst_len=2, src_stride=0, dst_stride=0)
            vcmutex.ready()

            vcmutex.wait()
            matmul_mx(l0z, l1x.T, l1y.T, scale_x, scale_y, m=M, n=N, k=K, is_init=True)
            z[:, :] <<= l0z
            vcmutex.free()

    return z


float_to_mxfp8_online_cast_transpose_matmul_kernel._simulator_config = SimulatorConfig(
    core_count=1,
    process_start_method="fork",
    execution_timeout_s=120.0,
)


def online_mxfp8_e4m3_ref(src: torch.Tensor) -> torch.Tensor:
    grouped = src.reshape(src.shape[0], GROUPS_PER_ROW, GROUP)
    bits = grouped.contiguous().view(torch.int32)
    exp_bits = bits & EXP_MASK
    scale = (exp_bits.amax(dim=-1).to(torch.int64) >> 23).to(torch.uint8)
    scale_f = e8m0_to_fp32(scale)
    payload = (grouped / scale_f.unsqueeze(-1)).to(torch.float8_e4m3fn)
    return (payload.float() * scale_f.unsqueeze(-1)).reshape_as(src)


if __name__ == "__main__":
    if not hasattr(torch, "float8_e4m3fn"):
        raise RuntimeError("Current torch build does not support torch.float8_e4m3fn")

    torch.manual_seed(2)
    x = torch.randn((K, M), dtype=torch.float32) * 16.0
    y = torch.randn((K, N), dtype=torch.float32) * 16.0
    z = torch.zeros((M, N), dtype=torch.float32)

    use_cannsim = "--cannsim" in sys.argv[1:]
    gen_only = "--gen-only" in sys.argv[1:]
    out = OpExec(
        float_to_mxfp8_online_cast_transpose_matmul_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/float_to_mxfp8_online_cast_transpose_kernel/custom_opp"),
        out_dir=os.path.abspath(
            "tmp/float_to_mxfp8_online_cast_transpose_kernel/build/cannsim"
            if use_cannsim else "tmp/float_to_mxfp8_online_cast_transpose_kernel/build/sim"
        ),
    )(x, y, z, 0)

    if gen_only:
        print("gen_only complete")
        sys.exit(0)

    ref_x = online_mxfp8_e4m3_ref(x.t().contiguous())
    ref_y = online_mxfp8_e4m3_ref(y.t().contiguous())
    ref = ref_x @ ref_y.t()
    torch.testing.assert_close(out, ref, rtol=2e-3, atol=2e-3)
    print("online cast transpose matmul passed max_abs_diff={:.6e}".format((out - ref).abs().max().item()))
