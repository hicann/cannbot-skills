"""Step 1: x NCHW -> NC1HWC0 with the H pad rows baked in (a2 vec, fp16).

x  [B*CIN, HW]        flat NCHW (CIN = C1*16 exact, HW multiple of CHUNK)
y  [B*C1*HP*W, C0]    5HD plane with HP = H + 2*PAD; the top/bottom PAD rows
                      stay zero (y arrives pre-zeroed), so the compute kernel
                      never needs pad_top/bottom.

Per (b, c1, hw-chunk): 16 channel rows of CHUNK elems -> one vnchwconv repeat
batch -> [CHUNK, 16] 5HD slab stored at row (c1*HP + PAD)*W + s.

  PYTHONPATH=<repo> python transdata_x_to_5hd.py            # python simulator
  PYTHONPATH=<repo> python transdata_x_to_5hd.py --debug    # 910B3 standalone
"""
from easyasc.a2 import *

from common import B, C0, C1, CIN, DEBUG, H, HP, HW, N_VEC, PAD, W

CHUNK = 1024
BLOCKS = B * C1
CHUNKS = HW // CHUNK


@kernel()
def transdata_x_to_5hd(x: GMTensor, y: GMTensor, nv: Var):
    # contiguous per-lane unit block + DBuff: consecutive units alternate slots
    # so the load of unit u+1 overlaps the transpose/store of unit u.
    src = DBuff(DT.half, [16, CHUNK], Position.UB)
    dst = DBuff(DT.half, [CHUNK, C0], Position.UB)
    zero = Tensor(DT.half, [PAD * W, C0], Position.UB)
    dup_ready = SEvent(Pipe.V, Pipe.MTE3, name="x5hd_dup_ready")  # autosync misses V-dup->MTE3 RAW
    vec_idx = GetVecIdx()
    units = BLOCKS * CHUNKS
    per_lane = (units + N_VEC - 1) // N_VEC
    begin = per_lane * vec_idx
    end = Min(begin + per_lane, units)
    with auto_sync():
        dup(zero, 0.0, repeat=PAD * W * C0 // 128, dst_blk_stride=1, dst_rep_stride=8)
        dup_ready.set()
        dup_ready.wait()
        for blk in range(BLOCKS):
            with If(blk % nv == vec_idx):                       # H pad rows stay zero
                y[blk * HP * W:blk * HP * W + PAD * W, :] <<= zero
                y[(blk * HP + PAD + H) * W:(blk * HP + PAD + H) * W + PAD * W, :] <<= zero
        for u in range(begin, end):
            blk = var_div(u, CHUNKS)
            s = var_mod(u, CHUNKS) * CHUNK
            s_buf = src[u]
            d_buf = dst[u]
            s_buf <<= x[blk * C0:blk * C0 + 16, s:s + CHUNK]
            transdata5hd(d_buf, s_buf, repeat=CHUNK // 16,
                         src_row_stride=CHUNK, dst_row_stride=C0,
                         src_rep_stride=1, dst_rep_stride=C0)
            out0 = (blk * HP + PAD) * W + s
            y[out0:out0 + CHUNK, :] <<= d_buf
    return y


if __name__ == "__main__":
    import torch

    torch.manual_seed(7)
    x = torch.randn((B, CIN, H, W), dtype=torch.float16)
    y = torch.zeros((B * C1 * HP * W, C0), dtype=torch.float16)
    xp = torch.nn.functional.pad(x, (0, 0, PAD, PAD))            # H pad baked in GM
    ref = torch.from_numpy(pack_nc1hwc0(xp.numpy()))
    got = OpExec(transdata_x_to_5hd, simulator=not DEBUG, debug=DEBUG)(
        x.reshape(B * CIN, HW), y, N_VEC)
    assert torch.equal(got, ref), float((got.float() - ref.float()).abs().max())
    print("transdata_x_to_5hd {}x{}x{}x{} exact".format(B, CIN, H, W))
