"""Phase B (uint64 half): on-board smoke + sim/board alignment for the unsigned
64-bit reg ops. int64 is covered by int64_native_ops_onboard.py; this adds the
uint64-specific semantics that the signed run cannot exercise:

- ``shiftrs`` is a *logical* right shift for uint64 (zero-fill), vs the arithmetic
  (sign-extending) shift for int64 -- inputs set the high bit so the two differ;
- ``compare``/``compares`` use *unsigned* ordering (a value with bit 63 set is the
  largest, not negative);
- ``dup`` of a >2**63 immediate lowers through format_scalar as ``(uint64_t)K``;
- add/sub/mul/and/or/xor/not/muladddst wrap in the 64-bit register width.

abssub is intentionally excluded -- MicroAPI AbsSub is {half, float, int64} only,
so the DSL rejects a uint64 abssub (asserted in the pytest sim regression instead).

uint64 tensors are built through a same-width int64 view (torch element assignment
overflows above 2**63), and goldens are computed as python ints mod 2**64.

Run:
- simulator (default): python kernels/a5/vec_only/uint64_native_ops_onboard.py
- on Ascend950 board:   python kernels/a5/vec_only/uint64_native_ops_onboard.py --run
"""
import builtins
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403  (also shadows builtin `range` with the DSL range)

ROWS = 64
COLS = 32
_MOD = 1 << 64
SHIFT = 5
DUP_K = (1 << 63) + (1 << 40) + 7      # high bit set: a uint64-only immediate
CMP_S = 1 << 63                        # unsigned midpoint: splits the value range


def _u64_tensor(vals):
    """[R*C] python ints in [0, 2**64) -> uint64 tensor via a signed same-width view."""
    signed = [v - _MOD if v >= (1 << 63) else v for v in vals]
    return torch.tensor(signed, dtype=torch.int64).view(torch.uint64).reshape(ROWS, COLS)


# --------------------------------------------------------------------------- #
# K_u1: arithmetic + bitwise + shift + dup + fused muladddst (uint64).
# --------------------------------------------------------------------------- #
_CORE_NAMES = ["add", "sub", "mul", "vand", "vor", "vxor", "vnot",
               "shiftls", "shiftrs", "dup", "muladddst"]


@vf()
def u64_core_vf(ub_a: Tensor, ub_b: Tensor, ub_add: Tensor, ub_sub: Tensor,
                ub_mul: Tensor, ub_and: Tensor, ub_or: Tensor, ub_xor: Tensor,
                ub_not: Tensor, ub_ls: Tensor, ub_rs: Tensor, ub_dup: Tensor,
                ub_mad: Tensor):
    ra = Reg(DT.uint64, name="uc_a")
    rb = Reg(DT.uint64, name="uc_b")
    ra <<= ub_a[0]
    rb <<= ub_b[0]
    r_add = Reg(DT.uint64, name="uc_add")
    r_sub = Reg(DT.uint64, name="uc_sub")
    r_mul = Reg(DT.uint64, name="uc_mul")
    r_and = Reg(DT.uint64, name="uc_and")
    r_or = Reg(DT.uint64, name="uc_or")
    r_xor = Reg(DT.uint64, name="uc_xor")
    r_not = Reg(DT.uint64, name="uc_not")
    r_ls = Reg(DT.uint64, name="uc_ls")
    r_rs = Reg(DT.uint64, name="uc_rs")
    r_dup = Reg(DT.uint64, name="uc_dup")
    r_mad = Reg(DT.uint64, name="uc_mad")
    add(r_add, ra, rb)
    sub(r_sub, ra, rb)
    mul(r_mul, ra, rb)
    vand(r_and, ra, rb)
    vor(r_or, ra, rb)
    vxor(r_xor, ra, rb)
    vnot(r_not, ra)
    shiftls(r_ls, ra, SHIFT)
    shiftrs(r_rs, ra, SHIFT)               # logical (zero-fill) for uint64
    dup(r_dup, DUP_K)
    r_mad <<= rb
    muladddst(r_mad, ra, ra)               # a*a + b (mod 2**64)
    ub_add[0] <<= r_add
    ub_sub[0] <<= r_sub
    ub_mul[0] <<= r_mul
    ub_and[0] <<= r_and
    ub_or[0] <<= r_or
    ub_xor[0] <<= r_xor
    ub_not[0] <<= r_not
    ub_ls[0] <<= r_ls
    ub_rs[0] <<= r_rs
    ub_dup[0] <<= r_dup
    ub_mad[0] <<= r_mad


@kernel(mode="vec")
def u64_core_kernel(a: GMTensor, b: GMTensor, o_add: GMTensor, o_sub: GMTensor,
                    o_mul: GMTensor, o_and: GMTensor, o_or: GMTensor, o_xor: GMTensor,
                    o_not: GMTensor, o_ls: GMTensor, o_rs: GMTensor, o_dup: GMTensor,
                    o_mad: GMTensor, rows: Var):
    ub_a = Tensor(DT.uint64, [1, COLS], Position.UB, name="ub_uca")
    ub_b = Tensor(DT.uint64, [1, COLS], Position.UB, name="ub_ucb")
    ubs = [Tensor(DT.uint64, [1, COLS], Position.UB, name=f"ub_uc{i}") for i in builtins.range(11)]
    rpv = CeilDiv(rows, GetVecNum())
    rb0 = Var(rpv * GetVecIdx())
    re0 = Min(rb0 + rpv, rows)
    outs = [o_add, o_sub, o_mul, o_and, o_or, o_xor, o_not, o_ls, o_rs, o_dup, o_mad]
    with auto_sync():
        for r in range(rb0, re0, name="ucore_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            ub_b[:, :] <<= b[r:r + 1, :]
            u64_core_vf(ub_a, ub_b, *ubs)
            for gm, ub in zip(outs, ubs):
                gm[r:r + 1, :] <<= ub
    return o_add, o_sub, o_mul, o_and, o_or, o_xor, o_not, o_ls, o_rs, o_dup, o_mad


# --------------------------------------------------------------------------- #
# K_u2: unsigned compare (reg-reg + scalar) observed through select.
# --------------------------------------------------------------------------- #
_CMPSEL_NAMES = ["cmp_rr_sel", "cmp_rs_sel"]


@vf()
def u64_cmpsel_vf(ub_a: Tensor, ub_b: Tensor, ub_rr: Tensor, ub_rs: Tensor):
    ra = Reg(DT.uint64, name="us_a")
    rb = Reg(DT.uint64, name="us_b")
    ra <<= ub_a[0]
    rb <<= ub_b[0]
    r_rr = Reg(DT.uint64, name="us_rr")
    r_rs = Reg(DT.uint64, name="us_rs")
    m_rr = MaskReg(DT.uint64, init_mode=MaskType.NONE, name="us_m_rr")
    m_rs = MaskReg(DT.uint64, init_mode=MaskType.NONE, name="us_m_rs")
    compare(m_rr, ra, rb, CompareMode.GT)       # unsigned a > b
    select(r_rr, ra, rb, mask=m_rr)
    compare(m_rs, ra, CMP_S, CompareMode.GT)     # unsigned a > 2**63
    select(r_rs, ra, rb, mask=m_rs)
    ub_rr[0] <<= r_rr
    ub_rs[0] <<= r_rs


@kernel(mode="vec")
def u64_cmpsel_kernel(a: GMTensor, b: GMTensor, o_rr: GMTensor, o_rs: GMTensor,
                      rows: Var):
    ub_a = Tensor(DT.uint64, [1, COLS], Position.UB, name="ub_usa")
    ub_b = Tensor(DT.uint64, [1, COLS], Position.UB, name="ub_usb")
    ub_rr = Tensor(DT.uint64, [1, COLS], Position.UB, name="ub_usrr")
    ub_rs = Tensor(DT.uint64, [1, COLS], Position.UB, name="ub_usrs")
    rpv = CeilDiv(rows, GetVecNum())
    rb0 = Var(rpv * GetVecIdx())
    re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="ucmpsel_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            ub_b[:, :] <<= b[r:r + 1, :]
            u64_cmpsel_vf(ub_a, ub_b, ub_rr, ub_rs)
            o_rr[r:r + 1, :] <<= ub_rr
            o_rs[r:r + 1, :] <<= ub_rs
    return o_rr, o_rs


# --------------------------------------------------------------------------- #
# Driver
# --------------------------------------------------------------------------- #
def _make_inputs():
    n = ROWS * COLS
    # Spread across [0, 2**64) with many high-bit-set values so unsigned ordering
    # and logical shift genuinely differ from the signed interpretation.
    av = [(i * (2 ** 58 + 1315423911) + 7) % _MOD for i in builtins.range(n)]
    bv = [(i * (2 ** 47 + 2654435761) + 2 ** 63) % _MOD for i in builtins.range(n)]
    return av, bv


def _golden(av, bv):
    m = _MOD
    add = [(x + y) % m for x, y in zip(av, bv)]
    sub = [(x - y) % m for x, y in zip(av, bv)]
    mul = [(x * y) % m for x, y in zip(av, bv)]
    vand = [x & y for x, y in zip(av, bv)]
    vor = [x | y for x, y in zip(av, bv)]
    vxor = [x ^ y for x, y in zip(av, bv)]
    vnot = [(m - 1 - x) for x in av]
    shiftls = [(x << SHIFT) % m for x in av]
    shiftrs = [x >> SHIFT for x in av]                      # logical (av are unsigned)
    dup = [DUP_K for _ in av]
    mad = [(x * x + y) % m for x, y in zip(av, bv)]
    rr = [x if x > y else y for x, y in zip(av, bv)]        # unsigned
    rs = [x if x > CMP_S else y for x, y in zip(av, bv)]
    return {
        "add": add, "sub": sub, "mul": mul, "vand": vand, "vor": vor, "vxor": vxor,
        "vnot": vnot, "shiftls": shiftls, "shiftrs": shiftrs, "dup": dup,
        "muladddst": mad, "cmp_rr_sel": rr, "cmp_rs_sel": rs,
    }


def _opexec(kern, mode, run_on_board, tag):
    if run_on_board:
        cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"])
    else:
        cfg = dict(simulator=True)
    return OpExec(kern, out_dir=os.path.abspath(f"tmp/uint64_native/{mode}_{tag}"),
                  custom_op_path=os.path.abspath("tmp/uint64_native/custom_opp"), **cfg)


def _u64_vals(t):
    """uint64 tensor -> flat list of python ints in [0, 2**64)."""
    return [int(x) % _MOD for x in t.reshape(-1).view(torch.int64).tolist()]


def _check(mode, name, got, want_vals, fails):
    got_vals = _u64_vals(got)
    if got_vals == want_vals:
        print(f"[{mode}] {name:12s} OK  (bit-exact uint64)")
    else:
        first = next(i for i in builtins.range(len(want_vals)) if got_vals[i] != want_vals[i])
        bad = sum(1 for i in builtins.range(len(want_vals)) if got_vals[i] != want_vals[i])
        print(f"[{mode}] {name:12s} MISMATCH count={bad} first_idx={first} "
              f"got={got_vals[first]} want={want_vals[first]}")
        fails.append(name)


def check_case(run_on_board):
    av, bv = _make_inputs()
    a = _u64_tensor(av).contiguous()
    b = _u64_tensor(bv).contiguous()
    g = _golden(av, bv)
    mode = "board" if run_on_board else "sim"
    fails, build_fails = [], []

    def run(tag, kern, names):
        try:
            outs = [torch.zeros((ROWS, COLS), dtype=torch.uint64) for _ in names]
            res = _opexec(kern, mode, run_on_board, tag)(a, b, *outs, ROWS)
            if not isinstance(res, (list, tuple)):
                res = (res,)
            for name, got in zip(names, res):
                _check(mode, name, got, g[name], fails)
        except Exception as exc:  # noqa: BLE001
            print(f"[{mode}] {tag:8s} BUILD/RUN-FAIL: {type(exc).__name__}: {str(exc)[:200]}")
            build_fails.extend(names)

    run("core", u64_core_kernel, _CORE_NAMES)
    run("cmpsel", u64_cmpsel_kernel, _CMPSEL_NAMES)

    total = len(_CORE_NAMES) + len(_CMPSEL_NAMES)
    ok = total - len(fails) - len(build_fails)
    print(f"\n[{mode}] summary: {ok}/{total} uint64 ops bit-exact; "
          f"value-mismatch={fails or '-'}; build/run-fail={build_fails or '-'}")
    if fails or build_fails:
        raise AssertionError(f"uint64 native-ops {mode}: mismatch={fails} build_fail={build_fails}")
    print(f"[{mode}] ALL {total} uint64 native ops bit-exact")


if __name__ == "__main__":
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1"
    check_case(run_on_board=run)
