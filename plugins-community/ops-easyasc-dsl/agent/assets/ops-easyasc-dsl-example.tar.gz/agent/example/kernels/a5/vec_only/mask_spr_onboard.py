"""On-board alignment for move_mask_spr (MicroAPI::MoveMask<T>()) + SetVectorMask (vec PipeS).

SetVectorMask / set_mask / set_mask_by_count run on the vec PipeS OUTSIDE the @vf; inside the vf
move_mask_spr materializes that SPR into a MaskReg. Board-verified mapping (movemask_probe.py):
lane-granular direct index -- MaskReg lane i <- SPR lane i. Here the recovered mask drives
select(7, 0) so active lanes reappear as 7; sim and board must both match the host golden (which
mirrors "lane i active iff SPR bit i set"). reset_mask() after each vf clears the SPR so the GM
store is not itself masked. --run for board.
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403


@vf()
def mms_vf(out_ub):
    m = MaskReg(DT.int, name="mms_m")
    move_mask_spr(m)                                 # m = MoveMask<int>() -- read the SPR
    seven = Reg(DT.int, name="mms_sv"); dup(seven, 7)
    zr = Reg(DT.int, name="mms_zr"); dup(zr, 0)
    outr = Reg(DT.int, name="mms_or"); dup(outr, 0)
    select(outr, seven, zr, m)                       # outr = m ? 7 : 0
    reg_to_ub_normal(out_ub, outr)


@kernel(mode="vec")
def mms_kernel(dummy: GMTensor, o_cnt: GMTensor, o_pat: GMTensor, rows: Var):
    d_ub = Tensor(DT.int, [1, 8], Position.UB, name="mms_d")
    oc_ub = Tensor(DT.int, [1, 64], Position.UB, name="mms_oc")
    op_ub = Tensor(DT.int, [1, 64], Position.UB, name="mms_op")
    with auto_sync():
        d_ub[:, :] <<= dummy[0:1, :]                 # satisfy input-tensor requirement
        set_mask_by_count(20); mms_vf(oc_ub); reset_mask(); o_cnt[0:1, :] <<= oc_ub
        set_mask(0, 0xF0F); mms_vf(op_ub); reset_mask(); o_pat[0:1, :] <<= op_ub
    return o_cnt, o_pat


def _golden_lanes(active):
    g = torch.zeros(64, dtype=torch.int32)
    g[active] = 7
    return g


def main(run):
    dummy = torch.zeros(1, 8, dtype=torch.int32)
    o_cnt = torch.zeros(1, 64, dtype=torch.int32)
    o_pat = torch.zeros(1, 64, dtype=torch.int32)
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    res = OpExec(mms_kernel, out_dir=os.path.abspath("tmp/maskspr/run"),
                 custom_op_path=os.path.abspath("tmp/maskspr/opp"),
                 **cfg)(dummy.contiguous(), o_cnt, o_pat, 1)
    gc, gp = (t.reshape(-1) for t in res)
    cnt_active = torch.arange(20).tolist()                 # set_mask_by_count(20) -> lanes 0..19
    pat_active = [0, 1, 2, 3, 8, 9, 10, 11]                # 0xF0F low bits
    ok_cnt = torch.equal(gc.to(torch.int32), _golden_lanes(cnt_active))
    ok_pat = torch.equal(gp.to(torch.int32), _golden_lanes(pat_active))
    print(f"count=20 : match={ok_cnt}  active(sel==7)={sorted((gc == 7).nonzero(as_tuple=True)[0].tolist())}")
    print(f"0xF0F    : match={ok_pat}  active(sel==7)={sorted((gp == 7).nonzero(as_tuple=True)[0].tolist())}")
    print("ALL_OK" if (ok_cnt and ok_pat) else "MISMATCH")


if __name__ == "__main__":
    main("--run" in sys.argv[1:])
