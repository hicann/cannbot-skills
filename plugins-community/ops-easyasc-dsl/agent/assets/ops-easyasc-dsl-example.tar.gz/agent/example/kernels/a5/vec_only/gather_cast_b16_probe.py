"""How does a 16-bit gather have to be indexed so `cast` can widen it?

The pooling kernel reads staged half/bfloat16 rows with `ub_to_reg_unpack` and
widens them with `cast`: UNPACK spreads 64 source elements across the 128 lanes
of a b16 register so the b32 view lines up.  Reaching an unaligned row start
needs `ub_to_reg_gather` instead, which is indexed per b16 lane - so the
question is which of the 128 lanes `cast` actually consumes.

Two candidate index layouts, both gathering the same 64 source elements:

  low   index[i]    = base + i          (values in lanes 0..63)
  even  index[2i]   = base + i          (values in even lanes, UNPACK-like)

Whichever matches the `ub_to_reg_unpack` reference is the layout to build.

Run: python kernels/a5/vec_only/gather_cast_b16_probe.py [--run]
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

SRC = 256
BASE = 16  # 32-byte aligned so the UNPACK reference is legal


@vf()
def ref_unpack_vf(src_ub, dst_ub, base: Var):
    native = Reg(DT.half, name="gc_ref_n")
    wide = Reg(DT.float, name="gc_ref_w")
    to_float = CastConfig(round_mode=RoundMode.NONE, name="gc_ref_cast")
    ub_to_reg_unpack(native, src_ub[0:1, base:base + 64])
    cast(wide, native, to_float)
    reg_to_ub_normal(dst_ub[0:1, 0:64], wide)


@kernel(mode="vec")
def ref_unpack_kernel(src: GMTensor, out: GMTensor, base: Var):
    src_ub = Tensor(DT.half, [1, SRC], Position.UB, name="gc_ref_src")
    dst_ub = Tensor(DT.float, [1, 64], Position.UB, name="gc_ref_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        ref_unpack_vf(src_ub, dst_ub, base)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gather_low_vf(src_ub, dst_ub, base: Var):
    """index[i] = base + i: the 64 values land in b16 lanes 0..63."""
    lane = Reg(DT.int16, name="gc_low_lane")
    idx = Reg(DT.uint16, name="gc_low_idx")
    native = Reg(DT.half, name="gc_low_n")
    wide = Reg(DT.float, name="gc_low_w")
    to_float = CastConfig(round_mode=RoundMode.NONE, name="gc_low_cast")
    base16 = Var(base, dtype=DT.uint16)
    arange(lane, 0)
    lane_u = lane.reinterpret(DT.uint16, name="gc_low_lane_u")
    adds(idx, lane_u, base16)
    ub_to_reg_gather(native, src_ub[0:1, 0:SRC], idx)
    cast(wide, native, to_float)
    reg_to_ub_normal(dst_ub[0:1, 0:64], wide)


@kernel(mode="vec")
def gather_low_kernel(src: GMTensor, out: GMTensor, base: Var):
    src_ub = Tensor(DT.half, [1, SRC], Position.UB, name="gc_low_src")
    dst_ub = Tensor(DT.float, [1, 64], Position.UB, name="gc_low_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        gather_low_vf(src_ub, dst_ub, base)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gather_even_vf(src_ub, dst_ub, base: Var):
    """index[2i] = base + i: UNPACK-like, values in the even b16 lanes."""
    lane = Reg(DT.int16, name="gc_even_lane")
    idx = Reg(DT.uint16, name="gc_even_idx")
    native = Reg(DT.half, name="gc_even_n")
    wide = Reg(DT.float, name="gc_even_w")
    to_float = CastConfig(round_mode=RoundMode.NONE, name="gc_even_cast")
    base16 = Var(base, dtype=DT.uint16)
    arange(lane, 0)
    lane_u = lane.reinterpret(DT.uint16, name="gc_even_lane_u")
    shiftrs(idx, lane_u, 1)
    adds(idx, idx, base16)
    ub_to_reg_gather(native, src_ub[0:1, 0:SRC], idx)
    cast(wide, native, to_float)
    reg_to_ub_normal(dst_ub[0:1, 0:64], wide)


@kernel(mode="vec")
def gather_even_kernel(src: GMTensor, out: GMTensor, base: Var):
    src_ub = Tensor(DT.half, [1, SRC], Position.UB, name="gc_even_src")
    dst_ub = Tensor(DT.float, [1, 64], Position.UB, name="gc_even_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        gather_even_vf(src_ub, dst_ub, base)
        out[0:1, :] <<= dst_ub
    return out


def main(run):
    mode = "board" if run else "sim"
    src = (torch.arange(SRC, dtype=torch.float32) % 241).to(torch.float16).reshape(1, SRC)
    want = src[0, BASE:BASE + 64].to(torch.float32).reshape(-1)
    for tag, kern in (("unpack", ref_unpack_kernel), ("low", gather_low_kernel),
                      ("even", gather_even_kernel)):
        cfg = dict(simulator=False, debug=False,
                   cann_path=os.environ["ASCEND_HOME_PATH"]) if run else dict(simulator=True)
        try:
            out = torch.zeros(1, 64, dtype=torch.float32)
            res = OpExec(kern, out_dir=os.path.abspath("tmp/gcast/" + tag),
                         custom_op_path=os.path.abspath("tmp/gcast/custom_opp"),
                         **cfg)(src.contiguous(), out, BASE)
            got = (res if isinstance(res, torch.Tensor) else res[0]).reshape(-1).float()
            ok = torch.equal(got, want)
            print("[{}] {:7s} {} got[:6]={}".format(
                mode, tag, "MATCH " if ok else "differ", got[:6].tolist()))
        except Exception as exc:  # noqa: BLE001
            print("[{}] {:7s} FAIL {}: {}".format(mode, tag, type(exc).__name__, str(exc)[:200]))
    print("[{}] want[:6]={}".format(mode, want[:6].tolist()))


if __name__ == "__main__":
    main("--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1")
