import os
import sys

os.environ.setdefault("TORCH_DEVICE_BACKEND_AUTOLOAD", "0")

import torch

from easyasc.a5 import (
    CastConfig, CeilDiv, DT, GMTensor, GetCubeIdx, GetCubeNum, MaskReg,
    MaskType, Min, OpExec, Pipe, Position, Reg, RegLayout, Tensor, Var,
    VcMutex, VfPipe, auto_sync, cast, cmax, div, dup, kernel, matmul_mx,
    range as asc_range, shiftrs, ub_to_l1, ub_to_l1_nd2nz, ub_to_reg, vand,
    vf, vf_barrier, vmaxs, E8M0_MIN_VALUE, e8m0_to_fp32,
)
from easyasc.simulator import SimulatorConfig


M = 16
N = 16
K = 64
GROUP = 32
GROUPS_PER_ROW = K // GROUP
EXP_MASK = 0x7F800000


@vf()
def online_cast_f32_to_mxfp8_e4m3_k64(
    src_f32: Tensor,
    src_u32: Tensor,
    dst_e4m3: Tensor,
    dst_scale_u8: Tensor,
    scale_bits_u32: Tensor,
    scale_bits_f32: Tensor,
    scale_bits_u8: Tensor,
    rows: Var,
):
    mask_f32_g32 = MaskReg(DT.float, init_mode=MaskType.LOWEST32)
    mask_u32_g32 = MaskReg(DT.uint32, init_mode=MaskType.LOWEST32)
    mask_e4m3_pack32 = MaskReg(DT.e4m3, init_mode=MaskType.LOWEST128)
    mask_u8_pack32 = MaskReg(DT.uint8, init_mode=MaskType.LOWEST128)

    src_reg = Reg(DT.float)
    norm_reg = Reg(DT.float)
    scale_reg = Reg(DT.float)
    scale_dup_reg = Reg(DT.float)
    fp8_reg = Reg(DT.e4m3)

    src_bits_reg = Reg(DT.uint32)
    exp_mask_reg = Reg(DT.uint32)
    exp_bits_reg = Reg(DT.uint32)
    max_exp_bits_reg = Reg(DT.uint32)
    scale_byte_bits_reg = Reg(DT.uint32)
    packed_scale_reg = Reg(DT.uint8)

    cfg_zero = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_online_e4m3")
    exp_mask_reg <<= EXP_MASK

    for r in asc_range(rows):
        for g in asc_range(GROUPS_PER_ROW):
            src_off = Var(r * K + g * GROUP)
            scale_off = Var(r * GROUPS_PER_ROW + g)

            ub_to_reg(src_reg, src_f32[src_off], mask=mask_f32_g32)
            ub_to_reg(src_bits_reg, src_u32[src_off], mask=mask_u32_g32)
            vand(exp_bits_reg, src_bits_reg, exp_mask_reg, mask=mask_u32_g32)
            cmax(max_exp_bits_reg, exp_bits_reg, mask=mask_u32_g32)

            scale_bits_u32[scale_off] <<= max_exp_bits_reg.single_value()
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)
            scale_reg <<= scale_bits_f32[scale_off].single()
            vmaxs(scale_reg, scale_reg, E8M0_MIN_VALUE)
            dup(scale_dup_reg, scale_reg)
            div(norm_reg, src_reg, scale_dup_reg, mask=mask_f32_g32)
            cast(fp8_reg, norm_reg, cfg_zero, mask=mask_e4m3_pack32)
            dst_e4m3[src_off] <<= mask_e4m3_pack32 * fp8_reg.pack4()

            vf_barrier(VfPipe.STORE, VfPipe.STORE)
            shiftrs(scale_byte_bits_reg, max_exp_bits_reg, 23)
            scale_bits_u32[scale_off] <<= scale_byte_bits_reg.single_value()

    packed_scale_reg <<= scale_bits_u8[0]
    dst_scale_u8[0] <<= mask_u8_pack32 * packed_scale_reg.pack4()


@kernel()
def float_to_mxfp8_online_cast_matmul_kernel(x: GMTensor, y: GMTensor, z: GMTensor, dummy: Var):
    vcmutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)

    l1x = Tensor(DT.e4m3, [M, K], Position.L1)
    l1y = Tensor(DT.e4m3, [N, K], Position.L1)
    scale_x = Tensor(DT.uint8, [M, GROUPS_PER_ROW], Position.L1)
    scale_y = Tensor(DT.uint8, [N, GROUPS_PER_ROW], Position.L1)
    l0z = Tensor(DT.float, [M, N], Position.L0C)

    ub_x_f32 = Tensor(DT.float, [M, K], Position.UB)
    ub_y_f32 = Tensor(DT.float, [N, K], Position.UB)
    ub_x_u32 = ub_x_f32.reinterpret(DT.uint32)
    ub_y_u32 = ub_y_f32.reinterpret(DT.uint32)
    ub_x_fp8 = Tensor(DT.e4m3, [M, K], Position.UB)
    ub_y_fp8 = Tensor(DT.e4m3, [N, K], Position.UB)

    scale_bits_x_u32 = Tensor(DT.uint32, [M, GROUPS_PER_ROW], Position.UB)
    scale_bits_y_u32 = Tensor(DT.uint32, [N, GROUPS_PER_ROW], Position.UB)
    scale_bits_x_f32 = scale_bits_x_u32.reinterpret(DT.float)
    scale_bits_y_f32 = scale_bits_y_u32.reinterpret(DT.float)
    scale_bits_x_u8 = scale_bits_x_u32.reinterpret(DT.uint8)
    scale_bits_y_u8 = scale_bits_y_u32.reinterpret(DT.uint8)
    ub_scale_x = Tensor(DT.uint8, [M, GROUPS_PER_ROW], Position.UB)
    ub_scale_y = Tensor(DT.uint8, [N, GROUPS_PER_ROW], Position.UB)

    work_items = Var(1)
    items_per_core = CeilDiv(work_items, GetCubeNum())
    item_begin = Var(items_per_core * GetCubeIdx())
    item_end = Min(item_begin + items_per_core, work_items)

    with auto_sync():
        for _item in asc_range(item_begin, item_end):
            vcmutex.lock()
            ub_x_f32[:, :] <<= x[:, :]
            ub_y_f32[:, :] <<= y[:, :]
            online_cast_f32_to_mxfp8_e4m3_k64(
                ub_x_f32, ub_x_u32, ub_x_fp8, ub_scale_x,
                scale_bits_x_u32, scale_bits_x_f32, scale_bits_x_u8, M,
            )
            online_cast_f32_to_mxfp8_e4m3_k64(
                ub_y_f32, ub_y_u32, ub_y_fp8, ub_scale_y,
                scale_bits_y_u32, scale_bits_y_f32, scale_bits_y_u8, N,
            )
            ub_to_l1_nd2nz(l1x, ub_x_fp8, m_dst=M, n_dst=K, m_src=M, n_src=K, N_src=K)
            ub_to_l1_nd2nz(l1y, ub_y_fp8, m_dst=N, n_dst=K, m_src=N, n_src=K, N_src=K)
            ub_to_l1(scale_x, ub_scale_x, n_burst=1, burst_len=1, src_stride=0, dst_stride=0)
            ub_to_l1(scale_y, ub_scale_y, n_burst=1, burst_len=1, src_stride=0, dst_stride=0)
            vcmutex.ready()

            vcmutex.wait()
            matmul_mx(l0z, l1x, l1y, scale_x, scale_y, m=M, n=N, k=K, is_init=True)
            z[:, :] <<= l0z
            vcmutex.free()

    return z


float_to_mxfp8_online_cast_matmul_kernel._simulator_config = SimulatorConfig(
    core_count=1,
    process_start_method="fork",
    execution_timeout_s=120.0,
)


def online_mxfp8_e4m3_ref(src: torch.Tensor) -> torch.Tensor:
    grouped = src.reshape(src.shape[0], GROUPS_PER_ROW, GROUP)
    bits = grouped.contiguous().view(torch.int32)
    exp_bits = bits & EXP_MASK
    scale = (exp_bits.amax(dim=-1).to(torch.int64) >> 23).to(torch.uint8)
    scale_f = e8m0_to_fp32(scale)
    payload = (grouped / scale_f.unsqueeze(-1)).to(torch.float8_e4m3fn)
    return (payload.float() * scale_f.unsqueeze(-1)).reshape_as(src)


if __name__ == "__main__":
    if not hasattr(torch, "float8_e4m3fn"):
        raise RuntimeError("Current torch build does not support torch.float8_e4m3fn")

    torch.manual_seed(1)
    x = torch.randn((M, K), dtype=torch.float32) * 16.0
    y = torch.randn((N, K), dtype=torch.float32) * 16.0
    z = torch.zeros((M, N), dtype=torch.float32)

    use_cannsim = "--cannsim" in sys.argv[1:]
    gen_only = "--gen-only" in sys.argv[1:]
    out = OpExec(
        float_to_mxfp8_online_cast_matmul_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/float_to_mxfp8_online_cast_kernel/custom_opp"),
        out_dir=os.path.abspath("tmp/float_to_mxfp8_online_cast_kernel/build/cannsim" if use_cannsim else "tmp/float_to_mxfp8_online_cast_kernel/build/sim"),
    )(x, y, z, 0)

    if gen_only:
        print("gen_only complete")
        sys.exit(0)

    ref = online_mxfp8_e4m3_ref(x) @ online_mxfp8_e4m3_ref(y).t()
    torch.testing.assert_close(out, ref, rtol=2e-3, atol=2e-3)
    print("online cast matmul passed max_abs_diff={:.6e}".format((out - ref).abs().max().item()))
