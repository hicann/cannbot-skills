"""matmul + a5/C310 fixpipe scalar quant on the L0C -> UB store (``ub <<= l0c.requant(...)``).

Companion to matmul_quant.py (which targets the L0C -> GM store). The same fixpipe scalar
quant modes are available on the L0C -> UB copy, but ONLY when the dual destination control
is off (SINGLE): SPLITM/SPLITN split the L0C tile across the two vector subblocks and support
neither relu nor any requant parameter. A requant/relu rider on the L0C tensor drives the
``ub <<= l0c.requant(...)`` operator to SINGLE, which writes ONE vector subblock -- so the target
subblock must be named explicitly with ``.subblk(0)``/``.subblk(1)`` (there is no silent default).

Each kernel matmuls into L0C, quantizes into UB, then copies UB -> GM so the host can read it
back. The fixpipe (cube/FIX pipe) -> UB write is bridged to the vector pipe with a CvMutex,
and the SINGLE store lands in vector subblock 0, so the UB -> GM read is guarded by
``GetSubBlockIdx() == 0``.

  * fp32 L0C -> int8 / uint8 UB : QF322B8_PRE   (sign from the UB dtype)
  * int32 L0C -> int8 UB        : REQ8
  * int32 L0C -> fp16 UB        : DEQF16
  * fp32 L0C -> fp16 UB scaled  : QF322F16_PRE
  * fp32 L0C -> int8 UB, relu   : relu then QF322B8_PRE

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_quant_ub.py             # repo simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_quant_ub.py --cannsim    # cannsim (VM only)
"""
from easyasc.a5 import *

QF_SCALE, QF_OFFSET = 0.5, 8      # QF322B8_PRE : fp32  L0C -> 8-bit UB
RQ_SCALE, RQ_OFFSET = 0.5, 0      # REQ8        : int32 L0C -> 8-bit UB
DQ_SCALE = 0.25                   # DEQF16      : int32 L0C -> fp16 UB
SC_SCALE = 0.5                    # QF322F16_PRE: fp32  L0C -> fp16 UB (scaled cast)


def _cvmutex():
    """FIX(cube fixpipe) -> V(vector) bridge for the L0C->UB store + the UB->GM read-back."""
    return CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)


@kernel()
def matmul_ub_quant_fp32_byte(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32, quantized to 8-bit on the L0C->UB store (QF322B8_PRE), then UB->GM."""
    cvmutex = _cvmutex()
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    ub = Tensor(z.dtype, [M, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cvmutex.lock()
        ub <<= l0c.requant(scale=QF_SCALE, offset=QF_OFFSET)   # rider -> SINGLE (subblock 0)
        cvmutex.ready()
        cvmutex.wait()
        if GetSubBlockIdx() == 0:
            z[0:M, 0:N] <<= ub[0:M, 0:N]
        cvmutex.free()
    return z


@kernel()
def matmul_ub_requant_int32_byte(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """int8 @ int8 -> int32, requantized to 8-bit on the L0C->UB store (REQ8), then UB->GM."""
    cvmutex = _cvmutex()
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l0c = Tensor(DT.int, [M, N], Position.L0C)
    ub = Tensor(z.dtype, [M, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cvmutex.lock()
        ub <<= l0c.requant(scale=RQ_SCALE, offset=RQ_OFFSET)
        cvmutex.ready()
        cvmutex.wait()
        if GetSubBlockIdx() == 0:
            z[0:M, 0:N] <<= ub[0:M, 0:N]
        cvmutex.free()
    return z


@kernel()
def matmul_ub_dequant_int32_to_fp16(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """int8 @ int8 -> int32, dequantized to fp16 on the L0C->UB store (DEQF16), then UB->GM."""
    cvmutex = _cvmutex()
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l0c = Tensor(DT.int, [M, N], Position.L0C)
    ub = Tensor(DT.half, [M, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cvmutex.lock()
        ub <<= l0c.requant(scale=DQ_SCALE)         # offset unused for DEQF16
        cvmutex.ready()
        cvmutex.wait()
        if GetSubBlockIdx() == 0:
            z[0:M, 0:N] <<= ub[0:M, 0:N]
        cvmutex.free()
    return z


@kernel()
def matmul_ub_scaledcast_fp16(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32, scaled-cast to fp16 on the L0C->UB store (QF322F16_PRE), then UB->GM."""
    cvmutex = _cvmutex()
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    ub = Tensor(DT.half, [M, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cvmutex.lock()
        ub <<= l0c.requant(scale=SC_SCALE)
        cvmutex.ready()
        cvmutex.wait()
        if GetSubBlockIdx() == 0:
            z[0:M, 0:N] <<= ub[0:M, 0:N]
        cvmutex.free()
    return z


@kernel()
def matmul_ub_relu_quant_fp32_byte(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32, relu then quantize to int8 on the L0C->UB store, then UB->GM."""
    cvmutex = _cvmutex()
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    ub = Tensor(z.dtype, [M, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cvmutex.lock()
        ub <<= l0c.relu().requant(scale=QF_SCALE, offset=QF_OFFSET)   # relu + requant -> SINGLE
        cvmutex.ready()
        cvmutex.wait()
        if GetSubBlockIdx() == 0:
            z[0:M, 0:N] <<= ub[0:M, 0:N]
        cvmutex.free()
    return z


# ---- split-and-move: a tall L0C requant-stored to UB in two halves via static L0C row slices ----
@kernel()
def matmul_ub_split_quant_byte(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    """half @ half -> fp32 (M rows), then store to UB in two halves by slicing the L0C source:
    l0c[0:16, :] and l0c[16:32, :], each a SINGLE-mode 8-bit requant store, then UB -> GM.

    Requant is SINGLE-only, so a tall L0C is split into static row sub-tiles rather than using
    the SPLITM dual mode. Each sub-tile keeps the full-tile M stride (M_src = L0C shape[0]); the
    offset (0 / 16) selects the half. Demo fixes M=32 (two 16-row halves)."""
    cv0 = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    cv1 = CvMutex(1, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    ub0 = Tensor(z.dtype, [16, N], Position.UB)
    ub1 = Tensor(z.dtype, [16, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cv0.lock()
        ub0 <<= l0c[0:16, :].requant(scale=QF_SCALE, offset=QF_OFFSET)
        cv0.ready()
        cv1.lock()
        ub1 <<= l0c[16:32, :].requant(scale=QF_SCALE, offset=QF_OFFSET)
        cv1.ready()
        cv0.wait()
        if GetSubBlockIdx() == 0:
            z[0:16, :] <<= ub0[0:16, :]
        cv0.free()
        cv1.wait()
        if GetSubBlockIdx() == 0:
            z[16:32, :] <<= ub1[0:16, :]
        cv1.free()
    return z


def _force_single_core():
    """Force block_dim=1 so CANNSIM simulates one AI core (much faster). Validation-only."""
    import easyasc.kernelbase.kernelbase as kb
    kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda device_type: 1)


if __name__ == "__main__":
    import os
    import struct
    import sys

    import torch

    QF_M, QF_N, QF_K = 16, 32, 48
    RQ_M, RQ_N, RQ_K = 16, 32, 64
    SP_M, SP_N, SP_K = 32, 64, 48     # split-and-move: tall (M=32) L0C, two 16-row halves

    def _fp19(scale):
        u = struct.unpack("<I", struct.pack("<f", float(scale)))[0] & 0xFFFFE000
        return struct.unpack("<f", struct.pack("<I", u))[0]

    def _quant_8bit(acc, signed, scale, offset):
        r = torch.round(acc.float() * _fp19(scale))            # round half to even
        r = torch.clamp(r, -256.0, 255.0) + float(offset)
        lo, hi, dt = (-128.0, 127.0, torch.int8) if signed else (0.0, 255.0, torch.uint8)
        return torch.clamp(r, lo, hi).to(dt)

    def _dequant_fp16(acc, scale):
        return (acc.float() * _fp19(scale)).to(torch.float16)

    def _scaledcast(acc, scale, dt):
        return (acc.float() * _fp19(scale)).to(dt)

    torch.manual_seed(0)
    xf = torch.randint(-3, 4, (QF_M, QF_K)).to(torch.float16)
    yf = torch.randint(-3, 4, (QF_N, QF_K)).to(torch.float16)
    acc_f = xf.float() @ yf.float().t()

    xi = torch.randint(-3, 4, (RQ_M, RQ_K), dtype=torch.int8)
    yi = torch.randint(-3, 4, (RQ_N, RQ_K), dtype=torch.int8)
    acc_i = xi.int() @ yi.int().t()

    xs = torch.randint(-3, 4, (SP_M, SP_K)).to(torch.float16)
    ys = torch.randint(-3, 4, (SP_N, SP_K)).to(torch.float16)
    acc_s = xs.float() @ ys.float().t()

    # slug, kernel, x, y, M, N, K, out_dtype, reference
    cases = (
        ("qf322b8_int8", matmul_ub_quant_fp32_byte, xf, yf, QF_M, QF_N, QF_K, torch.int8,
         _quant_8bit(acc_f, True, QF_SCALE, QF_OFFSET)),
        ("qf322b8_uint8", matmul_ub_quant_fp32_byte, xf, yf, QF_M, QF_N, QF_K, torch.uint8,
         _quant_8bit(acc_f, False, QF_SCALE, QF_OFFSET)),
        ("req8_int8", matmul_ub_requant_int32_byte, xi, yi, RQ_M, RQ_N, RQ_K, torch.int8,
         _quant_8bit(acc_i, True, RQ_SCALE, RQ_OFFSET)),
        ("deqf16", matmul_ub_dequant_int32_to_fp16, xi, yi, RQ_M, RQ_N, RQ_K, torch.float16,
         _dequant_fp16(acc_i, DQ_SCALE)),
        ("qf322f16", matmul_ub_scaledcast_fp16, xf, yf, QF_M, QF_N, QF_K, torch.float16,
         _scaledcast(acc_f, SC_SCALE, torch.float16)),
        ("relu_qf322b8", matmul_ub_relu_quant_fp32_byte, xf, yf, QF_M, QF_N, QF_K, torch.int8,
         _quant_8bit(torch.clamp(acc_f, min=0), True, QF_SCALE, QF_OFFSET)),
        ("split_qf322b8", matmul_ub_split_quant_byte, xs, ys, SP_M, SP_N, SP_K, torch.int8,
         _quant_8bit(acc_s, True, QF_SCALE, QF_OFFSET)),
    )

    use_cannsim = "--cannsim" in sys.argv[1:]
    wanted = [a for a in sys.argv[1:] if not a.startswith("-")]   # optional slug filter
    base = os.environ.get("QUANT_BASE", "./tmp/a5_quant_cannsim")
    cann = os.environ.get("ASCEND_HOME_PATH") or ""
    if use_cannsim:
        _force_single_core()

    failures = 0
    for slug, kern, xt, yt, M, N, K, odt, ref in cases:
        if wanted and slug not in wanted:
            continue
        z = torch.zeros((M, N), dtype=odt)
        if use_cannsim:
            got = OpExec(kern, simulator=False, cannsim=True, cann_path=cann,
                         custom_op_path=os.path.join(base, "ub_" + slug, "custom_opp"),
                         out_dir=os.path.join(base, "ub_" + slug))(xt, yt, z, M, N, K)
        else:
            got = OpExec(kern, simulator=True)(xt, yt, z, M, N, K)

        float_tols = {torch.float16: 4e-3}
        if odt in float_tols:
            tol = float_tols[odt]
            ok = torch.allclose(got.float(), ref.float(), rtol=tol, atol=tol)
            diff = torch.abs(got.float() - ref.float()).max().item()
        else:
            ok = torch.equal(got, ref)
            diff = int(torch.abs(got.int() - ref.int()).max().item())

        failures += 0 if ok else 1
        print("{:<14} [{}] {} max_abs_diff={}".format(
            slug, "cannsim" if use_cannsim else "sim", "PASS" if ok else "FAIL", diff))

    if failures:
        raise SystemExit("{} case(s) FAILED".format(failures))
