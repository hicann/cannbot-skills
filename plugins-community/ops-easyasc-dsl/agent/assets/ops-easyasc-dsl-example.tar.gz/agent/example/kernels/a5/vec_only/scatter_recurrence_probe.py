"""Does a loop-carried UB scatter recurrence hold on real A5 hardware?

`agent/references/constraints/sync.md` warns that a loop-carried, same-base
`DataCopyGather` / `DataCopyScatter` read-modify-write recurrence failed to
publish on Ascend 950PR with CANN 9.2.  A tiled scatter operator is built out of
exactly that shape, so the design cannot be chosen without measuring it.

Four probes, all over one UB tile that is seeded from GM and written back:

``waw``
    ROWS successive scatters into the same tile, no read.  This is the
    ``reduce=None`` inner loop.  Correct iff the later row wins every slot both
    rows touch.

``rmw``
    ROWS successive gather -> add -> scatter round trips into the same tile.
    This is the ``reduce=add`` inner loop.  Indices are unique *within* a row,
    so a failure can only come from the recurrence, not from lane collisions.

``rmw_fenced``
    Same as ``rmw`` with `vf_barrier(STORE, LOAD)` between the scatter and the
    next gather.

``dup``
    One register whose lanes deliberately collide.  The API doc says the last
    active lane wins; that rule is what makes a ``reduce=None`` row safe when
    the tile is only one column wide.

Run:
- simulator:  python kernels/a5/vec_only/scatter_recurrence_probe.py
- A5 board:   python kernels/a5/vec_only/scatter_recurrence_probe.py --run
"""
import builtins
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

TILE = 4096
LANES = 128
ROWS = 8
DUP_SLOTS = 16


@vf()
def waw_vf(y_ub: Tensor, idx_ub: Tensor, val_ub: Tensor, rows: Var, lanes: Var):
    index_signed = Reg(DT.int16, name="probe_waw_index_signed")
    value = Reg(DT.half, name="probe_waw_value")
    active = MaskReg(DT.half, init_mode=MaskType.NONE, name="probe_waw_active")
    for probe_waw_row in range(rows, name="probe_waw_row"):
        offset = Var(probe_waw_row * LANES)
        update_mask(active, Var(lanes, dtype=DT.uint32))
        ub_to_reg_normal(index_signed, idx_ub[offset])
        ub_to_reg_normal(value, val_ub[offset])
        index = index_signed.reinterpret(DT.uint16, name="probe_waw_index")
        reg_to_ub_scatter(y_ub[0:1, 0:TILE], value, index, mask=active)


@kernel(mode="vec")
def scatter_waw_probe_kernel(
    seed: GMTensor, idx: GMTensor, val: GMTensor, out: GMTensor,
    rows: Var, lanes: Var,
):
    y_ub = Tensor(DT.half, [1, TILE], Position.UB, name="probe_waw_y")
    idx_ub = Tensor(DT.int16, [1, ROWS * LANES], Position.UB, name="probe_waw_idx")
    val_ub = Tensor(DT.half, [1, ROWS * LANES], Position.UB, name="probe_waw_val")
    with auto_sync():
        y_ub[:, :] <<= seed[0:1, :]
        idx_ub[:, :] <<= idx[0:1, :]
        val_ub[:, :] <<= val[0:1, :]
        waw_vf(y_ub, idx_ub, val_ub, rows, lanes)
        out[0:1, :] <<= y_ub
    return out


@vf()
def waw_fenced_vf(
    y_ub: Tensor, idx_ub: Tensor, val_ub: Tensor, rows: Var, lanes: Var,
):
    index_signed = Reg(DT.int16, name="probe_wawf_index_signed")
    value = Reg(DT.half, name="probe_wawf_value")
    active = MaskReg(DT.half, init_mode=MaskType.NONE, name="probe_wawf_active")
    for probe_wawf_row in range(rows, name="probe_wawf_row"):
        offset = Var(probe_wawf_row * LANES)
        update_mask(active, Var(lanes, dtype=DT.uint32))
        ub_to_reg_normal(index_signed, idx_ub[offset])
        ub_to_reg_normal(value, val_ub[offset])
        index = index_signed.reinterpret(DT.uint16, name="probe_wawf_index")
        reg_to_ub_scatter(y_ub[0:1, 0:TILE], value, index, mask=active)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)


@kernel(mode="vec")
def scatter_waw_fenced_probe_kernel(
    seed: GMTensor, idx: GMTensor, val: GMTensor, out: GMTensor,
    rows: Var, lanes: Var,
):
    y_ub = Tensor(DT.half, [1, TILE], Position.UB, name="probe_wawf_y")
    idx_ub = Tensor(DT.int16, [1, ROWS * LANES], Position.UB, name="probe_wawf_idx")
    val_ub = Tensor(DT.half, [1, ROWS * LANES], Position.UB, name="probe_wawf_val")
    with auto_sync():
        y_ub[:, :] <<= seed[0:1, :]
        idx_ub[:, :] <<= idx[0:1, :]
        val_ub[:, :] <<= val[0:1, :]
        waw_fenced_vf(y_ub, idx_ub, val_ub, rows, lanes)
        out[0:1, :] <<= y_ub
    return out


@vf()
def rmw_vf(y_ub: Tensor, idx_ub: Tensor, val_ub: Tensor, rows: Var, lanes: Var):
    index_signed = Reg(DT.int16, name="probe_rmw_index_signed")
    value = Reg(DT.half, name="probe_rmw_value")
    current = Reg(DT.half, name="probe_rmw_current")
    active = MaskReg(DT.half, init_mode=MaskType.NONE, name="probe_rmw_active")
    for probe_rmw_row in range(rows, name="probe_rmw_row"):
        offset = Var(probe_rmw_row * LANES)
        update_mask(active, Var(lanes, dtype=DT.uint32))
        ub_to_reg_normal(index_signed, idx_ub[offset])
        ub_to_reg_normal(value, val_ub[offset])
        index = index_signed.reinterpret(DT.uint16, name="probe_rmw_index")
        ub_to_reg_gather(current, y_ub[0:1, 0:TILE], index, mask=active)
        add(value, value, current, mask=active)
        reg_to_ub_scatter(y_ub[0:1, 0:TILE], value, index, mask=active)


@kernel(mode="vec")
def scatter_rmw_probe_kernel(
    seed: GMTensor, idx: GMTensor, val: GMTensor, out: GMTensor,
    rows: Var, lanes: Var,
):
    y_ub = Tensor(DT.half, [1, TILE], Position.UB, name="probe_rmw_y")
    idx_ub = Tensor(DT.int16, [1, ROWS * LANES], Position.UB, name="probe_rmw_idx")
    val_ub = Tensor(DT.half, [1, ROWS * LANES], Position.UB, name="probe_rmw_val")
    with auto_sync():
        y_ub[:, :] <<= seed[0:1, :]
        idx_ub[:, :] <<= idx[0:1, :]
        val_ub[:, :] <<= val[0:1, :]
        rmw_vf(y_ub, idx_ub, val_ub, rows, lanes)
        out[0:1, :] <<= y_ub
    return out


@vf()
def rmw_fenced_vf(
    y_ub: Tensor, idx_ub: Tensor, val_ub: Tensor, rows: Var, lanes: Var,
):
    index_signed = Reg(DT.int16, name="probe_fen_index_signed")
    value = Reg(DT.half, name="probe_fen_value")
    current = Reg(DT.half, name="probe_fen_current")
    active = MaskReg(DT.half, init_mode=MaskType.NONE, name="probe_fen_active")
    for probe_fen_row in range(rows, name="probe_fen_row"):
        offset = Var(probe_fen_row * LANES)
        update_mask(active, Var(lanes, dtype=DT.uint32))
        ub_to_reg_normal(index_signed, idx_ub[offset])
        ub_to_reg_normal(value, val_ub[offset])
        index = index_signed.reinterpret(DT.uint16, name="probe_fen_index")
        ub_to_reg_gather(current, y_ub[0:1, 0:TILE], index, mask=active)
        add(value, value, current, mask=active)
        reg_to_ub_scatter(y_ub[0:1, 0:TILE], value, index, mask=active)
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel(mode="vec")
def scatter_rmw_fenced_probe_kernel(
    seed: GMTensor, idx: GMTensor, val: GMTensor, out: GMTensor,
    rows: Var, lanes: Var,
):
    y_ub = Tensor(DT.half, [1, TILE], Position.UB, name="probe_fen_y")
    idx_ub = Tensor(DT.int16, [1, ROWS * LANES], Position.UB, name="probe_fen_idx")
    val_ub = Tensor(DT.half, [1, ROWS * LANES], Position.UB, name="probe_fen_val")
    with auto_sync():
        y_ub[:, :] <<= seed[0:1, :]
        idx_ub[:, :] <<= idx[0:1, :]
        val_ub[:, :] <<= val[0:1, :]
        rmw_fenced_vf(y_ub, idx_ub, val_ub, rows, lanes)
        out[0:1, :] <<= y_ub
    return out


@vf()
def dup_vf(y_ub: Tensor, idx_ub: Tensor, val_ub: Tensor, lanes: Var):
    index_signed = Reg(DT.int16, name="probe_dup_index_signed")
    value = Reg(DT.half, name="probe_dup_value")
    active = MaskReg(DT.half, init_mode=MaskType.NONE, name="probe_dup_active")
    update_mask(active, Var(lanes, dtype=DT.uint32))
    ub_to_reg_normal(index_signed, idx_ub[0])
    ub_to_reg_normal(value, val_ub[0])
    index = index_signed.reinterpret(DT.uint16, name="probe_dup_index")
    reg_to_ub_scatter(y_ub[0:1, 0:TILE], value, index, mask=active)


@kernel(mode="vec")
def scatter_dup_probe_kernel(
    seed: GMTensor, idx: GMTensor, val: GMTensor, out: GMTensor, lanes: Var,
):
    y_ub = Tensor(DT.half, [1, TILE], Position.UB, name="probe_dup_y")
    idx_ub = Tensor(DT.int16, [1, ROWS * LANES], Position.UB, name="probe_dup_idx")
    val_ub = Tensor(DT.half, [1, ROWS * LANES], Position.UB, name="probe_dup_val")
    with auto_sync():
        y_ub[:, :] <<= seed[0:1, :]
        idx_ub[:, :] <<= idx[0:1, :]
        val_ub[:, :] <<= val[0:1, :]
        dup_vf(y_ub, idx_ub, val_ub, lanes)
        out[0:1, :] <<= y_ub
    return out


def _reference(seed, idx, val, mode):
    y = seed.clone().float()
    flat_idx = idx.reshape(-1).tolist()
    flat_val = val.reshape(-1).float().tolist()
    for position, target in builtins.enumerate(flat_idx):
        if mode == "add":
            y[0, target] = torch.tensor(
                y[0, target] + flat_val[position], dtype=torch.float16,
            ).float()
        else:
            y[0, target] = flat_val[position]
    return y


def main(run):
    mode = "board" if run else "sim"
    torch.manual_seed(7)
    cfg = dict(simulator=False, debug=False,
               cann_path=os.environ["ASCEND_HOME_PATH"]) if run else dict(simulator=True)

    seed = torch.arange(TILE, dtype=torch.float16).reshape(1, TILE) * 0.0 - 1.0
    base_values = (torch.randn(1, ROWS * LANES) * 4).round().to(torch.float16)

    # One permutation sliced with a stride below LANES: unique inside every row
    # (so a mismatch can only be the recurrence, never a lane collision) while
    # consecutive rows still overlap in LANES - stride slots.
    stride = 96
    permutation = torch.randperm(TILE)
    unique_rows = [
        permutation[row * stride:row * stride + LANES]
        for row in builtins.range(ROWS)
    ]
    unique_idx = torch.stack(unique_rows).reshape(1, -1).to(torch.int16)

    dup_idx = torch.zeros(1, ROWS * LANES, dtype=torch.int16)
    dup_idx[0, :LANES] = torch.arange(LANES, dtype=torch.int16) % DUP_SLOTS

    probes = (
        ("waw", scatter_waw_probe_kernel, unique_idx, "update",
         (ROWS, LANES)),
        ("waw_fenced", scatter_waw_fenced_probe_kernel, unique_idx, "update",
         (ROWS, LANES)),
        ("rmw", scatter_rmw_probe_kernel, unique_idx, "add", (ROWS, LANES)),
        ("rmw_fenced", scatter_rmw_fenced_probe_kernel, unique_idx, "add",
         (ROWS, LANES)),
        ("dup", scatter_dup_probe_kernel, dup_idx, "update", (LANES,)),
    )

    # The duplicate probe answers "which lane survives a same-slot collision",
    # so its payload is the lane index itself: whatever lands in a slot names
    # the lane that won it.
    lane_values = torch.arange(
        ROWS * LANES, dtype=torch.float16,
    ).reshape(1, -1)

    for tag, kernel_fn, index_tensor, reduce_mode, scalars in probes:
        out = torch.zeros(1, TILE, dtype=torch.float16)
        rows_used = 1 if tag == "dup" else ROWS
        values = lane_values if tag == "dup" else base_values
        expected = _reference(
            seed, index_tensor[:, :rows_used * LANES],
            values[:, :rows_used * LANES], reduce_mode,
        )
        try:
            result = OpExec(
                kernel_fn, out_dir=os.path.abspath("tmp/screc/" + tag),
                custom_op_path=os.path.abspath("tmp/screc/opp"), **cfg,
            )(seed.contiguous(), index_tensor.contiguous(),
              values.contiguous(), out, *scalars)
            got = (result if isinstance(result, torch.Tensor) else result[0])
            got = got.reshape(1, TILE).float()
            wrong = int((got != expected).sum())
            first = ""
            if wrong:
                where = (got != expected).nonzero()[0].tolist()
                first = " first@{} got={} want={}".format(
                    where[1], got[0, where[1]].item(), expected[0, where[1]].item(),
                )
            winners = ""
            if tag == "dup":
                winners = " slots[0:8]=" + str(
                    [int(x) for x in got[0, :8].tolist()]
                ) + " want=" + str(
                    [int(x) for x in expected[0, :8].tolist()]
                )
            print("[{}] {:11s} mismatches={:5d} -> {}{}{}".format(
                mode, tag, wrong, "PASS" if wrong == 0 else "FAIL", first,
                winners,
            ))
        except Exception as exc:  # noqa: BLE001
            print("[{}] {:11s} ERROR {}: {}".format(
                mode, tag, type(exc).__name__, str(exc)[:240],
            ))


if __name__ == "__main__":
    main("--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1")
