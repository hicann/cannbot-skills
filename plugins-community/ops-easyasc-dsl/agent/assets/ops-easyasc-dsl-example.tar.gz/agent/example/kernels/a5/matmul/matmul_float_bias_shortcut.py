"""fp32 matmul with bias via the matmul() shortcut (a5/950).

Exercises ``matmul(dst, l1a, l1b, ..., bias=l1bias)`` across all three tiling
modes -- nosplit, splitn, splitk -- computing z = x@y.t() + bias. The bias is a
contiguous fp32 [1, N] row staged into L1 with gm_to_l1_pad (NOT the <<= nd2nz
sugar, which would fractalize the row). The shortcut routes it through the
kernel's auto-inserted BT/C2 double-buffer (_btbuf/_btbufcnt): for splitn each
N-tile stages its own bias slice bias[:, n0:n0+valid_n] into a fresh BT slot
(ping-pong); for splitk the full row is staged once and added on the is_init
K-tile. Nosplit and splitk use an explicit static N=64 contract so the full row
is provably within one A5 BT slot; splitn keeps runtime N with a static 32-element
tile bound.

Validated on the simulator (all three modes); --cannsim runs all three modes
(VM only, single core); splitn exercises the per-tile L1->C2 source offset. Add
--mode <nosplit|splitn|splitk> to build/run just one mode.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_shortcut.py            # simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_shortcut.py --gen-only
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_shortcut.py --cannsim              # VM only, all 3
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python matmul_float_bias_shortcut.py --cannsim --mode splitk
"""
from easyasc.a5 import *


STATIC_BIAS_N = 64


@kernel()
def bias_nosplit(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor, M: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [STATIC_BIAS_N, K], Position.L1)
    l1b = Tensor(DT.float, [1, STATIC_BIAS_N], Position.L1)
    l0c = Tensor(DT.float, [M, STATIC_BIAS_N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        gm_to_l1_pad(l1b, bias[:, :])
        matmul(l0c, l1x, l1y, m=M, n=STATIC_BIAS_N, k=K, is_init=True, bias=l1b)
        z[:, :] <<= l0c
    return z


@kernel()
def bias_splitn(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l1b = Tensor(DT.float, [1, N], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        gm_to_l1_pad(l1b, bias[:, :])
        matmul(l0c, l1x, l1y, splitn=32, m=M, n=N, k=K, is_init=True, bias=l1b)
        z[:, :] <<= l0c
    return z


@kernel()
def bias_splitk(x: GMTensor, y: GMTensor, bias: GMTensor, z: GMTensor, M: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [STATIC_BIAS_N, K], Position.L1)
    l1b = Tensor(DT.float, [1, STATIC_BIAS_N], Position.L1)
    l0c = Tensor(DT.float, [M, STATIC_BIAS_N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        gm_to_l1_pad(l1b, bias[:, :])
        matmul(
            l0c, l1x, l1y, splitk=16, m=M, n=STATIC_BIAS_N, k=K,
            is_init=True, bias=l1b,
        )
        z[:, :] <<= l0c
    return z


def _force_single_core():
    """Force block_dim=1 so CANNSIM simulates one AI core (much faster). Validation
    only; does not touch the repo."""
    import easyasc.kernelbase.kernelbase as kb
    kb.KernelBase._resolve_op_host_block_dim = staticmethod(lambda device_type: 1)


if __name__ == "__main__":
    import os
    import sys

    import torch

    # Distinct M/N/K so the OpExec shape inference is unambiguous; small + single
    # core keeps CANNSIM fast. splitn=32 -> 2 N-tiles, splitk=16 -> 3 K-tiles.
    M, N, K = 32, 64, 48
    torch.manual_seed(0)
    x = torch.randn((M, K), dtype=torch.float32)
    y = torch.randn((N, K), dtype=torch.float32)
    bias = torch.randn((1, N), dtype=torch.float32)
    z_ref = x @ y.t() + bias

    gen_only = "--gen-only" in sys.argv[1:]
    use_cannsim = "--cannsim" in sys.argv[1:]

    modes = [
        ("nosplit", bias_nosplit, False),
        ("splitn", bias_splitn, True),
        ("splitk", bias_splitk, False),
    ]

    if not gen_only and not use_cannsim:
        for name, kern, dynamic_n in modes:
            z = torch.zeros((M, N), dtype=torch.float32)
            scalar_args = (M, N, K) if dynamic_n else (M, K)
            z_out = OpExec(kern, simulator=True)(x, y, bias, z, *scalar_args)
            torch.testing.assert_close(z_out, z_ref, rtol=1e-4, atol=1e-4)
            print("matmul shortcut bias [{}] passed max_abs_diff={:.6e}".format(
                name, float(torch.abs(z_out - z_ref).max().item())))
    else:
        # CANNSIM / codegen path (VM-local build; single core). Run all three modes so
        # splitk/splitn/nosplit bias staging + per-tile slicing are each validated; splitn
        # exercises the per-N-tile L1->C2 source offset. Each mode gets an isolated out_dir
        # and custom_op_path so the sequential CANN builds don't clobber each other.
        if use_cannsim:
            _force_single_core()
        base = os.environ.get("BIAS_BASE", "./tmp/a5_bias_cannsim")
        only = None
        if "--mode" in sys.argv[1:]:
            only = sys.argv[sys.argv.index("--mode") + 1]
        for name, kern, dynamic_n in modes:
            if only is not None and name != only:
                continue
            z = torch.zeros((M, N), dtype=torch.float32)
            out_dir = os.path.join(base, "biasshortcut_" + name)
            scalar_args = (M, N, K) if dynamic_n else (M, K)
            z_out = OpExec(
                kern,
                simulator=False,
                cannsim=use_cannsim,
                gen_only=gen_only,
                cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
                custom_op_path=os.path.join(base, "custom_opp_" + name),
                out_dir=out_dir,
            )(x, y, bias, z, *scalar_args)
            if gen_only:
                print("gen_only [{}] complete -> {}".format(name, out_dir))
            else:
                torch.testing.assert_close(z_out, z_ref, rtol=1e-4, atol=1e-4)
                print("cannsim matmul shortcut bias [{}] passed max_abs_diff={:.6e}".format(
                    name, float(torch.abs(z_out - z_ref).max().item())))
