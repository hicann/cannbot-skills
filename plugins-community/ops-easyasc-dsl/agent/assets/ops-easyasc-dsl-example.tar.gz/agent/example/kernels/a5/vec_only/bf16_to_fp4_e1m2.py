"""A5 vec-only BF16 -> packed FP4 E1M2 cast.

Contract:
- input:  ``x`` in BF16 ND layout with fixed shape ``[64, 128]``;
- output: ``y_carrier`` in uint8 with shape ``[64, 64]``;
- every output byte stores two consecutive FP4 E1M2 payloads along the last
  axis, with the lower-index payload in the low nibble;
- conversion uses ``RoundMode.TO_EVEN`` (CANN ``CAST_RINT``).
"""

import os
import sys

import torch

from easyasc.a5 import *


ROWS = 64
COLS = 128
PACKED_COLS = COLS // 2


@vf()
def cast_bf16_to_fp4_e1m2_vf(src: Tensor, dst: Tensor):
    src_reg = Reg(DT.bfloat16, name="src_reg")
    dst_reg = Reg(DT.fp4_e1m2, name="dst_reg")
    dst_carrier_reg = dst_reg.reinterpret(DT.uint8, name="dst_carrier_reg")
    mask = MaskReg(DT.bfloat16, name="bf16_mask")
    cfg = CastConfig(
        round_mode=RoundMode.TO_EVEN,
        reg_layout=RegLayout.ZERO,
        name="bf16_to_fp4_e1m2_rint",
    )

    src_reg <<= src[0]
    cast(dst_reg, src_reg, cfg, mask)
    # BF16->FP4 writes packed carrier bytes into every fourth uint8 register
    # slot selected by RegLayout.ZERO. PACK4 compacts those bytes for UB/GM.
    dst[0] <<= dst_carrier_reg.pack4()


@kernel(mode="vec")
def bf16_to_fp4_e1m2_kernel(x: GMTensor, y_carrier: GMTensor, rows: Var):
    ub_src = Tensor(DT.bfloat16, [1, COLS], Position.UB, name="ub_src")
    ub_dst_u8 = Tensor(DT.uint8, [1, PACKED_COLS], Position.UB, name="ub_dst_u8")

    rows_per_vec = CeilDiv(rows, GetVecNum())
    row_begin = Var(rows_per_vec * GetVecIdx())
    row_end = Min(row_begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(row_begin, row_end, name="row"):
            ub_src[:, :] <<= x[row:row + 1, :]
            cast_bf16_to_fp4_e1m2_vf(ub_src, ub_dst_u8)
            y_carrier[row:row + 1, :] <<= ub_dst_u8

    return y_carrier


def _build_input() -> torch.Tensor:
    # Includes exact values, tie cases, sub-minimum values, and saturation cases.
    pattern = torch.tensor(
        [
            -3.0, -1.875, -1.75, -1.625, -1.5, -1.375, -1.25, -1.125,
            -1.0, -0.875, -0.75, -0.625, -0.5, -0.375, -0.25, -0.125,
            0.0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875,
            1.0, 1.125, 1.25, 1.375, 1.5, 1.625, 1.75, 3.0,
        ],
        dtype=torch.bfloat16,
    )
    repeats = (ROWS * COLS + int(pattern.numel()) - 1) // int(pattern.numel())
    return pattern.repeat(repeats)[:ROWS * COLS].reshape(ROWS, COLS).contiguous()


def _run(use_cannsim: bool, gen_only: bool) -> None:
    x = _build_input()
    y = torch.zeros((ROWS, PACKED_COLS), dtype=torch.uint8)
    mode_dir = "cannsim" if use_cannsim else "sim"

    actual = OpExec(
        bf16_to_fp4_e1m2_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/bf16_to_fp4_e1m2/custom_opp"),
        out_dir=os.path.abspath(f"tmp/bf16_to_fp4_e1m2/{mode_dir}"),
    )(x, y, ROWS)

    if gen_only:
        print("bf16_to_fp4_e1m2 gen_only complete")
        return

    expected = fp32_to_fp4_e1m2(x.float(), pack_axis=-1, round_mode=RoundMode.TO_EVEN)
    if not torch.equal(actual, expected):
        mismatch = torch.nonzero(actual != expected, as_tuple=False)
        first = mismatch[0].tolist()
        raise AssertionError(
            "packed carrier mismatch count={} first_index={} actual=0x{:02x} expected=0x{:02x}".format(
                int(mismatch.shape[0]), first, int(actual[tuple(first)].item()), int(expected[tuple(first)].item())
            )
        )

    decoded = fp4_e1m2_to_fp32(actual, logical_shape=(ROWS, COLS), pack_axis=-1)
    print(
        "bf16_to_fp4_e1m2 passed carrier_mismatches=0 decoded_max_abs_diff={:.6e}".format(
            float(torch.abs(decoded - x.float()).max().item())
        )
    )


if __name__ == "__main__":
    _run(use_cannsim="--cannsim" in sys.argv[1:], gen_only="--gen-only" in sys.argv[1:])
