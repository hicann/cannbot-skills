"""Step 2: w OIHW -> conv fractal [COUT, K] ND on device (a2 vec, fp16).

w  [COUT, CIN*KH*KW]   flat OIHW; column order (cin, kh, kw), cin = c1*16 + c0
wz [COUT, K]           K order (c1, kh, kw, c0) = pack_conv_weight host layout

Row stays cout, only columns permute, so the slab transposes twice through
vnchwconv: [16 couts, 144] -> t1 [144, 16] (rows = cin-major c0*9+j) -> second
pass picks the 16 c0 rows per filter tap j and lands them back at [co, j*16+c0].
Per (cout block, c1) one (9 + 9)-repeat pair on a [16, 144] slab.

  PYTHONPATH=<repo> python transdata_w_to_fractal.py            # python simulator
  PYTHONPATH=<repo> python transdata_w_to_fractal.py --debug    # 910B3 standalone
"""
from easyasc.a2 import *

from common import C0, C1, CIN, COUT, DEBUG, K, KH, KW, N_VEC

TAPS = KH * KW                  # 9
KC1 = TAPS * C0                 # 144 K columns per c1
NCOB = COUT // 16               # 8 cout blocks


@kernel()
def transdata_w_to_fractal(w: GMTensor, wz: GMTensor, nv: Var):
    # contiguous per-lane unit block + DBuff (slots alternate per iteration).
    src = DBuff(DT.half, [16, KC1], Position.UB)
    t1 = DBuff(DT.half, [KC1, 16], Position.UB)
    t2 = DBuff(DT.half, [16, KC1], Position.UB)
    vec_idx = GetVecIdx()
    units = NCOB * C1
    per_lane = (units + N_VEC - 1) // N_VEC
    begin = per_lane * vec_idx
    end = Min(begin + per_lane, units)
    with auto_sync():
        for u in range(begin, end):
            cob = var_div(u, C1)
            c1 = var_mod(u, C1)
            sb = src[u]
            tb1 = t1[u]
            tb2 = t2[u]
            sb <<= w[cob * 16:cob * 16 + 16, c1 * KC1:c1 * KC1 + KC1]
            transdata5hd(tb1, sb, repeat=TAPS,
                         src_row_stride=KC1, dst_row_stride=16,
                         src_rep_stride=1, dst_rep_stride=16)
            transdata5hd(tb2, tb1, repeat=TAPS,
                         src_row_stride=TAPS * 16, dst_row_stride=KC1,
                         src_rep_stride=1, dst_rep_stride=1)
            wz[cob * 16:cob * 16 + 16, c1 * KC1:c1 * KC1 + KC1] <<= tb2
    return wz


if __name__ == "__main__":
    import torch

    torch.manual_seed(8)
    w = torch.randn((COUT, CIN, KH, KW), dtype=torch.float16)
    wz = torch.zeros((COUT, K), dtype=torch.float16)
    ref = torch.from_numpy(pack_conv_weight(w.numpy()))
    got = OpExec(transdata_w_to_fractal, simulator=not DEBUG, debug=DEBUG)(
        w.reshape(COUT, CIN * KH * KW), wz, N_VEC)
    assert torch.equal(got, ref), float((got.float() - ref.float()).abs().max())
    print("transdata_w_to_fractal {}x{}x{}x{} exact".format(COUT, CIN, KH, KW))
