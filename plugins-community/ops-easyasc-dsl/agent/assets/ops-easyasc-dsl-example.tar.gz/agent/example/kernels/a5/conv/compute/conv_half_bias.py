"""fp16 conv2d + fp32 bias via load3d img2col on a5: y = conv(x, w) + b.

Same spec as kernels/a2/conv/compute/conv_half_bias.py, ported to a5. Prime runtime
channels (C=31, COUT=47) exercise the zero-padded C/N tails through the Var path.
Bias is staged as a flat L1 ND row (matmul idiom) and routed through conv2d() ->
l1_to_bt (BT/C2) on the is_init K-tile.

  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python conv_half_bias.py          # python simulator
  PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python conv_half_bias.py --run     # real Ascend950
"""
from easyasc.a5 import *

C0 = 16
KH = KW = 3
PAD = (1, 1, 1, 1)
TILE_M = 32
# static worst-case capacities; pairwise distinct from every GM dim
C_MAX, H_MAX, W_MAX, COUT_MAX = 32, 8, 8, 48
C1_MAX = (C_MAX + C0 - 1) // C0
K_MAX = C1_MAX * KH * KW * C0
COUT_P = (COUT_MAX + 15) // 16 * 16
C1O = COUT_P // C0
TILE_K = 144                                    # divides K for every C1 in 1..C1_MAX


@kernel()
def conv_half_bias(data: GMTensor, weight: GMTensor, bias: GMTensor, out: GMTensor,
                   h: Var, w: Var, c: Var, cout: Var, m_pad: Var):
    conv = Conv2D(KH, KW, pad=PAD)
    fm = Tensor(DT.half, [C1_MAX * H_MAX * W_MAX, C0], Position.L1)
    w_l1 = Tensor(DT.half, [COUT_P, K_MAX], Position.L1)
    b_l1 = Tensor(DT.float, [1, COUT_P], Position.L1, layout=Layout.ND)
    l0c = Tensor(DT.float, [TILE_M, COUT_P], Position.L0C)
    with auto_sync():
        fm <<= data[:, :]
        w_l1 <<= weight[:, :]
        b_l1 <<= bias[:, :]                 # ND layout -> flat gm_to_l1 (BT contract)
        for m0 in range(0, m_pad, TILE_M):
            conv2d(l0c, fm, w_l1, conv, h=h, w=w, c=c, cout=cout, m0=m0,
                   tile_k=TILE_K, bias=b_l1)
            l0c_to_gm_nz2nz(out[m0:m0 + TILE_M, :], l0c, m_pad=m_pad)
    return out


if __name__ == "__main__":
    import sys
    import torch
    from easyasc.utils.conv2d import pack_nc1hwc0, pack_conv_weight

    torch.manual_seed(1)
    C, H, W, COUT = 31, H_MAX, W_MAX, 47    # prime runtime channels < static caps
    HO = H + PAD[2] + PAD[3] - KH + 1
    WO = W + PAD[0] + PAD[1] - KW + 1
    M_PAD = (HO * WO + 15) // 16 * 16
    x = torch.randn((1, C, H, W), dtype=torch.float16)
    w = torch.randn((COUT, C, KH, KW), dtype=torch.float16)
    b = torch.randn((COUT,), dtype=torch.float32)
    data = torch.zeros((C1_MAX * H_MAX * W_MAX, C0), dtype=torch.float16)
    data[:(C + C0 - 1) // C0 * H * W] = torch.from_numpy(pack_nc1hwc0(x.numpy()))
    wz = torch.zeros((COUT_P, K_MAX), dtype=torch.float16)
    wk = torch.from_numpy(pack_conv_weight(w.numpy()))
    wz[:wk.shape[0], :wk.shape[1]] = wk
    bp = torch.zeros((1, COUT_P), dtype=torch.float32)
    bp[0, :COUT] = b
    out = torch.zeros((C1O * M_PAD, C0), dtype=torch.float32)
    ref = torch.nn.functional.conv2d(x.float(), w.float(), b, padding=1)
    ref = ref.reshape(COUT, HO * WO).t()

    run = "--run" in sys.argv[1:]
    got = OpExec(conv_half_bias, simulator=not run, debug=False)(
        data, wz, bp, out, H, W, C, COUT, M_PAD)
    got = got.reshape(C1O, M_PAD, C0).permute(1, 0, 2).reshape(M_PAD, COUT_P)  # NZ -> ND
    got = got[:HO * WO, :COUT]
    torch.testing.assert_close(got, ref, rtol=3e-3, atol=3e-3)
    print("conv_half_bias max_abs_diff={:.6e}".format(float((got - ref).abs().max())))
