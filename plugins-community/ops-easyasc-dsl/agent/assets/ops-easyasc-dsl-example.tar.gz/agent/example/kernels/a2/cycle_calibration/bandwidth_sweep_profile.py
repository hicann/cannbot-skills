import argparse
import csv
import os
import re
from typing import Dict, Iterable, List, Optional, Tuple

import torch

from easyasc.a2 import *


COLS = 128
MAX_ROWS = 256
STATUS_ELEMS = 64
DEFAULT_ROWS = (32, 64, 128, 256)
DEFAULT_REPEATS = 256
DEFAULT_CORE_COUNT = 20
VEC_LANES_PER_CORE = 2
PROFILE_RE = re.compile(r"---- N_TESTS:\s+\d+\s+AVG:\s+([0-9.]+)us")


@kernel()
def bw_empty_kernel(dummy: GMTensor, status: GMTensor, rows: Var, repeats: Var):
    status_ub = Tensor(DT.float, [1, STATUS_ELEMS], Position.UB)

    for _ in range(0, repeats):
        pass

    with vec_scope():
        status_row = GetCubeIdx() * VEC_LANES_PER_CORE + GetSubBlockIdx()
        with auto_sync():
            dup(status_ub, 0.0)
            status[status_row:status_row + 1, 0:STATUS_ELEMS] <<= status_ub
    return status


@kernel()
def bw_gm_to_l1_kernel(src: GMTensor, status: GMTensor, rows: Var, repeats: Var):
    l1 = Tensor(DT.half, [MAX_ROWS, COLS], Position.L1)
    status_ub = Tensor(DT.float, [1, STATUS_ELEMS], Position.UB)

    with cube_scope():
        tile_rows = rows * repeats
        row_base = GetCubeIdx() * tile_rows
        for rep in range(0, repeats):
            row0 = row_base + rep * rows
            gm_to_l1_nd2nz(l1, src[row0:row0 + rows, 0:COLS], rows, COLS, COLS, MAX_ROWS)

    with vec_scope():
        status_row = GetCubeIdx() * VEC_LANES_PER_CORE + GetSubBlockIdx()
        with auto_sync():
            dup(status_ub, 1.0)
            status[status_row:status_row + 1, 0:STATUS_ELEMS] <<= status_ub
    return status


@kernel()
def bw_gm_to_ub_kernel(src: GMTensor, status: GMTensor, rows: Var, repeats: Var):
    ub = Tensor(DT.half, [MAX_ROWS, COLS], Position.UB)

    with vec_scope():
        tile_rows = rows * repeats
        vec_rank = GetCubeIdx() * VEC_LANES_PER_CORE + GetSubBlockIdx()
        row_base = vec_rank * tile_rows
        with auto_sync():
            for rep in range(0, repeats):
                row0 = row_base + rep * rows
                ub[0:rows, 0:COLS] <<= src[row0:row0 + rows, 0:COLS]
            status[vec_rank:vec_rank + 1, 0:STATUS_ELEMS] <<= ub[0:1, 0:STATUS_ELEMS]
    return status


@kernel()
def bw_ub_to_gm_kernel(dummy: GMTensor, out: GMTensor, rows: Var, repeats: Var):
    ub = Tensor(DT.half, [MAX_ROWS, COLS], Position.UB)

    with vec_scope():
        tile_rows = rows * repeats
        vec_rank = GetCubeIdx() * VEC_LANES_PER_CORE + GetSubBlockIdx()
        row_base = vec_rank * tile_rows
        for rep in range(0, repeats):
            row0 = row_base + rep * rows
            out[row0:row0 + rows, 0:COLS] <<= ub[0:rows, 0:COLS]
    return out


@kernel()
def bw_l0c_to_gm_kernel(src: GMTensor, out: GMTensor, rows: Var, repeats: Var):
    l0c = Tensor(DT.float, [MAX_ROWS, COLS], Position.L0C)

    with cube_scope():
        tile_rows = rows * repeats
        row_base = GetCubeIdx() * tile_rows
        for rep in range(0, repeats):
            row0 = row_base + rep * rows
            l0c_to_gm_nz2nd(out[row0:row0 + rows, 0:COLS], l0c, rows, COLS, COLS, MAX_ROWS)
    return out


@kernel()
def bw_contended_all_kernel(src: GMTensor, out_half: GMTensor, out_float: GMTensor, rows: Var, repeats: Var):
    l1_stream = Tensor(DT.half, [MAX_ROWS, COLS], Position.L1)
    l0c = Tensor(DT.float, [MAX_ROWS, COLS], Position.L0C)
    ub_in = Tensor(DT.half, [MAX_ROWS, COLS], Position.UB)
    ub_out = Tensor(DT.half, [MAX_ROWS, COLS], Position.UB)

    with cube_scope():
        tile_rows = rows * repeats
        cube_row_base = GetCubeIdx() * tile_rows
        for rep in range(0, repeats):
            row0 = cube_row_base + rep * rows
            gm_to_l1_nd2nz(l1_stream, src[row0:row0 + rows, 0:COLS], rows, COLS, COLS, MAX_ROWS)
            l0c_to_gm_nz2nd(out_float[row0:row0 + rows, 0:COLS], l0c, rows, COLS, COLS, MAX_ROWS)

    with vec_scope():
        tile_rows = rows * repeats
        vec_rank = GetCubeIdx() * VEC_LANES_PER_CORE + GetSubBlockIdx()
        vec_src_base = (GetCubeNum() + vec_rank) * tile_rows
        vec_out_base = vec_rank * tile_rows
        for rep in range(0, repeats):
            src_row0 = vec_src_base + rep * rows
            out_row0 = vec_out_base + rep * rows
            ub_in[0:rows, 0:COLS] <<= src[src_row0:src_row0 + rows, 0:COLS]
            out_half[out_row0:out_row0 + rows, 0:COLS] <<= ub_out[0:rows, 0:COLS]
    return out_half, out_float


def _parse_positive_ints(text: Iterable[str], label: str) -> Tuple[int, ...]:
    values = tuple(int(item) for item in text)
    if not values:
        raise ValueError(f"at least one {label} value is required")
    for value in values:
        if value <= 0:
            raise ValueError(f"{label} values must be positive")
    return values


def _core_slots(args) -> int:
    return int(args.core_count)


def _vec_slots(args) -> int:
    return int(args.core_count) * VEC_LANES_PER_CORE


def _payload_bytes(case_name: str, rows: int, repeats: int, args) -> int:
    half_tile_bytes = rows * COLS * 2
    float_tile_bytes = rows * COLS * 4
    core_slots = _core_slots(args)
    vec_slots = _vec_slots(args)
    if case_name == "gm_to_l1":
        return half_tile_bytes * repeats * core_slots
    if case_name in ("gm_to_ub", "ub_to_gm"):
        return half_tile_bytes * repeats * vec_slots
    if case_name == "l0c_to_gm":
        return float_tile_bytes * repeats * core_slots
    if case_name == "contended_all":
        return (half_tile_bytes + float_tile_bytes) * repeats * core_slots + 2 * half_tile_bytes * repeats * vec_slots
    return 0


def _participant_bytes(case_name: str, rows: int, repeats: int) -> int:
    half_tile_bytes = rows * COLS * 2
    float_tile_bytes = rows * COLS * 4
    if case_name in ("gm_to_l1", "gm_to_ub", "ub_to_gm"):
        return half_tile_bytes * repeats
    if case_name == "l0c_to_gm":
        return float_tile_bytes * repeats
    if case_name == "contended_all":
        return (2 * half_tile_bytes + half_tile_bytes + float_tile_bytes) * repeats
    return 0


def _tile_rows(rows: int, repeats: int) -> int:
    return rows * repeats


def _alloc_rows(rows: int, repeats: int, slots: int) -> int:
    return max(_tile_rows(rows, repeats) * slots, 1)


def _make_src(rows: int, repeats: int, slots: int, zero: bool = False) -> torch.Tensor:
    shape = (_alloc_rows(rows, repeats, slots), COLS)
    if zero:
        return torch.zeros(shape, dtype=torch.float16)
    return torch.empty(shape, dtype=torch.float16)


def _shape_bindings(*tensors: torch.Tensor) -> Dict[int, List[Optional[int]]]:
    return {idx: [None for _ in tensor.shape] for idx, tensor in enumerate(tensors)}


def _extract_profile_time_us(log_path: str = "r.sh.log") -> Optional[float]:
    if not os.path.exists(log_path):
        return None
    found = None
    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            match = PROFILE_RE.search(line)
            if match is not None:
                found = float(match.group(1))
    return found


def _run_one(case_name: str, rows: int, repeats: int, args) -> Dict[str, object]:
    tile_rows = _tile_rows(rows, repeats)
    core_slots = _core_slots(args)
    vec_slots = _vec_slots(args)
    out_dir = os.path.join(args.out_root, f"{case_name}_r{rows}_rep{repeats}_nonoverlap")

    if case_name == "empty":
        src = torch.empty((1, COLS), dtype=torch.float16)
        status = torch.empty((vec_slots, STATUS_ELEMS), dtype=torch.float32)
        actual = OpExec(
            bw_empty_kernel,
            out_dir=out_dir,
            cann_path=args.cann_path,
            custom_op_path=args.custom_op_path,
            simulator=args.simulator,
            profile=True,
            gen_only=args.gen_only,
            skip_compile=args.skip_compile,
        )(src, status, rows, repeats, shape_bindings=_shape_bindings(src, status))
    elif case_name == "gm_to_l1":
        src = _make_src(rows, repeats, core_slots, zero=args.simulator)
        status = torch.empty((vec_slots, STATUS_ELEMS), dtype=torch.float32)
        actual = OpExec(
            bw_gm_to_l1_kernel,
            out_dir=out_dir,
            cann_path=args.cann_path,
            custom_op_path=args.custom_op_path,
            simulator=args.simulator,
            profile=True,
            gen_only=args.gen_only,
            skip_compile=args.skip_compile,
        )(src, status, rows, repeats, shape_bindings=_shape_bindings(src, status))
    elif case_name == "gm_to_ub":
        src = _make_src(rows, repeats, vec_slots, zero=args.simulator)
        status = torch.empty((vec_slots, STATUS_ELEMS), dtype=torch.float16)
        actual = OpExec(
            bw_gm_to_ub_kernel,
            out_dir=out_dir,
            cann_path=args.cann_path,
            custom_op_path=args.custom_op_path,
            simulator=args.simulator,
            profile=True,
            gen_only=args.gen_only,
            skip_compile=args.skip_compile,
        )(src, status, rows, repeats, shape_bindings=_shape_bindings(src, status))
    elif case_name == "ub_to_gm":
        src = torch.empty((1, COLS), dtype=torch.float16)
        out = torch.empty((_alloc_rows(rows, repeats, vec_slots), COLS), dtype=torch.float16)
        actual = OpExec(
            bw_ub_to_gm_kernel,
            out_dir=out_dir,
            cann_path=args.cann_path,
            custom_op_path=args.custom_op_path,
            simulator=args.simulator,
            profile=True,
            gen_only=args.gen_only,
            skip_compile=args.skip_compile,
        )(src, out, rows, repeats, shape_bindings=_shape_bindings(src, out))
    elif case_name == "l0c_to_gm":
        src = torch.empty((1, COLS), dtype=torch.float16)
        out = torch.empty((_alloc_rows(rows, repeats, core_slots), COLS), dtype=torch.float32)
        actual = OpExec(
            bw_l0c_to_gm_kernel,
            out_dir=out_dir,
            cann_path=args.cann_path,
            custom_op_path=args.custom_op_path,
            simulator=args.simulator,
            profile=True,
            gen_only=args.gen_only,
            skip_compile=args.skip_compile,
        )(src, out, rows, repeats, shape_bindings=_shape_bindings(src, out))
    elif case_name == "contended_all":
        src = _make_src(rows, repeats, core_slots + vec_slots, zero=args.simulator)
        out_half = torch.empty((_alloc_rows(rows, repeats, vec_slots), COLS), dtype=torch.float16)
        out_float = torch.empty((_alloc_rows(rows, repeats, core_slots), COLS), dtype=torch.float32)
        actual = OpExec(
            bw_contended_all_kernel,
            out_dir=out_dir,
            cann_path=args.cann_path,
            custom_op_path=args.custom_op_path,
            simulator=args.simulator,
            profile=True,
            gen_only=args.gen_only,
            skip_compile=args.skip_compile,
        )(src, out_half, out_float, rows, repeats, shape_bindings=_shape_bindings(src, out_half, out_float))
    else:
        raise ValueError(f"unknown case: {case_name}")

    if args.simulator:
        if case_name in ("empty", "gm_to_l1", "gm_to_ub"):
            assert torch.isfinite(actual.float()).all()
        elif isinstance(actual, tuple):
            for tensor in actual:
                assert tensor.shape[0] >= tile_rows and tensor.shape[1] == COLS
        else:
            assert actual.shape[0] >= tile_rows and actual.shape[1] == COLS

    payload = _payload_bytes(case_name, rows, repeats, args)
    participant_payload = _participant_bytes(case_name, rows, repeats)
    time_us = None if args.simulator or args.gen_only else _extract_profile_time_us()
    gb_s = None if not time_us or payload == 0 else payload / 1000.0 / time_us
    print(
        f"case={case_name} rows={rows} repeats={repeats} "
        f"participant_mib={participant_payload / (1024 * 1024):.3f} "
        f"aggregate_mib={payload / (1024 * 1024):.3f} "
        f"time_us={time_us if time_us is not None else '-'} out_dir={out_dir}",
        flush=True,
    )
    return {
        "case": case_name,
        "rows": rows,
        "repeats": repeats,
        "participant_mib": participant_payload / (1024 * 1024),
        "aggregate_mib": payload / (1024 * 1024),
        "time_us": time_us,
        "gb_s": gb_s,
        "out_dir": out_dir,
    }


def _format_optional_float(value: object, digits: int = 2) -> str:
    if value is None:
        return "-"
    return f"{float(value):.{digits}f}"


def _summary_markdown(results: List[Dict[str, object]]) -> str:
    lines = [
        "| case | rows | repeats | participant MiB | aggregate MiB | time us | aggregate GB/s |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for item in results:
        lines.append(
            "| {case} | {rows} | {repeats} | {participant_mib} | {aggregate_mib} | {time_us} | {gb_s} |".format(
                case=item["case"],
                rows=item["rows"],
                repeats=item["repeats"],
                participant_mib=_format_optional_float(item["participant_mib"], 3),
                aggregate_mib=_format_optional_float(item["aggregate_mib"], 3),
                time_us=_format_optional_float(item["time_us"], 2),
                gb_s=_format_optional_float(item["gb_s"], 2),
            )
        )
    return "\n".join(lines)


def _write_summary(results: List[Dict[str, object]], out_root: str) -> None:
    md_path = os.path.join(out_root, "summary.md")
    csv_path = os.path.join(out_root, "summary.csv")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(_summary_markdown(results) + "\n")
    with open(csv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=("case", "rows", "repeats", "participant_mib", "aggregate_mib", "time_us", "gb_s", "out_dir"),
        )
        writer.writeheader()
        for item in results:
            writer.writerow(item)
    print(f"\nWrote summary files: {md_path}, {csv_path}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Profile A2 GM/L2 datamove bandwidth. "
            "Default path uses OpExec(..., simulator=False, profile=True)."
        )
    )
    parser.add_argument("--rows", nargs="+", default=[str(v) for v in DEFAULT_ROWS])
    parser.add_argument("--repeats", type=int, default=DEFAULT_REPEATS)
    parser.add_argument("--core-count", type=int, default=DEFAULT_CORE_COUNT)
    parser.add_argument(
        "--case",
        choices=("all", "empty", "gm_to_l1", "gm_to_ub", "ub_to_gm", "l0c_to_gm", "contended_all"),
        default="all",
    )
    parser.add_argument("--out-root", default="./tmp/a2_bandwidth_sweep_profile")
    parser.add_argument("--cann-path", default=None)
    parser.add_argument("--custom-op-path", default="./")
    parser.add_argument("--gen-only", action="store_true")
    parser.add_argument("--skip-compile", action="store_true")
    parser.add_argument("--simulator", action="store_true")
    args = parser.parse_args()

    rows_values = _parse_positive_ints(args.rows, "rows")
    if args.repeats <= 0:
        raise ValueError("repeats must be positive")
    if args.core_count <= 0:
        raise ValueError("core-count must be positive")
    for rows in rows_values:
        if rows > MAX_ROWS:
            raise ValueError(f"rows must be <= {MAX_ROWS}, got {rows}")

    os.makedirs(args.out_root, exist_ok=True)
    cases = ("empty", "gm_to_l1", "gm_to_ub", "ub_to_gm", "l0c_to_gm", "contended_all")
    results = []
    for rows in rows_values:
        for case_name in cases:
            if args.case != "all" and args.case != case_name:
                continue
            results.append(_run_one(case_name, rows, args.repeats, args))

    if results:
        print("\n" + _summary_markdown(results), flush=True)
        _write_summary(results, args.out_root)

    print(
        "Aggregate bandwidth uses non-overlapping per-core/per-vec-lane GM regions. "
        "For contended_all, aggregate payload counts cube half read + vec half read "
        "+ vec half write + cube float write.",
        flush=True,
    )


if __name__ == "__main__":
    main()
