"""SIMT UB boundary probe for accesses at and beyond 8 KiB.

Run by default through the in-process simulator.  Pass ``--cannsim`` to run the
same probe through the generated custom-op path under CANNSIM.
"""

import sys

from easyasc.a5 import *


BASE_ELEMS = 2048  # 2048 float32 elements == 8192 bytes.
COUNT = 64
TOTAL_ELEMS = BASE_ELEMS + COUNT

SHAPE_BINDINGS = {
    0: [None, 0],
    1: [None, 0],
    2: [None, 0],
    3: [None, 0],
    4: [None, 0],
    5: [None, 0],
}


@simt()
def read_high_ub_simt(x_ub: Tensor, out_ub: Tensor, count: Var):
    for i in range(simt_thread_id(), count, simt_thread_num()):
        out_ub[i] = x_ub[BASE_ELEMS + i]


@simt()
def write_high_ub_simt(x_ub: Tensor, out_ub: Tensor, count: Var):
    for i in range(simt_thread_id(), count, simt_thread_num()):
        out_ub[BASE_ELEMS + i] = x_ub[i]


@simt()
def read_boundary_ub_simt(x_ub: Tensor, out_ub: Tensor, count: Var):
    for i in range(simt_thread_id(), count, simt_thread_num()):
        out_ub[i] = x_ub[i]


@simt()
def write_boundary_ub_simt(x_ub: Tensor, out_ub: Tensor, count: Var):
    for i in range(simt_thread_id(), count, simt_thread_num()):
        out_ub[i] = x_ub[i]


@kernel()
def simt_ub_high_probe_kernel(
    x: GMTensor,
    control_out: GMTensor,
    read_out: GMTensor,
    write_out: GMTensor,
    boundary_read_out: GMTensor,
    boundary_write_out: GMTensor,
    N: Var,
):
    pad_ub = Tensor(DT.float, [1, BASE_ELEMS], Position.UB)
    boundary_ub = Tensor(DT.float, [1, COUNT], Position.UB)
    boundary_scratch_ub = Tensor(DT.float, [1, COUNT], Position.UB)
    boundary_write_src_ub = Tensor(DT.float, [1, COUNT], Position.UB)
    x_ub = Tensor(DT.float, [1, TOTAL_ELEMS], Position.UB)
    read_ub = Tensor(DT.float, [1, COUNT], Position.UB)
    write_ub = Tensor(DT.float, [1, TOTAL_ELEMS], Position.UB)
    count = Var(COUNT, DT.int)

    with auto_sync():
        pad_ub <<= x[0:1, 0:BASE_ELEMS]
        boundary_ub <<= x[0:1, 0:COUNT]
        read_boundary_ub_simt(boundary_ub, boundary_scratch_ub, count)
        boundary_read_out[0:1, 0:COUNT] <<= boundary_scratch_ub

        boundary_write_src_ub <<= x[0:1, COUNT:COUNT + COUNT]
        write_boundary_ub_simt(boundary_write_src_ub, boundary_ub, count)
        boundary_write_out[0:1, 0:COUNT] <<= boundary_ub

        x_ub <<= x[0:1, 0:TOTAL_ELEMS]

        control_out[0:1, 0:COUNT] <<= x_ub[0:1, BASE_ELEMS:BASE_ELEMS + COUNT]

        read_high_ub_simt(x_ub, read_ub, count)
        read_out[0:1, 0:COUNT] <<= read_ub

        write_high_ub_simt(x_ub, write_ub, count)
        write_out[0:1, BASE_ELEMS:BASE_ELEMS + COUNT] <<= (
            write_ub[0:1, BASE_ELEMS:BASE_ELEMS + COUNT]
        )

    return control_out, read_out, write_out, boundary_read_out, boundary_write_out


if __name__ == "__main__":
    import torch

    use_cannsim = "--cannsim" in sys.argv[1:]
    out_dir = "./tmp/simt_ub_8kb_probe_cannsim" if use_cannsim else "./tmp/simt_ub_8kb_probe_simulator"

    x = torch.arange(TOTAL_ELEMS, dtype=torch.float32).reshape(1, TOTAL_ELEMS)
    control_out = torch.empty_like(x)
    read_out = torch.empty_like(x)
    write_out = torch.empty_like(x)
    boundary_read_out = torch.empty_like(x)
    boundary_write_out = torch.empty_like(x)

    actual = OpExec(
        simt_ub_high_probe_kernel,
        out_dir=out_dir,
        simulator=not use_cannsim,
        cannsim=use_cannsim,
    )(
        x,
        control_out,
        read_out,
        write_out,
        boundary_read_out,
        boundary_write_out,
        TOTAL_ELEMS,
        shape_bindings=SHAPE_BINDINGS,
    )
    control_actual, read_actual, write_actual, boundary_read_actual, boundary_write_actual = actual

    expected_high = x[:, BASE_ELEMS:BASE_ELEMS + COUNT]
    expected_low = x[:, 0:COUNT]
    expected_next = x[:, COUNT:COUNT + COUNT]

    torch.testing.assert_close(control_actual[:, 0:COUNT], expected_high, rtol=0, atol=0)
    torch.testing.assert_close(read_actual[:, 0:COUNT], expected_high, rtol=0, atol=0)
    torch.testing.assert_close(
        write_actual[:, BASE_ELEMS:BASE_ELEMS + COUNT], expected_low, rtol=0, atol=0
    )
    torch.testing.assert_close(boundary_read_actual[:, 0:COUNT], expected_low, rtol=0, atol=0)
    torch.testing.assert_close(boundary_write_actual[:, 0:COUNT], expected_next, rtol=0, atol=0)

    print("simt_read_boundary_8kb_ub=pass")
    print("simt_write_boundary_8kb_ub=pass")
    print("control_high_mte=pass")
    print("simt_read_high_ub=pass")
    print("simt_write_high_ub=pass")
