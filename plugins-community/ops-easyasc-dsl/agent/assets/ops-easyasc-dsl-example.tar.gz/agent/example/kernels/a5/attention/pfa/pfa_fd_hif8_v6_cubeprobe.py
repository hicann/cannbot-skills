"""V6 cube-isolation and synchronization-structure probes.

Goal: understand why every V6 pipe caps around 50-62% under balanced critical-path overlap. These
probes strip / restructure the schedule to expose each pipe's ceiling in isolation and to test sync ideas.

On real hardware, you cannot keep the AIV side and no-op a cube op it waits on (or drop
one half of a barrier) — the MIX_AIC handshake deadlocks (sim is too lenient). So the isolation probes here
are **pure-cube, AIV-free, mutex-free** (AIC-only → no handshake to break), and the full-V6 probes keep BOTH
barrier halves intact.

Design constraint: easyasc's @func rewrites EVERY `if` in the decorated body to `with If()`. So (a) DSL
control flow (`if kt==0` on Vars) must be TEXTUALLY inside the @func — it cannot live in a plain helper
(Python would call __bool__ on the Var and raise); and (b) a Python-bool `if` (e.g. `if use_events:`) inside
the body would be rewritten and always execute. Hence each full-V6 variant is a separate FLAT @func body
(the loop inlined), differing structurally — not by a runtime flag. `_alloc_v6` (allocation only, no `if`)
is the one safe shared helper.

Probes (env `PV_CPROBE`):
  base        full V6 (control; correct ~5.5e-3) — reference makespan/ratios in THIS file's run env
  purecube    (1) cube chain only: K/V/Q-load, QK-mmad, QK-fix, P-store, PV-mmad, PV-fix. NO vec, NO mutex,
                  auto_sync kept for cube-internal order → each cube pipe's util with zero vec/sync interference
  qkonly      (2) only K-load + QK-mmad + QK-fix (l0c->ub) → the QK half's mac-vs-fixpipe split
  pvonly      (3) only V-load + PV-mmad + PV-fix (l0c->ub) → the PV half's mac-vs-fixpipe split
  --- load2d-blowup discriminators (why purecube 209µs >> qkonly 65 + pvonly 65; the extra ~78µs is ~all in
      mte1/load2d: 56→172µs. Which of P-store-dep / interleaving / count causes it?) ---
  qkpv        interleaved QK+PV but NO P-store (l1p constant) → purecube−qkpv = P-store/l1p-dep; qkpv−130 = interleave
  qk2x        qkonly with 2 QK-mmads/step on SAME l1k/l1q → cheap ⇒ blowup is operand-switching, not count
  pvonlyfreshp pvonly + a dummy fresh l1p write/step → pvonlyfreshp−pvonly = cost of l1p being live-updated
  phasesplit  all QK (pipelined) → bar_all (drain every cube pipe) → all PV (pipelined), l1p constant, NO
              QK<->PV interleave. makespan ≈ qkonly+pvonly ⇒ purecube's slowdown is L0-double-buffer
              contention (each phase alone owns both L0 slots); ≈ purecube ⇒ slowdown is intrinsic not contention
  splitl0     purecube UNCHANGED (interleaved + P-store) except QK and PV get SEPARATE hif8 depth-2 L0 buffers
              (own DBuff pair + counters, matmul_nosplit). SPACE de-interleave — keeps the pipeline, so it is a
              real-V6-viable fix. splitl0 << purecube ⇒ collapse was shared-L0 contention & this fixes it
  mutexse     (4) full V6 but every mutex has src_start=src_end & dst_start=dst_end (tighten the sync window)
  noautosync  (5) full V6 with the main-loop `with auto_sync()` removed → instruction ceiling, unconstrained
  splitevent  (6) full V6 (auto_sync KEPT) + QK-mac->fix and PV-mac->fix each guarded by its OWN SEvent
                  (M->FIX). Tests whether giving the two chains separate explicit events lets the scheduler
                  overlap them more than auto_sync's shared handling. Numerically correct (events supplement,
                  not replace, auto_sync). Exploratory scaffold. NOTE: adding events to a NO-auto_sync body
                  makes the sim event model inconsistent (crash), so auto_sync stays here.

Correctness: base / mutexse / splitevent are numerically correct (valid schedules ~6.8e-3); purecube/qkonly/
pvonly write no `out` (|O|=0); noautosync races (garbage). Read AVG makespan + op_summary pipe ratios.
"""
import builtins
import math
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5pr") == "a5":
    from easyasc.a5 import *
else:
    from easyasc.a5pr import *
from easyasc.simulator.config import SimulatorConfig
from easyasc.shortcuts.matmul import matmul_nosplit  # low-level path: lets a probe pass its OWN L0A/L0B buffers

from pfa_fd_hif8_probe_common import (
    _CacheBuf,
    init_softmax_state_vf, softmax_t_scale_vf, softmax_t_scale_tail_vf,
    accum_pv_vf, accum_pv_first_vf, init_accum_vf, final_div_cast_bf16_vf,
    fd_merge_vf, output_cast_vf, _qk_bridge_splitn, _pairwise_split_ok,
    _ref_mqa, _err,
    TILE_M, ROWS_PER_SB, QLANES, TILE_N, D_HEAD, KROW, CACHE, PRELOAD_N,
    MAX_CORE_COUNT, MAX_FD_WS, fp32_to_hif8, hif8_to_fp32,
    # fp16 (V2/V4) path, aligned to v6/v7 (ln16 added here; expsub unusable on half)
    init_softmax_half_vf, accum_pv_fp16ow_vf, final_div_fp16rsum_vf,
    _qk_bridge_dual_single, SOFTMAX_SCALE,
    UNROLL, RB_MAX_H, RB_EXP_H, KREGS, NEG_LARGE_H,
)

_pyrange = builtins.range
LN16 = math.log(16.0)   # exp-max bias so hif8 stores 16*P (same as v6/v7); cancels in O via rsum


# ============================ (1) pure-cube: no vec, no mutex, AIC-only ============================
@func()
def _cube_only_body(q, k, v, out, B, MQ, N, D):
    """QK-mmad -> QK-fix -> P-store -> PV-mmad -> PV-fix, software-pipelined (PRELOAD_N) exactly as V6, but
    with ZERO vec VFs and ZERO mutexes. auto_sync orders the cube-internal chain. ub_p/ub_score/ub_pv are
    written by fixpipe (a cube pipe) and never read by vec, so the kernel is AIC-only — no handshake, no
    deadlock. Measures each cube pipe's util (mac / fixpipe / mte1 / mte2 / mte3) free of vec+sync."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
                _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                               m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_kv_base = Var(lag_batch * N)
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ (2) QK half only ============================
@func()
def _qk_only_body(q, k, v, out, B, MQ, N, D):
    """K-load -> QK-mmad -> QK-fix only. Isolates the QK-side mac vs fixpipe cost."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            qm = Var(mt % 2)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            kv_base = Var(batch * N)
            m0 = Var(local_mt * TILE_M)
            valid_m = Min(TILE_M, MQ - m0)
            n0 = Var(kt * TILE_N)
            valid_n = Min(TILE_N, N - n0)

            need_q = Var(0, DT.int)
            if kt == 0:
                need_q <<= 1
            if step == 0:
                need_q <<= 1
            if need_q > 0:
                l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

            l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            matmul(l0c_qk[step], l1k[step], l1q[qm],
                   m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
            _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
    return out


# ============================ (3) PV half only ============================
@func()
def _pv_only_body(q, k, v, out, B, MQ, N, D):
    """V-load -> PV-mmad -> PV-fix only. l1p is left constant (garbage P) since QK/softmax are absent; the
    op timings (mac vs fixpipe on the PV side) are what we measure, not the values."""
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)
        set_constant_to_l1(l1p[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            batch = Var(mt // tiles_m_per_b)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)
            v_rows = Min(TILE_N, N - n0)

            l1v[step][0:v_rows, 0:D] <<= v_hif8[kv_base + n0:kv_base + n0 + v_rows, 0:D]
            matmul(l0c_pv[step][0:TILE_M, 0:D_HEAD], l1p[step].T, l1v[step].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            l0c_to_ub(ub_pv[step], l0c_pv[step][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ load2d-blowup discriminator probes (why purecube > qkonly+pvonly) ============================
@func()
def _qkpv_body(q, k, v, out, B, MQ, N, D):
    """Interleaved QK+PV (like purecube) but NO P-store: l1p is set_constant, PV reads the constant. Splits
    purecube's extra time: purecube − qkpv = P-store / l1p write->read dependency (hyp B); qkpv − (qkonly+
    pvonly) = the pure QK<->PV interleaving / L0-thrash cost (hyp A)."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)
        set_constant_to_l1(l1p[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
                _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                # NO P-store: l1p stays the set_constant tile

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_kv_base = Var(lag_batch * N)
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


@func()
def _qk2x_body(q, k, v, out, B, MQ, N, D):
    """qkonly but TWO QK-mmads per step on the SAME l1k/l1q (no operand switch). Doubles the matmul count
    with ZERO operand-switching. If load2d stays hidden (~qkonly time, mac just grows) → purecube's blowup
    is QK<->PV OPERAND SWITCHING / L0-thrash (hyp A), not raw count. If load2d blows up → it's the count."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            qm = Var(mt % 2)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            kv_base = Var(batch * N)
            m0 = Var(local_mt * TILE_M)
            valid_m = Min(TILE_M, MQ - m0)
            n0 = Var(kt * TILE_N)
            valid_n = Min(TILE_N, N - n0)

            need_q = Var(0, DT.int)
            if kt == 0:
                need_q <<= 1
            if step == 0:
                need_q <<= 1
            if need_q > 0:
                l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

            l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            matmul(l0c_qk[0], l1k[step], l1q[qm], m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
            _qk_bridge_splitn(ub_score[0], l0c_qk[0], 1.0)
            matmul(l0c_qk[1], l1k[step], l1q[qm], m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
            _qk_bridge_splitn(ub_score[1], l0c_qk[1], 1.0)
    return out


@func()
def _pvonly_freshp_body(q, k, v, out, B, MQ, N, D):
    """pvonly but l1p is FRESHLY written by a dummy P-store (ub->l1) each step before PV-mmad, instead of a
    one-time constant. pvonly_freshp − pvonly = the cost of l1p being live-updated (its L1 tile invalidated
    each step so PV's load2d cannot reuse / must reload) — the mechanism (B) that a constant l1p hides."""
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            batch = Var(mt // tiles_m_per_b)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)
            v_rows = Min(TILE_N, N - n0)

            ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                           m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
            l1v[step][0:v_rows, 0:D] <<= v_hif8[kv_base + n0:kv_base + n0 + v_rows, 0:D]
            matmul(l0c_pv[step][0:TILE_M, 0:D_HEAD], l1p[step].T, l1v[step].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            l0c_to_ub(ub_pv[step], l0c_pv[step][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ clean single-side cost: cube-only (GM->L1, matmul, L0C->UB; NO P-store/vec) ============================
@func()
def _cubeonly_body(q, k, v, out, B, MQ, N, D):
    """Clean CUBE-side cost: per step GM->L1 (K/Q/V loads), matmul (QK + PV), L0C->UB (QK-fix + PV-fix). l1p is
    a set_constant tile (no vec P-store, no cross-lane l1p) so this is genuinely AIC-only — the fixpipe writes
    ub_score/ub_pv which no vec reads (no handshake, safe). Unlike qkonly/pvonly this is the FULL cube chain
    (both matmuls + both fixes) with ZERO vec coupling, i.e. the true cube-pipe throughput of one V6 step."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1p[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            qm = Var(mt % 2)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            kv_base = Var(batch * N)
            m0 = Var(local_mt * TILE_M)
            valid_m = Min(TILE_M, MQ - m0)
            n0 = Var(kt * TILE_N)
            valid_n = Min(TILE_N, N - n0)

            need_q = Var(0, DT.int)
            if kt == 0:
                need_q <<= 1
            if step == 0:
                need_q <<= 1
            if need_q > 0:
                l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

            l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            l1v[step][0:valid_n, 0:D] <<= v_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            matmul(l0c_qk[step], l1k[step], l1q[qm],
                   m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
            _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
            matmul(l0c_pv[step][0:TILE_M, 0:D_HEAD], l1p[step].T, l1v[step].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            l0c_to_ub(ub_pv[step], l0c_pv[step][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ clean single-side cost: vec-only (GM->UB, VF, UB->L1, UB->GM; NO cube) ============================
@func()
def _veconly_body(q, k, v, out, B, MQ, N, D):
    """Clean VEC-side cost: per step GM->UB (score+pv inputs arrive, standing in for the cube L0C->UB fixes
    that don't exist here), VF (init_softmax_state / softmax_t_scale / accum_pv / final_div_cast), UB->L1 (the
    P-store ub_to_l1_nd2nz), UB->GM (output store). NO matmul, NO GM->L1, NO cube. AIV-only. This is the true
    vec-pipe throughput of one V6 step, with none of the cube/P-load coupling that pvonly/purecube carried.
    The GM->UB loads feed the VFs (so nothing is DCE'd) and l1p is stored to AND partially re-read into ub via
    a dummy so the UB->L1 P-store survives codegen. Values are garbage (profiling-only)."""
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            # GM->UB: score + pv inputs arrive (raw-byte load, feeds the VFs so nothing is DCE'd)
            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_t_scale_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            # UB->L1: the P-store
            ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                           m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_cast_bf16_vf(ub_accum, ub_rsum[sm], ub_out)
                # UB->GM: output store
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


# ============================ vec-only WITHOUT the P-store (isolate the P-store's own vec-lane cost) ============================
@func()
def _vecnostore_body(q, k, v, out, B, MQ, N, D):
    """`veconly` MINUS the UB->L1 P-store (no l1p, no `ub_to_l1_nd2nz`). Everything else identical: GM->UB
    inputs, VF (softmax/accum/final), UB->GM output. softmax_t_scale_vf still writes ub_p but nothing reads it
    (its ub_rmax/ub_rsum/ub_old_weight ARE consumed, so the VF is not DCE'd — only the store is gone). So:
      veconly − vecnostore = the P-store's OWN vec-lane cost (the UB2L1_ND2NZ op alone, no cube waiting on it).
    Compare with pvonlyfreshp − pvonly (= 88µs, the P-store cost WITH cube cross-lane coupling): if
    veconly−vecnostore << 88 ⇒ most of the 88µs was the cube-waits-on-vec handshake, not the store's DMA;
    if ≈ 88 ⇒ the store's own fragmented vec time dominates. Profiling-only (garbage)."""
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_t_scale_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_cast_bf16_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


# ============================ fp16 single-side probes (cube-only / vec-only / vec-no-store), V2 & V4 ============================
@func()
def _cubeonly_h_body(q, k, v, out, B, MQ, N, D, l0c_scale):
    """fp16 cube-only: = _cubeonly_body but the QK score fix is the fp16 dual-SINGLE bridge (2 SINGLE fixes
    per step, fp32->half downcast + optional requant on the deqScalar path) writing a HALF ub_score.
    l0c_scale = SOFTMAX_SCALE (V2: requant+downcast) or 1.0 (V4: downcast only) -> the V2/V4 cube split.
    PV side unchanged (fp32 SPLITM). l1p constant, no vec P-store. AIC-only (no handshake)."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1p[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            qm = Var(mt % 2)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            kv_base = Var(batch * N)
            m0 = Var(local_mt * TILE_M)
            valid_m = Min(TILE_M, MQ - m0)
            n0 = Var(kt * TILE_N)
            valid_n = Min(TILE_N, N - n0)

            need_q = Var(0, DT.int)
            if kt == 0:
                need_q <<= 1
            if step == 0:
                need_q <<= 1
            if need_q > 0:
                l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

            l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            l1v[step][0:valid_n, 0:D] <<= v_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            matmul(l0c_qk[step], l1k[step], l1q[qm],
                   m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
            _qk_bridge_dual_single(ub_score[step], l0c_qk[step], l0c_scale)
            matmul(l0c_pv[step][0:TILE_M, 0:D_HEAD], l1p[step].T, l1v[step].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            l0c_to_ub(ub_pv[step], l0c_pv[step][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


@func()
def _veconly_h_body(q, k, v, out, B, MQ, N, D, softmax_h_fn):
    """fp16 vec-only: = _veconly_body but half ub_score/state, init_softmax_half + fp16 softmax
    (softmax_h_fn = scale (V4) / noscale (V2)) + reg_to_ub_downsample P (inside the VF) + ub_to_l1_nd2nz
    P-store + accum_pv_fp16ow + final_div_fp16rsum. GM->UB proxy feeds the VFs (garbage, profiling-only)."""
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    ub_score = DBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_rmax = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_rsum = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_old_weight = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_half_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_h_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                           m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_fp16ow_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_fp16rsum_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


@func()
def _vecnostore_h_body(q, k, v, out, B, MQ, N, D, softmax_h_fn):
    """_veconly_h_body MINUS the ub_to_l1_nd2nz P-store (softmax_h_fn still writes ub_p via
    reg_to_ub_downsample but nobody reads it; rmax/rsum/old_weight ARE consumed so the VF isn't DCE'd).
    veconly_h - vecnostore_h = the fp16 P-store's own vec-lane nd2nz cost."""
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    ub_score = DBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_rmax = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_rsum = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_old_weight = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_half_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_h_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_fp16ow_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_fp16rsum_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


# ============================ P-store burst-granularity probes (H1: UB2L1_ND2NZ blockLen=1 fragmentation) ============================
@func()
def _pstorenz_body(q, k, v, out, B, MQ, N, D):
    """H1 test — identical to pvonlyfreshp EXCEPT the per-step l1p write uses `ub_to_l1_nz` (bulk NZ copy,
    C++ `UB2L1_NZ`, blockLen=msrc=128 → 2 bursts of 4096B) instead of `ub_to_l1_nd2nz` (`UB2L1_ND2NZ`,
    blockLen=1 → 256 bursts of 32B). SAME data volume (128×64 hif8 = 8192B), 128× coarser burst. The P-store
    is a VEC-lane op (UB→L1) that the cube PV load2d waits on (codegen: it lands in `*_kernel_vec.h`), so a
    slow fragmented store stalls the cube. Decisive H1 A/B vs pvonlyfreshp (153µs) and pvonly (65µs, no store):
      pstorenz ≈ pvonly (~65)      ⇒ the whole +88µs was UB2L1_ND2NZ burst fragmentation → real fix = emit P in
                                     NZ so the store is bulk (blockLen=128). ~88µs on the table for V6.
      pstorenz ≈ pvonlyfreshp (153) ⇒ burst granularity is NOT the cost (look to cross-lane handshake / H2 bank
                                     conflict / the store→load serialization itself).
    (ub_p_nz is uninitialised garbage — profiling-only, like pvonlyfreshp; only the store's timing matters.)"""
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p_nz = Tensor(DT.hif8, [TILE_N, ROWS_PER_SB], Position.UB)  # NZ-shaped source → bulk UB2L1_NZ

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            batch = Var(mt // tiles_m_per_b)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)
            v_rows = Min(TILE_N, N - n0)

            ub_to_l1_nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p_nz,
                        m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB)
            l1v[step][0:v_rows, 0:D] <<= v_hif8[kv_base + n0:kv_base + n0 + v_rows, 0:D]
            matmul(l0c_pv[step][0:TILE_M, 0:D_HEAD], l1p[step].T, l1v[step].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            l0c_to_ub(ub_pv[step], l0c_pv[step][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ P-store H2: dodge UB-read bank conflict via odd C0-row stride ============================
@func()
def _pstorepad_body(q, k, v, out, B, MQ, N, D):
    """H2 test (isolated from H1) — identical to pvonlyfreshp (still `ub_to_l1_nd2nz`, still blockLen=1
    fragmented, so H1 is UNCHANGED) EXCEPT ub_p is widened to 96 cols and N_src=96. The nd2nz UB read strides
    by ceil(N_src/C0) C0-blocks per row: N_src=64 (pvonlyfreshp) → stride 2 → column-0 hits C0-block indices
    0,2,4,... (ALL EVEN slots → same UB bank → conflict); N_src=96 → stride 3 (odd) → 0,3,6,... (alternating
    banks → no conflict). Same data volume, same burst granularity — ONLY the bank pattern differs. So:
      pvonlyfreshp − pstorepad = the UB-read bank-conflict (H2) cost, isolated from burst fragmentation (H1);
      pstorepad − pstorenz     = the residual H1 (blockLen=1) cost after H2 is removed.
    (ub_p garbage — profiling-only.)"""
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    _PAD_KROW = 96  # 3*C0(hif8=32): ceil(96/32)=3 (odd) → UB-read strides odd C0-blocks/row → alternating banks
    ub_p = Tensor(DT.hif8, [TILE_N, _PAD_KROW], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            batch = Var(mt // tiles_m_per_b)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)
            v_rows = Min(TILE_N, N - n0)

            ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                           m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=_PAD_KROW)
            l1v[step][0:v_rows, 0:D] <<= v_hif8[kv_base + n0:kv_base + n0 + v_rows, 0:D]
            matmul(l0c_pv[step][0:TILE_M, 0:D_HEAD], l1p[step].T, l1v[step].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            l0c_to_ub(ub_pv[step], l0c_pv[step][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ phase-split: all-QK -> bar_all -> all-PV (no QK<->PV interleave) ============================
@func()
def _phasesplit_body(q, k, v, out, B, MQ, N, D):
    """Run ALL QK (K-load, QK-mmad, QK-fix) as one pipelined phase, then bar_all() to drain every cube pipe,
    then run ALL PV (V-load, PV-mmad, PV-fix) as a second pipelined phase. l1p stays constant (no P-store),
    exactly like pvonly. The two phases never interleave, so each phase owns the shared depth-2 L0A/L0B
    double-buffer by itself (full load2d<->mmad overlap, like isolated qkonly/pvonly). Decisive test of the
    'L0 double-buffer is split between QK and PV' hypothesis:
      makespan ~= qkonly + pvonly (~130us)  => purecube's 209us is pure QK/PV L0-buffer contention.
      makespan ~= purecube (~209us)          => the slowdown is intrinsic to running both halves, not contention.
    bar_all() is AIC-only-safe: the barrier's parties = this (cube) lane's pipe count, and _handle_bar_all
    marks only this lane's own mailboxes — no AIV side participates, so no MIX_AIC handshake to deadlock."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)
        set_constant_to_l1(l1p[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        # ---- phase 1: all QK, software-pipelined (owns L0 alone) ----
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            qm = Var(mt % 2)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            kv_base = Var(batch * N)
            m0 = Var(local_mt * TILE_M)
            valid_m = Min(TILE_M, MQ - m0)
            n0 = Var(kt * TILE_N)
            valid_n = Min(TILE_N, N - n0)

            need_q = Var(0, DT.int)
            if kt == 0:
                need_q <<= 1
            if step == 0:
                need_q <<= 1
            if need_q > 0:
                l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

            l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            matmul(l0c_qk[step], l1k[step], l1q[qm],
                   m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
            _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)

        # ---- hard drain of every cube pipe between the two phases ----
        bar_all()

        # ---- phase 2: all PV, software-pipelined (owns L0 alone; constant l1p) ----
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            batch = Var(mt // tiles_m_per_b)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)
            v_rows = Min(TILE_N, N - n0)

            l1v[step][0:v_rows, 0:D] <<= v_hif8[kv_base + n0:kv_base + n0 + v_rows, 0:D]
            matmul(l0c_pv[step][0:TILE_M, 0:D_HEAD], l1p[step].T, l1v[step].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            l0c_to_ub(ub_pv[step], l0c_pv[step][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ splitl0: purecube but QK/PV get SEPARATE depth-2 L0 double-buffers ============================
@func()
def _splitl0_body(q, k, v, out, B, MQ, N, D):
    """Identical to purecube (interleaved QK+PV, P-store kept) EXCEPT the two matmuls no longer share the
    kernel's one auto L0A/L0B double-buffer. Each stream gets its OWN hif8 depth-2 DBuff via matmul_nosplit:
    l0a_qk/l0b_qk for QK, l0a_pv/l0b_pv for PV, with independent ping-pong counters. hif8 tiles are 16KB, so
    2 buffers x 2 slots x 16KB = 64KB fills L0A exactly (same for L0B). The depth-4-at-hif8 idea
    realized as 2x depth-2. (The auto _l0a/_l0b are unused here; reset_cache after they are declared zeroes the
    L0A/L0B bump-offset, so these body buffers start at offset 0 and do not overflow.)

    This is the SPACE de-interleave (vs phasesplit's TIME de-interleave): the software-pipelined QK<->PV
    schedule is UNCHANGED — only where each matmul's operands live in L0 differs. So it is a viable-for-real-V6
    fix, unlike phasesplit. Decisive A/B against purecube:
      splitl0 << purecube (toward ~130us) => the collapse WAS shared-L0-buffer contention, and separate L0
                                             double-buffers fix it WITHOUT giving up interleaving. (the win)
      splitl0 ~= purecube (~209us)        => giving each stream its own L0 slots does NOT help => the collapse
                                             is not physical slot contention (look elsewhere: mmad serialization,
                                             fixpipe, or the load2d issue-rate itself)."""
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)

    # own L0 double-buffers (hif8 = 16KB/slot): QK owns {l0a_qk,l0b_qk}, PV owns {l0a_pv,l0b_pv}
    l0a_qk = DBuff(DT.hif8, [TILE_N, D_HEAD], Position.L0A)
    l0b_qk = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L0B)
    l0a_pv = DBuff(DT.hif8, [TILE_M, TILE_N], Position.L0A)
    l0b_pv = DBuff(DT.hif8, [D_HEAD, TILE_N], Position.L0B)
    cnt_qk_a = Var(0, name="cnt_qk_a")
    cnt_qk_b = Var(0, name="cnt_qk_b")
    cnt_pv_a = Var(0, name="cnt_pv_a")
    cnt_pv_b = Var(0, name="cnt_pv_b")

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul_nosplit(l0c_qk[step], l1k[step], l1q[qm], l0a_qk, l0b_qk,
                               cnt_qk_a, cnt_qk_b, True, m=TILE_N, n=TILE_M, k=D_HEAD)
                _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                               m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_kv_base = Var(lag_batch * N)
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                matmul_nosplit(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                               l0a_pv, l0b_pv, cnt_pv_a, cnt_pv_b, True, m=TILE_M, n=D_HEAD, k=TILE_N)
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ full-V6 shared allocation (no control flow — safe as a helper) ============================
def _alloc_v6(q, k, v):
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")
    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.float, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_old_weight = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rmax = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_rsum = _CacheBuf(DT.float, [1, QLANES], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)
    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.float, [MAX_FD_WS, 1, TILE_M], name="fd_sum")
    return (q_hif8, k_hif8, v_hif8, l1q, l1k, l1v, l1p, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p,
            ub_old_weight, ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out, fd_accum, fd_max, fd_sum)


# ---- (base) + (4) mutexse : full V6, auto_sync ON, mutexes passed in ----
@func()
def _v6_full_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, p_mutex):
    (q_hif8, k_hif8, v_hif8, l1q, l1k, l1v, l1p, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p, ub_old_weight,
     ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out, fd_accum, fd_max, fd_sum) = _alloc_v6(q, k, v)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_t_scale_tail_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                            ub_old_weight[step], valid_n)
                else:
                    softmax_t_scale_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                       ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                               m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                sm2 = Var(lag_mt % CACHE)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_local_mt = Var(lag_mt % tiles_m_per_b)
                lag_q_base = Var(lag_batch * MQ)
                lag_kv_base = Var(lag_batch * N)
                lag_m0 = Var(lag_local_mt * TILE_M)
                lag_valid_m = Min(TILE_M, MQ - lag_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_kt == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                elif lag == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:
                    accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                fd_merge_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                            ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


# ---- (5) noautosync + (6) splitevent : full V6, main-loop auto_sync REMOVED. splitevent adds 2 DEvents on
#      the QK and PV mac->fix edges. Structural (not a flag) because @func rewrites `if` — see module docstring.
@func()
def _v6_noautosync_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, p_mutex):
    (q_hif8, k_hif8, v_hif8, l1q, l1k, l1v, l1p, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p, ub_old_weight,
     ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out, fd_accum, fd_max, fd_sum) = _alloc_v6(q, k, v)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    prefix_mt = Var(-1, DT.int)
    suffix_mt = Var(-1, DT.int)
    if my_tasks > 0:
        start_k = Var(flat_start % k_tiles)
        if start_k != 0:
            prefix_mt <<= flat_start // k_tiles
        end_k = Var(flat_end % k_tiles)
        if end_k != 0:
            suffix_mt <<= (flat_end - 1) // k_tiles

    for step in range(0, my_tasks + PRELOAD_N):
        if step < my_tasks:
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            qm = Var(mt % 2)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            kv_base = Var(batch * N)
            m0 = Var(local_mt * TILE_M)
            valid_m = Min(TILE_M, MQ - m0)
            n0 = Var(kt * TILE_N)
            valid_n = Min(TILE_N, N - n0)

            need_q = Var(0, DT.int)
            if kt == 0:
                need_q <<= 1
            if step == 0:
                need_q <<= 1
            if need_q > 0:
                l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

            l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            matmul(l0c_qk[step], l1k[step], l1q[qm],
                   m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

            cv.lock()
            _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
            cv.ready()
            cv.wait()
            if valid_n < TILE_N:
                softmax_t_scale_tail_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                        ub_old_weight[step], valid_n)
            else:
                softmax_t_scale_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                   ub_old_weight[step])
            cv.free()

            p_mutex.lock()
            ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                           m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
            p_mutex.ready()

        if step >= PRELOAD_N:
            lag = Var(step - PRELOAD_N)
            lag_t = Var(flat_start + lag)
            lag_mt = Var(lag_t // k_tiles)
            lag_kt = Var(lag_t % k_tiles)
            sm2 = Var(lag_mt % CACHE)
            lag_batch = Var(lag_mt // tiles_m_per_b)
            lag_local_mt = Var(lag_mt % tiles_m_per_b)
            lag_q_base = Var(lag_batch * MQ)
            lag_kv_base = Var(lag_batch * N)
            lag_m0 = Var(lag_local_mt * TILE_M)
            lag_valid_m = Min(TILE_M, MQ - lag_m0)
            local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
            lag_n0 = Var(lag_kt * TILE_N)
            v_rows = Min(TILE_N, N - lag_n0)

            l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
            p_mutex.wait()
            matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            p_mutex.free()

            pv_mutex.lock()
            l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
            pv_mutex.ready()
            pv_mutex.wait()

            if lag_kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[lag])
            elif lag == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[lag])
            else:
                accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
            pv_mutex.free()

            if lag_kt == k_tiles - 1:
                if lag_mt == prefix_mt:
                    if local_rows > 0:
                        fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                        fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                        fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                else:
                    final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                    if local_rows > 0:
                        out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                            ub_out[0:local_rows, 0:D]
                        )

            if lag + 1 == my_tasks:
                if lag_kt != k_tiles - 1:
                    if lag_mt == suffix_mt:
                        if local_rows > 0:
                            fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

    allvec_ready(7, Pipe.MTE3)
    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                fd_merge_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                            ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


@func()
def _v6_splitevent_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, p_mutex):
    (q_hif8, k_hif8, v_hif8, l1q, l1k, l1v, l1p, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p, ub_old_weight,
     ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out, fd_accum, fd_max, fd_sum) = _alloc_v6(q, k, v)

    ev_qk = SEvent(Pipe.M, Pipe.FIX, name="ev_qk")
    ev_pv = SEvent(Pipe.M, Pipe.FIX, name="ev_pv")

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    init_softmax_state_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
                ev_qk.set()
                ev_qk.wait()

                cv.lock()
                _qk_bridge_splitn(ub_score[step], l0c_qk[step], 1.0)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_t_scale_tail_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                            ub_old_weight[step], valid_n)
                else:
                    softmax_t_scale_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p,
                                       ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                               m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                sm2 = Var(lag_mt % CACHE)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_local_mt = Var(lag_mt % tiles_m_per_b)
                lag_q_base = Var(lag_batch * MQ)
                lag_kv_base = Var(lag_batch * N)
                lag_m0 = Var(lag_local_mt * TILE_M)
                lag_valid_m = Min(TILE_M, MQ - lag_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()
                ev_pv.set()
                ev_pv.wait()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_kt == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                elif lag == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:
                    accum_pv_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]
                    else:
                        final_div_cast_bf16_vf(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= ub_accum[0:local_rows, 0:D_HEAD]
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rmax[sm2][0:1, 0:local_rows]
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= ub_rsum[sm2][0:1, 0:local_rows]

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                fd_merge_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                            ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


def _cv_normal():
    return CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                   src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)


def _pv_normal():
    return CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)


def _p_normal():
    return VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)


def _pv_se():
    return CvMutex(2, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                   src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)


def _p_se():
    return VcMutex(1, depth=CACHE, src_start_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1,
                   src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)


@kernel()
def cprobe_base_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _v6_full_body(q, k, v, out, B, MQ, N, D, _cv_normal(), _pv_normal(), _p_normal())


@kernel()
def cprobe_purecube_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _cube_only_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_qkonly_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _qk_only_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_pvonly_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _pv_only_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_qkpv_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _qkpv_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_qk2x_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _qk2x_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_pvonlyfreshp_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _pvonly_freshp_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_cubeonly_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _cubeonly_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_veconly_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_vecnostore_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_pstorenz_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _pstorenz_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_pstorepad_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _pstorepad_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_phasesplit_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _phasesplit_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_splitl0_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _splitl0_body(q, k, v, out, B, MQ, N, D)


@kernel()
def cprobe_mutexse_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _v6_full_body(q, k, v, out, B, MQ, N, D, _cv_normal(), _pv_se(), _p_se())


@kernel()
def cprobe_noautosync_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _v6_noautosync_body(q, k, v, out, B, MQ, N, D, _cv_normal(), _pv_normal(), _p_normal())


@kernel()
def cprobe_splitevent_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _v6_splitevent_body(q, k, v, out, B, MQ, N, D, _cv_normal(), _pv_normal(), _p_normal())


_PROBES = {
    "base": cprobe_base_kernel, "purecube": cprobe_purecube_kernel, "qkonly": cprobe_qkonly_kernel,
    "pvonly": cprobe_pvonly_kernel, "mutexse": cprobe_mutexse_kernel,
    "noautosync": cprobe_noautosync_kernel, "splitevent": cprobe_splitevent_kernel,
    "qkpv": cprobe_qkpv_kernel, "qk2x": cprobe_qk2x_kernel, "pvonlyfreshp": cprobe_pvonlyfreshp_kernel,
    "phasesplit": cprobe_phasesplit_kernel, "splitl0": cprobe_splitl0_kernel,
    "pstorenz": cprobe_pstorenz_kernel, "pstorepad": cprobe_pstorepad_kernel,
    "cubeonly": cprobe_cubeonly_kernel, "veconly": cprobe_veconly_kernel,
    "vecnostore": cprobe_vecnostore_kernel,
}
_CORRECT = {"base", "mutexse", "splitevent"}


def main():
    probe = os.environ.get("PV_CPROBE", "base")
    kern = _PROBES[probe]
    torch.manual_seed(0)
    B = int(os.environ.get("PV_B", "1"))
    HQ = int(os.environ.get("PV_HQ", "8"))
    SQ = int(os.environ.get("PV_SQ", "257"))
    SKV = int(os.environ.get("PV_SKV", "256"))
    MQ = HQ * SQ
    q_fp32 = torch.randn((B * MQ, D_HEAD), dtype=torch.float32)
    k_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    v_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    q = fp32_to_hif8(q_fp32); k = fp32_to_hif8(k_fp32); v = fp32_to_hif8(v_fp32)
    out = torch.zeros((B * MQ, D_HEAD), dtype=torch.bfloat16)

    tiles_m_per_b = (MQ + TILE_M - 1) // TILE_M
    k_tiles = (SKV + TILE_N - 1) // TILE_N
    total_blocks = B * tiles_m_per_b

    mode = os.environ.get("PV_MODE", "sim")
    sim_cores = int(os.environ.get("PV_SIM_CORES", "4"))
    launch_cores = sim_cores if mode == "sim" else MAX_CORE_COUNT
    profile = os.environ.get("PV_PROFILE", "0") == "1"
    ok, max_owners, split_blocks = _pairwise_split_ok(total_blocks, k_tiles, launch_cores)
    if not ok and probe in _CORRECT:
        raise SystemExit("pairwise split precondition failed: max_owners={}".format(max_owners))

    kern._simulator_config = SimulatorConfig(core_count=sim_cores, execution_timeout_s=3600.0)
    d = os.environ.get("PV_OUT_DIR") or "./tmp/pfa_fd_v6cprobe_{}_{}".format(probe, mode)
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, out, B, MQ, SKV, D_HEAD)
    sb = {0: [1 if B == 1 else None, 3], 1: [2 if B == 1 else None, 3],
          2: [2 if B == 1 else None, 3], 3: [1 if B == 1 else None, 3]}

    print("V6-CPROBE[{}]: B={} HQ={} SQ={} SKV={} blocks={} k_tiles={} cores={} split={}".format(
        probe, B, HQ, SQ, SKV, total_blocks, k_tiles, launch_cores, split_blocks))
    if mode == "sim":
        outs = OpExec(kern, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, cannsim=True)(*args, shape_bindings=sb)
    elif mode == "hw":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")

    O = torch.as_tensor(outs).float()
    qf = hif8_to_fp32(q); kf = hif8_to_fp32(k); vf = hif8_to_fp32(v)
    o_ref = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV)
    tag = "CORRECT" if probe in _CORRECT else "profiling-only (output not meaningful)"
    print("|O| max={:.3f}  [{}]".format(O.abs().max().item(), tag))
    print("O vs fp32 ref:     max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref.to(torch.bfloat16).float())))


if __name__ == "__main__":
    main()
