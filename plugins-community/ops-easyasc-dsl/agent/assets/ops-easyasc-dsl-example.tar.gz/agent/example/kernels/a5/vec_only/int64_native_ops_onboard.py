"""Phase B: on-board smoke + sim/board alignment for the int64 reg ops that were
already native in the simulator but not yet validated on the Ascend950 board.

The simulator handled these integer paths natively, but that only proves the DSL
and the *simulator* agree -- it does not prove the generated MicroAPI compiles and
runs on hardware. The `format_scalar` ops are the real risk: `adds`/`muls` needed
a typed `(int64_t)K` immediate to satisfy the MicroAPI `SupportType<U, ...>` assert
(the axpy fix), and `shiftls`/`shiftrs`/`compares`/`dup` lower their scalar through
the SAME `format_scalar`, so whether the board's ShiftScalar/CompareScalar/Duplicate
accept an int64_t immediate is exactly what this run answers. The reg-reg arithmetic
and bitwise ops, `select`, and the fused `abssub`/`muladddst` round out the surface.

Each op family is a separate `@kernel` so a board *build* failure in one is isolated
and still yields a clean pass/fail matrix for the rest (a compile abort would
otherwise hide every other op in the same kernel). Magnitudes are ~2**28 so an fp32
path would diverge, while every product stays < 2**63 (no wrap ambiguity).

Run:
- simulator (default): python kernels/a5/vec_only/int64_native_ops_onboard.py
- on Ascend950 board:   python kernels/a5/vec_only/int64_native_ops_onboard.py --run
"""
import builtins
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403  (also shadows builtin `range` with the DSL range)

ROWS = 64
COLS = 32  # 32 int64 lanes = 256 bytes = one full vector register

# ~2**28 magnitudes: > 2**24 (an fp32 path loses bits) yet a*b < 2**63 (no wrap).
KA = 262147
KB = 131101
SHIFT = 5
DUP_K = 2 ** 40 + 12345          # large int64 immediate for Duplicate
CMP_S = 12345678                 # splits the a-range so compares yields mixed lanes


# --------------------------------------------------------------------------- #
# K1: reg-reg arithmetic + bitwise (low risk, standard integer MicroAPI ops).
# --------------------------------------------------------------------------- #
_SAFE_NAMES = ["add", "sub", "mul", "vand", "vor", "vxor", "vnot"]


@vf()
def int64_safe_vf(ub_a: Tensor, ub_b: Tensor, ub_add: Tensor, ub_sub: Tensor,
                  ub_mul: Tensor, ub_and: Tensor, ub_or: Tensor, ub_xor: Tensor,
                  ub_not: Tensor):
    ra = Reg(DT.int64, name="sf_a")
    rb = Reg(DT.int64, name="sf_b")
    ra <<= ub_a[0]
    rb <<= ub_b[0]
    r_add = Reg(DT.int64, name="sf_add")
    r_sub = Reg(DT.int64, name="sf_sub")
    r_mul = Reg(DT.int64, name="sf_mul")
    r_and = Reg(DT.int64, name="sf_and")
    r_or = Reg(DT.int64, name="sf_or")
    r_xor = Reg(DT.int64, name="sf_xor")
    r_not = Reg(DT.int64, name="sf_not")
    add(r_add, ra, rb)
    sub(r_sub, ra, rb)
    mul(r_mul, ra, rb)
    vand(r_and, ra, rb)
    vor(r_or, ra, rb)
    vxor(r_xor, ra, rb)
    vnot(r_not, ra)
    ub_add[0] <<= r_add
    ub_sub[0] <<= r_sub
    ub_mul[0] <<= r_mul
    ub_and[0] <<= r_and
    ub_or[0] <<= r_or
    ub_xor[0] <<= r_xor
    ub_not[0] <<= r_not


@kernel(mode="vec")
def int64_safe_kernel(a: GMTensor, b: GMTensor, o_add: GMTensor, o_sub: GMTensor,
                      o_mul: GMTensor, o_and: GMTensor, o_or: GMTensor,
                      o_xor: GMTensor, o_not: GMTensor, rows: Var):
    ub_a = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_sa")
    ub_b = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_sb")
    ubs = [Tensor(DT.int64, [1, COLS], Position.UB, name=f"ub_sf{i}") for i in builtins.range(7)]
    rpv = CeilDiv(rows, GetVecNum())
    rb0 = Var(rpv * GetVecIdx())
    re0 = Min(rb0 + rpv, rows)
    outs = [o_add, o_sub, o_mul, o_and, o_or, o_xor, o_not]
    with auto_sync():
        for r in range(rb0, re0, name="safe_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            ub_b[:, :] <<= b[r:r + 1, :]
            int64_safe_vf(ub_a, ub_b, *ubs)
            for gm, ub in zip(outs, ubs):
                gm[r:r + 1, :] <<= ub
    return o_add, o_sub, o_mul, o_and, o_or, o_xor, o_not


# --------------------------------------------------------------------------- #
# K2: scalar shifts -- lower the shift amount through format_scalar.
# --------------------------------------------------------------------------- #
_SHIFT_NAMES = ["shiftls", "shiftrs"]


@vf()
def int64_shift_vf(ub_a: Tensor, ub_ls: Tensor, ub_rs: Tensor):
    ra = Reg(DT.int64, name="sh_a")
    ra <<= ub_a[0]
    r_ls = Reg(DT.int64, name="sh_ls")
    r_rs = Reg(DT.int64, name="sh_rs")
    shiftls(r_ls, ra, SHIFT)
    shiftrs(r_rs, ra, SHIFT)
    ub_ls[0] <<= r_ls
    ub_rs[0] <<= r_rs


@kernel(mode="vec")
def int64_shift_kernel(a: GMTensor, o_ls: GMTensor, o_rs: GMTensor, rows: Var):
    ub_a = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_sha")
    ub_ls = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_ls")
    ub_rs = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_rs")
    rpv = CeilDiv(rows, GetVecNum())
    rb0 = Var(rpv * GetVecIdx())
    re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="shift_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            int64_shift_vf(ub_a, ub_ls, ub_rs)
            o_ls[r:r + 1, :] <<= ub_ls
            o_rs[r:r + 1, :] <<= ub_rs
    return o_ls, o_rs


# --------------------------------------------------------------------------- #
# K3: dup a large int64 immediate (Duplicate via format_scalar).
# --------------------------------------------------------------------------- #
_DUP_NAMES = ["dup"]


@vf()
def int64_dup_vf(ub_a: Tensor, ub_dup: Tensor):
    # ub_a is loaded only to satisfy OpExec's "a kernel needs >=1 input GMTensor"
    # rule; dup writes a compile-time int64 immediate independent of the input.
    ra = Reg(DT.int64, name="dp_a")
    ra <<= ub_a[0]
    r_dup = Reg(DT.int64, name="dp_r")
    dup(r_dup, DUP_K)
    ub_dup[0] <<= r_dup


@kernel(mode="vec")
def int64_dup_kernel(a: GMTensor, o_dup: GMTensor, rows: Var):
    ub_a = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_dupa")
    ub_dup = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_dup")
    rpv = CeilDiv(rows, GetVecNum())
    rb0 = Var(rpv * GetVecIdx())
    re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="dup_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            int64_dup_vf(ub_a, ub_dup)
            o_dup[r:r + 1, :] <<= ub_dup
    return o_dup


# --------------------------------------------------------------------------- #
# K4: compare (reg-reg) + compares (scalar) observed through select.
# --------------------------------------------------------------------------- #
_CMPSEL_NAMES = ["cmp_rr_sel", "cmp_rs_sel"]


@vf()
def int64_cmpsel_vf(ub_a: Tensor, ub_b: Tensor, ub_rr: Tensor, ub_rs: Tensor):
    ra = Reg(DT.int64, name="cs_a")
    rb = Reg(DT.int64, name="cs_b")
    ra <<= ub_a[0]
    rb <<= ub_b[0]
    r_rr = Reg(DT.int64, name="cs_rr")
    r_rs = Reg(DT.int64, name="cs_rs")
    m_rr = MaskReg(DT.int64, init_mode=MaskType.NONE, name="cs_m_rr")
    m_rs = MaskReg(DT.int64, init_mode=MaskType.NONE, name="cs_m_rs")
    # reg-reg compare: mask = a > b, then pick a where true else b (== max)
    compare(m_rr, ra, rb, CompareMode.GT)
    select(r_rr, ra, rb, mask=m_rr)
    # scalar compare: mask = a > CMP_S, then pick a where true else b
    compare(m_rs, ra, CMP_S, CompareMode.GT)
    select(r_rs, ra, rb, mask=m_rs)
    ub_rr[0] <<= r_rr
    ub_rs[0] <<= r_rs


@kernel(mode="vec")
def int64_cmpsel_kernel(a: GMTensor, b: GMTensor, o_rr: GMTensor, o_rs: GMTensor,
                        rows: Var):
    ub_a = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_ca")
    ub_b = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_cb")
    ub_rr = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_rr")
    ub_rs = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_rs2")
    rpv = CeilDiv(rows, GetVecNum())
    rb0 = Var(rpv * GetVecIdx())
    re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="cmpsel_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            ub_b[:, :] <<= b[r:r + 1, :]
            int64_cmpsel_vf(ub_a, ub_b, ub_rr, ub_rs)
            o_rr[r:r + 1, :] <<= ub_rr
            o_rs[r:r + 1, :] <<= ub_rs
    return o_rr, o_rs


# --------------------------------------------------------------------------- #
# K5: fused abssub (int64) + muladddst (int64).
# --------------------------------------------------------------------------- #
_FUSED_NAMES = ["abssub", "muladddst"]


@vf()
def int64_fused_vf(ub_a: Tensor, ub_b: Tensor, ub_abs: Tensor, ub_mad: Tensor):
    ra = Reg(DT.int64, name="fu_a")
    rb = Reg(DT.int64, name="fu_b")
    ra <<= ub_a[0]
    rb <<= ub_b[0]
    r_abs = Reg(DT.int64, name="fu_abs")
    r_mad = Reg(DT.int64, name="fu_mad")
    abssub(r_abs, ra, rb)          # abs(a - b)
    r_mad <<= rb                   # muladddst accumulates into dst: dst = a*a + b
    muladddst(r_mad, ra, ra)
    ub_abs[0] <<= r_abs
    ub_mad[0] <<= r_mad


@kernel(mode="vec")
def int64_fused_kernel(a: GMTensor, b: GMTensor, o_abs: GMTensor, o_mad: GMTensor,
                       rows: Var):
    ub_a = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_fa")
    ub_b = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_fb")
    ub_abs = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_fabs")
    ub_mad = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_fmad")
    rpv = CeilDiv(rows, GetVecNum())
    rb0 = Var(rpv * GetVecIdx())
    re0 = Min(rb0 + rpv, rows)
    with auto_sync():
        for r in range(rb0, re0, name="fused_row"):
            ub_a[:, :] <<= a[r:r + 1, :]
            ub_b[:, :] <<= b[r:r + 1, :]
            int64_fused_vf(ub_a, ub_b, ub_abs, ub_mad)
            o_abs[r:r + 1, :] <<= ub_abs
            o_mad[r:r + 1, :] <<= ub_mad
    return o_abs, o_mad


# --------------------------------------------------------------------------- #
# Driver
# --------------------------------------------------------------------------- #
def _make_inputs():
    idx = torch.arange(ROWS * COLS, dtype=torch.int64).reshape(ROWS, COLS)
    a = ((idx - (ROWS * COLS) // 2) * KA).contiguous()            # ±~2**28
    b = (((idx * 7) % 4099 - 2048) * KB).contiguous()             # ±~2**28
    return a, b


def _opexec(kern, mode, run_on_board, tag, nout):
    if run_on_board:
        cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"])
    else:
        cfg = dict(simulator=True)
    return OpExec(kern, out_dir=os.path.abspath(f"tmp/int64_native/{mode}_{tag}"),
                  custom_op_path=os.path.abspath("tmp/int64_native/custom_opp"), **cfg)


def _golden(a, b):
    return {
        "add": a + b,
        "sub": a - b,
        "mul": a * b,
        "vand": a & b,
        "vor": a | b,
        "vxor": a ^ b,
        "vnot": ~a,
        "shiftls": a << SHIFT,
        "shiftrs": a >> SHIFT,                        # arithmetic (signed int64)
        "dup": torch.full_like(a, DUP_K),
        "cmp_rr_sel": torch.where(a > b, a, b),
        "cmp_rs_sel": torch.where(a > CMP_S, a, b),
        "abssub": torch.abs(a - b),
        "muladddst": a * a + b,
    }


def _check(mode, name, got, want, fails):
    if torch.equal(got, want):
        print(f"[{mode}] {name:12s} OK  (bit-exact int64)")
    else:
        bad = torch.nonzero(got != want, as_tuple=False)
        first = bad[0].tolist()
        print(f"[{mode}] {name:12s} MISMATCH count={bad.shape[0]} first={first} "
              f"got={int(got[tuple(first)])} want={int(want[tuple(first)])}")
        fails.append(name)


def check_case(run_on_board):
    a, b = _make_inputs()
    g = _golden(a, b)
    mode = "board" if run_on_board else "sim"
    fails, build_fails = [], []

    def run(tag, kern, names, inputs):
        """Build+run one kernel; a build/exec error is recorded, not fatal, so the
        remaining kernels still report (a board compile abort is per-kernel)."""
        try:
            outs = [torch.zeros((ROWS, COLS), dtype=torch.int64) for _ in names]
            res = _opexec(kern, mode, run_on_board, tag, len(names))(*inputs, *outs, ROWS)
            if not isinstance(res, (list, tuple)):
                res = (res,)
            for name, got in zip(names, res):
                _check(mode, name, got, g[name], fails)
        except Exception as exc:  # noqa: BLE001  -- want the whole matrix even on one failure
            print(f"[{mode}] {tag:8s} BUILD/RUN-FAIL: {type(exc).__name__}: {str(exc)[:200]}")
            build_fails.extend(names)

    run("safe", int64_safe_kernel, _SAFE_NAMES, (a, b))
    run("shift", int64_shift_kernel, _SHIFT_NAMES, (a,))
    run("dup", int64_dup_kernel, _DUP_NAMES, (a,))
    run("cmpsel", int64_cmpsel_kernel, _CMPSEL_NAMES, (a, b))
    run("fused", int64_fused_kernel, _FUSED_NAMES, (a, b))

    total = len(_SAFE_NAMES) + len(_SHIFT_NAMES) + len(_DUP_NAMES) + len(_CMPSEL_NAMES) + len(_FUSED_NAMES)
    ok = total - len(fails) - len(build_fails)
    print(f"\n[{mode}] summary: {ok}/{total} ops bit-exact; "
          f"value-mismatch={fails or '-'}; build/run-fail={build_fails or '-'}")
    if fails or build_fails:
        raise AssertionError(f"int64 native-ops {mode}: mismatch={fails} build_fail={build_fails}")
    print(f"[{mode}] ALL {total} int64 native ops bit-exact")


if __name__ == "__main__":
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1"
    check_case(run_on_board=run)
