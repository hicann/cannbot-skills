from typing import Any, Tuple

from easyasc.a5 import *
from tools.estimate_matmul_datamove import (
    SPLIT_MODE_MIX,
    estimate_multi_core,
    estimate_strategy,
    generate_split_candidates,
)


TILE_M = 128
TILE_N = 256
TILE_K = 256
SPLIT_K = 64
ADD_VALUE = 1.0

SHAPE_BINDINGS = {
    0: [0, 2],  # x[M, K]
    1: [1, 2],  # y[N, K]
    2: [0, 1],  # z[M, N]
}


@vf()
def add_one_vf(tile_ub: Tensor, n_loops: Var):
    reg_f = Reg(DT.float)
    for i in range(n_loops):
        reg_f <<= tile_ub[i * 64]
        reg_f <<= reg_f + ADD_VALUE
        tile_ub[i * 64] <<= reg_f
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


def _split_rank(datamove: int, m_split: int, n_split: int) -> Tuple[int, int, int, int, int]:
    split_diff = m_split - n_split if m_split >= n_split else n_split - m_split
    shared_depth = m_split if m_split <= n_split else n_split
    return (
        datamove,
        0 if m_split > 1 and n_split > 1 else 1,
        split_diff,
        -shared_depth,
        m_split,
        n_split,
    )


def _pick_best_split(items: Any) -> Tuple[int, int, int]:
    best_item = None

    for item in items:
        candidate = _split_rank(item["datamove"], item["m_split"], item["n_split"])
        if best_item is None or candidate < best_item[0]:
            best_item = (candidate, item)

    if best_item is None:
        raise ValueError("No valid split candidate found for matmul_mknk_2dgrid_splitk_add1")

    picked = best_item[1]
    return picked["m_split"], picked["n_split"], picked["datamove"]


def select_mknk_2dgrid_splitk_add1(m: int, n: int, k: int, num_core: int = 32) -> Tuple[int, int, int]:
    search = estimate_strategy(
        m,
        n,
        k,
        num_core,
        SPLIT_MODE_MIX,
        min_tile_m=TILE_M,
        min_tile_n=TILE_N,
        dbuf_l0c=True,
    )
    exact_tile_matches = [
        item
        for item in search["best_results"]
        if item["TILEM"] == TILE_M and item["TILEN"] == TILE_N and item["TILEK"] == TILE_K
    ]
    if exact_tile_matches:
        return _pick_best_split(exact_tile_matches)

    fallback_results = []
    for m_split, n_split in generate_split_candidates(num_core, SPLIT_MODE_MIX):
        try:
            datamove = estimate_multi_core(
                m,
                n,
                k,
                m_split,
                n_split,
                TILE_M,
                TILE_N,
                TILE_K,
                dbuf_l0c=True,
            )
        except ValueError:
            continue
        fallback_results.append(
            {
                "datamove": datamove,
                "m_split": m_split,
                "n_split": n_split,
            }
        )

    if not fallback_results:
        raise ValueError("No valid fixed-tile strategy found for matmul_mknk_2dgrid_splitk_add1")

    return _pick_best_split(fallback_results)


@kernel()
def matmul_mknk_2dgrid_splitk_add1_kernel(
    x: GMTensor, y: GMTensor, z: GMTensor,
    M: Var, N: Var, K: Var, M_SPLIT: Var, N_SPLIT: Var,
):
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1y = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)
    tile_ub = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)

    l1_cnt = Var(0)
    tile_cnt = Var(0)
    vf_loops = Var(TILE_M // 2 * TILE_N // 64)

    core_m_idx = Var(GetCubeIdx() // N_SPLIT)
    core_n_idx = Var(GetCubeIdx() % N_SPLIT)
    tile_m = CeilDiv(M, TILE_M)
    tile_n = CeilDiv(N, TILE_N)
    tile_m_per_split = CeilDiv(tile_m, M_SPLIT)
    tile_n_per_split = CeilDiv(tile_n, N_SPLIT)
    tile_m_begin = Var(tile_m_per_split * core_m_idx)
    tile_m_end = Min(tile_m_begin + tile_m_per_split, tile_m)
    tile_n_begin = Var(tile_n_per_split * core_n_idx)
    tile_n_end = Min(tile_n_begin + tile_n_per_split, tile_n)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            for nt in range(tile_n_begin, tile_n_end):
                n0 = Var(nt * TILE_N)
                valid_n = Min(TILE_N, N - n0)
                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    l1x[l1_cnt] <<= x[m0:m0 + valid_m, k0:k0 + valid_k]
                    l1y[l1_cnt] <<= y[n0:n0 + valid_n, k0:k0 + valid_k]
                    matmul(
                        l0c[tile_cnt][0:valid_m, 0:valid_n],
                        l1x[l1_cnt],
                        l1y[l1_cnt],
                        splitk=SPLIT_K,
                        m=valid_m,
                        n=valid_n,
                        k=valid_k,
                        is_init=(k0 == 0),
                    )
                    l1_cnt += 1

                cvmutex.lock()
                tile_ub[tile_cnt] <<= l0c[tile_cnt]
                cvmutex.ready()

                cvmutex.wait()
                add_one_vf(tile_ub[tile_cnt], vf_loops)
                cvmutex.free()

                half_rows = CeilDiv(valid_m, 2)
                sb_idx = GetSubBlockIdx()
                row_begin = sb_idx * half_rows
                row_end = Min(row_begin + half_rows, valid_m)
                row_count = row_end - row_begin
                z[m0 + row_begin:m0 + row_end, n0:n0 + valid_n] <<= tile_ub[tile_cnt][0:row_count, 0:valid_n]

                tile_cnt += 1
    return z


if __name__ == "__main__":
    import torch

    large_m = 10240
    large_n = 5120
    large_k = 2560
    large_m_split, large_n_split, large_datamove = select_mknk_2dgrid_splitk_add1(large_m, large_n, large_k)
    print(
        "large_shape=(M={m}, N={n}, K={k}) selected_split=(m_split={ms}, n_split={ns}) outer_tile_datamove={dm}".format(
            m=large_m,
            n=large_n,
            k=large_k,
            ms=large_m_split,
            ns=large_n_split,
            dm=large_datamove,
        )
    )

    test_shapes = [(128, 256, 256)]

    for M, N, K in test_shapes:
        m_split, n_split, _ = select_mknk_2dgrid_splitk_add1(M, N, K)
        torch.manual_seed(0)
        x = torch.rand((M, K), dtype=torch.float16)
        y = torch.rand((N, K), dtype=torch.float16)
        z = torch.zeros((M, N), dtype=torch.float32)

        z_kernel = OpExec(matmul_mknk_2dgrid_splitk_add1_kernel, simulator=True)(
            x,
            y,
            z,
            M,
            N,
            K,
            m_split,
            n_split,
            shape_bindings=SHAPE_BINDINGS,
        )
        z_ref = x.float() @ y.float().t() + ADD_VALUE

        torch.testing.assert_close(z_kernel, z_ref, rtol=3e-3, atol=3e-3)
        print(f"shape=(M={M}, N={N}, K={K})")
        print(f"selected_split=(m_split={m_split}, n_split={n_split})")
        print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
