"""Cube matmul + SIMT transpose -- contiguous-UB-read variant.

Hybrid kernel: cube computes a @ b.t() into UB, then SIMT writes the
transposed result to GM.  This file pairs the SIMT body with a
*contiguous UB read* (in_ub[i] for thread i) at the cost of a *strided
GM write* (stride M).  Compare against simt_matmul_transpose_contig_write.py,
which makes the opposite trade.
"""

import sys

from easyasc.a5 import *


@simt()
def transpose_simt_contig_read(in_ub: Tensor, out_gm: GMTensor, M: Var, N: Var):
    """Decompose the flat thread index into the *input* layout.

    row = i / N, col = i % N, then out_gm[col * M + row] = in_ub[i].
    UB reads are contiguous; GM writes are strided by M.
    """
    total = M * N
    for i in range(simt_thread_id(), total, simt_thread_num()):
        row = i / N
        col = i % N
        out_gm[col * M + row] = in_ub[row * N + col]


@kernel()
def simt_matmul_transpose_contig_read_kernel(
    a: GMTensor, b: GMTensor, c_t: GMTensor, m: Var, n: Var, k: Var
):
    l1a = Tensor(DT.float, [m, k], Position.L1)
    l1b = Tensor(DT.float, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)
    out_ub = Tensor(DT.float, [m, n], Position.UB)

    cv = CvMutex(flag_id=0, dst_end_pipe=Pipe.V)

    with auto_sync():
        l1a <<= a[:, :]
        l1b <<= b[:, :]
        matmul(l0c, l1a, l1b)
        cv.lock()
        l0c_to_ub(out_ub, l0c, dual_mode=DualMode.SINGLE, sub_block_id=0)
        l0c_to_ub(out_ub, l0c, dual_mode=DualMode.SINGLE, sub_block_id=1)
        cv.ready()
        cv.wait()
        transpose_simt_contig_read(out_ub, c_t, m, n)
        cv.free()

    return c_t


if __name__ == "__main__":
    import torch

    use_cannsim = "--cannsim" in sys.argv[1:]

    M, N, K = 32, 16, 8
    torch.manual_seed(0)
    a = torch.randn((M, K), dtype=torch.float32)
    b = torch.randn((N, K), dtype=torch.float32)
    c_t = torch.zeros((N, M), dtype=torch.float32)

    SHAPE_BINDINGS = {
        0: [0, 2],  # a [M, K]
        1: [1, 2],  # b [N, K]
        2: [1, 0],  # c_t [N, M]
    }

    if use_cannsim:
        actual = OpExec(
            simt_matmul_transpose_contig_read_kernel,
            out_dir="./tmp/simt_matmul_transpose_contig_read_cannsim",
            simulator=False,
            cannsim=True,
        )(a, b, c_t, M, N, K, shape_bindings=SHAPE_BINDINGS)
    else:
        actual = OpExec(
            simt_matmul_transpose_contig_read_kernel,
            out_dir="./tmp/simt_matmul_transpose_contig_read_simulator",
            simulator=True,
        )(a, b, c_t, M, N, K, shape_bindings=SHAPE_BINDINGS)

    expected = (a @ b.t()).t()
    torch.testing.assert_close(actual, expected, rtol=1e-4, atol=1e-4)
    print(f"max_abs_diff={torch.max(torch.abs(actual - expected)).item():.6e}")
