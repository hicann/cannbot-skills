"""Is `reg_to_ub_scatter`'s mask lane-wise, or expanded to whole C0 blocks?

The API doc says lane-wise ("It is not expanded to C0 blocks"), but the
simulator runs the mask through `_expand_mask_c0` first.  The two disagree, and
the difference decides whether a scatter can write a *subset* of a 32-byte
block - which is what a packed output tile with an odd row width needs.

Two probes, each writing into a destination pre-filled with a sentinel:

``b32``
    lanes 0..4 active out of a 8-lane C0 block, index[i] = i.
    lane-wise -> 5 written;  C0-expanded -> 8 written.

``b16``
    the even lanes of a 16-lane C0 block active, index[2i] = index[2i+1] = i,
    which is the layout `cast` produces when it narrows a b32 register.
    lane-wise -> the cast results land intact;  C0-expanded -> the odd lanes
    (the untouched high halves) win the duplicate-index race and clobber them.

Run:
- simulator (default): python kernels/a5/vec_only/scatter_mask_probe.py
- on Ascend950 board:   python kernels/a5/vec_only/scatter_mask_probe.py --run
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403

LANES_32 = 64
N = 64
ACTIVE32 = 5
ACTIVE16 = 11
SENTINEL = -1.0


@vf()
def scatter32_vf(src_ub, dst_ub, active: Var):
    value = Reg(DT.float, name="sm32_value")
    lane = Reg(DT.int, name="sm32_lane")
    index = Reg(DT.uint32, name="sm32_index")
    live = MaskReg(DT.float, init_mode=MaskType.NONE, name="sm32_live")
    lanes = Var(active, dtype=DT.uint32)
    update_mask(live, lanes)
    arange(lane, 0)
    lane_u = lane.reinterpret(DT.uint32, name="sm32_lane_u")
    adds(index, lane_u, 0)
    ub_to_reg_normal(value, src_ub[0:1, 0:LANES_32])
    reg_to_ub_scatter(dst_ub[0:1, 0:N], value, index, mask=live)


@kernel(mode="vec")
def scatter32_kernel(src: GMTensor, init: GMTensor, out: GMTensor, active: Var):
    src_ub = Tensor(DT.float, [1, LANES_32], Position.UB, name="sm32_src")
    dst_ub = Tensor(DT.float, [1, N], Position.UB, name="sm32_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        dst_ub[:, :] <<= init[0:1, :]
        scatter32_vf(src_ub, dst_ub, active)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def scatter16_vf(src_ub, dst_ub, active: Var):
    wide = Reg(DT.float, name="sm16_wide")
    narrow = Reg(DT.half, name="sm16_narrow")
    lane = Reg(DT.int16, name="sm16_lane")
    half = Reg(DT.uint16, name="sm16_half")
    twice = Reg(DT.uint16, name="sm16_twice")
    probe = Reg(DT.uint16, name="sm16_probe")
    limit = Reg(DT.uint16, name="sm16_limit")
    index = Reg(DT.uint16, name="sm16_index")
    live = MaskReg(DT.uint16, init_mode=MaskType.NONE, name="sm16_live")
    to_narrow = CastConfig(round_mode=RoundMode.TO_EVEN, name="sm16_round")

    arange(lane, 0)
    lane_u = lane.reinterpret(DT.uint16, name="sm16_lane_u")
    shiftrs(half, lane_u, 1)
    shiftls(twice, half, 1)
    sub(probe, lane_u, twice)
    # Odd lanes get a probe value no lane count can reach, so only the even
    # lanes below `active` survive the compare.
    muls(probe, probe, LANES_32)
    add(probe, probe, half)
    dup(limit, Var(active, dtype=DT.uint16))
    compare(live, probe, limit, CompareMode.LT)

    ub_to_reg_normal(wide, src_ub[0:1, 0:LANES_32])
    cast(narrow, wide, to_narrow)
    vcopy(index, half)
    reg_to_ub_scatter(dst_ub[0:1, 0:N], narrow, index, mask=live)


@kernel(mode="vec")
def scatter16_kernel(src: GMTensor, init: GMTensor, out: GMTensor, active: Var):
    src_ub = Tensor(DT.float, [1, LANES_32], Position.UB, name="sm16_src")
    dst_ub = Tensor(DT.half, [1, N], Position.UB, name="sm16_dst")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        dst_ub[:, :] <<= init[0:1, :]
        scatter16_vf(src_ub, dst_ub, active)
        out[0:1, :] <<= dst_ub
    return out


def main(run):
    mode = "board" if run else "sim"
    src = torch.arange(1, LANES_32 + 1, dtype=torch.float32).reshape(1, LANES_32)
    cfg = dict(simulator=False, debug=False,
               cann_path=os.environ["ASCEND_HOME_PATH"]) if run else dict(simulator=True)

    for tag, kern, dtype, active in (("b32", scatter32_kernel, torch.float32, ACTIVE32),
                                     ("b16", scatter16_kernel, torch.float16, ACTIVE16)):
        init = torch.full((1, N), SENTINEL, dtype=dtype)
        out = torch.zeros(1, N, dtype=dtype)
        try:
            res = OpExec(kern, out_dir=os.path.abspath("tmp/scmask/" + tag),
                         custom_op_path=os.path.abspath("tmp/scmask/opp"),
                         **cfg)(src.contiguous(), init.contiguous(), out, active)
            got = (res if isinstance(res, torch.Tensor) else res[0]).reshape(-1).float()
            written = int((got != SENTINEL).sum())
            correct = torch.equal(got[:active], src.reshape(-1)[:active])
            verdict = ("LANE-WISE" if written == active and correct
                       else "C0-EXPANDED" if written > active else "OTHER")
            print("[{}] {} active={} written={} head={} -> {}".format(
                mode, tag, active, written, got[:active + 6].tolist(), verdict))
        except Exception as exc:  # noqa: BLE001
            print("[{}] {} FAIL {}: {}".format(mode, tag, type(exc).__name__,
                                               str(exc)[:220]))


if __name__ == "__main__":
    main("--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1")
