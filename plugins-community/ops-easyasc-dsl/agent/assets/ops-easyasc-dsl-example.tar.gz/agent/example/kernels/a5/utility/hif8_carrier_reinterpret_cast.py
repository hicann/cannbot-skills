"""CANNSIM smoke for true hif8 casts behind uint8 public carriers.

Contract:
- Device: a5 / Ascend950.
- Input/output carrier tensors are public `DT.uint8` because torch has no hif8
  dtype.
- Inside the kernel, carrier UB tensors are reinterpreted to `DT.hif8`.
- The decode kernel checks `uint8 carrier -> hif8 -> fp32`.
- The encode kernels check `fp32 -> hif8 -> uint8 carrier` for both
  `CAST_ROUND` and `CAST_HYBRID`.
- The half kernels check `uint8 carrier -> hif8 -> fp16` and
  `fp16 -> hif8 -> uint8 carrier` for both `CAST_ROUND` and `CAST_HYBRID`.
- The visible validation shape is aligned to the micro tile sizes; this probe
  is for format support, not tail handling.
"""

import os
import sys

import numpy as np
import torch

from easyasc.a5 import *


FLOAT_TILE = 64
HALF_TILE = 128
TOTAL = 256
SHAPE_BINDINGS = {
    0: [0],
    1: [0],
}


@vf()
def cast_hif8_to_float_vf(src_hif8: Tensor, dst_float: Tensor):
    src_reg = Reg(DT.hif8)
    dst_reg = Reg(DT.float)
    dst_mask = MaskReg(DT.float)
    cfg = CastConfig(round_mode=RoundMode.NONE, name="cfg_hif8_to_float")

    ub_to_reg_unpack4(src_reg, src_hif8[0])
    cast(dst_reg, src_reg, cfg, dst_mask)
    dst_float[0] <<= dst_reg


@vf()
def cast_float_to_hif8_vf(src_float: Tensor, dst_hif8: Tensor):
    src_reg = Reg(DT.float)
    dst_reg = Reg(DT.hif8)
    dst_mask = MaskReg(DT.hif8)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, name="cfg_float_to_hif8")

    src_reg <<= src_float[0]
    cast(dst_reg, src_reg, cfg, dst_mask)
    dst_hif8[0] <<= dst_reg.pack4()


@vf()
def cast_float_to_hif8_hybrid_vf(src_float: Tensor, dst_hif8: Tensor):
    src_reg = Reg(DT.float)
    dst_reg = Reg(DT.hif8)
    dst_mask = MaskReg(DT.hif8)
    cfg = CastConfig(round_mode=RoundMode.HYBRID, name="cfg_float_to_hif8_hybrid")

    src_reg <<= src_float[0]
    cast(dst_reg, src_reg, cfg, dst_mask)
    dst_hif8[0] <<= dst_reg.pack4()


@vf()
def cast_hif8_to_half_vf(src_hif8: Tensor, dst_half: Tensor):
    src_reg = Reg(DT.hif8)
    dst_reg = Reg(DT.half)
    dst_mask = MaskReg(DT.half)
    cfg = CastConfig(round_mode=RoundMode.NONE, name="cfg_hif8_to_half")

    ub_to_reg_unpack(src_reg, src_hif8[0])
    cast(dst_reg, src_reg, cfg, dst_mask)
    dst_half[0] <<= dst_reg


@vf()
def cast_half_to_hif8_vf(src_half: Tensor, dst_hif8: Tensor):
    src_reg = Reg(DT.half)
    dst_reg = Reg(DT.hif8)
    dst_mask = MaskReg(DT.hif8)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, name="cfg_half_to_hif8")

    src_reg <<= src_half[0]
    cast(dst_reg, src_reg, cfg, dst_mask)
    dst_hif8[0] <<= dst_reg.downsample()


@vf()
def cast_half_to_hif8_hybrid_vf(src_half: Tensor, dst_hif8: Tensor):
    src_reg = Reg(DT.half)
    dst_reg = Reg(DT.hif8)
    dst_mask = MaskReg(DT.hif8)
    cfg = CastConfig(round_mode=RoundMode.HYBRID, name="cfg_half_to_hif8_hybrid")

    src_reg <<= src_half[0]
    cast(dst_reg, src_reg, cfg, dst_mask)
    dst_hif8[0] <<= dst_reg.downsample()


@kernel()
def hif8_carrier_to_float_kernel(x_carrier: GMTensor, y_float: GMTensor, total: Var):
    ub_carrier = Tensor(DT.uint8, [1, FLOAT_TILE], Position.UB)
    ub_hif8 = ub_carrier.reinterpret(DT.hif8, name="ub_hif8")
    ub_float = Tensor(DT.float, [1, FLOAT_TILE], Position.UB)

    n_tiles = CeilDiv(total, FLOAT_TILE)
    tiles_per_vec = CeilDiv(n_tiles, GetVecNum())
    tile_begin = Var(tiles_per_vec * GetVecIdx())
    tile_end = Min(tile_begin + tiles_per_vec, n_tiles)

    with auto_sync():
        for tile in range(tile_begin, tile_end):
            offset = Var(tile * FLOAT_TILE)
            ub_carrier[:, :] <<= x_carrier[offset:offset + FLOAT_TILE]
            cast_hif8_to_float_vf(ub_hif8, ub_float)
            y_float[offset:offset + FLOAT_TILE] <<= ub_float

    return y_float


@kernel()
def float_to_hif8_carrier_kernel(x_float: GMTensor, y_carrier: GMTensor, total: Var):
    ub_float = Tensor(DT.float, [1, FLOAT_TILE], Position.UB)
    ub_carrier = Tensor(DT.uint8, [1, FLOAT_TILE], Position.UB)
    ub_hif8 = ub_carrier.reinterpret(DT.hif8, name="ub_hif8_out")

    n_tiles = CeilDiv(total, FLOAT_TILE)
    tiles_per_vec = CeilDiv(n_tiles, GetVecNum())
    tile_begin = Var(tiles_per_vec * GetVecIdx())
    tile_end = Min(tile_begin + tiles_per_vec, n_tiles)

    with auto_sync():
        for tile in range(tile_begin, tile_end):
            offset = Var(tile * FLOAT_TILE)
            ub_float[:, :] <<= x_float[offset:offset + FLOAT_TILE]
            cast_float_to_hif8_vf(ub_float, ub_hif8)
            y_carrier[offset:offset + FLOAT_TILE] <<= ub_carrier

    return y_carrier


@kernel()
def float_to_hif8_hybrid_carrier_kernel(x_float: GMTensor, y_carrier: GMTensor, total: Var):
    ub_float = Tensor(DT.float, [1, FLOAT_TILE], Position.UB)
    ub_carrier = Tensor(DT.uint8, [1, FLOAT_TILE], Position.UB)
    ub_hif8 = ub_carrier.reinterpret(DT.hif8, name="ub_hif8_hybrid_out")

    n_tiles = CeilDiv(total, FLOAT_TILE)
    tiles_per_vec = CeilDiv(n_tiles, GetVecNum())
    tile_begin = Var(tiles_per_vec * GetVecIdx())
    tile_end = Min(tile_begin + tiles_per_vec, n_tiles)

    with auto_sync():
        for tile in range(tile_begin, tile_end):
            offset = Var(tile * FLOAT_TILE)
            ub_float[:, :] <<= x_float[offset:offset + FLOAT_TILE]
            cast_float_to_hif8_hybrid_vf(ub_float, ub_hif8)
            y_carrier[offset:offset + FLOAT_TILE] <<= ub_carrier

    return y_carrier


@kernel()
def hif8_carrier_to_half_kernel(x_carrier: GMTensor, y_half: GMTensor, total: Var):
    ub_carrier = Tensor(DT.uint8, [1, HALF_TILE], Position.UB)
    ub_hif8 = ub_carrier.reinterpret(DT.hif8, name="ub_hif8_half")
    ub_half = Tensor(DT.half, [1, HALF_TILE], Position.UB)

    n_tiles = CeilDiv(total, HALF_TILE)
    tiles_per_vec = CeilDiv(n_tiles, GetVecNum())
    tile_begin = Var(tiles_per_vec * GetVecIdx())
    tile_end = Min(tile_begin + tiles_per_vec, n_tiles)

    with auto_sync():
        for tile in range(tile_begin, tile_end):
            offset = Var(tile * HALF_TILE)
            ub_carrier[:, :] <<= x_carrier[offset:offset + HALF_TILE]
            cast_hif8_to_half_vf(ub_hif8, ub_half)
            y_half[offset:offset + HALF_TILE] <<= ub_half

    return y_half


@kernel()
def half_to_hif8_carrier_kernel(x_half: GMTensor, y_carrier: GMTensor, total: Var):
    ub_half = Tensor(DT.half, [1, HALF_TILE], Position.UB)
    ub_carrier = Tensor(DT.uint8, [1, HALF_TILE], Position.UB)
    ub_hif8 = ub_carrier.reinterpret(DT.hif8, name="ub_hif8_half_out")

    n_tiles = CeilDiv(total, HALF_TILE)
    tiles_per_vec = CeilDiv(n_tiles, GetVecNum())
    tile_begin = Var(tiles_per_vec * GetVecIdx())
    tile_end = Min(tile_begin + tiles_per_vec, n_tiles)

    with auto_sync():
        for tile in range(tile_begin, tile_end):
            offset = Var(tile * HALF_TILE)
            ub_half[:, :] <<= x_half[offset:offset + HALF_TILE]
            cast_half_to_hif8_vf(ub_half, ub_hif8)
            y_carrier[offset:offset + HALF_TILE] <<= ub_carrier

    return y_carrier


@kernel()
def half_to_hif8_hybrid_carrier_kernel(x_half: GMTensor, y_carrier: GMTensor, total: Var):
    ub_half = Tensor(DT.half, [1, HALF_TILE], Position.UB)
    ub_carrier = Tensor(DT.uint8, [1, HALF_TILE], Position.UB)
    ub_hif8 = ub_carrier.reinterpret(DT.hif8, name="ub_hif8_half_hybrid_out")

    n_tiles = CeilDiv(total, HALF_TILE)
    tiles_per_vec = CeilDiv(n_tiles, GetVecNum())
    tile_begin = Var(tiles_per_vec * GetVecIdx())
    tile_end = Min(tile_begin + tiles_per_vec, n_tiles)

    with auto_sync():
        for tile in range(tile_begin, tile_end):
            offset = Var(tile * HALF_TILE)
            ub_half[:, :] <<= x_half[offset:offset + HALF_TILE]
            cast_half_to_hif8_hybrid_vf(ub_half, ub_hif8)
            y_carrier[offset:offset + HALF_TILE] <<= ub_carrier

    return y_carrier


def _build_decode_input() -> torch.Tensor:
    return torch.arange(TOTAL, dtype=torch.uint8)


def _build_encode_input() -> torch.Tensor:
    codes = torch.arange(256, dtype=torch.uint8)
    decoded = hif8_to_fp32(codes)
    finite = torch.isfinite(decoded)
    values = decoded[finite]
    if int(values.numel()) < TOTAL:
        values = torch.cat([values, values[:TOTAL - int(values.numel())]])
    return values[:TOTAL].contiguous()


def _build_half_encode_input() -> torch.Tensor:
    interesting_bits = [
        0x0000, 0x8000, 0x0001, 0x0002, 0x0003, 0x0005, 0x0040,
        0x017D, 0x817D, 0x0340, 0x0350, 0x0360, 0x0373,
        0x8340, 0x8350, 0x8360, 0x8373,
        0x3C00, 0x4000, 0x4400, 0x4800, 0x4C00, 0xC800, 0xCC00,
        0x7900, 0xF900, 0x7BFF, 0xFBFF, 0x7C00, 0xFC00, 0x7E00,
    ]
    bits = list(interesting_bits)
    seed = 17
    while len(bits) < TOTAL:
        bits.append(seed & 0xFFFF)
        seed += 251
    arr = np.asarray(bits[:TOTAL], dtype=np.uint16).view(np.float16).copy()
    return torch.from_numpy(arr)


def _run_decode(use_cannsim: bool, gen_only: bool) -> None:
    x = _build_decode_input()
    y = torch.empty((TOTAL,), dtype=torch.float32)
    actual = OpExec(
        hif8_carrier_to_float_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/hif8_carrier_decode/custom_opp"),
        out_dir=os.path.abspath("tmp/hif8_carrier_decode/cannsim" if use_cannsim else "tmp/hif8_carrier_decode/sim"),
    )(x, y, TOTAL, shape_bindings=SHAPE_BINDINGS)

    if gen_only:
        print("hif8 carrier decode gen_only complete")
        return

    expected = hif8_to_fp32(x)
    torch.testing.assert_close(actual, expected, rtol=1e-4, atol=1e-4, equal_nan=True)
    diff = torch.nan_to_num(torch.abs(actual - expected), nan=0.0)
    print("hif8 carrier decode passed max_abs_diff={:.6e}".format(float(diff.max().item())))


def _run_encode(use_cannsim: bool, gen_only: bool) -> None:
    x = _build_encode_input()
    y = torch.empty((TOTAL,), dtype=torch.uint8)
    actual = OpExec(
        float_to_hif8_carrier_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/hif8_carrier_encode/custom_opp"),
        out_dir=os.path.abspath("tmp/hif8_carrier_encode/cannsim" if use_cannsim else "tmp/hif8_carrier_encode/sim"),
    )(x, y, TOTAL, shape_bindings=SHAPE_BINDINGS)

    if gen_only:
        print("float to hif8 carrier encode gen_only complete")
        return

    expected = fp32_to_hif8(x)
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    print("float to hif8 carrier encode passed mismatches=0")


def _run_encode_hybrid(use_cannsim: bool, gen_only: bool) -> None:
    x = _build_encode_input()
    y = torch.empty((TOTAL,), dtype=torch.uint8)
    actual = OpExec(
        float_to_hif8_hybrid_carrier_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/hif8_carrier_encode_hybrid/custom_opp"),
        out_dir=os.path.abspath("tmp/hif8_carrier_encode_hybrid/cannsim" if use_cannsim else "tmp/hif8_carrier_encode_hybrid/sim"),
    )(x, y, TOTAL, shape_bindings=SHAPE_BINDINGS)

    if gen_only:
        print("float to hif8 carrier hybrid encode gen_only complete")
        return

    expected = fp32_to_hif8(x, round_mode=RoundMode.HYBRID)
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    print("float to hif8 carrier hybrid encode passed mismatches=0")


def _run_half_decode(use_cannsim: bool, gen_only: bool) -> None:
    x = _build_decode_input()
    y = torch.empty((TOTAL,), dtype=torch.float16)
    actual = OpExec(
        hif8_carrier_to_half_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/hif8_carrier_decode_half/custom_opp"),
        out_dir=os.path.abspath("tmp/hif8_carrier_decode_half/cannsim" if use_cannsim else "tmp/hif8_carrier_decode_half/sim"),
    )(x, y, TOTAL, shape_bindings=SHAPE_BINDINGS)

    if gen_only:
        print("hif8 carrier half decode gen_only complete")
        return

    expected = hif8_to_fp32(x).to(torch.float16)
    torch.testing.assert_close(actual, expected, rtol=0, atol=0, equal_nan=True)
    diff = torch.nan_to_num(torch.abs(actual.float() - expected.float()), nan=0.0)
    print("hif8 carrier half decode passed max_abs_diff={:.6e}".format(float(diff.max().item())))


def _run_half_encode(use_cannsim: bool, gen_only: bool) -> None:
    x = _build_half_encode_input()
    y = torch.empty((TOTAL,), dtype=torch.uint8)
    actual = OpExec(
        half_to_hif8_carrier_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/hif8_carrier_encode_half/custom_opp"),
        out_dir=os.path.abspath("tmp/hif8_carrier_encode_half/cannsim" if use_cannsim else "tmp/hif8_carrier_encode_half/sim"),
    )(x, y, TOTAL, shape_bindings=SHAPE_BINDINGS)

    if gen_only:
        print("half to hif8 carrier encode gen_only complete")
        return

    expected = fp16_to_hif8(x)
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    print("half to hif8 carrier encode passed mismatches=0")


def _run_half_encode_hybrid(use_cannsim: bool, gen_only: bool) -> None:
    x = _build_half_encode_input()
    y = torch.empty((TOTAL,), dtype=torch.uint8)
    actual = OpExec(
        half_to_hif8_hybrid_carrier_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/hif8_carrier_encode_half_hybrid/custom_opp"),
        out_dir=os.path.abspath("tmp/hif8_carrier_encode_half_hybrid/cannsim" if use_cannsim else "tmp/hif8_carrier_encode_half_hybrid/sim"),
    )(x, y, TOTAL, shape_bindings=SHAPE_BINDINGS)

    if gen_only:
        print("half to hif8 carrier hybrid encode gen_only complete")
        return

    expected = fp16_to_hif8(x, round_mode=RoundMode.HYBRID)
    mismatches = actual != expected
    if bool(mismatches.any().item()):
        x_bits = x.view(torch.uint16)
        mismatch_idx = torch.nonzero(mismatches, as_tuple=False).flatten()
        shown = mismatch_idx[:16]
        for idx in shown.tolist():
            print(
                "half hybrid mismatch idx={} bits=0x{:04x} value={} actual=0x{:02x} expected=0x{:02x}".format(
                    idx,
                    int(x_bits[idx].item()),
                    float(x[idx].item()),
                    int(actual[idx].item()),
                    int(expected[idx].item()),
                )
            )
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    print("half to hif8 carrier hybrid encode passed mismatches=0")


if __name__ == "__main__":
    use_cannsim = "--cannsim" in sys.argv[1:]
    gen_only = "--gen-only" in sys.argv[1:]
    _run_decode(use_cannsim, gen_only)
    _run_encode(use_cannsim, gen_only)
    _run_encode_hybrid(use_cannsim, gen_only)
    _run_half_decode(use_cannsim, gen_only)
    _run_half_encode(use_cannsim, gen_only)
    _run_half_encode_hybrid(use_cannsim, gen_only)
