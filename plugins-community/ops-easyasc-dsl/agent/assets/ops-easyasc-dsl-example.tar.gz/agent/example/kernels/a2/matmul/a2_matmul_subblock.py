import torch

from easyasc.a2 import *


BLK = 64


@kernel()
def cubefunc(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    z.bind_cv_mutex(0)

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    xub = DBuff(DT.half, [BLK, N], Position.UB)
    outub = DBuff(DT.half, [BLK, N], Position.UB)

    cnt = Var(0)

    m_per_core = CeilDiv(M, GetCubeNum())
    m1 = Var(m_per_core * GetCubeIdx())
    m2 = Min(m1 + m_per_core, M)

    with auto_sync():
        for m in range(m1, m2, BLK):
            l1x[cnt] <<= x[m:m+BLK, :]
            l1y[cnt] <<= y[:, :]

            matmul(l0c[cnt], l1x[cnt], l1y[cnt])
            z.lock()
            z[m:m+BLK, :] <<= l0c[cnt]
            z.ready()
            z.wait()
            xub[cnt] <<= z[m:m+BLK, :]
            z.free()

            if GetSubBlockIdx() == 0:
                outub[cnt] <<= xub[cnt] * 2
                z[m:m+BLK, :] <<= outub[cnt]

    return z


if __name__ == "__main__":
    import os
    import sys

    M = 64 * 20
    N = 64
    K = 128
    torch.manual_seed(42)
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"

    x = torch.randn(M, K).half()
    y = torch.randn(N, K).half()
    z_out = torch.zeros(M, N).half()

    z_ref = (x.float() @ y.float().T) * 2

    exec_kwargs = dict(simulator=True)
    if run:
        exec_kwargs = dict(
            simulator=False,
            debug=True,
            out_dir="./tmp/a2_matmul_subblock",
            cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        )

    z_kernel = OpExec(cubefunc, **exec_kwargs)(
        x, y, z_out, M, N, K,
        shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1]},
    )

    torch.testing.assert_close(z_kernel.float(), z_ref, rtol=3e-3, atol=3e-3)
    print(f"max_abs_diff={torch.abs(z_kernel.float() - z_ref).max().item():.6e}")
