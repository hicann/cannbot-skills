"""A5 int64 reg-op on-board smoke + sim/board alignment (Commit 1A coverage).

Exercises every micro op whose simulator path was moved off fp32 to native
integer math, so each one is validated bit-exactly on the Ascend950 board and
against the (fixed) simulator. Magnitudes are above 2**24 so an fp32 path would
diverge visibly. Two kernels share the same [ROWS, 32] int64 layout:

- elementwise: vmin, vmax (native baseline), neg, abs, adds, muls, vmaxs, vmins,
  axpy, copy;
- reductions:  cgadd, cgmax, cgmin (blocks of c0=4), cpadd (pairs).

Run:
- simulator (default): via a tmp wrapper that imports check_case (see module doc),
  or  python kernels/a5/vec_only/int64_ops_onboard.py
- on Ascend950 board:  python kernels/a5/vec_only/int64_ops_onboard.py --run
"""
import builtins
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403  (also shadows builtin `range` with the DSL range)

ROWS = 64
COLS = 32  # 32 int64 lanes = 256 bytes = one full vector register
C0 = 32 // 8  # int64 group-reduce block size = 4
ADDS_K = 1000000007
MULS_K = 3
MAXS_K = 500000000
MINS_K = -400000000
AXPY_K = 5


_ELT_NAMES = ["vmin", "vmax", "neg", "abs", "adds", "muls", "vmaxs", "vmins", "copy", "axpy"]
_ELT_OUTS = ["o_min", "o_max", "o_neg", "o_abs", "o_adds", "o_muls", "o_maxs", "o_mins", "o_copy", "o_axpy"]


@vf()
def int64_elt_vf(ub_a: Tensor, ub_b: Tensor, ub_min: Tensor, ub_max: Tensor,
                 ub_neg: Tensor, ub_abs: Tensor, ub_adds: Tensor, ub_muls: Tensor,
                 ub_maxs: Tensor, ub_mins: Tensor, ub_copy: Tensor, ub_axpy: Tensor):
    ra = Reg(DT.int64, name="ra")
    rb = Reg(DT.int64, name="rb")
    ra <<= ub_a[0]
    rb <<= ub_b[0]

    r_min = Reg(DT.int64, name="r_min")
    r_max = Reg(DT.int64, name="r_max")
    r_neg = Reg(DT.int64, name="r_neg")
    r_abs = Reg(DT.int64, name="r_abs")
    r_adds = Reg(DT.int64, name="r_adds")
    r_muls = Reg(DT.int64, name="r_muls")
    r_maxs = Reg(DT.int64, name="r_maxs")
    r_mins = Reg(DT.int64, name="r_mins")
    r_copy = Reg(DT.int64, name="r_copy")
    r_axpy = Reg(DT.int64, name="r_axpy")

    vmin(r_min, ra, rb)
    vmax(r_max, ra, rb)
    r_neg <<= ra.neg()
    r_abs <<= ra.abs()
    adds(r_adds, ra, ADDS_K)
    muls(r_muls, ra, MULS_K)
    vmaxs(r_maxs, ra, MAXS_K)
    vmins(r_mins, ra, MINS_K)
    r_copy <<= ra
    r_axpy <<= rb            # axpy accumulates into dst: dst = dst + src * K
    axpy(r_axpy, ra, AXPY_K)

    ub_min[0] <<= r_min
    ub_max[0] <<= r_max
    ub_neg[0] <<= r_neg
    ub_abs[0] <<= r_abs
    ub_adds[0] <<= r_adds
    ub_muls[0] <<= r_muls
    ub_maxs[0] <<= r_maxs
    ub_mins[0] <<= r_mins
    ub_copy[0] <<= r_copy
    ub_axpy[0] <<= r_axpy


@kernel(mode="vec")
def int64_elt_kernel(a: GMTensor, b: GMTensor, o_min: GMTensor, o_max: GMTensor,
                     o_neg: GMTensor, o_abs: GMTensor, o_adds: GMTensor, o_muls: GMTensor,
                     o_maxs: GMTensor, o_mins: GMTensor, o_copy: GMTensor, o_axpy: GMTensor,
                     rows: Var):
    ub_a = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_a")
    ub_b = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_b")
    ubs = [Tensor(DT.int64, [1, COLS], Position.UB, name=f"ub_o{i}") for i in builtins.range(10)]

    rows_per_vec = CeilDiv(rows, GetVecNum())
    row_begin = Var(rows_per_vec * GetVecIdx())
    row_end = Min(row_begin + rows_per_vec, rows)

    outs = [o_min, o_max, o_neg, o_abs, o_adds, o_muls, o_maxs, o_mins, o_copy, o_axpy]
    with auto_sync():
        for r in range(row_begin, row_end, name="erow"):
            ub_a[:, :] <<= a[r:r + 1, :]
            ub_b[:, :] <<= b[r:r + 1, :]
            int64_elt_vf(ub_a, ub_b, *ubs)
            for gm, ub in zip(outs, ubs):
                gm[r:r + 1, :] <<= ub

    return o_min, o_max, o_neg, o_abs, o_adds, o_muls, o_maxs, o_mins, o_copy, o_axpy


# NOTE (board-truth, matches API doc): the *grouped* / pairwise reduces are not
# int64 on Ascend950 -- ReduceDataBlock (cgadd/cgmax/cgmin) tops out at 32-bit ints
# (SupportType uint16/int16/uint32/int32/float/half) and PairReduceElem (cpadd) is
# float/half only. Only the *whole-register* reduces cadd/cmax/cmin (Reduce, doc
# 0411) accept int64/uint64, so those are what we validate here; the DSL group/pair
# stubs should gain an int64/uint64 guard (tracked for 1B).
_RED_NAMES = ["cadd", "cmax", "cmin"]


@vf()
def int64_reduce_vf(ub_a: Tensor, ub_cadd: Tensor, ub_cmax: Tensor, ub_cmin: Tensor):
    ra = Reg(DT.int64, name="ra")
    ra <<= ub_a[0]
    r_cadd = Reg(DT.int64, name="r_cadd")
    r_cmax = Reg(DT.int64, name="r_cmax")
    r_cmin = Reg(DT.int64, name="r_cmin")
    cadd(r_cadd, ra)
    cmax(r_cmax, ra)
    cmin(r_cmin, ra)
    ub_cadd[0] <<= r_cadd
    ub_cmax[0] <<= r_cmax
    ub_cmin[0] <<= r_cmin


@kernel(mode="vec")
def int64_reduce_kernel(a: GMTensor, o_cadd: GMTensor, o_cmax: GMTensor,
                        o_cmin: GMTensor, rows: Var):
    ub_a = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_a")
    ub_cadd = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_cadd")
    ub_cmax = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_cmax")
    ub_cmin = Tensor(DT.int64, [1, COLS], Position.UB, name="ub_cmin")

    rows_per_vec = CeilDiv(rows, GetVecNum())
    row_begin = Var(rows_per_vec * GetVecIdx())
    row_end = Min(row_begin + rows_per_vec, rows)

    with auto_sync():
        for r in range(row_begin, row_end, name="rrow"):
            ub_a[:, :] <<= a[r:r + 1, :]
            int64_reduce_vf(ub_a, ub_cadd, ub_cmax, ub_cmin)
            o_cadd[r:r + 1, :] <<= ub_cadd
            o_cmax[r:r + 1, :] <<= ub_cmax
            o_cmin[r:r + 1, :] <<= ub_cmin

    return o_cadd, o_cmax, o_cmin


def _make_inputs():
    idx = torch.arange(ROWS * COLS, dtype=torch.int64).reshape(ROWS, COLS)
    a = (idx - (ROWS * COLS) // 2) * (2 ** 33 + 5)          # large ±, > 2**24
    b = ((idx * 7) % 101 - 50) * (2 ** 37 + 3)
    return a.contiguous(), b.contiguous()


def _pad_reduce(reduced):
    out = torch.zeros((ROWS, COLS), dtype=torch.int64)
    out[:, :reduced.shape[1]] = reduced
    return out


def _elt_golden(a, b):
    return {
        "vmin": torch.minimum(a, b),
        "vmax": torch.maximum(a, b),
        "neg": -a,
        "abs": torch.abs(a),
        "adds": a + ADDS_K,
        "muls": a * MULS_K,
        "vmaxs": torch.clamp(a, min=MAXS_K),
        "vmins": torch.clamp(a, max=MINS_K),
        "copy": a.clone(),
        "axpy": b + a * AXPY_K,
    }


def _reduce_golden(a):
    # cadd/cmax/cmin reduce the whole 32-lane register; the reduced value lands in
    # lane 0. (On hardware cmax/cmin ALSO write the arg-index into lane 1 -- a
    # pre-existing, dtype-independent behavior the simulator does not model -- so we
    # compare only lane 0, which is where the int64 reduce value lives.)
    return {
        "cadd": a.sum(dim=1),
        "cmax": a.amax(dim=1),
        "cmin": a.amin(dim=1),
    }


def _check(mode, name, got, want, fails):
    if torch.equal(got, want):
        print(f"[{mode}] {name:6s} OK  (bit-exact int64)")
    else:
        bad = torch.nonzero(got != want, as_tuple=False)
        first = bad[0].tolist()
        print(f"[{mode}] {name:6s} MISMATCH count={bad.shape[0]} first={first} "
              f"got={int(got[tuple(first)])} want={int(want[tuple(first)])}")
        fails.append(name)


def _opexec(kernel, mode, run_on_board, tag):
    if run_on_board:
        cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"])
    else:
        cfg = dict(simulator=True)
    return OpExec(kernel, out_dir=os.path.abspath(f"tmp/int64_ops/{mode}_{tag}"),
                  custom_op_path=os.path.abspath("tmp/int64_ops/custom_opp"), **cfg)


def check_case(run_on_board):
    a, b = _make_inputs()
    mode = "board" if run_on_board else "sim"
    fails = []

    elt_out = [torch.zeros((ROWS, COLS), dtype=torch.int64) for _ in builtins.range(len(_ELT_NAMES))]
    res = _opexec(int64_elt_kernel, mode, run_on_board, "elt")(a, b, *elt_out, ROWS)
    eg = _elt_golden(a, b)
    for name, got in zip(_ELT_NAMES, res):
        _check(mode, name, got, eg[name], fails)

    red_out = [torch.zeros((ROWS, COLS), dtype=torch.int64) for _ in builtins.range(len(_RED_NAMES))]
    res = _opexec(int64_reduce_kernel, mode, run_on_board, "red")(a, *red_out, ROWS)
    rg = _reduce_golden(a)
    for name, got in zip(_RED_NAMES, res):
        _check(mode, name, got[:, 0], rg[name], fails)  # lane 0 = reduced value

    if fails:
        raise AssertionError(f"int64_ops {mode} mismatch: {fails}")
    print(f"[{mode}] ALL {len(_ELT_NAMES) + len(_RED_NAMES)} int64 ops bit-exact")


if __name__ == "__main__":
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1"
    check_case(run_on_board=run)
