"""What a radix level, a compaction pass and the sort ladder cost per element.

The shipped A5 TopK funnels every element through the C310 sort ISA, which is
why it sits near 30x ``t_hw``.  A radix select reads each element once per
level instead of once per ladder pass, so the whole design question is the
ratio of three per-element costs, measured on the same UB-resident array:

* ``hist``    -- one 8-bit radix level: load, monotone key, bucket test,
                 ``pack`` down to bytes, two ``histograms``.
* ``compact`` -- the pass that writes the survivors out: load, key, compare,
                 ``unsqueeze``, two scatters, a counting reduce.
* ``sort``    -- ``sort32`` + three ``mergesort4`` over 2048-element chunks,
                 then one ``mergesort_2seq`` into a resident k-run: exactly the
                 inner loop of the shipped strip-mined path.

Each kernel repeats its pass ``reps`` times over the same buffer, so the host
subtracts two runs at different ``reps`` and the launch overhead cancels.

Run:  python kernels/a5/vec_only/radix_timing_probe.py --run
"""
import builtins
import os
import sys
import time

import torch

from easyasc.a5 import *


N = 8192           # keys resident in UB
GROUP = 64
MAXK = 512
TILE = 2048

LEVELS = ((24, 0x00000000), (16, 0xFF000000), (8, 0xFFFF0000), (0, 0xFFFFFF00))


def _hist_level_body(keys: Tensor, count: Var, shift, hi_mask):
    """One radix level over ``count`` keys; the running prefix is a constant."""
    fkey = Reg(DT.float, name="ht_fkey")
    ukey = Reg(DT.uint32, name="ht_ukey")
    sbit = Reg(DT.int, name="ht_sbit")
    flip = Reg(DT.uint32, name="ht_flip")
    hi = Reg(DT.uint32, name="ht_hi")
    byte32 = Reg(DT.uint32, name="ht_byte32")
    halfword = Reg(DT.uint16, name="ht_halfword")
    byte = Reg(DT.uint8, name="ht_byte")
    zero32 = Reg(DT.uint32, name="ht_zero32")
    prefix = Reg(DT.uint32, name="ht_prefix")
    signbit = Reg(DT.uint32, name="ht_signbit")
    bytemask = Reg(DT.uint32, name="ht_bytemask")
    himask = Reg(DT.uint32, name="ht_himask")
    h0 = Reg(DT.uint16, name="ht_h0")
    h1 = Reg(DT.uint16, name="ht_h1")
    live8 = MaskReg(DT.uint8, init_mode=MaskType.NONE, name="ht_live8")
    keep = MaskReg(DT.uint32, init_mode=MaskType.NONE, name="ht_keep")

    dup(zero32, 0)
    dup(signbit, 0x80000000)
    dup(bytemask, 0xFF)
    dup(prefix, 0)
    dup(himask, hi_mask)
    dup(h0, 0)
    dup(h1, 0)
    groups = CeilDiv(count, GROUP)
    for htg in range(groups, name="ht_grp"):
        off = Var(htg * GROUP, name="ht_off")
        lanes = Var(GROUP, dtype=DT.uint32, name="ht_lanes")
        update_mask(live8, lanes)
        ub_to_reg(fkey, keys[off])
        ukey <<= fkey.reinterpret(DT.uint32, name="ht_fbits")
        sbit <<= fkey.reinterpret(DT.int, name="ht_ibits")
        shiftrs(sbit, sbit, 31)
        flip <<= sbit.reinterpret(DT.uint32, name="ht_sbitu")
        vor(flip, flip, signbit)
        vxor(ukey, ukey, flip)
        shiftrs(byte32, ukey, shift)
        vand(byte32, byte32, bytemask)
        vand(hi, ukey, himask)
        compare(keep, hi, prefix, CompareMode.EQ)
        select(byte32, byte32, zero32, mask=keep)
        pack(halfword, byte32, HighLowPart.LOWEST)
        pack(byte, halfword, HighLowPart.LOWEST)
        histograms(h0, byte, HistBin.BIN0, HistMode.ACCUMULATE, mask=live8)
        histograms(h1, byte, HistBin.BIN1, HistMode.ACCUMULATE, mask=live8)
    # keep the histogram alive so the level cannot be folded away
    reg_to_ub(keys[0], h0.reinterpret(DT.float, name="ht_h0f"))
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


def _load_only_body(keys: Tensor, count: Var):
    """The same loop with nothing but the load: isolates the issue cost."""
    fkey = Reg(DT.float, name="lo_fkey")
    acc = Reg(DT.float, name="lo_acc")
    dup(acc, 0.0)
    groups = CeilDiv(count, GROUP)
    for log in range(groups, name="lo_grp"):
        off = Var(log * GROUP, name="lo_off")
        ub_to_reg(fkey, keys[off])
        vmax(acc, acc, fkey)
    reg_to_ub(keys[0], acc)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


def _compact_body(keys: Tensor, cand: Tensor, cidx: Tensor, count: Var,
                  k: Var):
    """The survivor pass: key, compare against a constant, two scatters."""
    fkey = Reg(DT.float, name="cp_fkey")
    ukey = Reg(DT.uint32, name="cp_ukey")
    sbit = Reg(DT.int, name="cp_sbit")
    flip = Reg(DT.uint32, name="cp_flip")
    signbit = Reg(DT.uint32, name="cp_signbit")
    zero32 = Reg(DT.uint32, name="cp_zero32")
    prefix = Reg(DT.uint32, name="cp_prefix")
    lane = Reg(DT.int, name="cp_lane")
    idx = Reg(DT.int, name="cp_idx")
    rank = Reg(DT.uint32, name="cp_rank")
    pos = Reg(DT.uint32, name="cp_pos")
    base = Reg(DT.uint32, name="cp_base")
    cnt = Reg(DT.uint32, name="cp_cnt")
    red32 = Reg(DT.uint32, name="cp_red32")
    one32 = Reg(DT.uint32, name="cp_one32")
    bidx32 = Reg(DT.uint32, name="cp_bidx32")
    gt = MaskReg(DT.uint32, init_mode=MaskType.NONE, name="cp_gt")

    dup(zero32, 0)
    dup(one32, 1)
    dup(bidx32, 0)
    dup(base, 0)
    dup(signbit, 0x80000000)
    # a threshold no key can reach keeps the scatter cold but still issued
    dup(prefix, 0xFFFFFFFF)
    groups = CeilDiv(count, GROUP)
    for cpg in range(groups, name="cp_grp"):
        off = Var(cpg * GROUP, name="cp_off")
        ub_to_reg(fkey, keys[off])
        ukey <<= fkey.reinterpret(DT.uint32, name="cp_fbits")
        sbit <<= fkey.reinterpret(DT.int, name="cp_ibits")
        shiftrs(sbit, sbit, 31)
        flip <<= sbit.reinterpret(DT.uint32, name="cp_sbitu")
        vor(flip, flip, signbit)
        vxor(ukey, ukey, flip)
        arange(lane, 0)
        adds(idx, lane, off)
        compare(gt, ukey, prefix, CompareMode.GT)
        unsqueeze(rank, gt)
        add(pos, rank, base)
        reg_to_ub_scatter(cand, fkey, pos, mask=gt)
        reg_to_ub_scatter(cidx, idx, pos, mask=gt)
        select(cnt, one32, zero32, mask=gt)
        cadd(red32, cnt)
        gather(cnt, red32, bidx32)
        add(base, base, cnt)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def hist_vf(keys: Tensor, count: Var):
    _hist_level_body(keys, count, 24, 0x00000000)


@vf()
def load_vf(keys: Tensor, count: Var):
    _load_only_body(keys, count)


@vf()
def compact_vf(keys: Tensor, cand: Tensor, cidx: Tensor, count: Var, k: Var):
    _compact_body(keys, cand, cidx, count, k)


@func()
def _sort_ladder(keys: Tensor, idxs: Tensor, pair_a: Tensor, pair_b: Tensor):
    sort32(pair_a, keys, idxs, repeat=64)
    mergesort4(pair_b, pair_a, 32, 16)
    mergesort4(pair_a, pair_b, 128, 4)
    mergesort4(pair_b, pair_a, 512, 1)


@kernel(mode="vec")
def hist_kernel(keys: GMTensor, out: GMTensor, count: Var, reps: Var):
    keys_ub = Tensor(DT.float, [1, N], Position.UB, name="tm_keys")
    with auto_sync():
        keys_ub[:, :] <<= keys[0:1, :]
        for rep in range(reps, name="tm_hrep"):
            hist_vf(keys_ub, count)
        out[0:1, 0:64] <<= keys_ub[0:1, 0:64]
    return out


@kernel(mode="vec")
def load_kernel(keys: GMTensor, out: GMTensor, count: Var, reps: Var):
    keys_ub = Tensor(DT.float, [1, N], Position.UB, name="tm_keys")
    with auto_sync():
        keys_ub[:, :] <<= keys[0:1, :]
        for rep in range(reps, name="tm_lrep"):
            load_vf(keys_ub, count)
        out[0:1, 0:64] <<= keys_ub[0:1, 0:64]
    return out


@kernel(mode="vec")
def compact_kernel(keys: GMTensor, out: GMTensor, count: Var, k: Var,
                   reps: Var):
    keys_ub = Tensor(DT.float, [1, N], Position.UB, name="tm_keys")
    cand = Tensor(DT.float, [1, MAXK + 128], Position.UB, name="tm_cand")
    cidx = Tensor(DT.int, [1, MAXK + 128], Position.UB, name="tm_cidx")
    with auto_sync():
        keys_ub[:, :] <<= keys[0:1, :]
        for rep in range(reps, name="tm_crep"):
            compact_vf(keys_ub, cand, cidx, count, k)
        out[0:1, 0:64] <<= cand[0:1, 0:64]
    return out


@kernel(mode="vec")
def sort_kernel(keys: GMTensor, out: GMTensor, count: Var, k: Var, reps: Var):
    keys_ub = Tensor(DT.float, [1, N], Position.UB, name="tm_keys")
    idxs_i = Tensor(DT.int, [1, TILE], Position.UB, name="tm_idxs")
    idxs = reinterpret(idxs_i, DT.uint32)
    pair_a = Tensor(DT.float, [1, 2 * TILE], Position.UB, name="tm_pa")
    pair_b = Tensor(DT.float, [1, 2 * TILE + 128], Position.UB, name="tm_pb")
    running = Tensor(DT.float, [1, 2 * MAXK + 128], Position.UB, name="tm_run")
    merged = Tensor(DT.float, [1, 2 * (MAXK + TILE)], Position.UB,
                    name="tm_mrg")
    with auto_sync():
        keys_ub[:, :] <<= keys[0:1, :]
        tiles = CeilDiv(count, TILE)
        for rep in range(reps, name="tm_srep"):
            for tile in range(tiles, name="tm_stile"):
                off = Var(tile * TILE, name="tm_soff")
                _sort_ladder(keys_ub[0:1, off:off + TILE], idxs, pair_a,
                             pair_b)
                mergesort_2seq(merged, running, pair_b, k, k)
                ub_to_ub(running[0:1, 0:2 * k], merged[0:1, 0:2 * k])
        out[0:1, 0:64] <<= running[0:1, 0:64]
    return out


def _time(fn, args, out_dir, cfg, warm=1, runs=2):
    best = None
    for _ in builtins.range(warm + runs):
        start = time.perf_counter()
        OpExec(fn, out_dir=out_dir,
               custom_op_path=os.path.abspath("tmp/radixtime/opp"),
               **cfg)(*args)
        elapsed = time.perf_counter() - start
        best = elapsed if best is None else min(best, elapsed)
    return best


def main(run):
    if not run:
        print("timing probe is board-only; pass --run")
        return 0
    cfg = dict(simulator=False, debug=False,
               cann_path=os.environ["ASCEND_HOME_PATH"])
    generator = torch.Generator().manual_seed(7)
    keys = (torch.randn(1, N, generator=generator) * 100.0).contiguous()
    out = torch.zeros(1, 64, dtype=torch.float32)
    k = 100
    # An OpExec call costs ~30 s of build/launch overhead but reproduces to
    # under a millisecond, so the repeat counts only have to make the kernel
    # itself worth a few tenths of a second.
    lo, hi = 200000, 400000

    plans = [
        ("load", load_kernel, lambda r: (keys, out, N, r), "tmp/radixtime/l"),
        ("hist", hist_kernel, lambda r: (keys, out, N, r), "tmp/radixtime/h"),
        ("compact", compact_kernel, lambda r: (keys, out, N, k, r),
         "tmp/radixtime/c"),
        ("sort", sort_kernel, lambda r: (keys, out, N, k, r),
         "tmp/radixtime/s"),
    ]
    # the sort ladder is ~50x the cost of a level pass, so it needs far fewer
    # repeats to dominate the launch
    reps = {"load": (lo, hi), "hist": (lo, hi), "compact": (lo, hi),
            "sort": (20000, 40000)}
    for name, fn, mk, out_dir in plans:
        r0, r1 = reps[name]
        try:
            t0 = _time(fn, mk(r0), os.path.abspath(out_dir), cfg)
            t1 = _time(fn, mk(r1), os.path.abspath(out_dir), cfg)
        except Exception as error:  # noqa: BLE001
            print("[time] {:8s} EXC {}: {}".format(
                name, type(error).__name__, str(error)[:300]))
            continue
        per_pass = (t1 - t0) / (r1 - r0)
        print("[time] {:8s} t({})={:.4f}s t({})={:.4f}s  "
              "pass={:9.2f} us  per element={:6.3f} ns".format(
                  name, r0, t0, r1, t1, per_pass * 1e6,
                  per_pass * 1e9 / N))
    return 0


if __name__ == "__main__":
    sys.exit(main("--run" in sys.argv[1:]
                  or os.environ.get("EASYASC_RUN_ON_A5") == "1"))
