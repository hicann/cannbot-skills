"""A5 MXFP4 matmul smoke with uint8 public carriers.

Contract:
- Public A/B inputs are `DT.uint8` carriers because torch has no native FP4 dtype.
- A is FP4 E2M1, B is FP4 E1M2, both packed two payloads per uint8 along K.
- Public scale inputs are e8m0 bytes packed as GM `[num_blocks, 32]` MX scale blocks.
- The kernel reinterprets the L1 carrier tensors as FP4 and consumes them with
  `matmul_mx`, producing fp32 output.
"""

import os
import sys
from typing import Tuple

os.environ.setdefault("TORCH_DEVICE_BACKEND_AUTOLOAD", "0")
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../..")))

import torch

from easyasc.a5 import (
    DT, FP4_E1M2_MAX_VALUE, FP4_E2M1_MAX_VALUE, GMTensor, OpExec,
    Position, Tensor, Var, auto_sync, e8m0_to_fp32, fp32_to_fp4_e1m2,
    fp32_to_fp4_e2m1, fp4_e1m2_to_fp32, fp4_e2m1_to_fp32,
    gm_to_l1_mx_scale, kernel, matmul_mx,
)
from easyasc.simulator import SimulatorConfig


M_VALUE = 16
N_VALUE = 16
K_VALUE = 64
GROUP_VALUE = 32
K_CARRIER_VALUE = (K_VALUE + 1) // 2
SCALE_GROUPS_VALUE = (K_VALUE + GROUP_VALUE - 1) // GROUP_VALUE
SCALE_COLS_VALUE = 2 * ((K_VALUE + 63) // 64)


@kernel()
def mxfp4_carrier_matmul_kernel(
    a_carrier: GMTensor,
    b_carrier: GMTensor,
    scale_a_gm: GMTensor,
    scale_b_gm: GMTensor,
    out: GMTensor,
    dummy: Var,
):
    l1a_u8 = Tensor(DT.uint8, [M_VALUE, K_CARRIER_VALUE], Position.L1)
    l1b_u8 = Tensor(DT.uint8, [N_VALUE, K_CARRIER_VALUE], Position.L1)
    l1a = l1a_u8.reinterpret(DT.fp4_e2m1, name="l1a_fp4_e2m1")
    l1b = l1b_u8.reinterpret(DT.fp4_e1m2, name="l1b_fp4_e1m2")
    scale_a = Tensor(DT.uint8, [M_VALUE, SCALE_COLS_VALUE], Position.L1)
    scale_b = Tensor(DT.uint8, [N_VALUE, SCALE_COLS_VALUE], Position.L1)
    l0c = Tensor(DT.float, [M_VALUE, N_VALUE], Position.L0C)

    with auto_sync():
        l1a_u8[:, :] <<= a_carrier[:, :]
        l1b_u8[:, :] <<= b_carrier[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(l0c, l1a, l1b, scale_a, scale_b, m=M_VALUE, n=N_VALUE, k=K_VALUE, is_init=True)
        out[:, :] <<= l0c

    return out


mxfp4_carrier_matmul_kernel._simulator_config = SimulatorConfig(
    core_count=1,
    process_start_method="fork",
    execution_timeout_s=120.0,
)


def _pack_mx_scale(values: torch.Tensor, k: int) -> torch.Tensor:
    rows = int(values.shape[0])
    groups = (int(k) + GROUP_VALUE - 1) // GROUP_VALUE
    row_blocks = (rows + 15) // 16
    col_blocks = (int(k) + 63) // 64
    values = values.to(torch.uint8)
    if tuple(values.shape) != (rows, groups):
        raise ValueError("MX scale values must have shape [rows, ceil(k / 32)]")

    padded = torch.full((row_blocks * 16, col_blocks * 2), 127, dtype=torch.uint8)
    padded[:rows, :groups] = values
    blocks = []
    for row_block in range(row_blocks):
        for col_block in range(col_blocks):
            block = padded[row_block * 16 : (row_block + 1) * 16, col_block * 2 : col_block * 2 + 2]
            blocks.append(block.contiguous().reshape(32))
    return torch.cat(blocks).contiguous().reshape(-1, 32)


def _expand_mx_scale(values: torch.Tensor, k: int) -> torch.Tensor:
    group_index = torch.arange(int(k), dtype=torch.long) // GROUP_VALUE
    return e8m0_to_fp32(values).index_select(1, group_index)


def _build_inputs() -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    a_base = torch.arange(M_VALUE * K_VALUE, dtype=torch.float32).reshape(M_VALUE, K_VALUE)
    b_base = torch.arange(N_VALUE * K_VALUE, dtype=torch.float32).reshape(N_VALUE, K_VALUE)
    a_fp32 = ((a_base * 5.0 + 3.0) % 25.0 - 12.0) / 12.0 * FP4_E2M1_MAX_VALUE
    b_fp32 = ((b_base * 7.0 + 1.0) % 17.0 - 8.0) / 8.0 * FP4_E1M2_MAX_VALUE

    a_carrier = fp32_to_fp4_e2m1(a_fp32, pack_axis=-1)
    b_carrier = fp32_to_fp4_e1m2(b_fp32, pack_axis=-1)

    rows_a = torch.arange(M_VALUE, dtype=torch.int16).reshape(M_VALUE, 1)
    rows_b = torch.arange(N_VALUE, dtype=torch.int16).reshape(N_VALUE, 1)
    groups = torch.arange(SCALE_GROUPS_VALUE, dtype=torch.int16).reshape(1, SCALE_GROUPS_VALUE)
    scale_a_values = (126 + ((rows_a + groups) % 3)).to(torch.uint8)
    scale_b_values = (126 + ((2 * rows_b + groups + 1) % 3)).to(torch.uint8)

    out = torch.empty((M_VALUE, N_VALUE), dtype=torch.float32)
    return a_carrier, b_carrier, _pack_mx_scale(scale_a_values, K_VALUE), _pack_mx_scale(scale_b_values, K_VALUE), out


def _mxfp4_ref(
    a_carrier: torch.Tensor,
    b_carrier: torch.Tensor,
    scale_a_gm: torch.Tensor,
    scale_b_gm: torch.Tensor,
) -> torch.Tensor:
    a_q = fp4_e2m1_to_fp32(a_carrier, logical_shape=(M_VALUE, K_VALUE), pack_axis=-1)
    b_q = fp4_e1m2_to_fp32(b_carrier, logical_shape=(N_VALUE, K_VALUE), pack_axis=-1)
    scale_a_values = scale_a_gm.reshape(M_VALUE, SCALE_COLS_VALUE)
    scale_b_values = scale_b_gm.reshape(N_VALUE, SCALE_COLS_VALUE)
    a_scaled = a_q * _expand_mx_scale(scale_a_values[:, :SCALE_GROUPS_VALUE], K_VALUE)
    b_scaled = b_q * _expand_mx_scale(scale_b_values[:, :SCALE_GROUPS_VALUE], K_VALUE)
    return a_scaled @ b_scaled.t()


def _run(use_cannsim: bool, gen_only: bool) -> None:
    a_carrier, b_carrier, scale_a_gm, scale_b_gm, out = _build_inputs()
    actual = OpExec(
        mxfp4_carrier_matmul_kernel,
        simulator=not use_cannsim,
        cannsim=use_cannsim and not gen_only,
        gen_only=gen_only,
        cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
        custom_op_path=os.path.abspath("tmp/mxfp4_carrier_matmul/custom_opp"),
        out_dir=os.path.abspath("tmp/mxfp4_carrier_matmul/cannsim" if use_cannsim else "tmp/mxfp4_carrier_matmul/sim"),
    )(a_carrier, b_carrier, scale_a_gm, scale_b_gm, out, 0)

    if gen_only:
        print("mxfp4 carrier matmul gen_only complete")
        return

    expected = _mxfp4_ref(a_carrier, b_carrier, scale_a_gm, scale_b_gm)
    torch.testing.assert_close(actual, expected, rtol=2e-3, atol=2e-3)
    print("mxfp4 carrier matmul passed max_abs_diff={:.6e}".format(float(torch.abs(actual - expected).max().item())))


if __name__ == "__main__":
    use_cannsim = "--cannsim" in sys.argv[1:]
    gen_only = "--gen-only" in sys.argv[1:]
    _run(use_cannsim, gen_only)
