from builtins import range as py_range

from easyasc.a2 import *

TILE_M = 128
TILE_N = 128
TILE_K = 128
HALF_M = TILE_M // 2
HALF_N = TILE_N // 2
GROUP_N = 4
GROUP_STAGE_SLOTS = 4
GROUP_LOOKAHEAD = 2
ROW_CHUNK = 32
NEG_LARGE = -1.0e30


@kernel()
def flash_attn_full_kernel(
    q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor,
    S1: Var, S2: Var, D: Var, BH: Var, scale: Var,
):
    score_ws = split_workspace(
        DT.float, [GetCubeNum(), GROUP_STAGE_SLOTS, TILE_M, GROUP_N * TILE_N], name="score_ws"
    )
    p_ws = split_workspace(
        DT.half, [GetCubeNum(), GROUP_STAGE_SLOTS, TILE_M, GROUP_N * TILE_N], name="p_ws"
    )
    pv_ws = split_workspace(DT.float, [GetCubeNum(), GROUP_STAGE_SLOTS, TILE_M, TILE_K], name="pv_ws")

    l1q = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1k = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l1p = DBuff(DT.half, [TILE_M, TILE_N], Position.L1)
    l1v = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)

    ub_score_group = QBuff(DT.float, [ROW_CHUNK, TILE_N], Position.UB)
    ub_p_group = QBuff(DT.half, [ROW_CHUNK, TILE_N], Position.UB)
    ub_pv = Tensor(DT.float, [HALF_M, TILE_K], Position.UB)
    ub_tmp = Tensor(DT.float, [ROW_CHUNK, HALF_N], Position.UB)
    ub_max_s = Tensor(DT.float, [1, ROW_CHUNK], Position.UB)
    ub_group_max_s = Tensor(DT.float, [1, ROW_CHUNK], Position.UB)
    ub_old_max_s = Tensor(DT.float, [1, ROW_CHUNK], Position.UB)
    ub_rmax_s = Tensor(DT.float, [1, HALF_M], Position.UB)
    ub_sum_s = Tensor(DT.float, [1, ROW_CHUNK], Position.UB)
    ub_group_sum_s = Tensor(DT.float, [1, ROW_CHUNK], Position.UB)
    ub_rsum_s = Tensor(DT.float, [1, HALF_M], Position.UB)
    ub_zero_s = Tensor(DT.float, [1, HALF_M], Position.UB)
    ub_zero_chunk_s = Tensor(DT.float, [1, ROW_CHUNK], Position.UB)
    ub_max = Tensor(DT.float, [ROW_CHUNK, 8], Position.UB)
    ub_rowsum = Tensor(DT.float, [HALF_M, 8], Position.UB)
    ub_expdiff = Tensor(DT.float, [HALF_M, 8], Position.UB)
    ub_group_expdiff_chunk_s = Tensor(DT.float, [1, ROW_CHUNK], Position.UB)
    accum_ub = Tensor(DT.float, [HALF_M, TILE_K], Position.UB)
    expdiff_buf = QBuff(DT.float, [1, HALF_M], Position.UB)
    q_load_valid = SEvent(Pipe.MTE2, Pipe.MTE1, name="q_load_valid")
    score_slot_free = SEvent(Pipe.V, Pipe.MTE2, preset=True, name="score_slot_free")
    p_ub_slot_free = SEvent(Pipe.MTE3, Pipe.V, preset=True, name="p_ub_slot_free")
    accum_store_ready = SEvent(Pipe.V, Pipe.MTE3, name="accum_store_ready")
    accum_store_valid = SEvent(Pipe.MTE3, Pipe.V, preset=True, name="accum_store_valid")

    qk_mutex = CvMutex(0, GROUP_STAGE_SLOTS, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.MTE2)
    p_mutex = VcMutex(1, GROUP_STAGE_SLOTS, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE2)
    pv_mutex = CvMutex(2, GROUP_STAGE_SLOTS, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.MTE2)

    l1k_cnt = Var(0)
    l1pv_cnt = Var(0)
    l0c_cnt = Var(0)
    stage1_cnt = Var(0)
    stage2_cnt = Var(0)
    q_cur = Var(0)

    cube_idx = GetCubeIdx()
    sb = GetSubBlockIdx()
    sb_row = Var(sb * HALF_M)

    tiles_m = CeilDiv(S1, TILE_M)
    tiles_n = CeilDiv(S2, TILE_N)
    active_groups = CeilDiv(tiles_n, GROUP_N)
    core_count = GetCubeNum()
    core_step = Var(1, DT.int)
    core_step <<= core_count
    total_m = Var(BH * tiles_m)

    for gmt in range(cube_idx, total_m, core_step):
        bh = Var(gmt // tiles_m)
        lmt = Var(gmt % tiles_m)
        q_row = Var(bh * S1 + lmt * TILE_M)
        kv_base = Var(bh * S2)

        accum_store_valid.wait()
        dup(ub_rmax_s, NEG_LARGE)
        dup(ub_rsum_s, 0.0)
        dup(ub_zero_s, 0.0)
        dup(ub_zero_chunk_s, 0.0, count=ROW_CHUNK)
        dup(accum_ub, 0.0)

        with auto_sync():
            l1q[q_cur] <<= q[q_row:q_row + TILE_M, 0:D]
            q_load_valid.set()

        for group_id in range(0, active_groups + GROUP_LOOKAHEAD):
            if group_id < active_groups:
                group_start = Var(group_id * GROUP_N)
                group_len = Min(GROUP_N, tiles_n - group_start)
                stage1_slot = var_mod(stage1_cnt, GROUP_STAGE_SLOTS)

                qk_mutex.lock()
                for gi in range(0, GROUP_N):
                    if gi < group_len:
                        with auto_sync():
                            ni = Var(group_start + gi)
                            n_off = Var(ni * TILE_N)
                            kv_row = Var(kv_base + n_off)

                            l1k[l1k_cnt] <<= k[kv_row:kv_row + TILE_N, 0:D]
                            if group_id == 0:
                                if gi == 0:
                                    q_load_valid.wait()
                            matmul(l0c[l0c_cnt], l1q[q_cur], l1k[l1k_cnt], is_init=True)

                            group_col = gi * TILE_N
                            score_ws[cube_idx, stage1_slot, 0:TILE_M, group_col:group_col + TILE_N] <<= l0c[l0c_cnt]
                            l1k_cnt += 1
                            l0c_cnt += 1
                qk_mutex.ready()
                qk_mutex.wait()
                p_mutex.lock()

                for rb in py_range(0, HALF_M, ROW_CHUNK):
                    score_slot_free.wait()
                    p_ub_slot_free.wait()
                    chunk_row = Var(sb_row + rb)

                    dup(ub_group_max_s, NEG_LARGE, count=ROW_CHUNK)
                    for gi in range(0, GROUP_N):
                        if gi < group_len:
                            with auto_sync():
                                ub_score = ub_score_group[gi]
                                group_col = gi * TILE_N
                                ub_score <<= score_ws[
                                    cube_idx, stage1_slot,
                                    chunk_row:chunk_row + ROW_CHUNK,
                                    group_col:group_col + TILE_N,
                                ]

                                muls(ub_score, ub_score, scale)
                                vmax(ub_tmp, ub_score[0:ROW_CHUNK, 0:HALF_N], ub_score[0:ROW_CHUNK, HALF_N:TILE_N])
                                cmax(ub_max_s, ub_tmp)
                                vmax(ub_group_max_s, ub_group_max_s, ub_max_s, count=ROW_CHUNK)

                    add(ub_old_max_s, ub_rmax_s[0:1, rb:rb + ROW_CHUNK], ub_zero_chunk_s, count=ROW_CHUNK)
                    vmax(
                        ub_rmax_s[0:1, rb:rb + ROW_CHUNK],
                        ub_rmax_s[0:1, rb:rb + ROW_CHUNK],
                        ub_group_max_s,
                        count=ROW_CHUNK,
                    )
                    sub(ub_group_expdiff_chunk_s, ub_old_max_s, ub_rmax_s[0:1, rb:rb + ROW_CHUNK], count=ROW_CHUNK)
                    exp(ub_group_expdiff_chunk_s, ub_group_expdiff_chunk_s, count=ROW_CHUNK)
                    add(
                        expdiff_buf[stage1_slot][0:1, rb:rb + ROW_CHUNK],
                        ub_group_expdiff_chunk_s,
                        ub_zero_chunk_s,
                        count=ROW_CHUNK,
                    )
                    dup(ub_group_sum_s, 0.0, count=ROW_CHUNK)

                    brcb(
                        ub_max, ub_rmax_s[0:1, rb:rb + ROW_CHUNK],
                        repeat=ROW_CHUNK // 8, dst_blk_stride=1, dst_rep_stride=8,
                    )
                    for gi in range(0, GROUP_N):
                        if gi < group_len:
                            with auto_sync():
                                ub_p = ub_p_group[gi]
                                ub_score = ub_score_group[gi]
                                group_col = gi * TILE_N

                                sub(ub_score[0:ROW_CHUNK, 0:HALF_N], ub_score[0:ROW_CHUNK, 0:HALF_N], ub_max)
                                sub(ub_score[0:ROW_CHUNK, HALF_N:TILE_N], ub_score[0:ROW_CHUNK, HALF_N:TILE_N], ub_max)

                                exp(ub_score, ub_score)
                                add(ub_tmp, ub_score[0:ROW_CHUNK, 0:HALF_N], ub_score[0:ROW_CHUNK, HALF_N:TILE_N])
                                cadd(ub_sum_s, ub_tmp)
                                add(ub_group_sum_s, ub_group_sum_s, ub_sum_s, count=ROW_CHUNK)

                                cast(ub_p, ub_score)
                                p_ws[
                                    cube_idx, stage1_slot,
                                    chunk_row:chunk_row + ROW_CHUNK,
                                    group_col:group_col + TILE_N,
                                ] <<= ub_p

                    mul(
                        ub_rsum_s[0:1, rb:rb + ROW_CHUNK],
                        ub_rsum_s[0:1, rb:rb + ROW_CHUNK],
                        ub_group_expdiff_chunk_s,
                        count=ROW_CHUNK,
                    )
                    add(
                        ub_rsum_s[0:1, rb:rb + ROW_CHUNK],
                        ub_rsum_s[0:1, rb:rb + ROW_CHUNK],
                        ub_group_sum_s,
                        count=ROW_CHUNK,
                    )
                    score_slot_free.set()
                    p_ub_slot_free.set()

                qk_mutex.free()
                p_mutex.ready()
                stage1_cnt += 1

            if group_id >= GROUP_LOOKAHEAD:
                stage2_slot = var_mod(stage2_cnt, GROUP_STAGE_SLOTS)

                with cube_scope():
                    with auto_sync():
                        p_mutex.wait()
                        group_start2 = Var((group_id - GROUP_LOOKAHEAD) * GROUP_N)
                        group_len2 = Min(GROUP_N, tiles_n - group_start2)
                        for gi in range(0, GROUP_N):
                            if gi < group_len2:
                                ni = Var(group_start2 + gi)
                                n_off = Var(ni * TILE_N)
                                v_row = Var(kv_base + n_off)
                                group_col = gi * TILE_N

                                l1p[l1pv_cnt] <<= p_ws[
                                    cube_idx, stage2_slot,
                                    0:TILE_M,
                                    group_col:group_col + TILE_N,
                                ]
                                l1v[l1pv_cnt] <<= v[v_row:v_row + TILE_N, 0:D]
                                if gi == 0:
                                    matmul(l0c[l0c_cnt], l1p[l1pv_cnt], l1v[l1pv_cnt].T, is_init=True)
                                else:
                                    matmul(l0c[l0c_cnt], l1p[l1pv_cnt], l1v[l1pv_cnt].T, is_init=False)
                                l1pv_cnt += 1
                        p_mutex.free()

                        pv_mutex.lock()
                        pv_ws[cube_idx, stage2_slot, 0:TILE_M, 0:D] <<= l0c[l0c_cnt]
                        pv_mutex.ready()
                        l0c_cnt += 1

                with auto_sync():
                    pv_mutex.wait()
                    ub_pv <<= pv_ws[cube_idx, stage2_slot, sb_row:sb_row + HALF_M, 0:D]
                    pv_mutex.free()

                    brcb(ub_expdiff, expdiff_buf[stage2_slot], repeat=HALF_M // 8, dst_blk_stride=1, dst_rep_stride=8)
                    mul(accum_ub[0:HALF_M, 0:HALF_N], accum_ub[0:HALF_M, 0:HALF_N], ub_expdiff)
                    mul(accum_ub[0:HALF_M, HALF_N:TILE_K], accum_ub[0:HALF_M, HALF_N:TILE_K], ub_expdiff)
                    add(accum_ub, accum_ub, ub_pv)
                    stage2_cnt += 1

        brcb(ub_rowsum, ub_rsum_s, repeat=HALF_M // 8, dst_blk_stride=1, dst_rep_stride=8)
        div(accum_ub[0:HALF_M, 0:HALF_N], accum_ub[0:HALF_M, 0:HALF_N], ub_rowsum)
        div(accum_ub[0:HALF_M, HALF_N:TILE_K], accum_ub[0:HALF_M, HALF_N:TILE_K], ub_rowsum)

        out_row = Var(q_row + sb_row)
        accum_store_ready.set()
        accum_store_ready.wait()
        out[out_row:out_row + HALF_M, 0:D] <<= accum_ub
        accum_store_valid.set()
        q_cur += 1

    return out


def _ref_flash_attn_full(q, k, v):
    import builtins
    import torch

    B, H, S1, D = q.shape
    S2 = k.shape[2]
    scale = 1.0 / (D ** 0.5)

    q_f = q.float()
    k_f = k.float()
    v_f = v.float()

    row_max = torch.zeros(B, H, S1, 1)
    row_sum = torch.zeros(B, H, S1, 1)
    out = torch.zeros(B, H, S1, D, dtype=torch.float32)

    for j in builtins.range(0, S2, TILE_N):
        k_blk = k_f[:, :, j:j + TILE_N, :]
        score_j = torch.einsum("bhsd,bhtd->bhst", q_f, k_blk) * scale
        max_j = score_j.max(dim=-1, keepdim=True).values

        if j == 0:
            row_max = max_j
            expdiff = torch.ones_like(row_max)
        else:
            curr_max = torch.maximum(row_max, max_j)
            expdiff = torch.exp(row_max - curr_max)
            row_max = curr_max

        p_j = torch.exp(score_j - row_max)
        sum_j = p_j.sum(dim=-1, keepdim=True)
        if j == 0:
            row_sum = sum_j
        else:
            row_sum = row_sum * expdiff + sum_j

        v_blk = v_f[:, :, j:j + TILE_N, :]
        pv_j = torch.einsum("bhst,bhtd->bhsd", p_j.half().float(), v_blk)
        if j == 0:
            out = pv_j
        else:
            out = out * expdiff + pv_j

    return out / row_sum


def _standard_flash_attn_ref(q, k, v):
    import math
    import torch

    score = torch.einsum("bhsd,bhtd->bhst", q.float(), k.float()) * (1.0 / math.sqrt(q.shape[-1]))
    prob = torch.softmax(score, dim=-1)
    return torch.einsum("bhst,bhtd->bhsd", prob, v.float())


if __name__ == "__main__":
    import math
    import os
    import sys
    import torch
    from easyasc.simulator import SimulatorConfig

    torch.manual_seed(42)
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"
    full_sim_matrix = os.environ.get("EASYASC_FULL_SIM_MATRIX") == "1"

    def run_case(B, H, S1, S2, D):
        BH = B * H

        q = torch.randn(B, H, S1, D, dtype=torch.float16)
        k = torch.randn(B, H, S2, D, dtype=torch.float16)
        v = torch.randn(B, H, S2, D, dtype=torch.float16)
        out_ref = _ref_flash_attn_full(q, k, v)
        softmax_ref = _standard_flash_attn_ref(q, k, v)

        q_flat = q.reshape(BH * S1, D).contiguous()
        k_flat = k.reshape(BH * S2, D).contiguous()
        v_flat = v.reshape(BH * S2, D).contiguous()
        out_flat = torch.zeros(BH * S1, D, dtype=torch.float32)

        if run:
            out_kernel = OpExec(
                flash_attn_full_kernel,
                simulator=False,
                debug=True,
                out_dir="./tmp/flash_attn_full",
                cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
            )(q_flat, k_flat, v_flat, out_flat, S1, S2, D, BH, 1.0 / math.sqrt(D))
        else:
            saved_sim_config = getattr(flash_attn_full_kernel, "_simulator_config", None)
            flash_attn_full_kernel._simulator_config = SimulatorConfig(
                core_count=20,
                execution_timeout_s=180.0,
            )
            try:
                out_kernel = OpExec(flash_attn_full_kernel, simulator=True)(
                    q_flat, k_flat, v_flat, out_flat, S1, S2, D, BH, 1.0 / math.sqrt(D)
                )
            finally:
                if saved_sim_config is None:
                    try:
                        delattr(flash_attn_full_kernel, "_simulator_config")
                    except AttributeError:
                        pass
                else:
                    flash_attn_full_kernel._simulator_config = saved_sim_config
        out_kernel = out_kernel.reshape(B, H, S1, D)

        tolerances = [(1e-2, 1e-2), (2e-2, 2e-2)]
        used_rtol, used_atol = tolerances[-1]
        for rtol, atol in tolerances:
            try:
                torch.testing.assert_close(out_kernel, out_ref, rtol=rtol, atol=atol)
                used_rtol, used_atol = rtol, atol
                break
            except AssertionError:
                used_rtol, used_atol = tolerances[-1]

        torch.testing.assert_close(out_kernel, out_ref, rtol=used_rtol, atol=used_atol)
        print(
            f"shape=({B},{H},{S1},{S2},{D}): "
            f"tol=({used_rtol:.0e},{used_atol:.0e}) "
            f"kernel_max_abs_diff={torch.abs(out_kernel - out_ref).max().item():.6e} "
            f"inline_vs_softmax_max_abs_diff={torch.abs(out_ref - softmax_ref).max().item():.6e}",
            flush=True,
        )

    smoke_shapes = (
        (1, 3, 256, 256, 128),
        (1, 1, 256, 512, 128),
    )
    full_shapes = smoke_shapes + (
        (1, 3, 256, 512, 128),
        (1, 3, 2048, 4096, 128),
    )
    shapes = smoke_shapes if run else (full_shapes if full_sim_matrix else smoke_shapes)
    for shape in shapes:
        run_case(*shape)
