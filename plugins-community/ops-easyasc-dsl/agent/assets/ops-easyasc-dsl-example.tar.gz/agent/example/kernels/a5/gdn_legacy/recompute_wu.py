from easyasc.a5 import *


C = 64
D = 128
ROWS_PER_BATCH = C
HALF_ROWS = C // 2
FLOAT_REGS_PER_ROW = D // 64
SCALAR_COLS = 8


@vf()
def mul_decay_row_vf(k_beta_row: Tensor, decay_scalar_ub: Tensor, k_pre_row: Tensor):
    scalar_reg = Reg(DT.float)
    row_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    scalar_reg <<= decay_scalar_ub[0:1, 0:1].single()
    row_regs <<= k_beta_row[0:1, 0:D]
    row_regs <<= row_regs * scalar_reg
    k_pre_row[0:1, 0:D] <<= row_regs


@vf()
def mul_decay_rows_vf(k_beta_block: Tensor, decay_block_ub: Tensor, k_pre_block: Tensor, n_rows: Var):
    scalar_reg = Reg(DT.float)
    row_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    for i in range(n_rows):
        scalar_reg <<= decay_block_ub[i:i + 1, 0:1].single()
        row_regs <<= k_beta_block[i * D]
        row_regs <<= row_regs * scalar_reg
        k_pre_block[i * D] <<= row_regs


@vf()
def pack_k_pre_to_nz_row(src_nd: Tensor, dst_nz: Tensor, n_rows: Var):
    row_reg = Reg(DT.half)
    for i in range(n_rows):
        row_reg <<= src_nd[i * D]
        reg_to_ub(dst_nz[i * 16], row_reg, n_rows)


@kernel()
def recompute_wu_kernel(
    attn: GMTensor, k_beta: GMTensor, decay_exp: GMTensor, v: GMTensor, k_cumdecay: GMTensor, kv: GMTensor,
    bhn: Var,
):
    # Vec producer ends on MTE3 (L1 <<= UB routes to ub_to_l1_nd2nz), cube consumer ends on FIX (matmul).
    vcmutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)

    l1_attn = DBuff(DT.half, [C, C], Position.L1)
    l1_kpre = DBuff(DT.half, [C, D], Position.L1)
    l1_v = DBuff(DT.half, [C, D], Position.L1)
    l0c_kcumdecay = DBuff(DT.float, [C, D], Position.L0C)
    l0c_kv = DBuff(DT.float, [C, D], Position.L0C)

    k_beta_ub = DBuff(DT.half, [HALF_ROWS, D], Position.UB)
    k_pre_ub = DBuff(DT.half, [HALF_ROWS, D], Position.UB)
    k_pre_nz_ub = DBuff(DT.half, [HALF_ROWS, D], Position.UB)
    decay_block_ub = DBuff(DT.float, [HALF_ROWS, SCALAR_COLS], Position.UB)

    vcnt = Var(0)
    ccnt = Var(0)
    bhn_per_core = CeilDiv(bhn, GetCubeNum())
    bhn_begin = Var(bhn_per_core * GetCubeIdx())
    bhn_end = Min(bhn_begin + bhn_per_core, bhn)

    with auto_sync():
        for bhn_idx in range(bhn_begin, bhn_end):
            row0 = Var(bhn_idx * C)

            vcmutex.lock()
            row_begin = Var(GetSubBlockIdx() * HALF_ROWS)
            if row_begin < C:
                row_end = Min(row_begin + HALF_ROWS, C)
                rows_this = Var(row_end - row_begin)
                k_beta_ub[vcnt][0:HALF_ROWS, 0:D] <<= k_beta[row0 + row_begin:row0 + row_end, 0:D]
                decay_block_ub[vcnt][0:rows_this, 0:1] <<= decay_exp[row0 + row_begin:row0 + row_end, 0:1]
                mul_decay_rows_vf(k_beta_ub[vcnt], decay_block_ub[vcnt], k_pre_ub[vcnt], rows_this)
                pack_k_pre_to_nz_row(k_pre_ub[vcnt], k_pre_nz_ub[vcnt], rows_this)
                l1_kpre[ccnt][row_begin:row_end, 0:D] <<= k_pre_nz_ub[vcnt][0:rows_this, 0:D].nz()
            vcnt += 1
            vcmutex.ready()

            vcmutex.wait()
            # Cluster same-pipe stages when possible:
            # 1) MTE2 loads, 2) cube matmul compute, 3) FIX writeback.
            l1_attn[ccnt] <<= attn[row0:row0 + C, 0:C]
            l1_v[ccnt] <<= v[row0:row0 + C, 0:D]

            matmul(l0c_kcumdecay[ccnt], l1_attn[ccnt], l1_kpre[ccnt].T, splitn=128)
            matmul(l0c_kv[ccnt], l1_attn[ccnt], l1_v[ccnt].T, splitn=128)

            k_cumdecay[row0:row0 + C, 0:D] <<= l0c_kcumdecay[ccnt]
            kv[row0:row0 + C, 0:D] <<= l0c_kv[ccnt]
            vcmutex.free()

            ccnt += 1

    return k_cumdecay, kv
if __name__ == "__main__":
    import torch

    torch.manual_seed(0)

    B = 1
    H = 4
    N = 2

    attn = torch.randn(B, H, N, C, C, dtype=torch.float16)
    k_beta = torch.randn(B, H, N, C, D, dtype=torch.float16)
    decay_exp = torch.randn(B, H, N, C, 1, dtype=torch.float16)
    v = torch.randn(B, H, N, C, D, dtype=torch.float16)

    bhn = int(B * H * N)
    attn_f = attn.reshape(bhn * C, C).contiguous()
    k_beta_f = k_beta.reshape(bhn * C, D).contiguous()
    decay_exp_f = decay_exp.reshape(bhn * C, 1).contiguous().float()
    v_f = v.reshape(bhn * C, D).contiguous()
    k_cumdecay_f = torch.empty((bhn * C, D), dtype=torch.float32, device=attn.device)
    kv_f = torch.empty((bhn * C, D), dtype=torch.float32, device=attn.device)

    # `k_pre` is staged through half UB/L1 before the cube consumer.
    k_pre = (k_beta.float() * decay_exp).half()
    k_cumdecay_ref = attn.float() @ k_pre.float()
    kv_ref = attn.float() @ v.float()

    k_cumdecay_kernel, kv_kernel = OpExec(
        recompute_wu_kernel, out_dir="test_cust_op", simulator=True
    )(attn_f, k_beta_f, decay_exp_f, v_f, k_cumdecay_f, kv_f, bhn)
    k_cumdecay_kernel = k_cumdecay_kernel.reshape(B, H, N, C, D)
    kv_kernel = kv_kernel.reshape(B, H, N, C, D)

    torch.testing.assert_close(k_cumdecay_kernel, k_cumdecay_ref, rtol=3e-3, atol=3e-3)
    torch.testing.assert_close(kv_kernel, kv_ref, rtol=3e-3, atol=3e-3)
    print(f"k_cumdecay_max_abs_diff={torch.abs(k_cumdecay_kernel - k_cumdecay_ref).max().item():.6e}")
    print(f"kv_max_abs_diff={torch.abs(kv_kernel - kv_ref).max().item():.6e}")
