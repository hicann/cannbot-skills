"""fp16-softmax single-side probes (cube-only / vec-only / vec-no-store), V2 & V4, nd2nz (a) + NZ (b).

Standalone follow-up to pfa_fd_hif8_v6_cubeprobe.py's fp32 single-side probes, for measuring the
fp16 (V2/V4) softmax path's per-side cost on board. Mirrors the fp32 probe skeleton (single-core flat split,
no FD merge, GM->UB proxy loads feeding the VFs; values are garbage -> profiling-only, read AVG makespan +
op_summary pipe ratios, NOT O-vs-ref).

Probes (env PV_CPROBE):
  cubeonly_hv2 / hv4      AIC-only: K/V/Q-load, QK-mmad, fp16 dual-SINGLE QK-fix (half ub_score; scale=SCALE
                          for V2 requant+downcast / 1.0 for V4 downcast-only), PV-mmad, PV-fix. l1p constant.
                          Does NOT split a/b (no vec P-store).
  --- a: current fp16 P-store = reg_to_ub_downsample (in the VF) + ub_to_l1_nd2nz ---
  veconly_hv2 / hv4       AIV-only: init_softmax_half + fp16 softmax (noscale=V2 / scale=V4) + downsample P +
                          nd2nz P-store + accum_pv_fp16ow + final_div_fp16rsum.
  vecnostore_hv2 / hv4    veconly minus the nd2nz UB->L1 P-store.
  --- b: fp16-NZ P-store = 2-key odd/even gather deinterleave + strided reg_to_ub(NZ) + bulk ub_to_l1_nz ---
  veconly_hv2_nz / hv4_nz same but the softmax VF emits NZ ub_p via the 2-key gather pack (softmax_half_*_nz_vf).
  vecnostore_hv2_nz/hv4_nz veconly_nz minus the bulk NZ UB->L1 P-store.

So: veconly - vecnostore isolates the UB->L1 cost (nd2nz vs bulk-NZ); vecnostore_a vs vecnostore_b isolates
the reg->UB pack cost (downsample vs 2-key gather deinterleave). No ln16 (matches V2/V4 as-is, profiling-only).
"""
import builtins
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5pr") == "a5":
    from easyasc.a5 import *
else:
    from easyasc.a5pr import *
from easyasc.simulator.config import SimulatorConfig

from pfa_fd_hif8_probe_common import (
    _CacheBuf,
    init_softmax_half_vf, softmax_half_scale_vf, softmax_half_noscale_vf,
    accum_pv_fp16ow_vf, accum_pv_first_vf, init_accum_vf, final_div_fp16rsum_vf,
    _qk_bridge_dual_single,
    TILE_M, ROWS_PER_SB, QLANES, TILE_N, D_HEAD, KROW, CACHE,
    UNROLL, RB_MAX_H, RB_EXP_H, NEG_LARGE_H, SOFTMAX_SCALE,
    MAX_CORE_COUNT, fp32_to_hif8, hif8_to_fp32,
)

_pyrange = builtins.range
NZ_C0 = 32               # hif8 C0 (32-byte fractal inner dim), same as nz2
NZ_M = TILE_N + 1        # 129: NZ fractal row stride (M_src)


# ============================ fp16-NZ softmax VFs (b): 2-key odd/even gather deinterleave -> NZ ============================
# Same 2-key-packed half online softmax as the shared probe VFs, but the P-store is swapped from
# reg_to_ub_downsample (dense ND, paired with nd2nz) to the NZ-direct pack: cast half->hif8 (stride-2 sparse,
# key A in even lanes 0..126, key B in 128..254) -> 2 gathers split the two keys AND compact each to dense
# -> 2 strided reg_to_ub(NZ_M) into the NZ ub_p (paired with bulk ub_to_l1_nz). idxA=[0,2,..,126],
# idxB=[128,130,..,254]. Key rows are adjacent (2g, 2g+1). No ln16.
@vf()
def softmax_half_scale_nz_vf(ub_h: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.half, UNROLL); acc = RegList(DT.half, UNROLL); preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="ph_hif8")
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dpA = Reg(DT.hif8); dpB = Reg(DT.hif8)
    gA = Reg(DT.int8); arange(gA, 0); shiftls(gA, gA, 1); idxA = gA.reinterpret(DT.uint8)   # [0,2,..,126]
    gB = Reg(DT.int8); arange(gB, 0); shiftls(gB, gB, 1)
    hi = Reg(DT.int8); hi <<= -128; vxor(gB, gB, hi); idxB = gB.reinterpret(DT.uint8)        # [128,130,..,254]
    neg = Reg(DT.half); block_max = Reg(DT.half); block_sum = Reg(DT.half); t = Reg(DT.half); swap = Reg(DT.half)
    v_pmax = Reg(DT.half); v_nmax = Reg(DT.half); v_oldw = Reg(DT.half)
    v_psum = Reg(DT.half); v_nsum = Reg(DT.half)
    idx16 = Reg(DT.int16); arange(idx16, 0)
    swp64 = Reg(DT.int16); swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)
    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX_H, name="mxh"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u) * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    muls(block_max, block_max, SOFTMAX_SCALE)
    v_pmax <<= ub_rmax[0:1, 0:TILE_N]
    v_nmax <<= block_max.vmax(v_pmax)
    sub(v_oldw, v_pmax, v_nmax); exp(v_oldw, v_oldw)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP_H, name="exh"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u) * TILE_N]
            muls(sreg[u], sreg[u], SOFTMAX_SCALE)
            sub(preg[u], sreg[u], v_nmax)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            gather(dpA, p_h[u], idxA)                                     # key 2g  (even lanes)
            reg_to_ub(ub_p[(2 * (rb * UNROLL + u)) * NZ_C0], dpA, NZ_M, mask=qmask)
            gather(dpB, p_h[u], idxB)                                     # key 2g+1 (lanes 128..254)
            reg_to_ub(ub_p[(2 * (rb * UNROLL + u) + 1) * NZ_C0], dpB, NZ_M, mask=qmask)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:TILE_N]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= v_nmax
    ub_rsum[0:1, 0:TILE_N] <<= v_nsum
    ub_old_weight[0:1, 0:TILE_N] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_half_noscale_nz_vf(ub_h: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor, ub_old_weight: Tensor):
    sreg = RegList(DT.half, UNROLL); acc = RegList(DT.half, UNROLL); preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="ph_hif8")
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    dpA = Reg(DT.hif8); dpB = Reg(DT.hif8)
    gA = Reg(DT.int8); arange(gA, 0); shiftls(gA, gA, 1); idxA = gA.reinterpret(DT.uint8)
    gB = Reg(DT.int8); arange(gB, 0); shiftls(gB, gB, 1)
    hi = Reg(DT.int8); hi <<= -128; vxor(gB, gB, hi); idxB = gB.reinterpret(DT.uint8)
    neg = Reg(DT.half); block_max = Reg(DT.half); block_sum = Reg(DT.half); t = Reg(DT.half); swap = Reg(DT.half)
    v_pmax = Reg(DT.half); v_nmax = Reg(DT.half); v_oldw = Reg(DT.half)
    v_psum = Reg(DT.half); v_nsum = Reg(DT.half)
    idx16 = Reg(DT.int16); arange(idx16, 0)
    swp64 = Reg(DT.int16); swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)
    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX_H, name="mxh"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u) * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1]); t <<= acc[2].vmax(acc[3]); block_max <<= block_max.vmax(t)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    v_pmax <<= ub_rmax[0:1, 0:TILE_N]
    v_nmax <<= block_max.vmax(v_pmax)
    sub(v_oldw, v_pmax, v_nmax); exp(v_oldw, v_oldw)
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_EXP_H, name="exh"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u) * TILE_N]
            sub(preg[u], sreg[u], v_nmax)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            gather(dpA, p_h[u], idxA)
            reg_to_ub(ub_p[(2 * (rb * UNROLL + u)) * NZ_C0], dpA, NZ_M, mask=qmask)
            gather(dpB, p_h[u], idxB)
            reg_to_ub(ub_p[(2 * (rb * UNROLL + u) + 1) * NZ_C0], dpB, NZ_M, mask=qmask)
    block_sum <<= acc[0] + acc[1]; t <<= acc[2] + acc[3]; block_sum <<= block_sum + t
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:TILE_N]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= v_nmax
    ub_rsum[0:1, 0:TILE_N] <<= v_nsum
    ub_old_weight[0:1, 0:TILE_N] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


# ============================ cube-only (fp16 dual-SINGLE half bridge) ============================
@func()
def _cubeonly_h_body(q, k, v, out, B, MQ, N, D, l0c_scale):
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1p[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            qm = Var(mt % 2)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            kv_base = Var(batch * N)
            m0 = Var(local_mt * TILE_M)
            valid_m = Min(TILE_M, MQ - m0)
            n0 = Var(kt * TILE_N)
            valid_n = Min(TILE_N, N - n0)

            need_q = Var(0, DT.int)
            if kt == 0:
                need_q <<= 1
            if step == 0:
                need_q <<= 1
            if need_q > 0:
                l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]

            l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            l1v[step][0:valid_n, 0:D] <<= v_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
            matmul(l0c_qk[step], l1k[step], l1q[qm],
                   m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
            _qk_bridge_dual_single(ub_score[step], l0c_qk[step], l0c_scale)
            matmul(l0c_pv[step][0:TILE_M, 0:D_HEAD], l1p[step].T, l1v[step].T,
                   m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
            l0c_to_ub(ub_pv[step], l0c_pv[step][0:TILE_M, 0:D_HEAD],
                      M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
    return out


# ============================ vec-only / vec-no-store, a = nd2nz P-store ============================
@func()
def _veconly_h_body(q, k, v, out, B, MQ, N, D, softmax_h_fn):
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    ub_score = DBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_rmax = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_rsum = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_old_weight = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_half_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_h_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            ub_to_l1_nd2nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                           m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=TILE_N, n_src=ROWS_PER_SB, N_src=KROW)

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_fp16ow_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_fp16rsum_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


@func()
def _vecnostore_h_body(q, k, v, out, B, MQ, N, D, softmax_h_fn):
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    ub_score = DBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [TILE_N, KROW], Position.UB)
    ub_rmax = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_rsum = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_old_weight = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_half_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_h_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_fp16ow_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_fp16rsum_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


# ============================ vec-only / vec-no-store, b = NZ P-store (2-key gather deinterleave) ============================
@func()
def _veconly_h_nz_body(q, k, v, out, B, MQ, N, D, softmax_h_nz_fn):
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    ub_score = DBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [NZ_M, 4 * ROWS_PER_SB], Position.UB)   # [129, 256] NZ, M_src=NZ_M
    ub_rmax = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_rsum = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_old_weight = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_half_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_h_nz_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            ub_to_l1_nz(l1p[step][0:TILE_N, row_begin:row_begin + ROWS_PER_SB], ub_p,
                        m_dst=TILE_N, n_dst=ROWS_PER_SB, m_src=NZ_M, n_src=ROWS_PER_SB)

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_fp16ow_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_fp16rsum_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


@func()
def _vecnostore_h_nz_body(q, k, v, out, B, MQ, N, D, softmax_h_nz_fn):
    v_u8 = v.reinterpret(DT.uint8, name="v_u8")

    ub_score = DBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [NZ_M, 4 * ROWS_PER_SB], Position.UB)
    ub_rmax = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_rsum = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_old_weight = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_tasks = Var(B * tiles_m_per_b * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    with auto_sync():
        for step in range(0, my_tasks):
            t = Var(flat_start + step)
            mt = Var(t // k_tiles)
            kt = Var(t % k_tiles)
            sm = Var(mt % CACHE)
            batch = Var(mt // tiles_m_per_b)
            local_mt = Var(mt % tiles_m_per_b)
            q_base = Var(batch * MQ)
            m0 = Var(local_mt * TILE_M)
            kv_base = Var(batch * N)
            n0 = Var(kt * TILE_N)

            ub_score[step].reinterpret(DT.uint8)[0:TILE_N, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + TILE_N, 0:D_HEAD]
            ub_pv[step].reinterpret(DT.uint8)[0:ROWS_PER_SB, 0:D_HEAD] <<= v_u8[kv_base + n0:kv_base + n0 + ROWS_PER_SB, 0:D_HEAD]

            if kt == 0:
                init_softmax_half_vf(ub_rmax[sm], ub_rsum[sm])
            softmax_h_nz_fn(ub_score[step], ub_rmax[sm], ub_rsum[sm], ub_p, ub_old_weight[step])

            if kt == 0:
                init_accum_vf(ub_accum)
                accum_pv_first_vf(ub_accum, ub_pv[step])
            else:
                accum_pv_fp16ow_vf(ub_accum, ub_pv[step], ub_old_weight[step])

            if kt == k_tiles - 1:
                final_div_fp16rsum_vf(ub_accum, ub_rsum[sm], ub_out)
                out[q_base + m0 + row_begin:q_base + m0 + row_begin + ROWS_PER_SB, 0:D] <<= ub_out[0:ROWS_PER_SB, 0:D]
    return out


# ============================ kernel wrappers ============================
@kernel()
def cprobe_cubeonly_hv2_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _cubeonly_h_body(q, k, v, out, B, MQ, N, D, SOFTMAX_SCALE)


@kernel()
def cprobe_cubeonly_hv4_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _cubeonly_h_body(q, k, v, out, B, MQ, N, D, 1.0)


@kernel()
def cprobe_veconly_hv2_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_h_body(q, k, v, out, B, MQ, N, D, softmax_half_noscale_vf)


@kernel()
def cprobe_veconly_hv4_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_h_body(q, k, v, out, B, MQ, N, D, softmax_half_scale_vf)


@kernel()
def cprobe_vecnostore_hv2_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_h_body(q, k, v, out, B, MQ, N, D, softmax_half_noscale_vf)


@kernel()
def cprobe_vecnostore_hv4_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_h_body(q, k, v, out, B, MQ, N, D, softmax_half_scale_vf)


@kernel()
def cprobe_veconly_hv2_nz_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_h_nz_body(q, k, v, out, B, MQ, N, D, softmax_half_noscale_nz_vf)


@kernel()
def cprobe_veconly_hv4_nz_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _veconly_h_nz_body(q, k, v, out, B, MQ, N, D, softmax_half_scale_nz_vf)


@kernel()
def cprobe_vecnostore_hv2_nz_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_h_nz_body(q, k, v, out, B, MQ, N, D, softmax_half_noscale_nz_vf)


@kernel()
def cprobe_vecnostore_hv4_nz_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    return _vecnostore_h_nz_body(q, k, v, out, B, MQ, N, D, softmax_half_scale_nz_vf)


_PROBES = {
    "cubeonly_hv2": cprobe_cubeonly_hv2_kernel, "cubeonly_hv4": cprobe_cubeonly_hv4_kernel,
    "veconly_hv2": cprobe_veconly_hv2_kernel, "veconly_hv4": cprobe_veconly_hv4_kernel,
    "vecnostore_hv2": cprobe_vecnostore_hv2_kernel, "vecnostore_hv4": cprobe_vecnostore_hv4_kernel,
    "veconly_hv2_nz": cprobe_veconly_hv2_nz_kernel, "veconly_hv4_nz": cprobe_veconly_hv4_nz_kernel,
    "vecnostore_hv2_nz": cprobe_vecnostore_hv2_nz_kernel, "vecnostore_hv4_nz": cprobe_vecnostore_hv4_nz_kernel,
}


def main():
    probe = os.environ.get("PV_CPROBE", "veconly_hv4")
    kern = _PROBES[probe]
    torch.manual_seed(0)
    B = int(os.environ.get("PV_B", "1"))
    HQ = int(os.environ.get("PV_HQ", "8"))
    SQ = int(os.environ.get("PV_SQ", "257"))
    SKV = int(os.environ.get("PV_SKV", "256"))
    MQ = HQ * SQ
    q_fp32 = torch.randn((B * MQ, D_HEAD), dtype=torch.float32)
    k_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    v_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    q = fp32_to_hif8(q_fp32); k = fp32_to_hif8(k_fp32); v = fp32_to_hif8(v_fp32)
    out = torch.zeros((B * MQ, D_HEAD), dtype=torch.bfloat16)

    tiles_m_per_b = (MQ + TILE_M - 1) // TILE_M
    k_tiles = (SKV + TILE_N - 1) // TILE_N
    total_blocks = B * tiles_m_per_b

    mode = os.environ.get("PV_MODE", "sim")
    sim_cores = int(os.environ.get("PV_SIM_CORES", "4"))
    launch_cores = sim_cores if mode == "sim" else MAX_CORE_COUNT
    profile = os.environ.get("PV_PROFILE", "0") == "1"

    kern._simulator_config = SimulatorConfig(core_count=sim_cores, execution_timeout_s=3600.0)
    d = os.environ.get("PV_OUT_DIR") or "./tmp/pfa_fd_fp16probe_{}_{}".format(probe, mode)
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, out, B, MQ, SKV, D_HEAD)
    sb = {0: [1 if B == 1 else None, 3], 1: [2 if B == 1 else None, 3],
          2: [2 if B == 1 else None, 3], 3: [1 if B == 1 else None, 3]}

    print("FP16PROBE[{}]: B={} HQ={} SQ={} SKV={} blocks={} k_tiles={} cores={}".format(
        probe, B, HQ, SQ, SKV, total_blocks, k_tiles, launch_cores))
    if mode == "sim":
        outs = OpExec(kern, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, cannsim=True)(*args, shape_bindings=sb)
    elif mode == "hw":
        outs = OpExec(kern, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")

    O = torch.as_tensor(outs).float()
    print("|O| max={:.3f}  [profiling-only (output not meaningful)]".format(O.abs().max().item()))


if __name__ == "__main__":
    main()
