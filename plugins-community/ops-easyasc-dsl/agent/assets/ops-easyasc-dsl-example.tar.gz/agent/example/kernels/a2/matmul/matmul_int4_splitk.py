"""A2 signed-int4 matmul with int32 output and L0C split-K accumulation.

Contract:
    x : int32 [M, ceil(K / 8)]  packs A[M, K], 8 signed int4 values per int32
    y : int32 [N, ceil(K / 8)]  packs B[N, K], 8 signed int4 values per int32
    z : int32 [M, N]            z = A.int32() @ B.int32().t()

Packing is low-nibble first inside each int32 carrier. Logical int4 values use
two's-complement signed range [-8, 7]. M, N, and K may all have tails.
"""

from easyasc.a2 import *


TILE_M = 64
TILE_N = 64
SPLIT_K = 128
SPLIT_K_CARRIER = SPLIT_K // 8
TAIL_SAFE_K = 64
TAIL_SAFE_K_CARRIER = TAIL_SAFE_K // 8

SHAPE_BINDINGS = {
    0: [0, 3],  # x[M, ceil(K / 8)]
    1: [1, 3],  # y[N, ceil(K / 8)]
    2: [0, 1],  # z[M, N]
}


@kernel()
def matmul_int4_splitk_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var, KC: Var):
    l1x = DBuff(DT.int, [TILE_M, SPLIT_K_CARRIER], Position.L1)
    l1y = DBuff(DT.int, [TILE_N, SPLIT_K_CARRIER], Position.L1)
    l1x_tail = DBuff(DT.int, [TILE_M, TAIL_SAFE_K_CARRIER], Position.L1)
    l1y_tail = DBuff(DT.int, [TILE_N, TAIL_SAFE_K_CARRIER], Position.L1)
    l0c = DBuff(DT.int, [TILE_M, TILE_N], Position.L0C)

    l1_cnt = Var(0)
    l0c_cnt = Var(0)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                for k0 in range(0, K, SPLIT_K):
                    valid_k = Min(SPLIT_K, K - k0)
                    k0_carrier = Var(k0 // 8)
                    valid_k_carrier = Min(SPLIT_K_CARRIER, KC - k0_carrier)
                    valid_k_tail_carrier = Min(TAIL_SAFE_K_CARRIER, KC - k0_carrier)

                    with If(valid_k <= TAIL_SAFE_K):
                        # 910B3 miscomputes the last valid M row when an int4 tail chunk
                        # uses the wide 16-carrier L1 shape. Route short tail chunks through
                        # an 8-carrier tail buffer instead; direct HW probes show this matches
                        # simulator/math for k=9/33/64 while the 16-carrier path does not.
                        l1x_tail[l1_cnt] <<= x[m0:m0 + valid_m, k0_carrier:k0_carrier + valid_k_tail_carrier]
                        l1y_tail[l1_cnt] <<= y[n0:n0 + valid_n, k0_carrier:k0_carrier + valid_k_tail_carrier]
                        matmul(
                            l0c[l0c_cnt],
                            l1x_tail[l1_cnt].reinterpret(DT.int4),
                            l1y_tail[l1_cnt].reinterpret(DT.int4),
                            k=valid_k,
                            is_init=(k0 == 0),
                        )
                    with Else():
                        l1x[l1_cnt] <<= x[m0:m0 + valid_m, k0_carrier:k0_carrier + valid_k_carrier]
                        l1y[l1_cnt] <<= y[n0:n0 + valid_n, k0_carrier:k0_carrier + valid_k_carrier]
                        matmul(
                            l0c[l0c_cnt],
                            l1x[l1_cnt].reinterpret(DT.int4),
                            l1y[l1_cnt].reinterpret(DT.int4),
                            k=valid_k,
                            is_init=(k0 == 0),
                        )
                    l1_cnt += 1
                z[m0:m0 + valid_m, n0:n0 + valid_n] <<= l0c[l0c_cnt][0:valid_m, 0:valid_n]
                l0c_cnt += 1
    return z


if __name__ == "__main__":
    import os
    import sys
    import torch

    test_shapes = [
        (17, 19, 137),
        (65, 70, 129),
    ]
    run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A2") == "1"

    for M, N, K in test_shapes:
        torch.manual_seed(M * 1000000 + N * 1000 + K)
        x_logical = torch.randint(-8, 8, (M, K), dtype=torch.int32)
        y_logical = torch.randint(-8, 8, (N, K), dtype=torch.int32)
        x = pack_signed_int4(x_logical)
        y = pack_signed_int4(y_logical)
        z = torch.zeros((M, N), dtype=torch.int32)
        KC = x.shape[1]

        exec_kwargs = dict(simulator=True)
        if run:
            exec_kwargs = dict(
                simulator=False,
                debug=True,
                out_dir="./tmp/matmul_int4_splitk",
                cann_path=os.environ.get("ASCEND_HOME_PATH") or "",
            )
        z_kernel = OpExec(matmul_int4_splitk_kernel, **exec_kwargs)(
            x, y, z, M, N, K, KC, shape_bindings=SHAPE_BINDINGS
        )
        z_ref = x_logical @ y_logical.t()

        torch.testing.assert_close(z_kernel, z_ref)
        print(f"shape=(M={M}, N={N}, K={K})")
        print(f"max_abs_diff={(z_kernel - z_ref).abs().max().item()}")
