# a5 conv compute samples (load3d img2col path)

fp16 conv2d kernels on a5/950, ported from `kernels/a2/conv/compute`. Same spec:
`Conv2D` descriptor + `img2col` view + `conv2d` shortcut. conv2d() is matmul-scope
(L1 -> L0 -> mmad -> L0C, one M tile); the kernels own GM->L1, the m loop, the
multicore gate, and the NZ store (`l0c_to_gm_nz2nz`, plane [C1o*M_pad, C0] ==
NC1HWC0). Host does all transdata; no device transdata (only the conv_half* compute
flows are ported, not the two transdata kernels).

a5 note: load3d on a5 has no K-direction destination stride, so
`l1_to_l0a_img2col` internally loops the C0 K-chunks (see
`easyasc/resources/tensorutils.h` `L12L0A_IMG2COL` a5 branch). The conv2d shortcut
and these kernels are otherwise identical to a2; `conv2d` is now exported from
`easyasc.a5`.

| sample | shape | covers | sim | real HW (Ascend950) |
| --- | --- | --- | --- | --- |
| `conv_half_basic.py` | 20→40ch, 8×8, 3×3 same-pad | minimal end-to-end | 2.3e-5 | 1.9e-5 |
| `conv_half_dilation.py` | 12→24ch, 12×12, dilation 2, stride 2 | dilation/stride, downsampling | 1.1e-5 | 9.5e-6 |
| `conv_half_large.py` | 2×32×64×64 → 64ch, 4×4, pads (1,2,1,2) | 256KB fmap, multi-K-tile, per-batch reload, asymmetric pad | 3.8e-5 (14×14) | 6.1e-5 (64×64) |
| `conv_half_bias.py` | 31→47ch prime, 8×8, 3×3 + bias | BT/C2 bias, C/N zero-pad tails | sim-only fail | 1.9e-5 |

`conv_half_bias` is **correct on real HW** (1.9e-5, deterministic) but fails in the
**Python simulator only**. The kernel hits a cross-m-tile L0C WAR (m-tile N+1's mmad
vs m-tile N's store). auto_sync emits the correct FIX→M WAR edge for it (loop-carried
`SEvent _tmp_sevent_valid_fix_0`, verified in both codegen and the sim's
post-autosync stream), and real HW honors it — but the simulator contains the same
event yet still races, so the bug is in the simulator's execution of that
loop-carried `preset=True` cross-pipe SEvent, **not** auto_sync and **not** the BT
restage. The kernel remains HW-correct. This simulator-only discrepancy is an
accepted limitation of this sample and is not an active simulator-repair task.

Run (each script):

```bash
PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python <sample>.py          # python simulator
PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python <sample>.py --run     # real Ascend950 (simulator=False, debug=False)
```
