"""V9 all-HIF8 PFA for A5/Ascend950 with FP16 score exports.

The three score tiles share one online-softmax max update. Their HIF8 P tiles are
multiplied by V into the same L0C accumulator, so every full 384-key group emits
one PV FixP transfer instead of three. QK remains physically tiled at 128 keys and
the normalized numerator remains resident in UB.

The 256-KiB A5 L0C is split into two score and two PV slots. QK0/QK2 share the
first score slot after its FixP export, while the double-buffered PV result lets
the following group start MMAD before the previous PV FixP retires. A two-group
producer lead overlaps the score/softmax path with the delayed PV consumer.

V9 keeps V8's grouped PV accumulation and two-group lookahead schedule but
replaces every QK SPLITN score export with two FP32-to-FP16 SINGLE exports, one
natural-layout `[128,64]` score tile per AIV subblock. The FP16 softmax VFs
gather each adjacent key pair into the compact four-slab NZ carrier consumed by
direct UB2L1_NZ publishes. Its padded 33-block slab stride rotates successive
stores across UB banks while avoiding the fragmented ND2NZ conversion.

The maintained runner accepts every positive final-group length from 1 through
384, including single-group inputs. P0/P1/P2 have independent UB buffers because
real A5 exposes an MTE3-to-Vector race when P2 reuses P0. Direct A5 selection
measured 3002.27 us average at B=1, HQ=40, SQ=SKV=9360, with max/mean absolute
error 4.211e-3 / 4.857e-4.

Run the default one-core simulator smoke directly, or set
`PV_MODE=hw PV_HQ=40 PV_SQ=9360 PV_SKV=9360` for the selected production shape.
"""
import builtins
import math
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5") != "a5":
    raise RuntimeError("logical-384 PFA supports only EASYASC_TARGET=a5")
os.environ["EASYASC_TARGET"] = "a5"

from easyasc.a5 import *
from easyasc.simulator.config import SimulatorConfig
from kernels.a5.attention.pfa import pfa_fd_v6_allhif8 as _v6
from kernels.a5.attention.pfa.pfa_fd_hif8_softmax_variants import (
    accum_pv_fp16ow_vf,
    fd_merge_fp16_vf,
    final_div_fp16rsum_vf,
    init_softmax_half_vf,
)


_pyrange = builtins.range

TILE_M = 128
ROWS_PER_SB = 64
QLANES = ROWS_PER_SB
TILE_N = 128
GROUP_N = 3 * TILE_N
FAST_TAIL_N = 3
D_HEAD = 128
SOFTMAX_SCALE = 1.0 / math.sqrt(D_HEAD)
LN16 = math.log(16.0)
CHUNKS_D = D_HEAD // 64
M_Q = QLANES
CD = CHUNKS_D

# Keep two complete producer groups ahead of the delayed PV consumer. P and V
# therefore use three physical L1 slots; K remains double-buffered because only
# the immediately following producer group is preloaded.
GROUP_PRELOAD = 2
GROUP_CACHE = GROUP_PRELOAD + 1
BUFFER_SLOTS = 2
# The producer publishes P0/P1/P2 as ordered beats. Three credits match the
# three-slot P/V families while the lead-2 producer continues.
P_EVENT_DEPTH = GROUP_CACHE
MAX_CORE_COUNT = 32
MAX_FD_WS = MAX_CORE_COUNT * 2
UNROLL = 4
RB_MAX = TILE_N // UNROLL
NEG_LARGE = -1.0e30
NEG_LARGE_H = -60000.0
PAIR_ROWS = TILE_N // 2
PAIR_RB = PAIR_ROWS // UNROLL

NZ_C0 = 32
SLAB = TILE_N // 4
FRAC_STRIDE4 = SLAB + 1
KEYS_PER_GRP = 4
RB4 = 16
UNROLL4 = 2
PAIR_SLAB_ROWS = SLAB // 2
PAIR_SLAB_RB = PAIR_SLAB_ROWS // UNROLL
SLAB_STRIDE4 = 2 * FRAC_STRIDE4 * NZ_C0


def _remainder_first_intervals(total_tasks, core_count):
    tasks_floor, tasks_extra = divmod(total_tasks, core_count)
    return [
        (c * tasks_floor + min(c, tasks_extra),
         (c + 1) * tasks_floor + min(c + 1, tasks_extra))
        for c in _pyrange(core_count)
    ]


def _remainder_first_pairwise_split_ok(total_blocks, k_groups, core_count):
    owners = [0] * total_blocks
    for start, end in _remainder_first_intervals(total_blocks * k_groups, core_count):
        if start >= end:
            continue
        first = start // k_groups
        last = (end - 1) // k_groups
        for mb in _pyrange(first, last + 1):
            owners[mb] += 1
    max_owners = max(owners) if owners else 0
    split_blocks = sum(1 for count in owners if count == 2)
    return max_owners <= 2, max_owners, split_blocks


# Reuse the unchanged V6 state, UB-accumulation, FD-merge, and host-reference
# helpers. EASYASC_TARGET is forced to a5 before importing the source module.
init_softmax_state_vf = _v6.init_softmax_state_vf
softmax_vf = _v6.softmax_vf
softmax_tail_vf = _v6.softmax_tail_vf
accum_pv_vf = _v6.accum_pv_vf
accum_pv_first_vf = _v6.accum_pv_first_vf
final_div_cast_bf16_vf = _v6.final_div_cast_bf16_vf
init_accum_vf = _v6.init_accum_vf
fd_merge_vf = _v6.fd_merge_vf
output_cast_vf = _v6.output_cast_vf


@vf()
def group_half_softmax_p0_first_vf(ub_score0: Tensor, ub_score1: Tensor,
                                   ub_score2: Tensor, ub_rmax: Tensor,
                                   ub_rsum: Tensor, ub_p0: Tensor):
    """Initialize a full logical group and emit NZ-ready P0 in FP16."""
    sreg = RegList(DT.half, UNROLL)
    acc = RegList(DT.half, UNROLL)
    preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    neg = Reg(DT.half)
    block_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    tmp = Reg(DT.half)
    swap = Reg(DT.half)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO,
                     reg_layout=RegLayout.ZERO, name="gfp16_first_p")
    halfmask = MaskReg(DT.hif8, init_mode=MaskType.LOWHALF)
    pair01 = Reg(DT.hif8)
    pair23 = Reg(DT.hif8)
    deint_dummy = Reg(DT.hif8)
    gathered01 = Reg(DT.hif8)
    gathered23 = Reg(DT.hif8)
    packed_even = Reg(DT.hif8)
    lane_i8 = Reg(DT.int8)
    arange(lane_i8, 0)
    low6_mask = Reg(DT.int8)
    low6_mask <<= 63
    bit6_mask = Reg(DT.int8)
    bit6_mask <<= 64
    low6 = Reg(DT.int8)
    vand(low6, lane_i8, low6_mask)
    bit6 = Reg(DT.int8)
    vand(bit6, lane_i8, bit6_mask)
    shiftls(bit6, bit6, 1)
    even_i8 = Reg(DT.int8)
    vor(even_i8, low6, bit6)
    even_idx = even_i8.reinterpret(DT.uint8)
    odd_i8 = Reg(DT.int8)
    vor(odd_i8, even_i8, bit6_mask)
    odd_idx = odd_i8.reinterpret(DT.uint8)
    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(PAIR_RB, name="hfm0"):
        for u in unroll(UNROLL):
            row = rb * UNROLL + u
            sreg[u] <<= ub_score0[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score1[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score2[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1])
    tmp <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(tmp)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)

    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for pair_row in range(PAIR_SLAB_ROWS, name="hfex0"):
        for u in unroll(UNROLL):
            row = pair_row + u * PAIR_SLAB_ROWS
            sreg[u] <<= ub_score0[row * TILE_N]
            sub(preg[u], sreg[u], block_max)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg)
        deinterleave(pair01, deint_dummy, p_h[0], p_h[1])
        deinterleave(pair23, deint_dummy, p_h[2], p_h[3])
        nz_base = 2 * pair_row * NZ_C0
        gather(gathered01, pair01, even_idx)
        gather(gathered23, pair23, even_idx)
        select(packed_even, gathered01, gathered23, mask=halfmask)
        reg_to_ub(ub_p0[nz_base], packed_even, FRAC_STRIDE4)
        gather(gathered01, pair01, odd_idx)
        gather(gathered23, pair23, odd_idx)
        select(packed_even, gathered01, gathered23, mask=halfmask)
        reg_to_ub(ub_p0[nz_base + NZ_C0], packed_even, FRAC_STRIDE4)
    block_sum <<= acc[0] + acc[1]
    tmp <<= acc[2] + acc[3]
    block_sum <<= block_sum + tmp
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    ub_rmax[0:1, 0:TILE_N] <<= block_max
    ub_rsum[0:1, 0:TILE_N] <<= block_sum
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_half_softmax_p0_vf(ub_score0: Tensor, ub_score1: Tensor,
                             ub_score2: Tensor, ub_rmax: Tensor,
                             ub_rsum: Tensor, ub_old_weight: Tensor,
                             ub_p0: Tensor):
    """Update a full logical group and emit NZ-ready P0 in FP16."""
    sreg = RegList(DT.half, UNROLL)
    acc = RegList(DT.half, UNROLL)
    preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    neg = Reg(DT.half)
    block_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    tmp = Reg(DT.half)
    swap = Reg(DT.half)
    prev_max = Reg(DT.half)
    next_max = Reg(DT.half)
    old_weight = Reg(DT.half)
    prev_sum = Reg(DT.half)
    next_sum = Reg(DT.half)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO,
                     reg_layout=RegLayout.ZERO, name="gfp16_p0")
    halfmask = MaskReg(DT.hif8, init_mode=MaskType.LOWHALF)
    pair01 = Reg(DT.hif8)
    pair23 = Reg(DT.hif8)
    deint_dummy = Reg(DT.hif8)
    gathered01 = Reg(DT.hif8)
    gathered23 = Reg(DT.hif8)
    packed_even = Reg(DT.hif8)
    lane_i8 = Reg(DT.int8)
    arange(lane_i8, 0)
    low6_mask = Reg(DT.int8)
    low6_mask <<= 63
    bit6_mask = Reg(DT.int8)
    bit6_mask <<= 64
    low6 = Reg(DT.int8)
    vand(low6, lane_i8, low6_mask)
    bit6 = Reg(DT.int8)
    vand(bit6, lane_i8, bit6_mask)
    shiftls(bit6, bit6, 1)
    even_i8 = Reg(DT.int8)
    vor(even_i8, low6, bit6)
    even_idx = even_i8.reinterpret(DT.uint8)
    odd_i8 = Reg(DT.int8)
    vor(odd_i8, even_i8, bit6_mask)
    odd_idx = odd_i8.reinterpret(DT.uint8)
    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(PAIR_RB, name="hgm0"):
        for u in unroll(UNROLL):
            row = rb * UNROLL + u
            sreg[u] <<= ub_score0[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score1[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score2[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1])
    tmp <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(tmp)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    prev_max <<= ub_rmax[0:1, 0:TILE_N]
    next_max <<= block_max.vmax(prev_max)
    sub(old_weight, prev_max, next_max)
    exp(old_weight, old_weight)
    prev_sum <<= ub_rsum[0:1, 0:TILE_N]
    next_sum <<= prev_sum * old_weight

    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for pair_row in range(PAIR_SLAB_ROWS, name="hgex0"):
        for u in unroll(UNROLL):
            row = pair_row + u * PAIR_SLAB_ROWS
            sreg[u] <<= ub_score0[row * TILE_N]
            sub(preg[u], sreg[u], next_max)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg)
        deinterleave(pair01, deint_dummy, p_h[0], p_h[1])
        deinterleave(pair23, deint_dummy, p_h[2], p_h[3])
        nz_base = 2 * pair_row * NZ_C0
        gather(gathered01, pair01, even_idx)
        gather(gathered23, pair23, even_idx)
        select(packed_even, gathered01, gathered23, mask=halfmask)
        reg_to_ub(ub_p0[nz_base], packed_even, FRAC_STRIDE4)
        gather(gathered01, pair01, odd_idx)
        gather(gathered23, pair23, odd_idx)
        select(packed_even, gathered01, gathered23, mask=halfmask)
        reg_to_ub(ub_p0[nz_base + NZ_C0], packed_even, FRAC_STRIDE4)
    block_sum <<= acc[0] + acc[1]
    tmp <<= acc[2] + acc[3]
    block_sum <<= block_sum + tmp
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    next_sum <<= next_sum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= next_max
    ub_rsum[0:1, 0:TILE_N] <<= next_sum
    ub_old_weight[0:1, 0:TILE_N] <<= old_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_half_short_p0_vf(ub_score0: Tensor, ub_score1: Tensor,
                           ub_rmax: Tensor, ub_rsum: Tensor,
                           ub_old_weight: Tensor, ub_p0: Tensor,
                           valid_n1: Var):
    """Update a 128-plus-partial group and emit its full NZ-ready P0 tile."""
    sreg = RegList(DT.half, UNROLL)
    tail = Reg(DT.half)
    acc = RegList(DT.half, UNROLL)
    preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    neg = Reg(DT.half)
    block_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    tmp = Reg(DT.half)
    swap = Reg(DT.half)
    prev_max = Reg(DT.half)
    next_max = Reg(DT.half)
    old_weight = Reg(DT.half)
    prev_sum = Reg(DT.half)
    next_sum = Reg(DT.half)
    rowmask = MaskReg(DT.half, init_mode=MaskType.ALL)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO,
                     reg_layout=RegLayout.ZERO, name="gfp16_short_p0")
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    packed_even = Reg(DT.hif8)
    packed_odd = Reg(DT.hif8)
    even_i8 = Reg(DT.int8)
    arange(even_i8, 0)
    shiftls(even_i8, even_i8, 1)
    even_idx = even_i8.reinterpret(DT.uint8)
    odd_i8 = Reg(DT.int8)
    arange(odd_i8, 0)
    shiftls(odd_i8, odd_i8, 1)
    high_bit = Reg(DT.int8)
    high_bit <<= -128
    vxor(odd_i8, odd_i8, high_bit)
    odd_idx = odd_i8.reinterpret(DT.uint8)
    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(PAIR_RB, name="hsm0"):
        for u in unroll(UNROLL):
            row = rb * UNROLL + u
            sreg[u] <<= ub_score0[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
            cnt = Var(QLANES * Min(Max(valid_n1 - 2 * row, 0), 2), dtype=DT.uint32)
            tail <<= ub_score1[row * TILE_N]
            update_mask(rowmask, cnt)
            select(tail, tail, neg, mask=rowmask)
            acc[u] <<= acc[u].vmax(tail)
    block_max <<= acc[0].vmax(acc[1])
    tmp <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(tmp)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    prev_max <<= ub_rmax[0:1, 0:TILE_N]
    next_max <<= block_max.vmax(prev_max)
    sub(old_weight, prev_max, next_max)
    exp(old_weight, old_weight)
    prev_sum <<= ub_rsum[0:1, 0:TILE_N]
    next_sum <<= prev_sum * old_weight

    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for slab_id in range(KEYS_PER_GRP, name="hssl0"):
        for rb in range(PAIR_SLAB_RB, name="hsex0"):
            for u in unroll(UNROLL):
                pair_row = rb * UNROLL + u
                row = slab_id * PAIR_SLAB_ROWS + pair_row
                sreg[u] <<= ub_score0[row * TILE_N]
                sub(preg[u], sreg[u], next_max)
                exp(preg[u], preg[u])
                acc[u] <<= acc[u] + preg[u]
                cast(p_h[u], preg[u], cfg)
            for u in unroll(UNROLL):
                pair_row = rb * UNROLL + u
                nz_base = slab_id * SLAB_STRIDE4 + 2 * pair_row * NZ_C0
                gather(packed_even, p_h[u], even_idx)
                reg_to_ub(ub_p0[nz_base], packed_even, FRAC_STRIDE4, mask=qmask)
                gather(packed_odd, p_h[u], odd_idx)
                reg_to_ub(ub_p0[nz_base + NZ_C0], packed_odd,
                          FRAC_STRIDE4, mask=qmask)
    block_sum <<= acc[0] + acc[1]
    tmp <<= acc[2] + acc[3]
    block_sum <<= block_sum + tmp
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    next_sum <<= next_sum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= next_max
    ub_rsum[0:1, 0:TILE_N] <<= next_sum
    ub_old_weight[0:1, 0:TILE_N] <<= old_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_half_one_tail_p0_vf(ub_score0: Tensor, ub_rmax: Tensor,
                              ub_rsum: Tensor, ub_old_weight: Tensor,
                              ub_p0: Tensor, valid_n0: Var):
    """Update from one partial score tile and emit its masked NZ-ready P0."""
    score = Reg(DT.half)
    expv = Reg(DT.half)
    neg = Reg(DT.half)
    block_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    swap = Reg(DT.half)
    prev_max = Reg(DT.half)
    next_max = Reg(DT.half)
    old_weight = Reg(DT.half)
    prev_sum = Reg(DT.half)
    next_sum = Reg(DT.half)
    p_h = Reg(DT.hif8)
    rowmask = MaskReg(DT.half, init_mode=MaskType.ALL)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO,
                     reg_layout=RegLayout.ZERO, name="gfp16_one_tail_p0")
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    packed_even = Reg(DT.hif8)
    packed_odd = Reg(DT.hif8)
    even_i8 = Reg(DT.int8)
    arange(even_i8, 0)
    shiftls(even_i8, even_i8, 1)
    even_idx = even_i8.reinterpret(DT.uint8)
    odd_i8 = Reg(DT.int8)
    arange(odd_i8, 0)
    shiftls(odd_i8, odd_i8, 1)
    high_bit = Reg(DT.int8)
    high_bit <<= -128
    vxor(odd_i8, odd_i8, high_bit)
    odd_idx = odd_i8.reinterpret(DT.uint8)
    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    neg <<= NEG_LARGE_H
    block_max <<= neg
    for slab_id in range(KEYS_PER_GRP, name="hotms"):
        for pair_row in range(PAIR_SLAB_ROWS, name="hotmr"):
            row = slab_id * PAIR_SLAB_ROWS + pair_row
            cnt = Var(QLANES * Min(Max(valid_n0 - 2 * row, 0), 2), dtype=DT.uint32)
            score <<= ub_score0[row * TILE_N]
            update_mask(rowmask, cnt)
            select(score, score, neg, mask=rowmask)
            block_max <<= block_max.vmax(score)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    prev_max <<= ub_rmax[0:1, 0:TILE_N]
    next_max <<= block_max.vmax(prev_max)
    sub(old_weight, prev_max, next_max)
    exp(old_weight, old_weight)
    prev_sum <<= ub_rsum[0:1, 0:TILE_N]
    next_sum <<= prev_sum * old_weight

    block_sum <<= 0.0
    for slab_id in range(KEYS_PER_GRP, name="hotes"):
        for pair_row in range(PAIR_SLAB_ROWS, name="hoter"):
            row = slab_id * PAIR_SLAB_ROWS + pair_row
            cnt = Var(QLANES * Min(Max(valid_n0 - 2 * row, 0), 2), dtype=DT.uint32)
            score <<= ub_score0[row * TILE_N]
            update_mask(rowmask, cnt)
            select(score, score, neg, mask=rowmask)
            sub(expv, score, next_max)
            exp(expv, expv)
            block_sum <<= block_sum + expv
            cast(p_h, expv, cfg)
            nz_base = slab_id * SLAB_STRIDE4 + 2 * pair_row * NZ_C0
            gather(packed_even, p_h, even_idx)
            reg_to_ub(ub_p0[nz_base], packed_even, FRAC_STRIDE4, mask=qmask)
            gather(packed_odd, p_h, odd_idx)
            reg_to_ub(ub_p0[nz_base + NZ_C0], packed_odd,
                      FRAC_STRIDE4, mask=qmask)
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    next_sum <<= next_sum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= next_max
    ub_rsum[0:1, 0:TILE_N] <<= next_sum
    ub_old_weight[0:1, 0:TILE_N] <<= old_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_half_long_tail_p0_vf(ub_score0: Tensor, ub_score1: Tensor,
                               ub_score2: Tensor, ub_rmax: Tensor,
                               ub_rsum: Tensor, ub_old_weight: Tensor,
                               ub_p0: Tensor, valid_n2: Var):
    """Update a 256-plus-partial group and emit its full NZ-ready P0 tile."""
    sreg = RegList(DT.half, UNROLL)
    tail = Reg(DT.half)
    acc = RegList(DT.half, UNROLL)
    preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    neg = Reg(DT.half)
    block_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    tmp = Reg(DT.half)
    swap = Reg(DT.half)
    prev_max = Reg(DT.half)
    next_max = Reg(DT.half)
    old_weight = Reg(DT.half)
    prev_sum = Reg(DT.half)
    next_sum = Reg(DT.half)
    rowmask = MaskReg(DT.half, init_mode=MaskType.ALL)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO,
                     reg_layout=RegLayout.ZERO, name="gfp16_long_tail_p0")
    halfmask = MaskReg(DT.hif8, init_mode=MaskType.LOWHALF)
    pair01 = Reg(DT.hif8)
    pair23 = Reg(DT.hif8)
    deint_dummy = Reg(DT.hif8)
    gathered01 = Reg(DT.hif8)
    gathered23 = Reg(DT.hif8)
    packed_even = Reg(DT.hif8)
    lane_i8 = Reg(DT.int8)
    arange(lane_i8, 0)
    low6_mask = Reg(DT.int8)
    low6_mask <<= 63
    bit6_mask = Reg(DT.int8)
    bit6_mask <<= 64
    low6 = Reg(DT.int8)
    vand(low6, lane_i8, low6_mask)
    bit6 = Reg(DT.int8)
    vand(bit6, lane_i8, bit6_mask)
    shiftls(bit6, bit6, 1)
    even_i8 = Reg(DT.int8)
    vor(even_i8, low6, bit6)
    even_idx = even_i8.reinterpret(DT.uint8)
    odd_i8 = Reg(DT.int8)
    vor(odd_i8, even_i8, bit6_mask)
    odd_idx = odd_i8.reinterpret(DT.uint8)
    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(PAIR_RB, name="hltm0"):
        for u in unroll(UNROLL):
            row = rb * UNROLL + u
            sreg[u] <<= ub_score0[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score1[row * TILE_N]
            acc[u] <<= acc[u].vmax(sreg[u])
            cnt = Var(QLANES * Min(Max(valid_n2 - 2 * row, 0), 2), dtype=DT.uint32)
            tail <<= ub_score2[row * TILE_N]
            update_mask(rowmask, cnt)
            select(tail, tail, neg, mask=rowmask)
            acc[u] <<= acc[u].vmax(tail)
    block_max <<= acc[0].vmax(acc[1])
    tmp <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(tmp)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    prev_max <<= ub_rmax[0:1, 0:TILE_N]
    next_max <<= block_max.vmax(prev_max)
    sub(old_weight, prev_max, next_max)
    exp(old_weight, old_weight)
    prev_sum <<= ub_rsum[0:1, 0:TILE_N]
    next_sum <<= prev_sum * old_weight

    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for pair_row in range(PAIR_SLAB_ROWS, name="hlte0"):
        for u in unroll(UNROLL):
            row = pair_row + u * PAIR_SLAB_ROWS
            sreg[u] <<= ub_score0[row * TILE_N]
            sub(preg[u], sreg[u], next_max)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg)
        deinterleave(pair01, deint_dummy, p_h[0], p_h[1])
        deinterleave(pair23, deint_dummy, p_h[2], p_h[3])
        nz_base = 2 * pair_row * NZ_C0
        gather(gathered01, pair01, even_idx)
        gather(gathered23, pair23, even_idx)
        select(packed_even, gathered01, gathered23, mask=halfmask)
        reg_to_ub(ub_p0[nz_base], packed_even, FRAC_STRIDE4)
        gather(gathered01, pair01, odd_idx)
        gather(gathered23, pair23, odd_idx)
        select(packed_even, gathered01, gathered23, mask=halfmask)
        reg_to_ub(ub_p0[nz_base + NZ_C0], packed_even, FRAC_STRIDE4)
    block_sum <<= acc[0] + acc[1]
    tmp <<= acc[2] + acc[3]
    block_sum <<= block_sum + tmp
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    next_sum <<= next_sum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= next_max
    ub_rsum[0:1, 0:TILE_N] <<= next_sum
    ub_old_weight[0:1, 0:TILE_N] <<= old_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_half_emit_vf(ub_score: Tensor, ub_rmax: Tensor,
                       ub_rsum: Tensor, ub_p: Tensor):
    """Emit one full NZ-ready P tile against the shared FP16 max."""
    sreg = RegList(DT.half, UNROLL)
    preg = RegList(DT.half, UNROLL)
    acc = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    group_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    tmp = Reg(DT.half)
    swap = Reg(DT.half)
    running_sum = Reg(DT.half)
    next_sum = Reg(DT.half)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO,
                     reg_layout=RegLayout.ZERO, name="gfp16_emit")
    halfmask = MaskReg(DT.hif8, init_mode=MaskType.LOWHALF)
    pair01 = Reg(DT.hif8)
    pair23 = Reg(DT.hif8)
    deint_dummy = Reg(DT.hif8)
    gathered01 = Reg(DT.hif8)
    gathered23 = Reg(DT.hif8)
    packed_even = Reg(DT.hif8)
    lane_i8 = Reg(DT.int8)
    arange(lane_i8, 0)
    low6_mask = Reg(DT.int8)
    low6_mask <<= 63
    bit6_mask = Reg(DT.int8)
    bit6_mask <<= 64
    low6 = Reg(DT.int8)
    vand(low6, lane_i8, low6_mask)
    bit6 = Reg(DT.int8)
    vand(bit6, lane_i8, bit6_mask)
    shiftls(bit6, bit6, 1)
    even_i8 = Reg(DT.int8)
    vor(even_i8, low6, bit6)
    even_idx = even_i8.reinterpret(DT.uint8)
    odd_i8 = Reg(DT.int8)
    vor(odd_i8, even_i8, bit6_mask)
    odd_idx = odd_i8.reinterpret(DT.uint8)
    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    group_max <<= ub_rmax[0:1, 0:TILE_N]
    running_sum <<= ub_rsum[0:1, 0:TILE_N]
    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for pair_row in range(PAIR_SLAB_ROWS, name="hem0"):
        for u in unroll(UNROLL):
            row = pair_row + u * PAIR_SLAB_ROWS
            sreg[u] <<= ub_score[row * TILE_N]
            sub(preg[u], sreg[u], group_max)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg)
        deinterleave(pair01, deint_dummy, p_h[0], p_h[1])
        deinterleave(pair23, deint_dummy, p_h[2], p_h[3])
        nz_base = 2 * pair_row * NZ_C0
        gather(gathered01, pair01, even_idx)
        gather(gathered23, pair23, even_idx)
        select(packed_even, gathered01, gathered23, mask=halfmask)
        reg_to_ub(ub_p[nz_base], packed_even, FRAC_STRIDE4)
        gather(gathered01, pair01, odd_idx)
        gather(gathered23, pair23, odd_idx)
        select(packed_even, gathered01, gathered23, mask=halfmask)
        reg_to_ub(ub_p[nz_base + NZ_C0], packed_even, FRAC_STRIDE4)
    block_sum <<= acc[0] + acc[1]
    tmp <<= acc[2] + acc[3]
    block_sum <<= block_sum + tmp
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    next_sum <<= running_sum + block_sum
    ub_rsum[0:1, 0:TILE_N] <<= next_sum
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_half_emit_tail_vf(ub_score: Tensor, ub_rmax: Tensor,
                            ub_rsum: Tensor, ub_p: Tensor,
                            valid_n: Var):
    """Emit one masked NZ-ready P tile against the shared FP16 max."""
    score = Reg(DT.half)
    expv = Reg(DT.half)
    neg = Reg(DT.half)
    group_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    swap = Reg(DT.half)
    running_sum = Reg(DT.half)
    next_sum = Reg(DT.half)
    p_h = Reg(DT.hif8)
    rowmask = MaskReg(DT.half, init_mode=MaskType.ALL)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO,
                     reg_layout=RegLayout.ZERO, name="gfp16_emit_tail")
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    packed_even = Reg(DT.hif8)
    packed_odd = Reg(DT.hif8)
    even_i8 = Reg(DT.int8)
    arange(even_i8, 0)
    shiftls(even_i8, even_i8, 1)
    even_idx = even_i8.reinterpret(DT.uint8)
    odd_i8 = Reg(DT.int8)
    arange(odd_i8, 0)
    shiftls(odd_i8, odd_i8, 1)
    high_bit = Reg(DT.int8)
    high_bit <<= -128
    vxor(odd_i8, odd_i8, high_bit)
    odd_idx = odd_i8.reinterpret(DT.uint8)
    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    neg <<= NEG_LARGE_H
    group_max <<= ub_rmax[0:1, 0:TILE_N]
    running_sum <<= ub_rsum[0:1, 0:TILE_N]
    block_sum <<= 0.0
    for slab_id in range(KEYS_PER_GRP, name="hetsl"):
        for pair_row in range(PAIR_SLAB_ROWS, name="het0"):
            row = slab_id * PAIR_SLAB_ROWS + pair_row
            cnt = Var(QLANES * Min(Max(valid_n - 2 * row, 0), 2), dtype=DT.uint32)
            score <<= ub_score[row * TILE_N]
            update_mask(rowmask, cnt)
            select(score, score, neg, mask=rowmask)
            sub(expv, score, group_max)
            exp(expv, expv)
            block_sum <<= block_sum + expv
            cast(p_h, expv, cfg)
            nz_base = slab_id * SLAB_STRIDE4 + 2 * pair_row * NZ_C0
            gather(packed_even, p_h, even_idx)
            reg_to_ub(ub_p[nz_base], packed_even, FRAC_STRIDE4, mask=qmask)
            gather(packed_odd, p_h, odd_idx)
            reg_to_ub(ub_p[nz_base + NZ_C0], packed_odd,
                      FRAC_STRIDE4, mask=qmask)
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    next_sum <<= running_sum + block_sum
    ub_rsum[0:1, 0:TILE_N] <<= next_sum
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_prepare_vf(ub_score0: Tensor, ub_score1: Tensor, ub_rmax: Tensor,
                     ub_rsum: Tensor, ub_old_weight: Tensor):
    """Update max once for two full score tiles and pre-scale the old denominator."""
    sreg = RegList(DT.float, UNROLL)
    acc = RegList(DT.float, UNROLL)
    neg = Reg(DT.float)
    block_max = Reg(DT.float)
    tmp = Reg(DT.float)
    prev_max = Reg(DT.float)
    next_max = Reg(DT.float)
    old_weight = Reg(DT.float)
    prev_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="gmx"):
        for u in unroll(UNROLL):
            row = rb * UNROLL + u
            sreg[u] <<= ub_score0[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score1[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1])
    tmp <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(tmp)
    muls(block_max, block_max, SOFTMAX_SCALE)
    prev_max <<= ub_rmax[0:1, 0:QLANES]
    next_max <<= block_max.vmax(prev_max)
    expsub(old_weight, prev_max, next_max)
    prev_sum <<= ub_rsum[0:1, 0:QLANES]
    next_sum <<= prev_sum * old_weight
    ub_rmax[0:1, 0:QLANES] <<= next_max
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    ub_old_weight[0:1, 0:QLANES] <<= old_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_prepare_one_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor,
                         ub_old_weight: Tensor):
    """Update the online state from one full score tile without emitting P."""
    sreg = RegList(DT.float, UNROLL)
    acc = RegList(DT.float, UNROLL)
    neg = Reg(DT.float)
    block_max = Reg(DT.float)
    tmp = Reg(DT.float)
    prev_max = Reg(DT.float)
    next_max = Reg(DT.float)
    old_weight = Reg(DT.float)
    prev_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="gomx"):
        for u in unroll(UNROLL):
            row = rb * UNROLL + u
            sreg[u] <<= ub_score[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1])
    tmp <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(tmp)
    muls(block_max, block_max, SOFTMAX_SCALE)
    prev_max <<= ub_rmax[0:1, 0:QLANES]
    next_max <<= block_max.vmax(prev_max)
    expsub(old_weight, prev_max, next_max)
    prev_sum <<= ub_rsum[0:1, 0:QLANES]
    next_sum <<= prev_sum * old_weight
    ub_rmax[0:1, 0:QLANES] <<= next_max
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    ub_old_weight[0:1, 0:QLANES] <<= old_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group3_prepare_tail_vf(ub_score0: Tensor, ub_score1: Tensor, ub_score2: Tensor,
                           ub_rmax: Tensor, ub_rsum: Tensor, ub_old_weight: Tensor,
                           valid_n0: Var, valid_n1: Var, valid_n2: Var):
    """Update one online-softmax state from a partial three-tile group."""
    score0 = Reg(DT.float)
    score1 = Reg(DT.float)
    score2 = Reg(DT.float)
    neg = Reg(DT.float)
    block_max = Reg(DT.float)
    prev_max = Reg(DT.float)
    next_max = Reg(DT.float)
    old_weight = Reg(DT.float)
    prev_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    neg <<= NEG_LARGE
    block_max <<= NEG_LARGE
    for ni in range(TILE_N, name="g3tn"):
        cnt0 = Var(QLANES * Min(Max(valid_n0 - ni, 0), 1), dtype=DT.uint32)
        score0 <<= ub_score0[ni:ni + 1, :]
        muls(score0, score0, SOFTMAX_SCALE)
        update_mask(rowmask, cnt0)
        select(score0, score0, neg, mask=rowmask)
        block_max <<= block_max.vmax(score0)

        cnt1 = Var(QLANES * Min(Max(valid_n1 - ni, 0), 1), dtype=DT.uint32)
        score1 <<= ub_score1[ni:ni + 1, :]
        muls(score1, score1, SOFTMAX_SCALE)
        update_mask(rowmask, cnt1)
        select(score1, score1, neg, mask=rowmask)
        block_max <<= block_max.vmax(score1)

        cnt2 = Var(QLANES * Min(Max(valid_n2 - ni, 0), 1), dtype=DT.uint32)
        score2 <<= ub_score2[ni:ni + 1, :]
        muls(score2, score2, SOFTMAX_SCALE)
        update_mask(rowmask, cnt2)
        select(score2, score2, neg, mask=rowmask)
        block_max <<= block_max.vmax(score2)
    prev_max <<= ub_rmax[0:1, 0:QLANES]
    next_max <<= block_max.vmax(prev_max)
    expsub(old_weight, prev_max, next_max)
    prev_sum <<= ub_rsum[0:1, 0:QLANES]
    next_sum <<= prev_sum * old_weight
    ub_rmax[0:1, 0:QLANES] <<= next_max
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    ub_old_weight[0:1, 0:QLANES] <<= old_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_refine_tail_max_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor,
                             ub_old_weight: Tensor, valid_n: Var):
    """Refine a two-half group state with one masked third-half max."""
    score = Reg(DT.float)
    neg = Reg(DT.float)
    block_max = Reg(DT.float)
    prev_max = Reg(DT.float)
    next_max = Reg(DT.float)
    tail_weight = Reg(DT.float)
    prev_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    prior_weight = Reg(DT.float)
    combined_weight = Reg(DT.float)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    neg <<= NEG_LARGE
    block_max <<= NEG_LARGE
    for ni in range(TILE_N, name="grtn"):
        cnt = Var(QLANES * Min(Max(valid_n - ni, 0), 1), dtype=DT.uint32)
        score <<= ub_score[ni:ni + 1, :]
        muls(score, score, SOFTMAX_SCALE)
        update_mask(rowmask, cnt)
        select(score, score, neg, mask=rowmask)
        block_max <<= block_max.vmax(score)
    prev_max <<= ub_rmax[0:1, 0:QLANES]
    next_max <<= block_max.vmax(prev_max)
    expsub(tail_weight, prev_max, next_max)
    prev_sum <<= ub_rsum[0:1, 0:QLANES]
    next_sum <<= prev_sum * tail_weight
    prior_weight <<= ub_old_weight[0:1, 0:QLANES]
    combined_weight <<= prior_weight * tail_weight
    ub_rmax[0:1, 0:QLANES] <<= next_max
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    ub_old_weight[0:1, 0:QLANES] <<= combined_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_refine_tail3_max_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor,
                              ub_old_weight: Tensor):
    """Refine the group state from the fixed three-key production tail."""
    score = Reg(DT.float)
    block_max = Reg(DT.float)
    prev_max = Reg(DT.float)
    next_max = Reg(DT.float)
    tail_weight = Reg(DT.float)
    prev_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    prior_weight = Reg(DT.float)
    combined_weight = Reg(DT.float)
    block_max <<= NEG_LARGE
    for ni in range(FAST_TAIL_N, name="grt3"):
        score <<= ub_score[ni:ni + 1, :]
        muls(score, score, SOFTMAX_SCALE)
        block_max <<= block_max.vmax(score)
    prev_max <<= ub_rmax[0:1, 0:QLANES]
    next_max <<= block_max.vmax(prev_max)
    expsub(tail_weight, prev_max, next_max)
    prev_sum <<= ub_rsum[0:1, 0:QLANES]
    next_sum <<= prev_sum * tail_weight
    prior_weight <<= ub_old_weight[0:1, 0:QLANES]
    combined_weight <<= prior_weight * tail_weight
    ub_rmax[0:1, 0:QLANES] <<= next_max
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    ub_old_weight[0:1, 0:QLANES] <<= combined_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_emit_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor):
    """Emit one full HIF8 P tile against a group-shared max and add its denominator."""
    sreg = RegList(DT.float, UNROLL)
    psum = RegList(DT.float, UNROLL)
    preg = RegList(DT.float, UNROLL)
    group_max = Reg(DT.float)
    exp_max = Reg(DT.float)
    block_sum = Reg(DT.float)
    tmp = Reg(DT.float)
    running_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO,
                     name="group_p_hif8")
    group_max <<= ub_rmax[0:1, 0:QLANES]
    running_sum <<= ub_rsum[0:1, 0:QLANES]
    adds(exp_max, group_max, -LN16)
    for kk in _pyrange(KEYS_PER_GRP):
        psum[kk] <<= 0.0
    hh = RegList(DT.hif8, KEYS_PER_GRP)
    aa = Reg(DT.hif8)
    bb = Reg(DT.hif8)
    fin = Reg(DT.hif8)
    dummy = Reg(DT.hif8)
    for rb in range(RB4, name="gex"):
        for u in unroll(UNROLL4):
            for kk in _pyrange(KEYS_PER_GRP):
                row = (rb * UNROLL4 + u) + kk * SLAB
                sreg[0] <<= ub_score[row:row + 1, :]
                muls(sreg[0], sreg[0], SOFTMAX_SCALE)
                expsub(preg[0], sreg[0], exp_max)
                psum[kk] <<= psum[kk] + preg[0]
                cast(hh[kk], preg[0], cfg)
            deinterleave(aa, dummy, hh[0], hh[1])
            deinterleave(bb, dummy, hh[2], hh[3])
            deinterleave(fin, dummy, aa, bb)
            reg_to_ub(ub_p[(rb * UNROLL4 + u) * NZ_C0], fin, FRAC_STRIDE4)
    block_sum <<= psum[0] + psum[1]
    tmp <<= psum[2] + psum[3]
    block_sum <<= block_sum + tmp
    next_sum <<= running_sum + block_sum
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_emit_tail_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor,
                       ub_p: Tensor, valid_n: Var):
    """Emit a masked HIF8 P tile against a group-shared max and add its denominator."""
    score = Reg(DT.float)
    expv = Reg(DT.float)
    neg = Reg(DT.float)
    group_max = Reg(DT.float)
    exp_max = Reg(DT.float)
    block_sum = Reg(DT.float)
    running_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    p_hif8 = Reg(DT.hif8)
    packed = Reg(DT.hif8)
    gather_index_i8 = Reg(DT.int8)
    arange(gather_index_i8, 0)
    shiftls(gather_index_i8, gather_index_i8, 2)
    gather_index = gather_index_i8.reinterpret(DT.uint8)
    rowmask = MaskReg(DT.float, init_mode=MaskType.ALL)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO,
                     name="group_p_hif8_tail")
    neg <<= NEG_LARGE
    group_max <<= ub_rmax[0:1, 0:QLANES]
    running_sum <<= ub_rsum[0:1, 0:QLANES]
    adds(exp_max, group_max, -LN16)
    block_sum <<= 0.0
    slab_stride = 2 * FRAC_STRIDE4 * NZ_C0
    for g in range(KEYS_PER_GRP, name="getg"):
        for m in range(SLAB, name="getm"):
            ni = g * SLAB + m
            cnt = Var(QLANES * Min(Max(valid_n - ni, 0), 1), dtype=DT.uint32)
            score <<= ub_score[ni:ni + 1, :]
            muls(score, score, SOFTMAX_SCALE)
            update_mask(rowmask, cnt)
            select(score, score, neg, mask=rowmask)
            expsub(expv, score, exp_max)
            block_sum <<= block_sum + expv
            cast(p_hif8, expv, cfg)
            gather(packed, p_hif8, gather_index)
            reg_to_ub(ub_p[g * slab_stride + m * NZ_C0], packed,
                      FRAC_STRIDE4, mask=qmask)
    next_sum <<= running_sum + block_sum
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_emit_tail3_vf(ub_score: Tensor, ub_rmax: Tensor, ub_rsum: Tensor,
                        ub_p: Tensor):
    """Emit only the three P rows consumed by the exact-K production tail."""
    score = Reg(DT.float)
    expv = Reg(DT.float)
    group_max = Reg(DT.float)
    exp_max = Reg(DT.float)
    block_sum = Reg(DT.float)
    running_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    p_hif8 = Reg(DT.hif8)
    packed = Reg(DT.hif8)
    gather_index_i8 = Reg(DT.int8)
    arange(gather_index_i8, 0)
    shiftls(gather_index_i8, gather_index_i8, 2)
    gather_index = gather_index_i8.reinterpret(DT.uint8)
    qmask = MaskReg(DT.hif8, init_mode=MaskType.LOWQUAT)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO,
                     name="group_p_hif8_tail3")
    group_max <<= ub_rmax[0:1, 0:QLANES]
    running_sum <<= ub_rsum[0:1, 0:QLANES]
    adds(exp_max, group_max, -LN16)
    block_sum <<= 0.0
    for ni in range(FAST_TAIL_N, name="get3"):
        score <<= ub_score[ni:ni + 1, :]
        muls(score, score, SOFTMAX_SCALE)
        expsub(expv, score, exp_max)
        block_sum <<= block_sum + expv
        cast(p_hif8, expv, cfg)
        gather(packed, p_hif8, gather_index)
        reg_to_ub(ub_p[ni * NZ_C0], packed, FRAC_STRIDE4, mask=qmask)
    next_sum <<= running_sum + block_sum
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_softmax_p0_vf(ub_score0: Tensor, ub_score1: Tensor, ub_score2: Tensor, ub_rmax: Tensor,
                        ub_rsum: Tensor, ub_old_weight: Tensor, ub_p0: Tensor):
    """Prepare one full 384-key group and expose its first P third."""
    sreg = RegList(DT.float, UNROLL)
    acc = RegList(DT.float, UNROLL)
    preg = Reg(DT.float)
    neg = Reg(DT.float)
    block_max = Reg(DT.float)
    tmp = Reg(DT.float)
    prev_max = Reg(DT.float)
    next_max = Reg(DT.float)
    old_weight = Reg(DT.float)
    prev_sum = Reg(DT.float)
    next_sum = Reg(DT.float)
    exp_max = Reg(DT.float)
    block_sum = Reg(DT.float)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO,
                     name="group_pair_p_hif8")

    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="gpsmx"):
        for u in unroll(UNROLL):
            row = rb * UNROLL + u
            sreg[u] <<= ub_score0[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score1[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score2[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1])
    tmp <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(tmp)
    muls(block_max, block_max, SOFTMAX_SCALE)
    prev_max <<= ub_rmax[0:1, 0:QLANES]
    next_max <<= block_max.vmax(prev_max)
    expsub(old_weight, prev_max, next_max)
    prev_sum <<= ub_rsum[0:1, 0:QLANES]
    next_sum <<= prev_sum * old_weight
    adds(exp_max, next_max, -LN16)

    hh = RegList(DT.hif8, KEYS_PER_GRP)
    aa = Reg(DT.hif8)
    bb = Reg(DT.hif8)
    fin = Reg(DT.hif8)
    dummy = Reg(DT.hif8)

    for kk in _pyrange(KEYS_PER_GRP):
        acc[kk] <<= 0.0
    for rb in range(RB4, name="gpsex0"):
        for u in unroll(UNROLL4):
            for kk in _pyrange(KEYS_PER_GRP):
                row = (rb * UNROLL4 + u) + kk * SLAB
                sreg[0] <<= ub_score0[row:row + 1, :]
                muls(sreg[0], sreg[0], SOFTMAX_SCALE)
                expsub(preg, sreg[0], exp_max)
                acc[kk] <<= acc[kk] + preg
                cast(hh[kk], preg, cfg)
            deinterleave(aa, dummy, hh[0], hh[1])
            deinterleave(bb, dummy, hh[2], hh[3])
            deinterleave(fin, dummy, aa, bb)
            reg_to_ub(ub_p0[(rb * UNROLL4 + u) * NZ_C0], fin, FRAC_STRIDE4)
    block_sum <<= acc[0] + acc[1]
    tmp <<= acc[2] + acc[3]
    block_sum <<= block_sum + tmp
    next_sum <<= next_sum + block_sum

    ub_rmax[0:1, 0:QLANES] <<= next_max
    ub_rsum[0:1, 0:QLANES] <<= next_sum
    ub_old_weight[0:1, 0:QLANES] <<= old_weight
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def group_softmax_p0_first_vf(ub_score0: Tensor, ub_score1: Tensor, ub_score2: Tensor,
                              ub_rmax: Tensor, ub_rsum: Tensor, ub_p0: Tensor):
    """Prepare the first full group and expose P0 without initialized state."""
    sreg = RegList(DT.float, UNROLL)
    acc = RegList(DT.float, UNROLL)
    preg = Reg(DT.float)
    neg = Reg(DT.float)
    block_max = Reg(DT.float)
    tmp = Reg(DT.float)
    exp_max = Reg(DT.float)
    block_sum = Reg(DT.float)
    cfg = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO,
                     name="group_first_pair_p_hif8")

    neg <<= NEG_LARGE
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_MAX, name="gfsmx"):
        for u in unroll(UNROLL):
            row = rb * UNROLL + u
            sreg[u] <<= ub_score0[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score1[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
            sreg[u] <<= ub_score2[row:row + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1])
    tmp <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(tmp)
    muls(block_max, block_max, SOFTMAX_SCALE)
    adds(exp_max, block_max, -LN16)

    hh = RegList(DT.hif8, KEYS_PER_GRP)
    aa = Reg(DT.hif8)
    bb = Reg(DT.hif8)
    fin = Reg(DT.hif8)
    dummy = Reg(DT.hif8)

    for kk in _pyrange(KEYS_PER_GRP):
        acc[kk] <<= 0.0
    for rb in range(RB4, name="gfsex0"):
        for u in unroll(UNROLL4):
            for kk in _pyrange(KEYS_PER_GRP):
                row = (rb * UNROLL4 + u) + kk * SLAB
                sreg[0] <<= ub_score0[row:row + 1, :]
                muls(sreg[0], sreg[0], SOFTMAX_SCALE)
                expsub(preg, sreg[0], exp_max)
                acc[kk] <<= acc[kk] + preg
                cast(hh[kk], preg, cfg)
            deinterleave(aa, dummy, hh[0], hh[1])
            deinterleave(bb, dummy, hh[2], hh[3])
            deinterleave(fin, dummy, aa, bb)
            reg_to_ub(ub_p0[(rb * UNROLL4 + u) * NZ_C0], fin, FRAC_STRIDE4)
    block_sum <<= acc[0] + acc[1]
    tmp <<= acc[2] + acc[3]
    block_sum <<= block_sum + tmp

    ub_rmax[0:1, 0:QLANES] <<= block_max
    ub_rsum[0:1, 0:QLANES] <<= block_sum
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@func()
def _qk_bridge_two_single_group(ub_dst, l0c_src):
    """Downcast one complete 128x64 score tile into each AIV subblock."""
    l0c_to_ub(ub_dst, l0c_src[0:TILE_N, 0:ROWS_PER_SB],
              M=TILE_N, N=ROWS_PER_SB, N_dst=ROWS_PER_SB, M_src=TILE_N,
              dual_mode=DualMode.SINGLE, sub_block_id=0, scale=SOFTMAX_SCALE)
    l0c_to_ub(ub_dst, l0c_src[0:TILE_N, ROWS_PER_SB:TILE_M],
              M=TILE_N, N=ROWS_PER_SB, N_dst=ROWS_PER_SB, M_src=TILE_N,
              dual_mode=DualMode.SINGLE, sub_block_id=1, scale=SOFTMAX_SCALE)


@func()
def _publish_group_p(l1p_dst, ub_p, row_begin, p_mutex):
    p_mutex.lock()
    for slab_id in _pyrange(KEYS_PER_GRP):
        l1p_dst[slab_id * SLAB:(slab_id + 1) * SLAB,
                row_begin:row_begin + ROWS_PER_SB] <<= (
            ub_p.nz()[0:SLAB,
                      slab_id * ROWS_PER_SB:(slab_id + 1) * ROWS_PER_SB]
        )
    p_mutex.ready()


@func()
def _publish_group_p3(l1p_dst, ub_p, row_begin, p_mutex):
    """Publish a minimal unused payload to preserve the three-beat event phase."""
    p_mutex.lock()
    l1p_dst[0:FAST_TAIL_N, row_begin:row_begin + ROWS_PER_SB] <<= (
        ub_p.nz()[0:FAST_TAIL_N, 0:ROWS_PER_SB]
    )
    p_mutex.ready()


@func()
def _alloc_group(q, k, v):
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")
    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k0 = DBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1k1 = DBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1k2 = DBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v0 = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v1 = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v2 = TBuff(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p0 = TBuff(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l1p1 = TBuff(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l1p2 = TBuff(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = TBuff(DT.half, [TILE_N, ROWS_PER_SB], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p0 = DBuff(DT.hif8, [FRAC_STRIDE4, KEYS_PER_GRP * ROWS_PER_SB], Position.UB)
    ub_p1 = DBuff(DT.hif8, [FRAC_STRIDE4, KEYS_PER_GRP * ROWS_PER_SB], Position.UB)
    ub_p2 = DBuff(DT.hif8, [FRAC_STRIDE4, KEYS_PER_GRP * ROWS_PER_SB], Position.UB)
    ub_old_weight = TBuff(DT.half, [1, TILE_N], Position.UB)
    ub_rmax = TBuff(DT.half, [1, TILE_N], Position.UB)
    ub_rsum = TBuff(DT.half, [1, TILE_N], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)
    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.half, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.half, [MAX_FD_WS, 1, TILE_M], name="fd_sum")
    return (q_hif8, k_hif8, v_hif8, l1q, l1k0, l1k1, l1k2, l1v0, l1v1, l1v2,
            l1p0, l1p1, l1p2, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p0, ub_p1, ub_p2,
            ub_old_weight, ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out,
            fd_accum, fd_max, fd_sum)


@func()
def _group384_body(q, k, v, out, B, MQ, N, D, cv0, cv1, pv_mutex, p_mutex,
                   qk0_l0c_reusable, qk1_l0c_reusable, qk2_l0c_reusable,
                   pv_l0c_reusable, l0c_mmad_ready,
                   boundary_store_done):
    (q_hif8, k_hif8, v_hif8, l1q, l1k0, l1k1, l1k2, l1v0, l1v1, l1v2,
     l1p0, l1p1, l1p2, l0c_qk, l0c_pv, ub_score, ub_pv, ub_p0, ub_p1, ub_p2,
     ub_old_weight, ub_rmax, ub_rsum, ub_merge_a, ub_merge_den, ub_accum, ub_out,
     fd_accum, fd_max, fd_sum) = _alloc_group(q, k, v)

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_groups = CeilDiv(N, GROUP_N)
    total_tasks = Var(B * tiles_m_per_b * k_groups)
    tasks_floor = Var(total_tasks // core_count)
    # Avoid Var modulo here: the side-split trace exposes an inactive-side
    # GetCubeNum placeholder of zero, while the already-supported division is
    # normalized by lowering.  The algebraic remainder has identical runtime value.
    tasks_extra = Var(total_tasks - tasks_floor * core_count)
    flat_start = Var(core * tasks_floor + Min(core, tasks_extra))
    flat_end = Var((core + 1) * tasks_floor + Min(core + 1, tasks_extra))
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for boundary_core in range(1, MAX_CORE_COUNT, name="gbc"):
        if core_count > boundary_core:
            boundary = Var(boundary_core * tasks_floor + Min(boundary_core, tasks_extra))
            if boundary % k_groups != 0:
                if core == boundary_core:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == boundary_core:
                    head_ws <<= split_count * 2
                split_count += 1

    last_group_valid = Var(N - (k_groups - 1) * GROUP_N)
    for ki in _pyrange(BUFFER_SLOTS):
        # The first score tile can itself be partial. It is still issued as a
        # physical 128-row QK tile and masked in the one-tile tail VF.
        if last_group_valid < TILE_N:
            set_constant_to_l1(l1k0[ki].reinterpret(DT.uint8), 0)
        # A core may begin at a 128/<128/0 tail.  K1 is still issued as a
        # physical 128-row QK tile and masked in Vector, so its untouched rows
        # must be finite.  Keep the selected 4099 path unchanged by paying this
        # initialization only when the final group has no third tile.
        if last_group_valid <= 2 * TILE_N:
            set_constant_to_l1(l1k1[ki].reinterpret(DT.uint8), 0)
        # A core may begin directly at the final 128/128/<128 group.  K2's
        # untouched rows must be finite before the full physical QK MMAD; the
        # tail VF masks them logically after FixP.
        set_constant_to_l1(l1k2[ki].reinterpret(DT.uint8), 0)
    for vi in _pyrange(GROUP_CACHE):
        set_constant_to_l1(l1v0[vi].reinterpret(DT.uint8), 0)
        set_constant_to_l1(l1v1[vi].reinterpret(DT.uint8), 0)
        set_constant_to_l1(l1v2[vi].reinterpret(DT.uint8), 0)
    # The explicit per-slot events are the sole Fix->M reuse authority. QK0 and
    # QK2 rotate through one shared score slot; PV rotates through two slots.
    # Lead-2 can expose three QK results plus one older PV result before Fix
    # consumes the FIFO head, so the result-ready edge needs four credits.
    with auto_sync(mode="manual_fix"):
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_group = Var(flat_start % k_groups)
            if start_group != 0:
                prefix_mt <<= flat_start // k_groups
            end_group = Var(flat_end % k_groups)
            if end_group != 0:
                suffix_mt <<= (flat_end - 1) // k_groups

        # Seed producer/consumer coordinates once.  The hot loop advances them
        # with cheap increments and wrap tests instead of repeating integer
        # division/modulo for both sides of every group beat.
        p_start_mt = Var(flat_start // k_groups)
        p_kg = Var(flat_start - p_start_mt * k_groups)
        p_qm = Var(p_start_mt % 2)
        p_sm = Var(p_start_mt % GROUP_CACHE)
        p_batch = Var(p_start_mt // tiles_m_per_b)
        p_local_mt = Var(p_start_mt - p_batch * tiles_m_per_b)
        p_q_base = Var(p_batch * MQ)
        p_kv_base = Var(p_batch * N)
        p_m0 = Var(p_local_mt * TILE_M)
        p_need_q = Var(1, DT.int)

        c_lag = Var(0, DT.int)
        c_mt = Var(p_start_mt)
        c_kg = Var(p_kg)
        c_sm = Var(p_sm)
        c_batch = Var(p_batch)
        c_local_mt = Var(p_local_mt)
        c_q_base = Var(p_q_base)
        c_kv_base = Var(p_kv_base)
        c_m0 = Var(p_m0)

        # V preload coordinates advance independently from p_*.  V[c_lag] is
        # consumed before its physical slot is refilled, then the next V group
        # is queued at the bottom of the same iteration.
        vl_lag = Var(0, DT.int)
        vl_kg = Var(p_kg)
        vl_local_mt = Var(p_local_mt)
        vl_kv_base = Var(p_kv_base)

        # Prime K for the first producer beat. Every later K group is loaded at
        # the end of its predecessor beat into the opposite DBuff slot.
        if my_tasks > 0:
            pk_n0 = Var(p_kg * GROUP_N)
            pk_valid_n0 = Min(TILE_N, N - pk_n0)
            pk_n1 = Var(pk_n0 + TILE_N)
            pk_valid_n1 = Min(TILE_N, Max(N - pk_n1, 0))
            pk_n2 = Var(pk_n1 + TILE_N)
            pk_valid_n2 = Min(TILE_N, Max(N - pk_n2, 0))
            l1k0[0][0:pk_valid_n0, 0:D] <<= (
                k_hif8[p_kv_base + pk_n0:p_kv_base + pk_n0 + pk_valid_n0, 0:D]
            )
            if pk_valid_n1 > 0:
                l1k1[0][0:pk_valid_n1, 0:D] <<= (
                    k_hif8[p_kv_base + pk_n1:p_kv_base + pk_n1 + pk_valid_n1, 0:D]
                )
            if pk_valid_n2 > 0:
                l1k2[0][0:pk_valid_n2, 0:D] <<= (
                    k_hif8[p_kv_base + pk_n2:p_kv_base + pk_n2 + pk_valid_n2, 0:D]
                )

        for step in range(0, my_tasks + GROUP_PRELOAD, name="gstep"):
            if step < my_tasks:
                p_n0 = Var(p_kg * GROUP_N)
                valid_m = Min(TILE_M, MQ - p_m0)
                valid_n0 = Min(TILE_N, N - p_n0)
                n1 = Var(p_n0 + TILE_N)
                valid_n1 = Min(TILE_N, Max(N - n1, 0))
                n2 = Var(n1 + TILE_N)
                valid_n2 = Min(TILE_N, Max(N - n2, 0))

                if p_need_q > 0:
                    l1q[p_qm][0:valid_m, 0:D] <<= (
                        q_hif8[p_q_base + p_m0:p_q_base + p_m0 + valid_m, 0:D]
                    )
                    # Only a full three-tile group has a dedicated first-group
                    # VF. Every partial group starts from explicit state.
                    if valid_n2 != TILE_N:
                        init_softmax_half_vf(ub_rmax[p_sm], ub_rsum[p_sm])

                qk0_l0c_reusable.wait()
                matmul(l0c_qk[0], l1k0[step], l1q[p_qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
                l0c_mmad_ready.set()
                cv0.lock()
                l0c_mmad_ready.wait()
                _qk_bridge_two_single_group(ub_score[0], l0c_qk[0])
                qk0_l0c_reusable.set()
                cv0.ready()

                qk1_l0c_reusable.wait()
                matmul(l0c_qk[1], l1k1[step], l1q[p_qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
                l0c_mmad_ready.set()
                cv1.lock()
                l0c_mmad_ready.wait()
                _qk_bridge_two_single_group(ub_score[1], l0c_qk[1])
                qk1_l0c_reusable.set()
                cv1.ready()

                # QK2 reuses QK0's score slot after its FixP export. Even a
                # 128/<128/0 tail executes this zero-K tile: cv0 is a depth-two
                # score0/score2 ring, so skipping the second beat would
                # phase-shift the next query tile onto the wrong event slot.
                qk2_l0c_reusable.wait()
                matmul(l0c_qk[0], l1k2[step], l1q[p_qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)
                l0c_mmad_ready.set()
                cv0.lock()
                l0c_mmad_ready.wait()
                _qk_bridge_two_single_group(ub_score[2], l0c_qk[0])
                qk2_l0c_reusable.set()
                cv0.ready()

                cv0.wait()
                cv1.wait()
                # cv0 is a depth-2 FIFO: its first token owns score0 and its
                # second token owns score2.
                cv0.wait()
                if valid_n2 == TILE_N:
                    if p_need_q > 0:
                        group_half_softmax_p0_first_vf(
                            ub_score[0], ub_score[1], ub_score[2],
                            ub_rmax[p_sm], ub_rsum[p_sm], ub_p0[step]
                        )
                    else:
                        group_half_softmax_p0_vf(
                            ub_score[0], ub_score[1], ub_score[2],
                            ub_rmax[p_sm], ub_rsum[p_sm],
                            ub_old_weight[step], ub_p0[step]
                        )
                else:
                    if valid_n1 == 0:
                        group_half_one_tail_p0_vf(
                            ub_score[0], ub_rmax[p_sm], ub_rsum[p_sm],
                            ub_old_weight[step], ub_p0[step], valid_n0
                        )
                    else:
                        if valid_n2 == 0:
                            group_half_short_p0_vf(
                                ub_score[0], ub_score[1], ub_rmax[p_sm],
                                ub_rsum[p_sm], ub_old_weight[step], ub_p0[step],
                                valid_n1
                            )
                        else:
                            group_half_long_tail_p0_vf(
                                ub_score[0], ub_score[1], ub_score[2],
                                ub_rmax[p_sm], ub_rsum[p_sm],
                                ub_old_weight[step], ub_p0[step], valid_n2
                            )
                cv0.free()
                _publish_group_p(l1p0[step], ub_p0[step], row_begin, p_mutex)

                # Each published P beat can enter Cube while Vector emits the
                # next beat against the shared group max.
                if valid_n1 == TILE_N:
                    group_half_emit_vf(
                        ub_score[1], ub_rmax[p_sm], ub_rsum[p_sm], ub_p1[step]
                    )
                else:
                    # valid_n1 can be zero. The masked emitter then produces a
                    # zero tile while retaining the original V->MTE3 ownership
                    # scope and the fixed P0/P1/P2 event sequence.
                    group_half_emit_tail_vf(
                        ub_score[1], ub_rmax[p_sm], ub_rsum[p_sm],
                        ub_p1[step], valid_n1
                    )
                cv1.free()
                _publish_group_p(l1p1[step], ub_p1[step], row_begin, p_mutex)
                # P2 owns an independent UB tile. Reusing P0 here is a real-A5
                # MTE3->Vector race even though the simulator accepts it.
                if valid_n2 > 0:
                    if valid_n2 == TILE_N:
                        group_half_emit_vf(
                            ub_score[2], ub_rmax[p_sm], ub_rsum[p_sm], ub_p2[step]
                        )
                    else:
                        group_half_emit_tail_vf(
                            ub_score[2], ub_rmax[p_sm], ub_rsum[p_sm],
                            ub_p2[step], valid_n2
                        )
                    _publish_group_p(l1p2[step], ub_p2[step], row_begin, p_mutex)
                else:
                    # p_mutex is a depth-three P0/P1/P2 credit ring. Publish a
                    # phase-only three-row beat so the next logical group keeps
                    # the same physical credit mapping; consumer PV skips it.
                    _publish_group_p3(l1p2[step], ub_p2[step], row_begin, p_mutex)
                cv0.free()

                p_need_q <<= 0
                p_kg += 1
                if p_kg == k_groups:
                    p_kg <<= 0
                    p_need_q <<= 1
                    p_qm <<= 1 - p_qm
                    p_sm += 1
                    if p_sm == GROUP_CACHE:
                        p_sm <<= 0
                    p_local_mt += 1
                    p_m0 += TILE_M
                    if p_local_mt == tiles_m_per_b:
                        p_local_mt <<= 0
                        p_m0 <<= 0
                        p_batch += 1
                        p_q_base += MQ
                        p_kv_base += N

                # Queue K[next] before V[current]. The next producer can start
                # from K0 as soon as its head transfer is ready, while the rest
                # of this MTE2 sequence overlaps the current consumer's PV work.
                if step + 1 < my_tasks:
                    nk_n0 = Var(p_kg * GROUP_N)
                    nk_valid_n0 = Min(TILE_N, N - nk_n0)
                    nk_n1 = Var(nk_n0 + TILE_N)
                    nk_valid_n1 = Min(TILE_N, Max(N - nk_n1, 0))
                    nk_n2 = Var(nk_n1 + TILE_N)
                    nk_valid_n2 = Min(TILE_N, Max(N - nk_n2, 0))
                    l1k0[step + 1][0:nk_valid_n0, 0:D] <<= (
                        k_hif8[p_kv_base + nk_n0:p_kv_base + nk_n0 + nk_valid_n0, 0:D]
                    )
                    if nk_valid_n1 > 0:
                        l1k1[step + 1][0:nk_valid_n1, 0:D] <<= (
                            k_hif8[p_kv_base + nk_n1:p_kv_base + nk_n1 + nk_valid_n1, 0:D]
                        )
                    if nk_valid_n2 > 0:
                        l1k2[step + 1][0:nk_valid_n2, 0:D] <<= (
                            k_hif8[p_kv_base + nk_n2:p_kv_base + nk_n2 + nk_valid_n2, 0:D]
                        )

            if step >= GROUP_PRELOAD:
                c_n0 = Var(c_kg * GROUP_N)
                lag_valid_m = Min(TILE_M, MQ - c_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                v_rows0 = Min(TILE_N, N - c_n0)
                lag_n1 = Var(c_n0 + TILE_N)
                v_rows1 = Min(TILE_N, Max(N - lag_n1, 0))
                lag_n2 = Var(lag_n1 + TILE_N)
                v_rows2 = Min(TILE_N, Max(N - lag_n2, 0))

                # Only one PV result is emitted per logical group. Two L0C
                # slots let the following PV MMAD overlap the previous FixP.
                pv_l0c_reusable.wait()
                p_mutex.wait()
                if v_rows0 == TILE_N:
                    matmul(l0c_pv[c_lag],
                           l1p0[c_lag].T, l1v0[c_lag].T,
                           m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                else:
                    matmul(l0c_pv[c_lag],
                           l1p0[c_lag].T, l1v0[c_lag].T,
                           m=TILE_M, n=D_HEAD, k=v_rows0, is_init=True)
                p_mutex.free()
                # P1 always owns the second ring token, including a dummy beat
                # for tails no longer than 128 keys.
                p_mutex.wait()
                if v_rows1 > 0:
                    if v_rows1 == TILE_N:
                        matmul(l0c_pv[c_lag],
                               l1p1[c_lag].T, l1v1[c_lag].T,
                               m=TILE_M, n=D_HEAD, k=TILE_N, is_init=False)
                    else:
                        matmul(l0c_pv[c_lag],
                               l1p1[c_lag].T, l1v1[c_lag].T,
                               m=TILE_M, n=D_HEAD, k=v_rows1, is_init=False)
                p_mutex.free()
                p_mutex.wait()
                if v_rows2 > 0:
                    if v_rows2 == TILE_N:
                        matmul(l0c_pv[c_lag],
                               l1p2[c_lag].T, l1v2[c_lag].T,
                               m=TILE_M, n=D_HEAD, k=TILE_N, is_init=False)
                    else:
                        # Partial P/V accumulate paths must not read padded key
                        # rows: a full-K accumulate can introduce NaNs even when
                        # both L1 operands were explicitly zero-filled.
                        matmul(l0c_pv[c_lag],
                               l1p2[c_lag].T, l1v2[c_lag].T,
                               m=TILE_M, n=D_HEAD, k=v_rows2, is_init=False)
                p_mutex.free()
                l0c_mmad_ready.set()

                pv_mutex.lock()
                l0c_mmad_ready.wait()
                l0c_to_ub(ub_pv[c_lag], l0c_pv[c_lag],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_l0c_reusable.set()
                pv_mutex.ready()
                pv_mutex.wait()

                if c_kg == 0:
                    boundary_store_done.wait()
                    # The first PV overwrites every accumulator element.
                    accum_pv_first_vf(ub_accum, ub_pv[c_lag])
                elif c_lag == 0:
                    boundary_store_done.wait()
                    accum_pv_first_vf(ub_accum, ub_pv[c_lag])
                else:
                    accum_pv_fp16ow_vf(ub_accum, ub_pv[c_lag], ub_old_weight[c_lag])
                pv_mutex.free()

                if c_kg == k_groups - 1:
                    if c_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= (
                                ub_accum[0:local_rows, 0:D_HEAD]
                            )
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= (
                                ub_rmax[c_sm][0:1, 0:local_rows]
                            )
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= (
                                ub_rsum[c_sm][0:1, 0:local_rows]
                            )
                        boundary_store_done.set()
                    else:
                        final_div_fp16rsum_vf(ub_accum, ub_rsum[c_sm], ub_out)
                        if local_rows > 0:
                            out[c_q_base + c_m0 + row_begin:
                                c_q_base + c_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )
                        boundary_store_done.set()

                if c_lag + 1 == my_tasks:
                    if c_kg != k_groups - 1:
                        if c_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= (
                                    ub_accum[0:local_rows, 0:D_HEAD]
                                )
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= (
                                    ub_rmax[c_sm][0:1, 0:local_rows]
                                )
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= (
                                    ub_rsum[c_sm][0:1, 0:local_rows]
                                )
                            boundary_store_done.set()

                c_lag += 1
                c_kg += 1
                if c_kg == k_groups:
                    c_kg <<= 0
                    c_mt += 1
                    c_sm += 1
                    if c_sm == GROUP_CACHE:
                        c_sm <<= 0
                    c_local_mt += 1
                    c_m0 += TILE_M
                    if c_local_mt == tiles_m_per_b:
                        c_local_mt <<= 0
                        c_m0 <<= 0
                        c_batch += 1
                        c_q_base += MQ
                        c_kv_base += N

            # Refill V only after the consumer has retired the same modulo-3
            # slot. The first two iterations prime V0/V1; every steady
            # iteration consumes one old group and then queues one future group.
            if vl_lag < my_tasks:
                vl_n0 = Var(vl_kg * GROUP_N)
                vl_rows0 = Min(TILE_N, N - vl_n0)
                vl_n1 = Var(vl_n0 + TILE_N)
                vl_rows1 = Min(TILE_N, Max(N - vl_n1, 0))
                vl_n2 = Var(vl_n1 + TILE_N)
                vl_rows2 = Min(TILE_N, Max(N - vl_n2, 0))
                l1v0[vl_lag][0:vl_rows0, 0:D] <<= (
                    v_hif8[vl_kv_base + vl_n0:vl_kv_base + vl_n0 + vl_rows0, 0:D]
                )
                if vl_rows1 > 0:
                    l1v1[vl_lag][0:vl_rows1, 0:D] <<= (
                        v_hif8[vl_kv_base + vl_n1:vl_kv_base + vl_n1 + vl_rows1, 0:D]
                    )
                if vl_rows2 > 0:
                    l1v2[vl_lag][0:vl_rows2, 0:D] <<= (
                        v_hif8[vl_kv_base + vl_n2:vl_kv_base + vl_n2 + vl_rows2, 0:D]
                    )
                vl_lag += 1
                vl_kg += 1
                if vl_kg == k_groups:
                    vl_kg <<= 0
                    vl_local_mt += 1
                    if vl_local_mt == tiles_m_per_b:
                        vl_local_mt <<= 0
                        vl_kv_base += N

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for boundary_core in range(1, MAX_CORE_COUNT, name="gscan"):
        if core_count > boundary_core:
            boundary = Var(boundary_core * tasks_floor + Min(boundary_core, tasks_extra))
            if boundary % k_groups != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_groups
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                fd_merge_fp16_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                                 ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                boundary_store_done.wait()
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
                boundary_store_done.set()
    # `preset=True` is released by the generated SEvent destructor.  Keep the
    # final store token for that implicit wait; draining it here deadlocks A5.
    return out


@kernel()
def pfa_fd_v9_allhif8_kernel(q: GMTensor, k: GMTensor, v: GMTensor,
                            out: GMTensor, B: Var, MQ: Var, N: Var, D: Var):
    cv0 = CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                  src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    cv1 = CvMutex(1, depth=1, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                  src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    pv_mutex = CvMutex(2, depth=2,
                       src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                       src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(3, depth=P_EVENT_DEPTH,
                      src_start_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1,
                      src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    qk0_l0c_reusable = SEvent(Pipe.FIX, Pipe.M, preset=True, name="qk02_l0c_reusable")
    qk1_l0c_reusable = SEvent(Pipe.FIX, Pipe.M, preset=True, name="qk1_l0c_reusable")
    pv_l0c_reusable = DEvent(Pipe.FIX, Pipe.M, preset=True, name="pv_l0c_reusable")
    l0c_mmad_ready = QEvent(Pipe.M, Pipe.FIX, name="l0c_mmad_ready")
    boundary_store_done = SEvent(Pipe.MTE3, Pipe.V, preset=True, name="boundary_store_done")
    return _group384_body(q, k, v, out, B, MQ, N, D, cv0, cv1, pv_mutex, p_mutex,
                          qk0_l0c_reusable, qk1_l0c_reusable, qk0_l0c_reusable,
                          pv_l0c_reusable, l0c_mmad_ready,
                          boundary_store_done)


def main():
    torch.manual_seed(0)
    batch_count = int(os.environ.get("PV_B", "1"))
    query_heads = int(os.environ.get("PV_HQ", "1"))
    query_seq = int(os.environ.get("PV_SQ", "257"))
    kv_seq = int(os.environ.get("PV_SKV", "528"))
    if kv_seq <= 0:
        raise SystemExit("V9 all-HIF8 PFA requires PV_SKV > 0")
    mq = query_heads * query_seq
    q_fp32 = torch.randn((batch_count * mq, D_HEAD), dtype=torch.float32)
    k_fp32 = torch.randn((batch_count * kv_seq, D_HEAD), dtype=torch.float32)
    v_fp32 = torch.randn((batch_count * kv_seq, D_HEAD), dtype=torch.float32)
    q = fp32_to_hif8(q_fp32)
    k = fp32_to_hif8(k_fp32)
    v = fp32_to_hif8(v_fp32)
    out = torch.zeros((batch_count * mq, D_HEAD), dtype=torch.bfloat16)

    tiles_m_per_b = (mq + TILE_M - 1) // TILE_M
    k_groups = (kv_seq + GROUP_N - 1) // GROUP_N
    total_blocks = batch_count * tiles_m_per_b
    last_group_valid = kv_seq - (k_groups - 1) * GROUP_N
    mode = os.environ.get("PV_MODE", "sim")
    sim_cores = int(os.environ.get("PV_SIM_CORES", "1"))
    launch_cores = sim_cores if mode in ("sim", "cannsim") else MAX_CORE_COUNT
    profile = os.environ.get("PV_PROFILE", "0") == "1"
    ok, max_owners, split_blocks = _remainder_first_pairwise_split_ok(
        total_blocks, k_groups, launch_cores
    )
    if not ok:
        raise SystemExit("pairwise split precondition failed: max_owners={}".format(max_owners))

    pfa_fd_v9_allhif8_kernel._simulator_config = SimulatorConfig(
        core_count=sim_cores, execution_timeout_s=3600.0
    )
    out_dir = os.environ.get("PV_OUT_DIR") or "./tmp/v9_allhif8_{}".format(mode)
    cann_path = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, out, batch_count, mq, kv_seq, D_HEAD)
    shape_bindings = {
        0: [1 if batch_count == 1 else None, 3],
        1: [2 if batch_count == 1 else None, 3],
        2: [2 if batch_count == 1 else None, 3],
        3: [1 if batch_count == 1 else None, 3],
    }

    print("PFA-V9-ALLHIF8-A5: B={} HQ={} SQ={} SKV={} blocks={} groups={} tail={} cores={} split={}".format(
        batch_count, query_heads, query_seq, kv_seq, total_blocks, k_groups,
        last_group_valid, launch_cores, split_blocks
    ))
    if mode == "sim":
        outs = OpExec(pfa_fd_v9_allhif8_kernel, out_dir=out_dir, simulator=True)(
            *args, shape_bindings=shape_bindings
        )
    elif mode == "cannsim":
        outs = OpExec(
            pfa_fd_v9_allhif8_kernel,
            out_dir=out_dir,
            cann_path=cann_path,
            custom_op_path=os.path.abspath(os.path.join(out_dir, "custom_opp")),
            simulator=False,
            cannsim=True,
        )(*args, shape_bindings=shape_bindings)
    elif mode == "hw":
        outs = OpExec(
            pfa_fd_v9_allhif8_kernel,
            out_dir=out_dir,
            cann_path=cann_path,
            custom_op_path=os.path.abspath(os.path.join(out_dir, "custom_opp")),
            simulator=False,
            debug=False,
            profile=profile,
        )(*args, shape_bindings=shape_bindings)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")

    output = torch.as_tensor(outs).float()
    q_ref = hif8_to_fp32(q)
    k_ref = hif8_to_fp32(k)
    v_ref = hif8_to_fp32(v)
    reference = _v6._ref_mqa(q_ref, k_ref, v_ref, batch_count, query_heads, query_seq, kv_seq)
    max_err, mean_err = _v6._err(output, reference.to(torch.bfloat16).float())
    print("|O| max={:.3f}".format(output.abs().max().item()))
    print("O vs fp32 ref:     max/mean abs err: {:.3e} {:.3e}".format(max_err, mean_err))
    if os.environ.get("PV_DIAG_ROWS", "0") == "1":
        ref_bf16 = reference.to(torch.bfloat16).float()
        for row0 in _pyrange(0, mq, ROWS_PER_SB):
            row1 = min(row0 + ROWS_PER_SB, mq)
            slab_err = (output[row0:row1] - ref_bf16[row0:row1]).abs()
            print("rows[{}:{}] |O|={:.3e} err max/mean={:.3e}/{:.3e}".format(
                row0, row1, output[row0:row1].abs().max().item(),
                slab_err.max().item(), slab_err.mean().item()
            ))
    max_allowed = float(os.environ.get("PV_MAX_ABS_ERR", "0.05"))
    if not torch.isfinite(output).all().item():
        raise RuntimeError("V9 all-HIF8 output contains non-finite values")
    if max_err > max_allowed:
        raise RuntimeError("V9 all-HIF8 max abs error {:.6e} exceeds {:.6e}".format(
            max_err, max_allowed
        ))


if __name__ == "__main__":
    main()
