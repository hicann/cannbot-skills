# a2 conv compute samples (load3d img2col path)

fp16 conv2d kernels built on the `Conv2D` descriptor + `img2col` view +
`conv2d` shortcut. conv2d() is matmul-scope (L1 -> L0 -> mmad -> L0C, one M
tile); the kernels own GM->L1 (incl. flat ND bias rows), the m loop, the
multicore If gate, and the NZ store (`l0c_to_gm_nz2nz`, plane [C1o*M_pad, C0]
== NC1HWC0). Host does all transdata; no device transdata.

| sample | shape | covers |
| --- | --- | --- |
| `conv_half_basic.py` | 32→32ch, 8×8, 3×3 same-pad | minimal end-to-end |
| `conv_half_bias.py` | 31→47ch prime, 8×8, 3×3 | BT/C2 bias contract, C/N zero-pad tails |
| `conv_half_dilation.py` | 16→32ch, 8×8, dilation 2, stride 2 | dilation/stride metadata, downsampling |
| `conv_half_large.py` | 2×32×64×64 → 64ch, 4×4, pads (1,2,1,2) | 256KB fmap, multi-K-tile, 20-core M split, per-batch reload, asymmetric pad (910B3 @10.5 µs/batch hand-tuned baseline) |

Run (each script):

```bash
PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python <sample>.py          # python simulator
PYTHONPATH=<repo> TORCH_DEVICE_BACKEND_AUTOLOAD=0 python <sample>.py --debug  # debug workspace on a 910B3 box
```

Simulator: multi-tile loops without DBuff are fine (depth-1 events fold per
anonymous L0 buffer across If gates; see `testcases/codegen/core/
test_autosync_anon_scope.py`). `conv_half_large` shrinks to 16x16 in sim purely
for speed; the load3d golden is vectorized torch (index grids + masked gather).
