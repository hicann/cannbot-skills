"""Directional PFA probe: hv2 fp16 softmax with BF16-style NZ P publish.

This probe records a non-promoted direction. It tests whether hv2 can avoid the
fragmented nd2nz P-store without using the earlier per-key NZ store:

* QK L0C->UB uses four SINGLE fixpipe copies per cube tile. Each vector
  sub-block sees ub_score as [64, 128], where each row packs key i in the low
  64 lanes and key i+64 in the high 64 lanes.
* The fp16 softmax VF therefore follows the original BF16 two-key pack shape.
  A half->hif8 cast leaves values in even hif8 lanes; one DeInterleave compacts
  both key halves into the low half of a hif8 register, and one strided
  reg_to_ub writes the pair into an NZ-source UB tile.
* P is published to L1 with two bulk ub_to_l1_nz transfers via ub_p.nz(), just
  like the original BF16 PFA path.
"""
import builtins
import os

import torch

if os.environ.get("EASYASC_TARGET", "a5pr") == "a5":
    from easyasc.a5 import *
else:
    from easyasc.a5pr import *
from easyasc.simulator.config import SimulatorConfig

from pfa_fd_hif8_probe_common import (
    _CacheBuf,
    _err,
    _pairwise_split_ok,
    _ref_mqa,
    accum_pv_first_vf,
    accum_pv_fp16ow_vf,
    fd_merge_fp16_vf,
    final_div_fp16rsum_vf,
    init_accum_vf,
    init_softmax_half_vf,
    output_cast_vf,
    CACHE,
    D_HEAD,
    HALF,
    MAX_CORE_COUNT,
    MAX_FD_WS,
    NEG_LARGE_H,
    PRELOAD_N,
    QLANES,
    ROWS_PER_SB,
    SOFTMAX_SCALE,
    TILE_M,
    TILE_N,
    UNROLL,
    fp32_to_hif8,
    hif8_to_fp32,
)

_pyrange = builtins.range

CHUNKS_D = D_HEAD // 64
CD = CHUNKS_D
FRAC_STRIDE = HALF + 1
NZ_C0 = 32
RB_PAIR = HALF // UNROLL
M_Q = ROWS_PER_SB


@func()
def _qk_bridge_pair64_hv2(ub_dst, l0c_src, l0c_scale):
    """Arrange score as 64 rows of key-pairs: [key i lanes | key i+64 lanes].

    Each SINGLE store targets one vector sub-block. The first two stores fill
    vec0's query lanes, the second two fill vec1's query lanes.
    """
    l0c_to_ub(ub_dst[0:HALF, 0:ROWS_PER_SB], l0c_src[0:HALF, 0:ROWS_PER_SB],
              M=HALF, N=ROWS_PER_SB, N_dst=TILE_N, M_src=TILE_N,
              dual_mode=DualMode.SINGLE, sub_block_id=0, scale=l0c_scale)
    l0c_to_ub(ub_dst[0:HALF, ROWS_PER_SB:TILE_N], l0c_src[HALF:TILE_N, 0:ROWS_PER_SB],
              M=HALF, N=ROWS_PER_SB, N_dst=TILE_N, M_src=TILE_N,
              dual_mode=DualMode.SINGLE, sub_block_id=0, scale=l0c_scale)
    l0c_to_ub(ub_dst[0:HALF, 0:ROWS_PER_SB], l0c_src[0:HALF, ROWS_PER_SB:TILE_M],
              M=HALF, N=ROWS_PER_SB, N_dst=TILE_N, M_src=TILE_N,
              dual_mode=DualMode.SINGLE, sub_block_id=1, scale=l0c_scale)
    l0c_to_ub(ub_dst[0:HALF, ROWS_PER_SB:TILE_N], l0c_src[HALF:TILE_N, ROWS_PER_SB:TILE_M],
              M=HALF, N=ROWS_PER_SB, N_dst=TILE_N, M_src=TILE_N,
              dual_mode=DualMode.SINGLE, sub_block_id=1, scale=l0c_scale)


@vf()
def softmax_half_pair_nz_vf(ub_h: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                            ub_old_weight: Tensor):
    sreg = RegList(DT.half, UNROLL)
    acc = RegList(DT.half, UNROLL)
    preg = RegList(DT.half, UNROLL)
    p_h = RegList(DT.hif8, UNROLL)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="ph_pair_hif8")
    hmask = MaskReg(DT.hif8, init_mode=MaskType.LOWHALF)
    pk = Reg(DT.hif8)
    dummy = Reg(DT.hif8)
    neg = Reg(DT.half)
    block_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    t = Reg(DT.half)
    swap = Reg(DT.half)
    v_pmax = Reg(DT.half)
    v_nmax = Reg(DT.half)
    v_oldw = Reg(DT.half)
    v_psum = Reg(DT.half)
    v_nsum = Reg(DT.half)

    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    neg <<= NEG_LARGE_H
    for u in unroll(UNROLL):
        acc[u] <<= neg
    for rb in range(RB_PAIR, name="mxp"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            acc[u] <<= acc[u].vmax(sreg[u])
    block_max <<= acc[0].vmax(acc[1])
    t <<= acc[2].vmax(acc[3])
    block_max <<= block_max.vmax(t)
    gather(swap, block_max, idxu)
    block_max <<= block_max.vmax(swap)
    v_pmax <<= ub_rmax[0:1, 0:TILE_N]
    v_nmax <<= block_max.vmax(v_pmax)
    sub(v_oldw, v_pmax, v_nmax)
    exp(v_oldw, v_oldw)

    for u in unroll(UNROLL):
        acc[u] <<= 0.0
    for rb in range(RB_PAIR, name="exp"):
        for u in unroll(UNROLL):
            sreg[u] <<= ub_h[(rb * UNROLL + u):(rb * UNROLL + u) + 1, :]
            sub(preg[u], sreg[u], v_nmax)
            exp(preg[u], preg[u])
            acc[u] <<= acc[u] + preg[u]
            cast(p_h[u], preg[u], cfg_i)
        for u in unroll(UNROLL):
            deinterleave(pk, dummy, p_h[u], p_h[u])
            reg_to_ub(ub_p[(rb * UNROLL + u) * NZ_C0], pk, FRAC_STRIDE, mask=hmask)

    block_sum <<= acc[0] + acc[1]
    t <<= acc[2] + acc[3]
    block_sum <<= block_sum + t
    gather(swap, block_sum, idxu)
    block_sum <<= block_sum + swap
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:TILE_N]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= v_nmax
    ub_rsum[0:1, 0:TILE_N] <<= v_nsum
    ub_old_weight[0:1, 0:TILE_N] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def softmax_half_pair_nz_tail_vf(ub_h: Tensor, ub_rmax: Tensor, ub_rsum: Tensor, ub_p: Tensor,
                                 ub_old_weight: Tensor, valid_n: Var):
    s = Reg(DT.half)
    e = Reg(DT.half)
    neg = Reg(DT.half)
    block_max = Reg(DT.half)
    block_sum = Reg(DT.half)
    p_hif8 = Reg(DT.hif8)
    pk = Reg(DT.hif8)
    dummy = Reg(DT.hif8)
    rowmask = MaskReg(DT.half, init_mode=MaskType.ALL)
    hmask = MaskReg(DT.hif8, init_mode=MaskType.LOWHALF)
    cfg_i = CastConfig(round_mode=RoundMode.AWAY_FROM_ZERO, reg_layout=RegLayout.ZERO, name="ph_pair_tail_i")
    v_pmax = Reg(DT.half)
    v_nmax = Reg(DT.half)
    v_oldw = Reg(DT.half)
    v_psum = Reg(DT.half)
    v_nsum = Reg(DT.half)

    idx16 = Reg(DT.int16)
    arange(idx16, 0)
    swp64 = Reg(DT.int16)
    swp64 <<= QLANES
    vxor(idx16, idx16, swp64)
    idxu = idx16.reinterpret(DT.uint16)

    block_max <<= NEG_LARGE_H
    neg <<= NEG_LARGE_H
    for i in range(HALF, name="tmax"):
        cnt = Var(QLANES * Min(Max(valid_n - i, 0), 1)
                  + QLANES * Min(Max(valid_n - (i + HALF), 0), 1), dtype=DT.uint32)
        s <<= ub_h[i:i + 1, :]
        update_mask(rowmask, cnt)
        select(s, s, neg, mask=rowmask)
        block_max <<= block_max.vmax(s)
    gather(e, block_max, idxu)
    block_max <<= block_max.vmax(e)
    v_pmax <<= ub_rmax[0:1, 0:TILE_N]
    v_nmax <<= block_max.vmax(v_pmax)
    sub(v_oldw, v_pmax, v_nmax)
    exp(v_oldw, v_oldw)

    block_sum <<= 0.0
    for i in range(HALF, name="texp"):
        cnt = Var(QLANES * Min(Max(valid_n - i, 0), 1)
                  + QLANES * Min(Max(valid_n - (i + HALF), 0), 1), dtype=DT.uint32)
        s <<= ub_h[i:i + 1, :]
        update_mask(rowmask, cnt)
        select(s, s, neg, mask=rowmask)
        sub(e, s, v_nmax)
        exp(e, e)
        block_sum <<= block_sum + e
        cast(p_hif8, e, cfg_i)
        deinterleave(pk, dummy, p_hif8, p_hif8)
        reg_to_ub(ub_p[i * NZ_C0], pk, FRAC_STRIDE, mask=hmask)

    gather(e, block_sum, idxu)
    block_sum <<= block_sum + e
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    v_psum <<= ub_rsum[0:1, 0:TILE_N]
    v_nsum <<= v_psum * v_oldw
    v_nsum <<= v_nsum + block_sum
    ub_rmax[0:1, 0:TILE_N] <<= v_nmax
    ub_rsum[0:1, 0:TILE_N] <<= v_nsum
    ub_old_weight[0:1, 0:TILE_N] <<= v_oldw
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@func()
def _hv2_pair64_nz_probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, p_mutex):
    q_hif8 = q.reinterpret(DT.hif8, name="q_hif8")
    k_hif8 = k.reinterpret(DT.hif8, name="k_hif8")
    v_hif8 = v.reinterpret(DT.hif8, name="v_hif8")

    l1q = DBuff(DT.hif8, [TILE_M, D_HEAD], Position.L1)
    l1k = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1v = _CacheBuf(DT.hif8, [TILE_N, D_HEAD], Position.L1)
    l1p = _CacheBuf(DT.hif8, [TILE_N, TILE_M], Position.L1)
    l0c_qk = DBuff(DT.float, [TILE_M, TILE_M], Position.L0C)
    l0c_pv = DBuff(DT.float, [TILE_M, D_HEAD], Position.L0C)
    ub_score = DBuff(DT.half, [HALF, TILE_N], Position.UB)
    ub_pv = DBuff(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_p = Tensor(DT.hif8, [FRAC_STRIDE, 2 * ROWS_PER_SB], Position.UB)
    ub_old_weight = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_rmax = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_rsum = _CacheBuf(DT.half, [1, TILE_N], Position.UB)
    ub_merge_a = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_merge_den = Tensor(DT.float, [1, TILE_M], Position.UB)
    ub_accum = Tensor(DT.float, [ROWS_PER_SB, D_HEAD], Position.UB)
    ub_out = Tensor(DT.bfloat16, [ROWS_PER_SB, D_HEAD], Position.UB)

    fd_accum = split_workspace(DT.float, [MAX_FD_WS, TILE_M, D_HEAD], name="fd_accum")
    fd_max = split_workspace(DT.half, [MAX_FD_WS, 1, TILE_M], name="fd_max")
    fd_sum = split_workspace(DT.half, [MAX_FD_WS, 1, TILE_M], name="fd_sum")

    core = Var(GetCubeIdx())
    core_count = Var(GetCubeNum())
    vec = Var(GetVecIdx())
    row_begin = Var(GetSubBlockIdx() * ROWS_PER_SB)
    tiles_m_per_b = CeilDiv(MQ, TILE_M)
    k_tiles = CeilDiv(N, TILE_N)
    total_blocks = Var(B * tiles_m_per_b)
    total_tasks = Var(total_blocks * k_tiles)
    flat_start = Var(total_tasks * core // core_count)
    flat_end = Var(total_tasks * (core + 1) // core_count)
    my_tasks = Var(Max(flat_end - flat_start, 0))

    tail_ws = Var(-1, DT.int)
    head_ws = Var(-1, DT.int)
    split_count = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if core == b:
                    tail_ws <<= split_count * 2 + 1
                if core + 1 == b:
                    head_ws <<= split_count * 2
                split_count += 1

    for _vi in _pyrange(CACHE):
        set_constant_to_l1(l1v[_vi].reinterpret(DT.uint8), 0)

    with auto_sync():
        prefix_mt = Var(-1, DT.int)
        suffix_mt = Var(-1, DT.int)
        if my_tasks > 0:
            start_k = Var(flat_start % k_tiles)
            if start_k != 0:
                prefix_mt <<= flat_start // k_tiles
            end_k = Var(flat_end % k_tiles)
            if end_k != 0:
                suffix_mt <<= (flat_end - 1) // k_tiles

        for step in range(0, my_tasks + PRELOAD_N):
            if step < my_tasks:
                t = Var(flat_start + step)
                mt = Var(t // k_tiles)
                kt = Var(t % k_tiles)
                qm = Var(mt % 2)
                sm = Var(mt % CACHE)
                batch = Var(mt // tiles_m_per_b)
                local_mt = Var(mt % tiles_m_per_b)
                q_base = Var(batch * MQ)
                kv_base = Var(batch * N)
                m0 = Var(local_mt * TILE_M)
                valid_m = Min(TILE_M, MQ - m0)
                n0 = Var(kt * TILE_N)
                valid_n = Min(TILE_N, N - n0)

                need_q = Var(0, DT.int)
                if kt == 0:
                    need_q <<= 1
                if step == 0:
                    need_q <<= 1
                if need_q > 0:
                    l1q[qm][0:valid_m, 0:D] <<= q_hif8[q_base + m0:q_base + m0 + valid_m, 0:D]
                    init_softmax_half_vf(ub_rmax[sm], ub_rsum[sm])

                l1k[step][0:valid_n, 0:D] <<= k_hif8[kv_base + n0:kv_base + n0 + valid_n, 0:D]
                matmul(l0c_qk[step], l1k[step], l1q[qm],
                       m=TILE_N, n=TILE_M, k=D_HEAD, is_init=True)

                cv.lock()
                _qk_bridge_pair64_hv2(ub_score[step], l0c_qk[step], SOFTMAX_SCALE)
                cv.ready()
                cv.wait()
                if valid_n < TILE_N:
                    softmax_half_pair_nz_tail_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm],
                                                 ub_p, ub_old_weight[step], valid_n)
                else:
                    softmax_half_pair_nz_vf(ub_score[step], ub_rmax[sm], ub_rsum[sm],
                                            ub_p, ub_old_weight[step])
                cv.free()

                p_mutex.lock()
                l1p[step][0:HALF, row_begin:row_begin + ROWS_PER_SB] <<= ub_p.nz()[0:HALF, 0:ROWS_PER_SB]
                l1p[step][HALF:TILE_N, row_begin:row_begin + ROWS_PER_SB] <<= (
                    ub_p.nz()[0:HALF, ROWS_PER_SB:2 * ROWS_PER_SB]
                )
                p_mutex.ready()

            if step >= PRELOAD_N:
                lag = Var(step - PRELOAD_N)
                lag_t = Var(flat_start + lag)
                lag_mt = Var(lag_t // k_tiles)
                lag_kt = Var(lag_t % k_tiles)
                sm2 = Var(lag_mt % CACHE)
                lag_batch = Var(lag_mt // tiles_m_per_b)
                lag_local_mt = Var(lag_mt % tiles_m_per_b)
                lag_q_base = Var(lag_batch * MQ)
                lag_kv_base = Var(lag_batch * N)
                lag_m0 = Var(lag_local_mt * TILE_M)
                lag_valid_m = Min(TILE_M, MQ - lag_m0)
                local_rows = Min(ROWS_PER_SB, Max(lag_valid_m - row_begin, 0))
                lag_n0 = Var(lag_kt * TILE_N)
                v_rows = Min(TILE_N, N - lag_n0)

                l1v[lag][0:v_rows, 0:D] <<= v_hif8[lag_kv_base + lag_n0:lag_kv_base + lag_n0 + v_rows, 0:D]
                p_mutex.wait()
                matmul(l0c_pv[lag][0:TILE_M, 0:D_HEAD], l1p[lag].T, l1v[lag].T,
                       m=TILE_M, n=D_HEAD, k=TILE_N, is_init=True)
                p_mutex.free()

                pv_mutex.lock()
                l0c_to_ub(ub_pv[lag], l0c_pv[lag][0:TILE_M, 0:D_HEAD],
                          M=TILE_M, N=D_HEAD, N_dst=D_HEAD, M_src=TILE_M,
                          dual_mode=DualMode.SPLITM, sub_block_id=0)
                pv_mutex.ready()
                pv_mutex.wait()

                if lag_kt == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                elif lag == 0:
                    init_accum_vf(ub_accum)
                    accum_pv_first_vf(ub_accum, ub_pv[lag])
                else:
                    accum_pv_fp16ow_vf(ub_accum, ub_pv[lag], ub_old_weight[lag])
                pv_mutex.free()

                if lag_kt == k_tiles - 1:
                    if lag_mt == prefix_mt:
                        if local_rows > 0:
                            fd_accum[tail_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= (
                                ub_accum[0:local_rows, 0:D_HEAD]
                            )
                            fd_max[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= (
                                ub_rmax[sm2][0:1, 0:local_rows]
                            )
                            fd_sum[tail_ws, 0:1, row_begin:row_begin + local_rows] <<= (
                                ub_rsum[sm2][0:1, 0:local_rows]
                            )
                    else:
                        final_div_fp16rsum_vf(ub_accum, ub_rsum[sm2], ub_out)
                        if local_rows > 0:
                            out[lag_q_base + lag_m0 + row_begin:lag_q_base + lag_m0 + row_begin + local_rows, 0:D] <<= (
                                ub_out[0:local_rows, 0:D]
                            )

                if lag + 1 == my_tasks:
                    if lag_kt != k_tiles - 1:
                        if lag_mt == suffix_mt:
                            if local_rows > 0:
                                fd_accum[head_ws, row_begin:row_begin + local_rows, 0:D_HEAD] <<= (
                                    ub_accum[0:local_rows, 0:D_HEAD]
                                )
                                fd_max[head_ws, 0:1, row_begin:row_begin + local_rows] <<= (
                                    ub_rmax[sm2][0:1, 0:local_rows]
                                )
                                fd_sum[head_ws, 0:1, row_begin:row_begin + local_rows] <<= (
                                    ub_rsum[sm2][0:1, 0:local_rows]
                                )

        allvec_ready(7, Pipe.MTE3)

    allvec_wait(7, Pipe.MTE2)

    fd_task = Var(vec // 2)
    fd_row0 = Var((vec % 2) * ROWS_PER_SB)
    fd_found = Var(0, DT.int)
    fd_mt = Var(0, DT.int)
    scan_rank = Var(0, DT.int)
    for b in range(1, MAX_CORE_COUNT):
        if core_count > b:
            boundary = Var(total_tasks * b // core_count)
            if boundary % k_tiles != 0:
                if scan_rank == fd_task:
                    fd_found <<= 1
                    fd_mt <<= boundary // k_tiles
                scan_rank += 1

    if fd_found > 0:
        fd_batch = Var(fd_mt // tiles_m_per_b)
        fd_local_mt = Var(fd_mt % tiles_m_per_b)
        fd_q_base = Var(fd_batch * MQ)
        fd_m0 = Var(fd_local_mt * TILE_M)
        fd_valid_m = Min(TILE_M, MQ - fd_m0)
        fd_rows = Min(ROWS_PER_SB, Max(fd_valid_m - fd_row0, 0))
        fd_lo = Var(fd_task * 2)
        fd_hi = Var(fd_lo + 1)
        if fd_rows > 0:
            with auto_sync():
                ub_rmax[0][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rmax[1][0:1, 0:ROWS_PER_SB] <<= fd_max[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[0][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_lo, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_rsum[1][0:1, 0:ROWS_PER_SB] <<= fd_sum[fd_hi, 0:1, fd_row0:fd_row0 + ROWS_PER_SB]
                ub_pv[0][:, :] <<= fd_accum[fd_lo, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                ub_pv[1][:, :] <<= fd_accum[fd_hi, fd_row0:fd_row0 + ROWS_PER_SB, 0:D_HEAD]
                fd_merge_fp16_vf(ub_pv[0], ub_pv[1], ub_rmax[0], ub_rmax[1],
                                 ub_rsum[0], ub_rsum[1], ub_merge_a, ub_merge_den, ub_pv[0])
                output_cast_vf(ub_pv[0], ub_out)
                out[fd_q_base + fd_m0 + fd_row0:fd_q_base + fd_m0 + fd_row0 + fd_rows, 0:D] <<= (
                    ub_out[0:fd_rows, 0:D]
                )
    return out


@kernel()
def hv2_pair64_nz_probe_kernel(q: GMTensor, k: GMTensor, v: GMTensor, out: GMTensor,
                               B: Var, MQ: Var, N: Var, D: Var):
    cv = CvMutex(0, depth=2, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V,
                 src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    pv_mutex = CvMutex(2, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, depth=CACHE, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    return _hv2_pair64_nz_probe_body(q, k, v, out, B, MQ, N, D, cv, pv_mutex, p_mutex)


def main():
    torch.manual_seed(0)
    B = int(os.environ.get("PV_B", "1"))
    HQ = int(os.environ.get("PV_HQ", "8"))
    SQ = int(os.environ.get("PV_SQ", "257"))
    SKV = int(os.environ.get("PV_SKV", "256"))
    MQ = HQ * SQ
    q_fp32 = torch.randn((B * MQ, D_HEAD), dtype=torch.float32)
    k_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    v_fp32 = torch.randn((B * SKV, D_HEAD), dtype=torch.float32)
    q = fp32_to_hif8(q_fp32)
    k = fp32_to_hif8(k_fp32)
    v = fp32_to_hif8(v_fp32)
    out = torch.zeros((B * MQ, D_HEAD), dtype=torch.bfloat16)

    tiles_m_per_b = (MQ + TILE_M - 1) // TILE_M
    k_tiles = (SKV + TILE_N - 1) // TILE_N
    total_blocks = B * tiles_m_per_b
    mode = os.environ.get("PV_MODE", "sim")
    sim_cores = int(os.environ.get("PV_SIM_CORES", "4"))
    launch_cores = sim_cores if mode == "sim" else MAX_CORE_COUNT
    profile = os.environ.get("PV_PROFILE", "0") == "1"
    debug = os.environ.get("PV_DEBUG", "0") == "1"
    ok, max_owners, split_blocks = _pairwise_split_ok(total_blocks, k_tiles, launch_cores)
    if not ok:
        raise SystemExit("pairwise split precondition failed: max_owners={}".format(max_owners))

    hv2_pair64_nz_probe_kernel._simulator_config = SimulatorConfig(
        core_count=sim_cores, execution_timeout_s=3600.0
    )
    d = os.environ.get("PV_OUT_DIR") or "./tmp/hv2_pair64_nz_probe_{}".format(mode)
    cann = os.environ.get("ASCEND_HOME_PATH", "")
    args = (q, k, v, out, B, MQ, SKV, D_HEAD)
    sb = {0: [1 if B == 1 else None, 3], 1: [2 if B == 1 else None, 3],
          2: [2 if B == 1 else None, 3], 3: [1 if B == 1 else None, 3]}

    print("HV2-PAIR64-NZ-PROBE: B={} HQ={} SQ={} SKV={} blocks={} k_tiles={} cores={} split={}".format(
        B, HQ, SQ, SKV, total_blocks, k_tiles, launch_cores, split_blocks))
    if mode == "sim":
        outs = OpExec(hv2_pair64_nz_probe_kernel, out_dir=d, simulator=True)(*args, shape_bindings=sb)
    elif mode == "cannsim":
        outs = OpExec(hv2_pair64_nz_probe_kernel, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, cannsim=True, debug=debug)(*args, shape_bindings=sb)
    elif mode == "hw":
        outs = OpExec(hv2_pair64_nz_probe_kernel, out_dir=d, cann_path=cann,
                      custom_op_path=os.path.abspath(os.path.join(d, "custom_opp")),
                      simulator=False, debug=False, profile=profile)(*args, shape_bindings=sb)
    else:
        raise SystemExit("PV_MODE must be sim|cannsim|hw")

    O = torch.as_tensor(outs).float()
    if os.environ.get("PV_DUMP_NAN", "0") == "1":
        finite = torch.isfinite(O)
        print("finite={}/{} nan_rows={} nan_cols={}".format(
            int(finite.sum().item()), O.numel(),
            torch.nonzero(~finite.all(dim=1), as_tuple=False).flatten()[:16].tolist(),
            torch.nonzero(~finite.all(dim=0), as_tuple=False).flatten()[:16].tolist(),
        ))
        print("row finite counts first16={}".format(finite[:16].sum(dim=1).tolist()))
        print("O first2x8={}".format(O[:2, :8].tolist()))
    qf = hif8_to_fp32(q)
    kf = hif8_to_fp32(k)
    vf = hif8_to_fp32(v)
    o_ref = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV)
    o_ref_q = _ref_mqa(qf, kf, vf, B, HQ, SQ, SKV, quant_p=True)
    print("|O| max={:.3f}".format(O.abs().max().item()))
    print("O vs fp32 ref:     max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref.to(torch.bfloat16).float())))
    print("O vs hif8-P/V ref: max/mean abs err: {:.3e} {:.3e}".format(*_err(O, o_ref_q)))


if __name__ == "__main__":
    main()
