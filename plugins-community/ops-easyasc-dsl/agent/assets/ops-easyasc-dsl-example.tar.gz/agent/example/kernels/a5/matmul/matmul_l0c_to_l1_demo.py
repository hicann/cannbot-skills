import torch


from easyasc.a5 import *


@kernel()
def matmul_l0c_to_l1_demo_kernel(
    x: GMTensor,
    y: GMTensor,
    z: GMTensor,
    out: GMTensor,
    M: Var,
    N: Var,
    P: Var,
    K: Var,
):
    # test workspace size 
    tmp_work1 = split_workspace(DT.float, [M, N, P])
    tmp_work2 = split_workspace(DT.half, [M, K])

    # test L0C to L1
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l1z = Tensor(DT.half, [P, N], Position.L1)
    l1mid = Tensor(DT.half, [M, N], Position.L1)
    l0c_mid = Tensor(DT.float, [M, N], Position.L0C)
    l0c_out = Tensor(DT.float, [M, P], Position.L0C)
    
    event_fix_mte1 = SEvent(Pipe.FIX, Pipe.MTE1)

    var1 = Var(1.0)

    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        l1z <<= z[:, :]

        matmul(l0c_mid, l1x, l1y, m=M, n=N, k=K, is_init=True)

        # Keep the first matmul result on chip by publishing it from L0C back to L1.
        l1mid <<= l0c_mid

        event_fix_mte1.set()
        event_fix_mte1.wait()

        matmul(l0c_out, l1mid, l1z, m=M, n=P, k=N, is_init=True)
        out[:, :] <<= l0c_out
        kernel_print('var1: %f\n', var1)
    
    kernel_dump_tensor(out, desc=123, dumpSize=16)
    return out


if __name__ == "__main__":
    M = 64
    N = 64
    P = 64
    K = 64

    torch.manual_seed(0)
    x = torch.randn((M, K), dtype=torch.float16) * 0.2
    y = torch.randn((N, K), dtype=torch.float16) * 0.2
    z = torch.randn((P, N), dtype=torch.float16) * 0.2
    out = torch.zeros((M, P), dtype=torch.float32)

    out_kernel = OpExec(matmul_l0c_to_l1_demo_kernel, simulator=True)(
        x, y, z, out, M, N, P, K,
        shape_bindings={0: [0, 3], 1: [1, 3], 2: [2, 1], 3: [0, 2]},
    )
    mid_ref = (x.float() @ y.float().t()).half()
    out_ref = mid_ref.float() @ z.float().t()

    torch.testing.assert_close(out_kernel, out_ref, rtol=1e-3, atol=1e-3)
    print(f"max_abs_diff={torch.abs(out_kernel - out_ref).max().item():.6e}")
