"""End-to-end sim + on-board validation of ub_to_reg_gather / reg_to_ub_scatter
across every hardware-supported data-type / index-type combination.

MicroAPI::DataCopyGather (vgather2) and DataCopyScatter (vscatter) on dav_c310
(Ascend950) support, keyed on the UB byte width (kernel_micro_datacopy_impl.h
DataCopyGather/ScatterImpl static_asserts):

  gather:  b8 src -> b16 dst, u16 idx  (byte ZERO-extend: dst = 0x00<byte>)
           b16 -> b16, u16   |   b32 -> b32, u32   |   b64 -> b64, u32 | u64
  scatter: b8, u16  (EVEN source lanes: flat[idx[k]] = src[2k])
           b16, u16   |   b32, u32   |   b64, u32 | u64

Two b8 runtime semantics are board-verified (2026-07-21) and baked into the golden
below: the b8->b16 gather ZERO-extends the source byte, and the b8 scatter moves
only the EVEN source lanes (src[2k]).

The index is supplied as a host-controlled GM input (a reversed permutation),
loaded into UB and reinterpret-aliased to the unsigned index dtype. This is
dtype-agnostic and isolates the gather/scatter under test on identical sim/board
inputs (it also sidesteps arange entirely -- building the permutation with a
decreasing arange is what first surfaced the arange DECREASE start-convention
codegen bug, now fixed so sim == board).

Run:
- simulator (default): python kernels/a5/vec_only/gather_scatter_onboard.py
- on Ascend950 board:   python kernels/a5/vec_only/gather_scatter_onboard.py --run
"""
import os
import sys

import torch

from easyasc.a5 import *  # noqa: F401,F403  (also shadows builtin range with the DSL range)


# =========================================================================== #
# GATHER kernels: dst[i] = src[idx[i]]   (idx loaded from GM, reinterpret->unsigned)
# =========================================================================== #
@vf()
def gather_b8b16_signed_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint16, name="g8s_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.int16, name="g8s_d")
    ub_to_reg_gather(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gather_b8b16_signed_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.int8, [1, 256], Position.UB, name="g8s_src")
    dst_ub = Tensor(DT.int16, [1, 128], Position.UB, name="g8s_dst")
    idx_s = Tensor(DT.int16, [1, 128], Position.UB, name="g8s_idx_s")
    idx_u = reinterpret(idx_s, DT.uint16, name="g8s_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gather_b8b16_signed_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gather_b8b16_unsigned_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint16, name="g8u_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.uint16, name="g8u_d")
    ub_to_reg_gather(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gather_b8b16_unsigned_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="g8u_src")
    dst_ub = Tensor(DT.uint16, [1, 128], Position.UB, name="g8u_dst")
    idx_s = Tensor(DT.int16, [1, 128], Position.UB, name="g8u_idx_s")
    idx_u = reinterpret(idx_s, DT.uint16, name="g8u_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gather_b8b16_unsigned_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gather_b16_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint16, name="g16_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.half, name="g16_d")
    ub_to_reg_gather(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gather_b16_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.half, [1, 128], Position.UB, name="g16_src")
    dst_ub = Tensor(DT.half, [1, 128], Position.UB, name="g16_dst")
    idx_s = Tensor(DT.int16, [1, 128], Position.UB, name="g16_idx_s")
    idx_u = reinterpret(idx_s, DT.uint16, name="g16_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gather_b16_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gather_b32_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint32, name="g32_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.float, name="g32_d")
    ub_to_reg_gather(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gather_b32_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.float, [1, 64], Position.UB, name="g32_src")
    dst_ub = Tensor(DT.float, [1, 64], Position.UB, name="g32_dst")
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="g32_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="g32_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gather_b32_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gather_b64_u32_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint32, name="g64a_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.int64, name="g64a_d")
    ub_to_reg_gather(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gather_b64_u32_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.int64, [1, 32], Position.UB, name="g64a_src")
    dst_ub = Tensor(DT.int64, [1, 32], Position.UB, name="g64a_dst")
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="g64a_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="g64a_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gather_b64_u32_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def gather_b64_u64_vf(src_ub, dst_ub, idx_u):
    ui = Reg(DT.uint64, name="g64b_ui"); ub_to_reg_normal(ui, idx_u)
    d = Reg(DT.uint64, name="g64b_d")
    ub_to_reg_gather(d, src_ub, ui)
    reg_to_ub_normal(dst_ub, d)


@kernel(mode="vec")
def gather_b64_u64_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.uint64, [1, 32], Position.UB, name="g64b_src")
    dst_ub = Tensor(DT.uint64, [1, 32], Position.UB, name="g64b_dst")
    idx_s = Tensor(DT.int64, [1, 32], Position.UB, name="g64b_idx_s")
    idx_u = reinterpret(idx_s, DT.uint64, name="g64b_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        gather_b64_u64_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


# =========================================================================== #
# SCATTER kernels: flat[idx[k]] = src[k]   (b8: src[2k]); dst pre-zeroed
# =========================================================================== #
@vf()
def scatter_b8_vf(src_ub, dst_ub, idx_u):
    z = Reg(DT.uint8, name="s8_z"); dup(z, 0); reg_to_ub_normal(dst_ub, z)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    sr = Reg(DT.uint8, name="s8_sr"); ub_to_reg_normal(sr, src_ub)
    ui = Reg(DT.uint16, name="s8_ui"); ub_to_reg_normal(ui, idx_u)
    reg_to_ub_scatter(dst_ub, sr, ui)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)


@kernel(mode="vec")
def scatter_b8_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="s8_src")
    dst_ub = Tensor(DT.uint8, [1, 256], Position.UB, name="s8_dst")
    idx_s = Tensor(DT.int16, [1, 128], Position.UB, name="s8_idx_s")
    idx_u = reinterpret(idx_s, DT.uint16, name="s8_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        scatter_b8_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def scatter_b16_vf(src_ub, dst_ub, idx_u):
    z = Reg(DT.half, name="s16_z"); dup(z, 0.0); reg_to_ub_normal(dst_ub, z)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    sr = Reg(DT.half, name="s16_sr"); ub_to_reg_normal(sr, src_ub)
    ui = Reg(DT.uint16, name="s16_ui"); ub_to_reg_normal(ui, idx_u)
    reg_to_ub_scatter(dst_ub, sr, ui)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)


@kernel(mode="vec")
def scatter_b16_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.half, [1, 128], Position.UB, name="s16_src")
    dst_ub = Tensor(DT.half, [1, 128], Position.UB, name="s16_dst")
    idx_s = Tensor(DT.int16, [1, 128], Position.UB, name="s16_idx_s")
    idx_u = reinterpret(idx_s, DT.uint16, name="s16_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        scatter_b16_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def scatter_b32_vf(src_ub, dst_ub, idx_u):
    z = Reg(DT.float, name="s32_z"); dup(z, 0.0); reg_to_ub_normal(dst_ub, z)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    sr = Reg(DT.float, name="s32_sr"); ub_to_reg_normal(sr, src_ub)
    ui = Reg(DT.uint32, name="s32_ui"); ub_to_reg_normal(ui, idx_u)
    reg_to_ub_scatter(dst_ub, sr, ui)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)


@kernel(mode="vec")
def scatter_b32_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.float, [1, 64], Position.UB, name="s32_src")
    dst_ub = Tensor(DT.float, [1, 64], Position.UB, name="s32_dst")
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="s32_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="s32_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        scatter_b32_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def scatter_b64_u32_vf(src_ub, dst_ub, idx_u):
    z = Reg(DT.int64, name="s64a_z"); dup(z, 0); reg_to_ub_normal(dst_ub, z)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    sr = Reg(DT.int64, name="s64a_sr"); ub_to_reg_normal(sr, src_ub)
    ui = Reg(DT.uint32, name="s64a_ui"); ub_to_reg_normal(ui, idx_u)
    reg_to_ub_scatter(dst_ub, sr, ui)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)


@kernel(mode="vec")
def scatter_b64_u32_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.int64, [1, 32], Position.UB, name="s64a_src")
    dst_ub = Tensor(DT.int64, [1, 32], Position.UB, name="s64a_dst")
    idx_s = Tensor(DT.int, [1, 64], Position.UB, name="s64a_idx_s")
    idx_u = reinterpret(idx_s, DT.uint32, name="s64a_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        scatter_b64_u32_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


@vf()
def scatter_b64_u64_vf(src_ub, dst_ub, idx_u):
    z = Reg(DT.uint64, name="s64b_z"); dup(z, 0); reg_to_ub_normal(dst_ub, z)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    sr = Reg(DT.uint64, name="s64b_sr"); ub_to_reg_normal(sr, src_ub)
    ui = Reg(DT.uint64, name="s64b_ui"); ub_to_reg_normal(ui, idx_u)
    reg_to_ub_scatter(dst_ub, sr, ui)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)


@kernel(mode="vec")
def scatter_b64_u64_kernel(src: GMTensor, idx: GMTensor, out: GMTensor, rows: Var):
    src_ub = Tensor(DT.uint64, [1, 32], Position.UB, name="s64b_src")
    dst_ub = Tensor(DT.uint64, [1, 32], Position.UB, name="s64b_dst")
    idx_s = Tensor(DT.int64, [1, 32], Position.UB, name="s64b_idx_s")
    idx_u = reinterpret(idx_s, DT.uint64, name="s64b_idx_u")
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        idx_s[:, :] <<= idx[0:1, :]
        scatter_b64_u64_vf(src_ub, dst_ub, idx_u)
        out[0:1, :] <<= dst_ub
    return out


# --------------------------------------------------------------------------- #
# host inputs + goldens
# --------------------------------------------------------------------------- #
def _rev(n, lanes=None):  # signed int64 [n-1, n-2, ..., 0] padded with 0 to `lanes`
    lanes = lanes or n
    t = torch.zeros(lanes, dtype=torch.int64)
    t[:n] = torch.arange(n - 1, -1, -1, dtype=torch.int64)
    return t


def _gather_cases():
    cases = []
    # b8 -> b16: idx reads the HIGH bytes; zero-extend -> golden == idx value (byte j -> j).
    hi = torch.arange(255, 127, -1, dtype=torch.int64)          # [255..128], 128 lanes
    src8 = torch.arange(256, dtype=torch.int64).remainder(256)
    cases.append(("g.b8b16.int", gather_b8b16_signed_kernel,
                  src8.to(torch.uint8).view(torch.int8).reshape(1, 256),
                  hi.to(torch.int16).reshape(1, 128),                    # idx (signed GM)
                  (src8[hi] & 0xFF).to(torch.int16).reshape(1, 128), 0))
    cases.append(("g.b8b16.uint", gather_b8b16_unsigned_kernel,
                  src8.to(torch.uint8).reshape(1, 256),
                  hi.to(torch.int16).reshape(1, 128),
                  (src8[hi] & 0xFF).to(torch.int64).to(torch.uint16).reshape(1, 128), 0))
    # b16 half
    s16 = torch.arange(128, dtype=torch.float32).to(torch.float16); i16 = _rev(128)
    cases.append(("g.b16.half", gather_b16_kernel, s16.reshape(1, 128),
                  i16.to(torch.int16).reshape(1, 128), s16[i16].reshape(1, 128), 0))
    # b32 float
    s32 = torch.arange(64, dtype=torch.float32); i32 = _rev(64)
    cases.append(("g.b32.float", gather_b32_kernel, s32.reshape(1, 64),
                  i32.to(torch.int32).reshape(1, 64), s32[i32].reshape(1, 64), 0))
    # b64 int64, u32 idx (64 lanes, first 32 used)
    s64 = torch.arange(32, dtype=torch.int64) * 0x100000001; i64a = _rev(32, 64)
    cases.append(("g.b64.i64.u32", gather_b64_u32_kernel, s64.reshape(1, 32),
                  i64a.to(torch.int32).reshape(1, 64), s64[i64a[:32]].reshape(1, 32), 0))
    # b64 uint64, u64 idx (torch CPU lacks uint64 index -> gather in int64 view)
    su_i = torch.arange(32, dtype=torch.int64) * 0x100000007; i64b = _rev(32)
    cases.append(("g.b64.u64.u64", gather_b64_u64_kernel, su_i.to(torch.uint64).reshape(1, 32),
                  i64b.reshape(1, 32), su_i[i64b].to(torch.uint64).reshape(1, 32), 0))
    return cases


def _scatter_cases():
    cases = []
    # b8 even-source: dst(256)=0; dst[idx[k]] = src[2k]; idx reversed [127..0]
    src8 = torch.arange(256, dtype=torch.int64).remainder(256); i = _rev(128)
    d8 = torch.zeros(256, dtype=torch.int64); d8[i] = torch.arange(0, 256, 2, dtype=torch.int64)
    cases.append(("s.b8.even", scatter_b8_kernel, src8.to(torch.uint8).reshape(1, 256),
                  i.to(torch.int16).reshape(1, 128), d8.to(torch.uint8).reshape(1, 256), 0))
    # b16 half
    s16 = torch.arange(128, dtype=torch.float32).to(torch.float16); i16 = _rev(128)
    d16 = torch.zeros(128, dtype=torch.float16); d16[i16] = s16
    cases.append(("s.b16.half", scatter_b16_kernel, s16.reshape(1, 128),
                  i16.to(torch.int16).reshape(1, 128), d16.reshape(1, 128), 0))
    # b32 float
    s32 = torch.arange(64, dtype=torch.float32); i32 = _rev(64)
    d32 = torch.zeros(64, dtype=torch.float32); d32[i32] = s32
    cases.append(("s.b32.float", scatter_b32_kernel, s32.reshape(1, 64),
                  i32.to(torch.int32).reshape(1, 64), d32.reshape(1, 64), 0))
    # b64 int64 u32 idx
    s64 = torch.arange(32, dtype=torch.int64) * 0x100000001; i64a = _rev(32, 64)
    d64 = torch.zeros(32, dtype=torch.int64); d64[i64a[:32]] = s64
    cases.append(("s.b64.i64.u32", scatter_b64_u32_kernel, s64.reshape(1, 32),
                  i64a.to(torch.int32).reshape(1, 64), d64.reshape(1, 32), 0))
    # b64 uint64 u64 idx (golden in int64, reinterpret to uint64)
    su_i = torch.arange(32, dtype=torch.int64) * 0x100000007; i64b = _rev(32)
    du_i = torch.zeros(32, dtype=torch.int64); du_i[i64b] = su_i
    cases.append(("s.b64.u64.u64", scatter_b64_u64_kernel, su_i.to(torch.uint64).reshape(1, 32),
                  i64b.reshape(1, 32), du_i.to(torch.uint64).reshape(1, 32), 0))
    return cases


# --------------------------------------------------------------------------- #
def _opexec(kern, tag, run):
    cfg = dict(simulator=False, debug=False, cann_path=os.environ["ASCEND_HOME_PATH"]) if run \
        else dict(simulator=True)
    safe = "".join(c if c.isalnum() else "_" for c in tag)  # dir name must avoid './>'
    return OpExec(kern, out_dir=os.path.abspath(f"tmp/gather_scatter/{safe}"),
                  custom_op_path=os.path.abspath("tmp/gather_scatter/custom_opp"), **cfg)


def _cmp(mode, tag, got, want, tol, fails):
    got = got.reshape(-1); want = want.reshape(-1)
    if got.is_floating_point():
        ok = torch.allclose(got.float(), want.float(), rtol=tol, atol=tol)
        err = (got.float() - want.float()).abs().max().item()
    else:
        gi = got.view(torch.int64) if got.dtype is torch.uint64 else got.to(torch.int64)
        wi = want.view(torch.int64) if want.dtype is torch.uint64 else want.to(torch.int64)
        ok = bool(torch.equal(gi, wi)); err = 0 if ok else int((gi - wi).abs().max())
    if ok:
        print(f"[{mode}] {tag:16s} OK  (max|err|={err})")
    else:
        gi = got.view(torch.int64) if got.dtype is torch.uint64 else got
        wi = want.view(torch.int64) if want.dtype is torch.uint64 else want
        bad = (gi != wi).nonzero().flatten()[:6].tolist()
        print(f"[{mode}] {tag:16s} MISMATCH max|err|={err} first_bad={bad} "
              f"got[:4]={got.flatten()[:4].tolist()} want[:4]={want.flatten()[:4].tolist()}")
        fails.append(tag)


def main(run, only=None):
    mode = "board" if run else "sim"
    fails, build = [], []
    cases = _gather_cases() + _scatter_cases()
    if only:
        cases = [c for c in cases if c[0] == only]
        if not cases:
            raise SystemExit(f"no case matches --only={only}")
    for tag, kern, src, idx, want, tol in cases:
        try:
            out = torch.zeros_like(want)
            res = _opexec(kern, tag, run)(src.contiguous(), idx.contiguous(), out, 1)
            got = res if isinstance(res, torch.Tensor) else res[0]
            _cmp(mode, tag, got, want, tol, fails)
        except Exception as exc:  # noqa: BLE001
            print(f"[{mode}] {tag:16s} BUILD/RUN-FAIL: {type(exc).__name__}: {str(exc)[:200]}")
            build.append(tag)
    ok = len(cases) - len(fails) - len(build)
    print(f"\n[{mode}] summary: {ok}/{len(cases)} combos exact; "
          f"mismatch={fails or '-'}; build/run-fail={build or '-'}")
    if fails or build:
        raise AssertionError(f"gather/scatter {mode}: mismatch={fails} build_fail={build}")
    print(f"[{mode}] ALL {len(cases)} gather/scatter dtype combos match the golden")


if __name__ == "__main__":
    _run = "--run" in sys.argv[1:] or os.environ.get("EASYASC_RUN_ON_A5") == "1"
    # --only=<tag> runs a single case (one fresh process per op avoids the shared-950
    # device-memory accumulation that OOMs long back-to-back aclnn sweeps).
    _only = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--only=")), None)
    main(_run, only=_only)
