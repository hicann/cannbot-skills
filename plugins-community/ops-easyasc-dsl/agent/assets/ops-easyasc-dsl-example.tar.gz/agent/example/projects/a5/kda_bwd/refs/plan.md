# Canonical Decomposition - kda_bwd (`disable_recompute=True`, `cp_context=None`)

**Target.** `a5`  
**Precision.** `bf16 IO / fp32 compute` (`atol=1e-3`, `rtol=1e-3` at input scale `0.01`)  
**Project dir.** `projects/a5/kda_bwd`

## Behavior

This plan now matches the upstream KDA backward path for:

- `disable_recompute=True`
- `cp_context=None`
- `use_gate_in_kernel=False`

That means backward consumes forward-saved tensors directly and does **not**
need a backward-side `forward_state` recompute/materialization kernel.

The saved forward cache contract is:

- `g_cumsum`
- `Aqk`
- `Akk`
- `w`
- `u`
- `qg`
- `kg`
- `v_new`
- `h`

Under this contract the backward decomposition is:

1. `scan_bwd`: upstream `chunk_kda_bwd_dAv` + `chunk_gated_delta_rule_bwd_dhu`
2. `inverse_bwd`: upstream `chunk_kda_bwd_wy_dqkg_fused`
3. `finalize_bwd`: upstream `chunk_kda_bwd_intra` + GVA reduction + reverse cumsum

## IO Contract

Every public tensor is `bfloat16` — inputs, forward-saved caches, stage
handoffs, and outputs. Kernels and refs upcast to fp32 internally and downcast
once on store.

| tensor | dtype | shape | notes |
| --- | --- | --- | --- |
| `q`, `k` | `bfloat16` | `[B, T, H, K]` | shared across `G = HV / H` value heads |
| `v`, `do` | `bfloat16` | `[B, T, HV, V]` | per-HV activations and upstream grad |
| `g` | `bfloat16` | `[B, T, HV, K]` | raw pre-cumsum gate input |
| `beta` | `bfloat16` | `[B, T, HV]` | per-token scalar |
| `initial_state`, `dht` | `bfloat16` | `[B, HV, K, V]` | initial recurrent state and final-state grad |
| `g_cumsum` | `bfloat16` | `[B, T, HV, K]` | saved forward gate after chunk-local cumsum and `/ ln(2)` conversion |
| `Aqk`, `Akk` | `bfloat16` | `[B, T, HV, chunk_size]` | saved forward lower-triangular per-chunk matrices in flat row-major form |
| `w`, `qg`, `kg` | `bfloat16` | `[B, T, HV, K]` | saved forward per-token K-side intermediates |
| `u`, `v_new` | `bfloat16` | `[B, T, HV, V]` | saved forward per-token V-side intermediates |
| `h` | `bfloat16` | `[B, NT, HV, K, V]` | saved forward recurrent state before each chunk update |
| `dq`, `dk` | `bfloat16` | `[B, T, H, K]` | q/k grads after summing shared HV groups |
| `dv` | `bfloat16` | `[B, T, HV, V]` | value grad |
| `dbeta` | `bfloat16` | `[B, T, HV]` | beta grad |
| `dg` | `bfloat16` | `[B, T, HV, K]` | raw pre-cumsum gate grad |
| `dh0` | `bfloat16` | `[B, HV, K, V]` | initial-state grad |

Runtime axes: `B, T, H, HV, K, V`. Tail handling is supported on `T` via the
final short chunk when `T % chunk_size != 0`.

## Sub-kernels

| sub | ref file | inputs | outputs | primitives |
| --- | --- | --- | --- | --- |
| `scan_bwd` | `refs/scan_bwd_ref.py` | saved `g_cumsum`, `Aqk`, `qg`, `kg`, `w`, `u`, `v_new`, `h`, plus `do`, `dht` | `dAqk`, `dh`, `dv`, `dh0` | `[P1, P2, P6, A3]` |
| `inverse_bwd` | `refs/inverse_bwd_ref.py` | `q,k,v,beta,do` plus saved `g_cumsum`, `Akk`, `h`, `v_new`, and `scan_bwd` outputs `dh`, `dv` | `dq_hv`, `dk_hv`, `dv`, `dbeta`, `dg_core`, `dAkk` | `[P1, P2, P6]` |
| `finalize_bwd` | `refs/finalize_bwd_ref.py` | `q,k,beta,g_cumsum,dAqk,dq_hv,dk_hv,dv,dbeta,dg_core,dAkk,dh0` | `dq`, `dk`, `dv`, `dbeta`, `dg`, `dh0` | `[P1, P2, P6]` |

## DAG

```text
forward_saved_cache -> scan_bwd -> inverse_bwd -> finalize_bwd
forward_saved_cache -----------------------> inverse_bwd
forward_saved_cache -----------------------> finalize_bwd
scan_bwd ----------------------------------> finalize_bwd
```

Machine-readable file: `refs/dag.json`

## Precision / Casts

This plan is bf16 IO with fp32 internal compute.

- All public tensors (inputs, saved caches, stage handoffs, outputs) are bf16.
- Each stage upcasts to fp32 on load, computes in fp32, and downcasts once on
  store. The chunk-reversed state scan in `scan_bwd` carries its running state
  in fp32; only the per-chunk `dh` snapshots are stored as bf16.
- No recompute path is modeled inside backward.
- No `cp_context` preprocessing path is modeled.
- `oracle.py` stays independent from the split: it differentiates the clean
  fp32 forward end to end and downcasts the resulting gradients to bf16.
- The staged refs assume the forward-saved tensors are available as bf16
  inputs.
- Tolerance: `atol=1e-3`, `rtol=1e-3`, tied to the input range
  (`make_inputs` default `scale=0.01`, `k_scale=0.05`). The `dk` error is
  bf16 cancellation noise at ~1.5% of `|dk|max` (relative, independent of
  input scale; flat in `T`); the absolute floor therefore scales with
  `scale**3` - ~3e-4 at `scale=0.01`, which gives about 3x margin. The
  remaining outputs sit at `1e-6`..`1e-5`.
- With softplus gates the per-chunk decay is ~`2^-75` per K-channel, so `h`
  effectively carries only the most recent chunk and `|h|` stays small
  (`L * scale_k * scale_v`). Gentler gates (e.g. `g * 0.005`) raise the
  steady-state factor and `|h|` by up to roughly 4x; the relative error
  contract is unchanged.

## Validation

```bash
python -m py_compile projects/a5/kda_bwd/refs/*.py
for f in projects/a5/kda_bwd/refs/*_check.py; do /opt/miniconda3/envs/torch210npu/bin/python "$f"; done
/opt/miniconda3/envs/torch210npu/bin/python projects/a5/kda_bwd/refs/compose.py
```

## Notes

- `saved_forward_check.py` verifies that the local cache builder replays the
  clean forward exactly; it is a local verification helper, not a planned DSL kernel.
- The refs keep `Aqk` and `Akk` in the flat `[B, T, HV, chunk_size]` style,
  which is closer to the upstream saved-cache contract than the earlier
  chunk-matrix-only layout.
