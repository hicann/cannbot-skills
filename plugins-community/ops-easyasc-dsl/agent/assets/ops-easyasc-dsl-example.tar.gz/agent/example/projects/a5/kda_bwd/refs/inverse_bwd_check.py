"""Smoke-check the saved-cache local backward stage wrapper."""

from common import (
    _check_close,
    build_saved_forward,
    inverse_bwd,
    local_mids_as_tuple,
    local_mids_from_tuple,
    make_inputs,
    scan_bwd,
)
from inverse_bwd_ref import subkernel


def main():
    inputs = make_inputs(B=1, H=2, HV=4, T=8, K=8, V=6, chunk_size=4, seed=13)
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    scan = scan_bwd(inputs.do, inputs.dht, caches, inputs.chunk_size)
    expected = inverse_bwd(inputs.q, inputs.k, inputs.v, inputs.beta, inputs.do, caches, scan, inputs.chunk_size)
    actual = local_mids_from_tuple(
        subkernel(
            inputs.q,
            inputs.k,
            inputs.v,
            inputs.beta,
            inputs.do,
            caches.g_cumsum,
            caches.Akk,
            caches.h,
            caches.v_new,
            scan.dh,
            scan.dv,
            inputs.chunk_size,
        )
    )
    for name, got, ref in zip(
        ("dq_hv", "dk_hv", "dv", "dbeta", "dg_core", "dAkk"),
        local_mids_as_tuple(actual),
        local_mids_as_tuple(expected),
    ):
        _check_close(name, got, ref, 1e-6, 1e-6)
    print("inverse_bwd_check: OK")


if __name__ == "__main__":
    main()
