# Delta Rule Forward Optimization Timeline

This file records the project-local optimization rationale for the current
`projects/a5/delta_rule_fwd` implementation.

Stable cross-project lessons have already moved to owner docs:

- `agent/references/constraints/sync.md` - autosync event-family reuse and
  cross-pipe buffer-lifetime rules
- `agent/references/constraints/precision.md` - BT/C2 bias dtype and
  accumulation rules
- `agent/references/code-paths.md` - where the shared `conv2d`, img2col, and
  other DSL lowering/runtime paths live
- `agent/references/facts-simulator-opexec.md` - `OpExec` and simulator usage
  rules

## Current Result

The active default runtime path is:

```text
delta_preprocess
tril_inverse64            # default impl = block
delta_recompute_wu
chunk_delta_compose       # sub1 fused into sub2
```

The current forward project is:

- ungated (`g` removed from the public contract and all stage formulas)
- simulator-validated end-to-end
- still centered on the GDN-compatible 4-step decomposition
- using the original block `tril_inverse64` implementation by default, with an
  optional Neumann variant for A/B testing

Representative 1-core simulator profile after the kept compose-side changes
(`B=1, H=1, C=8`):

| stage | cycles | note |
|---|---:|---|
| `delta_preprocess` | `5884` | MTE2-heavy |
| `tril_inverse64` (block) | `27503` | vec-bound |
| `delta_recompute_wu` | `14629` | FIX-heavy |
| `chunk_delta_compose` | `65596` | fused sub1 + sub2 |
| total | `113612` | default block path |

Important default-vs-optional status:

- the block inverse remains the shipped default
- the optional Neumann inverse is available through
  `delta_rule_full.py --tril-impl {block,neumann}` and
  `TRIL_IMPL=block|neumann` in `test_script/run_onboard_profile.sh`
- the Neumann path won clearly in simulator on large same-core multi-chunk
  shapes, but it keeps a small bf16-only accuracy margin and is not the default

## 1. First Ungated Port

The first step was a direct ungated port of `projects/a5/gdn_fwd/`:

```text
delta_preprocess
tril_inverse64            # reused verbatim
delta_recompute_wu
chunk_delta_sub1
chunk_delta_sub2
chunk_delta_compose
```

Key decisions in that phase:

- keep the GDN 4-step decomposition instead of inventing a new split
- delete every `g`-dependent term rather than approximating it
- prove correctness against GDN at `g == 0`, not just against a handwritten
  delta-rule reference

Result:

- all stage kernels matched their PyTorch refs at `max_abs = 0`
- `delta_rule_full.py --check-gated` proved bit-exact equivalence to the GDN
  forward at `g == 0`
- the full 4-step kernel path matched the staged reference exactly and stayed
  within the bf16-vs-fp32 budget

## 2. `chunk_delta_sub2` Optimization Pass

The first serious optimization work targeted `chunk_delta_sub2`, which was the
largest and most bubble-heavy stage in the initial 1-core profile.

Baseline (`B=1, H=1, C=4`, 1 core):

| stage | baseline cycles |
|---|---:|
| `delta_preprocess` | `5884` |
| `tril_inverse64` | `27503` |
| `delta_recompute_wu` | `14629` |
| `chunk_delta_sub1` | `8096` |
| `chunk_delta_sub2` | `31959` |

Accepted `chunk_delta_sub2` wins:

| change | local result |
|---|---:|
| double-buffer the cube↔vec bridge (`CvMutex` depth `1 -> 2`) | `31959 -> 30540` |
| reorder the recurrence: start `S_delta = k.T @ v_new` before deferred output | `30540 -> 29010` |
| fold `q @ state` into the output L0C accumulator | `29010 -> 28002` |

Kept interpretation:

- the dominant remaining chain is still serial:
  `matmul1 -> make_v_new -> matmul4 -> state_add -> matmul1[next chunk]`
- after the accepted changes, most remaining cost was sync/bubble rather than
  obviously removable extra math

Rejected / neutral work worth remembering:

- double-buffering `l1_v_new` was noise-only (`29010 -> 29013`) and did not
  address the real wait
- the bottleneck was production latency of `v_new`, not L1 reuse serialization

## 3. Fuse `sub1` into `sub2`

The next structural win was to delete the explicit GM handoff of the
intra-chunk attention tile:

- `chunk_delta_sub1` stayed as a standalone reference kernel
- `chunk_delta_compose` stopped calling it
- `chunk_delta_sub2` grew an internal `q @ k.T` + causal-keep path and consumed
  that attention tile directly

Representative 1-core `B=1, H=1, C=8` result:

| chunk-attention path | cycles |
|---|---:|
| separate `sub1 + sub2` | `72730` |
| fused `chunk_delta_compose` | `65596` |
| delta | `-9.8%` |

Why this was kept:

- it removed one kernel launch
- it deleted the `attn [B, H, C, L, L]` GM round-trip
- the added `q @ k.T` cube work overlapped well enough with existing bubbles
  that the composed stage still got smaller

Important implementation note from this phase:

- `l0c_to_ub` cannot use dynamic row-offset L0C slices on this path; the stable
  idiom is to bridge the full L0C tile and let the half-height UB drive the
  per-sub-block split

## 4. Optional Neumann `tril_inverse64`

The project then explored replacing the shared block inverse with an ungated
delta-specialized Neumann-style inverse:

```text
(I - A)^-1 = ∏_{j=0}^{5} (I + A^(2^j))
```

This happened in several rounds:

1. prove the algebra and bf16 error budget in torch
2. build a whole-64 fp32 kernel (correct but far too compute-heavy)
3. build a whole-64 bf16 kernel (correct, but sync-bound)
4. add a software-pipelined square/update overlap
5. add cross-chunk interleave
6. add a 2-chunk parity interleave

Key measured milestones:

| variant | result |
|---|---:|
| whole-64 fp32 | dead end; cube compute alone exceeded the block kernel |
| whole-64 bf16 | correct but still slower than block |
| software-pipelined bf16 | `1.05x` to `1.06x` vs block |
| cross-chunk bf16 | `1.07x` to `1.08x` vs block |
| 2-chunk interleave bf16 | `1.23x` to `1.26x` vs block |

Final disposition:

- keep the Neumann path as an opt-in switch
- keep the block inverse as default
- do not silently swap the default to the bf16 Neumann path until hardware A/B
  data and acceptable default tolerance are both settled

The opt-in switch is already wired through the public forward runner and the
onboard profile script, so future work can compare the two paths without
rewriting the project structure.

## Current Open Questions

- whether the optional Neumann path is worth promoting beyond simulator-only
  evidence
- whether any meaningful additional win remains in the fused chunk stage without
  changing the decomposition itself
- whether future onboard profiling should keep the block path as the reporting
  baseline and treat Neumann strictly as an experiment
