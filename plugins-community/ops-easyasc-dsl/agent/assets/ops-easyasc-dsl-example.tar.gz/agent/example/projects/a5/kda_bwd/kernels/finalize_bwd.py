"""Finalize stage driver -- pure kernel plumbing, no host math.

Chains the four finalize-stage kernels:

    finalize_pre     -> q_scaled, k_scaled, kg, M_qk, M_base, M_beta
    finalize_pair    -> qk_left, qk_right, s_base, t_beta
    finalize_post    -> dq_hv', dk_hv', dbeta, dg     (per value head)
    finalize_reduce  -> dq, dk                        (HV -> H group sum)

The former host pre-loop (scales + tril masks) now lives in `finalize_pre`; the
host post-loop (pairwise products, accumulation, the per-chunk reverse cumsum of
dg, and the HV->H reduction) is split across `finalize_post` and
`finalize_reduce`. `dv` and `dh0` pass straight through. The only host work left
is dtype/layout plumbing inside each kernel's `run()`.
"""

from pathlib import Path

import torch

from finalize_pre import run as run_finalize_pre
from finalize_pair import run as run_finalize_pair
from finalize_post import run as run_finalize_post
from finalize_reduce import run as run_finalize_reduce
from _torch_formula import L, build_saved_forward, finalize_bwd as finalize_ref, inverse_bwd as inverse_ref, scan_bwd


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "kda_bwd_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def _child_out_dir(out_dir, name):
    if not out_dir:
        return ""
    path = Path(out_dir) / name
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def run(q, k, beta, g_cumsum, dAqk, dq_hv, dk_hv, dv, dbeta, dg_core, dAkk, dh0, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    common = dict(simulator=simulator, gen_only=gen_only, skip_compile=skip_compile, profile=profile)

    # Pure plumbing: the finalize kernels read/write token-major BTHVD directly
    # (strided on-device, with the H->HV gather done in-kernel). The only host ops
    # left are the free intra-stage reshapes [B,HV,C,L,*]<->[B,HV,T,*] (contiguous
    # views, no data movement) between finalize_pre/pair/post.
    B, T, H, _ = q.shape
    HV = dq_hv.shape[2]
    C = T // L

    q_scaled, k_scaled, kg, m_qk, m_base, m_beta = run_finalize_pre(
        q, k, beta, g_cumsum, dAqk, dAkk,
        trace=_child_trace(trace, out_dir, "finalize_pre"),
        out_dir=_child_out_dir(out_dir, "finalize_pre"), **common,
    )

    # finalize_pre emits [B, HV, C, L, *]; finalize_pair wants the token-major
    # [B, HV, T, *] -- a free reshape (C, L adjacent and contiguous).
    to_tl = lambda x: x.view(B, HV, T, x.shape[-1])
    qk_left, qk_right, s_base, t_beta = run_finalize_pair(
        to_tl(m_qk), to_tl(m_base), to_tl(m_beta), to_tl(q_scaled), to_tl(k_scaled), to_tl(kg),
        trace=_child_trace(trace, out_dir, "finalize_pair"),
        out_dir=_child_out_dir(out_dir, "finalize_pair"), **common,
    )

    # finalize_pair emits [B, HV, T, D] bf16; finalize_post wants [B, HV, C, L, D]
    # bf16 -- a free reshape only (the fp32->bf16 downcast now happens inside
    # finalize_pair's fixpipe store).
    to_cl = lambda x: x.view(B, HV, C, L, x.shape[-1])
    dq_hv_p, dk_hv_p, dbeta_out, dg = run_finalize_post(
        q, k, beta, g_cumsum,
        to_cl(qk_left), to_cl(qk_right), to_cl(s_base), to_cl(t_beta),
        dq_hv, dk_hv, dbeta, dg_core,
        trace=_child_trace(trace, out_dir, "finalize_post"),
        out_dir=_child_out_dir(out_dir, "finalize_post"), **common,
    )

    # finalize_post emits dq_hv'/dk_hv' [B, HV, C, L, D] fp32; finalize_reduce
    # consumes them directly (intra-stage GM-native) and writes public dq/dk.
    dq, dk = run_finalize_reduce(
        dq_hv_p, dk_hv_p, H,
        trace=_child_trace(trace, out_dir, "finalize_reduce"),
        out_dir=_child_out_dir(out_dir, "finalize_reduce"), **common,
    )

    # All outputs are already public BTHVD (kernels wrote them strided on-device):
    # dq/dk (reduce), dv (passthrough from inverse), dbeta_out/dg (post), dh0 (scan).
    return dq, dk, dv, dbeta_out, dg, dh0


if __name__ == "__main__":
    import torch
    from projects.a5.kda_bwd.refs.common import make_inputs

    tol = 8e-3
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    caches = build_saved_forward(inputs)
    scan = scan_bwd(inputs, caches)
    local = inverse_ref(inputs, caches, scan)
    # The real inverse kernel emits dbeta in fp32 (finalize_post downcasts it
    # on-device); the bf16 reference is upcast here only to mirror that seam.
    got = run(inputs.q, inputs.k, inputs.beta, caches.g_cumsum, scan.dAqk, local.dq_hv, local.dk_hv, local.dv, local.dbeta.float(), local.dg_core, local.dAkk, scan.dh0, simulator=True)
    exp = finalize_ref(inputs, caches, scan, local)
    names = ("dq", "dk", "dv", "dbeta", "dg", "dh0")
    for name, got_item, exp_item in zip(names, got, (exp.dq, exp.dk, exp.dv, exp.dbeta, exp.dg, exp.dh0)):
        torch.testing.assert_close(got_item.float(), exp_item.float(), rtol=tol, atol=tol)
        print(f"{name}: max_abs={(got_item.float() - exp_item.float()).abs().max().item():.3e} OK")
    print([tuple(item.shape) for item in got], [item.dtype for item in got])
