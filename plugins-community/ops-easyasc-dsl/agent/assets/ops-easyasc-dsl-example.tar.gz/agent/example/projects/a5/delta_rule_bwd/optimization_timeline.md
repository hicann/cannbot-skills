# Delta Rule Backward Optimization Timeline

This file records the project-local optimization rationale for the current
`projects/a5/delta_rule_bwd` implementation.

Stable cross-project lessons have already moved to owner docs:

- `agent/references/code-paths.md` - parser/runtime lookup map
- `agent/references/facts-simulator-opexec.md` - simulator and `OpExec` usage
  rules

## Current Result

The active runtime path is:

```text
scan_split_bwd
  -> scan_local_bwd
  -> scan_state_bwd
wu_bwd
inverse_preprocess_bwd
finalize_bwd
kernel_compose
```

Current project state:

- ungated backward (`gdn_bwd` evaluated at `g == 0`)
- full end-to-end simulator validation complete
- bf16 public contract with fp32 internal compute, matching the refs and
  golden path
- optimization target clearly narrowed to `scan_state_bwd`

End-to-end correctness snapshots:

| check | result |
|---|---|
| `delta_rule_bwd_full.py` self-check vs autograd | clean |
| `compare_against_gated_zero_g` | all kept grads bit-exact to `gdn_bwd(g=0)` |
| compose vs refs oracle (`B=1, H=1, C=2`) | float-epsilon level |
| compose vs fp32 golden (`B=1, H=1, C=2`) | `max_abs <= 5.3e-4` |
| cross-tile compose (`B=1, H=33, C=2`) | `max_abs <= 8.1e-4` vs fp32 golden |

Representative 1-core simulator profile (`B=1, H=1, C=8`):

| stage | cycles | dominant note |
|---|---:|---|
| `scan_local_bwd` | `30031` | cube-load bound |
| `scan_state_bwd` | `111975` | recurrence-serialized |
| `wu_bwd` | `23973` | FIX + MTE2 heavy |
| `inverse_preprocess_bwd` | `31501` | FIX-bound |
| `finalize_bwd` | `49871` | vec-only UB-load heavy |
| total | `247351` | clear scan-state bottleneck |

## 1. Golden and Refs: `gdn_bwd` at `g == 0`

The project began by freezing the ungated math contract before any kernel port:

- `delta_rule_bwd_full.py` became the authoritative PyTorch golden
- the full formula was derived directly from `gdn_bwd_full.py` at `g == 0`
- the ref layer mirrored `gdn_bwd/refs/` but removed all gate-only work

Core contract changes established here:

- saved forward tensors shrink from 6 to 4
- public outputs drop `d_g`
- recurrent state update becomes the plain ungated form
- the only bf16 boundary kept from GDN is the `wu_attn` handoff

This phase finished only after two proofs were in place:

- autograd self-check of the ungated golden
- bit-exact equality of every kept gradient against `gdn_bwd_full(g=0)`

## 2. Refs Decomposition First

Before DSL kernel authoring, the full ref layer was mirrored from GDN:

```text
scan_local -> scan_state -> wu -> inverse_preprocess
all -> finalize
```

What was settled in this phase:

- plan-local `refs/` are the exact ungated mirror of the GDN split
- all per-stage `*_ref.py` and `*_check.py` files passed
- `compose.py` matched the refs oracle
- `golden_check.py` tied the bf16-cube refs back to the fp32 golden

This gave the kernel port a stable stage-by-stage target instead of forcing all
validation through the full compose path.

## 3. First Kernel Bring-up: `scan_local_bwd`

The first DSL stage to land was `scan_local_bwd`.

Why it came first:

- it was close in structure to the already-understood GDN local scan
- it exercised both the ungated causal-keep replacement and the standard
  cube→vec→cube handoff pattern
- it gave an early proof that "minus `g`" was not just a golden-only idea

Main adaptation:

- replace the GDN `decay_mask` GM input with an in-kernel causal keep built
  from the absolute row index
- remove the gate-only `d_decay_core` outputs

Result:

- `d_score_tmp` and `d_v_attn_tmp` matched the ref at `max_abs = 0`

## 4. Full Kernel Port

The remaining kernels then landed against the ungated refs:

- `scan_state_bwd`
- `wu_bwd`
- `inverse_preprocess_bwd`
- `finalize_bwd`
- thin wiring helpers `scan_split_bwd` and `kernel_compose`

Important structural choices that survived:

- keep `scan_state_bwd` as the hard recurrent kernel and do not try to hide its
  state carry inside another stage
- preserve the GDN split rather than inventing a new backward decomposition
- drop all gate-only sub-computations completely instead of stubbing them out

Stage results in the initial porting phase:

| kernel | status |
|---|---|
| `scan_state_bwd` | exact vs ref |
| `wu_bwd` | exact vs ref |
| `inverse_preprocess_bwd` | exact vs ref |
| `finalize_bwd` | exact vs ref |
| `kernel_compose` | exact vs refs oracle; within bf16 budget vs fp32 golden |

At that point the project was functionally complete: golden, refs, kernels, and
compose wiring all existed and agreed.

## 5. End-to-End Validation and Cross-Tile Guardrail

After the kernel port was complete, the validation focus shifted from "does each
stage work?" to "does the project survive realistic reuse geometry?"

The key added guardrail was:

- `B=1, H=33, C=2` compose validation, forcing more than one `bh` or `bhc`
  group onto at least one core

That check mattered because it exercised:

- cross-tile buffer reuse
- cross-`bh` reuse in the BHC-parallel stages
- scan-state recurrence beyond the single-trivial-core case

The result stayed comfortably within the fp32-golden bf16 budget, so the
project ended the correctness phase with both a minimal smoke and a same-core
reuse regression.

## 6. Profiling Harness and Bottleneck Identification

Once correctness was stable, the work shifted to profiling rather than more
kernel rewrites.

Infrastructure added in this phase:

- `test_script/module_vs_ref.py`
- `test_script/run_onboard_profile.sh`
- `profile_pipe_occupancy.py`
- `test_script/profile_fla_delta_rule_bwd.py` for the NVIDIA/Triton baseline

The important conclusion from the first full 1-core occupancy snapshot was not
"all stages need tuning"; it was much narrower:

- `scan_state_bwd` is the dominant wall-clock stage
- and it is dominant because of the reverse recurrence itself, not because one
  obvious pipe is under-used by a removable local schedule mistake

That changed the optimization posture:

- the project became "simulator-complete, profiling-ready"
- the next serious win, if any, is expected to come from `scan_state_bwd`
- the other four stages are already near their natural local bounds

## Current Open Questions

- whether `scan_state_bwd` should stay as-is and be accepted as the natural
  dominant stage, or whether a more structural rewrite is worth attempting
- whether future work should pursue hardware timing first, or more simulator-side
  schedule experiments first
- whether any project-local optimization timeline beyond this point should stay
  stage-specific (`scan_state_bwd`) rather than continuing as one mixed log
