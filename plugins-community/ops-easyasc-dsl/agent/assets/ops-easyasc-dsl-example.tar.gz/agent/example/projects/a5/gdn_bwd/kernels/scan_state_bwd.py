import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _torch_formula import L, D


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
HALF_L = L // 2
HALF_D = D // 2
REGS_D = D // 64
BF16_C0 = 16
SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
    2: [0, 1, 2, None, None],
    3: [0, 1, 2, None],
    4: [0, 1, 2, None, None],
    5: [0, 1, 2, None, None],
    6: [0, 1, None, None],
    7: [0, 1, 2, None, None],
    8: [0, 1, 2, None, None],
    9: [0, 1, 2, None, None],
    10: [0, 1, 2, None, None],
    11: [0, 1, 2, None],
    12: [0, 1, 2, None, None],
    13: [0, 1, 2, None, None],
    14: [0, 1, 2, None],
    15: [0, 1, 2, None, None],
    16: [0, 1, 2, None, None],
}


@vf()
def cast_d_rows_float_to_bf16_nz_vf(src_ub: Tensor, dst_nz_ub: Tensor, rows: Var):
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)

    for r in range(rows):
        row_lo <<= src_ub[r:r + 1, 0:64]
        row_hi <<= src_ub[r:r + 1, 64:D]
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def make_q_exp_nz_vf(q_bf16_ub: Tensor, g_ub: Tensor, q_exp_nz_ub: Tensor, exp_g_ub: Tensor, rows: Var):
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    g_reg = Reg(DT.float)
    exp_g = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(rows):
        g_reg <<= g_ub[0:1, r:r + 1].single()
        exp_g <<= g_reg.exp()
        exp_g_ub[0:1, r:r + 1] <<= exp_g.single_value()
        row_lo <<= q_bf16_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * exp_g
        row_hi <<= q_bf16_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * exp_g
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(q_exp_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def add_scaled_d_rows_vf(score_ub: Tensor, exp_ub: Tensor, exp_g_ub: Tensor, out_ub: Tensor, rows: Var):
    score_regs = RegList(DT.float, REGS_D)
    exp_regs = RegList(DT.float, REGS_D)
    exp_g = Reg(DT.float)
    for r in range(rows):
        exp_g <<= exp_g_ub[0:1, r:r + 1].single()
        score_regs <<= score_ub[r:r + 1, 0:D]
        exp_regs <<= exp_ub[r:r + 1, 0:D]
        exp_regs <<= exp_regs * exp_g
        score_regs <<= score_regs + exp_regs
        out_ub[r:r + 1, 0:D] <<= score_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def postprocess_dk_vf(d_k_score_ub: Tensor, d_k_weighted_ub: Tensor, exp_delta_ub: Tensor, out_ub: Tensor, rows: Var):
    score_regs = RegList(DT.float, REGS_D)
    weighted_regs = RegList(DT.float, REGS_D)
    exp_delta = Reg(DT.float)
    for r in range(rows):
        exp_delta <<= exp_delta_ub[0:1, r:r + 1].single()
        score_regs <<= d_k_score_ub[r:r + 1, 0:D]
        weighted_regs <<= d_k_weighted_ub[r:r + 1, 0:D]
        weighted_regs <<= weighted_regs * exp_delta
        score_regs <<= score_regs + weighted_regs
        out_ub[r:r + 1, 0:D] <<= score_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def add_and_negate_d_rows_vf(dep_ub: Tensor, base_ub: Tensor, sum_ub: Tensor, neg_ub: Tensor, rows: Var):
    dep_regs = RegList(DT.float, REGS_D)
    base_regs = RegList(DT.float, REGS_D)
    for r in range(rows):
        dep_regs <<= dep_ub[r:r + 1, 0:D]
        base_regs <<= base_ub[r:r + 1, 0:D]
        base_regs <<= base_regs + dep_regs
        sum_ub[r:r + 1, 0:D] <<= base_regs
        base_regs <<= base_regs * -1.0
        neg_ub[r:r + 1, 0:D] <<= base_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def add_cast_d_rows_bf16_vf(dep_ub: Tensor, base_ub: Tensor, out_bf16_ub: Tensor, rows: Var):
    dep_lo = Reg(DT.float)
    dep_hi = Reg(DT.float)
    base_lo = Reg(DT.float)
    base_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(rows):
        dep_lo <<= dep_ub[r:r + 1, 0:64]
        dep_hi <<= dep_ub[r:r + 1, 64:D]
        base_lo <<= base_ub[r:r + 1, 0:64]
        base_hi <<= base_ub[r:r + 1, 64:D]
        base_lo <<= base_lo + dep_lo
        base_hi <<= base_hi + dep_hi
        lo_bf16 <<= base_lo.astype(DT.bfloat16)
        hi_bf16 <<= base_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(out_bf16_ub[r:r + 1, 0:D], row_bf16)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def add_negate_cast_d_rows_bf16_vf(dep_ub: Tensor, base_ub: Tensor, sum_bf16_ub: Tensor, neg_ub: Tensor, neg_nz_ub: Tensor, rows: Var):
    dep_lo = Reg(DT.float)
    dep_hi = Reg(DT.float)
    base_lo = Reg(DT.float)
    base_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(rows):
        dep_lo <<= dep_ub[r:r + 1, 0:64]
        dep_hi <<= dep_ub[r:r + 1, 64:D]
        base_lo <<= base_ub[r:r + 1, 0:64]
        base_hi <<= base_ub[r:r + 1, 64:D]
        base_lo <<= base_lo + dep_lo
        base_hi <<= base_hi + dep_hi
        lo_bf16 <<= base_lo.astype(DT.bfloat16)
        hi_bf16 <<= base_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(sum_bf16_ub[r:r + 1, 0:D], row_bf16)
        base_lo <<= base_lo * -1.0
        base_hi <<= base_hi * -1.0
        neg_ub[r:r + 1, 0:64] <<= base_lo
        neg_ub[r:r + 1, 64:D] <<= base_hi
        lo_bf16 <<= base_lo.astype(DT.bfloat16)
        hi_bf16 <<= base_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(neg_nz_ub[r * BF16_C0], row_bf16, rows)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def zero_d_rows_bf16_vf(dst_ub: Tensor, rows: Var):
    zero_lo = Reg(DT.bfloat16)
    zero_hi = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    zero_lo <<= 0.0
    zero_hi <<= 0.0
    for r in range(rows):
        deinterleave(row_bf16, dummy_bf16, zero_lo, zero_hi)
        reg_to_ub(dst_ub[r:r + 1, 0:D], row_bf16)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def update_d_state_half_vf(seed_ub: Tensor, old_d_state_ub: Tensor, out_ub: Tensor, g_last: Var):
    seed_regs = RegList(DT.float, REGS_D)
    old_regs = RegList(DT.float, REGS_D)
    scale = Reg(DT.float)
    scale <<= g_last
    scale <<= scale.exp()
    for r in range(HALF_D):
        seed_regs <<= seed_ub[r:r + 1, 0:D]
        old_regs <<= old_d_state_ub[r:r + 1, 0:D]
        old_regs <<= old_regs * scale
        seed_regs <<= seed_regs + old_regs
        out_ub[r:r + 1, 0:D] <<= seed_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def update_d_state_half_cast_nz_vf(seed_ub: Tensor, old_d_state_ub: Tensor, out_ub: Tensor, dst_nz_ub: Tensor, g_last: Var):
    seed_lo = Reg(DT.float)
    seed_hi = Reg(DT.float)
    old_lo = Reg(DT.float)
    old_hi = Reg(DT.float)
    scale = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    scale <<= g_last
    scale <<= scale.exp()
    for r in range(HALF_D):
        seed_lo <<= seed_ub[r:r + 1, 0:64]
        seed_hi <<= seed_ub[r:r + 1, 64:D]
        old_lo <<= old_d_state_ub[r:r + 1, 0:64]
        old_hi <<= old_d_state_ub[r:r + 1, 64:D]
        old_lo <<= old_lo * scale
        old_hi <<= old_hi * scale
        seed_lo <<= seed_lo + old_lo
        seed_hi <<= seed_hi + old_hi
        out_ub[r:r + 1, 0:64] <<= seed_lo
        out_ub[r:r + 1, 64:D] <<= seed_hi
        lo_bf16 <<= seed_lo.astype(DT.bfloat16)
        hi_bf16 <<= seed_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, L)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_state_dot_half_vf(d_state_rows_ub: Tensor, state_bf16_rows_ub: Tensor, accum_ub: Tensor, partial_vec_ub: Tensor):
    d_state_regs = RegList(DT.float, REGS_D)
    state_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    low8_mask = MaskReg(DT.float, init_mode=MaskType.LOWEST8)
    row_sum = Reg(DT.float)
    acc = Reg(DT.float)
    acc_vec = Reg(DT.float)
    acc <<= 0.0
    for r in range(L):
        d_state_regs <<= d_state_rows_ub[r:r + 1, 0:D]
        state_regs <<= state_bf16_rows_ub[r:r + 1, 0:D]
        prod_regs <<= d_state_regs * state_regs
        row_sum <<= prod_regs.cadd()
        acc <<= acc + row_sum
    accum_ub[0:1, 0:1] <<= acc.single_value()
    acc_vec <<= acc
    reg_to_ub(partial_vec_ub[0:1, 0:8], acc_vec, mask=low8_mask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def add_peer_partial_scalar_vf(accum_ub: Tensor, peer_partial_ub: Tensor):
    acc = Reg(DT.float)
    peer = Reg(DT.float)
    acc <<= accum_ub[0:1, 0:1].single()
    peer <<= peer_partial_ub[0:1, 0:1].single()
    acc <<= acc + peer
    accum_ub[0:1, 0:1] <<= acc.single_value()


@vf()
def broadcast_scalar_vf(src_ub: Tensor, dst_vec_ub: Tensor):
    low8_mask = MaskReg(DT.float, init_mode=MaskType.LOWEST8)
    val = Reg(DT.float)
    val <<= src_ub[0:1, 0:1].single()
    reg_to_ub(dst_vec_ub[0:1, 0:8], val, mask=low8_mask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def pack_second_scalar_vf(dst_vec_ub: Tensor, second_vec_ub: Tensor):
    second = Reg(DT.float)
    second <<= second_vec_ub[0:1, 0:1].single()
    dst_vec_ub[0:1, 1:2] <<= second.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_dq_g_half_vf(d_q_exp_ub: Tensor, q_bf16_ub: Tensor, exp_g_ub: Tensor, d_g_ub: Tensor):
    dq_regs = RegList(DT.float, REGS_D)
    q_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    exp_g = Reg(DT.float)
    row_sum = Reg(DT.float)
    for r in range(HALF_L):
        exp_g <<= exp_g_ub[0:1, r:r + 1].single()
        dq_regs <<= d_q_exp_ub[r:r + 1, 0:D]
        q_regs <<= q_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dq_regs * q_regs
        row_sum <<= prod_regs.cadd()
        row_sum <<= row_sum * exp_g
        d_g_ub[0:1, r:r + 1] <<= row_sum.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def finish_g_half_vf(d_k_weighted_ub: Tensor, k_bf16_ub: Tensor, exp_delta_ub: Tensor, d_g_base_ub: Tensor, d_g_ub: Tensor, partial_scalar_ub: Tensor, partial_vec_ub: Tensor):
    dk_regs = RegList(DT.float, REGS_D)
    k_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    low8_mask = MaskReg(DT.float, init_mode=MaskType.LOWEST8)
    exp_delta = Reg(DT.float)
    d_delta = Reg(DT.float)
    delta_sum = Reg(DT.float)
    g_val = Reg(DT.float)
    partial_vec = Reg(DT.float)
    delta_sum <<= 0.0
    for r in range(HALF_L):
        exp_delta <<= exp_delta_ub[0:1, r:r + 1].single()
        dk_regs <<= d_k_weighted_ub[r:r + 1, 0:D]
        k_regs <<= k_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dk_regs * k_regs
        d_delta <<= prod_regs.cadd()
        d_delta <<= d_delta * exp_delta
        delta_sum <<= delta_sum + d_delta
        g_val <<= d_g_base_ub[0:1, r:r + 1].single()
        g_val <<= g_val - d_delta
        d_g_ub[0:1, r:r + 1] <<= g_val.single_value()

    partial_scalar_ub[0:1, 0:1] <<= delta_sum.single_value()
    partial_vec <<= delta_sum
    reg_to_ub(partial_vec_ub[0:1, 0:8], partial_vec, mask=low8_mask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def finish_g_half_tail_vf(d_g_ub: Tensor, local_delta_ub: Tensor, peer_delta_and_exp_ub: Tensor, g_last: Var):
    g_val = Reg(DT.float)
    local_sum = Reg(DT.float)
    peer_sum = Reg(DT.float)
    d_exp = Reg(DT.float)
    exp_last = Reg(DT.float)
    exp_last <<= g_last
    exp_last <<= exp_last.exp()
    g_val <<= d_g_ub[0:1, HALF_L - 1:HALF_L].single()
    local_sum <<= local_delta_ub[0:1, 0:1].single()
    peer_sum <<= peer_delta_and_exp_ub[0:1, 0:1].single()
    d_exp <<= peer_delta_and_exp_ub[0:1, 1:2].single()
    d_exp <<= d_exp * exp_last
    g_val <<= g_val + local_sum
    g_val <<= g_val + peer_sum
    g_val <<= g_val + d_exp
    d_g_ub[0:1, HALF_L - 1:HALF_L] <<= g_val.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def finish_g_zero_base_half_vf(d_k_weighted_ub: Tensor, k_bf16_ub: Tensor, exp_delta_ub: Tensor, d_g_ub: Tensor, partial_scalar_ub: Tensor, partial_vec_ub: Tensor):
    dk_regs = RegList(DT.float, REGS_D)
    k_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    low8_mask = MaskReg(DT.float, init_mode=MaskType.LOWEST8)
    exp_delta = Reg(DT.float)
    d_delta = Reg(DT.float)
    delta_sum = Reg(DT.float)
    g_val = Reg(DT.float)
    partial_vec = Reg(DT.float)
    delta_sum <<= 0.0
    for r in range(HALF_L):
        exp_delta <<= exp_delta_ub[0:1, r:r + 1].single()
        dk_regs <<= d_k_weighted_ub[r:r + 1, 0:D]
        k_regs <<= k_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dk_regs * k_regs
        d_delta <<= prod_regs.cadd()
        d_delta <<= d_delta * exp_delta
        delta_sum <<= delta_sum + d_delta
        g_val <<= d_delta * -1.0
        d_g_ub[0:1, r:r + 1] <<= g_val.single_value()

    partial_scalar_ub[0:1, 0:1] <<= delta_sum.single_value()
    partial_vec <<= delta_sum
    reg_to_ub(partial_vec_ub[0:1, 0:8], partial_vec, mask=low8_mask)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def finish_g_zero_base_half_tail_vf(d_g_ub: Tensor, local_partial_ub: Tensor, peer_partial_ub: Tensor):
    g_val = Reg(DT.float)
    local_sum = Reg(DT.float)
    peer_sum = Reg(DT.float)
    g_val <<= d_g_ub[0:1, HALF_L - 1:HALF_L].single()
    local_sum <<= local_partial_ub[0:1, 0:1].single()
    peer_sum <<= peer_partial_ub[0:1, 0:1].single()
    g_val <<= g_val + local_sum
    g_val <<= g_val + peer_sum
    d_g_ub[0:1, HALF_L - 1:HALF_L] <<= g_val.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def scan_state_bwd_kernel(
    query: GMTensor,
    key: GMTensor,
    grad_output: GMTensor,
    g_cumsum: GMTensor,
    k_cumdecay: GMTensor,
    state_after_history: GMTensor,
    grad_final_state: GMTensor,
    d_score_tmp: GMTensor,
    v_new_history: GMTensor,
    k_weighted_history: GMTensor,
    d_v_attn_tmp: GMTensor,
    exp_delta_history: GMTensor,
    d_q_core: GMTensor,
    d_k_core: GMTensor,
    d_g_core: GMTensor,
    d_value_wu: GMTensor,
    d_k_cumdecay: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    cvmutex = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    cv_seed_mutex = CvMutex(1, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    dvprime_mutex = VcMutex(2, depth=1, src_start_pipe=Pipe.MTE3, src_end_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1, dst_end_pipe=Pipe.MTE1)
    dstate_mutex = VcMutex(3, depth=1, src_start_pipe=Pipe.MTE3, src_end_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1, dst_end_pipe=Pipe.MTE1)
    dkcum_zero_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_dkcum_zero_out_ready")
    dvalue_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_dvalue_out_ready")
    dq_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_out_ready")
    dk_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dk_core_out_ready")
    q_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dq_core_q_in_ready")
    k_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dq_core_k_in_ready")
    state_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dq_core_state_in_ready")
    q_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_q_out_ready")
    exp_delta_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dq_core_exp_delta_in_ready")
    dvat_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dq_core_dvat_in_ready")
    dvprime_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_dvprime_out_ready")
    dstate_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dq_core_dstate_in_ready")
    dstate_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_dstate_out_ready")
    g_mid_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dq_core_g_mid_in_ready")
    g_mid_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_g_mid_out_ready")
    g_peer_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dq_core_g_peer_in_ready")
    g_first_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_g_first_out_ready")
    g_pack_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_g_pack_out_ready")
    g_final_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dq_core_g_final_out_ready")

    l1_q = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_k = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_d_out = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_kcd = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_state = Tensor(DT.bfloat16, [D, D], Position.L1)
    l1_d_state = Tensor(DT.bfloat16, [D, D], Position.L1)
    l1_q_exp = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_k_weighted = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_v_new = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_d_score = Tensor(DT.bfloat16, [L, L], Position.L1)
    l1_d_v_prime = Tensor(DT.bfloat16, [L, D], Position.L1)

    l0c_ld0 = Tensor(DT.float, [L, D], Position.L0C)
    l0c_ld1 = Tensor(DT.float, [L, D], Position.L0C)
    l0c_dd = Tensor(DT.float, [D, D], Position.L0C)

    bf16_full_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    bf16_alt_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    state_half_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    q_raw_ub = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    k_raw_ub = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    d_q_exp_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    score_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    term_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    out_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    tmp_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    g_ub = Tensor(DT.float, [1, HALF_L], Position.UB)
    exp_g_half_ub = Tensor(DT.float, [1, HALF_L], Position.UB)
    exp_delta_ub = Tensor(DT.float, [1, HALF_L], Position.UB)
    d_exp_ub = Tensor(DT.float, [1, 8], Position.UB)
    d_g_base_ub = Tensor(DT.float, [1, HALF_L], Position.UB)
    d_g_full_ub = Tensor(DT.float, [1, HALF_L], Position.UB)
    d_g_partial_ub = Tensor(DT.float, [1, 8], Position.UB)
    d_g_peer_ub = Tensor(DT.float, [1, 8], Position.UB)
    ub_d_state = DBuff(DT.float, [HALF_D, D], Position.UB)
    ub_d_state_seed = Tensor(DT.float, [HALF_D, D], Position.UB)

    bh_count = B * H
    bh_per_core = CeilDiv(bh_count, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, bh_count)
    dstate_read_cnt = Var(0)
    dstate_write_cnt = Var(1)

    for bh in range(bh_begin, bh_end):
        b_idx = Var(bh // H)
        h_idx = Var(bh % H)
        row_begin_l = Var(GetSubBlockIdx() * HALF_L)
        row_end_l = Var(row_begin_l + HALF_L)
        rows_l = Var(HALF_L)
        row_begin_d = Var(GetSubBlockIdx() * HALF_D)
        row_end_d = Var(row_begin_d + HALF_D)

        dstate_cur = ub_d_state[dstate_read_cnt]
        dstate_cur[0:HALF_D, 0:D] <<= grad_final_state[b_idx, h_idx, row_begin_d:row_end_d, 0:D]
        dstate_in_ready.set()
        dstate_in_ready.wait()
        dstate_mutex.lock()
        cast_d_rows_float_to_bf16_nz_vf(dstate_cur[0:HALF_D, 0:D], bf16_full_ub, L)
        dstate_out_ready.set()
        dstate_out_ready.wait()
        l1_d_state[row_begin_d:row_end_d, 0:D] <<= bf16_full_ub[0:L, 0:D].nz()
        bar_all()
        dstate_mutex.ready()
        dstate_mutex.wait()

        for rev_c in range(C):
            c_idx = Var(C - 1 - rev_c)
            c_prev = Var(c_idx - 1)
            g_last = Var(0.0, DT.float)

            if c_idx != 0:
                g_last.GetValueFrom(g_cumsum[b_idx, h_idx, c_idx, L - 1:L])
                q_raw_ub[0:rows_l, 0:D] <<= query[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D]
                g_ub[0:1, 0:rows_l] <<= g_cumsum[b_idx, h_idx, c_idx, row_begin_l:row_end_l]
                state_half_ub[0:L, 0:D] <<= state_after_history[b_idx, h_idx, c_prev, row_begin_d:row_end_d, 0:D]
                q_in_ready.set()
                q_in_ready.wait()
                make_q_exp_nz_vf(q_raw_ub, g_ub, bf16_alt_ub, exp_g_half_ub, rows_l)
                q_out_ready.set()
                q_out_ready.wait()
                l1_q_exp[row_begin_l:row_end_l, 0:D] <<= bf16_alt_ub[0:rows_l, 0:D].nz()
                state_in_ready.set()
                state_in_ready.wait()
                accum_state_dot_half_vf(dstate_cur[0:HALF_D, 0:D], state_half_ub, d_exp_ub, d_g_partial_ub)
                if GetSubBlockIdx() == 1:
                    g_mid_out_ready.set()
                    g_mid_out_ready.wait()
                    d_g_core[b_idx, h_idx, c_idx, L - 16:L - 8] <<= d_g_partial_ub[0:1, 0:8]
                intracore_allvec_ready(7, pipe=Pipe.MTE3)
                intracore_allvec_wait(7, pipe=Pipe.MTE2)
                if GetSubBlockIdx() == 0:
                    d_g_partial_ub[0:1, 0:8] <<= d_g_core[b_idx, h_idx, c_idx, L - 16:L - 8]
                    g_mid_in_ready.set()
                    g_mid_in_ready.wait()
                    add_peer_partial_scalar_vf(d_exp_ub, d_g_partial_ub)
                    broadcast_scalar_vf(d_exp_ub, d_g_peer_ub)

            exp_delta_ub[0:1, 0:rows_l] <<= exp_delta_history[b_idx, h_idx, c_idx, row_begin_l:row_end_l]
            k_raw_ub[0:rows_l, 0:D] <<= key[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D]
            exp_delta_in_ready.set()
            exp_delta_in_ready.wait()
            k_in_ready.set()
            k_in_ready.wait()

            with auto_sync():
                l1_q[0:L, 0:D] <<= query[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_k[0:L, 0:D] <<= key[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_v_new[0:L, 0:D] <<= v_new_history[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_d_score[0:L, 0:L] <<= d_score_tmp[b_idx, h_idx, c_idx, 0:L, 0:L]
                matmul(l0c_ld1, l1_v_new, l1_d_state, m=L, n=D, k=D, splitn=HALF_D)
                cvmutex.lock()
                term_ub <<= l0c_ld1
                cvmutex.ready()
            cvmutex.wait()
            cvmutex.free()

            if c_idx == 0:
                finish_g_zero_base_half_vf(term_ub, k_raw_ub, exp_delta_ub, d_g_full_ub, d_exp_ub, d_g_partial_ub)
                g_first_out_ready.set()
                if GetSubBlockIdx() == 0:
                    g_first_out_ready.wait()
                    d_g_core[b_idx, h_idx, c_idx, L - 8:L] <<= d_g_partial_ub[0:1, 0:8]
                if GetSubBlockIdx() == 1:
                    g_first_out_ready.wait()
                intracore_allvec_ready(6, pipe=Pipe.MTE3)
                intracore_allvec_wait(6, pipe=Pipe.MTE2)
                if GetSubBlockIdx() == 1:
                    d_g_partial_ub[0:1, 0:8] <<= d_g_core[b_idx, h_idx, c_idx, L - 8:L]
                    g_peer_in_ready.set()
                    g_peer_in_ready.wait()
                    finish_g_zero_base_half_tail_vf(d_g_full_ub, d_exp_ub, d_g_partial_ub)
                g_final_out_ready.set()
                g_final_out_ready.wait()
                d_g_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l] <<= d_g_full_ub[0:1, 0:rows_l]

                zero_d_rows_bf16_vf(bf16_alt_ub, rows_l)
                dkcum_zero_out_ready.set()
                dkcum_zero_out_ready.wait()
                d_k_cumdecay[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= bf16_alt_ub[0:rows_l, 0:D]

                with auto_sync():
                    matmul(l0c_ld0, l1_d_score, l1_k.T, m=L, n=D, k=L, splitn=D)
                    d_q_core[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_ld0

                with auto_sync():
                    matmul(l0c_ld0, l1_d_score.T, l1_q.T, m=L, n=D, k=L, splitn=D)
                    cvmutex.lock()
                    score_ub <<= l0c_ld0
                    cvmutex.ready()
                cvmutex.wait()
                postprocess_dk_vf(score_ub, term_ub, exp_delta_ub, d_q_exp_ub, rows_l)
                dk_out_ready.set()
                dk_out_ready.wait()
                d_k_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= d_q_exp_ub[0:rows_l, 0:D]
                cvmutex.free()

                with auto_sync():
                    l1_k_weighted[0:L, 0:D] <<= k_weighted_history[b_idx, h_idx, c_idx, 0:L, 0:D]
                    matmul(l0c_ld0, l1_k_weighted, l1_d_state.T, m=L, n=D, k=D, splitn=HALF_D)
                    cvmutex.lock()
                    score_ub <<= l0c_ld0
                    cvmutex.ready()
                tmp_ub[0:rows_l, 0:D] <<= d_v_attn_tmp[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D]
                dvat_in_ready.set()
                cvmutex.wait()
                cvmutex.free()
                dvat_in_ready.wait()
                add_cast_d_rows_bf16_vf(score_ub, tmp_ub, bf16_alt_ub, rows_l)
                dvalue_out_ready.set()
                dvalue_out_ready.wait()
                d_value_wu[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= bf16_alt_ub[0:rows_l, 0:D]
            else:
                with auto_sync():
                    l1_d_out[0:L, 0:D] <<= grad_output[b_idx, h_idx, c_idx, 0:L, 0:D]
                    l1_kcd[0:L, 0:D] <<= k_cumdecay[b_idx, h_idx, c_idx, 0:L, 0:D]
                    l1_state[0:D, 0:D] <<= state_after_history[b_idx, h_idx, c_prev, 0:D, 0:D]
                    l1_k_weighted[0:L, 0:D] <<= k_weighted_history[b_idx, h_idx, c_idx, 0:L, 0:D]
                    matmul(l0c_ld0, l1_d_out, l1_state, m=L, n=D, k=D, splitn=HALF_D)
                    cvmutex.lock()
                    score_ub <<= l0c_ld0
                    d_q_exp_ub <<= l0c_ld0
                    cvmutex.ready()
                with auto_sync():
                    matmul(l0c_dd, l1_q_exp.T, l1_d_out.T, m=D, n=D, k=L, splitn=D)
                cvmutex.wait()
                cvmutex.free()

                with auto_sync():
                    matmul(l0c_ld0, l1_k_weighted, l1_d_state.T, m=L, n=D, k=D, splitn=HALF_D)
                    cvmutex.lock()
                    out_ub <<= l0c_ld0
                    cvmutex.ready()
                tmp_ub[0:rows_l, 0:D] <<= d_v_attn_tmp[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D]
                dvat_in_ready.set()
                cvmutex.wait()
                cvmutex.free()
                dvat_in_ready.wait()
                add_negate_cast_d_rows_bf16_vf(out_ub, tmp_ub, bf16_alt_ub, ub_d_state_seed, bf16_full_ub, rows_l)
                dvalue_out_ready.set()
                dvalue_out_ready.wait()
                d_value_wu[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= bf16_alt_ub[0:rows_l, 0:D]

                dvprime_mutex.lock()
                dvprime_out_ready.set()
                dvprime_out_ready.wait()
                l1_d_v_prime[row_begin_l:row_end_l, 0:D] <<= bf16_full_ub[0:rows_l, 0:D].nz()
                dvprime_mutex.ready()
                dvprime_mutex.wait()
                bar_all()

                with auto_sync():
                    matmul(l0c_ld0, l1_d_v_prime, l1_state, m=L, n=D, k=D, splitn=HALF_D)
                    d_k_cumdecay[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_ld0
                    matmul(l0c_dd, l1_kcd.T, l1_d_v_prime.T, m=D, n=D, k=L, splitn=D, is_init=False)
                    cv_seed_mutex.lock()
                    l0c_to_ub(ub_d_state_seed, l0c_dd, M=D, N=D, N_dst=D, M_src=D, dual_mode=DualMode.SPLITM, sub_block_id=0)
                    cv_seed_mutex.ready()
                dvprime_mutex.free()

                accum_dq_g_half_vf(d_q_exp_ub, q_raw_ub, exp_g_half_ub, d_g_base_ub)
                finish_g_half_vf(term_ub, k_raw_ub, exp_delta_ub, d_g_base_ub, d_g_full_ub, d_exp_ub, d_g_partial_ub)
                g_first_out_ready.set()
                if GetSubBlockIdx() == 0:
                    g_first_out_ready.wait()
                    pack_second_scalar_vf(d_g_partial_ub, d_g_peer_ub)
                    g_pack_out_ready.set()
                    g_pack_out_ready.wait()
                    d_g_core[b_idx, h_idx, c_idx, L - 8:L] <<= d_g_partial_ub[0:1, 0:8]
                if GetSubBlockIdx() == 1:
                    g_first_out_ready.wait()
                intracore_allvec_ready(6, pipe=Pipe.MTE3)
                intracore_allvec_wait(6, pipe=Pipe.MTE2)
                if GetSubBlockIdx() == 1:
                    d_g_partial_ub[0:1, 0:8] <<= d_g_core[b_idx, h_idx, c_idx, L - 8:L]
                    g_peer_in_ready.set()
                    g_peer_in_ready.wait()
                    finish_g_half_tail_vf(d_g_full_ub, d_exp_ub, d_g_partial_ub, g_last)
                g_final_out_ready.set()
                g_final_out_ready.wait()
                d_g_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l] <<= d_g_full_ub[0:1, 0:rows_l]

                with auto_sync():
                    matmul(l0c_ld0, l1_d_score, l1_k.T, m=L, n=D, k=L, splitn=D)
                    cvmutex.lock()
                    out_ub <<= l0c_ld0
                    cvmutex.ready()
                cvmutex.wait()
                add_scaled_d_rows_vf(out_ub, score_ub, exp_g_half_ub, out_ub, rows_l)
                dq_out_ready.set()
                dq_out_ready.wait()
                d_q_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= out_ub[0:rows_l, 0:D]
                cvmutex.free()

                with auto_sync():
                    matmul(l0c_ld0, l1_d_score.T, l1_q.T, m=L, n=D, k=L, splitn=D)
                    cvmutex.lock()
                    score_ub <<= l0c_ld0
                    cvmutex.ready()
                cvmutex.wait()
                postprocess_dk_vf(score_ub, term_ub, exp_delta_ub, d_q_exp_ub, rows_l)
                dk_out_ready.set()
                dk_out_ready.wait()
                d_k_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= d_q_exp_ub[0:rows_l, 0:D]
                cvmutex.free()

            if c_idx != 0:
                dstate_mutex.free()
                cv_seed_mutex.wait()
                dstate_next = ub_d_state[dstate_write_cnt]
                update_d_state_half_cast_nz_vf(ub_d_state_seed, dstate_cur, dstate_next, bf16_full_ub, g_last)
                cv_seed_mutex.free()
                dstate_mutex.lock()
                dstate_out_ready.set()
                dstate_out_ready.wait()
                l1_d_state[row_begin_d:row_end_d, 0:D] <<= bf16_full_ub[0:L, 0:D].nz()
                bar_all()
                dstate_mutex.ready()
                dstate_mutex.wait()
                dstate_read_cnt += 1
                dstate_write_cnt += 1
                dstate_cur = ub_d_state[dstate_read_cnt]

        dstate_mutex.free()

    bar_all()
    return d_q_core, d_k_core, d_g_core, d_value_wu, d_k_cumdecay


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "gdn_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def _run_opexec(query, key, grad_output, g_cumsum, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, k_weighted_history, d_v_attn_tmp, exp_delta_history, outputs, B, H, C, simulator, trace_path, gen_only, out_dir, skip_compile, profile):
    previous_config = getattr(scan_state_bwd_kernel, "_simulator_config", None)
    if simulator:
        scan_state_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            scan_state_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            query, key, grad_output, g_cumsum, k_cumdecay, state_after_history,
            grad_final_state, d_score_tmp, v_new_history, k_weighted_history,
            d_v_attn_tmp, exp_delta_history,
            outputs[0], outputs[1], outputs[2], outputs[3], outputs[4], B, H, C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(scan_state_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                scan_state_bwd_kernel._simulator_config = previous_config
    return result


def run(query, key, grad_output, g_cumsum, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, k_weighted_history, d_v_attn_tmp, exp_delta_history, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    B = int(key.shape[0])
    H = int(key.shape[1])
    C = int(key.shape[2])
    outputs = (
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=key.device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=key.device),
        torch.empty((B, H, C, L), dtype=torch.float32, device=key.device),
        torch.empty((B, H, C, L, D), dtype=torch.bfloat16, device=key.device),
        torch.empty((B, H, C, L, D), dtype=torch.bfloat16, device=key.device),
    )
    result = _run_opexec(
        query, key, grad_output, g_cumsum, k_cumdecay, state_after_history,
        grad_final_state, d_score_tmp, v_new_history, k_weighted_history,
        d_v_attn_tmp, exp_delta_history, outputs,
        B, H, C, simulator, _trace_path(trace, out_dir, "scan_state_bwd"),
        gen_only, out_dir, skip_compile, profile,
    )
    if gen_only:
        return result
    return result


if __name__ == "__main__":
    torch.manual_seed(42)
    B, H, C = 1, 1, int(os.environ.get("C_SIZE", "2"))
    query = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    grad_output = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.1).to(torch.bfloat16)
    g_cumsum = torch.randn(B, H, C, L, dtype=torch.float32) * 0.05
    k_cumdecay = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    state_after_history = (torch.randn(B, H, C, D, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    grad_final_state = torch.randn(B, H, D, D, dtype=torch.float32) * 0.05
    d_score_tmp = (torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    v_new_history = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    k_weighted_history = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    d_v_attn_tmp = torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05
    exp_delta_history = torch.randn(B, H, C, L, dtype=torch.float32) * 0.05
    out = run(
        query, key, grad_output, g_cumsum, k_cumdecay, state_after_history,
        grad_final_state, d_score_tmp, v_new_history, k_weighted_history,
        d_v_attn_tmp, exp_delta_history,
    )
    print([tuple(item.shape) for item in out], [item.dtype for item in out])
