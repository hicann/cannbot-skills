"""finalize_bwd (ungated): final gradient accumulation for delta_rule backward.

Ungated port of `gdn_bwd/kernels/finalize_bwd.py`.  The entire d_g lower path
(cube section with selector/eye/reverse_tril constants, d_decay_core_masked,
d_decay_pre_masked, d_g_core, d_g_wu inputs, d_g output) is dropped.  Only the
upper-VF path that computes d_value, d_beta, d_key is kept.

Math (fp32):
  d_k_beta = d_k_beta_wu + d_k_beta_pre
  d_v      = d_v_beta * beta
  d_beta   = sum((d_v_beta * value) + (d_k_beta * key), dim=-1)
  d_k      = d_k_core + d_k_pre + d_k_beta * beta
"""
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 300.0

L = 64
D = 128
HALF_L = L // 2
UPPER_TILE_L = L // 4
REGS_D = D // 64

# Tensor argument indices -> [B, H, C, seq, (D)] axis symbols.
# Symbol 0=B, 1=H, 2=C; None means independent axis.
SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],   # key        [B,H,C,L,D]
    1: [0, 1, 2, None, None],   # value      [B,H,C,L,D]
    2: [0, 1, 2, None],         # beta       [B,H,C,L]
    3: [0, 1, 2, None, None],   # d_k_core   [B,H,C,L,D]
    4: [0, 1, 2, None, None],   # d_v_beta   [B,H,C,L,D]
    5: [0, 1, 2, None, None],   # d_k_beta_wu [B,H,C,L,D]
    6: [0, 1, 2, None, None],   # d_k_pre    [B,H,C,L,D]
    7: [0, 1, 2, None, None],   # d_k_beta_pre [B,H,C,L,D]
    8: [0, 1, 2, None, None],   # d_key  out [B,H,C,L,D]
    9: [0, 1, 2, None, None],   # d_value out [B,H,C,L,D]
    10: [0, 1, 2, None],        # d_beta  out [B,H,C,L]
}


@vf()
def finalize_upper_vf(
    key_ub: Tensor,
    value_ub: Tensor,
    beta_ub: Tensor,
    d_v_beta_ub: Tensor,
    d_k_beta_wu_ub: Tensor,
    d_k_beta_pre_ub: Tensor,
    d_k_core_ub: Tensor,
    d_k_pre_ub: Tensor,
    d_value_out_ub: Tensor,
    d_beta_ub: Tensor,
    d_key_out_ub: Tensor,
    rows: Var,
):
    key_regs = RegList(DT.float, REGS_D)
    value_regs = RegList(DT.float, REGS_D)
    d_v_regs = RegList(DT.float, REGS_D)
    d_k_beta_regs = RegList(DT.float, REGS_D)
    d_k_beta_pre_regs = RegList(DT.float, REGS_D)
    d_k_regs = RegList(DT.float, REGS_D)
    d_k_pre_regs = RegList(DT.float, REGS_D)
    tmp_regs = RegList(DT.float, REGS_D)
    beta_reg = Reg(DT.float)
    beta_sum = Reg(DT.float)

    for r in range(rows):
        beta_reg <<= beta_ub[0:1, r:r + 1].single()
        key_regs <<= key_ub[r:r + 1, 0:D]
        value_regs <<= value_ub[r:r + 1, 0:D]
        d_v_regs <<= d_v_beta_ub[r:r + 1, 0:D]
        d_k_beta_regs <<= d_k_beta_wu_ub[r:r + 1, 0:D]
        d_k_beta_pre_regs <<= d_k_beta_pre_ub[r:r + 1, 0:D]
        d_k_regs <<= d_k_core_ub[r:r + 1, 0:D]
        d_k_pre_regs <<= d_k_pre_ub[r:r + 1, 0:D]

        # d_k_beta = d_k_beta_wu + d_k_beta_pre
        d_k_beta_regs <<= d_k_beta_regs + d_k_beta_pre_regs

        # d_beta = sum(d_v_beta * value + d_k_beta * key, dim=-1)
        tmp_regs <<= d_v_regs * value_regs
        key_regs <<= d_k_beta_regs * key_regs
        tmp_regs <<= tmp_regs + key_regs
        beta_sum <<= tmp_regs.cadd()
        d_beta_ub[0:1, r:r + 1] <<= beta_sum.single_value()

        # d_v = d_v_beta * beta
        d_v_regs <<= d_v_regs * beta_reg
        d_value_out_ub[r:r + 1, 0:D] <<= d_v_regs

        # d_k = d_k_core + d_k_pre + d_k_beta * beta
        d_k_beta_regs <<= d_k_beta_regs * beta_reg
        d_k_regs <<= d_k_regs + d_k_pre_regs
        d_k_regs <<= d_k_regs + d_k_beta_regs
        d_key_out_ub[r:r + 1, 0:D] <<= d_k_regs


@kernel()
def finalize_bwd_kernel(
    key: GMTensor,
    value: GMTensor,
    beta: GMTensor,
    d_k_core: GMTensor,
    d_v_beta: GMTensor,
    d_k_beta_wu: GMTensor,
    d_k_pre: GMTensor,
    d_k_beta_pre: GMTensor,
    d_key: GMTensor,
    d_value: GMTensor,
    d_beta: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    key_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    value_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    beta_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    d_k_pre_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)  # bf16 bridge from inverse (half GM->UB traffic)
    d_k_beta_wu_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_k_beta_pre_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)  # bf16 bridge from inverse
    d_v_beta_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_k_core_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_beta_ub = DBuff(DT.float, [1, UPPER_TILE_L], Position.UB)
    d_value_out_ub = DBuff(DT.float, [UPPER_TILE_L, D], Position.UB)
    d_key_out_ub = DBuff(DT.float, [UPPER_TILE_L, D], Position.UB)

    bhc_count = B * H * C
    bhc_per_vec = CeilDiv(bhc_count, GetVecNum())
    bhc_begin = Var(bhc_per_vec * GetVecIdx())
    bhc_end = Min(bhc_begin + bhc_per_vec, bhc_count)
    rows_this = Var(UPPER_TILE_L)
    in_buf_cnt = Var(0)
    out_buf_cnt = Var(0)

    with auto_sync():
        for bhc in range(bhc_begin, bhc_end):
            c_idx = Var(bhc // (B * H))
            bh_remainder = Var(bhc % (B * H))
            b_idx = Var(bh_remainder // H)
            h_idx = Var(bh_remainder % H)

            for half_idx in range(2):
                half_begin = Var(half_idx * HALF_L)
                half_end = Var(half_begin + HALF_L)

                key_ub[in_buf_cnt][0:HALF_L, 0:D] <<= key[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                value_ub[in_buf_cnt][0:HALF_L, 0:D] <<= value[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                beta_ub[in_buf_cnt][0:1, 0:HALF_L] <<= beta[b_idx, h_idx, c_idx, half_begin:half_end]
                d_v_beta_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_v_beta[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                d_k_beta_wu_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_k_beta_wu[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                d_k_beta_pre_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_k_beta_pre[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                d_k_core_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_k_core[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                d_k_pre_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_k_pre[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]

                for tile_idx in range(2):
                    local_begin = Var(tile_idx * UPPER_TILE_L)
                    local_end = Var(local_begin + UPPER_TILE_L)
                    row_begin = Var(half_begin + local_begin)
                    row_end = Var(row_begin + UPPER_TILE_L)

                    finalize_upper_vf(
                        key_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        value_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        beta_ub[in_buf_cnt][0:1, local_begin:local_end],
                        d_v_beta_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_k_beta_wu_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_k_beta_pre_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_k_core_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_k_pre_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_value_out_ub[out_buf_cnt],
                        d_beta_ub[out_buf_cnt],
                        d_key_out_ub[out_buf_cnt],
                        rows_this,
                    )

                    d_value[b_idx, h_idx, c_idx, row_begin:row_end, 0:D] <<= d_value_out_ub[out_buf_cnt][0:rows_this, 0:D]
                    d_beta[b_idx, h_idx, c_idx, row_begin:row_end] <<= d_beta_ub[out_buf_cnt][0:1, 0:rows_this]
                    d_key[b_idx, h_idx, c_idx, row_begin:row_end, 0:D] <<= d_key_out_ub[out_buf_cnt][0:rows_this, 0:D]
                    out_buf_cnt += 1
                in_buf_cnt += 1

    return d_key, d_value, d_beta


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "delta_rule_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(
    key,
    value,
    beta,
    d_k_core,
    d_v_beta,
    d_k_beta_wu,
    d_k_pre,
    d_k_beta_pre,
    simulator=True,
    trace=None,
    gen_only=False,
    out_dir="",
    skip_compile=False,
    profile=False,
):
    B = int(key.shape[0])
    H = int(key.shape[1])
    C = int(key.shape[2])
    device = key.device
    outputs = (
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L), dtype=torch.float32, device=device),
    )
    trace_path = _trace_path(trace, out_dir, "finalize_bwd")
    previous_config = getattr(finalize_bwd_kernel, "_simulator_config", None)
    if simulator:
        finalize_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            finalize_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            profile=profile,
            gen_only=gen_only,
            skip_compile=skip_compile,
        )(
            key, value, beta, d_k_core, d_v_beta, d_k_beta_wu, d_k_pre, d_k_beta_pre,
            outputs[0], outputs[1], outputs[2],
            B, H, C, shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(finalize_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                finalize_bwd_kernel._simulator_config = previous_config
    return result[0], result[1], result[2]


if __name__ == "__main__":
    import sys
    from pathlib import Path

    _ROOT = Path(__file__).resolve().parents[4]
    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
    _REFS = Path(__file__).resolve().parents[1] / "refs"
    if str(_REFS) not in sys.path:
        sys.path.insert(0, str(_REFS))

    from common import (
        core_scan_bwd, make_inputs, inverse_preprocess_bwd, wu_recompute_bwd,
    )
    from finalize_bwd_ref import subkernel

    torch.manual_seed(42)
    B, H, C = 1, 1, 2
    full = make_inputs(B, H, C)
    scan = core_scan_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])
    wu = wu_recompute_bwd(full[1], full[2], full[3], full[5], scan[2], scan[3])
    inv = inverse_preprocess_bwd(full[1], full[3], full[5], wu[0])

    key, value, beta = full[1], full[2], full[3]
    d_k_core, d_v_beta, d_k_beta_wu = scan[1], wu[1], wu[2]
    d_k_pre, d_k_beta_pre = inv[0], inv[1]

    ref = subkernel(key, value, beta, scan[0], scan[1], wu[1], wu[2], inv[0], inv[1])

    d_key_got, d_value_got, d_beta_got = run(
        key, value, beta, d_k_core, d_v_beta, d_k_beta_wu, d_k_pre, d_k_beta_pre,
        simulator=True, out_dir="tmp/delta_bwd_fin",
    )
    d_key_ref, d_value_ref, d_beta_ref = ref[1], ref[2], ref[3]

    dk_err = (d_key_got.float() - d_key_ref.float()).abs().max().item()
    dv_err = (d_value_got.float() - d_value_ref.float()).abs().max().item()
    db_err = (d_beta_got.float() - d_beta_ref.float()).abs().max().item()
    print(f"finalize_bwd: d_key max_abs={dk_err:.3e}  d_value max_abs={dv_err:.3e}  d_beta max_abs={db_err:.3e}")
    torch.testing.assert_close(d_key_got.float(), d_key_ref.float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(d_value_got.float(), d_value_ref.float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(d_beta_got.float(), d_beta_ref.float(), rtol=2e-3, atol=2e-3)
    print("finalize_bwd OK")
