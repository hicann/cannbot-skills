"""End-to-end PyTorch composition for the KDA forward decomposition."""

from pathlib import Path
import sys

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from oracle import from_chunked_output, oracle, sample_inputs as oracle_sample_inputs, to_chunked_inputs  # noqa: E402
from sub1_gate_ref import subkernel as sub1_gate  # noqa: E402
from sub2_intra_ref import subkernel as sub2_intra  # noqa: E402
from sub3_wy_ref import subkernel as sub3_wy  # noqa: E402
from sub45_fused_ref import subkernel as sub45_fused  # noqa: E402

ATOL = 2e-2
RTOL = 2e-2
DEFAULT_CHUNK_SIZE = 64


def composed(q, k, v, g_raw, beta, initial_state=None, chunk_size=DEFAULT_CHUNK_SIZE):
    scale = q.shape[-1] ** -0.5
    q_c, k_c, v_c, g_raw_c, beta_c = to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=chunk_size)
    g_c = sub1_gate(g_raw_c)
    Aqk, Akk = sub2_intra(q_c, k_c, g_c, beta_c, scale=scale)
    w, u, qg, kg = sub3_wy(q_c, k_c, v_c, beta_c, Akk, g_c)
    o_c, final_state = sub45_fused(q_c, Aqk, kg, w, u, g_c, initial_state, scale)
    o = from_chunked_output(o_c)
    return o, final_state, g_c, Aqk, Akk, w, u, qg, kg


def sample_inputs(chunk_size=DEFAULT_CHUNK_SIZE):
    return oracle_sample_inputs(B=1, H=1, HV=1, C=1, L=chunk_size, K=64, V=64, seed=42)


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return (value,)


def _check_case(label, inputs, chunk_size):
    actual = _as_tuple(composed(*inputs, chunk_size=chunk_size))[:2]
    expected = _as_tuple(oracle(*inputs))
    if len(actual) != len(expected):
        raise AssertionError(f"arity mismatch: actual={len(actual)} expected={len(expected)}")
    max_abs = 0.0
    max_tol_ratio = 0.0
    for idx, (act, exp) in enumerate(zip(actual, expected)):
        if not torch.isfinite(act).all() or not torch.isfinite(exp).all():
            raise AssertionError(f"non-finite output at index {idx}")
        diff = (act.float() - exp.float()).abs()
        tol_ratio = diff / (ATOL + RTOL * exp.float().abs())
        max_abs = max(max_abs, float(diff.max()))
        max_tol_ratio = max(max_tol_ratio, float(tol_ratio.max()))
        torch.testing.assert_close(act.float(), exp.float(), atol=ATOL, rtol=RTOL)
    print(f"compose [{label}]: max_abs={max_abs:.3e} tol_ratio={max_tol_ratio:.3e} OK")


def main():
    cases = [
        ("single_chunk_L64", 1, 1, 1, 1, 64, 32, 32, 61),
        ("aligned64_L64", 1, 1, 1, 1, 64, 64, 64, 63),
        ("gva_two_chunks_L64", 1, 2, 4, 2, 64, 32, 32, 62),
        ("single_chunk_L32", 1, 1, 1, 1, 32, 32, 32, 71),
        ("gva_two_chunks_L32", 1, 2, 4, 2, 32, 32, 32, 72),
    ]
    for label, B, H, HV, C, chunk_size, K, V, seed in cases:
        inputs = oracle_sample_inputs(B=B, H=H, HV=HV, C=C, L=chunk_size, K=K, V=V, seed=seed)
        _check_case(label, inputs, chunk_size)
    print("OK")


if __name__ == "__main__":
    main()
