"""Pure PyTorch reference for recompute-WU backward products."""

from common import make_inputs, wu_recompute_bwd


def subkernel(key, value, beta, g_cumsum, wu_attn_bf16, d_value_wu, d_k_cumdecay):
    return wu_recompute_bwd(key, value, beta, g_cumsum, wu_attn_bf16, d_value_wu, d_k_cumdecay)


if __name__ == "__main__":
    args = make_inputs()
    scan = __import__("scan_bwd_ref").subkernel(args[0], args[1], args[5], args[6], args[7], args[10], args[11], args[12], args[13], args[14])
    result = subkernel(args[1], args[2], args[3], args[6], args[8], scan[4], scan[5])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
