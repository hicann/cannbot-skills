"""Check that the locally-built saved forward caches replay the clean forward.

The caches are stored in bf16, so the replay only matches the fp32 forward up
to bf16 quantization of the saved tensors.
"""

from common import ATOL, RTOL, _check_close, build_saved_forward, forward_reference, make_inputs, replay_forward


def main():
    inputs = make_inputs(B=1, H=2, HV=4, T=10, K=8, V=6, chunk_size=4, seed=7)
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    actual_out, actual_state = replay_forward(caches, inputs.chunk_size)
    expected_out, expected_state = forward_reference(
        inputs.q,
        inputs.k,
        inputs.v,
        inputs.g,
        inputs.beta,
        inputs.initial_state,
        inputs.chunk_size,
    )
    _check_close("forward_output", actual_out, expected_out, ATOL, RTOL)
    _check_close("forward_state", actual_state, expected_state, ATOL, RTOL)
    print("saved_forward_check: OK")


if __name__ == "__main__":
    main()
