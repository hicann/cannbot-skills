"""Randomized oracle check for sub-kernel sub1. Candidate F.

Location: `tmp_deepseek_decompose_delta_h/F/refs/sub1_check.py`

Runs N samples with inputs drawn from distributions wide enough to exercise
L1 bf16 downcast (identity on bf16-origin inputs). Includes aligned case
(B=2,H=4) and reuse_pressure case (B=8,H=16).
"""

import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

from oracle import expected_sub1          # noqa: E402
from sub1_ref import subkernel as sub1   # noqa: E402


ATOL = 2e-3
RTOL = 2e-3
N_SAMPLES = 32


def sample_inputs(B, H, C, L=64, D=128):
    q_i = torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05
    k_i = torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05
    decay_mask_i = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.1
    return q_i, k_i, decay_mask_i


def check_case(case_name, B, H, C):
    max_abs = 0.0
    max_rel = 0.0
    for _ in range(N_SAMPLES):
        q_i, k_i, decay_mask_i = sample_inputs(B, H, C)
        ref = expected_sub1(q_i, k_i, decay_mask_i)
        sub = sub1(q_i, k_i, decay_mask_i)

        if not torch.isfinite(ref).all() or not torch.isfinite(sub).all():
            print(f"FAIL [{case_name}]: non-finite value in reference or sub-kernel output",
                  file=sys.stderr)
            return False

        diff = (ref - sub).abs()
        max_abs = max(max_abs, float(diff.max()))
        denom = ref.abs().clamp_min(1e-12)
        max_rel = max(max_rel, float((diff / denom).max()))

        if not torch.allclose(sub, ref, atol=ATOL, rtol=RTOL):
            print(f"sub1 [{case_name}]: atol={max_abs:.3e} rtol={max_rel:.3e} "
                  f"(budget atol={ATOL}, rtol={RTOL})")
            print(f"FAIL [{case_name}]: exceeded policy budget", file=sys.stderr)
            return False

    print(f"sub1 [{case_name}]: atol={max_abs:.3e} rtol={max_rel:.3e} "
          f"(budget atol={ATOL}, rtol={RTOL})")
    return True


def main():
    cases = [
        ("aligned", 2, 4, 2),
        ("reuse_pressure", 8, 4, 3),
    ]
    all_passed = True
    for case_name, B, H, C in cases:
        if not check_case(case_name, B, H, C):
            all_passed = False
    if all_passed:
        print("OK")
        return 0
    else:
        return 1


if __name__ == "__main__":
    sys.exit(main())
