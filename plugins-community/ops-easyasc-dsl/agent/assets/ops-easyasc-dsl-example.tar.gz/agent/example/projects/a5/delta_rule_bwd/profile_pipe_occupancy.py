"""Per-step pipe occupancy for the delta_rule backward kernels (simulator traces).

Runs each of the 5 backward stages -- scan_local_bwd -> scan_state_bwd ->
wu_bwd -> inverse_preprocess_bwd -> finalize_bwd -- under a forced core count
with tracing on, then reports `active / span` occupancy per pipe track from each
kernel's trace file.  Upstream tensors are fed from the PyTorch refs (the same
`_ref_upstream` wiring `module_vs_ref.py` uses), so every stage sees clean inputs.

Occupancy = union of active intervals on a track / (last_end - first_start) on
that same track, with stall events excluded (only `cat in PIPE_CATS` events count).

Each leaf kernel constructs its `SimulatorConfig(core_count=DEFAULT_CORE_COUNT)`
at call time from its module global, so this profiler forces 1 core by setting
`<module>.DEFAULT_CORE_COUNT` before `run()` (the backward analog of the forward
profiler's `SIM_CORE_COUNT`).

Default profile shape is 1-core, B=1, H=1, C=8.

  python projects/a5/delta_rule_bwd/profile_pipe_occupancy.py
  python projects/a5/delta_rule_bwd/profile_pipe_occupancy.py --core-count 1 --C 8
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import torch

SCRIPT_DIR = Path(__file__).resolve().parent          # projects/a5/delta_rule_bwd
REPO_ROOT = SCRIPT_DIR.parents[2]                      # repo root
REFS_DIR = SCRIPT_DIR / "refs"
KERNELS_DIR = SCRIPT_DIR / "kernels"
TEST_DIR = SCRIPT_DIR / "test_script"
for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR), str(TEST_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import make_inputs  # noqa: E402
from module_vs_ref import _ref_upstream  # noqa: E402  (single source of the upstream wiring)

# Bare-name kernel modules (same module objects scan_split/kernel_compose import),
# so DEFAULT_CORE_COUNT overrides land on the modules whose run() we call.
import scan_local_bwd as scan_local_mod  # noqa: E402
import scan_state_bwd as scan_state_mod  # noqa: E402
import wu_bwd as wu_mod  # noqa: E402
import inverse_preprocess_bwd as inv_mod  # noqa: E402
import finalize_bwd as finalize_mod  # noqa: E402


PIPE_CATS = {"MTE2", "MTE1", "M", "FIX", "V", "MTE3"}

# DAG order: scan_local -> scan_state -> wu -> inverse_preprocess -> finalize.
STAGES = ["scan_local_bwd", "scan_state_bwd", "wu_bwd", "inverse_preprocess_bwd", "finalize_bwd"]
KERNEL_MODULES = [scan_local_mod, scan_state_mod, wu_mod, inv_mod, finalize_mod]


def _interval_union(intervals: Sequence[Tuple[float, float]]) -> float:
    if not intervals:
        return 0.0
    ordered = sorted(intervals)
    cur_start, cur_end = ordered[0]
    total = 0.0
    for start, end in ordered[1:]:
        if start <= cur_end:
            if end > cur_end:
                cur_end = end
            continue
        total += cur_end - cur_start
        cur_start, cur_end = start, end
    total += cur_end - cur_start
    return total


def _trace_makespan(trace_events: Iterable[Dict]) -> float:
    end_times = [float(e["ts"]) + float(e["dur"]) for e in trace_events if e.get("ph") == "X"]
    return max(end_times) if end_times else 0.0


def _load_trace_summary(trace_path: Path) -> Dict[str, object]:
    payload = json.loads(trace_path.read_text(encoding="utf-8"))
    events = payload.get("traceEvents", [])
    tid_to_name = {}
    for event in events:
        if event.get("ph") == "M" and event.get("name") == "thread_name":
            tid_to_name[int(event["tid"])] = str(event.get("args", {}).get("name", ""))

    pipe_intervals: Dict[str, List[Tuple[float, float]]] = {}
    for event in events:
        if event.get("ph") != "X":
            continue
        if str(event.get("cat")) not in PIPE_CATS:
            continue
        track_name = tid_to_name.get(int(event["tid"]), "")
        if not track_name:
            continue
        start = float(event["ts"])
        end = start + float(event["dur"])
        pipe_intervals.setdefault(track_name, []).append((start, end))

    occupancies = []
    for track_name, intervals in sorted(pipe_intervals.items()):
        active = _interval_union(intervals)
        span = max(end for _, end in intervals) - min(start for start, _ in intervals)
        occ = 0.0 if span <= 0.0 else active / span
        occupancies.append({"track": track_name, "active": active, "span": span, "occupancy": occ})
    occupancies.sort(key=lambda item: (-float(item["occupancy"]), item["track"]))
    return {
        "trace_path": str(trace_path),
        "makespan": _trace_makespan(events),
        "occupancies": occupancies,
    }


def _print_step(step_name: str, trace_path: Path) -> None:
    if not trace_path.exists():
        print(f"[{step_name}] (no trace at {trace_path})")
        return
    summary = _load_trace_summary(trace_path)
    print(f"[{step_name}] makespan={summary['makespan']:.1f} cycles")
    for occ in summary["occupancies"]:
        print(
            "    %-22s occ=%5.1f%%  active=%8.1f  span=%8.1f"
            % (occ["track"], 100.0 * float(occ["occupancy"]), float(occ["active"]), float(occ["span"]))
        )
    if not summary["occupancies"]:
        print("    (no pipe events)")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=1)
    parser.add_argument("--C", type=int, default=8)
    parser.add_argument("--core-count", type=int, default=1)
    parser.add_argument("--seed", type=int, default=20260609)
    parser.add_argument("--out-dir", type=str, default=str(SCRIPT_DIR / "tmp" / "pipe_profile"))
    args = parser.parse_args()

    core_count = args.core_count
    for mod in KERNEL_MODULES:
        mod.DEFAULT_CORE_COUNT = core_count

    out_root = Path(args.out_dir).resolve()
    out_root.mkdir(parents=True, exist_ok=True)
    traces = {name: out_root / f"{name}.json" for name in STAGES}

    torch.manual_seed(args.seed)
    full = make_inputs(args.B, args.H, args.C)
    local, scan, wu, inv = _ref_upstream(full)

    # Stage 1: scan_local_bwd -> (d_score_tmp, d_v_attn_tmp).
    scan_local_mod.run(
        full[0], full[1], full[4], full[9],
        simulator=True, trace=str(traces["scan_local_bwd"]), out_dir=str(out_root / "scan_local_bwd"))
    # Stage 2: scan_state_bwd -> (d_q_core, d_k_core, d_value_wu, d_k_cumdecay).
    scan_state_mod.run(
        full[0], full[1], full[4], full[7], full[8], full[10], local[0], full[9], local[1],
        simulator=True, trace=str(traces["scan_state_bwd"]), out_dir=str(out_root / "scan_state_bwd"))
    # Stage 3: wu_bwd -> (d_wu, d_v_beta, d_k_beta_wu).
    wu_mod.run(
        full[1], full[2], full[3], full[5], scan[2], scan[3],
        simulator=True, trace=str(traces["wu_bwd"]), out_dir=str(out_root / "wu_bwd"))
    # Stage 4: inverse_preprocess_bwd -> (d_k_pre, d_k_beta_pre).
    inv_mod.run(
        full[1], full[3], full[5], wu[0],
        simulator=True, trace=str(traces["inverse_preprocess_bwd"]), out_dir=str(out_root / "inverse_preprocess_bwd"))
    # Stage 5: finalize_bwd -> (d_key, d_value, d_beta).
    finalize_mod.run(
        full[1], full[2], full[3], scan[1], wu[1], wu[2], inv[0], inv[1],
        simulator=True, trace=str(traces["finalize_bwd"]), out_dir=str(out_root / "finalize_bwd"))

    print(f"\n=== delta_rule_bwd pipe occupancy  core_count={core_count}  B={args.B} H={args.H} C={args.C} ===")
    _print_step("stage1 scan_local_bwd", traces["scan_local_bwd"])
    _print_step("stage2 scan_state_bwd", traces["scan_state_bwd"])
    _print_step("stage3 wu_bwd", traces["wu_bwd"])
    _print_step("stage4 inverse_preprocess_bwd", traces["inverse_preprocess_bwd"])
    _print_step("stage5 finalize_bwd", traces["finalize_bwd"])


if __name__ == "__main__":
    raise SystemExit(main())
