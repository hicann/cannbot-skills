"""Candidate-local expected outputs for sub-kernel checks. Candidate F.

Location: `tmp_deepseek_decompose_delta_h/F/refs/oracle_slices.py`

Each expected_* helper computes the oracle's local slice for one sub-kernel
following the DAG in plan.md.  The expected outputs are derived directly
from the shared oracle formula without importing it, so each sub can be
checked in isolation.
"""

import torch


def expected_sub1(q_i, k_i, decay_mask_i):
    """Oracle attn from M1 alone.

    Accepts a single chunk [B,H,L,D] or full C input [B,H,C,L,D]. The
    sub1->sub2 GM boundary is bf16 in the authored execution path.
    """
    return (q_i.float() @ k_i.float().transpose(-1, -2) * decay_mask_i).bfloat16()


def expected_sub2(attn, q_i, k_i, v_i, k_cumdecay_i, g_i, last_recurrent_state):
    """Oracle fused M2-M5 output over the full C loop."""
    B, H, C, L, D = q_i.shape
    core_attn_out = torch.empty(B, H, C, L, D, dtype=torch.bfloat16, device=q_i.device)
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=q_i.device)

    for i in range(C):
        q = q_i[:, :, i].float()
        k = k_i[:, :, i].float()
        v = v_i[:, :, i].float()
        k_cumdecay = k_cumdecay_i[:, :, i].float()
        g = g_i[:, :, i].float()

        v_prime = k_cumdecay @ state.float()
        v_new = (v - v_prime).bfloat16()
        attn_inter = (q @ state.float()) * g[:, :, :, None].exp()
        core_attn_out[:, :, i] = (attn_inter + attn[:, :, i].float() @ v_new.float()).bfloat16()

        g_last = g[:, :, -1]
        k_weighted = k * (g_last[:, :, None] - g).exp()[..., None]
        state = (
            state.float() * g_last[:, :, None, None].exp()
            + k_weighted.transpose(-1, -2).bfloat16().float() @ v_new.float()
        ).bfloat16()

    return core_attn_out, state


def expected_sub2_state_history(attn, q_i, k_i, v_i, k_cumdecay_i, g_i, last_recurrent_state):
    """Sub2 oracle that also returns post-update state and saved bwd inputs."""
    B, H, C, L, D = q_i.shape
    core_attn_out = torch.empty(B, H, C, L, D, dtype=torch.bfloat16, device=q_i.device)
    state_after_history = torch.empty(B, H, C, D, D, dtype=torch.bfloat16, device=q_i.device)
    v_new_history = torch.empty(B, H, C, L, D, dtype=torch.bfloat16, device=q_i.device)
    k_weighted_history = torch.empty(B, H, C, L, D, dtype=torch.bfloat16, device=q_i.device)
    exp_delta_history = torch.empty(B, H, C, L, dtype=torch.float32, device=q_i.device)
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=q_i.device)

    for i in range(C):
        q = q_i[:, :, i].float()
        k = k_i[:, :, i].float()
        v = v_i[:, :, i].float()
        k_cumdecay = k_cumdecay_i[:, :, i].float()
        g = g_i[:, :, i].float()

        v_prime = k_cumdecay @ state.float()
        v_new = (v - v_prime).bfloat16()
        v_new_history[:, :, i] = v_new
        attn_inter = (q @ state.float()) * g[:, :, :, None].exp()
        core_attn_out[:, :, i] = (attn_inter + attn[:, :, i].float() @ v_new.float()).bfloat16()

        g_last = g[:, :, -1]
        exp_delta = (g_last[:, :, None] - g).exp()
        exp_delta_history[:, :, i] = exp_delta
        k_weighted = k * exp_delta[..., None]
        k_weighted_history[:, :, i] = k_weighted.bfloat16()
        state = (
            state.float() * g_last[:, :, None, None].exp()
            + k_weighted.transpose(-1, -2).bfloat16().float() @ v_new.float()
        ).bfloat16()
        state_after_history[:, :, i] = state

    return core_attn_out, state, state_after_history, v_new_history, k_weighted_history, exp_delta_history


def oracle_full(query, key, value, g, decay_mask, k_cumdecay):
    B, H, _C, _L, D = query.shape
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=query.device)
    attn = expected_sub1(query, key, decay_mask)
    return expected_sub2(attn, query, key, value, k_cumdecay, g, state)


def oracle_full_state_history(query, key, value, g, decay_mask, k_cumdecay):
    B, H, _C, _L, D = query.shape
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=query.device)
    attn = expected_sub1(query, key, decay_mask)
    return expected_sub2_state_history(attn, query, key, value, k_cumdecay, g, state)
