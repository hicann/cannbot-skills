"""End-to-end PyTorch reference composition - ungated delta-rule chunk recurrence.

sub1 handles all chunks; sub2 owns the recurrent C loop for M2-M5.
"""
import sys
from pathlib import Path
import torch

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

from sub1_ref import subkernel as sub1
from sub2_ref import subkernel as sub2
from oracle import oracle_full

ATOL = 2e-3
RTOL = 2e-3
N_SAMPLES = 32
L = 64
D = 128


def composed(query, key, value, k_cumdecay):
    B, H, _C, _L, _D = query.shape
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=query.device)
    attn = sub1(query, key)
    return sub2(attn, query, key, value, k_cumdecay, state)


def sample_inputs(B=4, H=8, C=2):
    return (
        torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05,
        torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05,
        torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05,
        torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05,
    )


def main():
    for case, B, H, C in [("aligned", 2, 4, 2), ("reuse_pressure", 8, 4, 3)]:
        max_abs, max_rel = 0.0, 0.0
        for _ in range(N_SAMPLES):
            args = sample_inputs(B, H, C)
            ref_core, ref_state = oracle_full(*args)
            cmp_core, cmp_state = composed(*args)
            for label, ref, cmp in [("core", ref_core, cmp_core), ("state", ref_state, cmp_state)]:
                rf, cf = ref.float(), cmp.float()
                diff = (cf - rf).abs()
                max_abs = max(max_abs, float(diff.max()))
                max_rel = max(max_rel, float((diff / rf.abs().clamp_min(1e-12)).max()))
                if not torch.allclose(cf, rf, atol=ATOL, rtol=RTOL):
                    print(f"compose [{case}/{label}] FAIL", file=sys.stderr)
                    return 1
        print(f"compose [{case} B={B} H={H} C={C}]: atol={max_abs:.3e} rtol={max_rel:.3e} OK")
    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
