"""Speed test for FLA's chunked delta-rule *backward* (Triton) with torch.profiler.

This benchmarks the *reference* GPU implementation — FLA's `chunk_delta_rule`
backward (https://github.com/fla-org/flash-linear-attention, the
`fla/ops/delta_rule/chunk.py` op, whose backward is the autograd pass at
`chunk.py#L61` that the EasyASC `delta_rule_bwd` kernels port). It is the GPU
baseline to compare the Ascend (a5/950) backward kernels against; it does NOT run
the EasyASC kernels.

This is the backward counterpart of `delta_rule_fwd/test_script/profile_fla_delta_rule.py`:
same op, same representative shape, but it builds the autograd graph (q/k/v/beta
require grad) and times `out.backward(grad_output)`.

Requires an NVIDIA CUDA GPU and `flash-linear-attention` installed:

    pip install flash-linear-attention   # pulls in triton
    python projects/a5/delta_rule_bwd/test_script/profile_fla_delta_rule_bwd.py

Representative shape (matches the kernel's chunked layout B,H,C,L,D):

    B=1, H=32, C=16, L=64, D=128   ->   FLA sequence length T = C*L = 1024

FLA's op is *not* chunked at the Python boundary: it takes the full sequence
[*, T, *] and tiles internally (chunk size 64 == our L), so we pass T=C*L.

How the backward is isolated:
  * Headline backward latency uses CUDA events placed *after* the forward and
    *around* `out.backward(do)` in the same (in-order) stream, so the forward —
    re-run fresh each iter to keep the graph valid — is excluded from the delta.
  * Forward-only and full fwd+bwd step latencies are reported alongside for context.
  * The torch.profiler table is taken over backward-only (one forward built up
    front, then `backward(retain_graph=True)` in the loop); if this FLA version
    won't re-enter the graph, it falls back to fresh-forward-each-iter and says so.

Output mirrors the forward script: CUDA-event headline latencies, a torch.profiler
key-averages table (top CUDA kernels), and a Chrome trace (open in chrome://tracing).

The script introspects `chunk_delta_rule`'s signature so it works across FLA
versions (layout flag `head_first`, plus `scale`/`output_final_state`/
`use_qk_l2norm_in_kernel` passed only when supported).
"""

from __future__ import annotations

import argparse
import inspect
import sys
from pathlib import Path

import torch


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--B", type=int, default=1, help="batch")
    p.add_argument("--H", type=int, default=32, help="heads")
    p.add_argument("--C", type=int, default=16, help="number of chunks (T = C*L)")
    p.add_argument("--L", type=int, default=64, help="chunk length (FLA internal chunk size)")
    p.add_argument("--D", type=int, default=128, help="head dim")
    p.add_argument("--iters", type=int, default=10, help="timed iterations")
    p.add_argument("--warmup", type=int, default=5, help="warmup iterations (untimed)")
    p.add_argument("--dtype", choices=("bf16", "fp16"), default="bf16")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--trace", type=str, default=str(Path(__file__).resolve().parent / "tmp" / "fla_delta_rule_bwd_trace.json"),
                   help="Chrome trace output path")
    p.add_argument("--rows", type=int, default=15, help="rows in the profiler table")
    return p.parse_args()


def _build_inputs(B, H, C, L, D, dtype, device, head_first):
    """Leaf q/k/v/beta (requires_grad=True) in the layout FLA expects.

    head_first=True  -> [B, H, T, D], beta [B, H, T]
    head_first=False -> [B, T, H, D], beta [B, T, H]
    """
    T = C * L
    if head_first:
        qkv_shape, beta_shape = (B, H, T, D), (B, H, T)
    else:
        qkv_shape, beta_shape = (B, T, H, D), (B, T, H)

    q = torch.randn(qkv_shape, device=device, dtype=dtype)
    k = torch.randn(qkv_shape, device=device, dtype=dtype)
    v = torch.randn(qkv_shape, device=device, dtype=dtype)
    # beta in (0, 1), as produced by the delta-net beta projection (sigmoid).
    beta = torch.rand(beta_shape, device=device, dtype=dtype)
    for t in (q, k, v, beta):
        t.requires_grad_(True)
    return q, k, v, beta


def main() -> int:
    args = _parse_args()

    if not torch.cuda.is_available():
        print(
            "ERROR: FLA's chunk_delta_rule is a Triton/CUDA kernel and needs an "
            "NVIDIA GPU. Run this on a CUDA box (it does not run on CPU / Ascend NPU).",
            file=sys.stderr,
        )
        return 2

    try:
        from fla.ops.delta_rule import chunk_delta_rule
    except Exception as exc:  # pragma: no cover - depends on the runtime box
        print(f"ERROR: could not import fla.ops.delta_rule.chunk_delta_rule: {exc}", file=sys.stderr)
        print("Install with:  pip install flash-linear-attention", file=sys.stderr)
        return 2

    device = "cuda"
    dtype = torch.bfloat16 if args.dtype == "bf16" else torch.float16
    torch.manual_seed(args.seed)

    B, H, C, L, D = args.B, args.H, args.C, args.L, args.D
    T = C * L
    scale = D ** -0.5  # FLA's default (head_dim ** -0.5)

    # --- adapt to this FLA version's signature -------------------------------
    params = inspect.signature(chunk_delta_rule).parameters
    head_first = "head_first" in params
    use_kernel_l2 = "use_qk_l2norm_in_kernel" in params

    call_kwargs = {}
    if "scale" in params:
        call_kwargs["scale"] = scale
    if "output_final_state" in params:
        call_kwargs["output_final_state"] = False
    if head_first:
        call_kwargs["head_first"] = True
    if use_kernel_l2:
        # let the kernel do the q/k L2-norm (closest to real delta-net usage), so
        # its backward is part of the FLA backward we are timing.
        call_kwargs["use_qk_l2norm_in_kernel"] = True

    q, k, v, beta = _build_inputs(B, H, C, L, D, dtype, device, head_first=head_first)
    leaves = (q, k, v, beta)
    l2norm_outside = not use_kernel_l2

    def run_fwd():
        qi, ki = q, k
        if l2norm_outside:
            # delta-net L2-normalizes q/k before the op; keep it differentiable so
            # q/k grads still flow (only when the kernel won't normalize internally).
            qi = torch.nn.functional.normalize(q.float(), p=2, dim=-1).to(dtype)
            ki = torch.nn.functional.normalize(k.float(), p=2, dim=-1).to(dtype)
        out = chunk_delta_rule(qi, ki, v, beta, **call_kwargs)
        return out[0] if isinstance(out, (tuple, list)) else out

    def zero_grads():
        for t in leaves:
            t.grad = None

    # --- sanity (shape + finiteness of output and grads) ---------------------
    o = run_fwd()
    do = torch.randn_like(o)
    torch.cuda.synchronize()
    layout = "[B,H,T,D]" if head_first else "[B,T,H,D]"
    print(f"FLA chunk_delta_rule BWD | B={B} H={H} C={C} L={L} D={D}  T=C*L={T}  layout={layout}")
    print(f"  signature kwargs: {call_kwargs}")
    print(f"  output: shape={tuple(o.shape)} dtype={o.dtype} finite={torch.isfinite(o).all().item()}")

    zero_grads()
    o.backward(do, retain_graph=True)
    torch.cuda.synchronize()
    grads_ok = all(t.grad is not None and torch.isfinite(t.grad).all().item() for t in leaves)
    gshapes = ", ".join(f"{n}={tuple(t.grad.shape)}" for n, t in zip(("dq", "dk", "dv", "dbeta"), leaves))
    print(f"  grads finite={grads_ok}  ({gshapes})")

    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)

    # --- forward-only latency (context) --------------------------------------
    for _ in range(args.warmup):
        run_fwd()
    torch.cuda.synchronize()
    starter.record()
    for _ in range(args.iters):
        run_fwd()
    ender.record()
    torch.cuda.synchronize()
    fwd_ms = starter.elapsed_time(ender) / args.iters

    # --- backward-only latency (headline) ------------------------------------
    # Fresh forward each iter keeps the graph valid; the events sit after the
    # forward in the in-order stream, so only backward is timed.
    for _ in range(args.warmup):
        oo = run_fwd()
        zero_grads()
        oo.backward(do)
    torch.cuda.synchronize()
    bwd_total = 0.0
    for _ in range(args.iters):
        oo = run_fwd()
        zero_grads()
        starter.record()
        oo.backward(do)
        ender.record()
        torch.cuda.synchronize()
        bwd_total += starter.elapsed_time(ender)
    bwd_ms = bwd_total / args.iters

    # --- full fwd+bwd step latency (context) ---------------------------------
    step_total = 0.0
    for _ in range(args.iters):
        zero_grads()
        starter.record()
        oo = run_fwd()
        oo.backward(do)
        ender.record()
        torch.cuda.synchronize()
        step_total += starter.elapsed_time(ender)
    step_ms = step_total / args.iters

    toks = B * T
    print(
        f"\n[cuda-event] over {args.iters} iters (avg ms/iter):"
        f"\n  forward      : {fwd_ms:.4f} ms"
        f"\n  backward     : {bwd_ms:.4f} ms   ({toks / (bwd_ms * 1e3):.2f} Mtok/s)   <- headline"
        f"\n  fwd+bwd step : {step_ms:.4f} ms"
    )

    # --- torch.profiler breakdown over the backward --------------------------
    from torch.profiler import ProfilerActivity, profile, record_function

    o_prof = run_fwd()
    torch.cuda.synchronize()
    profiled_what = "backward-only (retain_graph)"
    try:
        with profile(
            activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
            record_shapes=True,
            with_stack=False,
        ) as prof:
            for _ in range(args.iters):
                zero_grads()
                with record_function("fla_chunk_delta_rule_bwd"):
                    o_prof.backward(do, retain_graph=True)
            torch.cuda.synchronize()
    except RuntimeError:
        # This FLA version frees the graph after one backward; profile fresh
        # fwd+bwd instead (the table then also includes the forward kernels).
        profiled_what = "fwd+bwd (retain_graph unsupported)"
        with profile(
            activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
            record_shapes=True,
            with_stack=False,
        ) as prof:
            for _ in range(args.iters):
                oo = run_fwd()
                zero_grads()
                with record_function("fla_chunk_delta_rule_bwd"):
                    oo.backward(do)
            torch.cuda.synchronize()

    print(f"\n[torch.profiler] top {args.rows} ops by CUDA self time over {args.iters} iters ({profiled_what}):")
    print(prof.key_averages().table(sort_by="self_cuda_time_total", row_limit=args.rows))

    trace_path = Path(args.trace)
    trace_path.parent.mkdir(parents=True, exist_ok=True)
    prof.export_chrome_trace(str(trace_path))
    print(f"[torch.profiler] Chrome trace written to {trace_path}  (open in chrome://tracing)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
