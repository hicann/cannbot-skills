"""Inverse-stage elementwise epilogue (formerly the host triple loop).

Consumes the bf16 `inverse_mm` fan-out (`d_qg, d_kg, d_v_beta, d_k_beta_g`)
plus `q, k, v, beta, g_cumsum, h, dh` and produces the per-token gradients
`dq_hv, dk_hv, dv, dbeta, dg_core` and the reusable `k_exp = k * exp2(g)`
(needed by the dA_inv path in `inverse_dakk`). All vector work; one `@vf` per
chunk.

Precision: bf16 GM IO, fp32 in-register compute. exp2 is computed as
`(g * ln2).exp()` because a5 micro has only natural `exp` (the stored
`g_cumsum` already carries the `1/ln2` factor, so `2^g_stored` is the target).

`d_g_last` (added to `dg` row L-1 only) has two parts:
  term1 = (h * dh).sum(V) * exp2(g_last)   -- per-K row dot over [D, D]
  term2 = (k * dk_from_kg).sum(token)       -- cross-row accumulate over L
"""

import builtins
import math
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _torch_formula import D, L, build_saved_forward, inverse_qkgw_only, inverse_beta_only, scan_bwd
from _layout import flat_lvd, to_lvd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
HALF_D = D // 2
REGS_D = D // 64
LN2 = math.log(2.0)
SCALE = 1.0 / (D ** 0.5)
BETA_SCALAR_PACK = DT.bfloat16.C0  # 32B row for one bf16 scalar burst
DBETA_SCALAR_PACK = DT.float.C0    # 32B row for one fp32 scalar burst
# d_* are GM-native (internal, from inverse_mm). q/k are frozen [B,T,H,D] with H
# query heads (gathered H->HV on-device, head axis = sym3 to stay distinct from
# C = sym2 when H == C); v/g_cumsum are frozen BTHVD; beta is frozen BTHV; h/dh
# are frozen [B,C,HV,D,D]. The four token-major grads + dbeta are written strided
# to the public seams; k_exp stays GM-native (internal -> inverse_dainv).
# Var args: B/HV/C/Hq/G.
SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],   # d_qg       [B, HV, C, L, D]  internal
    1: [0, 1, 2, None, None],   # d_kg
    2: [0, 1, 2, None, None],   # d_v_beta
    3: [0, 1, 2, None, None],   # d_k_beta_g
    4: [0, None, 3, None],      # q          [B, T, H, D]   gather (H = sym3)
    5: [0, None, 3, None],      # k          [B, T, H, D]
    6: [0, None, 1, None],      # v          [B, T, HV, D]
    7: [0, None, 1, None],      # g_cumsum   [B, T, HV, D]
    8: [0, None, 1],            # beta       [B, T, HV]
    9: [0, 2, 1, None, None],   # h          [B, C, HV, D, D]
    10: [0, 2, 1, None, None],  # dh         [B, C, HV, D, D]
    11: [0, None, 1, None],     # dq_hv      [B, T, HV, D]  -> finalize_post
    12: [0, None, 1, None],     # dk_hv      [B, T, HV, D]
    13: [0, None, 1, None],     # dv         [B, T, HV, D]  -> public
    14: [0, None, 1],           # dbeta      [B, T, HV] fp32 -> finalize_post
    15: [0, None, 1, None],     # dg_core    [B, T, HV, D]  -> finalize_post
    16: [0, 1, 2, None, None],  # k_exp      [B, HV, C, L, D]  internal
}


@vf()
def compute_exp_glast_vf(g_ub: Tensor, exp_glast_ub: Tensor):
    glast = RegList(DT.float, REGS_D)
    glast <<= g_ub[L - 1:L, 0:D]
    glast <<= glast * LN2
    glast <<= glast.exp()
    exp_glast_ub[0:1, 0:D] <<= glast
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def dglast_term1_vf(h_ub: Tensor, dh_ub: Tensor, exp_glast_ub: Tensor, dglast_ub: Tensor, row_begin: Var, rows: Var):
    h_regs = RegList(DT.float, REGS_D)
    dh_regs = RegList(DT.float, REGS_D)
    prod = RegList(DT.float, REGS_D)
    dot = Reg(DT.float)
    scale = Reg(DT.float)
    for r in range(rows):
        gk = Var(row_begin + r)
        h_regs <<= h_ub[r:r + 1, 0:D]
        dh_regs <<= dh_ub[r:r + 1, 0:D]
        prod <<= h_regs * dh_regs
        dot <<= prod.cadd()
        scale <<= exp_glast_ub[0:1, gk:gk + 1].single()
        dot <<= dot * scale
        dglast_ub[0:1, gk:gk + 1] <<= dot.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def inverse_epilogue_vf(
    q_ub: Tensor,
    k_ub: Tensor,
    v_ub: Tensor,
    g_ub: Tensor,
    dqg_ub: Tensor,
    dkg_ub: Tensor,
    dvbeta_ub: Tensor,
    dkbetag_ub: Tensor,
    beta_ub: Tensor,
    dglast_ub: Tensor,
    dq_ub: Tensor,
    dk_ub: Tensor,
    dv_ub: Tensor,
    dbeta_ub: Tensor,
    dg_ub: Tensor,
    kexp_ub: Tensor,
    rows: Var,
):
    glast = RegList(DT.float, REGS_D)
    g = RegList(DT.float, REGS_D)
    expg = RegList(DT.float, REGS_D)
    explmg = RegList(DT.float, REGS_D)
    q = RegList(DT.float, REGS_D)
    k = RegList(DT.float, REGS_D)
    v = RegList(DT.float, REGS_D)
    dqg = RegList(DT.float, REGS_D)
    dkg = RegList(DT.float, REGS_D)
    dvbeta = RegList(DT.float, REGS_D)
    dkbetag = RegList(DT.float, REGS_D)
    dq = RegList(DT.float, REGS_D)
    dkkg = RegList(DT.float, REGS_D)
    kexp = RegList(DT.float, REGS_D)
    dkw = RegList(DT.float, REGS_D)
    dgw = RegList(DT.float, REGS_D)
    dg = RegList(DT.float, REGS_D)
    tmp = RegList(DT.float, REGS_D)
    prod = RegList(DT.float, REGS_D)
    acc = RegList(DT.float, REGS_D)
    beta_r = Reg(DT.float)
    db1 = Reg(DT.float)
    db2 = Reg(DT.float)

    glast <<= g_ub[L - 1:L, 0:D]
    acc.fill(0.0)

    for r in range(rows):
        g <<= g_ub[r:r + 1, 0:D]
        tmp <<= g * LN2
        expg <<= tmp.exp()
        tmp <<= glast - g
        tmp <<= tmp * LN2
        explmg <<= tmp.exp()

        # dq = d_qg * exp_g * scale  (fp32 kept for dg)
        dqg <<= dqg_ub[r:r + 1, 0:D]
        dq <<= dqg * expg
        dq <<= dq * SCALE
        dq_ub[r * D] <<= dq[0]
        dq_ub[r * D + 64] <<= dq[1]

        # dk_from_kg = d_kg * exp2(g_last - g)
        dkg <<= dkg_ub[r:r + 1, 0:D]
        dkkg <<= dkg * explmg

        # k_exp = k * exp_g
        k <<= k_ub[r:r + 1, 0:D]
        kexp <<= k * expg
        kexp_ub[r * D] <<= kexp[0]
        kexp_ub[r * D + 64] <<= kexp[1]

        # dv = d_v_beta * beta
        beta_r <<= beta_ub[r:r + 1, 0:1].single()
        dvbeta <<= dvbeta_ub[r:r + 1, 0:D]
        tmp <<= dvbeta * beta_r
        dv_ub[r * D] <<= tmp[0]
        dv_ub[r * D + 64] <<= tmp[1]

        # dbeta = (d_v_beta * v).sum + (d_k_beta_g * k_exp).sum
        v <<= v_ub[r:r + 1, 0:D]
        prod <<= dvbeta * v
        db1 <<= prod.cadd()
        dkbetag <<= dkbetag_ub[r:r + 1, 0:D]
        prod <<= dkbetag * kexp
        db2 <<= prod.cadd()
        db1 <<= db1 + db2
        dbeta_ub[r:r + 1, 0:1] <<= db1.single_value()

        # dk_from_w = d_k_beta_g * beta * exp_g ; dk_hv = dk_from_kg + dk_from_w
        dkw <<= dkbetag * beta_r
        dkw <<= dkw * expg
        tmp <<= dkkg + dkw
        dk_ub[r * D] <<= tmp[0]
        dk_ub[r * D + 64] <<= tmp[1]

        # dg_from_w = d_k_beta_g * k_exp * beta
        dgw <<= dkbetag * kexp
        dgw <<= dgw * beta_r

        # dg = q * dq - k * dk_from_kg + dg_from_w
        q <<= q_ub[r:r + 1, 0:D]
        dg <<= q * dq
        prod <<= k * dkkg
        dg <<= dg - prod
        dg <<= dg + dgw
        dg_ub[r * D] <<= dg[0]
        dg_ub[r * D + 64] <<= dg[1]

        # term2 accumulator: sum_token (k * dk_from_kg)
        acc <<= acc + prod

    # d_g_last = term1 (dglast_ub) + term2 (acc); add into dg row L-1 only.
    # The loop already wrote dg_ub[L-1]; barrier so that store is visible to the
    # read-modify-write below (store -> load on the same range).
    tmp <<= dglast_ub[0:1, 0:D]
    acc <<= acc + tmp
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    dg <<= dg_ub[L - 1:L, 0:D]
    dg <<= dg + acc
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    dg_ub[(L - 1) * D] <<= dg[0]
    dg_ub[(L - 1) * D + 64] <<= dg[1]
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def inverse_epilogue_kernel(
    d_qg: GMTensor,
    d_kg: GMTensor,
    d_v_beta: GMTensor,
    d_k_beta_g: GMTensor,
    q: GMTensor,
    k: GMTensor,
    v: GMTensor,
    g_cumsum: GMTensor,
    beta: GMTensor,
    h: GMTensor,
    dh: GMTensor,
    dq_hv: GMTensor,
    dk_hv: GMTensor,
    dv: GMTensor,
    dbeta: GMTensor,
    dg_core: GMTensor,
    k_exp: GMTensor,
    B: Var,
    HV: Var,
    C: Var,
    Hq: Var,
    G: Var,
):
    dqg_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dkg_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dvbeta_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dkbetag_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    q_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    k_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    v_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    g_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    # Scalar burst copies need a 32B physical row; packing beta/dbeta as [L, C0]
    # keeps each token's scalar at a row start instead of a sparse [1, L] layout.
    beta_ub = Tensor(DT.bfloat16, [L, BETA_SCALAR_PACK], Position.UB)
    h_ub = Tensor(DT.bfloat16, [HALF_D, D], Position.UB)
    dh_ub = Tensor(DT.bfloat16, [HALF_D, D], Position.UB)

    exp_glast_ub = Tensor(DT.float, [1, D], Position.UB)
    dglast_ub = Tensor(DT.float, [1, D], Position.UB)

    dq_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dk_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dv_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dg_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    kexp_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dbeta_ub = Tensor(DT.float, [L, DBETA_SCALAR_PACK], Position.UB)

    work_count = Var(B * HV * C)
    work_per_core = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_core * GetCubeIdx())
    work_end = Min(work_begin + work_per_core, work_count)

    with auto_sync():
        for work in range(work_begin, work_end):
            c_idx = Var(work % C)
            bhv = Var(work / C)
            hv_idx = Var(bhv % HV)
            b_idx = Var(bhv / HV)
            tok0 = Var(c_idx * L)
            tok1 = Var(tok0 + L)
            h_idx = Var(hv_idx / G)   # H->HV gather: q/k own a contiguous G-block

            # g_cumsum strided from frozen BTHVD (explicit (HV-1)*D gap).
            gm_to_ub_pad(g_ub[0:L, 0:D], g_cumsum[b_idx, tok0:tok1, hv_idx, 0:D], L, D, (HV - 1) * D, 0)
            compute_exp_glast_vf(g_ub, exp_glast_ub)

            for half in range(2):
                row0 = Var(half * HALF_D)
                row1 = Var(row0 + HALF_D)
                # h/dh contiguous [D,D] blocks from frozen [B,C,HV,D,D]: index
                # reorder only (the half-row slice keeps source row pitch D).
                h_ub[0:HALF_D, 0:D] <<= h[b_idx, c_idx, hv_idx, row0:row1, 0:D]
                dh_ub[0:HALF_D, 0:D] <<= dh[b_idx, c_idx, hv_idx, row0:row1, 0:D]
                dglast_term1_vf(h_ub, dh_ub, exp_glast_ub, dglast_ub, row0, Var(HALF_D))

            dqg_ub[0:L, 0:D] <<= d_qg[b_idx, hv_idx, c_idx, 0:L, 0:D]
            dkg_ub[0:L, 0:D] <<= d_kg[b_idx, hv_idx, c_idx, 0:L, 0:D]
            dvbeta_ub[0:L, 0:D] <<= d_v_beta[b_idx, hv_idx, c_idx, 0:L, 0:D]
            dkbetag_ub[0:L, 0:D] <<= d_k_beta_g[b_idx, hv_idx, c_idx, 0:L, 0:D]
            # q/k strided + H->HV gather from frozen [B,T,H,D] (gap (Hq-1)*D);
            # v strided from frozen BTHVD; beta strided burst_len=1 from BTHV.
            gm_to_ub_pad(q_ub[0:L, 0:D], q[b_idx, tok0:tok1, h_idx, 0:D], L, D, (Hq - 1) * D, 0)
            gm_to_ub_pad(k_ub[0:L, 0:D], k[b_idx, tok0:tok1, h_idx, 0:D], L, D, (Hq - 1) * D, 0)
            gm_to_ub_pad(v_ub[0:L, 0:D], v[b_idx, tok0:tok1, hv_idx, 0:D], L, D, (HV - 1) * D, 0)
            gm_to_ub_pad(beta_ub[0:L, 0:1], beta[b_idx, tok0:tok1, hv_idx], L, 1, HV - 1, 0)

            inverse_epilogue_vf(
                q_ub, k_ub, v_ub, g_ub, dqg_ub, dkg_ub, dvbeta_ub, dkbetag_ub,
                beta_ub, dglast_ub,
                dq_ub, dk_ub, dv_ub, dbeta_ub, dg_ub, kexp_ub, Var(L),
            )

            # Inter-stage grads written strided to the frozen public seams:
            # dq_hv/dk_hv/dv/dg_core BTHVD ((HV-1)*D gap), dbeta BTHV fp32
            # ((HV-1) gap). k_exp stays GM-native (internal -> inverse_dainv).
            ub_to_gm_pad(dq_hv[b_idx, tok0:tok1, hv_idx, 0:D], dq_ub[0:L, 0:D], L, D, 0, (HV - 1) * D)
            ub_to_gm_pad(dk_hv[b_idx, tok0:tok1, hv_idx, 0:D], dk_ub[0:L, 0:D], L, D, 0, (HV - 1) * D)
            ub_to_gm_pad(dv[b_idx, tok0:tok1, hv_idx, 0:D], dv_ub[0:L, 0:D], L, D, 0, (HV - 1) * D)
            ub_to_gm_pad(dbeta[b_idx, tok0:tok1, hv_idx], dbeta_ub[0:L, 0:1], L, 1, 0, HV - 1)
            ub_to_gm_pad(dg_core[b_idx, tok0:tok1, hv_idx, 0:D], dg_ub[0:L, 0:D], L, D, 0, (HV - 1) * D)
            k_exp[b_idx, hv_idx, c_idx, 0:L, 0:D] <<= kexp_ub[0:L, 0:D]

    return dq_hv, dk_hv, dv, dbeta, dg_core, k_exp


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(d_qg, d_kg, d_v_beta, d_k_beta_g, q, k, v, g_cumsum, beta, h, dh, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    # No host glue: q/k are frozen [B,T,H,D] (H query heads, gathered H->HV
    # on-device); v/g_cumsum frozen BTHVD; beta frozen BTHV; h/dh frozen
    # [B,C,HV,D,D]; d_* GM-native (internal, from inverse_mm). All bf16. The four
    # token-major grads + dbeta are written strided to the public seams; k_exp
    # stays GM-native (internal -> inverse_dainv).
    bf16 = torch.bfloat16
    B = int(q.shape[0])
    T = int(q.shape[1])
    Hq = int(q.shape[2])
    HV = int(v.shape[2])
    C = T // L
    G = HV // Hq
    for name, tensor in (
        ("d_qg", d_qg), ("d_kg", d_kg), ("d_v_beta", d_v_beta), ("d_k_beta_g", d_k_beta_g),
        ("q", q), ("k", k), ("v", v), ("g_cumsum", g_cumsum),
        ("beta", beta), ("h", h), ("dh", dh),
    ):
        if tensor.dtype != bf16:
            raise TypeError(f"{name} must be bfloat16, got {tensor.dtype}")

    outputs = (
        torch.empty((B, T, HV, D), dtype=bf16, device=q.device),        # dq_hv   BTHVD
        torch.empty((B, T, HV, D), dtype=bf16, device=q.device),        # dk_hv   BTHVD
        torch.empty((B, T, HV, D), dtype=bf16, device=q.device),        # dv      BTHVD (-> public)
        torch.empty((B, T, HV), dtype=torch.float32, device=q.device),  # dbeta   BTHV fp32
        torch.empty((B, T, HV, D), dtype=bf16, device=q.device),        # dg_core BTHVD
        torch.empty((B, HV, C, L, D), dtype=bf16, device=q.device),     # k_exp   GM-native internal
    )
    previous_config = getattr(inverse_epilogue_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "inverse_epilogue")
    if simulator:
        inverse_epilogue_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            inverse_epilogue_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            d_qg, d_kg, d_v_beta, d_k_beta_g, q, k, v, g_cumsum,
            beta, h, dh,
            outputs[0], outputs[1], outputs[2], outputs[3], outputs[4], outputs[5],
            B, HV, C, Hq, G, shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(inverse_epilogue_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                inverse_epilogue_kernel._simulator_config = previous_config
    if gen_only:
        return result

    # dq_hv/dk_hv/dv/dg_core [B, T, HV, D] bf16 + dbeta [B, T, HV] fp32: public
    # BTHVD/BTHV seams written strided on-device. k_exp [B, HV, C, L, D] bf16 is
    # internal (-> inverse_dainv). No host layout/dtype conversion.
    return result[0], result[1], result[2], result[3], result[4], result[5]


if __name__ == "__main__":
    from projects.a5.kda_bwd.refs.common import make_inputs

    tol = 6e-3
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    caches = build_saved_forward(inputs)
    scan = scan_bwd(inputs, caches)
    d_qg, d_kg, d_vh = inverse_qkgw_only(inputs, caches, scan)
    d_w = -d_vh
    d_v_beta, d_k_beta_g = inverse_beta_only(inputs, caches, scan, d_w)

    bf16 = torch.bfloat16
    # d_* are internal (inverse_mm GM-native, scaffolded via to_lvd); q/k/v/g/beta
    # /h/dh are raw frozen -- the kernel reads them strided (and gathers q/k).
    got = run(
        to_lvd(d_qg.to(bf16)), to_lvd(d_kg.to(bf16)),
        to_lvd(d_v_beta.to(bf16)), to_lvd(d_k_beta_g.to(bf16)),
        inputs.q, inputs.k, inputs.v, caches.g_cumsum,
        inputs.beta, caches.h, scan.dh,
        simulator=True,
    )
    # dq_hv/dk_hv/dv/dg_core BTHVD + dbeta BTHV fp32 come back public-direct;
    # k_exp stays GM-native (internal), flattened here only for comparison.
    got = (got[0], got[1], got[2], got[3], got[4], flat_lvd(got[5]))

    # fp32 reference for the five elementwise grads + k_exp (mirror common.py inverse_bwd)
    import math as _math
    B, T, H, Kd = inputs.q.shape
    HV = inputs.v.shape[2]
    G = HV // H
    scale = 1.0 / (Kd ** 0.5)
    qf, kf, vf = inputs.q.float(), inputs.k.float(), inputs.v.float()
    betaf, gf = inputs.beta.float(), caches.g_cumsum.float()
    hf, dhf = caches.h.float(), scan.dh.float()
    d_qg_f, d_kg_f = d_qg.float(), d_kg.float()
    d_vbeta_f, d_kbg_f = d_v_beta.float(), d_k_beta_g.float()
    exp2 = lambda x: torch.exp2(x)
    e_dq = torch.empty(B, T, HV, D); e_dk = torch.empty(B, T, HV, D)
    e_dv = torch.empty(B, T, HV, D); e_db = torch.empty(B, T, HV)
    e_dg = torch.empty(B, T, HV, D); e_ke = torch.empty(B, T, HV, D)
    for b in builtins.range(B):
        for c in builtins.range(T // L):
            s, e = c * L, c * L + L
            for hv in builtins.range(HV):
                hq = hv // G
                qb, kb, vb = qf[b, s:e, hq], kf[b, s:e, hq], vf[b, s:e, hv]
                gb, bb = gf[b, s:e, hv], betaf[b, s:e, hv]
                eg = exp2(gb); gl = gb[L - 1]; elmg = exp2(gl[None, :] - gb)
                dq = d_qg_f[b, s:e, hv] * eg * scale
                dkkg = d_kg_f[b, s:e, hv] * elmg
                ke = kb * eg
                dgl = (hf[b, c, hv] * dhf[b, c, hv]).sum(1) * exp2(gl) + (kb * dkkg).sum(0)
                e_dv[b, s:e, hv] = d_vbeta_f[b, s:e, hv] * bb[:, None]
                db = (d_vbeta_f[b, s:e, hv] * vb).sum(1) + (d_kbg_f[b, s:e, hv] * ke).sum(1)
                dkw = d_kbg_f[b, s:e, hv] * bb[:, None] * eg
                dgw = d_kbg_f[b, s:e, hv] * ke * bb[:, None]
                e_dq[b, s:e, hv] = dq
                e_dk[b, s:e, hv] = dkkg + dkw
                e_db[b, s:e, hv] = db
                dg = qb * dq - kb * dkkg + dgw
                dg[L - 1] = dg[L - 1] + dgl
                e_dg[b, s:e, hv] = dg
                e_ke[b, s:e, hv] = ke
    refs = (e_dq, e_dk, e_dv, e_db, e_dg, e_ke)
    names = ("dq_hv", "dk_hv", "dv", "dbeta", "dg_core", "k_exp")
    for name, g, r in zip(names, got, refs):
        torch.testing.assert_close(g.float(), r, rtol=tol, atol=tol)
        print(f"{name}: max_abs={(g.float() - r).abs().max().item():.3e} OK")
    print([tuple(item.shape) for item in got], [item.dtype for item in got])
