"""GDN forward chunk-delta correctness check.

Two modes controlled by --mode (or MODE env var):

  simulator  (default)  Run sub1+sub2 through compose inside the simulator,
                        compare outputs against the PyTorch oracle.

  onboard              Run sub1+sub2 on the real device (no simulator).
                       Two passes:
                         1) Init: generate code only for all sub-kernels.
                         2) Run:  compile sub1, reuse sub2 .o,
                                  then execute and compare against oracle.

  --out-dir=DIR        Output directory for generated code / build artifacts
                       (also settable via OUT_DIR env var).

Examples:
  python projects/a5/gdn_fwd/test_script/check_chunk_delta_vs_ref.py
  python projects/a5/gdn_fwd/test_script/check_chunk_delta_vs_ref.py --B=1 --H=1 --C=2
  MODE=onboard python projects/a5/gdn_fwd/test_script/check_chunk_delta_vs_ref.py
  python projects/a5/gdn_fwd/test_script/check_chunk_delta_vs_ref.py --mode=onboard --out-dir=build/gdn_fwd
"""

import os
import sys
from pathlib import Path

import torch

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
REFS_DIR = PROJECT_DIR / "refs"
KERNELS_DIR = PROJECT_DIR / "kernels"
L = 64
D = 128
ATOL = 2e-3
RTOL = 2e-3

def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)

for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from chunk_delta_compose import run as kernel_run  # noqa: E402
from oracle import oracle_full  # noqa: E402


def _rand_bf16(shape, scale):
    return (torch.randn(shape, dtype=torch.float32) * scale).to(torch.bfloat16)


def _arg_int(name, default):
    env_value = os.environ.get(name)
    if env_value is not None:
        return int(env_value)
    prefix = "--" + name + "="
    for arg in sys.argv[1:]:
        if arg.startswith(prefix):
            return int(arg.split("=", 1)[1])
    return default


def _shape_args():
    return _arg_int("B", 1), _arg_int("H", 32), _arg_int("C", 8)


def make_inputs(B=None, H=None, C=None):
    torch.manual_seed(_arg_int("SEED", 12345))
    if B is None or H is None or C is None:
        B, H, C = _shape_args()
    query = _rand_bf16((B, H, C, L, D), 0.05)
    key = _rand_bf16((B, H, C, L, D), 0.05)
    value = _rand_bf16((B, H, C, L, D), 0.05)
    g = (-torch.rand(B, H, C, L, dtype=torch.float32) * 0.1).cumsum(-1)
    decay_mask = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.1
    k_cumdecay = _rand_bf16((B, H, C, L, D), 0.05)
    return query, key, value, g, decay_mask, k_cumdecay


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    return (value,)


def _check_output(idx, got, ref):
    if tuple(got.shape) != tuple(ref.shape):
        raise RuntimeError(
            f"gdn_fwd chunk_delta: output {idx} shape mismatch {tuple(got.shape)} != {tuple(ref.shape)}"
        )

    got_f = got.float()
    ref_f = ref.float()
    if not torch.isfinite(got_f).all() or not torch.isfinite(ref_f).all():
        raise RuntimeError(f"gdn_fwd chunk_delta: output {idx} has non-finite values")

    diff = (got_f - ref_f).abs()
    max_abs = float(diff.max())
    max_rel = float((diff / ref_f.abs().clamp_min(1e-12)).max())
    ok = bool(torch.allclose(got_f, ref_f, atol=ATOL, rtol=RTOL))
    print(
        f"gdn_fwd chunk_delta output{idx}: shape={tuple(got.shape)} dtype={got.dtype} "
        f"max_abs={max_abs:.3e} max_rel={max_rel:.3e} "
        f"tol=({ATOL:.3e}, {RTOL:.3e}) {'OK' if ok else 'FAIL'}"
    )
    return ok


# ---------------------------------------------------------------------------
# Simulator mode
# ---------------------------------------------------------------------------
def run_simulator():
    args = make_inputs()
    expected = _as_tuple(oracle_full(*args))
    actual = _as_tuple(kernel_run(*args, simulator=True))

    if len(actual) != len(expected):
        raise RuntimeError(f"gdn_fwd chunk_delta: output count mismatch {len(actual)} != {len(expected)}")

    all_ok = True
    for idx, (got, ref) in enumerate(zip(actual, expected)):
        all_ok = _check_output(idx, got, ref) and all_ok

    if not all_ok:
        return 1
    print("gdn_fwd chunk_delta simulator-vs-ref OK")
    return 0


# ---------------------------------------------------------------------------
# Onboard mode
# ---------------------------------------------------------------------------
def run_onboard(out_dir):
    from chunk_delta_sub1 import run as run_sub1  # noqa: E402
    from chunk_delta_sub2 import run as run_sub2  # noqa: E402

    query, key, value, g, decay_mask, k_cumdecay = make_inputs()
    B, H, C = int(query.shape[0]), int(query.shape[1]), int(query.shape[2])

    # ---- Step 1: init — generate code only for all sub-kernels ----
    print("=== onboard init: generating code for all sub-kernels ===")
    attn_dummy = run_sub1(
        query, key, decay_mask,
        simulator=False, gen_only=True, skip_compile=False,
        out_dir=out_dir,
    )
    state_init = torch.zeros(B, H, D, D, dtype=torch.bfloat16)
    run_sub2(
        attn_dummy, query, key, value, k_cumdecay, g, state_init,
        simulator=False, gen_only=True, skip_compile=False,
        out_dir=out_dir,
    )

    # ---- Step 2: run — recompile sub1 only, reuse sub2 .o ----
    print("=== onboard run: sub1 compile+run, sub2 reuse .o ===")
    attn = run_sub1(
        query, key, decay_mask,
        simulator=False, gen_only=False, skip_compile=False,
        out_dir=out_dir,
    )
    state_zero = torch.zeros(B, H, D, D, dtype=torch.bfloat16)
    actual = _as_tuple(run_sub2(
        attn, query, key, value, k_cumdecay, g, state_zero,
        simulator=False, gen_only=False, skip_compile=True,
        out_dir=out_dir,
    ))

    # ---- Compare ----
    expected = _as_tuple(oracle_full(query, key, value, g, decay_mask, k_cumdecay))

    if len(actual) != len(expected):
        raise RuntimeError(f"gdn_fwd chunk_delta: output count mismatch {len(actual)} != {len(expected)}")

    all_ok = True
    for idx, (got, ref) in enumerate(zip(actual, expected)):
        all_ok = _check_output(idx, got, ref) and all_ok

    if not all_ok:
        return 1
    print("gdn_fwd chunk_delta onboard-vs-ref OK")
    return 0


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    mode = "simulator"
    for a in sys.argv[1:]:
        if a.startswith("MODE="):
            mode = a.split("=", 1)[1]
            break
        if a.startswith("--mode="):
            mode = a.split("=", 1)[1]
            break

    out_dir = ""
    for a in sys.argv[1:]:
        if a.startswith("OUT_DIR="):
            out_dir = a.split("=", 1)[1]
        if a.startswith("--out-dir="):
            out_dir = a.split("=", 1)[1]

    mode = mode.strip().lower()
    if mode == "simulator":
        return run_simulator()
    elif mode == "onboard":
        return run_onboard(out_dir)
    else:
        print(f"Unknown mode: {mode}. Use 'simulator' or 'onboard'.", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
