# Decomposition Plan - chunk_kda_fwd / plan1

**Target.** `a5`
**Tolerance.** `atol=2e-2`, `rtol=2e-2`
**Plan dir.** `projects/a5/kda_fwd`

## Behavior

Original behavior is the fixed-length forward KDA path from
`fla/ops/kda/chunk_fwd.py::chunk_kda_fwd`, cross-checked against
`fla/ops/kda/naive.py::naive_recurrent_kda`.

This plan keeps the oracle in upstream public layout `[B,T,...]` and decomposes
the hardware path into chunked refs with `T = C * L`, where `L = chunk_size`
and the default is `64` as in upstream FLA:

```text
linear gate cumsum -> intra-chunk Aqk/Akk -> WY tensors -> fused state/output tail
```

The decomposition has four reference units that map one-to-one to the authored
A5 kernels. The final unit `sub45_fused` folds the recurrent state bridge and
the GLA-style output assembly into a single stage: the chunk state `h` and the
delta-corrected values `v_new` stay internal, and only `o` and `final_state`
are exposed.

Precision policy is loose. The oracle keeps the original fp32 recurrent
formula. Sub-refs model A5-friendly bf16/fp16 GM boundaries for cube operands
with fp32 matmul accumulation where the optimized source materializes low
precision intermediates.

## IO Contract

| tensor | dtype | shape | layout | notes |
| --- | --- | --- | --- | --- |
| `q` | bf16/fp16 | `[B,T,H,K]` oracle, `[B,H,C,L,K]` refs | contiguous ND | query heads expand to `HV` by `repeat_interleave(HV//H)` |
| `k` | bf16/fp16 | `[B,T,H,K]` oracle, `[B,H,C,L,K]` refs | contiguous ND | key heads expand to `HV` by `repeat_interleave(HV//H)` |
| `v` | bf16/fp16 | `[B,T,HV,V]` oracle, `[B,HV,C,L,V]` refs | contiguous ND | output dtype source |
| `g_raw` | fp32 | `[B,T,HV,K]` oracle, `[B,HV,C,L,K]` refs | contiguous ND | natural-log gate increments |
| `g` | fp32 | `[B,HV,C,L,K]` refs only | contiguous ND | linear cumulative gate, `exp(cumsum(g_raw, dim=L))` |
| `beta` | fp32 | `[B,T,HV]` oracle, `[B,HV,C,L]` refs | contiguous ND | beta weights |
| `initial_state` | fp32 | `[B,HV,K,V]` | contiguous ND | optional in source; plan refs pass it explicitly |
| `o` | `v.dtype` | `[B,T,HV,V]` oracle, `[B,HV,C,L,V]` refs | contiguous ND | user output |
| `final_state` | fp32 | `[B,HV,K,V]` | contiguous ND | user output when requested |

Constants:

- `L = chunk_size`, default `64`.
- Reference files infer `L` from tensor shapes and are tested at `32` and `64`.
- The upstream optimized intra kernel currently supports `chunk_size in {32, 64}`;
  planned hardware kernels should start with those two sizes unless a broader
  shape contract is explicitly requested.
- `K <= 256`

Runtime shape dims:

- `B` from `q.shape[0]`, no alignment requirement, typical range unknown.
- `T` from `q.shape[1]`, alignment `T % L == 0`, represented as `C * L`.
- `H` from `q.shape[2]`, no alignment requirement, typical range unknown.
- `HV` from `v.shape[2]`, requires `HV % H == 0`.
- `K` from `q.shape[3]`, cube-friendly multiples of 32/64 preferred; upstream state kernel requires `K <= 256`.
- `V` from `v.shape[3]`, cube-friendly multiples of 32/64 preferred.
- `C` from `T // L`, recurrent chunk count.

## Sub-kernels

| sub | ref file | inputs | outputs | pipe / primitive notes |
| --- | --- | --- | --- | --- |
| `sub1_gate` | `refs/sub1_gate_ref.py` | `g_raw` | `g` | chunk-local vec scan plus exp to materialize linear cumulative gates, [P1] |
| `sub2_intra` | `refs/sub2_intra_ref.py` | `q,k,g,beta,scale` | `Aqk,Akk` | cube reductions over `K` plus unit lower-triangular solve, [P1,P5,P6,L1,L4] |
| `sub3_wy` | `refs/sub3_wy_ref.py` | `q,k,v,beta,Akk,g` | `w,u,qg,kg` | vec gate/beta preparation plus cube WY materialization; `qg` is saved for backward, [P1,P5,P6,P7,L1,L3] |
| `sub45_fused` | `refs/sub45_fused_ref.py` | `q,Aqk,kg,w,u,g,initial_state,scale` | `o,final_state` | production fused tail; runs the recurrent state bridge and GLA-style output assembly in one unit, keeping `h` and `v_new` internal, [A3,P1,P5,P6,P7,L1,L3] |

## DAG

```mermaid
graph LR
    GR[g_raw] --> K1[sub1_gate<br/>linear gate cumsum]
    K1 --> G[g]

    Q[q] --> K2[sub2_intra<br/>Aqk/Akk]
    K[key] --> K2
    BETA[beta] --> K2
    G --> K2
    K2 --> AQK[Aqk]
    K2 --> AKK[Akk]

    Q --> K3[sub3_wy<br/>w/u/qg/kg]
    K --> K3
    V[value] --> K3
    BETA --> K3
    G --> K3
    AKK --> K3
    K3 --> W[w]
    K3 --> U[u]
    K3 --> QG[qg<br/>saved for bwd]
    K3 --> KG[kg]

    H0[initial_state] --> K45[sub45_fused<br/>state bridge + output]
    KG --> K45
    W --> K45
    U --> K45
    G --> K45
    Q --> K45
    AQK --> K45
    K45 --> O[o]
    K45 --> FS[final_state]
```

The fused tail consumes the upstream tensors directly:

```text
q, g, Aqk, kg, w, u, initial_state -> sub45_fused -> o, final_state
```

Machine-readable file: `refs/dag.json`; it records this four-unit decomposition
and the fused implementation contract.

`qg` is intentionally produced by `sub3_wy` even though the current forward
output assembly does not consume it after materialization. It is retained as a
backward-facing saved intermediate for the precomputed `q * g` operand.

## Casts and Lossy Boundaries

| location | primitive | original dtype/path | planned hardware path | reason | measured / budget |
| --- | --- | --- | --- | --- | --- |
| `sub2_intra.Aqk/Akk` | L1,L4 | oracle computes from fp32-expanded q/k/g/beta | q/k are cube operands in input dtype; accumulation is fp32; `Aqk/Akk` are stored in q/k dtype | upstream optimized path allocates `Aqk/Akk` with `k.dtype`; A5 cube prefers low precision operands with fp32 L0C | measured by `compose.py`, budget 2e-2 |
| `sub3_wy.w/u/qg/kg` | L1,L3 | oracle carries recurrent math in fp32 | gate/beta math stays fp32; cube operands and exposed `w/u/qg/kg` are stored in q/k/v dtype | later consumers use these tensors as cube operands or saved low precision intermediates; `qg` is retained for backward | measured by `compose.py`, budget 2e-2 |
| `sub45_fused.h/v_new` | A3,L1,L3 | oracle recurrent state update is fp32 token-by-token | the fused tail keeps `h` and `v_new` as internal low precision intermediates instead of exposing them as GM outputs | matches the optimized fused tail's on-chip dataflow | measured by `compose.py` and `sub45_fused_check.py`, budget 2e-2 |
| `sub45_fused.o/final_state` | A3,L1,P7 | oracle output is fp32 then cast to `v.dtype`; recurrent state stays fp32 | production fused tail returns only `o` (stored as `v.dtype`) and fp32 `final_state` computed from internal `h`/`v_new` | user-visible output dtype follows upstream KDA without a standalone sub4/sub5 GM roundtrip | measured by `compose.py` and `sub45_fused_check.py`, budget 2e-2 |

## Validation

From the repository root:

```bash
python -m py_compile projects/a5/kda_fwd/refs/*.py
for f in projects/a5/kda_fwd/refs/*_check.py; do python "$f"; done
python projects/a5/kda_fwd/refs/compose.py
```

Observed:

- `py_compile`: PASS.
- `sub1_gate_check.py`: PASS.
- `sub2_intra_check.py`: PASS.
- `sub3_wy_check.py`: PASS.
- `sub45_fused_check.py`: PASS.
- `compose.py`: PASS on `single_chunk_L64`, `aligned64_L64`,
  `gva_two_chunks_L64`, `single_chunk_L32`, and `gva_two_chunks_L32`; worst
  observed `max_abs=4.613e-05`, tolerance ratio `2.302e-03`.

## Open Questions

- Should the authored path support `use_gate_in_kernel=True` with `A_log`, `dt_bias`, and `lower_bound`?
- Should forward always materialize backward-facing `qg/w/u/kg/v_new/h`, or follow upstream `disable_recompute=False` deletion semantics?
- Is `state_v_first=True` required for the public API?
- Should authored hardware kernels support only upstream-style `chunk_size` values
  `32` and `64`, or also accept additional `L` values for the PyTorch ref
  contract?
- Are `cu_seqlens`, `chunk_indices`, `cp_context`, or `safe_gate` required beyond this fixed-length plan?
