"""KDA backward simulator-vs-ref check (full-bf16 IO contract).

Every public tensor (inputs, saved caches, stage handoffs, outputs) is bf16;
kernels and refs upcast to fp32 internally and downcast once at boundaries.
Tolerance follows refs/plan.md: dk error is bf16-cancellation-bound at ~1.5%
of |dk|max, so the absolute floor scales with the input range; atol=rtol=1e-3
holds at the default input config (`scale=0.01`, `k_scale=0.05`) (~3x margin
over the dk floor of ~3e-4).
"""

import sys
from pathlib import Path

import torch

PLAN_DIR = Path(__file__).resolve().parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"


def _find_repo_root(start: Path) -> Path:
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError(f"could not locate repository root from {start}")


REPO_ROOT = _find_repo_root(PLAN_DIR)

for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import ATOL, RTOL, make_inputs, oracle, outputs_as_tuple  # noqa: E402
from kernel_compose import run as kernel_run  # noqa: E402


def _check_output(name, got, ref):
    if got.dtype != ref.dtype:
        raise RuntimeError(f"{name}: dtype mismatch {got.dtype} != {ref.dtype}")
    got_f = got.float()
    ref_f = ref.float()
    if not torch.isfinite(got_f).all():
        raise RuntimeError(f"{name}: non-finite values in simulator output")
    if not torch.allclose(got_f, ref_f, atol=ATOL, rtol=RTOL):
        diff = (got_f - ref_f).abs()
        rel = diff / ref_f.abs().clamp_min(1e-12)
        raise RuntimeError(
            f"{name}: max_abs={float(diff.max()):.3e} max_rel={float(rel.max()):.3e} "
            f"exceeds tol=({ATOL:.3e}, {RTOL:.3e})"
        )
    print(f"{name}: max_abs={(got_f - ref_f).abs().max().item():.3e} OK")


def main():
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=64, seed=20260604)
    expected = oracle(inputs)
    actual = kernel_run(
        inputs.q,
        inputs.k,
        inputs.v,
        inputs.g,
        inputs.beta,
        inputs.initial_state,
        inputs.do,
        inputs.dht,
        simulator=True,
    )
    for name, got, ref in zip(("dq", "dk", "dv", "dbeta", "dg", "dh0"), actual, outputs_as_tuple(expected)):
        _check_output(name, got, ref)
    print("kda_bwd simulator-vs-ref OK")


if __name__ == "__main__":
    raise SystemExit(main())
