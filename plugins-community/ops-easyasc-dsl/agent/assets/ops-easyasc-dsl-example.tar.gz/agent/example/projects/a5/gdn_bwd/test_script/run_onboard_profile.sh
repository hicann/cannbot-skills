#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLAN_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

find_repo_root() {
  local dir="${PLAN_DIR}"
  while [[ "${dir}" != "/" ]]; do
    if [[ -f "${dir}/agent/ROUTER.md" && -f "${dir}/easyasc/a5.py" ]]; then
      printf '%s\n' "${dir}"
      return 0
    fi
    dir="$(dirname "${dir}")"
  done
  return 1
}

REPO_ROOT="$(find_repo_root)"

MODULE="${MODULE:-compose}"
UPSTREAM="${UPSTREAM:-ref}"
SEED="${SEED:-20260519}"
B="${B:-1}"
H="${H:-32}"
C="${C:-16}"
OUT_DIR="${OUT_DIR:-${PLAN_DIR}/hw_out/onboard_profile_${MODULE}_b${B}h${H}c${C}_$(date +%Y%m%d_%H%M%S)}"

if [[ -n "${PYTHON_CMD:-}" ]]; then
  read -r -a PYTHON_RUNNER <<< "${PYTHON_CMD}"
elif command -v conda >/dev/null 2>&1 && conda env list | grep -qE '^torch210npu[[:space:]]'; then
  PYTHON_RUNNER=(conda run -n torch210npu python)
else
  PYTHON_RUNNER=(python)
fi

mkdir -p "${OUT_DIR}"
OUT_DIR="$(cd "${OUT_DIR}" && pwd)"

# Keep generated custom-op packages under this run directory. OpExec defaults
# custom_op_path to the current working directory for onboard runs.
cd "${OUT_DIR}"

echo "gdn_bwd onboard profile"
echo "  module=${MODULE} upstream=${UPSTREAM} seed=${SEED} shape=(B=${B},H=${H},C=${C})"
echo "  repo_root=${REPO_ROOT}"
echo "  out_dir=${OUT_DIR}"
echo "  workdir=$(pwd)"
echo "  python=${PYTHON_RUNNER[*]}"

"${PYTHON_RUNNER[@]}" "${PLAN_DIR}/test_script/module_vs_ref.py" \
  --module "${MODULE}" \
  --mode onboard \
  --upstream "${UPSTREAM}" \
  --seed "${SEED}" \
  --B "${B}" \
  --H "${H}" \
  --C "${C}" \
  --out-dir "${OUT_DIR}" \
  --profile \
  --stop-on-fail \
  "$@"
