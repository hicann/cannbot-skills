"""Finalize-stage HV->H group reduction (formerly a host group-axis sum).

`finalize_post` emits the per-value-head grads `dq_hv'/dk_hv'` (fp32, shape
[B,T,HV,K]). The public `dq/dk` are per-query-head: each query head owns a
contiguous block of G = HV//H value heads (hv = h*G + g), so

    dq[b,t,h] = sum_{g=0}^{G-1} dq_hv'[b,t,h*G+g]          (likewise dk)

is a sum over a contiguous G-block. We keep the accumulation in fp32 (the oracle
does too -- a bf16 round-trip before the sum overshoots the 1e-3 tolerance) and
cast to bf16 only on the final store. In the representative shape H == HV
(G = 1) the reduce degenerates to the fp32 -> bf16 cast.

Pure vector. The GM symbol map distinguishes the HV input axis (symbol 1) from
the H output axis (symbol 2); G is passed as a scalar for the index math.
"""

import builtins
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _layout import to_lvd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
L = 64
D = 128
REGS_D = D // 64
SHAPE_BINDINGS = {
    0: [0, 1, 3, None, None],  # dq_hv'  [B, HV, C, L, D]   (HV = symbol 1)  intra-stage GM-native
    1: [0, 1, 3, None, None],  # dk_hv'
    2: [0, None, 2, None],     # dq_out  [B, T, H, D]       (H = symbol 2; T,D literal)  public BTHVD
    3: [0, None, 2, None],     # dk_out
}


@vf()
def reduce_add_vf(acc_ub: Tensor, add_ub: Tensor, rows: Var):
    a = RegList(DT.float, REGS_D)
    b = RegList(DT.float, REGS_D)
    for r in range(rows):
        a <<= acc_ub[r:r + 1, 0:D]
        b <<= add_ub[r:r + 1, 0:D]
        a <<= a + b
        acc_ub[r:r + 1, 0:D] <<= a
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def reduce_cast_vf(acc_ub: Tensor, out_ub: Tensor, rows: Var):
    a = RegList(DT.float, REGS_D)
    for r in range(rows):
        a <<= acc_ub[r:r + 1, 0:D]
        out_ub[r * D] <<= a[0]
        out_ub[r * D + 64] <<= a[1]
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def finalize_reduce_kernel(
    dq_hv: GMTensor,
    dk_hv: GMTensor,
    dq_out: GMTensor,
    dk_out: GMTensor,
    B: Var,
    HV: Var,
    H: Var,
    C: Var,
    G: Var,
):
    dqacc_ub = Tensor(DT.float, [L, D], Position.UB)
    dkacc_ub = Tensor(DT.float, [L, D], Position.UB)
    dq_g_ub = Tensor(DT.float, [L, D], Position.UB)
    dk_g_ub = Tensor(DT.float, [L, D], Position.UB)
    dq_out_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dk_out_ub = Tensor(DT.bfloat16, [L, D], Position.UB)

    work_count = Var(B * H * C)
    work_per_core = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_core * GetCubeIdx())
    work_end = Min(work_begin + work_per_core, work_count)

    with auto_sync():
        for work in range(work_begin, work_end):
            c_idx = Var(work % C)
            bh = Var(work / C)
            h_idx = Var(bh % H)
            b_idx = Var(bh / H)
            hv0 = Var(h_idx * G)

            # g = 0 initialises the fp32 accumulator (no cast on the fp32 load).
            dqacc_ub[0:L, 0:D] <<= dq_hv[b_idx, hv0, c_idx, 0:L, 0:D]
            dkacc_ub[0:L, 0:D] <<= dk_hv[b_idx, hv0, c_idx, 0:L, 0:D]
            for g in range(1, G):
                hv = Var(hv0 + g)
                dq_g_ub[0:L, 0:D] <<= dq_hv[b_idx, hv, c_idx, 0:L, 0:D]
                dk_g_ub[0:L, 0:D] <<= dk_hv[b_idx, hv, c_idx, 0:L, 0:D]
                reduce_add_vf(dqacc_ub, dq_g_ub, Var(L))
                reduce_add_vf(dkacc_ub, dk_g_ub, Var(L))
            reduce_cast_vf(dqacc_ub, dq_out_ub, Var(L))
            reduce_cast_vf(dkacc_ub, dk_out_ub, Var(L))
            # public dq/dk written strided into token-major BTHVD [B, T, H, D]
            # on-device (row pitch H*D); no host transpose.
            row0 = Var(c_idx * L)
            ub_to_gm_pad(dq_out[b_idx, row0:row0 + L, h_idx, 0:D], dq_out_ub[0:L, 0:D], L, D, 0, (H - 1) * D)
            ub_to_gm_pad(dk_out[b_idx, row0:row0 + L, h_idx, 0:D], dk_out_ub[0:L, 0:D], L, D, 0, (H - 1) * D)

    return dq_out, dk_out


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(dq_hv, dk_hv, H, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    # GM-native: dq_hv/dk_hv [B, HV, C, L, D] fp32 -- the on-purpose fp32 carries
    # the HV->H accumulation precision. Driver/story owns BTHVD<->GM conversion.
    B = int(dq_hv.shape[0])
    HV = int(dq_hv.shape[1])
    C = int(dq_hv.shape[2])
    G = HV // H
    for name, tensor in (("dq_hv", dq_hv), ("dk_hv", dk_hv)):
        if tensor.dtype != torch.float32:
            raise TypeError(f"{name} must be float32, got {tensor.dtype}")
    T = C * L
    dq_out = torch.empty((B, T, H, D), dtype=torch.bfloat16, device=dq_hv.device)  # public BTHVD
    dk_out = torch.empty((B, T, H, D), dtype=torch.bfloat16, device=dq_hv.device)

    previous_config = getattr(finalize_reduce_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "finalize_reduce")
    if simulator:
        finalize_reduce_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            finalize_reduce_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            dq_hv, dk_hv, dq_out, dk_out, B, HV, H, C, G,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(finalize_reduce_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                finalize_reduce_kernel._simulator_config = previous_config
    if gen_only:
        return result
    # Raw GM outputs [B, H, C, L, D] bf16; layout conversion owned by driver/story.
    return result[0], result[1]


if __name__ == "__main__":
    torch.manual_seed(0)
    B, H, HV, T, K = 1, 2, 4, 128, 128
    G = HV // H
    bf16 = torch.bfloat16
    # distinct fp32 values (not constants) so a group-reduce bug can't hide.
    dq_hv = torch.randn(B, T, HV, K) * 0.1
    dk_hv = torch.randn(B, T, HV, K) * 0.1

    # inputs stay GM-native (intra-stage from finalize_post); output is now public
    # BTHVD [B, T, H, K] written strided on-device -- no flat_lvd needed.
    got_dq, got_dk = run(to_lvd(dq_hv).float(), to_lvd(dk_hv).float(), H, simulator=True)

    exp_dq = dq_hv.reshape(B, T, H, G, K).sum(dim=3).to(bf16).float()
    exp_dk = dk_hv.reshape(B, T, H, G, K).sum(dim=3).to(bf16).float()
    tol = 4e-3
    torch.testing.assert_close(got_dq.float(), exp_dq, rtol=tol, atol=tol)
    torch.testing.assert_close(got_dk.float(), exp_dk, rtol=tol, atol=tol)
    print(f"dq: max_abs={(got_dq.float() - exp_dq).abs().max().item():.3e} OK")
    print(f"dk: max_abs={(got_dk.float() - exp_dk).abs().max().item():.3e} OK")
    print([tuple(got_dq.shape), tuple(got_dk.shape)], [got_dq.dtype, got_dk.dtype])
