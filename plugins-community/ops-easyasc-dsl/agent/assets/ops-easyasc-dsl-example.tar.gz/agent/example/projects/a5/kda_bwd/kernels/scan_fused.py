import math
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _torch_formula import L, build_saved_forward, scan_dav_only, scan_state_only


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
D = 128
HALF_L = L // 2
HALF_D = D // 2
FLOAT_REGS_PER_ROW = D // 64
FLOAT_REGS_PER_4ROWS = FLOAT_REGS_PER_ROW * 4
BF16_C0 = 16
QG_SCALE = 1.0 / 11.313708498984761   # 1/sqrt(D): folded into the qg-seed fixpipe
DAQK_SCALE = 1.0 / (D ** 0.5)         # 1/sqrt(D): folded into the dAqk fixpipe
LN2 = math.log(2.0)
# Scalar Var order: (B, HV, C) -> symbols 0, 1, 2. Inputs are read strided
# directly from the frozen public seams (no host permute/cast): kg/qg/w/do/v_new
# BTHVD [B,T,HV,D], Aqk BTHVL [B,T,HV,L], g_last [B,C,HV,D] (raw; exp2 in-kernel),
# dht [B,HV,D/2,2D]. Outputs written strided on-device: dAqk public BTHVL, dh ->
# inverse BCHVDD [B,C,HV,D,D], dv -> inverse BTHVD, dh0 public [B,HV,D,D].
SHAPE_BINDINGS = {
    0: [0, None, 1, None],      # kg       [B, T, HV, D]
    1: [0, None, 1, None],      # qg       [B, T, HV, D]  (raw, unscaled)
    2: [0, None, 1, None],      # w        [B, T, HV, D]
    3: [0, 2, 1, None],         # g_last   [B, C, HV, D]  (raw; exp2 in-kernel)
    4: [0, None, 1, None],      # grad_out [B, T, HV, D]  (do)
    5: [0, None, 1, None],      # Aqk      [B, T, HV, L]
    6: [0, None, 1, None],      # v_new    [B, T, HV, D]
    7: [0, 1, None, None],      # dht      [B, HV, D/2, 2D]
    8: [0, None, 1, None],      # dAqk     [B, T, HV, L]    public BTHVL out
    9: [0, 2, 1, None, None],   # dh       [B, C, HV, D, D] -> inverse (BCHVDD)
    10: [0, None, 1, None],     # dv       [B, T, HV, D]    -> inverse (BTHVD)
    11: [0, 1, None, None],     # dh0      [B, HV, D, D]    public
}


@vf()
def cast_dht_to_f32_vf(dht_h_ub: Tensor, dstate_f_ub: Tensor, row_begin_d: Var):
    reg_f32 = Reg(DT.float)
    dst_base = Var(row_begin_d * D)
    n_loops = Var(HALF_D * D / 64)
    for i in range(n_loops):
        reg_f32 <<= dht_h_ub[i * 64]
        dstate_f_ub[dst_base + i * 64] <<= reg_f32
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def snapshot_and_cast_state_vf(dstate_f_ub: Tensor, state_h_ub: Tensor, state_h_nz_ub: Tensor, row_begin_d: Var):
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(HALF_D):
        row_lo <<= dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 0:64]
        row_hi <<= dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 64:D]
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(state_h_ub[r:r + 1, 0:D], row_bf16)
        reg_to_ub(state_h_nz_ub[r * BF16_C0], row_bf16, HALF_D)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def add_dv_and_cast_bf16_vf(dv_delta_ub: Tensor, dv_sum_ub: Tensor, dv_bf16_ub: Tensor, dv_bf16_nz_ub: Tensor):
    delta_lo = Reg(DT.float)
    delta_hi = Reg(DT.float)
    sum_lo = Reg(DT.float)
    sum_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(HALF_L):
        delta_lo <<= dv_delta_ub[r:r + 1, 0:64]
        delta_hi <<= dv_delta_ub[r:r + 1, 64:D]
        sum_lo <<= dv_sum_ub[r:r + 1, 0:64]
        sum_hi <<= dv_sum_ub[r:r + 1, 64:D]
        sum_lo <<= sum_lo + delta_lo
        sum_hi <<= sum_hi + delta_hi
        lo_bf16 <<= sum_lo.astype(DT.bfloat16)
        hi_bf16 <<= sum_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(dv_bf16_ub[r:r + 1, 0:D], row_bf16)
        reg_to_ub(dv_bf16_nz_ub[r * BF16_C0], row_bf16, HALF_L)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def exp2_glast_vf(g_last_half_ub: Tensor, exp_g_last_half_ub: Tensor):
    # Per-chunk decay 2^g_last = exp(g_last * ln2): g_last (= g_cumsum at the chunk
    # boundary) already carries the 1/ln2 factor. Replaces the old host
    # torch.exp(g_last*ln2). One HALF_D-lane shot per sub-block.
    r = Reg(DT.float)
    r <<= g_last_half_ub[0:1, 0:HALF_D]   # bf16 -> fp32 upcast
    r <<= r * LN2
    r <<= r.exp()
    exp_g_last_half_ub[0:1, 0:HALF_D] <<= r
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def update_dstate_vf(
    seed_ub: Tensor,
    corr_ub: Tensor,
    dstate_f_ub: Tensor,
    state_h_ub: Tensor,
    state_h_nz_ub: Tensor,
    exp_g_last_half_ub: Tensor,
    row_begin_d: Var,
):
    seed_lo = Reg(DT.float)
    seed_hi = Reg(DT.float)
    corr_lo = Reg(DT.float)
    corr_hi = Reg(DT.float)
    state_lo = Reg(DT.float)
    state_hi = Reg(DT.float)
    scale = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(HALF_D):
        scale <<= exp_g_last_half_ub[0:1, r:r + 1].single()
        seed_lo <<= seed_ub[r:r + 1, 0:64]
        seed_hi <<= seed_ub[r:r + 1, 64:D]
        seed_lo <<= seed_lo * QG_SCALE   # 1/sqrt(D): was host qg pre-scale
        seed_hi <<= seed_hi * QG_SCALE
        corr_lo <<= corr_ub[r:r + 1, 0:64]
        corr_hi <<= corr_ub[r:r + 1, 64:D]
        state_lo <<= dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 0:64]
        state_hi <<= dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 64:D]
        state_lo <<= state_lo * scale
        state_hi <<= state_hi * scale
        seed_lo <<= seed_lo + state_lo
        seed_hi <<= seed_hi + state_hi
        seed_lo <<= seed_lo - corr_lo
        seed_hi <<= seed_hi - corr_hi
        dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 0:64] <<= seed_lo
        dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 64:D] <<= seed_hi
        lo_bf16 <<= seed_lo.astype(DT.bfloat16)
        hi_bf16 <<= seed_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(state_h_ub[r:r + 1, 0:D], row_bf16)
        reg_to_ub(state_h_nz_ub[r * BF16_C0], row_bf16, HALF_D)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def update_dstate_final_vf(
    seed_ub: Tensor,
    corr_ub: Tensor,
    dstate_f_ub: Tensor,
    state_h_ub: Tensor,
    exp_g_last_half_ub: Tensor,
    row_begin_d: Var,
):
    seed_lo = Reg(DT.float)
    seed_hi = Reg(DT.float)
    corr_lo = Reg(DT.float)
    corr_hi = Reg(DT.float)
    state_lo = Reg(DT.float)
    state_hi = Reg(DT.float)
    scale = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(HALF_D):
        scale <<= exp_g_last_half_ub[0:1, r:r + 1].single()
        seed_lo <<= seed_ub[r:r + 1, 0:64]
        seed_hi <<= seed_ub[r:r + 1, 64:D]
        seed_lo <<= seed_lo * QG_SCALE   # 1/sqrt(D): was host qg pre-scale
        seed_hi <<= seed_hi * QG_SCALE
        corr_lo <<= corr_ub[r:r + 1, 0:64]
        corr_hi <<= corr_ub[r:r + 1, 64:D]
        state_lo <<= dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 0:64]
        state_hi <<= dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 64:D]
        state_lo <<= state_lo * scale
        state_hi <<= state_hi * scale
        seed_lo <<= seed_lo + state_lo
        seed_hi <<= seed_hi + state_hi
        seed_lo <<= seed_lo - corr_lo
        seed_hi <<= seed_hi - corr_hi
        lo_bf16 <<= seed_lo.astype(DT.bfloat16)
        hi_bf16 <<= seed_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(state_h_ub[r:r + 1, 0:D], row_bf16)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def pre_update_dstate_scratch_vf(
    seed_ub: Tensor,
    dstate_f_ub: Tensor,
    scratch0_ub: Tensor,
    scratch1_ub: Tensor,
    exp_g_last_half_ub: Tensor,
    row_begin_d: Var,
):
    seed_lo = Reg(DT.float)
    seed_hi = Reg(DT.float)
    state_lo = Reg(DT.float)
    state_hi = Reg(DT.float)
    scale = Reg(DT.float)
    for r in range(HALF_L):
        scale <<= exp_g_last_half_ub[0:1, r:r + 1].single()
        seed_lo <<= seed_ub[r:r + 1, 0:64]
        seed_hi <<= seed_ub[r:r + 1, 64:D]
        state_lo <<= dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 0:64]
        state_hi <<= dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 64:D]
        state_lo <<= state_lo * scale
        state_hi <<= state_hi * scale
        seed_lo <<= seed_lo + state_lo
        seed_hi <<= seed_hi + state_hi
        scratch0_ub[r:r + 1, 0:64] <<= seed_lo
        scratch0_ub[r:r + 1, 64:D] <<= seed_hi
    for r in range(HALF_L):
        scale <<= exp_g_last_half_ub[0:1, HALF_L + r:HALF_L + r + 1].single()
        seed_lo <<= seed_ub[HALF_L + r:HALF_L + r + 1, 0:64]
        seed_hi <<= seed_ub[HALF_L + r:HALF_L + r + 1, 64:D]
        state_lo <<= dstate_f_ub[row_begin_d + HALF_L + r:row_begin_d + HALF_L + r + 1, 0:64]
        state_hi <<= dstate_f_ub[row_begin_d + HALF_L + r:row_begin_d + HALF_L + r + 1, 64:D]
        state_lo <<= state_lo * scale
        state_hi <<= state_hi * scale
        seed_lo <<= seed_lo + state_lo
        seed_hi <<= seed_hi + state_hi
        scratch1_ub[r:r + 1, 0:64] <<= seed_lo
        scratch1_ub[r:r + 1, 64:D] <<= seed_hi
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def finalize_update_dstate_vf(
    scratch0_ub: Tensor,
    scratch1_ub: Tensor,
    corr_ub: Tensor,
    dstate_f_ub: Tensor,
    state_h_ub: Tensor,
    state_h_nz_ub: Tensor,
    row_begin_d: Var,
):
    pre_lo = Reg(DT.float)
    pre_hi = Reg(DT.float)
    corr_lo = Reg(DT.float)
    corr_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(HALF_L):
        pre_lo <<= scratch0_ub[r:r + 1, 0:64]
        pre_hi <<= scratch0_ub[r:r + 1, 64:D]
        corr_lo <<= corr_ub[r:r + 1, 0:64]
        corr_hi <<= corr_ub[r:r + 1, 64:D]
        pre_lo <<= pre_lo - corr_lo
        pre_hi <<= pre_hi - corr_hi
        dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 0:64] <<= pre_lo
        dstate_f_ub[row_begin_d + r:row_begin_d + r + 1, 64:D] <<= pre_hi
        lo_bf16 <<= pre_lo.astype(DT.bfloat16)
        hi_bf16 <<= pre_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(state_h_ub[r:r + 1, 0:D], row_bf16)
        reg_to_ub(state_h_nz_ub[r * BF16_C0], row_bf16, HALF_D)
    for r in range(HALF_L):
        pre_lo <<= scratch1_ub[r:r + 1, 0:64]
        pre_hi <<= scratch1_ub[r:r + 1, 64:D]
        corr_lo <<= corr_ub[HALF_L + r:HALF_L + r + 1, 0:64]
        corr_hi <<= corr_ub[HALF_L + r:HALF_L + r + 1, 64:D]
        pre_lo <<= pre_lo - corr_lo
        pre_hi <<= pre_hi - corr_hi
        dstate_f_ub[row_begin_d + HALF_L + r:row_begin_d + HALF_L + r + 1, 0:64] <<= pre_lo
        dstate_f_ub[row_begin_d + HALF_L + r:row_begin_d + HALF_L + r + 1, 64:D] <<= pre_hi
        lo_bf16 <<= pre_lo.astype(DT.bfloat16)
        hi_bf16 <<= pre_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(state_h_ub[HALF_L + r:HALF_L + r + 1, 0:D], row_bf16)
        reg_to_ub(state_h_nz_ub[(HALF_L + r) * BF16_C0], row_bf16, HALF_D)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def finalize_update_dstate_final_vf(scratch0_ub: Tensor, scratch1_ub: Tensor, corr_ub: Tensor, state_h_ub: Tensor):
    pre_lo = Reg(DT.float)
    pre_hi = Reg(DT.float)
    corr_lo = Reg(DT.float)
    corr_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(HALF_L):
        pre_lo <<= scratch0_ub[r:r + 1, 0:64]
        pre_hi <<= scratch0_ub[r:r + 1, 64:D]
        corr_lo <<= corr_ub[r:r + 1, 0:64]
        corr_hi <<= corr_ub[r:r + 1, 64:D]
        pre_lo <<= pre_lo - corr_lo
        pre_hi <<= pre_hi - corr_hi
        lo_bf16 <<= pre_lo.astype(DT.bfloat16)
        hi_bf16 <<= pre_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(state_h_ub[r:r + 1, 0:D], row_bf16)
    for r in range(HALF_L):
        pre_lo <<= scratch1_ub[r:r + 1, 0:64]
        pre_hi <<= scratch1_ub[r:r + 1, 64:D]
        corr_lo <<= corr_ub[HALF_L + r:HALF_L + r + 1, 0:64]
        corr_hi <<= corr_ub[HALF_L + r:HALF_L + r + 1, 64:D]
        pre_lo <<= pre_lo - corr_lo
        pre_hi <<= pre_hi - corr_hi
        lo_bf16 <<= pre_lo.astype(DT.bfloat16)
        hi_bf16 <<= pre_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(state_h_ub[HALF_L + r:HALF_L + r + 1, 0:D], row_bf16)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def scan_fused_kernel(
    kg: GMTensor,
    qg: GMTensor,
    w: GMTensor,
    g_last: GMTensor,
    grad_out: GMTensor,
    Aqk: GMTensor,
    v_new: GMTensor,
    dht: GMTensor,
    dAqk: GMTensor,
    dh: GMTensor,
    dv: GMTensor,
    dh0: GMTensor,
    B: Var,
    HV: Var,
    C: Var,
):
    state_bridge = VcMutex(
        0,
        depth=1,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    dv_bridge = VcMutex(
        1,
        depth=1,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    dvdelta_mutex = CvMutex(2, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    seed_mutex = CvMutex(3, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    corr_mutex = CvMutex(4, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    dv0_mutex = CvMutex(5, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1_kg = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_qg = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_w = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_do = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_Aqk = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_vnew = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_dv = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_dstate = Tensor(DT.bfloat16, [D, D], Position.L1)

    l0c_dvdelta = Tensor(DT.float, [L, D], Position.L0C)
    l0c_seed = DBuff(DT.float, [D, D], Position.L0C)
    l0c_corr = Tensor(DT.float, [D, D], Position.L0C)
    l0c_dv0 = Tensor(DT.float, [L, D], Position.L0C)
    # dAqk shares the dvdelta accumulator: its matmul runs only after the
    # dvdelta fixpipe of the current chunk has drained.
    l0c_daqk = l0c_dvdelta

    dstate_f_ub = Tensor(DT.float, [D, D], Position.UB)
    state_h_ub = Tensor(DT.bfloat16, [HALF_D, D], Position.UB)
    state_h_nz_ub = Tensor(DT.bfloat16, [HALF_D, D], Position.UB)
    dv_delta_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    dht_h_ub = dv_delta_ub.reinterpret(DT.bfloat16)
    dv_sum_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    dv_bf16_ub = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    dv_bf16_nz_ub = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    seed_ub = DBuff(DT.float, [HALF_D, D], Position.UB)
    corr_ub = Tensor(DT.float, [HALF_D, D], Position.UB)
    g_last_half_ub = Tensor(DT.bfloat16, [1, HALF_D], Position.UB)
    exp_g_last_half_ub = Tensor(DT.float, [1, HALF_D], Position.UB)

    bhv_count = B * HV
    bhv_per_core = CeilDiv(bhv_count, GetCubeNum())
    bhv_begin = Var(bhv_per_core * GetCubeIdx())
    bhv_end = Min(bhv_begin + bhv_per_core, bhv_count)
    row_begin_l = Var(GetSubBlockIdx() * HALF_L)
    row_end_l = Var(row_begin_l + HALF_L)
    row_begin_d = Var(GetSubBlockIdx() * HALF_D)
    row_end_d = Var(row_begin_d + HALF_D)
    # dht GM rides as [B, HV, D/2, 2*D]: each sub-block owns HALF_L bf16 rows.
    dht_row_begin = Var(GetSubBlockIdx() * HALF_L)
    dht_row_end = Var(dht_row_begin + HALF_L)

    with auto_sync():
        for bhv in range(bhv_begin, bhv_end):
            b_idx = Var(bhv / HV)
            hv_idx = Var(bhv % HV)
            dht_h_ub[0:HALF_L, 0:2 * D] <<= dht[b_idx, hv_idx, dht_row_begin:dht_row_end, 0:2 * D]
            cast_dht_to_f32_vf(dht_h_ub, dstate_f_ub, row_begin_d)
            snapshot_and_cast_state_vf(dstate_f_ub, state_h_ub, state_h_nz_ub, row_begin_d)

            # Initial (last) chunk C-1: strided BTHVD/BTHVL loads from the frozen
            # public seams (explicit pitch HV*D / HV*L).
            tok0 = Var((C - 1) * L)
            tok1 = Var(tok0 + L)
            gm_to_l1_nd2nz(l1_qg[0][0:L, 0:D], qg[b_idx, tok0:tok1, hv_idx, 0:D], L, D, HV * D, L)
            gm_to_l1_nd2nz(l1_w[0][0:L, 0:D], w[b_idx, tok0:tok1, hv_idx, 0:D], L, D, HV * D, L)
            gm_to_l1_nd2nz(l1_do[0][0:L, 0:D], grad_out[b_idx, tok0:tok1, hv_idx, 0:D], L, D, HV * D, L)
            gm_to_l1_nd2nz(l1_Aqk[0][0:L, 0:L], Aqk[b_idx, tok0:tok1, hv_idx, 0:L], L, L, HV * L, L)
            gm_to_l1_nd2nz(l1_vnew[0][0:L, 0:D], v_new[b_idx, tok0:tok1, hv_idx, 0:D], L, D, HV * D, L)
            matmul(l0c_seed[0], l1_qg[0].T, l1_do[0].T, m=D, n=D, k=L, splitn=D)
            seed_mutex.lock()
            l0c_to_ub(seed_ub[0], l0c_seed[0], M=D, N=D, N_dst=D, M_src=D, dual_mode=DualMode.SPLITM, sub_block_id=0)
            seed_mutex.ready()
            matmul(l0c_daqk, l1_do[0], l1_vnew[0], m=L, n=L, k=D, splitn=L)
            # dAqk -> public BTHVL, scaled by 1/sqrt(D) in the fixpipe (finalize_pre
            # re-trils, so the below-diagonal values here are masked downstream).
            l0c_to_gm_nz2nd(dAqk[b_idx, tok0:tok1, hv_idx, 0:L], l0c_daqk, L, L, HV * L, L, scale=DAQK_SCALE)
            matmul(l0c_dv0, l1_Aqk[0].T, l1_do[0].T, m=L, n=D, k=L, splitn=D)
            dv0_mutex.lock()
            l0c_to_ub(dv_sum_ub, l0c_dv0, M=L, N=D, N_dst=D, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
            dv0_mutex.ready()

            for rev_c in range(C):
                c_idx = Var(C - 1 - rev_c)
                next_c_idx = Var(c_idx - 1)
                ctok0 = Var(c_idx * L)
                # Shared by both the next-chunk preload and the later dAqk writeback.
                ntok0 = Var(next_c_idx * L)
                # g_last read raw strided from [B,C,HV,D]; exp2 computed in-kernel.
                g_last_half_ub[0:1, 0:HALF_D] <<= g_last[b_idx, c_idx, hv_idx, row_begin_d:row_end_d]
                exp2_glast_vf(g_last_half_ub, exp_g_last_half_ub)

                state_bridge.lock()
                l1_dstate[row_begin_d:row_end_d, 0:D] <<= state_h_nz_ub[0:HALF_D, 0:D].nz()
                state_bridge.ready()

                gm_to_l1_nd2nz(l1_kg[0:L, 0:D], kg[b_idx, ctok0:ctok0 + L, hv_idx, 0:D], L, D, HV * D, L)
                state_bridge.wait()
                matmul(l0c_dvdelta, l1_kg, l1_dstate.T, m=L, n=D, k=D, splitn=D)
                state_bridge.free()
                # dh -> inverse seam BCHVDD [B,C,HV,D,D] (contiguous [D,D] sub-block).
                dh[b_idx, c_idx, hv_idx, row_begin_d:row_end_d, 0:D] <<= state_h_ub[0:HALF_D, 0:D]

                dvdelta_mutex.lock()
                l0c_to_ub(dv_delta_ub, l0c_dvdelta, M=L, N=D, N_dst=D, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
                dvdelta_mutex.ready()

                dvdelta_mutex.wait()
                dv0_mutex.wait()
                add_dv_and_cast_bf16_vf(dv_delta_ub, dv_sum_ub, dv_bf16_ub, dv_bf16_nz_ub)
                dvdelta_mutex.free()
                # dv_sum_ub is consumed; the next chunk's dv0 fixpipe may
                # overwrite it as soon as the prefetch runs.
                dv0_mutex.free()

                dv_bridge.lock()
                l1_dv[row_begin_l:row_end_l, 0:D] <<= dv_bf16_nz_ub[0:HALF_L, 0:D].nz()
                dv_bridge.ready()
                # dv -> public BTHVD [B,T,HV,D], strided (gap (HV-1)*D).
                ub_to_gm_pad(dv[b_idx, ctok0 + row_begin_l:ctok0 + row_end_l, hv_idx, 0:D], dv_bf16_ub[0:HALF_L, 0:D], HALF_L, D, 0, (HV - 1) * D)

                if rev_c + 1 < C:
                    gm_to_l1_nd2nz(l1_qg[rev_c + 1][0:L, 0:D], qg[b_idx, ntok0:ntok0 + L, hv_idx, 0:D], L, D, HV * D, L)
                    gm_to_l1_nd2nz(l1_w[rev_c + 1][0:L, 0:D], w[b_idx, ntok0:ntok0 + L, hv_idx, 0:D], L, D, HV * D, L)
                    gm_to_l1_nd2nz(l1_do[rev_c + 1][0:L, 0:D], grad_out[b_idx, ntok0:ntok0 + L, hv_idx, 0:D], L, D, HV * D, L)
                    gm_to_l1_nd2nz(l1_Aqk[rev_c + 1][0:L, 0:L], Aqk[b_idx, ntok0:ntok0 + L, hv_idx, 0:L], L, L, HV * L, L)
                    gm_to_l1_nd2nz(l1_vnew[rev_c + 1][0:L, 0:D], v_new[b_idx, ntok0:ntok0 + L, hv_idx, 0:D], L, D, HV * D, L)
                    matmul(l0c_seed[rev_c + 1], l1_qg[rev_c + 1].T, l1_do[rev_c + 1].T, m=D, n=D, k=L, splitn=D)
                    seed_mutex.lock()
                    l0c_to_ub(seed_ub[rev_c + 1], l0c_seed[rev_c + 1], M=D, N=D, N_dst=D, M_src=D, dual_mode=DualMode.SPLITM, sub_block_id=0)
                    seed_mutex.ready()

                dv_bridge.wait()
                matmul(l0c_corr, l1_w[rev_c].T, l1_dv.T, m=D, n=D, k=L, splitn=D)
                dv_bridge.free()

                corr_mutex.lock()
                l0c_to_ub(corr_ub, l0c_corr, M=D, N=D, N_dst=D, M_src=D, dual_mode=DualMode.SPLITM, sub_block_id=0)
                corr_mutex.ready()

                if rev_c + 1 < C:
                    matmul(l0c_daqk, l1_do[rev_c + 1], l1_vnew[rev_c + 1], m=L, n=L, k=D, splitn=L)
                    l0c_to_gm_nz2nd(dAqk[b_idx, ntok0:ntok0 + L, hv_idx, 0:L], l0c_daqk, L, L, HV * L, L, scale=DAQK_SCALE)
                    matmul(l0c_dv0, l1_Aqk[rev_c + 1].T, l1_do[rev_c + 1].T, m=L, n=D, k=L, splitn=D)
                    dv0_mutex.lock()
                    l0c_to_ub(dv_sum_ub, l0c_dv0, M=L, N=D, N_dst=D, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
                    dv0_mutex.ready()
                seed_mutex.wait()
                corr_mutex.wait()
                if rev_c + 1 < C:
                    update_dstate_vf(seed_ub[rev_c], corr_ub, dstate_f_ub, state_h_ub, state_h_nz_ub, exp_g_last_half_ub, row_begin_d)
                else:
                    update_dstate_final_vf(seed_ub[rev_c], corr_ub, dstate_f_ub, state_h_ub, exp_g_last_half_ub, row_begin_d)
                corr_mutex.free()
                seed_mutex.free()

            dh0[b_idx, hv_idx, row_begin_d:row_end_d, 0:D] <<= state_h_ub[0:HALF_D, 0:D]
            bar_all()

    return dAqk, dh, dv, dh0


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(kg, qg, w, g_last, grad_out, Aqk, v_new, dht, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    B = int(kg.shape[0])
    T = int(kg.shape[1])
    HV = int(kg.shape[2])
    C = T // L
    tensors = (("kg", kg), ("qg", qg), ("w", w), ("g_last", g_last), ("grad_out", grad_out), ("Aqk", Aqk), ("v_new", v_new), ("dht", dht))
    for name, tensor in tensors:
        if tensor.dtype != torch.bfloat16:
            raise TypeError(f"{name} must be bfloat16, got {tensor.dtype}")
    # No host glue: kg/qg/w/do/v_new are read strided from the frozen BTHVD seams,
    # Aqk from BTHVL, g_last raw [B,C,HV,D] (exp2 in-kernel). The qg 1/sqrt(D) scale
    # is folded into the seed fixpipe and dAqk's tril+scale runs on-device. dht
    # rides as a free [B,HV,D/2,2D] view (pure contiguous reshape, no data move).
    dht_gm = dht.view(B, HV, D // 2, 2 * D)

    outputs = (
        torch.empty((B, T, HV, L), dtype=torch.bfloat16, device=kg.device),     # dAqk  public BTHVL
        torch.empty((B, C, HV, D, D), dtype=torch.bfloat16, device=kg.device),  # dh    -> inverse BCHVDD
        torch.empty((B, T, HV, D), dtype=torch.bfloat16, device=kg.device),     # dv    -> inverse BTHVD
        torch.empty((B, HV, D, D), dtype=torch.bfloat16, device=kg.device),     # dh0   public
    )
    previous_config = getattr(scan_fused_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "scan_fused")
    if simulator:
        scan_fused_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            scan_fused_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            kg,
            qg,
            w,
            g_last,
            grad_out,
            Aqk,
            v_new,
            dht_gm,
            outputs[0],
            outputs[1],
            outputs[2],
            outputs[3],
            B,
            HV,
            C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(scan_fused_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                scan_fused_kernel._simulator_config = previous_config
    if gen_only:
        return result
    # Public/inter-stage seams already written strided on-device: dAqk BTHVL
    # (below-diagonal masked by finalize_pre's re-tril), dh BCHVDD, dv BTHVD,
    # dh0 [B,HV,D,D]. No host post-processing.
    return result[0], result[1], result[2], result[3]


if __name__ == "__main__":
    import dataclasses

    from projects.a5.kda_bwd.refs.common import make_inputs

    stage_tol = 4e-3

    def _check(inputs, label):
        caches = build_saved_forward(inputs)
        dAqk_ref, dv0_ref = scan_dav_only(inputs, caches)
        expected = scan_state_only(inputs, caches, dv0_ref)
        g_last = caches.g_cumsum[:, L - 1::L, :, :]
        got = run(caches.kg, caches.qg, caches.w, g_last, inputs.do, caches.Aqk, caches.v_new, inputs.dht, simulator=True)
        # dAqk is stored un-trilled on-device (finalize_pre re-trils downstream);
        # apply the per-chunk causal mask here to match the trilled stage reference.
        Bn, Tn, HVn, _ = got[0].shape
        Cn = Tn // L
        tri = torch.tril(torch.ones(L, L))
        daqk_masked = (got[0].float().reshape(Bn, Cn, L, HVn, L) * tri[None, None, :, None, :]).reshape(Bn, Tn, HVn, L)
        got = (daqk_masked, got[1], got[2], got[3])
        for got_item, exp_item in zip(got, (dAqk_ref,) + tuple(expected)):
            torch.testing.assert_close(got_item.float(), exp_item.float(), rtol=stage_tol, atol=stage_tol)
        print(f"{label}: OK", [tuple(item.shape) for item in got], [item.dtype for item in got])

    base = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    _check(base, "default (deep softplus decay, g_last ~ -74)")

    # exp2 guardrail: the deep-decay default underflows both 2^g_last and
    # e^g_last to ~0, masking a natural-exp regression in the decay scale.
    # Shrink the gate so g_last ~ -2 (where exp2 vs exp differ ~50%) and amplify
    # dht so the decayed state-carry term dominates the seed/corr terms -- a
    # kernel that uses exp() instead of exp2() then misses dh/dv/dh0 by ~0.1.
    base256 = make_inputs(B=1, H=2, HV=4, T=256, K=128, V=128, chunk_size=L, seed=0)
    gentle = dataclasses.replace(
        base256,
        g=(base256.g.float() * 0.03).to(base256.g.dtype),
        dht=(base256.dht.float() * 100.0).to(base256.dht.dtype),
    )
    _check(gentle, "exp2 guardrail (gentle decay, g_last ~ -2)")
