# GDN Backward 优化故事 / The Optimization Story

> 这是 `optimization_timeline.md` 的叙事版。timeline 仍是逐条、带全部 dense
> 数据的 canonical 记录；这里换一种讲法，把当前实现依据串成一个故事：每一步
> **为什么要做、怎么试的、成没成、省了多少**。所有 cycle / µs 数字都来自
> timeline，未做改动。
>
> 阅读约定：
> - kernel 名、API 名、`DBuff` / `mutex` / `lookahead` 这类术语保留英文。
> - cycle 数若不特别说明，都注明测量上下文（**32-core default** 指
>   `(B,H,C)=(1,2,2)` 的 32 模拟核 compose trace；**1-core stress** 指同 BHC
>   单核压测；**hardware AVG** 指 WebIDE 板上 `(1,32,16)` 的 `profile=True` 均值）。
> - 单位：cycle 是模拟器节拍，µs 是真机平均耗时。

---

## 序章：一个能跑、但很慢的 backward

故事的起点是 `gdn_bwd_full` —— 一条完整、正确，但完全没有为硬件考虑过的
反向公式。我们做的第一件事不是提速，而是**让它在 A5 上诚实地跑起来**。

第一版 plan1 把整条公式显式拆成五个阶段：

```text
scan_bwd -> wu_bwd -> inverse_preprocess_bwd -> finalize_bwd
scan_bwd, wu_bwd, inverse_preprocess_bwd -> finalize_bwd
```

**为什么这么拆**：原始公式里混着 recurrent 扫描、矩阵求逆预处理、加权累积
和最终汇总，硬件上各自需要的 pipe（cube / VF）完全不同。把它们摊开成独立
kernel，才有逐个调度的余地。

这一章基本是"把 SIMT 退场、让 cube/VF 上场"的搬运工作：

- `inverse_preprocess_bwd`：从 SIMT fallback 改成 cube/VF 结构。
- `finalize_bwd`：从 GM 全宽 SIMT 改成 vector reduction。
- `wu_bwd`：成为真正的 cube/VF kernel。
- `scan_bwd`：成为 reverse-C 的 recurrent kernel。
- refs 与 kernels 统一到 **bf16 cube 操作数 + fp32 累加**，容差 `atol=rtol=5e-4`。

**结果**：full compose 路径 simulator-vs-ref 通过。还没有任何提速，但我们有了
一个可信的基线——后面每一步"省了多少"，都是相对它来量的。

整条优化之路的全景图——Act I 是 trace 驱动的模拟器调优，Act II 是硬件 bring-up：

![优化时间线：跨两幕的九个阶段](figures/01_timeline.svg)

*Act I（阶段 1–5）在模拟器上调优；Act II（阶段 6–9）在 Ascend 950 上做 bring-up。
图中 chip 只显示相对改善（%）。*

---

## 第一章：先摘软柿子 —— 不碰 scan，先调尾巴

第一份 32-core default 基线长这样：

| stage | baseline cycles |
|---|---:|
| `scan_bwd` | `94373` |
| `wu_bwd` | `14161` |
| `inverse_preprocess_bwd` | `9621` |
| `finalize_bwd` | `16858` |
| `compose_sum` | `135013` |

一眼就能看出 `scan_bwd` 是大头。但我们**故意先不碰它**。

**为什么**：scan 又大又危险（recurrent，状态跨 chunk 流动，改错很难查）。
尾部三个 kernel（wu / inverse / finalize）小、独立、好验证，正好拿来打磨手感、
积累"哪些手法在这套硬件上真有效"的直觉，同时把 compose 总数先往下压一点。

### 成功的尾部改动

`finalize_bwd` 是收益最大的：

- 删掉死掉的 `d_q` VF 工作；再进一步，把 identity 的 `d_query` 拷贝**整个删掉**，
  改由 `kernel_compose.py` 直接 forward `scan[0]`。
- `d_g` 的列累加器留在寄存器里，不落 UB。
- 标量 reverse cumsum 换成 vector gather/prefix 形式。
- gather 索引的 scratch-UB reinterpret 换成 `Reg.reinterpret`。
- 拆分 value/beta 与 key 两个 VF，再用显式 vec-side ready/valid 信号取代大范围
  `auto_sync()`。

`wu_bwd` 两招：

- WU 因子生产与 bf16-NZ cast 融合——很小但很干净。
- 把 `l0c_d_k_beta_g -> UB` 提到 `d_wu` / `d_v_beta` GM 写回**之前**，让最后一个
  WU VF 能和 FIX 写回重叠。这才是 WU 真正的胜负手。

`inverse_preprocess_bwd` 三招：

- 更早发布 `l1_d_score` 就绪信号，让最后的 cube matmul 不必排在 `d_decay_pre`
  GM store 后面干等。
- 在 cube-to-vec 等待之前预取 `decay_mask`，用一个窄的 `V -> MTE2` 复用信号保护。
- 把单核多 BHC 路径重塑成 `V1C1` producer / `V2C2` consumer 的 lookahead，凡是
  跨两个 beat 存活的角色就用 TBuff。

这一章收尾时的账：

| metric | baseline | current | delta |
|---|---:|---:|---:|
| `wu_bwd` | `14161` | `12005` | `-2156` |
| `inverse_preprocess_bwd` | `9621` | `8509` | `-1112` |
| `finalize_bwd` | `16858` | `12069` | `-4789` |
| `compose_sum` | `135013` | `126956` | `-8057` |

逐步台账（顺序本身就是经验，故保留）：

| step | accepted edit | stage effect |
|---|---|---|
| 1 | 删 `finalize_vectors_beta_vf` 里的死 `d_q` 寄存器工作 | `finalize_bwd 16858 -> 16474` |
| 2 | `finalize_g_vf` 列和留寄存器 | `finalize_bwd 16474 -> 16092` |
| 3 | compose 里 `d_query` 直接 forward `scan[0]` | `finalize_bwd 16092 -> 15280` |
| 4 | `d_g` reverse cumsum 向量化（gather/prefix offset） | `finalize_bwd 15280 -> 13766` |
| 5 | gather 索引用 `Reg.reinterpret(DT.uint32)` | `finalize_bwd 13766 -> 13710` |
| 6 | WU 因子生产与 bf16-NZ pack 融合 | `wu_bwd 14161 -> 14141` |
| 7 | WU GM 写回前先把 `l0c_d_k_beta_g` 暴露到 UB | `wu_bwd 14141 -> 12005` |
| 8 | 两个 `d_beta` dot reduction 合并到一次 `cadd` | `finalize_bwd 13710 -> 13102` |
| 9 | 拆分 vector/beta 的输入输出 UB 归属 | `finalize_bwd 13102 -> 13038` |
| 10 | value/beta 与 key VF 拆开 + 手动 vec 信号 | `finalize_bwd 13038 -> 12069` |
| 11 | inverse `l1_d_score` 就绪先于 `d_decay_pre` GM store 发布 | `inverse_preprocess_bwd 9621 -> 9065` |
| 12 | inverse `decay_mask` 在窄复用信号后预取 | `inverse_preprocess_bwd 9065 -> 8503` |
| 13 | inverse 改 `V1C1`/`V2C2` lookahead | 单核赢；default `8503 -> 8509` |

### 失败的尝试（同样是故事的一部分）

- **过早 `d_query` 写回**：没加 load-to-store 信号就写，直接污染 output0；补上信号
  后正确了，但收益归零——于是改走 compose 层 forward，反而更干净。
- **给 vector/beta 直接套 `DBuff`**：多花约 `96 KB` UB，却没改变 issue 出来的调度，
  32-core 和单核 trace 上都是**零收益**。第一次明确教训：**DBuff 不等于提速**。
- **把 WU 最后那个 VF 拆成两个 16 行块**：`wu_bwd 12005 -> 12687` 回退；多一次 VF
  launch + 更碎的 store，盖过了重叠收益。
- **不拆归属就删 loop barrier**：触发 simulator local-memory 警告。真正的收益来自
  "把归属做实"，不是"把警告消音"。
- **inverse 过早做 `d_k_beta_pre` GM 写回**：单 BHC 检查能过，单核多 BHC 压测却
  `max_abs=3.210e-03` 挂掉——证明了**同核复用压测是必须的**。

尾巴打磨完，`scan` 的统治地位再无悬念。该上主菜了。

---

## 第二章：啃硬骨头 —— 单体 scan 的 VF 大扫除

这一版还是单体 `scan_bwd.py`。单核 trace 把热点 VF 摊得清清楚楚：

| work | approximate cycles |
|---|---:|
| `finish_g_full_vf` | `5179` |
| `accum_dq_g_full_vf` | `4298` |
| `postprocess_dk_vf` | `2003` |
| `postprocess_dq_vf` | `1898` |
| `make_k_weighted_vf` | `1555` |
| `make_q_exp_vf` | `1450` |

**主线策略**：与其炫技调度，不如**直接删活**——尤其是 `c_idx == 0` 那个 chunk，
此时 state 恒为零，一大票工作纯属多余。

具体做了：

- 删掉 q/k producer 里的死 fp32 镜像 store。
- q/k producer 的 VF 与 bf16-NZ pack 融合。
- 删掉 dq/dk postprocess 里的死 q/key load。
- 给 dq/dk postprocess 缓存半行 `exp(g)` 和 `exp(g_last-g)`。
- 只保留经同核复用压测证明确实需要的 barrier。
- 专门特化 c0 的 `d_g` 路径、c0 的 `v_new=value_wu`、c0 的 zero-state matmul、
  c0 的 q-exp 发布。
- 在合法处于 full-L `d_g` 路径复用 low-half exp 值。

**结果**：32-core compose trace 上单体 scan 从 `94373` 一路降到约 `65999` cycle。
漂亮的局部胜利——但 kernel 也被压得越来越满，再往下推就开始踩 cross-lane 生命期
风险。这为下一章"拆分"埋了伏笔。

![单体 scan 阶梯：16 个改动把 scan 压到基线的 70%](figures/02_scan_optimization.svg)

*16 个接受的改动按序施加，每步削一点；c0 zero-state 特化是最陡的那段。scan
makespan −30%。*

详细台账：

| milestone | default scan cycles | 要点 |
|---|---:|---|
| 尾部工作后稳定 | `94373` | scan 成为瓶颈 |
| 删死的 q/k fp32 镜像 store | `93605` | 无消费者 |
| q/k producer + bf16-NZ pack 融合 | `92029` | 更少 VF 调用 |
| 删死的 q/key postprocess load | `88525` | 删无用 GM load |
| 加半行 exp 缓存 | `85899` | 复用本地 exp 因子 |
| c0 zero-base `d_g` 特化 | `79901` | c0 处 state 为零 |
| c0 直接 `v_new=value_wu` 发布 | `77161` | 跳过 zero-state 路径 |
| 跳过 c0 zero-state matmul | `73840` | 删 cube 工作 |
| 跳过 c0 q-exp 发布 | `71965` | c0 无消费者 |
| lane0-only full-L `d_g` + 配对 handoff | `71652` | 删重复 vec 工作 |
| full state-dot VF 融合 | `71640` | 一次 launch 顶两次 |
| 独立 GM load 绕等待预取 | `70392` 再 `67815` | 是重叠，不是少指令 |
| full-L `d_g` 复用 low-half exp | `66375` | lane0 只能复用自己那半 |
| mask/copy/postprocess VF 的 tail-barrier 清理 | `66003` | 无警告地缩归属 |
| 最后的 middle-barrier/high-half 清理 | `65999` | 小而稳 |

### 单体 scan 的重要失败

- 不做合法归属拆分就删 `postprocess_dq_vf`/`postprocess_dk_vf` 的行循环 barrier：
  正确性挂。
- 把 full-L `d_g` handoff 仅 gate 到 `GetSubBlockIdx() == 0`：直接挂起，直到把
  mutex 配对修好——两条 lane 都需要匹配的 handoff/free 边。
- 把 `update_d_state_vf` 移到单个 tail barrier：过了一次，但冒 loop-carried
  local-memory 警告，回退。
- 直接从 FIX 产出的 UB view store c0 `d_q_core`：失败；copy VF 是必须的，要把
  lane-local 数据物化出来才能 GM store。
- 复用 `l0c_ld1` 或盲加 L0C `DBuff`：暴露真实的 FIX/M/生命期 hazard。那些诱人的
  更快 trace，要么精度挂，要么和生成的 event 序列撞车。

教训累积成一句话：**单体 kernel 已经到头了，要继续就得换结构。**

---

## 第三章：拆分 scan —— 主线浮出水面

下一个方向把 scan 拆成两半：一个 BHC 并行的本地 producer，一个 BH 并行的
reverse-state consumer。

```text
scan_local_bwd -> scan_state_bwd
```

**为什么拆**：单体里 local attention 乘积和 reverse recurrent `d_state` 路径
被焊在一起，调度面互相牵制。拆开后，`scan_local_bwd` 可以围绕 cube/VF 重叠
自由排程；`scan_state_bwd` 专心管 recurrent 与剩余输出。调优面一下子清晰了。

**第一次拆分的判断很微妙**：`C=2` 时反而更慢，但 `C=16` 时更快——后者足够
让我们把它留作候选继续探。这是一个"先难看、后正确"的决定。

打磨到一定程度时，clean default-core 拆分 trace：

| stage | cycles |
|---|---:|
| `scan_local_bwd` | `10779` |
| `scan_state_bwd` | `40282` |
| `scan_split_sum` | `51061` |
| `compose_sum` | `83644` |

这是 forward-cache 那一轮之前的**最佳模拟器路线**。

拆分路线的关键 checkpoint：

| checkpoint | result |
|---|---|
| `C=2` 首个 fp32-temp 拆分 | `scan_split_sum=74305`，慢于单体 `65999` |
| 同拆分 `C=16` | 拆分 `643103` vs 单体 `684337`，够格继续探 |
| default 拆分 compose | 公共输出通过，`compose_sum=106888` |
| 单核拆分基线 | `scan_local_bwd=38273`、`scan_state_bwd=119588`、`compose_sum=260613` |
| local store 重排 | local `38273 -> 32350` |
| `grad_output` 独立 mutex + 延迟 load | local `32350 -> 30727` |
| local lookahead-1 实验 | 单核 local `30727 -> 25296` |
| 多核 drain 修复（`M -> FIX` `ld0_ready`） | default 通过；local 成为 canonical 源 |

随后 state 阶段主攻 **lane 不均衡**与 scratch 流量：

![拆分 scan：9 个 lane 平衡改动把 scan_state 压到基线的 67%](figures/05_split_scan.svg)

*把原本压在 vec0 上的 gate 工作拆到两条 vector lane，加上无警告的
`cv_seed_mutex` handoff，单核 `scan_state_bwd` −33%。*

| checkpoint | 单核 `scan_state_bwd` | note |
|---|---:|---|
| 带 lookahead local 的基线 | `119588` | vec0 扛了大部分 gate 工作 |
| 拆 c0 `finish_g_zero_base` | `118329` | 两 lane 各管半行 |
| 拆 `d_exp` / state-dot 累加 | `112123` | 配对 half-D reduction |
| 拆 c!=0 `accum_dq_g` 与 `finish_g` | `104641` | lane 平衡改善 |
| 删死 scratch store + 冗余 barrier | `104034` | 小而干净 |
| gate VF 复用裸 q/k 半行 | `103982` | 代价 16 KB UB |
| 只拆初始 `grad_final_state -> l1_d_state` | `103222` | 更新后的拆分是错的 |
| lane0 delta 与 `d_exp_total` 打包进一个 scratch 向量 | `102654` | 省一次 scratch 往返 |
| 手动 vec 信号 + 小范围 cube `auto_sync()` | `80035`（带警告） | 太快但有警告，不能留 |
| 专用 `cv_seed_mutex` 包住 `l0c_dd -> ub_d_state_seed` | `80175`，无警告 | 接受的 sync 形态 |

注意那个从 `102654` 到 `80035` 的大跳：手动信号化把近 **2 万 cycle** 挤了出来，
但带着警告我们不敢要；补上专用 `cv_seed_mutex` 后落在 `80175`——几乎不损失收益，
却换回了无警告的正确归属。这正是"**警告不是装饰**"那条铁律的来源。

### 拆分 state 的重要失败

- 按 lane 拆 `update_d_state_vf` 或 update 后的 `l1_d_state` 发布：output 1/2/4
  挂。recurrent state 契约仍需要一个 lane0-full owner，或一套不同的共享状态设计。
- 从已有 UB 半行发布 `state_after_history`：与 cube 的 GM-to-L1 路径**布局不等价**。
- 把 gate q/k load 提到 `postprocess_dk` 之前预取：正确但更慢——**不是每个独立
  load 都该往前提**。
- 盲删剩余的 `FIX -> MTE1` 信号：回退。只有当数据路径确实是 `L0C -> UB -> VF`
  时删才安全。

---

## 第四章：改契约 —— 让 forward 替 backward 记账

到这里，单纯改 backward 调度的空间在收窄。于是我们改的不再是调度，而是**计划
本身的 IO 契约**：让 forward 把 backward 本来要重算的中间量存下来。

新增的 forward-saved history：

- `v_new_history`：省掉 local 阶段重算 `value_wu - k_cumdecay @ state`。
- `k_weighted_history`：省掉运行时 `key * exp_delta` 的 vector/pack 工作（喂
  `d_v_new` cube 乘积）。
- `exp_delta_history`：省掉 `scan_state_bwd` 里每行重算 `exp(g_last - g)`。

同时把 scan-local 到 scan-state 的 `d_score_tmp` handoff 从 fp32 GM 改成
**bf16 GM**——因为它只喂 cube score 乘积：

```text
d_q_score = d_score @ key
d_k_score = d_score.T @ query
```

![forward-cache 契约：保存 forward 中间量缩小 scan 阶段](figures/03_forward_cache.svg)

*每个 saved-history 张量都从 `scan_state_bwd` 削掉一截（保留收益 −11%）；内部 L1
lookahead 模拟器正确但引发真机挂起，已回退。*

这一轮探了好几种形态：

- 单个 `scan_saved_bwd`：正确，但 UB 紧到 `249.03125 KB / 256 KB`，不能当终态。
- 三段拆分 `scan_local_bwd -> scan_pre_bwd -> scan_state_recur_bwd`：暴露了有用
  的 UB 生命期教训（`float_full_ub` 需要定点 `DBuff`，否则 `d_q_core` 写回与后续
  full `d_q_exp` 输入共用同一 slot），但整体太贵。
- `scan_state_recur_bwd` 里的 L1 DBuff lookahead 帮了那个实验阶段
  （`105200 -> 100292`），但多出的 launch 和重复 state 工作让三段方案整体更差。
- `scan_state_bwd` 内部的小 L1 lookahead-1：模拟器里藏掉了一些 L1 publish 等待，
  但后来因**真机挂起**被从官方计划里回退。

最终接受的官方方向：

```text
scan_local_bwd -> scan_state_bwd
forward-saved v_new_history, k_weighted_history, exp_delta_history
bf16 d_score_tmp
不要 scan-state 内部 L1 lookahead
```

forward-cache 的计时阶梯（**1-core stress** `(1,2,2)`）：

| version | `scan_local_bwd` | `scan_state_bwd` | `scan_split_sum` | `compose_sum` |
|---|---:|---:|---:|---:|
| round2 前拆分基线 | `25297` | `80175` | `105472` | `208224` |
| +`v_new_history` | `21663` | `78592` | `100255` | `203005` |
| +`k_weighted_history` | `21663` | `75513` | `97176` | `199926` |
| 恢复两-kernel 路径 | `21663` | `74863` | `96526` | `199278` |
| +`exp_delta_history` | `21663` | `72415` | `94078` | `196828` |
| +bf16 `d_score_tmp` handoff | `21703` | `71474` | `93177` | `195929` |
| 内部 L1 lookahead 实验 | `21703` | `71338` | `93041` | `195793` |

那个内部 L1 lookahead 在模拟器里完全正确（连 `C=3` slot-wrap 回归都过了），
但只值 `136` 个 state cycle，后来还在真机上引发挂起。**于是官方计划留下了
forward-cache 和 bf16-handoff 这些大头收益，把 state L1 输入退回单 `Tensor` 存储。**
这是"收益太小 + 真机有风险 = 不要"的典型判断。

值得留档的几条记录：

- `k_weighted_history -> l1_k_weighted` 是 cube/MTE2 工作。`GetSubBlockIdx() == 0`
  是 **vector-side** 控制，并不等于"只有一个 cube subblock 发这个 load"——实验对
  这点的期望落空。
- 调查中顺手修了一个模拟器 GM-to-L1 partial-NZ 写 bug：部分行写现在会保留 peer
  行，而不是清空整个目标 panel。但天真的 half-L `k_weighted_history` 拆分修完后
  仍因上面那条 cube 控制原因失败。

这一版计划先从 scratch 提升进当前 `projects/a5/gdn_bwd/`（只含生产源、refs、
检查与笔记），待其他候选计划退役后，再提升到 canonical 的
`projects/a5/gdn_bwd/{kernels,refs,test_script}` 布局。生成的 ACLNN 树、trace JSON、
dump 和被否决的实验文件都**没有**被提升。

---

## 第五章：硬件，照妖镜

模拟器通过不是终点。WebIDE 真机检查揪出了一批**看着像精度漂移、其实是
调度/生命期 bug** 的问题。这一章把"模拟器干净 ≠ 硬件正确"钉死成项目铁律。

每次脱困的套路都一样——这也是贯穿 Act II 的主线：

![硬件 triage：逐输出重建每个 kernel](figures/06_incremental_rebuild.svg)

*盲补融合 kernel 只会把失败挪个位置。把每个 kernel 逐输出重新长出来——并在
inverse 里先写 `d_decay_pre` 再发布 `d_score`——才最终过了 WebIDE。*

**第一个硬件问题：`scan_local_bwd`。**

- `d_score_tmp` 和 `d_v_attn_tmp` 对得上。
- 但 `d_decay_core` 在每个 vec half 的**第一行**出现精确的零。
- 接受的修法：从连续的 `[HALF_L, L]` `ll2_ub` 缓冲写 `d_decay_core`，而不是之前
  的宽行 `float_full_ub` 路径。

**第二个硬件问题：融合版 `scan_state_bwd`。**

- `d_q_core`、`d_k_core`，以及后来的 `d_g_core` 在真机上挂。
- 试了很多融合 kernel 的修补，全被否——它们只是把失败**挪了个位置**。
- 于是改走更稳的增量路线：**搭一个干净的独立 kernel，一次只加一个输出。**

独立 scan-state 重建，逐输出验证：

1. 只有 `d_q_core`：模拟器 + 硬件通过。
2. 加 `d_k_core` 与 recurrent `d_state` 更新：硬件通过。
3. 加 `d_g_core`：用一个独立的 `d_q_exp_ub` 角色修掉 scratch 复用 bug。
4. 加 `d_value_wu`：把 c0 的额外 matmul staging 移出 `out_ub`，保住 pending 的
   `d_k_core` GM 写回稳定。
5. 加 `d_k_cumdecay`：通过一个已退役的 UB 角色清零，避免污染 pending 的
   `d_value_wu` GM 源。

至此 `scan_state_dq_core_bwd.py` 覆盖了全部 scan-state 输出且硬件通过。运行时
`scan_state_bwd` 绑定换成这个验证过的实现，老融合体只留作对照。

**收益**：独立替代版在 `(1,32,16)` 的硬件 profile 初测 `306.58us`，再经几处保留的
trace 驱动优化，把运行时路径降到最终 compose profile 值 **`266.23us`**。

---

## 第六章：inverse 的逐输出重建

`inverse_preprocess_bwd` 也有**只在硬件上出现**的失败，集中在 `d_decay_pre`。
我们再次用"慢但稳"的路线：隔离一个输出，硬件过了再加下一个。

路径：

1. 只 `d_k_pre`：本地模拟器 + WebIDE 硬件通过。
2. 加 `d_k_beta_pre` + `d_decay_pre`：暴露硬件生命期/顺序 bug——在 `d_decay_pre`
   GM 写**之前**把 `d_score` 发布进 L1，会让 `d_decay_pre` 失败或变成非有限值。
3. 改成先做 `d_decay_pre`，单独证明 decay 公式。
4. 加 `d_k_beta_pre`：只有当 `d_decay_pre` GM store 移到 `d_score` bf16-NZ 发布
   **之前**才通过。
5. 加最终 `d_k_pre`，补齐三元组：

   ```text
   d_k_pre, d_k_beta_pre, d_decay_pre
   ```

接受的完整 inverse 调度保住了这个硬件验证过的顺序：

```text
算 score-only 和 decay-only 的 VF 行
写 d_decay_pre 到 GM
把 d_score 发布成 bf16 NZ L1
跑下游 d_k_beta_pre 和 d_k_pre cube matmul
```

随后一轮轻量 L1 `DBuff`：把 `l1_w`、`l1_d_wu`、`l1_tmp`、`l1_d_score` 提成两-slot
DBuff，score mutex 深度改 2。这是一次**真机收益**：

| version | hardware AVG |
|---|---:|
| Tensor L1 基线 | `86.44us` |
| L1 DBuff | `84.69us` |
| final trace-check ref upstream | `82.78us` |
| final trace-check kernel upstream | `86.23us` |

**被否的 final-store 重写**：单核模拟器显示 tail 被直接的 `FIX:l0c_to_gm_nz2nd`
store 主导，但把它们换成 `L0C -> UB -> GM`、或只把第一个 final store 提前，要么
回归要么是噪声。收紧 score barrier 只省几个 cycle，于是恢复了更安全的 barrier。

---

## 第七章：finalize 与那个倔强的 `d_g`

Round2 曾给 `finalize_g` 做过一个模拟器正确的 cube-reduce 候选（host 提供
`ones16`、DBuff VCVC lookahead、VF reverse cumsum）。有意思，但不是最终硬件路线。

硬件暴露了一个**只挂 `d_g`**的问题——`d_key`、`d_value`、`d_beta` 全对。几个看着
合理的修法都没解决：

- 推迟 reduce mutex 释放，直到 lane0 消费完 row/col reduce 值；
- 把 row/col reduce 的 L0C scratch 提成 DBuff；
- 在 full kernel 里用 lane0-only 的 VF reduce 替换 cube reduce。

成功的还是增量路线：

1. `finalize_d_g_bwd.py`：只算 `d_g`，慢的 rowwise VF 路径。硬件通过。
2. `finalize_d_g_value_bwd.py`：加 `d_value = d_v_beta * beta`。修掉一个 CANN
   打包命名问题后硬件通过。
3. `finalize_d_g_value_beta_bwd.py`：加 `d_beta`。硬件通过。
4. 完整 `finalize_bwd.py`：保留证明过的 rowwise scalar/VF `d_g` 路径，恢复
   `d_key`、`d_value`、`d_beta` 的 vector 公式。

那个命名问题不是数学问题：CANN 把 `FinalizeDGValueBwdKernel` snake-case 成
`finalize_dg_value_bwd_kernel.cpp`，而 EasyAsc 的函数名
`finalize_d_g_value_bwd_kernel` 生成的文件名不同。把公共 `@kernel` 函数改名对齐
CANN 的 snake-case，打包就对上了。（这条后来沉淀成 a5 cannsim 的命名教训。）

最终独立硬件验证：

| kernel | mode | hardware AVG | result |
|---|---|---:|---|
| `finalize_d_g_value_bwd.py` | ref upstream | `103.20us` | OK |
| `finalize_d_g_value_bwd.py` | kernel upstream | `102.10us` | OK |
| `finalize_d_g_value_beta_bwd.py` | ref upstream | `112.56us` | OK |
| `finalize_d_g_value_beta_bwd.py` | kernel upstream | `112.82us` | OK |
| `finalize_bwd.py` | ref upstream | `140.81us` | OK |
| `finalize_bwd.py` | kernel upstream | `140.46us` | OK |

---

## 第八章：持续微调 —— 模拟器上的最后一公里

硬件路线稳定后，又回到模拟器做了一批更细的打磨（2026-05-27 / 05-28 起）。这些
改动单看都不大，但合起来把几个尾部 kernel 又压了一截，也产出了几条"数学上更
干净、调度上却更差"的反例。

### inverse 的再优化

用 1-core `(1,1,4)` 压测暴露同核 BHC 复用。基线 `18977` cycle（cube `FIX=72.6%`、
vec `V=71.5%`、vec `MTE2=75.0%` active/span）。一批想法被否（中性、错误、带警告
或更慢）：DBuff `l1_d_score`、融合 d-score cast、consumer-first 调度、裸 key 直接
GM->L1。

接受的那一版：把 L0C producer/final-output 临时量 DBuff 化，把即时的 `FIX -> M`
L0C 复用等待改成预置 DEvent，并在 `mask_score_and_decay_vf` 里把不变的列 arange
外提、对 `d_attn` 只 mask 一次再喂两个输出乘积。**收益**：1-core inverse
`18977 -> 18187`，32-core default `8610 -> 8325`，full gdn_bwd 在
`PYTHONWARNINGS=error` 下 simulator-vs-ref 通过。

### wu 的再优化与 bf16 输入契约

保留用户对 DBuff 的那点直觉里有用的部分：`d_k_beta_g_ub` 配一个匹配 depth-2
cube->vec mutex 的 DBuff slot，并在 finalize VF 消费该 slot 时释放 mutex。真正可
测的收益来自把 `make_wu_inputs_vf` 和 `finalize_wu_partials_vf` 里**每行的 VF
barrier 上提成 loop-end barrier**，外加一处 finalize 重写——先算
`d_k_beta = d_k_beta_g * exp_g` 再算 `d_g = sum(d_k_beta * k_beta)`，省掉老的
标量后乘。**收益**：1-core `(1,1,4)` `27584 -> 26752`，`(1,1,8)` 从 pre-hoist
DBuff 探针 `49579 -> 47740`。

接着把 `scan_state_bwd -> wu_bwd` 的 `d_value_wu` / `d_k_cumdecay` workspace 改成
bf16。ref-only 验证确认：32 个随机用例下最终输出**零差**，因为 WU 只把它们当
bf16 cube 操作数消费。落到 kernel 后，scan-state 内部本身近乎中性
（1-core C=4 `77938 -> 78002`：MTE3 降、V 因 bf16 行物化而升），但 wu 端直接吃
bf16 GM->L1，删掉了 fp32 GM->UB load 加 bf16 pack/NZ staging。**收益**：WU 的 UB
从 `240.875 KB / 256 KB` 降到 `144.875 KB / 256 KB`；1-core `(1,1,4)`
`26752 -> 21881`，`(1,1,8)` `47740 -> 39797`。

### scan_state 的尾部清理

`(1,1,8)` 复查。先删两个 `d_value_wu` VF finalizer 里的死 fp32 sum store：c0 和
非零分支都只物化 bf16 `d_value_wu` 行（非零分支仍写 negated fp32 state seed 与
bf16 NZ `d_v_prime` bridge）——`159747 -> 158723`。再加一条 c0-only `d_q_core`
快路径，直接从 L0C 写 GM（c0 不需要 `d_q` 的 VF postprocess），省掉老的
L0C->UB / VF copy / UB->GM 绕路——`158723 -> 157784`，local-memory hazard 检查
通过。

两条**被否**的替代同样留档：把 c0 `d_value_wu` 移到 `d_q`/`d_k` 之前，要么因共享
`score_ub` 而错、要么拆开后更慢（`160247`）；预缩放 c0 `d_k` 的 `term * exp_delta`
正确但更慢（`158180`）。

### finalize 的算术化简与那场 cube-reduce 拉锯

`finalize_bwd` 的 upper 分支是对角/配对 dot reduction，普通 cube matmul 会算出整个
跨行矩阵再把非对角丢掉——所以**没有走 cube**。保留的化简是一个融合 upper VF：
`d_k_beta_wu + d_k_beta_pre` 留在寄存器里同时喂 `d_beta` 和 `d_key`，删掉原来
value/beta 与 key 两个 VF 之间的 UB 往返。**收益**：default C=8 `22424 -> 21956`
（per-lane V active `13191 -> 12255`），2-core C=8 hazard-check `35966` 通过。

`d_g` 的 cube-reduce 老想法在这条生产路径上**继续被否**：它模拟器正确，但不是
硬件验证过的路线，VF row/col reduce + reverse cumsum 仍是更安全的实现。那个
cube-reduce 实验遗留的、没用上的 `ones16` GMTensor 参数从 live kernel ABI 里删掉了。

后续还试了把 lower half 做成显式 cube reduction（host 提供常量）：

- 第一版 scalar-row：在 VF 物化 `A = (d_decay_core + d_decay_pre) * decay_mask`，
  发布到 L1，在 L0C 里直接累加 `d_g_core @ eye + d_g_wu @ eye + ones @ A.T +
  neg_ones @ A`，再经一次 L0C->L1 handoff 后用第二个 matmul 应用 `reverse_tril`。
  所有常量都是 kernel 输入、提到 BHC loop 外。模拟器与 `gen_only` 都过；C=8/2-core
  lower-only trace `22885` cycle，`max_abs_diff=1.788139e-07`。
- `BHC_TILE=16` 跟进：把 base 和 final reverse-cumsum 批成 `[<=16,64]` matmul，用
  host 提供的 `selector_rows` / `neg_selector_rows` 常量，让每个 per-BHC `A` 贡献
  `selector[t] @ A` 和 `neg_selector[t] @ A.T` 到一行选中的 L0C。正确性仍过（C=8
  max diff `2.682209e-07`，BHC=32 max diff `3.576279e-07`），`gen_only` 成功——
  但调度更差：C=8/2-core 回归到 `50832`（单 16 行 tile 只让 core0 有活），完整
  两-tile `(1,4,8)`/2-core 是 `101807`。批处理虽降了 MMAD active，却加了 128KB
  selector L1、output L0C->UB->GM 流量和更多串行 vec/cube 等待。**被否**。

最终接受的 all-cube `d_g` 集成：直接用上游已 mask 的 decay 输出，只在 wrapper
边界 flatten lower-path BHC 张量，保持 `BHC_TILE=4`，让 `(1,1,8)` 给两个目标核都有
真 cube 活。`finalize_bwd` upper 融合 VF 不变，然后 reset cache、把 lower path 跑成
`mte2 -> mte1/mmad -> fix`，`d_decay_core_masked` / `d_decay_pre_masked` 用普通
DBuff L1 slot，常量由 host 提供。**收益**：2-core C=8 模拟器 profile 从此前 live
的 `35966` 降到 **`27987`**；输出 max diff 为 `0, 0, 1.676381e-08, 1.788139e-07`，
active-span 占用 `MTE2=100.0%`、`V=87.9%`、`M=73.5%`、`MTE3=56.1%`、`MTE1=41.6%`、
`FIX=47.9%`。`gen_only`、双上游 `finalize_bwd` 与小 compose smoke 全过。

（为支撑这条 all-cube `d_g`，上游 producer 在不破坏旧 ABI 的前提下追加了已 mask 的
decay 矩阵：`scan_local_bwd` 把 `d_decay_core_masked = d_decay_core * decay_mask`
作为 output 3，UB 升到 `152 KB / 256 KB`；`inverse_preprocess_bwd` 把
`d_decay_pre_masked` 作为 output 3，UB 升到 `192.375 KB / 256 KB`。期间还修了
`cast_l_rows_float_to_bf16_nz_vf` 用 `MaskType.LOWHALF` 写紧凑 64 列 bf16 NZ 行；
`scan_local_bwd::mask_attn_decay_vf` 也改用 `MaskType.LOWHALF`，堵住老的整寄存器
store 把 128 bf16 lane 写进 64 元素行视图、在最后一次写时溢出 UB 行的隐患。）

---

## 第九章：收尾与打包

最后一步是工程清理：

- 把硬件验证过的 scan-state 替代版提升进官方 `scan_state_bwd` 路径。
- 给所有 wrapper 加 profile passthrough。
- 加 `test_script/run_onboard_profile.sh` 作为直接的 onboard profile 入口。
- 干净硬件跑通后，删掉过时的增量 kernel。
- 重新打包本地计划，剔除 AppleDouble 文件、`__pycache__`、`vendors`、旧 `hw_out`。
- 替换独立上传的计划目录，并在硬件上验证干净上传的树。

上传时冒出一个重要的**部署 bug**：第一版脚本假设 `PLAN_DIR/../../../../` 是仓库
根。这只对老的、checked-in 的计划目录深度成立；浅层独立上传后那个
路径解析成了 `/`。于是 OpExec 在错误的 `vendors` 路径下生成/查找 custom-op 产物，
导致缺 ACLNN 头文件和 `libcust_opapi`。

修法：脚本改为向上走到 `agent/ROUTER.md` 和 `easyasc/a5.py` 来定位仓库根，再
`cd` 到绝对的 profile `OUT_DIR` 后才调用 `module_vs_ref.py`，把生成的 custom-op
包和 `vendors/` 隔离在 run 输出目录下。

---

## 终章：成绩单

当前运行时路径：

```text
scan_split_bwd
  -> scan_local_bwd
  -> scan_state_bwd
wu_bwd
inverse_preprocess_bwd
finalize_bwd
kernel_compose
```

`d_query` 由 scan 阶段直接 forward；`finalize_bwd` 只负责 `d_key`、`d_value`、
`d_beta`、`d_g`。scan-local 到 scan-state 的 score handoff 是 bf16，因为下游只把它
当 cube 操作数。计划消费 forward-saved 的 `v_new_history`、`k_weighted_history`、
`exp_delta_history`。

干净上传后，`(B,H,C)=(1,32,16)`、`profile=True` 的最终 WebIDE onboard profile：

![最终硬件 profile：板上运行时都花在哪](figures/04_hw_profile.svg)

| stage | hardware AVG |
|---|---:|
| `scan_local_bwd` | `88.82us` |
| `scan_state_bwd` | `266.23us` |
| `wu_bwd` | `143.23us` |
| `inverse_preprocess_bwd` | `52.12us` |
| `finalize_bwd` | `138.61us` |

全部 compose 输出 `bad=0`：

| output | max abs |
|---|---:|
| `d_query` | `3.994e-06` |
| `d_key` | `5.007e-06` |
| `d_value` | `4.820e-05` |
| `d_beta` | `2.787e-06` |
| `d_g` | `2.837e-04` |

最终硬件日志未纳入仓库；kernel 发生变化后，必须重新运行上板脚本才能继续引用这些历史数值。

回看整条线：32-core default compose 从最初的 `135013` cycle 起步，尾部打磨到
`126956`，单体 scan 大扫除把 scan 从 `94373` 砍到 `65999`，拆分把 default
`compose_sum` 拉到 `83644`，forward-cache 又在 1-core stress 上把 `compose_sum`
从 `208224` 压到 `195929`——而真正让它能上板的，是硬件 triage 那几轮逐输出重建。

---

## 我们学到的东西

- **模拟器擅长找结构，但只有 WebIDE 硬件能闭环。** 好几个模拟器干净的设计只在
  硬件上挂。
- **硬件失败时，一个单输出 kernel 往往比盲补巨型融合 kernel 快得多。** scan-state、
  inverse、finalize 三处都是靠"一次加一个输出"才走出来的。
- **`DBuff` 不自动等于提速。** 只有当调度真的用那个额外 slot 去重叠 producer/
  consumer beat 时才有用——纯加 slot 反而白花 UB。
- **改生命期就必须上同核 slot 复用压测。** 很多单 BHC smoke 会漏掉 pending GM 源、
  UB 源或 mutex 释放竞态（`max_abs=3.210e-03` 那次就是它救的）。
- **警告不是装饰。** 最有用的修复，常常来自一路追 local-memory 和 `auto_sync`
  警告，直到把那条归属边写显式。
- **控制域很重要。** `GetSubBlockIdx()` 是 vector-side 控制；cube/MTE2 和 L0C 路径
  需要 cube-valid 控制和合法的常量 subblock id。
- **有些数学上干净的重写是更差的调度。** cube-reduce 和 cube reverse-cumsum 实验都
  正确，但多出来的 publish/L1/FIX 流量不值回票价。
- **打包和当前工作目录也是正确性的一部分。** 生成的名字、cwd、`vendors` 放置，
  能让一个好 kernel 在执行之前就失败。
