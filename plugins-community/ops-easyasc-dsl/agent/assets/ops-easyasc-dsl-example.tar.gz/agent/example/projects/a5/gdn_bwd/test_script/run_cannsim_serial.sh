#!/bin/bash
# Run several gdn_bwd kernels through CANNSIM STRICTLY SERIALLY (one at a time).
# CANNSIM can consume several GB per process, so concurrent runs may be killed
# for lack of memory. This loop is inherently serial because each
# run_cannsim_kernel.sh invocation blocks until its CANNSIM run finishes.
#   run_cannsim_serial.sh <C_SIZE> <kernel1> [kernel2 ...]
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CS="$1"; shift
for k in "$@"; do
  echo "########## SERIAL: $k (C=$CS) start $(date +%T) ##########"
  bash "$SCRIPT_DIR/run_cannsim_kernel.sh" "$k" "$CS"
  echo "########## SERIAL: $k done $(date +%T) ##########"
done
echo "########## ALL SERIAL DONE $(date +%T) ##########"
