"""Pure PyTorch reference for final gradient accumulation (ungated)."""

from common import finalize_grads, make_inputs


def subkernel(key, value, beta, d_q, d_k_core, d_v_beta, d_k_beta_wu, d_k_pre, d_k_beta_pre):
    return finalize_grads(key, value, beta, d_q, d_k_core, d_v_beta, d_k_beta_wu, d_k_pre, d_k_beta_pre)


if __name__ == "__main__":
    args = make_inputs()
    scan = __import__("scan_split_bwd_ref").subkernel(args[0], args[1], args[4], args[7], args[8], args[9], args[10])
    wu = __import__("wu_bwd_ref").subkernel(args[1], args[2], args[3], args[5], scan[2], scan[3])
    inv = __import__("inverse_preprocess_bwd_ref").subkernel(args[1], args[3], args[5], wu[0])
    result = subkernel(args[1], args[2], args[3], scan[0], scan[1], wu[1], wu[2], inv[0], inv[1])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
