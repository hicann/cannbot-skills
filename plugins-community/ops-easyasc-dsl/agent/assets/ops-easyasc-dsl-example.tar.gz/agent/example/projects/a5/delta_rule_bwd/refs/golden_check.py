"""Tie the bf16-cube refs to the fp32 golden `delta_rule_bwd_full`.

The refs model the A5 cube precision path (bf16 operands, fp32 accumulate); the
golden is the monolithic fp32 reference.  They agree within the bf16 budget
(2e-3), which validates the whole decomposition against the golden end to end.
"""

import sys
from pathlib import Path

import torch

_ROOT = Path(__file__).resolve().parents[4]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from common import make_inputs, oracle  # noqa: E402
from projects.a5.delta_rule_bwd.delta_rule_bwd_full import delta_rule_bwd_full  # noqa: E402

NAMES = ("d_query", "d_key", "d_value", "d_beta")


def main():
    for seed, shape in ((1, (1, 2, 2)), (5, (2, 1, 3))):
        torch.manual_seed(seed)
        (query, key, value, beta, grad_output, wu_attn_bf16, value_wu,
         k_cumdecay, state_after_history, v_new_history, grad_final_state) = make_inputs(*shape)
        ref = oracle(query, key, value, beta, grad_output, wu_attn_bf16, value_wu,
                     k_cumdecay, state_after_history, v_new_history, grad_final_state)
        gold = delta_rule_bwd_full(query, key, value, beta, grad_output, wu_attn_bf16,
                                   value_wu, k_cumdecay, state_after_history,
                                   grad_final_state=grad_final_state)
        for name, r, g in zip(NAMES, ref, gold):
            diff = (r.float() - g.float()).abs().max().item()
            print(f"  shape={shape} {name}: bf16-refs vs fp32-golden max_abs={diff:.3e}")
            torch.testing.assert_close(r.float(), g.float(), atol=2e-3, rtol=2e-3)
    print("golden_check (bf16 refs vs fp32 golden): OK")


if __name__ == "__main__":
    main()
