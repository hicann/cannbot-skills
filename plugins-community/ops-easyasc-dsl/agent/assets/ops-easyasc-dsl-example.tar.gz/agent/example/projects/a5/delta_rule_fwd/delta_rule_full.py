"""Pure PyTorch oracle for the chunked (ungated) delta-rule forward on a5.

This is the ground-truth reference for `projects/a5/delta_rule_fwd/`.  It is the
FLA `chunk_delta_rule` forward
(https://github.com/fla-org/flash-linear-attention/blob/c525f495/fla/ops/delta_rule/chunk.py),
written in the same chunked `[B, H, C, 64, 128]` layout as
`projects/a5/gdn_fwd/` so the two paths are directly comparable.

Relationship to GDN.  The delta rule is the GDN (gated delta net) forward with
the per-token gate `g` removed.  Starting from
`gdn_fwd/gdn_full.py::gdn_full_original_chunked` and deleting every `g` term
gives exactly this file.  Dropping `g` removes:

  * the cumulative gate `g_cumsum = g.cumsum(-1)` and every `exp(g_cumsum)`
    factor (so `k_cumdecay = (I-A)^-1 @ k_beta`, with no `exp(g_cumsum)` weight,
    and the inter-chunk term is plain `q_i @ S` with no `exp(g_cumsum)` on `q`);
  * the intra-chunk `decay_mask` `exp(g_cumsum_i - g_cumsum_j)` — it degenerates
    to a plain lower-triangular causal keep (`tril(ones)`);
  * the recurrent-state decay `S * exp(g_last)` and the per-key forget weight
    `k * exp(g_last - g_cumsum)` — the update becomes plain `S += k_i^T @ v_new`.

Setting `g == 0` in `gdn_full_original_chunked` reproduces this file bit-for-bit
(same fp32 math, same bf16 boundaries); see `compare_against_gated_zero_g()`.

Precision path (mirrors the GDN "original" reference, minus `g`):
  * q/k/v inputs are bf16; the intra-chunk `q_i @ k_i^T` runs as a bf16 matmul,
    every other matmul and the recurrent state accumulate in fp32;
  * `beta` is applied in fp32; `core_attn_out` accumulates in fp32 and is cast
    back to the input dtype (bf16) on return; the recurrent state stays fp32.
"""

import argparse
import os
import sys
from pathlib import Path
from typing import Optional, Tuple

import torch

_ROOT = Path(__file__).resolve().parents[3]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


L = 64
D = 128
ATOL = 2e-3
RTOL = 2e-3

INPUT_CONTRACT = {
    "query": "torch.bfloat16 [B, H, C, 64, 128]",
    "key": "torch.bfloat16 [B, H, C, 64, 128]",
    "value": "torch.bfloat16 [B, H, C, 64, 128]",
    "beta": "torch.float32 [B, H, C, 64]",
    "scale": "python float; FLA chunk_delta_rule defaults to head_dim**-0.5, "
    "this oracle defaults to 1.0 to match the GDN reference",
    "initial_state": "None or zero torch.bfloat16 [B, H, 128, 128]",
}

INTERMEDIATE_CONTRACT = {
    "preprocess_attn": "torch.float32 [B, H, C, 64, 64], strict-lower A = -(k_beta @ key^T)",
    "wu_attn_fp32": "torch.float32 [B, H, C, 64, 64], (I - A)^-1",
    "value_wu": "torch.float32 [B, H, C, 64, 128], u = (I-A)^-1 @ (value*beta)",
    "k_cumdecay": "torch.float32 [B, H, C, 64, 128], w = (I-A)^-1 @ (key*beta)",
}

# The single difference vs GDN, made explicit: GDN multiplies the intra-chunk
# scores by `decay_mask = exp(g_cumsum_i - g_cumsum_j)` restricted to the lower
# triangle.  With `g == 0` that decay mask is exactly `tril(ones)`, i.e. a plain
# causal keep.  The delta rule has no gate, so it uses that causal keep directly.
PRECISION_BOUNDARIES = (
    "preprocess: key/key cube inputs are bf16; score accumulates in fp32; beta is applied in fp32.",
    "tril_inverse64: strict-lower preprocess_attn stays fp32 through inverse(I - A).",
    "chunk-delta intra: query/key matmul runs in bf16, multiplied by the fp32 causal keep.",
    "chunk-delta recurrence: v_new, per-chunk output, and the recurrent state accumulate in fp32.",
)


def _check_shape(name: str, tensor: torch.Tensor, shape: Tuple[int, ...]) -> None:
    if tuple(tensor.shape) != shape:
        raise ValueError(f"{name} shape must be {shape}, got {tuple(tensor.shape)}")


def _check_dtype(name: str, tensor: torch.Tensor, dtype: torch.dtype) -> None:
    if tensor.dtype != dtype:
        raise TypeError(f"{name} dtype must be {dtype}, got {tensor.dtype}")


def _check_chunked_inputs(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    initial_state: Optional[torch.Tensor],
) -> Tuple[int, int, int]:
    if query.ndim != 5:
        raise ValueError(f"query must be [B,H,C,{L},{D}], got {tuple(query.shape)}")

    B, H, C, length_per_chunk, head_dim = (int(x) for x in query.shape)
    if length_per_chunk != L or head_dim != D:
        raise ValueError(f"this path is specialized for L={L}, D={D}; got L={length_per_chunk}, D={head_dim}")
    if B <= 0 or H <= 0 or C <= 0:
        raise ValueError(f"B/H/C must be positive, got B={B}, H={H}, C={C}")

    qkv_shape = (B, H, C, L, D)
    scalar_shape = (B, H, C, L)
    state_shape = (B, H, D, D)

    for name, tensor in (("query", query), ("key", key), ("value", value)):
        _check_shape(name, tensor, qkv_shape)
        _check_dtype(name, tensor, torch.bfloat16)

    _check_shape("beta", beta, scalar_shape)
    _check_dtype("beta", beta, torch.float32)

    devices = {tensor.device for tensor in (query, key, value, beta)}
    if len(devices) != 1:
        raise ValueError(f"all inputs must be on one device, got {sorted(str(device) for device in devices)}")

    if initial_state is not None:
        _check_shape("initial_state", initial_state, state_shape)
        _check_dtype("initial_state", initial_state, torch.bfloat16)
        if initial_state.device != query.device:
            raise ValueError(f"initial_state device must be {query.device}, got {initial_state.device}")
        if not torch.count_nonzero(initial_state).eq(0).item():
            raise NotImplementedError("delta-rule currently matches the zero-initial-state kernel path only")

    return B, H, C


def delta_rule_full_original_chunked(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    scale: float = 1.0,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    sequence_length: Optional[int] = None,
    return_chunked: bool = True,
    return_intermediates: bool = False,
):
    """Ground-truth chunked delta-rule forward (the GDN reference with `g` removed).

    Inputs are already in kernel layout:
      query/key/value: [B, H, C, 64, 128] bf16
      beta:            [B, H, C, 64] fp32

    Returns:
      core_attn_out: [B, H, C, 64, 128] bf16  (or [B, H, S, 128] if return_chunked=False)
      final_state:   [B, H, 128, 128] fp32, or None
      intermediates: optional dict of the WY-representation tensors
    """
    _check_chunked_inputs(query, key, value, beta, None)
    B, H, C, _, _ = query.shape
    if initial_state is not None:
        _check_shape("initial_state", initial_state, (B, H, D, D))
        if initial_state.device != query.device:
            raise ValueError(f"initial_state device must be {query.device}, got {initial_state.device}")

    initial_dtype = query.dtype
    # FLA scales the queries (default head_dim**-0.5); kept bf16-preserving so a
    # scale of 1.0 is an exact no-op and the GDN(g=0) equivalence holds.
    query = query * scale
    v_beta = value * beta.unsqueeze(-1)
    k_beta = key * beta.unsqueeze(-1)

    # Lower-triangular causal keep (incl. diagonal): GDN's `decay_mask` with g=0.
    causal_keep = torch.tril(torch.ones(L, L, dtype=torch.float32, device=query.device))
    strict_upper = torch.triu(torch.ones(L, L, dtype=torch.bool, device=query.device), diagonal=0)

    # A = -(k_beta @ key^T) on the strict lower triangle.  GDN multiplies by
    # decay_mask here; with g=0 that is the (redundant-with-the-mask) causal keep.
    preprocess_attn = -((k_beta.float() @ key.float().transpose(-1, -2)) * causal_keep).masked_fill(strict_upper, 0)

    # (I - A)^-1 via forward substitution over rows (identical to GDN).
    wu_attn = preprocess_attn.clone()
    for row_idx in range(1, L):
        row = wu_attn[..., row_idx, :row_idx].clone()
        sub = wu_attn[..., :row_idx, :row_idx].clone()
        wu_attn[..., row_idx, :row_idx] = row + (row.unsqueeze(-1) * sub).sum(-2)
    wu_attn = wu_attn + torch.eye(L, dtype=wu_attn.dtype, device=wu_attn.device)

    value_wu = wu_attn @ v_beta.float()      # u = (I-A)^-1 @ (value*beta)
    k_cumdecay = wu_attn @ k_beta.float()    # w = (I-A)^-1 @ (key*beta)   [no exp(g_cumsum) factor]
    last_recurrent_state = (
        torch.zeros(B, H, D, D, dtype=value_wu.dtype, device=value_wu.device)
        if initial_state is None
        else initial_state.to(value_wu)
    )
    core_attn_out = torch.zeros_like(value_wu)

    for chunk_idx in range(C):
        q_i = query[:, :, chunk_idx]
        k_i = key[:, :, chunk_idx]
        v_i = value_wu[:, :, chunk_idx]
        attn = q_i @ k_i.transpose(-1, -2) * causal_keep            # no decay_mask: plain causal keep
        v_prime = k_cumdecay[:, :, chunk_idx] @ last_recurrent_state
        v_new = v_i - v_prime
        attn_inter = q_i.float() @ last_recurrent_state             # no exp(g_cumsum) on q
        core_attn_out[:, :, chunk_idx] = attn_inter + attn @ v_new
        # no state decay (no `* exp(g_last)`) and no per-key forget weight:
        last_recurrent_state = last_recurrent_state + k_i.float().transpose(-1, -2) @ v_new

    if not output_final_state:
        last_recurrent_state = None

    if return_chunked:
        output = core_attn_out.to(initial_dtype)
    else:
        seq_len = C * L if sequence_length is None else sequence_length
        if seq_len < 0 or seq_len > C * L:
            raise ValueError(f"sequence_length must be in [0, {C * L}], got {seq_len}")
        output = core_attn_out.reshape(B, H, C * L, D)
        output = output[:, :, :seq_len]
        output = output.transpose(1, 2).contiguous().to(initial_dtype)

    if not return_intermediates:
        return output, last_recurrent_state

    intermediates = {
        "preprocess_attn": preprocess_attn,
        "wu_attn_fp32": wu_attn,
        "value_wu": value_wu,
        "k_cumdecay": k_cumdecay,
    }
    return output, last_recurrent_state, intermediates


def delta_rule_full_original_sequence(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    scale: float = 1.0,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    sequence_length: Optional[int] = None,
    chunk_size: int = L,
):
    """Sequence-layout entry: reshape `[B,H,S,D]` into chunks, then run the chunked path."""
    if chunk_size != L:
        raise ValueError(f"current path is specialized for chunk_size={L}, got {chunk_size}")
    if query.ndim != 4:
        raise ValueError(f"query must be [B,H,S,D], got {tuple(query.shape)}")
    if tuple(key.shape) != tuple(query.shape) or tuple(value.shape) != tuple(query.shape):
        raise ValueError("query/key/value must have identical [B,H,S,D] shapes")
    B, H, total_sequence_length, head_dim = (int(x) for x in query.shape)
    if head_dim != D:
        raise ValueError(f"this path is specialized for D={D}, got {head_dim}")
    if total_sequence_length % L != 0:
        raise ValueError(f"total_sequence_length must be divisible by {L}, got {total_sequence_length}")
    if tuple(beta.shape) != (B, H, total_sequence_length):
        raise ValueError("beta must be [B,H,S]")

    q_chunks = query.reshape(B, H, -1, L, D)
    k_chunks = key.reshape(B, H, -1, L, D)
    v_chunks = value.reshape(B, H, -1, L, D)
    beta_chunks = beta.reshape(B, H, -1, L)
    return delta_rule_full_original_chunked(
        q_chunks, k_chunks, v_chunks, beta_chunks,
        scale=scale,
        initial_state=initial_state,
        output_final_state=output_final_state,
        sequence_length=total_sequence_length if sequence_length is None else sequence_length,
        return_chunked=False,
    )


# ---------------------------------------------------------------------------
# Kernel-aligned 4-step path (preprocess -> tril_inverse64 -> recompute_wu ->
# chunk_delta), mirroring gdn_full.py::gdn_full_chunked.  The per-step helpers
# match the GDN kernel precision boundaries (minus the gate), so the composed
# path agrees with the fp32 ground truth within the 2e-3 budget.
# ---------------------------------------------------------------------------

def delta_preprocess_ref(key: torch.Tensor, beta: torch.Tensor) -> torch.Tensor:
    """Step 1 (kernel-aligned): GDN `gdn_preprocess_v2` with `g` removed.

    `key @ key^T` runs as a bf16 cube matmul (fp32 accumulate); `beta` is applied
    row-wise in fp32 after the matmul; the result is restricted to the strict
    lower triangle.  Returns the strict-lower A consumed by `tril_inverse64`.
    There is no `g_cumsum` and no `decay_mask` output.
    """
    if key.dtype != torch.bfloat16:
        raise TypeError("key must be torch.bfloat16")
    if beta.dtype != torch.float32:
        raise TypeError("beta must be torch.float32")
    length_per_chunk = key.shape[-2]
    attn_scores = key.float() @ key.float().transpose(-1, -2)  # bf16-origin -> fp32 accum
    strict_lower = torch.tril(
        torch.ones(length_per_chunk, length_per_chunk, dtype=torch.float32, device=key.device),
        diagonal=-1,
    )
    attn_scores = attn_scores * beta.unsqueeze(-1)
    return -(attn_scores * strict_lower)


def delta_recompute_wu_ref(key: torch.Tensor, value: torch.Tensor, beta: torch.Tensor, attn: torch.Tensor):
    """Step 3 (kernel-aligned): GDN `gdn_recompute_wu` with the `exp(g_cumsum)` key weight removed.

    `attn` is the bf16 `(I - A)^-1`.  Returns `value_wu = attn @ (value*beta)` and
    `k_cumdecay = attn @ (key*beta)`, both rounded to bf16 at the GM boundary.
    """
    v_beta = (value.float() * beta.unsqueeze(-1)).to(torch.bfloat16)
    k_beta = (key.float() * beta.unsqueeze(-1)).to(torch.bfloat16)
    value_wu = (attn.float() @ v_beta.float()).bfloat16()
    k_cumdecay = (attn.float() @ k_beta.float()).bfloat16()
    return value_wu, k_cumdecay


def delta_full_chunked(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    scale: float = 1.0,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    return_intermediates: bool = False,
):
    """Run the kernel-aligned 4-step delta path on chunked inputs.

    Reuses GDN's `tril_inverse64` (step 2) verbatim — it inverts a strict-lower
    matrix and is gate-independent.  Steps 1/3/4 use the ungated helpers above
    and `refs/oracle.py::oracle_full`.
    """
    _check_chunked_inputs(query, key, value, beta, initial_state)

    from projects.a5.gdn_fwd.kernels.tril_inverse64 import inverse_from_strict_lower_a
    from projects.a5.delta_rule_fwd.refs.oracle import oracle_full as delta_chunk_ref

    query = query * scale

    # Stage 1: preprocess -> strict-lower A.
    preprocess_attn = delta_preprocess_ref(key, beta)
    # Stage 2: tril_inverse64 -> (I - A)^-1; the chunk-delta boundary is bf16.
    wu_attn_fp32 = inverse_from_strict_lower_a(preprocess_attn)
    wu_attn_bf16 = wu_attn_fp32.to(torch.bfloat16)
    # Stage 3: recompute-WU -> u (value_wu), w (k_cumdecay).
    value_wu, k_cumdecay = delta_recompute_wu_ref(key, value, beta, wu_attn_bf16)
    # Stage 4: chunk-delta recurrence (sub1 -> fused sub2).
    core_attn_out, final_state = delta_chunk_ref(query, key, value_wu, k_cumdecay)
    if not output_final_state:
        final_state = None

    if not return_intermediates:
        return core_attn_out, final_state

    intermediates = {
        "preprocess_attn": preprocess_attn,
        "wu_attn_fp32": wu_attn_fp32,
        "wu_attn_bf16": wu_attn_bf16,
        "value_wu": value_wu,
        "k_cumdecay": k_cumdecay,
    }
    return core_attn_out, final_state, intermediates


def _stage_out_dir(root: str, stage: str) -> str:
    return str(Path(root) / stage) if root else ""


def delta_full_chunked_kernels(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    scale: float = 1.0,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    return_intermediates: bool = False,
    trace=None,
    on_npu: bool = False,
    out_dir: str = "",
    tril_impl: Optional[str] = None,
):
    """Run the same 4-step path through the DSL kernels (simulator or onboard).

    ``tril_impl`` selects the step-2 (I - A)^-1 kernel: ``"block"`` (default, the
    fp32-diagonal forward-substitution kernel) or ``"neumann"`` (the opt-in whole-64
    log-squaring kernel — cube-bound, faster at >=2 chunks/core, bf16 margin). When
    ``None`` it falls back to ``$DELTA_TRIL_IMPL`` then ``"block"``.
    """
    _check_chunked_inputs(query, key, value, beta, initial_state)
    simulator = not on_npu
    profile = bool(on_npu)

    from projects.a5.delta_rule_fwd.kernels.delta_preprocess import run_kernel as run_preprocess_kernel
    from projects.a5.delta_rule_fwd.kernels.delta_recompute_wu import run_kernel as run_recompute_wu_kernel
    from projects.a5.delta_rule_fwd.kernels.chunk_delta_compose import run as run_chunk_delta_kernel

    impl = (tril_impl or os.environ.get("DELTA_TRIL_IMPL", "block")).lower()
    if impl == "neumann":
        from projects.a5.delta_rule_fwd.kernels.tril_inverse64 import (
            inverse_from_strict_lower_a_neumann_bf16_a5 as run_tril_kernel,
        )
    elif impl == "block":
        from projects.a5.delta_rule_fwd.kernels.tril_inverse64 import (
            inverse_from_strict_lower_a_bf16_a5_v2 as run_tril_kernel,
        )
    else:
        raise ValueError(f"unknown tril_impl={impl!r}; expected 'block' or 'neumann'")
    print(f"[delta] tril_inverse64 impl: {impl}")

    query = query * scale

    preprocess_out = run_preprocess_kernel(
        key, beta,
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "preprocess"),
    )
    preprocess_attn = preprocess_out[0] if isinstance(preprocess_out, tuple) else preprocess_out
    wu_attn_bf16 = run_tril_kernel(
        preprocess_attn,
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "tril_inverse64_strict_bf16"),
    )
    value_wu, k_cumdecay = run_recompute_wu_kernel(
        key, value, beta, wu_attn_bf16,
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "recompute_wu"),
    )
    core_attn_out, final_state = run_chunk_delta_kernel(
        query, key, value_wu, k_cumdecay,
        simulator=simulator,
        trace=trace,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "chunk_delta"),
    )
    if not output_final_state:
        final_state = None

    if not return_intermediates:
        return core_attn_out, final_state

    intermediates = {
        "preprocess_attn": preprocess_attn,
        "wu_attn_bf16": wu_attn_bf16,
        "value_wu": value_wu,
        "k_cumdecay": k_cumdecay,
    }
    return core_attn_out, final_state, intermediates


def make_inputs(B: int = 1, H: int = 2, C: int = 2, device: Optional[torch.device] = None):
    device = device or torch.device("cpu")
    query = (torch.randn(B, H, C, L, D, dtype=torch.float32, device=device) * 0.05).to(torch.bfloat16)
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32, device=device) * 0.05).to(torch.bfloat16)
    value = (torch.randn(B, H, C, L, D, dtype=torch.float32, device=device) * 0.05).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32, device=device)
    return query, key, value, beta


def _error_stats(got: torch.Tensor, ref: torch.Tensor):
    got_f = got.float()
    ref_f = ref.float()
    diff = (got_f - ref_f).abs()
    max_abs = float(diff.max())
    max_rel = float((diff / ref_f.abs().clamp_min(1e-12)).max())
    ok = bool(torch.allclose(got_f, ref_f, atol=ATOL, rtol=RTOL))
    return max_abs, max_rel, ok


def _print_error_stats(title: str, pairs) -> None:
    print(title)
    for name, got, ref in pairs:
        max_abs, max_rel, ok = _error_stats(got, ref)
        status = "OK" if ok else "DIFF"
        print(f"  {name}: max_abs={max_abs:.3e} max_rel={max_rel:.3e} tol=({ATOL:.1e},{RTOL:.1e}) {status}")


def compare_against_gated_zero_g(B: int = 1, H: int = 2, C: int = 2, seed: int = 0) -> None:
    """Prove `delta_rule == GDN with g=0`: run both on identical inputs, compare.

    Every pair should report ~0 error.  This is the numerical demonstration that
    the ungated delta rule is exactly the GDN forward with the gate removed.
    """
    torch.manual_seed(seed)
    query, key, value, beta = make_inputs(B=B, H=H, C=C)
    g_zero = torch.zeros(B, H, C, L, dtype=torch.float32, device=query.device)

    delta_core, delta_state, delta_mids = delta_rule_full_original_chunked(
        query, key, value, beta, scale=1.0, return_intermediates=True
    )

    from projects.a5.gdn_fwd.gdn_full import gdn_full_original_chunked

    gdn_core, gdn_state, gdn_mids = gdn_full_original_chunked(
        query, key, value, beta, g_zero, return_intermediates=True
    )

    pairs = [
        ("core_attn_out", delta_core, gdn_core),
        ("final_state", delta_state, gdn_state),
        ("preprocess_attn", delta_mids["preprocess_attn"], gdn_mids["preprocess_attn"]),
        ("wu_attn_fp32", delta_mids["wu_attn_fp32"], gdn_mids["wu_attn_fp32"]),
        ("value_wu (u)", delta_mids["value_wu"], gdn_mids["value_wu"]),
        ("k_cumdecay (w)", delta_mids["k_cumdecay"], gdn_mids["k_cumdecay"]),
    ]
    _print_error_stats("delta-rule oracle vs GDN with g=0 (every pair must be ~0)", pairs)


def compare_original_vs_rewritten(B: int = 1, H: int = 2, C: int = 2, seed: int = 0) -> None:
    """Check the kernel-aligned 4-step path against the fp32 ground truth.

    The bf16 GM boundaries (wu_attn, value_wu, k_cumdecay) and the
    beta-after-matmul ordering make this differ from the monolithic fp32
    reference by at most the 2e-3 budget.
    """
    torch.manual_seed(seed)
    args = make_inputs(B=B, H=H, C=C)
    orig_core, orig_state, orig_mids = delta_rule_full_original_chunked(*args, scale=1.0, return_intermediates=True)
    rew_core, rew_state, rew_mids = delta_full_chunked(*args, scale=1.0, return_intermediates=True)

    pairs = [
        ("core_attn_out", rew_core, orig_core),
        ("final_state", rew_state, orig_state),
        ("preprocess_attn", rew_mids["preprocess_attn"], orig_mids["preprocess_attn"]),
        ("wu_attn_fp32", rew_mids["wu_attn_fp32"], orig_mids["wu_attn_fp32"]),
        ("value_wu (u)", rew_mids["value_wu"], orig_mids["value_wu"]),
        ("k_cumdecay (w)", rew_mids["k_cumdecay"], orig_mids["k_cumdecay"]),
    ]
    _print_error_stats("kernel-aligned 4-step path vs fp32 ground truth", pairs)


def compare_rewritten_vs_kernel_split(
    B: int = 1, H: int = 1, C: int = 2, seed: int = 7, on_npu: bool = False, out_dir: str = "",
    tril_impl: Optional[str] = None,
) -> None:
    """Check the DSL kernel 4-step path against the kernel-aligned PyTorch path."""
    torch.manual_seed(seed)
    args = make_inputs(B=B, H=H, C=C)
    ref_core, ref_state, ref_mids = delta_full_chunked(*args, scale=1.0, return_intermediates=True)
    got_core, got_state, got_mids = delta_full_chunked_kernels(
        *args, scale=1.0, return_intermediates=True, on_npu=on_npu, out_dir=out_dir,
        tril_impl=tril_impl,
    )
    pairs = [
        ("core_attn_out", got_core, ref_core),
        ("final_state", got_state, ref_state),
        ("preprocess_attn", got_mids["preprocess_attn"], ref_mids["preprocess_attn"]),
        ("wu_attn_bf16", got_mids["wu_attn_bf16"], ref_mids["wu_attn_bf16"]),
        ("value_wu", got_mids["value_wu"], ref_mids["value_wu"]),
        ("k_cumdecay", got_mids["k_cumdecay"], ref_mids["k_cumdecay"]),
    ]
    runner = "onboard" if on_npu else "simulator"
    _print_error_stats(f"{runner} kernel split vs kernel-aligned PyTorch path", pairs)


def _summarize(name: str, tensor: torch.Tensor) -> None:
    if tensor is None:
        print(f"{name}: None")
        return
    finite = bool(torch.isfinite(tensor.float()).all())
    print(f"{name}: shape={tuple(tensor.shape)} dtype={tensor.dtype} finite={finite}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-gated", action="store_true", help="verify delta == GDN with g=0")
    parser.add_argument("--check-rewritten", action="store_true", help="verify 4-step path == fp32 ground truth")
    parser.add_argument("--check-kernels", action="store_true", help="verify DSL kernel path == kernel-aligned path")
    parser.add_argument("--on-npu", action="store_true")
    parser.add_argument("--out-dir", default="")
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=2)
    parser.add_argument("--C", type=int, default=2)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument(
        "--tril-impl", choices=["block", "neumann"],
        default=os.environ.get("DELTA_TRIL_IMPL", "block"),
        help="step-2 (I-A)^-1 kernel: 'block' (default, fp32 diagonal) or 'neumann' "
             "(opt-in whole-64 log-squaring, cube-bound, ~1.2-1.3x at >=2 chunks/core). "
             "Default also reads $DELTA_TRIL_IMPL.",
    )
    args_ns = parser.parse_args()

    if args_ns.check_gated:
        compare_against_gated_zero_g(B=args_ns.B, H=args_ns.H, C=args_ns.C, seed=args_ns.seed)
    elif args_ns.check_rewritten:
        compare_original_vs_rewritten(B=args_ns.B, H=args_ns.H, C=args_ns.C, seed=args_ns.seed)
    elif args_ns.check_kernels:
        compare_rewritten_vs_kernel_split(
            B=args_ns.B, H=args_ns.H, C=args_ns.C, seed=args_ns.seed,
            on_npu=args_ns.on_npu, out_dir=args_ns.out_dir, tril_impl=args_ns.tril_impl,
        )
    else:
        torch.manual_seed(args_ns.seed)
        inputs = make_inputs(B=args_ns.B, H=args_ns.H, C=args_ns.C)
        core, state, mids = delta_rule_full_original_chunked(
            *inputs, scale=args_ns.scale, return_intermediates=True
        )
        _summarize("core_attn_out", core)
        _summarize("final_state", state)
        for key, tensor in mids.items():
            _summarize(key, tensor)
        print(f"tolerance_budget: atol={ATOL:.1e} rtol={RTOL:.1e}")
