"""Pure PyTorch reference for the default split scan backward stage (ungated)."""

from common import make_inputs, scan_split_bwd


def subkernel(query, key, grad_output, k_cumdecay, state_after_history, v_new_history, grad_final_state=None):
    return scan_split_bwd(
        query, key, grad_output, k_cumdecay, state_after_history,
        v_new_history, grad_final_state,
    )


if __name__ == "__main__":
    args = make_inputs()
    result = subkernel(args[0], args[1], args[4], args[7], args[8], args[9], args[10])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
