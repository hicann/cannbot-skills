"""Shared pure PyTorch formulas for the simplified KDA backward refs.

This layout mirrors the upstream `disable_recompute=True`, `cp_context=None`
path: backward consumes forward-saved caches directly instead of recomputing
them inside a backward-side "forward_state" kernel.

IO contract: every public tensor is bfloat16 — inputs (`q`, `k`, `v`, `g`,
`beta`, `initial_state`, `do`, `dht`), forward-saved caches (`g_cumsum`,
`Aqk`, `Akk`, `w`, `u`, `qg`, `kg`, `v_new`, `h`), stage handoffs, and
outputs (`dq`, `dk`, `dv`, `dbeta`, `dg`, `dh0`). Internal compute upcasts
to float32 at stage boundaries and downcasts once on store.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn.functional as F


RCP_LN2 = 1.0 / math.log(2.0)
IO_DTYPE = torch.bfloat16
# dk error is bf16-cancellation-bound at ~1.5% of |dk|max and scales linearly
# with input magnitude, so the absolute floor follows scale**3 (~3e-4 at
# scale=0.01, both T=128 and T=1024). atol=rtol=1e-3 gives ~3x margin at the
# default input range (`scale=0.01`, `k_scale=0.05`); do not tighten further
# without lowering the value scales.
ATOL = 1e-3
RTOL = 1e-3
INPUT_SCALE = 0.01
INPUT_K_SCALE = 0.05

REPRESENTATIVE_SHAPE = {
    "B": 1,
    "T": 1024,
    "H": 32,
    "HV": 32,
    "K": 128,
    "V": 128,
    "chunk_size": 64,
}


@dataclass(frozen=True)
class KDAOracleInputs:
    q: torch.Tensor
    k: torch.Tensor
    v: torch.Tensor
    g: torch.Tensor
    beta: torch.Tensor
    initial_state: torch.Tensor
    do: torch.Tensor
    dht: torch.Tensor
    chunk_size: int


@dataclass
class KDAOracleOutputs:
    dq: torch.Tensor
    dk: torch.Tensor
    dv: torch.Tensor
    dbeta: torch.Tensor
    dg: torch.Tensor
    dh0: torch.Tensor


@dataclass
class KDAForwardCaches:
    g_cumsum: torch.Tensor
    Aqk: torch.Tensor
    Akk: torch.Tensor
    w: torch.Tensor
    u: torch.Tensor
    qg: torch.Tensor
    kg: torch.Tensor
    v_new: torch.Tensor
    h: torch.Tensor


@dataclass
class KDAScanBwdMids:
    dAqk: torch.Tensor
    dh: torch.Tensor
    dv: torch.Tensor
    dh0: torch.Tensor


@dataclass
class KDALocalBwdMids:
    dq_hv: torch.Tensor
    dk_hv: torch.Tensor
    dv: torch.Tensor
    dbeta: torch.Tensor
    dg_core: torch.Tensor
    dAkk: torch.Tensor


def _exp2(x: torch.Tensor) -> torch.Tensor:
    return torch.exp2(x) if hasattr(torch, "exp2") else torch.pow(2.0, x)


def _to_io(x: torch.Tensor) -> torch.Tensor:
    return x.to(IO_DTYPE)


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _chunk_bounds(total_length: int, chunk_size: int):
    return [(start, min(total_length, start + chunk_size)) for start in range(0, total_length, chunk_size)]


def _chunk_local_cumsum(x: torch.Tensor, chunk_size: int, reverse: bool = False) -> torch.Tensor:
    out = torch.empty_like(x, dtype=torch.float32)
    for start, end in _chunk_bounds(x.shape[1], chunk_size):
        block = x[:, start:end].float()
        if reverse:
            block = torch.flip(torch.cumsum(torch.flip(block, dims=(1,)), dim=1), dims=(1,))
        else:
            block = torch.cumsum(block, dim=1)
        out[:, start:end] = block
    return out


def _pairwise_decay(g_blk: torch.Tensor) -> torch.Tensor:
    return _exp2(g_blk[:, None, :] - g_blk[None, :, :])


def _validate_contract(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    g: torch.Tensor,
    beta: torch.Tensor,
    initial_state: torch.Tensor,
    chunk_size: int,
    do: Optional[torch.Tensor] = None,
    dht: Optional[torch.Tensor] = None,
) -> Tuple[int, int, int, int, int, int, int, float]:
    _require(q.ndim == 4, "q must have shape [B, T, H, K]")
    _require(k.shape == q.shape, "k must match q shape [B, T, H, K]")
    _require(v.ndim == 4, "v must have shape [B, T, HV, V]")
    _require(g.ndim == 4, "g must have shape [B, T, HV, K]")
    _require(beta.ndim == 3, "beta must have shape [B, T, HV]")
    _require(initial_state.ndim == 4, "initial_state must have shape [B, HV, K, V]")
    _require(chunk_size > 0, "chunk_size must be positive")

    B, T, H, Kdim = q.shape
    Bv, Tv, HV, Vdim = v.shape
    Bg, Tg, HVg, Kg = g.shape
    Bb, Tb, HVb = beta.shape
    Bs, HVs, Ks, Vs = initial_state.shape

    _require((Bv, Tv) == (B, T), "v must match q batch/time dimensions")
    _require((Bg, Tg, Kg) == (B, T, Kdim), "g must match q batch/time/K dimensions")
    _require((Bb, Tb) == (B, T), "beta must match q batch/time dimensions")
    _require(HVg == HV == HVb == HVs, "v, g, beta, initial_state must agree on HV")
    _require((Bs, Ks, Vs) == (B, Kdim, Vdim), "initial_state must have shape [B, HV, K, V]")
    _require(HV % H == 0, "HV must be an integer multiple of H")

    tensors = [q, k, v, g, beta, initial_state]
    if do is not None:
        _require(do.shape == v.shape, "do must match v shape [B, T, HV, V]")
        tensors.append(do)
    if dht is not None:
        _require(dht.shape == initial_state.shape, "dht must match initial_state shape [B, HV, K, V]")
        tensors.append(dht)

    devices = {tensor.device for tensor in tensors}
    _require(len(devices) == 1, "all tensors must be on the same device")
    _require(all(tensor.dtype == IO_DTYPE for tensor in tensors), "all public tensors must be bfloat16")

    group = HV // H
    scale = Kdim ** -0.5
    return B, T, H, HV, Kdim, Vdim, group, scale


def validate_inputs(inputs: KDAOracleInputs) -> Tuple[int, int, int, int, int, int, int, float]:
    return _validate_contract(
        inputs.q,
        inputs.k,
        inputs.v,
        inputs.g,
        inputs.beta,
        inputs.initial_state,
        inputs.chunk_size,
        do=inputs.do,
        dht=inputs.dht,
    )


def forward_reference(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    g: torch.Tensor,
    beta: torch.Tensor,
    initial_state: torch.Tensor,
    chunk_size: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """bf16 inputs -> fp32 outputs (internal building block for the oracle)."""
    _validate_contract(q, k, v, g, beta, initial_state, chunk_size)
    return _forward_reference_f32(
        q.float(),
        k.float(),
        v.float(),
        g.float(),
        beta.float(),
        initial_state.float(),
        chunk_size,
    )


def build_saved_forward(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    g: torch.Tensor,
    beta: torch.Tensor,
    initial_state: torch.Tensor,
    chunk_size: int,
) -> KDAForwardCaches:
    """bf16 inputs -> bf16 saved caches (computed in fp32, downcast on store)."""
    B, T, H, HV, Kdim, Vdim, group, scale = _validate_contract(q, k, v, g, beta, initial_state, chunk_size)
    qf = q.float()
    kf = k.float()
    vf = v.float()
    gf = _chunk_local_cumsum(g.float(), chunk_size) * RCP_LN2
    betaf = beta.float()
    initf = initial_state.float()
    chunk_bounds = _chunk_bounds(T, chunk_size)
    num_chunks = len(chunk_bounds)

    Aqk = torch.zeros(B, T, HV, chunk_size, dtype=IO_DTYPE, device=q.device)
    Akk = torch.zeros(B, T, HV, chunk_size, dtype=IO_DTYPE, device=q.device)
    w = torch.empty(B, T, HV, Kdim, dtype=IO_DTYPE, device=q.device)
    u = torch.empty(B, T, HV, Vdim, dtype=IO_DTYPE, device=q.device)
    qg = torch.empty(B, T, HV, Kdim, dtype=IO_DTYPE, device=q.device)
    kg = torch.empty(B, T, HV, Kdim, dtype=IO_DTYPE, device=q.device)
    v_new = torch.empty(B, T, HV, Vdim, dtype=IO_DTYPE, device=q.device)
    h = torch.empty(B, num_chunks, HV, Kdim, Vdim, dtype=IO_DTYPE, device=q.device)
    states = initf.clone()

    for b in range(B):
        for chunk_idx, (start, end) in enumerate(chunk_bounds):
            valid = end - start
            for hv in range(HV):
                hq = hv // group
                q_blk = qf[b, start:end, hq]
                k_blk = kf[b, start:end, hq]
                v_blk = vf[b, start:end, hv]
                g_blk = gf[b, start:end, hv]
                beta_blk = betaf[b, start:end, hv]

                decay = _pairwise_decay(g_blk)
                score = (q_blk[:, None, :] * k_blk[None, :, :] * decay).sum(dim=-1)
                score = torch.tril(score) * scale
                kk = (k_blk[:, None, :] * k_blk[None, :, :] * decay).sum(dim=-1)
                kk_lower = torch.tril(kk * beta_blk[:, None], diagonal=-1)
                A_blk = torch.linalg.inv(torch.eye(valid, device=q.device, dtype=torch.float32) + kk_lower)

                exp_g = _exp2(g_blk)
                qg_blk = q_blk * exp_g
                w_blk = A_blk @ (k_blk * beta_blk[:, None] * exp_g)
                u_blk = A_blk @ (v_blk * beta_blk[:, None])
                g_last = g_blk[valid - 1]
                kg_blk = k_blk * _exp2(g_last[None, :] - g_blk)

                state = states[b, hv]
                v_new_blk = u_blk - w_blk @ state
                next_state = state * _exp2(g_last)[:, None] + kg_blk.transpose(-1, -2) @ v_new_blk

                Aqk[b, start:end, hv, :valid] = _to_io(score)
                Akk[b, start:end, hv, :valid] = _to_io(A_blk)
                w[b, start:end, hv] = _to_io(w_blk)
                u[b, start:end, hv] = _to_io(u_blk)
                qg[b, start:end, hv] = _to_io(qg_blk)
                kg[b, start:end, hv] = _to_io(kg_blk)
                v_new[b, start:end, hv] = _to_io(v_new_blk)
                h[b, chunk_idx, hv] = _to_io(state)
                states[b, hv] = next_state

    return KDAForwardCaches(
        g_cumsum=_to_io(gf),
        Aqk=Aqk,
        Akk=Akk,
        w=w,
        u=u,
        qg=qg,
        kg=kg,
        v_new=v_new,
        h=h,
    )


def replay_forward(caches: KDAForwardCaches, chunk_size: int) -> Tuple[torch.Tensor, torch.Tensor]:
    """bf16 caches -> fp32 replayed output/final state."""
    B, T, HV, Kdim = caches.g_cumsum.shape
    Vdim = caches.v_new.shape[-1]
    scale = Kdim ** -0.5
    chunk_bounds = _chunk_bounds(T, chunk_size)
    num_chunks = len(chunk_bounds)
    _require(caches.h.shape == (B, num_chunks, HV, Kdim, Vdim), "h shape mismatch")

    outputs = torch.empty(B, T, HV, Vdim, dtype=torch.float32, device=caches.g_cumsum.device)
    final_state = torch.empty(B, HV, Kdim, Vdim, dtype=torch.float32, device=caches.g_cumsum.device)
    for b in range(B):
        for hv in range(HV):
            state = None
            for chunk_idx, (start, end) in enumerate(chunk_bounds):
                valid = end - start
                Aqk_blk = torch.tril(caches.Aqk[b, start:end, hv, :valid].float())
                qg_blk = caches.qg[b, start:end, hv].float()
                kg_blk = caches.kg[b, start:end, hv].float()
                h_blk = caches.h[b, chunk_idx, hv].float()
                v_new_blk = caches.v_new[b, start:end, hv].float()
                outputs[b, start:end, hv] = Aqk_blk @ v_new_blk + scale * (qg_blk @ h_blk)

                g_last = caches.g_cumsum[b, end - 1, hv].float()
                state = h_blk * _exp2(g_last)[:, None] + kg_blk.transpose(-1, -2) @ v_new_blk

            final_state[b, hv] = state

    return outputs, final_state


def oracle(inputs: KDAOracleInputs) -> KDAOracleOutputs:
    """bf16 inputs -> bf16 grads; autograd through the fp32 forward formula."""
    validate_inputs(inputs)

    q = inputs.q.detach().clone().float().requires_grad_(True)
    k = inputs.k.detach().clone().float().requires_grad_(True)
    v = inputs.v.detach().clone().float().requires_grad_(True)
    g = inputs.g.detach().clone().float().requires_grad_(True)
    beta = inputs.beta.detach().clone().float().requires_grad_(True)
    initial_state = inputs.initial_state.detach().clone().float().requires_grad_(True)
    do = inputs.do.detach().clone().float()
    dht = inputs.dht.detach().clone().float()

    output, final_state = _forward_reference_f32(
        q, k, v, g, beta, initial_state, inputs.chunk_size
    )
    loss = (output * do).sum() + (final_state * dht).sum()
    dq, dk, dv, dg, dbeta, dh0 = torch.autograd.grad(loss, (q, k, v, g, beta, initial_state))
    return KDAOracleOutputs(
        dq=_to_io(dq.detach()),
        dk=_to_io(dk.detach()),
        dv=_to_io(dv.detach()),
        dbeta=_to_io(dbeta.detach()),
        dg=_to_io(dg.detach()),
        dh0=_to_io(dh0.detach()),
    )


def _forward_reference_f32(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    g: torch.Tensor,
    beta: torch.Tensor,
    initial_state: torch.Tensor,
    chunk_size: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Differentiable fp32 forward used by the oracle (inputs already fp32)."""
    B, T, H, Kdim = q.shape
    HV = v.shape[2]
    group = HV // H
    scale = Kdim ** -0.5
    gf = _chunk_local_cumsum_diff(g, chunk_size) * RCP_LN2
    chunk_bounds = _chunk_bounds(T, chunk_size)

    batch_outputs = []
    batch_final_states = []
    for b in range(B):
        hv_outputs = []
        hv_states = []
        for hv in range(HV):
            hq = hv // group
            state = initial_state[b, hv]
            chunk_outputs = []
            for start, end in chunk_bounds:
                q_blk = q[b, start:end, hq]
                k_blk = k[b, start:end, hq]
                v_blk = v[b, start:end, hv]
                g_blk = gf[b, start:end, hv]
                beta_blk = beta[b, start:end, hv]

                decay = _pairwise_decay(g_blk)
                score = (q_blk[:, None, :] * k_blk[None, :, :] * decay).sum(dim=-1)
                score = torch.tril(score)
                kk = (k_blk[:, None, :] * k_blk[None, :, :] * decay).sum(dim=-1)
                kk_lower = torch.tril(kk * beta_blk[:, None], diagonal=-1)
                A_blk = torch.linalg.inv(torch.eye(end - start, device=q.device, dtype=torch.float32) + kk_lower)

                exp_g = _exp2(g_blk)
                qg_blk = q_blk * exp_g
                w_blk = A_blk @ (k_blk * beta_blk[:, None] * exp_g)
                u_blk = A_blk @ (v_blk * beta_blk[:, None])
                g_last = g_blk[end - start - 1]
                kg_blk = k_blk * _exp2(g_last[None, :] - g_blk)
                v_new_blk = u_blk - w_blk @ state

                chunk_outputs.append(torch.tril(score * scale) @ v_new_blk + scale * (qg_blk @ state))
                state = state * _exp2(g_last)[:, None] + kg_blk.transpose(-1, -2) @ v_new_blk

            hv_outputs.append(torch.cat(chunk_outputs, dim=0))
            hv_states.append(state)

        batch_outputs.append(torch.stack(hv_outputs, dim=1))
        batch_final_states.append(torch.stack(hv_states, dim=0))

    return torch.stack(batch_outputs, dim=0), torch.stack(batch_final_states, dim=0)


def _chunk_local_cumsum_diff(x: torch.Tensor, chunk_size: int, reverse: bool = False) -> torch.Tensor:
    blocks = []
    for start, end in _chunk_bounds(x.shape[1], chunk_size):
        block = x[:, start:end].float()
        if reverse:
            block = torch.flip(torch.cumsum(torch.flip(block, dims=(1,)), dim=1), dims=(1,))
        else:
            block = torch.cumsum(block, dim=1)
        blocks.append(block)
    return torch.cat(blocks, dim=1)


def scan_bwd(do: torch.Tensor, dht: torch.Tensor, caches: KDAForwardCaches, chunk_size: int) -> KDAScanBwdMids:
    """bf16 inputs/caches -> bf16 mids; the reverse state scan runs in fp32."""
    B, T, HV, Kdim = caches.g_cumsum.shape
    Vdim = caches.v_new.shape[-1]
    _require(do.shape == (B, T, HV, Vdim), "do must match forward output shape [B, T, HV, V]")
    _require(dht.shape == (B, HV, Kdim, Vdim), "dht must have shape [B, HV, K, V]")

    chunk_bounds = _chunk_bounds(T, chunk_size)
    num_chunks = len(chunk_bounds)
    scale = Kdim ** -0.5

    dAqk = torch.zeros(B, T, HV, chunk_size, dtype=IO_DTYPE, device=do.device)
    dv = torch.empty(B, T, HV, Vdim, dtype=torch.float32, device=do.device)
    dof = do.float()

    for b in range(B):
        for start, end in chunk_bounds:
            valid = end - start
            for hv in range(HV):
                do_blk = dof[b, start:end, hv]
                v_new_blk = caches.v_new[b, start:end, hv].float()
                Aqk_blk = torch.tril(caches.Aqk[b, start:end, hv, :valid].float())
                dAqk[b, start:end, hv, :valid] = _to_io(torch.tril(do_blk @ v_new_blk.transpose(-1, -2)) * scale)
                dv[b, start:end, hv] = Aqk_blk.transpose(-1, -2) @ do_blk

    dh = torch.empty(B, num_chunks, HV, Kdim, Vdim, dtype=IO_DTYPE, device=do.device)
    grad_states = dht.float().clone()
    for b in range(B):
        for chunk_idx in range(num_chunks - 1, -1, -1):
            start, end = chunk_bounds[chunk_idx]
            for hv in range(HV):
                grad_state = grad_states[b, hv]
                dh[b, chunk_idx, hv] = _to_io(grad_state)

                kg_blk = caches.kg[b, start:end, hv].float()
                dv_blk = dv[b, start:end, hv] + kg_blk @ grad_state
                dv[b, start:end, hv] = dv_blk

                qg_blk = caches.qg[b, start:end, hv].float()
                w_blk = caches.w[b, start:end, hv].float()
                do_blk = dof[b, start:end, hv]
                g_last = caches.g_cumsum[b, end - 1, hv].float()
                grad_states[b, hv] = (
                    grad_state * _exp2(g_last)[:, None]
                    + qg_blk.transpose(-1, -2) @ do_blk * scale
                    - w_blk.transpose(-1, -2) @ dv_blk
                )

    return KDAScanBwdMids(dAqk=dAqk, dh=dh, dv=_to_io(dv), dh0=_to_io(grad_states))


def inverse_bwd(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    beta: torch.Tensor,
    do: torch.Tensor,
    caches: KDAForwardCaches,
    scan: KDAScanBwdMids,
    chunk_size: int,
) -> KDALocalBwdMids:
    """bf16 inputs/caches/mids -> bf16 mids; per-chunk math in fp32."""
    B, T, H, Kdim = q.shape
    HV = v.shape[2]
    Vdim = v.shape[-1]
    group = HV // H
    scale = Kdim ** -0.5
    qf = q.float()
    kf = k.float()
    vf = v.float()
    betaf = beta.float()
    dof = do.float()
    chunk_bounds = _chunk_bounds(T, chunk_size)

    dq_hv = torch.empty(B, T, HV, Kdim, dtype=IO_DTYPE, device=q.device)
    dk_hv = torch.empty(B, T, HV, Kdim, dtype=IO_DTYPE, device=q.device)
    dv_out = torch.empty(B, T, HV, Vdim, dtype=IO_DTYPE, device=q.device)
    dbeta = torch.empty(B, T, HV, dtype=IO_DTYPE, device=q.device)
    dg_core = torch.empty(B, T, HV, Kdim, dtype=IO_DTYPE, device=q.device)
    dAkk = torch.zeros(B, T, HV, chunk_size, dtype=IO_DTYPE, device=q.device)

    for b in range(B):
        for chunk_idx, (start, end) in enumerate(chunk_bounds):
            valid = end - start
            for hv in range(HV):
                hq = hv // group
                q_blk = qf[b, start:end, hq]
                k_blk = kf[b, start:end, hq]
                v_blk = vf[b, start:end, hv]
                v_new_blk = caches.v_new[b, start:end, hv].float()
                g_blk = caches.g_cumsum[b, start:end, hv].float()
                beta_blk = betaf[b, start:end, hv]
                Akk_blk = caches.Akk[b, start:end, hv, :valid].float()
                h_blk = caches.h[b, chunk_idx, hv].float()
                dh_blk = scan.dh[b, chunk_idx, hv].float()
                do_blk = dof[b, start:end, hv]
                dv_blk = scan.dv[b, start:end, hv].float()

                exp_g = _exp2(g_blk)
                g_last = g_blk[valid - 1]
                exp_last_minus_g = _exp2(g_last[None, :] - g_blk)

                d_qg = do_blk @ h_blk.transpose(-1, -2)
                dq_blk = d_qg * exp_g * scale

                d_kg = v_new_blk @ dh_blk.transpose(-1, -2)
                dk_from_kg = d_kg * exp_last_minus_g

                d_g_last = (h_blk * dh_blk).sum(dim=1) * _exp2(g_last)
                d_g_last = d_g_last + (k_blk * dk_from_kg).sum(dim=0)

                d_w = -(dv_blk @ h_blk.transpose(-1, -2))
                k_exp = k_blk * exp_g
                dA_inv = dv_blk @ v_blk.transpose(-1, -2) + d_w @ k_exp.transpose(-1, -2)

                d_v_beta = Akk_blk.transpose(-1, -2) @ dv_blk
                dv_out[b, start:end, hv] = _to_io(d_v_beta * beta_blk[:, None])
                dbeta_blk = (d_v_beta * v_blk).sum(dim=1)

                d_k_beta_g = Akk_blk.transpose(-1, -2) @ d_w
                dk_from_w = d_k_beta_g * beta_blk[:, None] * exp_g
                dbeta_blk = dbeta_blk + (d_k_beta_g * k_exp).sum(dim=1)
                dg_from_w = d_k_beta_g * k_exp * beta_blk[:, None]

                dg_blk = q_blk * dq_blk - k_blk * dk_from_kg + dg_from_w
                dg_blk[valid - 1] = dg_blk[valid - 1] + d_g_last

                dq_hv[b, start:end, hv] = _to_io(dq_blk)
                dk_hv[b, start:end, hv] = _to_io(dk_from_kg + dk_from_w)
                dbeta[b, start:end, hv] = _to_io(dbeta_blk)
                dg_core[b, start:end, hv] = _to_io(dg_blk)

                D_tri = torch.tril(dA_inv * beta_blk[None, :], diagonal=-1)
                dL = -(Akk_blk.transpose(-1, -2) @ D_tri @ Akk_blk.transpose(-1, -2))
                dAkk[b, start:end, hv, :valid] = _to_io(torch.tril(dL, diagonal=-1))

    return KDALocalBwdMids(
        dq_hv=dq_hv,
        dk_hv=dk_hv,
        dv=dv_out,
        dbeta=dbeta,
        dg_core=dg_core,
        dAkk=dAkk,
    )


def finalize_bwd(
    q: torch.Tensor,
    k: torch.Tensor,
    beta: torch.Tensor,
    g_cumsum: torch.Tensor,
    dAqk: torch.Tensor,
    local: KDALocalBwdMids,
    dh0: torch.Tensor,
    chunk_size: int,
) -> KDAOracleOutputs:
    """bf16 inputs/mids -> bf16 public outputs; accumulation in fp32."""
    B, T, H, Kdim = q.shape
    HV = g_cumsum.shape[2]
    group = HV // H
    qf = q.float()
    kf = k.float()
    betaf = beta.float()
    g_cumsumf = g_cumsum.float()
    dAqkf = dAqk.float()
    dAkkf = local.dAkk.float()

    dq_hv = local.dq_hv.float()
    dk_hv = local.dk_hv.float()
    dbeta = local.dbeta.float()
    dg = local.dg_core.float()

    for b in range(B):
        for start, end in _chunk_bounds(T, chunk_size):
            valid = end - start
            for hv in range(HV):
                hq = hv // group
                q_blk = qf[b, start:end, hq]
                k_blk = kf[b, start:end, hq]
                g_blk = g_cumsumf[b, start:end, hv]
                beta_blk = betaf[b, start:end, hv]

                for row in range(valid):
                    for col in range(row + 1):
                        decay = _exp2(g_blk[row] - g_blk[col])

                        coeff_qk = dAqkf[b, start + row, hv, col]
                        pair_qk = coeff_qk * q_blk[row] * k_blk[col] * decay
                        dq_hv[b, start + row, hv] = dq_hv[b, start + row, hv] + coeff_qk * k_blk[col] * decay
                        dk_hv[b, start + col, hv] = dk_hv[b, start + col, hv] + coeff_qk * q_blk[row] * decay
                        dg[b, start + row, hv] = dg[b, start + row, hv] + pair_qk
                        dg[b, start + col, hv] = dg[b, start + col, hv] - pair_qk

                        if col < row:
                            coeff_kk = dAkkf[b, start + row, hv, col]
                            pair_kk = coeff_kk * beta_blk[row] * k_blk[row] * k_blk[col] * decay
                            dk_hv[b, start + row, hv] = (
                                dk_hv[b, start + row, hv] + coeff_kk * beta_blk[row] * k_blk[col] * decay
                            )
                            dk_hv[b, start + col, hv] = (
                                dk_hv[b, start + col, hv] + coeff_kk * beta_blk[row] * k_blk[row] * decay
                            )
                            dbeta[b, start + row, hv] = (
                                dbeta[b, start + row, hv] + coeff_kk * (k_blk[row] * k_blk[col] * decay).sum()
                            )
                            dg[b, start + row, hv] = dg[b, start + row, hv] + pair_kk
                            dg[b, start + col, hv] = dg[b, start + col, hv] - pair_kk

    dq = dq_hv.reshape(B, T, H, group, Kdim).sum(dim=3)
    dk = dk_hv.reshape(B, T, H, group, Kdim).sum(dim=3)
    dg = _chunk_local_cumsum(dg, chunk_size, reverse=True)
    return KDAOracleOutputs(
        dq=_to_io(dq),
        dk=_to_io(dk),
        dv=local.dv,
        dbeta=_to_io(dbeta),
        dg=_to_io(dg),
        dh0=dh0,
    )


def composed(inputs: KDAOracleInputs) -> KDAOracleOutputs:
    validate_inputs(inputs)
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    scan = scan_bwd(inputs.do, inputs.dht, caches, inputs.chunk_size)
    local = inverse_bwd(inputs.q, inputs.k, inputs.v, inputs.beta, inputs.do, caches, scan, inputs.chunk_size)
    return finalize_bwd(inputs.q, inputs.k, inputs.beta, caches.g_cumsum, scan.dAqk, local, scan.dh0, inputs.chunk_size)


def saved_forward_as_tuple(caches: KDAForwardCaches) -> Tuple[torch.Tensor, ...]:
    return (
        caches.g_cumsum,
        caches.Aqk,
        caches.Akk,
        caches.w,
        caches.u,
        caches.qg,
        caches.kg,
        caches.v_new,
        caches.h,
    )


def saved_forward_from_tuple(values: Tuple[torch.Tensor, ...]) -> KDAForwardCaches:
    return KDAForwardCaches(*values)


def scan_mids_as_tuple(mids: KDAScanBwdMids) -> Tuple[torch.Tensor, ...]:
    return mids.dAqk, mids.dh, mids.dv, mids.dh0


def scan_mids_from_tuple(values: Tuple[torch.Tensor, ...]) -> KDAScanBwdMids:
    return KDAScanBwdMids(*values)


def local_mids_as_tuple(mids: KDALocalBwdMids) -> Tuple[torch.Tensor, ...]:
    return mids.dq_hv, mids.dk_hv, mids.dv, mids.dbeta, mids.dg_core, mids.dAkk


def local_mids_from_tuple(values: Tuple[torch.Tensor, ...]) -> KDALocalBwdMids:
    return KDALocalBwdMids(*values)


def outputs_as_tuple(outputs: KDAOracleOutputs) -> Tuple[torch.Tensor, ...]:
    return outputs.dq, outputs.dk, outputs.dv, outputs.dbeta, outputs.dg, outputs.dh0


def outputs_from_tuple(values: Tuple[torch.Tensor, ...]) -> KDAOracleOutputs:
    return KDAOracleOutputs(*values)


def _check_close(name: str, actual: torch.Tensor, expected: torch.Tensor, atol: float, rtol: float) -> None:
    if actual.shape != expected.shape:
        raise RuntimeError("%s: shape mismatch %s != %s" % (name, tuple(actual.shape), tuple(expected.shape)))
    af = actual.float()
    ef = expected.float()
    if not torch.allclose(af, ef, atol=atol, rtol=rtol):
        diff = (af - ef).abs()
        rel = diff / ef.abs().clamp_min(1e-12)
        raise RuntimeError(
            "%s: max_abs=%.3e max_rel=%.3e exceeds atol=%.3e rtol=%.3e"
            % (name, float(diff.max()), float(rel.max()), atol, rtol)
        )


def compare_outputs(actual: KDAOracleOutputs, expected: KDAOracleOutputs, atol: float = ATOL, rtol: float = RTOL) -> None:
    for name, got, ref in zip(
        ("dq", "dk", "dv", "dbeta", "dg", "dh0"),
        outputs_as_tuple(actual),
        outputs_as_tuple(expected),
    ):
        _check_close(name, got, ref, atol, rtol)


def make_inputs(
    B: int = 1,
    H: int = 32,
    HV: int = 32,
    T: Optional[int] = None,
    C: Optional[int] = None,
    K: int = 128,
    V: int = 128,
    chunk_size: int = 64,
    seed: int = 0,
    device: str = "cpu",
    dtype: torch.dtype = IO_DTYPE,
    scale: float = INPUT_SCALE,
    k_scale: float = INPUT_K_SCALE,
) -> KDAOracleInputs:
    if T is None and C is None:
        C = 16
    if T is None:
        _require(C is not None, "either T or C must be provided")
        T = C * chunk_size
    elif C is not None:
        _require(C * chunk_size == T, "when both T and C are provided, they must satisfy T == C * chunk_size")

    gen = torch.Generator(device="cpu").manual_seed(seed)

    def randn(*shape: int) -> torch.Tensor:
        return torch.randn(*shape, generator=gen, device=device, dtype=torch.float32)

    q = (randn(B, T, H, K) * scale).to(dtype)
    k = (randn(B, T, H, K) * k_scale).to(dtype)
    v = (randn(B, T, HV, V) * scale).to(dtype)
    g = (-F.softplus(randn(B, T, HV, K))).to(dtype)
    beta = torch.sigmoid(randn(B, T, HV)).to(dtype)
    initial_state = (randn(B, HV, K, V) * scale).to(dtype)
    do = (randn(B, T, HV, V) * scale).to(dtype)
    dht = (randn(B, HV, K, V) * scale).to(dtype)
    return KDAOracleInputs(
        q=q,
        k=k,
        v=v,
        g=g,
        beta=beta,
        initial_state=initial_state,
        do=do,
        dht=dht,
        chunk_size=chunk_size,
    )


def make_representative_inputs(
    seed: int = 0,
    device: str = "cpu",
    dtype: torch.dtype = IO_DTYPE,
    scale: float = INPUT_SCALE,
    k_scale: float = INPUT_K_SCALE,
) -> KDAOracleInputs:
    return make_inputs(
        B=REPRESENTATIVE_SHAPE["B"],
        H=REPRESENTATIVE_SHAPE["H"],
        HV=REPRESENTATIVE_SHAPE["HV"],
        T=REPRESENTATIVE_SHAPE["T"],
        K=REPRESENTATIVE_SHAPE["K"],
        V=REPRESENTATIVE_SHAPE["V"],
        chunk_size=REPRESENTATIVE_SHAPE["chunk_size"],
        seed=seed,
        device=device,
        dtype=dtype,
        scale=scale,
        k_scale=k_scale,
    )
