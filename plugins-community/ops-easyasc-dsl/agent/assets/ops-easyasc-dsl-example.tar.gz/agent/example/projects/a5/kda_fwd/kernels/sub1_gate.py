"""KDA forward sub1: materialize chunk-local cumulative gates.

A5 implementation specialized to L=64, K=128 with dynamic B, HV, and C. The
subkernel consumes fp32 raw gate increments `g_raw[B,HV,C,L,K]` and writes
`eg = exp(cumsum(g_raw, dim=L))` in fp32. Downstream subkernels consume this
materialized linear gate factor directly; the raw gate increments are not part
of their public contracts.
"""

import argparse
import os
from pathlib import Path
import sys

import torch

_REPO_ROOT = Path(__file__).resolve().parents[4]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from easyasc.a5 import *  # noqa: F401,F403
from easyasc.simulator import SimulatorConfig


L = 64
K_DIM = 128
K_BLOCK = 64
K_TILES = K_DIM // K_BLOCK
DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 300.0

SHAPE_BINDINGS = {
    0: [0, 1, 2, 3, 4],  # g_raw[B,HV,C,L,K]
    1: [0, 1, 2, 3, 4],  # eg[B,HV,C,L,K]
}


@vf()
def gate_cumsum_vf(src_ub: Tensor, dst_ub: Tensor):
    prev = Reg(DT.float)
    curr = Reg(DT.float)
    prev_exp = Reg(DT.float)

    for tile in range(K_TILES):
        k_begin = tile * K_BLOCK
        k_end = k_begin + K_BLOCK
        prev <<= src_ub[0:1, k_begin:k_end]
        prev_exp <<= prev.exp()
        dst_ub[0:1, k_begin:k_end] <<= prev_exp

        for r in range(1, L):
            curr <<= src_ub[r:r + 1, k_begin:k_end]
            prev <<= prev + curr
            prev_exp <<= prev.exp()
            dst_ub[r:r + 1, k_begin:k_end] <<= prev_exp


@kernel()
def kda_sub1_gate_kernel(
    g_raw: GMTensor,
    eg: GMTensor,
    B: Var,
    HV: Var,
    C: Var,
    length_per_chunk: Var,
    head_dim: Var,
):
    src_ub = DBuff(DT.float, [L, K_DIM], Position.UB)
    dst_ub = DBuff(DT.float, [L, K_DIM], Position.UB)

    work_count = B * HV * C
    work_per_vec = CeilDiv(work_count, GetVecNum())
    work_begin = Var(work_per_vec * GetVecIdx())
    work_end = Min(work_begin + work_per_vec, work_count)

    with auto_sync():
        for work in range(work_begin, work_end):
            c_idx = Var(work % C)
            tmp = Var(work // C)
            hv_idx = Var(tmp % HV)
            b_idx = Var(tmp // HV)

            src_ub[work][0:L, 0:K_DIM] <<= g_raw[b_idx, hv_idx, c_idx, 0:L, 0:K_DIM]
            gate_cumsum_vf(src_ub[work], dst_ub[work])
            eg[b_idx, hv_idx, c_idx, 0:L, 0:K_DIM] <<= dst_ub[work][0:L, 0:K_DIM]

    return eg


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_fwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def _check_contract(g_raw):
    B, HV, C, length_per_chunk, head_dim = g_raw.shape
    if B <= 0 or HV <= 0 or C <= 0:
        raise ValueError(f"B/HV/C must be positive, got B={B}, HV={HV}, C={C}")
    if length_per_chunk != L or head_dim != K_DIM:
        raise ValueError(f"sub1_gate is specialized for L={L}, K={K_DIM}, got L={length_per_chunk}, K={head_dim}")
    if g_raw.dtype != torch.float32:
        raise TypeError("g_raw must be torch.float32")
    return B, HV, C, length_per_chunk, head_dim


def run(g_raw, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False, core_count=None):
    B, HV, C, length_per_chunk, head_dim = _check_contract(g_raw)
    eg = torch.empty_like(g_raw)
    trace_path = _trace_path(trace, out_dir, "sub1_gate")

    previous_config = getattr(kda_sub1_gate_kernel, "_simulator_config", None)
    if simulator:
        kda_sub1_gate_kernel._simulator_config = SimulatorConfig(
            core_count=core_count or DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            kda_sub1_gate_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(g_raw, eg, B, HV, C, length_per_chunk, head_dim, shape_bindings=SHAPE_BINDINGS)
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(kda_sub1_gate_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                kda_sub1_gate_kernel._simulator_config = previous_config
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run KDA forward sub1_gate smoke or hardware profile case.")
    parser.add_argument("--hardware-profile", action="store_true", help="Run the real-hardware profile case: simulator=False, profile=True, B=1, H=HV=32, C=16.")
    parser.add_argument("--out-dir", default="", help="Output directory for generated hardware artifacts.")
    parser.add_argument("--skip-compile", action="store_true", help="Reuse previously compiled artifacts for the hardware profile run.")
    parser.add_argument("--gen-only", action="store_true", help="Generate hardware artifacts without running them.")
    parser.add_argument("--seed", type=int, default=11, help="Random seed for generated inputs.")
    parser.add_argument("--core-count", type=int, default=DEFAULT_CORE_COUNT, help="Simulator core count for non-hardware runs.")
    parser.add_argument("--trace", default=None, help="Path to write a simulator trace for non-hardware runs.")
    args = parser.parse_args()

    refs_dir = Path(__file__).resolve().parents[1] / "refs"
    if str(refs_dir) not in sys.path:
        sys.path.insert(0, str(refs_dir))
    from oracle import sample_inputs as oracle_sample_inputs, to_chunked_inputs
    from sub1_gate_ref import subkernel as ref_sub1_gate

    if args.hardware_profile:
        q, k, v, g_raw_full, beta, _initial_state = oracle_sample_inputs(
            B=1, H=32, HV=32, C=16, L=L, K=K_DIM, V=K_DIM, seed=args.seed
        )
        _q_c, _k_c, _v_c, g_raw, _beta_c = to_chunked_inputs(q, k, v, g_raw_full, beta, chunk_size=L)
        out_dir = args.out_dir or "./tmp/kda_sub1_gate_hardware_profile"
        result = run(
            g_raw,
            simulator=False,
            profile=True,
            gen_only=args.gen_only,
            out_dir=out_dir,
            skip_compile=args.skip_compile,
        )
        if args.gen_only:
            print(f"g: shape={tuple(result.shape)} dtype={result.dtype}")
            print("pytorch verification skipped for --gen-only because no hardware output was produced")
        else:
            ref = ref_sub1_gate(g_raw)
            torch.testing.assert_close(result, ref, rtol=1e-6, atol=1e-6)
            max_abs = float((result - ref).abs().max())
            print(f"eg: shape={tuple(result.shape)} dtype={result.dtype} max_abs={max_abs:.6e} OK")
        print(f"hardware profile case complete: B=1 H=32 HV=32 C=16 out_dir={out_dir}")
        raise SystemExit(0)

    q, k, v, g_raw_full, beta, _initial_state = oracle_sample_inputs(
        B=1, H=8, HV=8, C=8, L=L, K=K_DIM, V=K_DIM, seed=args.seed
    )
    _q_c, _k_c, _v_c, g_raw, _beta_c = to_chunked_inputs(q, k, v, g_raw_full, beta, chunk_size=L)
    result = run(g_raw, trace=args.trace, core_count=args.core_count)
    ref = ref_sub1_gate(g_raw)
    torch.testing.assert_close(result, ref, rtol=1e-6, atol=1e-6)
    print(tuple(result.shape), result.dtype, f"max_abs={float((result - ref).abs().max()):.6e}")
