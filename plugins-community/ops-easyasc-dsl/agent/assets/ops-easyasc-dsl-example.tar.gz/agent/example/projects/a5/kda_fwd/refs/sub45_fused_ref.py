"""Sub-kernel reference: sub45_fused - fused state bridge plus output.

I/O contract
------------
Inputs:
  - q:             torch.bfloat16/float16 [B, H,  C, L, K]
  - Aqk:           q.dtype                [B, HV, C, L, L]
  - kg:            q.dtype                [B, HV, C, L, K]
  - w:             q.dtype                [B, HV, C, L, K]
  - u:             torch.bfloat16/float16 [B, HV, C, L, V]
  - g:             torch.float32          [B, HV, C, L, K] cumulative gates in linear space
  - initial_state: torch.float32          [B, HV, K, V] or None
  - scale:         Python float or scalar

Outputs:
  - o:             u.dtype       [B, HV, C, L, V]
  - final_state:   torch.float32 [B, HV, K, V]

This is the implementation-facing fused contract for the production A5 kernel.
It folds the recurrent state bridge (formerly sub4) and the GLA-style output
assembly (formerly sub5) into one reference: the chunk state `h` and the
delta-corrected values `v_new` stay internal to this function, matching the
fused A5 kernel which only exposes the public outputs `o` and `final_state`.

Primitives used: [A3, P1, P5, P6, P7]
"""

import torch


def _expand_qk_to_value_heads(x, hv):
    h = x.shape[1]
    group = hv // h
    return x.repeat_interleave(group, dim=1)


def subkernel(q, Aqk, kg, w, u, g, initial_state, scale):
    B, HV, C, L, K = kg.shape
    V = u.shape[-1]

    # --- Recurrent state bridge (internal h / v_new) ---
    state = torch.zeros(B, HV, K, V, dtype=torch.float32, device=kg.device)
    if initial_state is not None:
        state = state + initial_state.float()

    h = torch.empty(B, HV, C, K, V, dtype=kg.dtype, device=kg.device)
    v_new = torch.empty_like(u)
    for c in range(C):
        h[:, :, c] = state.to(kg.dtype)
        v_delta = u[:, :, c].float() - torch.matmul(w[:, :, c].float(), state)
        v_new[:, :, c] = v_delta.to(u.dtype)

        g_last = g[:, :, c, -1, :].float()
        state = state * g_last[..., None]
        state = state + torch.matmul(kg[:, :, c].float().transpose(-1, -2), v_new[:, :, c].float())

    final_state = state

    # --- GLA-style output assembly ---
    q_hv = _expand_qk_to_value_heads(q.float(), HV)
    state_part = torch.matmul(q_hv * g.float(), h.float()) * scale

    row = torch.arange(L, device=q.device)[:, None]
    col = torch.arange(L, device=q.device)[None, :]
    lower_inclusive = row >= col
    A = torch.where(lower_inclusive, Aqk.float(), torch.zeros_like(Aqk.float()))
    local_part = torch.matmul(A, v_new.float())
    o = (state_part + local_part).to(u.dtype)

    return o, final_state


if __name__ == "__main__":
    from oracle import sample_inputs, to_chunked_inputs
    from sub1_gate_ref import subkernel as gate_cumsum
    from sub2_intra_ref import subkernel as intra
    from sub3_wy_ref import subkernel as wy

    q, k, v, g_raw, beta, initial_state = sample_inputs(B=1, H=1, HV=1, C=1, L=32, K=32, V=32, seed=42)
    q_c, k_c, v_c, g_raw_c, beta_c = to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=32)
    g_c = gate_cumsum(g_raw_c)
    Aqk, Akk = intra(q_c, k_c, g_c, beta_c, scale=32 ** -0.5)
    w, u, _qg, kg = wy(q_c, k_c, v_c, beta_c, Akk, g_c)
    result = subkernel(q_c, Aqk, kg, w, u, g_c, initial_state, scale=32 ** -0.5)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
