"""delta preprocess (ungated): strict-lower A = -(key @ key^T) * beta.

Ungated delta-rule port of `gdn_fwd/kernels/gdn_preprocess.py`.  Removed vs GDN:
  * the `g @ triu` cumulative-sum matmul (no `g`/`triu` inputs, no `g_cumsum`);
  * the `decay_mask = exp(g_cumsum_i - g_cumsum_j)` path (no `decay_mask` output).

`key @ key^T` runs as a bf16 cube matmul (fp32 accumulate); beta is applied
row-wise in fp32; the result is restricted to the strict lower triangle (excl.
diagonal) — the strict-lower A consumed by `tril_inverse64`.
"""
import builtins

import torch


from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig


L = 64
D = 128
HALF_L = L // 2
SIM_CORE_COUNT = 32

SHAPE_BINDINGS = {
    0: [0, 1, 2, 3, 4],  # key[B,H,C,L,D]
    1: [0, 1, 2, 3],     # beta[B,H,C,L]
    2: [0, 1, 2, 3, 3],  # attn[B,H,C,L,L], fp32
}


def _bf16_cube_matmul_fp32_acc(left, right):
    if left.dtype != torch.bfloat16 or right.dtype != torch.bfloat16:
        raise TypeError("bf16 cube matmul reference expects bfloat16 inputs")
    return left.float() @ right.float().transpose(-1, -2)


def delta_preprocess(key, beta):
    """Reference delta preprocess (GDN gdn_preprocess_v2 with `g` removed)."""
    B, H, C, length_per_chunk, head_dim = key.shape
    scalar_shape = (B, H, C, length_per_chunk)
    if beta.shape != scalar_shape:
        raise ValueError(f"beta shape must be {scalar_shape}, got {tuple(beta.shape)}")
    if key.dtype != torch.bfloat16:
        raise TypeError("key must be torch.bfloat16")
    if beta.dtype != torch.float32:
        raise TypeError("beta must be torch.float32")

    attn_scores = _bf16_cube_matmul_fp32_acc(key, key)
    strict_lower = torch.tril(torch.ones(length_per_chunk, length_per_chunk, dtype=torch.float32, device=key.device), diagonal=-1)
    attn_scores = attn_scores * beta.unsqueeze(-1)
    attn = -(attn_scores * strict_lower)
    return attn


@vf()
def init_strict_lower_vf(strict_lower_ub: Tensor, row_begin: Var, rows: Var):
    cols = Reg(DT.int)
    zero = Reg(DT.float)
    strict_row = Reg(DT.float)
    strict_lower_mask = MaskReg(DT.int, init_mode=MaskType.NONE)

    zero <<= 0.0
    cols.arange(0)

    for r in range(rows):
        abs_r = Var(row_begin + r)
        strict_row <<= 1.0
        compare(strict_lower_mask, cols, abs_r, CompareMode.LT)  # cols < abs_r (strict lower)
        select(strict_row, strict_row, zero, mask=strict_lower_mask)
        strict_lower_ub[r:r + 1, 0:L] <<= strict_row


@vf()
def apply_beta_and_mask_vf(
    score_ub: Tensor,
    beta_ub: Tensor,
    strict_lower_mask_ub: Tensor,
    attn_ub: Tensor,
    row_begin: Var,
    rows: Var,
):
    beta_reg = Reg(DT.float)
    score_row = Reg(DT.float)
    attn_row = Reg(DT.float)
    mask_row = Reg(DT.float)

    for r in range(rows):
        beta_reg <<= beta_ub[0:1, r:r + 1].single()
        score_row <<= score_ub[r:r + 1, 0:L]
        score_row <<= score_row * beta_reg
        attn_row <<= score_row * -1.0
        mask_row <<= strict_lower_mask_ub[r:r + 1, 0:L]
        attn_row <<= attn_row * mask_row
        attn_ub[r:r + 1, 0:L] <<= attn_row


@kernel()
def delta_preprocess_kernel(
    key: GMTensor,
    beta: GMTensor,
    attn: GMTensor,
    B: Var,
    H: Var,
    C: Var,
    length_per_chunk: Var,
    head_dim: Var,
):
    cvmutex = CvMutex(1, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1_key = DBuff(DT.bfloat16, [L, D], Position.L1)
    l0c_score = DBuff(DT.float, [L, L], Position.L0C)

    beta_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    score_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    strict_lower_mask_ub = Tensor(DT.float, [HALF_L, L], Position.UB)
    attn_ub = DBuff(DT.float, [HALF_L, L], Position.UB)

    stage1_cnt = Var(0)
    stage2_cnt = Var(0)
    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    with auto_sync():
        if bhc_begin < bhc_end:
            mask_row_begin = Var(GetSubBlockIdx() * HALF_L)
            mask_row_end = Min(mask_row_begin + HALF_L, L)
            init_strict_lower_vf(strict_lower_mask_ub, mask_row_begin, mask_row_end - mask_row_begin)

        for bhc in range(bhc_begin, bhc_end + 1):
            if bhc < bhc_end:
                c_idx = Var(bhc // (B * H))
                bh_remainder = Var(bhc % (B * H))
                b_idx = Var(bh_remainder // H)
                h_idx = Var(bh_remainder % H)

                l1_key[stage1_cnt][0:L, 0:D] <<= key[b_idx, h_idx, c_idx, 0:L, 0:D]
                matmul(l0c_score[stage1_cnt], l1_key[stage1_cnt], l1_key[stage1_cnt], m=L, n=L, k=D, splitn=L)

                cvmutex.lock()
                score_ub[stage1_cnt] <<= l0c_score[stage1_cnt]
                cvmutex.ready()
                stage1_cnt += 1

            if bhc > bhc_begin:
                prev_bhc = Var(bhc - 1)
                prev_c_idx = Var(prev_bhc // (B * H))
                prev_bh_remainder = Var(prev_bhc % (B * H))
                prev_b_idx = Var(prev_bh_remainder // H)
                prev_h_idx = Var(prev_bh_remainder % H)

                post_row_begin = Var(GetSubBlockIdx() * HALF_L)
                post_row_end = Min(post_row_begin + HALF_L, L)
                post_rows_this = Var(post_row_end - post_row_begin)

                cvmutex.wait()
                beta_ub[stage2_cnt][0:1, 0:post_rows_this] <<= beta[
                    prev_b_idx,
                    prev_h_idx,
                    prev_c_idx,
                    post_row_begin:post_row_end,
                ]
                apply_beta_and_mask_vf(
                    score_ub[stage2_cnt],
                    beta_ub[stage2_cnt],
                    strict_lower_mask_ub,
                    attn_ub[stage2_cnt],
                    post_row_begin,
                    post_rows_this,
                )
                cvmutex.free()

                attn[prev_b_idx, prev_h_idx, prev_c_idx, post_row_begin:post_row_end, 0:L] <<= attn_ub[stage2_cnt][0:post_rows_this, 0:L]
                stage2_cnt += 1

    return attn


def _check_contract(B, H, C, length_per_chunk, head_dim):
    if length_per_chunk != L:
        raise ValueError(f"this A5 kernel is specialized for L={L}, got L={length_per_chunk}")
    if head_dim != D:
        raise ValueError(f"this A5 kernel is specialized for D={D}, got D={head_dim}")
    if B <= 0 or H <= 0 or C <= 0:
        raise ValueError(f"B/H/C must be positive, got B={B}, H={H}, C={C}")


def run_kernel(key, beta, simulator=True, trace=None, profile=False, out_dir=""):
    B, H, C, length_per_chunk, head_dim = key.shape
    _check_contract(B, H, C, length_per_chunk, head_dim)
    device = key.device
    attn = torch.empty((B, H, C, L, L), dtype=torch.float32, device=device)

    saved_sim_config = getattr(delta_preprocess_kernel, "_simulator_config", None)
    if simulator:
        delta_preprocess_kernel._simulator_config = SimulatorConfig(
            core_count=SIM_CORE_COUNT,
            execution_timeout_s=180.0,
            trace_enabled=trace is not None,
        )

    try:
        return OpExec(
            delta_preprocess_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace,
            profile=profile,
        )(
            key,
            beta,
            attn,
            B,
            H,
            C,
            L,
            D,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr(delta_preprocess_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                delta_preprocess_kernel._simulator_config = saved_sim_config


if __name__ == "__main__":
    torch.manual_seed(0)

    B = 1
    H = 64
    C = 2
    key = torch.randn(B, H, C, L, D, dtype=torch.float32).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32)

    ref = delta_preprocess(key, beta)
    out = run_kernel(key, beta, simulator=True)
    got = out[0] if isinstance(out, tuple) else out

    torch.testing.assert_close(got, ref, rtol=2e-3, atol=2e-3)
    print(f"attn: shape={tuple(got.shape)} dtype={got.dtype} max_abs={torch.abs(got - ref).max().item():.6e}")
    assert got.dtype == ref.dtype
    print("delta_preprocess OK")
