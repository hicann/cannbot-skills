"""End-to-end PyTorch oracle for the flat-contract KDA backward reference.

Split-specific stage boundaries now live in the local `refs/*_ref.py` files and
their shared helpers in `refs/common.py`. This file stays focused on the public
backward contract:

- inputs:  `q`, `k`, `v`, `g`, `beta`, `initial_state`, `do`, `dht` — all bf16
- outputs: `dq`, `dk`, `dv`, `dbeta`, `dg`, `dh0` — all bf16

Internally the oracle upcasts to fp32, differentiates the clean fp32 forward,
and downcasts the gradients once at the end.
"""

from common import (
    ATOL,
    IO_DTYPE,
    RTOL,
    RCP_LN2,
    REPRESENTATIVE_SHAPE,
    KDAForwardCaches,
    KDAOracleInputs,
    KDAOracleOutputs,
    build_saved_forward,
    make_inputs,
    make_representative_inputs,
    oracle,
)

__all__ = [
    "ATOL",
    "IO_DTYPE",
    "RTOL",
    "RCP_LN2",
    "REPRESENTATIVE_SHAPE",
    "KDAForwardCaches",
    "KDAOracleInputs",
    "KDAOracleOutputs",
    "build_saved_forward",
    "make_inputs",
    "make_representative_inputs",
    "oracle",
]


if __name__ == "__main__":
    outputs = oracle(
        make_inputs(B=1, H=2, HV=4, T=8, K=8, V=6, chunk_size=4, seed=0)
    )
    print(
        {
            "dq": (tuple(outputs.dq.shape), outputs.dq.dtype),
            "dk": (tuple(outputs.dk.shape), outputs.dk.dtype),
            "dv": (tuple(outputs.dv.shape), outputs.dv.dtype),
            "dbeta": (tuple(outputs.dbeta.shape), outputs.dbeta.dtype),
            "dg": (tuple(outputs.dg.shape), outputs.dg.dtype),
            "dh0": (tuple(outputs.dh0.shape), outputs.dh0.dtype),
        }
    )
