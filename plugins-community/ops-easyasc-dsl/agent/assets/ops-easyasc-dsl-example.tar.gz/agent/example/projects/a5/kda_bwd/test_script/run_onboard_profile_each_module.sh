#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLAN_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

find_repo_root() {
  local dir="${PLAN_DIR}"
  while [[ "${dir}" != "/" ]]; do
    if [[ -f "${dir}/agent/ROUTER.md" && -f "${dir}/easyasc/a5.py" ]]; then
      printf '%s\n' "${dir}"
      return 0
    fi
    dir="$(dirname "${dir}")"
  done
  return 1
}

REPO_ROOT="$(find_repo_root)"

MODULES="${MODULES:-leaf}"
UPSTREAM="${UPSTREAM:-ref}"
SEED="${SEED:-20260604}"
B="${B:-1}"
H="${H:-32}"
HV="${HV:-32}"
C="${C:-16}"
STOP_ON_FAIL="${STOP_ON_FAIL:-0}"
OUT_DIR="${OUT_DIR:-${PLAN_DIR}/hw_out/onboard_profile_each_${MODULES}_b${B}h${H}hv${HV}c${C}_$(date +%Y%m%d_%H%M%S)}"
SUMMARY_TSV_NAME="${SUMMARY_TSV_NAME:-summary.tsv}"

if [[ -n "${PYTHON_CMD:-}" ]]; then
  read -r -a PYTHON_RUNNER <<< "${PYTHON_CMD}"
elif command -v conda >/dev/null 2>&1 && conda env list | grep -qE '^torch210npu[[:space:]]'; then
  PYTHON_RUNNER=(conda run -n torch210npu python)
else
  PYTHON_RUNNER=(python)
fi

mkdir -p "${OUT_DIR}"
OUT_DIR="$(cd "${OUT_DIR}" && pwd)"

MODULE_LIST=()
while IFS= read -r module_name; do
  if [[ -n "${module_name}" ]]; then
    MODULE_LIST+=("${module_name}")
  fi
done < <(
  "${PYTHON_RUNNER[@]}" "${PLAN_DIR}/test_script/module_vs_ref.py" \
    --module "${MODULES}" \
    --list-modules
)

echo "kda_bwd onboard per-module sweep"
echo "  modules=${MODULES} -> ${MODULE_LIST[*]}"
echo "  upstream=${UPSTREAM} seed=${SEED} shape=(B=${B},H=${H},HV=${HV},C=${C})"
echo "  repo_root=${REPO_ROOT}"
echo "  out_dir=${OUT_DIR}"
echo "  python=${PYTHON_RUNNER[*]}"

FAILED=()
RUN_MODULES=()
STATUS_LIST=()
RC_LIST=()
OUT_DIR_LIST=()
SUMMARY_TSV="${OUT_DIR}/${SUMMARY_TSV_NAME}"
printf 'module\tstatus\trc\tout_dir\n' > "${SUMMARY_TSV}"

append_summary_row() {
  local module="$1"
  local status="$2"
  local rc="$3"
  local out_dir="$4"
  RUN_MODULES+=("${module}")
  STATUS_LIST+=("${status}")
  RC_LIST+=("${rc}")
  OUT_DIR_LIST+=("${out_dir}")
  printf '%s\t%s\t%s\t%s\n' "${module}" "${status}" "${rc}" "${out_dir}" >> "${SUMMARY_TSV}"
}

for module in "${MODULE_LIST[@]}"; do
  echo
  echo "===== module ${module} ====="
  module_out_dir="${OUT_DIR}/${module}"
  RC=0
  MODULE="${module}" \
  UPSTREAM="${UPSTREAM}" \
  SEED="${SEED}" \
  B="${B}" \
  H="${H}" \
  HV="${HV}" \
  C="${C}" \
  OUT_DIR="${module_out_dir}" \
  PYTHON_CMD="${PYTHON_RUNNER[*]}" \
  "${SCRIPT_DIR}/run_onboard_profile.sh" "$@" || RC=$?
  if [[ "${RC}" -ne 0 ]]; then
    FAILED+=("${module}")
    append_summary_row "${module}" "FAIL" "${RC}" "${module_out_dir}"
    if [[ "${STOP_ON_FAIL}" == "1" ]]; then
      break
    fi
  else
    append_summary_row "${module}" "OK" "0" "${module_out_dir}"
  fi
done

echo
echo "===== summary ====="
printf '%-24s  %-6s  %-3s  %s\n' "module" "status" "rc" "out_dir"
printf '%-24s  %-6s  %-3s  %s\n' "------" "------" "--" "-------"
for idx in "${!RUN_MODULES[@]}"; do
  printf '%-24s  %-6s  %-3s  %s\n' \
    "${RUN_MODULES[$idx]}" \
    "${STATUS_LIST[$idx]}" \
    "${RC_LIST[$idx]}" \
    "${OUT_DIR_LIST[$idx]}"
done
echo
echo "summary_tsv=${SUMMARY_TSV}"

if [[ "${#RUN_MODULES[@]}" -lt "${#MODULE_LIST[@]}" ]]; then
  SKIPPED=("${MODULE_LIST[@]:${#RUN_MODULES[@]}}")
  echo "skipped_modules=${SKIPPED[*]}"
fi

if [[ "${#FAILED[@]}" -eq 0 ]]; then
  echo "All requested modules passed."
  exit 0
fi

echo "Failed modules: ${FAILED[*]}"
exit 1
