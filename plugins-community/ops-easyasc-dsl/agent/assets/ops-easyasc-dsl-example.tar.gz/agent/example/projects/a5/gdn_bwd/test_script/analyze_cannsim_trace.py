#!/usr/bin/env python3
"""Analyze a CANNSIM Chrome-trace (core 0) into the 7 A5 pipe categories the
gdn reports use, with WAIT_FLAG_* / sync / scalar EXCLUDED from work-util.

Categories (per user spec: cube {mte2,mte1,m,fix} + vec {mte2,v,mte3}):
  cube-MTE2 : pid4  GM->L1 matmul-operand load (MOV_OUT_TO_L1_*ND2NZ + GM->L1 aligned)
  MTE1      : pid3  L1->L0 (LOAD_2Dv2)
  M         : pid6  MMAD
  FIX       : pid17 L0C->UB/L1 fixpipe (FIX_L0C_TO_DST)
  vec-MTE2  : pid4  GM->UB vector load (MOV_SRC_TO_DST_ALIGNv2 on MTE2)
  V         : pid11-14 RV_* vector exec (union across the 4 RVEC sub-pipes)
  MTE3      : pid7  UB->GM store + UB->L1 NZ publish (MOV_UB_TO_L1 + MOV_SRC_TO_DST_ALIGN)
Excluded from work-util (reported separately): WAIT_FLAG_*, SET_INTRA_BLOCK,
MOV_SPR_XN, PUSH*/VF container (pid10), SCALAR/SCALARLDST (pid1,2), FLOWCTRL.

Usage:
  python analyze_cannsim_trace.py trace_core0.json [--win T0 T1] [--mm-per-iter N]
"""
import json, sys, argparse
from collections import defaultdict, Counter

WAIT_PREFIXES = ("WAIT_FLAG", "SET_INTRA", "SET_CROSS", "MOV_SPR", "PUSH", "MOVEMASK")

def union_len(intervals, w0=None, w1=None):
    """Merge [ts,end) intervals, clip to [w0,w1), return covered length."""
    ivs = []
    for a, b in intervals:
        if w0 is not None:
            a = max(a, w0); b = min(b, w1)
        if b > a:
            ivs.append((a, b))
    if not ivs:
        return 0.0
    ivs.sort()
    tot = 0.0
    ca, cb = ivs[0]
    for a, b in ivs[1:]:
        if a <= cb:
            cb = max(cb, b)
        else:
            tot += cb - ca; ca, cb = a, b
    tot += cb - ca
    return tot


def is_wait(name):
    return any(name.startswith(p) for p in WAIT_PREFIXES)


def categorize(pid, name):
    if is_wait(name):
        return None
    if pid == 4:  # MTE2 shared
        if "ND2NZ" in name or "OUT_TO_L1" in name:
            return "cube-MTE2"
        if "ALIGN" in name or "SRC_TO_DST" in name:
            return "vec-MTE2"
        return "cube-MTE2"
    if pid == 3 and "LOAD_2D" in name:
        return "MTE1"
    if pid == 6 and name == "MMAD":
        return "M"
    if pid == 17 and name.startswith("FIX"):
        return "FIX"
    if pid in (11, 12, 13, 14) and name.startswith("RV_"):
        return "V"
    if pid == 7 and (name.startswith("MOV_UB_TO_L1") or "ALIGN" in name or "SRC_TO_DST" in name):
        return "MTE3"
    return None


CUBE = ["cube-MTE2", "MTE1", "M", "FIX"]
VEC = ["vec-MTE2", "V", "MTE3"]
ORDER = CUBE + VEC


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("trace")
    ap.add_argument("--win", nargs=2, type=float, default=None, help="steady-state window t0 t1")
    ap.add_argument("--mm-per-iter", type=int, default=None, help="matmuls per loop iter -> derive #iters")
    args = ap.parse_args()

    with open(args.trace) as f:
        ev = json.load(f)
    pid_name = {e["pid"]: e["args"]["name"] for e in ev if e.get("ph") == "M" and e.get("name") == "process_name"}
    xs = [e for e in ev if e.get("ph") == "X"]

    def ts(e): return float(e.get("ts", 0) or 0)
    def dur(e): return float(e.get("dur", 0) or 0)

    gmin = min(ts(e) for e in xs)
    gmax = max(ts(e) + dur(e) for e in xs)
    makespan = gmax - gmin
    print(f"trace={args.trace}")
    print(f"makespan = {makespan:.0f} cycles  (ts {gmin:.0f}..{gmax:.0f})   X-events={len(xs)}")

    # gather intervals per category
    cat_iv = defaultdict(list)
    cat_names = defaultdict(Counter)
    for e in xs:
        c = categorize(e["pid"], e.get("name", "?"))
        if c is None:
            continue
        cat_iv[c].append((ts(e), ts(e) + dur(e)))
        cat_names[c][e.get("name")] += 1

    # MMAD / VF anchors
    mmads = sorted(ts(e) for e in xs if e["pid"] == 6 and e.get("name") == "MMAD")
    vfs = sorted(((ts(e), dur(e)) for e in xs if e["pid"] == 10 and e.get("name") == "VF"))
    print(f"\nMMAD count = {len(mmads)}   VF-container count = {len(vfs)}")
    if args.mm_per_iter:
        print(f"  -> ~{len(mmads)/args.mm_per_iter:.1f} iterations (mm_per_iter={args.mm_per_iter})")

    # windows: full + auto compute-region [firstMMAD, lastMMAD end] + optional steady
    windows = [("FULL makespan", gmin, gmax)]
    if mmads:
        mm_end = max(ts(e) + dur(e) for e in xs if e["pid"] == 6 and e.get("name") == "MMAD")
        windows.append(("COMPUTE-REGION [1st..last MMAD]", mmads[0], mm_end))
    if args.win:
        windows.append(("STEADY window", args.win[0], args.win[1]))

    for label, w0, w1 in windows:
        wlen = w1 - w0
        print(f"\n=== {label}: [{w0:.0f}, {w1:.0f}]  len={wlen:.0f} ===")
        print(f"  {'category':<12} {'union-busy':>10} {'occupancy':>10}")
        side_tot = {"cube": 0.0, "vec": 0.0}
        for c in ORDER:
            u = union_len(cat_iv[c], w0, w1)
            occ = u / wlen if wlen else 0
            side = "cube" if c in CUBE else "vec"
            side_tot[side] += u
            print(f"  {c:<12} {u:>10.0f} {occ*100:>9.1f}%")
        # any-pipe-busy (all 7 categories union)
        allb = union_len([iv for c in ORDER for iv in cat_iv[c]], w0, w1)
        print(f"  {'-'*34}")
        print(f"  {'cube-side Σ':<12} {side_tot['cube']:>10.0f} {side_tot['cube']/wlen*100:>9.1f}%")
        print(f"  {'vec-side Σ':<12} {side_tot['vec']:>10.0f} {side_tot['vec']/wlen*100:>9.1f}%")
        print(f"  {'ANY-pipe':<12} {allb:>10.0f} {allb/wlen*100:>9.1f}%  (>=1 pipe busy)")

    # category membership (validate split vs source)
    print("\n=== category membership (name x count, whole trace) ===")
    for c in ORDER:
        parts = ", ".join(f"{n}:{k}" for n, k in cat_names[c].most_common())
        print(f"  {c:<12} {parts}")

    # VF list for loop detection
    print(f"\n=== VF-container events (pid10 VF): idx ts dur ===")
    for i, (t, d) in enumerate(vfs):
        print(f"  vf[{i:2d}] ts={t:.0f} dur={d:.0f}")

    # MMAD timestamps (loop boundary detection)
    print(f"\n=== MMAD ts (gaps show iteration grouping) ===")
    prev = None
    for i, t in enumerate(mmads):
        gap = "" if prev is None else f" (+{t-prev:.0f})"
        print(f"  mm[{i:2d}] ts={t:.0f}{gap}")
        prev = t


if __name__ == "__main__":
    main()
