"""KDA forward fused sub4 state update plus sub5 output assembly.

A5 implementation specialized to L=64, K=128, V=128 with dynamic B, H, HV,
and C where HV is a positive multiple of H. The production contract consumes
`q`, `Aqk`, `kg`, `w`, `u`, `eg`, and `initial_state`, and returns only `o`
and `final_state`; the former split-stage `h` and `v_new` tensors stay on chip.

For each chunk, the fused schedule computes:

    h = state
    v_new = u - w @ h
    delta = kg.T @ v_new
    o = (q * eg * scale) @ h + Aqk @ v_new
    state = state * eg_last + delta

Work is distributed by complete `(B, HV)` value-tile pairs, so the shared
`q*eg*scale` and Aqk staging for the output product does not straddle two
different value heads on uneven core counts.
"""

import argparse
import os
from pathlib import Path
import sys

import torch

_REPO_ROOT = Path(__file__).resolve().parents[4]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from easyasc.a5 import *  # noqa: F401,F403
from easyasc.simulator import SimulatorConfig


L = 64
K_DIM = 128
V_DIM = 128
V_BLOCK = 64
V_TILES = V_DIM // V_BLOCK
HALF_L = L // 2
HALF_K = K_DIM // 2
K_BLOCK = 64
K_TILES = K_DIM // K_BLOCK
SPLIT_N = 64
DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 300.0

SHAPE_BINDINGS = {
    0: [0, 1, 3, 4, 5],  # q[B,H,C,L,K]
    1: [0, 2, 3, 4, 4],  # Aqk[B,HV,C,L,L]
    2: [0, 2, 3, 4, 5],  # kg[B,HV,C,L,K]
    3: [0, 2, 3, 4, 5],  # w[B,HV,C,L,K]
    4: [0, 2, 3, 4, 6],  # u[B,HV,C,L,V]
    5: [0, 2, 3, 4, 5],  # eg[B,HV,C,L,K]
    6: [0, 2, 5, 6],     # initial_state[B,HV,K,V]
    7: [0, 2, 3, 4, 6],  # o[B,HV,C,L,V]
    8: [0, 2, 5, 6],     # final_state[B,HV,K,V]
}


@vf()
def cast_state_to_h_vf(state_ub: Tensor, h_ub: Tensor, rows: Var):
    state_row = Reg(DT.float)
    row_bf16 = Reg(DT.bfloat16)
    row_mask_bf16 = MaskReg(DT.bfloat16, init_mode=MaskType.NONE)

    row_mask_bf16 <<= Var(V_BLOCK * 2, dtype=DT.uint32)

    for r in range(rows):
        state_row <<= state_ub[r:r + 1, 0:V_BLOCK]
        row_bf16 <<= state_row.astype(DT.bfloat16)
        reg_to_ub_downsample(h_ub[r:r + 1, 0:V_BLOCK], row_bf16, mask=row_mask_bf16)


@vf()
def make_vnew_vf(prod_ub: Tensor, u_ub: Tensor, vnew_ub: Tensor, rows: Var):
    prod_row = Reg(DT.float)
    u_row = Reg(DT.float)
    row_bf16 = Reg(DT.bfloat16)
    row_mask_bf16 = MaskReg(DT.bfloat16, init_mode=MaskType.NONE)

    row_mask_bf16 <<= Var(V_BLOCK * 2, dtype=DT.uint32)

    for r in range(rows):
        prod_row <<= prod_ub[r:r + 1, 0:V_BLOCK]
        u_row <<= u_ub[r:r + 1, 0:V_BLOCK]
        prod_row <<= u_row - prod_row
        row_bf16 <<= prod_row.astype(DT.bfloat16)
        reg_to_ub_downsample(vnew_ub[r:r + 1, 0:V_BLOCK], row_bf16, mask=row_mask_bf16)


@vf()
def decay_state_vf(state_ub: Tensor, g_last_ub: Tensor, state_decayed_ub: Tensor, rows: Var):
    state_row = Reg(DT.float)
    decay = Reg(DT.float)

    for r in range(rows):
        state_row <<= state_ub[r:r + 1, 0:V_BLOCK]
        decay <<= g_last_ub[0:1, r:r + 1].single()
        state_row <<= state_row * decay
        state_decayed_ub[r:r + 1, 0:V_BLOCK] <<= state_row


@vf()
def add_delta_to_state_vf(state_decayed_ub: Tensor, delta_ub: Tensor, state_ub: Tensor, rows: Var):
    state_row = Reg(DT.float)
    delta_row = Reg(DT.float)

    for r in range(rows):
        state_row <<= state_decayed_ub[r:r + 1, 0:V_BLOCK]
        delta_row <<= delta_ub[r:r + 1, 0:V_BLOCK]
        state_row <<= state_row + delta_row
        state_ub[r:r + 1, 0:V_BLOCK] <<= state_row


@vf()
def qg_scale_vf(q_ub: Tensor, eg_ub: Tensor, qg_ub: Tensor, rows: Var, scale: Var):
    q_row = Reg(DT.float)
    eg_row = Reg(DT.float)
    tmp = Reg(DT.float)
    row_bf16 = Reg(DT.bfloat16)
    row_mask_bf16 = MaskReg(DT.bfloat16, init_mode=MaskType.NONE)

    row_mask_bf16 <<= Var(K_BLOCK * 2, dtype=DT.uint32)

    for r in range(rows):
        for tile in range(K_TILES):
            k_begin = tile * K_BLOCK
            k_end = k_begin + K_BLOCK
            q_row <<= q_ub[r:r + 1, k_begin:k_end]
            eg_row <<= eg_ub[r:r + 1, k_begin:k_end]
            tmp <<= q_row * eg_row
            tmp <<= tmp * scale
            row_bf16 <<= tmp.astype(DT.bfloat16)
            reg_to_ub_downsample(qg_ub[r:r + 1, k_begin:k_end], row_bf16, mask=row_mask_bf16)


@kernel()
def kda_sub45_fused_kernel(
    q: GMTensor,
    Aqk: GMTensor,
    kg: GMTensor,
    w: GMTensor,
    u: GMTensor,
    eg: GMTensor,
    initial_state: GMTensor,
    o: GMTensor,
    final_state: GMTensor,
    B: Var,
    H: Var,
    HV: Var,
    C: Var,
    length_per_chunk: Var,
    head_dim: Var,
    value_dim: Var,
    scale: Var,
):
    prod_mutex = CvMutex(0, src_start_pipe=Pipe.FIX, src_end_pipe=Pipe.FIX, dst_start_pipe=Pipe.V, dst_end_pipe=Pipe.V)
    vnew_mutex = VcMutex(1, src_start_pipe=Pipe.MTE3, src_end_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1, dst_end_pipe=Pipe.MTE1)
    state_mutex = VcMutex(2, src_start_pipe=Pipe.MTE3, src_end_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1, dst_end_pipe=Pipe.MTE1)
    delta_mutex = CvMutex(3, src_start_pipe=Pipe.FIX, src_end_pipe=Pipe.FIX, dst_start_pipe=Pipe.V, dst_end_pipe=Pipe.V)
    qg_mutex = VcMutex(4, src_start_pipe=Pipe.MTE3, src_end_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1, dst_end_pipe=Pipe.MTE1)

    state_ubout_valid = DEvent(Pipe.MTE3, Pipe.MTE2, preset=True)
    state_ubin_ready = DEvent(Pipe.MTE2, Pipe.V)
    state_ubout_ready = DEvent(Pipe.V, Pipe.MTE3)

    h_ubout_valid = DEvent(Pipe.MTE3, Pipe.V, preset=True)
    h_ubout_ready = DEvent(Pipe.V, Pipe.MTE3)
    vnew_ubout_valid = DEvent(Pipe.MTE3, Pipe.V, preset=True)
    vnew_ubout_ready = DEvent(Pipe.V, Pipe.MTE3)

    u_ubin_valid = DEvent(Pipe.V, Pipe.MTE2, preset=True)
    u_ubin_ready = DEvent(Pipe.MTE2, Pipe.V)
    g_ubin_valid = DEvent(Pipe.V, Pipe.MTE2, preset=True)
    g_ubin_ready = DEvent(Pipe.MTE2, Pipe.V)
    q_ubin_valid = DEvent(Pipe.V, Pipe.MTE2, preset=True)
    q_ubin_ready = DEvent(Pipe.MTE2, Pipe.V)
    qg_ubout_valid = DEvent(Pipe.MTE3, Pipe.V, preset=True)
    qg_ubout_ready = DEvent(Pipe.V, Pipe.MTE3)

    w_l1_valid = DEvent(Pipe.MTE1, Pipe.MTE2, preset=True)
    w_l1_ready = DEvent(Pipe.MTE2, Pipe.MTE1)
    kg_l1_valid = DEvent(Pipe.MTE1, Pipe.MTE2, preset=True)
    kg_l1_ready = DEvent(Pipe.MTE2, Pipe.MTE1)
    aqk_l1_valid = DEvent(Pipe.MTE1, Pipe.MTE2, preset=True)
    aqk_l1_ready = DEvent(Pipe.MTE2, Pipe.MTE1)

    prod_l0_valid = DEvent(Pipe.M, Pipe.MTE1, preset=True)
    prod_l0_ready = DEvent(Pipe.MTE1, Pipe.M)
    prod_l0c_valid = DEvent(Pipe.FIX, Pipe.M, preset=True)
    prod_l0c_ready = DEvent(Pipe.M, Pipe.FIX)
    delta_l0_valid = DEvent(Pipe.M, Pipe.MTE1, preset=True)
    delta_l0_ready = DEvent(Pipe.MTE1, Pipe.M)
    delta_l0c_valid = DEvent(Pipe.FIX, Pipe.M, preset=True)
    delta_l0c_ready = DEvent(Pipe.M, Pipe.FIX)
    out_l0c_valid = DEvent(Pipe.FIX, Pipe.M, preset=True)
    out_l0c_ready = DEvent(Pipe.M, Pipe.FIX)

    l1_state = DBuff(DT.bfloat16, [K_DIM, V_BLOCK], Position.L1)
    l1_qg = DBuff(DT.bfloat16, [L, K_DIM], Position.L1)
    l1_Aqk = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_w = DBuff(DT.bfloat16, [L, K_DIM], Position.L1)
    l1_kg = DBuff(DT.bfloat16, [L, K_DIM], Position.L1)
    l1_vnew = DBuff(DT.bfloat16, [L, V_BLOCK], Position.L1)
    l0a_prod = DBuff(DT.bfloat16, [L, K_DIM], Position.L0A)
    l0b_prod = DBuff(DT.bfloat16, [V_BLOCK, K_DIM], Position.L0B)
    l0a_delta = DBuff(DT.bfloat16, [K_DIM, L], Position.L0A)
    l0b_delta = DBuff(DT.bfloat16, [V_BLOCK, L], Position.L0B)
    l0c_prod = DBuff(DT.float, [L, V_BLOCK], Position.L0C)
    l0c_delta = DBuff(DT.float, [K_DIM, V_BLOCK], Position.L0C)
    l0c_out = DBuff(DT.float, [L, V_BLOCK], Position.L0C)

    state_ub = DBuff(DT.float, [HALF_K, V_BLOCK], Position.UB)
    h_ub = DBuff(DT.bfloat16, [HALF_K, V_BLOCK], Position.UB)
    prod_ub = DBuff(DT.float, [HALF_L, V_BLOCK], Position.UB)
    u_ub = DBuff(DT.bfloat16, [HALF_L, V_BLOCK], Position.UB)
    vnew_ub = DBuff(DT.bfloat16, [HALF_L, V_BLOCK], Position.UB)
    delta_ub = DBuff(DT.float, [HALF_K, V_BLOCK], Position.UB)
    state_decayed_ub = DBuff(DT.float, [HALF_K, V_BLOCK], Position.UB)
    g_last_ub = DBuff(DT.float, [1, HALF_K], Position.UB)
    q_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)
    eg_q_ub = DBuff(DT.float, [HALF_L, K_DIM], Position.UB)
    qg_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)

    pair_count = B * HV
    work_count = pair_count * V_TILES
    pair_begin = Var((pair_count * GetCubeIdx()) // GetCubeNum())
    pair_end = Var((pair_count * (GetCubeIdx() + 1)) // GetCubeNum())
    group = Var(HV // H)

    # auto sync is not used here because the nested for loops interfere with it,
    # causing auto sync to not output the correct event pairs
    for pair_idx in range(pair_begin, pair_end):
        pair = Var(pair_idx * V_TILES)
        row_begin_l = Var(GetSubBlockIdx() * HALF_L)
        row_end_l = Var(row_begin_l + HALF_L)
        row_begin_k = Var(GetSubBlockIdx() * HALF_K)
        row_end_k = Var(row_begin_k + HALF_K)

        for slot in range(2):
            work = Var(pair + slot)
            if work < work_count:
                v_tile = Var(work % V_TILES)
                head_work = Var(work // V_TILES)
                hv_idx = Var(head_work % HV)
                b_idx = Var(head_work // HV)
                v_begin = Var(v_tile * V_BLOCK)
                v_end = Var(v_begin + V_BLOCK)
                state_ubout_valid.wait()
                state_ub[slot][0:HALF_K, 0:V_BLOCK] <<= initial_state[
                    b_idx, hv_idx, row_begin_k:row_end_k, v_begin:v_end
                ]
                state_ubin_ready.set()

        for c_idx in range(C):
            # Vec stage A: publish current state as h and as bf16 L1.
            for slot in range(2):
                work = Var(pair + slot)
                if work < work_count:
                    head_work = Var(work // V_TILES)
                    if c_idx == 0:
                        state_ubin_ready.wait()
                    h_ubout_valid.wait()
                    cast_state_to_h_vf(state_ub[slot], h_ub[slot], HALF_K)
                    h_ubout_ready.set()
                    h_ubout_ready.wait()
                    state_mutex.lock()
                    l1_state[slot][row_begin_k:row_end_k, 0:V_BLOCK] <<= h_ub[slot][
                        0:HALF_K, 0:V_BLOCK
                    ]
                    state_mutex.ready()
                    h_ubout_valid.set()

            # Vec stage A1: build q * eg * scale once per head/chunk for both value tiles.
            work_q = Var(pair)
            if work_q < work_count:
                head_work_q = Var(work_q // V_TILES)
                hv_q = Var(head_work_q % HV)
                b_q = Var(head_work_q // HV)
                h_q = Var(hv_q // group)
                q_slot = Var(c_idx % 2)
                q_ubin_valid.wait()
                q_ub[q_slot][0:HALF_L, 0:K_DIM] <<= q[b_q, h_q, c_idx, row_begin_l:row_end_l, 0:K_DIM]
                eg_q_ub[q_slot][0:HALF_L, 0:K_DIM] <<= eg[b_q, hv_q, c_idx, row_begin_l:row_end_l, 0:K_DIM]
                q_ubin_ready.set()
                q_ubin_ready.wait()
                qg_ubout_valid.wait()
                qg_scale_vf(q_ub[q_slot], eg_q_ub[q_slot], qg_ub[q_slot], HALF_L, scale)
                q_ubin_valid.set()
                qg_ubout_ready.set()
                qg_ubout_ready.wait()
                qg_mutex.lock()
                l1_qg[q_slot][row_begin_l:row_end_l, 0:K_DIM] <<= qg_ub[q_slot][0:HALF_L, 0:K_DIM]
                qg_mutex.ready()
                qg_ubout_valid.set()

            # Cube-side input for the local output product, shared by both value tiles.
            work_aqk = Var(pair)
            if work_aqk < work_count:
                head_work_aqk = Var(work_aqk // V_TILES)
                hv_aqk = Var(head_work_aqk % HV)
                b_aqk = Var(head_work_aqk // HV)
                aqk_slot = Var(c_idx % 2)
                aqk_l1_valid.wait()
                l1_Aqk[aqk_slot][0:L, 0:L] <<= Aqk[b_aqk, hv_aqk, c_idx, 0:L, 0:L]
                aqk_l1_ready.set()

            # Vec stage A2: use the first w @ state wait gap for slot 0 decay.
            for slot in range(1):
                work = Var(pair + slot)
                if work < work_count:
                    head_work = Var(work // V_TILES)
                    hv_idx = Var(head_work % HV)
                    b_idx = Var(head_work // HV)
                    g_ubin_valid.wait()
                    g_last_ub[slot][0:1, 0:HALF_K] <<= eg[
                        b_idx, hv_idx, c_idx, L - 1:L, row_begin_k:row_end_k
                    ]
                    g_ubin_ready.set()
                    g_ubin_ready.wait()
                    decay_state_vf(state_ub[slot], g_last_ub[slot], state_decayed_ub[slot], HALF_K)
                    g_ubin_valid.set()

            # Cube stage A: w @ state.
            for slot in range(2):
                work = Var(pair + slot)
                if work < work_count:
                    head_work = Var(work // V_TILES)
                    hv_idx = Var(head_work % HV)
                    b_idx = Var(head_work // HV)
                    w_l1_valid.wait()
                    l1_w[slot][0:L, 0:K_DIM] <<= w[b_idx, hv_idx, c_idx, 0:L, 0:K_DIM]
                    w_l1_ready.set()
                    state_mutex.wait()
                    w_l1_ready.wait()
                    prod_l0_valid.wait()
                    l0a_prod[slot][0:L, 0:K_DIM] <<= l1_w[slot][0:L, 0:K_DIM]
                    l0b_prod[slot][0:V_BLOCK, 0:K_DIM] <<= l1_state[slot].T
                    w_l1_valid.set()
                    prod_l0_ready.set()
                    prod_l0_ready.wait()
                    prod_l0c_valid.wait()
                    # Keep the explicit cube pipe sequence visible because sync is manual here.
                    mmad(l0c_prod[slot], l0a_prod[slot], l0b_prod[slot], M=L, N=V_BLOCK, K=K_DIM, is_init=True)
                    prod_l0_valid.set()
                    prod_l0c_ready.set()
                    prod_mutex.lock()
                    prod_l0c_ready.wait()
                    prod_ub[slot] <<= l0c_prod[slot]
                    prod_l0c_valid.set()
                    prod_mutex.ready()

            # Vec stage B: u - w @ state, then publish v_new to L1.
            for slot in range(2):
                work = Var(pair + slot)
                if work < work_count:
                    v_tile = Var(work % V_TILES)
                    head_work = Var(work // V_TILES)
                    hv_idx = Var(head_work % HV)
                    b_idx = Var(head_work // HV)
                    v_begin = Var(v_tile * V_BLOCK)
                    v_end = Var(v_begin + V_BLOCK)
                    u_ubin_valid.wait()
                    u_ub[slot][0:HALF_L, 0:V_BLOCK] <<= u[
                        b_idx, hv_idx, c_idx, row_begin_l:row_end_l, v_begin:v_end
                    ]
                    u_ubin_ready.set()
                    prod_mutex.wait()
                    u_ubin_ready.wait()
                    vnew_ubout_valid.wait()
                    make_vnew_vf(prod_ub[slot], u_ub[slot], vnew_ub[slot], HALF_L)
                    u_ubin_valid.set()
                    prod_mutex.free()
                    vnew_ubout_ready.set()
                    vnew_ubout_ready.wait()
                    vnew_mutex.lock()
                    l1_vnew[slot][row_begin_l:row_end_l, 0:V_BLOCK] <<= vnew_ub[slot][
                        0:HALF_L, 0:V_BLOCK
                    ]
                    vnew_mutex.ready()
                    vnew_ubout_valid.set()

            # Vec stage B2: use the delta wait gap for slot 1 decay.
            for slot in range(1, 2):
                work = Var(pair + slot)
                if work < work_count:
                    head_work = Var(work // V_TILES)
                    hv_idx = Var(head_work % HV)
                    b_idx = Var(head_work // HV)
                    g_ubin_valid.wait()
                    g_last_ub[slot][0:1, 0:HALF_K] <<= eg[
                        b_idx, hv_idx, c_idx, L - 1:L, row_begin_k:row_end_k
                    ]
                    g_ubin_ready.set()
                    g_ubin_ready.wait()
                    decay_state_vf(state_ub[slot], g_last_ub[slot], state_decayed_ub[slot], HALF_K)
                    g_ubin_valid.set()

            # Cube stage B: kg.T @ v_new.
            for slot in range(2):
                work = Var(pair + slot)
                if work < work_count:
                    head_work = Var(work // V_TILES)
                    hv_idx = Var(head_work % HV)
                    b_idx = Var(head_work // HV)
                    kg_l1_valid.wait()
                    l1_kg[slot][0:L, 0:K_DIM] <<= kg[b_idx, hv_idx, c_idx, 0:L, 0:K_DIM]
                    kg_l1_ready.set()
                    vnew_mutex.wait()
                    kg_l1_ready.wait()
                    delta_l0_valid.wait()
                    l0a_delta[slot][0:K_DIM, 0:L] <<= l1_kg[slot].T
                    l0b_delta[slot][0:V_BLOCK, 0:L] <<= l1_vnew[slot].T
                    kg_l1_valid.set()
                    vnew_mutex.free()
                    delta_l0_ready.set()
                    delta_l0_ready.wait()
                    delta_l0c_valid.wait()
                    mmad(
                        l0c_delta[slot],
                        l0a_delta[slot],
                        l0b_delta[slot],
                        M=K_DIM,
                        N=V_BLOCK,
                        K=L,
                        is_init=True,
                    )
                    delta_l0_valid.set()
                    delta_l0c_ready.set()
                    delta_mutex.lock()
                    delta_l0c_ready.wait()
                    delta_ub[slot] <<= l0c_delta[slot]
                    delta_l0c_valid.set()
                    delta_mutex.ready()

            # Cube stage C: assemble the sub5 output while h and v_new are still on chip.
            work_out = Var(pair)
            aqk_slot = Var(c_idx % 2)
            qg_slot = Var(c_idx % 2)
            if work_out < work_count:
                aqk_l1_ready.wait()
                qg_mutex.wait()

            for slot in range(2):
                work = Var(pair + slot)
                if work < work_count:
                    v_tile = Var(work % V_TILES)
                    head_work = Var(work // V_TILES)
                    hv_idx = Var(head_work % HV)
                    b_idx = Var(head_work // HV)
                    v_begin = Var(v_tile * V_BLOCK)
                    v_end = Var(v_begin + V_BLOCK)

                    prod_l0_valid.wait()
                    l0a_prod[slot][0:L, 0:K_DIM] <<= l1_qg[qg_slot][0:L, 0:K_DIM]
                    l0b_prod[slot][0:V_BLOCK, 0:K_DIM] <<= l1_state[slot].T
                    state_mutex.free()
                    prod_l0_ready.set()
                    prod_l0_ready.wait()
                    out_l0c_valid.wait()
                    # Reuse the prod L0A/L0B buffers for qg @ h.
                    mmad(l0c_out[slot], l0a_prod[slot], l0b_prod[slot], M=L, N=V_BLOCK, K=K_DIM, is_init=True)
                    prod_l0_valid.set()
                    delta_l0_valid.wait()
                    l0a_delta[slot][0:L, 0:L] <<= l1_Aqk[aqk_slot][0:L, 0:L]
                    delta_l0_ready.set()
                    delta_l0_ready.wait()
                    mmad(l0c_out[slot], l0a_delta[slot][0:L, 0:L], l0b_delta[slot], M=L, N=V_BLOCK, K=L, is_init=False)
                    delta_l0_valid.set()
                    out_l0c_ready.set()
                    out_l0c_ready.wait()
                    o[b_idx, hv_idx, c_idx, 0:L, v_begin:v_end] <<= l0c_out[slot][0:L, 0:V_BLOCK]
                    out_l0c_valid.set()

            if work_out < work_count:
                qg_mutex.free()
                aqk_l1_valid.set()

            # Vec stage C: apply recurrent state update.
            for slot in range(2):
                work = Var(pair + slot)
                if work < work_count:
                    delta_mutex.wait()
                    add_delta_to_state_vf(state_decayed_ub[slot], delta_ub[slot], state_ub[slot], HALF_K)
                    delta_mutex.free()
                    if c_idx == C - 1:
                        state_ubout_ready.set()

        for slot in range(2):
            work = Var(pair + slot)
            if work < work_count:
                v_tile = Var(work % V_TILES)
                head_work = Var(work // V_TILES)
                hv_idx = Var(head_work % HV)
                b_idx = Var(head_work // HV)
                v_begin = Var(v_tile * V_BLOCK)
                v_end = Var(v_begin + V_BLOCK)
                state_ubout_ready.wait()
                final_state[b_idx, hv_idx, row_begin_k:row_end_k, v_begin:v_end] <<= state_ub[
                    slot
                ][0:HALF_K, 0:V_BLOCK]
                state_ubout_valid.set()

    return o, final_state


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_fwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def _check_contract(q, Aqk, kg, w, u, eg, initial_state):
    B, H, C, length_per_chunk, head_dim = q.shape
    kg_B, HV, kg_C, kg_L, kg_K = kg.shape
    value_dim = u.shape[-1]
    if kg_B != B or kg_C != C or kg_L != length_per_chunk or kg_K != head_dim:
        raise ValueError("q and kg shape prefixes must agree")
    if length_per_chunk != L or head_dim != K_DIM or value_dim != V_DIM:
        raise ValueError(
            f"sub45_fused is specialized for L={L}, K={K_DIM}, V={V_DIM}, "
            f"got L={length_per_chunk}, K={head_dim}, V={value_dim}"
        )
    if q.dtype != torch.bfloat16 or Aqk.dtype != torch.bfloat16 or kg.dtype != torch.bfloat16 or w.dtype != torch.bfloat16 or u.dtype != torch.bfloat16:
        raise TypeError("q, Aqk, kg, w, and u must be torch.bfloat16")
    if eg.dtype != torch.float32 or initial_state.dtype != torch.float32:
        raise TypeError("eg and initial_state must be torch.float32")
    if HV % H != 0:
        raise ValueError(f"HV must be divisible by H, got H={H}, HV={HV}")
    return B, H, HV, C, length_per_chunk, head_dim, value_dim


def run(q, Aqk, kg, w, u, eg, initial_state, scale, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False, core_count=None):
    B, H, HV, C, length_per_chunk, head_dim, value_dim = _check_contract(q, Aqk, kg, w, u, eg, initial_state)
    o = torch.empty((B, HV, C, L, V_DIM), dtype=u.dtype, device=u.device)
    final_state = torch.empty((B, HV, K_DIM, V_DIM), dtype=torch.float32, device=kg.device)
    trace_path = _trace_path(trace, out_dir, "sub45_fused")

    previous_config = getattr(kda_sub45_fused_kernel, "_simulator_config", None)
    if simulator:
        kda_sub45_fused_kernel._simulator_config = SimulatorConfig(
            core_count=core_count or DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            kda_sub45_fused_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(q, Aqk, kg, w, u, eg, initial_state, o, final_state, B, H, HV, C, length_per_chunk, head_dim, value_dim, scale, shape_bindings=SHAPE_BINDINGS)
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(kda_sub45_fused_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                kda_sub45_fused_kernel._simulator_config = previous_config
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run KDA forward fused sub4/sub5 kernel.")
    parser.add_argument("--hardware-profile", action="store_true", help="Run the real-hardware profile case: simulator=False, profile=True, B=1, H=HV=32, C=16.")
    parser.add_argument("--out-dir", default="", help="Output directory for generated hardware artifacts.")
    parser.add_argument("--skip-compile", action="store_true", help="Reuse previously compiled artifacts for the hardware profile run.")
    parser.add_argument("--gen-only", action="store_true", help="Generate hardware artifacts without running them.")
    parser.add_argument("--seed", type=int, default=41, help="Random seed for generated inputs.")
    parser.add_argument("--core-count", type=int, default=DEFAULT_CORE_COUNT, help="Simulator core count for non-hardware runs.")
    parser.add_argument("--trace", default=None, help="Path to write a simulator trace for non-hardware runs.")
    args = parser.parse_args()

    refs_dir = Path(__file__).resolve().parents[1] / "refs"
    if str(refs_dir) not in sys.path:
        sys.path.insert(0, str(refs_dir))
    from oracle import sample_inputs as oracle_sample_inputs, to_chunked_inputs
    from sub1_gate_ref import subkernel as ref_sub1_gate
    from sub2_intra_ref import subkernel as ref_sub2_intra
    from sub3_wy_ref import subkernel as ref_sub3_wy
    from sub45_fused_ref import subkernel as ref_sub45_fused

    if args.hardware_profile:
        q_full, k_full, v_full, g_raw_full, beta_full, initial_state = oracle_sample_inputs(
            B=1, H=32, HV=32, C=16, L=L, K=K_DIM, V=V_DIM, seed=args.seed
        )
        q, k, v, g_raw, beta = to_chunked_inputs(q_full, k_full, v_full, g_raw_full, beta_full, chunk_size=L)
        eg = ref_sub1_gate(g_raw)
        scale = K_DIM ** -0.5
        Aqk, Akk = ref_sub2_intra(q, k, eg, beta, scale=scale)
        w, u, _qg, kg = ref_sub3_wy(q, k, v, beta, Akk, eg)
        out_dir = args.out_dir or "./tmp/kda_sub45_fused_hardware_profile"
        result = run(
            q,
            Aqk,
            kg,
            w,
            u,
            eg,
            initial_state,
            scale,
            simulator=False,
            profile=True,
            gen_only=args.gen_only,
            out_dir=out_dir,
            skip_compile=args.skip_compile,
        )
        if args.gen_only:
            for name, out in zip(("o", "final_state"), result):
                print(f"{name}: shape={tuple(out.shape)} dtype={out.dtype}")
            print("pytorch verification skipped for --gen-only because no hardware output was produced")
        else:
            expected = ref_sub45_fused(q, Aqk, kg, w, u, eg, initial_state, scale)
            for name, got, ref in zip(("o", "final_state"), result, expected):
                torch.testing.assert_close(got.float(), ref.float(), rtol=2e-2, atol=2e-2)
                max_abs = float((got.float() - ref.float()).abs().max())
                print(f"{name}: shape={tuple(got.shape)} dtype={got.dtype} max_abs={max_abs:.6e} OK")
        print(f"hardware profile case complete: B=1 H=32 HV=32 C=16 out_dir={out_dir}")
        raise SystemExit(0)

    q_full, k_full, v_full, g_raw_full, beta_full, initial_state = oracle_sample_inputs(
        B=1, H=8, HV=8, C=8, L=L, K=K_DIM, V=V_DIM, seed=args.seed
    )
    q, k, v, g_raw, beta = to_chunked_inputs(q_full, k_full, v_full, g_raw_full, beta_full, chunk_size=L)
    eg = ref_sub1_gate(g_raw)
    scale = K_DIM ** -0.5
    Aqk, Akk = ref_sub2_intra(q, k, eg, beta, scale=scale)
    w, u, _qg, kg = ref_sub3_wy(q, k, v, beta, Akk, eg)
    result = run(q, Aqk, kg, w, u, eg, initial_state, scale, trace=args.trace, core_count=args.core_count)
    expected = ref_sub45_fused(q, Aqk, kg, w, u, eg, initial_state, scale)
    for name, got, ref in zip(("o", "final_state"), result, expected):
        torch.testing.assert_close(got.float(), ref.float(), rtol=2e-2, atol=2e-2)
        max_abs = float((got.float() - ref.float()).abs().max())
        print(f"{name}: shape={tuple(got.shape)} dtype={got.dtype} max_abs={max_abs:.6e}")
