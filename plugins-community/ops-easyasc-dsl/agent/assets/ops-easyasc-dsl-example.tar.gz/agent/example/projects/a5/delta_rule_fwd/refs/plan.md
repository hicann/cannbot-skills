# Decomposition Plan - delta_chunk_recurrence (ungated)

> Ungated delta-rule analogue of `projects/a5/gdn_fwd/refs/plan.md`. Covers the
> step-4 chunk recurrence only; the surrounding 4-step pipeline
> (preprocess -> tril_inverse64 -> recompute_wu -> chunk_delta) is shared with
> GDN and documented in the project README.

**Target.** `a5`
**Precision policy.** `loose` (atol=2e-3, rtol=2e-3, matmul_downcast=allow bf16)
**Shared oracle.** `../delta_rule_full.py::delta_rule_full_original_chunked`

## 1. Overview

The authored execution path handles the full C axis. Sub1 is a pure cube
producer for M1 (`q@k^T * causal_keep`) and folds C into the B*H*C parallel
axis. The recurrent state dependency requires M2-M5 to stay in one kernel, so
Sub2 owns the internal C loop and produces `core_attn_out` plus the final state.
The runnable compose path is Sub1 -> fused Sub2.

This is the GDN chunk-delta decomposition with the gate `g` removed. The split
(Sub1 cube producer + fused Sub2 recurrence) is identical; only the per-op math
changes, as summarized in section 5.

## 2. Oracle

- Shared end-to-end path: `../delta_rule_full.py` (the GDN reference minus `g`,
  validated bit-for-bit against GDN at `g == 0`).
- Candidate-local expected sub-kernel outputs: `oracle.py`.
- Tolerance budget enforced by `sub1_check.py`, `sub2_check.py`, and `compose.py`
  using `torch.allclose` semantics: `atol=2e-3`, `rtol=2e-3`.

## 3. DAG

```mermaid
graph LR
    Q[query] --> K1[sub1: cube<br/>M1 over B*H*C]
    K[key] --> K1
    K1 --> W1[attn GM]
    W1 --> K2[sub2: cube->vec->cube<br/>M2-M5 internal C loop]
    Q --> K2
    K --> K2
    V[value_wu] --> K2
    KC[k_cumdecay] --> K2
    K2 -- "state bridge inside C loop" --> K2
    K2 --> O1[core_attn_out]
    K2 --> O2[final_recurrent_state]
    K2 --> O3[state_after_history]
    K2 --> O4[v_new_history]
```

Machine-readable: `dag.json`

**Nodes.**

| node | pipe | memory | dtype_in | dtype_compute | dtype_out | producer | consumer |
|------|------|--------|----------|---------------|-----------|----------|----------|
| sub1 | cube | L0C/UB | bf16/fp32 | bf16 matmul / fp32 accum / vec mask | bf16 | user:query,key | sub2 |
| sub2 | cube->vec->cube | L0C/UB/L1 | bf16/fp32 | bf16 matmul / fp32 accum / vec | bf16 | sub1:attn,user:query,key,value_wu,k_cumdecay,initial_state | user:core_attn_out,final_state,state_after_history,v_new_history |

**Edges.**

| src -> dst | via | dtype | sync |
|------------|-----|-------|------|
| sub1 -> sub2 | attn (GM) | bf16 | kernel boundary |
| sub2(c-1) -> sub2(c) | recurrent state inside kernel | bf16 | kernel order |

## 4. Sub-kernels

| sub | file | I/O contract | primitives |
|-----|------|--------------|------------|
| sub1 | `sub1_ref.py` | (query,key:[B,H,C,64,128]bf16) -> attn:[B,H,C,64,64]bf16 | [P6, L1] |
| sub2 | `sub2_ref.py` | (attn,query,key,value_wu,k_cumdecay,state0) -> (core_attn_out:[B,H,C,64,128]bf16, final_state:[B,H,128,128]bf16; state-history path also returns state_after_history:[B,H,C,128,128]bf16 and v_new_history:[B,H,C,64,128]bf16) | [P6, P2, L1, L3] |

Expected-output helpers: `oracle.py`.

### 4.1 Axis classification

| symbol | category | binding | range / hint | parallel_axis? |
|--------|----------|---------|--------------|----------------|
| B | runtime variable | Var_0 | typical 1-32 | part of B*H |
| H | runtime variable | Var_1 | typical 1-32 | part of B*H |
| C | runtime variable | Var_2 | typical 1-8 | sub1 parallel / sub2 loop |
| L | compile-time constant | literal 64 | fixed | |
| D | compile-time constant | literal 128 | fixed | |

## 5. What changed vs GDN (gate removed)

| GDN op | ungated delta-rule op |
|--------|------------------------|
| sub1: `attn = q@k^T * decay_mask` (data-dependent) | `attn = q@k^T * causal_keep` (constant `tril(ones)`); no `decay_mask` input |
| sub2 inter: `attn_inter = (q * exp(g_cumsum)) @ S` | `attn_inter = q @ S` |
| sub2 state: `S = S*exp(g_last) + (k*exp(g_last-g_cumsum))^T @ v_new` | `S = S + k^T @ v_new` |
| saved `k_weighted_history` = `k*exp(g_last-g_cumsum)` | degenerates to raw key — not re-emitted |
| saved `exp_delta_history` = `exp(g_last-g_cumsum)` | degenerates to all-ones — not re-emitted |

`v_beta`/`k_beta`, the strict-lower `A`, the `(I-A)^-1` substitution, `u`, and
the `o = attn_inter + (q@k^T ⊙ causal) @ v_new` structure are unchanged.

## 6. Lossy Operations Ledger

| location | transform | dtype in -> compute | measured |
|----------|-----------|---------------------|----------|
| sub1.M1 | matmul downcast (L1) | bf16 -> fp32 (L0C fp32) | 0 |
| sub2.M2 | matmul downcast (L1) | bf16 -> fp32 (L0C fp32) | 0 |
| sub2.M3 | matmul downcast (L1) | bf16 -> fp32 (L0C fp32) | 0 |
| sub2.v_new | explicit cast (L3) | fp32 -> bf16 | 0 |
| sub2.M4 | matmul downcast (L1) | bf16 -> fp32 (L0C fp32) | 0 |
| sub2.M5 | bf16-round key before L1 | fp32 -> bf16 -> fp32 matmul | 0 |

**Composed worst-case.** measured (`compose.py`) = 0. Within budget: YES.

## 7. Verification Summary

**Per sub-kernel (CPU PyTorch).**

| sub | check script | N samples | atol | rtol | pass |
|-----|--------------|-----------|------|------|------|
| sub1 | `sub1_check.py` | 2x32 | 0.000e+00 | 0.000e+00 | YES |
| sub2 | `sub2_check.py` | 2x32 | 0.000e+00 | 0.000e+00 | YES |

**End-to-end (`compose.py`).**

| N samples | atol | rtol | pass |
|-----------|------|------|------|
| 2x32 | 0.000e+00 | 0.000e+00 | YES |

## 8. Scope Boundary

This plan covers the step-4 chunk recurrence decomposition. The DSL kernels
(`kernels/`) and the simulator-vs-ref checks (`test_script/`) are tracked
separately; `tril_inverse64` (step 2) is reused verbatim from GDN because it is
gate-independent.
