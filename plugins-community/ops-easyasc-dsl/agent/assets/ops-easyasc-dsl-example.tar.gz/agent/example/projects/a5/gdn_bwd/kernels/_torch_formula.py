"""Project-local PyTorch formulas used by the canonical gdn_bwd kernel wrappers.

These helpers intentionally do not import the refs directory. They mirror the
verified decomposition contract so the plan-local deliverable stays movable.
"""

import torch


L = 64
D = 128


def _strict_lower(device):
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device), diagonal=-1)


def _reverse_cumsum(x):
    return torch.flip(torch.cumsum(torch.flip(x, dims=(-1,)), dim=-1), dims=(-1,))


def _f32(x):
    return x if x.dtype == torch.float32 else x.float()


def _bf16_cube_operand(x):
    return x.to(torch.bfloat16).float()


def _bf16_cube_mm(lhs, rhs):
    """A5 cube contract for this plan: bf16 inputs, fp32 accumulation/output."""
    return _bf16_cube_operand(lhs) @ _bf16_cube_operand(rhs)


def core_scan_bwd(query, key, grad_output, g_cumsum, decay_mask, value_wu, k_cumdecay, state_after_history, grad_final_state):
    B, H, C, _, _ = query.shape
    q = _bf16_cube_operand(query)
    k = _bf16_cube_operand(key)
    g_cumsum = g_cumsum.float()
    decay_mask = decay_mask.float()
    value_wu = _bf16_cube_operand(value_wu)
    k_cumdecay = _bf16_cube_operand(k_cumdecay)
    state_after_history = _bf16_cube_operand(state_after_history)
    final_state = state_after_history[:, :, C - 1]
    d_state = grad_final_state.float()
    d_core = _bf16_cube_operand(grad_output)

    d_q = torch.zeros_like(q)
    d_k = torch.zeros_like(k)
    d_g_cumsum = torch.zeros_like(g_cumsum)
    d_decay_mask = torch.zeros_like(decay_mask)
    d_value_wu = torch.zeros_like(value_wu)
    d_k_cumdecay = torch.zeros_like(k_cumdecay)

    for c in range(C - 1, -1, -1):
        state = torch.zeros_like(final_state) if c == 0 else state_after_history[:, :, c - 1]
        q_i = q[:, :, c]
        k_i = k[:, :, c]
        d_out = d_core[:, :, c]
        g_i = g_cumsum[:, :, c]
        score_qk = _bf16_cube_mm(q_i, k_i.transpose(-1, -2))
        attn = score_qk * decay_mask[:, :, c]
        v_new = value_wu[:, :, c] - _bf16_cube_mm(k_cumdecay[:, :, c], state)
        exp_g_i = g_i.exp()
        q_exp = q_i * exp_g_i.unsqueeze(-1)
        exp_g_last = g_i[:, :, -1].exp()
        exp_delta = (g_i[:, :, -1].unsqueeze(-1) - g_i).exp()
        k_weighted = k_i * exp_delta.unsqueeze(-1)

        d_q_exp = _bf16_cube_mm(d_out, state.transpose(-1, -2))
        d_state_in = _bf16_cube_mm(q_exp.transpose(-1, -2), d_out) + d_state * exp_g_last[:, :, None, None]
        d_attn = _bf16_cube_mm(d_out, v_new.transpose(-1, -2))
        d_v_new = _bf16_cube_mm(attn.transpose(-1, -2), d_out)
        d_exp_g_last = (d_state * state).sum(dim=(-1, -2))
        d_k_weighted = _bf16_cube_mm(v_new, d_state.transpose(-1, -2))
        d_v_new = d_v_new + _bf16_cube_mm(k_weighted, d_state)

        d_value_wu[:, :, c] = d_value_wu[:, :, c] + d_v_new
        d_v_prime = -d_v_new
        d_k_cumdecay[:, :, c] = d_k_cumdecay[:, :, c] + _bf16_cube_mm(d_v_prime, state.transpose(-1, -2))
        d_state_in = d_state_in + _bf16_cube_mm(k_cumdecay[:, :, c].transpose(-1, -2), d_v_prime)

        d_score_qk = d_attn * decay_mask[:, :, c]
        d_decay_mask[:, :, c] = d_decay_mask[:, :, c] + d_attn * score_qk
        d_q[:, :, c] = d_q[:, :, c] + _bf16_cube_mm(d_score_qk, k_i) + d_q_exp * exp_g_i.unsqueeze(-1)
        d_k[:, :, c] = d_k[:, :, c] + _bf16_cube_mm(d_score_qk.transpose(-1, -2), q_i)
        d_g_cumsum[:, :, c] = d_g_cumsum[:, :, c] + (d_q_exp * q_i).sum(dim=-1) * exp_g_i

        d_k[:, :, c] = d_k[:, :, c] + d_k_weighted * exp_delta.unsqueeze(-1)
        d_delta = (d_k_weighted * k_i).sum(dim=-1) * exp_delta
        d_g_cumsum[:, :, c] = d_g_cumsum[:, :, c] - d_delta
        d_g_cumsum[:, :, c, -1] = d_g_cumsum[:, :, c, -1] + d_exp_g_last * exp_g_last + d_delta.sum(dim=-1)
        d_state = d_state_in

    return d_q, d_k, d_g_cumsum, d_decay_mask, d_value_wu, d_k_cumdecay


def wu_recompute_bwd(key, value, beta, g_cumsum, wu_attn_bf16, d_value_wu, d_k_cumdecay):
    k = _bf16_cube_operand(key)
    v = _bf16_cube_operand(value)
    beta_f = beta.float()
    g_cumsum = g_cumsum.float()
    wu_attn = _bf16_cube_operand(wu_attn_bf16)
    d_value_wu = d_value_wu.float()
    d_k_cumdecay = d_k_cumdecay.float()

    exp_g_cumsum = g_cumsum.exp()
    k_beta = k * beta_f.unsqueeze(-1)
    v_beta = v * beta_f.unsqueeze(-1)
    k_beta_g = k_beta * exp_g_cumsum.unsqueeze(-1)

    d_wu = _bf16_cube_mm(d_value_wu, v_beta.transpose(-1, -2)) + _bf16_cube_mm(d_k_cumdecay, k_beta_g.transpose(-1, -2))
    d_wu = d_wu.to(torch.bfloat16)
    d_v_beta = _bf16_cube_mm(wu_attn.transpose(-1, -2), d_value_wu)
    d_k_beta_g = _bf16_cube_mm(wu_attn.transpose(-1, -2), d_k_cumdecay)
    d_k_beta = d_k_beta_g * exp_g_cumsum.unsqueeze(-1)
    d_g_cumsum = (d_k_beta_g * k_beta).sum(dim=-1) * exp_g_cumsum
    return d_wu, d_v_beta, d_k_beta, d_g_cumsum


def inverse_preprocess_bwd(key, beta, decay_mask, wu_attn_bf16, d_wu):
    k = _bf16_cube_operand(key)
    beta_f = beta.float()
    decay_mask = decay_mask.float()
    wu_attn = _bf16_cube_operand(wu_attn_bf16)
    d_wu = d_wu.float()
    k_beta = k * beta_f.unsqueeze(-1)
    preprocess_score = _bf16_cube_mm(k_beta, k.transpose(-1, -2))

    d_attn_pre = _bf16_cube_mm(_bf16_cube_mm(wu_attn.transpose(-1, -2), d_wu), wu_attn.transpose(-1, -2))
    strict = _strict_lower(key.device)
    d_score_pre = -d_attn_pre * decay_mask * strict
    d_decay_mask = -d_attn_pre * preprocess_score * strict
    d_decay_masked = d_decay_mask * decay_mask
    d_k_beta = _bf16_cube_mm(d_score_pre, k)
    d_k = _bf16_cube_mm(d_score_pre.transpose(-1, -2), k_beta)
    return d_k, d_k_beta, d_decay_mask, d_decay_masked


def finalize_grads(key, value, beta, decay_mask, d_q, d_k_core, d_g_core, d_decay_core, d_v_beta, d_k_beta_wu, d_g_wu, d_k_pre, d_k_beta_pre, d_decay_pre):
    k = _f32(key)
    v = _f32(value)
    beta_f = beta.float()
    decay_mask = decay_mask.float()
    d_k = d_k_core.float() + d_k_pre.float()
    d_g_cumsum = d_g_core.float() + d_g_wu.float()
    d_decay_mask = d_decay_core.float() + d_decay_pre.float()
    d_k_beta = d_k_beta_wu.float() + d_k_beta_pre.float()
    d_v_beta = d_v_beta.float()

    d_g_cumsum = d_g_cumsum + (d_decay_mask * decay_mask).sum(dim=-1) - (d_decay_mask * decay_mask).sum(dim=-2)
    d_v = d_v_beta * beta_f.unsqueeze(-1)
    d_beta = (d_v_beta * v).sum(dim=-1)
    d_k = d_k + d_k_beta * beta_f.unsqueeze(-1)
    d_beta = d_beta + (d_k_beta * k).sum(dim=-1)
    return d_q.float(), d_k, d_v, d_beta, _reverse_cumsum(d_g_cumsum)
