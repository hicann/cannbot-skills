"""Smoke-check the finalize stage wrapper against direct stage composition."""

from common import (
    _check_close,
    build_saved_forward,
    finalize_bwd,
    inverse_bwd,
    make_inputs,
    outputs_as_tuple,
    outputs_from_tuple,
    scan_bwd,
)
from finalize_bwd_ref import subkernel


def main():
    inputs = make_inputs(B=1, H=2, HV=4, T=10, K=8, V=6, chunk_size=4, seed=17)
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    scan = scan_bwd(inputs.do, inputs.dht, caches, inputs.chunk_size)
    local = inverse_bwd(inputs.q, inputs.k, inputs.v, inputs.beta, inputs.do, caches, scan, inputs.chunk_size)
    expected = finalize_bwd(inputs.q, inputs.k, inputs.beta, caches.g_cumsum, scan.dAqk, local, scan.dh0, inputs.chunk_size)
    actual = outputs_from_tuple(
        subkernel(
            inputs.q,
            inputs.k,
            inputs.beta,
            caches.g_cumsum,
            scan.dAqk,
            local.dq_hv,
            local.dk_hv,
            local.dv,
            local.dbeta,
            local.dg_core,
            local.dAkk,
            scan.dh0,
            inputs.chunk_size,
        )
    )
    for name, got, ref in zip(("dq", "dk", "dv", "dbeta", "dg", "dh0"), outputs_as_tuple(actual), outputs_as_tuple(expected)):
        _check_close(name, got, ref, 1e-6, 1e-6)
    print("finalize_bwd_check: OK")


if __name__ == "__main__":
    main()
