"""Pure PyTorch reference for inverse and preprocess backward products."""

from common import inverse_preprocess_bwd, make_inputs


def subkernel(key, beta, decay_mask, wu_attn_bf16, d_wu):
    return inverse_preprocess_bwd(key, beta, decay_mask, wu_attn_bf16, d_wu)


if __name__ == "__main__":
    args = make_inputs()
    scan = __import__("scan_bwd_ref").subkernel(args[0], args[1], args[5], args[6], args[7], args[10], args[11], args[12], args[13], args[14])
    wu = __import__("wu_bwd_ref").subkernel(args[1], args[2], args[3], args[6], args[8], scan[4], scan[5])
    result = subkernel(args[1], args[3], args[7], args[8], wu[0])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
