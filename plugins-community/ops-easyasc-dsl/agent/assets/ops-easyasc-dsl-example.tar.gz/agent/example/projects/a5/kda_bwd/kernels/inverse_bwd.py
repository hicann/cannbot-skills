"""Inverse stage driver -- pure kernel plumbing, no host math.

Chains the four inverse-stage kernels:

    inverse_mm        -> d_qg, d_kg, d_w, d_v_beta, d_k_beta_g
    inverse_epilogue  -> dq_hv, dk_hv, dv, dbeta, dg_core, k_exp
    inverse_dainv     -> D_tri
    inverse_dakk      -> dAkk

The former host triple loop (elementwise grads + dA_inv + D_tri tril) now lives
inside `inverse_epilogue` and `inverse_dainv`; `inverse_dakk` masks dAkk
in-kernel. The only host work left is dtype/layout plumbing between kernels.
"""

from pathlib import Path

import torch

from inverse_mm import run as run_inverse_mm
from inverse_epilogue import run as run_inverse_epilogue
from inverse_dainv import run as run_inverse_dainv
from inverse_dakk_fused import run as run_inverse_dakk
from _torch_formula import L, build_saved_forward, inverse_bwd as inverse_ref, scan_bwd


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "kda_bwd_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def _child_out_dir(out_dir, name):
    if not out_dir:
        return ""
    path = Path(out_dir) / name
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def run(q, k, v, beta, do, g_cumsum, v_new, h, dh, dv, Akk, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    common = dict(simulator=simulator, gen_only=gen_only, skip_compile=skip_compile, profile=profile)

    # Pure plumbing: every inverse kernel reads/writes the frozen public layout
    # directly (strided on-device; q/k gathered H->HV in-kernel). Internal
    # hand-offs (d_qg.., d_w, k_exp, d_tri) stay GM-native. The only host op is the
    # free [B,HV,C,L,L]->[B,HV,T,L] reshape between inverse_dainv and inverse_dakk.
    B, T, H, _ = q.shape
    HV = v.shape[2]

    d_qg, d_kg, d_w, d_v_beta, d_k_beta_g = run_inverse_mm(
        do, v_new, dv, h, dh, Akk,
        trace=_child_trace(trace, out_dir, "inverse_mm"),
        out_dir=_child_out_dir(out_dir, "inverse_mm"), **common,
    )

    dq_hv, dk_hv, dv_out, dbeta, dg_core, k_exp = run_inverse_epilogue(
        d_qg, d_kg, d_v_beta, d_k_beta_g, q, k, v, g_cumsum, beta, h, dh,
        trace=_child_trace(trace, out_dir, "inverse_epilogue"),
        out_dir=_child_out_dir(out_dir, "inverse_epilogue"), **common,
    )

    d_tri = run_inverse_dainv(
        dv, v, d_w, k_exp, beta,
        trace=_child_trace(trace, out_dir, "inverse_dainv"),
        out_dir=_child_out_dir(out_dir, "inverse_dainv"), **common,
    )

    # inverse_dainv emits [B, HV, C, L, L]; inverse_dakk wants the token-major
    # [B, HV, T, L] -- a free reshape (C, L are adjacent and contiguous).
    d_tri_tl = d_tri.view(B, HV, T, L)
    d_akk = run_inverse_dakk(
        Akk, d_tri_tl,
        trace=_child_trace(trace, out_dir, "inverse_dakk"),
        out_dir=_child_out_dir(out_dir, "inverse_dakk"), **common,
    )

    # All six outputs are already public (kernels wrote them strided on-device):
    # dq_hv/dk_hv/dv (-> public dv)/dg_core BTHVD, dbeta BTHV fp32, dAkk BTHVL.
    return dq_hv, dk_hv, dv_out, dbeta, dg_core, d_akk


if __name__ == "__main__":
    import torch
    from projects.a5.kda_bwd.refs.common import make_inputs

    tol = 7e-3
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    caches = build_saved_forward(inputs)
    scan = scan_bwd(inputs, caches)
    got = run(inputs.q, inputs.k, inputs.v, inputs.beta, inputs.do, caches.g_cumsum, caches.v_new, caches.h, scan.dh, scan.dv, caches.Akk, simulator=True)
    exp = inverse_ref(inputs, caches, scan)
    names = ("dq_hv", "dk_hv", "dv", "dbeta", "dg_core", "dAkk")
    for name, g, r in zip(names, got, (exp.dq_hv, exp.dk_hv, exp.dv, exp.dbeta, exp.dg_core, exp.dAkk)):
        torch.testing.assert_close(g.float(), r.float(), rtol=tol, atol=tol)
        print(f"{name}: max_abs={(g.float() - r.float()).abs().max().item():.3e} OK")
    print([tuple(item.shape) for item in got], [item.dtype for item in got])
