"""Kernel-aligned full GDN path for the a5 project kernels.

This file is intentionally chunked-first.  The real kernels under
`projects/a5/gdn_fwd/` already operate on `[B, H, C, 64, 128]` tensors, so this
path does not reshape raw sequence-layout inputs into chunks.  Do that at the
caller boundary if needed.
"""

import argparse
import sys
from pathlib import Path
from typing import Optional, Tuple

import torch

_ROOT = Path(__file__).resolve().parents[3]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from projects.a5.gdn_fwd.kernels.gdn_preprocess import gdn_preprocess_v2
from projects.a5.gdn_fwd.kernels.gdn_recompute_wu import gdn_recompute_wu
from projects.a5.gdn_fwd.kernels.tril_inverse64 import inverse_from_strict_lower_a
from projects.a5.gdn_fwd.refs.oracle import (
    oracle_full as chunk_delta_ref,
    oracle_full_state_history as chunk_delta_ref_state_history,
)


L = 64
D = 128
ATOL = 2e-3
RTOL = 2e-3
DEFAULT_KERNEL_OUT_DIR = "tmp/gdn_full_kernels"

INPUT_CONTRACT = {
    "query": "torch.bfloat16 [B, H, C, 64, 128]",
    "key": "torch.bfloat16 [B, H, C, 64, 128]",
    "value": "torch.bfloat16 [B, H, C, 64, 128]",
    "beta": "torch.float32 [B, H, C, 64]",
    "g": "torch.float32 [B, H, C, 64], raw per-token gate log value, not cumsum",
    "initial_state": "None or zero torch.bfloat16 [B, H, 128, 128]",
}

INTERMEDIATE_CONTRACT = {
    "g_cumsum": "torch.float32 [B, H, C, 64]",
    "decay_mask": "torch.float32 [B, H, C, 64, 64]",
    "preprocess_attn": "torch.float32 [B, H, C, 64, 64], strict-lower A",
    "wu_attn_fp32": "torch.float32 [B, H, C, 64, 64], inverse(I - A)",
    "wu_attn_bf16": "torch.bfloat16 [B, H, C, 64, 64], recompute-WU GM boundary",
    "value_wu": "torch.bfloat16 [B, H, C, 64, 128]",
    "k_cumdecay": "torch.bfloat16 [B, H, C, 64, 128]",
    "state_after_history": "torch.bfloat16 [B, H, C, 128, 128], post-update state after each chunk",
    "v_new_history": "torch.bfloat16 [B, H, C, 64, 128], per-chunk post-decay value consumed by backward",
    "k_weighted_history": "torch.bfloat16 [B, H, C, 64, 128], per-chunk gated key consumed by backward",
    "exp_delta_history": "torch.float32 [B, H, C, 64], per-chunk exp(g_last - g) consumed by backward",
    "chunk_attn": "internal chunk-delta sub1 bf16 [B, H, C, 64, 64]",
}

PRECISION_BOUNDARIES = (
    "preprocess: key/key cube inputs are bf16; score accumulates in fp32; beta is applied in fp32.",
    "tril_inverse64: strict-lower preprocess_attn stays fp32 through inverse(I - A).",
    "recompute_wu boundary: inverse attention is rounded to bf16 before entering the bf16 L1 matmuls.",
    "recompute_wu: value*beta and key*beta*exp(g_cumsum) are rounded to bf16 before cube matmuls.",
    "chunk_delta sub1: query/key matmul accumulates fp32, multiplies fp32 decay_mask, then stores bf16 attn.",
    "chunk_delta sub2: v_new, per-chunk output, k_weighted, and recurrent state are rounded to bf16 at kernel boundaries.",
)


def _check_shape(name: str, tensor: torch.Tensor, shape: Tuple[int, ...]) -> None:
    if tuple(tensor.shape) != shape:
        raise ValueError(f"{name} shape must be {shape}, got {tuple(tensor.shape)}")


def _check_dtype(name: str, tensor: torch.Tensor, dtype: torch.dtype) -> None:
    if tensor.dtype != dtype:
        raise TypeError(f"{name} dtype must be {dtype}, got {tensor.dtype}")


def _check_chunked_inputs(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor],
) -> Tuple[int, int, int]:
    if query.ndim != 5:
        raise ValueError(f"query must be [B,H,C,{L},{D}], got {tuple(query.shape)}")

    B, H, C, length_per_chunk, head_dim = (int(x) for x in query.shape)
    if length_per_chunk != L or head_dim != D:
        raise ValueError(f"this path is specialized for L={L}, D={D}; got L={length_per_chunk}, D={head_dim}")
    if B <= 0 or H <= 0 or C <= 0:
        raise ValueError(f"B/H/C must be positive, got B={B}, H={H}, C={C}")

    qkv_shape = (B, H, C, L, D)
    scalar_shape = (B, H, C, L)
    state_shape = (B, H, D, D)

    for name, tensor in (("query", query), ("key", key), ("value", value)):
        _check_shape(name, tensor, qkv_shape)
        _check_dtype(name, tensor, torch.bfloat16)

    for name, tensor in (("beta", beta), ("g", g)):
        _check_shape(name, tensor, scalar_shape)
        _check_dtype(name, tensor, torch.float32)

    devices = {tensor.device for tensor in (query, key, value, beta, g)}
    if len(devices) != 1:
        raise ValueError(f"all inputs must be on one device, got {sorted(str(device) for device in devices)}")

    if initial_state is not None:
        _check_shape("initial_state", initial_state, state_shape)
        _check_dtype("initial_state", initial_state, torch.bfloat16)
        if initial_state.device != query.device:
            raise ValueError(f"initial_state device must be {query.device}, got {initial_state.device}")
        if not torch.count_nonzero(initial_state).eq(0).item():
            raise NotImplementedError("chunk-delta currently matches the zero-initial-state kernel path only")

    return B, H, C


def _triu(device: torch.device) -> torch.Tensor:
    return torch.triu(torch.ones(L, L, dtype=torch.float32, device=device))


def _stage_out_dir(root: str, stage: str) -> str:
    return str(Path(root or DEFAULT_KERNEL_OUT_DIR) / stage)


def gdn_full_original_chunked(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    sequence_length: Optional[int] = None,
    return_chunked: bool = True,
    return_intermediates: bool = False,
):
    """Original full PyTorch path, kept beside the kernel-aligned rewrite.

    This mirrors the code pasted at the start, but starts from chunked tensors
    so it can be compared directly with the current project kernels.
    """
    _check_chunked_inputs(query, key, value, beta, g, None)
    B, H, C, _, _ = query.shape
    if initial_state is not None:
        _check_shape("initial_state", initial_state, (B, H, D, D))
        if initial_state.device != query.device:
            raise ValueError(f"initial_state device must be {query.device}, got {initial_state.device}")

    initial_dtype = query.dtype
    v_beta = value * beta.unsqueeze(-1)
    k_beta = key * beta.unsqueeze(-1)

    mask = torch.triu(torch.ones(L, L, dtype=torch.bool, device=query.device), diagonal=0)

    g_cumsum = g.cumsum(dim=-1)
    decay_mask = ((g_cumsum.unsqueeze(-1) - g_cumsum.unsqueeze(-2)).tril().exp().float()).tril()
    preprocess_attn = -((k_beta.float() @ key.float().transpose(-1, -2)) * decay_mask).masked_fill(mask, 0)

    wu_attn = preprocess_attn.clone()
    for row_idx in range(1, L):
        row = wu_attn[..., row_idx, :row_idx].clone()
        sub = wu_attn[..., :row_idx, :row_idx].clone()
        wu_attn[..., row_idx, :row_idx] = row + (row.unsqueeze(-1) * sub).sum(-2)
    wu_attn = wu_attn + torch.eye(L, dtype=wu_attn.dtype, device=wu_attn.device)

    value_wu = wu_attn @ v_beta
    k_cumdecay = wu_attn @ (k_beta * g_cumsum.exp().unsqueeze(-1))
    last_recurrent_state = (
        torch.zeros(B, H, D, D, dtype=value_wu.dtype, device=value_wu.device)
        if initial_state is None
        else initial_state.to(value_wu)
    )
    core_attn_out = torch.zeros_like(value_wu)

    for chunk_idx in range(C):
        q_i = query[:, :, chunk_idx]
        k_i = key[:, :, chunk_idx]
        v_i = value_wu[:, :, chunk_idx]
        attn = q_i @ k_i.transpose(-1, -2) * decay_mask[:, :, chunk_idx]
        v_prime = k_cumdecay[:, :, chunk_idx] @ last_recurrent_state
        v_new = v_i - v_prime
        attn_inter = (q_i.float() * g_cumsum[:, :, chunk_idx, :, None].exp()) @ last_recurrent_state
        core_attn_out[:, :, chunk_idx] = attn_inter + attn @ v_new
        last_recurrent_state = (
            last_recurrent_state * g_cumsum[:, :, chunk_idx, -1, None, None].exp()
            + (
                k_i.float()
                * (g_cumsum[:, :, chunk_idx, -1, None] - g_cumsum[:, :, chunk_idx]).exp()[..., None]
            ).transpose(-1, -2)
            @ v_new
        )

    if not output_final_state:
        last_recurrent_state = None

    if return_chunked:
        output = core_attn_out.to(initial_dtype)
    else:
        seq_len = C * L if sequence_length is None else sequence_length
        if seq_len < 0 or seq_len > C * L:
            raise ValueError(f"sequence_length must be in [0, {C * L}], got {seq_len}")
        output = core_attn_out.reshape(B, H, C * L, D)
        output = output[:, :, :seq_len]
        output = output.transpose(1, 2).contiguous().to(initial_dtype)

    if not return_intermediates:
        return output, last_recurrent_state

    intermediates = {
        "g_cumsum": g_cumsum,
        "decay_mask": decay_mask,
        "preprocess_attn": preprocess_attn,
        "wu_attn_fp32": wu_attn,
        "value_wu": value_wu,
        "k_cumdecay": k_cumdecay,
    }
    return output, last_recurrent_state, intermediates


def gdn_full_original_sequence(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    sequence_length: Optional[int] = None,
    chunk_size: int = L,
):
    """Original pasted path with the input-side sequence -> chunk reshape."""
    if chunk_size != L:
        raise ValueError(f"current kernel comparison path is specialized for chunk_size={L}, got {chunk_size}")
    if query.ndim != 4:
        raise ValueError(f"query must be [B,H,S,D], got {tuple(query.shape)}")
    if tuple(key.shape) != tuple(query.shape) or tuple(value.shape) != tuple(query.shape):
        raise ValueError("query/key/value must have identical [B,H,S,D] shapes")
    B, H, total_sequence_length, head_dim = (int(x) for x in query.shape)
    if head_dim != D:
        raise ValueError(f"this path is specialized for D={D}, got {head_dim}")
    if total_sequence_length % L != 0:
        raise ValueError(f"total_sequence_length must be divisible by {L}, got {total_sequence_length}")
    if tuple(beta.shape) != (B, H, total_sequence_length) or tuple(g.shape) != (B, H, total_sequence_length):
        raise ValueError("beta/g must be [B,H,S]")

    q_chunks = query.reshape(B, H, -1, L, D)
    k_chunks = key.reshape(B, H, -1, L, D)
    v_chunks = value.reshape(B, H, -1, L, D)
    beta_chunks = beta.reshape(B, H, -1, L)
    g_chunks = g.reshape(B, H, -1, L)
    return gdn_full_original_chunked(
        q_chunks,
        k_chunks,
        v_chunks,
        beta_chunks,
        g_chunks,
        initial_state=initial_state,
        output_final_state=output_final_state,
        sequence_length=total_sequence_length if sequence_length is None else sequence_length,
        return_chunked=False,
    )


def gdn_full_chunked(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    return_intermediates: bool = False,
):
    """Run the complete current a5 GDN computation path on chunked inputs.

    Inputs are already in kernel layout:
      query/key/value: [B, H, C, 64, 128] bf16
      beta/g:          [B, H, C, 64] fp32

    Returns:
      core_attn_out: [B, H, C, 64, 128] bf16
      final_state:   [B, H, 128, 128] bf16, or None
      intermediates: optional dict for checking kernel handoff tensors
    """
    _check_chunked_inputs(query, key, value, beta, g, initial_state)

    # Stage 1: gdn_preprocess.  This is the current project semantic path:
    # score = key@key.T first, then row-wise beta in fp32.
    g_cumsum, decay_mask, preprocess_attn = gdn_preprocess_v2(key, beta, g, _triu(query.device))

    # Stage 2: tril_inverse64 consumes the strict-lower A and computes
    # inverse(I - A).  The recompute-WU kernel receives this through bf16 L1.
    wu_attn_fp32 = inverse_from_strict_lower_a(preprocess_attn)
    wu_attn_bf16 = wu_attn_fp32.to(torch.bfloat16)

    # Stage 3: recompute-WU.  Full-path g here is the per-chunk cumsum from
    # preprocess, matching the original algorithm after `g = g.cumsum(dim=-1)`.
    value_wu, k_cumdecay = gdn_recompute_wu(key, value, beta, g_cumsum, wu_attn_bf16)

    # Stage 4: chunk-delta.  It recomputes query@key.T*decay_mask as sub1
    # and runs the recurrent C loop in sub2.
    core_attn_out, final_state = chunk_delta_ref(query, key, value_wu, g_cumsum, decay_mask, k_cumdecay)
    if not output_final_state:
        final_state = None

    if not return_intermediates:
        return core_attn_out, final_state

    intermediates = {
        "g_cumsum": g_cumsum,
        "decay_mask": decay_mask,
        "preprocess_attn": preprocess_attn,
        "wu_attn_fp32": wu_attn_fp32,
        "wu_attn_bf16": wu_attn_bf16,
        "value_wu": value_wu,
        "k_cumdecay": k_cumdecay,
    }
    return core_attn_out, final_state, intermediates


def gdn_full_chunked_state_history(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    return_intermediates: bool = False,
):
    """Reference full path that also returns chunk-delta post-update state history."""
    _check_chunked_inputs(query, key, value, beta, g, initial_state)

    g_cumsum, decay_mask, preprocess_attn = gdn_preprocess_v2(key, beta, g, _triu(query.device))
    wu_attn_fp32 = inverse_from_strict_lower_a(preprocess_attn)
    wu_attn_bf16 = wu_attn_fp32.to(torch.bfloat16)
    value_wu, k_cumdecay = gdn_recompute_wu(key, value, beta, g_cumsum, wu_attn_bf16)
    core_attn_out, final_state, state_after_history, v_new_history, k_weighted_history, exp_delta_history = chunk_delta_ref_state_history(
        query, key, value_wu, g_cumsum, decay_mask, k_cumdecay
    )
    if not output_final_state:
        final_state = None

    if not return_intermediates:
        return core_attn_out, final_state, state_after_history

    intermediates = {
        "g_cumsum": g_cumsum,
        "decay_mask": decay_mask,
        "preprocess_attn": preprocess_attn,
        "wu_attn_fp32": wu_attn_fp32,
        "wu_attn_bf16": wu_attn_bf16,
        "value_wu": value_wu,
        "k_cumdecay": k_cumdecay,
        "state_after_history": state_after_history,
        "v_new_history": v_new_history,
        "k_weighted_history": k_weighted_history,
        "exp_delta_history": exp_delta_history,
    }
    return core_attn_out, final_state, state_after_history, intermediates


def gdn_full_chunked_kernels(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    return_intermediates: bool = False,
    trace=None,
    on_npu: bool = False,
    out_dir: str = "",
):
    """Run the same chunked path through the existing kernel wrappers."""
    _check_chunked_inputs(query, key, value, beta, g, initial_state)
    simulator = not on_npu
    profile = bool(on_npu)

    from projects.a5.gdn_fwd.kernels.gdn_preprocess import run_kernel as run_preprocess_kernel
    from projects.a5.gdn_fwd.kernels.gdn_recompute_wu import run_kernel as run_recompute_wu_kernel
    from projects.a5.gdn_fwd.kernels.tril_inverse64 import inverse_from_strict_lower_a_bf16_a5_v2
    from projects.a5.gdn_fwd.kernels.chunk_delta_compose import run as run_chunk_delta_kernel

    g_cumsum, decay_mask, preprocess_attn = run_preprocess_kernel(
        key, beta, g, _triu(query.device),
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "preprocess"),
    )
    wu_attn_bf16 = inverse_from_strict_lower_a_bf16_a5_v2(
        preprocess_attn,
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "tril_inverse64_strict_bf16"),
    )
    value_wu, k_cumdecay = run_recompute_wu_kernel(
        key, value, beta, g_cumsum, wu_attn_bf16,
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "recompute_wu"),
    )
    core_attn_out, final_state = run_chunk_delta_kernel(
        query, key, value_wu, g_cumsum, decay_mask, k_cumdecay,
        simulator=simulator,
        trace=trace,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "chunk_delta"),
    )
    if not output_final_state:
        final_state = None

    if not return_intermediates:
        return core_attn_out, final_state

    intermediates = {
        "g_cumsum": g_cumsum,
        "decay_mask": decay_mask,
        "preprocess_attn": preprocess_attn,
        "wu_attn_bf16": wu_attn_bf16,
        "value_wu": value_wu,
        "k_cumdecay": k_cumdecay,
    }
    return core_attn_out, final_state, intermediates


def gdn_full_chunked_kernels_state_history(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    return_intermediates: bool = False,
    trace=None,
    on_npu: bool = False,
    out_dir: str = "",
):
    """Kernel split path that also returns chunk-delta post-update state history."""
    _check_chunked_inputs(query, key, value, beta, g, initial_state)
    simulator = not on_npu
    profile = bool(on_npu)

    from projects.a5.gdn_fwd.kernels.gdn_preprocess import run_kernel as run_preprocess_kernel
    from projects.a5.gdn_fwd.kernels.gdn_recompute_wu import run_kernel as run_recompute_wu_kernel
    from projects.a5.gdn_fwd.kernels.tril_inverse64 import inverse_from_strict_lower_a_bf16_a5_v2
    from projects.a5.gdn_fwd.kernels.chunk_delta_compose_state_history import (
        run as run_chunk_delta_state_history_kernel,
    )

    g_cumsum, decay_mask, preprocess_attn = run_preprocess_kernel(
        key, beta, g, _triu(query.device),
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "preprocess"),
    )
    wu_attn_bf16 = inverse_from_strict_lower_a_bf16_a5_v2(
        preprocess_attn,
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "tril_inverse64_strict_bf16"),
    )
    value_wu, k_cumdecay = run_recompute_wu_kernel(
        key, value, beta, g_cumsum, wu_attn_bf16,
        simulator=simulator,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "recompute_wu"),
    )
    core_attn_out, final_state, state_after_history, v_new_history, k_weighted_history, exp_delta_history = run_chunk_delta_state_history_kernel(
        query, key, value_wu, g_cumsum, decay_mask, k_cumdecay,
        simulator=simulator,
        trace=trace,
        profile=profile,
        out_dir=_stage_out_dir(out_dir, "chunk_delta_state_history"),
    )
    if not output_final_state:
        final_state = None

    if not return_intermediates:
        return core_attn_out, final_state, state_after_history

    intermediates = {
        "g_cumsum": g_cumsum,
        "decay_mask": decay_mask,
        "preprocess_attn": preprocess_attn,
        "wu_attn_bf16": wu_attn_bf16,
        "value_wu": value_wu,
        "k_cumdecay": k_cumdecay,
        "state_after_history": state_after_history,
        "v_new_history": v_new_history,
        "k_weighted_history": k_weighted_history,
        "exp_delta_history": exp_delta_history,
    }
    return core_attn_out, final_state, state_after_history, intermediates


def GDN_full(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = True,
    sequence_length: Optional[int] = None,
    return_chunked: bool = True,
    return_intermediates: bool = False,
    state_after_history: bool = False,
):
    """Compatibility wrapper around the chunked kernel path.

    Set `return_chunked=False` only at the outer model boundary.  The internal
    path stays in `[B,H,C,64,128]`; no input-side reshape is done here.
    """
    full_fn = gdn_full_chunked_state_history if state_after_history else gdn_full_chunked
    result = full_fn(
        query, key, value, beta, g,
        initial_state=initial_state,
        output_final_state=output_final_state,
        return_intermediates=return_intermediates,
    )
    if state_after_history:
        if return_intermediates:
            core_attn_out, final_state, state_history, intermediates = result
        else:
            core_attn_out, final_state, state_history = result
            intermediates = None
    else:
        if return_intermediates:
            core_attn_out, final_state, intermediates = result
        else:
            core_attn_out, final_state = result
            intermediates = None
        state_history = None

    if return_chunked:
        output = core_attn_out
    else:
        B, H, C, _, _ = core_attn_out.shape
        output = core_attn_out.reshape(B, H, C * L, D)
        if sequence_length is not None:
            if sequence_length < 0 or sequence_length > C * L:
                raise ValueError(f"sequence_length must be in [0, {C * L}], got {sequence_length}")
            output = output[:, :, :sequence_length, :]
        output = output.transpose(1, 2).contiguous().to(query.dtype)

    if return_intermediates:
        if state_after_history:
            return output, final_state, state_history, intermediates
        return output, final_state, intermediates
    if state_after_history:
        return output, final_state, state_history
    return output, final_state


def make_inputs(B: int = 1, H: int = 2, C: int = 2, device: Optional[torch.device] = None):
    device = device or torch.device("cpu")
    query = (torch.randn(B, H, C, L, D, dtype=torch.float32, device=device) * 0.05).to(torch.bfloat16)
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32, device=device) * 0.05).to(torch.bfloat16)
    value = (torch.randn(B, H, C, L, D, dtype=torch.float32, device=device) * 0.05).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32, device=device)
    g = torch.log(torch.sigmoid(torch.randn(B, H, C, L, dtype=torch.float32, device=device)))
    return query, key, value, beta, g


def _error_stats(got: torch.Tensor, ref: torch.Tensor):
    got_f = got.float()
    ref_f = ref.float()
    diff = (got_f - ref_f).abs()
    max_abs = float(diff.max())
    max_rel = float((diff / ref_f.abs().clamp_min(1e-12)).max())
    ok = bool(torch.allclose(got_f, ref_f, atol=ATOL, rtol=RTOL))
    return max_abs, max_rel, ok


def _print_error_stats(title: str, pairs) -> None:
    print(title)
    for name, got, ref in pairs:
        max_abs, max_rel, ok = _error_stats(got, ref)
        status = "OK" if ok else "DIFF"
        print(f"  {name}: max_abs={max_abs:.3e} max_rel={max_rel:.3e} tol=({ATOL:.1e},{RTOL:.1e}) {status}")


def compare_original_vs_rewritten(B: int = 1, H: int = 2, C: int = 2, seed: int = 0) -> None:
    torch.manual_seed(seed)
    args = make_inputs(B=B, H=H, C=C)
    orig_core, orig_state, orig_mids = gdn_full_original_chunked(*args, return_intermediates=True)
    rewritten_core, rewritten_state, rewritten_mids = gdn_full_chunked(*args, return_intermediates=True)

    pairs = [
        ("core_attn_out", rewritten_core, orig_core),
        ("final_state", rewritten_state, orig_state),
        ("g_cumsum", rewritten_mids["g_cumsum"], orig_mids["g_cumsum"]),
        ("decay_mask", rewritten_mids["decay_mask"], orig_mids["decay_mask"]),
        ("preprocess_attn", rewritten_mids["preprocess_attn"], orig_mids["preprocess_attn"]),
        ("wu_attn_fp32", rewritten_mids["wu_attn_fp32"], orig_mids["wu_attn_fp32"]),
        ("value_wu", rewritten_mids["value_wu"], orig_mids["value_wu"]),
        ("k_cumdecay", rewritten_mids["k_cumdecay"], orig_mids["k_cumdecay"]),
    ]
    _print_error_stats("rewritten precision path vs original pasted full path", pairs)


def compare_rewritten_vs_kernel_split(
    B: int = 1,
    H: int = 1,
    C: int = 1,
    seed: int = 7,
    on_npu: bool = False,
    out_dir: str = "",
    state_after_history: bool = False,
) -> None:
    torch.manual_seed(seed)
    args = make_inputs(B=B, H=H, C=C)
    if state_after_history:
        ref_core, ref_state, ref_history, ref_mids = gdn_full_chunked_state_history(*args, return_intermediates=True)
        got_core, got_state, got_history, got_mids = gdn_full_chunked_kernels_state_history(
            *args,
            return_intermediates=True,
            on_npu=on_npu,
            out_dir=out_dir,
        )
    else:
        ref_core, ref_state, ref_mids = gdn_full_chunked(*args, return_intermediates=True)
        got_core, got_state, got_mids = gdn_full_chunked_kernels(
            *args,
            return_intermediates=True,
            on_npu=on_npu,
            out_dir=out_dir,
        )

    pairs = [
        ("core_attn_out", got_core, ref_core),
        ("final_state", got_state, ref_state),
        ("g_cumsum", got_mids["g_cumsum"], ref_mids["g_cumsum"]),
        ("decay_mask", got_mids["decay_mask"], ref_mids["decay_mask"]),
        ("preprocess_attn", got_mids["preprocess_attn"], ref_mids["preprocess_attn"]),
        ("wu_attn_bf16", got_mids["wu_attn_bf16"], ref_mids["wu_attn_bf16"]),
        ("value_wu", got_mids["value_wu"], ref_mids["value_wu"]),
        ("k_cumdecay", got_mids["k_cumdecay"], ref_mids["k_cumdecay"]),
    ]
    runner = "onboard" if on_npu else "simulator"
    title = f"{runner} kernel split vs rewritten precision path"
    if state_after_history:
        pairs.append(("state_after_history", got_history, ref_history))
        pairs.append(("v_new_history", got_mids["v_new_history"], ref_mids["v_new_history"]))
        pairs.append(("k_weighted_history", got_mids["k_weighted_history"], ref_mids["k_weighted_history"]))
        pairs.append(("exp_delta_history", got_mids["exp_delta_history"], ref_mids["exp_delta_history"]))
        title = f"{runner} kernel split state-history path vs rewritten precision path"
    _print_error_stats(title, pairs)


def _summarize(name: str, tensor: torch.Tensor) -> None:
    finite = bool(torch.isfinite(tensor.float()).all())
    print(f"{name}: shape={tuple(tensor.shape)} dtype={tensor.dtype} finite={finite}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-original", action="store_true")
    parser.add_argument("--check-kernels", action="store_true")
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=2)
    parser.add_argument("--C", type=int, default=2)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--on-npu", action="store_true")
    parser.add_argument("--out-dir", default="")
    parser.add_argument("--state-after-history", action="store_true")
    args_ns = parser.parse_args()

    if args_ns.check_original:
        compare_original_vs_rewritten(B=args_ns.B, H=args_ns.H, C=args_ns.C, seed=args_ns.seed)
    elif args_ns.check_kernels:
        compare_rewritten_vs_kernel_split(
            B=args_ns.B,
            H=args_ns.H,
            C=args_ns.C,
            seed=args_ns.seed,
            on_npu=args_ns.on_npu,
            out_dir=args_ns.out_dir,
            state_after_history=args_ns.state_after_history,
        )
    else:
        torch.manual_seed(args_ns.seed)
        args = make_inputs(B=args_ns.B, H=args_ns.H, C=args_ns.C)
        if args_ns.on_npu:
            if args_ns.state_after_history:
                core, state, state_history, mids = gdn_full_chunked_kernels_state_history(
                    *args,
                    return_intermediates=True,
                    on_npu=True,
                    out_dir=args_ns.out_dir,
                )
            else:
                core, state, mids = gdn_full_chunked_kernels(
                    *args,
                    return_intermediates=True,
                    on_npu=True,
                    out_dir=args_ns.out_dir,
                )
                state_history = None
        else:
            if args_ns.state_after_history:
                core, state, state_history, mids = GDN_full(
                    *args,
                    return_intermediates=True,
                    state_after_history=True,
                )
            else:
                core, state, mids = GDN_full(*args, return_intermediates=True)
                state_history = None

        _summarize("core_attn_out", core)
        _summarize("final_state", state)
        if state_history is not None:
            _summarize("state_after_history", state_history)
        for key, tensor in mids.items():
            if key == "state_after_history" and state_history is not None:
                continue
            _summarize(key, tensor)

        print(f"tolerance_budget: atol={ATOL:.1e} rtol={RTOL:.1e}")
