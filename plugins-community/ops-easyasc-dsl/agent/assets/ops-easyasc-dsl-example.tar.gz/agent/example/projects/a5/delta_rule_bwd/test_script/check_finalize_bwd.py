"""Simulator validation for delta_rule_bwd finalize_bwd kernel.

Wires upstream partials from refs/common.py exactly as finalize_bwd_ref.py
__main__ does, then checks d_key, d_value, d_beta against the ref[1:].
"""
import sys
from pathlib import Path

import torch

# --- path setup (must precede all project imports) ---
_SCRIPT_DIR = Path(__file__).resolve().parent
_PLAN_DIR = _SCRIPT_DIR.parent
_REFS_DIR = _PLAN_DIR / "refs"
_KERNELS_DIR = _PLAN_DIR / "kernels"


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


_REPO_ROOT = _find_repo_root(_SCRIPT_DIR)
for _p in (str(_REPO_ROOT), str(_REFS_DIR), str(_KERNELS_DIR)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# --- imports (all project imports after path setup) ---
from easyasc.a5 import *  # noqa: F401, F403 -- must resolve before kernel import
from common import make_inputs, core_scan_bwd, wu_recompute_bwd, inverse_preprocess_bwd  # noqa: E402
from finalize_bwd_ref import subkernel  # noqa: E402
import finalize_bwd as kern  # noqa: E402


def main():
    torch.manual_seed(42)
    B, H, C = 1, 1, 2
    full = make_inputs(B, H, C)

    # Build upstream partials exactly as finalize_bwd_ref.py __main__ does.
    scan = core_scan_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])
    wu = wu_recompute_bwd(full[1], full[2], full[3], full[5], scan[2], scan[3])
    inv = inverse_preprocess_bwd(full[1], full[3], full[5], wu[0])

    key, value, beta = full[1], full[2], full[3]
    d_k_core = scan[1]
    d_v_beta = wu[1]
    d_k_beta_wu = wu[2]
    d_k_pre = inv[0]
    d_k_beta_pre = inv[1]

    # Reference: subkernel carries d_q passthrough; kernel outputs are ref[1:]
    ref = subkernel(key, value, beta, scan[0], scan[1], wu[1], wu[2], inv[0], inv[1])
    d_key_ref, d_value_ref, d_beta_ref = ref[1], ref[2], ref[3]

    # Run kernel in simulator
    d_key_got, d_value_got, d_beta_got = kern.run(
        key, value, beta, d_k_core, d_v_beta, d_k_beta_wu, d_k_pre, d_k_beta_pre,
        simulator=True, out_dir="tmp/delta_bwd_fin",
    )

    dk_err = (d_key_got.float() - d_key_ref.float()).abs().max().item()
    dv_err = (d_value_got.float() - d_value_ref.float()).abs().max().item()
    db_err = (d_beta_got.float() - d_beta_ref.float()).abs().max().item()

    print("finalize_bwd (delta_rule_bwd):")
    print("  d_key  max_abs=%.3e" % dk_err)
    print("  d_value max_abs=%.3e" % dv_err)
    print("  d_beta max_abs=%.3e" % db_err)

    torch.testing.assert_close(d_key_got.float(), d_key_ref.float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(d_value_got.float(), d_value_ref.float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(d_beta_got.float(), d_beta_ref.float(), rtol=2e-3, atol=2e-3)
    print("finalize_bwd OK")


if __name__ == "__main__":
    main()
