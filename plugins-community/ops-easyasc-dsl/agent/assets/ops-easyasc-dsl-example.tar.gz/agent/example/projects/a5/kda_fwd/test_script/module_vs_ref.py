"""Module-by-module kernel-vs-reference checks for kda_fwd.

Default behavior runs each leaf kernel with reference upstream tensors. That
lets us answer the hardware question "which kernel is wrong by itself?" before a
bad upstream stage poisons every downstream check. Use `--upstream kernel` to
feed each leaf with the previous kernel's real output instead (cascade).

Modules:
  leaf  : sub1_gate, sub2_intra, sub3_wy, sub45_fused  (per-kernel vs ref)
  stage : compose                                       (end-to-end vs oracle)

Examples:
  python projects/a5/kda_fwd/test_script/module_vs_ref.py
  python projects/a5/kda_fwd/test_script/module_vs_ref.py --module compose --B 1 --H 2 --HV 2 --C 2
  python projects/a5/kda_fwd/test_script/module_vs_ref.py --module leaf --upstream kernel --stop-on-fail
  python projects/a5/kda_fwd/test_script/module_vs_ref.py --module all --mode onboard --profile
"""

import argparse
import inspect
import sys
from pathlib import Path

import torch


SCRIPT_DIR = Path(__file__).resolve().parent
PLAN_DIR = SCRIPT_DIR.parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)

for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from oracle import oracle, sample_inputs, to_chunked_inputs  # noqa: E402
from sub1_gate_ref import subkernel as ref_sub1_gate  # noqa: E402
from sub2_intra_ref import subkernel as ref_sub2_intra  # noqa: E402
from sub3_wy_ref import subkernel as ref_sub3_wy  # noqa: E402
from sub45_fused_ref import subkernel as ref_sub45_fused  # noqa: E402
from sub1_gate import run as run_sub1_gate  # noqa: E402
from sub2_intra import run as run_sub2_intra  # noqa: E402
from sub3_wy import run as run_sub3_wy  # noqa: E402
from sub45_fused import run as run_sub45_fused  # noqa: E402
from kernel_compose import run as run_compose  # noqa: E402


DEFAULT_ATOL = 2e-2
DEFAULT_RTOL = 2e-2

LEAF_MODULES = ["sub1_gate", "sub2_intra", "sub3_wy", "sub45_fused"]
STAGE_MODULES = ["compose"]
ALL_MODULES = LEAF_MODULES + STAGE_MODULES
MODULE_ALIASES = {
    "leaf": LEAF_MODULES,
    "leaves": LEAF_MODULES,
    "stage": STAGE_MODULES,
    "stages": STAGE_MODULES,
    "pipeline": STAGE_MODULES,
    "all": ALL_MODULES,
}
MODULE_OUTPUT_NAMES = {
    "sub1_gate": ["g"],
    "sub2_intra": ["Aqk", "Akk"],
    "sub3_wy": ["w", "u", "qg", "kg"],
    "sub45_fused": ["o", "final_state"],
    "compose": ["o", "final_state"],
}
MODULE_TOLERANCES = {
    "sub1_gate": (DEFAULT_ATOL, DEFAULT_RTOL),
    "sub2_intra": (DEFAULT_ATOL, DEFAULT_RTOL),
    "sub3_wy": (DEFAULT_ATOL, DEFAULT_RTOL),
    "sub45_fused": (DEFAULT_ATOL, DEFAULT_RTOL),
    "compose": (DEFAULT_ATOL, DEFAULT_RTOL),
}


def _parse_csv_ints(text):
    values = []
    for item in text.split(","):
        item = item.strip()
        if item:
            values.append(int(item))
    return values


def _as_tuple(value):
    return value if isinstance(value, tuple) else (value,)


def _expand_modules(items):
    modules = []
    valid = set(ALL_MODULES)
    valid_names = valid | set(MODULE_ALIASES)
    for item in items:
        for name in item.split(","):
            name = name.strip()
            if not name:
                continue
            modules.extend(MODULE_ALIASES.get(name, [name]))

    seen = set()
    expanded = []
    for name in modules:
        if name not in valid:
            raise ValueError("unknown module %r; valid: %s" % (name, ", ".join(sorted(valid_names))))
        if name not in seen:
            expanded.append(name)
            seen.add(name)
    return expanded


def _trace_value(trace_root, module_name, seed):
    if not trace_root:
        return None
    path = Path(trace_root) / ("seed_%s" % seed) / ("%s.json" % module_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


def _call_run(run_fn, args, options, module_name, seed):
    call_out_dir = str(Path(options.out_dir) / module_name) if options.out_dir else ""
    call_args = tuple(arg.clone() if torch.is_tensor(arg) else arg for arg in args)
    kwargs = {
        "simulator": (options.mode == "simulator"),
        "trace": _trace_value(options.trace_root, module_name, seed),
        "out_dir": call_out_dir,
        "skip_compile": options.skip_compile,
    }
    if options.profile and "profile" in inspect.signature(run_fn).parameters:
        kwargs["profile"] = True
    return _as_tuple(run_fn(*call_args, **kwargs))


def _compare_tensor(module_name, output_name, index, actual, expected, atol, rtol):
    if tuple(actual.shape) != tuple(expected.shape):
        print(
            "  [%s.%s] shape FAIL actual=%s expected=%s"
            % (module_name, output_name, tuple(actual.shape), tuple(expected.shape))
        )
        return False

    actual_f = actual.float()
    expected_f = expected.float()
    if not torch.isfinite(actual_f).all() or not torch.isfinite(expected_f).all():
        print("  [%s.%s] finite FAIL" % (module_name, output_name))
        return False

    diff = (actual_f - expected_f).abs()
    rel = diff / expected_f.abs().clamp_min(1e-12)
    close = torch.isclose(actual_f, expected_f, atol=atol, rtol=rtol)
    ok = bool(close.all())
    bad_count = int((~close).sum().item())
    max_abs = float(diff.max()) if diff.numel() else 0.0
    max_rel = float(rel.max()) if rel.numel() else 0.0
    flat_idx = int(diff.reshape(-1).argmax().item()) if diff.numel() else 0
    idx_tuple = tuple(int(i) for i in torch.unravel_index(torch.tensor(flat_idx), diff.shape))
    actual_val = float(actual_f[idx_tuple]) if diff.numel() else 0.0
    expected_val = float(expected_f[idx_tuple]) if diff.numel() else 0.0
    status = "OK" if ok else "FAIL"
    print(
        "  [%s.%s] %s shape=%s dtype=%s max_abs=%.3e max_rel=%.3e bad=%d idx=%s got=%.8e ref=%.8e"
        % (
            module_name,
            output_name or ("output%d" % index),
            status,
            tuple(actual.shape),
            actual.dtype,
            max_abs,
            max_rel,
            bad_count,
            idx_tuple,
            actual_val,
            expected_val,
        )
    )
    return ok


def _compare_tuple(module_name, actual, expected, atol, rtol):
    actual = _as_tuple(actual)
    expected = _as_tuple(expected)
    if len(actual) != len(expected):
        print("  [%s] arity FAIL actual=%d expected=%d" % (module_name, len(actual), len(expected)))
        return False

    names = MODULE_OUTPUT_NAMES.get(module_name, [])
    ok = True
    for idx, (act, exp) in enumerate(zip(actual, expected)):
        output_name = names[idx] if idx < len(names) else "output%d" % idx
        ok = _compare_tensor(module_name, output_name, idx, act, exp, atol, rtol) and ok
    return ok


def _module_tolerance(module_name, options):
    default_atol, default_rtol = MODULE_TOLERANCES.get(module_name, (DEFAULT_ATOL, DEFAULT_RTOL))
    atol = options.atol if options.atol is not None else default_atol
    rtol = options.rtol if options.rtol is not None else default_rtol
    return atol, rtol


class KdaFwdCase(object):
    """Holds one seed's inputs plus lazily-built reference upstream tensors.

    `expected_for_module` always uses the pure-PyTorch ref chain (the correct
    answer). `actual_for_module` feeds each kernel from the ref chain
    (`--upstream ref`, isolates the kernel) or from the kernel chain
    (`--upstream kernel`, cascades real outputs).
    """

    def __init__(self, seed, options):
        self.seed = seed
        self.options = options
        self.inputs = sample_inputs(
            B=options.B,
            H=options.H,
            HV=options.HV,
            C=options.C_eff,
            L=options.chunk_size,
            K=options.K,
            V=options.V,
            seed=seed,
        )
        q, k, v, g_raw, beta, initial_state = self.inputs
        self.scale = options.K ** -0.5
        self.q_c, self.k_c, self.v_c, self.g_raw_c, self.beta_c = to_chunked_inputs(
            q, k, v, g_raw, beta, chunk_size=options.chunk_size
        )
        self.initial_state = initial_state
        self._ref = {}
        self._actual_cache = {}

    # --- reference upstream chain (pure torch) ---
    def ref_g(self):
        if "g" not in self._ref:
            self._ref["g"] = ref_sub1_gate(self.g_raw_c)
        return self._ref["g"]

    def ref_aqk_akk(self):
        if "aqk_akk" not in self._ref:
            self._ref["aqk_akk"] = ref_sub2_intra(self.q_c, self.k_c, self.ref_g(), self.beta_c, self.scale)
        return self._ref["aqk_akk"]

    def ref_wy(self):
        if "wy" not in self._ref:
            _Aqk, Akk = self.ref_aqk_akk()
            self._ref["wy"] = ref_sub3_wy(self.q_c, self.k_c, self.v_c, self.beta_c, Akk, self.ref_g())
        return self._ref["wy"]

    # --- upstream resolver: ref chain or kernel chain ---
    def _up_g(self):
        if self.options.upstream == "ref":
            return self.ref_g()
        return self.actual_for_module("sub1_gate")[0]

    def _up_aqk_akk(self):
        if self.options.upstream == "ref":
            return self.ref_aqk_akk()
        return self.actual_for_module("sub2_intra")

    def _up_wy(self):
        if self.options.upstream == "ref":
            return self.ref_wy()
        return self.actual_for_module("sub3_wy")

    # --- kernel outputs (cached) ---
    def actual_for_module(self, module_name):
        if module_name in self._actual_cache:
            return self._actual_cache[module_name]
        options = self.options
        if module_name == "sub1_gate":
            out = _call_run(run_sub1_gate, (self.g_raw_c,), options, module_name, self.seed)
        elif module_name == "sub2_intra":
            g = self._up_g()
            out = _call_run(run_sub2_intra, (self.q_c, self.k_c, g, self.beta_c, self.scale), options, module_name, self.seed)
        elif module_name == "sub3_wy":
            g = self._up_g()
            _Aqk, Akk = self._up_aqk_akk()
            out = _call_run(run_sub3_wy, (self.q_c, self.k_c, self.v_c, self.beta_c, Akk, g), options, module_name, self.seed)
        elif module_name == "sub45_fused":
            g = self._up_g()
            Aqk, _Akk = self._up_aqk_akk()
            w, u, _qg, kg = self._up_wy()
            out = _call_run(
                run_sub45_fused,
                (self.q_c, Aqk, kg, w, u, g, self.initial_state, self.scale),
                options,
                module_name,
                self.seed,
            )
        elif module_name == "compose":
            q, k, v, g_raw, beta, initial_state = self.inputs
            out = _call_run(run_compose, (q, k, v, g_raw, beta, initial_state), options, module_name, self.seed)
        else:
            raise ValueError("unsupported module %r" % module_name)
        self._actual_cache[module_name] = out
        return out

    # --- reference expectations (pure torch / oracle) ---
    def expected_for_module(self, module_name):
        if module_name == "sub1_gate":
            return _as_tuple(self.ref_g())
        if module_name == "sub2_intra":
            return self.ref_aqk_akk()
        if module_name == "sub3_wy":
            return self.ref_wy()
        if module_name == "sub45_fused":
            Aqk, _Akk = self.ref_aqk_akk()
            w, u, _qg, kg = self.ref_wy()
            return _as_tuple(
                ref_sub45_fused(self.q_c, Aqk, kg, w, u, self.ref_g(), self.initial_state, self.scale)
            )
        if module_name == "compose":
            return _as_tuple(oracle(*self.inputs))
        raise ValueError("unsupported module %r" % module_name)


def run_case(seed, modules, options):
    print(
        "=== seed=%d shape=(B=%d,H=%d,HV=%d,C=%d,L=%d,K=%d,V=%d) mode=%s upstream=%s ==="
        % (
            seed,
            options.B,
            options.H,
            options.HV,
            options.C_eff,
            options.chunk_size,
            options.K,
            options.V,
            options.mode,
            options.upstream,
        )
    )
    case = KdaFwdCase(seed, options)
    ok = True
    for module_name in modules:
        print("[%s]" % module_name)
        actual = case.actual_for_module(module_name)
        expected = case.expected_for_module(module_name)
        atol, rtol = _module_tolerance(module_name, options)
        ok = _compare_tuple(module_name, actual, expected, atol, rtol) and ok
        if not ok and options.stop_on_fail:
            break
    return ok


def parse_args(argv):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--module",
        action="append",
        default=None,
        help="module, comma list, or alias: leaf/stage/all",
    )
    parser.add_argument("--upstream", choices=("ref", "kernel"), default="ref")
    parser.add_argument("--list-modules", action="store_true", help="print the expanded module list and exit")
    parser.add_argument("--mode", choices=("simulator", "onboard"), default="simulator")
    parser.add_argument("--seed", default="2026", help="comma-separated torch seeds")
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=32)
    parser.add_argument("--HV", type=int, default=32)
    parser.add_argument("--C", type=int, default=16, help="chunks; T = C * chunk_size unless --T given")
    parser.add_argument("--T", type=int, default=None, help="sequence length; overrides --C when set")
    parser.add_argument("--K", type=int, default=128, help="head dim (kernels specialize to 128)")
    parser.add_argument("--V", type=int, default=128, help="value dim (kernels specialize to 128)")
    parser.add_argument("--chunk-size", type=int, default=64, help="chunk length L (kernels specialize to 64)")
    parser.add_argument("--atol", type=float, default=None, help="override absolute tolerance for every module")
    parser.add_argument("--rtol", type=float, default=None, help="override relative tolerance for every module")
    parser.add_argument("--out-dir", default="", help="OpExec output dir (per-module build packages land under here)")
    parser.add_argument("--trace", action="store_true", help="emit simulator traces (simulator mode only)")
    parser.add_argument("--profile", action="store_true", help="pass profile=True to leaf kernels (onboard HW timing)")
    parser.add_argument("--skip-compile", action="store_true")
    parser.add_argument("--stop-on-fail", action="store_true")
    args = parser.parse_args(argv)

    args.modules = _expand_modules(args.module or ["leaf"])
    args.seeds = _parse_csv_ints(args.seed)
    if not args.seeds:
        parser.error("--seed produced no integers")
    if args.T is not None:
        if args.T % args.chunk_size != 0:
            parser.error("--T=%d must be divisible by --chunk-size=%d" % (args.T, args.chunk_size))
        args.C_eff = args.T // args.chunk_size
    else:
        args.C_eff = args.C
    if args.trace and args.mode == "simulator":
        if args.out_dir:
            args.trace_root = str(Path(args.out_dir) / "traces")
        else:
            args.trace_root = str(PLAN_DIR / "tmp" / "module_vs_ref_traces")
    else:
        args.trace_root = ""
    return args


def main(argv=None):
    options = parse_args(sys.argv[1:] if argv is None else argv)
    if options.list_modules:
        for name in options.modules:
            print(name)
        return 0

    all_ok = True
    for seed in options.seeds:
        ok = run_case(seed, options.modules, options)
        all_ok = ok and all_ok
        if not ok and options.stop_on_fail:
            break
    if all_ok:
        print("kda_fwd module-vs-ref OK")
        return 0
    print("kda_fwd module-vs-ref FAIL")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
