"""Sub-kernel reference: sub3_wy - materialize KDA WY tensors.

I/O contract
------------
Inputs:
  - q:    torch.bfloat16/float16 [B, H,  C, L, K]
  - k:    torch.bfloat16/float16 [B, H,  C, L, K]
  - v:    torch.bfloat16/float16 [B, HV, C, L, V]
  - beta: torch.float32          [B, HV, C, L]
  - Akk:  k.dtype                [B, HV, C, L, L]
  - g:    torch.float32          [B, HV, C, L, K] cumulative gates in linear space

Outputs:
  - w:    k.dtype [B, HV, C, L, K]
  - u:    v.dtype [B, HV, C, L, V]
  - qg:   q.dtype [B, HV, C, L, K], saved for backward
  - kg:   k.dtype [B, HV, C, L, K]

Primitives used: [P1, P5, P6, P7]
"""

import torch


def _expand_qk_to_value_heads(x, hv):
    h = x.shape[1]
    group = hv // h
    return x.repeat_interleave(group, dim=1)


def subkernel(q, k, v, beta, Akk, g):
    HV = v.shape[1]
    q_hv = _expand_qk_to_value_heads(q.float(), HV)
    k_hv = _expand_qk_to_value_heads(k.float(), HV)
    vf = v.float()
    betaf = beta.float()
    gf = g.float()
    A = Akk.float()

    qg = q_hv * gf
    k_beta_g = k_hv * betaf[..., None] * gf
    v_beta = vf * betaf[..., None]
    w = torch.matmul(A, k_beta_g)
    u = torch.matmul(A, v_beta)
    g_last = gf[..., -1:, :]
    kg = k_hv * (g_last / gf)
    return w.to(k.dtype), u.to(v.dtype), qg.to(q.dtype), kg.to(k.dtype)


if __name__ == "__main__":
    from oracle import sample_inputs, to_chunked_inputs
    from sub1_gate_ref import subkernel as gate_cumsum
    from sub2_intra_ref import subkernel as intra

    q, k, v, g_raw, beta, _ = sample_inputs(B=1, H=1, HV=1, C=1, L=32, K=32, V=32, seed=42)
    q_c, k_c, v_c, g_raw_c, beta_c = to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=32)
    g_c = gate_cumsum(g_raw_c)
    _Aqk, Akk = intra(q_c, k_c, g_c, beta_c, scale=32 ** -0.5)
    result = subkernel(q_c, k_c, v_c, beta_c, Akk, g_c)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
