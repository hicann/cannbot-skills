"""Speed test for FLA's chunked delta-rule forward (Triton) with torch.profiler.

This benchmarks the *reference* GPU implementation — FLA's `chunk_delta_rule`
forward (https://github.com/fla-org/flash-linear-attention, the
`fla/ops/delta_rule/chunk.py` op that the EasyASC `delta_rule_fwd` kernel ports).
It is the GPU baseline to compare the Ascend (a5/950) kernel against; it does NOT
run the EasyASC kernel.

Requires an NVIDIA CUDA GPU and `flash-linear-attention` installed:

    pip install flash-linear-attention   # pulls in triton
    python projects/a5/delta_rule_fwd/test_script/profile_fla_delta_rule.py

Representative shape (matches the kernel's chunked layout B,H,C,L,D):

    B=1, H=32, C=16, L=64, D=128   ->   FLA sequence length T = C*L = 1024

FLA's op is *not* chunked at the Python boundary: it takes the full sequence
[*, T, *] and tiles internally (chunk size 64 == our L), so we pass T=C*L and
read the per-call latency back out.

Output:
  * a torch.profiler key-averages table (top CUDA kernels), and
  * a clean CUDA-event headline latency (avg over the timed loop), which is the
    number to quote — profiler instrumentation itself adds a little overhead.
  * a Chrome trace written next to the script (open in chrome://tracing).

The script introspects `chunk_delta_rule`'s signature so it works across FLA
versions (the layout flag has been `head_first=True` -> `[B,H,T,D]` in older
releases and `[B,T,H,D]` in newer ones; `scale`/`output_final_state`/
`use_qk_l2norm_in_kernel` are passed only when supported).
"""

from __future__ import annotations

import argparse
import inspect
import sys
from pathlib import Path

import torch


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--B", type=int, default=1, help="batch")
    p.add_argument("--H", type=int, default=32, help="heads")
    p.add_argument("--C", type=int, default=16, help="number of chunks (T = C*L)")
    p.add_argument("--L", type=int, default=64, help="chunk length (FLA internal chunk size)")
    p.add_argument("--D", type=int, default=128, help="head dim")
    p.add_argument("--iters", type=int, default=10, help="timed iterations")
    p.add_argument("--warmup", type=int, default=5, help="warmup iterations (untimed)")
    p.add_argument("--dtype", choices=("bf16", "fp16"), default="bf16")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--trace", type=str, default=str(Path(__file__).resolve().parent / "tmp" / "fla_delta_rule_trace.json"),
                   help="Chrome trace output path")
    p.add_argument("--rows", type=int, default=15, help="rows in the profiler table")
    return p.parse_args()


def _build_inputs(B, H, C, L, D, dtype, device, head_first, l2norm_outside):
    """q/k/v and beta in the layout FLA expects for this version.

    head_first=True  -> [B, H, T, D], beta [B, H, T]
    head_first=False -> [B, T, H, D], beta [B, T, H]
    """
    T = C * L
    if head_first:
        qkv_shape, beta_shape, norm_dim = (B, H, T, D), (B, H, T), -1
    else:
        qkv_shape, beta_shape, norm_dim = (B, T, H, D), (B, T, H), -1

    q = torch.randn(qkv_shape, device=device, dtype=dtype)
    k = torch.randn(qkv_shape, device=device, dtype=dtype)
    v = torch.randn(qkv_shape, device=device, dtype=dtype)
    # delta-net L2-normalizes q/k before the op (keeps the recurrence finite for a
    # clean sanity check); timing is independent of the values.  Skip it when the
    # kernel will normalize internally (use_qk_l2norm_in_kernel=True).
    if l2norm_outside:
        q = torch.nn.functional.normalize(q.float(), p=2, dim=norm_dim).to(dtype)
        k = torch.nn.functional.normalize(k.float(), p=2, dim=norm_dim).to(dtype)
    # beta in (0, 1), as produced by the delta-net beta projection (sigmoid).
    beta = torch.rand(beta_shape, device=device, dtype=dtype)
    return q, k, v, beta


def main() -> int:
    args = _parse_args()

    if not torch.cuda.is_available():
        print(
            "ERROR: FLA's chunk_delta_rule is a Triton/CUDA kernel and needs an "
            "NVIDIA GPU. Run this on a CUDA box (it does not run on CPU / Ascend NPU).",
            file=sys.stderr,
        )
        return 2

    try:
        from fla.ops.delta_rule import chunk_delta_rule
    except Exception as exc:  # pragma: no cover - depends on the runtime box
        print(f"ERROR: could not import fla.ops.delta_rule.chunk_delta_rule: {exc}", file=sys.stderr)
        print("Install with:  pip install flash-linear-attention", file=sys.stderr)
        return 2

    device = "cuda"
    dtype = torch.bfloat16 if args.dtype == "bf16" else torch.float16
    torch.manual_seed(args.seed)

    B, H, C, L, D = args.B, args.H, args.C, args.L, args.D
    T = C * L
    scale = D ** -0.5  # FLA's default (head_dim ** -0.5)

    # --- adapt to this FLA version's signature -------------------------------
    params = inspect.signature(chunk_delta_rule).parameters
    head_first = "head_first" in params
    use_kernel_l2 = "use_qk_l2norm_in_kernel" in params

    call_kwargs = {}
    if "scale" in params:
        call_kwargs["scale"] = scale
    if "output_final_state" in params:
        call_kwargs["output_final_state"] = False
    if head_first:
        call_kwargs["head_first"] = True
    if use_kernel_l2:
        # let the kernel do the q/k L2-norm (closest to real delta-net usage)
        call_kwargs["use_qk_l2norm_in_kernel"] = True

    q, k, v, beta = _build_inputs(
        B, H, C, L, D, dtype, device,
        head_first=head_first,
        l2norm_outside=not use_kernel_l2,
    )

    def run():
        out = chunk_delta_rule(q, k, v, beta, **call_kwargs)
        return out[0] if isinstance(out, (tuple, list)) else out

    # --- correctness-ish sanity (shape + finiteness) -------------------------
    o = run()
    torch.cuda.synchronize()
    layout = "[B,H,T,D]" if head_first else "[B,T,H,D]"
    print(f"FLA chunk_delta_rule | B={B} H={H} C={C} L={L} D={D}  T=C*L={T}  layout={layout}")
    print(f"  signature kwargs: {call_kwargs}")
    print(f"  output: shape={tuple(o.shape)} dtype={o.dtype} finite={torch.isfinite(o).all().item()}")

    # --- warmup --------------------------------------------------------------
    for _ in range(args.warmup):
        run()
    torch.cuda.synchronize()

    # --- headline latency via CUDA events (low overhead) ---------------------
    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    starter.record()
    for _ in range(args.iters):
        run()
    ender.record()
    torch.cuda.synchronize()
    total_ms = starter.elapsed_time(ender)
    per_iter_ms = total_ms / args.iters
    toks = B * T
    print(
        f"\n[cuda-event] {args.iters} iters: total={total_ms:.3f} ms  "
        f"avg={per_iter_ms:.4f} ms/iter  ({toks / (per_iter_ms * 1e3):.2f} Mtok/s)"
    )

    # --- torch.profiler breakdown (the requested measurement) ----------------
    from torch.profiler import ProfilerActivity, profile, record_function

    with profile(
        activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
        record_shapes=True,
        with_stack=False,
    ) as prof:
        for _ in range(args.iters):
            with record_function("fla_chunk_delta_rule_fwd"):
                run()
        torch.cuda.synchronize()

    print(f"\n[torch.profiler] top {args.rows} ops by CUDA self time over {args.iters} iters:")
    print(prof.key_averages().table(sort_by="self_cuda_time_total", row_limit=args.rows))

    trace_path = Path(args.trace)
    trace_path.parent.mkdir(parents=True, exist_ok=True)
    prof.export_chrome_trace(str(trace_path))
    print(f"[torch.profiler] Chrome trace written to {trace_path}  (open in chrome://tracing)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
