"""Shared host-side layout conversions between the public BTHVD layout and the
kernels' native GM layout.

The KDA backward leaf kernels index GM in a per-chunk, HV-major layout
(``[B, HV, C, L, X]`` and friends), while the public/compose interface uses the
token-major ``[B, T, HV, X]`` layout (T = C * L). These helpers are the single
source of truth for that mapping, used by the stage drivers (once per stage
boundary) and by each leaf's standalone ``__main__`` story (at its call site).

All helpers are **dtype-preserving** pure layout transforms — the caller adds
``.to(bf16)`` / ``.float()`` only where a kernel's declared GM dtype differs
from the tensor it has (most GM tensors are bf16; the few fp32 ones, e.g.
``inverse_dainv``'s beta, are cast explicitly by the caller).
"""

L = 64  # chunk size; hard architectural constant, must match _torch_formula.L


def to_lvd(x):
    """[B, T, HV, X] -> [B, HV, C, L, X]  (X = D or L; T = C * L)."""
    B, T, HV, X = x.shape
    C = T // L
    return x.reshape(B, C, L, HV, X).permute(0, 3, 1, 2, 4).contiguous()


def flat_lvd(x):
    """[B, HV, C, L, X] -> [B, T, HV, X]  (inverse of to_lvd)."""
    B, HV, C, Lc, X = x.shape
    return x.permute(0, 2, 3, 1, 4).reshape(B, C * Lc, HV, X).contiguous()


def to_hvcl(x):
    """[B, T, HV] -> [B, HV, C, L]  (beta)."""
    B, T, HV = x.shape
    C = T // L
    return x.reshape(B, C, L, HV).permute(0, 3, 1, 2).contiguous()


def flat_hvcl(x):
    """[B, HV, C, L] -> [B, T, HV]  (inverse of to_hvcl; dbeta)."""
    B, HV, C, Lc = x.shape
    return x.permute(0, 2, 3, 1).reshape(B, C * Lc, HV).contiguous()


def to_hvtl(x):
    """[B, T, HV, X] -> [B, HV, T, X]  (Akk-style token-major GM)."""
    return x.permute(0, 2, 1, 3).contiguous()


def flat_hvtl(x):
    """[B, HV, T, X] -> [B, T, HV, X]  (inverse of to_hvtl; dAkk)."""
    return x.permute(0, 2, 1, 3).contiguous()


def to_hvcdd(x):
    """[B, C, HV, D, D] -> [B, HV, C, D, D]  (h, dh)."""
    return x.permute(0, 2, 1, 3, 4).contiguous()


if __name__ == "__main__":
    import torch

    B, C, HV, D = 2, 3, 4, 8
    T = C * L
    # 5-D round trips
    x5 = torch.randn(B, T, HV, D)
    assert torch.equal(flat_lvd(to_lvd(x5)), x5), "to_lvd/flat_lvd round-trip"
    xl = torch.randn(B, T, HV, L)
    assert torch.equal(flat_lvd(to_lvd(xl)), xl), "to_lvd/flat_lvd (X=L) round-trip"
    # 3-D round trip
    x3 = torch.randn(B, T, HV)
    assert torch.equal(flat_hvcl(to_hvcl(x3)), x3), "to_hvcl/flat_hvcl round-trip"
    # token-major round trip
    xt = torch.randn(B, T, HV, L)
    assert torch.equal(flat_hvtl(to_hvtl(xt)), xt), "to_hvtl/flat_hvtl round-trip"
    # hvcdd shape check
    xh = torch.randn(B, C, HV, D, D)
    assert tuple(to_hvcdd(xh).shape) == (B, HV, C, D, D), "to_hvcdd shape"
    # exact match vs the inlined ops the leaves use today
    ref = x5.reshape(B, C, L, HV, D).permute(0, 3, 1, 2, 4).contiguous()
    assert torch.equal(to_lvd(x5), ref), "to_lvd matches inlined leaf op"
    print("kda_bwd _layout round-trips OK")
