#!/usr/bin/env bash
# Onboard (Ascend 950 / a5) profile for delta_rule_bwd.
#
# Drives `module_vs_ref.py --mode onboard --profile`, which builds + runs the
# requested module on the NPU and (because profile=True) makes each leaf kernel's
# aclnn test print
#       ---- N_TESTS: <n>   AVG: <us>   FirstRun: <us> ----
# (per-call average over the mid-50 of 100 runs) into its own
# `<...>_kernel_script/r.sh.log`.  After the run this wrapper finds every
# r.sh.log under OUT_DIR and prints a per-kernel AVG summary.
#
# MODULE=compose (default) profiles the whole backward, so every leaf kernel
# (scan_local_bwd, scan_state_bwd, wu_bwd, inverse_preprocess_bwd, finalize_bwd)
# is built + timed in one run.  Set MODULE to a single stage to profile it alone.
#
# IMPORTANT: a5 onboard uses debug=False / full-project generate(profile=True)
# (the default OpExec path), NOT the a2 debug=True standalone harness; the timing
# token is `N_TESTS/AVG` (us), not a2's `Time cost: <ms>`.
#
# Must run on the Ascend box (NPU + CANN).  On the Mac (no HW) the onboard build
# fails at b.sh.  Validate the driver logic locally first with the simulator:
#       MODE=simulator B=1 H=1 C=8 ./run_onboard_profile.sh
# (simulator mode does not build on the NPU, so it prints no AVG timings -- it
# only confirms the module wiring + numerics.)
#
# Usage:
#   projects/a5/delta_rule_bwd/test_script/run_onboard_profile.sh
#   B=1 H=32 C=16 SEED=20260609 ./run_onboard_profile.sh
#   MODULE=scan_state_bwd ./run_onboard_profile.sh
#   PYTHON_CMD="conda run -n torch210npu python" ./run_onboard_profile.sh
#   MODE=simulator ./run_onboard_profile.sh         # local dry run, no NPU
#
# Env knobs (all optional):
#   MODE        onboard (default) | simulator
#   MODULE      compose (default) | scan_local_bwd | scan_state_bwd | scan_split_bwd
#               | wu_bwd | inverse_preprocess_bwd | finalize_bwd | all
#   B,H,C       problem shape (default 1 / 32 / 16)
#   SEED        RNG seed (default 20260609)
#   OUT_DIR     run directory (default hw_out/onboard_profile_*_<timestamp>)
#   PYTHON_CMD  python runner override (else torch210npu conda env, else python)
# Extra args after `--` are forwarded to module_vs_ref.py.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLAN_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

find_repo_root() {
  local dir="${PLAN_DIR}"
  while [[ "${dir}" != "/" ]]; do
    if [[ -f "${dir}/agent/ROUTER.md" && -f "${dir}/easyasc/a5.py" ]]; then
      printf '%s\n' "${dir}"
      return 0
    fi
    dir="$(dirname "${dir}")"
  done
  return 1
}

REPO_ROOT="$(find_repo_root)"

MODE="${MODE:-onboard}"
MODULE="${MODULE:-compose}"
SEED="${SEED:-20260609}"
B="${B:-1}"
H="${H:-32}"
C="${C:-16}"

case "${MODE}" in
  onboard|simulator) ;;
  *) echo "Unknown MODE=${MODE}. Use onboard or simulator." >&2; exit 2 ;;
esac

OUT_DIR="${OUT_DIR:-${PLAN_DIR}/hw_out/onboard_profile_${MODULE}_b${B}h${H}c${C}_$(date +%Y%m%d_%H%M%S)}"

if [[ -n "${PYTHON_CMD:-}" ]]; then
  read -r -a PYTHON_RUNNER <<< "${PYTHON_CMD}"
elif command -v conda >/dev/null 2>&1 && conda env list | grep -qE '^torch210npu[[:space:]]'; then
  PYTHON_RUNNER=(conda run -n torch210npu python)
else
  PYTHON_RUNNER=(python)
fi

mkdir -p "${OUT_DIR}"
OUT_DIR="$(cd "${OUT_DIR}" && pwd)"
export PYTHONPATH="${REPO_ROOT}${PYTHONPATH:+:${PYTHONPATH}}"

# OpExec defaults custom_op_path to the current working directory for onboard
# runs; keep generated custom-op packages under this run directory.
cd "${OUT_DIR}"

echo "delta_rule_bwd onboard profile"
echo "  mode=${MODE} module=${MODULE} seed=${SEED} shape=(B=${B},H=${H},C=${C})"
echo "  repo_root=${REPO_ROOT}"
echo "  out_dir=${OUT_DIR}"
echo "  workdir=$(pwd)"
echo "  python=${PYTHON_RUNNER[*]}"

python_args=(
  --module "${MODULE}"
  --mode "${MODE}"
  --seed "${SEED}"
  --B "${B}"
  --H "${H}"
  --C "${C}"
  --out-dir "${OUT_DIR}"
  --profile
  --stop-on-fail
)
if (( $# )); then
  python_args+=("$@")  # forward any extra args to module_vs_ref.py
fi

echo "=== module_vs_ref.py --module ${MODULE} --mode ${MODE} --profile ==="
"${PYTHON_RUNNER[@]}" "${PLAN_DIR}/test_script/module_vs_ref.py" "${python_args[@]}"

# --- per-kernel AVG timing summary -------------------------------------------
echo
echo "=== onboard AVG timing per kernel (grep N_TESTS/AVG in r.sh.log) ==="
found=0
while IFS= read -r -d '' log; do
  line="$(grep -aE 'N_TESTS|AVG' "${log}" | tail -1 || true)"
  if [[ -n "${line}" ]]; then
    label="$(basename "$(dirname "${log}")")"
    label="${label%_kernel_script}"
    printf '  %-30s %s\n' "${label}" "${line}"
    found=1
  fi
done < <(find "${OUT_DIR}" -name 'r.sh.log' -print0 2>/dev/null)

if [[ "${found}" -eq 0 ]]; then
  echo "  (no N_TESTS/AVG lines under ${OUT_DIR})"
  if [[ "${MODE}" != "onboard" ]]; then
    echo "  MODE=${MODE} does not build/run on the NPU, so this is expected."
    echo "  Run on the Ascend box with MODE=onboard for real timings."
  else
    echo "  Onboard run did not reach r.sh -- check the build log (b.sh.log) under OUT_DIR."
  fi
fi
