"""Local randomized check for sub2_intra_ref.py."""

import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from oracle import sample_inputs as oracle_sample_inputs, to_chunked_inputs  # noqa: E402
from sub1_gate_ref import subkernel as gate_cumsum  # noqa: E402
from sub2_intra_ref import subkernel  # noqa: E402


ATOL = 0.0
RTOL = 0.0


def _expand_qk_to_value_heads(x, hv):
    h = x.shape[1]
    return x.repeat_interleave(hv // h, dim=1)


def _solve_unit_lower_from_strict(strict_lower):
    out = strict_lower.clone()
    L = out.shape[-1]
    for i in range(1, L):
        prev = out[..., :i, :i].clone()
        row = out[..., i, :i].clone()
        correction = (out[..., i, :i, None].clone() * prev).sum(-2)
        out[..., i, :i] = row + correction
    eye = torch.eye(L, dtype=out.dtype, device=out.device)
    return out + eye


def expected(q, k, g, beta, scale):
    B, H, C, L, _K = q.shape
    HV = g.shape[1]
    q_hv = _expand_qk_to_value_heads(q.float(), HV)
    k_hv = _expand_qk_to_value_heads(k.float(), HV)
    gf = g.float()
    betaf = beta.float()

    Aqk = torch.empty(B, HV, C, L, L, dtype=torch.float32, device=q.device)
    Akk_raw = torch.empty_like(Aqk)
    for j in range(L):
        k_j = k_hv[..., j, :]
        gate = gf / gf[..., j:j + 1, :]
        Aqk[..., :, j] = (q_hv * gate * k_j[..., None, :]).sum(-1) * scale
        Akk_raw[..., :, j] = (k_hv * gate * k_j[..., None, :]).sum(-1)

    row = torch.arange(L, device=q.device)[:, None]
    col = torch.arange(L, device=q.device)[None, :]
    lower_inclusive = row >= col
    strict_lower = row > col
    Aqk = torch.where(lower_inclusive, Aqk, torch.zeros_like(Aqk))
    strict = torch.where(strict_lower, -(Akk_raw * betaf[..., :, None]), torch.zeros_like(Akk_raw))
    Akk = _solve_unit_lower_from_strict(strict)
    return Aqk.to(q.dtype), Akk.to(k.dtype)


def sample_inputs():
    chunk_size = 32
    q, k, v, g_raw, beta, _ = oracle_sample_inputs(B=1, H=2, HV=4, C=1, L=chunk_size, K=32, V=32, seed=21)
    q_c, k_c, _v_c, g_raw_c, beta_c = to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=chunk_size)
    return q_c, k_c, gate_cumsum(g_raw_c), beta_c, 32 ** -0.5


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return (value,)


def main():
    inputs = sample_inputs()
    actual = _as_tuple(subkernel(*inputs))
    expected_items = _as_tuple(expected(*inputs))
    if len(actual) != len(expected_items):
        raise AssertionError(f"arity mismatch: actual={len(actual)} expected={len(expected_items)}")
    for idx, (act, exp) in enumerate(zip(actual, expected_items)):
        if not torch.isfinite(act.float()).all() or not torch.isfinite(exp.float()).all():
            raise AssertionError(f"non-finite output at index {idx}")
        torch.testing.assert_close(act.float(), exp.float(), atol=ATOL, rtol=RTOL)
    print("sub2_intra: OK")


if __name__ == "__main__":
    main()
