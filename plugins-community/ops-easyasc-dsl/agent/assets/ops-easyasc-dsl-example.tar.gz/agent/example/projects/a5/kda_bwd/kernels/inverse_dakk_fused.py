"""Fused dAkk chain: tmp = Dtri @ Akk stays on chip, then dL_raw = Akk^T @ tmp^T.

Replaces the inverse_dakk_mm1 + inverse_dakk_mm2 pair. Akk loads once per
chunk and the fp32 intermediate crosses FIX -> UB -> bf16 -> L1 instead of a
GM round trip.
"""

import builtins
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _layout import to_hvtl


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
L = 64
HALF_L = L // 2
# Akk is read strided from the frozen BTHVL cache and dAkk is written strided to
# the frozen BTHVL seam consumed by finalize_pre; Dtri stays GM-native [B,HV,T,L]
# (internal, from inverse_dainv). Var args: B/HV/T.
SHAPE_BINDINGS = {
    0: [0, 2, 1, None],   # Akk   [B, T, HV, L]   strided BTHVL (cache)
    1: [0, 1, 2, None],   # Dtri  [B, HV, T, L]   internal GM-native
    2: [0, 2, 1, None],   # dAkk  [B, T, HV, L]   strided BTHVL (-> finalize_pre)
}


@vf()
def cast_tmp_to_bf16_vf(tmp_f_ub: Tensor, tmp_h_ub: Tensor):
    reg_f32 = Reg(DT.float)
    n_loops = Var(HALF_L * L / 64)
    for i in range(n_loops):
        reg_f32 <<= tmp_f_ub[i * 64]
        tmp_h_ub[i * 64] <<= reg_f32
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def neg_tril_vf(raw_ub: Tensor, dakk_ub: Tensor, row_begin: Var, rows: Var):
    # dAkk = -tril(dL_raw, -1): negate the strict-lower triangle, zero the rest.
    cols = Reg(DT.int)
    row = Reg(DT.float)
    out = Reg(DT.float)
    zero = Reg(DT.float)
    mask = MaskReg(DT.int, init_mode=MaskType.NONE)
    zero <<= 0.0
    for r in range(rows):
        rg = Var(row_begin + r)
        cols.arange(0)
        row <<= raw_ub[r:r + 1, 0:L]
        row <<= row * (-1.0)
        compare(mask, cols, rg, CompareMode.LT)
        select(out, row, zero, mask=mask)
        dakk_ub[r:r + 1, 0:L] <<= out
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def inverse_dakk_fused_kernel(
    Akk_bf16: GMTensor,
    Dtri_bf16: GMTensor,
    dAkk: GMTensor,
    B: Var,
    HV: Var,
    T: Var,
):
    tmp_mutex = CvMutex(0, depth=3, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    tmp_bridge = VcMutex(
        1,
        depth=3,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    out_mutex = CvMutex(2, depth=3, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1_Akk = TBuff(DT.bfloat16, [L, L], Position.L1)
    l1_Dtri = TBuff(DT.bfloat16, [L, L], Position.L1)
    l1_tmp = TBuff(DT.bfloat16, [L, L], Position.L1)
    l0c_tmp = TBuff(DT.float, [L, L], Position.L0C)
    l0c_out = TBuff(DT.float, [L, L], Position.L0C)
    tmp_f_ub = TBuff(DT.float, [HALF_L, L], Position.UB)
    tmp_h_ub = TBuff(DT.bfloat16, [HALF_L, L], Position.UB)
    dakk_f_ub = TBuff(DT.float, [HALF_L, L], Position.UB)
    dakk_h_ub = TBuff(DT.bfloat16, [HALF_L, L], Position.UB)

    chunk_count = Var(T / L)
    work_count = Var(B * HV * chunk_count)
    work_per_core = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_core * GetCubeIdx())
    work_end = Min(work_begin + work_per_core, work_count)
    row_begin_l = Var(GetSubBlockIdx() * HALF_L)
    row_end_l = Var(row_begin_l + HALF_L)

    # Two-stage software pipeline: the mm2 of work item i runs two iterations
    # behind its producer chain, so MTE2/M/FIX/V/MTE3 of consecutive chunks
    # overlap instead of serializing on the FIX -> UB -> L1 round trip.
    with auto_sync():
        for pipe_work in range(work_begin, work_end + 2):
            if pipe_work < work_end:
                c_idx = Var(pipe_work % chunk_count)
                bhv_idx = Var(pipe_work / chunk_count)
                hv_idx = Var(bhv_idx % HV)
                b_idx = Var(bhv_idx / HV)
                row0 = Var(c_idx * L)
                row1 = Var(row0 + L)

                # Akk strided from frozen BTHVL (explicit HV*L pitch); Dtri stays
                # GM-native [B, HV, T, L] (internal, from inverse_dainv).
                gm_to_l1_nd2nz(l1_Akk[pipe_work][0:L, 0:L], Akk_bf16[b_idx, row0:row1, hv_idx, 0:L], L, L, HV * L, L)
                l1_Dtri[pipe_work][0:L, 0:L] <<= Dtri_bf16[b_idx, hv_idx, row0:row1, 0:L]
                matmul(l0c_tmp[pipe_work], l1_Dtri[pipe_work], l1_Akk[pipe_work], m=L, n=L, k=L, splitn=L)

                tmp_mutex.lock()
                l0c_to_ub(tmp_f_ub[pipe_work], l0c_tmp[pipe_work], M=L, N=L, N_dst=L, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
                tmp_mutex.ready()
                tmp_mutex.wait()
                cast_tmp_to_bf16_vf(tmp_f_ub[pipe_work], tmp_h_ub[pipe_work])
                tmp_mutex.free()

                tmp_bridge.lock()
                l1_tmp[pipe_work][row_begin_l:row_end_l, 0:L] <<= tmp_h_ub[pipe_work][0:HALF_L, 0:L]
                tmp_bridge.ready()

            if pipe_work >= work_begin + 2:
                prev_work = Var(pipe_work - 2)
                prev_c = Var(prev_work % chunk_count)
                prev_bhv = Var(prev_work / chunk_count)
                prev_hv = Var(prev_bhv % HV)
                prev_b = Var(prev_bhv / HV)
                prev_row0 = Var(prev_c * L)
                prev_row1 = Var(prev_row0 + L)

                tmp_bridge.wait()
                matmul(l0c_out[prev_work], l1_Akk[prev_work].T, l1_tmp[prev_work].T, m=L, n=L, k=L, splitn=L)
                tmp_bridge.free()

                out_mutex.lock()
                l0c_to_ub(dakk_f_ub[prev_work], l0c_out[prev_work], M=L, N=L, N_dst=L, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
                out_mutex.ready()
                out_mutex.wait()
                neg_tril_vf(dakk_f_ub[prev_work], dakk_h_ub[prev_work], row_begin_l, Var(HALF_L))
                out_mutex.free()
                # dAkk written strided to the frozen BTHVL seam (-> finalize_pre):
                # SPLITM half-row store, explicit (HV-1)*L token gap.
                ub_to_gm_pad(dAkk[prev_b, prev_row0 + row_begin_l:prev_row0 + row_end_l, prev_hv, 0:L], dakk_h_ub[prev_work][0:HALF_L, 0:L], HALF_L, L, 0, (HV - 1) * L)

    return dAkk


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(Akk, D_tri, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    # Akk read strided from the frozen BTHVL cache [B, T, HV, L]; D_tri GM-native
    # [B, HV, T, L] (internal); dAkk written strided back to frozen BTHVL.
    B = int(Akk.shape[0])
    T = int(Akk.shape[1])
    HV = int(Akk.shape[2])
    for name, tensor in (("Akk", Akk), ("D_tri", D_tri)):
        if tensor.dtype != torch.bfloat16:
            raise TypeError(f"{name} must be bfloat16, got {tensor.dtype}")
    outputs = (torch.empty((B, T, HV, L), dtype=torch.bfloat16, device=Akk.device),)  # frozen BTHVL
    previous_config = getattr(inverse_dakk_fused_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "inverse_dakk_fused")
    if simulator:
        inverse_dakk_fused_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            inverse_dakk_fused_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            Akk, D_tri, outputs[0], B, HV, T, shape_bindings=SHAPE_BINDINGS
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(inverse_dakk_fused_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                inverse_dakk_fused_kernel._simulator_config = previous_config
    if gen_only:
        return result
    # dAkk is fully masked (-tril(dL_raw, -1)) in-kernel; raw GM [B, HV, T, L] bf16.
    return result


if __name__ == "__main__":
    torch.manual_seed(0)
    B, T, HV = 1, 128, 2
    Akk = torch.tril(torch.randn(B, T, HV, L) * 0.2).to(torch.bfloat16)
    D_tri = torch.tril(torch.randn(B, T, HV, L) * 0.2, diagonal=-1)

    # Akk raw frozen BTHVL (strided read); D_tri to GM-native (internal); dAkk
    # comes back BTHVL directly (no flat_hvtl).
    got = run(Akk, to_hvtl(D_tri.to(torch.bfloat16)), simulator=True)

    bf = lambda x: x.to(torch.bfloat16).float()
    tol = 2e-2  # |dL| ~ 1.6 with 0.2-scale smoke inputs; bf16 ULP ~ 8e-3 here
    for b in builtins.range(B):
        for c in builtins.range(T // L):
            s, e = c * L, (c + 1) * L
            for hv in builtins.range(HV):
                tmp = bf(D_tri[b, s:e, hv]) @ Akk[b, s:e, hv].float()
                dL = -(Akk[b, s:e, hv].float().T @ bf(tmp) @ Akk[b, s:e, hv].float().T)
                exp = torch.tril(dL, diagonal=-1).to(torch.bfloat16).float()
                torch.testing.assert_close(got[b, s:e, hv].float(), exp, rtol=tol, atol=tol)
    print(tuple(got.shape), got.dtype)
