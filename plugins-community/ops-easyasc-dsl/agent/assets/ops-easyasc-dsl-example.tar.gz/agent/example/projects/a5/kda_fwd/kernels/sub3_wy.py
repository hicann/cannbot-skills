"""KDA forward sub3: materialize w, u, qg, and kg from `eg`.

A5 implementation specialized to L=64, K=128, V=128 with dynamic B, H, HV,
and C where HV is a positive multiple of H. VF expands q/k to value heads and
materializes:

    qg = q * eg
    k_exp = k * eg
    kg = k * eg_last / eg
    A_beta = Akk * beta_col

Cube computes `w = A_beta @ k_exp` and `u = A_beta @ v`. `qg` is emitted as a
saved intermediate for backward, while `kg` feeds the fused state/output
subkernel.
"""

import argparse
import os
from pathlib import Path
import sys

import torch

_REPO_ROOT = Path(__file__).resolve().parents[4]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from easyasc.a5 import *  # noqa: F401,F403
from easyasc.simulator import SimulatorConfig


L = 64
K_DIM = 128
V_DIM = 128
K_BLOCK = 64
V_BLOCK = 64
K_TILES = K_DIM // K_BLOCK
V_TILES = V_DIM // V_BLOCK
HALF_L = L // 2
SPLIT_N = 64
DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 300.0

SHAPE_BINDINGS = {
    0: [0, 1, 3, 4, 5],  # q[B,H,C,L,K]
    1: [0, 1, 3, 4, 5],  # k[B,H,C,L,K]
    2: [0, 2, 3, 4, 6],  # v[B,HV,C,L,V]
    3: [0, 2, 3, 4],     # beta[B,HV,C,L]
    4: [0, 2, 3, 4, 4],  # Akk[B,HV,C,L,L]
    5: [0, 2, 3, 4, 5],  # eg[B,HV,C,L,K]
    6: [0, 2, 3, 4, 5],  # w[B,HV,C,L,K]
    7: [0, 2, 3, 4, 6],  # u[B,HV,C,L,V]
    8: [0, 2, 3, 4, 5],  # qg[B,HV,C,L,K]
    9: [0, 2, 3, 4, 5],  # kg[B,HV,C,L,K]
}


@vf()
def wy_preprocess_vf(
    q_ub: Tensor,
    k_ub: Tensor,
    beta_full_ub: Tensor,
    eg_ub: Tensor,
    eg_last_ub: Tensor,
    Akk_ub: Tensor,
    kexp_ub: Tensor,
    abeta_ub: Tensor,
    qg_ub: Tensor,
    kg_ub: Tensor,
    rows: Var,
):
    q_row = Reg(DT.float)
    k_row = Reg(DT.float)
    eg_row = Reg(DT.float)
    eg_last = Reg(DT.float)
    ratio_row = Reg(DT.float)
    a_row = Reg(DT.float)
    beta_row = Reg(DT.float)
    tmp_k = Reg(DT.float)
    tmp_a = Reg(DT.float)
    row_bf16 = Reg(DT.bfloat16)
    row_mask_bf16 = MaskReg(DT.bfloat16, init_mode=MaskType.NONE)

    row_mask_bf16 <<= Var(K_BLOCK * 2, dtype=DT.uint32)

    for r in range(rows):
        for tile in range(K_TILES):
            k_begin = tile * K_BLOCK
            k_end = k_begin + K_BLOCK
            q_row <<= q_ub[r:r + 1, k_begin:k_end]
            k_row <<= k_ub[r:r + 1, k_begin:k_end]
            eg_row <<= eg_ub[r:r + 1, k_begin:k_end]
            eg_last <<= eg_last_ub[0:1, k_begin:k_end]

            tmp_k <<= q_row * eg_row
            row_bf16 <<= tmp_k.astype(DT.bfloat16)
            reg_to_ub_downsample(qg_ub[r:r + 1, k_begin:k_end], row_bf16, mask=row_mask_bf16)

            tmp_k <<= k_row * eg_row
            row_bf16 <<= tmp_k.astype(DT.bfloat16)
            reg_to_ub_downsample(kexp_ub[r:r + 1, k_begin:k_end], row_bf16, mask=row_mask_bf16)

            ratio_row <<= eg_last / eg_row
            tmp_k <<= k_row * ratio_row
            row_bf16 <<= tmp_k.astype(DT.bfloat16)
            reg_to_ub_downsample(kg_ub[r:r + 1, k_begin:k_end], row_bf16, mask=row_mask_bf16)

        a_row <<= Akk_ub[r:r + 1, 0:L]
        beta_row <<= beta_full_ub[0:1, 0:L]
        tmp_a <<= a_row * beta_row
        row_bf16 <<= tmp_a.astype(DT.bfloat16)
        reg_to_ub_downsample(abeta_ub[r:r + 1, 0:L], row_bf16, mask=row_mask_bf16)


@kernel()
def kda_sub3_wy_kernel(
    q: GMTensor,
    k: GMTensor,
    v: GMTensor,
    beta: GMTensor,
    Akk: GMTensor,
    eg: GMTensor,
    w: GMTensor,
    u: GMTensor,
    qg: GMTensor,
    kg: GMTensor,
    B: Var,
    H: Var,
    HV: Var,
    C: Var,
    length_per_chunk: Var,
    head_dim: Var,
    value_dim: Var,
):
    vcmutex = VcMutex(
        0,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    l1_abeta = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_kexp = DBuff(DT.bfloat16, [L, K_DIM], Position.L1)
    l1_v = DBuff(DT.bfloat16, [L, V_DIM], Position.L1)
    l0c_w = DBuff(DT.float, [L, K_DIM], Position.L0C)
    l0c_u = DBuff(DT.float, [L, V_DIM], Position.L0C)

    q_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)
    k_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)
    beta_full_ub = DBuff(DT.float, [1, L], Position.UB)
    eg_ub = DBuff(DT.float, [HALF_L, K_DIM], Position.UB)
    eg_last_ub = DBuff(DT.float, [1, K_DIM], Position.UB)
    Akk_ub = DBuff(DT.bfloat16, [HALF_L, L], Position.UB)
    kexp_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)
    abeta_ub = DBuff(DT.bfloat16, [HALF_L, L], Position.UB)
    qg_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)
    kg_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)

    work_count = B * HV * C
    work_per_cube = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_cube * GetCubeIdx())
    work_end = Min(work_begin + work_per_cube, work_count)
    group = Var(HV // H)
    vcnt = Var(0)
    ccnt = Var(0)

    with auto_sync():
        for work in range(work_begin, work_end):
            c_idx = Var(work % C)
            tmp = Var(work // C)
            hv_idx = Var(tmp % HV)
            b_idx = Var(tmp // HV)
            h_idx = Var(hv_idx // group)

            row_begin = Var(GetSubBlockIdx() * HALF_L)
            row_end = Min(row_begin + HALF_L, L)
            rows_this = Var(row_end - row_begin)
            q_ub[vcnt][0:rows_this, 0:K_DIM] <<= q[b_idx, h_idx, c_idx, row_begin:row_end, 0:K_DIM]
            k_ub[vcnt][0:rows_this, 0:K_DIM] <<= k[b_idx, h_idx, c_idx, row_begin:row_end, 0:K_DIM]
            beta_full_ub[vcnt][0:1, 0:L] <<= beta[b_idx, hv_idx, c_idx, 0:L]
            eg_ub[vcnt][0:rows_this, 0:K_DIM] <<= eg[b_idx, hv_idx, c_idx, row_begin:row_end, 0:K_DIM]
            eg_last_ub[vcnt][0:1, 0:K_DIM] <<= eg[b_idx, hv_idx, c_idx, L - 1:L, 0:K_DIM]
            Akk_ub[vcnt][0:rows_this, 0:L] <<= Akk[b_idx, hv_idx, c_idx, row_begin:row_end, 0:L]
            wy_preprocess_vf(
                q_ub[vcnt],
                k_ub[vcnt],
                beta_full_ub[vcnt],
                eg_ub[vcnt],
                eg_last_ub[vcnt],
                Akk_ub[vcnt],
                kexp_ub[vcnt],
                abeta_ub[vcnt],
                qg_ub[vcnt],
                kg_ub[vcnt],
                rows_this,
            )
            
            qg[b_idx, hv_idx, c_idx, row_begin:row_end, 0:K_DIM] <<= qg_ub[vcnt][0:rows_this, 0:K_DIM]
            kg[b_idx, hv_idx, c_idx, row_begin:row_end, 0:K_DIM] <<= kg_ub[vcnt][0:rows_this, 0:K_DIM]
            
            vcmutex.lock()
            l1_abeta[ccnt][row_begin:row_end, 0:L] <<= abeta_ub[vcnt][0:rows_this, 0:L]
            l1_kexp[ccnt][row_begin:row_end, 0:K_DIM] <<= kexp_ub[vcnt][0:rows_this, 0:K_DIM]
            vcmutex.ready()

            l1_v[ccnt][0:L, 0:V_DIM] <<= v[b_idx, hv_idx, c_idx, 0:L, 0:V_DIM]
            
            vcnt += 1

            vcmutex.wait()
            matmul(l0c_w[ccnt], l1_abeta[ccnt], l1_kexp[ccnt].T, m=L, n=K_DIM, k=L, splitn=SPLIT_N)
            matmul(l0c_u[ccnt], l1_abeta[ccnt], l1_v[ccnt].T, m=L, n=V_DIM, k=L, splitn=SPLIT_N)
            vcmutex.free()
            w[b_idx, hv_idx, c_idx, 0:L, 0:K_DIM] <<= l0c_w[ccnt][0:L, 0:K_DIM]
            u[b_idx, hv_idx, c_idx, 0:L, 0:V_DIM] <<= l0c_u[ccnt][0:L, 0:V_DIM]
            ccnt += 1

    return w, u, qg, kg


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_fwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def _check_contract(q, k, v, beta, Akk, eg):
    B, H, C, length_per_chunk, head_dim = q.shape
    HV = v.shape[1]
    value_dim = v.shape[-1]
    if length_per_chunk != L or head_dim != K_DIM or value_dim != V_DIM:
        raise ValueError(
            f"sub3_wy is specialized for L={L}, K={K_DIM}, V={V_DIM}, "
            f"got L={length_per_chunk}, K={head_dim}, V={value_dim}"
        )
    if q.dtype != torch.bfloat16 or k.dtype != torch.bfloat16 or v.dtype != torch.bfloat16 or Akk.dtype != torch.bfloat16:
        raise TypeError("q, k, v, and Akk must be torch.bfloat16")
    if beta.dtype != torch.float32 or eg.dtype != torch.float32:
        raise TypeError("beta and eg must be torch.float32")
    if HV % H != 0:
        raise ValueError(f"HV must be divisible by H, got H={H}, HV={HV}")
    return B, H, HV, C, length_per_chunk, head_dim, value_dim


def run(q, k, v, beta, Akk, eg, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False, core_count=None):
    B, H, HV, C, length_per_chunk, head_dim, value_dim = _check_contract(q, k, v, beta, Akk, eg)
    w = torch.empty((B, HV, C, L, K_DIM), dtype=k.dtype, device=k.device)
    u = torch.empty((B, HV, C, L, V_DIM), dtype=v.dtype, device=v.device)
    qg = torch.empty((B, HV, C, L, K_DIM), dtype=q.dtype, device=q.device)
    kg = torch.empty((B, HV, C, L, K_DIM), dtype=k.dtype, device=k.device)
    trace_path = _trace_path(trace, out_dir, "sub3_wy")

    previous_config = getattr(kda_sub3_wy_kernel, "_simulator_config", None)
    if simulator:
        kda_sub3_wy_kernel._simulator_config = SimulatorConfig(
            core_count=core_count or DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            kda_sub3_wy_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(q, k, v, beta, Akk, eg, w, u, qg, kg, B, H, HV, C, length_per_chunk, head_dim, value_dim, shape_bindings=SHAPE_BINDINGS)
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(kda_sub3_wy_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                kda_sub3_wy_kernel._simulator_config = previous_config
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run KDA forward sub3_wy smoke or hardware profile case.")
    parser.add_argument("--hardware-profile", action="store_true", help="Run the real-hardware profile case: simulator=False, profile=True, B=1, H=HV=32, C=16.")
    parser.add_argument("--out-dir", default="", help="Output directory for generated hardware artifacts.")
    parser.add_argument("--skip-compile", action="store_true", help="Reuse previously compiled artifacts for the hardware profile run.")
    parser.add_argument("--gen-only", action="store_true", help="Generate hardware artifacts without running them.")
    parser.add_argument("--seed", type=int, default=31, help="Random seed for generated inputs.")
    parser.add_argument("--core-count", type=int, default=DEFAULT_CORE_COUNT, help="Simulator core count for non-hardware runs.")
    parser.add_argument("--trace", default=None, help="Path to write a simulator trace for non-hardware runs.")
    args = parser.parse_args()

    refs_dir = Path(__file__).resolve().parents[1] / "refs"
    if str(refs_dir) not in sys.path:
        sys.path.insert(0, str(refs_dir))
    from oracle import sample_inputs as oracle_sample_inputs, to_chunked_inputs
    from sub1_gate_ref import subkernel as ref_sub1_gate
    from sub2_intra_ref import subkernel as ref_sub2_intra
    from sub3_wy_ref import subkernel as ref_sub3_wy

    if args.hardware_profile:
        q_full, k_full, v_full, g_raw_full, beta_full, _initial_state = oracle_sample_inputs(
            B=1, H=32, HV=32, C=16, L=L, K=K_DIM, V=V_DIM, seed=args.seed
        )
        q, k, v, g_raw, beta = to_chunked_inputs(q_full, k_full, v_full, g_raw_full, beta_full, chunk_size=L)
        eg = ref_sub1_gate(g_raw)
        _Aqk, Akk = ref_sub2_intra(q, k, eg, beta, scale=K_DIM ** -0.5)
        out_dir = args.out_dir or "./tmp/kda_sub3_wy_hardware_profile"
        result = run(
            q,
            k,
            v,
            beta,
            Akk,
            eg,
            simulator=False,
            profile=True,
            gen_only=args.gen_only,
            out_dir=out_dir,
            skip_compile=args.skip_compile,
        )
        if args.gen_only:
            for name, out in zip(("w", "u", "qg", "kg"), result):
                print(f"{name}: shape={tuple(out.shape)} dtype={out.dtype}")
            print("pytorch verification skipped for --gen-only because no hardware output was produced")
        else:
            expected = ref_sub3_wy(q, k, v, beta, Akk, eg)
            for name, got, ref in zip(("w", "u", "qg", "kg"), result, expected):
                torch.testing.assert_close(got.float(), ref.float(), rtol=2e-2, atol=2e-2)
                max_abs = float((got.float() - ref.float()).abs().max())
                print(f"{name}: shape={tuple(got.shape)} dtype={got.dtype} max_abs={max_abs:.6e} OK")
        print(f"hardware profile case complete: B=1 H=32 HV=32 C=16 out_dir={out_dir}")
        raise SystemExit(0)

    q_full, k_full, v_full, g_raw_full, beta_full, _initial_state = oracle_sample_inputs(
        B=1, H=8, HV=8, C=8, L=L, K=K_DIM, V=V_DIM, seed=args.seed
    )
    q, k, v, g_raw, beta = to_chunked_inputs(q_full, k_full, v_full, g_raw_full, beta_full, chunk_size=L)
    eg = ref_sub1_gate(g_raw)
    _Aqk, Akk = ref_sub2_intra(q, k, eg, beta, scale=K_DIM ** -0.5)
    result = run(q, k, v, beta, Akk, eg, trace=args.trace, core_count=args.core_count)
    expected = ref_sub3_wy(q, k, v, beta, Akk, eg)
    for name, got, ref in zip(("w", "u", "qg", "kg"), result, expected):
        torch.testing.assert_close(got.float(), ref.float(), rtol=2e-2, atol=2e-2)
        max_abs = float((got.float() - ref.float()).abs().max())
        print(f"{name}: shape={tuple(got.shape)} dtype={got.dtype} max_abs={max_abs:.6e}")
