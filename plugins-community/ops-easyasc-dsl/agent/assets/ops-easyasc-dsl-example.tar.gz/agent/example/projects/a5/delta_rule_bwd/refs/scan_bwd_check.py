"""Local check: the split scan (local + state) equals the monolithic scan."""

import torch

from common import core_scan_bwd, make_inputs
from scan_split_bwd_ref import subkernel as scan_split


def main():
    for seed in (11, 17):
        torch.manual_seed(seed)
        full = make_inputs(B=1, H=2, C=2)
        split = scan_split(full[0], full[1], full[4], full[7], full[8], full[9], full[10])
        mono = core_scan_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])
        for act, exp in zip(split, mono):
            torch.testing.assert_close(act.float(), exp.float(), atol=0.0, rtol=0.0)
    print("scan_bwd (split == monolithic): OK")


if __name__ == "__main__":
    main()
