"""Speed test for FLA's chunked KDA forward (Triton) with torch.profiler.

This benchmarks the *reference* GPU implementation — FLA's public `chunk_kda`
op (`fla/ops/kda/chunk.py`), whose forward implementation lives in
`fla/ops/kda/chunk_fwd.py` (the upstream path that EasyASC `kda_fwd` will port).
It is the GPU baseline to compare the Ascend (a5/950) kernel against; it does
NOT run the EasyASC kernel.

Input semantics are aligned to the upstream `naive_chunk_kda` reference in
`fla/ops/kda/naive.py`: equal-length `[B, T, H/HV, *]` inputs with `cp_context=None`.
Branch decision for this profiler:
  * fix `use_gate_in_kernel=False`: this script only profiles the same
    precomputed log-space gate contract as `naive_chunk_kda`, i.e. the
    `chunk_local_cumsum` path.
  * do NOT cover `cp_context is not None`: that is a context-parallel wrapper
    path in `chunk.py`, not part of `naive.py`'s single-device reference contract.

Requires an NVIDIA CUDA GPU and `flash-linear-attention` installed:

    pip install flash-linear-attention   # pulls in triton
    python projects/a5/kda_fwd/test_script/profile_fla_kda.py

Representative shape (matches the local KDA project convention):

    B=1, H=32, HV=32, C=16, L=64, K=128, V=128   ->   FLA sequence length T = C*L = 1024

By default the script profiles the equal-length `[B, T, H/HV, *]` path with:
  * precomputed log-space gate input `g` (`use_gate_in_kernel=False`)
  * post-sigmoid `beta` (`use_beta_sigmoid_in_kernel=False`)
  * an explicit initial state

Use the CLI flags to switch only the beta / qk-l2norm related public options.

Output:
  * a torch.profiler key-averages table (top CUDA kernels), and
  * a clean CUDA-event headline latency (avg over the timed loop), which is the
    number to quote — profiler instrumentation itself adds a little overhead.
  * a Chrome trace written next to the script (open in chrome://tracing).
"""

from __future__ import annotations

import argparse
import inspect
import sys
from pathlib import Path

import torch
import torch.nn.functional as F


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--B", type=int, default=1, help="batch")
    p.add_argument("--H", type=int, default=32, help="q/k heads")
    p.add_argument("--HV", type=int, default=32, help="value/gate heads (must be a multiple of H)")
    p.add_argument("--C", type=int, default=16, help="number of chunks (T = C*L)")
    p.add_argument("--L", type=int, default=64, help="chunk length (FLA chunk_size)")
    p.add_argument("--K", type=int, default=128, help="q/k head dim")
    p.add_argument("--V", type=int, default=128, help="value head dim")
    p.add_argument("--iters", type=int, default=10, help="timed iterations")
    p.add_argument("--warmup", type=int, default=5, help="warmup iterations (untimed)")
    p.add_argument("--dtype", choices=("bf16", "fp16"), default="bf16")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--input-scale", type=float, default=0.01, help="stddev for q/v/initial_state")
    p.add_argument("--k-scale", type=float, default=0.05, help="stddev for k")
    p.add_argument("--attn-scale", type=float, default=None, help="attention score scale (default: K**-0.5)")
    p.add_argument("--no-initial-state", action="store_true", help="pass initial_state=None")
    p.add_argument("--output-final-state", action="store_true", help="request/report final_state")
    p.add_argument("--use-qk-l2norm-in-kernel", action="store_true",
                   help="let FLA normalize q/k internally")
    p.add_argument("--use-beta-sigmoid-in-kernel", action="store_true",
                   help="let FLA fuse beta sigmoid internally")
    p.add_argument("--allow-neg-eigval", action="store_true",
                   help="use 2*sigmoid(beta) when beta sigmoid is fused in-kernel")
    p.add_argument("--disable-recompute", action="store_true",
                   help="save forward intermediates instead of recomputing them")
    p.add_argument("--state-v-first", action="store_true",
                   help="store recurrent state in [V, K] layout instead of [K, V]")
    p.add_argument("--trace", type=str, default=str(Path(__file__).resolve().parent / "tmp" / "fla_kda_trace.json"),
                   help="Chrome trace output path")
    p.add_argument("--rows", type=int, default=15, help="rows in the profiler table")
    return p.parse_args()


def _randn(shape, dtype, device, scale=1.0):
    return (torch.randn(shape, device=device, dtype=torch.float32) * scale).to(dtype)


def _build_inputs(args, dtype, device):
    B, H, HV, C, L, Kdim, Vdim = args.B, args.H, args.HV, args.C, args.L, args.K, args.V
    T = C * L

    q = _randn((B, T, H, Kdim), dtype, device, scale=args.input_scale)
    k = _randn((B, T, H, Kdim), dtype, device, scale=args.k_scale)
    v = _randn((B, T, HV, Vdim), dtype, device, scale=args.input_scale)
    g = (-F.softplus(torch.randn(B, T, HV, Kdim, device=device, dtype=torch.float32))).to(dtype)

    if args.use_beta_sigmoid_in_kernel:
        beta = _randn((B, T, HV), dtype, device)
        beta_naive = torch.sigmoid(beta.float())
        if args.allow_neg_eigval:
            beta_naive = 2.0 * beta_naive
        beta_naive = beta_naive.to(dtype)
    else:
        beta = torch.sigmoid(torch.randn(B, T, HV, device=device, dtype=torch.float32)).to(dtype)
        beta_naive = beta

    initial_state = None
    if not args.no_initial_state:
        state_shape = (B, HV, Vdim, Kdim) if args.state_v_first else (B, HV, Kdim, Vdim)
        initial_state = _randn(state_shape, dtype, device, scale=args.input_scale)

    return q, k, v, g, beta, initial_state, beta_naive


def _format_shape(x) -> str:
    return "None" if x is None else str(tuple(x.shape))


def main() -> int:
    args = _parse_args()

    if args.HV % args.H != 0:
        print(f"ERROR: HV={args.HV} must be a multiple of H={args.H}.", file=sys.stderr)
        return 2
    if args.allow_neg_eigval and not args.use_beta_sigmoid_in_kernel:
        print("ERROR: --allow-neg-eigval requires --use-beta-sigmoid-in-kernel.", file=sys.stderr)
        return 2

    if not torch.cuda.is_available():
        print(
            "ERROR: FLA's chunk_kda is a Triton/CUDA kernel and needs an NVIDIA "
            "GPU. Run this on a CUDA box (it does not run on CPU / Ascend NPU).",
            file=sys.stderr,
        )
        return 2

    try:
        from fla.ops.kda import chunk_kda
    except Exception:
        try:
            from fla.ops.kda.chunk import chunk_kda
        except Exception as exc:  # pragma: no cover - depends on the runtime box
            print(f"ERROR: could not import fla.ops.kda.chunk_kda: {exc}", file=sys.stderr)
            print("Install with:  pip install flash-linear-attention", file=sys.stderr)
            return 2

    device = "cuda"
    dtype = torch.bfloat16 if args.dtype == "bf16" else torch.float16
    torch.manual_seed(args.seed)

    B, H, HV, C, L, Kdim, Vdim = args.B, args.H, args.HV, args.C, args.L, args.K, args.V
    T = C * L
    attn_scale = args.attn_scale if args.attn_scale is not None else Kdim ** -0.5

    params = inspect.signature(chunk_kda).parameters
    call_kwargs = {}
    maybe_kwargs = (
        ("scale", attn_scale),
        ("initial_state", None),  # filled after inputs are built
        ("output_final_state", args.output_final_state),
        ("use_qk_l2norm_in_kernel", args.use_qk_l2norm_in_kernel),
        ("use_gate_in_kernel", False),
        ("use_beta_sigmoid_in_kernel", args.use_beta_sigmoid_in_kernel),
        ("allow_neg_eigval", args.allow_neg_eigval),
        ("disable_recompute", args.disable_recompute),
        ("state_v_first", args.state_v_first),
    )

    q, k, v, g, beta, initial_state, beta_naive = _build_inputs(args, dtype, device)
    for name, value in maybe_kwargs:
        if name == "initial_state":
            value = initial_state
        if name in params and value is not None:
            call_kwargs[name] = value

    printable_kwargs = {}
    for key, value in call_kwargs.items():
        if torch.is_tensor(value):
            printable_kwargs[key] = tuple(value.shape)
        else:
            printable_kwargs[key] = value

    def run():
        out = chunk_kda(q, k, v, g, beta, **call_kwargs)
        if isinstance(out, (tuple, list)):
            return out[0], out[1] if len(out) > 1 else None
        return out, None

    o, final_state = run()
    torch.cuda.synchronize()

    print(
        f"FLA chunk_kda | B={B} H={H} HV={HV} C={C} L={L} K={Kdim} V={Vdim}  "
        f"T=C*L={T}"
    )
    print(
        "  scope: naive_chunk_kda-aligned equal-length contract "
        "(cp_context=None only)"
    )
    print(f"  signature kwargs: {printable_kwargs}")
    print(
        f"  inputs: q={tuple(q.shape)} k={tuple(k.shape)} v={tuple(v.shape)} "
        f"g={tuple(g.shape)} beta={tuple(beta.shape)} initial_state={_format_shape(initial_state)}"
    )
    print(
        f"  naive-aligned semantics: gate_mode=precomputed "
        f"(use_gate_in_kernel=False, chunk_local_cumsum path) "
        f"g_ref={tuple(g.shape)} beta_ref={tuple(beta_naive.shape)}"
    )
    print(f"  output: shape={tuple(o.shape)} dtype={o.dtype} finite={torch.isfinite(o).all().item()}")
    print(
        f"  final_state: shape={_format_shape(final_state)} "
        f"finite={True if final_state is None else torch.isfinite(final_state).all().item()}"
    )

    for _ in range(args.warmup):
        run()
    torch.cuda.synchronize()

    starter = torch.cuda.Event(enable_timing=True)
    ender = torch.cuda.Event(enable_timing=True)
    starter.record()
    for _ in range(args.iters):
        run()
    ender.record()
    torch.cuda.synchronize()
    total_ms = starter.elapsed_time(ender)
    per_iter_ms = total_ms / args.iters
    toks = B * T
    print(
        f"\n[cuda-event] {args.iters} iters: total={total_ms:.3f} ms  "
        f"avg={per_iter_ms:.4f} ms/iter  ({toks / (per_iter_ms * 1e3):.2f} Mtok/s)"
    )

    from torch.profiler import ProfilerActivity, profile, record_function

    with profile(
        activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
        record_shapes=True,
        with_stack=False,
    ) as prof:
        for _ in range(args.iters):
            with record_function("fla_chunk_kda_fwd"):
                run()
        torch.cuda.synchronize()

    print(f"\n[torch.profiler] top {args.rows} ops by CUDA self time over {args.iters} iters:")
    print(prof.key_averages().table(sort_by="self_cuda_time_total", row_limit=args.rows))

    trace_path = Path(args.trace)
    trace_path.parent.mkdir(parents=True, exist_ok=True)
    prof.export_chrome_trace(str(trace_path))
    print(f"[torch.profiler] Chrome trace written to {trace_path}  (open in chrome://tracing)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
