"""Sub-kernel reference: sub1 - M1 pure cube (q@k^T * causal_keep).

Ungated delta-rule analogue of `gdn_fwd/refs/sub1_ref.py`.  GDN multiplies by a
data-dependent `decay_mask`; the delta rule has no gate, so the multiplier is a
constant lower-triangular causal keep (incl. diagonal) — exactly GDN's
`decay_mask` at `g == 0`.  There is therefore no `decay_mask` GM input.

I/O contract
------------
Inputs:
  - q_i:  torch.bfloat16 [B, H, C, 64, 128]  memory=GM
  - k_i:  torch.bfloat16 [B, H, C, 64, 128]  memory=GM

Outputs:
  - attn: torch.bfloat16 [B, H, C, 64, 64]   memory=GM

Producer(s): user input
Consumer(s): sub2

Primitives used: [P6, L1]

Precision
---------
L1 (matmul downcast bf16): q_i, k_i are bf16-origin -> L1 identity roundtrip.
The causal keep multiply happens on fp32 after the matmul, no L1 involved.
"""

import torch


def subkernel(q_i, k_i):
    L = q_i.shape[-2]
    causal_keep = torch.tril(torch.ones(L, L, dtype=torch.float32, device=q_i.device))
    q_fp32 = q_i.float()
    k_fp32 = k_i.float()
    attn = (q_fp32.to(torch.bfloat16).to(torch.float32)
            @ k_fp32.to(torch.bfloat16).to(torch.float32).transpose(-1, -2)) * causal_keep
    return attn.bfloat16()
