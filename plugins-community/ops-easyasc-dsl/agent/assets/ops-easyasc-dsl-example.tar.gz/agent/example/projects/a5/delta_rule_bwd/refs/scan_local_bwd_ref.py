"""Pure PyTorch reference for the split scan local stage (ungated)."""

from common import make_inputs, scan_local_bwd


def subkernel(query, key, grad_output, v_new_history):
    return scan_local_bwd(query, key, grad_output, v_new_history)


if __name__ == "__main__":
    args = make_inputs()
    result = subkernel(args[0], args[1], args[4], args[9])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
