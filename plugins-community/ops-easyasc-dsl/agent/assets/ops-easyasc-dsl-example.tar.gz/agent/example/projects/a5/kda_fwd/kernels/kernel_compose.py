"""Plan-local KDA forward kernel composition."""

from pathlib import Path
import sys
from typing import Optional

import torch


KERNELS_DIR = Path(__file__).resolve().parent
if str(KERNELS_DIR) not in sys.path:
    sys.path.insert(0, str(KERNELS_DIR))

from sub1_gate import run as run_sub1_gate  # noqa: E402
from sub2_intra import run as run_sub2_intra  # noqa: E402
from sub3_wy import run as run_sub3_wy  # noqa: E402
from sub45_fused import run as run_sub45_fused  # noqa: E402


DEFAULT_CHUNK_SIZE = 64
L = DEFAULT_CHUNK_SIZE
K_DIM = 128
V_DIM = 128


def _trace_name(trace, name):
    if trace is True:
        return True
    if trace:
        trace_path = Path(trace)
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    return trace


def _child_out_dir(out_dir, name):
    """Give each sub-kernel its own subdirectory so their generated custom-op
    packages do not collide under a shared compose out_dir."""
    if not out_dir:
        return out_dir
    return str(Path(out_dir) / name)


def from_chunked_output(o):
    B, HV, C, length_per_chunk, value_dim = o.shape
    return o.permute(0, 2, 3, 1, 4).reshape(B, C * length_per_chunk, HV, value_dim).contiguous()


def _check_dtype(name, tensor, dtype):
    if tensor.dtype != dtype:
        raise TypeError(f"{name} dtype must be {dtype}, got {tensor.dtype}")


def _check_shape(name, tensor, shape):
    if tuple(tensor.shape) != tuple(shape):
        raise ValueError(f"{name} shape must be {tuple(shape)}, got {tuple(tensor.shape)}")


def _check_sequence_inputs(q, k, v, g_raw, beta, chunk_size=DEFAULT_CHUNK_SIZE):
    if chunk_size != L:
        raise ValueError(f"kernel_compose is specialized for chunk_size={L}, got {chunk_size}")
    if q.ndim != 4:
        raise ValueError(f"q must be [B,T,H,K], got {tuple(q.shape)}")
    for name, tensor, ndim in (("k", k, 4), ("v", v, 4), ("g_raw", g_raw, 4), ("beta", beta, 3)):
        if tensor.ndim != ndim:
            raise ValueError(f"{name} must have rank {ndim}, got {tuple(tensor.shape)}")

    B, T, H, head_dim = (int(x) for x in q.shape)
    if T % chunk_size != 0:
        raise ValueError(f"T={T} must be divisible by chunk_size={chunk_size}")
    if head_dim != K_DIM:
        raise ValueError(f"kernel_compose is specialized for K={K_DIM}, got K={head_dim}")

    HV = int(v.shape[2])
    value_dim = int(v.shape[-1])
    if value_dim != V_DIM:
        raise ValueError(f"kernel_compose is specialized for V={V_DIM}, got V={value_dim}")
    if H <= 0 or HV <= 0 or HV % H != 0:
        raise ValueError(f"HV must be a positive multiple of H, got H={H}, HV={HV}")

    _check_shape("k", k, (B, T, H, head_dim))
    _check_shape("v", v, (B, T, HV, value_dim))
    _check_shape("g_raw", g_raw, (B, T, HV, head_dim))
    _check_shape("beta", beta, (B, T, HV))

    _check_dtype("q", q, torch.bfloat16)
    _check_dtype("k", k, torch.bfloat16)
    _check_dtype("v", v, torch.bfloat16)
    _check_dtype("g_raw", g_raw, torch.float32)
    _check_dtype("beta", beta, torch.float32)

    devices = {tensor.device for tensor in (q, k, v, g_raw, beta)}
    if len(devices) != 1:
        raise ValueError(f"all sequence inputs must be on one device, got {sorted(str(device) for device in devices)}")

    C = T // chunk_size
    return B, T, H, HV, C, head_dim, value_dim


def _check_initial_state(initial_state, B, HV, head_dim, value_dim, device):
    if initial_state is None:
        return torch.zeros((B, HV, head_dim, value_dim), dtype=torch.float32, device=device)
    _check_shape("initial_state", initial_state, (B, HV, head_dim, value_dim))
    _check_dtype("initial_state", initial_state, torch.float32)
    if initial_state.device != device:
        raise ValueError(f"initial_state device must be {device}, got {initial_state.device}")
    return initial_state


def to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=DEFAULT_CHUNK_SIZE):
    B, _T, H, HV, C, head_dim, value_dim = _check_sequence_inputs(q, k, v, g_raw, beta, chunk_size)
    q_c = q.reshape(B, C, chunk_size, H, head_dim).permute(0, 3, 1, 2, 4).contiguous()
    k_c = k.reshape(B, C, chunk_size, H, head_dim).permute(0, 3, 1, 2, 4).contiguous()
    v_c = v.reshape(B, C, chunk_size, HV, value_dim).permute(0, 3, 1, 2, 4).contiguous()
    g_c = g_raw.reshape(B, C, chunk_size, HV, head_dim).permute(0, 3, 1, 2, 4).contiguous()
    beta_c = beta.reshape(B, C, chunk_size, HV).permute(0, 3, 1, 2).contiguous()
    return q_c, k_c, v_c, g_c, beta_c


def run(
    q,
    k,
    v,
    g_raw,
    beta,
    initial_state: Optional[torch.Tensor] = None,
    simulator=True,
    trace=None,
    gen_only=False,
    out_dir="",
    skip_compile=False,
    profile=False,
    chunk_size=DEFAULT_CHUNK_SIZE,
):
    B, _T, _H, HV, _C, head_dim, value_dim = _check_sequence_inputs(q, k, v, g_raw, beta, chunk_size)
    initial_state = _check_initial_state(initial_state, B, HV, head_dim, value_dim, q.device)
    scale = head_dim ** -0.5
    q_c, k_c, v_c, g_raw_c, beta_c = to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=chunk_size)
    g = run_sub1_gate(
        g_raw_c,
        simulator=simulator,
        trace=_trace_name(trace, "sub1_gate"),
        gen_only=gen_only,
        out_dir=_child_out_dir(out_dir, "sub1_gate"),
        skip_compile=skip_compile,
        profile=profile,
    )
    Aqk, Akk = run_sub2_intra(
        q_c,
        k_c,
        g,
        beta_c,
        scale,
        simulator=simulator,
        trace=_trace_name(trace, "sub2_intra"),
        gen_only=gen_only,
        out_dir=_child_out_dir(out_dir, "sub2_intra"),
        skip_compile=skip_compile,
        profile=profile,
    )
    w, u, _qg, kg = run_sub3_wy(
        q_c,
        k_c,
        v_c,
        beta_c,
        Akk,
        g,
        simulator=simulator,
        trace=_trace_name(trace, "sub3_wy"),
        gen_only=gen_only,
        out_dir=_child_out_dir(out_dir, "sub3_wy"),
        skip_compile=skip_compile,
        profile=profile,
    )
    o_c, final_state = run_sub45_fused(
        q_c,
        Aqk,
        kg,
        w,
        u,
        g,
        initial_state,
        scale,
        simulator=simulator,
        trace=_trace_name(trace, "sub45_fused"),
        gen_only=gen_only,
        out_dir=_child_out_dir(out_dir, "sub45_fused"),
        skip_compile=skip_compile,
        profile=profile,
    )
    return from_chunked_output(o_c), final_state


def _sample_inputs(
    B=1,
    H=1,
    HV=1,
    C=1,
    chunk_size=DEFAULT_CHUNK_SIZE,
    head_dim=K_DIM,
    value_dim=V_DIM,
    seed=42,
):
    generator = torch.Generator(device="cpu").manual_seed(seed)
    T = C * chunk_size
    q = torch.randn(B, T, H, head_dim, generator=generator).mul(0.04).to(torch.bfloat16)
    k = torch.randn(B, T, H, head_dim, generator=generator).mul(0.04).to(torch.bfloat16)
    v = torch.randn(B, T, HV, value_dim, generator=generator).mul(0.04).to(torch.bfloat16)
    g_raw = -torch.rand(B, T, HV, head_dim, generator=generator).mul(0.03)
    beta = torch.rand(B, T, HV, generator=generator).mul(0.45).add(0.05)
    initial_state = torch.randn(B, HV, head_dim, value_dim, generator=generator).mul(0.01)
    return q, k, v, g_raw, beta, initial_state


if __name__ == "__main__":
    result = run(*_sample_inputs(), simulator=True)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
