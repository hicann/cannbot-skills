# KDA Forward (a5)

Decomposition project for the fixed-length KDA forward path from
`fla/ops/kda/chunk_fwd.py`.

The checked-in refs follow the same project shape as `projects/a5/gdn_fwd/`:
the `refs/` directory contains the executable PyTorch oracle, sub-kernel
references, local checks, DAG, and the human plan. The `kernels/` directory
contains the A5 EasyASC sub-kernels and plan-local composition runner. The
`test_script/` directory holds the simulator/onboard correctness entry. The
production path uses `sub45_fused.py` for the recurrent state bridge plus final
output assembly; standalone sub4/sub5 kernel modules are no longer kept.

## Layout

- `refs/oracle.py` - naive recurrent KDA oracle, cross-checked against the
  upstream `naive.py` behavior.
- `refs/sub1_gate_ref.py` - chunk-local gate cumsum materialized in linear
  space, `exp(cumsum(g_raw))`.
- `refs/sub2_intra_ref.py` - intra-chunk `Aqk` and triangular `Akk` solve.
- `refs/sub3_wy_ref.py` - WY materialization: `w`, `u`, `qg`, and chunk-final
  scaled `kg`; `qg` is kept as a backward-facing saved intermediate.
- `refs/sub45_fused_ref.py` - self-contained fused tail that runs the recurrent
  state bridge and GLA-style output assembly in one unit, keeping `h` and
  `v_new` internal and returning only `o` and `final_state`.
- `refs/compose.py` - runs the full four-unit decomposed path and compares with
  the oracle. `chunk_size` defaults to 64 but can be varied for reference runs.
- `refs/dag.json` and `refs/plan.md` - machine-readable and human-readable
  decomposition contract.
- `kernels/` - authored A5 sub-kernels (`sub1_gate`, `sub2_intra`, `sub3_wy`,
  `sub45_fused`) plus the `kernel_compose.py` composition runner.
- `test_script/module_vs_ref.py` - module-by-module kernel-vs-ref checks
  (leaf = `sub1_gate`/`sub2_intra`/`sub3_wy`/`sub45_fused`, stage = `compose`),
  with `--mode simulator|onboard`, `--upstream ref|kernel`, shape args, and
  per-tensor reporting. `--module compose` is the end-to-end check.
- `test_script/run_onboard_profile.sh` - bash driver for `module_vs_ref.py` on
  the Ascend box: sets `PYTHONPATH`, picks the python runner, runs onboard with
  `--profile`, and prints a per-kernel HW timing summary.
- `test_script/profile_fla_kda.py` - FLA (Triton) GPU baseline profiler for the
  upstream `chunk_kda` forward; the number the Ascend kernels are compared against.
- `optimization_timeline.md` - project-local optimization history and retained
  implementation notes.

## Running

From the repo root:

```bash
# Pure-PyTorch reference checks (no PYTHONPATH needed):
python -m py_compile projects/a5/kda_fwd/refs/*.py
for f in projects/a5/kda_fwd/refs/*_check.py; do python "$f"; done
python projects/a5/kda_fwd/refs/compose.py

# Module-by-module kernel-vs-ref in the simulator (leaf kernels + compose):
PYTHONPATH=. python projects/a5/kda_fwd/test_script/module_vs_ref.py --module all
# end-to-end only (kernels via compose vs oracle):
PYTHONPATH=. python projects/a5/kda_fwd/test_script/module_vs_ref.py --module compose

# Onboard (Ascend 950) profile + correctness, on the HW box:
projects/a5/kda_fwd/test_script/run_onboard_profile.sh
MODULE=leaf UPSTREAM=kernel projects/a5/kda_fwd/test_script/run_onboard_profile.sh
```

The plan is intentionally scoped to the normal fixed-length path:
`cu_seqlens=None`, `cp_context=None`, `use_gate_in_kernel=False`,
`safe_gate=False`, and `state_v_first=False`. The PyTorch refs infer the chunk
length `L` from tensor shapes; local validation covers both `chunk_size=32` and
`chunk_size=64`, matching the upstream optimized KDA intra kernel's supported
sizes.
