# GDN Forward (a5)

System project that wires the GDN forward attention block into runnable EasyASC
DSL kernels on a5. The files here cooperate as one algorithm and use the same
root layout as `projects/a5/gdn_bwd/`.

## Layout

- `gdn_full.py` - chunked-first full runner and reference comparison harness.
- `kernels/gdn_preprocess.py` - current `cube -> vec` preprocess path:
  `g @ triu`, bf16-input `key @ key.T`, fp32 beta/decay/mask postprocess.
- `kernels/tril_inverse64.py` - staged strict-lower `A -> inverse(I - A)`
  handoff, including the bf16 GM output used by recompute-WU.
- `kernels/gdn_recompute_wu.py` - recompute-WU path:
  `attn @ bf16(value * beta)` and
  `attn @ bf16(key * beta * exp(g_cumsum))`.
- `kernels/chunk_delta_compose.py` - plain forward chunk recurrence.
- `kernels/chunk_delta_compose_state_history.py` - forward recurrence variant
  that also writes the saved tensors consumed by backward:
  `state_after_history`, `v_new_history`, `k_weighted_history`, and
  `exp_delta_history`.
- `kernels/chunk_delta_sub*.py` - sub-kernels used by the two compose entries.
- `refs/` - PyTorch oracle and sub-kernel reference checks.
- `test_script/` - simulator/onboard correctness checks.

The old legacy v1 kernels were removed from this checked-in project. Internal
Python function names such as `gdn_preprocess_v2` remain where they are useful
for ABI compatibility and historical trace labels.

## Running

All scripts assume the repo root is on `PYTHONPATH`. From the repo root:

```bash
python projects/a5/gdn_fwd/kernels/gdn_preprocess.py
python projects/a5/gdn_fwd/kernels/tril_inverse64.py
python projects/a5/gdn_fwd/test_script/check_chunk_delta_vs_ref.py
python projects/a5/gdn_fwd/test_script/check_chunk_delta_state_history_vs_ref.py
python projects/a5/gdn_fwd/gdn_full.py --check-kernels --B 1 --H 32 --C 16
bash projects/a5/gdn_fwd/test_script/run_onboard_profile.sh
bash projects/a5/gdn_fwd/test_script/run_onboard_chunk_delta.sh
```

The full-path runner keeps the internal contract chunked as
`[B,H,C,64,128]` / `[B,H,C,64]`. Its `gdn_full_chunked_kernels(...)` path
launches the split kernels in order. Pass `--state-after-history` to exercise
the forward path that publishes the backward-facing saved tensors.

For onboard runs, `run_onboard_profile.sh` accepts `VARIANT=plain`,
`VARIANT=state_history`, or `VARIANT=both` and defaults to the full
`(B,H,C)=(1,32,16)` profile shape. `run_onboard_chunk_delta.sh` is the smaller
standalone recurrence smoke/profile entry and defaults to `(1,32,8)`. Both
scripts accept `B=... H=... C=... SEED=... OUT_DIR=... PYTHON_CMD=...`.

## Stage Relationships

```text
gdn_preprocess        -> preprocess_attn(strict A), g_cumsum, decay_mask
        |
        v
tril_inverse64        -> wu_attn_bf16
        |
        v
gdn_recompute_wu      -> value_out, k_cumdecay
        |
        v
chunk_delta_compose   -> core_attn_out, final_state
        |
        +-- chunk_delta_compose_state_history also writes backward saved state
```

## Performance notes (CANNSIM)

Timing reference is **CANNSIM** (CANN's cycle simulator, `Ascend950`), not the
easyasc Python simulator — the latter over-estimates `chunk_delta_sub2` by ~31%
and mis-ranks its ops (it over-charges arithmetic VFs and under-charges the
`reg_to_ub` NZ strided stores). Measured single-core, `B=1,H=1,C=4` (L=64,D=128),
`block_dim=1`.

| kernel | change | CANNSIM makespan |
|--------|--------|------------------|
| `chunk_delta_sub2` | baseline | 32284 cycles |
| `chunk_delta_sub2` | unroll the bf16 NZ pack VFs | **29589 cycles (-8.3%)** |

The bf16 NZ pack VFs (`pack_bf16_*_rows_to_nz_vf`) used a runtime `for r in
range(rows)` with `rows: Var`, which re-emits scalar address arithmetic + a loop
branch per row and serializes the load->store chain. Specializing them to
compile-time-constant loops (`range(HALF_L)` / `range(HALF_D)`) lets the stores
overlap: per-VF `pack_state` 1331->584 cyc (-56%), `pack_vnew` 712->333 (-53%).
Correctness stays bit-exact vs the PyTorch oracle. The dominant remaining cost is
cube/vec **sync/serialization** — `WAIT_FLAG` stalls total ~163% x pipe (7 depth-1
handshakes per chunk + the serial state recurrence); no single pipe saturates
(loads ~36%, scalar ~33%, vector ~26%, MTE3 store only ~12%). So the next levers
are reducing handshakes + opening run-ahead (merge M2+M3, `ub_to_l1_nd2nz`
one-step publish to drop a pack stage, cross-`bh` overlap), NOT offloading stores.
See `tmp_report_chunk_delta_sub2.md` (repo root) for the full analysis.
