"""Module-by-module kernel-vs-reference checks for canonical gdn_bwd.

Default behavior runs plan pipeline modules with simulator=True and feeds each
module reference upstream tensors. That isolates the first bad module instead
of letting an earlier wrong stage poison every downstream check.

Examples:
  python projects/a5/gdn_bwd/test_script/module_vs_ref.py
  python projects/a5/gdn_bwd/test_script/module_vs_ref.py --module scan_state_bwd --seed 101 --B 1 --H 2 --C 2
  python projects/a5/gdn_bwd/test_script/module_vs_ref.py --module all --upstream kernel --stop-on-fail
  python projects/a5/gdn_bwd/test_script/module_vs_ref.py --trace --out-dir tmp/gdn_bwd_debug
"""

import argparse
import inspect
import importlib
import sys
from pathlib import Path

import torch


SCRIPT_DIR = Path(__file__).resolve().parent
PLAN_DIR = SCRIPT_DIR.parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)

for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import ATOL as DEFAULT_ATOL, RTOL as DEFAULT_RTOL, make_inputs  # noqa: E402
from finalize_bwd_ref import subkernel as ref_finalize_bwd  # noqa: E402
from inverse_preprocess_bwd_ref import subkernel as ref_inverse_preprocess_bwd  # noqa: E402
from oracle import oracle as ref_oracle  # noqa: E402
from scan_bwd_ref import subkernel as ref_scan_bwd  # noqa: E402
from scan_local_bwd_ref import subkernel as ref_scan_local_bwd  # noqa: E402
from scan_split_bwd_ref import subkernel as ref_scan_split_bwd  # noqa: E402
from scan_state_bwd_ref import subkernel as ref_scan_state_bwd  # noqa: E402
from wu_bwd_ref import subkernel as ref_wu_bwd  # noqa: E402


PIPELINE_MODULES = [
    "scan_local_bwd",
    "scan_state_bwd",
    "scan_split_bwd",
    "wu_bwd",
    "inverse_preprocess_bwd",
    "finalize_bwd",
    "compose",
]
EXTRA_MODULES = []
MODULE_ALIASES = {
    "pipeline": PIPELINE_MODULES,
    "all": PIPELINE_MODULES + EXTRA_MODULES,
}
MODULE_OUTPUT_NAMES = {
    "scan_local_bwd": ["d_score_tmp", "d_v_attn_tmp", "d_decay_core", "d_decay_core_masked"],
    "scan_state_bwd": ["d_q_core", "d_k_core", "d_g_core", "d_value_wu", "d_k_cumdecay"],
    "scan_split_bwd": ["d_q_core", "d_k_core", "d_g_core", "d_decay_core", "d_value_wu", "d_k_cumdecay", "d_decay_core_masked"],
    "wu_bwd": ["d_wu", "d_v_beta", "d_k_beta_wu", "d_g_wu"],
    "inverse_preprocess_bwd": ["d_k_pre", "d_k_beta_pre", "d_decay_pre", "d_decay_pre_masked"],
    "finalize_bwd": ["d_key", "d_value", "d_beta", "d_g"],
    "compose": ["d_query", "d_key", "d_value", "d_beta", "d_g"],
}


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    return (value,)


def _parse_csv_ints(text):
    result = []
    for item in text.split(","):
        item = item.strip()
        if item:
            result.append(int(item))
    return result


def _expand_modules(items):
    modules = []
    for item in items:
        for name in item.split(","):
            name = name.strip()
            if not name:
                continue
            modules.extend(MODULE_ALIASES.get(name, [name]))

    seen = set()
    expanded = []
    valid = set(PIPELINE_MODULES + EXTRA_MODULES)
    valid_names = valid | set(MODULE_ALIASES)
    for name in modules:
        if name not in valid:
            raise ValueError("unknown module %r; valid: %s" % (name, ", ".join(sorted(valid_names))))
        if name not in seen:
            expanded.append(name)
            seen.add(name)
    return expanded


def _kernel_run(name):
    module = importlib.import_module(name)
    return module.run


def _trace_value(trace_root, module_name, seed):
    if not trace_root:
        return None
    path = Path(trace_root) / ("seed_%s" % seed) / ("%s.json" % module_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


def _call_run(run_fn, args, options, module_name, seed):
    # Keep reference/cache tensors immutable from the harness point of view.
    # Some OpExec paths can receive tensors that are later reused by another
    # module check, so pass per-call tensor clones to avoid cross-check poison.
    call_out_dir = str(Path(options.out_dir) / module_name) if options.out_dir else ""
    call_args = tuple(arg.clone() if torch.is_tensor(arg) else arg for arg in args)
    kwargs = {
        "simulator": (options.mode == "simulator"),
        "trace": _trace_value(options.trace_root, module_name, seed),
        "out_dir": call_out_dir,
        "skip_compile": options.skip_compile,
    }
    if options.profile and "profile" in inspect.signature(run_fn).parameters:
        kwargs["profile"] = True
    return _as_tuple(
        run_fn(
            *call_args,
            **kwargs
        )
    )


def _compare_tensor(module_name, output_name, index, actual, expected, atol, rtol):
    if tuple(actual.shape) != tuple(expected.shape):
        print(
            "  [%s.%s] shape FAIL actual=%s expected=%s"
            % (module_name, output_name, tuple(actual.shape), tuple(expected.shape))
        )
        return False

    actual_f = actual.float()
    expected_f = expected.float()
    if not torch.isfinite(actual_f).all() or not torch.isfinite(expected_f).all():
        print("  [%s.%s] finite FAIL" % (module_name, output_name))
        return False

    diff = (actual_f - expected_f).abs()
    rel = diff / expected_f.abs().clamp_min(1e-12)
    close = torch.isclose(actual_f, expected_f, atol=atol, rtol=rtol)
    ok = bool(close.all())
    bad_count = int((~close).sum().item())
    max_abs = float(diff.max()) if diff.numel() else 0.0
    max_rel = float(rel.max()) if rel.numel() else 0.0

    flat_idx = int(diff.reshape(-1).argmax().item()) if diff.numel() else 0
    idx_tuple = tuple(int(i) for i in torch.unravel_index(torch.tensor(flat_idx), diff.shape))
    actual_val = float(actual_f[idx_tuple]) if diff.numel() else 0.0
    expected_val = float(expected_f[idx_tuple]) if diff.numel() else 0.0
    status = "OK" if ok else "FAIL"
    print(
        "  [%s.%s] %s shape=%s dtype=%s max_abs=%.3e max_rel=%.3e bad=%d idx=%s got=%.8e ref=%.8e"
        % (
            module_name,
            output_name or ("output%d" % index),
            status,
            tuple(actual.shape),
            actual.dtype,
            max_abs,
            max_rel,
            bad_count,
            idx_tuple,
            actual_val,
            expected_val,
        )
    )
    return ok


def _compare_tuple(module_name, actual, expected, atol, rtol):
    actual = _as_tuple(actual)
    expected = _as_tuple(expected)
    if len(actual) != len(expected):
        print("  [%s] arity FAIL actual=%d expected=%d" % (module_name, len(actual), len(expected)))
        return False

    names = MODULE_OUTPUT_NAMES.get(module_name, [])
    ok = True
    for idx, (act, exp) in enumerate(zip(actual, expected)):
        output_name = names[idx] if idx < len(names) else "output%d" % idx
        ok = _compare_tensor(module_name, output_name, idx, act, exp, atol, rtol) and ok
    return ok


class GdnBwdCase(object):
    def __init__(self, seed, shape, options):
        self.seed = seed
        self.shape = shape
        self.options = options
        torch.manual_seed(seed)
        self.inputs = make_inputs(*shape)
        self.ref_cache = {}
        self.kernel_cache = {}

    def ref_scan_local(self):
        if "scan_local_bwd" not in self.ref_cache:
            full = self.inputs
            self.ref_cache["scan_local_bwd"] = _as_tuple(
                ref_scan_local_bwd(full[0], full[1], full[5], full[7], full[12])
            )
        return self.ref_cache["scan_local_bwd"]

    def ref_scan_state(self, local=None):
        use_cache = local is None
        if use_cache and "scan_state_bwd" in self.ref_cache:
            return self.ref_cache["scan_state_bwd"]
        full = self.inputs
        local = self.ref_scan_local() if local is None else local
        result = _as_tuple(
            ref_scan_state_bwd(
                full[0], full[1], full[5], full[6], full[10], full[11],
                full[14], local[0], full[12], full[13], local[1], full[15],
            )
        )
        if use_cache:
            self.ref_cache["scan_state_bwd"] = result
        return result

    def ref_scan_split(self):
        if "scan_split_bwd" not in self.ref_cache:
            full = self.inputs
            self.ref_cache["scan_split_bwd"] = _as_tuple(
                ref_scan_split_bwd(full[0], full[1], full[5], full[6], full[7], full[10], full[11], full[12], full[13], full[14], full[15])
            )
        return self.ref_cache["scan_split_bwd"]

    def ref_wu(self, scan=None):
        use_cache = scan is None
        if use_cache and "wu_bwd" in self.ref_cache:
            return self.ref_cache["wu_bwd"]
        full = self.inputs
        scan = self.ref_scan_split() if scan is None else scan
        result = _as_tuple(ref_wu_bwd(full[1], full[2], full[3], full[6], full[8], scan[4], scan[5]))
        if use_cache:
            self.ref_cache["wu_bwd"] = result
        return result

    def ref_inverse(self, wu=None):
        use_cache = wu is None
        if use_cache and "inverse_preprocess_bwd" in self.ref_cache:
            return self.ref_cache["inverse_preprocess_bwd"]
        full = self.inputs
        wu = self.ref_wu() if wu is None else wu
        result = _as_tuple(ref_inverse_preprocess_bwd(full[1], full[3], full[7], full[8], wu[0]))
        if use_cache:
            self.ref_cache["inverse_preprocess_bwd"] = result
        return result

    def ref_finalize(self, scan=None, wu=None, inv=None):
        use_cache = scan is None and wu is None and inv is None
        if use_cache and "finalize_bwd" in self.ref_cache:
            return self.ref_cache["finalize_bwd"]
        full = self.inputs
        scan = self.ref_scan_split() if scan is None else scan
        wu = self.ref_wu(scan) if wu is None else wu
        inv = self.ref_inverse(wu) if inv is None else inv
        result = _as_tuple(
            ref_finalize_bwd(
                full[1], full[2], full[3], full[7],
                scan[0], scan[1], scan[2], scan[3],
                wu[1], wu[2], wu[3],
                inv[0], inv[1], inv[2],
            )
        )
        if use_cache:
            self.ref_cache["finalize_bwd"] = result
        return result

    def ref_compose(self):
        if "compose" not in self.ref_cache:
            self.ref_cache["compose"] = _as_tuple(ref_oracle(*self.inputs))
        return self.ref_cache["compose"]

    def kernel_scan_local(self):
        if "scan_local_bwd" not in self.kernel_cache:
            full = self.inputs
            self.kernel_cache["scan_local_bwd"] = _call_run(
                _kernel_run("scan_local_bwd"),
                (full[0], full[1], full[5], full[7], full[12]),
                self.options,
                "scan_local_bwd",
                self.seed,
        )
        return self.kernel_cache["scan_local_bwd"]

    def _scan_state_inputs(self):
        full = self.inputs
        local = self.kernel_scan_local() if self.options.upstream == "kernel" else self.ref_scan_local()
        return (
            full[0], full[1], full[5], full[6], full[10], full[11],
            full[14], local[0], full[12], full[13], local[1], full[15],
        ), local

    def kernel_scan_state(self):
        if "scan_state_bwd" not in self.kernel_cache:
            args, _ = self._scan_state_inputs()
            self.kernel_cache["scan_state_bwd"] = _call_run(
                _kernel_run("scan_state_bwd"),
                args,
                self.options,
                "scan_state_bwd",
                self.seed,
        )
        return self.kernel_cache["scan_state_bwd"]

    def kernel_scan_split(self):
        if "scan_split_bwd" not in self.kernel_cache:
            full = self.inputs
            self.kernel_cache["scan_split_bwd"] = _call_run(
                _kernel_run("scan_split_bwd"),
                (full[0], full[1], full[5], full[6], full[7], full[10], full[11], full[12], full[13], full[14], full[15]),
                self.options,
                "scan_split_bwd",
                self.seed,
            )
        return self.kernel_cache["scan_split_bwd"]

    def _kernel_scan_outputs_for_downstream(self):
        if self.options.upstream != "kernel":
            return self.ref_scan_split()
        if "_kernel_scan_outputs_for_downstream" not in self.kernel_cache:
            self.kernel_cache["_kernel_scan_outputs_for_downstream"] = self.kernel_scan_split()
        return self.kernel_cache["_kernel_scan_outputs_for_downstream"]

    def kernel_wu(self):
        if "wu_bwd" not in self.kernel_cache:
            full = self.inputs
            scan = self._kernel_scan_outputs_for_downstream()
            self.kernel_cache["wu_bwd"] = _call_run(
                _kernel_run("wu_bwd"),
                (full[1], full[2], full[3], full[6], full[8], scan[4], scan[5]),
                self.options,
                "wu_bwd",
                self.seed,
            )
        return self.kernel_cache["wu_bwd"]

    def kernel_inverse(self):
        if "inverse_preprocess_bwd" not in self.kernel_cache:
            full = self.inputs
            wu = self.kernel_wu() if self.options.upstream == "kernel" else self.ref_wu()
            self.kernel_cache["inverse_preprocess_bwd"] = _call_run(
                _kernel_run("inverse_preprocess_bwd"),
                (full[1], full[3], full[7], full[8], wu[0]),
                self.options,
                "inverse_preprocess_bwd",
                self.seed,
        )
        return self.kernel_cache["inverse_preprocess_bwd"]

    def kernel_finalize(self):
        if "finalize_bwd" not in self.kernel_cache:
            full = self.inputs
            if self.options.upstream == "kernel":
                scan = self._kernel_scan_outputs_for_downstream()
                wu = self.kernel_wu()
                inv = self.kernel_inverse()
            else:
                scan = self.ref_scan_split()
                wu = self.ref_wu(scan)
                inv = self.ref_inverse(wu)
            self.kernel_cache["finalize_bwd"] = _call_run(
                _kernel_run("finalize_bwd"),
                (
                    full[1], full[2], full[3],
                    scan[1], scan[2], scan[6],
                    wu[1], wu[2], wu[3],
                    inv[0], inv[1], inv[3],
                ),
                self.options,
                "finalize_bwd",
                self.seed,
            )
        return self.kernel_cache["finalize_bwd"]

    def kernel_compose(self):
        if "compose" not in self.kernel_cache:
            self.kernel_cache["compose"] = _call_run(
                _kernel_run("kernel_compose"),
                self.inputs,
                self.options,
                "compose",
                self.seed,
            )
        return self.kernel_cache["compose"]

    def expected_for_module(self, module_name):
        if module_name == "scan_local_bwd":
            return self.ref_scan_local()
        if module_name == "scan_state_bwd":
            _, local = self._scan_state_inputs()
            return self.ref_scan_state(local)
        if module_name == "scan_split_bwd":
            return self.ref_scan_split()
        if module_name == "wu_bwd":
            return self.ref_wu(self._kernel_scan_outputs_for_downstream())
        if module_name == "inverse_preprocess_bwd":
            wu = self.kernel_wu() if self.options.upstream == "kernel" else self.ref_wu()
            return self.ref_inverse(wu)
        if module_name == "finalize_bwd":
            if self.options.upstream == "kernel":
                expected = self.ref_finalize(self._kernel_scan_outputs_for_downstream(), self.kernel_wu(), self.kernel_inverse())
            else:
                expected = self.ref_finalize()
            return expected[1:]
        if module_name == "compose":
            return self.ref_compose()
        raise ValueError("unsupported module %r" % module_name)

    def actual_for_module(self, module_name):
        if module_name == "scan_local_bwd":
            return self.kernel_scan_local()
        if module_name == "scan_state_bwd":
            return self.kernel_scan_state()
        if module_name == "scan_split_bwd":
            return self.kernel_scan_split()
        if module_name == "wu_bwd":
            return self.kernel_wu()
        if module_name == "inverse_preprocess_bwd":
            return self.kernel_inverse()
        if module_name == "finalize_bwd":
            return self.kernel_finalize()
        if module_name == "compose":
            return self.kernel_compose()
        raise ValueError("unsupported module %r" % module_name)


def _dump_failure(dump_dir, seed, shape, module_name, actual, expected):
    if not dump_dir:
        return
    path = Path(dump_dir)
    path.mkdir(parents=True, exist_ok=True)
    file_path = path / ("seed_%s_shape_%s_%s.pt" % (seed, "x".join(str(i) for i in shape), module_name))
    torch.save({"actual": actual, "expected": expected, "shape": shape, "seed": seed}, str(file_path))
    print("  dumped failure tensors: %s" % file_path)


def run_case(seed, shape, modules, options):
    print("=== seed=%d shape=(B=%d,H=%d,C=%d) mode=%s upstream=%s ===" % (seed, shape[0], shape[1], shape[2], options.mode, options.upstream))
    case = GdnBwdCase(seed, shape, options)
    all_ok = True
    for module_name in modules:
        print("[%s]" % module_name)
        actual = case.actual_for_module(module_name)
        expected = case.expected_for_module(module_name)
        ok = _compare_tuple(module_name, actual, expected, options.atol, options.rtol)
        if not ok:
            _dump_failure(options.dump_dir, seed, shape, module_name, actual, expected)
            all_ok = False
            if options.stop_on_fail:
                return False
    return all_ok


def parse_args(argv):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--module", action="append", default=None, help="module, comma list, or alias: pipeline/all")
    parser.add_argument("--seed", default="20260519", help="comma-separated torch seeds")
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=2)
    parser.add_argument("--C", type=int, default=2)
    parser.add_argument("--mode", choices=("simulator", "onboard"), default="simulator")
    parser.add_argument("--upstream", choices=("ref", "kernel"), default="ref", help="feed ref upstream tensors or kernel upstream tensors")
    parser.add_argument("--atol", type=float, default=DEFAULT_ATOL)
    parser.add_argument("--rtol", type=float, default=DEFAULT_RTOL)
    parser.add_argument("--out-dir", default=str(SCRIPT_DIR / "out"), help="OpExec output dir")
    parser.add_argument("--trace", action="store_true", help="write simulator traces under OUT_DIR/traces")
    parser.add_argument("--dump-dir", default="", help="optional directory for failing actual/ref tensors")
    parser.add_argument("--skip-compile", action="store_true", help="pass skip_compile=True to kernel wrappers")
    parser.add_argument("--profile", action="store_true", help="pass profile=True to kernel wrappers that support it")
    parser.add_argument("--stop-on-fail", action="store_true")
    args = parser.parse_args(argv)
    args.modules = _expand_modules(args.module or ["pipeline"])
    args.seeds = _parse_csv_ints(args.seed)
    args.shape = (args.B, args.H, args.C)
    args.trace_root = str(Path(args.out_dir) / "traces") if args.trace else ""
    return args


def main(argv=None):
    options = parse_args(sys.argv[1:] if argv is None else argv)
    all_ok = True
    for seed in options.seeds:
        ok = run_case(seed, options.shape, options.modules, options)
        all_ok = ok and all_ok
        if not ok and options.stop_on_fail:
            break
    if all_ok:
        print("gdn_bwd module-vs-ref OK")
        return 0
    print("gdn_bwd module-vs-ref FAIL")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
