import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

L = 64
D = 128


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "gdn_fwd_chunk_delta_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def _rand_bf16(shape, scale=0.125):
    return (torch.randn(shape, dtype=torch.float32) * scale).to(torch.bfloat16)


def _rand_g(shape):
    return (-torch.rand(shape, dtype=torch.float32) * 0.1).cumsum(-1).to(torch.bfloat16)


def _sample_inputs(B=2, H=4, C=2):
    query = _rand_bf16((B, H, C, L, D))
    key = _rand_bf16((B, H, C, L, D))
    value = _rand_bf16((B, H, C, L, D))
    g = _rand_g((B, H, C, L)).float()
    decay_mask = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.125
    k_cumdecay = _rand_bf16((B, H, C, L, D))
    return query, key, value, g, decay_mask, k_cumdecay

from chunk_delta_sub1 import run as run_sub1  # noqa: E402
from chunk_delta_sub2 import run as run_sub2  # noqa: E402


def run(
    query, key, value, g, decay_mask, k_cumdecay,
    simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=True,
):
    B, H, _C = int(query.shape[0]), int(query.shape[1]), int(query.shape[2])
    state = torch.zeros((B, H, D, D), dtype=torch.bfloat16, device=query.device)
    attn = run_sub1(
        query, key, decay_mask,
        simulator=simulator,
        trace=_child_trace(trace, out_dir, "sub1"),
        gen_only=gen_only,
        out_dir=out_dir,
        skip_compile=skip_compile,
        profile=profile,
    )
    return run_sub2(
        attn, query, key, value, k_cumdecay, g, state,
        simulator=simulator,
        trace=_child_trace(trace, out_dir, "sub2"),
        gen_only=gen_only,
        out_dir=out_dir,
        skip_compile=skip_compile,
        profile=profile,
    )


if __name__ == "__main__":
    torch.manual_seed(42)
    args = _sample_inputs(B=1, H=1, C=2)
    out, state = run(*args, simulator=True)
    print("chunk_delta_compose", tuple(out.shape), out.dtype, tuple(state.shape), state.dtype)
