import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _torch_formula import L, D, core_scan_bwd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
HALF_L = L // 2
HALF_D = D // 2
REGS_D = D // 64
BF16_C0 = 16
SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
    2: [0, 1, 2, None, None],
    3: [0, 1, 2, None, None],
    4: [0, 1, 2, None, None],
    5: [0, 1, 2, None, None],
    6: [0, 1, 2, None, None],
    7: [0, 1, 2, None, None],
    8: [0, 1, 2, None, None],
}


@vf()
def cast_d_rows_float_to_bf16_nz_vf(src_ub: Tensor, dst_nz_ub: Tensor, rows: Var):
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)

    for r in range(rows):
        row_lo <<= src_ub[r:r + 1, 0:64]
        row_hi <<= src_ub[r:r + 1, 64:D]
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def cast_l_rows_float_to_bf16_nz_vf(src_ub: Tensor, dst_nz_ub: Tensor, rows: Var):
    row_float = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)

    for r in range(rows):
        row_float <<= src_ub[r:r + 1, 0:L]
        lo_bf16 <<= row_float.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, dummy_bf16)
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def pack_d_rows_bf16_to_nz_vf(src_ub: Tensor, dst_nz_ub: Tensor, rows: Var):
    row_bf16 = Reg(DT.bfloat16)
    for r in range(rows):
        row_bf16 <<= src_ub[r:r + 1, 0:D]
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def make_q_exp_nz_vf(
    q_bf16_ub: Tensor,
    g_ub: Tensor,
    q_exp_nz_ub: Tensor,
    exp_g_ub: Tensor,
    rows: Var,
):
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    g_reg = Reg(DT.float)
    exp_g = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(rows):
        g_reg <<= g_ub[0:1, r:r + 1].single()
        exp_g <<= g_reg.exp()
        exp_g_ub[0:1, r:r + 1] <<= exp_g.single_value()
        row_lo <<= q_bf16_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * exp_g
        row_hi <<= q_bf16_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * exp_g
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(q_exp_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def make_k_weighted_nz_vf(
    k_bf16_ub: Tensor,
    g_ub: Tensor,
    g_last: Var,
    k_weighted_nz_ub: Tensor,
    exp_delta_ub: Tensor,
    rows: Var,
):
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    g_reg = Reg(DT.float)
    gl_reg = Reg(DT.float)
    exp_delta = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    gl_reg <<= g_last
    for r in range(rows):
        g_reg <<= g_ub[0:1, r:r + 1].single()
        exp_delta <<= gl_reg - g_reg
        exp_delta <<= exp_delta.exp()
        exp_delta_ub[0:1, r:r + 1] <<= exp_delta.single_value()
        row_lo <<= k_bf16_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * exp_delta
        row_hi <<= k_bf16_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * exp_delta
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_weighted_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def make_v_new_vf(v_prime_ub: Tensor, value_bf16_ub: Tensor, out_ub: Tensor, rows: Var):
    prime_regs = RegList(DT.float, REGS_D)
    value_regs = RegList(DT.float, REGS_D)
    for r in range(rows):
        prime_regs <<= v_prime_ub[r:r + 1, 0:D]
        value_regs <<= value_bf16_ub[r:r + 1, 0:D]
        value_regs <<= value_regs - prime_regs
        out_ub[r:r + 1, 0:D] <<= value_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def copy_bf16_to_float_d_rows_vf(src_ub: Tensor, dst_ub: Tensor, rows: Var):
    regs = RegList(DT.float, REGS_D)
    for r in range(rows):
        regs <<= src_ub[r:r + 1, 0:D]
        dst_ub[r:r + 1, 0:D] <<= regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def mask_attn_decay_vf(
    score_to_attn_ub: Tensor,
    d_attn_to_d_score_ub: Tensor,
    decay_to_d_decay_ub: Tensor,
    attn_out_ub: Tensor,
    d_score_bf16_out_ub: Tensor,
    d_decay_out_ub: Tensor,
    d_decay_masked_out_ub: Tensor,
    rows: Var,
):
    score_regs = Reg(DT.float)
    d_attn_regs = Reg(DT.float)
    decay_regs = Reg(DT.float)
    tmp_regs = Reg(DT.float)
    score_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    score_row = Reg(DT.bfloat16)
    bf16_lowhalf = MaskReg(DT.bfloat16, init_mode=MaskType.LOWHALF)
    for r in range(rows):
        score_regs <<= score_to_attn_ub[r:r + 1, 0:L]
        d_attn_regs <<= d_attn_to_d_score_ub[r:r + 1, 0:L]
        decay_regs <<= decay_to_d_decay_ub[r:r + 1, 0:L]

        tmp_regs <<= score_regs * decay_regs
        attn_out_ub[r:r + 1, 0:L] <<= tmp_regs

        tmp_regs <<= d_attn_regs * decay_regs
        score_bf16 <<= tmp_regs.astype(DT.bfloat16)
        deinterleave(score_row, dummy_bf16, score_bf16, dummy_bf16)
        reg_to_ub(d_score_bf16_out_ub[r:r + 1, 0:L], score_row, mask=bf16_lowhalf)

        tmp_regs <<= d_attn_regs * score_regs
        d_decay_out_ub[r:r + 1, 0:L] <<= tmp_regs
        tmp_regs <<= tmp_regs * decay_regs
        d_decay_masked_out_ub[r:r + 1, 0:L] <<= tmp_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def negate_vf(src_ub: Tensor, out_ub: Tensor, rows: Var):
    regs = RegList(DT.float, REGS_D)
    for r in range(rows):
        regs <<= src_ub[r:r + 1, 0:D]
        regs <<= regs * -1.0
        out_ub[r:r + 1, 0:D] <<= regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def zero_like_d_rows_vf(src_ub: Tensor, dst_ub: Tensor, rows: Var):
    regs = RegList(DT.float, REGS_D)
    for r in range(rows):
        regs <<= src_ub[r:r + 1, 0:D]
        regs <<= regs * 0.0
        dst_ub[r:r + 1, 0:D] <<= regs
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def zero_d_rows_vf(dst_ub: Tensor, rows: Var):
    zero = Reg(DT.float)
    zero <<= 0.0
    for r in range(rows):
        dst_ub[r:r + 1, 0:64] <<= zero
        dst_ub[r:r + 1, 64:D] <<= zero
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def copy_d_rows_vf(src_ub: Tensor, dst_ub: Tensor, rows: Var):
    regs = RegList(DT.float, REGS_D)
    for r in range(rows):
        regs <<= src_ub[r:r + 1, 0:D]
        dst_ub[r:r + 1, 0:D] <<= regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def postprocess_dq_vf(
    d_q_score_ub: Tensor,
    d_q_exp_ub: Tensor,
    exp_g_ub: Tensor,
    out_ub: Tensor,
    rows: Var,
):
    score_regs = RegList(DT.float, REGS_D)
    exp_regs = RegList(DT.float, REGS_D)
    exp_g = Reg(DT.float)
    for r in range(rows):
        exp_g <<= exp_g_ub[0:1, r:r + 1].single()
        score_regs <<= d_q_score_ub[r:r + 1, 0:D]
        exp_regs <<= d_q_exp_ub[r:r + 1, 0:D]
        exp_regs <<= exp_regs * exp_g
        score_regs <<= score_regs + exp_regs
        out_ub[r:r + 1, 0:D] <<= score_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def postprocess_dk_vf(
    d_k_score_ub: Tensor,
    d_k_weighted_ub: Tensor,
    exp_delta_ub: Tensor,
    out_ub: Tensor,
    rows: Var,
):
    score_regs = RegList(DT.float, REGS_D)
    weighted_regs = RegList(DT.float, REGS_D)
    exp_delta = Reg(DT.float)
    for r in range(rows):
        exp_delta <<= exp_delta_ub[0:1, r:r + 1].single()
        score_regs <<= d_k_score_ub[r:r + 1, 0:D]
        weighted_regs <<= d_k_weighted_ub[r:r + 1, 0:D]
        weighted_regs <<= weighted_regs * exp_delta
        score_regs <<= score_regs + weighted_regs
        out_ub[r:r + 1, 0:D] <<= score_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def zero_scalar_vf(dst_ub: Tensor):
    zero = Reg(DT.float)
    zero <<= 0.0
    dst_ub[0:1, 0:1] <<= zero.single_value()


@vf()
def accum_state_dot_vf(d_state_rows_ub: Tensor, state_bf16_rows_ub: Tensor, accum_ub: Tensor):
    d_state_regs = RegList(DT.float, REGS_D)
    state_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    row_sum = Reg(DT.float)
    acc = Reg(DT.float)
    acc <<= accum_ub[0:1, 0:1].single()
    for r in range(L):
        d_state_regs <<= d_state_rows_ub[r:r + 1, 0:D]
        state_regs <<= state_bf16_rows_ub[r:r + 1, 0:D]
        prod_regs <<= d_state_regs * state_regs
        row_sum <<= prod_regs.cadd()
        acc <<= acc + row_sum
    accum_ub[0:1, 0:1] <<= acc.single_value()


@vf()
def accum_state_dot_full_vf(
    d_state_lo_ub: Tensor,
    state_lo_bf16_ub: Tensor,
    d_state_hi_ub: Tensor,
    state_hi_bf16_ub: Tensor,
    accum_ub: Tensor,
):
    d_state_regs = RegList(DT.float, REGS_D)
    state_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    row_sum = Reg(DT.float)
    acc = Reg(DT.float)
    acc <<= 0.0
    for r in range(L):
        d_state_regs <<= d_state_lo_ub[r:r + 1, 0:D]
        state_regs <<= state_lo_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= d_state_regs * state_regs
        row_sum <<= prod_regs.cadd()
        acc <<= acc + row_sum
    for r in range(L):
        d_state_regs <<= d_state_hi_ub[r:r + 1, 0:D]
        state_regs <<= state_hi_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= d_state_regs * state_regs
        row_sum <<= prod_regs.cadd()
        acc <<= acc + row_sum
    accum_ub[0:1, 0:1] <<= acc.single_value()


@vf()
def update_d_state_vf(seed_to_out_ub: Tensor, old_d_state_ub: Tensor, g_last: Var):
    seed_regs = RegList(DT.float, REGS_D)
    old_regs = RegList(DT.float, REGS_D)
    scale = Reg(DT.float)
    scale <<= g_last
    scale <<= scale.exp()
    for r in range(D):
        seed_regs <<= seed_to_out_ub[r:r + 1, 0:D]
        old_regs <<= old_d_state_ub[r:r + 1, 0:D]
        old_regs <<= old_regs * scale
        seed_regs <<= seed_regs + old_regs
        seed_to_out_ub[r:r + 1, 0:D] <<= seed_regs
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def accum_dq_g_full_vf(
    d_q_exp_ub: Tensor,
    q_bf16_ub: Tensor,
    g_ub: Tensor,
    exp_g_lo_ub: Tensor,
    d_g_ub: Tensor,
):
    dq_regs = RegList(DT.float, REGS_D)
    q_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    g_reg = Reg(DT.float)
    exp_g = Reg(DT.float)
    row_sum = Reg(DT.float)
    for r in range(HALF_L):
        exp_g <<= exp_g_lo_ub[0:1, r:r + 1].single()
        dq_regs <<= d_q_exp_ub[r:r + 1, 0:D]
        q_regs <<= q_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dq_regs * q_regs
        row_sum <<= prod_regs.cadd()
        row_sum <<= row_sum * exp_g
        d_g_ub[0:1, r:r + 1] <<= row_sum.single_value()
    for r in range(HALF_L, L):
        g_reg <<= g_ub[0:1, r:r + 1].single()
        exp_g <<= g_reg.exp()
        dq_regs <<= d_q_exp_ub[r:r + 1, 0:D]
        q_regs <<= q_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dq_regs * q_regs
        row_sum <<= prod_regs.cadd()
        row_sum <<= row_sum * exp_g
        d_g_ub[0:1, r:r + 1] <<= row_sum.single_value()


@vf()
def finish_g_full_vf(
    d_k_weighted_ub: Tensor,
    k_bf16_ub: Tensor,
    g_ub: Tensor,
    g_last: Var,
    exp_delta_lo_ub: Tensor,
    d_exp_ub: Tensor,
    d_g_base_ub: Tensor,
    d_g_ub: Tensor,
):
    dk_regs = RegList(DT.float, REGS_D)
    k_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    g_reg = Reg(DT.float)
    gl_reg = Reg(DT.float)
    exp_delta = Reg(DT.float)
    d_delta = Reg(DT.float)
    delta_sum = Reg(DT.float)
    g_val = Reg(DT.float)
    exp_last = Reg(DT.float)
    d_exp = Reg(DT.float)
    gl_reg <<= g_last
    delta_sum <<= 0.0
    for r in range(HALF_L):
        exp_delta <<= exp_delta_lo_ub[0:1, r:r + 1].single()
        dk_regs <<= d_k_weighted_ub[r:r + 1, 0:D]
        k_regs <<= k_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dk_regs * k_regs
        d_delta <<= prod_regs.cadd()
        d_delta <<= d_delta * exp_delta
        delta_sum <<= delta_sum + d_delta
        g_val <<= d_g_base_ub[0:1, r:r + 1].single()
        g_val <<= g_val - d_delta
        d_g_ub[0:1, r:r + 1] <<= g_val.single_value()
    for r in range(HALF_L, L):
        g_reg <<= g_ub[0:1, r:r + 1].single()
        exp_delta <<= gl_reg - g_reg
        exp_delta <<= exp_delta.exp()
        dk_regs <<= d_k_weighted_ub[r:r + 1, 0:D]
        k_regs <<= k_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dk_regs * k_regs
        d_delta <<= prod_regs.cadd()
        d_delta <<= d_delta * exp_delta
        delta_sum <<= delta_sum + d_delta
        g_val <<= d_g_base_ub[0:1, r:r + 1].single()
        g_val <<= g_val - d_delta
        d_g_ub[0:1, r:r + 1] <<= g_val.single_value()

    exp_last <<= gl_reg.exp()
    d_exp <<= d_exp_ub[0:1, 0:1].single()
    d_exp <<= d_exp * exp_last
    d_exp <<= d_exp + delta_sum
    g_val <<= g_val + d_exp
    d_g_ub[0:1, L - 1:L] <<= g_val.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def finish_g_zero_base_full_vf(
    d_k_weighted_ub: Tensor,
    k_bf16_ub: Tensor,
    g_ub: Tensor,
    g_last: Var,
    exp_delta_lo_ub: Tensor,
    d_g_ub: Tensor,
):
    dk_regs = RegList(DT.float, REGS_D)
    k_regs = RegList(DT.float, REGS_D)
    prod_regs = RegList(DT.float, REGS_D)
    g_reg = Reg(DT.float)
    gl_reg = Reg(DT.float)
    exp_delta = Reg(DT.float)
    d_delta = Reg(DT.float)
    delta_sum = Reg(DT.float)
    g_val = Reg(DT.float)
    gl_reg <<= g_last
    delta_sum <<= 0.0
    for r in range(HALF_L):
        exp_delta <<= exp_delta_lo_ub[0:1, r:r + 1].single()
        dk_regs <<= d_k_weighted_ub[r:r + 1, 0:D]
        k_regs <<= k_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dk_regs * k_regs
        d_delta <<= prod_regs.cadd()
        d_delta <<= d_delta * exp_delta
        delta_sum <<= delta_sum + d_delta
        g_val <<= d_delta * -1.0
        d_g_ub[0:1, r:r + 1] <<= g_val.single_value()
    for r in range(HALF_L, L):
        g_reg <<= g_ub[0:1, r:r + 1].single()
        exp_delta <<= gl_reg - g_reg
        exp_delta <<= exp_delta.exp()
        dk_regs <<= d_k_weighted_ub[r:r + 1, 0:D]
        k_regs <<= k_bf16_ub[r:r + 1, 0:D]
        prod_regs <<= dk_regs * k_regs
        d_delta <<= prod_regs.cadd()
        d_delta <<= d_delta * exp_delta
        delta_sum <<= delta_sum + d_delta
        g_val <<= d_delta * -1.0
        d_g_ub[0:1, r:r + 1] <<= g_val.single_value()

    g_val <<= g_val + delta_sum
    d_g_ub[0:1, L - 1:L] <<= g_val.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def scan_local_bwd_kernel(
    query: GMTensor,
    key: GMTensor,
    grad_output: GMTensor,
    decay_mask: GMTensor,
    v_new_history: GMTensor,
    d_score_tmp: GMTensor,
    d_v_attn_tmp: GMTensor,
    d_decay_core: GMTensor,
    d_decay_core_masked: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    cvmutex = CvMutex(0, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    attn_mutex = VcMutex(1, depth=2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1_q = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_k = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_d_out = TBuff(DT.bfloat16, [L, D], Position.L1)
    l1_v_new = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_attn = DBuff(DT.bfloat16, [L, L], Position.L1)

    l0c_ll0 = DBuff(DT.float, [L, L], Position.L0C)
    l0c_ll1 = DBuff(DT.float, [L, L], Position.L0C)
    l0c_dv = DBuff(DT.float, [L, D], Position.L0C)

    bf16_full_ub = DBuff(DT.bfloat16, [L, D], Position.UB)
    float_half0_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_score_bf16_ub = DBuff(DT.bfloat16, [HALF_L, L], Position.UB)
    ll0_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    ll1_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    ll2_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    d_decay_out_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    d_decay_masked_out_ub = DBuff(DT.float, [HALF_L, L], Position.UB)

    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    for pipe_bhc in range(bhc_begin, bhc_end + 1):
        if pipe_bhc < bhc_end:
            with auto_sync():
                pipe_slot = var_mod(pipe_bhc - bhc_begin, 2)
                dout_slot = var_mod(pipe_bhc - bhc_begin, 3)
                c_idx = Var(pipe_bhc % C)
                bh = Var(pipe_bhc // C)
                b_idx = Var(bh // H)
                h_idx = Var(bh % H)
                row_begin_l = Var(GetSubBlockIdx() * HALF_L)
                row_end_l = Var(row_begin_l + HALF_L)
                rows_l = Var(HALF_L)

                l1_q[pipe_slot][0:L, 0:D] <<= query[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_k[pipe_slot][0:L, 0:D] <<= key[b_idx, h_idx, c_idx, 0:L, 0:D]

                l1_d_out[dout_slot][0:L, 0:D] <<= grad_output[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_v_new[pipe_slot][0:L, 0:D] <<= v_new_history[b_idx, h_idx, c_idx, 0:L, 0:D]

                matmul(l0c_ll0[pipe_slot], l1_q[pipe_slot], l1_k[pipe_slot], m=L, n=L, k=D, splitn=L)
                matmul(l0c_ll1[pipe_slot], l1_d_out[dout_slot], l1_v_new[pipe_slot], m=L, n=L, k=D, splitn=L)

                cvmutex.lock()
                ll0_ub[pipe_slot] <<= l0c_ll0[pipe_slot]
                ll1_ub[pipe_slot] <<= l0c_ll1[pipe_slot]
                cvmutex.ready()
                ll2_ub[pipe_slot][0:rows_l, 0:L] <<= decay_mask[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:L]
                cvmutex.wait()
                mask_attn_decay_vf(
                    ll0_ub[pipe_slot],
                    ll1_ub[pipe_slot],
                    ll2_ub[pipe_slot],
                    float_half0_ub[pipe_slot],
                    d_score_bf16_ub[pipe_slot],
                    d_decay_out_ub[pipe_slot],
                    d_decay_masked_out_ub[pipe_slot],
                    rows_l,
                )
                cvmutex.free()

                attn_mutex.lock()
                cast_l_rows_float_to_bf16_nz_vf(float_half0_ub[pipe_slot], bf16_full_ub[pipe_slot], rows_l)
                l1_attn[pipe_slot][row_begin_l:row_end_l, 0:L] <<= bf16_full_ub[pipe_slot][0:rows_l, 0:L].nz()
                attn_mutex.ready()

                d_score_tmp[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:L] <<= d_score_bf16_ub[pipe_slot][0:rows_l, 0:L]
                d_decay_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:L] <<= d_decay_out_ub[pipe_slot][0:rows_l, 0:L]
                d_decay_core_masked[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:L] <<= d_decay_masked_out_ub[pipe_slot][0:rows_l, 0:L]

        if pipe_bhc > bhc_begin:
            with auto_sync():
                bhc = Var(pipe_bhc - 1)
                bhc_slot = var_mod(bhc - bhc_begin, 2)
                dout_slot = var_mod(bhc - bhc_begin, 3)
                c_idx = Var(bhc % C)
                bh = Var(bhc // C)
                b_idx = Var(bh // H)
                h_idx = Var(bh % H)

                attn_mutex.wait()

                matmul(l0c_dv[bhc_slot], l1_attn[bhc_slot].T, l1_d_out[dout_slot].T, m=L, n=D, k=L, splitn=D)
                attn_mutex.free()

                d_v_attn_tmp[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_dv[bhc_slot]

    return d_score_tmp, d_v_attn_tmp, d_decay_core, d_decay_core_masked


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "gdn_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def _run_opexec(query, key, grad_output, decay_mask, v_new_history, outputs, B, H, C, simulator, trace_path, gen_only, out_dir, skip_compile, profile):
    previous_config = getattr(scan_local_bwd_kernel, "_simulator_config", None)
    if simulator:
        scan_local_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            scan_local_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            query, key, grad_output, decay_mask, v_new_history,
            outputs[0], outputs[1], outputs[2], outputs[3], B, H, C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(scan_local_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                scan_local_bwd_kernel._simulator_config = previous_config
    return result


def run(query, key, grad_output, decay_mask, v_new_history, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    B = int(query.shape[0])
    H = int(query.shape[1])
    C = int(query.shape[2])
    device = query.device
    outputs = (
        torch.empty((B, H, C, L, L), dtype=torch.bfloat16, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, L), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, L), dtype=torch.float32, device=device),
    )
    result = _run_opexec(
        query, key, grad_output, decay_mask, v_new_history, outputs, B, H, C, simulator,
        _trace_path(trace, out_dir, "scan_local_bwd"), gen_only, out_dir, skip_compile, profile,
    )
    if gen_only:
        return result
    return result


if __name__ == "__main__":
    torch.manual_seed(42)
    B, H, C = 1, 1, int(os.environ.get("C_SIZE", "1"))
    query = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    grad_output = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.1).to(torch.bfloat16)
    g_cumsum = torch.randn(B, H, C, L, dtype=torch.float32) * 0.05
    decay_mask = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.05
    v_new_history = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    result = run(query, key, grad_output, decay_mask, v_new_history)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
