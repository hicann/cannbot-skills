"""Simulator check for inverse_preprocess_bwd (ungated delta_rule backward).

Wires up: core_scan_bwd -> wu_recompute_bwd -> inverse_preprocess_bwd (ref),
then runs the DSL kernel in the simulator and asserts close at atol/rtol=2e-3.
"""
import sys
from pathlib import Path

import torch

SCRIPT_DIR = Path(__file__).resolve().parent
PLAN_DIR = SCRIPT_DIR.parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)
for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import core_scan_bwd, make_inputs, wu_recompute_bwd  # noqa: E402
from inverse_preprocess_bwd_ref import subkernel  # noqa: E402
from inverse_preprocess_bwd import run  # noqa: E402


def main():
    torch.manual_seed(42)
    full = make_inputs(1, 1, 2)

    # Compute upstream grads exactly as inverse_preprocess_bwd_ref.py __main__ does
    scan = core_scan_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])
    wu = wu_recompute_bwd(full[1], full[2], full[3], full[5], scan[2], scan[3])

    key = full[1]
    beta = full[3]
    wu_attn_bf16 = full[5]
    d_wu = wu[0]

    ref = subkernel(key, beta, wu_attn_bf16, d_wu)

    result = run(key, beta, wu_attn_bf16, d_wu, simulator=True, out_dir="tmp/delta_bwd_inv")

    d_k_got, d_k_beta_got = result
    d_k_ref, d_k_beta_ref = ref

    d_k_err = (d_k_got.float() - d_k_ref.float()).abs().max().item()
    d_k_beta_err = (d_k_beta_got.float() - d_k_beta_ref.float()).abs().max().item()
    print("inverse_preprocess_bwd: d_k max_abs=%.6e  d_k_beta max_abs=%.6e" % (d_k_err, d_k_beta_err))

    torch.testing.assert_close(d_k_got.float(), d_k_ref.float(), atol=2e-3, rtol=2e-3)
    torch.testing.assert_close(d_k_beta_got.float(), d_k_beta_ref.float(), atol=2e-3, rtol=2e-3)
    print("inverse_preprocess_bwd OK")


if __name__ == "__main__":
    main()
