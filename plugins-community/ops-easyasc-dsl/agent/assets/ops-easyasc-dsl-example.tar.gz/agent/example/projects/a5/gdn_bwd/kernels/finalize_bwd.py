import builtins
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _torch_formula import L, D, finalize_grads


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
HALF_L = L // 2
UPPER_TILE_L = L // 4
REGS_D = D // 64
BHC_TILE = 4
ACC_TILE_M = 16
SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
    2: [0, 1, 2, None],
    3: [0, 1, 2, None, None],
    4: [3, None],
    5: [3, None, None],
    6: [0, 1, 2, None, None],
    7: [0, 1, 2, None, None],
    8: [3, None],
    9: [0, 1, 2, None, None],
    10: [0, 1, 2, None, None],
    11: [3, None, None],
    12: [None, None],
    13: [None, None],
    14: [None, None],
    15: [None, None],
    16: [0, 1, 2, None, None],
    17: [0, 1, 2, None, None],
    18: [0, 1, 2, None],
    19: [3, None],
}


@vf()
def finalize_upper_vf(
    key_ub: Tensor,
    value_ub: Tensor,
    beta_ub: Tensor,
    d_v_beta_ub: Tensor,
    d_k_beta_wu_ub: Tensor,
    d_k_beta_pre_ub: Tensor,
    d_k_core_ub: Tensor,
    d_k_pre_ub: Tensor,
    d_value_out_ub: Tensor,
    d_beta_ub: Tensor,
    d_key_out_ub: Tensor,
    rows: Var,
):
    key_regs = RegList(DT.float, REGS_D)
    value_regs = RegList(DT.float, REGS_D)
    d_v_regs = RegList(DT.float, REGS_D)
    d_k_beta_regs = RegList(DT.float, REGS_D)
    d_k_beta_pre_regs = RegList(DT.float, REGS_D)
    d_k_regs = RegList(DT.float, REGS_D)
    d_k_pre_regs = RegList(DT.float, REGS_D)
    tmp_regs = RegList(DT.float, REGS_D)
    beta_reg = Reg(DT.float)
    beta_sum = Reg(DT.float)

    for r in range(rows):
        beta_reg <<= beta_ub[0:1, r:r + 1].single()
        key_regs <<= key_ub[r:r + 1, 0:D]
        value_regs <<= value_ub[r:r + 1, 0:D]
        d_v_regs <<= d_v_beta_ub[r:r + 1, 0:D]
        d_k_beta_regs <<= d_k_beta_wu_ub[r:r + 1, 0:D]
        d_k_beta_pre_regs <<= d_k_beta_pre_ub[r:r + 1, 0:D]
        d_k_regs <<= d_k_core_ub[r:r + 1, 0:D]
        d_k_pre_regs <<= d_k_pre_ub[r:r + 1, 0:D]

        d_k_beta_regs <<= d_k_beta_regs + d_k_beta_pre_regs

        tmp_regs <<= d_v_regs * value_regs
        key_regs <<= d_k_beta_regs * key_regs
        tmp_regs <<= tmp_regs + key_regs
        beta_sum <<= tmp_regs.cadd()
        d_beta_ub[0:1, r:r + 1] <<= beta_sum.single_value()

        d_v_regs <<= d_v_regs * beta_reg
        d_value_out_ub[r:r + 1, 0:D] <<= d_v_regs

        d_k_beta_regs <<= d_k_beta_regs * beta_reg
        d_k_regs <<= d_k_regs + d_k_pre_regs
        d_k_regs <<= d_k_regs + d_k_beta_regs
        d_key_out_ub[r:r + 1, 0:D] <<= d_k_regs


@kernel()
def finalize_bwd_kernel(
    key: GMTensor,
    value: GMTensor,
    beta: GMTensor,
    d_k_core: GMTensor,
    d_g_core: GMTensor,
    d_decay_core_masked: GMTensor,
    d_v_beta: GMTensor,
    d_k_beta_wu: GMTensor,
    d_g_wu: GMTensor,
    d_k_pre: GMTensor,
    d_k_beta_pre: GMTensor,
    d_decay_pre_masked: GMTensor,
    selector_rows: GMTensor,
    neg_selector_rows: GMTensor,
    eye: GMTensor,
    reverse_tril: GMTensor,
    d_key: GMTensor,
    d_value: GMTensor,
    d_beta: GMTensor,
    d_g: GMTensor,
    B: Var,
    H: Var,
    C: Var,
    BHC: Var,
):
    key_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    value_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    beta_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    d_k_pre_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_k_beta_wu_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_k_beta_pre_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_v_beta_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_k_core_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_beta_ub = DBuff(DT.float, [1, UPPER_TILE_L], Position.UB)
    d_value_out_ub = DBuff(DT.float, [UPPER_TILE_L, D], Position.UB)
    d_key_out_ub = DBuff(DT.float, [UPPER_TILE_L, D], Position.UB)

    bhc_count = B * H * C
    bhc_per_vec = CeilDiv(bhc_count, GetVecNum())
    bhc_begin = Var(bhc_per_vec * GetVecIdx())
    bhc_end = Min(bhc_begin + bhc_per_vec, bhc_count)
    rows_this = Var(UPPER_TILE_L)
    in_buf_cnt = Var(0)
    out_buf_cnt = Var(0)

    with auto_sync():
        for bhc in range(bhc_begin, bhc_end):
            c_idx = Var(bhc // (B * H))
            bh_remainder = Var(bhc % (B * H))
            b_idx = Var(bh_remainder // H)
            h_idx = Var(bh_remainder % H)

            for half_idx in range(2):
                half_begin = Var(half_idx * HALF_L)
                half_end = Var(half_begin + HALF_L)

                key_ub[in_buf_cnt][0:HALF_L, 0:D] <<= key[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                value_ub[in_buf_cnt][0:HALF_L, 0:D] <<= value[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                beta_ub[in_buf_cnt][0:1, 0:HALF_L] <<= beta[b_idx, h_idx, c_idx, half_begin:half_end]
                d_v_beta_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_v_beta[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                d_k_beta_wu_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_k_beta_wu[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                d_k_beta_pre_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_k_beta_pre[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                d_k_core_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_k_core[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]
                d_k_pre_ub[in_buf_cnt][0:HALF_L, 0:D] <<= d_k_pre[b_idx, h_idx, c_idx, half_begin:half_end, 0:D]

                for tile_idx in range(2):
                    local_begin = Var(tile_idx * UPPER_TILE_L)
                    local_end = Var(local_begin + UPPER_TILE_L)
                    row_begin = Var(half_begin + local_begin)
                    row_end = Var(row_begin + UPPER_TILE_L)

                    finalize_upper_vf(
                        key_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        value_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        beta_ub[in_buf_cnt][0:1, local_begin:local_end],
                        d_v_beta_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_k_beta_wu_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_k_beta_pre_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_k_core_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_k_pre_ub[in_buf_cnt][local_begin:local_end, 0:D],
                        d_value_out_ub[out_buf_cnt],
                        d_beta_ub[out_buf_cnt],
                        d_key_out_ub[out_buf_cnt],
                        rows_this,
                    )

                    d_value[b_idx, h_idx, c_idx, row_begin:row_end, 0:D] <<= d_value_out_ub[out_buf_cnt][0:rows_this, 0:D]
                    d_beta[b_idx, h_idx, c_idx, row_begin:row_end] <<= d_beta_ub[out_buf_cnt][0:1, 0:rows_this]
                    d_key[b_idx, h_idx, c_idx, row_begin:row_end, 0:D] <<= d_key_out_ub[out_buf_cnt][0:rows_this, 0:D]
                    out_buf_cnt += 1
                in_buf_cnt += 1

    reset_cache()

    l1_g_core = Tensor(DT.float, [ACC_TILE_M, L], Position.L1)
    l1_g_wu = Tensor(DT.float, [ACC_TILE_M, L], Position.L1)
    l1_decay_core = DBuff(DT.float, [L, L], Position.L1)
    l1_decay_pre = DBuff(DT.float, [L, L], Position.L1)
    l1_selectors = Tensor(DT.float, [BHC_TILE * BHC_TILE, L], Position.L1)
    l1_neg_selectors = Tensor(DT.float, [BHC_TILE * BHC_TILE, L], Position.L1)
    l1_eye = Tensor(DT.float, [L, L], Position.L1)
    l1_reverse = Tensor(DT.float, [L, L], Position.L1)
    l1_x = Tensor(DT.float, [ACC_TILE_M, L], Position.L1)

    l0c_x = Tensor(DT.float, [ACC_TILE_M, L], Position.L0C)
    l0c_out = Tensor(DT.float, [ACC_TILE_M, L], Position.L0C)

    x_ready = SEvent(Pipe.FIX, Pipe.MTE1, name="finalize_d_g_cube_x_ready")
    tile_count = CeilDiv(BHC, BHC_TILE)
    tile_per_core = CeilDiv(tile_count, GetCubeNum())
    tile_begin = Var(tile_per_core * GetCubeIdx())
    tile_end = Min(tile_begin + tile_per_core, tile_count)
    decay_buf_cnt = Var(0)

    with auto_sync():
        l1_selectors[0:BHC_TILE * BHC_TILE, 0:L] <<= selector_rows[0:BHC_TILE * BHC_TILE, 0:L]
        l1_neg_selectors[0:BHC_TILE * BHC_TILE, 0:L] <<= neg_selector_rows[0:BHC_TILE * BHC_TILE, 0:L]
        l1_eye[0:L, 0:L] <<= eye[0:L, 0:L]
        l1_reverse[0:L, 0:L] <<= reverse_tril[0:L, 0:L]

        for tile_idx in range(tile_begin, tile_end):
            tile_bhc_begin = Var(tile_idx * BHC_TILE)
            rows_cube = Min(BHC_TILE, BHC - tile_bhc_begin)

            l1_g_core[0:rows_cube, 0:L] <<= d_g_core[tile_bhc_begin:tile_bhc_begin + rows_cube, 0:L]
            l1_g_wu[0:rows_cube, 0:L] <<= d_g_wu[tile_bhc_begin:tile_bhc_begin + rows_cube, 0:L]

            matmul(l0c_x, l1_g_core, l1_eye.T, m=rows_cube, n=L, k=L)
            matmul(l0c_x, l1_g_wu, l1_eye.T, m=rows_cube, n=L, k=L, is_init=False)

            for local_t in range(rows_cube):
                bhc_flat = Var(tile_bhc_begin + local_t)
                selector_begin = Var(local_t * BHC_TILE)
                selector_end = Var(selector_begin + rows_cube)
                current_decay_core = l1_decay_core[decay_buf_cnt]
                current_decay_pre = l1_decay_pre[decay_buf_cnt]

                current_decay_core[0:L, 0:L] <<= d_decay_core_masked[bhc_flat, 0:L, 0:L]
                current_decay_pre[0:L, 0:L] <<= d_decay_pre_masked[bhc_flat, 0:L, 0:L]

                matmul(
                    l0c_x,
                    l1_selectors[selector_begin:selector_end, 0:L],
                    current_decay_core,
                    m=rows_cube,
                    n=L,
                    k=L,
                    is_init=False,
                )
                matmul(
                    l0c_x,
                    l1_selectors[selector_begin:selector_end, 0:L],
                    current_decay_pre,
                    m=rows_cube,
                    n=L,
                    k=L,
                    is_init=False,
                )
                matmul(
                    l0c_x,
                    l1_neg_selectors[selector_begin:selector_end, 0:L],
                    current_decay_core.T,
                    m=rows_cube,
                    n=L,
                    k=L,
                    is_init=False,
                )
                matmul(
                    l0c_x,
                    l1_neg_selectors[selector_begin:selector_end, 0:L],
                    current_decay_pre.T,
                    m=rows_cube,
                    n=L,
                    k=L,
                    is_init=False,
                )
                decay_buf_cnt += 1

            l1_x <<= l0c_x
            x_ready.set()
            x_ready.wait()
            matmul(l0c_out, l1_x, l1_reverse.T, m=rows_cube, n=L, k=L)
            d_g[tile_bhc_begin:tile_bhc_begin + rows_cube, 0:L] <<= l0c_out[0:rows_cube, 0:L]
    return d_key, d_value, d_beta, d_g


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "gdn_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def make_constants(device):
    selector_rows = torch.zeros((BHC_TILE * BHC_TILE, L), dtype=torch.float32, device=device)
    for t in builtins.range(BHC_TILE):
        selector_rows[t * BHC_TILE + t, :] = 1.0
    neg_selector_rows = -selector_rows
    eye = torch.eye(L, dtype=torch.float32, device=device)
    reverse_tril = torch.tril(torch.ones((L, L), dtype=torch.float32, device=device))
    return selector_rows, neg_selector_rows, eye, reverse_tril


def run(
    key,
    value,
    beta,
    d_k_core,
    d_g_core,
    d_decay_core_masked,
    d_v_beta,
    d_k_beta_wu,
    d_g_wu,
    d_k_pre,
    d_k_beta_pre,
    d_decay_pre_masked,
    selector_rows=None,
    neg_selector_rows=None,
    eye=None,
    reverse_tril=None,
    simulator=True,
    trace=None,
    gen_only=False,
    out_dir="",
    skip_compile=False,
    profile=False,
):
    B = int(key.shape[0])
    H = int(key.shape[1])
    C = int(key.shape[2])
    bhc = B * H * C
    device = key.device
    if selector_rows is None or neg_selector_rows is None or eye is None or reverse_tril is None:
        selector_rows, neg_selector_rows, eye, reverse_tril = make_constants(device)

    d_g_core_flat = d_g_core.reshape(bhc, L)
    d_g_wu_flat = d_g_wu.reshape(bhc, L)
    d_decay_core_masked_flat = d_decay_core_masked.reshape(bhc, L, L)
    d_decay_pre_masked_flat = d_decay_pre_masked.reshape(bhc, L, L)
    outputs = (
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L), dtype=torch.float32, device=device),
        torch.empty((bhc, L), dtype=torch.float32, device=device),
    )
    trace_path = _trace_path(trace, out_dir, "finalize_bwd")
    previous_config = getattr(finalize_bwd_kernel, "_simulator_config", None)
    if simulator:
        finalize_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            finalize_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            profile=profile,
            gen_only=gen_only,
            skip_compile=skip_compile,
        )(
            key, value, beta, d_k_core, d_g_core_flat, d_decay_core_masked_flat,
            d_v_beta, d_k_beta_wu, d_g_wu_flat, d_k_pre, d_k_beta_pre,
            d_decay_pre_masked_flat, selector_rows, neg_selector_rows, eye,
            reverse_tril, outputs[0], outputs[1], outputs[2], outputs[3],
            B, H, C, bhc, shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(finalize_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                finalize_bwd_kernel._simulator_config = previous_config
    return result[0], result[1], result[2], result[3].reshape(B, H, C, L)


if __name__ == "__main__":
    torch.manual_seed(42)
    B, H, C = 1, 1, 1
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    value = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    decay_mask = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.05
    d_q = torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05
    d_k_core = torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05
    d_g_core = torch.randn(B, H, C, L, dtype=torch.float32) * 0.05
    d_decay_core = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.05
    d_v_beta = torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05
    d_k_beta_wu = torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05
    d_g_wu = torch.randn(B, H, C, L, dtype=torch.float32) * 0.05
    d_k_pre = torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05
    d_k_beta_pre = torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05
    d_decay_pre = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.05
    result_tail = run(
        key, value, beta, d_k_core, d_g_core, d_decay_core * decay_mask,
        d_v_beta, d_k_beta_wu, d_g_wu, d_k_pre, d_k_beta_pre,
        d_decay_pre * decay_mask,
    )
    result = (d_q,) + tuple(result_tail)
    expected = finalize_grads(key, value, beta, decay_mask, d_q, d_k_core, d_g_core, d_decay_core, d_v_beta, d_k_beta_wu, d_g_wu, d_k_pre, d_k_beta_pre, d_decay_pre)
    for got, ref in zip(result, expected):
        torch.testing.assert_close(got, ref, rtol=5e-4, atol=5e-4)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
