# Decomposition Plan - delta_chunk_recurrence / Candidate F

> Candidate artifact. One plan per candidate. Produced by the `candidate-decomposition-worker` role. Sections are fixed - do not reorder or drop.

**Candidate.** `F` - `Progressive Pipeline`
**Target.** `a5`
**Precision policy.** `loose` (atol=2e-3, rtol=2e-3, matmul_downcast=allow bf16)
**Date.** `2026-04-26`
**Candidate dir.** `tmp_deepseek_decompose_delta_h/F/`
**Shared oracle.** `tmp_deepseek_decompose_delta_h/oracle.py`
**Author manifest.** `author_manifest.json`

## 1. Overview

The authored execution path handles the full C axis. Sub1 is a pure cube
producer for M1 (`q@k^T * decay_mask`) and folds C into the B*H*C parallel
axis. The recurrent state dependency requires M2-M5 to stay in one kernel, so
Sub2 owns the internal C loop and produces `core_attn_out` plus the final
state. The state-history variant also publishes per-chunk `state_after_history`,
`v_new_history`, `k_weighted_history`, and `exp_delta_history` so backward
kernels can consume forward-saved recurrence state, post-decay values, gated
keys, and fp32 gate deltas. The runnable compose path is Sub1 -> fused Sub2.

This plan is the canonical retained implementation for the equivalent runnable
paths that were previously kept as plan7 and plan8. Those candidates converged
to byte-identical Sub1/Sub2 kernels after optimization, so their active copies
were removed to avoid duplicated kernels and stale documentation.

## 2. Oracle

- Shared path: `../oracle.py` (relative to this candidate dir)
- Frozen end-to-end oracle from the user's original PyTorch.
- Candidate-local expected sub-kernel outputs: `refs/oracle.py`.
- Tolerance budget enforced by `refs/<sub>_check.py`, `refs/compose.py`, and
  `test_script/check_chunk_delta_vs_ref.py` using `torch.allclose` semantics:
  `atol=2e-3`, `rtol=2e-3`.

## 3. DAG

```mermaid
graph LR
    Q[query] --> K1[sub1: cube<br/>M1 over B*H*C]
    K[key] --> K1
    M[decay_mask] --> K1
    K1 --> W1[attn GM]
    W1 --> K2[sub2: cube->vec->cube<br/>M2-M5 internal C loop]
    Q --> K2
    K --> K2
    V[value] --> K2
    KC[k_cumdecay] --> K2
    G[g] --> K2
    K2 -- "state bridge inside C loop" --> K2
    K2 --> O1[core_attn_out]
    K2 --> O2[final_recurrent_state]
    K2 --> O3[state_after_history]
    K2 --> O4[v_new_history]
    K2 --> O5[k_weighted_history]
    K2 --> O6[exp_delta_history]
```

Machine-readable: `dag.json`

**Nodes.**

| node | pipe | memory | dtype_in | dtype_compute | dtype_out | producer | consumer |
|------|------|--------|----------|---------------|-----------|----------|----------|
| sub1 | cube | L0C/UB | bf16/fp32 | bf16 matmul / fp32 accum / vec mask | bf16 | user:query,key,decay_mask | sub2 |
| sub2 | cube->vec->cube | L0C/UB/L1 | bf16/fp32 | bf16 matmul / fp32 accum / vec | bf16/fp32 | sub1:attn,user:query,key,value,g,k_cumdecay,initial_state | user:core_attn_out,final_state,state_after_history,v_new_history,k_weighted_history,exp_delta_history |

**Edges.**

| src -> dst | via | dtype | sync |
|------------|-----|-------|------|
| sub1 -> sub2 | attn (GM) | bf16 | kernel boundary |
| sub2(c-1) -> sub2(c) | recurrent state inside kernel | bf16 | kernel order |

## 4. Sub-kernels

| sub | file | I/O contract | primitives |
|-----|------|--------------|------------|
| sub1 | `refs/sub1_ref.py` | (query,key:[B,H,C,64,128]bf16, decay_mask:[B,H,C,64,64]fp32) -> attn:[B,H,C,64,64]bf16 | [P6, L1] |
| sub2 | `refs/sub2_ref.py` | (attn,query,key,value,k_cumdecay,g,state0) -> (core_attn_out:[B,H,C,64,128]bf16, final_state:[B,H,128,128]bf16; state-history path also returns state_after_history:[B,H,C,128,128]bf16, v_new_history:[B,H,C,64,128]bf16, k_weighted_history:[B,H,C,64,128]bf16, and exp_delta_history:[B,H,C,64]fp32) | [P6, P2, L1, L3] |

Expected-output helpers: `refs/oracle.py`.

### 4.1 Axis classification

| symbol | category | binding | alignment | range / hint | parallel_axis? |
|--------|----------|---------|-----------|--------------|----------------|
| B | runtime variable | Var_0 | - | typical 1-32 | part of B*H |
| H | runtime variable | Var_1 | - | typical 1-32 | part of B*H |
| C | runtime variable | Var_2 | - | typical 1-8 | sub1 parallel / sub2 loop |
| L | compile-time constant | literal 64 | - | fixed | |
| D | compile-time constant | literal 128 | - | fixed | |

## 5. Lossy Operations Ledger

| location | transform | dtype in -> compute | predicted | measured |
|----------|-----------|---------------------|-----------|----------|
| sub1.M1 | matmul downcast (L1) | bf16 -> fp32 (L0C fp32) | 0 | 0 |
| sub2.M2 | matmul downcast (L1) | bf16 -> fp32 (L0C fp32) | 0 | 0 |
| sub2.M3 | matmul downcast (L1) | bf16 -> fp32 (L0C fp32) | 0 | 0 |
| sub2.v_new | explicit cast (L3) | fp32 -> bf16 | within budget | 0 |
| sub2.M4 | matmul downcast (L1) | bf16 -> fp32 (L0C fp32) | 0 | 0 |
| sub2.M5 | bf16-round k_weighted before L1 | fp32 -> bf16 -> fp32 matmul | within budget | 0 |

**Composed worst-case.** predicted = 0, measured (`compose.py`) = 0.
Policy budget: atol=2e-3, rtol=2e-3. Pass/fail uses `torch.allclose`
semantics. **Within budget: YES.**

## 6. Candidate rationale

- Strict producer->consumer pipeline following the natural dependency order:
  attn -> fused recurrent output.
- C is inside Sub2 because v_new and attn_inter for chunk c require the state
  produced by chunk c-1.
- The state-history kernel writes `v_new_history` from the existing bf16
  `ub_v` / `ub_v_new` values; this adds a GM output/writeback but no new local
  UB/L1/L0 allocation.
- The state-history kernel writes `k_weighted_history` from the existing scaled
  key path. The `ub_k` tile is overwritten with the bf16 gated key after the
  original key rows have been read, so the extra GM output does not allocate a
  new UB/L1/L0 buffer or change the C-loop DBuff shape.
- The state-history kernel writes `exp_delta_history` from the same per-row
  fp32 scale registers used to build `k_weighted_history`. The tensor is
  fp32 `[B,H,C,64]` and adds only a small GM write per BHC tile.
- M5 computes the scaled key rows in fp32, rounds them to bf16 compact NZ, and
  consumes them through L1 together with bf16 `v_new`.
- Two kernel launches means only attn crosses GM between sub-kernels.

## 7. Assumptions & Unknowns

**Assumptions (free-form).**

- L=64 and D=128 are fixed at compile time; no tail handling needed.
- The recurrent state [B,H,128,128] is owned by Sub2 across the internal C
  loop.
- Sub1's query/key inputs are also read by Sub2 as user inputs.

**Input distribution assumptions (structured).**

| tensor | kind | mean | std | low | high | rationale |
|--------|------|------|-----|-----|------|-----------|
| query | normal | 0.0 | 0.05 | - | - | scaled for bf16 allclose budget |
| key | normal | 0.0 | 0.05 | - | - | scaled for bf16 allclose budget |
| value | normal | 0.0 | 0.05 | - | - | scaled for bf16 allclose budget |
| decay_mask | normal | 0.0 | 0.1 | - | - | bounded multiplicative mask |
| k_cumdecay | normal | 0.0 | 0.05 | - | - | scaled for bf16 allclose budget |
| g | normal | 0.0 | 0.025 | - | - | bounded log-space decay multipliers |

**Unknowns / flagged for the kernel author.**

- Sub2 has four matmuls per C iteration and reuses state, v_new, and scaled key
  across cube/vec stages. Trace-based scheduling can still optimize this path.

## 8. Verification Summary

**Per sub-kernel.**

| sub | check script | N samples | atol (core/state) | rtol (core/state) | pass |
|-----|--------------|-----------|--------------------|--------------------|------|
| sub1 | `refs/sub1_check.py` | 2x32 | 0.000e+00 | 0.000e+00 | YES |
| sub2 | `refs/sub2_check.py` | 2x32 | 0.000e+00 / 0.000e+00 | 0.000e+00 / 0.000e+00 | YES |

**End-to-end (`compose.py`).**

| N samples | atol | rtol | pass |
|-----------|------|------|------|
| 32 | 0.000e+00 | 0.000e+00 | YES |

**Simulator-vs-ref (`test_script/check_chunk_delta_vs_ref.py`).**

| shape | max_abs | max_rel | pass |
|-------|---------|---------|------|
| B=1,H=1,C=2 | 0.000e+00 | 0.000e+00 | YES |

## 9. Scope Boundary

This plan covers the current runnable DSL execution path for candidate F.
