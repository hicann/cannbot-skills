# KDA Backward Optimization Timeline

This file records the project-local optimization rationale for the current
`projects/a5/kda_bwd` implementation.

Stable cross-project lessons that escaped this project have been moved to owner
docs:

- `agent/references/constraints/a5.md` — A5 per-token scalar-burst physical-row
  requirements
- `agent/references/code-paths.md` — where to inspect `print_reg`, frontend
  signature guards, parser local-`Var` lifetime checks, and branch-local `Var`
  control-flow ownership
- `agent/references/facts-simulator-opexec.md` — `OpExec` / kernel-signature
  rules, including case-insensitive parameter-name rejection

## Current Result

The active runtime path is:

```text
scan_bwd
  -> scan_fused
inverse_bwd
  -> inverse_mm
  -> inverse_epilogue
  -> inverse_dainv
  -> inverse_dakk_fused
finalize_bwd
  -> finalize_pre
  -> finalize_pair
  -> finalize_post
  -> finalize_reduce
kernel_compose
```

Current project state:

- full-bf16 public contract with fp32 internal compute
- default input range `scale=0.01`, `k_scale=0.05`
- end-to-end simulator gate at `atol=1e-3`, `rtol=1e-3`
- compose path has zero host math beyond layout prep, `g_last` slicing, and
  `build_saved_forward` test-harness glue

Representative 1-core simulator profile (`B=1, H=1, HV=1, T=512`):

| kernel | cycles | dominant note |
|---|---:|---|
| `scan_fused` | `60049` | V-bound reverse state scan |
| `inverse_mm` | `55924` | MTE2-heavy fused inverse matmuls |
| `inverse_dakk_fused` | `11789` | lookahead-2 all-cube tail |
| `finalize_pair` | `45207` | FIX-bound paired qk/kk matmuls |

Stage sum versus the older split set:

| milestone | 1-core stage sum |
|---|---:|
| split kernels | `213771` |
| first fused stage pass | `198037` |
| fused + deep tuning | `172969` |

## 2026-06-04: Split Bring-up and Scan-State Optimization

### First runnable split

The first working split was built in three stages:

- `scan_dav.py`, then `scan_state.py`, then `scan_bwd.py`
- inverse-stage kernels `inverse_qkgw.py`, `inverse_beta.py`,
  `inverse_dakk_mm1.py`, `inverse_dakk_mm2.py`, then `inverse_bwd.py`
- finalize-stage kernels `finalize_qk.py`, `finalize_kk.py`, then
  `finalize_bwd.py`

At that point:

- the staged simulator compose path matched the project oracle
- `profile_pipe_occupancy.py` was added as the authoritative 1-core tuning tool

### Kept wins

The scan-state entries below are listed in the order they were accepted. The
before/after numbers are the local branch baseline at the time of each probe,
not a reconstructed single monotonic chain.

| area | accepted change | local result |
|---|---|---:|
| `inverse_qkgw` | one-beat flat-work lookahead with depth-2 `VcMutex` handoff | `65959 -> 39673` |
| `scan_state` | remove helper-local `vf_barrier(STORE, STORE)` fences | `102701 -> 96685` |
| `scan_state` | 4-row `RegList(DT.float, 8)` hot helpers | `96685 -> 91917` |
| `scan_state` | store internal `dh` / `dv` workspaces as bf16 GM | `91917 -> 87821` |
| `scan_state` | hoist per-row `exp(g_last)` work out of the hot VF | `87821 -> 78061` |
| `scan_state` | explicit NZ publish instead of `ub_to_l1_nd2nz` on the hot path | `73893 -> 67602` |
| `scan_state` | delay the `dh` GM write until after the more critical state handoff | `67336 -> 61652` |
| `scan_state` | remove dead `dv_sum_ub` helper-local writeback | `61647 -> 60639` |
| `scan_state` | special final-step helper without dead `dstate_f_ub` writeback | `60639 -> 60367` |
| `scan_state` | row-wise `64+64` recurrence rewrite | `60367 -> 58265` |
| `scan_state` | fuse live `state_h -> state_h_nz` pack into the row-wise helper | `58265 -> 57299` |
| `scan_state` | split update into seed/state precompute + corr finalization | `57299 -> 54826` |

Other kept structural changes from the same round:

- hoist the fixed `1 / sqrt(128)` scale out of the hot update path
- keep `dht -> state_h -> state_h_nz` aligned with the steady-state publish
  shape even when it was cycle-flat, so the file had one consistent row-wise
  publish style
- keep a one-core multi-`bhv` guardrail run, even though it exposed a
  pre-existing issue rather than a regression from the latest keep

### Rejected or neutral probes

These were useful enough to keep as "do not retry blindly" notes:

- `kg` lookahead on top of the newer NZ-publish baseline regressed or stayed
  neutral; it was not the next bottleneck
- folding the NZ pack directly into the older hot 4-row helpers regressed
- delaying the `dv` GM write the same way as `dh` was exactly neutral
- moving `seed_mutex.wait()` later and pulling next-seed work earlier were both
  neutral
- carrying `dv0` internally as bf16 regressed, and the more aggressive DBuff
  lookahead variant stopped making progress on simulator
- prefetching `exp_g_last` behaved badly enough in simulator that it was not a
  good checked-in direction
- the hybrid recurrence-body rewrite that reintroduced the older 4-row
  `RegList` style on top of the newer row-wise path regressed
- shrinking or moving the final kept seed/state precompute further did not pay

## 2026-06-04 to 2026-06-05: Full-bf16 Contract and Tolerance Reset

The project then pivoted from the older mixed-precision split to the current
full-bf16 public contract:

- every public tensor, forward cache, stage handoff, and output became bf16
- internal compute stayed fp32
- the older kernel set was retired from the working tree and remains available
  only through version control

Important outcomes from that pivot:

- refs and kernels matched more cleanly because the refs now quantized `h`
  exactly the same way as the kernels
- the first safe tolerance after the pivot was `atol=8e-2`, `rtol=3e-2`
- after measuring the new floor, the project tightened to `atol=1e-2`,
  `rtol=1e-2`

Then the tolerance investigation continued:

- `dk` error was found to be a bf16 cancellation floor, relative to `|dk|max`
  and effectively flat in `T`
- the earlier larger input scales were what made the absolute floor look too
  high
- lowering the default input range to `scale=0.01`, `k_scale=0.05` brought the
  absolute `dk` floor down to the current `~3e-4`
- that made the current end-to-end `1e-3` gate practical without changing the
  actual math contract

## 2026-06-05: Fusion Pass and Deep Occupancy Tuning

### Stage fusion

The first fusion pass merged the split kernels that shared inputs:

| merge | main effect | local result |
|---|---|---:|
| `finalize_qk + finalize_kk -> finalize_pair` | one `kg` load, shared cube path | `49186 -> 45207` |
| `inverse_dakk_mm1 + inverse_dakk_mm2 -> inverse_dakk_fused` | `Akk` loads once, tmp stays on chip | `20018 -> 17557` |
| `inverse_qkgw + inverse_beta -> inverse_mm` | `dv` loads once; `d_w` negate/cast stays on chip | split-stage pair -> `65903` |
| `scan_dav + scan_state -> scan_fused` | `dv0` stays on chip; `dAqk` matmul joins reverse loop | `74355 -> 69370` |

That moved the 1-core stage sum from `213771` to `198037` cycles.

### Deep fused-kernel pass

The next round attacked the fused kernels directly:

| kernel | accepted change | local result |
|---|---|---:|
| `inverse_dakk_fused` | lookahead-2, TBuff/depth-3 pipeline | `17557 -> 11789` |
| `inverse_mm` | FIX offload for dqg/dvbeta/dkg through `l0c_to_ub -> cast VF -> MTE3` | `65903 -> 55924` |
| `scan_fused` | single fused update VF, release `dv0` after add-dv | `69370 -> 60049` |

That moved the 1-core stage sum from `198037` to `172969`.

Important lessons from this round:

- `l0c_to_ub` with `DualMode.SPLITM` was the stable cube->vec bridge for these
  kernels; the analogous `SINGLE` usage raced in the inverse path
- moving selected fp32 results off FIX and through `l0c_to_ub` could help even
  when the public contract still ended in bf16
- after the full-bf16 rewrite, most all-cube kernels were already above the
  90% occupancy stop-rule; the real remaining work was concentrated in
  `scan_fused` / `scan_state`

## 2026-06-05 to 2026-06-06: Host-Glue Removal

### Inverse path

The inverse stage moved from host loops to DSL kernels:

- `inverse_epilogue.py` became the pure-VF port of the inverse triple loop
- `inverse_dainv.py` materialized `dA_inv` and strict-lower `D_tri`
- `inverse_dakk_fused.py` absorbed the final in-kernel `-tril`
- `inverse_bwd.py` became pure plumbing

### Finalize path

The finalize stage then moved its remaining host math into DSL:

- `finalize_pre.py` dropped `row_scale` / `col_scale` outputs
- `finalize_post.py` fused the pairwise products, accumulation, and the
  per-chunk reverse cumsum of `dg` into one reverse-order row loop
- `finalize_reduce.py` absorbed the `HV -> H` group reduce
- `finalize_bwd.py` became pure plumbing

Important project-local details that shaped the current code:

- the oracle's `dg` cumsum is per-chunk, not full-`T`; the kernel path now
  matches that directly
- `single_value()` store dtype must match the source register dtype
- mixed `HV`/`H` tensor shape bindings need distinct scalar-symbol positions

### Scan path

The last host-glue cleanup finished the scan side too:

- `scan_fused` absorbed the `exp2` path through `exp2_glast_vf`
- `QG_SCALE` was folded into the consuming VF rather than using a requantized
  `l0c_to_ub` bridge
- the scan-stage `dAqk` seam is stored unmasked and re-masked downstream where
  the next stage already needs the causal mask
- a docstring-aware scrub over the compose and stage drivers confirmed that
  only layout prep, `g_last` slicing, and `build_saved_forward` test glue
  remain on host

## 2026-06-05 to 2026-06-07: Hardware-only Debug and Profiling Harness

### Harness and defaults

The project gained reusable hardware-debug scaffolding:

- `test_script/module_vs_ref.py` for leaf/module isolation with
  `--mode simulator|onboard`
- `test_script/run_onboard_profile.sh`
- `test_script/run_onboard_profile_each_module.sh`

The default CLI/test input profile was aligned with the new tolerance floor:

- `scale=0.01` for `q/v/initial_state/do/dht`
- `k_scale=0.05` for `k`

### Scalar-burst failures

The large remaining hardware-only failures came from per-token scalar-burst
paths:

- `inverse_epilogue` had a `dv=0` failure until `beta` / `dbeta` were repacked
  as `[L, C0]` aligned rows
- `finalize_post` first failed `dq_hv_post`, then later showed the write-side
  `dbeta` twin of the same trap
- `finalize_pre` still needed the same aligned-row `beta` staging on the
  large-scale `scale=1.0` bisect path
- `inverse_dainv` ended up needing aligned-row staging plus an explicit gather
  to rebuild the 64-lane fp32 `betav`

The stable cross-project lesson from those fixes lives in
`agent/references/constraints/a5.md`; this timeline keeps only the project
history.

### Debugging aid added during this round

While chasing those VF-local issues, the project also added the simulator-only
micro `print_reg(...)` helper so `Reg` / `RegList` values inside `@vf()` could
be inspected directly. That helper is now documented via the agent owner docs,
not only here.
