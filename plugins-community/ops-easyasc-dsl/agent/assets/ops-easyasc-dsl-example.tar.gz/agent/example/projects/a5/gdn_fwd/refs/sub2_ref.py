"""Sub-kernel reference: sub2 - fused M2-M5 with an internal C loop.

Location: `tmp_deepseek_decompose_delta_h/F/refs/sub2.py`

I/O contract
------------
Inputs:
  - attn:                  torch.bfloat16 [B, H, C, 64, 64]  memory=GM
  - q_i:                   torch.bfloat16 [B, H, C, 64, 128] memory=GM
  - k_i:                   torch.bfloat16 [B, H, C, 64, 128] memory=GM
  - k_cumdecay_i:          torch.bfloat16 [B, H, C, 64, 128] memory=GM
  - v_i:                   torch.bfloat16 [B, H, C, 64, 128] memory=GM
  - g_i:                   torch.float32  [B, H, C, 64]      memory=GM
  - last_recurrent_state:  torch.bfloat16 [B, H, 128, 128]  memory=GM

Outputs:
  - core_attn_out:         torch.bfloat16 [B, H, C, 64, 128] memory=GM
  - final_state:           torch.bfloat16 [B, H, 128, 128]   memory=GM

Producer(s): sub1, user input
Consumer(s): user output

Primitives used: [P6, P2, L1, L3]

Precision
---------
M2/M3/M4 use bf16-origin cube inputs with fp32 accumulation.
v_new and state are quantized to bf16 at the same boundaries as the authored
kernel. M5 rounds k_weighted to bf16 before the state-update matmul.
"""

import torch


def subkernel(attn, q_i, k_i, v_i, k_cumdecay_i, g_i, last_recurrent_state):
    B, H, C, L, D = q_i.shape
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=q_i.device)
    core_attn_out = torch.empty(B, H, C, L, D, dtype=torch.bfloat16, device=q_i.device)

    for i in range(C):
        q = q_i[:, :, i].float()
        k = k_i[:, :, i].float()
        v = v_i[:, :, i].float()
        k_cumdecay = k_cumdecay_i[:, :, i].float()
        g = g_i[:, :, i].float()

        v_prime = (
            k_cumdecay.to(torch.bfloat16).to(torch.float32)
            @ state.float().to(torch.bfloat16).to(torch.float32)
        )
        v_new = (v - v_prime).bfloat16()
        attn_inter = (
            q.to(torch.bfloat16).to(torch.float32)
            @ state.float().to(torch.bfloat16).to(torch.float32)
        ) * g[:, :, :, None].exp()
        core_attn_out[:, :, i] = (
            attn_inter + attn[:, :, i].float() @ v_new.float()
        ).bfloat16()

        g_last = g[:, :, -1]
        k_weighted = k * (g_last[:, :, None] - g).exp()[..., None]
        state = (
            state.float() * g_last[:, :, None, None].exp()
            + k_weighted.transpose(-1, -2).bfloat16().float() @ v_new.float()
        ).bfloat16()

    return core_attn_out, state
