"""Per-step pipe occupancy for the delta_rule forward kernels (simulator traces).

Runs each of the 4 pipeline steps (preprocess -> tril_inverse64 ->
recompute_wu -> chunk_delta sub1/sub2) under a forced core count with tracing
on, then reports `active / span` occupancy per pipe track from the child trace
files.  `tril_inverse64` is the gate-independent GDN kernel; it is launched here
via a direct OpExec so it can emit a trace without modifying the shared file.

Occupancy = union of active intervals on a track / (last_end - first_start) on
that same track, with stall events excluded (only `cat in PIPE_CATS` events count).

Default profile shape is 1-core, B=1, H=1, C=4.

  python projects/a5/delta_rule_fwd/profile_pipe_occupancy.py
  python projects/a5/delta_rule_fwd/profile_pipe_occupancy.py --core-count 1 --C 4
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import torch

_ROOT = Path(__file__).resolve().parents[3]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from easyasc.a5 import OpExec  # noqa: E402
from easyasc.simulator import SimulatorConfig  # noqa: E402

from projects.a5.delta_rule_fwd.delta_rule_full import make_inputs  # noqa: E402
import projects.a5.delta_rule_fwd.kernels.delta_preprocess as preprocess_mod  # noqa: E402
import projects.a5.delta_rule_fwd.kernels.delta_recompute_wu as recompute_mod  # noqa: E402
import projects.a5.delta_rule_fwd.kernels.chunk_delta_sub1 as sub1_mod  # noqa: E402
import projects.a5.delta_rule_fwd.kernels.chunk_delta_sub2 as sub2_mod  # noqa: E402
from projects.a5.gdn_fwd.kernels import tril_inverse64 as tril_mod  # noqa: E402


PIPE_CATS = {"MTE2", "MTE1", "M", "FIX", "V", "MTE3"}


def _interval_union(intervals: Sequence[Tuple[float, float]]) -> float:
    if not intervals:
        return 0.0
    ordered = sorted(intervals)
    cur_start, cur_end = ordered[0]
    total = 0.0
    for start, end in ordered[1:]:
        if start <= cur_end:
            if end > cur_end:
                cur_end = end
            continue
        total += cur_end - cur_start
        cur_start, cur_end = start, end
    total += cur_end - cur_start
    return total


def _trace_makespan(trace_events: Iterable[Dict]) -> float:
    end_times = [float(e["ts"]) + float(e["dur"]) for e in trace_events if e.get("ph") == "X"]
    return max(end_times) if end_times else 0.0


def _load_trace_summary(trace_path: Path) -> Dict[str, object]:
    payload = json.loads(trace_path.read_text(encoding="utf-8"))
    events = payload.get("traceEvents", [])
    tid_to_name = {}
    for event in events:
        if event.get("ph") == "M" and event.get("name") == "thread_name":
            tid_to_name[int(event["tid"])] = str(event.get("args", {}).get("name", ""))

    pipe_intervals: Dict[str, List[Tuple[float, float]]] = {}
    for event in events:
        if event.get("ph") != "X":
            continue
        if str(event.get("cat")) not in PIPE_CATS:
            continue
        track_name = tid_to_name.get(int(event["tid"]), "")
        if not track_name:
            continue
        start = float(event["ts"])
        end = start + float(event["dur"])
        pipe_intervals.setdefault(track_name, []).append((start, end))

    occupancies = []
    for track_name, intervals in sorted(pipe_intervals.items()):
        active = _interval_union(intervals)
        span = max(end for _, end in intervals) - min(start for start, _ in intervals)
        occ = 0.0 if span <= 0.0 else active / span
        occupancies.append({"track": track_name, "active": active, "span": span, "occupancy": occ})
    occupancies.sort(key=lambda item: (-float(item["occupancy"]), item["track"]))
    return {
        "trace_path": str(trace_path),
        "makespan": _trace_makespan(events),
        "occupancies": occupancies,
    }


def _print_step(step_name: str, trace_path: Path) -> None:
    summary = _load_trace_summary(trace_path)
    print(f"[{step_name}] makespan={summary['makespan']:.1f} cycles")
    for occ in summary["occupancies"]:
        print(
            "    %-22s occ=%5.1f%%  active=%8.1f  span=%8.1f"
            % (occ["track"], 100.0 * float(occ["occupancy"]), float(occ["active"]), float(occ["span"]))
        )
    if not summary["occupancies"]:
        print("    (no pipe events)")


def _as_first(value):
    return value[0] if isinstance(value, tuple) else value


def _run_tril_traced(a, core_count, trace_path, out_dir):
    """Launch the reused GDN tril_inverse64 kernel with tracing + forced cores."""
    SIZE = tril_mod.SIZE
    kernel_dtype = tril_mod.KERNEL_DTYPE
    a = a.to(kernel_dtype)
    B, H, C = (int(d) for d in a.shape[:3])
    out = torch.empty(a.shape, dtype=torch.bfloat16, device=a.device)
    kfn = tril_mod.tril_inverse64_v2_strict_bf16_kernel
    saved = getattr(kfn, "_simulator_config", None)
    kfn._simulator_config = SimulatorConfig(core_count=core_count, execution_timeout_s=180.0, trace_enabled=True)
    try:
        return OpExec(kfn, out_dir=out_dir, simulator=True, trace=str(trace_path))(
            a.contiguous(), out, B, H, C, shape_bindings=tril_mod.SHAPE_BINDINGS
        )
    finally:
        if saved is None:
            try:
                delattr(kfn, "_simulator_config")
            except AttributeError:
                pass
        else:
            kfn._simulator_config = saved


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=1)
    parser.add_argument("--C", type=int, default=4)
    parser.add_argument("--core-count", type=int, default=1)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--out-dir", type=str, default=str(Path(__file__).resolve().parent / "tmp" / "pipe_profile"))
    args = parser.parse_args()

    core_count = args.core_count
    preprocess_mod.SIM_CORE_COUNT = core_count
    recompute_mod.SIM_CORE_COUNT = core_count
    sub1_mod.SIM_CORE_COUNT = core_count
    sub2_mod.SIM_CORE_COUNT = core_count

    out_root = Path(args.out_dir).resolve()
    out_root.mkdir(parents=True, exist_ok=True)
    traces = {name: out_root / f"{name}.json" for name in
              ("preprocess", "tril_inverse64", "recompute_wu", "sub1", "sub2")}

    torch.manual_seed(args.seed)
    query, key, value, beta = make_inputs(B=args.B, H=args.H, C=args.C)

    # Step 1: preprocess -> strict-lower A.
    preprocess_attn = _as_first(preprocess_mod.run_kernel(
        key, beta, simulator=True, trace=str(traces["preprocess"]), out_dir=str(out_root / "preprocess")))
    # Step 2: tril_inverse64 -> (I - A)^-1 (reused GDN kernel).
    wu_attn_bf16 = _run_tril_traced(preprocess_attn, core_count, traces["tril_inverse64"], str(out_root / "tril"))
    # Step 3: recompute-WU -> value_wu, k_cumdecay.
    value_wu, k_cumdecay = recompute_mod.run_kernel(
        key, value, beta, wu_attn_bf16, simulator=True, trace=str(traces["recompute_wu"]), out_dir=str(out_root / "recompute_wu"))
    # Step 4a: standalone sub1 -> attn (reference only; sub1 is now fused into sub2).
    _as_first(sub1_mod.run(query, key, simulator=True, trace=str(traces["sub1"]), out_dir=str(out_root / "sub1")))
    # Step 4b: fused sub2 -> core_attn_out, final_state (computes attn internally).
    state0 = torch.zeros((args.B, args.H, 128, 128), dtype=torch.bfloat16)
    sub2_mod.run(query, key, value_wu, k_cumdecay, state0,
                 simulator=True, trace=str(traces["sub2"]), out_dir=str(out_root / "sub2"))

    print(f"\n=== delta_rule_fwd pipe occupancy  core_count={core_count}  B={args.B} H={args.H} C={args.C} ===")
    _print_step("step1 preprocess", traces["preprocess"])
    _print_step("step2 tril_inverse64", traces["tril_inverse64"])
    _print_step("step3 recompute_wu", traces["recompute_wu"])
    _print_step("step4a sub1 (standalone, now fused into sub2)", traces["sub1"])
    _print_step("step4b chunk_delta FUSED sub2 (sub1+sub2)", traces["sub2"])


if __name__ == "__main__":
    raise SystemExit(main())
