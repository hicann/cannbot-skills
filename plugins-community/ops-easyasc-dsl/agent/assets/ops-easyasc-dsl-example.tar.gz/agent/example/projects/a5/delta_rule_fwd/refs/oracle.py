"""Candidate-local expected outputs for the chunk-delta sub-kernel checks.

Ungated delta-rule analogue of `projects/a5/gdn_fwd/refs/oracle.py`.  Each
`expected_*` helper computes the oracle's local slice for one sub-kernel of the
step-4 chunk-delta recurrence, following the same Sub1 -> fused Sub2 split that
GDN uses.

Difference from GDN (gate `g` removed):
  * Sub1 has no data-dependent `decay_mask` input — the intra-chunk score is
    multiplied by a constant lower-triangular causal keep (incl. diagonal),
    which is exactly GDN's `decay_mask` at `g == 0`.
  * Sub2 drops every gate factor: the inter-chunk read is plain `q @ S`, the
    state update is plain `S += k^T @ v_new` (no `exp(g_last)` decay, no per-key
    `exp(g_last - g_cumsum)` forget weight).
"""

import torch


def _causal_keep(L: int, device: torch.device) -> torch.Tensor:
    """Lower-triangular keep incl. diagonal == GDN decay_mask at g=0."""
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device))


def expected_sub1(q_i, k_i):
    """Oracle attn from M1 alone: ``q @ k^T`` on the causal keep.

    Accepts a single chunk [B,H,L,D] or full C input [B,H,C,L,D]. The
    sub1->sub2 GM boundary is bf16 in the authored execution path.
    """
    L = q_i.shape[-2]
    return (q_i.float() @ k_i.float().transpose(-1, -2) * _causal_keep(L, q_i.device)).bfloat16()


def expected_sub2(attn, q_i, k_i, v_i, k_cumdecay_i, last_recurrent_state):
    """Oracle fused M2-M5 output over the full C loop (ungated)."""
    B, H, C, L, D = q_i.shape
    core_attn_out = torch.empty(B, H, C, L, D, dtype=torch.bfloat16, device=q_i.device)
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=q_i.device)

    for i in range(C):
        q = q_i[:, :, i].float()
        k = k_i[:, :, i].float()
        v = v_i[:, :, i].float()
        k_cumdecay = k_cumdecay_i[:, :, i].float()

        v_prime = k_cumdecay @ state.float()
        v_new = (v - v_prime).bfloat16()
        attn_inter = q @ state.float()
        core_attn_out[:, :, i] = (attn_inter + attn[:, :, i].float() @ v_new.float()).bfloat16()

        state = (
            state.float()
            + k.transpose(-1, -2).bfloat16().float() @ v_new.float()
        ).bfloat16()

    return core_attn_out, state


def expected_sub2_state_history(attn, q_i, k_i, v_i, k_cumdecay_i, last_recurrent_state):
    """Sub2 oracle that also returns post-update state and the saved bwd inputs.

    For the ungated delta rule the only non-trivial saved tensors are the
    per-chunk post-update `state_after_history` and `v_new_history`.  GDN's
    `k_weighted_history` degenerates to the raw key (no `exp(g_last - g_cumsum)`
    weight) and `exp_delta_history` degenerates to all-ones, so they are not
    re-emitted here.
    """
    B, H, C, L, D = q_i.shape
    core_attn_out = torch.empty(B, H, C, L, D, dtype=torch.bfloat16, device=q_i.device)
    state_after_history = torch.empty(B, H, C, D, D, dtype=torch.bfloat16, device=q_i.device)
    v_new_history = torch.empty(B, H, C, L, D, dtype=torch.bfloat16, device=q_i.device)
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=q_i.device)

    for i in range(C):
        q = q_i[:, :, i].float()
        k = k_i[:, :, i].float()
        v = v_i[:, :, i].float()
        k_cumdecay = k_cumdecay_i[:, :, i].float()

        v_prime = k_cumdecay @ state.float()
        v_new = (v - v_prime).bfloat16()
        v_new_history[:, :, i] = v_new
        attn_inter = q @ state.float()
        core_attn_out[:, :, i] = (attn_inter + attn[:, :, i].float() @ v_new.float()).bfloat16()

        state = (
            state.float()
            + k.transpose(-1, -2).bfloat16().float() @ v_new.float()
        ).bfloat16()
        state_after_history[:, :, i] = state

    return core_attn_out, state, state_after_history, v_new_history


def oracle_full(query, key, value, k_cumdecay):
    B, H, _C, _L, D = query.shape
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=query.device)
    attn = expected_sub1(query, key)
    return expected_sub2(attn, query, key, value, k_cumdecay, state)


def oracle_full_state_history(query, key, value, k_cumdecay):
    B, H, _C, _L, D = query.shape
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=query.device)
    attn = expected_sub1(query, key)
    return expected_sub2_state_history(attn, query, key, value, k_cumdecay, state)
