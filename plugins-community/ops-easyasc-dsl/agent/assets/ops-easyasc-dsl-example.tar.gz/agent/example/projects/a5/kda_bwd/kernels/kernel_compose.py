from pathlib import Path

from _torch_formula import L, build_saved_forward
from inverse_bwd import run as run_inverse_bwd
from projects.a5.kda_bwd.refs.common import KDAOracleInputs
from scan_bwd import run as run_scan_bwd
from finalize_bwd import run as run_finalize_bwd


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "kda_bwd_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def run(q, k, v, g, beta, initial_state, do, dht, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    inputs = KDAOracleInputs(q=q, k=k, v=v, g=g, beta=beta, initial_state=initial_state, do=do, dht=dht, chunk_size=L)
    caches = build_saved_forward(inputs)
    g_last = caches.g_cumsum[:, L - 1::L, :, :]

    scan = run_scan_bwd(
        caches.Aqk,
        caches.v_new,
        do,
        caches.kg,
        caches.qg,
        caches.w,
        g_last,
        dht,
        simulator=simulator,
        trace=_child_trace(trace, out_dir, "scan_bwd"),
        gen_only=gen_only,
        out_dir=out_dir,
        skip_compile=skip_compile,
        profile=profile,
    )
    inverse = run_inverse_bwd(
        q,
        k,
        v,
        beta,
        do,
        caches.g_cumsum,
        caches.v_new,
        caches.h,
        scan[1],
        scan[2],
        caches.Akk,
        simulator=simulator,
        trace=_child_trace(trace, out_dir, "inverse_bwd"),
        gen_only=gen_only,
        out_dir=out_dir,
        skip_compile=skip_compile,
        profile=profile,
    )
    return run_finalize_bwd(
        q,
        k,
        beta,
        caches.g_cumsum,
        scan[0],
        inverse[0],
        inverse[1],
        inverse[2],
        inverse[3],
        inverse[4],
        inverse[5],
        scan[3],
        simulator=simulator,
        trace=_child_trace(trace, out_dir, "finalize_bwd"),
        gen_only=gen_only,
        out_dir=out_dir,
        skip_compile=skip_compile,
        profile=profile,
    )
