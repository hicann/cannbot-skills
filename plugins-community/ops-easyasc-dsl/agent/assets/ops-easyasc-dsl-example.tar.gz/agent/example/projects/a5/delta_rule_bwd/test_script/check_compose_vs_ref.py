"""End-to-end: run the full delta_rule_bwd kernel_compose in the simulator and
compare the public gradients against (1) the bf16-cube refs oracle and (2) the
fp32 golden delta_rule_bwd_full.

Usage:
  python projects/a5/delta_rule_bwd/test_script/check_compose_vs_ref.py [--B 1 --H 1 --C 2]
"""

import sys
from pathlib import Path

import torch

SCRIPT_DIR = Path(__file__).resolve().parent
PLAN_DIR = SCRIPT_DIR.parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)
for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import make_inputs, oracle as ref_oracle  # noqa: E402
from kernel_compose import run as kernel_run  # noqa: E402
from projects.a5.delta_rule_bwd.delta_rule_bwd_full import delta_rule_bwd_full  # noqa: E402

NAMES = ("d_query", "d_key", "d_value", "d_beta")


def _arg(name, default):
    pref = "--" + name
    for i, a in enumerate(sys.argv[1:]):
        if a == pref and i + 2 <= len(sys.argv[1:]):
            return int(sys.argv[1:][i + 1])
        if a.startswith(pref + "="):
            return int(a.split("=", 1)[1])
    return default


def _report(title, got, ref, atol, rtol):
    ok_all = True
    print(title)
    for name, g, r in zip(NAMES, got, ref):
        gf, rf = g.float(), r.float()
        err = (gf - rf).abs().max().item()
        ok = bool(torch.allclose(gf, rf, atol=atol, rtol=rtol)) and bool(torch.isfinite(gf).all())
        ok_all = ok_all and ok
        print(f"  {name}: max_abs={err:.3e} {'OK' if ok else 'FAIL'}")
    return ok_all


def main():
    B, H, C = _arg("B", 1), _arg("H", 1), _arg("C", 4)  # C>=3 exercises the multi-update d_state recurrence
    torch.manual_seed(20260609)
    full = make_inputs(B, H, C)

    got = kernel_run(*full, simulator=True, out_dir="tmp/delta_bwd_compose")
    ref = ref_oracle(*full)

    # golden (fp32) takes the same saved tensors minus value_wu/v_new_history (it recomputes v_new).
    query, key, value, beta, grad_output, wu_attn_bf16, value_wu, k_cumdecay, state_after_history, v_new_history, grad_final_state = full
    gold = delta_rule_bwd_full(query, key, value, beta, grad_output, wu_attn_bf16, value_wu, k_cumdecay, state_after_history, grad_final_state=grad_final_state)

    ok1 = _report("=== kernel_compose vs bf16-cube refs oracle (expect ~0) ===", got, ref, atol=2e-3, rtol=2e-3)
    ok2 = _report("=== kernel_compose vs fp32 golden (expect <2e-3, bf16 path) ===", got, gold, atol=2e-3, rtol=2e-3)
    ok = ok1 and ok2
    print("delta_rule_bwd compose-vs-ref %s" % ("OK" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
