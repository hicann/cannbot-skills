"""Pure PyTorch reference for the default split scan backward stage."""

from common import make_inputs, scan_split_bwd


def subkernel(query, key, grad_output, g_cumsum, decay_mask, k_cumdecay, state_after_history, v_new_history, k_weighted_history, grad_final_state, exp_delta_history=None):
    return scan_split_bwd(
        query, key, grad_output, g_cumsum, decay_mask,
        k_cumdecay, state_after_history, v_new_history, k_weighted_history,
        grad_final_state, exp_delta_history,
    )


if __name__ == "__main__":
    args = make_inputs()
    result = subkernel(args[0], args[1], args[5], args[6], args[7], args[10], args[11], args[12], args[13], args[14], args[15])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
