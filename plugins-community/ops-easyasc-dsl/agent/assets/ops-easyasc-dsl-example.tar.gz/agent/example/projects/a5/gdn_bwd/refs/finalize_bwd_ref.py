"""Pure PyTorch reference for final gradient accumulation and reverse cumsum."""

from common import finalize_grads, make_inputs


def subkernel(key, value, beta, decay_mask, d_q, d_k_core, d_g_core, d_decay_core, d_v_beta, d_k_beta_wu, d_g_wu, d_k_pre, d_k_beta_pre, d_decay_pre):
    return finalize_grads(
        key, value, beta, decay_mask,
        d_q, d_k_core, d_g_core, d_decay_core,
        d_v_beta, d_k_beta_wu, d_g_wu,
        d_k_pre, d_k_beta_pre, d_decay_pre,
    )


if __name__ == "__main__":
    args = make_inputs()
    scan = __import__("scan_bwd_ref").subkernel(args[0], args[1], args[5], args[6], args[7], args[10], args[11], args[12], args[13], args[14])
    wu = __import__("wu_bwd_ref").subkernel(args[1], args[2], args[3], args[6], args[8], scan[4], scan[5])
    inv = __import__("inverse_preprocess_bwd_ref").subkernel(args[1], args[3], args[7], args[8], wu[0])
    result = subkernel(args[1], args[2], args[3], args[7], scan[0], scan[1], scan[2], scan[3], wu[1], wu[2], wu[3], inv[0], inv[1], inv[2])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
