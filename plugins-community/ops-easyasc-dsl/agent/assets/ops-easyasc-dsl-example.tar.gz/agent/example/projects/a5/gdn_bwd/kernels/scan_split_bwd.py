import os
from pathlib import Path

from scan_local_bwd import run as run_scan_local_bwd
from scan_state_bwd import run as run_scan_state_bwd


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "gdn_bwd_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def _child_out_dir(out_dir, name):
    if not out_dir:
        return ""
    path = Path(out_dir) / name
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def run(query, key, grad_output, g_cumsum, decay_mask, k_cumdecay, state_after_history, v_new_history, k_weighted_history, grad_final_state, exp_delta_history, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    local = run_scan_local_bwd(
        query, key, grad_output, decay_mask, v_new_history,
        simulator=simulator, trace=_child_trace(trace, out_dir, "scan_local_bwd"),
        gen_only=gen_only, out_dir=_child_out_dir(out_dir, "scan_local_bwd"),
        skip_compile=skip_compile, profile=profile,
    )
    d_score_tmp, d_v_attn_tmp, d_decay_core, d_decay_core_masked = local

    state = run_scan_state_bwd(
        query, key, grad_output, g_cumsum, k_cumdecay, state_after_history,
        grad_final_state, d_score_tmp, v_new_history, k_weighted_history,
        d_v_attn_tmp, exp_delta_history,
        simulator=simulator, trace=_child_trace(trace, out_dir, "scan_state_bwd"),
        gen_only=gen_only, out_dir=_child_out_dir(out_dir, "scan_state_bwd"),
        skip_compile=skip_compile, profile=profile,
    )
    d_q_core, d_k_core, d_g_core, d_value_wu, d_k_cumdecay = state
    return d_q_core, d_k_core, d_g_core, d_decay_core, d_value_wu, d_k_cumdecay, d_decay_core_masked


if __name__ == "__main__":
    os.environ.setdefault("C_SIZE", "1")
