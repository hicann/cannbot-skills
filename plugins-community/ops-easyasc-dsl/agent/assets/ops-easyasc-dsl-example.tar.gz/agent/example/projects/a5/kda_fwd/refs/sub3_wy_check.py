"""Local randomized check for sub3_wy_ref.py."""

import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from oracle import sample_inputs as oracle_sample_inputs, to_chunked_inputs  # noqa: E402
from sub1_gate_ref import subkernel as gate_cumsum  # noqa: E402
from sub2_intra_ref import subkernel as intra  # noqa: E402
from sub3_wy_ref import subkernel  # noqa: E402


ATOL = 0.0
RTOL = 0.0


def _expand_qk_to_value_heads(x, hv):
    h = x.shape[1]
    return x.repeat_interleave(hv // h, dim=1)


def expected(q, k, v, beta, Akk, g):
    HV = v.shape[1]
    q_hv = _expand_qk_to_value_heads(q.float(), HV)
    k_hv = _expand_qk_to_value_heads(k.float(), HV)
    gf = g.float()
    betaf = beta.float()
    w = torch.matmul(Akk.float(), k_hv * betaf[..., None] * gf)
    u = torch.matmul(Akk.float(), v.float() * betaf[..., None])
    qg = q_hv * gf
    kg = k_hv * (gf[..., -1:, :] / gf)
    return w.to(k.dtype), u.to(v.dtype), qg.to(q.dtype), kg.to(k.dtype)


def sample_inputs():
    chunk_size = 32
    q, k, v, g_raw, beta, _ = oracle_sample_inputs(B=1, H=1, HV=1, C=1, L=chunk_size, K=32, V=32, seed=31)
    q_c, k_c, v_c, g_raw_c, beta_c = to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=chunk_size)
    g_c = gate_cumsum(g_raw_c)
    _Aqk, Akk = intra(q_c, k_c, g_c, beta_c, scale=32 ** -0.5)
    return q_c, k_c, v_c, beta_c, Akk, g_c


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return (value,)


def main():
    inputs = sample_inputs()
    actual = _as_tuple(subkernel(*inputs))
    expected_items = _as_tuple(expected(*inputs))
    if len(actual) != len(expected_items):
        raise AssertionError(f"arity mismatch: actual={len(actual)} expected={len(expected_items)}")
    for idx, (act, exp) in enumerate(zip(actual, expected_items)):
        if not torch.isfinite(act.float()).all() or not torch.isfinite(exp.float()).all():
            raise AssertionError(f"non-finite output at index {idx}")
        torch.testing.assert_close(act.float(), exp.float(), atol=ATOL, rtol=RTOL)
    print("sub3_wy: OK")


if __name__ == "__main__":
    main()
