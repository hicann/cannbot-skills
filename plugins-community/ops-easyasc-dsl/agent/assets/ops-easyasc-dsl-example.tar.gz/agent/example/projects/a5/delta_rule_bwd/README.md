# Delta Rule Backward (ungated)

A5 implementation of `delta_rule_bwd` — the chunked **ungated** delta-rule
backward. It is `projects/a5/gdn_bwd/` with the per-token gate `g` removed.

The FLA reference implements this exact backward by reusing the *gated*
delta-rule kernels with `g=None` in `fla/ops/delta_rule/chunk.py`, returning
`(dq, dk, dv, db, None, dh0, …)` — there is no `dg`. This project mirrors that
relationship: the math is `gdn_bwd` evaluated at `g == 0`.

## Status

Complete and validated end-to-end in the simulator. The PyTorch golden, the
`refs/` decomposition, all 5 DSL kernels, and the `kernel_compose` wiring are in
place; the full backward matches the bf16-cube refs oracle to float epsilon and
the fp32 golden within the 2e-3 bf16 budget.

## Layout

- `delta_rule_bwd_full.py`: PyTorch golden/reference formula (`gdn_bwd_full` minus `g`).
- `refs/`: plan-local PyTorch references (`common.py` staged formulas, `oracle.py`,
  per-stage `*_ref.py` + `*_check.py`, `compose.py`, `golden_check.py`, `plan.md`, `dag.json`).
- `kernels/`: the 5 DSL stages (`scan_local_bwd`, `scan_state_bwd`, `wu_bwd`,
  `inverse_preprocess_bwd`, `finalize_bwd`) + wiring (`scan_split_bwd`, `kernel_compose`).
- `test_script/`: per-module checks (`check_*.py`, `module_vs_ref.py`) and the
  end-to-end `check_compose_vs_ref.py`.
- `optimization_timeline.md`: project-local optimization and profiling
  rationale for the current implementation.

Each kernel is the `gdn_bwd/kernels/` version with the gate removed; `gdn_bwd` is
untouched. The 5-stage DAG is `scan_local → scan_state → wu → inverse_preprocess`,
all → `finalize` (see `refs/plan.md`).

## What "minus `g`" means

Setting `g == 0` makes every `exp(g_cumsum)` factor 1:

- intra-chunk `decay_mask = exp(g_cumsum_i - g_cumsum_j)` → constant causal keep
  `tril(ones)` (no longer a saved forward tensor);
- `k_cumdecay = (I-A)^-1 @ (key*beta)` loses its `exp(g_cumsum)` weight;
- recurrent-state decay `S * exp(g_last)` and per-key forget `k * exp(g_last - g_cumsum)`
  vanish → the update is the plain `S += k_i^T @ v_new`;
- the inter-chunk term is plain `q @ S` (no `exp(g_cumsum)` on `q`).

In the backward, the whole gate-gradient sub-computation
(`d_g_cumsum` / `d_decay_mask` / `d_exp_g_last` / `d_delta`) is removed — it only
ever fed `d_g` and never flows into `d_q/d_k/d_v/d_beta`. So:

- saved forward tensors shrink **6 → 4**: `(wu_attn_bf16, value_wu, k_cumdecay, state_after_history)`
  (drop `g_cumsum`, `decay_mask`);
- outputs shrink to `(d_query, d_key, d_value, d_beta[, d_initial_state])` (drop `d_g`).

Precision path mirrors `gdn_bwd`: inputs promoted to fp32 internally, the only
bf16 boundary is the `wu_attn` kernel-handoff tensor, and the inverse block uses
`dA = W.T @ dW @ W.T` with `W = (I - A)^-1`.

## Quick checks

```bash
# golden: self-check vs autograd + bit-for-bit cross-check against gdn_bwd_full(g=0)
python -m projects.a5.delta_rule_bwd.delta_rule_bwd_full

# refs: per-stage checks + compose==oracle + bf16-refs vs fp32-golden tie
for f in projects/a5/delta_rule_bwd/refs/*_check.py; do python "$f"; done
python projects/a5/delta_rule_bwd/refs/compose.py
python projects/a5/delta_rule_bwd/refs/golden_check.py

# kernels: each stage in the simulator vs its ref
python projects/a5/delta_rule_bwd/test_script/check_wu_bwd.py
python projects/a5/delta_rule_bwd/test_script/check_inverse_preprocess_bwd.py
python projects/a5/delta_rule_bwd/test_script/check_finalize_bwd.py
python projects/a5/delta_rule_bwd/test_script/check_scan_state_bwd.py
python projects/a5/delta_rule_bwd/test_script/module_vs_ref.py --module scan_local_bwd

# end-to-end: full kernel backward vs refs-oracle + fp32-golden
python projects/a5/delta_rule_bwd/test_script/check_compose_vs_ref.py --B 1 --H 1 --C 2
```

Expected: the golden's `compare_against_gated_zero_g` reports `max_abs = 0.000e+00`
for every kept gradient (the executable proof that `delta_rule_bwd == gdn_bwd` with
`g == 0`); each kernel matches its ref to ~float epsilon; the end-to-end compose
matches the refs oracle to float epsilon and the fp32 golden within 2e-3.

## Profiling

```bash
# simulator pipe occupancy (active/span per pipe track), 1-core, all 5 stages
python projects/a5/delta_rule_bwd/profile_pipe_occupancy.py --core-count 1 --B 1 --H 1 --C 8

# onboard (Ascend 950) per-kernel AVG timing — run on the Ascend box (needs NPU+CANN)
projects/a5/delta_rule_bwd/test_script/run_onboard_profile.sh            # MODULE=compose, all 5 leaves
MODULE=scan_state_bwd projects/a5/delta_rule_bwd/test_script/run_onboard_profile.sh
MODE=simulator projects/a5/delta_rule_bwd/test_script/run_onboard_profile.sh   # local no-NPU dry run

# GPU baseline: FLA chunk_delta_rule *backward* (Triton) — run on an NVIDIA box (needs CUDA + fla)
python projects/a5/delta_rule_bwd/test_script/profile_fla_delta_rule_bwd.py
```

`profile_pipe_occupancy.py` runs locally; `run_onboard_profile.sh` builds+times on the NPU
(`module_vs_ref.py --mode onboard --profile`) and greps each `r.sh.log` for the `N_TESTS/AVG` token.
At 1-core B1H1C8, `scan_state_bwd` dominates wall-clock (~45%) but is recurrence-serialized (no pipe
>42%); the other four sit near their natural bound — see `optimization_timeline.md`
for the full snapshot.

`profile_fla_delta_rule_bwd.py` is the GPU baseline (counterpart of
`delta_rule_fwd/test_script/profile_fla_delta_rule.py`): it times FLA's `chunk_delta_rule`
**backward** Triton kernels on the representative B1 H32 C16 shape (T=C*L=1024) via CUDA events +
`torch.profiler`. It needs an NVIDIA GPU + `flash-linear-attention`; on a non-CUDA box it exits with
a clear guard message (it does not run the EasyASC kernels).
