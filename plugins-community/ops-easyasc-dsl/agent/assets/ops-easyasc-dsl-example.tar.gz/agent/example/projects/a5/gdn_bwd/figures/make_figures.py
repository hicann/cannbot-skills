#!/usr/bin/env python3
"""Generate slide-ready SVG figures for the GDN backward optimization timeline.

Source: projects/a5/gdn_bwd/optimization_timeline.md
Raw simulator cycle counts / hardware AVG values from that document are kept
here only as source data for computing ratios. The SVGs themselves display
RELATIVE numbers only (percentages): cycle-based charts show % of baseline,
the hardware profile shows % of total runtime. Hardware is Ascend 950.

Run:  python3 make_figures.py
Emits: 01_timeline.svg 02_scan_optimization.svg 03_forward_cache.svg 04_hw_profile.svg
       05_split_scan.svg 06_incremental_rebuild.svg
SVGs are 1280x720 (16:9), white background, Segoe-first font stack for PowerPoint.
"""

import os

FONT = "'Segoe UI', system-ui, -apple-system, Helvetica, Arial, sans-serif"

# ---- palette -------------------------------------------------------------
INK   = "#0F172A"   # titles
BODY  = "#334155"   # body text
MUTE  = "#64748B"   # captions
GRID  = "#E2E8F0"
BG    = "#FFFFFF"

BLUE       = "#2563EB"   # simulator accent
BLUE_BORD  = "#BFDBFE"
BLUE_BAND  = "#EFF6FF"
BLUE_AREA  = "#DBEAFE"
BLUE_MID   = "#93C5FD"
BLUE_SUB   = "#3B82F6"

ORANGE     = "#EA580C"   # hardware accent
ORANGE_BORD= "#FED7AA"
ORANGE_BAND= "#FFF7ED"
ORANGE_MID = "#FDBA74"
ORANGE_SUB = "#FB923C"

GREEN      = "#15803D"
SLATE      = "#64748B"
TRACK      = "#F1F5F9"

OUT = os.path.dirname(os.path.abspath(__file__))


# ---- svg primitives ------------------------------------------------------
def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def text(x, y, s, size=14, fill=INK, weight="normal", anchor="start", spacing=None, opacity=None):
    extra = ""
    if spacing is not None:
        extra += f' letter-spacing="{spacing}"'
    if opacity is not None:
        extra += f' opacity="{opacity}"'
    return (f'<text x="{x:.2f}" y="{y:.2f}" font-family="{FONT}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}"{extra}>{esc(s)}</text>')


def vtext(x, cy, s, size=14, **kw):
    return text(x, cy + size * 0.35, s, size=size, **kw)


def mtext(x, y, lines, size=14, lh=None, **kw):
    lh = lh if lh is not None else size * 1.3
    out = ""
    for i, ln in enumerate(lines):
        out += text(x, y + i * lh, ln, size=size, **kw)
    return out


def rect(x, y, w, h, fill, rx=0, stroke=None, sw=1, opacity=None):
    extra = ""
    if stroke:
        extra += f' stroke="{stroke}" stroke-width="{sw}"'
    if opacity is not None:
        extra += f' opacity="{opacity}"'
    return f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" rx="{rx}" fill="{fill}"{extra}/>'


def line(x1, y1, x2, y2, stroke, sw=1, dash=None, cap="butt"):
    extra = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" '
            f'stroke="{stroke}" stroke-width="{sw}" stroke-linecap="{cap}"{extra}/>')


def circle(cx, cy, r, fill, stroke=None, sw=1):
    extra = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ""
    return f'<circle cx="{cx:.2f}" cy="{cy:.2f}" r="{r:.2f}" fill="{fill}"{extra}/>'


def polyline(pts, stroke, sw=2, dash=None):
    p = " ".join(f"{x:.2f},{y:.2f}" for x, y in pts)
    extra = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<polyline points="{p}" fill="none" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round"{extra}/>'


def polygon(pts, fill, opacity=None):
    p = " ".join(f"{x:.2f},{y:.2f}" for x, y in pts)
    extra = f' opacity="{opacity}"' if opacity is not None else ""
    return f'<polygon points="{p}" fill="{fill}"{extra}/>'


def wrap(s, maxw, size, cw=0.54):
    words = s.split()
    lines, cur = [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if len(t) * size * cw <= maxw or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def chip(x, y, s, bg, fg="#FFFFFF", size=11):
    w = len(s) * size * 0.56 + 18
    h = 21
    out = rect(x, y, w, h, bg, rx=10)
    out += vtext(x + w / 2, y + h / 2, s, size=size, fill=fg, weight="700", anchor="middle")
    return out, w


def svg_open(w, h):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
            f'viewBox="0 0 {w} {h}" font-family="{FONT}">\n{rect(0,0,w,h,BG)}\n')


def save(name, body):
    p = os.path.join(OUT, name)
    with open(p, "w") as f:
        f.write(body + "</svg>\n")
    return p


# ====================================================================== #
# 1. NARRATIVE TIMELINE
# ====================================================================== #
def fig_timeline():
    W, H = 1280, 720
    s = svg_open(W, H)
    s += text(60, 54, "GDN Backward — Optimization Timeline", size=30, weight="700")
    s += text(60, 84, "From the first correct split to hardware-verified kernels on Ascend 950",
              size=15, fill=MUTE)

    bandTop, bandBot, boundary = 104, 648, 703
    s += rect(48, bandTop, boundary - 48, bandBot - bandTop, BLUE_BAND, rx=14)
    s += rect(boundary + 8, bandTop, 1232 - (boundary + 8), bandBot - bandTop, ORANGE_BAND, rx=14)

    s += text(72, 132, "ACT I  ·  SIMULATOR OPTIMIZATION", size=13, weight="700", fill=BLUE, spacing="1.4")
    s += text(72, 151, "phases 1–5  ·  trace-driven scheduling", size=11.5, fill=BLUE_SUB)
    s += text(boundary + 30, 132, "ACT II  ·  HARDWARE BRING-UP & VERIFICATION", size=13, weight="700",
              fill=ORANGE, spacing="1.4")
    s += text(boundary + 30, 151, "phases 6–9  ·  WebIDE on Ascend 950", size=11.5, fill=ORANGE_SUB)

    spineY = 388
    n = 9
    x0, x1 = 135, 1145
    nodes = [x0 + i * (x1 - x0) / (n - 1) for i in range(n)]
    s += line(nodes[0], spineY, boundary, spineY, BLUE_MID, sw=4, cap="round")
    s += line(boundary, spineY, nodes[-1], spineY, ORANGE_MID, sw=4, cap="round")

    # chips show RELATIVE improvement only (% reductions), never absolute counts.
    phases = [
        ("First Correct Plan1", "5-stage explicit split of gdn_bwd_full", "sim ✓ ref", BLUE),
        ("Cheap Tail Wins", "Tune wu / inverse / finalize before touching scan", "compose −6%", BLUE),
        ("Monolithic Scan Pass", "Delete dead work; specialize the c0 zero-state path", "scan −30%", BLUE),
        ("Split Scan", "BHC-local producer + reverse-state consumer", "scan −23%", BLUE),
        ("Forward-Cache Contract", "Save v_new / k_weighted / exp_delta; bf16 handoff", "state −11%", BLUE),
        ("Hardware Triage", "HW-only fails; rebuild scan-state output-by-output", "scan_state −13%", ORANGE),
        ("Inverse Rebuilt", "One output at a time; light L1 DBuff pass", "inverse −4%", ORANGE),
        ("Finalize Rebuilt", "Hardware-proven rowwise d_g path", "HW ✓", ORANGE),
        ("Final Packaging", "Onboard profile script; clean upload to 950", "shipped ✓", GREEN),
    ]

    CW, CH = 170, 150
    aboveTop, belowTop = 196, 426
    for i, (title, outcome, chiptxt, chipcol) in enumerate(phases):
        nx = nodes[i]
        era = BLUE if i < 5 else ORANGE
        bord = BLUE_BORD if i < 5 else ORANGE_BORD
        above = (i % 2 == 0)
        top = aboveTop if above else belowTop
        cardL = nx - CW / 2
        if above:
            s += line(nx, spineY - 19, nx, top + CH, era, sw=2)
        else:
            s += line(nx, spineY + 19, nx, top, era, sw=2)
        s += rect(cardL, top, CW, CH, "#FFFFFF", rx=11, stroke=bord, sw=1.6)
        pad = 13
        ty = top + 25
        for ln in wrap(title, CW - 2 * pad, 14, cw=0.6):
            s += text(cardL + pad, ty, ln, size=14, weight="700", fill=INK)
            ty += 17
        ty += 5
        for ln in wrap(outcome, CW - 2 * pad, 11.5):
            s += text(cardL + pad, ty, ln, size=11.5, fill=BODY)
            ty += 15
        cs, _ = chip(cardL + pad, top + CH - 31, chiptxt, chipcol)
        s += cs

    for i in range(n):
        era = BLUE if i < 5 else ORANGE
        s += circle(nodes[i], spineY, 19, era, stroke="#FFFFFF", sw=3)
        s += vtext(nodes[i], spineY, str(i + 1), size=17, fill="#FFFFFF", weight="700", anchor="middle")

    s += text(60, 694, "Source: projects/a5/gdn_bwd/optimization_timeline.md   ·   "
                       "chips show relative improvement (%)   ·   hardware: Ascend 950",
              size=11, fill=MUTE)
    return save("01_timeline.svg", s)


# ====================================================================== #
# 2. MONOLITHIC SCAN STAIRCASE  (% of baseline)
# ====================================================================== #
def fig_scan():
    W, H = 1280, 720
    s = svg_open(W, H)
    s += text(60, 54, "Killing the Bottleneck — Monolithic Scan Pass", size=28, weight="700")
    s += text(60, 84, "scan_bwd simulator makespan, relative to baseline  ·  32 A5 cores  ·  (B,H,C) = (1,2,2)",
              size=15, fill=MUTE)

    vals = [94373, 93605, 92029, 88525, 85899, 79901, 77161, 73840,
            71965, 71652, 71640, 70392, 67815, 66375, 66003, 65999]
    pct = [v / vals[0] * 100 for v in vals]
    PX0, PX1, PY0, PY1 = 110, 1150, 150, 560
    yMin, yMax = 68, 100
    X = lambda i: PX0 + i * (PX1 - PX0) / (len(vals) - 1)
    Y = lambda p: PY1 - (p - yMin) / (yMax - yMin) * (PY1 - PY0)

    for g in range(70, 101, 5):
        yy = Y(g)
        s += line(PX0, yy, PX1, yy, GRID, sw=1)
        s += text(PX0 - 12, yy + 4, f"{g}%", size=11, fill=MUTE, anchor="end")
    s += text(PX0 - 12, Y(100) - 16, "% of baseline", size=11, fill=MUTE, anchor="end")

    pts = [(X(i), Y(p)) for i, p in enumerate(pct)]
    s += polygon([(PX0, PY1)] + pts + [(PX1, PY1)], BLUE_AREA, opacity=0.85)
    s += polyline(pts, BLUE, sw=3)
    for i, (x, y) in enumerate(pts):
        s += line(x, PY1, x, PY1 + 5, GRID, sw=1)
        s += text(x, PY1 + 19, str(i + 1), size=10, fill=MUTE, anchor="middle")
        s += circle(x, y, 4, "#FFFFFF", stroke=BLUE, sw=2)
    s += text((PX0 + PX1) / 2, PY1 + 40, "16 accepted edits, applied in order →",
              size=12, fill=MUTE, anchor="middle")

    s += circle(pts[0][0], pts[0][1], 5.5, BLUE)
    s += text(pts[0][0] + 12, pts[0][1] - 10, "100%  (baseline)", size=15, weight="700", fill=INK)
    s += text(pts[0][0] + 12, pts[0][1] - 27, "scan is the bottleneck", size=11, fill=MUTE)
    s += circle(pts[-1][0], pts[-1][1], 5.5, BLUE)
    s += text(pts[-1][0] - 8, pts[-1][1] + 22, "70%", size=16, weight="700", fill=BLUE, anchor="end")

    cx, cy = X(6), Y(pct[6])
    s += line(cx, cy, 470, 268, MUTE, sw=1)
    s += circle(cx, cy, 3.5, BLUE)
    s += mtext(330, 248, ["c0 zero-state", "specializations"], size=12.5, weight="700", fill=BODY, lh=16)
    s += text(330, 286, "state is zero at c_idx = 0", size=11, fill=MUTE)

    cx2, cy2 = X(12), Y(pct[12])
    s += line(cx2, cy2, 815, 332, MUTE, sw=1)
    s += circle(cx2, cy2, 3.5, BLUE)
    s += mtext(690, 312, ["prefetch overlap", "+ exp reuse"], size=12.5, weight="700", fill=BODY, lh=16)

    bx, by = 968, 196
    s += rect(bx, by, 172, 80, "#FFFFFF", rx=12, stroke=BLUE, sw=1.6)
    s += text(bx + 18, by + 46, "−30%", size=34, weight="700", fill=BLUE)
    s += text(bx + 18, by + 67, "scan makespan", size=13, fill=BODY)
    return save("02_scan_optimization.svg", s)


# ====================================================================== #
# 3. ROUND-2 FORWARD-CACHE  (both series as % of their own baseline)
# ====================================================================== #
def fig_forward_cache():
    W, H = 1280, 720
    s = svg_open(W, H)
    s += text(60, 54, "Round 2 — Forward-Cache Contract", size=28, weight="700")
    s += text(60, 84, "Saving forward intermediates shrinks the scan stages  ·  1 core  ·  (B,H,C) = (1,2,2)",
              size=15, fill=MUTE)

    labels = [["split", "baseline"], ["+ v_new", "history"], ["+ k_weighted", "history"],
              ["restored", "2-kernel"], ["+ exp_delta", "history"], ["bf16", "d_score"],
              ["+ L1", "lookahead*"]]
    state   = [80175, 78592, 75513, 74863, 72415, 71474, 71338]
    compose = [208224, 203005, 199926, 199278, 196828, 195929, 195793]
    sp = [v / state[0] * 100 for v in state]
    cp = [v / compose[0] * 100 for v in compose]

    PX0, PX1, PY0, PY1 = 150, 1110, 168, 512
    X = lambda i: PX0 + i * (PX1 - PX0) / (len(state) - 1)
    yMin, yMax = 88, 100
    Y = lambda p: PY1 - (p - yMin) / (yMax - yMin) * (PY1 - PY0)

    for g in range(88, 101, 2):
        yy = Y(g)
        s += line(PX0, yy, PX1, yy, GRID, sw=1)
        s += text(PX0 - 12, yy + 4, f"{g}%", size=11, fill=MUTE, anchor="end")
    s += text(PX0 - 12, PY0 - 30, "% of each series' baseline", size=12, weight="700", fill=BODY, anchor="start")

    # legend (upper-right empty region)
    lgx, lgy = 880, 206
    s += line(lgx, lgy, lgx + 28, lgy, BLUE, sw=3)
    s += circle(lgx + 14, lgy, 4.5, "#FFFFFF", stroke=BLUE, sw=2)
    s += text(lgx + 38, lgy + 4, "scan_state_bwd", size=12.5, weight="700", fill=BLUE)
    s += line(lgx, lgy + 24, lgx + 28, lgy + 24, SLATE, sw=2, dash="6 5")
    s += circle(lgx + 14, lgy + 24, 3.5, SLATE)
    s += text(lgx + 38, lgy + 28, "compose_sum", size=12.5, weight="700", fill=SLATE)

    # compose (secondary, slate dashed)
    cpts = [(X(i), Y(cp[i])) for i in range(len(cp))]
    s += polyline(cpts[:6], SLATE, sw=2, dash="6 5")
    s += polyline(cpts[5:], SLATE, sw=2, dash="2 5")
    for i, (x, y) in enumerate(cpts):
        s += circle(x, y, 3.5, "#FFFFFF" if i == 6 else SLATE, stroke=SLATE, sw=1.5)
    s += text(cpts[5][0], cpts[5][1] - 12, f"{cp[5]:.0f}%", size=11, weight="700", fill=SLATE, anchor="middle")

    # scan_state (primary, blue) + area for kept portion
    spts = [(X(i), Y(sp[i])) for i in range(len(sp))]
    s += polygon([(spts[0][0], PY1)] + spts[:6] + [(spts[5][0], PY1)], BLUE_AREA, opacity=0.45)
    s += polyline(spts[:6], BLUE, sw=3)
    s += polyline(spts[5:], BLUE, sw=2.5, dash="3 5")
    for i, (x, y) in enumerate(spts):
        if i == 6:
            s += circle(x, y, 5, "#FFFFFF", stroke=ORANGE, sw=2)
        else:
            s += circle(x, y, 4.5, "#FFFFFF", stroke=BLUE, sw=2)
        if i != 0:  # index 0 is 100% for both series — the gridline already says so
            s += text(x, y - 12, f"{sp[i]:.0f}%", size=11, weight="700",
                      fill=ORANGE if i == 6 else INK, anchor="middle")

    for i, lab in enumerate(labels):
        for j, ln in enumerate(lab):
            s += text(X(i), PY1 + 28 + j * 15, ln, size=11.5,
                      fill=ORANGE if (i == 6 and j == 0) else BODY, anchor="middle",
                      weight="700" if i == 6 else "normal")

    cs, w1 = chip(150, 600, "scan_state  −11%  (kept)", BLUE)
    s += cs
    cs, w2 = chip(150 + w1 + 14, 600, "compose_sum  −6%", SLATE)
    s += cs
    s += text(60, 660, "* internal L1 lookahead was simulator-correct (a tiny extra gain) but caused hardware "
                       "hangs — rolled back; the forward-cache and bf16 wins were kept.", size=11.5, fill=MUTE)
    return save("03_forward_cache.svg", s)


# ====================================================================== #
# 4. FINAL HARDWARE PROFILE  (% of total runtime)
# ====================================================================== #
def fig_hw():
    W, H = 1280, 720
    s = svg_open(W, H)
    s += text(60, 54, "Where the Runtime Goes — Final Hardware Profile", size=27, weight="700")
    s += text(60, 84, "Each stage's share of total on-board runtime  ·  Ascend 950  ·  (B,H,C) = (1,32,16)  "
                      "·  avg of 100 launches", size=15, fill=MUTE)

    raw = [("scan_state_bwd", 266.23, True), ("wu_bwd", 143.23, False),
           ("finalize_bwd", 138.61, False), ("scan_local_bwd", 88.82, False),
           ("inverse_preprocess_bwd", 52.12, False)]
    total = sum(v for _, v, _ in raw)
    bars = [(name, v / total * 100, hot) for name, v, hot in raw]

    BX0, BX1 = 312, 1120
    maxv = 42.0
    barH, gap, y0 = 56, 36, 158
    W_ = lambda v: (v / maxv) * (BX1 - BX0)
    axis_bottom = y0 + 5 * (barH + gap) - gap

    for t in range(0, 41, 10):
        xx = BX0 + W_(t)
        s += line(xx, y0 - 10, xx, axis_bottom, GRID, sw=1)
        s += text(xx, axis_bottom + 20, f"{t}%", size=11, fill=MUTE, anchor="middle")
    s += text((BX0 + BX1) / 2, axis_bottom + 40, "% of total runtime", size=12, fill=MUTE, anchor="middle")

    for i, (name, v, hot) in enumerate(bars):
        yy = y0 + i * (barH + gap)
        col = ORANGE if hot else BLUE
        s += rect(BX0, yy, BX1 - BX0, barH, TRACK, rx=8)
        s += rect(BX0, yy, W_(v), barH, col, rx=8)
        s += vtext(BX0 - 16, yy + barH / 2, name, size=15, weight="700",
                   fill=INK if hot else BODY, anchor="end")
        s += vtext(BX0 + W_(v) + 14, yy + barH / 2, f"{v:.1f}%", size=15, weight="700", fill=col, anchor="start")
        if hot:
            s += vtext(BX0 + 14, yy + barH / 2, "dominant stage", size=12, fill="#FFFFFF", anchor="start")

    fy = 626
    s += rect(60, fy, 1160, 62, "#F8FAFC", rx=10, stroke=GRID, sw=1)
    s += text(80, fy + 26, "All compose outputs accepted  ·  bad = 0", size=14, weight="700", fill=GREEN)
    s += text(80, fy + 48,
              "max abs error:   d_query 4.0e-06    d_key 5.0e-06    d_value 4.8e-05    "
              "d_beta 2.8e-06    d_g 2.8e-04", size=12.5, fill=BODY)
    return save("04_hw_profile.svg", s)


# ====================================================================== #
# 5. SPLIT-SCAN STATE REBALANCE  (% of baseline)
# ====================================================================== #
def fig_split_scan():
    W, H = 1280, 720
    s = svg_open(W, H)
    s += text(60, 54, "Split Scan — Rebalancing the State Pass", size=28, weight="700")
    s += text(60, 84, "scan_state_bwd simulator makespan, relative to baseline  ·  1 core  ·  (B,H,C) = (1,2,2)",
              size=15, fill=MUTE)

    # Kept (warning-free) path. A manual-event variant reached 80035 cycles but
    # carried a local-memory warning, so the dedicated cv_seed_mutex form (80175)
    # was the one kept. Chart shows % of the lane-imbalanced baseline only.
    vals = [119588, 118329, 112123, 104641, 104034, 103982, 103222, 102654, 80175]
    pct = [v / vals[0] * 100 for v in vals]
    PX0, PX1, PY0, PY1 = 110, 1150, 150, 545
    yMin, yMax = 62, 100
    X = lambda i: PX0 + i * (PX1 - PX0) / (len(vals) - 1)
    Y = lambda p: PY1 - (p - yMin) / (yMax - yMin) * (PY1 - PY0)

    for g in range(65, 101, 5):
        yy = Y(g)
        s += line(PX0, yy, PX1, yy, GRID, sw=1)
        s += text(PX0 - 12, yy + 4, f"{g}%", size=11, fill=MUTE, anchor="end")
    s += text(PX0 - 12, Y(100) - 16, "% of baseline", size=11, fill=MUTE, anchor="end")

    pts = [(X(i), Y(p)) for i, p in enumerate(pct)]
    s += polygon([(PX0, PY1)] + pts + [(PX1, PY1)], BLUE_AREA, opacity=0.85)
    s += polyline(pts, BLUE, sw=3)
    for i, (x, y) in enumerate(pts):
        s += line(x, PY1, x, PY1 + 5, GRID, sw=1)
        s += text(x, PY1 + 19, str(i + 1), size=10, fill=MUTE, anchor="middle")
        s += circle(x, y, 4, "#FFFFFF", stroke=BLUE, sw=2)
    s += text((PX0 + PX1) / 2, PY1 + 40, "9 lane-balance + scratch + sync edits, applied in order →",
              size=12, fill=MUTE, anchor="middle")

    s += circle(pts[0][0], pts[0][1], 5.5, BLUE)
    s += text(pts[0][0] + 12, pts[0][1] - 10, "100%  (baseline)", size=15, weight="700", fill=INK)
    s += text(pts[0][0] + 12, pts[0][1] - 27, "vec0 carries most gate work", size=11, fill=MUTE)
    s += circle(pts[-1][0], pts[-1][1], 5.5, BLUE)
    s += text(pts[-1][0] - 8, pts[-1][1] + 22, "67%", size=16, weight="700", fill=BLUE, anchor="end")

    cx, cy = X(2), Y(pct[2])
    s += line(cx, cy, 470, 250, MUTE, sw=1)
    s += circle(cx, cy, 3.5, BLUE)
    s += mtext(330, 224, ["split gate / d_exp work", "across both vector lanes"],
               size=12.5, weight="700", fill=BODY, lh=16)

    cx2, cy2 = X(8), Y(pct[8])
    s += line(cx2, cy2, 905, 360, MUTE, sw=1)
    s += mtext(726, 338, ["manual vec events +", "cv_seed_mutex (warning-free)"],
               size=12.5, weight="700", fill=BODY, lh=16)
    s += text(726, 390, "a manual-event variant hit 80035 but warned", size=10.5, fill=MUTE)

    bx, by = 966, 184
    s += rect(bx, by, 174, 80, "#FFFFFF", rx=12, stroke=BLUE, sw=1.6)
    s += text(bx + 18, by + 46, "−33%", size=34, weight="700", fill=BLUE)
    s += text(bx + 18, by + 67, "scan_state (1 core)", size=12.5, fill=BODY)
    return save("05_split_scan.svg", s)


# ====================================================================== #
# 6. HARDWARE TRIAGE — INCREMENTAL ONE-OUTPUT REBUILD
# ====================================================================== #
def fig_incremental():
    W, H = 1280, 720
    s = svg_open(W, H)
    s += text(60, 54, "When Hardware Fails — Rebuild One Output at a Time", size=27, weight="700")
    s += text(60, 84, "Act II: patching the fused kernel only moved the failure around — re-growing each "
                      "kernel output-by-output is what passed WebIDE on Ascend 950", size=14.5, fill=MUTE)

    def arrow(x1, x2, y, col=SLATE):
        out = line(x1, y, x2 - 7, y, col, sw=2)
        out += polygon([(x2, y), (x2 - 8, y - 4.5), (x2 - 8, y + 4.5)], col)
        return out

    def pill(x, yc, label, border, fg=INK, fill="#FFFFFF", size=12.5):
        w = len(label) * size * 0.60 + 26
        h = 38
        out = rect(x, yc - h / 2, w, h, fill, rx=10, stroke=border, sw=1.8)
        out += vtext(x + w / 2, yc, label, size=size, weight="700", fill=fg, anchor="middle")
        return out, w

    lanes = [
        ("scan_state_bwd", "HW ✓   then −13%",
         [("d_q_core", BLUE_BORD, INK, "#FFFFFF"),
          ("+d_k_core, d_state", BLUE_BORD, INK, "#FFFFFF"),
          ("+d_g_core", BLUE_BORD, INK, "#FFFFFF"),
          ("+d_value_wu", BLUE_BORD, INK, "#FFFFFF"),
          ("+d_k_cumdecay", BLUE_BORD, INK, "#FFFFFF")], None),
        ("inverse_preprocess_bwd", "HW ✓   L1 DBuff −4%",
         [("d_k_pre", BLUE_BORD, INK, "#FFFFFF"),
          ("+pre pair  ✗", ORANGE, ORANGE, ORANGE_BAND),
          ("d_decay_pre first", BLUE_BORD, INK, "#FFFFFF"),
          ("+d_k_beta_pre", BLUE_BORD, INK, "#FFFFFF"),
          ("+d_k_pre", BLUE_BORD, INK, "#FFFFFF")],
         "publishing d_score to L1 before the d_decay_pre GM store made d_decay_pre "
         "non-finite  →  store decay first"),
        ("finalize_bwd", "HW ✓   rowwise d_g",
         [("d_g  (rowwise VF)", BLUE_BORD, INK, "#FFFFFF"),
          ("+d_value", BLUE_BORD, INK, "#FFFFFF"),
          ("+d_beta", BLUE_BORD, INK, "#FFFFFF"),
          ("restore d_key", BLUE_BORD, INK, "#FFFFFF")],
         "d_g-only failed on HW while d_key / d_value / d_beta were fine; the proven "
         "rowwise scalar/VF d_g path was kept"),
    ]

    laneY = [205, 380, 545]
    px0 = 306
    for li, (kname, outcome, steps, note) in enumerate(lanes):
        yc = laneY[li]
        s += vtext(72, yc - 8, kname, size=14, weight="700", fill=INK)
        s += vtext(72, yc + 12, "rebuilt clean", size=11.5, fill=MUTE)
        x = px0
        prev_right = None
        for (label, border, fg, fill) in steps:
            if prev_right is not None:
                s += arrow(prev_right, x, yc)
            ps, w = pill(x, yc, label, border, fg=fg, fill=fill)
            s += ps
            prev_right = x + w
            x = x + w + 34
        s += arrow(prev_right, x, yc, col=GREEN)
        cs, _ = chip(x, yc - 10, outcome, GREEN)
        s += cs
        if note:
            s += text(px0, yc + 36, note, size=11, fill=MUTE)

    fy = 636
    s += rect(60, fy, 1160, 54, BLUE_BAND, rx=10, stroke=BLUE_BORD, sw=1)
    s += text(80, fy + 33, "A one-output kernel that passes beats a fused kernel that almost works — "
                           "each green check is a hardware-verified checkpoint to build on.",
              size=13, weight="700", fill=INK)
    return save("06_incremental_rebuild.svg", s)


if __name__ == "__main__":
    for p in (fig_timeline(), fig_scan(), fig_forward_cache(), fig_hw(),
              fig_split_scan(), fig_incremental()):
        print("wrote", p)
