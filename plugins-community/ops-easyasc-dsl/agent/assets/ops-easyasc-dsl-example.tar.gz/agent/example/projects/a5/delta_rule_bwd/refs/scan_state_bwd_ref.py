"""Pure PyTorch reference for the split scan state stage (ungated)."""

from common import make_inputs, scan_local_bwd, scan_state_bwd


def subkernel(query, key, grad_output, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, d_v_attn_tmp):
    return scan_state_bwd(
        query, key, grad_output, k_cumdecay, state_after_history,
        grad_final_state, d_score_tmp, v_new_history, d_v_attn_tmp,
    )


if __name__ == "__main__":
    args = make_inputs()
    d_score_tmp, d_v_attn_tmp = scan_local_bwd(args[0], args[1], args[4], args[9])
    result = subkernel(args[0], args[1], args[4], args[7], args[8], args[10], d_score_tmp, args[9], d_v_attn_tmp)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
