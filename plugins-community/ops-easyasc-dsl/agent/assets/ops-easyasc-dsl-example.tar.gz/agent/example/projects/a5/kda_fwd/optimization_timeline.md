# KDA Forward Timeline

Project-local optimization and implementation rationale for the authored A5
KDA forward kernels. Read this after `refs/plan.md` when you need to understand
why the current kernels have their shape.

## Current Authored Path

- Kernels live in `projects/a5/kda_fwd/kernels/` and are specialized to
  `L=64`, `K=V=128`, bf16 q/k/v intermediates, and fp32 gate/state math.
- Default simulator smoke CLIs use the smaller common shape
  `B=1,H=HV=C=8,L=64,K=V=128` so local traced runs are balanced and finish
  under the default timeout.
- Hardware-profile CLIs keep the target benchmark shape
  `B=1,H=HV=32,C=16,L=64,K=V=128` where the subkernel consumes `V`.
- Active subkernel simulator timeout defaults are standardized at `300s`; the
  full target-shape fused-tail simulator smoke can exceed this when tracing is
  enabled, so use smaller default smokes locally, opt into trace generation with
  `--trace`, and use hardware-profile runs for target-shape timing.
- Active subkernel CLIs consistently expose `--core-count` for non-hardware
  simulator smoke runs, which keeps uneven-work-distribution checks easy to
  reproduce without editing the files.
- The production composition uses `sub45_fused.py` for the recurrent state
  bridge plus final output assembly. Standalone `sub4_state.py` and
  `sub5_output.py` kernel modules are no longer kept.
- The PyTorch refs mirror the four authored units (`sub1_gate`, `sub2_intra`,
  `sub3_wy`, `sub45_fused`). The former split `sub4_state_ref.py` /
  `sub5_output_ref.py` are folded into the self-contained `sub45_fused_ref.py`,
  which keeps `h` and `v_new` internal and exposes only `o` and `final_state`.

## Promoted Optimizations

- `sub1_gate` publishes the linear cumulative gate `exp(cumsum(g_raw))`; all
  downstream stages consume that materialized factor directly.
- `sub2_intra` uses cube score formation plus the existing A5 strict-lower
  inverse kernel. Its score stage prepares `q*g*scale`, `-k*g*beta`, and `k/g`,
  computes dense score matrices with `splitk=64`, then applies the lower and
  strict-lower masks in one merged post VF guarded by a single `score_cvmutex`.
  This merged-mask path was promoted after real hardware improved around
  `50 us -> 49 us`.
- `sub3_wy` materializes `A_beta = bf16(Akk * beta_col)` and
  `k_exp = bf16(k * g)`, then computes `w = A_beta @ k_exp` and
  `u = A_beta @ v`. `qg = q * g` is emitted as a backward-facing saved
  intermediate, matching upstream FLA's saved `qg = q * exp2(gk)` after mapping
  their log2 gate to this plan's linear gate. The beta-fold path was promoted
  after hardware profiling at `B=1,H=HV=32,C=16` moved the subkernel from
  roughly `49 us` to `32.1-32.3 us`. The full `v` tile is loaded directly from
  GM to L1; avoid restoring the old `v -> UB -> L1` relay.
- `sub45_fused.py` fuses the former sub4 state update with sub5 output
  assembly, returns only `o` and `final_state`, and keeps `h` and `v_new` on
  chip. It distributes work by complete `(B, HV)` value-tile pairs rather than
  raw V-tile work ids, so shared `qg/Aqk` staging cannot straddle two different
  heads on awkward core counts.

## Archived Outcomes

- The `sub3_wy` g-last-hoist experiment was neutral/slightly worse; beta reload
  and loop-order cost outweighed saved `g_last` UB reads.
- The `sub4_state` fused recurrent-update experiments regressed because the old
  split decay was mostly hidden under cube work, while the fused update moved
  more V work onto the post-delta path. Do not promote a fused
  `state = state * g_last + delta` update without fresh evidence.
- The `sub2_intra` post-factor-fold experiment regressed on hardware
  (`~56 us -> ~58 us`) because it moved scale/beta work from hideable
  preprocess V calls into the post-FIX/post-mask tail.

## Fused Tail Evidence

- Target-shape simulator check `B=1,H=HV=32,C=16,L=64,K=V=128` passed against
  the fused ref contract: `o max_abs=7.629395e-06`,
  `final_state max_abs=2.783164e-05`.
- A 28-core simulator check at `B=1,H=HV=32,C=2,L=64,K=V=128` passed after the
  pair-partition change: `o max_abs=7.629395e-06`,
  `final_state max_abs=2.844189e-05`.
- Trace result at the target shape: fused makespan `90026` cycles versus the
  previously measured separate-tail total `83454 + 45464 = 128918` cycles,
  suggesting about `30%` simulator saving for the combined sub4+sub5 region.
- The bottleneck shifted from standalone sub5 `cube.MTE2` (`94.7%`
  active/makespan) to fused `vec V` (`93.9%` active/makespan). The fusion
  removes the `h` and `v_new` GM roundtrip but adds qg VF work inside the state
  schedule.
