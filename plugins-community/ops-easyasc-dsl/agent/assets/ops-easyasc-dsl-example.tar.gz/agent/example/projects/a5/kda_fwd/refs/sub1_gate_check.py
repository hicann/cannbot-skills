"""Local randomized check for sub1_gate_ref.py."""

import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from sub1_gate_ref import subkernel  # noqa: E402


ATOL = 0.0
RTOL = 0.0


def expected(g_raw):
    return torch.exp(torch.cumsum(g_raw.float(), dim=-2))


def sample_inputs():
    torch.manual_seed(11)
    g_raw = -torch.rand(2, 3, 2, 32, 32).mul(0.03)
    return (g_raw,)


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return (value,)


def main():
    inputs = sample_inputs()
    actual = _as_tuple(subkernel(*inputs))
    expected_items = _as_tuple(expected(*inputs))
    if len(actual) != len(expected_items):
        raise AssertionError(f"arity mismatch: actual={len(actual)} expected={len(expected_items)}")
    for idx, (act, exp) in enumerate(zip(actual, expected_items)):
        if not torch.isfinite(act).all() or not torch.isfinite(exp).all():
            raise AssertionError(f"non-finite output at index {idx}")
        torch.testing.assert_close(act.float(), exp.float(), atol=ATOL, rtol=RTOL)
    print("sub1_gate: OK")


if __name__ == "__main__":
    main()
