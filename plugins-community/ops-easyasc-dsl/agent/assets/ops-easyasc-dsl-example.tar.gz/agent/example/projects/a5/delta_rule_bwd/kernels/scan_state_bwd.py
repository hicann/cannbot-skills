"""scan_state_bwd (ungated): BH-parallel reverse-C state recurrence for delta_rule backward.

Ungated port of `gdn_bwd/kernels/scan_state_bwd.py`. With g == 0 the entire gate
apparatus vanishes:
  * `make_q_exp` (q_exp = q*exp(g)) -> use raw `query` (q_exp == q);
  * `exp_delta`/`k_weighted_history` (k_weighted = k*exp(g_last-g)) -> use raw `key`;
  * the recurrent-state decay `S*exp(g_last)` -> plain `d_state_next = seed + old`;
  * the whole cross-sub-block `d_g` reduction (accum_state_dot / accum_dq_g /
    finish_g / d_g_core) and its events -> deleted (gate gradient only);
  * the gated post-VFs (`add_scaled`, `postprocess_dk`) -> plain row adds.

Dropped inputs vs gdn: `g_cumsum`, `k_weighted_history`, `exp_delta_history`.
Dropped output: `d_g_core`. Kept the matmul sequence and the
cvmutex/cv_seed_mutex/dvprime_mutex/dstate_mutex choreography + the [D,D] d_state
carry (UB DBuff ping-pong staged to L1 each chunk).

Per reverse chunk c (state = 0 at c==0, else state_after_history[c-1]):
  d_k_from_state = v_new @ d_state^T            (term)
  d_q_inter      = grad_output @ state^T        (== 0 at c==0)
  d_state_q      = q^T @ grad_output            ([D,D])
  d_v_state      = key @ d_state
  d_v_new        = d_v_attn + d_v_state ; d_value_wu = d_v_new ; d_v_prime = -d_v_new
  d_k_cumdecay   = d_v_prime @ state^T          (== 0 at c==0)
  d_state_k      = k_cumdecay^T @ d_v_prime     (accumulated into d_state_q)
  d_q_core = (d_score @ key) + d_q_inter
  d_k_core = (d_score^T @ q) + d_k_from_state
  d_state(next) = d_state_q + d_state_k + d_state
"""
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0

L = 64
D = 128
HALF_L = L // 2
HALF_D = D // 2
REGS_D = D // 64
BF16_C0 = 16

SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],   # query
    1: [0, 1, 2, None, None],   # key
    2: [0, 1, 2, None, None],   # grad_output
    3: [0, 1, 2, None, None],   # k_cumdecay
    4: [0, 1, 2, None, None],   # state_after_history [B,H,C,D,D]
    5: [0, 1, None, None],      # grad_final_state [B,H,D,D]
    6: [0, 1, 2, None, None],   # d_score_tmp [B,H,C,L,L]
    7: [0, 1, 2, None, None],   # v_new_history
    8: [0, 1, 2, None, None],   # d_v_attn_tmp
    9: [0, 1, 2, None, None],   # d_q_core
    10: [0, 1, 2, None, None],  # d_k_core
    11: [0, 1, 2, None, None],  # d_value_wu
    12: [0, 1, 2, None, None],  # d_k_cumdecay
}


@vf()
def cast_d_rows_float_to_bf16_nz_vf(src_ub: Tensor, dst_nz_ub: Tensor, rows: Var):
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(rows):
        row_lo <<= src_ub[r:r + 1, 0:64]
        row_hi <<= src_ub[r:r + 1, 64:D]
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def add_d_rows_vf(a_ub: Tensor, b_ub: Tensor, out_ub: Tensor, rows: Var):
    """out = a + b over [rows, D] (ungated collapse of add_scaled / postprocess_dk)."""
    a_regs = RegList(DT.float, REGS_D)
    b_regs = RegList(DT.float, REGS_D)
    for r in range(rows):
        a_regs <<= a_ub[r:r + 1, 0:D]
        b_regs <<= b_ub[r:r + 1, 0:D]
        a_regs <<= a_regs + b_regs
        out_ub[r:r + 1, 0:D] <<= a_regs
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def add_cast_d_rows_bf16_vf(dep_ub: Tensor, base_ub: Tensor, out_bf16_ub: Tensor, rows: Var):
    dep_lo = Reg(DT.float)
    dep_hi = Reg(DT.float)
    base_lo = Reg(DT.float)
    base_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(rows):
        dep_lo <<= dep_ub[r:r + 1, 0:64]
        dep_hi <<= dep_ub[r:r + 1, 64:D]
        base_lo <<= base_ub[r:r + 1, 0:64]
        base_hi <<= base_ub[r:r + 1, 64:D]
        base_lo <<= base_lo + dep_lo
        base_hi <<= base_hi + dep_hi
        lo_bf16 <<= base_lo.astype(DT.bfloat16)
        hi_bf16 <<= base_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(out_bf16_ub[r:r + 1, 0:D], row_bf16)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def add_negate_cast_d_rows_bf16_vf(dep_ub: Tensor, base_ub: Tensor, sum_bf16_ub: Tensor, neg_ub: Tensor, neg_nz_ub: Tensor, rows: Var):
    dep_lo = Reg(DT.float)
    dep_hi = Reg(DT.float)
    base_lo = Reg(DT.float)
    base_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(rows):
        dep_lo <<= dep_ub[r:r + 1, 0:64]
        dep_hi <<= dep_ub[r:r + 1, 64:D]
        base_lo <<= base_ub[r:r + 1, 0:64]
        base_hi <<= base_ub[r:r + 1, 64:D]
        base_lo <<= base_lo + dep_lo
        base_hi <<= base_hi + dep_hi
        lo_bf16 <<= base_lo.astype(DT.bfloat16)
        hi_bf16 <<= base_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(sum_bf16_ub[r:r + 1, 0:D], row_bf16)
        base_lo <<= base_lo * -1.0
        base_hi <<= base_hi * -1.0
        neg_ub[r:r + 1, 0:64] <<= base_lo
        neg_ub[r:r + 1, 64:D] <<= base_hi
        lo_bf16 <<= base_lo.astype(DT.bfloat16)
        hi_bf16 <<= base_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(neg_nz_ub[r * BF16_C0], row_bf16, rows)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def zero_d_rows_bf16_vf(dst_ub: Tensor, rows: Var):
    zero_lo = Reg(DT.bfloat16)
    zero_hi = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    zero_lo <<= 0.0
    zero_hi <<= 0.0
    for r in range(rows):
        deinterleave(row_bf16, dummy_bf16, zero_lo, zero_hi)
        reg_to_ub(dst_ub[r:r + 1, 0:D], row_bf16)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def update_d_state_add_cast_nz_vf(seed_ub: Tensor, old_d_state_ub: Tensor, out_ub: Tensor, dst_nz_ub: Tensor):
    """d_state_next = seed + old (no exp(g_last) decay), staged fp32 + bf16 NZ."""
    seed_lo = Reg(DT.float)
    seed_hi = Reg(DT.float)
    old_lo = Reg(DT.float)
    old_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    for r in range(HALF_D):
        seed_lo <<= seed_ub[r:r + 1, 0:64]
        seed_hi <<= seed_ub[r:r + 1, 64:D]
        old_lo <<= old_d_state_ub[r:r + 1, 0:64]
        old_hi <<= old_d_state_ub[r:r + 1, 64:D]
        seed_lo <<= seed_lo + old_lo
        seed_hi <<= seed_hi + old_hi
        out_ub[r:r + 1, 0:64] <<= seed_lo
        out_ub[r:r + 1, 64:D] <<= seed_hi
        lo_bf16 <<= seed_lo.astype(DT.bfloat16)
        hi_bf16 <<= seed_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, L)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def scan_state_bwd_kernel(
    query: GMTensor,
    key: GMTensor,
    grad_output: GMTensor,
    k_cumdecay: GMTensor,
    state_after_history: GMTensor,
    grad_final_state: GMTensor,
    d_score_tmp: GMTensor,
    v_new_history: GMTensor,
    d_v_attn_tmp: GMTensor,
    d_q_core: GMTensor,
    d_k_core: GMTensor,
    d_value_wu: GMTensor,
    d_k_cumdecay: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    cvmutex = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    cv_seed_mutex = CvMutex(1, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    dvprime_mutex = VcMutex(2, depth=1, src_start_pipe=Pipe.MTE3, src_end_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1, dst_end_pipe=Pipe.MTE1)
    dstate_mutex = VcMutex(3, depth=1, src_start_pipe=Pipe.MTE3, src_end_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1, dst_end_pipe=Pipe.MTE1)
    dkcum_zero_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dst_dkcum_zero_out_ready")
    dvalue_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dst_dvalue_out_ready")
    dq_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dst_dq_out_ready")
    dk_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dst_dk_out_ready")
    dvat_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dst_dvat_in_ready")
    dvprime_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dst_dvprime_out_ready")
    dstate_in_ready = SEvent(Pipe.MTE2, Pipe.V, name="dst_dstate_in_ready")
    dstate_out_ready = SEvent(Pipe.V, Pipe.MTE3, name="dst_dstate_out_ready")

    l1_q = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_k = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_d_out = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_kcd = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_state = Tensor(DT.bfloat16, [D, D], Position.L1)
    l1_d_state = Tensor(DT.bfloat16, [D, D], Position.L1)
    l1_v_new = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_d_score = Tensor(DT.bfloat16, [L, L], Position.L1)
    l1_d_v_prime = Tensor(DT.bfloat16, [L, D], Position.L1)

    l0c_ld0 = Tensor(DT.float, [L, D], Position.L0C)
    l0c_ld1 = Tensor(DT.float, [L, D], Position.L0C)
    l0c_dd = Tensor(DT.float, [D, D], Position.L0C)

    bf16_full_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    bf16_alt_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    score_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    term_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    out_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    tmp_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    dk_scratch_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    # Single in-place fp32 d_state carry. The recurrence is serialized by the
    # per-chunk bar_all(), so a 2-slot ping-pong buys no overlap; a DBuff whose
    # slot is selected by a loop-incremented Var view created *before* the
    # rev_c loop drifts after the first update (wrong d_state for C>=3). Plain
    # in-place add is correct (update reads row r before writing row r).
    ub_d_state = Tensor(DT.float, [HALF_D, D], Position.UB)
    ub_d_state_seed = Tensor(DT.float, [HALF_D, D], Position.UB)

    bh_count = B * H
    bh_per_core = CeilDiv(bh_count, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, bh_count)

    for bh in range(bh_begin, bh_end):
        b_idx = Var(bh // H)
        h_idx = Var(bh % H)
        row_begin_l = Var(GetSubBlockIdx() * HALF_L)
        row_end_l = Var(row_begin_l + HALF_L)
        rows_l = Var(HALF_L)
        row_begin_d = Var(GetSubBlockIdx() * HALF_D)
        row_end_d = Var(row_begin_d + HALF_D)

        dstate_cur = ub_d_state
        dstate_cur[0:HALF_D, 0:D] <<= grad_final_state[b_idx, h_idx, row_begin_d:row_end_d, 0:D]
        dstate_in_ready.set()
        dstate_in_ready.wait()
        dstate_mutex.lock()
        cast_d_rows_float_to_bf16_nz_vf(dstate_cur[0:HALF_D, 0:D], bf16_full_ub, L)
        dstate_out_ready.set()
        dstate_out_ready.wait()
        l1_d_state[row_begin_d:row_end_d, 0:D] <<= bf16_full_ub[0:L, 0:D].nz()
        bar_all()
        dstate_mutex.ready()
        dstate_mutex.wait()

        for rev_c in range(C):
            c_idx = Var(C - 1 - rev_c)
            c_prev = Var(c_idx - 1)

            with auto_sync():
                l1_q[0:L, 0:D] <<= query[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_k[0:L, 0:D] <<= key[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_v_new[0:L, 0:D] <<= v_new_history[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_d_score[0:L, 0:L] <<= d_score_tmp[b_idx, h_idx, c_idx, 0:L, 0:L]
                matmul(l0c_ld1, l1_v_new, l1_d_state, m=L, n=D, k=D, splitn=HALF_D)
                cvmutex.lock()
                term_ub <<= l0c_ld1
                cvmutex.ready()
            cvmutex.wait()
            cvmutex.free()

            if c_idx == 0:
                zero_d_rows_bf16_vf(bf16_alt_ub, rows_l)
                dkcum_zero_out_ready.set()
                dkcum_zero_out_ready.wait()
                d_k_cumdecay[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= bf16_alt_ub[0:rows_l, 0:D]

                with auto_sync():
                    matmul(l0c_ld0, l1_d_score, l1_k.T, m=L, n=D, k=L, splitn=D)
                    d_q_core[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_ld0

                with auto_sync():
                    matmul(l0c_ld0, l1_d_score.T, l1_q.T, m=L, n=D, k=L, splitn=D)
                    cvmutex.lock()
                    score_ub <<= l0c_ld0
                    cvmutex.ready()
                cvmutex.wait()
                add_d_rows_vf(score_ub, term_ub, dk_scratch_ub, rows_l)
                dk_out_ready.set()
                dk_out_ready.wait()
                d_k_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= dk_scratch_ub[0:rows_l, 0:D]
                cvmutex.free()

                with auto_sync():
                    matmul(l0c_ld0, l1_k, l1_d_state.T, m=L, n=D, k=D, splitn=HALF_D)
                    cvmutex.lock()
                    score_ub <<= l0c_ld0
                    cvmutex.ready()
                tmp_ub[0:rows_l, 0:D] <<= d_v_attn_tmp[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D]
                dvat_in_ready.set()
                cvmutex.wait()
                cvmutex.free()
                dvat_in_ready.wait()
                add_cast_d_rows_bf16_vf(score_ub, tmp_ub, bf16_alt_ub, rows_l)
                dvalue_out_ready.set()
                dvalue_out_ready.wait()
                d_value_wu[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= bf16_alt_ub[0:rows_l, 0:D]
            else:
                with auto_sync():
                    l1_d_out[0:L, 0:D] <<= grad_output[b_idx, h_idx, c_idx, 0:L, 0:D]
                    l1_kcd[0:L, 0:D] <<= k_cumdecay[b_idx, h_idx, c_idx, 0:L, 0:D]
                    l1_state[0:D, 0:D] <<= state_after_history[b_idx, h_idx, c_prev, 0:D, 0:D]
                    matmul(l0c_ld0, l1_d_out, l1_state, m=L, n=D, k=D, splitn=HALF_D)
                    cvmutex.lock()
                    score_ub <<= l0c_ld0
                    cvmutex.ready()
                with auto_sync():
                    matmul(l0c_dd, l1_q.T, l1_d_out.T, m=D, n=D, k=L, splitn=D)
                cvmutex.wait()
                cvmutex.free()

                with auto_sync():
                    matmul(l0c_ld0, l1_k, l1_d_state.T, m=L, n=D, k=D, splitn=HALF_D)
                    cvmutex.lock()
                    out_ub <<= l0c_ld0
                    cvmutex.ready()
                tmp_ub[0:rows_l, 0:D] <<= d_v_attn_tmp[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D]
                dvat_in_ready.set()
                cvmutex.wait()
                cvmutex.free()
                dvat_in_ready.wait()
                add_negate_cast_d_rows_bf16_vf(out_ub, tmp_ub, bf16_alt_ub, ub_d_state_seed, bf16_full_ub, rows_l)
                dvalue_out_ready.set()
                dvalue_out_ready.wait()
                d_value_wu[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= bf16_alt_ub[0:rows_l, 0:D]

                dvprime_mutex.lock()
                dvprime_out_ready.set()
                dvprime_out_ready.wait()
                l1_d_v_prime[row_begin_l:row_end_l, 0:D] <<= bf16_full_ub[0:rows_l, 0:D].nz()
                dvprime_mutex.ready()
                dvprime_mutex.wait()
                bar_all()

                with auto_sync():
                    matmul(l0c_ld0, l1_d_v_prime, l1_state, m=L, n=D, k=D, splitn=HALF_D)
                    d_k_cumdecay[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_ld0
                    matmul(l0c_dd, l1_kcd.T, l1_d_v_prime.T, m=D, n=D, k=L, splitn=D, is_init=False)
                    cv_seed_mutex.lock()
                    l0c_to_ub(ub_d_state_seed, l0c_dd, M=D, N=D, N_dst=D, M_src=D, dual_mode=DualMode.SPLITM, sub_block_id=0)
                    cv_seed_mutex.ready()
                dvprime_mutex.free()

                with auto_sync():
                    matmul(l0c_ld0, l1_d_score, l1_k.T, m=L, n=D, k=L, splitn=D)
                    cvmutex.lock()
                    out_ub <<= l0c_ld0
                    cvmutex.ready()
                cvmutex.wait()
                add_d_rows_vf(out_ub, score_ub, out_ub, rows_l)
                dq_out_ready.set()
                dq_out_ready.wait()
                d_q_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= out_ub[0:rows_l, 0:D]
                cvmutex.free()

                with auto_sync():
                    matmul(l0c_ld0, l1_d_score.T, l1_q.T, m=L, n=D, k=L, splitn=D)
                    cvmutex.lock()
                    score_ub <<= l0c_ld0
                    cvmutex.ready()
                cvmutex.wait()
                add_d_rows_vf(score_ub, term_ub, dk_scratch_ub, rows_l)
                dk_out_ready.set()
                dk_out_ready.wait()
                d_k_core[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= dk_scratch_ub[0:rows_l, 0:D]
                cvmutex.free()

            if c_idx != 0:
                dstate_mutex.free()
                cv_seed_mutex.wait()
                dstate_next = ub_d_state
                update_d_state_add_cast_nz_vf(ub_d_state_seed, dstate_cur, dstate_next, bf16_full_ub)
                cv_seed_mutex.free()
                dstate_mutex.lock()
                dstate_out_ready.set()
                dstate_out_ready.wait()
                l1_d_state[row_begin_d:row_end_d, 0:D] <<= bf16_full_ub[0:L, 0:D].nz()
                bar_all()
                dstate_mutex.ready()
                dstate_mutex.wait()

        dstate_mutex.free()

    bar_all()
    return d_q_core, d_k_core, d_value_wu, d_k_cumdecay


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "delta_rule_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(query, key, grad_output, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, d_v_attn_tmp, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    B = int(key.shape[0])
    H = int(key.shape[1])
    C = int(key.shape[2])
    outputs = (
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=key.device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=key.device),
        torch.empty((B, H, C, L, D), dtype=torch.bfloat16, device=key.device),
        torch.empty((B, H, C, L, D), dtype=torch.bfloat16, device=key.device),
    )
    trace_path = _trace_path(trace, out_dir, "scan_state_bwd")

    saved_sim_config = getattr(scan_state_bwd_kernel, "_simulator_config", None)
    if simulator:
        scan_state_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=trace_path is not None,
        )
    try:
        result = OpExec(
            scan_state_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            query, key, grad_output, k_cumdecay, state_after_history, grad_final_state,
            d_score_tmp, v_new_history, d_v_attn_tmp,
            outputs[0], outputs[1], outputs[2], outputs[3], B, H, C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr(scan_state_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                scan_state_bwd_kernel._simulator_config = saved_sim_config
    return result


if __name__ == "__main__":
    import sys
    from pathlib import Path

    _ROOT = Path(__file__).resolve().parents[4]
    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
    _REFS = Path(__file__).resolve().parents[1] / "refs"
    if str(_REFS) not in sys.path:
        sys.path.insert(0, str(_REFS))
    from common import make_inputs, scan_local_bwd as ref_scan_local, scan_state_bwd as ref_scan_state

    torch.manual_seed(42)
    B, H, C = 1, 1, int(os.environ.get("C_SIZE", "2"))
    full = make_inputs(B, H, C)
    query, key, grad_output = full[0], full[1], full[4]
    k_cumdecay, state_after_history, v_new_history, grad_final_state = full[7], full[8], full[9], full[10]
    d_score_tmp, d_v_attn_tmp = ref_scan_local(query, key, grad_output, v_new_history)
    refs = ref_scan_state(query, key, grad_output, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, d_v_attn_tmp)

    got = run(query, key, grad_output, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, d_v_attn_tmp)
    names = ("d_q_core", "d_k_core", "d_value_wu", "d_k_cumdecay")
    for name, g, r in zip(names, got, refs):
        err = (g.float() - r.float()).abs().max().item()
        print(f"scan_state_bwd {name}: max_abs={err:.6e}")
        torch.testing.assert_close(g.float(), r.float(), rtol=2e-3, atol=2e-3)
    print("scan_state_bwd OK")
