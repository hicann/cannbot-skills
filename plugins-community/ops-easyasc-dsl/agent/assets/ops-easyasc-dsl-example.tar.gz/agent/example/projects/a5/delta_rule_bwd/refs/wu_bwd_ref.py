"""Pure PyTorch reference for the WY-representation backward stage (ungated)."""

from common import core_scan_bwd, make_inputs, wu_recompute_bwd


def subkernel(key, value, beta, wu_attn_bf16, d_value_wu, d_k_cumdecay):
    return wu_recompute_bwd(key, value, beta, wu_attn_bf16, d_value_wu, d_k_cumdecay)


if __name__ == "__main__":
    args = make_inputs()
    scan = core_scan_bwd(args[0], args[1], args[4], args[7], args[8], args[9], args[10])
    result = subkernel(args[1], args[2], args[3], args[5], scan[2], scan[3])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
