"""Pure PyTorch composition check for canonical delta_rule_bwd."""

import torch

from common import ATOL, RTOL, compare_tuple, make_inputs
from finalize_bwd_ref import subkernel as finalize_bwd
from inverse_preprocess_bwd_ref import subkernel as inverse_preprocess_bwd
from oracle import oracle
from scan_split_bwd_ref import subkernel as scan_bwd
from wu_bwd_ref import subkernel as wu_bwd


def composed(query, key, value, beta, grad_output, wu_attn_bf16, value_wu, k_cumdecay, state_after_history, v_new_history, grad_final_state):
    scan = scan_bwd(query, key, grad_output, k_cumdecay, state_after_history, v_new_history, grad_final_state)
    wu = wu_bwd(key, value, beta, wu_attn_bf16, scan[2], scan[3])
    inv = inverse_preprocess_bwd(key, beta, wu_attn_bf16, wu[0])
    return finalize_bwd(key, value, beta, scan[0], scan[1], wu[1], wu[2], inv[0], inv[1])


def main():
    for seed, shape in ((101, (1, 2, 2)), (103, (2, 1, 3))):
        torch.manual_seed(seed)
        inputs = make_inputs(*shape)
        actual = composed(*inputs)
        expected = oracle(*inputs)
        compare_tuple(actual, expected, ATOL, RTOL)
        print(f"compose delta_rule_bwd shape={shape}: OK")


if __name__ == "__main__":
    main()
