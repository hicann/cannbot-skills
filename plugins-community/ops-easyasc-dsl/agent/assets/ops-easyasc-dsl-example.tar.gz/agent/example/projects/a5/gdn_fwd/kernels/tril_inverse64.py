import builtins

import torch


from easyasc.a5 import *


SIZE = 64
BLOCK = 16
NUM_BLOCKS = SIZE // BLOCK
KERNEL_DTYPE = torch.float32
SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
}


def _block(mat: torch.Tensor, row: int, col: int, block: int = BLOCK) -> torch.Tensor:
    r0 = row * block
    c0 = col * block
    return mat[..., r0:r0 + block, c0:c0 + block]


def block_inverse_i_minus_a(mat: torch.Tensor, block: int = BLOCK) -> torch.Tensor:
    """Invert a 64x64 unit lower-triangular matrix with 16x16 blocks.

    The input is expected to be I - A, where A is strictly lower triangular.
    Batched leading dimensions are supported.
    """
    if mat.shape[-2:] != (SIZE, SIZE):
        raise ValueError(f"expected last two dimensions to be {(SIZE, SIZE)}, got {mat.shape[-2:]}")
    if SIZE % block != 0:
        raise ValueError(f"block size {block} must divide matrix size {SIZE}")
    num_blocks = SIZE // block

    eye = torch.eye(block, dtype=mat.dtype, device=mat.device)
    eye = eye.expand(mat.shape[:-2] + (block, block))
    zero = torch.zeros_like(_block(mat, 0, 0, block))

    inv_blocks = [[zero.clone() for _ in builtins.range(num_blocks)] for _ in builtins.range(num_blocks)]
    diag_inv = []
    for i in builtins.range(num_blocks):
        inv_diag = torch.linalg.solve_triangular(_block(mat, i, i, block), eye, upper=False)
        diag_inv.append(inv_diag)
        inv_blocks[i][i] = inv_diag

    for i in builtins.range(num_blocks):
        for j in builtins.range(0, i):
            acc = torch.zeros_like(zero)
            for k in builtins.range(j, i):
                a_ik = -_block(mat, i, k, block)
                acc = acc + a_ik @ inv_blocks[k][j]
            inv_blocks[i][j] = diag_inv[i] @ acc

    rows = [torch.cat(inv_blocks[i], dim=-1) for i in builtins.range(num_blocks)]
    return torch.cat(rows, dim=-2)


def inverse_from_strict_lower_a(a: torch.Tensor) -> torch.Tensor:
    """Build I - A from a strict lower-triangular A and invert it by blocks."""
    if a.shape[-2:] != (SIZE, SIZE):
        raise ValueError(f"expected last two dimensions to be {(SIZE, SIZE)}, got {a.shape[-2:]}")

    eye = torch.eye(SIZE, dtype=a.dtype, device=a.device)
    mat = eye.expand(a.shape[:-2] + (SIZE, SIZE)) - torch.tril(a, diagonal=-1)
    return block_inverse_i_minus_a(mat)


@func()
def _init_zero_tile(tile_ub: Tensor, zero: Reg, row_mask: MaskReg):
    for r in range(0, BLOCK):
        reg_to_ub(tile_ub[r:r + 1, 0:BLOCK], zero, mask=row_mask)


@func()
def _init_diag_seed_row(diag_ub: Tensor, zero: Reg, one: Reg, row_mask: MaskReg):
    reg_to_ub(diag_ub[0:1, 0:BLOCK], zero, mask=row_mask)
    vf_barrier(VfPipe.STORE, VfPipe.STORE)
    diag_ub[0:1, 0:1] <<= one.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@func()
def _negate_tile(tile_ub: Tensor, row_mask: MaskReg, row_reg: Reg):
    for r in range(0, BLOCK):
        ub_to_reg(row_reg, tile_ub[r:r + 1, 0:BLOCK], mask=row_mask)
        row_reg <<= row_reg * -1.0
        reg_to_ub(tile_ub[r:r + 1, 0:BLOCK], row_reg, mask=row_mask)
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@func()
def _invert_diag_tile(
    src_ub: Tensor,
    diag_ub: Tensor,
    row_mask: MaskReg,
    one: Reg,
    acc: Reg,
    a_val: Reg,
    prev_row: Reg,
    prod: Reg,
):
    for i in range(1, BLOCK):
        acc.fill(0.0)
        for k in range(0, i):
            a_val <<= src_ub[i:i + 1, k:k + 1].single()
            a_val <<= a_val * -1.0
            ub_to_reg(prev_row, diag_ub[k:k + 1, 0:BLOCK], mask=row_mask)
            prod <<= prev_row * a_val
            acc <<= acc + prod
        reg_to_ub(diag_ub[i:i + 1, 0:BLOCK], acc, mask=row_mask)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        diag_ub[i:i + 1, i:i + 1] <<= one.single_value()
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@func()
def _invert_diag_tile_from_strict_a(
    src_ub: Tensor,
    diag_ub: Tensor,
    row_mask: MaskReg,
    one: Reg,
    acc: Reg,
    a_val: Reg,
    prev_row: Reg,
    prod: Reg,
):
    for i in range(1, BLOCK):
        acc.fill(0.0)
        for k in range(0, i):
            a_val <<= src_ub[i:i + 1, k:k + 1].single()
            ub_to_reg(prev_row, diag_ub[k:k + 1, 0:BLOCK], mask=row_mask)
            prod <<= prev_row * a_val
            acc <<= acc + prod
        reg_to_ub(diag_ub[i:i + 1, 0:BLOCK], acc, mask=row_mask)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        diag_ub[i:i + 1, i:i + 1] <<= one.single_value()
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def tril_inverse_block64_d0_vf(d0_src_ub: Tensor, zero16_ub: Tensor, d0_ub: Tensor):
    zero = Reg(DT.float)
    one = Reg(DT.float)
    acc = Reg(DT.float)
    a_val = Reg(DT.float)
    prev_row = Reg(DT.float)
    prod = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)

    zero.fill(0.0)
    one.fill(1.0)

    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    _init_zero_tile(zero16_ub, zero, row_mask)
    _init_diag_seed_row(d0_ub, zero, one, row_mask)
    _invert_diag_tile(d0_src_ub, d0_ub, row_mask, one, acc, a_val, prev_row, prod)


@vf()
def tril_inverse_block64_d1_vf(d1_src_ub: Tensor, d1_ub: Tensor, a10_ub: Tensor):
    zero = Reg(DT.float)
    one = Reg(DT.float)
    acc = Reg(DT.float)
    a_val = Reg(DT.float)
    prev_row = Reg(DT.float)
    prod = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)

    zero.fill(0.0)
    one.fill(1.0)

    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    _init_diag_seed_row(d1_ub, zero, one, row_mask)
    _negate_tile(a10_ub, row_mask, prev_row)
    _invert_diag_tile(d1_src_ub, d1_ub, row_mask, one, acc, a_val, prev_row, prod)


@vf()
def tril_inverse_block64_d2_vf(d2_src_ub: Tensor, d2_ub: Tensor, a20_ub: Tensor, a21_ub: Tensor):
    zero = Reg(DT.float)
    one = Reg(DT.float)
    acc = Reg(DT.float)
    a_val = Reg(DT.float)
    prev_row = Reg(DT.float)
    prod = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)

    zero.fill(0.0)
    one.fill(1.0)

    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    _init_diag_seed_row(d2_ub, zero, one, row_mask)
    _negate_tile(a20_ub, row_mask, prev_row)
    _negate_tile(a21_ub, row_mask, prev_row)
    _invert_diag_tile(d2_src_ub, d2_ub, row_mask, one, acc, a_val, prev_row, prod)


@vf()
def tril_inverse_block64_d3_vf(
    d3_src_ub: Tensor,
    d3_ub: Tensor,
    a30_ub: Tensor,
    a31_ub: Tensor,
    a32_ub: Tensor,
):
    zero = Reg(DT.float)
    one = Reg(DT.float)
    acc = Reg(DT.float)
    a_val = Reg(DT.float)
    prev_row = Reg(DT.float)
    prod = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)

    zero.fill(0.0)
    one.fill(1.0)

    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    _init_diag_seed_row(d3_ub, zero, one, row_mask)
    _negate_tile(a30_ub, row_mask, prev_row)
    _negate_tile(a31_ub, row_mask, prev_row)
    _negate_tile(a32_ub, row_mask, prev_row)
    _invert_diag_tile(d3_src_ub, d3_ub, row_mask, one, acc, a_val, prev_row, prod)


@vf()
def tril_inverse_block64_strict_d0_vf(d0_src_ub: Tensor, zero16_ub: Tensor, d0_ub: Tensor):
    zero = Reg(DT.float)
    one = Reg(DT.float)
    acc = Reg(DT.float)
    a_val = Reg(DT.float)
    prev_row = Reg(DT.float)
    prod = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)

    zero.fill(0.0)
    one.fill(1.0)

    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    _init_zero_tile(zero16_ub, zero, row_mask)
    _init_diag_seed_row(d0_ub, zero, one, row_mask)
    _invert_diag_tile_from_strict_a(d0_src_ub, d0_ub, row_mask, one, acc, a_val, prev_row, prod)


@vf()
def tril_inverse_block64_strict_d1_vf(d1_src_ub: Tensor, d1_ub: Tensor):
    zero = Reg(DT.float)
    one = Reg(DT.float)
    acc = Reg(DT.float)
    a_val = Reg(DT.float)
    prev_row = Reg(DT.float)
    prod = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)

    zero.fill(0.0)
    one.fill(1.0)

    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    _init_diag_seed_row(d1_ub, zero, one, row_mask)
    _invert_diag_tile_from_strict_a(d1_src_ub, d1_ub, row_mask, one, acc, a_val, prev_row, prod)


@vf()
def tril_inverse_block64_strict_d2_vf(d2_src_ub: Tensor, d2_ub: Tensor):
    zero = Reg(DT.float)
    one = Reg(DT.float)
    acc = Reg(DT.float)
    a_val = Reg(DT.float)
    prev_row = Reg(DT.float)
    prod = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)

    zero.fill(0.0)
    one.fill(1.0)

    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    _init_diag_seed_row(d2_ub, zero, one, row_mask)
    _invert_diag_tile_from_strict_a(d2_src_ub, d2_ub, row_mask, one, acc, a_val, prev_row, prod)


@vf()
def tril_inverse_block64_strict_d3_vf(d3_src_ub: Tensor, d3_ub: Tensor):
    zero = Reg(DT.float)
    one = Reg(DT.float)
    acc = Reg(DT.float)
    a_val = Reg(DT.float)
    prev_row = Reg(DT.float)
    prod = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)

    zero.fill(0.0)
    one.fill(1.0)

    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    _init_diag_seed_row(d3_ub, zero, one, row_mask)
    _invert_diag_tile_from_strict_a(d3_src_ub, d3_ub, row_mask, one, acc, a_val, prev_row, prod)


@vf()
def cast_block_float_to_bf16_vf(src_ub: Tensor, dst_ub: Tensor):
    row = Reg(DT.float)
    row_bf16 = Reg(DT.bfloat16)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)
    row_mask_bf16 = MaskReg(DT.bfloat16, init_mode=MaskType.NONE)
    row_mask <<= Var(BLOCK, dtype=DT.uint32)
    row_mask_bf16 <<= Var(BLOCK * 2, dtype=DT.uint32)
    for r in range(0, BLOCK):
        ub_to_reg(row, src_ub[r:r + 1, 0:BLOCK], mask=row_mask)
        row_bf16 <<= row.astype(DT.bfloat16)
        reg_to_ub_downsample(dst_ub[r:r + 1, 0:BLOCK], row_bf16, mask=row_mask_bf16)


@func()
def _publish_l0c_to_l1(l1_dst: Tensor, l0c_src: Tensor, valid: SEvent):
    l1_dst <<= l0c_src
    valid.set()
    valid.wait()


@func()
def _matmul_to_l1_tmp(l0c_tmp: Tensor, l1_tmp: Tensor, left: Tensor, right: Tensor, valid: SEvent):
    matmul(l0c_tmp, left, right.T, m=BLOCK, n=BLOCK, k=BLOCK)
    _publish_l0c_to_l1(l1_tmp, l0c_tmp, valid)


@kernel()
def tril_inverse64_v2_kernel(mat: GMTensor, inv: GMTensor, B: Var, H: Var, C: Var):
    stage0_mutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    stage1_mutex = VcMutex(1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    l1_valid = SEvent(Pipe.FIX, Pipe.MTE1)

    total_chunks = B * H * C
    mat_tiles = mat.reshape([total_chunks, SIZE, SIZE], name="mat_tiles")
    inv_tiles = inv.reshape([total_chunks, SIZE, SIZE], name="inv_tiles")

    d0_src_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d1_src_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d2_src_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d3_src_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    zero16_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d0_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d1_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d2_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d3_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a10_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a20_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a21_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a30_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a31_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a32_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)

    l1_d0 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_d1 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_d2 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_d3 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a10 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a20 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a21 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a30 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a31 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a32 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_x10 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_x20 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_x21 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_p21 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_p31 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_p32 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_tmp = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)

    l0c_tmp = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x10 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x20 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x21 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x30 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x31 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x32 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)

    chunks_per_core = CeilDiv(total_chunks, GetCubeNum())
    chunk_begin = Var(chunks_per_core * GetCubeIdx())
    chunk_end = Min(chunk_begin + chunks_per_core, total_chunks)
    buf_cnt = Var(0)

    for chunk_idx in range(chunk_begin, chunk_end):
        with auto_sync():
            stage0_mutex.lock()
            stage1_mutex.lock()

            if GetSubBlockIdx() == 0:
                d0_src_ub <<= mat_tiles[chunk_idx, 0:BLOCK, 0:BLOCK]
                tril_inverse_block64_d0_vf(d0_src_ub, zero16_ub, d0_ub)
                l1_d0[buf_cnt][0:BLOCK, 0:BLOCK] <<= d0_ub[0:BLOCK, 0:BLOCK]
                stage0_mutex.ready()

            if GetSubBlockIdx() == 1:
                d1_src_ub <<= mat_tiles[chunk_idx, BLOCK:2 * BLOCK, BLOCK:2 * BLOCK]
                a10_ub <<= mat_tiles[chunk_idx, BLOCK:2 * BLOCK, 0:BLOCK]
                tril_inverse_block64_d1_vf(d1_src_ub, d1_ub, a10_ub)
                l1_d1[buf_cnt][0:BLOCK, 0:BLOCK] <<= d1_ub[0:BLOCK, 0:BLOCK]
                l1_a10[buf_cnt][0:BLOCK, 0:BLOCK] <<= a10_ub[0:BLOCK, 0:BLOCK]
                stage0_mutex.ready()

            stage0_mutex.wait()

            # X10 = D1 @ A10 @ D0. Run this as soon as D0/D1/A10 are published,
            # while the vec side prepares D2/D3 and the remaining A blocks.
            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_tmp[buf_cnt], l1_d1[buf_cnt], l1_a10[buf_cnt], l1_valid)
            matmul(l0c_x10[buf_cnt], l1_tmp[buf_cnt], l1_d0[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            _publish_l0c_to_l1(l1_x10[buf_cnt], l0c_x10[buf_cnt], l1_valid)

            if GetSubBlockIdx() == 1:
                d3_src_ub <<= mat_tiles[chunk_idx, 3 * BLOCK:SIZE, 3 * BLOCK:SIZE]
                a30_ub <<= mat_tiles[chunk_idx, 3 * BLOCK:SIZE, 0:BLOCK]
                a31_ub <<= mat_tiles[chunk_idx, 3 * BLOCK:SIZE, BLOCK:2 * BLOCK]
                a32_ub <<= mat_tiles[chunk_idx, 3 * BLOCK:SIZE, 2 * BLOCK:3 * BLOCK]
                tril_inverse_block64_d3_vf(d3_src_ub, d3_ub, a30_ub, a31_ub, a32_ub)
                l1_d3[buf_cnt][0:BLOCK, 0:BLOCK] <<= d3_ub[0:BLOCK, 0:BLOCK]
                l1_a30[buf_cnt][0:BLOCK, 0:BLOCK] <<= a30_ub[0:BLOCK, 0:BLOCK]
                l1_a31[buf_cnt][0:BLOCK, 0:BLOCK] <<= a31_ub[0:BLOCK, 0:BLOCK]
                l1_a32[buf_cnt][0:BLOCK, 0:BLOCK] <<= a32_ub[0:BLOCK, 0:BLOCK]
                stage1_mutex.ready()

            if GetSubBlockIdx() == 0:
                d2_src_ub <<= mat_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 2 * BLOCK:3 * BLOCK]
                a20_ub <<= mat_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 0:BLOCK]
                a21_ub <<= mat_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, BLOCK:2 * BLOCK]
                tril_inverse_block64_d2_vf(d2_src_ub, d2_ub, a20_ub, a21_ub)
                l1_d2[buf_cnt][0:BLOCK, 0:BLOCK] <<= d2_ub[0:BLOCK, 0:BLOCK]
                l1_a20[buf_cnt][0:BLOCK, 0:BLOCK] <<= a20_ub[0:BLOCK, 0:BLOCK]
                l1_a21[buf_cnt][0:BLOCK, 0:BLOCK] <<= a21_ub[0:BLOCK, 0:BLOCK]
                stage1_mutex.ready()

                inv_tiles[chunk_idx, 0:BLOCK, 0:BLOCK] <<= d0_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 0:BLOCK, BLOCK:2 * BLOCK] <<= zero16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 0:BLOCK, 2 * BLOCK:3 * BLOCK] <<= zero16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 0:BLOCK, 3 * BLOCK:SIZE] <<= zero16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, BLOCK:2 * BLOCK, 2 * BLOCK:3 * BLOCK] <<= zero16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, BLOCK:2 * BLOCK, 3 * BLOCK:SIZE] <<= zero16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 2 * BLOCK:3 * BLOCK] <<= d2_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 3 * BLOCK:SIZE] <<= zero16_ub[0:BLOCK, 0:BLOCK]

            if GetSubBlockIdx() == 1:
                inv_tiles[chunk_idx, BLOCK:2 * BLOCK, BLOCK:2 * BLOCK] <<= d1_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 3 * BLOCK:SIZE, 3 * BLOCK:SIZE] <<= d3_ub[0:BLOCK, 0:BLOCK]

            stage1_mutex.wait()

            # X21 = D2 @ A21 @ D1
            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_p21[buf_cnt], l1_d2[buf_cnt], l1_a21[buf_cnt], l1_valid)
            matmul(l0c_x21[buf_cnt], l1_p21[buf_cnt], l1_d1[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            _publish_l0c_to_l1(l1_x21[buf_cnt], l0c_x21[buf_cnt], l1_valid)
            inv_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, BLOCK:2 * BLOCK] <<= l0c_x21[buf_cnt][0:BLOCK, 0:BLOCK]

            # X32 = D3 @ A32 @ D2
            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_p32[buf_cnt], l1_d3[buf_cnt], l1_a32[buf_cnt], l1_valid)
            matmul(l0c_x32[buf_cnt], l1_p32[buf_cnt], l1_d2[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            inv_tiles[chunk_idx, 3 * BLOCK:SIZE, 2 * BLOCK:3 * BLOCK] <<= l0c_x32[buf_cnt][0:BLOCK, 0:BLOCK]

            # X20 = D2 @ A20 @ D0 + D2 @ A21 @ X10
            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_tmp[buf_cnt], l1_d2[buf_cnt], l1_a20[buf_cnt], l1_valid)
            matmul(l0c_x20[buf_cnt], l1_tmp[buf_cnt], l1_d0[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            matmul(l0c_x20[buf_cnt], l1_p21[buf_cnt], l1_x10[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK, is_init=False)
            _publish_l0c_to_l1(l1_x20[buf_cnt], l0c_x20[buf_cnt], l1_valid)
            inv_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 0:BLOCK] <<= l0c_x20[buf_cnt][0:BLOCK, 0:BLOCK]

            # X31 = D3 @ A31 @ D1 + D3 @ A32 @ X21
            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_p31[buf_cnt], l1_d3[buf_cnt], l1_a31[buf_cnt], l1_valid)
            matmul(l0c_x31[buf_cnt], l1_p31[buf_cnt], l1_d1[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            matmul(l0c_x31[buf_cnt], l1_p32[buf_cnt], l1_x21[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK, is_init=False)
            inv_tiles[chunk_idx, 3 * BLOCK:SIZE, BLOCK:2 * BLOCK] <<= l0c_x31[buf_cnt][0:BLOCK, 0:BLOCK]

            # X30 = D3 @ A30 @ D0 + D3 @ A31 @ X10 + D3 @ A32 @ X20
            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_tmp[buf_cnt], l1_d3[buf_cnt], l1_a30[buf_cnt], l1_valid)
            matmul(l0c_x30[buf_cnt], l1_tmp[buf_cnt], l1_d0[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            matmul(l0c_x30[buf_cnt], l1_p31[buf_cnt], l1_x10[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK, is_init=False)
            matmul(l0c_x30[buf_cnt], l1_p32[buf_cnt], l1_x20[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK, is_init=False)
            inv_tiles[chunk_idx, 3 * BLOCK:SIZE, 0:BLOCK] <<= l0c_x30[buf_cnt][0:BLOCK, 0:BLOCK]

            inv_tiles[chunk_idx, BLOCK:2 * BLOCK, 0:BLOCK] <<= l0c_x10[buf_cnt][0:BLOCK, 0:BLOCK]
            stage1_mutex.free()
            stage0_mutex.free()
            bar_all()
            buf_cnt += 1

    return inv


@kernel()
def tril_inverse64_v2_strict_bf16_kernel(a: GMTensor, inv: GMTensor, B: Var, H: Var, C: Var):
    stage0_mutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    stage1_mutex = VcMutex(1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    l1_valid = SEvent(Pipe.FIX, Pipe.MTE1)

    total_chunks = B * H * C
    a_tiles = a.reshape([total_chunks, SIZE, SIZE], name="a_tiles")
    inv_tiles = inv.reshape([total_chunks, SIZE, SIZE], name="inv_tiles")

    d0_src_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d1_src_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d2_src_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d3_src_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    zero16_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d0_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d1_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d2_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    d3_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a10_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a20_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a21_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a30_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a31_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    a32_ub = Tensor(DT.float, [BLOCK, BLOCK], Position.UB)
    zero16_bf16_ub = Tensor(DT.bfloat16, [BLOCK, BLOCK], Position.UB)
    d0_bf16_ub = Tensor(DT.bfloat16, [BLOCK, BLOCK], Position.UB)
    d1_bf16_ub = Tensor(DT.bfloat16, [BLOCK, BLOCK], Position.UB)
    d2_bf16_ub = Tensor(DT.bfloat16, [BLOCK, BLOCK], Position.UB)
    d3_bf16_ub = Tensor(DT.bfloat16, [BLOCK, BLOCK], Position.UB)

    l1_d0 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_d1 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_d2 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_d3 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a10 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a20 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a21 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a30 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a31 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_a32 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_x10 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_x20 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_x21 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_p21 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_p31 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_p32 = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)
    l1_tmp = DBuff(DT.float, [BLOCK, BLOCK], Position.L1)

    l0c_tmp = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x10 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x20 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x21 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x30 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x31 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)
    l0c_x32 = DBuff(DT.float, [BLOCK, BLOCK], Position.L0C)

    chunks_per_core = CeilDiv(total_chunks, GetCubeNum())
    chunk_begin = Var(chunks_per_core * GetCubeIdx())
    chunk_end = Min(chunk_begin + chunks_per_core, total_chunks)
    buf_cnt = Var(0)

    for chunk_idx in range(chunk_begin, chunk_end):
        with auto_sync():
            stage0_mutex.lock()
            stage1_mutex.lock()

            if GetSubBlockIdx() == 0:
                d0_src_ub <<= a_tiles[chunk_idx, 0:BLOCK, 0:BLOCK]
                tril_inverse_block64_strict_d0_vf(d0_src_ub, zero16_ub, d0_ub)
                l1_d0[buf_cnt][0:BLOCK, 0:BLOCK] <<= d0_ub[0:BLOCK, 0:BLOCK]
                stage0_mutex.ready()

            if GetSubBlockIdx() == 1:
                d1_src_ub <<= a_tiles[chunk_idx, BLOCK:2 * BLOCK, BLOCK:2 * BLOCK]
                a10_ub <<= a_tiles[chunk_idx, BLOCK:2 * BLOCK, 0:BLOCK]
                tril_inverse_block64_strict_d1_vf(d1_src_ub, d1_ub)
                l1_d1[buf_cnt][0:BLOCK, 0:BLOCK] <<= d1_ub[0:BLOCK, 0:BLOCK]
                l1_a10[buf_cnt][0:BLOCK, 0:BLOCK] <<= a10_ub[0:BLOCK, 0:BLOCK]
                stage0_mutex.ready()

            stage0_mutex.wait()

            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_tmp[buf_cnt], l1_d1[buf_cnt], l1_a10[buf_cnt], l1_valid)
            matmul(l0c_x10[buf_cnt], l1_tmp[buf_cnt], l1_d0[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            _publish_l0c_to_l1(l1_x10[buf_cnt], l0c_x10[buf_cnt], l1_valid)

            if GetSubBlockIdx() == 1:
                d3_src_ub <<= a_tiles[chunk_idx, 3 * BLOCK:SIZE, 3 * BLOCK:SIZE]
                a30_ub <<= a_tiles[chunk_idx, 3 * BLOCK:SIZE, 0:BLOCK]
                a31_ub <<= a_tiles[chunk_idx, 3 * BLOCK:SIZE, BLOCK:2 * BLOCK]
                a32_ub <<= a_tiles[chunk_idx, 3 * BLOCK:SIZE, 2 * BLOCK:3 * BLOCK]
                tril_inverse_block64_strict_d3_vf(d3_src_ub, d3_ub)
                l1_d3[buf_cnt][0:BLOCK, 0:BLOCK] <<= d3_ub[0:BLOCK, 0:BLOCK]
                l1_a30[buf_cnt][0:BLOCK, 0:BLOCK] <<= a30_ub[0:BLOCK, 0:BLOCK]
                l1_a31[buf_cnt][0:BLOCK, 0:BLOCK] <<= a31_ub[0:BLOCK, 0:BLOCK]
                l1_a32[buf_cnt][0:BLOCK, 0:BLOCK] <<= a32_ub[0:BLOCK, 0:BLOCK]
                stage1_mutex.ready()

            if GetSubBlockIdx() == 0:
                d2_src_ub <<= a_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 2 * BLOCK:3 * BLOCK]
                a20_ub <<= a_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 0:BLOCK]
                a21_ub <<= a_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, BLOCK:2 * BLOCK]
                tril_inverse_block64_strict_d2_vf(d2_src_ub, d2_ub)
                l1_d2[buf_cnt][0:BLOCK, 0:BLOCK] <<= d2_ub[0:BLOCK, 0:BLOCK]
                l1_a20[buf_cnt][0:BLOCK, 0:BLOCK] <<= a20_ub[0:BLOCK, 0:BLOCK]
                l1_a21[buf_cnt][0:BLOCK, 0:BLOCK] <<= a21_ub[0:BLOCK, 0:BLOCK]
                stage1_mutex.ready()

                cast_block_float_to_bf16_vf(zero16_ub, zero16_bf16_ub)
                cast_block_float_to_bf16_vf(d0_ub, d0_bf16_ub)
                cast_block_float_to_bf16_vf(d2_ub, d2_bf16_ub)
                inv_tiles[chunk_idx, 0:BLOCK, 0:BLOCK] <<= d0_bf16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 0:BLOCK, BLOCK:2 * BLOCK] <<= zero16_bf16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 0:BLOCK, 2 * BLOCK:3 * BLOCK] <<= zero16_bf16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 0:BLOCK, 3 * BLOCK:SIZE] <<= zero16_bf16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, BLOCK:2 * BLOCK, 2 * BLOCK:3 * BLOCK] <<= zero16_bf16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, BLOCK:2 * BLOCK, 3 * BLOCK:SIZE] <<= zero16_bf16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 2 * BLOCK:3 * BLOCK] <<= d2_bf16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 3 * BLOCK:SIZE] <<= zero16_bf16_ub[0:BLOCK, 0:BLOCK]

            if GetSubBlockIdx() == 1:
                cast_block_float_to_bf16_vf(d1_ub, d1_bf16_ub)
                cast_block_float_to_bf16_vf(d3_ub, d3_bf16_ub)
                inv_tiles[chunk_idx, BLOCK:2 * BLOCK, BLOCK:2 * BLOCK] <<= d1_bf16_ub[0:BLOCK, 0:BLOCK]
                inv_tiles[chunk_idx, 3 * BLOCK:SIZE, 3 * BLOCK:SIZE] <<= d3_bf16_ub[0:BLOCK, 0:BLOCK]

            stage1_mutex.wait()

            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_p21[buf_cnt], l1_d2[buf_cnt], l1_a21[buf_cnt], l1_valid)
            matmul(l0c_x21[buf_cnt], l1_p21[buf_cnt], l1_d1[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            _publish_l0c_to_l1(l1_x21[buf_cnt], l0c_x21[buf_cnt], l1_valid)
            inv_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, BLOCK:2 * BLOCK] <<= l0c_x21[buf_cnt][0:BLOCK, 0:BLOCK]

            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_p32[buf_cnt], l1_d3[buf_cnt], l1_a32[buf_cnt], l1_valid)
            matmul(l0c_x32[buf_cnt], l1_p32[buf_cnt], l1_d2[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            inv_tiles[chunk_idx, 3 * BLOCK:SIZE, 2 * BLOCK:3 * BLOCK] <<= l0c_x32[buf_cnt][0:BLOCK, 0:BLOCK]

            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_tmp[buf_cnt], l1_d2[buf_cnt], l1_a20[buf_cnt], l1_valid)
            matmul(l0c_x20[buf_cnt], l1_tmp[buf_cnt], l1_d0[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            matmul(l0c_x20[buf_cnt], l1_p21[buf_cnt], l1_x10[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK, is_init=False)
            _publish_l0c_to_l1(l1_x20[buf_cnt], l0c_x20[buf_cnt], l1_valid)
            inv_tiles[chunk_idx, 2 * BLOCK:3 * BLOCK, 0:BLOCK] <<= l0c_x20[buf_cnt][0:BLOCK, 0:BLOCK]

            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_p31[buf_cnt], l1_d3[buf_cnt], l1_a31[buf_cnt], l1_valid)
            matmul(l0c_x31[buf_cnt], l1_p31[buf_cnt], l1_d1[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            matmul(l0c_x31[buf_cnt], l1_p32[buf_cnt], l1_x21[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK, is_init=False)
            inv_tiles[chunk_idx, 3 * BLOCK:SIZE, BLOCK:2 * BLOCK] <<= l0c_x31[buf_cnt][0:BLOCK, 0:BLOCK]

            _matmul_to_l1_tmp(l0c_tmp[buf_cnt], l1_tmp[buf_cnt], l1_d3[buf_cnt], l1_a30[buf_cnt], l1_valid)
            matmul(l0c_x30[buf_cnt], l1_tmp[buf_cnt], l1_d0[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK)
            matmul(l0c_x30[buf_cnt], l1_p31[buf_cnt], l1_x10[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK, is_init=False)
            matmul(l0c_x30[buf_cnt], l1_p32[buf_cnt], l1_x20[buf_cnt].T, m=BLOCK, n=BLOCK, k=BLOCK, is_init=False)
            inv_tiles[chunk_idx, 3 * BLOCK:SIZE, 0:BLOCK] <<= l0c_x30[buf_cnt][0:BLOCK, 0:BLOCK]

            inv_tiles[chunk_idx, BLOCK:2 * BLOCK, 0:BLOCK] <<= l0c_x10[buf_cnt][0:BLOCK, 0:BLOCK]
            stage1_mutex.free()
            stage0_mutex.free()
            bar_all()
            buf_cnt += 1

    return inv


# --------------------------------------------------------------------------- #
# Neumann / log-squaring whole-64 inverse (cube-bound; vec-light).
#
# For strict-lower (nilpotent, A^64 = 0) A,
#     (I - A)^-1 = prod_{j=0}^{5} (I + A^(2^j))
# because (I-A)·prod = I - A^64 = I.  Built by the doubling recurrence
#     inv = I + A;  Apow = A
#     repeat 5x:  Apow = Apow@Apow;  inv = inv@(I + Apow) = inv + inv@Apow
# which is ~17 fp32 64x64 cube matmuls and *no* serial vec substitution — the
# opposite balance to the block-substitution kernel above (vec-bound).  fp32
# throughout (the cube already runs fp32 here), so it matches the block kernel's
# precision; powers of the small delta/GDN A decay, so rounding stays ~1e-7.
# --------------------------------------------------------------------------- #


@vf()
def _build_eye64_vf(eye_ub: Tensor):
    """Write a SIZE x SIZE fp32 identity into UB (zero each row, set the diagonal)."""
    zero = Reg(DT.float)
    one = Reg(DT.float)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)
    zero.fill(0.0)
    one.fill(1.0)
    row_mask <<= Var(SIZE, dtype=DT.uint32)
    for r in range(0, SIZE):
        reg_to_ub(eye_ub[r:r + 1, 0:SIZE], zero, mask=row_mask)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        eye_ub[r:r + 1, r:r + 1] <<= one.single_value()
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def _cast_half_float_to_bf16_vf(src_ub: Tensor, dst_ub: Tensor):
    """Cast a (SIZE/2) x SIZE fp32 UB tile to bf16 (one sub-block's row half)."""
    half = SIZE // 2
    row = Reg(DT.float)
    row_bf16 = Reg(DT.bfloat16)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)
    row_mask_bf16 = MaskReg(DT.bfloat16, init_mode=MaskType.NONE)
    row_mask <<= Var(SIZE, dtype=DT.uint32)
    row_mask_bf16 <<= Var(SIZE * 2, dtype=DT.uint32)
    for r in range(0, half):
        ub_to_reg(row, src_ub[r:r + 1, 0:SIZE], mask=row_mask)
        row_bf16 <<= row.astype(DT.bfloat16)
        reg_to_ub_downsample(dst_ub[r:r + 1, 0:SIZE], row_bf16, mask=row_mask_bf16)


@vf()
def _cast_full_float_to_bf16_vf(src_ub: Tensor, dst_ub: Tensor):
    """Cast a SIZE x SIZE fp32 UB tile to bf16 (seed I / A as bf16 cube operands)."""
    row = Reg(DT.float)
    row_bf16 = Reg(DT.bfloat16)
    row_mask = MaskReg(DT.float, init_mode=MaskType.NONE)
    row_mask_bf16 = MaskReg(DT.bfloat16, init_mode=MaskType.NONE)
    row_mask <<= Var(SIZE, dtype=DT.uint32)
    row_mask_bf16 <<= Var(SIZE * 2, dtype=DT.uint32)
    for r in range(0, SIZE):
        ub_to_reg(row, src_ub[r:r + 1, 0:SIZE], mask=row_mask)
        row_bf16 <<= row.astype(DT.bfloat16)
        reg_to_ub_downsample(dst_ub[r:r + 1, 0:SIZE], row_bf16, mask=row_mask_bf16)


@func()
def _square_publish(l0c_sq: Tensor, l1_apow: Tensor, valid: SEvent):
    """l1_apow <- l1_apow @ l1_apow  (Apow^2), republished to L1 for the next read."""
    matmul(l0c_sq, l1_apow, l1_apow.T, m=SIZE, n=SIZE, k=SIZE)
    _publish_l0c_to_l1(l1_apow, l0c_sq, valid)


@func()
def _inv_times_i_plus_apow(l0c_inv: Tensor, l1_inv: Tensor, l1_eye: Tensor,
                           l1_apow: Tensor, valid: SEvent):
    """l1_inv <- l1_inv @ (I + Apow) = inv@I + inv@Apow, republished to L1."""
    matmul(l0c_inv, l1_inv, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)                  # inv @ I = inv
    matmul(l0c_inv, l1_inv, l1_apow.T, m=SIZE, n=SIZE, k=SIZE, is_init=False)  # + inv @ Apow
    _publish_l0c_to_l1(l1_inv, l0c_inv, valid)


@kernel()
def tril_inverse64_neumann_strict_bf16_kernel(a: GMTensor, inv: GMTensor, B: Var, H: Var, C: Var):
    # 2-chunk interleave: process chunks in PAIRS with compile-time parity A/B.
    # Each parity owns an independent Apow ping-pong / l1_inv / l0c / event set, so
    # chunk B's squares+invs (no data dep on A) fill chunk A's serial-chain bubbles
    # and vice versa. Cores that draw an odd chunk count finish with one solo chunk
    # (the validated single-chunk pipeline). DBuff (parity A=2 SEvents -> no runtime
    # index needed) sidesteps the SEvent-has-no-depth / DBuff-is-depth-2 limits that
    # blocked a runtime-parity cross-chunk pipeline.
    eye_setup_vc = VcMutex(2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    a_vc = VcMutex(1, depth=2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    cast_cv = CvMutex(0, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    apow_a = SEvent(Pipe.FIX, Pipe.MTE1)
    apow_b = SEvent(Pipe.FIX, Pipe.MTE1)
    inva = SEvent(Pipe.FIX, Pipe.MTE1)
    invb = SEvent(Pipe.FIX, Pipe.MTE1)

    half = SIZE // 2
    total_chunks = B * H * C
    a_tiles = a.reshape([total_chunks, SIZE, SIZE], name="a_tiles")
    inv_tiles = inv.reshape([total_chunks, SIZE, SIZE], name="inv_tiles")

    eye_f32_ub = Tensor(DT.float, [SIZE, SIZE], Position.UB)       # built once
    eye_bf16_ub = Tensor(DT.bfloat16, [SIZE, SIZE], Position.UB)   # built once
    # DBuff slot0 = parity A, slot1 = parity B (both live within one pair).
    a_f32_ub = DBuff(DT.float, [SIZE, SIZE], Position.UB)
    a_bf16_ub = DBuff(DT.bfloat16, [SIZE, SIZE], Position.UB)
    inv_f32_ub = DBuff(DT.float, [half, SIZE], Position.UB)
    inv_bf16_ub = DBuff(DT.bfloat16, [half, SIZE], Position.UB)

    # bf16 L1 operands -> the cube's fast matmul path; fp32 L0C accumulate, FIX
    # casts fp32 L0C -> bf16 L1 on every publish (de-risked to 2.4e-4 vs exact).
    l1_eye = Tensor(DT.bfloat16, [SIZE, SIZE], Position.L1)        # constant, once
    # per-parity 2-slot Apow ping-pong (square writes Apow_{j+1} to the free slot
    # while inv_j still reads Apow_j) + per-parity running inverse.
    l1_apow_a = DBuff(DT.bfloat16, [SIZE, SIZE], Position.L1)
    l1_apow_b = DBuff(DT.bfloat16, [SIZE, SIZE], Position.L1)
    l1_inv_a = Tensor(DT.bfloat16, [SIZE, SIZE], Position.L1)
    l1_inv_b = Tensor(DT.bfloat16, [SIZE, SIZE], Position.L1)

    # l0c_inv DBuff rotates per pair so pair N's cast overlaps pair N+1's init.
    l0c_inv_a = DBuff(DT.float, [SIZE, SIZE], Position.L0C)
    l0c_inv_b = DBuff(DT.float, [SIZE, SIZE], Position.L0C)
    l0c_sq_a = Tensor(DT.float, [SIZE, SIZE], Position.L0C)
    l0c_sq_b = Tensor(DT.float, [SIZE, SIZE], Position.L0C)

    chunks_per_core = CeilDiv(total_chunks, GetCubeNum())
    chunk_begin = Var(chunks_per_core * GetCubeIdx())
    chunk_end = Min(chunk_begin + chunks_per_core, total_chunks)
    row_begin = Var(GetSubBlockIdx() * half)
    row_end = Var(row_begin + half)
    num_chunks = Var(chunk_end - chunk_begin)
    num_pairs = Var(num_chunks // 2)

    with auto_sync():
        # --- build the bf16 identity ONCE; VcMutex(MTE3->MTE1) syncs it to the cube
        #     (bar_all does NOT cover MTE3->MTE1, so a one-time publish needs this) ---
        eye_setup_vc.lock()
        if GetSubBlockIdx() == 0:
            _build_eye64_vf(eye_f32_ub)
            _cast_full_float_to_bf16_vf(eye_f32_ub, eye_bf16_ub)
            l1_eye[0:SIZE, 0:SIZE] <<= eye_bf16_ub[0:SIZE, 0:SIZE]
        eye_setup_vc.ready()
        eye_setup_vc.wait()
        eye_setup_vc.free()

        pair_buf = Var(0)
        for p in range(0, num_pairs):
            ca = Var(chunk_begin + 2 * p)
            cb = Var(ca + 1)

            # --- load A -> l1_apow_a[0], B -> l1_apow_b[0] (= Apow_0 each) ---
            a_vc.lock()
            if GetSubBlockIdx() == 0:
                a_f32_ub[0][0:SIZE, 0:SIZE] <<= a_tiles[ca, 0:SIZE, 0:SIZE]
                _cast_full_float_to_bf16_vf(a_f32_ub[0], a_bf16_ub[0])
                l1_apow_a[0][0:SIZE, 0:SIZE] <<= a_bf16_ub[0][0:SIZE, 0:SIZE]
                a_f32_ub[1][0:SIZE, 0:SIZE] <<= a_tiles[cb, 0:SIZE, 0:SIZE]
                _cast_full_float_to_bf16_vf(a_f32_ub[1], a_bf16_ub[1])
                l1_apow_b[0][0:SIZE, 0:SIZE] <<= a_bf16_ub[1][0:SIZE, 0:SIZE]
            a_vc.ready()
            a_vc.wait()

            # --- init: inv_0 = I + A = A@I + I@I  (A, then B) ---
            matmul(l0c_inv_a[pair_buf], l1_apow_a[0], l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
            matmul(l0c_inv_a[pair_buf], l1_eye, l1_eye.T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
            l1_inv_a[0:SIZE, 0:SIZE] <<= l0c_inv_a[pair_buf][0:SIZE, 0:SIZE]
            inva.set()
            matmul(l0c_inv_b[pair_buf], l1_apow_b[0], l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
            matmul(l0c_inv_b[pair_buf], l1_eye, l1_eye.T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
            l1_inv_b[0:SIZE, 0:SIZE] <<= l0c_inv_b[pair_buf][0:SIZE, 0:SIZE]
            invb.set()

            # --- sq_1: Apow_1 = Apow_0^2 -> slot1  (A, then B) ---
            matmul(l0c_sq_a, l1_apow_a[0], l1_apow_a[0].T, m=SIZE, n=SIZE, k=SIZE)
            l1_apow_a[1][0:SIZE, 0:SIZE] <<= l0c_sq_a[0:SIZE, 0:SIZE]
            apow_a.set()
            matmul(l0c_sq_b, l1_apow_b[0], l1_apow_b[0].T, m=SIZE, n=SIZE, k=SIZE)
            l1_apow_b[1][0:SIZE, 0:SIZE] <<= l0c_sq_b[0:SIZE, 0:SIZE]
            apow_b.set()

            # --- doublings j=1..4: square A,B one step ahead, then inv A,B.
            #     (rd, wr) = (Apow_j slot read, Apow_{j+1} slot written); inv_j also
            #     reads Apow_j in `rd`. Interleaving the two parities fills each
            #     square's FIX (publish) gap with the other parity's matmuls. ---
            for (rd, wr) in [(1, 0), (0, 1), (1, 0), (0, 1)]:
                apow_a.wait()                                                        # Apow_a_j
                matmul(l0c_sq_a, l1_apow_a[rd], l1_apow_a[rd].T, m=SIZE, n=SIZE, k=SIZE)
                l1_apow_a[wr][0:SIZE, 0:SIZE] <<= l0c_sq_a[0:SIZE, 0:SIZE]            # Apow_a_{j+1}
                apow_a.set()
                apow_b.wait()                                                        # Apow_b_j
                matmul(l0c_sq_b, l1_apow_b[rd], l1_apow_b[rd].T, m=SIZE, n=SIZE, k=SIZE)
                l1_apow_b[wr][0:SIZE, 0:SIZE] <<= l0c_sq_b[0:SIZE, 0:SIZE]            # Apow_b_{j+1}
                apow_b.set()
                inva.wait()                                                          # inv_a_{j-1}
                matmul(l0c_inv_a[pair_buf], l1_inv_a, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
                matmul(l0c_inv_a[pair_buf], l1_inv_a, l1_apow_a[rd].T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
                l1_inv_a[0:SIZE, 0:SIZE] <<= l0c_inv_a[pair_buf][0:SIZE, 0:SIZE]
                inva.set()
                invb.wait()                                                          # inv_b_{j-1}
                matmul(l0c_inv_b[pair_buf], l1_inv_b, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
                matmul(l0c_inv_b[pair_buf], l1_inv_b, l1_apow_b[rd].T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
                l1_inv_b[0:SIZE, 0:SIZE] <<= l0c_inv_b[pair_buf][0:SIZE, 0:SIZE]
                invb.set()

            # --- epilogue: inv_5 = inv_4 @ (I + Apow_5)  (Apow_5 in slot1), no publish ---
            apow_a.wait()                                                            # Apow_a_5
            inva.wait()                                                              # inv_a_4
            matmul(l0c_inv_a[pair_buf], l1_inv_a, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
            matmul(l0c_inv_a[pair_buf], l1_inv_a, l1_apow_a[1].T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
            apow_b.wait()                                                            # Apow_b_5
            invb.wait()                                                              # inv_b_4
            matmul(l0c_inv_b[pair_buf], l1_inv_b, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
            matmul(l0c_inv_b[pair_buf], l1_inv_b, l1_apow_b[1].T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
            a_vc.free()

            # --- cast A,B fp32 inv -> bf16 -> GM; SPLITM gives each sub-block a row half ---
            cast_cv.lock()
            l0c_to_ub(inv_f32_ub[0], l0c_inv_a[pair_buf], M=SIZE, N=SIZE, N_dst=SIZE, M_src=SIZE,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
            cast_cv.ready()
            cast_cv.wait()
            _cast_half_float_to_bf16_vf(inv_f32_ub[0], inv_bf16_ub[0])
            cast_cv.free()
            inv_tiles[ca, row_begin:row_end, 0:SIZE] <<= inv_bf16_ub[0][0:half, 0:SIZE]

            cast_cv.lock()
            l0c_to_ub(inv_f32_ub[1], l0c_inv_b[pair_buf], M=SIZE, N=SIZE, N_dst=SIZE, M_src=SIZE,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
            cast_cv.ready()
            cast_cv.wait()
            _cast_half_float_to_bf16_vf(inv_f32_ub[1], inv_bf16_ub[1])
            cast_cv.free()
            inv_tiles[cb, row_begin:row_end, 0:SIZE] <<= inv_bf16_ub[1][0:half, 0:SIZE]
            pair_buf += 1

        # --- odd tail: one solo chunk (the validated single-chunk pipeline, parity A) ---
        if num_chunks % 2 != 0:
            ct = Var(chunk_end - 1)
            a_vc.lock()
            if GetSubBlockIdx() == 0:
                a_f32_ub[0][0:SIZE, 0:SIZE] <<= a_tiles[ct, 0:SIZE, 0:SIZE]
                _cast_full_float_to_bf16_vf(a_f32_ub[0], a_bf16_ub[0])
                l1_apow_a[0][0:SIZE, 0:SIZE] <<= a_bf16_ub[0][0:SIZE, 0:SIZE]
            a_vc.ready()
            a_vc.wait()

            matmul(l0c_inv_a[pair_buf], l1_apow_a[0], l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
            matmul(l0c_inv_a[pair_buf], l1_eye, l1_eye.T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
            l1_inv_a[0:SIZE, 0:SIZE] <<= l0c_inv_a[pair_buf][0:SIZE, 0:SIZE]
            inva.set()
            matmul(l0c_sq_a, l1_apow_a[0], l1_apow_a[0].T, m=SIZE, n=SIZE, k=SIZE)
            l1_apow_a[1][0:SIZE, 0:SIZE] <<= l0c_sq_a[0:SIZE, 0:SIZE]
            apow_a.set()
            for (rd, wr) in [(1, 0), (0, 1), (1, 0), (0, 1)]:
                apow_a.wait()
                matmul(l0c_sq_a, l1_apow_a[rd], l1_apow_a[rd].T, m=SIZE, n=SIZE, k=SIZE)
                l1_apow_a[wr][0:SIZE, 0:SIZE] <<= l0c_sq_a[0:SIZE, 0:SIZE]
                apow_a.set()
                inva.wait()
                matmul(l0c_inv_a[pair_buf], l1_inv_a, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
                matmul(l0c_inv_a[pair_buf], l1_inv_a, l1_apow_a[rd].T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
                l1_inv_a[0:SIZE, 0:SIZE] <<= l0c_inv_a[pair_buf][0:SIZE, 0:SIZE]
                inva.set()
            apow_a.wait()
            inva.wait()
            matmul(l0c_inv_a[pair_buf], l1_inv_a, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
            matmul(l0c_inv_a[pair_buf], l1_inv_a, l1_apow_a[1].T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
            a_vc.free()

            cast_cv.lock()
            l0c_to_ub(inv_f32_ub[0], l0c_inv_a[pair_buf], M=SIZE, N=SIZE, N_dst=SIZE, M_src=SIZE,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
            cast_cv.ready()
            cast_cv.wait()
            _cast_half_float_to_bf16_vf(inv_f32_ub[0], inv_bf16_ub[0])
            cast_cv.free()
            inv_tiles[ct, row_begin:row_end, 0:SIZE] <<= inv_bf16_ub[0][0:half, 0:SIZE]

    return inv


@kernel()
def tril_inverse64_neumann_strict_bf16_serial_kernel(a: GMTensor, inv: GMTensor, B: Var, H: Var, C: Var):
    # SERIAL Neumann: the validated single-chunk pipeline run once per chunk in a
    # runtime loop. The 2-chunk A/B interleave (…_kernel above) is board-CORRECT in
    # sim but board-HANGS on a5pr: mixing the serial auto_sync FIX chain with the
    # manual FIX->MTE1 apow/inv events across two interleaved parities closes a
    # MTE1->FIX->M->MTE1 pipe cycle that sim does not model. Dropping the interleave
    # (parity A only, 2 SEvents) removes the cycle. board-validated on a5pr.
    eye_setup_vc = VcMutex(2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    a_vc = VcMutex(1, depth=2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    cast_cv = CvMutex(0, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    apow_a = SEvent(Pipe.FIX, Pipe.MTE1)
    inva = SEvent(Pipe.FIX, Pipe.MTE1)

    half = SIZE // 2
    total_chunks = B * H * C
    a_tiles = a.reshape([total_chunks, SIZE, SIZE], name="a_tiles")
    inv_tiles = inv.reshape([total_chunks, SIZE, SIZE], name="inv_tiles")

    eye_f32_ub = Tensor(DT.float, [SIZE, SIZE], Position.UB)
    eye_bf16_ub = Tensor(DT.bfloat16, [SIZE, SIZE], Position.UB)
    a_f32_ub = DBuff(DT.float, [SIZE, SIZE], Position.UB)
    a_bf16_ub = DBuff(DT.bfloat16, [SIZE, SIZE], Position.UB)
    inv_f32_ub = DBuff(DT.float, [half, SIZE], Position.UB)
    inv_bf16_ub = DBuff(DT.bfloat16, [half, SIZE], Position.UB)

    l1_eye = Tensor(DT.bfloat16, [SIZE, SIZE], Position.L1)
    l1_apow_a = DBuff(DT.bfloat16, [SIZE, SIZE], Position.L1)
    l1_inv_a = Tensor(DT.bfloat16, [SIZE, SIZE], Position.L1)
    l0c_inv_a = DBuff(DT.float, [SIZE, SIZE], Position.L0C)
    l0c_sq_a = Tensor(DT.float, [SIZE, SIZE], Position.L0C)

    chunks_per_core = CeilDiv(total_chunks, GetCubeNum())
    chunk_begin = Var(chunks_per_core * GetCubeIdx())
    chunk_end = Min(chunk_begin + chunks_per_core, total_chunks)
    num_chunks = Var(chunk_end - chunk_begin)
    row_begin = Var(GetSubBlockIdx() * half)
    row_end = Var(row_begin + half)

    with auto_sync():
        eye_setup_vc.lock()
        if GetSubBlockIdx() == 0:
            _build_eye64_vf(eye_f32_ub)
            _cast_full_float_to_bf16_vf(eye_f32_ub, eye_bf16_ub)
            l1_eye[0:SIZE, 0:SIZE] <<= eye_bf16_ub[0:SIZE, 0:SIZE]
        eye_setup_vc.ready()
        eye_setup_vc.wait()
        eye_setup_vc.free()

        for c in range(0, num_chunks):
            ct = Var(chunk_begin + c)

            # --- load A -> l1_apow_a[0] (= Apow_0) ---
            a_vc.lock()
            if GetSubBlockIdx() == 0:
                a_f32_ub[0][0:SIZE, 0:SIZE] <<= a_tiles[ct, 0:SIZE, 0:SIZE]
                _cast_full_float_to_bf16_vf(a_f32_ub[0], a_bf16_ub[0])
                l1_apow_a[0][0:SIZE, 0:SIZE] <<= a_bf16_ub[0][0:SIZE, 0:SIZE]
            a_vc.ready()
            a_vc.wait()

            # --- init: inv_0 = I + A ;  sq_1: Apow_1 = Apow_0^2 -> slot1 ---
            matmul(l0c_inv_a[0], l1_apow_a[0], l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
            matmul(l0c_inv_a[0], l1_eye, l1_eye.T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
            l1_inv_a[0:SIZE, 0:SIZE] <<= l0c_inv_a[0][0:SIZE, 0:SIZE]
            inva.set()
            matmul(l0c_sq_a, l1_apow_a[0], l1_apow_a[0].T, m=SIZE, n=SIZE, k=SIZE)
            l1_apow_a[1][0:SIZE, 0:SIZE] <<= l0c_sq_a[0:SIZE, 0:SIZE]
            apow_a.set()

            # --- doublings j=1..4: square one step ahead, then inv ---
            for (rd, wr) in [(1, 0), (0, 1), (1, 0), (0, 1)]:
                apow_a.wait()
                matmul(l0c_sq_a, l1_apow_a[rd], l1_apow_a[rd].T, m=SIZE, n=SIZE, k=SIZE)
                l1_apow_a[wr][0:SIZE, 0:SIZE] <<= l0c_sq_a[0:SIZE, 0:SIZE]
                apow_a.set()
                inva.wait()
                matmul(l0c_inv_a[0], l1_inv_a, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
                matmul(l0c_inv_a[0], l1_inv_a, l1_apow_a[rd].T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
                l1_inv_a[0:SIZE, 0:SIZE] <<= l0c_inv_a[0][0:SIZE, 0:SIZE]
                inva.set()

            # --- epilogue: inv_5 = inv_4 @ (I + Apow_5), no publish ---
            apow_a.wait()
            inva.wait()
            matmul(l0c_inv_a[0], l1_inv_a, l1_eye.T, m=SIZE, n=SIZE, k=SIZE)
            matmul(l0c_inv_a[0], l1_inv_a, l1_apow_a[1].T, m=SIZE, n=SIZE, k=SIZE, is_init=False)
            a_vc.free()

            # --- cast fp32 inv -> bf16 -> GM (SPLITM row half per sub-block) ---
            cast_cv.lock()
            l0c_to_ub(inv_f32_ub[0], l0c_inv_a[0], M=SIZE, N=SIZE, N_dst=SIZE, M_src=SIZE,
                      dual_mode=DualMode.SPLITM, sub_block_id=0)
            cast_cv.ready()
            cast_cv.wait()
            _cast_half_float_to_bf16_vf(inv_f32_ub[0], inv_bf16_ub[0])
            cast_cv.free()
            inv_tiles[ct, row_begin:row_end, 0:SIZE] <<= inv_bf16_ub[0][0:half, 0:SIZE]
    return inv


def inverse_from_strict_lower_a_neumann_bf16_a5(
    a: torch.Tensor,
    simulator: bool = True,
    profile: bool = False,
    out_dir: str = "",
    trace: str = None,
    core_count: int = None,
) -> torch.Tensor:
    """Whole-64 Neumann/log-squaring strict-lower inverse; bf16 output.

    Drop-in alternative to ``inverse_from_strict_lower_a_bf16_a5_v2`` that moves
    the diagonal inversion off the serial vec ALU and onto the (idle) fp32 cube.
    """
    squeeze_2d = False
    if a.shape == (SIZE, SIZE):
        a = a.reshape(1, 1, 1, SIZE, SIZE)
        squeeze_2d = True
    if a.ndim != 5 or a.shape[-2:] != (SIZE, SIZE):
        raise ValueError(f"expected shape [B, H, C, {SIZE}, {SIZE}], got {tuple(a.shape)}")
    if a.dtype != KERNEL_DTYPE:
        raise TypeError(f"the A5 kernel path expects {KERNEL_DTYPE}, got {a.dtype}")

    out = torch.empty(a.shape, dtype=torch.bfloat16, device=a.device)
    B, H, C = (int(dim) for dim in a.shape[:3])
    kfn = tril_inverse64_neumann_strict_bf16_kernel
    saved = getattr(kfn, "_simulator_config", None)
    if simulator and core_count is not None:
        from easyasc.simulator import SimulatorConfig
        kfn._simulator_config = SimulatorConfig(
            core_count=core_count, execution_timeout_s=180.0, trace_enabled=trace is not None)
    try:
        result = OpExec(kfn, out_dir=out_dir, simulator=simulator, profile=profile, trace=trace)(
            a.contiguous(), out, B, H, C, shape_bindings=SHAPE_BINDINGS
        )
    finally:
        if simulator and core_count is not None:
            if saved is None:
                try:
                    delattr(kfn, "_simulator_config")
                except AttributeError:
                    pass
            else:
                kfn._simulator_config = saved
    if squeeze_2d:
        return result.reshape(SIZE, SIZE)
    return result


def block_inverse_i_minus_a_a5_v2(
    mat: torch.Tensor,
    simulator: bool = True,
    profile: bool = False,
    out_dir: str = "",
) -> torch.Tensor:
    """Run the A5 DSL v2 kernel for float32 [B, H, C, 64, 64] inputs."""
    squeeze_2d = False
    if mat.shape == (SIZE, SIZE):
        mat = mat.reshape(1, 1, 1, SIZE, SIZE)
        squeeze_2d = True
    if mat.ndim != 5 or mat.shape[-2:] != (SIZE, SIZE):
        raise ValueError(f"expected shape [B, H, C, {SIZE}, {SIZE}], got {tuple(mat.shape)}")
    if mat.dtype != KERNEL_DTYPE:
        raise TypeError(f"the A5 kernel path expects {KERNEL_DTYPE}, got {mat.dtype}")

    out = torch.empty_like(mat)
    B, H, C = (int(dim) for dim in mat.shape[:3])
    result = OpExec(
        tril_inverse64_v2_kernel,
        out_dir=out_dir,
        simulator=simulator,
        profile=profile,
    )(
        mat.contiguous(), out, B, H, C, shape_bindings=SHAPE_BINDINGS
    )
    if squeeze_2d:
        return result.reshape(SIZE, SIZE)
    return result


def inverse_from_strict_lower_a_bf16_a5_v2(
    a: torch.Tensor,
    simulator: bool = True,
    profile: bool = False,
    out_dir: str = "",
) -> torch.Tensor:
    """Run the A5 v2 strict-lower inverse kernel and return bf16 output.

    Input is strict-lower A in `inverse(I - A)`. The kernel keeps all live
    inverse math in fp32 local buffers and writes the final GM output as bf16.
    """
    squeeze_2d = False
    if a.shape == (SIZE, SIZE):
        a = a.reshape(1, 1, 1, SIZE, SIZE)
        squeeze_2d = True
    if a.ndim != 5 or a.shape[-2:] != (SIZE, SIZE):
        raise ValueError(f"expected shape [B, H, C, {SIZE}, {SIZE}], got {tuple(a.shape)}")
    if a.dtype != KERNEL_DTYPE:
        raise TypeError(f"the A5 kernel path expects {KERNEL_DTYPE}, got {a.dtype}")

    out = torch.empty(a.shape, dtype=torch.bfloat16, device=a.device)
    B, H, C = (int(dim) for dim in a.shape[:3])
    result = OpExec(
        tril_inverse64_v2_strict_bf16_kernel,
        out_dir=out_dir,
        simulator=simulator,
        profile=profile,
    )(
        a.contiguous(), out, B, H, C, shape_bindings=SHAPE_BINDINGS
    )
    if squeeze_2d:
        return result.reshape(SIZE, SIZE)
    return result


def _demo_pytorch() -> None:
    torch.manual_seed(0)
    dtype = torch.float64

    a = torch.randn(SIZE, SIZE, dtype=dtype)
    a = torch.tril(a, diagonal=-1) * 0.03
    mat = torch.eye(SIZE, dtype=dtype) - a

    got = block_inverse_i_minus_a(mat)
    ref = torch.linalg.inv(mat)

    identity = torch.eye(SIZE, dtype=dtype)
    max_inv_err = (got - ref).abs().max().item()
    max_residual = (mat @ got - identity).abs().max().item()

    print(f"max error vs torch.linalg.inv: {max_inv_err:.3e}")
    print(f"max residual for (I - A) @ inv: {max_residual:.3e}")


def _demo_a5_kernel() -> None:
    torch.manual_seed(1)

    B, H, C = 1, 2, 2
    a = torch.randn(B, H, C, SIZE, SIZE, dtype=KERNEL_DTYPE)
    a = torch.tril(a, diagonal=-1) * 0.03
    mat = torch.eye(SIZE, dtype=KERNEL_DTYPE).expand(B, H, C, SIZE, SIZE) - a

    got = block_inverse_i_minus_a_a5_v2(mat)
    ref = block_inverse_i_minus_a(mat)

    identity = torch.eye(SIZE, dtype=KERNEL_DTYPE).expand(B, H, C, SIZE, SIZE)
    max_inv_err = torch.abs(got - ref).max().item()
    max_residual = torch.abs(mat @ got - identity).max().item()

    torch.testing.assert_close(got, ref, rtol=1e-4, atol=1e-4)
    print(f"A5 kernel max error vs PyTorch block inverse: {max_inv_err:.3e}")
    print(f"A5 kernel max residual for (I - A) @ inv: {max_residual:.3e}")

    got_bf16 = inverse_from_strict_lower_a_bf16_a5_v2(a)
    ref_bf16 = inverse_from_strict_lower_a(a).to(torch.bfloat16)
    max_bf16_err = torch.abs(got_bf16.float() - ref_bf16.float()).max().item()

    torch.testing.assert_close(got_bf16.float(), ref_bf16.float(), rtol=2e-3, atol=2e-3)
    print(f"A5 bf16 strict-A kernel max error vs fp32->bf16 reference: {max_bf16_err:.3e}")


if __name__ == "__main__":
    _demo_pytorch()
    _demo_a5_kernel()
