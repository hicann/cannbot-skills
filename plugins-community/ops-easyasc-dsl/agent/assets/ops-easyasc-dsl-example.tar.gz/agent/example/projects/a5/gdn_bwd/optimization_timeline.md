# GDN Backward Optimization Timeline

This document is the canonical project-local optimization rationale for the
current `gdn_bwd` implementation. It keeps the useful dense step records needed
to explain why the active version is shaped the way it is.

Folded source notes:

- `refs/plan.md`: current decomposition and IO contract.
- retired `optimization_route.md`: early makespan route and round2 decisions.
- retired `scan_vf_optimization.md`: monolithic scan VF pass.
- retired `scan_state_optimization.md`: split scan and forward-cache state pass.

## Current Result

The active runtime path is:

```text
scan_split_bwd
  -> scan_local_bwd
  -> scan_state_bwd
wu_bwd
inverse_preprocess_bwd
finalize_bwd
kernel_compose
```

The current plan consumes the forward-saved state-history tensors
`v_new_history`, `k_weighted_history`, and `exp_delta_history`. The scan-local
to scan-state score handoff is bf16 because the downstream consumers use it
only as a cube operand. The public `d_query` output is forwarded directly from
the scan stage; `finalize_bwd` owns only `d_key`, `d_value`, `d_beta`, and
`d_g`.

Final WebIDE onboard profile after the clean upload passed at
`(B,H,C)=(1,32,16)` with `OpExec(..., profile=True)`:

| stage | hardware AVG |
|---|---:|
| `scan_local_bwd` | `88.82us` |
| `scan_state_bwd` | `266.23us` |
| `wu_bwd` | `143.23us` |
| `inverse_preprocess_bwd` | `52.12us` |
| `finalize_bwd` | `138.61us` |

All final compose outputs were accepted with `bad=0`:

| output | max abs |
|---|---:|
| `d_query` | `3.994e-06` |
| `d_key` | `5.007e-06` |
| `d_value` | `4.820e-05` |
| `d_beta` | `2.787e-06` |
| `d_g` | `2.837e-04` |

The final hardware log is not tracked; rerun the onboard script before relying
on these historical values after a kernel change.

Latest simulator-only update on 2026-05-28:

- The next all-cube `finalize_bwd` lower-half rewrite needs the already-masked
  decay matrices, so the upstream producers now append them without replacing
  the old ABI. `scan_local_bwd` returns
  `d_decay_core_masked = d_decay_core * decay_mask` as output 3, computed in
  the existing `mask_attn_decay_vf`; UB rises to `152 KB / 256 KB`.
  `inverse_preprocess_bwd` returns
  `d_decay_pre_masked = d_decay_pre * decay_mask` as output 3, computed in
  `mask_score_and_decay_vf`; UB rises to `192.375 KB / 256 KB`. Existing tuple
  indices remain stable for the current compose/finalize path. While validating
  inverse, `cast_l_rows_float_to_bf16_nz_vf` was fixed to use
  `MaskType.LOWHALF` for compact 64-column bf16 NZ rows. `module_vs_ref` passes
  for the two producers and the old compose smoke under `PYTHONWARNINGS=error`.
- A 2026-05-28 local tmp finalize experiment computed the normal upper outputs
  (`d_key`, `d_value`, `d_beta`) and materializes
  `A = (d_decay_core + d_decay_pre) * decay_mask` in one fused VF over
  `L//4=16` row tiles. The DBuff UB footprint is `160.25 KB / 256 KB`, so the
  shape fits comfortably. Correctness passes for `(B,H,C)=(1,1,8)` / 2-core
  with `max_abs_diff=1.862645e-08`; the standalone trace makespan is `46193`
  cycles, with vec MTE2 at ~100% active/span. This makes full-A materialization
  feasible but clearly GM->UB bandwidth-heavy.
- A fairer local tmp follow-up keeps the current production upper phase
  unchanged and puts A materialization behind
  `reset_cache()` as a separate `[32,64]` DBuff phase. This uses
  `224.375 KB / 256 KB` UB for upper and only `64 KB / 256 KB` for A. The same
  C=8 / 2-core run passes with `max_abs_diff=1.862645e-08` and measures
  `34279` cycles; upper ends at `27959`, so A-only adds about `6320` cycles.
  MTE2 events per active lane are `44` instead of the L//4 fused version's
  `88`, so the earlier 46k result was dominated by fragmented loads.
- `scan_local_bwd::mask_attn_decay_vf` now stores the bf16 score row with a
  `MaskType.LOWHALF` mask. The old full-register store wrote 128 bf16 lanes
  into a 64-element row view, which could spill beyond the intended UB row at
  the final write.
- For `(B,H,C,L,D)=(1,1,4,64,128)`, isolated `scan_state_bwd` simulator
  makespan moved from `81923` cycles to `77961` cycles. This run used
  `PYTHONWARNINGS=error` and all five scan-state outputs passed at
  `atol=rtol=5e-4`.
- Kept `scan_state_bwd` changes:
  fused nonzero-C d-state update with immediate bf16 NZ publish; fused
  nonzero-C d-value add/negate with d-v-prime bf16 NZ publish; dropped the
  dead c0 d-state-seed negate; moved c0 zero `d_k_cumdecay` and c0
  `d_value_wu` stores earlier so tail MTE3 writes overlap later work.
- A follow-up `scan_state_bwd` pass fixed the remaining scalar handoff UB
  footprint by masking `[1,8]` fp32 scratch stores with `MaskType.LOWEST8`, then
  moved the `d_g` finish/handoff work before the two `d_score` output matmuls.
  This keeps the same GM scratch exchange between subblocks but overlaps its
  MTE3 tail with later `d_q`/`d_k` work. On `(B,H,C)=(1,1,4)`, strict
  simulator trace makespan improved `82639 -> 74467` cycles after the
  footprint-safe baseline; `(1,1,8)` and default `(1,2,2)` scan-state checks
  also passed. The same pass split the later `d_k` postprocess output away from
  `out_ub` into the already-dead `d_q_exp_ub`, closing a hazard-check finding
  where `d_q_core` MTE3 could still be reading `out_ub` while
  `postprocess_dk_vf` wrote it.
- Rejected two measured fusions despite lower summed V time because they
  worsened the critical path: nonzero-C `add_scaled_d_rows_vf +
  accum_dq_g_half_vf` (`80343` cycles), and c0 `postprocess_dk_vf +
  finish_g_zero_base_half_vf` (`78506` cycles). For this shape, tail MTE3
  placement and synchronization timing beat raw VF-duration reduction.
- Promoted the tmp1 scan-local C->V->C lookahead into the project kernel. The
  producer beat now owns `q @ k.T`, `d_out @ v_new.T`,
  `mask_attn_decay_vf`, and bf16-NZ attention publication; the delayed
  consumer beat owns only `attn.T @ d_out` plus direct `L0C -> GM` writeback.
  The accepted mutex shape follows the existing library pattern:
  `CvMutex` for `l0c_ll* -> UB -> vf` and
  `VcMutex(src_end=MTE3,dst_end=MTE1)` for `vf/MTE3 -> L1 attn -> cube`.
  All rotating slots are DBuff except `l1_d_out`, which remains TBuff because
  it is live in the producer matmul and the next beat's consumer matmul.
  Splitting `ll2_ub` from the dedicated `d_decay_out_ub` avoided a false
  MTE2/MTE3 dependency between the next `decay_mask` load and previous
  `d_decay_core` store source. On the 1-core same-BHC stress
  `(B,H,C)=(1,1,4)`, isolated `scan_local_bwd` improved from the original tmp
  baseline `21703` cycles to `17279`; cube MTE2 reached effectively `100%`
  active/span, so the local kernel is now mainly GM->L1 data-movement limited.
- Promoted the tmp1 `wu_bwd` vec->cube lookahead into the project kernel, then
  simplified the `scan_state_bwd -> wu_bwd` ABI so `d_value_wu` and
  `d_k_cumdecay` are bf16 workspaces. The producer beat now builds only
  `v_beta` and `k_beta_g` into DBuff L1 slots; the delayed consumer beat loads
  `wu_attn_bf16` plus the two bf16 scan-state workspaces directly to L1, runs
  the four matmuls, then performs cube->vec `d_k_beta/d_g` finalization. Rotating
  L1, L0C, and producer-side UB roles are DBuff, with `d_k_beta_g_ub` also
  DBuffed for the cube->vec mutex handoff. On the 1-core `(B,H,C)=(1,1,4)`
  stress, isolated `wu_bwd` improved from the original tmp baseline
  `44534 -> 27584 -> 26752 -> 21881` cycles across lookahead, VF-barrier
  hoisting, and direct bf16 inputs; `(1,1,8)` improved `47740 -> 39797` on the
  final bf16-input step. The default 32-core `(1,2,2)` compose shape gives each
  active core roughly one BHC, so it is expected to show less from lookahead
  than the 1-core same-BHC stress.

## 1. First Correct Plan1

The first plan1 implementation was a five-stage explicit split of
`gdn_bwd_full`:

```text
scan_bwd -> wu_bwd -> inverse_preprocess_bwd -> finalize_bwd
scan_bwd, wu_bwd, inverse_preprocess_bwd -> finalize_bwd
```

The early work was about making the full formula executable and numerically
honest:

- `inverse_preprocess_bwd` moved from SIMT fallback to cube/VF structure.
- `finalize_bwd` moved from GM-wide SIMT to vector reductions.
- `wu_bwd` became a real cube/VF kernel.
- `scan_bwd` became the reverse-C recurrent kernel.
- The refs and kernels were aligned around bf16 cube operands with fp32
  accumulation and `atol=rtol=5e-4`.

This phase ended with simulator-vs-ref passing for the full compose path.

## 2. Cheap Tail Wins Before Touching Scan

The first makespan baseline at `(B,H,C)=(1,2,2)` and 32 simulated A5 cores was:

| stage | baseline cycles |
|---|---:|
| `scan_bwd` | `94373` |
| `wu_bwd` | `14161` |
| `inverse_preprocess_bwd` | `9621` |
| `finalize_bwd` | `16858` |
| `compose_sum` | `135013` |

The early decision was conservative: optimize the tail kernels first because
they were smaller and easier to validate.

Accepted `finalize_bwd` changes:

- Removed dead `d_q` VF work, then removed the identity `d_query` copy entirely
  by forwarding `scan[0]` from `kernel_compose.py`.
- Kept the `d_g` column accumulator in registers instead of UB.
- Replaced scalar reverse cumsum with a vector gather/prefix form.
- Replaced scratch-UB reinterpret of gather indices with `Reg.reinterpret`.
- Split value/beta and key VFs, then replaced broad `auto_sync()` with explicit
  vec-side ready/valid events.

Accepted `wu_bwd` changes:

- Fused WU factor production with bf16-NZ casts. This was tiny but clean.
- Moved `l0c_d_k_beta_g -> UB` before `d_wu` / `d_v_beta` GM writeback, which
  let the final WU VF overlap with FIX writeback. This was the real WU win.

Accepted `inverse_preprocess_bwd` changes:

- Published `l1_d_score` readiness earlier so the final cube matmuls did not
  wait behind `d_decay_pre` GM store.
- Prefetched `decay_mask` before the cube-to-vec wait, protected by a narrow
  `V -> MTE2` reuse event.
- Reshaped the one-core multi-BHC path as a `V1C1` producer and `V2C2`
  consumer lookahead, using TBuff where the carried role crossed two beats.

After this phase the tail route was:

| metric | baseline | current | delta |
|---|---:|---:|---:|
| `wu_bwd` | `14161` | `12005` | `-2156` |
| `inverse_preprocess_bwd` | `9621` | `8509` | `-1112` |
| `finalize_bwd` | `16858` | `12069` | `-4789` |
| `compose_sum` | `135013` | `126956` | `-8057` |

The accepted step ledger from the retired makespan route is preserved here
because it explains the order of the tail changes:

| step | accepted edit | stage effect |
|---|---|---|
| 1 | removed dead `d_q` register work in `finalize_vectors_beta_vf` | `finalize_bwd 16858 -> 16474` |
| 2 | kept `finalize_g_vf` column sums in registers | `finalize_bwd 16474 -> 16092` |
| 3 | forwarded `d_query` from `scan[0]` in compose | `finalize_bwd 16092 -> 15280` |
| 4 | vectorized `d_g` reverse cumsum with gather/prefix offsets | `finalize_bwd 15280 -> 13766` |
| 5 | used `Reg.reinterpret(DT.uint32)` for gather indices | `finalize_bwd 13766 -> 13710` |
| 6 | fused WU factor production with bf16-NZ casts | `wu_bwd 14161 -> 14141` |
| 7 | exposed `l0c_d_k_beta_g` to UB before WU GM writeback | `wu_bwd 14141 -> 12005` |
| 8 | combined the two `d_beta` dot reductions before one `cadd` | `finalize_bwd 13710 -> 13102` |
| 9 | split vector/beta input and output UB ownership | `finalize_bwd 13102 -> 13038` |
| 10 | split value/beta and key VFs with manual vec events | `finalize_bwd 13038 -> 12069` |
| 11 | published inverse `l1_d_score` readiness before `d_decay_pre` GM store | `inverse_preprocess_bwd 9621 -> 9065` |
| 12 | prefetched inverse `decay_mask` behind a narrow reuse event | `inverse_preprocess_bwd 9065 -> 8503` |
| 13 | changed inverse to `V1C1` producer / `V2C2` consumer lookahead | one-core win; default `8503 -> 8509` |

Important rejected tail experiments:

- Early `d_query` writeback without a load-to-store event corrupted output0;
  adding the event made it correct but neutral, so compose-level forwarding won.
- Plain vector/beta `DBuff` added about `96 KB` UB but did not shift the issued
  schedule, so it gave zero cycle benefit on both 32-core and one-core traces.
- Splitting the WU final VF into two 16-row chunks regressed
  `wu_bwd 12005 -> 12687`; the extra VF launch and smaller stores outweighed
  overlap.
- Deleting loop barriers without separating UB ownership produced simulator
  local-memory warnings. The kept wins came from making ownership real, not
  silencing warnings.
- Early inverse `d_k_beta_pre` GM writeback passed a single-BHC check but failed
  the one-core multi-BHC stress (`max_abs=3.210e-03`), proving the same-core
  reuse test was necessary.

The scan stage was now obviously dominant.

## 3. Monolithic Scan VF Pass

The first scan optimization still used the monolithic `scan_bwd.py`. The
single-core scan trace made the hot VF work obvious:

| work | approximate cycles |
|---|---:|
| `finish_g_full_vf` | `5179` |
| `accum_dq_g_full_vf` | `4298` |
| `postprocess_dk_vf` | `2003` |
| `postprocess_dq_vf` | `1898` |
| `make_k_weighted_vf` | `1555` |
| `make_q_exp_vf` | `1450` |

The kept route was mostly deleting work and specializing the `c_idx == 0`
chunk where state is zero:

- Removed dead fp32 mirror stores from q/k producers.
- Fused q/k producer VFs with bf16-NZ packing.
- Removed dead q/key loads from dq/dk postprocess.
- Cached half-row `exp(g)` and `exp(g_last-g)` for dq/dk postprocess.
- Kept only barriers that proved necessary under same-core reuse.
- Specialized the c0 d_g path, c0 `v_new=value_wu`, c0 zero-state matmuls, and
  c0 q-exp publication.
- Reused low-half exp values in full-L d_g paths where legal.

The monolithic scan fell from `94373` cycles to about `65999` cycles in the
32-core compose trace. That was a good local win, but the kernel was becoming
tightly packed and hard to keep pushing without adding cross-lane lifetime
risk.

The detailed monolithic scan ledger was:

| milestone | default scan cycles | main point |
|---|---:|---|
| stable after tail work | `94373` | scan was now the bottleneck |
| dead q/k fp32 mirror stores removed | `93605` | no consumer remained |
| q/k producer plus bf16-NZ pack fused | `92029` | fewer VF calls |
| dead q/key postprocess loads removed | `88525` | deleted useless GM loads |
| half-row exp caches added | `85899` | reused local exp factors |
| c0 zero-base `d_g` specialization | `79901` | state is zero at `c_idx == 0` |
| c0 direct `v_new=value_wu` publication | `77161` | skipped zero-state path |
| c0 zero-state matmuls skipped | `73840` | cube work removed |
| c0 q-exp publication skipped | `71965` | no remaining c0 consumer |
| lane0-only full-L `d_g` with paired handoff | `71652` | removed duplicate vec work |
| full state-dot VF fused | `71640` | one launch instead of two |
| independent GM loads prefetched around waits | `70392` then `67815` | overlap, not fewer instructions |
| low-half exp reused in full-L `d_g` | `66375` | lane0 can reuse only its own half |
| tail-barrier cleanup for mask/copy/postprocess VFs | `66003` | warning-free ownership shrink |
| final middle-barrier/high-half cleanup | `65999` | tiny but stable cleanup |

Important scan-VF rejects:

- Removing `postprocess_dq_vf` / `postprocess_dk_vf` row-loop barriers without
  a valid ownership split failed correctness.
- Gating the full-L `d_g` handoff to only `GetSubBlockIdx() == 0` hung until the
  mutex pairing was repaired; both lanes still need matched handoff/free edges.
- Moving `update_d_state_vf` to a single tail barrier passed once but emitted
  loop-carried local-memory warnings, so it was rolled back.
- Directly storing c0 `d_q_core` from the FIX-produced UB view failed; the copy
  VF is required to materialize the lane-local data for GM store.
- Attempts to reuse `l0c_ld1` or add a blind L0C `DBuff` exposed real
  FIX/M/lifetime hazards. The tempting faster traces either failed precision or
  collided with generated event sequencing.

## 4. Split Scan Becomes The Main Story

The next direction split scan into a BHC-parallel local producer and a
BH-parallel reverse-state consumer:

```text
scan_local_bwd -> scan_state_bwd
```

The first split was worse for small `C=2` but better for larger `C=16`, which
was enough to keep it as the candidate. The split made the tuning surface much
clearer:

- `scan_local_bwd` owns local attention products and can be scheduled around
  cube/VF overlap.
- `scan_state_bwd` owns the reverse recurrent `d_state` path and the remaining
  scan outputs.

Important local-stage events:

- Reordered local stores so final GM writes did not block useful cube work.
- Split `grad_output` onto a separate mutex and loaded it after issuing initial
  matmuls.
- Built a lookahead-1 local experiment.
- Fixed its final-drain and cross-beat bugs by using TBuff for roles that live
  across producer beats and by adding an explicit `M -> FIX` readiness edge for
  `l0c_ld0`.
- Canonicalized the lookahead implementation back into
  `kernels/scan_local_bwd.py`.

Important state-stage events:

- Split lane-0-heavy gate reductions across both vector lanes.
- Removed dead scratch stores and redundant local barriers.
- Cached raw q/k half rows for later gate VFs.
- Split only the initial `grad_final_state -> l1_d_state` publication; the
  post-update recurrent state publish remained lane0-full because the simple
  half-state rewrite was wrong.
- Replaced broad loop `auto_sync()` with smaller cube-side regions and explicit
  vec-side events, then fixed the resulting warning by moving the
  `l0c_dd -> ub_d_state_seed` handoff under a dedicated `CvMutex(2)`.

By this point the clean default-core split trace reached:

| stage | cycles |
|---|---:|
| `scan_local_bwd` | `10779` |
| `scan_state_bwd` | `40282` |
| `scan_split_sum` | `51061` |
| `compose_sum` | `83644` |

This was the best simulator route before the forward-cache round.

The split-scan route went through these checkpoints:

| checkpoint | result |
|---|---|
| first fp32-temp split at `C=2` | `scan_split_sum=74305`, slower than monolithic `65999` |
| same split at `C=16` | split `643103` vs monolithic `684337`, enough to keep exploring |
| default split compose | public outputs passed, `compose_sum=106888` |
| one-core split baseline | `scan_local_bwd=38273`, `scan_state_bwd=119588`, `compose_sum=260613` |
| local store reorder | local `38273 -> 32350` |
| split `grad_output` mutex and delayed load | local `32350 -> 30727` |
| local lookahead-1 experiment | one-core local `30727 -> 25296` |
| multi-core drain fix with `M -> FIX` `ld0_ready` | default split passed; local became the canonical source |

The state pass then attacked lane imbalance and scratch traffic:

| checkpoint | one-core `scan_state_bwd` | note |
|---|---:|---|
| baseline with lookahead local | `119588` | vec0 carried most gate work |
| split c0 `finish_g_zero_base` | `118329` | both lanes own half rows |
| split `d_exp` / state-dot accumulation | `112123` | paired half-D reductions |
| split c!=0 `accum_dq_g` and `finish_g` | `104641` | lane balance improved |
| drop dead scratch stores and redundant barriers | `104034` | small but clean |
| reuse raw q/k half rows for gate VFs | `103982` | costs 16 KB UB |
| split initial `grad_final_state -> l1_d_state` only | `103222` | post-update split was wrong |
| pack lane0 delta and `d_exp_total` into one scratch vector | `102654` | one scratch round trip removed |
| manual vec events plus small cube `auto_sync()` regions | `80035` with warning | too fast to keep while warning remained |
| dedicated `cv_seed_mutex` around `l0c_dd -> ub_d_state_seed` | `80175`, no warning | accepted sync shape |

Rejected split-state ideas mattered as much as the wins:

- Splitting `update_d_state_vf` or the post-update `l1_d_state` publication by
  lane failed outputs 1/2/4. The recurrent state contract still needs a
  lane0-full owner or a different shared-state design.
- Publishing `state_after_history` from existing UB half rows was not
  layout-equivalent to the cube GM-to-L1 path.
- Prefetching gate q/k loads earlier around `postprocess_dk` was correct but
  slower, showing that not every independent load belongs earlier.
- Removing stale `FIX -> MTE1` events was kept only where the actual data path
  was `L0C -> UB -> VF`; removing the remaining ones blindly regressed.

## 5. Round2 Forward-Cache Contract

The next step changed the plan contract instead of only the backward schedule.
Forward started saving intermediates that backward was otherwise recomputing:

- `v_new_history`: removes local-stage recompute of `value_wu - k_cumdecay @ state`.
- `k_weighted_history`: removes runtime `key * exp_delta` vector/pack work for
  the `d_v_new` cube product.
- `exp_delta_history`: removes per-row `exp(g_last - g)` recompute from
  `scan_state_bwd`.

The scan-local to scan-state `d_score_tmp` handoff was also changed from fp32
GM to bf16 GM because it feeds only cube score products:

```text
d_q_score = d_score @ key
d_k_score = d_score.T @ query
```

This phase explored several shapes:

- A plain single `scan_saved_bwd` kernel was correct but UB-tight.
- A three-stage split
  `scan_local_bwd -> scan_pre_bwd -> scan_state_recur_bwd` exposed useful UB
  lifetime lessons, but was too expensive.
- L1 DBuff lookahead in `scan_state_recur_bwd` helped that experiment, but the
  active path was restored to two kernels because launch and duplicated state
  work dominated.
- A small L1 lookahead-1 inside `scan_state_bwd` hid some L1 publish wait in
  simulator, but was later rolled back from the official plan after hardware
  hangs.

The accepted official direction was:

```text
scan_local_bwd -> scan_state_bwd
forward-saved v_new_history, k_weighted_history, exp_delta_history
bf16 d_score_tmp
no internal scan-state L1 lookahead
```

The forward-cache timing ladder on the one-core `(B,H,C)=(1,2,2)` trace was:

| version | `scan_local_bwd` | `scan_state_bwd` | `scan_split_sum` | `compose_sum` |
|---|---:|---:|---:|---:|
| pre-round2 split baseline | `25297` | `80175` | `105472` | `208224` |
| after `v_new_history` | `21663` | `78592` | `100255` | `203005` |
| after `k_weighted_history` | `21663` | `75513` | `97176` | `199926` |
| restored two-kernel path | `21663` | `74863` | `96526` | `199278` |
| after `exp_delta_history` | `21663` | `72415` | `94078` | `196828` |
| after bf16 `d_score_tmp` handoff | `21703` | `71474` | `93177` | `195929` |
| internal L1 lookahead experiment | `21703` | `71338` | `93041` | `195793` |

The internal L1 lookahead was correct in simulator, including a `C=3` slot-wrap
regression, but its gain was only `136` state cycles and it later caused
hardware hangs. The official plan therefore kept the larger forward-cache and
bf16-handoff wins, then rolled the state L1 inputs back to single `Tensor`
storage.

Round2 also produced several records worth keeping:

- The direct `k_weighted_history -> l1_k_weighted` load is cube/MTE2 work. A
  `GetSubBlockIdx() == 0` guard is vector-side control and does not mean "only
  one cube subblock issues this load" in the way the experiment hoped.
- A simulator GM-to-L1 partial-NZ write bug was fixed during the investigation:
  partial row writes now preserve peer rows instead of clearing the whole
  destination panel. The naive half-L `k_weighted_history` split still failed
  afterward for the cube-control reason above.
- The single `scan_saved_bwd` reset proved the saved-history contract with a
  plain kernel, but used `249.03125 KB / 256 KB` UB and was too tight to be the
  final path.
- The three-stage split
  `scan_local_bwd -> scan_pre_bwd -> scan_state_recur_bwd` exposed a real UB
  source-lifetime bug: `float_full_ub` needed a targeted `DBuff` so `d_q_core`
  GM writeback and later full `d_q_exp` input did not share the same slot.
- `scan_state_recur_bwd` L1 DBuff lookahead improved that experimental recurrent
  stage `105200 -> 100292`, but the extra launch and duplicated state work made
  the three-stage plan worse than the restored two-kernel route.

The plan was first promoted from scratch into the current `projects/a5/gdn_bwd/` tree with
only production sources, refs, checks, and notes. It was later promoted again
to the canonical `projects/a5/gdn_bwd/{kernels,refs,test_script}` layout after
other candidate plans were retired. Generated ACLNN trees, trace JSON, dumps,
and rejected experiment files were intentionally not promoted.

## 6. Hardware Triage Changed The Plan Again

Simulator success was not the end. WebIDE hardware checks found issues that
looked like precision drift but were actually schedule/lifetime bugs.

First hardware issue: `scan_local_bwd`.

- `d_score_tmp` and `d_v_attn_tmp` matched.
- `d_decay_core` had exact zeros in the first row of each vec half.
- The accepted fix wrote `d_decay_core` from the contiguous `[HALF_L, L]`
  `ll2_ub` buffer instead of the previous wide-row `float_full_ub` path.

Second hardware issue: fused `scan_state_bwd`.

- `d_q_core`, `d_k_core`, and later `d_g_core` failed on hardware.
- Many fused-kernel fixes were tried and rejected because they only moved the
  failure around.
- The investigation switched to the safer incremental route: build a clean
  standalone kernel and add one output at a time.

The standalone scan-state rebuild proved the formulas and a simpler schedule:

1. `d_q_core` only passed simulator and hardware.
2. Added `d_k_core` and the recurrent `d_state` update; passed hardware.
3. Added `d_g_core`; a separate `d_q_exp_ub` role fixed a scratch reuse bug.
4. Added `d_value_wu`; moving the c0 extra matmul staging off `out_ub` kept
   pending `d_k_core` GM writeback stable.
5. Added `d_k_cumdecay`; zeroing through a retired UB role avoided corrupting
   the pending `d_value_wu` GM source.

After this, `scan_state_dq_core_bwd.py` covered the full scan-state output set
and passed hardware. The runtime `scan_state_bwd` binding was replaced with
the verified implementation, and the old fused body was left only for
comparison.

Hardware profile for the standalone replacement at `(1,32,16)` initially
showed `AVG: 306.58us`, then a few kept trace-driven optimizations brought the
runtime path to the final compose profile value `266.23us`.

## 7. Inverse Was Rebuilt One Output At A Time

The inverse preprocess kernel had hardware-only failures around `d_decay_pre`.
The team again used the slow-but-sane route: isolate one output, then add the
next output only after hardware passes.

The path went:

1. A minimal `d_k_pre`-only kernel passed local simulator and WebIDE hardware.
2. Adding `d_k_beta_pre` and `d_decay_pre` exposed a hardware lifetime/order
   bug: publishing `d_score` into L1 before the `d_decay_pre` GM write made
   `d_decay_pre` fail or become non-finite.
3. Rebuilding as `d_decay_pre` first proved the decay formula alone.
4. Adding `d_k_beta_pre` passed only after the `d_decay_pre` GM store was moved
   before the `d_score` bf16-NZ publish.
5. Adding final `d_k_pre` completed the tuple:

   ```text
   d_k_pre, d_k_beta_pre, d_decay_pre
   ```

The accepted full inverse schedule preserves that hardware-proven ordering:

```text
compute score-only and decay-only VF rows
write d_decay_pre to GM
publish d_score to bf16 NZ L1
run downstream d_k_beta_pre and d_k_pre cube matmuls
```

Then a light L1 DBuff pass lifted `l1_w`, `l1_d_wu`, `l1_tmp`, and
`l1_d_score` to two-slot DBuff and changed the score mutex depth to 2. This
was a real hardware win:

| version | hardware AVG |
|---|---:|
| Tensor L1 baseline | `86.44us` |
| L1 DBuff | `84.69us` |
| final trace-check ref upstream | `82.78us` |
| final trace-check kernel upstream | `86.23us` |

Final-store rewrites were rejected. The one-core simulator showed the tail was
dominated by direct `FIX:l0c_to_gm_nz2nd` stores, but replacing them with
`L0C -> UB -> GM` or moving only the first final store earlier either regressed
or was noise. Tightening the score barriers saved only a few cycles, so the
safer barriers were restored.

## 8. Finalize Was Rebuilt Around Hardware-Proven `d_g`

Round2 had a correct simulator cube-reduce candidate for `finalize_g` using
host-provided `ones16`, DBuff VCVC lookahead, and VF reverse cumsum. It was
interesting but not the final hardware path.

Hardware exposed a `d_g`-only failure while `d_key`, `d_value`, and `d_beta`
were correct. Several plausible fixes did not solve it:

- delaying reduce mutex free until lane0 consumed row/col reduce values;
- lifting row/col reduce L0C scratch to DBuff;
- replacing the cube reduce with a lane0-only VF reduce inside the full kernel.

The successful route was again incremental:

1. `finalize_d_g_bwd.py`: d_g only, slow rowwise VF path. This passed hardware.
2. `finalize_d_g_value_bwd.py`: added `d_value = d_v_beta * beta`. This passed
   hardware after a CANN packaging naming fix.
3. `finalize_d_g_value_beta_bwd.py`: added `d_beta`. This passed hardware.
4. The full `finalize_bwd.py` kept the proven rowwise scalar/VF `d_g` route and
   restored `d_key`, `d_value`, and `d_beta` vector formulas.

The naming issue was not a math problem: CANN snake-cased
`FinalizeDGValueBwdKernel` to `finalize_dg_value_bwd_kernel.cpp`, while the
EasyAsc function name `finalize_d_g_value_bwd_kernel` generated a different
filename. Renaming the public `@kernel` functions to match the CANN
snake-case fixed the packaging mismatch.

Final standalone hardware validation:

| kernel | mode | hardware AVG | result |
|---|---|---:|---|
| `finalize_d_g_value_bwd.py` | ref upstream | `103.20us` | OK |
| `finalize_d_g_value_bwd.py` | kernel upstream | `102.10us` | OK |
| `finalize_d_g_value_beta_bwd.py` | ref upstream | `112.56us` | OK |
| `finalize_d_g_value_beta_bwd.py` | kernel upstream | `112.82us` | OK |
| `finalize_bwd.py` | ref upstream | `140.81us` | OK |
| `finalize_bwd.py` | kernel upstream | `140.46us` | OK |

## 9. Final Packaging And Onboard Script

The last step was operational cleanup:

- Promoted the hardware-verified scan-state replacement into the official
  `scan_state_bwd` path.
- Added profile passthrough to all wrappers.
- Added `test_script/run_onboard_profile.sh` as the direct onboard profile
  entrypoint.
- Removed obsolete incremental kernels after the clean hardware run.
- Repacked the local plan without AppleDouble files, `__pycache__`, `vendors`,
  or old `hw_out`.
- Replaced the standalone uploaded plan and verified the clean tree on hardware.

One important deployment bug showed up during upload: the first script assumed
`PLAN_DIR/../../../../` was the repository root. That worked only for the old
checked-in plan directory depth; a shallow standalone upload resolved that
path to `/`. OpExec then generated or searched custom-op artifacts under the
wrong `vendors` path, causing missing ACLNN headers and `libcust_opapi`.

The script now finds the repo root by walking upward to `agent/ROUTER.md` and
`easyasc/a5.py`, then changes directory to the absolute profile `OUT_DIR`
before calling `module_vs_ref.py`. That isolates generated custom-op packages
and `vendors/` under the run output directory.

## Lessons From The Story

- 2026-05-27 local simulator follow-up:
  `inverse_preprocess_bwd` was profiled with a 1-core `(B,H,C)=(1,1,4)` stress
  to expose same-core BHC reuse. Its baseline was `18977` cycles, with cube
  `FIX=72.6%`, vec `V=71.5%`, and vec `MTE2=75.0%` active/span; DBuffing
  `l1_d_score`, fusing d-score cast, consumer-first scheduling, and direct
  raw-key GM->L1 loading were all rejected because they were neutral,
  incorrect, warning-generating, or slower. A later accepted inverse pass
  DBuffed the L0C producer/final-output temporaries and changed the immediate
  `FIX -> M` L0C reuse wait into a preset DEvent, then reduced
  `mask_score_and_decay_vf` by hoisting the invariant column arange and masking
  `d_attn` once before both output products. This moved the 1-core inverse
  profile `18977 -> 18187` cycles and the default `(1,2,2)` 32-core profile
  `8610 -> 8325`, with full gdn_bwd simulator-vs-ref passing under
  `PYTHONWARNINGS=error`. `wu_bwd` then kept the useful part of the user's
  DBuff suspicion: `d_k_beta_g_ub` now has a DBuff slot matching
  the depth-2 cube->vec mutex, and the mutex is freed when finalize VF consumes
  that slot. The measurable win came from hoisting per-row VF barriers in
  `make_wu_inputs_vf` and `finalize_wu_partials_vf` to loop-end barriers, plus
  a finalize rewrite that computes `d_k_beta = d_k_beta_g * exp_g` before
  `d_g = sum(d_k_beta * k_beta)` so the old scalar post-sum multiply
  disappears. 1-core `(1,1,4)` improved `27584 -> 26752`, and `(1,1,8)`
  improved from the pre-hoist DBuff probe `49579 -> 47740`. Full gdn_bwd
  simulator-vs-ref passed. A ref-only follow-up confirmed that making the
  `scan_state_bwd -> wu_bwd` `d_value_wu`/`d_k_cumdecay` workspaces bf16 causes
  zero final-output diff across 32 randomized cases, because WU consumes both
  only as bf16 cube operands; the plan-local refs now record that contract.
  The first real kernel step updates `scan_state_bwd` to allocate those two
  outputs as bf16 GM. Nonzero `d_k_cumdecay` keeps direct `float L0C -> bf16 GM`
  stores, while `d_value_wu` is rounded into bf16 ND UB rows during the existing
  VF add wave before GM store. This is neutral inside scan-state itself on the
  1-core C=4 profile (`77938 -> 78002` cycles): MTE3 drops, but V rises for the
  new bf16 row materialization. The payoff appears in `wu_bwd`, which now
  consumes both workspaces directly as bf16 GM->L1 cube operands and deletes
  their fp32 GM->UB load plus bf16 pack/NZ staging. WU UB usage drops from the
  old `240.875 KB / 256 KB` shape to `144.875 KB / 256 KB`; 1-core `(1,1,4)`
  improves `26752 -> 21881`, and `(1,1,8)` improves `47740 -> 39797`. Full
  gdn_bwd simulator-vs-ref passes under `PYTHONWARNINGS=error`.
  `finalize_bwd` was then simplified into an autosync upper phase and a
  reset-cache `d_g` phase, sharded by `GetVecNum()` over BHC instead of funneling
  work through one subblock. A simulator bug in `bar_all()` cycle propagation
  was fixed during this pass; with that model corrected, replacing the phase
  boundary with a single `V -> MTE2` event is safe only when upper MTE3 store
  sources do not overlap the reset-phase `d_g` input buffers. The final safe
  output-ownership form keeps upper inputs as `L//2` DBuff tiles, but emits
  `d_value`, `d_key`, and `d_beta` through independent `L//4` DBuff output
  tiles. This removes the dangerous `d_v_beta_ub` / `d_k_core_ub` input-output
  alias without falling into the slow all-`L//4` load pattern. For C=8 / 2-core
  it passes all outputs at `36434` cycles with upper UB usage
  `224.375 KB / 256 KB`; MTE2/V/MTE3 active-span occupancy is
  `84.6% / 86.1% / 42.0%`. The generated-code dangling-var failure in this
  shape was closed by treating caller-side Tensor view offsets as already
  applied by `call_micro(... GetPhyAddr())`; VF formal tensors now start from
  offset zero, so the readable `L//4` view-passing source can be kept.
- 2026-05-28 local simulator follow-up:
  `scan_state_bwd` was revisited for `(B,H,C)=(1,1,8)` after the `d_g`
  handoff cleanup. The retained path first removes dead fp32 sum stores from
  the two `d_value_wu` VF finalizers: c0 and nonzero branches now materialize
  only the bf16 `d_value_wu` row, while the nonzero branch still writes the
  negated fp32 state seed and bf16 NZ `d_v_prime` bridge. That moved the trace
  `159747 -> 158723` cycles. A c0-only `d_q_core` fast path then writes the
  score matmul directly from L0C to GM because c0 needs no VF postprocess for
  `d_q`; this removes the old L0C->UB, VF copy, UB->GM detour and lands at
  `157784` cycles. Local-memory hazard checking passes for the L0C source
  reuse. Two measured-but-rejected alternatives are also recorded: moving c0
  `d_value_wu` before `d_q`/`d_k` was either wrong with shared `score_ub` or
  slower when separated (`160247`), and pre-scaling c0 `d_k`'s
  `term * exp_delta` was correct but slower (`158180`).
- `finalize_bwd` was then checked for arithmetic simplification and possible
  cube use. The upper branch's rowwise products are diagonal/paired dot
  reductions, so ordinary cube matmul would compute a full cross-row matrix and
  discard the off-diagonal work. The retained simplification is a fused upper
  VF: `d_k_beta_wu + d_k_beta_pre` now stays in registers and feeds both
  `d_beta` and `d_key`, deleting the old UB round trip between separate
  value/beta and key VFs. Default C=8 trace improves `22424 -> 21956` cycles
  with per-lane V active `13191 -> 12255`; a 2-core C=8 hazard-check run
  passes at `35966` cycles. The old `d_g` cube-reduce idea remains rejected for
  this production path: it was simulator-correct but not the final
  hardware-proven route, and the VF row/column reduce plus reverse cumsum is
  still the safer implementation. The unused `ones16` GMTensor argument from
  that cube-reduce experiment was removed from the live kernel ABI.
- A follow-up local tmp experiment tested the lower half as explicit cube
  reductions with host-provided constants. The
  first scalar-row version materialized
  `A = (d_decay_core + d_decay_pre) * decay_mask` in VF, published it to L1,
  accumulated `d_g_core @ eye + d_g_wu @ eye + ones @ A.T + neg_ones @ A`
  directly in L0C, then applied `reverse_tril` through a second matmul after an
  L0C->L1 handoff. All constants were kernel inputs and hoisted out of the BHC
  loop. Simulator and `gen_only` both passed; C=8/2-core lower-only trace was
  `22885` cycles with `max_abs_diff=1.788139e-07`.
- A `BHC_TILE=16` follow-up batches base and final reverse-cumsum as
  `[<=16,64]` matmuls and uses host-provided `selector_rows` /
  `neg_selector_rows` constants so each per-BHC `A` contributes
  `selector[t] @ A` and `neg_selector[t] @ A.T` into one selected L0C row.
  Correctness still passes (`C=8` max diff `2.682209e-07`, `BHC=32` max diff
  `3.576279e-07`) and `gen_only` succeeds, but the schedule is worse: C=8/2-core
  regresses to `50832` cycles because the single 16-row tile only gives core0
  real work, and a full two-tile `(B,H,C)=(1,4,8)` / 2-core run is `101807`
  cycles. The batching lowers MMAD active work but adds 128KB of selector L1
  footprint, output L0C->UB->GM traffic, and more serialized vec/cube waits.
- The accepted all-cube `d_g` integration uses the upstream masked decay
  outputs directly, flattens only the lower-path BHC tensors at the wrapper
  boundary, and keeps `BHC_TILE=4` so `(B,H,C)=(1,1,8)` gives both target cores
  real cube work. `finalize_bwd` now keeps the fused upper VF unchanged, then
  resets cache and runs the lower path as `mte2 -> mte1/mmad -> fix`, with
  plain DBuff L1 slots for `d_decay_core_masked` and `d_decay_pre_masked` and
  host-provided selector/identity/reverse-triangular constants. The 2-core C=8
  simulator profile improves from the previous live `35966` cycles to `27987`;
  output max diffs are `0, 0, 1.676381e-08, 1.788139e-07`, and active-span
  occupancy is `MTE2=100.0%`, `V=87.9%`, `M=73.5%`, `MTE3=56.1%`,
  `MTE1=41.6%`, `FIX=47.9%`. `gen_only`, `finalize_bwd` with both ref and
  kernel upstreams, and a small compose smoke all pass.

- Simulator trace is good at finding structure, but WebIDE hardware must close
  the loop. Several simulator-clean designs failed only on hardware.
- When hardware fails, a one-output kernel is often faster than trying to
  patch a giant fused kernel blindly.
- `DBuff` is not automatically a speedup. It helps only when the schedule uses
  the extra slot to overlap real producer/consumer beats.
- A same-core slot-reuse stress shape is mandatory for lifetime changes. Many
  single-BHC smoke tests miss pending GM-source, UB-source, or mutex release
  races.
- Warnings are not cosmetic. The most useful fixes often came from chasing
  local-memory and `auto_sync` warnings until the ownership edge was explicit.
- Control domains matter. `GetSubBlockIdx()` is vector-side control; cube/MTE2
  and L0C paths need cube-valid control and legal constant subblock ids.
- Some mathematically clean rewrites are worse schedules. The cube-reduce and
  cube reverse-cumsum experiments were correct, but the extra publish/L1/FIX
  traffic did not pay for itself.
- Packaging and cwd are part of correctness for onboard runs. Generated names,
  current working directory, and `vendors` placement can make a good kernel
  fail before it executes.
