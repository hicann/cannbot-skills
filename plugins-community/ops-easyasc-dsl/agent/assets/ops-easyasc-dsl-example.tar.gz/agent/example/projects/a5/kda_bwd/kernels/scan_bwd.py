from pathlib import Path

import torch

from scan_fused import run as run_scan_fused


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "kda_bwd_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def _child_out_dir(out_dir, name):
    if not out_dir:
        return ""
    path = Path(out_dir) / name
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def run(Aqk, v_new, do, kg, qg, w, g_last, dht, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    return run_scan_fused(
        kg,
        qg,
        w,
        g_last,
        do,
        Aqk,
        v_new,
        dht,
        simulator=simulator,
        trace=_child_trace(trace, out_dir, "scan_fused"),
        gen_only=gen_only,
        out_dir=_child_out_dir(out_dir, "scan_fused"),
        skip_compile=skip_compile,
        profile=profile,
    )


if __name__ == "__main__":
    from projects.a5.kda_bwd.refs.common import make_inputs
    from _torch_formula import L, build_saved_forward, scan_bwd as scan_ref

    tol = 4e-3
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    caches = build_saved_forward(inputs)
    g_last = caches.g_cumsum[:, L - 1::L, :, :]
    expected = scan_ref(inputs, caches)
    got = run(caches.Aqk, caches.v_new, inputs.do, caches.kg, caches.qg, caches.w, g_last, inputs.dht, simulator=True)
    # dAqk is stored un-trilled on-device (finalize_pre re-trils downstream); apply
    # the per-chunk causal mask here to match the trilled stage reference.
    Bn, Tn, HVn, _ = got[0].shape
    tri = torch.tril(torch.ones(L, L))
    daqk_masked = (got[0].float().reshape(Bn, Tn // L, L, HVn, L) * tri[None, None, :, None, :]).reshape(Bn, Tn, HVn, L)
    got = (daqk_masked, got[1], got[2], got[3])
    for got_item, exp_item in zip(got, (expected.dAqk, expected.dh, expected.dv, expected.dh0)):
        torch.testing.assert_close(got_item.float(), exp_item.float(), rtol=tol, atol=tol)
    print([tuple(item.shape) for item in got], [item.dtype for item in got])
