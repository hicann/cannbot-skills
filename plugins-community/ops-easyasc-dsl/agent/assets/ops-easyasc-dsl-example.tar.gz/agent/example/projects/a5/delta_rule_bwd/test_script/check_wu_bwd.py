"""Simulator check for delta_rule_bwd/kernels/wu_bwd.py vs its PyTorch reference.

Wiring (matching wu_bwd_ref.py __main__):
  full = make_inputs(1, 1, 2)
  scan = core_scan_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])
  ref  = subkernel(full[1], full[2], full[3], full[5], scan[2], scan[3])

Outputs:
  (d_wu, d_v_beta, d_k_beta)
"""
import sys
from pathlib import Path

import torch

# -- path setup: repo root + refs + kernels BEFORE any easyasc import --
_SCRIPT_DIR = Path(__file__).resolve().parent
_PLAN_DIR = _SCRIPT_DIR.parent
_REFS_DIR = _PLAN_DIR / "refs"
_KERNELS_DIR = _PLAN_DIR / "kernels"

def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)

_REPO_ROOT = _find_repo_root(_SCRIPT_DIR)
for _p in (str(_REPO_ROOT), str(_REFS_DIR), str(_KERNELS_DIR)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from common import core_scan_bwd, make_inputs  # noqa: E402
from wu_bwd_ref import subkernel  # noqa: E402
import wu_bwd as wu_bwd_kernel_module  # noqa: E402


def main():
    torch.manual_seed(42)
    B, H, C = 1, 1, 2
    full = make_inputs(B, H, C)

    # Upstream scan backward (same wiring as wu_bwd_ref.__main__)
    scan = core_scan_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])

    # PyTorch reference
    ref = subkernel(full[1], full[2], full[3], full[5], scan[2], scan[3])

    # DSL kernel (simulator)
    out_dir = "tmp/delta_bwd_wu"
    result = wu_bwd_kernel_module.run(
        full[1], full[2], full[3], full[5], scan[2], scan[3],
        simulator=True,
        out_dir=out_dir,
    )

    output_names = ["d_wu", "d_v_beta", "d_k_beta"]
    atol = 2e-3
    rtol = 2e-3
    all_ok = True
    for i, (name, got, exp) in enumerate(zip(output_names, result, ref)):
        err = (got.float() - exp.float()).abs().max().item()
        print("  [%s] shape=%s dtype=%s max_abs=%.3e" % (name, tuple(got.shape), got.dtype, err))
        try:
            torch.testing.assert_close(got.float(), exp.float(), atol=atol, rtol=rtol)
        except AssertionError as e:
            print("  [%s] FAIL: %s" % (name, e))
            all_ok = False

    if all_ok:
        print("wu_bwd check PASSED (atol=%.1e rtol=%.1e)" % (atol, rtol))
    else:
        print("wu_bwd check FAILED")
        sys.exit(1)


if __name__ == "__main__":
    main()
