"""Local randomized check for wu_bwd_ref.py."""

import torch

from common import core_scan_bwd, make_inputs, wu_recompute_bwd
from wu_bwd_ref import subkernel


def main():
    for seed in (23, 29):
        torch.manual_seed(seed)
        full = make_inputs(B=1, H=2, C=2)
        scan = core_scan_bwd(full[0], full[1], full[5], full[6], full[7], full[10], full[11], full[12], full[13], full[14])
        args = (full[1], full[2], full[3], full[6], full[8], scan[4], scan[5])
        actual = subkernel(*args)
        ref = wu_recompute_bwd(*args)
        for act, exp in zip(actual, ref):
            torch.testing.assert_close(act.float(), exp.float(), atol=0.0, rtol=0.0)
    print("wu_bwd: OK")


if __name__ == "__main__":
    main()
