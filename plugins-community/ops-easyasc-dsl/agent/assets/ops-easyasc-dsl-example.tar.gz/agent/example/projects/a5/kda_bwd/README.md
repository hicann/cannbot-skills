# KDA Backward (a5)

A5 project for KDA backward with a full-bf16 IO contract.

## Layout

- `refs/oracle.py` - clean end-to-end PyTorch oracle for the flat
  `[B, T, H/HV, ...]` backward contract.
- `refs/common.py` - shared pure PyTorch formulas used by the oracle and the
  staged refs.
- `refs/scan_bwd_ref.py` - saved-cache scan stage (`dAv + dhu` path).
- `refs/inverse_bwd_ref.py` - saved-cache local WY/inverse backward stage.
- `refs/finalize_bwd_ref.py` - pairwise finalize stage that reduces `HV -> H`
  and reverse-cumsums `dg`.
- `refs/compose.py` - staged composition check against the clean oracle.
- `refs/plan.md`, `refs/dag.json` - decomposition contract for kernel
  authoring.
- `kernels/` - bf16 DSL kernels; the per-stage drivers `scan_bwd` /
  `inverse_bwd` / `finalize_bwd` (and `kernel_compose.py` for the whole
  backward) are now pure plumbing with zero host math. Stage kernels:
  `scan_fused` (dAqk + dv0 matmuls + reverse state scan; `dv0` never leaves the
  chip and the chunk update runs as a single fused VF); `inverse_mm` (all five
  inverse matmuls; `d_w` crosses FIX -> UB negate/cast -> L1 on chip;
  dqg/dvbeta/dkg leave bf16 through l0c_to_ub -> MTE3 to unload the FIX pipe;
  dkbetag mm runs lookahead-2); `inverse_epilogue` (pure-VF port of the inverse
  triple loop: dq_hv/dk_hv/dv/dbeta/dg_core + k_exp; exp2 = `(g*ln2).exp()`,
  `d_g_last` folded into dg row L-1); `inverse_dainv` (`dA_inv = dv@v^T +
  d_w@k_exp^T` -> strict-lower `D_tri`; SPLITM cube->vec bridge);
  `inverse_dakk_fused` (Akk loads once, mm1's `tmp` stays on chip, mm2
  lookahead-2, final `-tril` masked in-kernel); `finalize_pre` (scales +
  q_scaled/k_scaled/kg + the tril masks M_qk/M_base/M_beta); `finalize_pair`
  (qk and kk share one `kg` load); `finalize_post` (pairwise products +
  accumulate + the per-chunk reverse cumsum of dg, fused into one reverse-order
  row loop via a running accumulator); `finalize_reduce` (HV -> H group sum of
  dq_hv/dk_hv, fp32 accumulate then bf16 store).
- `kernels/_torch_formula.py` - kernel-local bf16 stage formulas used by the
  per-kernel smoke tests.
- `check_simulator_vs_ref.py` - end-to-end simulator-vs-oracle check.
- `optimization_timeline.md` - project-local optimization and hardware-debug
  rationale for the current implementation.

## Precision contract

- Every public tensor is bf16: inputs (`q`, `k`, `v`, `g`, `beta`,
  `initial_state`, `do`, `dht`), forward-saved caches (`g_cumsum`, `Aqk`,
  `Akk`, `w`, `u`, `qg`, `kg`, `v_new`, `h`), stage handoffs, and outputs
  (`dq`, `dk`, `dv`, `dbeta`, `dg`, `dh0`).
- Refs and kernels upcast to fp32 internally and downcast once on store. The
  reverse state scan carries fp32 running state; only stores are bf16.
- Tolerance: `atol=1e-3`, `rtol=1e-3` at the default input range
  (`make_inputs` `scale=0.01`, `k_scale=0.05`). The `dk` error is bf16
  cancellation noise at ~1.5% of `|dk|max` - relative, independent of the
  input scale and flat in `T` - so the absolute floor follows `scale**3`
  (~3e-4 at `scale=0.01`). Tightening further requires lowering the value
  scales, not the contract.

## Notes

- This project targets the upstream path with `disable_recompute=True` and
  `cp_context=None`, so backward consumes forward-saved caches directly.
- The representative hardware shape is
  `B=1, T=1024, H=HV=32, K=V=128, chunk_size=64`.
- In A5-style chunk notation, that same shape is `C=16` chunks of length `64`.
- The reference path supports a tail chunk when `T % chunk_size != 0`.
- The previous mixed-precision kernel set is no longer part of the working
  tree. Use version control when historical comparison is required; current
  refs and kernels are the only maintained contract.
- The current kernels keep the v1 split and scheduling but use the full-bf16
  contract everywhere. The inverse matmul fan-out
  (`d_qg`/`d_kg`/`d_vh`, `d_v_beta`/`d_k_beta_g`) stores bf16: every consumer
  upcasts to fp32 and rounds back to bf16 at the public boundary anyway.
- Hardware note: per-token scalar bursts (`beta`, `dbeta`) are not safe to
  consume as packed physical `[1, L]` UB rows on A5. The current kernels stage
  scalar seams as `[L, C0]` aligned rows, and `inverse_dainv` explicitly
  rebuilds its 64-lane `beta` vector from aligned rows before column scaling.
  Local simulator checks alone can miss regressions in this area; keep at least
  one onboard reference-upstream sweep for `inverse_dainv` / `finalize_post`
  when touching scalar-burst paths.
- All stage glue now runs in DSL kernels: the elementwise grads, tril masks,
  exp2 scales, `cadd`/cross-row reductions, the HV -> H group reduce, and the
  per-chunk reverse cumsum of dg. `kernel_compose.run()` does only dataclass
  plumbing, the cheap `.permute()/.reshape()` GM-layout prep, and the `g_last`
  chunk-boundary slice. The forward-cache recompute (`build_saved_forward`) is
  test-harness glue only - the deployed path consumes forward-saved caches
  directly (see the `disable_recompute=True` note above), so it stays on host.
- 1-core profile (B=1 H=1 HV=1 T=512, cycles): scan_fused 60,049
  (V-bound scan; MTE2 73.2%), inverse_dakk 11,789 (MTE2 99.8%), inverse_mm
  55,924 (MTE2 93.6%), finalize_pair 45,207 (FIX 99.9%). Stage sum 172,969
  vs 213,771 for the v1 split set (-19.1%).

## Verification

Use `tools/run_preferred_simulator.py` for simulator-side checks. On Windows
hosts, it prefers WSL's `torch210npu` environment when available; on Linux/WSL
it stays local.

```bash
conda run -n torch210npu python tools/run_preferred_simulator.py projects/a5/kda_bwd/refs/compose.py
for f in projects/a5/kda_bwd/refs/*_check.py; do
  conda run -n torch210npu python tools/run_preferred_simulator.py "$f"
done

# kernels (simulator)
for f in scan_fused scan_bwd inverse_mm inverse_epilogue inverse_dainv \
         inverse_dakk_fused inverse_bwd finalize_pre finalize_pair \
         finalize_post finalize_reduce finalize_bwd; do
  conda run -n torch210npu python tools/run_preferred_simulator.py projects/a5/kda_bwd/kernels/$f.py
done
conda run -n torch210npu python tools/run_preferred_simulator.py projects/a5/kda_bwd/check_simulator_vs_ref.py

# 1-core pipe occupancy / makespan
conda run -n torch210npu python tools/run_preferred_simulator.py projects/a5/kda_bwd/profile_pipe_occupancy.py --core-count 1

# per-module simulator / onboard isolation
conda run -n torch210npu python tools/run_preferred_simulator.py projects/a5/kda_bwd/test_script/module_vs_ref.py --module leaf --upstream ref
MODULES=leaf UPSTREAM=ref projects/a5/kda_bwd/test_script/run_onboard_profile_each_module.sh
```
