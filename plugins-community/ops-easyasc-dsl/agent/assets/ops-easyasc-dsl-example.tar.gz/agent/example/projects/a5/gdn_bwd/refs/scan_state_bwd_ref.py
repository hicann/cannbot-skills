"""Pure PyTorch reference for the split scan recurrent state stage."""

from common import make_inputs, scan_state_bwd
from scan_local_bwd_ref import subkernel as scan_local_bwd


def subkernel(query, key, grad_output, g_cumsum, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, k_weighted_history, d_v_attn_tmp, exp_delta_history=None):
    return scan_state_bwd(
        query, key, grad_output, g_cumsum, k_cumdecay, state_after_history,
        grad_final_state, d_score_tmp, v_new_history, k_weighted_history,
        d_v_attn_tmp, exp_delta_history,
    )


if __name__ == "__main__":
    args = make_inputs()
    local = scan_local_bwd(args[0], args[1], args[5], args[7], args[12])
    result = subkernel(args[0], args[1], args[5], args[6], args[10], args[11], args[14], local[0], args[12], args[13], local[1], args[15])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
