"""dA_inv -> D_tri stage (formerly host glue inside inverse_bwd).

Computes the strictly-lower D_tri that feeds `inverse_dakk_fused`:

    dA_inv = dv @ v^T + d_w @ k_exp^T           # [L, L]   (d_w = -d_vh)
    D_tri  = tril(dA_inv * beta[None, :], -1)   # column-scaled, strict lower

`d_w` is the already-negated inverse_mm output, so the two cube products land
in separate L0C tiles and are *added* in the masking VF -- no operand negate
and no vec->cube bridge. Topology: cube (2 mm) -> CvMutex -> vec (add + beta
col-scale + strict-lower mask + bf16 cast).
"""

import builtins
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _layout import flat_lvd, to_lvd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
L = 64
D = 128
HALF_L = L // 2
SCALAR_PACK_BF16 = DT.bfloat16.C0
SCALAR_PACK_F32 = DT.float.C0
# dv/v read strided from the frozen BTHVD seams; beta read strided bf16 from the
# frozen BTHV primary (upcast to fp32 implicitly on the Reg load). d_w/k_exp and
# the dtri output stay GM-native (internal to the inverse stage). Var args B/HV/C.
SHAPE_BINDINGS = {
    0: [0, None, 1, None],     # dv      [B, T, HV, D]   (strided BTHVD)
    1: [0, None, 1, None],     # v       [B, T, HV, D]
    2: [0, 1, 2, None, None],  # d_w     [B, HV, C, L, D]  internal
    3: [0, 1, 2, None, None],  # k_exp   [B, HV, C, L, D]  internal
    4: [0, None, 1],           # beta    [B, T, HV]      (strided BTHV, bf16)
    5: [0, 1, 2, None, None],  # dtri    [B, HV, C, L, L]  internal
}


@vf()
def dtri_mask_vf(
    dainv_a_ub: Tensor,
    dainv_b_ub: Tensor,
    beta_h_ub: Tensor,
    beta_f_ub: Tensor,
    dtri_ub: Tensor,
    row_begin: Var,
    rows: Var,
):
    cols = Reg(DT.int)
    a = Reg(DT.float)
    b = Reg(DT.float)
    beta_h = Reg(DT.bfloat16)
    beta_idx_i32 = Reg(DT.int)
    beta_idx_u32 = beta_idx_i32.reinterpret(DT.uint32)
    betav = Reg(DT.float)
    out = Reg(DT.float)
    zero = Reg(DT.float)
    mask = MaskReg(DT.int, init_mode=MaskType.NONE)

    zero <<= 0.0
    for c in range(L):
        beta_h <<= beta_h_ub[c:c + 1, 0:1].single()
        betav <<= beta_h.cast()
        beta_f_ub[c:c + 1, 0:1] <<= betav.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)
    beta_idx_i32.arange(0)
    beta_idx_i32 <<= beta_idx_i32 * SCALAR_PACK_F32
    betav.ub_gather(beta_f_ub, beta_idx_u32)
    for r in range(rows):
        rg = Var(row_begin + r)
        cols.arange(0)
        a <<= dainv_a_ub[r:r + 1, 0:L]
        b <<= dainv_b_ub[r:r + 1, 0:L]
        a <<= a + b
        a <<= a * betav
        compare(mask, cols, rg, CompareMode.LT)
        select(out, a, zero, mask=mask)
        dtri_ub[r:r + 1, 0:L] <<= out
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def inverse_dainv_kernel(
    dv: GMTensor,
    v: GMTensor,
    d_w: GMTensor,
    k_exp: GMTensor,
    beta: GMTensor,
    dtri: GMTensor,
    B: Var,
    HV: Var,
    C: Var,
):
    dainv_mutex = CvMutex(0, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1_dv = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_v = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_dw = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_kexp = DBuff(DT.bfloat16, [L, D], Position.L1)
    l0c_a = DBuff(DT.float, [L, L], Position.L0C)
    l0c_b = DBuff(DT.float, [L, L], Position.L0C)
    dainv_a_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    dainv_b_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    beta_h_ub = DBuff(DT.bfloat16, [L, SCALAR_PACK_BF16], Position.UB)
    beta_f_ub = DBuff(DT.float, [L, SCALAR_PACK_F32], Position.UB)
    dtri_ub = DBuff(DT.bfloat16, [HALF_L, L], Position.UB)

    work_count = Var(B * HV * C)
    work_per_core = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_core * GetCubeIdx())
    work_end = Min(work_begin + work_per_core, work_count)
    row_begin_l = Var(GetSubBlockIdx() * HALF_L)
    row_end_l = Var(row_begin_l + HALF_L)
    slot = Var(0)

    with auto_sync():
        for work in range(work_begin, work_end):
            c_idx = Var(work % C)
            bhv = Var(work / C)
            hv_idx = Var(bhv % HV)
            b_idx = Var(bhv / HV)
            row0 = Var(c_idx * L)
            row1 = Var(row0 + L)

            # dv/v strided from frozen BTHVD (explicit HV*D pitch); d_w/k_exp stay
            # GM-native (internal); beta strided bf16 from frozen BTHV, upcast to
            # fp32 implicitly on the Reg load inside dtri_mask_vf.
            gm_to_l1_nd2nz(l1_dv[slot][0:L, 0:D], dv[b_idx, row0:row1, hv_idx, 0:D], L, D, HV * D, L)
            gm_to_l1_nd2nz(l1_v[slot][0:L, 0:D], v[b_idx, row0:row1, hv_idx, 0:D], L, D, HV * D, L)
            l1_dw[slot][0:L, 0:D] <<= d_w[b_idx, hv_idx, c_idx, 0:L, 0:D]
            l1_kexp[slot][0:L, 0:D] <<= k_exp[b_idx, hv_idx, c_idx, 0:L, 0:D]
            gm_to_ub_pad(beta_h_ub[slot][0:L, 0:1], beta[b_idx, row0:row1, hv_idx], L, 1, HV - 1, 0)

            matmul(l0c_a[slot], l1_dv[slot], l1_v[slot].T, m=L, n=L, k=D, splitn=L)
            matmul(l0c_b[slot], l1_dw[slot], l1_kexp[slot].T, m=L, n=L, k=D, splitn=L)

            dainv_mutex.lock()
            l0c_to_ub(dainv_a_ub[slot], l0c_a[slot], M=L, N=L, N_dst=L, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
            l0c_to_ub(dainv_b_ub[slot], l0c_b[slot], M=L, N=L, N_dst=L, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
            dainv_mutex.ready()
            dainv_mutex.wait()
            dtri_mask_vf(dainv_a_ub[slot], dainv_b_ub[slot], beta_h_ub[slot], beta_f_ub[slot], dtri_ub[slot], row_begin_l, Var(HALF_L))
            dainv_mutex.free()
            dtri[b_idx, hv_idx, c_idx, row_begin_l:row_end_l, 0:L] <<= dtri_ub[slot][0:HALF_L, 0:L]
            slot += 1

    return dtri


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(dv, v, d_w, k_exp, beta, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    # dv/v strided from frozen BTHVD [B, T, HV, D] bf16; beta strided from frozen
    # BTHV [B, T, HV] bf16; d_w/k_exp GM-native [B, HV, C, L, D] bf16 (internal).
    B = int(dv.shape[0])
    T = int(dv.shape[1])
    HV = int(dv.shape[2])
    C = T // L
    for name, tensor in (("dv", dv), ("v", v), ("d_w", d_w), ("k_exp", k_exp)):
        if tensor.dtype != torch.bfloat16:
            raise TypeError(f"{name} must be bfloat16, got {tensor.dtype}")

    out = torch.empty((B, HV, C, L, L), dtype=torch.bfloat16, device=dv.device)
    previous_config = getattr(inverse_dainv_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "inverse_dainv")
    if simulator:
        inverse_dainv_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            inverse_dainv_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            dv, v, d_w, k_exp, beta, out, B, HV, C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(inverse_dainv_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                inverse_dainv_kernel._simulator_config = previous_config
    if gen_only:
        return result
    # Raw GM output [B, HV, C, L, L] bf16; the stage driver reshapes to
    # [B, HV, T, L] for inverse_dakk, the story flattens to BTHVL.
    return result


if __name__ == "__main__":
    from projects.a5.kda_bwd.refs.common import make_inputs
    from _torch_formula import build_saved_forward, scan_bwd, inverse_qkgw_only

    tol = 6e-3
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    caches = build_saved_forward(inputs)
    scan = scan_bwd(inputs, caches)
    _d_qg, _d_kg, d_vh = inverse_qkgw_only(inputs, caches, scan)
    d_w = -d_vh

    B, T, H, Kd = inputs.q.shape
    HV = inputs.v.shape[2]
    G = HV // H
    kf, gf = inputs.k.float(), caches.g_cumsum.float()
    k_exp = torch.empty(B, T, HV, D)
    for hv in builtins.range(HV):
        k_exp[:, :, hv] = kf[:, :, hv // G] * torch.exp2(gf[:, :, hv])

    # dv/v/beta raw frozen (strided on-device); d_w/k_exp stay GM-native internal.
    got = flat_lvd(run(
        scan.dv, inputs.v, to_lvd(d_w.to(torch.bfloat16)),
        to_lvd(k_exp.to(torch.bfloat16)), inputs.beta,
        simulator=True,
    ))

    bf = lambda x: x.to(torch.bfloat16).float()
    vf_ = inputs.v.float()
    betaf = inputs.beta.float()
    exp = torch.zeros(B, T, HV, L)
    for b in builtins.range(B):
        for c in builtins.range(T // L):
            s, e = c * L, c * L + L
            for hv in builtins.range(HV):
                dvb = scan.dv[b, s:e, hv].float()
                dA = bf(dvb) @ bf(vf_[b, s:e, hv]).T + bf(d_w[b, s:e, hv]) @ bf(k_exp[b, s:e, hv]).T
                exp[b, s:e, hv] = torch.tril(dA * betaf[b, s:e, hv][None, :], diagonal=-1)
    torch.testing.assert_close(got.float(), exp, rtol=tol, atol=tol)
    print(f"dtri: max_abs={(got.float() - exp).abs().max().item():.3e} OK", tuple(got.shape), got.dtype)
