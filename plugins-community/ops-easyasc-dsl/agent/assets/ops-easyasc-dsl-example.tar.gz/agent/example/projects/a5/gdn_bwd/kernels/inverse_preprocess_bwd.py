import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _torch_formula import L, D, inverse_preprocess_bwd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
HALF_L = L // 2
BF16_C0 = 16
SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None],
    2: [0, 1, 2, None, None],
    3: [0, 1, 2, None, None],
    4: [0, 1, 2, None, None],
    5: [0, 1, 2, None, None],
    6: [0, 1, 2, None, None],
    7: [0, 1, 2, None, None],
    8: [0, 1, 2, None, None],
}


@vf()
def cast_key_beta_and_w_vf(
    key_bf16_ub: Tensor,
    beta_ub: Tensor,
    key_nz_ub: Tensor,
    k_beta_nz_ub: Tensor,
    rows: Var,
):
    beta_reg = Reg(DT.float)
    key_row = Reg(DT.bfloat16)
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)

    for r in range(rows):
        beta_reg <<= beta_ub[0:1, r:r + 1].single()

        key_row <<= key_bf16_ub[r:r + 1, 0:D]
        reg_to_ub(key_nz_ub[r * BF16_C0], key_row, rows)

        row_lo <<= key_bf16_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * beta_reg
        row_hi <<= key_bf16_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * beta_reg
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_beta_nz_ub[r * BF16_C0], row_bf16, rows)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def cast_l_rows_float_to_bf16_vf(src_ub: Tensor, dst_ub: Tensor, rows: Var):
    row_float = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)

    for r in range(rows):
        row_float <<= src_ub[r:r + 1, 0:L]
        lo_bf16 <<= row_float.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, dummy_bf16)
        dst_ub[r:r + 1, 0:L] <<= row_bf16
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def cast_l_rows_float_to_bf16_nz_vf(src_ub: Tensor, dst_nz_ub: Tensor, rows: Var):
    row_float = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    bf16_lowhalf = MaskReg(DT.bfloat16, init_mode=MaskType.LOWHALF)

    for r in range(rows):
        row_float <<= src_ub[r:r + 1, 0:L]
        lo_bf16 <<= row_float.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, dummy_bf16)
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, rows, mask=bf16_lowhalf)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def mask_score_and_decay_vf(
    d_attn_ub: Tensor,
    preprocess_score_ub: Tensor,
    decay_mask_ub: Tensor,
    d_score_ub: Tensor,
    d_decay_ub: Tensor,
    d_decay_masked_ub: Tensor,
    row_begin: Var,
    rows: Var,
):
    cols = Reg(DT.int)
    d_attn_row = Reg(DT.float)
    score_row = Reg(DT.float)
    decay_row = Reg(DT.float)
    out_score = Reg(DT.float)
    out_decay = Reg(DT.float)
    selected_score = Reg(DT.float)
    selected_decay = Reg(DT.float)
    zero = Reg(DT.float)
    strict_lower_mask = MaskReg(DT.int, init_mode=MaskType.NONE)

    zero <<= 0.0

    for r in range(rows):
        abs_r = Var(row_begin + r)
        cols.arange(0)
        d_attn_row <<= d_attn_ub[r:r + 1, 0:L]
        score_row <<= preprocess_score_ub[r:r + 1, 0:L]
        decay_row <<= decay_mask_ub[r:r + 1, 0:L]

        out_score <<= d_attn_row * decay_row
        out_score <<= out_score * -1.0
        out_decay <<= d_attn_row * score_row
        out_decay <<= out_decay * -1.0

        compare(strict_lower_mask, cols, abs_r, CompareMode.LT)
        select(selected_score, out_score, zero, mask=strict_lower_mask)
        select(selected_decay, out_decay, zero, mask=strict_lower_mask)
        d_score_ub[r:r + 1, 0:L] <<= selected_score
        d_decay_ub[r:r + 1, 0:L] <<= selected_decay
        selected_decay <<= selected_decay * decay_row
        d_decay_masked_ub[r:r + 1, 0:L] <<= selected_decay
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def inverse_preprocess_bwd_kernel(
    key: GMTensor,
    beta: GMTensor,
    decay_mask: GMTensor,
    wu_attn_bf16: GMTensor,
    d_wu: GMTensor,
    d_k_pre: GMTensor,
    d_k_beta_pre: GMTensor,
    d_decay_pre: GMTensor,
    d_decay_pre_masked: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    key_mutex = VcMutex(
        0,
        depth=2,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    cvmutex = CvMutex(1, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    score_mutex = VcMutex(
        2,
        depth=1,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    fix_to_mte1 = SEvent(Pipe.FIX, Pipe.MTE1)
    fix_to_m = SEvent(Pipe.FIX, Pipe.M, name="inverse_l0c_reuse_ready")

    l1_key_buf = TBuff(DT.bfloat16, [L, D], Position.L1)
    l1_k_beta_buf = TBuff(DT.bfloat16, [L, D], Position.L1)
    l1_w_buf = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_d_wu_buf = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_tmp_buf = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_d_score_buf = DBuff(DT.bfloat16, [L, L], Position.L1)

    l0c_preprocess_score_buf = DBuff(DT.float, [L, L], Position.L0C)
    l0c_tmp_buf = DBuff(DT.float, [L, L], Position.L0C)
    l0c_d_attn_buf = DBuff(DT.float, [L, L], Position.L0C)
    l0c_d_k_buf = DBuff(DT.float, [L, D], Position.L0C)
    l0c_d_k_beta_buf = DBuff(DT.float, [L, D], Position.L0C)

    key_bf16_ub_buf = TBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    beta_ub_buf = TBuff(DT.float, [1, HALF_L], Position.UB)
    key_nz_ub_buf = TBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    k_beta_nz_ub_buf = TBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    d_attn_ub_buf = TBuff(DT.float, [HALF_L, L], Position.UB)
    preprocess_score_ub_buf = TBuff(DT.float, [HALF_L, L], Position.UB)
    decay_mask_ub_buf = TBuff(DT.float, [HALF_L, L], Position.UB)
    d_score_ub = Tensor(DT.float, [HALF_L, L], Position.UB)
    d_score_nz_ub_buf = DBuff(DT.bfloat16, [HALF_L, L], Position.UB)
    d_decay_ub_buf = DBuff(DT.float, [HALF_L, L], Position.UB)
    d_decay_masked_ub_buf = DBuff(DT.float, [HALF_L, L], Position.UB)

    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    if bhc_begin < bhc_end:
        with auto_sync():
            for pipe_bhc in range(bhc_begin, bhc_end + 1):
                row_begin = Var(GetSubBlockIdx() * HALF_L)
                row_end = Min(row_begin + HALF_L, L)
                rows_this = Var(row_end - row_begin)

                if pipe_bhc < bhc_end:
                    c_idx_next = Var(pipe_bhc // (B * H))
                    bh_remainder_next = Var(pipe_bhc % (B * H))
                    b_idx_next = Var(bh_remainder_next // H)
                    h_idx_next = Var(bh_remainder_next % H)

                    l1_key_next = l1_key_buf[pipe_bhc]
                    l1_k_beta_next = l1_k_beta_buf[pipe_bhc]
                    l1_w_next = l1_w_buf[pipe_bhc]
                    l1_d_wu_next = l1_d_wu_buf[pipe_bhc]
                    l1_tmp_next = l1_tmp_buf[pipe_bhc]
                    key_bf16_ub_next = key_bf16_ub_buf[pipe_bhc]
                    beta_ub_next = beta_ub_buf[pipe_bhc]
                    key_nz_ub_next = key_nz_ub_buf[pipe_bhc]
                    k_beta_nz_ub_next = k_beta_nz_ub_buf[pipe_bhc]
                    decay_mask_ub_next = decay_mask_ub_buf[pipe_bhc]
                    d_attn_ub_next = d_attn_ub_buf[pipe_bhc]
                    preprocess_score_ub_next = preprocess_score_ub_buf[pipe_bhc]
                    l0c_preprocess_score_next = l0c_preprocess_score_buf[pipe_bhc]
                    l0c_tmp_next = l0c_tmp_buf[pipe_bhc]
                    l0c_d_attn_next = l0c_d_attn_buf[pipe_bhc]
                    key_mutex.lock()
                    key_bf16_ub_next[0:rows_this, 0:D] <<= key[
                        b_idx_next, h_idx_next, c_idx_next, row_begin:row_end, 0:D
                    ]
                    beta_ub_next[0:1, 0:rows_this] <<= beta[
                        b_idx_next, h_idx_next, c_idx_next, row_begin:row_end
                    ]
                    cast_key_beta_and_w_vf(
                        key_bf16_ub_next,
                        beta_ub_next,
                        key_nz_ub_next,
                        k_beta_nz_ub_next,
                        rows_this,
                    )
                    l1_key_next[row_begin:row_end, 0:D] <<= key_nz_ub_next[0:rows_this, 0:D].nz()
                    l1_k_beta_next[row_begin:row_end, 0:D] <<= k_beta_nz_ub_next[0:rows_this, 0:D].nz()
                    key_mutex.ready()
                    decay_mask_ub_next[0:rows_this, 0:L] <<= decay_mask[
                        b_idx_next, h_idx_next, c_idx_next, row_begin:row_end, 0:L
                    ]

                    l1_w_next[0:L, 0:L] <<= wu_attn_bf16[b_idx_next, h_idx_next, c_idx_next, 0:L, 0:L]
                    l1_d_wu_next[0:L, 0:L] <<= d_wu[b_idx_next, h_idx_next, c_idx_next, 0:L, 0:L]
                    key_mutex.wait()
                    matmul(l0c_preprocess_score_next, l1_k_beta_next, l1_key_next, m=L, n=L, k=D, splitn=L)
                    matmul(l0c_tmp_next, l1_w_next.T, l1_d_wu_next.T, m=L, n=L, k=L, splitn=L)
                    l1_tmp_next <<= l0c_tmp_next
                    fix_to_mte1.set()
                    fix_to_mte1.wait()
                    matmul(l0c_d_attn_next, l1_tmp_next, l1_w_next, m=L, n=L, k=L, splitn=L)

                    cvmutex.lock()
                    d_attn_ub_next <<= l0c_d_attn_next
                    preprocess_score_ub_next <<= l0c_preprocess_score_next
                    fix_to_m.set()
                    fix_to_m.wait()
                    cvmutex.ready()

                if pipe_bhc > bhc_begin:
                    bhc = Var(pipe_bhc - 1)
                    c_idx = Var(bhc // (B * H))
                    bh_remainder = Var(bhc % (B * H))
                    b_idx = Var(bh_remainder // H)
                    h_idx = Var(bh_remainder % H)

                    l1_key = l1_key_buf[bhc]
                    l1_k_beta = l1_k_beta_buf[bhc]
                    l1_d_score = l1_d_score_buf[bhc]
                    d_attn_ub = d_attn_ub_buf[bhc]
                    preprocess_score_ub = preprocess_score_ub_buf[bhc]
                    decay_mask_ub = decay_mask_ub_buf[bhc]
                    d_score_nz_ub = d_score_nz_ub_buf[bhc]
                    d_decay_ub = d_decay_ub_buf[bhc]
                    d_decay_masked_ub = d_decay_masked_ub_buf[bhc]
                    l0c_d_k = l0c_d_k_buf[bhc]
                    l0c_d_k_beta = l0c_d_k_beta_buf[bhc]

                    score_mutex.lock()
                    cvmutex.wait()
                    mask_score_and_decay_vf(
                        d_attn_ub,
                        preprocess_score_ub,
                        decay_mask_ub,
                        d_score_ub,
                        d_decay_ub,
                        d_decay_masked_ub,
                        row_begin,
                        rows_this,
                    )
                    cvmutex.free()
                    cast_l_rows_float_to_bf16_nz_vf(d_score_ub, d_score_nz_ub, rows_this)
                    l1_d_score[row_begin:row_end, 0:L] <<= d_score_nz_ub[0:rows_this, 0:L].nz()
                    score_mutex.ready()
                    d_decay_pre[b_idx, h_idx, c_idx, row_begin:row_end, 0:L] <<= d_decay_ub[0:rows_this, 0:L]
                    d_decay_pre_masked[b_idx, h_idx, c_idx, row_begin:row_end, 0:L] <<= d_decay_masked_ub[0:rows_this, 0:L]

                    score_mutex.wait()
                    matmul(l0c_d_k_beta, l1_d_score, l1_key.T, m=L, n=D, k=L, splitn=D)
                    matmul(l0c_d_k, l1_d_score.T, l1_k_beta.T, m=L, n=D, k=L, splitn=D)
                    score_mutex.free()
                    key_mutex.free()
                    d_k_beta_pre[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_d_k_beta
                    d_k_pre[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_d_k
    return d_k_pre, d_k_beta_pre, d_decay_pre, d_decay_pre_masked


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "gdn_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(key, beta, decay_mask, wu_attn_bf16, d_wu, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    B = int(key.shape[0])
    H = int(key.shape[1])
    C = int(key.shape[2])
    device = key.device
    outputs = (
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, L), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, L), dtype=torch.float32, device=device),
    )
    trace_path = _trace_path(trace, out_dir, "inverse_preprocess_bwd")
    previous_config = getattr(inverse_preprocess_bwd_kernel, "_simulator_config", None)
    if simulator:
        inverse_preprocess_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            inverse_preprocess_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            key, beta, decay_mask, wu_attn_bf16, d_wu,
            outputs[0], outputs[1], outputs[2], outputs[3], B, H, C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(inverse_preprocess_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                inverse_preprocess_bwd_kernel._simulator_config = previous_config
    return result


if __name__ == "__main__":
    torch.manual_seed(42)
    B, H, C = 1, 1, 1
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    decay_mask = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.05
    wu_attn_bf16 = (torch.eye(L).reshape(1, 1, 1, L, L).repeat(B, H, C, 1, 1)).to(torch.bfloat16)
    d_wu = (torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    result = run(key, beta, decay_mask, wu_attn_bf16, d_wu)
    expected = inverse_preprocess_bwd(key, beta, decay_mask, wu_attn_bf16, d_wu)
    for got, ref in zip(result, expected):
        torch.testing.assert_close(got, ref, rtol=5e-4, atol=5e-4)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
