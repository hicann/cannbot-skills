"""delta_rule forward full 4-step path correctness check (simulator).

Runs the DSL kernel pipeline (delta_preprocess -> tril_inverse64 ->
delta_recompute_wu -> chunk_delta sub1/sub2) and compares the result against
both the kernel-aligned PyTorch path and the fp32 ground truth.

Examples:
  python projects/a5/delta_rule_fwd/test_script/check_full_vs_ref.py
  python projects/a5/delta_rule_fwd/test_script/check_full_vs_ref.py --B=1 --H=2 --C=4
"""

import os
import sys
from pathlib import Path

import torch

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from projects.a5.delta_rule_fwd.delta_rule_full import (  # noqa: E402
    ATOL, RTOL, make_inputs,
    delta_rule_full_original_chunked,
    delta_full_chunked,
    delta_full_chunked_kernels,
)


def _arg_int(name, default):
    env_value = os.environ.get(name)
    if env_value is not None:
        return int(env_value)
    prefix = "--" + name + "="
    for arg in sys.argv[1:]:
        if arg.startswith(prefix):
            return int(arg.split("=", 1)[1])
    return default


def _check(label, got, ref):
    got_f = got.float()
    ref_f = ref.float()
    if not torch.isfinite(got_f).all() or not torch.isfinite(ref_f).all():
        print(f"{label}: NON-FINITE", file=sys.stderr)
        return False
    diff = (got_f - ref_f).abs()
    max_abs = float(diff.max())
    max_rel = float((diff / ref_f.abs().clamp_min(1e-12)).max())
    ok = bool(torch.allclose(got_f, ref_f, atol=ATOL, rtol=RTOL))
    print(f"  {label}: max_abs={max_abs:.3e} max_rel={max_rel:.3e} {'OK' if ok else 'FAIL'}")
    return ok


def main():
    B = _arg_int("B", 1)
    H = _arg_int("H", 2)
    C = _arg_int("C", 4)
    seed = _arg_int("SEED", 7)
    torch.manual_seed(seed)
    args = make_inputs(B=B, H=H, C=C)

    orig_core, orig_state = delta_rule_full_original_chunked(*args, scale=1.0)
    ref_core, ref_state = delta_full_chunked(*args, scale=1.0)
    got_core, got_state = delta_full_chunked_kernels(*args, scale=1.0)

    print(f"delta_rule full path B={B} H={H} C={C} seed={seed}")
    print("kernel path vs kernel-aligned PyTorch path:")
    ok = _check("core_attn_out", got_core, ref_core)
    ok = _check("final_state", got_state, ref_state) and ok
    print("kernel path vs fp32 ground truth:")
    ok = _check("core_attn_out", got_core, orig_core) and ok
    ok = _check("final_state", got_state, orig_state) and ok

    if ok:
        print("delta_rule full-path simulator-vs-ref OK")
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
