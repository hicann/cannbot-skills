# GDN Backward

Canonical A5 implementation for `gdn_bwd_full`.

## Layout

- `gdn_bwd_full.py`: PyTorch golden/reference formula.
- `kernels/`: production DSL kernels and Python wrappers.
- `refs/`: plan-local PyTorch references, oracle, DAG, and contract notes.
- `test_script/`: module-vs-ref and onboard profile scripts.
- `check_simulator_vs_ref.py`: end-to-end simulator/onboard smoke entry.
- `optimization_timeline.md`: optimization and hardware-debug history.

The former `plan1` implementation has been promoted into this root layout. The
older candidate plans were retired so this directory has a single maintained
kernel path.

## Quick Checks

```bash
python projects/a5/gdn_bwd/test_script/module_vs_ref.py --module finalize_bwd --B 1 --H 1 --C 8 --stop-on-fail
python projects/a5/gdn_bwd/test_script/module_vs_ref.py --module compose --B 1 --H 1 --C 2 --stop-on-fail
```
