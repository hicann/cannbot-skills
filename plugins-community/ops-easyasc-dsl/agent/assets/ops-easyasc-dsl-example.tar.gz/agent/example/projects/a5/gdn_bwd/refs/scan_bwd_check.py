"""Local randomized check for scan_bwd_ref.py."""

import torch

from common import core_scan_bwd, make_inputs
from scan_bwd_ref import subkernel


def expected(*args):
    return core_scan_bwd(*args)


def main():
    for seed in (11, 17):
        torch.manual_seed(seed)
        full = make_inputs(B=1, H=2, C=2)
        args = (full[0], full[1], full[5], full[6], full[7], full[10], full[11], full[12], full[13], full[14])
        actual = subkernel(*args)
        ref = expected(*args)
        for act, exp in zip(actual, ref):
            torch.testing.assert_close(act.float(), exp.float(), atol=0.0, rtol=0.0)
    print("scan_bwd: OK")


if __name__ == "__main__":
    main()
