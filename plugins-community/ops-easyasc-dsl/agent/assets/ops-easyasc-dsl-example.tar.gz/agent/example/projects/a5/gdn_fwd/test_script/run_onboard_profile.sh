#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

find_repo_root() {
  local dir="${PROJECT_DIR}"
  while [[ "${dir}" != "/" ]]; do
    if [[ -f "${dir}/agent/ROUTER.md" && -f "${dir}/easyasc/a5.py" ]]; then
      printf '%s\n' "${dir}"
      return 0
    fi
    dir="$(dirname "${dir}")"
  done
  return 1
}

REPO_ROOT="$(find_repo_root)"

VARIANT="${VARIANT:-both}"
SEED="${SEED:-20260528}"
B="${B:-1}"
H="${H:-32}"
C="${C:-16}"
OUT_DIR="${OUT_DIR:-${PROJECT_DIR}/hw_out/onboard_profile_${VARIANT}_b${B}h${H}c${C}_$(date +%Y%m%d_%H%M%S)}"

if [[ -n "${PYTHON_CMD:-}" ]]; then
  read -r -a PYTHON_RUNNER <<< "${PYTHON_CMD}"
elif command -v conda >/dev/null 2>&1 && conda env list | grep -qE '^torch210npu[[:space:]]'; then
  PYTHON_RUNNER=(conda run -n torch210npu python)
else
  PYTHON_RUNNER=(python)
fi

mkdir -p "${OUT_DIR}"
OUT_DIR="$(cd "${OUT_DIR}" && pwd)"
export PYTHONPATH="${REPO_ROOT}${PYTHONPATH:+:${PYTHONPATH}}"

# Keep generated custom-op packages under this run directory. OpExec defaults
# custom_op_path to the current working directory for onboard runs.
cd "${OUT_DIR}"

echo "gdn_fwd full onboard profile"
echo "  variant=${VARIANT} seed=${SEED} shape=(B=${B},H=${H},C=${C})"
echo "  repo_root=${REPO_ROOT}"
echo "  out_dir=${OUT_DIR}"
echo "  workdir=$(pwd)"
echo "  python=${PYTHON_RUNNER[*]}"

EXTRA_ARGS=("$@")

run_variant() {
  local variant="$1"
  local variant_out="${OUT_DIR}/${variant}"
  local python_args=(
    --check-kernels
    --on-npu
    --seed "${SEED}"
    --B "${B}"
    --H "${H}"
    --C "${C}"
    --out-dir "${variant_out}"
  )

  case "${variant}" in
    plain)
      ;;
    state_history)
      python_args+=(--state-after-history)
      ;;
    *)
      echo "Unknown gdn_fwd onboard variant: ${variant}. Use plain, state_history, or both." >&2
      return 2
      ;;
  esac

  if (( ${#EXTRA_ARGS[@]} )); then
    python_args+=("${EXTRA_ARGS[@]}")
  fi

  mkdir -p "${variant_out}"
  echo "=== gdn_fwd onboard ${variant} ==="
  "${PYTHON_RUNNER[@]}" "${PROJECT_DIR}/gdn_full.py" "${python_args[@]}"
}

case "${VARIANT}" in
  plain|state_history)
    run_variant "${VARIANT}"
    ;;
  both)
    run_variant plain
    run_variant state_history
    ;;
  *)
    echo "Unknown VARIANT=${VARIANT}. Use plain, state_history, or both." >&2
    exit 2
    ;;
esac
