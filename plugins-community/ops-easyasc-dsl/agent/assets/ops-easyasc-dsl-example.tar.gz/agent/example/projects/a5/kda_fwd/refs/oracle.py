"""End-to-end PyTorch oracle for KDA forward.

This mirrors `fla/ops/kda/naive.py::naive_recurrent_kda` for the fixed-length
path. Chunked helpers default to `chunk_size=64`, matching the upstream KDA
default, but accept other chunk lengths for reference checks. Inputs use the
upstream public layout:

  q, k:  [B, T, H, K]
  v:     [B, T, HV, V]
  g:     [B, T, HV, K]  natural-log gate increments
  beta:  [B, T, HV]

The returned output is cast back to `v.dtype`; the final state remains fp32,
matching the optimized chunk path.
"""

import torch


def oracle(q, k, v, g, beta, initial_state=None):
    """Return the original fixed-length PyTorch result for the plan inputs."""
    return oracle_full(q, k, v, g, beta, initial_state=initial_state)


def oracle_full(q, k, v, g, beta, scale=None, initial_state=None, output_final_state=True):
    dtype = v.dtype
    B, T, H, K = q.shape
    HV = v.shape[2]
    V = v.shape[-1]
    G = HV // H
    if scale is None:
        scale = K ** -0.5

    qf = q.float().repeat_interleave(G, dim=2) * scale
    kf = k.float().repeat_interleave(G, dim=2)
    vf = v.float()
    gf = g.float()
    betaf = beta.float()

    state = torch.zeros(B, HV, K, V, dtype=torch.float32, device=q.device)
    if initial_state is not None:
        state = state + initial_state.float()

    out = torch.zeros_like(vf)
    for t in range(T):
        q_t = qf[:, t]
        k_t = kf[:, t]
        v_t = vf[:, t]
        g_t = gf[:, t]
        beta_t = betaf[:, t]

        state = state * torch.exp(g_t)[..., None]
        residual = v_t - (k_t[..., None] * state).sum(-2)
        state = state + torch.einsum("bhk,bhv->bhkv", beta_t[..., None] * k_t, residual)
        out[:, t] = torch.einsum("bhk,bhkv->bhv", q_t, state)

    final_state = state if output_final_state else None
    return out.to(dtype), final_state


def to_chunked_inputs(q, k, v, g, beta, chunk_size=64):
    """Convert upstream `[B, T, ...]` inputs into KDA chunked refs."""
    if chunk_size <= 0:
        raise ValueError(f"chunk_size must be positive, got {chunk_size}")
    B, T, H, K = q.shape
    HV = v.shape[2]
    V = v.shape[-1]
    C = T // chunk_size
    if T % chunk_size != 0:
        raise ValueError(f"T={T} must be divisible by chunk_size={chunk_size}")

    q_c = q.reshape(B, C, chunk_size, H, K).permute(0, 3, 1, 2, 4).contiguous()
    k_c = k.reshape(B, C, chunk_size, H, K).permute(0, 3, 1, 2, 4).contiguous()
    v_c = v.reshape(B, C, chunk_size, HV, V).permute(0, 3, 1, 2, 4).contiguous()
    g_c = g.reshape(B, C, chunk_size, HV, K).permute(0, 3, 1, 2, 4).contiguous()
    beta_c = beta.reshape(B, C, chunk_size, HV).permute(0, 3, 1, 2).contiguous()
    return q_c, k_c, v_c, g_c, beta_c


def from_chunked_output(o):
    B, HV, C, L, V = o.shape
    return o.permute(0, 2, 3, 1, 4).reshape(B, C * L, HV, V).contiguous()


def sample_inputs(B=1, H=2, HV=2, C=2, L=64, K=64, V=64, dtype=torch.bfloat16, seed=0):
    generator = torch.Generator(device="cpu").manual_seed(seed)
    T = C * L
    q = torch.randn(B, T, H, K, generator=generator).mul(0.04).to(dtype)
    k = torch.randn(B, T, H, K, generator=generator).mul(0.04).to(dtype)
    v = torch.randn(B, T, HV, V, generator=generator).mul(0.04).to(dtype)
    # Small mostly-negative log-space increments keep recurrent decay bounded.
    g = -torch.rand(B, T, HV, K, generator=generator).mul(0.03)
    beta = torch.rand(B, T, HV, generator=generator).mul(0.45).add(0.05)
    initial_state = torch.randn(B, HV, K, V, generator=generator).mul(0.01)
    return q, k, v, g, beta, initial_state


if __name__ == "__main__":
    inputs = sample_inputs(B=1, H=1, HV=1, C=1, K=32, V=32, seed=42)
    result = oracle(*inputs)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
