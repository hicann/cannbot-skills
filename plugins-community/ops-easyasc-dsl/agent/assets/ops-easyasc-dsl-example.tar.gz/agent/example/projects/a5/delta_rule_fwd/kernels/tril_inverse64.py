"""tril_inverse64 (step 2) - reused verbatim from gdn_fwd; gate-independent.

This step computes `(I - A)^-1` from a strict-lower `A` by forward substitution.
It depends only on the linear-algebra structure, not on the gate `g`, so the
delta-rule pipeline reuses the GDN kernel unchanged.  This thin module re-exports
the GDN entry points so the delta `kernels/` directory is self-describing.

  * `inverse_from_strict_lower_a(A)`               - fp32 PyTorch reference.
  * `inverse_from_strict_lower_a_bf16_a5_v2(A)`    - DSL block kernel runner (default).
  * `inverse_from_strict_lower_a_neumann_bf16_a5(A)` - opt-in whole-64 Neumann/log-squaring
    runner (cube-bound 2-chunk-interleaved; ~1.2-1.3x at >=2 chunks/core, drop-in signature).
    Selected via `DELTA_TRIL_IMPL=neumann` / `--tril-impl neumann`; the block kernel is the
    default because it keeps the diagonal inverse in fp32 (Neumann trades a bf16 margin).
"""
from projects.a5.gdn_fwd.kernels.tril_inverse64 import (  # noqa: F401
    inverse_from_strict_lower_a,
    inverse_from_strict_lower_a_bf16_a5_v2,
    inverse_from_strict_lower_a_neumann_bf16_a5,
)

__all__ = [
    "inverse_from_strict_lower_a",
    "inverse_from_strict_lower_a_bf16_a5_v2",
    "inverse_from_strict_lower_a_neumann_bf16_a5",
]
