# Canonical Decomposition - delta_rule_bwd_full

**Target.** `a5`
**Tolerance.** `atol=5e-4`, `rtol=5e-4`
**Project dir.** `projects/a5/delta_rule_bwd`

## Behavior

Five-stage explicit split of `projects/a5/delta_rule_bwd/delta_rule_bwd_full.py`,
the ungated delta-rule backward (`gdn_bwd` with the gate `g` removed). The scan
stage is split into a BHC-parallel local producer and a BH-parallel reverse-state
consumer; all cross-stage tensors are materialized in GM. Forward provides
`v_new_history`, so the local scan stage does not recompute
`value_wu - k_cumdecay @ state`. With `g == 0` the per-key forget weight is gone,
so the state pass consumes `key` directly (`k_weighted == key`) instead of a
forward-saved `k_weighted_history`, and there is no `exp_delta_history`. The
intra-chunk `decay_mask` collapses to a constant lower-triangular causal keep, so
it is not a saved input. The `scan_local_bwd -> scan_state_bwd` score handoff saves
`d_score_tmp` as bf16 because downstream score matmuls consume it only as a bf16
cube operand.

## IO Contract

| tensor | dtype | shape | layout | notes |
| --- | --- | --- | --- | --- |
| `query`, `key`, `value` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked row-major | original forward inputs |
| `beta` | `torch.float32` | `[B,H,C,64]` | chunked | |
| `grad_output` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked | upstream grad for bf16 forward output |
| `wu_attn_bf16` | `torch.bfloat16` | `[B,H,C,64,64]` | row-major | saved kernel handoff from inverse |
| `value_wu`, `k_cumdecay` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked | saved recompute-WU outputs; `value_wu` is retained for the WU tail contract but no longer feeds `scan_local_bwd` |
| `state_after_history` | `torch.bfloat16` | `[B,H,C,128,128]` | chunked | post-update state after each chunk |
| `v_new_history` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked | forward-saved per-chunk `value_wu - k_cumdecay @ state` |
| `grad_final_state` | `torch.float32` | `[B,H,128,128]` | row-major | optional in source; this plan treats it as provided |
| `d_query`, `d_key`, `d_value` | `torch.float32` | `[B,H,C,64,128]` | chunked | output grads |
| `d_beta` | `torch.float32` | `[B,H,C,64]` | chunked | output grad |

Constants: `L=64`, `D=128`. Runtime dims: `B,H,C`; no L/D tail handling.

Dropped vs `gdn_bwd` (gate machinery): `g`, `g_cumsum`, `decay_mask`,
`k_weighted_history`, `exp_delta_history` inputs; `d_g` output.

## Sub-kernels

| sub | ref file | inputs | outputs | pipe / primitive notes |
| --- | --- | --- | --- | --- |
| `scan_local_bwd` | `refs/scan_local_bwd_ref.py` | `query,key,grad_output,v_new_history` | `d_score_tmp`, `d_v_attn_tmp` | BHC-parallel local products; intra-chunk causal keep is a constant tril built in the vec stage; `d_score_tmp` saved bf16, [P1,P2,P6,L1] |
| `scan_state_bwd` | `refs/scan_state_bwd_ref.py` | `scan_local_bwd` temps + `v_new_history` + reverse state tensors | `d_q_core`, `d_k_core`, `d_value_wu`, `d_k_cumdecay` | BH-parallel reverse C state bridge; `key`, `v_new_history`, and bf16 `d_score_tmp` feed cube paths directly from GM to L1; c0 `d_q_core` stores L0C->GM; no gate prelude/postprocess, [P1,P2,P6,L1] |
| `wu_bwd` | `refs/wu_bwd_ref.py` | `key,value,beta,wu_attn_bf16,d_value_wu,d_k_cumdecay` | `d_wu`, WU partials | cube-heavy; no `exp(g_cumsum)` weight, [P1,P2,P6,L1] |
| `inverse_preprocess_bwd` | `refs/inverse_preprocess_bwd_ref.py` | `key,beta,wu_attn_bf16,d_wu` | preprocess partials | `W.T @ dW @ W.T`; `d_score_pre = -d_attn_pre * strict_lower`, [P1,P2,P6,L1] |
| `finalize_bwd` | `refs/finalize_bwd_ref.py` | upper partial gradients | `d_key`, `d_value`, `d_beta` | fused upper VF computes `d_value`, `d_beta`, `d_key` keeping `d_k_beta_wu + d_k_beta_pre` in registers; no all-cube `d_g` lower path, [P2,P6]; compose forwards `scan_state_bwd.d_q_core` directly as public `d_query` |

## DAG

Machine-readable file: `refs/dag.json`

```text
scan_local_bwd -> scan_state_bwd -> wu_bwd -> inverse_preprocess_bwd
scan_local_bwd, scan_state_bwd, wu_bwd, inverse_preprocess_bwd -> finalize_bwd
```

## Casts and Lossy Boundaries

| location | cast / approximation | reason | expected error |
| --- | --- | --- | --- |
| forward handoff | `wu_attn/value_wu/k_cumdecay/state_after_history/v_new_history` saved as bf16 | matches the forward kernel handoff; `scan_local_bwd` and `scan_state_bwd` consume saved `v_new_history` directly | included in oracle inputs |
| `scan_local_bwd -> scan_state_bwd` | `d_score_tmp` saved bf16, loaded GM->L1 ND2NZ; `d_v_attn_tmp` stays fp32 | avoids local-stage recompute and the state-side score staging | included in refs |
| `scan_state_bwd -> wu_bwd` | `d_value_wu` and `d_k_cumdecay` are bf16 workspaces | WU only consumes them as cube operands | exact to oracle |
| `wu_bwd -> inverse_preprocess_bwd` | `d_wu` saved bf16 | internal cube-only handoff | included in refs |
| cube refs | every matmul uses bf16 operands with fp32 accumulation/output | models the preferred A5 cube precision path; masks, reductions, and final accumulation stay fp32 | refs are exact to oracle |

## Validation

```bash
python -m py_compile refs/*.py
for f in refs/*_check.py; do python "$f"; done
python refs/compose.py
python refs/golden_check.py
```

`compose.py` checks `(B,H,C)=(1,2,2)` and `(2,1,3)`;
`golden_check.py` ties the bf16 refs to the fp32 golden within 2e-3.

## Open Questions

- This plan assumes `initial_state=None` and does not emit `d_initial_state`; the
  golden already supports `include_initial_state_grad`, so add it to `scan_state_bwd`
  outputs (the post-loop `d_state`) if the public backward needs trainable initial state.
