"""Run KDA backward stage traces and summarize per-track pipe occupancy.

The current first pass uses simulator traces for the three logical backward
stages:

- scan_bwd
- inverse_bwd
- finalize_bwd

Each logical stage launches one or more real DSL kernels. This helper keeps the
stage grouping for reporting while computing makespan and active/span occupancy
from the child trace files.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import torch


PLAN_DIR = Path(__file__).resolve().parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"
for _path in (str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import KDAOracleInputs, make_inputs, oracle, outputs_as_tuple  # noqa: E402
import kernel_compose as kernel_compose_mod  # noqa: E402
import scan_bwd as scan_bwd_mod  # noqa: E402
import inverse_bwd as inverse_bwd_mod  # noqa: E402
import finalize_bwd as finalize_bwd_mod  # noqa: E402
import scan_fused as scan_fused_mod  # noqa: E402
import inverse_mm as inverse_mm_mod  # noqa: E402
import inverse_epilogue as inverse_epilogue_mod  # noqa: E402
import inverse_dainv as inverse_dainv_mod  # noqa: E402
import inverse_dakk_fused as inverse_dakk_fused_mod  # noqa: E402
import finalize_pre as finalize_pre_mod  # noqa: E402
import finalize_pair as finalize_pair_mod  # noqa: E402
import finalize_post as finalize_post_mod  # noqa: E402
import finalize_reduce as finalize_reduce_mod  # noqa: E402
from _torch_formula import L, build_saved_forward  # noqa: E402


ATOL = 1e-3
RTOL = 1e-3
PIPE_CATS = {"MTE2", "MTE1", "M", "FIX", "V", "MTE3"}
# Every kernel that emits a trace must be listed here so --core-count forces it
# to a single core; otherwise a kernel keeps its module default (32) and its
# makespan is a multi-core latency, not comparable to the single-core kernels.
TRACE_MODULES = [
    scan_fused_mod,
    inverse_mm_mod,
    inverse_epilogue_mod,
    inverse_dainv_mod,
    inverse_dakk_fused_mod,
    finalize_pre_mod,
    finalize_pair_mod,
    finalize_post_mod,
    finalize_reduce_mod,
]


def _set_core_count(core_count: int):
    for mod in TRACE_MODULES:
        mod.DEFAULT_CORE_COUNT = core_count


def _check_output(name: str, got: torch.Tensor, ref: torch.Tensor):
    got_f = got.float()
    ref_f = ref.float()
    if not torch.isfinite(got_f).all():
        raise RuntimeError("%s: non-finite values in simulator output" % name)
    if not torch.allclose(got_f, ref_f, atol=ATOL, rtol=RTOL):
        diff = (got_f - ref_f).abs()
        rel = diff / ref_f.abs().clamp_min(1e-12)
        raise RuntimeError(
            "%s: max_abs=%.3e max_rel=%.3e exceeds tol=(%.3e, %.3e)"
            % (name, float(diff.max()), float(rel.max()), ATOL, RTOL)
        )


def _run_correctness(inputs: KDAOracleInputs):
    expected = oracle(inputs)
    actual = kernel_compose_mod.run(
        inputs.q,
        inputs.k,
        inputs.v,
        inputs.g,
        inputs.beta,
        inputs.initial_state,
        inputs.do,
        inputs.dht,
        simulator=True,
    )
    for name, got, ref in zip(("dq", "dk", "dv", "dbeta", "dg", "dh0"), actual, outputs_as_tuple(expected)):
        _check_output(name, got, ref)


def _interval_union(intervals: Sequence[Tuple[float, float]]) -> float:
    if not intervals:
        return 0.0
    ordered = sorted(intervals)
    cur_start, cur_end = ordered[0]
    total = 0.0
    for start, end in ordered[1:]:
        if start <= cur_end:
            if end > cur_end:
                cur_end = end
            continue
        total += cur_end - cur_start
        cur_start, cur_end = start, end
    total += cur_end - cur_start
    return total


def _trace_makespan(trace_events: Iterable[Dict]) -> float:
    end_times = [float(event["ts"]) + float(event["dur"]) for event in trace_events if event.get("ph") == "X"]
    return max(end_times) if end_times else 0.0


def _load_trace_summary(trace_path: Path) -> Dict[str, object]:
    payload = json.loads(trace_path.read_text(encoding="utf-8"))
    events = payload.get("traceEvents", [])
    tid_to_name = {}
    for event in events:
        if event.get("ph") == "M" and event.get("name") == "thread_name":
            tid_to_name[int(event["tid"])] = str(event.get("args", {}).get("name", ""))

    pipe_intervals: Dict[str, List[Tuple[float, float]]] = {}
    for event in events:
        if event.get("ph") != "X":
            continue
        if str(event.get("cat")) not in PIPE_CATS:
            continue
        track_name = tid_to_name.get(int(event["tid"]), "")
        if not track_name:
            continue
        start = float(event["ts"])
        end = start + float(event["dur"])
        pipe_intervals.setdefault(track_name, []).append((start, end))

    occupancies = []
    for track_name, intervals in sorted(pipe_intervals.items()):
        active = _interval_union(intervals)
        span = max(end for _, end in intervals) - min(start for start, _ in intervals)
        occ = 0.0 if span <= 0.0 else active / span
        occupancies.append(
            {
                "track": track_name,
                "active": active,
                "span": span,
                "occupancy": occ,
            }
        )
    occupancies.sort(key=lambda item: (-float(item["occupancy"]), item["track"]))
    return {
        "trace_path": str(trace_path),
        "makespan": _trace_makespan(events),
        "occupancies": occupancies,
    }


def _print_stage_summary(stage_name: str, traces: List[Dict[str, object]]):
    print("[%s]" % stage_name)
    stage_sum = 0.0
    best_occ = None
    for item in traces:
        trace_name = Path(str(item["trace_path"])).name
        makespan = float(item["makespan"])
        stage_sum += makespan
        top = item["occupancies"][0] if item["occupancies"] else None
        if top is not None and (best_occ is None or float(top["occupancy"]) > float(best_occ["occupancy"])):
            best_occ = top
        if top is None:
            print("  %s: makespan=%.1f cycles top_pipe=n/a" % (trace_name, makespan))
            continue
        print(
            "  %s: makespan=%.1f cycles top_pipe=%s occ=%.1f%% active=%.1f span=%.1f"
            % (
                trace_name,
                makespan,
                top["track"],
                100.0 * float(top["occupancy"]),
                float(top["active"]),
                float(top["span"]),
            )
        )
    if best_occ is None:
        print("  stage_sum=%.1f cycles best_pipe=n/a" % stage_sum)
    else:
        print(
            "  stage_sum=%.1f cycles best_pipe=%s occ=%.1f%%"
            % (stage_sum, best_occ["track"], 100.0 * float(best_occ["occupancy"]))
        )


def _collect_stage_traces(stage_dir: Path) -> List[Dict[str, object]]:
    trace_dir = stage_dir / "traces"
    if not trace_dir.is_dir():
        return []
    return [_load_trace_summary(path) for path in sorted(trace_dir.glob("*.json"))]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=1)
    parser.add_argument("--HV", type=int, default=1)
    parser.add_argument("--T", type=int, default=512)
    parser.add_argument("--K", type=int, default=128)
    parser.add_argument("--V", type=int, default=128)
    parser.add_argument("--chunk-size", type=int, default=L)
    parser.add_argument("--seed", type=int, default=20260604)
    parser.add_argument("--scale", type=float, default=0.01)
    parser.add_argument("--core-count", type=int, default=1)
    parser.add_argument("--out-dir", type=str, default=str(PLAN_DIR / "tmp" / "pipe_profile"))
    parser.add_argument("--skip-check", action="store_true")
    args = parser.parse_args()

    if args.T % args.chunk_size != 0:
        raise ValueError("T must be divisible by chunk_size")

    out_root = Path(args.out_dir).resolve()
    out_root.mkdir(parents=True, exist_ok=True)
    _set_core_count(args.core_count)

    inputs = make_inputs(
        B=args.B,
        H=args.H,
        HV=args.HV,
        T=args.T,
        K=args.K,
        V=args.V,
        chunk_size=args.chunk_size,
        seed=args.seed,
        scale=args.scale,
    )
    if not args.skip_check:
        _run_correctness(inputs)

    caches = build_saved_forward(inputs)
    g_last = caches.g_cumsum[:, args.chunk_size - 1::args.chunk_size, :, :]

    scan_out = scan_bwd_mod.run(
        caches.Aqk,
        caches.v_new,
        inputs.do,
        caches.kg,
        caches.qg,
        caches.w,
        g_last,
        inputs.dht,
        simulator=True,
        trace=True,
        out_dir=str(out_root / "scan_bwd"),
    )
    inverse_out = inverse_bwd_mod.run(
        inputs.q,
        inputs.k,
        inputs.v,
        inputs.beta,
        inputs.do,
        caches.g_cumsum,
        caches.v_new,
        caches.h,
        scan_out[1],
        scan_out[2],
        caches.Akk,
        simulator=True,
        trace=True,
        out_dir=str(out_root / "inverse_bwd"),
    )
    finalize_bwd_mod.run(
        inputs.q,
        inputs.k,
        inputs.beta,
        caches.g_cumsum,
        scan_out[0],
        inverse_out[0],
        inverse_out[1],
        inverse_out[2],
        inverse_out[3],
        inverse_out[4],
        inverse_out[5],
        scan_out[3],
        simulator=True,
        trace=True,
        out_dir=str(out_root / "finalize_bwd"),
    )

    print(
        "shape=B%d H%d HV%d T%d K%d V%d chunk=%d core_count=%d out_dir=%s"
        % (args.B, args.H, args.HV, args.T, args.K, args.V, args.chunk_size, args.core_count, out_root)
    )
    for stage_name in ("scan_bwd", "inverse_bwd", "finalize_bwd"):
        _print_stage_summary(stage_name, _collect_stage_traces(out_root / stage_name))


if __name__ == "__main__":
    raise SystemExit(main())
