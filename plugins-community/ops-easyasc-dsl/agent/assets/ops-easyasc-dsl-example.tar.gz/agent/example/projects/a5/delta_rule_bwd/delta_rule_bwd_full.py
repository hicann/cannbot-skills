"""PyTorch golden for full chunked (ungated) delta-rule backward on a5.

Relationship to GDN.  This is `projects/a5/gdn_bwd/gdn_bwd_full.py` with the
per-token gate `g` removed.  The repo already proves the *forward* equivalence
exactly (`delta_rule_fwd/delta_rule_full.py::compare_against_gated_zero_g`,
max_abs == 0): the ungated delta rule is the GDN forward with `g == 0`.
Identical forwards have identical backwards w.r.t. the shared inputs
`(query, key, value, beta)`, so this file is `gdn_bwd_full` evaluated at `g == 0`.

Setting `g == 0` makes every `exp(g_cumsum)` factor 1, which:
  * turns the intra-chunk `decay_mask = exp(g_cumsum_i - g_cumsum_j)` into a
    plain causal keep `tril(ones)` (constant, no longer a saved input);
  * drops the `exp(g_cumsum)` weight on `k_cumdecay` (`w = (I-A)^-1 @ k_beta`);
  * removes the recurrent-state decay `S * exp(g_last)` and the per-key forget
    weight `k * exp(g_last - g_cumsum)` (update becomes `S += k_i^T @ v_new`);
  * removes the `exp(g_cumsum)` factor on the inter-chunk `q @ S` term.
Every computation that exclusively fed the gate gradient `d_g` (the `d_g_cumsum`
/ `d_decay_mask` / `d_exp_g_last` / `d_delta` accumulators) is deleted — it never
flows back into `d_q/d_k/d_v/d_beta`, so dropping it leaves them unchanged.  The
output therefore shrinks from `(d_q, d_k, d_v, d_beta, d_g)` to
`(d_q, d_k, d_v, d_beta)`, and the saved forward tensors shrink from six to four
(no `g_cumsum`, no `decay_mask`).

`compare_against_gated_zero_g()` runs `gdn_bwd_full` at `g == 0` on identical
inputs and asserts the kept gradients agree — the executable form of the claim.

Precision path (mirrors `gdn_bwd_full`, minus `g`): inputs are promoted to fp32
internally; the only bf16 boundary is `wu_attn_bf16`, the kernel handoff tensor,
which this golden promotes back to fp32 for the backward math.  `W = (I - A)^-1`
gives `dA = W.T @ dW @ W.T` for the inverse block.
"""

from typing import Optional, Tuple

import torch


L = 64
D = 128

DELTA_BWD_FORWARD_TENSOR_NAMES = (
    "wu_attn_bf16", "value_wu", "k_cumdecay", "state_after_history",
)
DELTA_BWD_REQUIRED_INPUT_NAMES = (
    "query", "key", "value", "beta", "grad_output",
) + DELTA_BWD_FORWARD_TENSOR_NAMES
DELTA_BWD_OPTIONAL_INPUT_NAMES = ("grad_final_state", "initial_state")
DELTA_BWD_OUTPUT_NAMES = ("d_query", "d_key", "d_value", "d_beta")
DELTA_BWD_OUTPUT_NAMES_WITH_INITIAL_STATE = DELTA_BWD_OUTPUT_NAMES + ("d_initial_state",)


def _check(query, key, value, beta, initial_state=None) -> Tuple[int, int, int]:
    if query.ndim != 5:
        raise ValueError(f"query must be [B,H,C,{L},{D}], got {tuple(query.shape)}")
    B, H, C, chunk, dim = (int(x) for x in query.shape)
    if (chunk, dim) != (L, D):
        raise ValueError(f"this path is specialized for L={L}, D={D}; got L={chunk}, D={dim}")
    if tuple(key.shape) != tuple(query.shape) or tuple(value.shape) != tuple(query.shape):
        raise ValueError("query/key/value must have identical [B,H,C,L,D] shapes")
    if tuple(beta.shape) != (B, H, C, L):
        raise ValueError("beta must be [B,H,C,L]")
    if initial_state is not None and tuple(initial_state.shape) != (B, H, D, D):
        raise ValueError(f"initial_state must be [B,H,{D},{D}], got {tuple(initial_state.shape)}")
    return B, H, C


def _f(x: torch.Tensor) -> torch.Tensor:
    return x if x.dtype == torch.float32 else x.float()


def _strict_lower(device) -> torch.Tensor:
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device), diagonal=-1)


def _causal_keep(device) -> torch.Tensor:
    """GDN's `decay_mask` at g == 0: lower-triangular keep, diagonal included."""
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device))


def compute_delta_bwd_forward_tensors(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return the forward tensors consumed by `delta_rule_bwd_full`.

    `gdn_bwd`'s `compute_gdn_bwd_forward_tensors` with `g == 0`: the `decay_mask`
    multiply collapses to the strict-lower keep, and `k_cumdecay` loses its
    `exp(g_cumsum)` weight.
    """
    _check(query, key, value, beta)
    k, v, beta_f = _f(key), _f(value), beta.float()
    k_beta = k * beta_f.unsqueeze(-1)
    # A = -(k_beta @ key^T) on the strict lower triangle (decay_mask == 1 here).
    preprocess_attn = -((k_beta @ k.transpose(-1, -2)) * _strict_lower(query.device))
    wu_attn_fp32 = torch.linalg.inv(torch.eye(L, dtype=torch.float32, device=query.device) - preprocess_attn)
    wu_attn_bf16 = wu_attn_fp32.to(torch.bfloat16)
    wu_attn = wu_attn_bf16.float()
    value_wu = wu_attn @ (v * beta_f.unsqueeze(-1))
    k_cumdecay = wu_attn @ k_beta  # w = (I-A)^-1 @ (key*beta)   [no exp(g_cumsum) factor]
    _, state_after_history = _state_after_history(k, value_wu, k_cumdecay, None)
    return wu_attn_bf16, value_wu, k_cumdecay, state_after_history


def _check_forward_tensors(query, key, value, beta, tensors):
    B, H, C = _check(query, key, value, beta)
    shapes = (
        (B, H, C, L, L), (B, H, C, L, D), (B, H, C, L, D), (B, H, C, D, D),
    )
    for name, tensor, shape in zip(DELTA_BWD_FORWARD_TENSOR_NAMES, tensors, shapes):
        if tuple(tensor.shape) != shape:
            raise ValueError(f"{name} shape must be {shape}, got {tuple(tensor.shape)}")
        if name == "wu_attn_bf16" and tensor.dtype != torch.bfloat16:
            raise TypeError(f"{name} dtype must be torch.bfloat16, got {tensor.dtype}")
    return tuple(t.float() for t in tensors)


def _state_after_history(k, value_wu, k_cumdecay, initial_state):
    """Per-chunk state checkpoints; `gdn_bwd`'s `_state_after_history` at g == 0.

    No state decay (`* exp(g_last)`) and no per-key forget weight: the update is
    the plain delta-rule recurrence `S += k_i^T @ v_new`.
    """
    B, H, C, _, _ = k.shape
    state = torch.zeros(B, H, D, D, dtype=torch.float32, device=k.device) if initial_state is None else initial_state.float()
    states = []

    for c in range(C):
        k_i = k[:, :, c]
        v_new = value_wu[:, :, c] - k_cumdecay[:, :, c] @ state
        state = state + k_i.transpose(-1, -2) @ v_new
        states.append(state)

    return state, torch.stack(states, dim=2)


def _forward_ref(query, key, value, beta, initial_state=None):
    """Ungated delta-rule forward (the GDN reference minus `g`), used by the self-check."""
    mids = compute_delta_bwd_forward_tensors(query, key, value, beta)
    q, k = _f(query), _f(key)
    wu_attn_bf16, value_wu, k_cumdecay, _ = mids
    final_state, state_after_history = _state_after_history(k, value_wu, k_cumdecay, initial_state)
    causal_keep = _causal_keep(query.device)
    outputs = []
    for c in range(q.shape[2]):
        if c == 0:
            state = torch.zeros_like(final_state) if initial_state is None else initial_state.float()
        else:
            state = state_after_history[:, :, c - 1]
        q_i, k_i = q[:, :, c], k[:, :, c]
        score_qk = q_i @ k_i.transpose(-1, -2)
        attn = score_qk * causal_keep
        v_new = value_wu[:, :, c] - k_cumdecay[:, :, c] @ state
        outputs.append(q_i @ state + attn @ v_new)  # no exp(g_cumsum) on q
    output = torch.stack(outputs, dim=2)
    return output, final_state, (wu_attn_bf16, value_wu, k_cumdecay, state_after_history)


def delta_rule_bwd_full(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    grad_output: torch.Tensor,
    wu_attn_bf16: torch.Tensor,
    value_wu: torch.Tensor,
    k_cumdecay: torch.Tensor,
    state_after_history: torch.Tensor,
    grad_final_state: Optional[torch.Tensor] = None,
    initial_state: Optional[torch.Tensor] = None,
    include_initial_state_grad: bool = False,
) -> Tuple[torch.Tensor, ...]:
    """Return `(d_query, d_key, d_value, d_beta)` for chunked (ungated) delta rule.

    `gdn_bwd_full` with `g == 0`: every `exp(g_cumsum)` factor is 1, the
    `decay_mask` is the constant causal keep, and the entire `d_g` sub-computation
    (`d_g_cumsum`/`d_decay_mask`/`d_exp_g_last`/`d_delta`) is removed.
    """
    B, H, C = _check(query, key, value, beta, initial_state)
    if tuple(grad_output.shape) != (B, H, C, L, D):
        raise ValueError(f"grad_output must be {(B, H, C, L, D)}, got {tuple(grad_output.shape)}")

    wu_attn, value_wu, k_cumdecay, state_after_history = _check_forward_tensors(
        query, key, value, beta, (wu_attn_bf16, value_wu, k_cumdecay, state_after_history)
    )
    q, k, v, beta_f = _f(query), _f(key), _f(value), beta.float()
    k_beta = k * beta_f.unsqueeze(-1)
    v_beta = v * beta_f.unsqueeze(-1)
    causal_keep = _causal_keep(query.device)

    final_state = state_after_history[:, :, C - 1]
    d_state = torch.zeros_like(final_state) if grad_final_state is None else grad_final_state.float()
    d_core = grad_output.float()
    d_q, d_k, d_v = torch.zeros_like(q), torch.zeros_like(k), torch.zeros_like(v)
    d_beta = torch.zeros_like(beta_f)
    d_value_wu, d_k_cumdecay = torch.zeros_like(value_wu), torch.zeros_like(k_cumdecay)

    for c in range(C - 1, -1, -1):
        state = (
            torch.zeros_like(final_state) if c == 0 and initial_state is None
            else initial_state.float() if c == 0
            else state_after_history[:, :, c - 1]
        )
        q_i, k_i, d_out = q[:, :, c], k[:, :, c], d_core[:, :, c]
        score_qk = q_i @ k_i.transpose(-1, -2)
        attn = score_qk * causal_keep
        v_new = value_wu[:, :, c] - k_cumdecay[:, :, c] @ state
        # q_exp == q_i (no gate); k_weighted == k_i (no per-key forget weight).

        d_q_inter = d_out @ state.transpose(-1, -2)                       # grad of the q @ S term
        d_state_in = q_i.transpose(-1, -2) @ d_out + d_state             # no exp(g_last) decay
        d_attn = d_out @ v_new.transpose(-1, -2)
        d_v_new = attn.transpose(-1, -2) @ d_out
        d_k_from_state = v_new @ d_state.transpose(-1, -2)               # grad of k_i in S += k_i^T @ v_new
        d_v_new = d_v_new + k_i @ d_state

        d_value_wu[:, :, c] = d_value_wu[:, :, c] + d_v_new
        d_v_prime = -d_v_new
        d_k_cumdecay[:, :, c] = d_k_cumdecay[:, :, c] + d_v_prime @ state.transpose(-1, -2)
        d_state_in = d_state_in + k_cumdecay[:, :, c].transpose(-1, -2) @ d_v_prime

        d_score_qk = d_attn * causal_keep
        d_q[:, :, c] = d_q[:, :, c] + d_score_qk @ k_i + d_q_inter
        d_k[:, :, c] = d_k[:, :, c] + d_score_qk.transpose(-1, -2) @ q_i
        d_k[:, :, c] = d_k[:, :, c] + d_k_from_state
        d_state = d_state_in

    d_wu = d_value_wu @ v_beta.transpose(-1, -2) + d_k_cumdecay @ k_beta.transpose(-1, -2)
    d_v_beta = wu_attn.transpose(-1, -2) @ d_value_wu
    d_k_beta = wu_attn.transpose(-1, -2) @ d_k_cumdecay  # no exp(g_cumsum) factor

    d_attn_pre = wu_attn.transpose(-1, -2) @ d_wu @ wu_attn.transpose(-1, -2)
    d_score_pre = -d_attn_pre * _strict_lower(query.device)  # decay_mask * strict_lower -> strict_lower
    d_k_beta = d_k_beta + d_score_pre @ k
    d_k = d_k + d_score_pre.transpose(-1, -2) @ k_beta

    d_v = d_v + d_v_beta * beta_f.unsqueeze(-1)
    d_beta = d_beta + (d_v_beta * v).sum(dim=-1)
    d_k = d_k + d_k_beta * beta_f.unsqueeze(-1)
    d_beta = d_beta + (d_k_beta * k).sum(dim=-1)

    outputs = (d_q, d_k, d_v, d_beta)
    if include_initial_state_grad:
        if initial_state is None:
            raise ValueError("include_initial_state_grad=True requires initial_state")
        outputs = outputs + (d_state,)
    return outputs


golden = delta_rule_bwd_full


def _make_inputs(B=1, H=1, C=2, scale=0.05):
    query = torch.randn(B, H, C, L, D, dtype=torch.float32) * scale
    key = torch.randn(B, H, C, L, D, dtype=torch.float32) * scale
    value = torch.randn(B, H, C, L, D, dtype=torch.float32) * scale
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    return query, key, value, beta


def _check_close(name, got, ref, atol=5e-5, rtol=5e-5):
    diff = (got.float() - ref.float()).abs()
    ok = torch.allclose(got.float(), ref.float(), atol=atol, rtol=rtol)
    print(f"{name}: max_abs={float(diff.max()):.3e} {'OK' if ok else 'DIFF'}")
    if not ok:
        raise AssertionError(name)


def _self_check(include_initial_state=True, seed=1):
    """Validate the hand-derived backward against autograd of `_forward_ref`."""
    torch.manual_seed(seed)
    base = _make_inputs()
    inputs = [x.detach().clone().requires_grad_(True) for x in base]
    initial_state = (torch.randn(1, 1, D, D) * 0.02).requires_grad_(True) if include_initial_state else None
    output, final_state, mids = _forward_ref(*inputs, initial_state=initial_state)
    grad_output = torch.randn_like(output) * 0.1
    grad_final_state = torch.randn_like(final_state) * 0.1
    ((output * grad_output).sum() + (final_state * grad_final_state).sum()).backward()

    manual = delta_rule_bwd_full(
        *base, grad_output, *(x.detach() for x in mids),
        grad_final_state=grad_final_state,
        initial_state=initial_state.detach() if initial_state is not None else None,
        include_initial_state_grad=include_initial_state,
    )
    refs = [x.grad for x in inputs] + ([initial_state.grad] if include_initial_state else [])
    print(f"=== self-check vs autograd (include_initial_state={include_initial_state}, seed={seed}) ===")
    for name, got, ref in zip(DELTA_BWD_OUTPUT_NAMES_WITH_INITIAL_STATE, manual, refs):
        _check_close(name, got, ref)


def compare_against_gated_zero_g(include_initial_state=True, seed=1):
    """Prove `delta_rule_bwd == gdn_bwd` with `g == 0`: run both, compare the kept grads.

    Both goldens share the fp32-internal precision path with a single bf16
    `wu_attn` boundary, so the kept gradients agree to rounding.  `gdn_bwd`'s
    extra `d_g` output has no counterpart here and is ignored.
    """
    from projects.a5.gdn_bwd.gdn_bwd_full import (
        gdn_bwd_full, compute_gdn_bwd_forward_tensors,
    )

    torch.manual_seed(seed)
    query, key, value, beta = _make_inputs()
    g_zero = torch.zeros(*beta.shape, dtype=torch.float32, device=beta.device)
    initial_state = (torch.randn(1, 1, D, D) * 0.02) if include_initial_state else None

    gdn_mids = compute_gdn_bwd_forward_tensors(query, key, value, beta, g_zero)
    delta_mids = compute_delta_bwd_forward_tensors(query, key, value, beta)
    # The saved tensors delta keeps (wu_attn_bf16, value_wu, k_cumdecay,
    # state_after_history) are gdn_mids indices 2,3,4,5 — assert they coincide.
    shared_names = ("wu_attn_bf16", "value_wu", "k_cumdecay", "state_after_history")
    print(f"=== forward tensors: delta vs gdn(g=0) (seed={seed}) ===")
    for name, dm, gm in zip(shared_names, delta_mids, gdn_mids[2:]):
        _check_close(name, dm.float(), gm.float())

    _, _, C = _check(query, key, value, beta)
    grad_output = torch.randn(1, 1, C, L, D, dtype=torch.float32)
    grad_final_state = torch.randn(1, 1, D, D, dtype=torch.float32)

    gdn_out = gdn_bwd_full(
        query, key, value, beta, g_zero, grad_output, *gdn_mids,
        grad_final_state=grad_final_state, initial_state=initial_state,
        include_initial_state_grad=include_initial_state,
    )
    delta_out = delta_rule_bwd_full(
        query, key, value, beta, grad_output, *delta_mids,
        grad_final_state=grad_final_state, initial_state=initial_state,
        include_initial_state_grad=include_initial_state,
    )
    # gdn outputs (d_q, d_k, d_v, d_beta, d_g[, d_state]); delta drops d_g.
    gdn_kept = list(gdn_out[:4]) + (list(gdn_out[5:]) if include_initial_state else [])
    print(f"=== gradients: delta vs gdn(g=0), d_g dropped (include_initial_state={include_initial_state}) ===")
    for name, dout, gout in zip(DELTA_BWD_OUTPUT_NAMES_WITH_INITIAL_STATE, delta_out, gdn_kept):
        _check_close(name, dout, gout)
    print(f"[dropped for delta] gdn d_g |val|max={gdn_out[4].abs().max().item():.3e} (no g input in delta)")


if __name__ == "__main__":
    _self_check(include_initial_state=True, seed=1)
    _self_check(include_initial_state=False, seed=3)
    print()
    compare_against_gated_zero_g(include_initial_state=True, seed=1)
    compare_against_gated_zero_g(include_initial_state=False, seed=3)
