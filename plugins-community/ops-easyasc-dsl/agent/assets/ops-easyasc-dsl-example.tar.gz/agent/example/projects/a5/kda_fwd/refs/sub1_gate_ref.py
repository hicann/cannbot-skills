"""Sub-kernel reference: sub1_gate - chunk-local linear gate cumsum.

I/O contract
------------
Inputs:
  - g_raw: torch.float32 [B, HV, C, L, K]

Outputs:
  - g:     torch.float32 [B, HV, C, L, K] exp(cumsum(g_raw))

`g_raw` is in natural-log units. This EasyASC plan materializes cumulative
gates in linear space so later stages can consume `exp(cumsum(g_raw))`
directly.

Primitives used: [P1]
"""

import torch


def subkernel(g_raw):
    return torch.exp(torch.cumsum(g_raw.float(), dim=-2))


if __name__ == "__main__":
    torch.manual_seed(42)
    g_raw = -torch.rand(1, 1, 1, 32, 32).mul(0.03)
    result = subkernel(g_raw)
    print(tuple(result.shape), result.dtype)
