"""Finalize-stage post epilogue (formerly the host post-loop in finalize_bwd).

Per chunk, all-vector. Consumes `finalize_pair`'s four pairwise matmul outputs
(`qk_left = M_qk@kg`, `qk_right = M_qk^T@q_scaled`, `s_base = M_base@kg`,
`t_beta = M_beta^T@k_scaled`), rebuilds the exp2 scales, forms the qk/kk
pairwise gradient contributions and accumulates them onto the inverse-stage
running grads:

    dq_pair = row_scale * qk_left            dk_pair = col_scale * qk_right
    row_contrib = row_scale * s_base         col_contrib = col_scale * t_beta
    dg_qk = q_hv*dq_pair - k_hv*dk_pair
    dk_kk = beta*row_contrib + col_contrib
    dbeta_add = (k_hv * row_contrib).sum(D)            # cadd
    dg_kk = beta*k_hv*row_contrib - k_hv*col_contrib

    dq_hv' = dq_hv + dq_pair                 (fp32 -- summed HV->H downstream)
    dk_hv' = dk_hv + dk_pair + dk_kk         (fp32)
    dbeta' = dbeta + dbeta_add               (bf16)
    dg     = reverse_cumsum(dg_core + dg_qk + dg_kk)   (bf16, per-chunk over L)

The per-chunk reverse cumsum runs INSIDE the row loop by walking rows
L-1 -> 0 and carrying a running [1,D] accumulator (`running += dg'[r];
dg[r] = running`), so no scratch tile and no store->load barrier is needed.

`dq_hv'/dk_hv'` stay fp32: `finalize_reduce` sums them HV->H, and the oracle
keeps that reduction in fp32 -- a bf16 round-trip before the sum overshoots the
1e-3 dq/dk tolerance. `row_scale/col_scale` are recomputed here from `g` (fp32,
never round-tripped); see finalize_pre. exp2 = (x*ln2).exp() (a5 micro has no
exp2; stored g already carries the 1/ln2 factor).
"""

import builtins
import math
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _layout import flat_lvd, to_lvd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
L = 64
D = 128
REGS_D = D // 64
LN2 = math.log(2.0)
# A per-token scalar burst (burst_len=1) MUST live one-per-32B-row, never densely
# packed in [1, L]: a sub-32B `.single()` / `.single_value()` access silently
# mis-addresses in the micro path on hardware. Pack each scalar in its own 32B
# row via .C0, accessed [r, 0:1] -- mirrors finalize_pre / inverse_epilogue.
SCALAR_PACK_BF16 = DT.bfloat16.C0  # 32B row for a bf16 per-token scalar (=16)
SCALAR_PACK_F32 = DT.float.C0      # 32B row for an fp32 per-token scalar (=8)
# Scalar Var order: (B, HV, C, H, G) -> symbols 0,1,2,3,4. Public/inter-stage
# tensors are token-major BTHVD (read/written strided on-device); the four
# finalize_pair outputs (qk_*) and the dq_hv'/dk_hv' that feed finalize_reduce
# stay GM-native [B,HV,C,L,D] (intra-stage).
SHAPE_BINDINGS = {
    0: [0, None, 1, None],      # g_cumsum   [B, T, HV, D]   (cache, strided)
    1: [0, 1, 2, None, None],   # qk_left    [B, HV, C, L, D]  intra-stage GM-native
    2: [0, 1, 2, None, None],   # qk_right
    3: [0, 1, 2, None, None],   # s_base
    4: [0, 1, 2, None, None],   # t_beta
    5: [0, None, 3, None],      # q          [B, T, H, D]    (H = symbol 3; gather)
    6: [0, None, 3, None],      # k          [B, T, H, D]
    7: [0, None, 1],            # beta       [B, T, HV]
    8: [0, None, 1, None],      # dq_hv_in   [B, T, HV, D]   (from inverse)
    9: [0, None, 1, None],      # dk_hv_in   [B, T, HV, D]
    10: [0, None, 1],           # dbeta_in   [B, T, HV]      (from inverse, fp32)
    11: [0, None, 1, None],     # dg_core_in [B, T, HV, D]
    12: [0, 1, 2, None, None],  # dq_hv_out  [B, HV, C, L, D] fp32  intra-stage -> reduce
    13: [0, 1, 2, None, None],  # dk_hv_out
    14: [0, None, 1],           # dbeta_out  [B, T, HV] bf16  public
    15: [0, None, 1, None],     # dg_out     [B, T, HV, D] bf16  public
}


@vf()
def finalize_post_vf(
    g_ub: Tensor,
    qkl_ub: Tensor,
    qkr_ub: Tensor,
    sbase_ub: Tensor,
    tbeta_ub: Tensor,
    qhv_ub: Tensor,
    khv_ub: Tensor,
    beta_ub: Tensor,
    dqhv_in_ub: Tensor,
    dkhv_in_ub: Tensor,
    dbeta_in_ub: Tensor,
    dgcore_in_ub: Tensor,
    dqhv_out_ub: Tensor,
    dkhv_out_ub: Tensor,
    dbeta_out_ub: Tensor,
    dg_out_ub: Tensor,
    rows: Var,
):
    glast = RegList(DT.float, REGS_D)
    g = RegList(DT.float, REGS_D)
    rscale = RegList(DT.float, REGS_D)
    cscale = RegList(DT.float, REGS_D)
    qkl = RegList(DT.float, REGS_D)
    qkr = RegList(DT.float, REGS_D)
    sbase = RegList(DT.float, REGS_D)
    tbeta = RegList(DT.float, REGS_D)
    dqpair = RegList(DT.float, REGS_D)
    dkpair = RegList(DT.float, REGS_D)
    rowc = RegList(DT.float, REGS_D)
    colc = RegList(DT.float, REGS_D)
    qh = RegList(DT.float, REGS_D)
    kh = RegList(DT.float, REGS_D)
    dgqk = RegList(DT.float, REGS_D)
    dkkk = RegList(DT.float, REGS_D)
    dgkk = RegList(DT.float, REGS_D)
    dqhv = RegList(DT.float, REGS_D)
    dkhv = RegList(DT.float, REGS_D)
    dgp = RegList(DT.float, REGS_D)
    running = RegList(DT.float, REGS_D)
    tmp = RegList(DT.float, REGS_D)
    prod = RegList(DT.float, REGS_D)
    beta_r = Reg(DT.float)
    dbadd = Reg(DT.float)
    dbin = Reg(DT.float)
    dbout = Reg(DT.float)
    dbout_bf16 = Reg(DT.bfloat16)

    glast <<= g_ub[L - 1:L, 0:D]
    running.fill(0.0)

    # Walk rows L-1 -> 0 so `running` is the per-chunk reverse cumsum of dg'.
    for rt in range(rows):
        r = rows - 1 - rt

        g <<= g_ub[r:r + 1, 0:D]
        tmp <<= g - glast
        tmp <<= tmp * LN2
        rscale <<= tmp.exp()
        tmp <<= glast - g
        tmp <<= tmp * LN2
        cscale <<= tmp.exp()

        qkl <<= qkl_ub[r:r + 1, 0:D]
        dqpair <<= rscale * qkl
        qkr <<= qkr_ub[r:r + 1, 0:D]
        dkpair <<= cscale * qkr
        sbase <<= sbase_ub[r:r + 1, 0:D]
        rowc <<= rscale * sbase
        tbeta <<= tbeta_ub[r:r + 1, 0:D]
        colc <<= cscale * tbeta

        qh <<= qhv_ub[r:r + 1, 0:D]
        kh <<= khv_ub[r:r + 1, 0:D]
        beta_r <<= beta_ub[r:r + 1, 0:1].single()

        # dg_qk = q_hv*dq_pair - k_hv*dk_pair
        dgqk <<= qh * dqpair
        prod <<= kh * dkpair
        dgqk <<= dgqk - prod

        # dk_kk = beta*row_contrib + col_contrib
        dkkk <<= rowc * beta_r
        dkkk <<= dkkk + colc

        # dbeta_add = (k_hv * row_contrib).sum(D)
        prod <<= kh * rowc
        dbadd <<= prod.cadd()

        # dg_kk = beta*k_hv*row_contrib - k_hv*col_contrib
        dgkk <<= kh * rowc
        dgkk <<= dgkk * beta_r
        prod <<= kh * colc
        dgkk <<= dgkk - prod

        # dq_hv' = dq_hv + dq_pair   (fp32 out)
        dqhv <<= dqhv_in_ub[r:r + 1, 0:D]
        dqhv <<= dqhv + dqpair
        dqhv_out_ub[r:r + 1, 0:D] <<= dqhv

        # dk_hv' = dk_hv + dk_pair + dk_kk   (fp32 out)
        dkhv <<= dkhv_in_ub[r:r + 1, 0:D]
        dkhv <<= dkhv + dkpair
        dkhv <<= dkhv + dkkk
        dkhv_out_ub[r:r + 1, 0:D] <<= dkhv

        # dbeta' = dbeta + dbeta_add ; cast fp32->bf16 for the public bf16 output
        dbin <<= dbeta_in_ub[r:r + 1, 0:1].single()
        dbout <<= dbin + dbadd
        dbout_bf16 <<= dbout.cast()       # fp32 -> bf16 (round-to-nearest-even)
        dbeta_out_ub[r:r + 1, 0:1] <<= dbout_bf16.single_value()

        # dg' = dg_core + dg_qk + dg_kk ; running += dg' ; dg[r] = running
        dgp <<= dgcore_in_ub[r:r + 1, 0:D]
        dgp <<= dgp + dgqk
        dgp <<= dgp + dgkk
        running <<= running + dgp
        dg_out_ub[r * D] <<= running[0]
        dg_out_ub[r * D + 64] <<= running[1]
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def finalize_post_kernel(
    g_cumsum: GMTensor,
    qk_left: GMTensor,
    qk_right: GMTensor,
    s_base: GMTensor,
    t_beta: GMTensor,
    q: GMTensor,
    k: GMTensor,
    beta: GMTensor,
    dq_hv_in: GMTensor,
    dk_hv_in: GMTensor,
    dbeta_in: GMTensor,
    dg_core_in: GMTensor,
    dq_hv_out: GMTensor,
    dk_hv_out: GMTensor,
    dbeta_out: GMTensor,
    dg_out: GMTensor,
    B: Var,
    HV: Var,
    C: Var,
    H: Var,
    G: Var,
):
    g_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    qkl_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    qkr_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    sbase_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    tbeta_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    qhv_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    khv_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    beta_ub = Tensor(DT.bfloat16, [L, SCALAR_PACK_BF16], Position.UB)
    dqhv_in_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dkhv_in_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    dbeta_in_ub = Tensor(DT.float, [L, SCALAR_PACK_F32], Position.UB)  # fp32 per-token scalar, 32B-row pack
    dgcore_in_ub = Tensor(DT.bfloat16, [L, D], Position.UB)

    dqhv_out_ub = Tensor(DT.float, [L, D], Position.UB)
    dkhv_out_ub = Tensor(DT.float, [L, D], Position.UB)
    dbeta_out_ub = Tensor(DT.bfloat16, [L, SCALAR_PACK_BF16], Position.UB)  # bf16 per-token scalar, 32B-row pack
    dg_out_ub = Tensor(DT.bfloat16, [L, D], Position.UB)

    work_count = Var(B * HV * C)
    work_per_core = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_core * GetCubeIdx())
    work_end = Min(work_begin + work_per_core, work_count)

    with auto_sync():
        for work in range(work_begin, work_end):
            c_idx = Var(work % C)
            bhv = Var(work / C)
            hv_idx = Var(bhv % HV)
            b_idx = Var(bhv / HV)

            row0 = Var(c_idx * L)
            h_idx = Var(hv_idx / G)
            # g_cumsum: cache, strided (pitch HV*D)
            gm_to_ub_pad(g_ub[0:L, 0:D], g_cumsum[b_idx, row0:row0 + L, hv_idx, 0:D], L, D, (HV - 1) * D, 0)
            # qk_*: intra-stage from finalize_pair, contiguous GM-native (keep <<=)
            qkl_ub[0:L, 0:D] <<= qk_left[b_idx, hv_idx, c_idx, 0:L, 0:D]
            qkr_ub[0:L, 0:D] <<= qk_right[b_idx, hv_idx, c_idx, 0:L, 0:D]
            sbase_ub[0:L, 0:D] <<= s_base[b_idx, hv_idx, c_idx, 0:L, 0:D]
            tbeta_ub[0:L, 0:D] <<= t_beta[b_idx, hv_idx, c_idx, 0:L, 0:D]
            # q/k: primaries, strided (pitch H*D) with on-device H->HV gather
            gm_to_ub_pad(qhv_ub[0:L, 0:D], q[b_idx, row0:row0 + L, h_idx, 0:D], L, D, (H - 1) * D, 0)
            gm_to_ub_pad(khv_ub[0:L, 0:D], k[b_idx, row0:row0 + L, h_idx, 0:D], L, D, (H - 1) * D, 0)
            # beta: primary, strided (pitch HV, burst_len=1)
            gm_to_ub_pad(beta_ub[0:L, 0:1], beta[b_idx, row0:row0 + L, hv_idx], L, 1, HV - 1, 0)
            # inverse-stage outputs, strided BTHVD/BTHV (dbeta_in is fp32 -> fp32 UB)
            gm_to_ub_pad(dqhv_in_ub[0:L, 0:D], dq_hv_in[b_idx, row0:row0 + L, hv_idx, 0:D], L, D, (HV - 1) * D, 0)
            gm_to_ub_pad(dkhv_in_ub[0:L, 0:D], dk_hv_in[b_idx, row0:row0 + L, hv_idx, 0:D], L, D, (HV - 1) * D, 0)
            gm_to_ub_pad(dbeta_in_ub[0:L, 0:1], dbeta_in[b_idx, row0:row0 + L, hv_idx], L, 1, HV - 1, 0)
            gm_to_ub_pad(dgcore_in_ub[0:L, 0:D], dg_core_in[b_idx, row0:row0 + L, hv_idx, 0:D], L, D, (HV - 1) * D, 0)

            finalize_post_vf(
                g_ub, qkl_ub, qkr_ub, sbase_ub, tbeta_ub, qhv_ub, khv_ub, beta_ub,
                dqhv_in_ub, dkhv_in_ub, dbeta_in_ub, dgcore_in_ub,
                dqhv_out_ub, dkhv_out_ub, dbeta_out_ub, dg_out_ub, Var(L),
            )

            # dq_hv'/dk_hv': intra-stage to finalize_reduce, contiguous GM-native fp32 (keep)
            dq_hv_out[b_idx, hv_idx, c_idx, 0:L, 0:D] <<= dqhv_out_ub[0:L, 0:D]
            dk_hv_out[b_idx, hv_idx, c_idx, 0:L, 0:D] <<= dkhv_out_ub[0:L, 0:D]
            # dbeta/dg: public outputs, strided into token-major BTHV / BTHVD bf16
            ub_to_gm_pad(dbeta_out[b_idx, row0:row0 + L, hv_idx], dbeta_out_ub[0:L, 0:1], L, 1, 0, HV - 1)
            ub_to_gm_pad(dg_out[b_idx, row0:row0 + L, hv_idx, 0:D], dg_out_ub[0:L, 0:D], L, D, 0, (HV - 1) * D)

    return dq_hv_out, dk_hv_out, dbeta_out, dg_out


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(q, k, beta, g_cumsum, qk_left, qk_right, s_base, t_beta, dq_hv_in, dk_hv_in, dbeta_in, dg_core_in, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    # Strided-BTHVD on-device: q/k [B,T,H,D] (ungathered primaries), g_cumsum /
    # dq_hv_in / dk_hv_in / dg_core_in [B,T,HV,D], beta [B,T,HV]; dbeta_in [B,T,HV]
    # fp32 (inverse emits fp32, no host cast). The four finalize_pair outputs qk_*
    # stay GM-native [B,HV,C,L,D] bf16 (intra-stage). H->HV gather is on-device.
    bf16 = torch.bfloat16
    B = int(q.shape[0])
    T = int(q.shape[1])
    H = int(q.shape[2])
    HV = int(g_cumsum.shape[2])
    C = T // L
    G = HV // H
    for name, tensor in (
        ("q", q), ("k", k), ("beta", beta), ("g_cumsum", g_cumsum),
        ("qk_left", qk_left), ("qk_right", qk_right), ("s_base", s_base), ("t_beta", t_beta),
        ("dq_hv_in", dq_hv_in), ("dk_hv_in", dk_hv_in), ("dg_core_in", dg_core_in),
    ):
        if tensor.dtype != bf16:
            raise TypeError(f"{name} must be bfloat16, got {tensor.dtype}")
    if dbeta_in.dtype != torch.float32:
        raise TypeError(f"dbeta_in must be float32 (inverse emits fp32), got {dbeta_in.dtype}")

    outputs = (
        torch.empty((B, HV, C, L, D), dtype=torch.float32, device=q.device),  # dq_hv'  intra-stage
        torch.empty((B, HV, C, L, D), dtype=torch.float32, device=q.device),  # dk_hv'
        torch.empty((B, T, HV), dtype=bf16, device=q.device),     # dbeta  public BTHV
        torch.empty((B, T, HV, D), dtype=bf16, device=q.device),  # dg     public BTHVD
    )
    previous_config = getattr(finalize_post_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "finalize_post")
    if simulator:
        finalize_post_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            finalize_post_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            g_cumsum, qk_left, qk_right, s_base, t_beta, q, k, beta,
            dq_hv_in, dk_hv_in, dbeta_in, dg_core_in,
            outputs[0], outputs[1], outputs[2], outputs[3],
            B, HV, C, H, G, shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(finalize_post_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                finalize_post_kernel._simulator_config = previous_config
    if gen_only:
        return result
    # Raw GM outputs: dq_hv'/dk_hv' [B, HV, C, L, D] fp32 (kept fp32 for the
    # HV->H sum precision), dbeta' [B, HV, C, L] fp32, dg [B, HV, C, L, D] bf16.
    # The driver passes dq_hv'/dk_hv' straight to finalize_reduce.
    return result[0], result[1], result[2], result[3]


if __name__ == "__main__":
    from projects.a5.kda_bwd.refs.common import make_inputs
    from _torch_formula import build_saved_forward, scan_bwd, inverse_bwd as inverse_ref

    tol = 8e-3
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    caches = build_saved_forward(inputs)
    scan = scan_bwd(inputs, caches)
    local = inverse_ref(inputs, caches, scan)

    B, T, H, Kd = inputs.q.shape
    HV = inputs.v.shape[2]
    G = HV // H
    bf = lambda x: x.to(torch.bfloat16).float()
    qf = inputs.q.float()[:, :, torch.arange(HV) // G, :]
    kf = inputs.k.float()[:, :, torch.arange(HV) // G, :]
    betaf, gf = inputs.beta.float(), caches.g_cumsum.float()
    dAqkf, dAkkf = scan.dAqk.float(), local.dAkk.float()
    dqhv_in = local.dq_hv.float(); dkhv_in = local.dk_hv.float()
    dbeta_in = local.dbeta.float(); dgcore_in = local.dg_core.float()
    exp2 = torch.exp2

    # finalize_pair inputs (qk_left/qk_right/s_base/t_beta), fed to the kernel.
    qk_left = torch.empty(B, T, HV, D); qk_right = torch.empty(B, T, HV, D)
    s_base = torch.empty(B, T, HV, D); t_beta = torch.empty(B, T, HV, D)
    e_dq = torch.empty(B, T, HV, D); e_dk = torch.empty(B, T, HV, D)
    e_db = torch.empty(B, T, HV); e_dg = torch.empty(B, T, HV, D)
    for b in builtins.range(B):
        for c in builtins.range(T // L):
            s, e = c * L, c * L + L
            for hv in builtins.range(HV):
                gb = gf[b, s:e, hv]; gl = gb[L - 1]
                rs = exp2(gb - gl); cs = exp2(gl - gb)
                qsc = qf[b, s:e, hv] * rs; ksc = kf[b, s:e, hv] * rs
                kg = kf[b, s:e, hv] * cs
                Mqk = torch.tril(dAqkf[b, s:e, hv])
                Mbase = torch.tril(dAkkf[b, s:e, hv], diagonal=-1)
                Mbeta = Mbase * betaf[b, s:e, hv][:, None]
                ql = bf(Mqk) @ bf(kg)
                qr = bf(Mqk).T @ bf(qsc)
                sb = bf(Mbase) @ bf(kg)
                tb = bf(Mbeta).T @ bf(ksc)
                qk_left[b, s:e, hv] = ql; qk_right[b, s:e, hv] = qr
                s_base[b, s:e, hv] = sb; t_beta[b, s:e, hv] = tb
                # host post-loop (fp32)
                dq_pair = rs * ql; dk_pair = cs * qr
                row_contrib = rs * sb; col_contrib = cs * tb
                dg_qk = qf[b, s:e, hv] * dq_pair - kf[b, s:e, hv] * dk_pair
                dk_kk = betaf[b, s:e, hv][:, None] * row_contrib + col_contrib
                dbeta_add = (kf[b, s:e, hv] * row_contrib).sum(dim=-1)
                dg_kk = betaf[b, s:e, hv][:, None] * kf[b, s:e, hv] * row_contrib - kf[b, s:e, hv] * col_contrib
                e_dq[b, s:e, hv] = dqhv_in[b, s:e, hv] + dq_pair
                e_dk[b, s:e, hv] = dkhv_in[b, s:e, hv] + dk_pair + dk_kk
                e_db[b, s:e, hv] = dbeta_in[b, s:e, hv] + dbeta_add
                dg_blk = dgcore_in[b, s:e, hv] + dg_qk + dg_kk
                e_dg[b, s:e, hv] = torch.flip(torch.cumsum(torch.flip(dg_blk, dims=(0,)), dim=0), dims=(0,))

    bf16 = torch.bfloat16
    # Public/inter-stage inputs fed raw BTHVD (q/k ungathered [B,T,H,D]; dbeta_in
    # fp32). Only the intra-stage finalize_pair outputs qk_* are GM-native (to_lvd).
    # dq_hv'/dk_hv' come back GM-native (flat_lvd); dbeta/dg are public BTHVD.
    got = run(
        inputs.q, inputs.k, inputs.beta, caches.g_cumsum,
        to_lvd(qk_left.to(bf16)), to_lvd(qk_right.to(bf16)), to_lvd(s_base.to(bf16)), to_lvd(t_beta.to(bf16)),
        local.dq_hv.to(bf16), local.dk_hv.to(bf16),
        dbeta_in, local.dg_core.to(bf16),  # dbeta_in is fp32 (matches the inverse kernel's fp32 emit)
        simulator=True,
    )
    got = (flat_lvd(got[0]), flat_lvd(got[1]), got[2], got[3])
    refs = (e_dq, e_dk, e_db, e_dg)
    names = ("dq_hv'", "dk_hv'", "dbeta'", "dg")
    for name, g, r in zip(names, got, refs):
        torch.testing.assert_close(g.float(), r, rtol=tol, atol=tol)
        print(f"{name}: max_abs={(g.float() - r).abs().max().item():.3e} OK")
    print([tuple(item.shape) for item in got], [item.dtype for item in got])
