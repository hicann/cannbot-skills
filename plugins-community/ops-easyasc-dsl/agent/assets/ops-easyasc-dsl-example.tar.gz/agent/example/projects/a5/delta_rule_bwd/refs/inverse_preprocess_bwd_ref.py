"""Pure PyTorch reference for the inverse/preprocess backward stage (ungated)."""

from common import core_scan_bwd, inverse_preprocess_bwd, make_inputs, wu_recompute_bwd


def subkernel(key, beta, wu_attn_bf16, d_wu):
    return inverse_preprocess_bwd(key, beta, wu_attn_bf16, d_wu)


if __name__ == "__main__":
    args = make_inputs()
    scan = core_scan_bwd(args[0], args[1], args[4], args[7], args[8], args[9], args[10])
    wu = wu_recompute_bwd(args[1], args[2], args[3], args[5], scan[2], scan[3])
    result = subkernel(args[1], args[3], args[5], wu[0])
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
