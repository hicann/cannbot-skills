"""KDA forward sub2: intra-chunk Aqk and unit-lower Akk from `eg`.

A5 implementation specialized to L=64, K=128 with dynamic B, H, HV, and C
where HV is a positive multiple of H. The score products consume
`eg = exp(cumsum(g_raw, dim=L))` from sub1 and follow the upstream/naive
algebra:

    Aqk = (q * eg * scale) @ (k / eg).T
    strict = -(k * eg * beta) @ (k / eg).T
    Akk = inverse(I - strict_lower(strict))

The dense K reductions run on cube. VF prepares `q*eg*scale`, `-k*eg*beta`,
and `k/eg`, then a merged post-mask VF applies both the inclusive Aqk mask and
the strict-lower Akk workspace mask after cube writes the full score tiles back
to UB. The strict-lower inverse is delegated to the existing A5 64x64 block
inverse kernel used by GDN, which already owns the 16x16 triangular solve
schedule.
"""

import argparse
import os
from pathlib import Path
import sys

import torch

_REPO_ROOT = Path(__file__).resolve().parents[4]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

_GDN_KERNELS_DIR = _REPO_ROOT / "projects" / "a5" / "gdn_fwd" / "kernels"
if str(_GDN_KERNELS_DIR) not in sys.path:
    sys.path.insert(0, str(_GDN_KERNELS_DIR))

from easyasc.a5 import *  # noqa: F401,F403
from easyasc.simulator import SimulatorConfig
from tril_inverse64 import (  # noqa: E402
    SHAPE_BINDINGS as TRIL_INVERSE_SHAPE_BINDINGS,
    tril_inverse64_v2_strict_bf16_kernel,
)


L = 64
K_DIM = 128
K_BLOCK = 64
K_TILES = K_DIM // K_BLOCK
HALF_L = L // 2
DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 300.0

SHAPE_BINDINGS = {
    0: [0, 1, 3, 4, 5],  # q[B,H,C,L,K]
    1: [0, 1, 3, 4, 5],  # k[B,H,C,L,K]
    2: [0, 2, 3, 4, 5],  # eg[B,HV,C,L,K]
    3: [0, 2, 3, 4],     # beta[B,HV,C,L]
    4: [0, 2, 3, 4, 4],  # Aqk[B,HV,C,L,L]
    5: [0, 2, 3, 4, 4],  # strict[B,HV,C,L,L], fp32 workspace for inverse
}


@vf()
def score_preprocess_vf(
    q_ub: Tensor,
    k_ub: Tensor,
    eg_ub: Tensor,
    beta_ub: Tensor,
    qg_ub: Tensor,
    kbg_ub: Tensor,
    kgneg_ub: Tensor,
    rows: Var,
    scale: Var,
):
    q_row = Reg(DT.float)
    k_row = Reg(DT.float)
    eg_row = Reg(DT.float)
    beta_val = Reg(DT.float)
    out_row = Reg(DT.float)

    for r in range(rows):
        beta_val <<= beta_ub[0:1, r:r + 1].single()
        for tile in range(K_TILES):
            k_begin = tile * K_BLOCK
            k_end = k_begin + K_BLOCK
            q_row <<= q_ub[r:r + 1, k_begin:k_end]
            k_row <<= k_ub[r:r + 1, k_begin:k_end]
            eg_row <<= eg_ub[r:r + 1, k_begin:k_end]

            out_row <<= q_row * eg_row
            out_row <<= out_row * scale
            qg_ub[r:r + 1, k_begin:k_end] <<= out_row

            out_row <<= k_row * eg_row
            out_row <<= out_row * beta_val
            out_row <<= out_row.neg()
            kbg_ub[r:r + 1, k_begin:k_end] <<= out_row

            out_row <<= k_row / eg_row
            kgneg_ub[r:r + 1, k_begin:k_end] <<= out_row


@vf()
def apply_score_masks_vf(
    aqk_full_ub: Tensor,
    strict_full_ub: Tensor,
    aqk_out_ub: Tensor,
    strict_out_ub: Tensor,
    row_begin: Var,
    rows: Var,
):
    cols = Reg(DT.int)
    zero = Reg(DT.float)
    aqk_row = Reg(DT.float)
    strict_row = Reg(DT.float)
    aqk_masked = Reg(DT.float)
    strict_masked = Reg(DT.float)
    aqk_bf16 = Reg(DT.bfloat16)
    lower_eq_mask = MaskReg(DT.int, init_mode=MaskType.NONE)
    strict_lower_mask = MaskReg(DT.int, init_mode=MaskType.NONE)
    row_mask_bf16 = MaskReg(DT.bfloat16, init_mode=MaskType.NONE)

    zero <<= 0.0
    cols.arange(0)
    row_mask_bf16 <<= Var(L * 2, dtype=DT.uint32)

    for r in range(rows):
        abs_r = Var(row_begin + r)

        aqk_row <<= aqk_full_ub[r:r + 1, 0:L]
        compare(lower_eq_mask, cols, abs_r + 1, CompareMode.LT)
        select(aqk_masked, aqk_row, zero, mask=lower_eq_mask)
        aqk_bf16 <<= aqk_masked.astype(DT.bfloat16)
        reg_to_ub_downsample(aqk_out_ub[r:r + 1, 0:L], aqk_bf16, mask=row_mask_bf16)

        strict_row <<= strict_full_ub[r:r + 1, 0:L]
        compare(strict_lower_mask, cols, abs_r, CompareMode.LT)
        select(strict_masked, strict_row, zero, mask=strict_lower_mask)
        strict_out_ub[r:r + 1, 0:L] <<= strict_masked


@kernel()
def kda_sub2_score_kernel(
    q: GMTensor,
    k: GMTensor,
    eg: GMTensor,
    beta: GMTensor,
    Aqk: GMTensor,
    strict: GMTensor,
    B: Var,
    H: Var,
    HV: Var,
    C: Var,
    length_per_chunk: Var,
    head_dim: Var,
    scale: Var,
):
    vcmutex = VcMutex(
        0,
        depth=2,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    score_cvmutex = CvMutex(
        1,
        depth=2,
        src_start_pipe=Pipe.FIX,
        dst_start_pipe=Pipe.V,
        src_end_pipe=Pipe.FIX,
        dst_end_pipe=Pipe.V,
    )
    l1_qg = DBuff(DT.float, [L, K_DIM], Position.L1)
    l1_kbg = DBuff(DT.float, [L, K_DIM], Position.L1)
    l1_kgneg = DBuff(DT.float, [L, K_DIM], Position.L1)
    l0c_aqk = DBuff(DT.float, [L, L], Position.L0C)
    l0c_strict = DBuff(DT.float, [L, L], Position.L0C)

    q_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)
    k_ub = DBuff(DT.bfloat16, [HALF_L, K_DIM], Position.UB)
    eg_ub = DBuff(DT.float, [HALF_L, K_DIM], Position.UB)
    beta_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    qg_ub = DBuff(DT.float, [HALF_L, K_DIM], Position.UB)
    kbg_ub = DBuff(DT.float, [HALF_L, K_DIM], Position.UB)
    kgneg_ub = DBuff(DT.float, [HALF_L, K_DIM], Position.UB)
    aqk_full_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    strict_full_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    aqk_out_ub = DBuff(DT.bfloat16, [HALF_L, L], Position.UB)
    strict_out_ub = DBuff(DT.float, [HALF_L, L], Position.UB)

    work_count = B * HV * C
    work_per_cube = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_cube * GetCubeIdx())
    work_end = Min(work_begin + work_per_cube, work_count)
    group = Var(HV // H)
    pre_cnt = Var(0)
    cube_cnt = Var(0)
    post_cnt = Var(0)

    with auto_sync():
        for pipe_work in range(work_begin, work_end + 2):
            row_begin = Var(GetSubBlockIdx() * HALF_L)
            row_end = Min(row_begin + HALF_L, L)
            rows_this = Var(row_end - row_begin)

            if pipe_work < work_end:
                c_idx = Var(pipe_work % C)
                tmp = Var(pipe_work // C)
                hv_idx = Var(tmp % HV)
                b_idx = Var(tmp // HV)
                h_idx = Var(hv_idx // group)

                q_ub[pre_cnt][0:rows_this, 0:K_DIM] <<= q[b_idx, h_idx, c_idx, row_begin:row_end, 0:K_DIM]
                k_ub[pre_cnt][0:rows_this, 0:K_DIM] <<= k[b_idx, h_idx, c_idx, row_begin:row_end, 0:K_DIM]
                eg_ub[pre_cnt][0:rows_this, 0:K_DIM] <<= eg[b_idx, hv_idx, c_idx, row_begin:row_end, 0:K_DIM]
                beta_ub[pre_cnt][0:1, 0:rows_this] <<= beta[b_idx, hv_idx, c_idx, row_begin:row_end]
                score_preprocess_vf(
                    q_ub[pre_cnt],
                    k_ub[pre_cnt],
                    eg_ub[pre_cnt],
                    beta_ub[pre_cnt],
                    qg_ub[pre_cnt],
                    kbg_ub[pre_cnt],
                    kgneg_ub[pre_cnt],
                    rows_this,
                    scale,
                )

                vcmutex.lock()
                l1_qg[pre_cnt][row_begin:row_end, 0:K_DIM] <<= qg_ub[pre_cnt][0:rows_this, 0:K_DIM]
                l1_kbg[pre_cnt][row_begin:row_end, 0:K_DIM] <<= kbg_ub[pre_cnt][0:rows_this, 0:K_DIM]
                l1_kgneg[pre_cnt][row_begin:row_end, 0:K_DIM] <<= kgneg_ub[pre_cnt][0:rows_this, 0:K_DIM]
                vcmutex.ready()
                pre_cnt += 1

            if (pipe_work > work_begin) and (pipe_work < work_end + 1):
                vcmutex.wait()
                matmul(l0c_aqk[cube_cnt], l1_qg[cube_cnt], l1_kgneg[cube_cnt], splitk=K_BLOCK, m=L, n=L, k=K_DIM)
                matmul(l0c_strict[cube_cnt], l1_kbg[cube_cnt], l1_kgneg[cube_cnt], splitk=K_BLOCK, m=L, n=L, k=K_DIM)
                vcmutex.free()
                score_cvmutex.lock()
                aqk_full_ub[cube_cnt] <<= l0c_aqk[cube_cnt]
                strict_full_ub[cube_cnt] <<= l0c_strict[cube_cnt]
                score_cvmutex.ready()
                cube_cnt += 1

            if pipe_work > work_begin + 1:
                work = Var(pipe_work - 2)
                c_idx = Var(work % C)
                tmp = Var(work // C)
                hv_idx = Var(tmp % HV)
                b_idx = Var(tmp // HV)

                score_cvmutex.wait()
                apply_score_masks_vf(
                    aqk_full_ub[post_cnt],
                    strict_full_ub[post_cnt],
                    aqk_out_ub[post_cnt],
                    strict_out_ub[post_cnt],
                    row_begin,
                    rows_this,
                )
                score_cvmutex.free()
                Aqk[b_idx, hv_idx, c_idx, row_begin:row_end, 0:L] <<= aqk_out_ub[post_cnt][0:rows_this, 0:L]
                strict[b_idx, hv_idx, c_idx, row_begin:row_end, 0:L] <<= strict_out_ub[post_cnt][0:rows_this, 0:L]
                post_cnt += 1

    return Aqk, strict


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_fwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def _trace_child(trace_path, suffix):
    if not trace_path:
        return None
    path = Path(trace_path)
    return str(path.with_name(path.stem + "_" + suffix + path.suffix))


def _stage_out_dir(out_dir, name):
    if not out_dir:
        return ""
    return str(Path(out_dir) / name)


def _check_contract(q, k, eg, beta):
    B, H, C, length_per_chunk, head_dim = q.shape
    HV = eg.shape[1]
    if length_per_chunk != L or head_dim != K_DIM:
        raise ValueError(f"sub2_intra is specialized for L={L}, K={K_DIM}, got L={length_per_chunk}, K={head_dim}")
    if q.dtype != torch.bfloat16 or k.dtype != torch.bfloat16:
        raise TypeError("q and k must be torch.bfloat16")
    if eg.dtype != torch.float32 or beta.dtype != torch.float32:
        raise TypeError("eg and beta must be torch.float32")
    if HV % H != 0:
        raise ValueError(f"HV must be divisible by H, got H={H}, HV={HV}")
    return B, H, HV, C, length_per_chunk, head_dim


def _set_sim_config(kernel_func, simulator, trace_path, timeout_s, core_count=None):
    previous_config = getattr(kernel_func, "_simulator_config", None)
    if simulator:
        kernel_func._simulator_config = SimulatorConfig(
            core_count=core_count or DEFAULT_CORE_COUNT,
            execution_timeout_s=timeout_s,
            trace_enabled=bool(trace_path),
        )
    return previous_config


def _restore_sim_config(kernel_func, previous_config, simulator):
    if not simulator:
        return
    if previous_config is None:
        try:
            delattr(kernel_func, "_simulator_config")
        except AttributeError:
            pass
    else:
        kernel_func._simulator_config = previous_config


def run(q, k, eg, beta, scale, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False, core_count=None):
    B, H, HV, C, length_per_chunk, head_dim = _check_contract(q, k, eg, beta)
    Aqk = torch.empty((B, HV, C, L, L), dtype=q.dtype, device=q.device)
    strict = torch.empty((B, HV, C, L, L), dtype=torch.float32, device=q.device)
    Akk = torch.empty((B, HV, C, L, L), dtype=k.dtype, device=k.device)

    trace_path = _trace_path(trace, out_dir, "sub2_intra")
    score_trace = _trace_child(trace_path, "scores") if trace_path else None
    inverse_trace = _trace_child(trace_path, "inverse") if trace_path else None
    score_out_dir = _stage_out_dir(out_dir, "sub2_scores")
    inverse_out_dir = _stage_out_dir(out_dir, "sub2_inverse")

    prev_score_config = _set_sim_config(kda_sub2_score_kernel, simulator, score_trace, DEFAULT_SIM_TIMEOUT_S, core_count)
    prev_inverse_config = _set_sim_config(
        tril_inverse64_v2_strict_bf16_kernel,
        simulator,
        inverse_trace,
        DEFAULT_SIM_TIMEOUT_S,
        core_count,
    )
    try:
        Aqk, strict = OpExec(
            kda_sub2_score_kernel,
            out_dir=score_out_dir,
            simulator=simulator,
            trace=score_trace,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(q, k, eg, beta, Aqk, strict, B, H, HV, C, length_per_chunk, head_dim, scale, shape_bindings=SHAPE_BINDINGS)

        Akk = OpExec(
            tril_inverse64_v2_strict_bf16_kernel,
            out_dir=inverse_out_dir,
            simulator=simulator,
            trace=inverse_trace,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(strict, Akk, B, HV, C, shape_bindings=TRIL_INVERSE_SHAPE_BINDINGS)
    finally:
        _restore_sim_config(kda_sub2_score_kernel, prev_score_config, simulator)
        _restore_sim_config(tril_inverse64_v2_strict_bf16_kernel, prev_inverse_config, simulator)
    return Aqk, Akk


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run KDA forward sub2_intra smoke or hardware profile case.")
    parser.add_argument("--hardware-profile", action="store_true", help="Run the real-hardware profile case: simulator=False, profile=True, B=1, H=HV=32, C=16.")
    parser.add_argument("--out-dir", default="", help="Output directory for generated hardware artifacts.")
    parser.add_argument("--skip-compile", action="store_true", help="Reuse previously compiled artifacts for the hardware profile run.")
    parser.add_argument("--gen-only", action="store_true", help="Generate hardware artifacts without running them.")
    parser.add_argument("--seed", type=int, default=21, help="Random seed for generated inputs.")
    parser.add_argument("--core-count", type=int, default=DEFAULT_CORE_COUNT, help="Simulator core count for non-hardware runs.")
    parser.add_argument("--trace", default=None, help="Path to write simulator traces for non-hardware runs.")
    args = parser.parse_args()

    refs_dir = Path(__file__).resolve().parents[1] / "refs"
    if str(refs_dir) not in sys.path:
        sys.path.insert(0, str(refs_dir))
    from oracle import sample_inputs as oracle_sample_inputs, to_chunked_inputs
    from sub1_gate_ref import subkernel as ref_sub1_gate
    from sub2_intra_ref import subkernel as ref_sub2_intra

    if args.hardware_profile:
        q_full, k_full, v_full, g_raw_full, beta_full, _initial_state = oracle_sample_inputs(
            B=1, H=32, HV=32, C=16, L=L, K=K_DIM, V=K_DIM, seed=args.seed
        )
        q, k, _v, g_raw, beta = to_chunked_inputs(q_full, k_full, v_full, g_raw_full, beta_full, chunk_size=L)
        eg = ref_sub1_gate(g_raw)
        scale = K_DIM ** -0.5
        out_dir = args.out_dir or "./tmp/kda_sub2_intra_hardware_profile"
        result = run(
            q,
            k,
            eg,
            beta,
            scale,
            simulator=False,
            profile=True,
            gen_only=args.gen_only,
            out_dir=out_dir,
            skip_compile=args.skip_compile,
        )
        outputs = result if isinstance(result, tuple) else (result,)
        if args.gen_only:
            for name, out in zip(("Aqk", "Akk"), outputs):
                print(f"{name}: shape={tuple(out.shape)} dtype={out.dtype}")
            print("pytorch verification skipped for --gen-only because no hardware output was produced")
        else:
            expected = ref_sub2_intra(q, k, eg, beta, scale)
            for name, got, ref in zip(("Aqk", "Akk"), outputs, expected):
                torch.testing.assert_close(got.float(), ref.float(), rtol=2e-2, atol=2e-2)
                max_abs = float((got.float() - ref.float()).abs().max())
                print(f"{name}: shape={tuple(got.shape)} dtype={got.dtype} max_abs={max_abs:.6e} OK")
        print(f"hardware profile case complete: B=1 H=32 HV=32 C=16 out_dir={out_dir}")
        raise SystemExit(0)

    q_full, k_full, v_full, g_raw_full, beta_full, _initial_state = oracle_sample_inputs(
        B=1, H=8, HV=8, C=8, L=L, K=K_DIM, V=K_DIM, seed=args.seed
    )
    q, k, _v, g_raw, beta = to_chunked_inputs(q_full, k_full, v_full, g_raw_full, beta_full, chunk_size=L)
    eg = ref_sub1_gate(g_raw)
    scale = K_DIM ** -0.5
    result = run(q, k, eg, beta, scale, trace=args.trace, core_count=args.core_count)
    expected = ref_sub2_intra(q, k, eg, beta, scale)
    for name, got, ref in zip(("Aqk", "Akk"), result, expected):
        torch.testing.assert_close(got.float(), ref.float(), rtol=2e-2, atol=2e-2)
        max_abs = float((got.float() - ref.float()).abs().max())
        print(f"{name}: shape={tuple(got.shape)} dtype={got.dtype} max_abs={max_abs:.6e}")
