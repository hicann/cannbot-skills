"""Pure PyTorch composition check for the simplified kda_bwd path."""

from common import (
    ATOL,
    RTOL,
    build_saved_forward,
    compare_outputs,
    local_mids_from_tuple,
    make_inputs,
    oracle,
    outputs_from_tuple,
    scan_mids_from_tuple,
)
from finalize_bwd_ref import subkernel as finalize_bwd
from inverse_bwd_ref import subkernel as inverse_bwd
from scan_bwd_ref import subkernel as scan_bwd


def composed(inputs):
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    scan = scan_mids_from_tuple(
        scan_bwd(
            caches.g_cumsum,
            caches.Aqk,
            caches.qg,
            caches.kg,
            caches.w,
            caches.u,
            caches.v_new,
            caches.h,
            inputs.do,
            inputs.dht,
            inputs.chunk_size,
        )
    )
    local = local_mids_from_tuple(
        inverse_bwd(
            inputs.q,
            inputs.k,
            inputs.v,
            inputs.beta,
            inputs.do,
            caches.g_cumsum,
            caches.Akk,
            caches.h,
            caches.v_new,
            scan.dh,
            scan.dv,
            inputs.chunk_size,
        )
    )
    return outputs_from_tuple(
        finalize_bwd(
            inputs.q,
            inputs.k,
            inputs.beta,
            caches.g_cumsum,
            scan.dAqk,
            local.dq_hv,
            local.dk_hv,
            local.dv,
            local.dbeta,
            local.dg_core,
            local.dAkk,
            scan.dh0,
            inputs.chunk_size,
        )
    )


def main():
    cases = [
        ("aligned_grouped", make_inputs(B=1, H=2, HV=4, T=8, K=8, V=6, chunk_size=4, seed=101)),
        ("tail_grouped", make_inputs(B=2, H=1, HV=3, T=10, K=6, V=5, chunk_size=4, seed=103)),
    ]
    for name, inputs in cases:
        actual = composed(inputs)
        expected = oracle(inputs)
        compare_outputs(actual, expected, ATOL, RTOL)
        print("compose %s: atol=%.1e rtol=%.1e OK" % (name, ATOL, RTOL))


if __name__ == "__main__":
    main()
