import os

import torch


from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig


SIM_CORE_COUNT = 32
SIM_TIMEOUT_S = 180.0

L = 64
D = 128
HALF_L = L // 2
HALF_D = D // 2
REGS_PER_ROW_D = D // 64
REGS_PER_FOUR_ROWS_D = REGS_PER_ROW_D * 4
BF16_C0 = 16

SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
    2: [0, 1, 2, None, None],
    3: [0, 1, 2, None, None],
    4: [0, 1, 2, None, None],
    5: [0, 1, 2, None],
    6: [0, 1, None, None],
    7: [0, 1, 2, None, None],
    8: [0, 1, None, None],
    9: [0, 1, 2, None, None],
    10: [0, 1, 2, None, None],
    11: [0, 1, 2, None, None],
    12: [0, 1, 2, None],
}


@vf()
def make_v_new_vf(v_prime_ub: Tensor, v_ub: Tensor, v_new_ub: Tensor):
    prime_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    v_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    for row_quad in range(HALF_L // 4):
        r = row_quad * 4
        prime_regs <<= v_prime_ub[r:r + 4, 0:D]
        v_regs <<= v_ub[r:r + 4, 0:D]
        v_regs <<= v_regs - prime_regs
        v_new_ub[r:r + 4, 0:D] <<= v_regs


@vf()
def apply_g_gate_vf(q_state_ub: Tensor, g_ub: Tensor, attn_inter_ub: Tensor):
    q_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    g0_reg = Reg(DT.float)
    g1_reg = Reg(DT.float)
    g2_reg = Reg(DT.float)
    g3_reg = Reg(DT.float)
    scale0_reg = Reg(DT.float)
    scale1_reg = Reg(DT.float)
    scale2_reg = Reg(DT.float)
    scale3_reg = Reg(DT.float)
    for row_quad in range(HALF_L // 4):
        r = row_quad * 4
        q_regs <<= q_state_ub[r:r + 4, 0:D]
        g0_reg <<= g_ub[0:1, r:r + 1].single()
        g1_reg <<= g_ub[0:1, r + 1:r + 2].single()
        g2_reg <<= g_ub[0:1, r + 2:r + 3].single()
        g3_reg <<= g_ub[0:1, r + 3:r + 4].single()
        scale0_reg <<= g0_reg.exp()
        scale1_reg <<= g1_reg.exp()
        scale2_reg <<= g2_reg.exp()
        scale3_reg <<= g3_reg.exp()
        q_regs[0] <<= q_regs[0] * scale0_reg
        q_regs[1] <<= q_regs[1] * scale0_reg
        q_regs[2] <<= q_regs[2] * scale1_reg
        q_regs[3] <<= q_regs[3] * scale1_reg
        q_regs[4] <<= q_regs[4] * scale2_reg
        q_regs[5] <<= q_regs[5] * scale2_reg
        q_regs[6] <<= q_regs[6] * scale3_reg
        q_regs[7] <<= q_regs[7] * scale3_reg
        attn_inter_ub[r:r + 4, 0:D] <<= q_regs


@vf()
def make_kexp_vf(
    k_ub: Tensor,
    g_ub: Tensor,
    g_last: Var,
    k_exp_ub: Tensor,
    k_exp_nd_ub: Tensor,
    exp_delta_ub: Tensor,
):
    gl = Reg(DT.float)
    g0 = Reg(DT.float)
    g1 = Reg(DT.float)
    g2 = Reg(DT.float)
    g3 = Reg(DT.float)
    scale0 = Reg(DT.float)
    scale1 = Reg(DT.float)
    scale2 = Reg(DT.float)
    scale3 = Reg(DT.float)
    kf = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    gl <<= g_last
    for row_quad in range(HALF_L // 4):
        r = row_quad * 4
        g0 <<= g_ub[0:1, r:r + 1].single()
        g1 <<= g_ub[0:1, r + 1:r + 2].single()
        g2 <<= g_ub[0:1, r + 2:r + 3].single()
        g3 <<= g_ub[0:1, r + 3:r + 4].single()
        scale0 <<= gl - g0
        scale1 <<= gl - g1
        scale2 <<= gl - g2
        scale3 <<= gl - g3
        scale0 <<= scale0.exp()
        scale1 <<= scale1.exp()
        scale2 <<= scale2.exp()
        scale3 <<= scale3.exp()
        exp_delta_ub[0:1, r + 0:r + 1] <<= scale0.single_value()
        exp_delta_ub[0:1, r + 1:r + 2] <<= scale1.single_value()
        exp_delta_ub[0:1, r + 2:r + 3] <<= scale2.single_value()
        exp_delta_ub[0:1, r + 3:r + 4] <<= scale3.single_value()
        kf <<= k_ub[r:r + 4, 0:D]
        kf[0] <<= kf[0] * scale0
        kf[1] <<= kf[1] * scale0
        kf[2] <<= kf[2] * scale1
        kf[3] <<= kf[3] * scale1
        kf[4] <<= kf[4] * scale2
        kf[5] <<= kf[5] * scale2
        kf[6] <<= kf[6] * scale3
        kf[7] <<= kf[7] * scale3
        lo_bf16 <<= kf[0].astype(DT.bfloat16)
        hi_bf16 <<= kf[1].astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_exp_ub[(r + 0) * BF16_C0], row_bf16, HALF_L)
        reg_to_ub(k_exp_nd_ub[r + 0:r + 1, 0:D], row_bf16)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        lo_bf16 <<= kf[2].astype(DT.bfloat16)
        hi_bf16 <<= kf[3].astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_exp_ub[(r + 1) * BF16_C0], row_bf16, HALF_L)
        reg_to_ub(k_exp_nd_ub[r + 1:r + 2, 0:D], row_bf16)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        lo_bf16 <<= kf[4].astype(DT.bfloat16)
        hi_bf16 <<= kf[5].astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_exp_ub[(r + 2) * BF16_C0], row_bf16, HALF_L)
        reg_to_ub(k_exp_nd_ub[r + 2:r + 3, 0:D], row_bf16)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)
        lo_bf16 <<= kf[6].astype(DT.bfloat16)
        hi_bf16 <<= kf[7].astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_exp_ub[(r + 3) * BF16_C0], row_bf16, HALF_L)
        reg_to_ub(k_exp_nd_ub[r + 3:r + 4, 0:D], row_bf16)
        vf_barrier(VfPipe.STORE, VfPipe.STORE)


@vf()
def add_vf(a_ub: Tensor, b_ub: Tensor, out_ub: Tensor):
    a_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    b_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    for row_quad in range(HALF_L // 4):
        r = row_quad * 4
        a_regs <<= a_ub[r:r + 4, 0:D]
        b_regs <<= b_ub[r:r + 4, 0:D]
        a_regs <<= a_regs + b_regs
        out_ub[r:r + 4, 0:D] <<= a_regs


@vf()
def cast_l_rows_float_to_bf16_vf(src_ub: Tensor, dst_ub: Tensor):
    regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    for row_quad in range(HALF_L // 4):
        r = row_quad * 4
        regs <<= src_ub[r:r + 4, 0:D]
        dst_ub[r:r + 4, 0:D] <<= regs


@vf()
def cast_d_rows_vf(src_ub: Tensor, dst_ub: Tensor):
    regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    for row_quad in range(HALF_D // 4):
        r = row_quad * 4
        regs <<= src_ub[r:r + 4, 0:D]
        dst_ub[r:r + 4, 0:D] <<= regs


@vf()
def pack_bf16_rows_to_nz_vf(src_nd: Tensor, dst_nz: Tensor, rows: Var):
    row = Reg(DT.bfloat16)
    for r in range(rows):
        row <<= src_nd[r:r + 1, 0:D]
        reg_to_ub(dst_nz[r * BF16_C0], row, rows)


@vf()
def state_update_vf(state_old_ub: Tensor, delta_ub: Tensor, g_last: Var, out_ub: Tensor):
    scale = Reg(DT.float)
    delta_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    state_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    scale <<= g_last
    scale <<= scale.exp()
    for row_quad in range(HALF_D // 4):
        r = row_quad * 4
        delta_regs <<= delta_ub[r:r + 4, 0:D]
        state_regs <<= state_old_ub[r:r + 4, 0:D]
        state_regs <<= state_regs * scale
        delta_regs <<= delta_regs + state_regs
        out_ub[r:r + 4, 0:D] <<= delta_regs


@kernel()
def sub2_kernel(
    attn: GMTensor,
    q_i: GMTensor,
    k_i: GMTensor,
    v_i: GMTensor,
    k_cumdecay_i: GMTensor,
    g_i: GMTensor,
    last_recurrent_state: GMTensor,
    core_attn_out: GMTensor,
    new_recurrent_state: GMTensor,
    state_after_history: GMTensor,
    v_new_history: GMTensor,
    k_weighted_history: GMTensor,
    exp_delta_history: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    bh_count = B * H
    bh_per_core = CeilDiv(bh_count, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, bh_count)

    cvmutex = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    state_mutex = VcMutex(1, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    vnew_mutex = VcMutex(2, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    kexp_mutex = VcMutex(3, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1_state = Tensor(DT.bfloat16, [D, D], Position.L1)
    l1_kcd = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_q = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_attn = Tensor(DT.bfloat16, [L, L], Position.L1)
    l1_v_new = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_kexp = Tensor(DT.bfloat16, [L, D], Position.L1)

    l0c_ld = Tensor(DT.float, [L, D], Position.L0C)
    l0c_dxd = Tensor(DT.float, [D, D], Position.L0C)

    ub_prod = Tensor(DT.float, [HALF_L, D], Position.UB)
    ub_v = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_v_new = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_v_new_nz = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_g = Tensor(DT.float, [1, HALF_L], Position.UB)
    ub_exp_delta = Tensor(DT.float, [1, HALF_L], Position.UB)
    ub_attn_inter = Tensor(DT.float, [HALF_L, D], Position.UB)
    ub_out = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_k = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_kexp_nz = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_delta = Tensor(DT.float, [HALF_D, D], Position.UB)
    ub_state_nz = Tensor(DT.bfloat16, [HALF_D, D], Position.UB)
    ub_state = DBuff(DT.bfloat16, [HALF_D, D], Position.UB)
    state_read_cnt = Var(0)
    state_write_cnt = Var(1)
    kcd_read_cnt = Var(0)
    kcd_write_cnt = Var(0)
    g_last = Var(0.0, DT.float)

    for bh in range(bh_begin, bh_end):
        b_idx = Var(bh // H)
        h_idx = Var(bh % H)
        row_begin_l = Var(GetSubBlockIdx() * HALF_L)
        row_end_l = Var(row_begin_l + HALF_L)
        row_begin_d = Var(GetSubBlockIdx() * HALF_D)
        row_end_d = Var(row_begin_d + HALF_D)

        for c in range(C):
            ub_state_old = ub_state[state_read_cnt]
            ub_state_out = ub_state[state_write_cnt]
            with auto_sync():
                ub_v <<= v_i[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D]
                ub_g[0:1, 0:HALF_L] <<= g_i[b_idx, h_idx, c, row_begin_l:row_end_l]
                ub_k <<= k_i[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D]
                g_last.GetValueFrom(g_i[b_idx, h_idx, c, L - 1:L])
                if c != C - 1:
                    l1_kcd[kcd_write_cnt] <<= k_cumdecay_i[b_idx, h_idx, c + 1, 0:L, 0:D]
                    kcd_write_cnt += 1

                if c == 0:
                    pack_bf16_rows_to_nz_vf(ub_v, ub_v_new_nz, HALF_L)
                    vnew_mutex.lock()
                    l1_v_new[row_begin_l:row_end_l, 0:D] <<= ub_v_new_nz[0:HALF_L, 0:D].nz()
                    vnew_mutex.ready()
                    v_new_history[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D] <<= ub_v[0:HALF_L, 0:D]
                else:
                    pack_bf16_rows_to_nz_vf(ub_state_old, ub_state_nz, HALF_D)
                    state_mutex.lock()
                    l1_state[row_begin_d:row_end_d, 0:D] <<= ub_state_nz[0:HALF_D, 0:D].nz()
                    state_mutex.ready()

                    state_mutex.wait()

                    matmul(l0c_ld, l1_kcd[kcd_read_cnt], l1_state.T, m=L, n=D, k=D, splitn=D)

                    cvmutex.lock()
                    ub_prod <<= l0c_ld
                    cvmutex.ready()
                    cvmutex.wait()
                    make_v_new_vf(ub_prod, ub_v, ub_v_new)
                    cvmutex.free()
                    pack_bf16_rows_to_nz_vf(ub_v_new, ub_v_new_nz, HALF_L)

                    vnew_mutex.lock()
                    l1_v_new[row_begin_l:row_end_l, 0:D] <<= ub_v_new_nz[0:HALF_L, 0:D].nz()
                    vnew_mutex.ready()
                    v_new_history[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D] <<= ub_v_new[0:HALF_L, 0:D]

                    l1_q <<= q_i[b_idx, h_idx, c, 0:L, 0:D]
                    matmul(l0c_ld, l1_q, l1_state.T, m=L, n=D, k=D, splitn=D)
                    state_mutex.free()

                    cvmutex.lock()
                    ub_prod <<= l0c_ld
                    cvmutex.ready()
                    cvmutex.wait()
                    apply_g_gate_vf(ub_prod, ub_g, ub_attn_inter)
                    cvmutex.free()

                l1_attn <<= attn[b_idx, h_idx, c, 0:L, 0:L]

                kexp_mutex.lock()
                make_kexp_vf(ub_k, ub_g, g_last, ub_kexp_nz, ub_k, ub_exp_delta)
                l1_kexp[row_begin_l:row_end_l, 0:D] <<= ub_kexp_nz[0:HALF_L, 0:D].nz()
                kexp_mutex.ready()

                kexp_mutex.wait()
                vnew_mutex.wait()

                matmul(l0c_ld, l1_attn, l1_v_new.T, m=L, n=D, k=L, splitn=D)

                cvmutex.lock()
                ub_prod <<= l0c_ld
                cvmutex.ready()
                cvmutex.wait()
                if c == 0:
                    cast_l_rows_float_to_bf16_vf(ub_prod, ub_out)
                else:
                    add_vf(ub_prod, ub_attn_inter, ub_out)
                cvmutex.free()
                core_attn_out[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D] <<= ub_out[0:HALF_L, 0:D]
                k_weighted_history[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D] <<= ub_k[0:HALF_L, 0:D]
                exp_delta_history[b_idx, h_idx, c, row_begin_l:row_end_l] <<= ub_exp_delta[0:1, 0:HALF_L]

                matmul(l0c_dxd, l1_kexp.T, l1_v_new.T, m=D, n=D, k=L, splitn=D)
                kexp_mutex.free()
                vnew_mutex.free()

                cvmutex.lock()
                ub_delta <<= l0c_dxd
                cvmutex.ready()
                cvmutex.wait()
                if c == 0:
                    cast_d_rows_vf(ub_delta, ub_state_out)
                else:
                    state_update_vf(ub_state_old, ub_delta, g_last, ub_state_out)
                cvmutex.free()
                state_after_history[b_idx, h_idx, c, row_begin_d:row_end_d, 0:D] <<= ub_state_out[0:HALF_D, 0:D]
                if c == C - 1:
                    new_recurrent_state[b_idx, h_idx, row_begin_d:row_end_d, 0:D] <<= ub_state_out[0:HALF_D, 0:D]

            state_read_cnt += 1
            state_write_cnt += 1
            if c != 0:
                kcd_read_cnt += 1
        bar_all()

    return core_attn_out, new_recurrent_state, state_after_history, v_new_history, k_weighted_history, exp_delta_history


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "chunk_delta_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(
    attn, q_i, k_i, v_i, k_cumdecay_i, g_i, last_recurrent_state,
    simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=True,
):
    B = int(q_i.shape[0])
    H = int(q_i.shape[1])
    C = int(q_i.shape[2])
    device = q_i.device
    core_attn_out = torch.empty((B, H, C, L, D), dtype=torch.bfloat16, device=device)
    new_recurrent_state = torch.empty((B, H, D, D), dtype=torch.bfloat16, device=device)
    state_after_history = torch.empty((B, H, C, D, D), dtype=torch.bfloat16, device=device)
    v_new_history = torch.empty((B, H, C, L, D), dtype=torch.bfloat16, device=device)
    k_weighted_history = torch.empty((B, H, C, L, D), dtype=torch.bfloat16, device=device)
    exp_delta_history = torch.empty((B, H, C, L), dtype=torch.float32, device=device)
    trace_path = _trace_path(trace, out_dir, "sub2")

    saved_sim_config = getattr(sub2_kernel, "_simulator_config", None)
    if simulator:
        sub2_kernel._simulator_config = SimulatorConfig(
            core_count=SIM_CORE_COUNT,
            execution_timeout_s=SIM_TIMEOUT_S,
            trace_enabled=trace_path is not None,
        )

    try:
        result = OpExec(
            sub2_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            profile=profile,
            gen_only=gen_only,
            skip_compile=skip_compile,
        )(
            attn,
            q_i,
            k_i,
            v_i,
            k_cumdecay_i,
            g_i,
            last_recurrent_state,
            core_attn_out,
            new_recurrent_state,
            state_after_history,
            v_new_history,
            k_weighted_history,
            exp_delta_history,
            B,
            H,
            C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr(sub2_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                sub2_kernel._simulator_config = saved_sim_config

    return result


if __name__ == "__main__":
    torch.manual_seed(42)
    B = 1
    H = 1
    C = 2
    attn = (torch.randn((B, H, C, L, L), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    q_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    k_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    v_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    k_cumdecay_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    g_i = torch.randn((B, H, C, L), dtype=torch.float32) * 0.125
    last_recurrent_state = torch.zeros((B, H, D, D), dtype=torch.bfloat16)

    result = run(
        attn,
        q_i,
        k_i,
        v_i,
        k_cumdecay_i,
        g_i,
        last_recurrent_state,
        simulator=True,
    )
    outputs = result if isinstance(result, tuple) else (result,)
    summary = " ".join(f"{tuple(x.shape)} {x.dtype}" for x in outputs)
    print("sub2", summary)
