"""Randomized oracle check for sub-kernel sub2. Candidate F.

Location: `tmp_deepseek_decompose_delta_h/F/refs/sub2_check.py`

Runs N samples with inputs drawn from distributions wide enough to exercise
L1 bf16 downcast on M2 and M3 (identity on bf16-origin inputs).
"""

import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

from oracle import expected_sub1, expected_sub2  # noqa: E402
from sub2_ref import subkernel as sub2   # noqa: E402


ATOL = 2e-3
RTOL = 2e-3
N_SAMPLES = 32


def sample_inputs(B, H, C, L=64, D=128):
    q_i = torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05
    k_i = torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05
    v_i = torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05
    k_cumdecay_i = torch.randn(B, H, C, L, D, dtype=torch.bfloat16) * 0.05
    g_i = torch.randn(B, H, C, L, dtype=torch.float32) * 0.025
    decay_mask = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.1
    last_recurrent_state = torch.zeros(B, H, D, D, dtype=torch.bfloat16)
    attn = expected_sub1(q_i, k_i, decay_mask)
    return attn, q_i, k_i, v_i, k_cumdecay_i, g_i, last_recurrent_state


def check_case(case_name, B, H, C):
    max_abs_core = 0.0
    max_rel_core = 0.0
    max_abs_state = 0.0
    max_rel_state = 0.0
    for _ in range(N_SAMPLES):
        inputs = sample_inputs(B, H, C)
        ref_core, ref_state = expected_sub2(*inputs)
        sub_core, sub_state = sub2(*inputs)

        for ref, sub, label in [(ref_core, sub_core, "core"), (ref_state, sub_state, "state")]:
            if not torch.isfinite(ref).all() or not torch.isfinite(sub).all():
                print(f"FAIL [{case_name}]: non-finite value in {label}", file=sys.stderr)
                return False

            diff = (ref.float() - sub.float()).abs()
            denom = ref.float().abs().clamp_min(1e-12)
            if label == "core":
                max_abs_core = max(max_abs_core, float(diff.max()))
                max_rel_core = max(max_rel_core, float((diff / denom).max()))
            else:
                max_abs_state = max(max_abs_state, float(diff.max()))
                max_rel_state = max(max_rel_state, float((diff / denom).max()))

            if not torch.allclose(sub.float() if sub.dtype == torch.bfloat16 else sub,
                                  ref.float() if ref.dtype == torch.bfloat16 else ref,
                                  atol=ATOL, rtol=RTOL):
                max_abs = max_abs_core if label == "core" else max_abs_state
                max_rel = max_rel_core if label == "core" else max_rel_state
                print(f"sub2 [{case_name}] {label}: atol={max_abs:.3e} rtol={max_rel:.3e} "
                      f"(budget atol={ATOL}, rtol={RTOL})")
                print(f"FAIL [{case_name}]: exceeded policy budget ({label})", file=sys.stderr)
                return False

    print(f"sub2 [{case_name}] core: atol={max_abs_core:.3e} rtol={max_rel_core:.3e} "
          f"(budget atol={ATOL}, rtol={RTOL})")
    print(f"sub2 [{case_name}] state: atol={max_abs_state:.3e} rtol={max_rel_state:.3e} "
          f"(budget atol={ATOL}, rtol={RTOL})")
    return True


def main():
    cases = [
        ("aligned", 2, 4, 2),
        ("reuse_pressure", 8, 4, 3),
    ]
    all_passed = True
    for case_name, B, H, C in cases:
        if not check_case(case_name, B, H, C):
            all_passed = False
    if all_passed:
        print("OK")
        return 0
    else:
        return 1


if __name__ == "__main__":
    sys.exit(main())
