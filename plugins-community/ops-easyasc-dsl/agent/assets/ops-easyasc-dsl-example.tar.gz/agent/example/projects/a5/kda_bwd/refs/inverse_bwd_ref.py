"""Pure PyTorch reference for the saved-cache local WY/inverse backward stage."""

from common import KDAForwardCaches, KDAScanBwdMids, inverse_bwd, local_mids_as_tuple


def subkernel(q, k, v, beta, do, g_cumsum, Akk, h, v_new, dh, dv, chunk_size):
    zeros_k = g_cumsum.new_zeros(g_cumsum.shape)
    zeros_v = v_new.new_zeros(v_new.shape)
    caches = KDAForwardCaches(g_cumsum=g_cumsum, Aqk=Akk.new_zeros(Akk.shape), Akk=Akk, w=zeros_k, u=zeros_v, qg=zeros_k, kg=zeros_k, v_new=v_new, h=h)
    scan = KDAScanBwdMids(dAqk=Akk.new_zeros(Akk.shape), dh=dh, dv=dv, dh0=h[:, 0].new_zeros(h.shape[0], h.shape[2], h.shape[3], h.shape[4]))
    return local_mids_as_tuple(inverse_bwd(q, k, v, beta, do, caches, scan, chunk_size))


if __name__ == "__main__":
    from common import build_saved_forward, make_inputs, scan_bwd

    inputs = make_inputs(B=1, H=2, HV=4, T=8, K=8, V=6, chunk_size=4, seed=0)
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    scan = scan_bwd(inputs.do, inputs.dht, caches, inputs.chunk_size)
    result = subkernel(
        inputs.q,
        inputs.k,
        inputs.v,
        inputs.beta,
        inputs.do,
        caches.g_cumsum,
        caches.Akk,
        caches.h,
        caches.v_new,
        scan.dh,
        scan.dv,
        inputs.chunk_size,
    )
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
