import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _torch_formula import L, D, wu_recompute_bwd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
HALF_L = L // 2
REGS_D = D // 64
BF16_C0 = 16
SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
    2: [0, 1, 2, None],
    3: [0, 1, 2, None],
    4: [0, 1, 2, None, None],
    5: [0, 1, 2, None, None],
    6: [0, 1, 2, None, None],
    7: [0, 1, 2, None, None],
    8: [0, 1, 2, None, None],
    9: [0, 1, 2, None, None],
    10: [0, 1, 2, None],
}


@vf()
def make_wu_inputs_vf(
    key_ub: Tensor,
    value_ub: Tensor,
    beta_ub: Tensor,
    g_ub: Tensor,
    v_beta_nz_ub: Tensor,
    k_beta_g_nz_ub: Tensor,
    k_beta_ub: Tensor,
    exp_g_ub: Tensor,
    rows: Var,
):
    beta_reg = Reg(DT.float)
    g_reg = Reg(DT.float)
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)

    for r in range(rows):
        beta_reg <<= beta_ub[0:1, r:r + 1].single()
        g_reg <<= g_ub[0:1, r:r + 1].single()
        g_reg <<= g_reg.exp()
        exp_g_ub[0:1, r:r + 1] <<= g_reg.single_value()

        row_lo <<= value_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * beta_reg
        row_hi <<= value_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * beta_reg
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(v_beta_nz_ub[r * BF16_C0], row_bf16, rows)

        row_lo <<= key_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * beta_reg
        k_beta_ub[r:r + 1, 0:64] <<= row_lo
        row_lo <<= row_lo * g_reg
        row_hi <<= key_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * beta_reg
        k_beta_ub[r:r + 1, 64:D] <<= row_hi
        row_hi <<= row_hi * g_reg
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_beta_g_nz_ub[r * BF16_C0], row_bf16, rows)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def finalize_wu_partials_vf(
    d_k_beta_g_ub: Tensor,
    k_beta_ub: Tensor,
    exp_g_ub: Tensor,
    d_k_beta_ub: Tensor,
    d_g_ub: Tensor,
    rows: Var,
):
    d_k_beta_regs = RegList(DT.float, REGS_D)
    k_beta_regs = RegList(DT.float, REGS_D)
    tmp_regs = RegList(DT.float, REGS_D)
    exp_g = Reg(DT.float)
    d_g = Reg(DT.float)

    for r in range(rows):
        exp_g <<= exp_g_ub[0:1, r:r + 1].single()
        d_k_beta_regs <<= d_k_beta_g_ub[r:r + 1, 0:D]
        k_beta_regs <<= k_beta_ub[r:r + 1, 0:D]

        d_k_beta_regs <<= d_k_beta_regs * exp_g
        d_k_beta_ub[r:r + 1, 0:D] <<= d_k_beta_regs

        tmp_regs <<= d_k_beta_regs * k_beta_regs
        d_g <<= tmp_regs.cadd()
        d_g_ub[0:1, r:r + 1] <<= d_g.single_value()
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def wu_bwd_kernel(
    key: GMTensor,
    value: GMTensor,
    beta: GMTensor,
    g_cumsum: GMTensor,
    wu_attn_bf16: GMTensor,
    d_value_wu: GMTensor,
    d_k_cumdecay: GMTensor,
    d_wu: GMTensor,
    d_v_beta: GMTensor,
    d_k_beta: GMTensor,
    d_g_wu: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    vcmutex = VcMutex(
        0,
        depth=2,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    cvmutex = CvMutex(1, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1_v_beta = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_k_beta_g = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_w = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_d_value_wu = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_d_k_cumdecay = DBuff(DT.bfloat16, [L, D], Position.L1)

    l0c_d_wu = DBuff(DT.float, [L, L], Position.L0C)
    l0c_d_v_beta = DBuff(DT.float, [L, D], Position.L0C)
    l0c_d_k_beta_g = DBuff(DT.float, [L, D], Position.L0C)

    key_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    value_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    beta_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    g_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    v_beta_nz_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    k_beta_g_nz_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    k_beta_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    exp_g_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    d_k_beta_g_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_k_beta_ub = Tensor(DT.float, [HALF_L, D], Position.UB)
    d_g_ub = Tensor(DT.float, [1, HALF_L], Position.UB)

    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    for pipe_bhc in range(bhc_begin, bhc_end + 1):
        if pipe_bhc < bhc_end:
            with auto_sync():
                pipe_slot = var_mod(pipe_bhc - bhc_begin, 2)
                c_idx = Var(pipe_bhc // (B * H))
                bh_remainder = Var(pipe_bhc % (B * H))
                b_idx = Var(bh_remainder // H)
                h_idx = Var(bh_remainder % H)

                row_begin = Var(GetSubBlockIdx() * HALF_L)
                row_end = Var(row_begin + HALF_L)
                rows_this = Var(HALF_L)

                vcmutex.lock()
                key_ub[pipe_slot][0:rows_this, 0:D] <<= key[b_idx, h_idx, c_idx, row_begin:row_end, 0:D]
                value_ub[pipe_slot][0:rows_this, 0:D] <<= value[b_idx, h_idx, c_idx, row_begin:row_end, 0:D]
                beta_ub[pipe_slot][0:1, 0:rows_this] <<= beta[b_idx, h_idx, c_idx, row_begin:row_end]
                g_ub[pipe_slot][0:1, 0:rows_this] <<= g_cumsum[b_idx, h_idx, c_idx, row_begin:row_end]
                make_wu_inputs_vf(
                    key_ub[pipe_slot],
                    value_ub[pipe_slot],
                    beta_ub[pipe_slot],
                    g_ub[pipe_slot],
                    v_beta_nz_ub[pipe_slot],
                    k_beta_g_nz_ub[pipe_slot],
                    k_beta_ub[pipe_slot],
                    exp_g_ub[pipe_slot],
                    rows_this,
                )
                l1_v_beta[pipe_slot][row_begin:row_end, 0:D] <<= v_beta_nz_ub[pipe_slot][0:rows_this, 0:D].nz()
                l1_k_beta_g[pipe_slot][row_begin:row_end, 0:D] <<= k_beta_g_nz_ub[pipe_slot][0:rows_this, 0:D].nz()
                vcmutex.ready()

        if pipe_bhc > bhc_begin:
            with auto_sync():
                bhc = Var(pipe_bhc - 1)
                bhc_slot = var_mod(bhc - bhc_begin, 2)
                c_idx = Var(bhc // (B * H))
                bh_remainder = Var(bhc % (B * H))
                b_idx = Var(bh_remainder // H)
                h_idx = Var(bh_remainder % H)

                row_begin = Var(GetSubBlockIdx() * HALF_L)
                row_end = Var(row_begin + HALF_L)
                rows_this = Var(HALF_L)
                d_k_beta_g_slot = d_k_beta_g_ub[bhc_slot]

                l1_w[bhc_slot][0:L, 0:L] <<= wu_attn_bf16[b_idx, h_idx, c_idx, 0:L, 0:L]
                l1_d_value_wu[bhc_slot][0:L, 0:D] <<= d_value_wu[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_d_k_cumdecay[bhc_slot][0:L, 0:D] <<= d_k_cumdecay[b_idx, h_idx, c_idx, 0:L, 0:D]
                vcmutex.wait()
                matmul(l0c_d_wu[bhc_slot], l1_d_value_wu[bhc_slot], l1_v_beta[bhc_slot], m=L, n=L, k=D, splitn=L)
                matmul(l0c_d_wu[bhc_slot], l1_d_k_cumdecay[bhc_slot], l1_k_beta_g[bhc_slot], m=L, n=L, k=D, splitn=L, is_init=False)
                matmul(l0c_d_v_beta[bhc_slot], l1_w[bhc_slot].T, l1_d_value_wu[bhc_slot].T, m=L, n=D, k=L, splitn=D)
                matmul(l0c_d_k_beta_g[bhc_slot], l1_w[bhc_slot].T, l1_d_k_cumdecay[bhc_slot].T, m=L, n=D, k=L, splitn=D)

                vcmutex.free()

                cvmutex.lock()
                d_k_beta_g_slot <<= l0c_d_k_beta_g[bhc_slot]
                cvmutex.ready()

                d_wu[b_idx, h_idx, c_idx, 0:L, 0:L] <<= l0c_d_wu[bhc_slot]
                d_v_beta[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_d_v_beta[bhc_slot]

                cvmutex.wait()
                finalize_wu_partials_vf(
                    d_k_beta_g_slot,
                    k_beta_ub[bhc_slot],
                    exp_g_ub[bhc_slot],
                    d_k_beta_ub,
                    d_g_ub,
                    rows_this,
                )
                cvmutex.free()
                d_k_beta[b_idx, h_idx, c_idx, row_begin:row_end, 0:D] <<= d_k_beta_ub[0:rows_this, 0:D]
                d_g_wu[b_idx, h_idx, c_idx, row_begin:row_end] <<= d_g_ub[0:1, 0:rows_this]
    return d_wu, d_v_beta, d_k_beta, d_g_wu


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "gdn_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(key, value, beta, g_cumsum, wu_attn_bf16, d_value_wu, d_k_cumdecay, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    B = int(key.shape[0])
    H = int(key.shape[1])
    C = int(key.shape[2])
    device = key.device
    outputs = (
        torch.empty((B, H, C, L, L), dtype=torch.bfloat16, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L), dtype=torch.float32, device=device),
    )
    trace_path = _trace_path(trace, out_dir, "wu_bwd")
    previous_config = getattr(wu_bwd_kernel, "_simulator_config", None)
    if simulator:
        wu_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            wu_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            key, value, beta, g_cumsum, wu_attn_bf16, d_value_wu,
            d_k_cumdecay, outputs[0], outputs[1], outputs[2], outputs[3],
            B, H, C, shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(wu_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                wu_bwd_kernel._simulator_config = previous_config
    return result


if __name__ == "__main__":
    torch.manual_seed(42)
    B, H, C = 1, 1, 1
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    value = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    g_cumsum = torch.randn(B, H, C, L, dtype=torch.float32) * 0.05
    wu_attn_bf16 = (torch.eye(L).reshape(1, 1, 1, L, L).repeat(B, H, C, 1, 1)).to(torch.bfloat16)
    d_value_wu = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    d_k_cumdecay = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    result = run(key, value, beta, g_cumsum, wu_attn_bf16, d_value_wu, d_k_cumdecay)
    expected = wu_recompute_bwd(key, value, beta, g_cumsum, wu_attn_bf16, d_value_wu, d_k_cumdecay)
    for got, ref in zip(result, expected):
        torch.testing.assert_close(got, ref, rtol=5e-4, atol=5e-4)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
