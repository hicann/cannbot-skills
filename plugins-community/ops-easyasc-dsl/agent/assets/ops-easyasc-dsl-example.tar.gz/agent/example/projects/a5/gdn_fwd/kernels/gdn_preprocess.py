import builtins

import torch


from easyasc.a5 import *
from easyasc.simulator import SimulatorConfig


L = 64
D = 128
HALF_L = L // 2

SHAPE_BINDINGS = {
    0: [0, 1, 2, 3, 4],  # key[B,H,C,L,D]
    1: [0, 1, 2, 3],     # beta[B,H,C,L]
    2: [0, 1, 2, 3],     # g[B,H,C,L]
    3: [3, 3],           # triu[L,L]
    4: [0, 1, 2, 3],     # g_cumsum[B,H,C,L], fp32
    5: [0, 1, 2, 3, 3],  # decay_mask[B,H,C,L,L], fp32
    6: [0, 1, 2, 3, 3],  # attn[B,H,C,L,L], fp32
}


def _bf16_cube_matmul_fp32_acc(left, right):
    if left.dtype != torch.bfloat16 or right.dtype != torch.bfloat16:
        raise TypeError("bf16 cube matmul reference expects bfloat16 inputs")
    return left.float() @ right.float().transpose(-1, -2)


def gdn_preprocess_v2(key, beta, g, triu):
    """Reference GDN preprocess v2.

    Shape legend:
    B: batch
    H: head count
    C: chunk_size
    L: length_per_chunk
    D: head dimension
    """
    B, H, C, length_per_chunk, head_dim = key.shape
    scalar_shape = (B, H, C, length_per_chunk)
    matrix_shape = (length_per_chunk, length_per_chunk)

    if beta.shape != scalar_shape:
        raise ValueError(f"beta shape must be {scalar_shape}, got {tuple(beta.shape)}")
    if g.shape != scalar_shape:
        raise ValueError(f"g shape must be {scalar_shape}, got {tuple(g.shape)}")
    if triu.shape != matrix_shape:
        raise ValueError(f"triu shape must be {matrix_shape}, got {tuple(triu.shape)}")
    if key.dtype != torch.bfloat16:
        raise TypeError("key must be torch.bfloat16")
    if beta.dtype != torch.float32 or g.dtype != torch.float32 or triu.dtype != torch.float32:
        raise TypeError("beta/g/triu must be torch.float32")

    # Row-vector form: g @ triu is prefix cumsum when triu is upper-triangular ones.
    g_cumsum = (g.reshape(-1, length_per_chunk) @ triu).reshape(B, H, C, length_per_chunk)

    # A5 bf16 cube matmul accumulates to fp32 L0C; keep beta out of the cube input.
    attn_scores = _bf16_cube_matmul_fp32_acc(key, key)

    lower_eq = triu.t()
    strict_lower = torch.tril(torch.ones_like(triu), diagonal=-1)
    decay_mask = (g_cumsum.unsqueeze(-1) - g_cumsum.unsqueeze(-2)).exp() * lower_eq
    attn_scores = attn_scores * beta.unsqueeze(-1)
    attn = -(attn_scores * decay_mask * strict_lower)

    return g_cumsum, decay_mask, attn


@vf()
def init_causal_masks_vf(lower_eq_ub: Tensor, strict_lower_ub: Tensor, row_begin: Var, rows: Var):
    cols = Reg(DT.int)
    zero = Reg(DT.float)
    lower_row = Reg(DT.float)
    strict_row = Reg(DT.float)
    lower_eq_mask = MaskReg(DT.int, init_mode=MaskType.NONE)
    strict_lower_mask = MaskReg(DT.int, init_mode=MaskType.NONE)

    zero <<= 0.0
    cols.arange(0)

    for r in range(rows):
        abs_r = Var(row_begin + r)

        lower_row <<= 1.0
        compare(lower_eq_mask, cols, abs_r + 1, CompareMode.LT)
        select(lower_row, lower_row, zero, mask=lower_eq_mask)
        lower_eq_ub[r:r + 1, 0:L] <<= lower_row

        strict_row <<= 1.0
        compare(strict_lower_mask, cols, abs_r, CompareMode.LT)
        select(strict_row, strict_row, zero, mask=strict_lower_mask)
        strict_lower_ub[r:r + 1, 0:L] <<= strict_row


@vf()
def apply_decay_and_mask_vf(
    score_ub: Tensor,
    beta_ub: Tensor,
    gcum_ub: Tensor,
    lower_eq_mask_ub: Tensor,
    strict_lower_mask_ub: Tensor,
    decay_ub: Tensor,
    attn_ub: Tensor,
    row_begin: Var,
    rows: Var,
):
    grow = Reg(DT.float)
    beta_reg = Reg(DT.float)
    gcum_row = Reg(DT.float)
    score_row = Reg(DT.float)
    decay_row = Reg(DT.float)
    attn_row = Reg(DT.float)
    mask_row = Reg(DT.float)

    for r in range(rows):
        abs_r = Var(row_begin + r)
        grow <<= gcum_ub[0:1, abs_r:abs_r + 1].single()
        gcum_row <<= gcum_ub[0:1, 0:L]
        decay_row <<= grow - gcum_row
        decay_row <<= decay_row.exp()

        mask_row <<= lower_eq_mask_ub[r:r + 1, 0:L]
        decay_row <<= decay_row * mask_row
        decay_ub[r:r + 1, 0:L] <<= decay_row

        beta_reg <<= beta_ub[0:1, r:r + 1].single()
        score_row <<= score_ub[r:r + 1, 0:L]
        score_row <<= score_row * beta_reg
        attn_row <<= score_row * decay_row
        attn_row <<= attn_row * -1.0
        mask_row <<= strict_lower_mask_ub[r:r + 1, 0:L]
        attn_row <<= attn_row * mask_row
        attn_ub[r:r + 1, 0:L] <<= attn_row


@kernel()
def gdn_preprocess_v2_kernel(
    key: GMTensor,
    beta: GMTensor,
    g: GMTensor,
    triu: GMTensor,
    g_cumsum: GMTensor,
    decay_mask: GMTensor,
    attn: GMTensor,
    B: Var,
    H: Var,
    C: Var,
    length_per_chunk: Var,
    head_dim: Var,
):
    cvmutex = CvMutex(1, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1_key = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_g = DBuff(DT.float, [16, L], Position.L1)
    l1_triu = Tensor(DT.float, [L, L], Position.L1)
    l0c_gcum = DBuff(DT.float, [16, L], Position.L0C)
    l0c_score = DBuff(DT.float, [L, L], Position.L0C)

    beta_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    score_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    gcum_ub = DBuff(DT.float, [1, L], Position.UB)
    lower_eq_mask_ub = Tensor(DT.float, [HALF_L, L], Position.UB)
    strict_lower_mask_ub = Tensor(DT.float, [HALF_L, L], Position.UB)
    decay_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    attn_ub = DBuff(DT.float, [HALF_L, L], Position.UB)

    stage1_cnt = Var(0)
    stage2_cnt = Var(0)
    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    with auto_sync():
        if bhc_begin < bhc_end:
            l1_triu[0:L, 0:L] <<= triu[0:L, 0:L]
            mask_row_begin = Var(GetSubBlockIdx() * HALF_L)
            mask_row_end = Min(mask_row_begin + HALF_L, L)
            init_causal_masks_vf(lower_eq_mask_ub, strict_lower_mask_ub, mask_row_begin, mask_row_end - mask_row_begin)

        for bhc in range(bhc_begin, bhc_end + 1):
            if bhc < bhc_end:
                c_idx = Var(bhc // (B * H))
                bh_remainder = Var(bhc % (B * H))
                b_idx = Var(bh_remainder // H)
                h_idx = Var(bh_remainder % H)

                l1_key[stage1_cnt][0:L, 0:D] <<= key[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_g[stage1_cnt][0:1, 0:L] <<= g[b_idx, h_idx, c_idx, 0:L]
                matmul(l0c_gcum[stage1_cnt], l1_g[stage1_cnt], l1_triu.T, m=1, n=L, k=L)
                g_cumsum[b_idx, h_idx, c_idx, 0:L] <<= l0c_gcum[stage1_cnt][0:1, 0:L]

                matmul(l0c_score[stage1_cnt], l1_key[stage1_cnt], l1_key[stage1_cnt], m=L, n=L, k=D, splitn=L)

                cvmutex.lock()
                score_ub[stage1_cnt] <<= l0c_score[stage1_cnt]
                cvmutex.ready()
                stage1_cnt += 1

            if bhc > bhc_begin:
                prev_bhc = Var(bhc - 1)
                prev_c_idx = Var(prev_bhc // (B * H))
                prev_bh_remainder = Var(prev_bhc % (B * H))
                prev_b_idx = Var(prev_bh_remainder // H)
                prev_h_idx = Var(prev_bh_remainder % H)

                post_row_begin = Var(GetSubBlockIdx() * HALF_L)
                post_row_end = Min(post_row_begin + HALF_L, L)
                post_rows_this = Var(post_row_end - post_row_begin)

                cvmutex.wait()
                beta_ub[stage2_cnt][0:1, 0:post_rows_this] <<= beta[
                    prev_b_idx,
                    prev_h_idx,
                    prev_c_idx,
                    post_row_begin:post_row_end,
                ]
                gcum_ub[stage2_cnt][0:1, 0:L] <<= g_cumsum[prev_b_idx, prev_h_idx, prev_c_idx, 0:L]
                apply_decay_and_mask_vf(
                    score_ub[stage2_cnt],
                    beta_ub[stage2_cnt],
                    gcum_ub[stage2_cnt],
                    lower_eq_mask_ub,
                    strict_lower_mask_ub,
                    decay_ub[stage2_cnt],
                    attn_ub[stage2_cnt],
                    post_row_begin,
                    post_rows_this,
                )
                cvmutex.free()

                decay_mask[prev_b_idx, prev_h_idx, prev_c_idx, post_row_begin:post_row_end, 0:L] <<= decay_ub[stage2_cnt][0:post_rows_this, 0:L]
                attn[prev_b_idx, prev_h_idx, prev_c_idx, post_row_begin:post_row_end, 0:L] <<= attn_ub[stage2_cnt][0:post_rows_this, 0:L]
                stage2_cnt += 1

    return g_cumsum, decay_mask, attn


def _check_contract(B, H, C, length_per_chunk, head_dim):
    if length_per_chunk != L:
        raise ValueError(f"this A5 kernel is specialized for L={L}, got L={length_per_chunk}")
    if head_dim != D:
        raise ValueError(f"this A5 kernel is specialized for D={D}, got D={head_dim}")
    if B <= 0 or H <= 0 or C <= 0:
        raise ValueError(f"B/H/C must be positive, got B={B}, H={H}, C={C}")


def run_kernel(key, beta, g, triu, simulator=True, profile=False, out_dir=""):
    B, H, C, length_per_chunk, head_dim = key.shape
    _check_contract(B, H, C, length_per_chunk, head_dim)
    device = key.device
    g_cumsum = torch.empty((B, H, C, L), dtype=torch.float32, device=device)
    decay_mask = torch.empty((B, H, C, L, L), dtype=torch.float32, device=device)
    attn = torch.empty((B, H, C, L, L), dtype=torch.float32, device=device)

    saved_sim_config = getattr(gdn_preprocess_v2_kernel, "_simulator_config", None)
    if simulator:
        gdn_preprocess_v2_kernel._simulator_config = SimulatorConfig(
            core_count=32,
            execution_timeout_s=180.0,
        )

    try:
        return OpExec(
            gdn_preprocess_v2_kernel,
            out_dir=out_dir,
            simulator=simulator,
            profile=profile,
        )(
            key,
            beta,
            g,
            triu,
            g_cumsum,
            decay_mask,
            attn,
            B,
            H,
            C,
            L,
            D,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr(gdn_preprocess_v2_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                gdn_preprocess_v2_kernel._simulator_config = saved_sim_config


if __name__ == "__main__":
    torch.manual_seed(0)

    B = 1
    H = 64
    C = 2
    chunk_size = C
    length_per_chunk = L

    key = torch.randn(B, H, chunk_size, length_per_chunk, D, dtype=torch.float32).to(torch.bfloat16)
    beta = torch.rand(B, H, chunk_size, length_per_chunk, dtype=torch.float32)
    g = torch.log(torch.sigmoid(torch.randn(B, H, chunk_size, length_per_chunk, dtype=torch.float32)))
    triu = torch.triu(torch.ones(length_per_chunk, length_per_chunk, dtype=torch.float32))

    gcum_matmul = (g.reshape(-1, length_per_chunk) @ triu).reshape_as(g)
    torch.testing.assert_close(gcum_matmul, g.cumsum(dim=-1), rtol=1e-6, atol=1e-6)

    ref = gdn_preprocess_v2(key, beta, g, triu)
    out = run_kernel(key, beta, g, triu, simulator=True)
    outs = out if isinstance(out, tuple) else (out,)

    names = ("g_cumsum", "decay_mask", "attn")
    for name, got, expected in zip(names, outs, ref):
        torch.testing.assert_close(got, expected, rtol=2e-3, atol=2e-3)
        print(f"{name}: shape={tuple(got.shape)} dtype={got.dtype} max_abs={torch.abs(got - expected).max().item():.6e}")

    for idx in builtins.range(len(names)):
        assert outs[idx].dtype == ref[idx].dtype
