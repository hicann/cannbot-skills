"""wu_bwd (ungated): WY-representation backward for the ungated delta rule.

Ungated port of `gdn_bwd/kernels/wu_bwd.py`.  GDN applies an `exp(g_cumsum)`
weight to the key path and emits a gate gradient `d_g_wu`; the delta rule has
no gate, so:
  - `g_cumsum` input and every `exp(g_cumsum)` factor are dropped
  - `k_beta_g = key * beta * exp(g)` degenerates to `k_beta = key * beta`
  - `d_g_wu` output is removed entirely

Per (b,h,c) tile the kernel computes (bf16 cube operands, fp32 accumulate):
  v_beta  = value * beta          (vec, bf16 NZ -> L1)
  k_beta  = key   * beta          (vec, bf16 NZ -> L1)
  d_wu    = d_value_wu @ v_beta^T
          + d_k_cumdecay @ k_beta^T    (cube, bf16, -> bf16 GM)
  d_v_beta = wu_attn^T @ d_value_wu   (cube, -> fp32 GM)
  d_k_beta = wu_attn^T @ d_k_cumdecay (cube, -> fp32 GM, NO exp(g) factor)

Pipeline: DBuff two-slot VcMutex (vec produces L1) + CvMutex (cube bridges L0C
back to UB for the d_k_beta GM write).
"""
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
L = 64
D = 128
HALF_L = L // 2
REGS_D = D // 64
BF16_C0 = 16

SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
    2: [0, 1, 2, None],
    3: [0, 1, 2, None, None],
    4: [0, 1, 2, None, None],
    5: [0, 1, 2, None, None],
    6: [0, 1, 2, None, None],
    7: [0, 1, 2, None, None],
    8: [0, 1, 2, None, None],
}


@vf()
def make_wu_inputs_vf(
    key_ub: Tensor,
    value_ub: Tensor,
    beta_ub: Tensor,
    v_beta_nz_ub: Tensor,
    k_beta_nz_ub: Tensor,
    rows: Var,
):
    """Compute v_beta and k_beta (bf16 NZ) for the matmul pipeline.

    No gate: k_beta = key * beta only (no exp(g_cumsum) factor).
    """
    beta_reg = Reg(DT.float)
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)

    for r in range(rows):
        beta_reg <<= beta_ub[0:1, r:r + 1].single()

        # v_beta = value * beta -> bf16 NZ
        row_lo <<= value_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * beta_reg
        row_hi <<= value_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * beta_reg
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(v_beta_nz_ub[r * BF16_C0], row_bf16, rows)

        # k_beta = key * beta -> bf16 NZ  (no exp(g_cumsum) weight)
        row_lo <<= key_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * beta_reg
        row_hi <<= key_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * beta_reg
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_beta_nz_ub[r * BF16_C0], row_bf16, rows)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def wu_bwd_kernel(
    key: GMTensor,
    value: GMTensor,
    beta: GMTensor,
    wu_attn_bf16: GMTensor,
    d_value_wu: GMTensor,
    d_k_cumdecay: GMTensor,
    d_wu: GMTensor,
    d_v_beta: GMTensor,
    d_k_beta: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    vcmutex = VcMutex(
        0,
        depth=2,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    cvmutex = CvMutex(1, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1_v_beta = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_k_beta = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_w = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_d_value_wu = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_d_k_cumdecay = DBuff(DT.bfloat16, [L, D], Position.L1)

    l0c_d_wu = DBuff(DT.float, [L, L], Position.L0C)
    l0c_d_v_beta = DBuff(DT.float, [L, D], Position.L0C)
    l0c_d_k_beta = DBuff(DT.float, [L, D], Position.L0C)

    key_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    value_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    beta_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    v_beta_nz_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    k_beta_nz_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    d_k_beta_ub = DBuff(DT.float, [HALF_L, D], Position.UB)

    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    for pipe_bhc in range(bhc_begin, bhc_end + 1):
        if pipe_bhc < bhc_end:
            with auto_sync():
                pipe_slot = var_mod(pipe_bhc - bhc_begin, 2)
                c_idx = Var(pipe_bhc // (B * H))
                bh_remainder = Var(pipe_bhc % (B * H))
                b_idx = Var(bh_remainder // H)
                h_idx = Var(bh_remainder % H)

                row_begin = Var(GetSubBlockIdx() * HALF_L)
                row_end = Var(row_begin + HALF_L)
                rows_this = Var(HALF_L)

                vcmutex.lock()
                key_ub[pipe_slot][0:rows_this, 0:D] <<= key[b_idx, h_idx, c_idx, row_begin:row_end, 0:D]
                value_ub[pipe_slot][0:rows_this, 0:D] <<= value[b_idx, h_idx, c_idx, row_begin:row_end, 0:D]
                beta_ub[pipe_slot][0:1, 0:rows_this] <<= beta[b_idx, h_idx, c_idx, row_begin:row_end]
                make_wu_inputs_vf(
                    key_ub[pipe_slot],
                    value_ub[pipe_slot],
                    beta_ub[pipe_slot],
                    v_beta_nz_ub[pipe_slot],
                    k_beta_nz_ub[pipe_slot],
                    rows_this,
                )
                l1_v_beta[pipe_slot][row_begin:row_end, 0:D] <<= v_beta_nz_ub[pipe_slot][0:rows_this, 0:D].nz()
                l1_k_beta[pipe_slot][row_begin:row_end, 0:D] <<= k_beta_nz_ub[pipe_slot][0:rows_this, 0:D].nz()
                vcmutex.ready()

        if pipe_bhc > bhc_begin:
            with auto_sync():
                bhc = Var(pipe_bhc - 1)
                bhc_slot = var_mod(bhc - bhc_begin, 2)
                c_idx = Var(bhc // (B * H))
                bh_remainder = Var(bhc % (B * H))
                b_idx = Var(bh_remainder // H)
                h_idx = Var(bh_remainder % H)

                row_begin = Var(GetSubBlockIdx() * HALF_L)
                row_end = Var(row_begin + HALF_L)
                rows_this = Var(HALF_L)

                l1_w[bhc_slot][0:L, 0:L] <<= wu_attn_bf16[b_idx, h_idx, c_idx, 0:L, 0:L]
                l1_d_value_wu[bhc_slot][0:L, 0:D] <<= d_value_wu[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_d_k_cumdecay[bhc_slot][0:L, 0:D] <<= d_k_cumdecay[b_idx, h_idx, c_idx, 0:L, 0:D]
                vcmutex.wait()
                matmul(l0c_d_wu[bhc_slot], l1_d_value_wu[bhc_slot], l1_v_beta[bhc_slot], m=L, n=L, k=D, splitn=L)
                matmul(l0c_d_wu[bhc_slot], l1_d_k_cumdecay[bhc_slot], l1_k_beta[bhc_slot], m=L, n=L, k=D, splitn=L, is_init=False)
                matmul(l0c_d_v_beta[bhc_slot], l1_w[bhc_slot].T, l1_d_value_wu[bhc_slot].T, m=L, n=D, k=L, splitn=D)
                matmul(l0c_d_k_beta[bhc_slot], l1_w[bhc_slot].T, l1_d_k_cumdecay[bhc_slot].T, m=L, n=D, k=L, splitn=D)
                vcmutex.free()

                cvmutex.lock()
                d_k_beta_ub[bhc_slot] <<= l0c_d_k_beta[bhc_slot]
                cvmutex.ready()

                d_wu[b_idx, h_idx, c_idx, 0:L, 0:L] <<= l0c_d_wu[bhc_slot]
                d_v_beta[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_d_v_beta[bhc_slot]

                cvmutex.wait()
                cvmutex.free()
                d_k_beta[b_idx, h_idx, c_idx, row_begin:row_end, 0:D] <<= d_k_beta_ub[bhc_slot][0:rows_this, 0:D]

    return d_wu, d_v_beta, d_k_beta


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "delta_rule_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(key, value, beta, wu_attn_bf16, d_value_wu, d_k_cumdecay, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    B = int(key.shape[0])
    H = int(key.shape[1])
    C = int(key.shape[2])
    device = key.device
    outputs = (
        torch.empty((B, H, C, L, L), dtype=torch.bfloat16, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
    )
    trace_path = _trace_path(trace, out_dir, "wu_bwd")
    previous_config = getattr(wu_bwd_kernel, "_simulator_config", None)
    if simulator:
        wu_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            wu_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            key, value, beta, wu_attn_bf16, d_value_wu, d_k_cumdecay,
            outputs[0], outputs[1], outputs[2],
            B, H, C, shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(wu_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                wu_bwd_kernel._simulator_config = previous_config
    return result


if __name__ == "__main__":
    import sys
    from pathlib import Path

    _ROOT = Path(__file__).resolve().parents[4]
    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
    _REFS = Path(__file__).resolve().parents[1] / "refs"
    if str(_REFS) not in sys.path:
        sys.path.insert(0, str(_REFS))

    from common import core_scan_bwd, make_inputs
    from wu_bwd_ref import subkernel

    torch.manual_seed(42)
    B, H, C = 1, 1, int(os.environ.get("C_SIZE", "2"))
    full = make_inputs(B, H, C)
    scan = core_scan_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])
    ref = subkernel(full[1], full[2], full[3], full[5], scan[2], scan[3])

    result = run(full[1], full[2], full[3], full[5], scan[2], scan[3])
    for i, (got, exp) in enumerate(zip(result, ref)):
        err = (got.float() - exp.float()).abs().max().item()
        print("output[%d] max_abs=%.3e" % (i, err))
    torch.testing.assert_close(result[0].float(), ref[0].float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(result[1].float(), ref[1].float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(result[2].float(), ref[2].float(), rtol=2e-3, atol=2e-3)
    print("wu_bwd OK")
