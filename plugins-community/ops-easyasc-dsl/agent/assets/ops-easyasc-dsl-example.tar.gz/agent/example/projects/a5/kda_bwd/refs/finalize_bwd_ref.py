"""Pure PyTorch reference for the intra/finalize backward stage."""

from common import KDALocalBwdMids, finalize_bwd, outputs_as_tuple


def subkernel(q, k, beta, g_cumsum, dAqk, dq_hv, dk_hv, dv, dbeta, dg_core, dAkk, dh0, chunk_size):
    local = KDALocalBwdMids(dq_hv=dq_hv, dk_hv=dk_hv, dv=dv, dbeta=dbeta, dg_core=dg_core, dAkk=dAkk)
    return outputs_as_tuple(finalize_bwd(q, k, beta, g_cumsum, dAqk, local, dh0, chunk_size))


if __name__ == "__main__":
    from common import build_saved_forward, inverse_bwd, make_inputs, scan_bwd

    inputs = make_inputs(B=1, H=2, HV=4, T=8, K=8, V=6, chunk_size=4, seed=0)
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    scan = scan_bwd(inputs.do, inputs.dht, caches, inputs.chunk_size)
    local = inverse_bwd(inputs.q, inputs.k, inputs.v, inputs.beta, inputs.do, caches, scan, inputs.chunk_size)
    result = subkernel(
        inputs.q,
        inputs.k,
        inputs.beta,
        caches.g_cumsum,
        scan.dAqk,
        local.dq_hv,
        local.dk_hv,
        local.dv,
        local.dbeta,
        local.dg_core,
        local.dAkk,
        scan.dh0,
        inputs.chunk_size,
    )
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
