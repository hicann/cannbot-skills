#!/usr/bin/env python3
"""Generic CANNSIM runner for gdn_bwd sub-kernels.

Runs one @kernel through `OpExec(simulator=False, cannsim=True)` with block_dim
forced to 1 so a single core loops over all BHC tiles (exposes a steady-state
per-loop period). Numerics are NaN under CANNSIM (DDR readback artifact) -- this
is a TIMING tool only, so each kernel is fed correctly-SHAPED random inputs
independently of the pipeline.

Usage:
    WORK=<work-dir> C_SIZE=4 REPO=<easyasc-repo-root> \
      PYTHONPATH=<easyasc-repo-root> <python-bin> \
      projects/a5/gdn_bwd/test_script/cannsim_gdn_bwd.py <kernel-name>

kernel_name in: scan_local_bwd scan_state_bwd wu_bwd inverse_preprocess_bwd finalize_bwd
Then:  cannsim report -e <record_dir> -o <report_dir> -n 0
       <python-bin> projects/a5/gdn_bwd/test_script/analyze_cannsim_trace.py \
         <report_dir>/trace_core0.json
"""
import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("TORCH_DEVICE_BACKEND_AUTOLOAD", "0")
import torch

REPO = os.environ.get("REPO", str(Path(__file__).resolve().parents[4]))
KDIR = os.path.join(REPO, "projects/a5/gdn_bwd/kernels")
if KDIR not in sys.path:
    sys.path.insert(0, KDIR)

# --- force block_dim=1: single core loops over all BHC tiles ---
from easyasc.kernelbase.kernelbase import KernelBase
KernelBase._resolve_op_host_block_dim = staticmethod(lambda *a, **k: 1)

# --- monkeypatch OpExec so simulator=False implies cannsim=True ---
import easyasc.torchplugin as tp
_orig_init = tp.OpExec.__init__
def _patched_init(self, *a, **k):
    if not k.get("simulator", False):
        k["cannsim"] = True
    return _orig_init(self, *a, **k)
tp.OpExec.__init__ = _patched_init

L, D = 64, 128
B, H = 1, 1
C = int(os.environ.get("C_SIZE", "4"))
torch.manual_seed(42)


def _bf16(*shape):
    return (torch.randn(*shape, dtype=torch.float32) * 0.05).to(torch.bfloat16)

def _f32(*shape):
    return torch.randn(*shape, dtype=torch.float32) * 0.05


def inputs_scan_local_bwd():
    return dict(
        query=_bf16(B, H, C, L, D), key=_bf16(B, H, C, L, D),
        grad_output=(torch.randn(B, H, C, L, D) * 0.1).to(torch.bfloat16),
        decay_mask=_f32(B, H, C, L, L), v_new_history=_bf16(B, H, C, L, D),
    )

def inputs_scan_state_bwd():
    return dict(
        query=_bf16(B, H, C, L, D), key=_bf16(B, H, C, L, D),
        grad_output=(torch.randn(B, H, C, L, D) * 0.1).to(torch.bfloat16),
        g_cumsum=_f32(B, H, C, L), k_cumdecay=_bf16(B, H, C, L, D),
        state_after_history=_bf16(B, H, C, D, D),
        grad_final_state=_f32(B, H, D, D),
        d_score_tmp=_bf16(B, H, C, L, L), v_new_history=_bf16(B, H, C, L, D),
        k_weighted_history=_bf16(B, H, C, L, D),
        d_v_attn_tmp=_f32(B, H, C, L, D), exp_delta_history=_f32(B, H, C, L),
    )

def inputs_wu_bwd():
    return dict(
        key=_bf16(B, H, C, L, D), value=_bf16(B, H, C, L, D),
        beta=torch.rand(B, H, C, L), g_cumsum=_f32(B, H, C, L),
        wu_attn_bf16=torch.eye(L).reshape(1, 1, 1, L, L).repeat(B, H, C, 1, 1).to(torch.bfloat16),
        d_value_wu=_bf16(B, H, C, L, D), d_k_cumdecay=_bf16(B, H, C, L, D),
    )

def inputs_inverse_preprocess_bwd():
    return dict(
        key=_bf16(B, H, C, L, D), beta=torch.rand(B, H, C, L),
        decay_mask=_f32(B, H, C, L, L),
        wu_attn_bf16=torch.eye(L).reshape(1, 1, 1, L, L).repeat(B, H, C, 1, 1).to(torch.bfloat16),
        d_wu=_bf16(B, H, C, L, L),
    )

def inputs_finalize_bwd():
    # run() signature: key,value,beta, d_k_core,d_g_core,d_decay_core_masked,
    #                  d_v_beta,d_k_beta_wu,d_g_wu,d_k_pre,d_k_beta_pre,d_decay_pre_masked
    return dict(
        key=_bf16(B, H, C, L, D), value=_bf16(B, H, C, L, D), beta=torch.rand(B, H, C, L),
        d_k_core=_f32(B, H, C, L, D), d_g_core=_f32(B, H, C, L),
        d_decay_core_masked=_f32(B, H, C, L, L),
        d_v_beta=_f32(B, H, C, L, D), d_k_beta_wu=_f32(B, H, C, L, D),
        d_g_wu=_f32(B, H, C, L), d_k_pre=_f32(B, H, C, L, D),
        d_k_beta_pre=_f32(B, H, C, L, D), d_decay_pre_masked=_f32(B, H, C, L, L),
    )


FACTORIES = {
    "scan_local_bwd": inputs_scan_local_bwd,
    "scan_state_bwd": inputs_scan_state_bwd,
    "wu_bwd": inputs_wu_bwd,
    "inverse_preprocess_bwd": inputs_inverse_preprocess_bwd,
    "finalize_bwd": inputs_finalize_bwd,
}


def main():
    name = sys.argv[1]
    default_work = os.path.join(tempfile.gettempdir(), "easyasc-cannsim", "gdn_bwd", name)
    work = os.environ.get("WORK", default_work)
    os.makedirs(work, exist_ok=True)
    os.chdir(work)
    mod = __import__(name)
    ins = FACTORIES[name]()
    print(f"[cannsim] kernel={name} B={B} H={H} C={C} block_dim=1 work={work}")
    print(f"[cannsim] inputs: " + ", ".join(f"{k}{tuple(v.shape)}" for k, v in ins.items()))
    out_dir = os.path.join(work, "op")
    mod.run(**ins, simulator=False, out_dir=out_dir, skip_compile=False)
    print(f"[cannsim] DONE {name}; look for op_aclnn_test/cannsim_*/instr.bin under {work}")


if __name__ == "__main__":
    main()
