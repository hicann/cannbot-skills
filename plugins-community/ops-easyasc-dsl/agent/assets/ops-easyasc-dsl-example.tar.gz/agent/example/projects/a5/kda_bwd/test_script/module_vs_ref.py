"""Module-by-module kernel-vs-reference checks for canonical kda_bwd.

Default behavior runs leaf kernels with reference upstream tensors. That lets us
answer the hardware question "which kernel is wrong by itself?" before a bad
upstream stage poisons every downstream check.

Examples:
  python projects/a5/kda_bwd/test_script/module_vs_ref.py
  python projects/a5/kda_bwd/test_script/module_vs_ref.py --module inverse_epilogue --B 1 --H 2 --HV 4 --C 2
  python projects/a5/kda_bwd/test_script/module_vs_ref.py --module leaf --upstream kernel --stop-on-fail
  python projects/a5/kda_bwd/test_script/module_vs_ref.py --module all --mode onboard --profile
"""

import argparse
import inspect
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import torch


SCRIPT_DIR = Path(__file__).resolve().parent
PLAN_DIR = SCRIPT_DIR.parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)

for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import ATOL as DEFAULT_ATOL, INPUT_K_SCALE as DEFAULT_K_SCALE, INPUT_SCALE as DEFAULT_SCALE, RTOL as DEFAULT_RTOL  # noqa: E402
from common import (  # noqa: E402
    KDALocalBwdMids,
    KDAScanBwdMids,
    build_saved_forward as build_saved_forward_common,
    finalize_bwd as ref_finalize_bwd,
    inverse_bwd as ref_inverse_bwd,
    local_mids_from_tuple,
    local_mids_as_tuple,
    make_inputs,
    oracle,
    outputs_as_tuple,
    scan_bwd as ref_scan_bwd,
    scan_mids_as_tuple,
    scan_mids_from_tuple,
)
from _layout import flat_hvtl, flat_lvd, to_hvtl, to_lvd  # noqa: E402
from _torch_formula import (  # noqa: E402
    D,
    L,
    build_saved_forward as build_saved_forward_formula,
    inverse_beta_only,
    inverse_qkgw_only,
    scan_bwd as formula_scan_bwd,
)
from finalize_bwd import run as run_finalize_bwd  # noqa: E402
from finalize_pair import run as run_finalize_pair  # noqa: E402
from finalize_post import run as run_finalize_post  # noqa: E402
from finalize_pre import run as run_finalize_pre  # noqa: E402
from finalize_reduce import run as run_finalize_reduce  # noqa: E402
from inverse_bwd import run as run_inverse_bwd  # noqa: E402
from inverse_dainv import run as run_inverse_dainv  # noqa: E402
from inverse_dakk_fused import run as run_inverse_dakk  # noqa: E402
from inverse_epilogue import run as run_inverse_epilogue  # noqa: E402
from inverse_mm import run as run_inverse_mm  # noqa: E402
from kernel_compose import run as run_compose  # noqa: E402
from scan_bwd import run as run_scan_bwd  # noqa: E402
from scan_fused import run as run_scan_fused  # noqa: E402


LEAF_MODULES = [
    "scan_fused",
    "inverse_mm",
    "inverse_epilogue",
    "inverse_dainv",
    "inverse_dakk_fused",
    "finalize_pre",
    "finalize_pair",
    "finalize_post",
    "finalize_reduce",
]
STAGE_MODULES = [
    "scan_bwd",
    "inverse_bwd",
    "finalize_bwd",
    "compose",
]
MODULE_ALIASES = {
    "leaf": LEAF_MODULES,
    "leaves": LEAF_MODULES,
    "stage": STAGE_MODULES,
    "stages": STAGE_MODULES,
    "pipeline": STAGE_MODULES,
    "all": LEAF_MODULES + STAGE_MODULES,
    "inverse_dakk": ["inverse_dakk_fused"],
}
MODULE_OUTPUT_NAMES = {
    "scan_fused": ["dAqk", "dh", "dv", "dh0"],
    "scan_bwd": ["dAqk", "dh", "dv", "dh0"],
    "inverse_mm": ["d_qg", "d_kg", "d_w", "d_v_beta", "d_k_beta_g"],
    "inverse_epilogue": ["dq_hv", "dk_hv", "dv", "dbeta", "dg_core", "k_exp"],
    "inverse_dainv": ["D_tri"],
    "inverse_dakk_fused": ["dAkk"],
    "inverse_bwd": ["dq_hv", "dk_hv", "dv", "dbeta", "dg_core", "dAkk"],
    "finalize_pre": ["q_scaled", "k_scaled", "kg", "M_qk", "M_base", "M_beta"],
    "finalize_pair": ["qk_left", "qk_right", "s_base", "t_beta"],
    "finalize_post": ["dq_hv_post", "dk_hv_post", "dbeta", "dg"],
    "finalize_reduce": ["dq", "dk"],
    "finalize_bwd": ["dq", "dk", "dv", "dbeta", "dg", "dh0"],
    "compose": ["dq", "dk", "dv", "dbeta", "dg", "dh0"],
}
MODULE_TOLERANCES = {
    "scan_fused": (4e-3, 4e-3),
    "scan_bwd": (4e-3, 4e-3),
    "inverse_mm": (1e-2, 4e-3),
    "inverse_epilogue": (6e-3, 6e-3),
    "inverse_dainv": (6e-3, 6e-3),
    "inverse_dakk_fused": (2e-2, 2e-2),
    "inverse_bwd": (7e-3, 7e-3),
    "finalize_pre": (6e-3, 6e-3),
    "finalize_pair": (4e-3, 4e-3),
    "finalize_post": (8e-3, 8e-3),
    "finalize_reduce": (4e-3, 4e-3),
    "finalize_bwd": (8e-3, 8e-3),
    "compose": (DEFAULT_ATOL, DEFAULT_RTOL),
}
ALL_MODULES = LEAF_MODULES + STAGE_MODULES


def _parse_csv_ints(text):
    values = []
    for item in text.split(","):
        item = item.strip()
        if item:
            values.append(int(item))
    return values


def _as_tuple(value):
    return value if isinstance(value, tuple) else (value,)


def _expand_modules(items):
    modules = []
    valid = set(ALL_MODULES)
    valid_names = valid | set(MODULE_ALIASES)
    for item in items:
        for name in item.split(","):
            name = name.strip()
            if not name:
                continue
            modules.extend(MODULE_ALIASES.get(name, [name]))

    seen = set()
    expanded = []
    for name in modules:
        if name not in valid:
            raise ValueError("unknown module %r; valid: %s" % (name, ", ".join(sorted(valid_names))))
        if name not in seen:
            expanded.append(name)
            seen.add(name)
    return expanded


def _trace_value(trace_root, module_name, seed):
    if not trace_root:
        return None
    path = Path(trace_root) / ("seed_%s" % seed) / ("%s.json" % module_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


def _call_run(run_fn, args, options, module_name, seed):
    call_out_dir = str(Path(options.out_dir) / module_name) if options.out_dir else ""
    call_args = tuple(arg.clone() if torch.is_tensor(arg) else arg for arg in args)
    kwargs = {
        "simulator": (options.mode == "simulator"),
        "trace": _trace_value(options.trace_root, module_name, seed),
        "out_dir": call_out_dir,
        "skip_compile": options.skip_compile,
    }
    if options.profile and "profile" in inspect.signature(run_fn).parameters:
        kwargs["profile"] = True
    return _as_tuple(run_fn(*call_args, **kwargs))


def _compare_tensor(module_name, output_name, index, actual, expected, atol, rtol):
    if tuple(actual.shape) != tuple(expected.shape):
        print(
            "  [%s.%s] shape FAIL actual=%s expected=%s"
            % (module_name, output_name, tuple(actual.shape), tuple(expected.shape))
        )
        return False

    actual_f = actual.float()
    expected_f = expected.float()
    if not torch.isfinite(actual_f).all() or not torch.isfinite(expected_f).all():
        print("  [%s.%s] finite FAIL" % (module_name, output_name))
        return False

    diff = (actual_f - expected_f).abs()
    rel = diff / expected_f.abs().clamp_min(1e-12)
    close = torch.isclose(actual_f, expected_f, atol=atol, rtol=rtol)
    ok = bool(close.all())
    bad_count = int((~close).sum().item())
    max_abs = float(diff.max()) if diff.numel() else 0.0
    max_rel = float(rel.max()) if rel.numel() else 0.0
    flat_idx = int(diff.reshape(-1).argmax().item()) if diff.numel() else 0
    idx_tuple = tuple(int(i) for i in torch.unravel_index(torch.tensor(flat_idx), diff.shape))
    actual_val = float(actual_f[idx_tuple]) if diff.numel() else 0.0
    expected_val = float(expected_f[idx_tuple]) if diff.numel() else 0.0
    status = "OK" if ok else "FAIL"
    print(
        "  [%s.%s] %s shape=%s dtype=%s max_abs=%.3e max_rel=%.3e bad=%d idx=%s got=%.8e ref=%.8e"
        % (
            module_name,
            output_name or ("output%d" % index),
            status,
            tuple(actual.shape),
            actual.dtype,
            max_abs,
            max_rel,
            bad_count,
            idx_tuple,
            actual_val,
            expected_val,
        )
    )
    return ok


def _compare_tuple(module_name, actual, expected, atol, rtol):
    actual = _as_tuple(actual)
    expected = _as_tuple(expected)
    if len(actual) != len(expected):
        print("  [%s] arity FAIL actual=%d expected=%d" % (module_name, len(actual), len(expected)))
        return False

    names = MODULE_OUTPUT_NAMES.get(module_name, [])
    ok = True
    for idx, (act, exp) in enumerate(zip(actual, expected)):
        output_name = names[idx] if idx < len(names) else "output%d" % idx
        ok = _compare_tensor(module_name, output_name, idx, act, exp, atol, rtol) and ok
    return ok


def _module_tolerance(module_name, options):
    default_atol, default_rtol = MODULE_TOLERANCES.get(module_name, (DEFAULT_ATOL, DEFAULT_RTOL))
    atol = options.atol if options.atol is not None else default_atol
    rtol = options.rtol if options.rtol is not None else default_rtol
    return atol, rtol


class KdaBwdCase(object):
    def __init__(self, seed, options):
        self.seed = seed
        self.options = options
        self.inputs = make_inputs(
            B=options.B,
            H=options.H,
            HV=options.HV,
            T=options.T_eff,
            K=options.K,
            V=options.V,
            chunk_size=options.chunk_size,
            seed=seed,
            scale=options.scale,
            k_scale=options.k_scale,
        )
        self._common_caches = None
        self._formula_caches = None
        self._formula_scan = None
        self._ref_scan = None
        self._ref_inverse = None
        self._ref_finalize = None
        self._expected_cache = {}
        self._actual_cache = {}

    def _bf(self, x):
        return x.to(torch.bfloat16).float()

    def common_caches(self):
        if self._common_caches is None:
            inputs = self.inputs
            self._common_caches = build_saved_forward_common(
                inputs.q,
                inputs.k,
                inputs.v,
                inputs.g,
                inputs.beta,
                inputs.initial_state,
                inputs.chunk_size,
            )
        return self._common_caches

    def formula_caches(self):
        if self._formula_caches is None:
            self._formula_caches = build_saved_forward_formula(self.inputs)
        return self._formula_caches

    def formula_scan(self):
        if self._formula_scan is None:
            self._formula_scan = formula_scan_bwd(self.inputs, self.formula_caches())
        return self._formula_scan

    def ref_scan(self):
        if self._ref_scan is None:
            self._ref_scan = ref_scan_bwd(
                self.inputs.do,
                self.inputs.dht,
                self.common_caches(),
                self.inputs.chunk_size,
            )
        return self._ref_scan

    def ref_inverse(self):
        if self._ref_inverse is None:
            self._ref_inverse = ref_inverse_bwd(
                self.inputs.q,
                self.inputs.k,
                self.inputs.v,
                self.inputs.beta,
                self.inputs.do,
                self.common_caches(),
                self.ref_scan(),
                self.inputs.chunk_size,
            )
        return self._ref_inverse

    def ref_finalize(self):
        if self._ref_finalize is None:
            self._ref_finalize = ref_finalize_bwd(
                self.inputs.q,
                self.inputs.k,
                self.inputs.beta,
                self.common_caches().g_cumsum,
                self.ref_scan().dAqk,
                self.ref_inverse(),
                self.ref_scan().dh0,
                self.inputs.chunk_size,
            )
        return self._ref_finalize

    def _ref_k_exp(self):
        key = "_ref_k_exp"
        if key in self._expected_cache:
            return self._expected_cache[key]
        q_shape = self.inputs.q.shape
        B, T, Hq, _Kd = q_shape
        HV = self.inputs.v.shape[2]
        group = HV // Hq
        kf = self.inputs.k.float()
        gf = self.common_caches().g_cumsum.float()
        k_exp = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        for hv in range(HV):
            k_exp[:, :, hv] = kf[:, :, hv // group] * torch.exp2(gf[:, :, hv])
        self._expected_cache[key] = k_exp
        return k_exp

    def _expected_inverse_mm(self):
        key = "inverse_mm"
        if key in self._expected_cache:
            return self._expected_cache[key]
        d_qg, d_kg, d_vh = inverse_qkgw_only(self.inputs, self.formula_caches(), self.formula_scan())
        d_v_beta, d_k_beta_g = inverse_beta_only(
            self.inputs,
            self.formula_caches(),
            self.formula_scan(),
            -d_vh,
        )
        out = tuple(self._bf(x) for x in (d_qg, d_kg, -d_vh, d_v_beta, d_k_beta_g))
        self._expected_cache[key] = out
        return out

    def _expected_inverse_epilogue(self):
        key = "inverse_epilogue"
        if key in self._expected_cache:
            return self._expected_cache[key]
        local = self.ref_inverse()
        out = (
            local.dq_hv,
            local.dk_hv,
            local.dv,
            local.dbeta.float(),
            local.dg_core,
            self._ref_k_exp(),
        )
        self._expected_cache[key] = out
        return out

    def _expected_inverse_dainv(self):
        key = "inverse_dainv"
        if key in self._expected_cache:
            return self._expected_cache[key]
        scan = self.ref_scan()
        d_w = self._expected_inverse_mm()[2].float()
        k_exp = self._ref_k_exp()
        vf = self.inputs.v.float()
        betaf = self.inputs.beta.float()
        B, T, HV = self.inputs.beta.shape
        exp = torch.zeros(B, T, HV, L, dtype=torch.float32, device=self.inputs.q.device)
        for b in range(B):
            for c in range(T // L):
                start = c * L
                end = start + L
                for hv in range(HV):
                    dvb = scan.dv[b, start:end, hv].float()
                    dA = self._bf(dvb) @ self._bf(vf[b, start:end, hv]).T
                    dA = dA + self._bf(d_w[b, start:end, hv]) @ self._bf(k_exp[b, start:end, hv]).T
                    exp[b, start:end, hv] = torch.tril(dA * betaf[b, start:end, hv][None, :], diagonal=-1)
        self._expected_cache[key] = (exp,)
        return self._expected_cache[key]

    def _expected_finalize_pre(self):
        key = "finalize_pre"
        if key in self._expected_cache:
            return self._expected_cache[key]
        scan = self.ref_scan()
        local = self.ref_inverse()
        B, T, Hq, _Kd = self.inputs.q.shape
        HV = self.inputs.v.shape[2]
        group = HV // Hq
        qf = self.inputs.q.float()[:, :, torch.arange(HV) // group, :]
        kf = self.inputs.k.float()[:, :, torch.arange(HV) // group, :]
        betaf = self.inputs.beta.float()
        gf = self.common_caches().g_cumsum.float()
        dAqkf = scan.dAqk.float()
        dAkkf = local.dAkk.float()
        exp2 = torch.exp2
        e_qs = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        e_ks = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        e_kg = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        e_mqk = torch.zeros(B, T, HV, L, dtype=torch.float32, device=self.inputs.q.device)
        e_mb = torch.zeros(B, T, HV, L, dtype=torch.float32, device=self.inputs.q.device)
        e_mbe = torch.zeros(B, T, HV, L, dtype=torch.float32, device=self.inputs.q.device)
        for b in range(B):
            for c in range(T // L):
                start = c * L
                end = start + L
                for hv in range(HV):
                    gb = gf[b, start:end, hv]
                    gl = gb[L - 1]
                    row_scale = exp2(gb - gl)
                    col_scale = exp2(gl - gb)
                    e_qs[b, start:end, hv] = qf[b, start:end, hv] * row_scale
                    e_ks[b, start:end, hv] = kf[b, start:end, hv] * row_scale
                    e_kg[b, start:end, hv] = kf[b, start:end, hv] * col_scale
                    e_mqk[b, start:end, hv] = torch.tril(dAqkf[b, start:end, hv])
                    base = torch.tril(dAkkf[b, start:end, hv], diagonal=-1)
                    e_mb[b, start:end, hv] = base
                    e_mbe[b, start:end, hv] = base * betaf[b, start:end, hv][:, None]
        out = (e_qs, e_ks, e_kg, e_mqk, e_mb, e_mbe)
        self._expected_cache[key] = out
        return out

    def _expected_finalize_pair(self):
        key = "finalize_pair"
        if key in self._expected_cache:
            return self._expected_cache[key]
        q_scaled, k_scaled, kg, m_qk, m_base, m_beta = self._expected_finalize_pre()
        B, T, HV, _ = q_scaled.shape
        qk_left = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        qk_right = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        s_base = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        t_beta = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        for b in range(B):
            for c in range(T // L):
                start = c * L
                end = start + L
                for hv in range(HV):
                    qk_left[b, start:end, hv] = self._bf(m_qk[b, start:end, hv]) @ self._bf(kg[b, start:end, hv])
                    qk_right[b, start:end, hv] = self._bf(m_qk[b, start:end, hv]).T @ self._bf(q_scaled[b, start:end, hv])
                    s_base[b, start:end, hv] = self._bf(m_base[b, start:end, hv]) @ self._bf(kg[b, start:end, hv])
                    t_beta[b, start:end, hv] = self._bf(m_beta[b, start:end, hv]).T @ self._bf(k_scaled[b, start:end, hv])
        out = (qk_left, qk_right, s_base, t_beta)
        self._expected_cache[key] = out
        return out

    def _expected_finalize_post(self):
        key = "finalize_post"
        if key in self._expected_cache:
            return self._expected_cache[key]
        qk_left, qk_right, s_base, t_beta = self._expected_finalize_pair()
        local = self.ref_inverse()
        B, T, Hq, _Kd = self.inputs.q.shape
        HV = self.inputs.v.shape[2]
        group = HV // Hq
        qf = self.inputs.q.float()[:, :, torch.arange(HV) // group, :]
        kf = self.inputs.k.float()[:, :, torch.arange(HV) // group, :]
        betaf = self.inputs.beta.float()
        gf = self.common_caches().g_cumsum.float()
        dqhv_in = local.dq_hv.float()
        dkhv_in = local.dk_hv.float()
        dbeta_in = local.dbeta.float()
        dgcore_in = local.dg_core.float()
        exp2 = torch.exp2
        e_dq = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        e_dk = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        e_db = torch.empty(B, T, HV, dtype=torch.float32, device=self.inputs.q.device)
        e_dg = torch.empty(B, T, HV, D, dtype=torch.float32, device=self.inputs.q.device)
        for b in range(B):
            for c in range(T // L):
                start = c * L
                end = start + L
                for hv in range(HV):
                    gb = gf[b, start:end, hv]
                    gl = gb[L - 1]
                    row_scale = exp2(gb - gl)
                    col_scale = exp2(gl - gb)
                    dq_pair = row_scale * qk_left[b, start:end, hv]
                    dk_pair = col_scale * qk_right[b, start:end, hv]
                    row_contrib = row_scale * s_base[b, start:end, hv]
                    col_contrib = col_scale * t_beta[b, start:end, hv]
                    dg_qk = qf[b, start:end, hv] * dq_pair - kf[b, start:end, hv] * dk_pair
                    dk_kk = betaf[b, start:end, hv][:, None] * row_contrib + col_contrib
                    dbeta_add = (kf[b, start:end, hv] * row_contrib).sum(dim=-1)
                    dg_kk = (
                        betaf[b, start:end, hv][:, None] * kf[b, start:end, hv] * row_contrib
                        - kf[b, start:end, hv] * col_contrib
                    )
                    e_dq[b, start:end, hv] = dqhv_in[b, start:end, hv] + dq_pair
                    e_dk[b, start:end, hv] = dkhv_in[b, start:end, hv] + dk_pair + dk_kk
                    e_db[b, start:end, hv] = dbeta_in[b, start:end, hv] + dbeta_add
                    dg_blk = dgcore_in[b, start:end, hv] + dg_qk + dg_kk
                    e_dg[b, start:end, hv] = torch.flip(
                        torch.cumsum(torch.flip(dg_blk, dims=(0,)), dim=0),
                        dims=(0,),
                    )
        out = (e_dq, e_dk, e_db, e_dg)
        self._expected_cache[key] = out
        return out

    def _expected_finalize_reduce(self):
        key = "finalize_reduce"
        if key in self._expected_cache:
            return self._expected_cache[key]
        dq_hv, dk_hv = self._expected_finalize_post()[:2]
        B, T, Hq, Kdim = self.inputs.q.shape
        HV = self.inputs.v.shape[2]
        group = HV // Hq
        exp_dq = dq_hv.reshape(B, T, Hq, group, Kdim).sum(dim=3).to(torch.bfloat16).float()
        exp_dk = dk_hv.reshape(B, T, Hq, group, Kdim).sum(dim=3).to(torch.bfloat16).float()
        out = (exp_dq, exp_dk)
        self._expected_cache[key] = out
        return out

    def expected_for_module(self, module_name):
        if module_name == "scan_fused":
            return scan_mids_as_tuple(self.ref_scan())
        if module_name == "scan_bwd":
            return scan_mids_as_tuple(self.ref_scan())
        if module_name == "inverse_mm":
            return self._expected_inverse_mm()
        if module_name == "inverse_epilogue":
            return self._expected_inverse_epilogue()
        if module_name == "inverse_dainv":
            return self._expected_inverse_dainv()
        if module_name == "inverse_dakk_fused":
            return (self.ref_inverse().dAkk.float(),)
        if module_name == "inverse_bwd":
            return local_mids_as_tuple(self.ref_inverse())
        if module_name == "finalize_pre":
            return self._expected_finalize_pre()
        if module_name == "finalize_pair":
            return self._expected_finalize_pair()
        if module_name == "finalize_post":
            return self._expected_finalize_post()
        if module_name == "finalize_reduce":
            return self._expected_finalize_reduce()
        if module_name == "finalize_bwd":
            return outputs_as_tuple(self.ref_finalize())
        if module_name == "compose":
            return outputs_as_tuple(oracle(self.inputs))
        raise ValueError("unsupported module %r" % module_name)

    def _scan_upstream(self):
        if self.options.upstream == "ref":
            return self.ref_scan()
        return scan_mids_from_tuple(self.actual_for_module("scan_bwd"))

    def _inverse_upstream(self):
        if self.options.upstream == "ref":
            return self.ref_inverse()
        return local_mids_from_tuple(self.actual_for_module("inverse_bwd"))

    def actual_for_module(self, module_name):
        cache_key = (module_name, self.options.upstream)
        if module_name in ("scan_fused", "scan_bwd", "compose"):
            cache_key = (module_name, "fixed")
        if cache_key in self._actual_cache:
            return self._actual_cache[cache_key]

        caches = self.common_caches()
        inputs = self.inputs
        out = None

        if module_name == "scan_fused":
            g_last = caches.g_cumsum[:, L - 1::L, :, :]
            out = _call_run(
                run_scan_fused,
                (caches.kg, caches.qg, caches.w, g_last, inputs.do, caches.Aqk, caches.v_new, inputs.dht),
                self.options,
                module_name,
                self.seed,
            )
        elif module_name == "scan_bwd":
            g_last = caches.g_cumsum[:, L - 1::L, :, :]
            out = _call_run(
                run_scan_bwd,
                (caches.Aqk, caches.v_new, inputs.do, caches.kg, caches.qg, caches.w, g_last, inputs.dht),
                self.options,
                module_name,
                self.seed,
            )
        elif module_name == "inverse_mm":
            scan = self._scan_upstream()
            out = _call_run(
                run_inverse_mm,
                (inputs.do, caches.v_new, scan.dv, caches.h, scan.dh, caches.Akk),
                self.options,
                module_name,
                self.seed,
            )
            out = tuple(flat_lvd(x) for x in out)
        elif module_name == "inverse_epilogue":
            scan = self._scan_upstream()
            if self.options.upstream == "ref":
                d_qg, d_kg, d_w, d_v_beta, d_k_beta_g = self._expected_inverse_mm()
            else:
                d_qg, d_kg, d_w, d_v_beta, d_k_beta_g = self.actual_for_module("inverse_mm")
            out = _call_run(
                run_inverse_epilogue,
                (
                    to_lvd(d_qg.to(torch.bfloat16)),
                    to_lvd(d_kg.to(torch.bfloat16)),
                    to_lvd(d_v_beta.to(torch.bfloat16)),
                    to_lvd(d_k_beta_g.to(torch.bfloat16)),
                    inputs.q,
                    inputs.k,
                    inputs.v,
                    caches.g_cumsum,
                    inputs.beta,
                    caches.h,
                    scan.dh,
                ),
                self.options,
                module_name,
                self.seed,
            )
            out = (out[0], out[1], out[2], out[3], out[4], flat_lvd(out[5]))
        elif module_name == "inverse_dainv":
            scan = self._scan_upstream()
            if self.options.upstream == "ref":
                d_w = self._expected_inverse_mm()[2]
                k_exp = self._expected_inverse_epilogue()[5]
            else:
                d_w = self.actual_for_module("inverse_mm")[2]
                k_exp = self.actual_for_module("inverse_epilogue")[5]
            out = _call_run(
                run_inverse_dainv,
                (
                    scan.dv,
                    inputs.v,
                    to_lvd(d_w.to(torch.bfloat16)),
                    to_lvd(k_exp.to(torch.bfloat16)),
                    inputs.beta,
                ),
                self.options,
                module_name,
                self.seed,
            )
            out = (flat_lvd(out[0]),)
        elif module_name == "inverse_dakk_fused":
            if self.options.upstream == "ref":
                d_tri = self._expected_inverse_dainv()[0]
            else:
                d_tri = self.actual_for_module("inverse_dainv")[0]
            out = _call_run(
                run_inverse_dakk,
                (caches.Akk, to_hvtl(d_tri.to(torch.bfloat16))),
                self.options,
                module_name,
                self.seed,
            )
        elif module_name == "inverse_bwd":
            scan = self._scan_upstream()
            out = _call_run(
                run_inverse_bwd,
                (
                    inputs.q,
                    inputs.k,
                    inputs.v,
                    inputs.beta,
                    inputs.do,
                    caches.g_cumsum,
                    caches.v_new,
                    caches.h,
                    scan.dh,
                    scan.dv,
                    caches.Akk,
                ),
                self.options,
                module_name,
                self.seed,
            )
        elif module_name == "finalize_pre":
            scan = self._scan_upstream()
            inverse = self._inverse_upstream()
            out = _call_run(
                run_finalize_pre,
                (
                    inputs.q,
                    inputs.k,
                    inputs.beta,
                    caches.g_cumsum,
                    scan.dAqk,
                    inverse.dAkk,
                ),
                self.options,
                module_name,
                self.seed,
            )
            out = tuple(flat_lvd(x) for x in out)
        elif module_name == "finalize_pair":
            if self.options.upstream == "ref":
                q_scaled, k_scaled, kg, m_qk, m_base, m_beta = self._expected_finalize_pre()
            else:
                q_scaled, k_scaled, kg, m_qk, m_base, m_beta = self.actual_for_module("finalize_pre")
            out = _call_run(
                run_finalize_pair,
                (
                    to_hvtl(m_qk.to(torch.bfloat16)),
                    to_hvtl(m_base.to(torch.bfloat16)),
                    to_hvtl(m_beta.to(torch.bfloat16)),
                    to_hvtl(q_scaled.to(torch.bfloat16)),
                    to_hvtl(k_scaled.to(torch.bfloat16)),
                    to_hvtl(kg.to(torch.bfloat16)),
                ),
                self.options,
                module_name,
                self.seed,
            )
            out = tuple(flat_hvtl(x) for x in out)
        elif module_name == "finalize_post":
            inverse = self._inverse_upstream()
            if self.options.upstream == "ref":
                qk_left, qk_right, s_base, t_beta = self._expected_finalize_pair()
            else:
                qk_left, qk_right, s_base, t_beta = self.actual_for_module("finalize_pair")
            out = _call_run(
                run_finalize_post,
                (
                    inputs.q,
                    inputs.k,
                    inputs.beta,
                    caches.g_cumsum,
                    to_lvd(qk_left.to(torch.bfloat16)),
                    to_lvd(qk_right.to(torch.bfloat16)),
                    to_lvd(s_base.to(torch.bfloat16)),
                    to_lvd(t_beta.to(torch.bfloat16)),
                    inverse.dq_hv.to(torch.bfloat16),
                    inverse.dk_hv.to(torch.bfloat16),
                    inverse.dbeta.float(),
                    inverse.dg_core.to(torch.bfloat16),
                ),
                self.options,
                module_name,
                self.seed,
            )
            out = (flat_lvd(out[0]), flat_lvd(out[1]), out[2], out[3])
        elif module_name == "finalize_reduce":
            if self.options.upstream == "ref":
                dq_hv, dk_hv = self._expected_finalize_post()[:2]
            else:
                dq_hv, dk_hv = self.actual_for_module("finalize_post")[:2]
            out = _call_run(
                run_finalize_reduce,
                (to_lvd(dq_hv).float(), to_lvd(dk_hv).float(), inputs.q.shape[2]),
                self.options,
                module_name,
                self.seed,
            )
        elif module_name == "finalize_bwd":
            scan = self._scan_upstream()
            inverse = self._inverse_upstream()
            out = _call_run(
                run_finalize_bwd,
                (
                    inputs.q,
                    inputs.k,
                    inputs.beta,
                    caches.g_cumsum,
                    scan.dAqk,
                    inverse.dq_hv,
                    inverse.dk_hv,
                    inverse.dv,
                    inverse.dbeta.float(),
                    inverse.dg_core,
                    inverse.dAkk,
                    scan.dh0,
                ),
                self.options,
                module_name,
                self.seed,
            )
        elif module_name == "compose":
            out = _call_run(
                run_compose,
                (
                    inputs.q,
                    inputs.k,
                    inputs.v,
                    inputs.g,
                    inputs.beta,
                    inputs.initial_state,
                    inputs.do,
                    inputs.dht,
                ),
                self.options,
                module_name,
                self.seed,
            )
        else:
            raise ValueError("unsupported module %r" % module_name)

        self._actual_cache[cache_key] = out
        return out


def run_case(seed, modules, options):
    print(
        "=== seed=%d shape=(B=%d,H=%d,HV=%d,T=%d,K=%d,V=%d,chunk=%d) mode=%s upstream=%s ==="
        % (
            seed,
            options.B,
            options.H,
            options.HV,
            options.T_eff,
            options.K,
            options.V,
            options.chunk_size,
            options.mode,
            options.upstream,
        )
    )
    case = KdaBwdCase(seed, options)
    ok = True
    for module_name in modules:
        print("[%s]" % module_name)
        actual = case.actual_for_module(module_name)
        expected = case.expected_for_module(module_name)
        atol, rtol = _module_tolerance(module_name, options)
        ok = _compare_tuple(module_name, actual, expected, atol, rtol) and ok
        if not ok and options.stop_on_fail:
            break
    return ok


def parse_args(argv):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--module",
        action="append",
        default=None,
        help="module, comma list, or alias: leaf/stage/all",
    )
    parser.add_argument("--upstream", choices=("ref", "kernel"), default="ref")
    parser.add_argument("--list-modules", action="store_true", help="print the expanded module list and exit")
    parser.add_argument("--mode", choices=("simulator", "onboard"), default="simulator")
    parser.add_argument("--seed", default="20260604", help="comma-separated torch seeds")
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=32)
    parser.add_argument("--HV", type=int, default=32)
    parser.add_argument("--C", type=int, default=16, help="chunks; T = C * chunk_size unless --T given")
    parser.add_argument("--T", type=int, default=None, help="sequence length; overrides --C when set")
    parser.add_argument("--K", type=int, default=128)
    parser.add_argument("--V", type=int, default=128)
    parser.add_argument("--chunk-size", type=int, default=64)
    parser.add_argument("--scale", type=float, default=DEFAULT_SCALE)
    parser.add_argument("--k-scale", type=float, default=DEFAULT_K_SCALE, help="k random init scale")
    parser.add_argument("--atol", type=float, default=None, help="override absolute tolerance for every module")
    parser.add_argument("--rtol", type=float, default=None, help="override relative tolerance for every module")
    parser.add_argument("--out-dir", default="", help="OpExec output dir (per-module build packages land under here)")
    parser.add_argument("--trace", action="store_true", help="emit simulator traces (simulator mode only)")
    parser.add_argument("--profile", action="store_true", help="pass profile=True (onboard HW timing)")
    parser.add_argument("--skip-compile", action="store_true")
    parser.add_argument("--stop-on-fail", action="store_true")
    args = parser.parse_args(argv)

    args.modules = _expand_modules(args.module or ["leaf"])
    args.seeds = _parse_csv_ints(args.seed)
    if not args.seeds:
        parser.error("--seed produced no integers")
    if args.T is not None:
        args.T_eff = args.T
    else:
        args.T_eff = args.C * args.chunk_size
    if args.trace and args.mode == "simulator":
        if args.out_dir:
            args.trace_root = str(Path(args.out_dir) / "traces")
        else:
            args.trace_root = str(PLAN_DIR / "tmp" / "module_vs_ref_traces")
    else:
        args.trace_root = ""
    return args


def main(argv=None):
    options = parse_args(sys.argv[1:] if argv is None else argv)
    if options.list_modules:
        for name in options.modules:
            print(name)
        return 0

    all_ok = True
    for seed in options.seeds:
        ok = run_case(seed, options.modules, options)
        all_ok = ok and all_ok
        if not ok and options.stop_on_fail:
            break
    if all_ok:
        print("kda_bwd module-vs-ref OK")
        return 0
    print("kda_bwd module-vs-ref FAIL")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
