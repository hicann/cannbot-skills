import json
from pathlib import Path

import torch


from easyasc.a5 import *
from easyasc.simulator import SimulatorConfig


L = 64
D = 128
HALF_L = L // 2
BF16_C0 = 16

SHAPE_BINDINGS = {
    0: [0, 1, 2, 3, 4],  # key[B,H,C,L,D]
    1: [0, 1, 2, 3, 4],  # value[B,H,C,L,D]
    2: [0, 1, 2, 3],     # beta[B,H,C,L]
    3: [0, 1, 2, 3],     # g[B,H,C,L]
    4: [0, 1, 2, 3, 3],  # attn[B,H,C,L,L]
    5: [0, 1, 2, 3, 4],  # value_out[B,H,C,L,D]
    6: [0, 1, 2, 3, 4],  # k_cumdecay[B,H,C,L,D]
}


def make_input(B=1, H=32, C=16, L=L, D=D):
    # key/value: [B, H, C, L, D] bf16
    # beta/g:    [B, H, C, L] fp32
    # attn:      [B, H, C, L, L] bf16
    key = torch.randn(B, H, C, L, D, dtype=torch.float32).to(torch.bfloat16)
    value = torch.randn(B, H, C, L, D, dtype=torch.float32).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    g = torch.log(torch.sigmoid(torch.randn(B, H, C, L, dtype=torch.float32)))
    attn = torch.randn(B, H, C, L, L, dtype=torch.float32).to(torch.bfloat16)
    return key, value, beta, g, attn


def gdn_recompute_wu(key, value, beta, g, attn):
    v_beta = (value.float() * beta.unsqueeze(-1)).to(torch.bfloat16)
    k_beta_g = (key.float() * beta.unsqueeze(-1) * g.exp().unsqueeze(-1)).to(torch.bfloat16)

    value = (attn.float() @ v_beta.float()).bfloat16()
    k_cumdecay = (attn.float() @ k_beta_g.float()).bfloat16()

    return value, k_cumdecay


@vf()
def scale_and_pack_vf(
    key_ub: Tensor,
    value_ub: Tensor,
    beta_ub: Tensor,
    g_ub: Tensor,
    k_beta_g_nz_ub: Tensor,
    v_beta_nz_ub: Tensor,
    rows: Var,
):
    beta_reg = Reg(DT.float)
    g_reg = Reg(DT.float)
    row_lo = Reg(DT.float)
    row_hi = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    hi_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)

    for r in range(rows):
        beta_reg <<= beta_ub[0:1, r:r + 1].single()

        row_lo <<= value_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * beta_reg
        row_hi <<= value_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * beta_reg
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(v_beta_nz_ub[r * BF16_C0], row_bf16, rows)

        g_reg <<= g_ub[0:1, r:r + 1].single()
        g_reg <<= g_reg.exp()

        row_lo <<= key_ub[r:r + 1, 0:64]
        row_lo <<= row_lo * beta_reg
        row_lo <<= row_lo * g_reg
        row_hi <<= key_ub[r:r + 1, 64:D]
        row_hi <<= row_hi * beta_reg
        row_hi <<= row_hi * g_reg
        lo_bf16 <<= row_lo.astype(DT.bfloat16)
        hi_bf16 <<= row_hi.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, hi_bf16)
        reg_to_ub(k_beta_g_nz_ub[r * BF16_C0], row_bf16, rows)


@kernel()
def gdn_recompute_wu_v2_kernel(
    key: GMTensor,
    value: GMTensor,
    beta: GMTensor,
    g: GMTensor,
    attn: GMTensor,
    value_out: GMTensor,
    k_cumdecay: GMTensor,
    B: Var,
    H: Var,
    C: Var,
    length_per_chunk: Var,
    head_dim: Var,
):
    vcmutex = VcMutex(
        0,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )

    l1_attn = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_v_beta = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_k_beta_g = DBuff(DT.bfloat16, [L, D], Position.L1)
    l0c_value = DBuff(DT.float, [L, D], Position.L0C)
    l0c_kcumdecay = DBuff(DT.float, [L, D], Position.L0C)

    key_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    value_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    beta_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    g_ub = DBuff(DT.float, [1, HALF_L], Position.UB)
    v_beta_nz_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    k_beta_g_nz_ub = DBuff(DT.bfloat16, [HALF_L, D], Position.UB)

    vcnt = Var(0)
    ccnt = Var(0)
    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    with auto_sync():
        for bhc in range(bhc_begin, bhc_end):
            c_idx = Var(bhc // (B * H))
            bh_remainder = Var(bhc % (B * H))
            b_idx = Var(bh_remainder // H)
            h_idx = Var(bh_remainder % H)

            vcmutex.lock()
            row_begin = Var(GetSubBlockIdx() * HALF_L)
            if row_begin < L:
                row_end = Min(row_begin + HALF_L, L)
                rows_this = Var(row_end - row_begin)
                key_ub[vcnt][0:rows_this, 0:D] <<= key[b_idx, h_idx, c_idx, row_begin:row_end, 0:D]
                value_ub[vcnt][0:rows_this, 0:D] <<= value[b_idx, h_idx, c_idx, row_begin:row_end, 0:D]
                beta_ub[vcnt][0:1, 0:rows_this] <<= beta[b_idx, h_idx, c_idx, row_begin:row_end]
                g_ub[vcnt][0:1, 0:rows_this] <<= g[b_idx, h_idx, c_idx, row_begin:row_end]
                scale_and_pack_vf(
                    key_ub[vcnt],
                    value_ub[vcnt],
                    beta_ub[vcnt],
                    g_ub[vcnt],
                    k_beta_g_nz_ub[vcnt],
                    v_beta_nz_ub[vcnt],
                    rows_this,
                )
                l1_v_beta[ccnt][row_begin:row_end, 0:D] <<= v_beta_nz_ub[vcnt][0:rows_this, 0:D].nz()
                l1_k_beta_g[ccnt][row_begin:row_end, 0:D] <<= k_beta_g_nz_ub[vcnt][0:rows_this, 0:D].nz()
            vcnt += 1
            vcmutex.ready()

            vcmutex.wait()
            l1_attn[ccnt][0:L, 0:L] <<= attn[b_idx, h_idx, c_idx, 0:L, 0:L]

            matmul(l0c_value[ccnt], l1_attn[ccnt], l1_v_beta[ccnt].T, splitn=128)
            matmul(l0c_kcumdecay[ccnt], l1_attn[ccnt], l1_k_beta_g[ccnt].T, splitn=128)

            value_out[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_value[ccnt]
            k_cumdecay[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_kcumdecay[ccnt]
            vcmutex.free()
            ccnt += 1

    return value_out, k_cumdecay


def run_kernel(key, value, beta, g, attn, simulator=True, trace=None, profile=False, out_dir=""):
    B, H, C, length_per_chunk, head_dim = key.shape
    value_out = torch.empty_like(value)
    k_cumdecay = torch.empty_like(key)

    saved_sim_config = getattr(gdn_recompute_wu_v2_kernel, "_simulator_config", None)
    if simulator:
        gdn_recompute_wu_v2_kernel._simulator_config = SimulatorConfig(
            core_count=32,
            execution_timeout_s=180.0,
            trace_enabled=trace is not None,
        )

    try:
        return OpExec(
            gdn_recompute_wu_v2_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace,
            profile=profile,
        )(
            key,
            value,
            beta,
            g,
            attn,
            value_out,
            k_cumdecay,
            B,
            H,
            C,
            length_per_chunk,
            head_dim,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr(gdn_recompute_wu_v2_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                gdn_recompute_wu_v2_kernel._simulator_config = saved_sim_config


def trace_makespan(trace_path):
    with Path(trace_path).open("r", encoding="utf-8") as handle:
        events = json.load(handle).get("traceEvents", [])
    timed = [
        float(event.get("ts", 0.0)) + float(event.get("dur", 0.0))
        for event in events
        if "ts" in event and "dur" in event
    ]
    if not timed:
        raise ValueError(f"trace contains no timed events: {trace_path}")
    return max(timed)


if __name__ == "__main__":
    torch.manual_seed(0)
    trace_path = Path(__file__).resolve().parents[2] / "tmp" / "gdn_recompute_wu_v2_h32_c16_trace.json"
    trace_path.parent.mkdir(parents=True, exist_ok=True)

    key, value, beta, g, attn = make_input(B=1, H=32, C=16)
    ref = gdn_recompute_wu(key, value, beta, g, attn)
    out = run_kernel(key, value, beta, g, attn, simulator=True, trace=str(trace_path))

    names = ("value", "k_cumdecay")
    for name, got, expected in zip(names, out, ref):
        torch.testing.assert_close(got.float(), expected.float(), rtol=2e-3, atol=2e-3)
        print(f"{name}: shape={tuple(got.shape)} dtype={got.dtype} max_abs={torch.abs(got.float() - expected.float()).max().item():.6e}")

    print(f"trace_path={trace_path}")
    print(f"trace_makespan={trace_makespan(trace_path):.1f}")
