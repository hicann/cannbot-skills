"""Sub-kernel reference: sub1 - M1 pure cube (q@k^T * decay_mask).

Location: `tmp_deepseek_decompose_delta_h/F/refs/sub1.py`

I/O contract
------------
Inputs:
  - q_i:             torch.bfloat16 [B, H, C, 64, 128]  memory=GM
  - k_i:             torch.bfloat16 [B, H, C, 64, 128]  memory=GM
  - decay_mask_i:    torch.float32  [B, H, C, 64, 64]   memory=GM

Outputs:
  - attn:            torch.bfloat16 [B, H, C, 64, 64] memory=GM

Producer(s): user input
Consumer(s): sub2

Primitives used: [P6, L1]

Precision
---------
L1 (matmul downcast bf16): q_i, k_i are bf16-origin -> L1 identity roundtrip.
The decay_mask_i multiply happens on fp32 after the matmul, no L1 involved.
"""

import torch


def subkernel(q_i, k_i, decay_mask_i):
    q_fp32 = q_i.float()
    k_fp32 = k_i.float()
    attn = (q_fp32.to(torch.bfloat16).to(torch.float32)
            @ k_fp32.to(torch.bfloat16).to(torch.float32).transpose(-1, -2)) * decay_mask_i
    return attn.bfloat16()
