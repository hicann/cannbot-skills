import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

L = 64
D = 128

from finalize_bwd import run as run_finalize_bwd  # noqa: E402
from inverse_preprocess_bwd import run as run_inverse_preprocess_bwd  # noqa: E402
from scan_split_bwd import run as run_scan_bwd  # noqa: E402
from wu_bwd import run as run_wu_bwd  # noqa: E402


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "gdn_bwd_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def _child_out_dir(out_dir, name):
    if not out_dir:
        return ""
    path = Path(out_dir) / name
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def run(query, key, value, beta, g, grad_output, g_cumsum, decay_mask, wu_attn_bf16, value_wu, k_cumdecay, state_after_history, v_new_history, k_weighted_history, grad_final_state, exp_delta_history, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    _ = g
    scan = run_scan_bwd(
        query, key, grad_output, g_cumsum, decay_mask, k_cumdecay,
        state_after_history, v_new_history, k_weighted_history,
        grad_final_state, exp_delta_history, simulator=simulator,
        trace=_child_trace(trace, out_dir, "scan_bwd"), gen_only=gen_only,
        out_dir=_child_out_dir(out_dir, "scan_bwd"), skip_compile=skip_compile,
        profile=profile,
    )
    wu = run_wu_bwd(
        key, value, beta, g_cumsum, wu_attn_bf16, scan[4], scan[5],
        simulator=simulator, trace=_child_trace(trace, out_dir, "wu_bwd"),
        gen_only=gen_only, out_dir=_child_out_dir(out_dir, "wu_bwd"),
        skip_compile=skip_compile, profile=profile,
    )
    inv = run_inverse_preprocess_bwd(
        key, beta, decay_mask, wu_attn_bf16, wu[0],
        simulator=simulator, trace=_child_trace(trace, out_dir, "inverse_preprocess_bwd"),
        gen_only=gen_only, out_dir=_child_out_dir(out_dir, "inverse_preprocess_bwd"),
        skip_compile=skip_compile, profile=profile,
    )
    final_tail = run_finalize_bwd(
        key, value, beta, scan[1], scan[2], scan[6],
        wu[1], wu[2], wu[3], inv[0], inv[1], inv[3],
        simulator=simulator, trace=_child_trace(trace, out_dir, "finalize_bwd"),
        gen_only=gen_only, out_dir=_child_out_dir(out_dir, "finalize_bwd"),
        skip_compile=skip_compile, profile=profile,
    )
    return (scan[0],) + tuple(final_tail)


if __name__ == "__main__":
    torch.manual_seed(42)
    B, H, C = 1, 1, 1
    query = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    value = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    g = torch.log(torch.sigmoid(torch.randn(B, H, C, L, dtype=torch.float32)))
    grad_output = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.1).to(torch.bfloat16)
    g_cumsum = g.cumsum(dim=-1)
    decay_mask = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.05
    wu_attn_bf16 = (torch.eye(L).reshape(1, 1, 1, L, L).repeat(B, H, C, 1, 1)).to(torch.bfloat16)
    value_wu = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    k_cumdecay = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    state_after_history = (torch.randn(B, H, C, D, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    v_new_history = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    k_weighted_history = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.05).to(torch.bfloat16)
    grad_final_state = torch.randn(B, H, D, D, dtype=torch.float32) * 0.05
    exp_delta_history = torch.randn(B, H, C, L, dtype=torch.float32) * 0.05
    result = run(
        query, key, value, beta, g, grad_output, g_cumsum, decay_mask,
        wu_attn_bf16, value_wu, k_cumdecay, state_after_history,
        v_new_history, k_weighted_history, grad_final_state, exp_delta_history,
    )
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
