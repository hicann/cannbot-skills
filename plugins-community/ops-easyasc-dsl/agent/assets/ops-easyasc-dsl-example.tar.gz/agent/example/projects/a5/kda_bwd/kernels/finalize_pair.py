"""Fused finalize matmuls: the former finalize_qk + finalize_kk pair.

Both halves consume the same `kg` tile, so the fused kernel loads it once per
chunk and runs all four cube products before stepping to the next chunk.
"""

import builtins
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _layout import flat_hvtl, to_hvtl


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
L = 64
D = 128
SHAPE_BINDINGS = {
    0: [0, 1, 2, None],
    1: [0, 1, 2, None],
    2: [0, 1, 2, None],
    3: [0, 1, 2, None],
    4: [0, 1, 2, None],
    5: [0, 1, 2, None],
    6: [0, 1, 2, None],
    7: [0, 1, 2, None],
    8: [0, 1, 2, None],
    9: [0, 1, 2, None],
}


@kernel()
def finalize_pair_kernel(
    Mqk_bf16: GMTensor,
    Mbase_bf16: GMTensor,
    Mbeta_bf16: GMTensor,
    q_bf16: GMTensor,
    k_bf16: GMTensor,
    kg_bf16: GMTensor,
    dq_pair: GMTensor,
    dk_pair: GMTensor,
    s_base: GMTensor,
    t_beta: GMTensor,
    B: Var,
    HV: Var,
    T: Var,
):
    l1_Mqk = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_Mbase = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_Mbeta = DBuff(DT.bfloat16, [L, L], Position.L1)
    l1_q = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_k = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_kg = DBuff(DT.bfloat16, [L, D], Position.L1)
    l0c_dq = DBuff(DT.float, [L, D], Position.L0C)
    l0c_dk = DBuff(DT.float, [L, D], Position.L0C)
    l0c_s = DBuff(DT.float, [L, D], Position.L0C)
    l0c_t = DBuff(DT.float, [L, D], Position.L0C)

    chunk_count = Var(T / L)
    work_count = Var(B * HV * chunk_count)
    work_per_core = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_core * GetCubeIdx())
    work_end = Min(work_begin + work_per_core, work_count)
    slot = Var(0)

    with auto_sync():
        for work_idx in range(work_begin, work_end):
            c_idx = Var(work_idx % chunk_count)
            bhv_idx = Var(work_idx / chunk_count)
            hv_idx = Var(bhv_idx % HV)
            b_idx = Var(bhv_idx / HV)
            row0 = Var(c_idx * L)
            row1 = Var(row0 + L)

            l1_Mqk[slot][0:L, 0:L] <<= Mqk_bf16[b_idx, hv_idx, row0:row1, 0:L]
            l1_q[slot][0:L, 0:D] <<= q_bf16[b_idx, hv_idx, row0:row1, 0:D]
            l1_kg[slot][0:L, 0:D] <<= kg_bf16[b_idx, hv_idx, row0:row1, 0:D]
            matmul(l0c_dq[slot], l1_Mqk[slot], l1_kg[slot].T, m=L, n=D, k=L, splitn=D)
            matmul(l0c_dk[slot], l1_Mqk[slot].T, l1_q[slot].T, m=L, n=D, k=L, splitn=D)
            dq_pair[b_idx, hv_idx, row0:row1, 0:D] <<= l0c_dq[slot]
            dk_pair[b_idx, hv_idx, row0:row1, 0:D] <<= l0c_dk[slot]

            l1_Mbase[slot][0:L, 0:L] <<= Mbase_bf16[b_idx, hv_idx, row0:row1, 0:L]
            l1_Mbeta[slot][0:L, 0:L] <<= Mbeta_bf16[b_idx, hv_idx, row0:row1, 0:L]
            l1_k[slot][0:L, 0:D] <<= k_bf16[b_idx, hv_idx, row0:row1, 0:D]
            matmul(l0c_s[slot], l1_Mbase[slot], l1_kg[slot].T, m=L, n=D, k=L, splitn=D)
            matmul(l0c_t[slot], l1_Mbeta[slot].T, l1_k[slot].T, m=L, n=D, k=L, splitn=D)
            s_base[b_idx, hv_idx, row0:row1, 0:D] <<= l0c_s[slot]
            t_beta[b_idx, hv_idx, row0:row1, 0:D] <<= l0c_t[slot]
            slot += 1

    return dq_pair, dk_pair, s_base, t_beta


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(Mqk, Mbase, Mbeta, q_hv, k_scaled, kg, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    # GM-native intra-stage: all inputs [B, HV, T, *] bf16. Outputs are now bf16
    # too -- the L0C(fp32)->GM(bf16) store downcasts via fixpipe on-device, so
    # finalize_post reads them directly with no host .to(bf16) cast.
    B = int(Mqk.shape[0])
    HV = int(Mqk.shape[1])
    T = int(Mqk.shape[2])
    for name, tensor in (("Mqk", Mqk), ("Mbase", Mbase), ("Mbeta", Mbeta), ("q_hv", q_hv), ("k_scaled", k_scaled), ("kg", kg)):
        if tensor.dtype != torch.bfloat16:
            raise TypeError(f"{name} must be bfloat16, got {tensor.dtype}")
    outputs = tuple(torch.empty((B, HV, T, D), dtype=torch.bfloat16, device=Mqk.device) for _ in builtins.range(4))
    previous_config = getattr(finalize_pair_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "finalize_pair")
    if simulator:
        finalize_pair_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            finalize_pair_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            Mqk, Mbase, Mbeta, q_hv, k_scaled, kg,
            outputs[0], outputs[1], outputs[2], outputs[3], B, HV, T, shape_bindings=SHAPE_BINDINGS
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(finalize_pair_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                finalize_pair_kernel._simulator_config = previous_config
    if gen_only:
        return result
    # Raw GM outputs [B, HV, T, D] bf16 (fixpipe downcast on store).
    return result[0], result[1], result[2], result[3]


if __name__ == "__main__":
    torch.manual_seed(0)
    B, T, HV = 1, 128, 2
    Mqk = torch.tril(torch.randn(B, T, HV, L) * 0.1)
    Mbase = torch.tril(torch.randn(B, T, HV, L) * 0.1, diagonal=-1)
    beta = torch.sigmoid(torch.randn(B, T, HV))
    Mbeta = Mbase * beta[..., None]
    q_hv = torch.randn(B, T, HV, D) * 0.1
    k_scaled = torch.randn(B, T, HV, D) * 0.1
    kg = torch.randn(B, T, HV, D) * 0.1

    bf16 = torch.bfloat16
    got = run(
        to_hvtl(Mqk.to(bf16)), to_hvtl(Mbase.to(bf16)), to_hvtl(Mbeta.to(bf16)),
        to_hvtl(q_hv.to(bf16)), to_hvtl(k_scaled.to(bf16)), to_hvtl(kg.to(bf16)),
        simulator=True,
    )
    got = tuple(flat_hvtl(x).float() for x in got)  # outputs are bf16 now

    bf = lambda x: x.to(torch.bfloat16).float()
    tol = 4e-3
    for b in builtins.range(B):
        for c in builtins.range(T // L):
            s, e = c * L, (c + 1) * L
            for hv in builtins.range(HV):
                exp_dq = bf(Mqk[b, s:e, hv]) @ bf(kg[b, s:e, hv])
                exp_dk = bf(Mqk[b, s:e, hv]).T @ bf(q_hv[b, s:e, hv])
                exp_s = bf(Mbase[b, s:e, hv]) @ bf(kg[b, s:e, hv])
                exp_t = bf(Mbeta[b, s:e, hv]).T @ bf(k_scaled[b, s:e, hv])
                torch.testing.assert_close(got[0][b, s:e, hv], exp_dq, rtol=tol, atol=tol)
                torch.testing.assert_close(got[1][b, s:e, hv], exp_dk, rtol=tol, atol=tol)
                torch.testing.assert_close(got[2][b, s:e, hv], exp_s, rtol=tol, atol=tol)
                torch.testing.assert_close(got[3][b, s:e, hv], exp_t, rtol=tol, atol=tol)
    print([tuple(item.shape) for item in got], [item.dtype for item in got])
