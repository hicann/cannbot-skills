"""chunk-delta sub2 (ungated): fused M2-M5 recurrence over the internal C loop.

Ungated delta-rule port of `gdn_fwd/kernels/chunk_delta_sub2.py`.  The Sub1->Sub2
split, the cube/vec bridges, and the four matmuls per chunk follow GDN; only the
gate factors are removed (so there is no `g` input):

  * inter-chunk read `attn_inter = q @ S` (GDN: `(q*exp(g_cumsum)) @ S`) — the
    per-row `exp(g)` scaling vf is dropped.  Here it is also folded into the
    output L0C accumulator: `q @ S` (is_init) then `attn @ v_new` (is_init=False)
    sum in L0C, so there is no separate bridge + vec add for the inter-chunk term;
  * state delta `S_delta = k^T @ v_new` (GDN weights the key by
    `exp(g_last - g_cumsum)`) — the key is packed to NZ unscaled;
  * state update `S = S_old + S_delta` (GDN: `S_old*exp(g_last) + S_delta`) — the
    decay scale is dropped.
"""
import os

import torch


from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig


SIM_CORE_COUNT = 32
SIM_TIMEOUT_S = 180.0

L = 64
D = 128
HALF_L = L // 2
HALF_D = D // 2
REGS_PER_ROW_D = D // 64
REGS_PER_FOUR_ROWS_D = REGS_PER_ROW_D * 4
BF16_C0 = 16
M1_N = L  # intra-chunk attn is [L, L]; one fp32 reg holds a 64-wide row

SHAPE_BINDINGS = {
    # `attn` (the intra-chunk q@k^T) is no longer a GM input: sub2 now computes it
    # internally (fused sub1), so it is dropped from the signature.
    0: [0, 1, 2, None, None],  # q[B,H,C,L,D]
    1: [0, 1, 2, None, None],  # k[B,H,C,L,D]
    2: [0, 1, 2, None, None],  # v[B,H,C,L,D]
    3: [0, 1, 2, None, None],  # k_cumdecay[B,H,C,L,D]
    4: [0, 1, None, None],     # last_recurrent_state[B,H,D,D]
    5: [0, 1, 2, None, None],  # core_attn_out[B,H,C,L,D]
    6: [0, 1, None, None],     # new_recurrent_state[B,H,D,D]
}


@vf()
def make_v_new_vf(v_prime_ub: Tensor, v_ub: Tensor, v_new_ub: Tensor):
    prime_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    v_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    for row_quad in range(HALF_L // 4):
        r = row_quad * 4
        prime_regs <<= v_prime_ub[r:r + 4, 0:D]
        v_regs <<= v_ub[r:r + 4, 0:D]
        v_regs <<= v_regs - prime_regs
        v_new_ub[r:r + 4, 0:D] <<= v_regs


@vf()
def cast_l_rows_float_to_bf16_vf(src_ub: Tensor, dst_ub: Tensor):
    regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    for row_quad in range(HALF_L // 4):
        r = row_quad * 4
        regs <<= src_ub[r:r + 4, 0:D]
        dst_ub[r:r + 4, 0:D] <<= regs


@vf()
def cast_d_rows_vf(src_ub: Tensor, dst_ub: Tensor):
    regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    for row_quad in range(HALF_D // 4):
        r = row_quad * 4
        regs <<= src_ub[r:r + 4, 0:D]
        dst_ub[r:r + 4, 0:D] <<= regs


@vf()
def pack_bf16_rows_to_nz_vf(src_nd: Tensor, dst_nz: Tensor, rows: Var):
    row = Reg(DT.bfloat16)
    for r in range(rows):
        row <<= src_nd[r:r + 1, 0:D]
        reg_to_ub(dst_nz[r * BF16_C0], row, rows)


@vf()
def attn_causal_keep_vf(score_ub: Tensor, out_ub: Tensor, row_begin: Var, nrows: Var):
    """Fused sub1 epilogue: keep the lower triangle (incl. diagonal) of q@k^T.

    Ported verbatim from chunk_delta_sub1: reads the fp32 score row, zeros the
    columns strictly above the diagonal, and casts to bf16 on store.
    """
    cols = Reg(DT.int)
    zero = Reg(DT.float)
    a_reg = Reg(DT.float)
    keep_mask = MaskReg(DT.int, init_mode=MaskType.NONE)

    zero <<= 0.0
    cols.arange(0)

    for r in range(nrows):
        abs_r = Var(row_begin + r)
        a_reg <<= score_ub[r * M1_N]
        # keep columns <= abs_r (lower triangle incl. diagonal), zero the rest.
        compare(keep_mask, cols, abs_r + 1, CompareMode.LT)
        select(a_reg, a_reg, zero, mask=keep_mask)
        out_ub[r * M1_N] <<= a_reg


@vf()
def state_add_vf(state_old_ub: Tensor, delta_ub: Tensor, out_ub: Tensor):
    """S = S_old + S_delta with no gate decay (replaces state_update_vf)."""
    delta_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    state_regs = RegList(DT.float, REGS_PER_FOUR_ROWS_D)
    for row_quad in range(HALF_D // 4):
        r = row_quad * 4
        delta_regs <<= delta_ub[r:r + 4, 0:D]
        state_regs <<= state_old_ub[r:r + 4, 0:D]
        delta_regs <<= delta_regs + state_regs
        out_ub[r:r + 4, 0:D] <<= delta_regs


@kernel()
def sub2_kernel(
    q_i: GMTensor,
    k_i: GMTensor,
    v_i: GMTensor,
    k_cumdecay_i: GMTensor,
    last_recurrent_state: GMTensor,
    core_attn_out: GMTensor,
    new_recurrent_state: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    bh_count = B * H
    bh_per_core = CeilDiv(bh_count, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, bh_count)

    # Lever A: the cube->vec bridge (l0c_ld -> ub_prod) is double-buffered and the
    # cvmutex is depth-2, so the cube side can issue the next matmul/publish while
    # the vec side still consumes the previous result instead of strict ping-pong.
    cvmutex = CvMutex(0, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    state_mutex = VcMutex(1, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    vnew_mutex = VcMutex(2, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    knz_mutex = VcMutex(3, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    # Fused sub1: q@k^T (cube) -> causal-keep mask (vec) -> l1_attn (vec -> cube).
    attn_cv = CvMutex(4, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    attn_vc = VcMutex(5, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1_state = Tensor(DT.bfloat16, [D, D], Position.L1)
    l1_kcd = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_q = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_k = Tensor(DT.bfloat16, [L, D], Position.L1)  # full key for the fused q@k^T
    l1_attn = Tensor(DT.bfloat16, [L, L], Position.L1)
    l1_v_new = Tensor(DT.bfloat16, [L, D], Position.L1)
    l1_k_nz = Tensor(DT.bfloat16, [L, D], Position.L1)

    l0c_ld = DBuff(DT.float, [L, D], Position.L0C)
    l0c_dxd = Tensor(DT.float, [D, D], Position.L0C)
    l0c_attn = Tensor(DT.float, [L, L], Position.L0C)  # fused q@k^T (L0C 256KB has room)

    ub_prod = DBuff(DT.float, [HALF_L, D], Position.UB)
    ub_attn_score = Tensor(DT.float, [HALF_L, L], Position.UB)  # fused q@k^T rows
    ub_attn_keep = Tensor(DT.bfloat16, [HALF_L, L], Position.UB)  # masked attn (bf16)
    ub_v = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_v_new = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_v_new_nz = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_out = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_k = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_k_nz = Tensor(DT.bfloat16, [HALF_L, D], Position.UB)
    ub_delta = Tensor(DT.float, [HALF_D, D], Position.UB)
    ub_state_nz = Tensor(DT.bfloat16, [HALF_D, D], Position.UB)
    ub_state = DBuff(DT.bfloat16, [HALF_D, D], Position.UB)
    state_read_cnt = Var(0)
    state_write_cnt = Var(1)
    kcd_read_cnt = Var(0)
    kcd_write_cnt = Var(0)
    prod_cnt = Var(0)  # rotates the double-buffered l0c_ld/ub_prod bridge slot

    for bh in range(bh_begin, bh_end):
        b_idx = Var(bh // H)
        h_idx = Var(bh % H)
        row_begin_l = Var(GetSubBlockIdx() * HALF_L)
        row_end_l = Var(row_begin_l + HALF_L)
        row_begin_d = Var(GetSubBlockIdx() * HALF_D)
        row_end_d = Var(row_begin_d + HALF_D)

        for c in range(C):
            ub_state_old = ub_state[state_read_cnt]
            ub_state_out = ub_state[state_write_cnt]
            with auto_sync():
                ub_v <<= v_i[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D]
                ub_k <<= k_i[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D]
                # Full q/k in L1 for the fused intra-chunk attn (q is reused by q@state).
                l1_q <<= q_i[b_idx, h_idx, c, 0:L, 0:D]
                l1_k <<= k_i[b_idx, h_idx, c, 0:L, 0:D]
                if c != C - 1:
                    l1_kcd[kcd_write_cnt] <<= k_cumdecay_i[b_idx, h_idx, c + 1, 0:L, 0:D]
                    kcd_write_cnt += 1

                # --- fused sub1: attn = causal_keep(q @ k^T) ---
                # State-independent, computed here (early) so the masked attn lands in
                # L1 well before the deferred output matmul; this removes the sub1
                # kernel and the attn GM round-trip and overlaps sub2's cube/vec slack.
                matmul(l0c_attn, l1_q, l1_k, m=L, n=L, k=D, splitn=L)
                attn_cv.lock()
                # bare l0c->ub: the half-height ub signals the per-sub-block row split
                # (dynamic l0c[row_begin_l:...] slices are rejected by l0c_to_ub).
                ub_attn_score <<= l0c_attn
                attn_cv.ready()
                attn_cv.wait()
                attn_causal_keep_vf(ub_attn_score, ub_attn_keep, row_begin_l, HALF_L)
                attn_cv.free()
                attn_vc.lock()
                l1_attn[row_begin_l:row_end_l, 0:L] <<= ub_attn_keep[0:HALF_L, 0:L]
                attn_vc.ready()

                # Pack the key to NZ early (state-independent) so the critical
                # state-delta matmul is not gated by waiting for it.
                knz_mutex.lock()
                pack_bf16_rows_to_nz_vf(ub_k, ub_k_nz, HALF_L)
                l1_k_nz[row_begin_l:row_end_l, 0:D] <<= ub_k_nz[0:HALF_L, 0:D].nz()
                knz_mutex.ready()

                # --- produce v_new ---
                if c == 0:
                    pack_bf16_rows_to_nz_vf(ub_v, ub_v_new_nz, HALF_L)
                    vnew_mutex.lock()
                    l1_v_new[row_begin_l:row_end_l, 0:D] <<= ub_v_new_nz[0:HALF_L, 0:D].nz()
                    vnew_mutex.ready()
                else:
                    pack_bf16_rows_to_nz_vf(ub_state_old, ub_state_nz, HALF_D)
                    state_mutex.lock()
                    l1_state[row_begin_d:row_end_d, 0:D] <<= ub_state_nz[0:HALF_D, 0:D].nz()
                    state_mutex.ready()

                    state_mutex.wait()
                    matmul(l0c_ld[prod_cnt], l1_kcd[kcd_read_cnt], l1_state.T, m=L, n=D, k=D, splitn=D)

                    cvmutex.lock()
                    ub_prod[prod_cnt] <<= l0c_ld[prod_cnt]
                    cvmutex.ready()
                    cvmutex.wait()
                    make_v_new_vf(ub_prod[prod_cnt], ub_v, ub_v_new)
                    cvmutex.free()
                    prod_cnt += 1
                    pack_bf16_rows_to_nz_vf(ub_v_new, ub_v_new_nz, HALF_L)

                    vnew_mutex.lock()
                    l1_v_new[row_begin_l:row_end_l, 0:D] <<= ub_v_new_nz[0:HALF_L, 0:D].nz()
                    vnew_mutex.ready()

                    # attn_inter = q @ state[c] is folded into the OUTPUT L0C tile:
                    # matmul3 (attn @ v_new) accumulates on top of it below
                    # (is_init=False), so this needs no cube->vec bridge and no
                    # separate ub_attn_inter vec add.  prod_cnt is NOT advanced here,
                    # so the output matmul reuses this same l0c_ld slot.  state[c] is
                    # released right after this last read.  l1_q is already loaded at
                    # the top of the iteration (shared with the fused q@k^T).
                    matmul(l0c_ld[prod_cnt], l1_q, l1_state.T, m=L, n=D, k=D, splitn=D)
                    state_mutex.free()

                # --- state delta (critical path): advance state[c+1] BEFORE the output,
                # so the next chunk's recurrence can start while this chunk's output runs.
                knz_mutex.wait()
                vnew_mutex.wait()
                matmul(l0c_dxd, l1_k_nz.T, l1_v_new.T, m=D, n=D, k=L, splitn=D)
                knz_mutex.free()

                cvmutex.lock()
                ub_delta <<= l0c_dxd
                cvmutex.ready()
                cvmutex.wait()
                if c == 0:
                    cast_d_rows_vf(ub_delta, ub_state_out)
                else:
                    state_add_vf(ub_state_old, ub_delta, ub_state_out)
                cvmutex.free()
                if c == C - 1:
                    new_recurrent_state[b_idx, h_idx, row_begin_d:row_end_d, 0:D] <<= ub_state_out[0:HALF_D, 0:D]

                # --- output (deferred, off the state critical path):
                # out = attn @ v_new + q @ state.  `l1_attn` is the fused intra-chunk
                # attention produced at the top of the iteration; wait for that
                # vec->cube publish here.  For c>0 the q@state term is already in this
                # L0C tile, so matmul3 accumulates (is_init=False); for c==0 there is
                # no inter-chunk term, so matmul3 initializes.
                attn_vc.wait()
                if c == 0:
                    matmul(l0c_ld[prod_cnt], l1_attn, l1_v_new.T, m=L, n=D, k=L, splitn=D)
                else:
                    matmul(l0c_ld[prod_cnt], l1_attn, l1_v_new.T, m=L, n=D, k=L, splitn=D, is_init=False)
                attn_vc.free()
                vnew_mutex.free()

                cvmutex.lock()
                ub_prod[prod_cnt] <<= l0c_ld[prod_cnt]
                cvmutex.ready()
                cvmutex.wait()
                cast_l_rows_float_to_bf16_vf(ub_prod[prod_cnt], ub_out)
                cvmutex.free()
                prod_cnt += 1
                core_attn_out[b_idx, h_idx, c, row_begin_l:row_end_l, 0:D] <<= ub_out[0:HALF_L, 0:D]

            state_read_cnt += 1
            state_write_cnt += 1
            if c != 0:
                kcd_read_cnt += 1
        bar_all()

    return core_attn_out, new_recurrent_state


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "chunk_delta_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(
    q_i, k_i, v_i, k_cumdecay_i, last_recurrent_state,
    simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=True,
):
    B = int(q_i.shape[0])
    H = int(q_i.shape[1])
    C = int(q_i.shape[2])
    device = q_i.device
    core_attn_out = torch.empty((B, H, C, L, D), dtype=torch.bfloat16, device=device)
    new_recurrent_state = torch.empty((B, H, D, D), dtype=torch.bfloat16, device=device)
    trace_path = _trace_path(trace, out_dir, "sub2")

    saved_sim_config = getattr(sub2_kernel, "_simulator_config", None)
    if simulator:
        sub2_kernel._simulator_config = SimulatorConfig(
            core_count=SIM_CORE_COUNT,
            execution_timeout_s=SIM_TIMEOUT_S,
            trace_enabled=trace_path is not None,
        )

    try:
        result = OpExec(
            sub2_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            profile=profile,
            gen_only=gen_only,
            skip_compile=skip_compile,
        )(
            q_i,
            k_i,
            v_i,
            k_cumdecay_i,
            last_recurrent_state,
            core_attn_out,
            new_recurrent_state,
            B,
            H,
            C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr(sub2_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                sub2_kernel._simulator_config = saved_sim_config

    return result


if __name__ == "__main__":
    import sys
    from pathlib import Path

    _ROOT = Path(__file__).resolve().parents[4]
    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
    from projects.a5.delta_rule_fwd.refs.oracle import expected_sub1, expected_sub2

    torch.manual_seed(42)
    B = 1
    H = 1
    C = 2
    q_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    k_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    v_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    k_cumdecay_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    last_recurrent_state = torch.zeros((B, H, D, D), dtype=torch.bfloat16)

    # Reference still goes through expected_sub1; the fused kernel computes attn
    # itself from (q, k), so run() no longer takes an attn argument.
    attn = expected_sub1(q_i, k_i)
    ref_core, ref_state = expected_sub2(attn, q_i, k_i, v_i, k_cumdecay_i, last_recurrent_state)

    result = run(q_i, k_i, v_i, k_cumdecay_i, last_recurrent_state, simulator=True)
    outputs = result if isinstance(result, tuple) else (result,)
    got_core, got_state = outputs[0], outputs[1]
    max_abs_core = (got_core.float() - ref_core.float()).abs().max().item()
    max_abs_state = (got_state.float() - ref_state.float()).abs().max().item()
    print("sub2", tuple(got_core.shape), got_core.dtype, f"core_max_abs={max_abs_core:.6e} state_max_abs={max_abs_state:.6e}")
    torch.testing.assert_close(got_core.float(), ref_core.float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(got_state.float(), ref_state.float(), rtol=2e-3, atol=2e-3)
    print("sub2 OK")
