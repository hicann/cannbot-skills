"""Local randomized check for sub45_fused_ref.py."""

import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from oracle import from_chunked_output, oracle, sample_inputs as oracle_sample_inputs, to_chunked_inputs  # noqa: E402
from sub1_gate_ref import subkernel as gate_cumsum  # noqa: E402
from sub2_intra_ref import subkernel as intra  # noqa: E402
from sub3_wy_ref import subkernel as wy  # noqa: E402
from sub45_fused_ref import subkernel  # noqa: E402


ATOL = 2e-2
RTOL = 2e-2


def sample_inputs():
    chunk_size = 32
    q, k, v, g_raw, beta, initial_state = oracle_sample_inputs(
        B=1, H=2, HV=4, C=2, L=chunk_size, K=32, V=32, seed=45
    )
    q_c, k_c, v_c, g_raw_c, beta_c = to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=chunk_size)
    g_c = gate_cumsum(g_raw_c)
    Aqk, Akk = intra(q_c, k_c, g_c, beta_c, scale=32 ** -0.5)
    w, u, _qg, kg = wy(q_c, k_c, v_c, beta_c, Akk, g_c)
    return (q, k, v, g_raw, beta, initial_state), (q_c, Aqk, kg, w, u, g_c, initial_state, 32 ** -0.5)


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return (value,)


def main():
    oracle_inputs, fused_inputs = sample_inputs()
    o_c, final_state = subkernel(*fused_inputs)
    actual = (from_chunked_output(o_c), final_state)
    expected = _as_tuple(oracle(*oracle_inputs))
    if len(actual) != len(expected):
        raise AssertionError(f"arity mismatch: actual={len(actual)} expected={len(expected)}")
    for idx, (act, exp) in enumerate(zip(actual, expected)):
        if not torch.isfinite(act.float()).all() or not torch.isfinite(exp.float()).all():
            raise AssertionError(f"non-finite output at index {idx}")
        torch.testing.assert_close(act.float(), exp.float(), atol=ATOL, rtol=RTOL)
    print("sub45_fused: OK")


if __name__ == "__main__":
    main()
