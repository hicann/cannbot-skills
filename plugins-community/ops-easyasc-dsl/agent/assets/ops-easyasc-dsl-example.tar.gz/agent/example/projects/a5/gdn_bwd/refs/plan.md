# Canonical Decomposition - gdn_bwd_full

**Target.** `a5`
**Tolerance.** `atol=5e-4`, `rtol=5e-4`
**Project dir.** `projects/a5/gdn_bwd`

## Behavior

Five-stage explicit split of `projects/a5/gdn_bwd/gdn_bwd_full.py`. The scan stage is split into a BHC-parallel local producer and a BH-parallel reverse-state consumer; all cross-stage tensors are materialized in GM. Round2 assumes forward provides `v_new_history`, so the local scan stage no longer recomputes `value_wu - k_cumdecay @ state`. The current state pass also consumes forward-saved `k_weighted_history` and fp32 `exp_delta_history`, replacing both the runtime key/gate weighting path before the `d_v_new` cube product and the per-row `exp(g_last - g)` vector recompute used by `d_k`/`d_g`. The `scan_local_bwd -> scan_state_bwd` score handoff saves `d_score_tmp` as bf16 because downstream score matmuls consume it only as a bf16 cube operand.

## IO Contract

| tensor | dtype | shape | layout | notes |
| --- | --- | --- | --- | --- |
| `query`, `key`, `value` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked row-major | original forward inputs |
| `beta`, `g`, `g_cumsum` | `torch.float32` | `[B,H,C,64]` | chunked | `g_cumsum` is saved forward cumsum |
| `grad_output` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked | upstream grad for bf16 forward output |
| `decay_mask` | `torch.float32` | `[B,H,C,64,64]` | row-major | saved forward mask |
| `wu_attn_bf16` | `torch.bfloat16` | `[B,H,C,64,64]` | row-major | saved kernel handoff from inverse |
| `value_wu`, `k_cumdecay` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked | saved recompute-WU outputs; `value_wu` is retained for the WU tail contract but no longer feeds `scan_local_bwd` |
| `state_after_history` | `torch.bfloat16` | `[B,H,C,128,128]` | chunked | post-update state after each chunk |
| `v_new_history` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked | forward-saved per-chunk `value_wu - k_cumdecay @ state` |
| `k_weighted_history` | `torch.bfloat16` | `[B,H,C,64,128]` | chunked | forward-saved per-chunk `key * exp(g_last - g)` after bf16 rounding |
| `exp_delta_history` | `torch.float32` | `[B,H,C,64]` | chunked | forward-saved per-row `exp(g_last - g)` for `scan_state_bwd` postprocess |
| `grad_final_state` | `torch.float32` | `[B,H,128,128]` | row-major | optional in source; this plan treats it as provided |
| `d_query`, `d_key`, `d_value` | `torch.float32` | `[B,H,C,64,128]` | chunked | output grads |
| `d_beta`, `d_g` | `torch.float32` | `[B,H,C,64]` | chunked | output grads |

Constants: `L=64`, `D=128`. Runtime dims: `B,H,C`; no L/D tail handling.

## Sub-kernels

| sub | ref file | inputs | outputs | pipe / primitive notes |
| --- | --- | --- | --- | --- |
| `scan_local_bwd` | `refs/scan_local_bwd_ref.py` | `query,key,grad_output,decay_mask,v_new_history` | `d_score_tmp`, `d_v_attn_tmp`, `d_decay_core`, `d_decay_core_masked` | BHC-parallel local products; no `value_wu/k_cumdecay/state` recompute; `d_score_tmp` is saved as bf16; `d_decay_core_masked = d_decay_core * decay_mask` is appended for the next all-cube `d_g` finalize path, [P1,P2,P6,L1] |
| `scan_state_bwd` | `refs/scan_state_bwd_ref.py` | `scan_local_bwd` temps + `v_new_history` + `k_weighted_history` + `exp_delta_history` + reverse state tensors | `d_q_core`, `d_k_core`, `d_g_core`, `d_value_wu`, `d_k_cumdecay` | BH-parallel reverse C state bridge; `k_weighted_history`, `v_new_history`, and bf16 `d_score_tmp` feed cube paths directly from GM to L1, fp32 `exp_delta_history` feeds `d_k`/`d_g` postprocess without vector exp recompute, c0 `d_q_core` stores directly L0C->GM, and `d_value_wu` VF finalizers materialize only the bf16 workspace rows, [P1,P2,P6,L1] |
| `wu_bwd` | `refs/wu_bwd_ref.py` | `key,value,beta,g_cumsum,wu_attn_bf16,d_value_wu,d_k_cumdecay` | `d_wu`, WU partials | cube-heavy, [P1,P2,P6,L1] |
| `inverse_preprocess_bwd` | `refs/inverse_preprocess_bwd_ref.py` | `key,beta,decay_mask,wu_attn_bf16,d_wu` | preprocess partials + `d_decay_pre_masked` | `W.T @ dW @ W.T`; `d_decay_pre_masked = d_decay_pre * decay_mask` is appended for the next all-cube `d_g` finalize path, [P1,P2,P6,L1] |
| `finalize_bwd` | `refs/finalize_bwd_ref.py` | upper partial gradients + `d_decay_core_masked` + `d_decay_pre_masked` | `d_key`, `d_value`, `d_beta`, `d_g` | fused upper VF computes `d_value`, `d_beta`, and `d_key` while keeping `d_k_beta_wu + d_k_beta_pre` in registers; `d_g` is now an all-cube lower path over flat BHC tiles, consuming the upstream masked decay matrices plus host-provided selector/identity/reverse-triangular constants, [P2,P6]; compose forwards `scan_state_bwd.d_q_core` directly as public `d_query` |

Supporting experiments were kept as local tmp probes, not plan kernels. The
standalone all-cube `d_g` mirror was integrated into `finalize_bwd`, while the
older scalar and `BHC_TILE=16` selector-matmul variants remain rejected because
their extra staging and coarse tile ownership were slower than the integrated
`BHC_TILE=4` form.

`scan_state_bwd` ref is intentionally arranged around the candidate
`cube -> vec -> cube -> vec` body:

```text
vec prelude: exp_g_i, q_exp, exp_g_last, saved exp_delta
cube0: d_q_exp, d_state_q, d_k_weighted, d_v_state
vec0: d_v_new, d_v_prime
cube1: d_q_score, d_k_score, d_k_cumdecay_i, d_state_k
vec1: d_q_i, d_k_i, d_g_i, next d_state
```

## DAG

Machine-readable file: `refs/dag.json`

```text
scan_local_bwd -> scan_state_bwd -> wu_bwd -> inverse_preprocess_bwd
scan_local_bwd, scan_state_bwd, wu_bwd, inverse_preprocess_bwd -> finalize_bwd
```

## Casts and Lossy Boundaries

| location | cast / approximation | reason | expected error |
| --- | --- | --- | --- |
| forward handoff | `wu_attn/value_wu/k_cumdecay/state_after_history/v_new_history/k_weighted_history` saved as bf16 | matches `gdn_full_chunked_kernels_state_history`; `scan_local_bwd` consumes saved `v_new_history` directly and `scan_state_bwd` consumes saved `k_weighted_history` directly | included in oracle inputs |
| `scan_local_bwd -> scan_state_bwd` | `d_score_tmp` is saved as bf16 and loaded directly GM->L1 with ND2NZ; `d_v_attn_tmp` stays fp32; `v_new_tmp` is removed | avoids the local-stage recompute, one GM temp, and the state-side `GM->UB->bf16 NZ->L1` score staging; kernels load `v_new_history` and `d_score_tmp` directly from GM to L1 | included in refs |
| `forward_state_history -> scan_state_bwd` | `k_weighted_history` is saved as bf16 and loaded GM->L1 with ND2NZ for the cube operand; `exp_delta_history` is saved as fp32 and loaded GM->UB for vector postprocess | removes the runtime `key * exp_delta` vector/pack path and the fp32 `exp(g_last - g)` recompute from `scan_state_bwd` | included in refs |
| `scan_state_bwd -> wu_bwd` | `d_value_wu` and `d_k_cumdecay` are bf16 workspaces | WU only consumes them as cube operands, and cube operand staging rounds to bf16 anyway; keeping this boundary bf16 avoids a later fp32 GM->UB->bf16 pack path | exact to oracle |
| `wu_bwd -> inverse_preprocess_bwd` | `d_wu` saved as bf16 | internal cube-only handoff; avoids an fp32 GM path before the next bf16 cube operand load | included in refs |
| cube refs | every matmul uses bf16 operands with fp32 accumulation/output | models the preferred A5 cube precision path; exp, decay masks, reductions, and final accumulation stay fp32 | refs are exact to oracle |

## Validation

```bash
python -m py_compile refs/*.py
for f in refs/*_check.py; do python "$f"; done
python refs/compose.py
```

Observed:

- `py_compile`: OK
- `scan_bwd_check.py`, `scan_local_bwd_ref.py`, `scan_state_bwd_ref.py`, `scan_split_bwd_ref.py`, `wu_bwd_check.py`, `inverse_preprocess_bwd_check.py`, `finalize_bwd_check.py`: OK
- `compose.py`: OK for `(B,H,C)=(1,2,2)` and `(2,1,3)`

## Open Questions

- This plan assumes `initial_state=None` and does not emit `d_initial_state`; add it to `scan_bwd` outputs if the public backward needs trainable initial state.
