"""chunk-delta compose (ungated): a single fused chunk_delta kernel.

`sub1` (the intra-chunk attention `attn = causal_keep(q@k^T)`) is now fused into
`sub2`, so the chunk_delta stage is one kernel launch: `sub2` takes
(query, key, value_wu, k_cumdecay, state) and computes `attn` internally per
chunk — no `attn` GM round-trip, no separate sub1 launch.  (`chunk_delta_sub1.py`
is kept as a standalone reference kernel but is no longer on the compose path.)
"""
import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

L = 64
D = 128


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "delta_fwd_chunk_delta_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def _rand_bf16(shape, scale=0.125):
    return (torch.randn(shape, dtype=torch.float32) * scale).to(torch.bfloat16)


def _sample_inputs(B=2, H=4, C=2):
    query = _rand_bf16((B, H, C, L, D))
    key = _rand_bf16((B, H, C, L, D))
    value = _rand_bf16((B, H, C, L, D))
    k_cumdecay = _rand_bf16((B, H, C, L, D))
    return query, key, value, k_cumdecay


from chunk_delta_sub2 import run as run_sub2  # noqa: E402


def run(
    query, key, value, k_cumdecay,
    simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=True,
):
    B, H, _C = int(query.shape[0]), int(query.shape[1]), int(query.shape[2])
    state = torch.zeros((B, H, D, D), dtype=torch.bfloat16, device=query.device)
    return run_sub2(
        query, key, value, k_cumdecay, state,
        simulator=simulator,
        trace=_child_trace(trace, out_dir, "sub2"),
        gen_only=gen_only,
        out_dir=out_dir,
        skip_compile=skip_compile,
        profile=profile,
    )


if __name__ == "__main__":
    _ROOT = Path(__file__).resolve().parents[4]
    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
    from projects.a5.delta_rule_fwd.refs.oracle import oracle_full

    torch.manual_seed(42)
    args = _sample_inputs(B=1, H=1, C=2)
    out, state = run(*args, simulator=True)
    ref_core, ref_state = oracle_full(*args)
    core_max_abs = (out.float() - ref_core.float()).abs().max().item()
    state_max_abs = (state.float() - ref_state.float()).abs().max().item()
    print("chunk_delta_compose", tuple(out.shape), out.dtype,
          f"core_max_abs={core_max_abs:.6e} state_max_abs={state_max_abs:.6e}")
    torch.testing.assert_close(out.float(), ref_core.float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(state.float(), ref_state.float(), rtol=2e-3, atol=2e-3)
    print("chunk_delta_compose OK")
