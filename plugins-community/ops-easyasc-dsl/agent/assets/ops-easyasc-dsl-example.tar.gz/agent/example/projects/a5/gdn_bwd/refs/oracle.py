"""End-to-end PyTorch oracle for canonical gdn_bwd."""

from common import make_inputs, oracle


if __name__ == "__main__":
    outputs = oracle(*make_inputs())
    print([tuple(item.shape) for item in outputs], [item.dtype for item in outputs])
