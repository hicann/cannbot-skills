"""Fused inverse matmuls: the former inverse_qkgw + inverse_beta pair.

Loads `dv` once per chunk and keeps `d_w = -(dv @ h^T)` on chip: the fp32
d_vh product crosses FIX -> UB (negate + bf16 cast) -> L1 and feeds
`Akk^T @ d_w` directly. `d_vh` is still written to GM for the host epilogue
that needs the dA_inv path.

All five outputs store bf16: every consumer is fp32 host glue that rounds to
bf16 at the public boundary anyway. Four outputs leave through the vector
side (L0C -> UB cast -> MTE3 GM): FIX is L0C-read bandwidth bound, so a GM
store costs 1324 cycles while l0c_to_ub costs 138. Only d_vh keeps the FIX
GM store, moving the kernel from FIX-bound to MTE2-bound.
"""

import builtins
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _torch_formula import D, L, build_saved_forward, inverse_beta_only, inverse_qkgw_only, scan_bwd
from _layout import flat_lvd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
HALF_L = L // 2
# Frozen public layouts read strided on-device. do/v_new/dv are BTHVD
# [B, T, HV, D] (T,D literal; HV = sym1); h/dh are chunk-major [B, C, HV, D, D]
# (C = sym2, HV = sym1); Akk is BTHVL [B, T, HV, L]. The five outputs stay
# GM-native [B, HV, C, L, D] (internal to the inverse stage). Var args: B/HV/C.
SHAPE_BINDINGS = {
    0: [0, None, 1, None],      # do      [B, T, HV, D]
    1: [0, None, 1, None],      # v_new   [B, T, HV, D]
    2: [0, None, 1, None],      # dv      [B, T, HV, D]
    3: [0, 2, 1, None, None],   # h       [B, C, HV, D, D]
    4: [0, 2, 1, None, None],   # dh      [B, C, HV, D, D]
    5: [0, None, 1, None],      # Akk     [B, T, HV, L]
    6: [0, 1, 2, None, None],   # d_qg    [B, HV, C, L, D]  internal
    7: [0, 1, 2, None, None],   # d_kg
    8: [0, 1, 2, None, None],   # d_vh
    9: [0, 1, 2, None, None],   # d_v_beta
    10: [0, 1, 2, None, None],  # d_k_beta_g
}


@vf()
def negate_cast_dw_vf(dvh_f_ub: Tensor, dw_h_ub: Tensor):
    reg_f32 = Reg(DT.float)
    n_loops = Var(HALF_L * D / 64)
    for i in range(n_loops):
        reg_f32 <<= dvh_f_ub[i * 64]
        reg_f32 <<= reg_f32 * (-1.0)
        dw_h_ub[i * 64] <<= reg_f32
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@vf()
def cast_out_vf(out_f_ub: Tensor, out_h_ub: Tensor):
    reg_f32 = Reg(DT.float)
    n_loops = Var(HALF_L * D / 64)
    for i in range(n_loops):
        reg_f32 <<= out_f_ub[i * 64]
        out_h_ub[i * 64] <<= reg_f32
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def inverse_mm_kernel(
    do_bf16: GMTensor,
    vnew_bf16: GMTensor,
    dv_bf16: GMTensor,
    h_bf16: GMTensor,
    dh_bf16: GMTensor,
    Akk_bf16: GMTensor,
    d_qg: GMTensor,
    d_kg: GMTensor,
    d_vh: GMTensor,
    d_v_beta: GMTensor,
    d_k_beta_g: GMTensor,
    B: Var,
    HV: Var,
    C: Var,
):
    dvh_mutex = CvMutex(0, depth=3, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    dw_bridge = VcMutex(
        1,
        depth=3,
        src_start_pipe=Pipe.MTE3,
        src_end_pipe=Pipe.MTE3,
        dst_start_pipe=Pipe.MTE1,
        dst_end_pipe=Pipe.MTE1,
    )
    out_mutex = CvMutex(2, depth=3, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.MTE3)

    l1_do = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_vnew = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_dv = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_h = DBuff(DT.bfloat16, [D, D], Position.L1)
    l1_dh = DBuff(DT.bfloat16, [D, D], Position.L1)
    l1_Akk = TBuff(DT.bfloat16, [L, L], Position.L1)
    l1_dw = TBuff(DT.bfloat16, [L, D], Position.L1)

    l0c_dqg = Tensor(DT.float, [L, D], Position.L0C)
    l0c_dkg = Tensor(DT.float, [L, D], Position.L0C)
    l0c_dvh = DBuff(DT.float, [L, D], Position.L0C)
    l0c_dvbeta = DBuff(DT.float, [L, D], Position.L0C)
    l0c_dkbetag = DBuff(DT.float, [L, D], Position.L0C)

    dvh_f_ub = TBuff(DT.float, [HALF_L, D], Position.UB)
    dw_h_ub = TBuff(DT.bfloat16, [HALF_L, D], Position.UB)
    out_f_ub = TBuff(DT.float, [HALF_L, D], Position.UB)
    out_h_ub = TBuff(DT.bfloat16, [HALF_L, D], Position.UB)

    work_count = Var(B * HV * C)
    work_per_core = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_core * GetCubeIdx())
    work_end = Min(work_begin + work_per_core, work_count)
    row_begin_l = Var(GetSubBlockIdx() * HALF_L)
    row_end_l = Var(row_begin_l + HALF_L)

    with auto_sync():
        for pipe_work in range(work_begin, work_end + 2):
            if pipe_work < work_end:
                c_idx = Var(pipe_work % C)
                bhv_idx = Var(pipe_work / C)
                hv_idx = Var(bhv_idx % HV)
                b_idx = Var(bhv_idx / HV)
                row0 = Var(c_idx * L)
                row1 = Var(row0 + L)

                # Strided BTHVD/BTHVL reads from the frozen public layout: explicit
                # N_src = HV*D / HV*L pitch (the <<= auto-infer would use D/L and
                # silently read compacted adjacent tokens -- wrong data, no crash).
                # h/dh stay contiguous [D, D] blocks (frozen [B, C, HV, D, D]); only
                # their index order changes, so the <<= auto-infer (N_src=D) is right.
                gm_to_l1_nd2nz(l1_dv[pipe_work][0:L, 0:D], dv_bf16[b_idx, row0:row1, hv_idx, 0:D], L, D, HV * D, L)
                l1_h[pipe_work][0:D, 0:D] <<= h_bf16[b_idx, c_idx, hv_idx, 0:D, 0:D]
                gm_to_l1_nd2nz(l1_do[pipe_work][0:L, 0:D], do_bf16[b_idx, row0:row1, hv_idx, 0:D], L, D, HV * D, L)
                gm_to_l1_nd2nz(l1_vnew[pipe_work][0:L, 0:D], vnew_bf16[b_idx, row0:row1, hv_idx, 0:D], L, D, HV * D, L)
                l1_dh[pipe_work][0:D, 0:D] <<= dh_bf16[b_idx, c_idx, hv_idx, 0:D, 0:D]
                gm_to_l1_nd2nz(l1_Akk[pipe_work][0:L, 0:L], Akk_bf16[b_idx, row0:row1, hv_idx, 0:L], L, L, HV * L, L)

                # The dvh matmul leads: it gates the FIX -> UB -> L1 d_w chain.
                matmul(l0c_dvh[pipe_work], l1_dv[pipe_work], l1_h[pipe_work], m=L, n=D, k=D, splitn=D)
                matmul(l0c_dqg, l1_do[pipe_work], l1_h[pipe_work], m=L, n=D, k=D, splitn=D)
                matmul(l0c_dvbeta[pipe_work], l1_Akk[pipe_work].T, l1_dv[pipe_work].T, m=L, n=D, k=L, splitn=D)
                matmul(l0c_dkg, l1_vnew[pipe_work], l1_dh[pipe_work], m=L, n=D, k=D, splitn=D)

                d_vh[b_idx, hv_idx, c_idx, 0:L, 0:D] <<= l0c_dvh[pipe_work]

                dvh_mutex.lock()
                l0c_to_ub(dvh_f_ub[pipe_work], l0c_dvh[pipe_work], M=L, N=D, N_dst=D, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
                dvh_mutex.ready()
                dvh_mutex.wait()
                negate_cast_dw_vf(dvh_f_ub[pipe_work], dw_h_ub[pipe_work])
                dvh_mutex.free()

                dw_bridge.lock()
                l1_dw[pipe_work][row_begin_l:row_end_l, 0:D] <<= dw_h_ub[pipe_work][0:HALF_L, 0:D]
                dw_bridge.ready()

                # dqg / dvbeta / dkg leave through the vector side: FIX is L0C
                # read bound, so l0c_to_ub (138cy) + MTE3 store beats five
                # l0c_to_gm stores (1324cy each).
                out_mutex.lock()
                l0c_to_ub(out_f_ub[3 * pipe_work], l0c_dqg, M=L, N=D, N_dst=D, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
                out_mutex.ready()
                out_mutex.wait()
                cast_out_vf(out_f_ub[3 * pipe_work], out_h_ub[3 * pipe_work])
                d_qg[b_idx, hv_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= out_h_ub[3 * pipe_work][0:HALF_L, 0:D]
                out_mutex.free()

                out_mutex.lock()
                l0c_to_ub(out_f_ub[3 * pipe_work + 1], l0c_dvbeta[pipe_work], M=L, N=D, N_dst=D, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
                out_mutex.ready()
                out_mutex.wait()
                cast_out_vf(out_f_ub[3 * pipe_work + 1], out_h_ub[3 * pipe_work + 1])
                d_v_beta[b_idx, hv_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= out_h_ub[3 * pipe_work + 1][0:HALF_L, 0:D]
                out_mutex.free()

                out_mutex.lock()
                l0c_to_ub(out_f_ub[3 * pipe_work + 2], l0c_dkg, M=L, N=D, N_dst=D, M_src=L, dual_mode=DualMode.SPLITM, sub_block_id=0)
                out_mutex.ready()
                out_mutex.wait()
                cast_out_vf(out_f_ub[3 * pipe_work + 2], out_h_ub[3 * pipe_work + 2])
                d_kg[b_idx, hv_idx, c_idx, row_begin_l:row_end_l, 0:D] <<= out_h_ub[3 * pipe_work + 2][0:HALF_L, 0:D]
                out_mutex.free()

            if pipe_work >= work_begin + 2:
                prev_work = Var(pipe_work - 2)
                prev_c = Var(prev_work % C)
                prev_bhv = Var(prev_work / C)
                prev_hv = Var(prev_bhv % HV)
                prev_b = Var(prev_bhv / HV)

                dw_bridge.wait()
                matmul(l0c_dkbetag[prev_work], l1_Akk[prev_work].T, l1_dw[prev_work].T, m=L, n=D, k=L, splitn=D)
                dw_bridge.free()

                d_k_beta_g[prev_b, prev_hv, prev_c, 0:L, 0:D] <<= l0c_dkbetag[prev_work]

    return d_qg, d_kg, d_vh, d_v_beta, d_k_beta_g


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(do, v_new, dv, h, dh, Akk, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    # Frozen public layouts read strided on-device -- do/v_new/dv BTHVD
    # [B, T, HV, D], h/dh [B, C, HV, D, D], Akk BTHVL [B, T, HV, L], all bf16.
    # No host layout/dtype glue: the kernel's DataCopy strides over the seams.
    B = int(do.shape[0])
    T = int(do.shape[1])
    HV = int(do.shape[2])
    C = T // L
    for name, tensor in (("do", do), ("v_new", v_new), ("dv", dv), ("h", h), ("dh", dh), ("Akk", Akk)):
        if tensor.dtype != torch.bfloat16:
            raise TypeError(f"{name} must be bfloat16, got {tensor.dtype}")

    outputs = tuple(
        torch.empty((B, HV, C, L, D), dtype=torch.bfloat16, device=do.device) for _ in builtins.range(5)
    )
    previous_config = getattr(inverse_mm_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "inverse_mm")
    if simulator:
        inverse_mm_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            inverse_mm_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            do,
            v_new,
            dv,
            h,
            dh,
            Akk,
            outputs[0],
            outputs[1],
            outputs[2],
            outputs[3],
            outputs[4],
            B,
            HV,
            C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(inverse_mm_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                inverse_mm_kernel._simulator_config = previous_config
    if gen_only:
        return result
    # Raw GM outputs [B, HV, C, L, D] bf16; d_w = -d_vh (bf16 negate is exact).
    # The former bf16->fp32->bf16 round-trip is gone: consumers take bf16 GM.
    return result[0], result[1], -result[2], result[3], result[4]


if __name__ == "__main__":
    from projects.a5.kda_bwd.refs.common import make_inputs

    tol = 4e-3
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    caches = build_saved_forward(inputs)
    scan = scan_bwd(inputs, caches)
    exp_qg, exp_kg, exp_vh = inverse_qkgw_only(inputs, caches, scan)
    exp_v_beta, exp_k_beta_g = inverse_beta_only(inputs, caches, scan, -exp_vh)
    # Raw frozen inputs -- no host to_lvd/to_hvcdd/to_hvtl: the kernel reads the
    # BTHVD/BCHVDD/BTHVL seams strided on-device.
    got = run(
        inputs.do, caches.v_new, scan.dv,
        caches.h, scan.dh, caches.Akk,
        simulator=True,
    )
    got = tuple(flat_lvd(x) for x in got)  # outputs stay GM-native (internal)
    for got_item, exp_item in zip(got, (exp_qg, exp_kg, -exp_vh, exp_v_beta, exp_k_beta_g)):
        # Outputs store bf16: compare against the bf16-rounded reference with
        # a 2-ULP allowance for fp32-accumulation-order ties at |out| ~ 0.6.
        exp_item = exp_item.to(torch.bfloat16).float()
        torch.testing.assert_close(got_item.float(), exp_item, rtol=tol, atol=1e-2)
    print([tuple(item.shape) for item in got], [item.dtype for item in got])
