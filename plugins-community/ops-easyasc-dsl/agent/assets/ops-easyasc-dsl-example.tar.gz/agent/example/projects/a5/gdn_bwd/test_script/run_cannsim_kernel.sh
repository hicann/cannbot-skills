#!/bin/bash
# Full CANNSIM pipeline for one gdn_bwd sub-kernel.
#   run_cannsim_kernel.sh <kernel_name> <C_SIZE>
# Produces: $WORKROOT/<name>/report/trace_core0.json  +  $WORKROOT/<name>/analyze.log
set -u
NAME="$1"; CS="${2:-4}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"   # this test_script/ dir (durable copies)
REPO="${EASYASC_REPO_ROOT:-$(cd "$SCRIPT_DIR/../../../.." && pwd)}"
PY="${EASYASC_PYTHON:-python3}"
WORKROOT="${EASYASC_CANNSIM_WORK_ROOT:-${TMPDIR:-/tmp}/easyasc-cannsim/gdn_bwd}"
WORK="$WORKROOT/$NAME"
: "${ASCEND_HOME_PATH:?Set ASCEND_HOME_PATH after sourcing <ascend-cann-root>/set_env.sh}"
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
rm -rf "$WORK"; mkdir -p "$WORK"; cd "$WORK" || exit 9

echo "=== [$NAME] generate+build+cannsim (C=$CS) $(date +%T) ==="
WORK="$WORK" C_SIZE="$CS" REPO="$REPO" PYTHONPATH="$REPO" "$PY" "$SCRIPT_DIR/cannsim_gdn_bwd.py" "$NAME" 2>&1
echo "=== [$NAME] python exit=$? $(date +%T) ==="

REC=$(find "$WORK" -type d -name 'cannsim_*_test_aclnnop' 2>/dev/null | sort | tail -1)
if [ -z "$REC" ]; then echo "[$NAME] NO record dir (cannsim did not run)"; exit 3; fi
echo "=== [$NAME] record=$REC ==="
ls -la "$REC"/instr.bin 2>/dev/null

REP="$WORK/report"; rm -rf "$REP"; mkdir -p "$REP"
cannsim report -e "$REC" -o "$REP" -n 0 2>&1 | tail -3
TRACE=$(find "$REP" -name 'trace_core0.json' 2>/dev/null | head -1)
echo "=== [$NAME] trace=$TRACE ==="
if [ -n "$TRACE" ]; then
  "$PY" "$SCRIPT_DIR/analyze_cannsim_trace.py" "$TRACE" 2>&1 | tee "$WORK/analyze.log"
fi
echo "=== [$NAME] ALL DONE $(date +%T) ==="
