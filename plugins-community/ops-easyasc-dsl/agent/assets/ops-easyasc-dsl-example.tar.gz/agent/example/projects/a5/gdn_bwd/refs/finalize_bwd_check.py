"""Local randomized check for finalize_bwd_ref.py."""

import torch

from common import core_scan_bwd, finalize_grads, inverse_preprocess_bwd, make_inputs, wu_recompute_bwd
from finalize_bwd_ref import subkernel


def main():
    for seed in (41, 43):
        torch.manual_seed(seed)
        full = make_inputs(B=1, H=2, C=2)
        scan = core_scan_bwd(full[0], full[1], full[5], full[6], full[7], full[10], full[11], full[12], full[13], full[14])
        wu = wu_recompute_bwd(full[1], full[2], full[3], full[6], full[8], scan[4], scan[5])
        inv = inverse_preprocess_bwd(full[1], full[3], full[7], full[8], wu[0])
        args = (full[1], full[2], full[3], full[7], scan[0], scan[1], scan[2], scan[3], wu[1], wu[2], wu[3], inv[0], inv[1], inv[2])
        actual = subkernel(*args)
        ref = finalize_grads(*args)
        for act, exp in zip(actual, ref):
            torch.testing.assert_close(act.float(), exp.float(), atol=0.0, rtol=0.0)
    print("finalize_bwd: OK")


if __name__ == "__main__":
    main()
