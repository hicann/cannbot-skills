"""GDN forward chunk-delta state-history correctness check."""

import sys
from pathlib import Path

import torch

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
REFS_DIR = PROJECT_DIR / "refs"
KERNELS_DIR = PROJECT_DIR / "kernels"
L = 64
D = 128
ATOL = 2e-3
RTOL = 2e-3

def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)

for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from chunk_delta_compose_state_history import run as kernel_run  # noqa: E402
from oracle import oracle_full_state_history  # noqa: E402


def _rand_bf16(shape, scale):
    return (torch.randn(shape, dtype=torch.float32) * scale).to(torch.bfloat16)


def make_inputs():
    torch.manual_seed(23456)
    B, H, C = 1, 1, 2
    query = _rand_bf16((B, H, C, L, D), 0.05)
    key = _rand_bf16((B, H, C, L, D), 0.05)
    value = _rand_bf16((B, H, C, L, D), 0.05)
    g = (-torch.rand(B, H, C, L, dtype=torch.float32) * 0.1).cumsum(-1)
    decay_mask = torch.randn(B, H, C, L, L, dtype=torch.float32) * 0.1
    k_cumdecay = _rand_bf16((B, H, C, L, D), 0.05)
    return query, key, value, g, decay_mask, k_cumdecay


def _check_output(idx, got, ref):
    if tuple(got.shape) != tuple(ref.shape):
        raise RuntimeError(f"output {idx} shape mismatch {tuple(got.shape)} != {tuple(ref.shape)}")
    got_f = got.float()
    ref_f = ref.float()
    diff = (got_f - ref_f).abs()
    max_abs = float(diff.max())
    max_rel = float((diff / ref_f.abs().clamp_min(1e-12)).max())
    ok = bool(torch.allclose(got_f, ref_f, atol=ATOL, rtol=RTOL))
    print(
        f"gdn_fwd chunk_delta_state_history output{idx}: shape={tuple(got.shape)} dtype={got.dtype} "
        f"max_abs={max_abs:.3e} max_rel={max_rel:.3e} {'OK' if ok else 'FAIL'}"
    )
    return ok


def main():
    args = make_inputs()
    expected = oracle_full_state_history(*args)
    actual = kernel_run(*args, simulator=True)
    all_ok = True
    for idx, (got, ref) in enumerate(zip(actual, expected)):
        all_ok = _check_output(idx, got, ref) and all_ok
    if not all_ok:
        return 1
    print("gdn_fwd chunk_delta state-history simulator-vs-ref OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
