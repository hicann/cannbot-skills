"""Finalize-stage pre glue (formerly the host pre-loop in finalize_bwd).

Per chunk, all-vector:

    row_scale = exp2(g - g_last)              col_scale = exp2(g_last - g)
    q_scaled  = q_hv * row_scale              k_scaled  = k_hv * row_scale
    kg        = k_hv * col_scale
    M_qk      = tril(dAqk)                     (inclusive diagonal, j <= r)
    M_base    = tril(dAkk, -1)                 (strict lower, j < r)
    M_beta    = M_base * beta[:, None]         (row-scaled by beta)

`q_scaled / k_scaled / kg / M_qk / M_base / M_beta` feed `finalize_pair`.
`row_scale / col_scale` are NOT published: they span exp2 of O(g_last) ~ 1e29,
so a bf16 GM round-trip would lose too many bits and an fp32 one costs 64 KB of
UB downstream -- `finalize_post` recomputes them from `g` in fp32 instead.
exp2 = `(x * ln2).exp()` (a5 micro has no exp2).
"""

import builtins
import math
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig

from _layout import flat_lvd


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0
L = 64
D = 128
REGS_D = D // 64
LN2 = math.log(2.0)
#
# A per-token scalar burst must start on a 32B row boundary. Packing beta as
# [L, C0] keeps token r at row r, col 0 instead of the sparse [1, L] layout
# that mis-addresses `.single()` reads.
SCALAR_PACK_BF16 = DT.bfloat16.C0
# Scalar Var order: (B, HV, C, H, G) -> symbols 0,1,2,3,4. Inputs are token-major
# BTHVD (read strided on-device); outputs stay GM-native [B,HV,C,L,*].
SHAPE_BINDINGS = {
    0: [0, None, 3, None],      # q        [B, T, H, D]   (H = symbol 3; H->HV gather)
    1: [0, None, 3, None],      # k        [B, T, H, D]
    2: [0, None, 1, None],      # g_cumsum [B, T, HV, D]  (HV = symbol 1)
    3: [0, None, 1],            # beta     [B, T, HV]
    4: [0, None, 1, None],      # dAqk     [B, T, HV, L]  (from scan)
    5: [0, None, 1, None],      # dAkk     [B, T, HV, L]  (from inverse)
    6: [0, 1, 2, None, None],   # q_scaled [B, HV, C, L, D]   intra-stage GM-native
    7: [0, 1, 2, None, None],   # k_scaled
    8: [0, 1, 2, None, None],   # kg
    9: [0, 1, 2, None, None],   # M_qk     [B, HV, C, L, L]
    10: [0, 1, 2, None, None],  # M_base
    11: [0, 1, 2, None, None],  # M_beta
}


@vf()
def finalize_pre_vf(
    q_ub: Tensor,
    k_ub: Tensor,
    g_ub: Tensor,
    beta_ub: Tensor,
    dAqk_ub: Tensor,
    dAkk_ub: Tensor,
    q_scaled_ub: Tensor,
    k_scaled_ub: Tensor,
    kg_ub: Tensor,
    mqk_ub: Tensor,
    mbase_ub: Tensor,
    mbeta_ub: Tensor,
    rows: Var,
):
    glast = RegList(DT.float, REGS_D)
    g = RegList(DT.float, REGS_D)
    rscale = RegList(DT.float, REGS_D)
    cscale = RegList(DT.float, REGS_D)
    qr = RegList(DT.float, REGS_D)
    kr = RegList(DT.float, REGS_D)
    prod = RegList(DT.float, REGS_D)
    tmp = RegList(DT.float, REGS_D)
    cols = Reg(DT.int)
    daqk = Reg(DT.float)
    dakk = Reg(DT.float)
    base = Reg(DT.float)
    out = Reg(DT.float)
    zero = Reg(DT.float)
    beta_r = Reg(DT.float)
    mask_le = MaskReg(DT.int, init_mode=MaskType.NONE)
    mask_lt = MaskReg(DT.int, init_mode=MaskType.NONE)

    glast <<= g_ub[L - 1:L, 0:D]
    zero <<= 0.0

    for r in range(rows):
        g <<= g_ub[r:r + 1, 0:D]
        tmp <<= g - glast
        tmp <<= tmp * LN2
        rscale <<= tmp.exp()
        tmp <<= glast - g
        tmp <<= tmp * LN2
        cscale <<= tmp.exp()

        qr <<= q_ub[r:r + 1, 0:D]
        prod <<= qr * rscale
        q_scaled_ub[r * D] <<= prod[0]
        q_scaled_ub[r * D + 64] <<= prod[1]

        kr <<= k_ub[r:r + 1, 0:D]
        prod <<= kr * rscale
        k_scaled_ub[r * D] <<= prod[0]
        k_scaled_ub[r * D + 64] <<= prod[1]

        prod <<= kr * cscale
        kg_ub[r * D] <<= prod[0]
        kg_ub[r * D + 64] <<= prod[1]

        cols.arange(0)
        daqk <<= dAqk_ub[r:r + 1, 0:L]
        compare(mask_le, cols, Var(r + 1), CompareMode.LT)  # j < r+1  == j <= r
        select(out, daqk, zero, mask=mask_le)
        mqk_ub[r:r + 1, 0:L] <<= out

        dakk <<= dAkk_ub[r:r + 1, 0:L]
        compare(mask_lt, cols, r, CompareMode.LT)           # j < r
        select(base, dakk, zero, mask=mask_lt)
        mbase_ub[r:r + 1, 0:L] <<= base
        beta_r <<= beta_ub[r:r + 1, 0:1].single()
        base <<= base * beta_r
        mbeta_ub[r:r + 1, 0:L] <<= base
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def finalize_pre_kernel(
    q: GMTensor,
    k: GMTensor,
    g_cumsum: GMTensor,
    beta: GMTensor,
    dAqk: GMTensor,
    dAkk: GMTensor,
    q_scaled: GMTensor,
    k_scaled: GMTensor,
    kg: GMTensor,
    m_qk: GMTensor,
    m_base: GMTensor,
    m_beta: GMTensor,
    B: Var,
    HV: Var,
    C: Var,
    H: Var,
    G: Var,
):
    q_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    k_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    g_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    beta_ub = Tensor(DT.bfloat16, [L, SCALAR_PACK_BF16], Position.UB)
    dAqk_ub = Tensor(DT.bfloat16, [L, L], Position.UB)
    dAkk_ub = Tensor(DT.bfloat16, [L, L], Position.UB)

    q_scaled_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    k_scaled_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    kg_ub = Tensor(DT.bfloat16, [L, D], Position.UB)
    mqk_ub = Tensor(DT.bfloat16, [L, L], Position.UB)
    mbase_ub = Tensor(DT.bfloat16, [L, L], Position.UB)
    mbeta_ub = Tensor(DT.bfloat16, [L, L], Position.UB)

    work_count = Var(B * HV * C)
    work_per_core = CeilDiv(work_count, GetCubeNum())
    work_begin = Var(work_per_core * GetCubeIdx())
    work_end = Min(work_begin + work_per_core, work_count)

    with auto_sync():
        for work in range(work_begin, work_end):
            c_idx = Var(work % C)
            bhv = Var(work / C)
            hv_idx = Var(bhv % HV)
            b_idx = Var(bhv / HV)

            # Strided on-device reads from token-major BTHVD primaries/caches; the
            # H->HV gather (h_idx = hv_idx / G) happens here. q/k carry H heads
            # (pitch H*D); g/beta/dAqk/dAkk carry HV (pitch HV*D / HV / HV*L).
            row0 = Var(c_idx * L)
            h_idx = Var(hv_idx / G)
            gm_to_ub_pad(q_ub[0:L, 0:D], q[b_idx, row0:row0 + L, h_idx, 0:D], L, D, (H - 1) * D, 0)
            gm_to_ub_pad(k_ub[0:L, 0:D], k[b_idx, row0:row0 + L, h_idx, 0:D], L, D, (H - 1) * D, 0)
            gm_to_ub_pad(g_ub[0:L, 0:D], g_cumsum[b_idx, row0:row0 + L, hv_idx, 0:D], L, D, (HV - 1) * D, 0)
            gm_to_ub_pad(beta_ub[0:L, 0:1], beta[b_idx, row0:row0 + L, hv_idx], L, 1, HV - 1, 0)
            gm_to_ub_pad(dAqk_ub[0:L, 0:L], dAqk[b_idx, row0:row0 + L, hv_idx, 0:L], L, L, (HV - 1) * L, 0)
            gm_to_ub_pad(dAkk_ub[0:L, 0:L], dAkk[b_idx, row0:row0 + L, hv_idx, 0:L], L, L, (HV - 1) * L, 0)

            finalize_pre_vf(
                q_ub, k_ub, g_ub, beta_ub, dAqk_ub, dAkk_ub,
                q_scaled_ub, k_scaled_ub, kg_ub,
                mqk_ub, mbase_ub, mbeta_ub, Var(L),
            )

            q_scaled[b_idx, hv_idx, c_idx, 0:L, 0:D] <<= q_scaled_ub[0:L, 0:D]
            k_scaled[b_idx, hv_idx, c_idx, 0:L, 0:D] <<= k_scaled_ub[0:L, 0:D]
            kg[b_idx, hv_idx, c_idx, 0:L, 0:D] <<= kg_ub[0:L, 0:D]
            m_qk[b_idx, hv_idx, c_idx, 0:L, 0:L] <<= mqk_ub[0:L, 0:L]
            m_base[b_idx, hv_idx, c_idx, 0:L, 0:L] <<= mbase_ub[0:L, 0:L]
            m_beta[b_idx, hv_idx, c_idx, 0:L, 0:L] <<= mbeta_ub[0:L, 0:L]

    return q_scaled, k_scaled, kg, m_qk, m_base, m_beta


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "kda_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(q, k, beta, g_cumsum, dAqk, dAkk, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    # Strided-BTHVD on-device: q/k [B, T, H, D] (ungathered primaries), g_cumsum
    # [B, T, HV, D], beta [B, T, HV], dAqk/dAkk [B, T, HV, L]; all bf16. The H->HV
    # gather and every layout/dtype move happen inside the kernel -- no host glue.
    bf16 = torch.bfloat16
    B = int(q.shape[0])
    T = int(q.shape[1])
    H = int(q.shape[2])
    HV = int(g_cumsum.shape[2])
    C = T // L
    G = HV // H
    for name, tensor in (("q", q), ("k", k), ("beta", beta), ("g_cumsum", g_cumsum), ("dAqk", dAqk), ("dAkk", dAkk)):
        if tensor.dtype != bf16:
            raise TypeError(f"{name} must be bfloat16, got {tensor.dtype}")

    outs = (
        torch.empty((B, HV, C, L, D), dtype=bf16, device=q.device),  # q_scaled
        torch.empty((B, HV, C, L, D), dtype=bf16, device=q.device),  # k_scaled
        torch.empty((B, HV, C, L, D), dtype=bf16, device=q.device),  # kg
        torch.empty((B, HV, C, L, L), dtype=bf16, device=q.device),  # M_qk
        torch.empty((B, HV, C, L, L), dtype=bf16, device=q.device),  # M_base
        torch.empty((B, HV, C, L, L), dtype=bf16, device=q.device),  # M_beta
    )
    previous_config = getattr(finalize_pre_kernel, "_simulator_config", None)
    trace_path = _trace_path(trace, out_dir, "finalize_pre")
    if simulator:
        finalize_pre_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=bool(trace_path),
        )
    try:
        result = OpExec(
            finalize_pre_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            q, k, g_cumsum, beta, dAqk, dAkk,
            outs[0], outs[1], outs[2], outs[3], outs[4], outs[5],
            B, HV, C, H, G, shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if previous_config is None:
                try:
                    delattr(finalize_pre_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                finalize_pre_kernel._simulator_config = previous_config
    if gen_only:
        return result
    # Raw GM outputs: q_scaled/k_scaled/kg [B, HV, C, L, D], M_qk/M_base/M_beta
    # [B, HV, C, L, L], all bf16. Layout conversion is owned by the driver/story.
    return result[0], result[1], result[2], result[3], result[4], result[5]


if __name__ == "__main__":
    from projects.a5.kda_bwd.refs.common import make_inputs
    from _torch_formula import build_saved_forward, scan_bwd, inverse_bwd as inverse_ref

    tol = 6e-3
    inputs = make_inputs(B=1, H=2, HV=4, T=128, K=128, V=128, chunk_size=L, seed=0)
    caches = build_saved_forward(inputs)
    scan = scan_bwd(inputs, caches)
    local = inverse_ref(inputs, caches, scan)

    # Feed raw BTHVD primaries/caches (no host gather/transpose); the kernel reads
    # them strided and does the H->HV gather on-device. Outputs stay GM-native
    # (intra-stage), so flat_lvd them for the BTHVD reference comparison.
    got = run(
        inputs.q, inputs.k, inputs.beta, caches.g_cumsum,
        scan.dAqk, local.dAkk,
        simulator=True,
    )
    got = tuple(flat_lvd(x) for x in got)

    B, T, H, Kd = inputs.q.shape
    HV = inputs.v.shape[2]
    G = HV // H
    qf = inputs.q.float()[:, :, torch.arange(HV) // G, :]
    kf = inputs.k.float()[:, :, torch.arange(HV) // G, :]
    betaf, gf = inputs.beta.float(), caches.g_cumsum.float()
    dAqkf, dAkkf = scan.dAqk.float(), local.dAkk.float()
    exp2 = torch.exp2
    e_qs = torch.empty(B, T, HV, D); e_ks = torch.empty(B, T, HV, D); e_kg = torch.empty(B, T, HV, D)
    e_mqk = torch.zeros(B, T, HV, L); e_mb = torch.zeros(B, T, HV, L); e_mbe = torch.zeros(B, T, HV, L)
    for b in builtins.range(B):
        for c in builtins.range(T // L):
            s, e = c * L, c * L + L
            for hv in builtins.range(HV):
                gb = gf[b, s:e, hv]; gl = gb[L - 1]
                rs = exp2(gb - gl); cs = exp2(gl - gb)
                e_qs[b, s:e, hv] = qf[b, s:e, hv] * rs
                e_ks[b, s:e, hv] = kf[b, s:e, hv] * rs
                e_kg[b, s:e, hv] = kf[b, s:e, hv] * cs
                e_mqk[b, s:e, hv] = torch.tril(dAqkf[b, s:e, hv])
                base = torch.tril(dAkkf[b, s:e, hv], diagonal=-1)
                e_mb[b, s:e, hv] = base
                e_mbe[b, s:e, hv] = base * betaf[b, s:e, hv][:, None]
    refs = (e_qs, e_ks, e_kg, e_mqk, e_mb, e_mbe)
    names = ("q_scaled", "k_scaled", "kg", "M_qk", "M_base", "M_beta")
    for name, g, r in zip(names, got, refs):
        torch.testing.assert_close(g.float(), r, rtol=tol, atol=tol)
        print(f"{name}: max_abs={(g.float() - r).abs().max().item():.3e} OK")
    print([tuple(item.shape) for item in got])
