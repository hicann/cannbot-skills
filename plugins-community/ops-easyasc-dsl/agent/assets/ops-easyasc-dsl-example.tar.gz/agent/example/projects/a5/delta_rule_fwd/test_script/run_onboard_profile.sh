#!/usr/bin/env bash
# Onboard (Ascend 950 / a5) full-pipeline profile for delta_rule_fwd.
#
# Builds + runs all 5 DSL kernels of the forward pipeline on the NPU --
#   preprocess -> tril_inverse64 -> recompute_wu -> chunk_delta sub1 -> sub2
# -- via `delta_rule_full.py --check-kernels --on-npu`.  That path sets
# profile=True for every leaf (delta_full_chunked_kernels: profile = bool(on_npu)),
# so each kernel's aclnn test prints
#       ---- N_TESTS: <n>   AVG: <us>   FirstRun: <us> ----
# (per-call average over the mid-50 of 100 runs) into its own
# `<...>_kernel_script/r.sh.log`.  After the run this wrapper finds every
# r.sh.log under OUT_DIR and prints a per-kernel AVG summary.
#
# IMPORTANT: a5 onboard uses debug=False / full-project generate(profile=True)
# (the default OpExec path), NOT the a2 debug=True standalone harness; the timing
# token is `N_TESTS/AVG` (us), not a2's `Time cost: <ms>`.
#
# Must run on the Ascend box (NPU + CANN).  On the Mac (no HW) the onboard build
# fails at b.sh.  Validate the driver logic locally first with the simulator:
#       MODE=simulator B=1 H=1 C=2 ./run_onboard_profile.sh
#
# Usage:
#   projects/a5/delta_rule_fwd/test_script/run_onboard_profile.sh
#   B=1 H=32 C=16 SEED=20260609 ./run_onboard_profile.sh
#   PYTHON_CMD="conda run -n torch210npu python" ./run_onboard_profile.sh
#   MODE=simulator ./run_onboard_profile.sh         # local dry run, no NPU
#
# Env knobs (all optional):
#   MODE        onboard (default) | simulator
#   B,H,C       problem shape (default 1 / 32 / 16)
#   SEED        RNG seed (default 20260609)
#   TRIL_IMPL   step-2 (I-A)^-1 kernel: block (default, fp32 diagonal) | neumann
#               (opt-in whole-64 log-squaring, cube-bound, ~1.2-1.3x at >=2 chunks/core)
#   OUT_DIR     run directory (default hw_out/onboard_profile_*_<timestamp>)
#   PYTHON_CMD  python runner override (else torch210npu conda env, else python)
# Extra args after `--` are forwarded to delta_rule_full.py.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

find_repo_root() {
  local dir="${PROJECT_DIR}"
  while [[ "${dir}" != "/" ]]; do
    if [[ -f "${dir}/agent/ROUTER.md" && -f "${dir}/easyasc/a5.py" ]]; then
      printf '%s\n' "${dir}"
      return 0
    fi
    dir="$(dirname "${dir}")"
  done
  return 1
}

REPO_ROOT="$(find_repo_root)"

MODE="${MODE:-onboard}"
SEED="${SEED:-20260609}"
B="${B:-1}"
H="${H:-32}"
C="${C:-16}"
TRIL_IMPL="${TRIL_IMPL:-block}"

case "${TRIL_IMPL}" in
  block|neumann) ;;
  *) echo "Unknown TRIL_IMPL=${TRIL_IMPL}. Use block or neumann." >&2; exit 2 ;;
esac
OUT_DIR="${OUT_DIR:-${PROJECT_DIR}/hw_out/onboard_profile_b${B}h${H}c${C}_$(date +%Y%m%d_%H%M%S)}"

if [[ -n "${PYTHON_CMD:-}" ]]; then
  read -r -a PYTHON_RUNNER <<< "${PYTHON_CMD}"
elif command -v conda >/dev/null 2>&1 && conda env list | grep -qE '^torch210npu[[:space:]]'; then
  PYTHON_RUNNER=(conda run -n torch210npu python)
else
  PYTHON_RUNNER=(python)
fi

case "${MODE}" in
  onboard|simulator) ;;
  *) echo "Unknown MODE=${MODE}. Use onboard or simulator." >&2; exit 2 ;;
esac

mkdir -p "${OUT_DIR}"
OUT_DIR="$(cd "${OUT_DIR}" && pwd)"
export PYTHONPATH="${REPO_ROOT}${PYTHONPATH:+:${PYTHONPATH}}"

# OpExec defaults custom_op_path to the current working directory for onboard
# runs; keep generated custom-op packages under this run directory.
cd "${OUT_DIR}"

echo "delta_rule_fwd full ${MODE} profile"
echo "  seed=${SEED} shape=(B=${B},H=${H},C=${C})"
echo "  tril_impl=${TRIL_IMPL}"
echo "  repo_root=${REPO_ROOT}"
echo "  out_dir=${OUT_DIR}"
echo "  workdir=$(pwd)"
echo "  python=${PYTHON_RUNNER[*]}"

# Build args without ever expanding a possibly-empty array under `set -u`
# (macOS bash 3.2 treats an empty `arr[@]` as unset).
python_args=(
  --check-kernels
  --seed "${SEED}"
  --B "${B}"
  --H "${H}"
  --C "${C}"
  --tril-impl "${TRIL_IMPL}"
  --out-dir "${OUT_DIR}/kernels"
)
if [[ "${MODE}" == "onboard" ]]; then
  python_args+=(--on-npu)
fi
if (( $# )); then
  python_args+=("$@")  # forward any extra args to delta_rule_full.py
fi

echo "=== delta_rule_full.py --check-kernels (MODE=${MODE}) ==="
"${PYTHON_RUNNER[@]}" "${PROJECT_DIR}/delta_rule_full.py" "${python_args[@]}"

# --- per-kernel AVG timing summary -------------------------------------------
echo
echo "=== onboard AVG timing per kernel (grep N_TESTS/AVG in r.sh.log) ==="
found=0
while IFS= read -r -d '' log; do
  line="$(grep -aE 'N_TESTS|AVG' "${log}" | tail -1 || true)"
  if [[ -n "${line}" ]]; then
    label="$(basename "$(dirname "${log}")")"
    label="${label%_kernel_script}"
    printf '  %-30s %s\n' "${label}" "${line}"
    found=1
  fi
done < <(find "${OUT_DIR}" -name 'r.sh.log' -print0 2>/dev/null)

if [[ "${found}" -eq 0 ]]; then
  echo "  (no N_TESTS/AVG lines under ${OUT_DIR})"
  if [[ "${MODE}" != "onboard" ]]; then
    echo "  MODE=${MODE} does not build/run on the NPU, so this is expected."
    echo "  Run on the Ascend box with MODE=onboard for real timings."
  else
    echo "  Onboard run did not reach r.sh -- check the build log (b.sh.log) under OUT_DIR."
  fi
fi
