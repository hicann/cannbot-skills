"""Canonical gdn_bwd correctness check.

Two modes controlled by --mode (or MODE env var):

  simulator  (default)  Run sub-kernels through compose inside the simulator,
                        compare outputs against the PyTorch oracle.

  onboard              Run sub-kernels on the real device (no simulator).
                       Two passes:
                         1. Init: generate code only for all sub-kernels.
                         2. Run: compile split scan, then reuse downstream .o files.

  --out-dir=DIR        Output directory for generated code / build artifacts
                       (also settable via OUT_DIR env var).
"""

import os
import sys
from pathlib import Path

import torch

PLAN_DIR = Path(__file__).resolve().parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"
L = 64
D = 128
ATOL = 5e-4
RTOL = 5e-4

for _path in (str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from kernel_compose import run as kernel_run  # noqa: E402
from oracle import oracle  # noqa: E402


def _strict_lower(device):
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device), diagonal=-1)


def _lower_eq(device):
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device))


def _bf16_cube_operand(x):
    return x.to(torch.bfloat16).float()


def _bf16_cube_mm(lhs, rhs):
    return _bf16_cube_operand(lhs) @ _bf16_cube_operand(rhs)


def _state_history_forward(key, g_cumsum, value_wu, k_cumdecay):
    B, H, C, _, _ = key.shape
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=key.device)
    states = []
    v_news = []
    k_weighteds = []
    exp_deltas = []
    for c in range(C):
        k_i = key[:, :, c].float()
        g_i = g_cumsum[:, :, c].float()
        v_new = (value_wu[:, :, c].float() - _bf16_cube_mm(k_cumdecay[:, :, c], state)).to(torch.bfloat16)
        v_news.append(v_new)
        exp_g_last = g_i[:, :, -1].exp()
        exp_delta = (g_i[:, :, -1].unsqueeze(-1) - g_i).exp()
        exp_deltas.append(exp_delta)
        k_weighted_bf16 = (k_i * exp_delta.unsqueeze(-1)).to(torch.bfloat16)
        k_weighteds.append(k_weighted_bf16)
        k_weighted = k_weighted_bf16.float()
        state = (state.float() * exp_g_last[:, :, None, None] + _bf16_cube_mm(k_weighted.transpose(-1, -2), v_new)).to(torch.bfloat16)
        states.append(state)
    return (
        torch.stack(states, dim=2),
        torch.stack(v_news, dim=2),
        torch.stack(k_weighteds, dim=2),
        torch.stack(exp_deltas, dim=2),
    )


def make_inputs():
    torch.manual_seed(20260519)
    B, H, C = 1, 2, 2
    scale = 0.05
    query = (torch.randn(B, H, C, L, D, dtype=torch.float32) * scale).to(torch.bfloat16)
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32) * scale).to(torch.bfloat16)
    value = (torch.randn(B, H, C, L, D, dtype=torch.float32) * scale).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    g = torch.log(torch.sigmoid(torch.randn(B, H, C, L, dtype=torch.float32)))
    grad_output = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.1).to(torch.bfloat16)
    grad_final_state = torch.randn(B, H, D, D, dtype=torch.float32) * 0.1

    g_cumsum = g.cumsum(dim=-1)
    decay_mask = (g_cumsum.unsqueeze(-1) - g_cumsum.unsqueeze(-2)).exp() * _lower_eq(query.device)
    k = key.float()
    v = value.float()
    k_beta = k * beta.unsqueeze(-1)
    preprocess_attn = -(_bf16_cube_mm(k_beta, k.transpose(-1, -2)) * decay_mask * _strict_lower(query.device))
    wu_attn_fp32 = torch.linalg.inv(torch.eye(L, dtype=torch.float32, device=query.device) - preprocess_attn)
    wu_attn_bf16 = wu_attn_fp32.to(torch.bfloat16)
    v_beta = (v * beta.unsqueeze(-1)).to(torch.bfloat16).float()
    k_beta_g = (k_beta * g_cumsum.exp().unsqueeze(-1)).to(torch.bfloat16).float()
    value_wu = _bf16_cube_mm(wu_attn_bf16, v_beta).to(torch.bfloat16)
    k_cumdecay = _bf16_cube_mm(wu_attn_bf16, k_beta_g).to(torch.bfloat16)
    state_after_history, v_new_history, k_weighted_history, exp_delta_history = _state_history_forward(key, g_cumsum, value_wu, k_cumdecay)

    return (
        query, key, value, beta, g, grad_output,
        g_cumsum, decay_mask, wu_attn_bf16, value_wu, k_cumdecay,
        state_after_history, v_new_history, k_weighted_history, grad_final_state,
        exp_delta_history,
    )


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    return (value,)


def _clone_args(args):
    return tuple(arg.clone() if torch.is_tensor(arg) else arg for arg in args)


def _check_output(idx, got, ref):
    if tuple(got.shape) != tuple(ref.shape):
        raise RuntimeError(f"gdn_bwd: output {idx} shape mismatch {tuple(got.shape)} != {tuple(ref.shape)}")
    got_f = got.float()
    ref_f = ref.float()
    if not torch.isfinite(got_f).all() or not torch.isfinite(ref_f).all():
        raise RuntimeError(f"gdn_bwd: output {idx} has non-finite values")
    diff = (got_f - ref_f).abs()
    max_abs = float(diff.max())
    max_rel = float((diff / ref_f.abs().clamp_min(1e-12)).max())
    ok = bool(torch.allclose(got_f, ref_f, atol=ATOL, rtol=RTOL))
    print(
        f"gdn_bwd output{idx}: shape={tuple(got.shape)} dtype={got.dtype} "
        f"max_abs={max_abs:.3e} max_rel={max_rel:.3e} "
        f"tol=({ATOL:.3e}, {RTOL:.3e}) {'OK' if ok else 'FAIL'}"
    )
    return ok


def run_simulator(out_dir=""):
    args = make_inputs()
    expected = _as_tuple(oracle(*args))
    actual = _as_tuple(kernel_run(*_clone_args(args), simulator=True, out_dir=out_dir))
    if len(actual) != len(expected):
        raise RuntimeError(f"gdn_bwd: output count mismatch {len(actual)} != {len(expected)}")
    all_ok = True
    for idx, (got, ref) in enumerate(zip(actual, expected)):
        all_ok = _check_output(idx, got, ref) and all_ok
    if not all_ok:
        return 1
    print("gdn_bwd simulator-vs-ref OK")
    return 0


def run_onboard(out_dir):
    from finalize_bwd import run as run_finalize_bwd  # noqa: E402
    from inverse_preprocess_bwd import run as run_inverse_preprocess_bwd  # noqa: E402
    from scan_split_bwd import run as run_scan_bwd  # noqa: E402
    from wu_bwd import run as run_wu_bwd  # noqa: E402

    args = make_inputs()
    (
        query, key, value, beta, _g, grad_output, g_cumsum, decay_mask,
        wu_attn_bf16, value_wu, k_cumdecay, state_after_history,
        v_new_history, k_weighted_history, grad_final_state,
        exp_delta_history,
    ) = args

    print("=== onboard init: generating code for all sub-kernels ===")
    scan_dummy = run_scan_bwd(query, key, grad_output, g_cumsum, decay_mask, k_cumdecay, state_after_history, v_new_history, k_weighted_history, grad_final_state, exp_delta_history, simulator=False, gen_only=True, skip_compile=False, out_dir=out_dir)
    wu_dummy = run_wu_bwd(key, value, beta, g_cumsum, wu_attn_bf16, scan_dummy[4], scan_dummy[5], simulator=False, gen_only=True, skip_compile=False, out_dir=out_dir)
    inv_dummy = run_inverse_preprocess_bwd(key, beta, decay_mask, wu_attn_bf16, wu_dummy[0], simulator=False, gen_only=True, skip_compile=False, out_dir=out_dir)
    run_finalize_bwd(key, value, beta, scan_dummy[1], scan_dummy[2], scan_dummy[6], wu_dummy[1], wu_dummy[2], wu_dummy[3], inv_dummy[0], inv_dummy[1], inv_dummy[3], simulator=False, gen_only=True, skip_compile=False, out_dir=out_dir)

    print("=== onboard run: split scan compile+run, downstream reuse .o ===")
    scan = run_scan_bwd(query, key, grad_output, g_cumsum, decay_mask, k_cumdecay, state_after_history, v_new_history, k_weighted_history, grad_final_state, exp_delta_history, simulator=False, gen_only=False, skip_compile=False, out_dir=out_dir)
    wu = run_wu_bwd(key, value, beta, g_cumsum, wu_attn_bf16, scan[4], scan[5], simulator=False, gen_only=False, skip_compile=True, out_dir=out_dir)
    inv = run_inverse_preprocess_bwd(key, beta, decay_mask, wu_attn_bf16, wu[0], simulator=False, gen_only=False, skip_compile=True, out_dir=out_dir)
    final_tail = _as_tuple(run_finalize_bwd(key, value, beta, scan[1], scan[2], scan[6], wu[1], wu[2], wu[3], inv[0], inv[1], inv[3], simulator=False, gen_only=False, skip_compile=True, out_dir=out_dir))
    actual = (scan[0],) + final_tail
    expected = _as_tuple(oracle(*args))
    all_ok = True
    for idx, (got, ref) in enumerate(zip(actual, expected)):
        all_ok = _check_output(idx, got, ref) and all_ok
    if not all_ok:
        return 1
    print("gdn_bwd onboard-vs-ref OK")
    return 0


def main():
    mode = os.environ.get("MODE", "simulator")
    out_dir = os.environ.get("OUT_DIR", "")
    for arg in sys.argv[1:]:
        if arg.startswith("--mode="):
            mode = arg.split("=", 1)[1]
        elif arg.startswith("--out-dir="):
            out_dir = arg.split("=", 1)[1]
    mode = mode.strip().lower()
    if mode == "simulator":
        return run_simulator(out_dir)
    if mode == "onboard":
        return run_onboard(out_dir)
    print(f"Unknown mode: {mode}. Use 'simulator' or 'onboard'.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
