# Delta Rule Forward (a5)

Chunked **(ungated) delta-rule** forward, i.e. the FLA
[`chunk_delta_rule`](https://github.com/fla-org/flash-linear-attention/blob/main/fla/ops/delta_rule/chunk.py)
forward, wired into runnable EasyASC DSL kernels on a5. It reuses GDN's 4-step
decomposition and the same chunked `[B, H, C, 64, 128]` layout as
`projects/a5/gdn_fwd/`, so the two are directly comparable.

## Relationship to GDN

The delta rule **is the GDN (gated delta net) forward with the per-token gate
`g` removed**. Starting from `gdn_fwd` and deleting every `g` term yields this
project. Dropping `g` removes, in order:

| GDN term | What it is | Delta rule |
|----------|------------|------------|
| `g_cumsum = g.cumsum(-1)` | per-token cumulative gate | gone (no `g`/`triu` input) |
| `decay_mask = exp(g_cumsum_i - g_cumsum_j)` (lower tri) | intra-chunk score decay | → `tril(ones)` (constant causal keep) |
| `k_cumdecay = (I-A)^-1 @ (k_beta * exp(g_cumsum))` | gated WY key term | `w = (I-A)^-1 @ k_beta` |
| `attn_inter = (q * exp(g_cumsum)) @ S` | gated inter-chunk read | `q @ S` |
| `S = S*exp(g_last) + (k*exp(g_last-g_cumsum))^T @ v_new` | gated state recurrence | `S = S + k^T @ v_new` |

Everything else — `v_beta`/`k_beta`, the strict-lower `A = -(k_beta @ k^T)`, the
`(I-A)^-1` substitution, `u`, and `o = attn_inter + (q@k^T ⊙ causal) @ v_new` —
is unchanged. Verified bit-for-bit against GDN at `g == 0`:

```bash
python projects/a5/delta_rule_fwd/delta_rule_full.py --check-gated --B 1 --H 4 --C 4
```

## Layout

- `delta_rule_full.py` — full runner and reference harness. Holds the fp32
  ground-truth (`delta_rule_full_original_chunked`), the kernel-aligned 4-step
  PyTorch path (`delta_full_chunked`), and the DSL kernel path
  (`delta_full_chunked_kernels`). Check flags: `--check-gated` (delta == GDN at
  g=0), `--check-rewritten` (4-step == fp32 truth), `--check-kernels` (DSL ==
  4-step path).
- `kernels/delta_preprocess.py` — step 1: bf16 `key @ key.T`, fp32 beta, strict
  lower mask → strict-lower `A`. (GDN's preprocess minus `g_cumsum`/`decay_mask`.)
- `kernels/tril_inverse64.py` — step 2: **reused verbatim from gdn_fwd**
  (gate-independent `(I - A)^-1`); thin re-export.
- `kernels/delta_recompute_wu.py` — step 3: `value_wu = attn @ (value*beta)`,
  `k_cumdecay = attn @ (key*beta)`. (GDN's recompute-WU minus `exp(g_cumsum)`.)
- `kernels/chunk_delta_sub1.py` — step 4a: `attn = (q @ k^T) ⊙ causal_keep`.
- `kernels/chunk_delta_sub2.py` — step 4b: fused recurrence (v_new, output,
  state) over the internal C loop, ungated.
- `kernels/chunk_delta_compose.py` — step 4 driver: sub1 → fused sub2.
- `refs/` — PyTorch oracle and per-sub-kernel reference checks for step 4.
- `test_script/` — simulator/onboard correctness checks.
- `optimization_timeline.md` — project-local optimization rationale for the
  current implementation.

## Running

All scripts assume the repo root is on `PYTHONPATH`. From the repo root:

```bash
PYTHONPATH=. python projects/a5/delta_rule_fwd/kernels/delta_preprocess.py
PYTHONPATH=. python projects/a5/delta_rule_fwd/kernels/delta_recompute_wu.py
PYTHONPATH=. python projects/a5/delta_rule_fwd/kernels/chunk_delta_sub1.py
PYTHONPATH=. python projects/a5/delta_rule_fwd/kernels/chunk_delta_sub2.py
PYTHONPATH=. python projects/a5/delta_rule_fwd/kernels/chunk_delta_compose.py
PYTHONPATH=. python projects/a5/delta_rule_fwd/test_script/check_chunk_delta_vs_ref.py --B=1 --H=64 --C=3
PYTHONPATH=. python projects/a5/delta_rule_fwd/test_script/check_full_vs_ref.py --B=1 --H=2 --C=4
PYTHONPATH=. python projects/a5/delta_rule_fwd/delta_rule_full.py --check-kernels --B 1 --H 1 --C 2
# pure-PyTorch refs (no PYTHONPATH needed):
python projects/a5/delta_rule_fwd/refs/sub1_check.py
python projects/a5/delta_rule_fwd/refs/sub2_check.py
python projects/a5/delta_rule_fwd/refs/compose.py
```

## Stage Relationships

```text
delta_preprocess      -> preprocess_attn (strict-lower A)
        |
        v
tril_inverse64        -> wu_attn_bf16  (reused from gdn_fwd)
        |
        v
delta_recompute_wu    -> value_wu, k_cumdecay
        |
        v
chunk_delta_compose   -> core_attn_out, final_state   (sub1 -> fused sub2)
```

## Validation status (simulator)

All stages pass against their PyTorch references at `max_abs = 0`:

| stage | check | result |
|-------|-------|--------|
| preprocess | `kernels/delta_preprocess.py` | max_abs 0 |
| recompute_wu | `kernels/delta_recompute_wu.py` | max_abs 0 |
| sub1 | `kernels/chunk_delta_sub1.py` | max_abs 0 |
| sub2 | `kernels/chunk_delta_sub2.py` | core/state max_abs 0 |
| compose | `test_script/check_chunk_delta_vs_ref.py` (H=64, C=3) | max_abs 0 |
| full 4-step | `delta_rule_full.py --check-kernels` | max_abs 0 vs ref; within 2e-3 vs fp32 truth |

## Notes

- `scale`: FLA's `chunk_delta_rule` defaults the query scale to `head_dim**-0.5`.
  This project defaults `scale=1.0` to match the GDN reference path; pass
  `scale=` / `--scale` for the FLA default.
- Precision path mirrors GDN: bf16 q/k/v inputs, the intra-chunk `q@k^T` runs as
  a bf16 matmul, everything else accumulates in fp32; `core_attn_out` is bf16,
  the recurrent state stays fp32 in the ground truth (bf16 at the kernel boundary).
- The state-history forward (for a future delta backward) is sketched in
  `refs/oracle.py::oracle_full_state_history` (returns `state_after_history` and
  `v_new_history`; GDN's `k_weighted_history`/`exp_delta_history` degenerate to
  the raw key / all-ones and are dropped). A DSL state-history kernel is not
  authored yet.
```
