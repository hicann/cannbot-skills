"""PyTorch golden for full chunked GDN backward.

Backward inputs are the original forward inputs, upstream `grad_output`, and
the compact public forward tensors:
`g_cumsum`, `decay_mask`, `wu_attn_bf16`, `value_wu`, `k_cumdecay`,
`state_after_history`.

For the inverse block, `W = inverse(I - A)` gives `dA = W.T @ dW @ W.T`.
The saved forward `W` input is the bf16 kernel handoff tensor; this golden
promotes it back to fp32 internally for the backward math.
"""

from typing import Optional, Tuple

import torch


L = 64
D = 128

GDN_BWD_FORWARD_TENSOR_NAMES = (
    "g_cumsum", "decay_mask", "wu_attn_bf16", "value_wu", "k_cumdecay", "state_after_history",
)
GDN_BWD_REQUIRED_INPUT_NAMES = (
    "query", "key", "value", "beta", "g", "grad_output",
) + GDN_BWD_FORWARD_TENSOR_NAMES
GDN_BWD_OPTIONAL_INPUT_NAMES = ("grad_final_state", "initial_state")
GDN_BWD_OUTPUT_NAMES = ("d_query", "d_key", "d_value", "d_beta", "d_g")
GDN_BWD_OUTPUT_NAMES_WITH_INITIAL_STATE = GDN_BWD_OUTPUT_NAMES + ("d_initial_state",)


def _check(query, key, value, beta, g, initial_state=None) -> Tuple[int, int, int]:
    if query.ndim != 5:
        raise ValueError(f"query must be [B,H,C,{L},{D}], got {tuple(query.shape)}")
    B, H, C, chunk, dim = (int(x) for x in query.shape)
    if (chunk, dim) != (L, D):
        raise ValueError(f"this path is specialized for L={L}, D={D}; got L={chunk}, D={dim}")
    if tuple(key.shape) != tuple(query.shape) or tuple(value.shape) != tuple(query.shape):
        raise ValueError("query/key/value must have identical [B,H,C,L,D] shapes")
    if tuple(beta.shape) != (B, H, C, L) or tuple(g.shape) != (B, H, C, L):
        raise ValueError("beta/g must be [B,H,C,L]")
    if initial_state is not None and tuple(initial_state.shape) != (B, H, D, D):
        raise ValueError(f"initial_state must be [B,H,{D},{D}], got {tuple(initial_state.shape)}")
    return B, H, C


def _f(x: torch.Tensor) -> torch.Tensor:
    return x if x.dtype == torch.float32 else x.float()


def _strict_lower(device) -> torch.Tensor:
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device), diagonal=-1)


def _lower_eq(device) -> torch.Tensor:
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device))


def _reverse_cumsum(x: torch.Tensor) -> torch.Tensor:
    return torch.flip(torch.cumsum(torch.flip(x, dims=(-1,)), dim=-1), dims=(-1,))


def compute_gdn_bwd_forward_tensors(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return the forward tensors consumed by `gdn_bwd_full`."""
    _check(query, key, value, beta, g)
    k, v, beta_f = _f(key), _f(value), beta.float()
    g_cumsum = g.float().cumsum(dim=-1)
    decay_mask = (g_cumsum.unsqueeze(-1) - g_cumsum.unsqueeze(-2)).exp() * _lower_eq(query.device)
    k_beta = k * beta_f.unsqueeze(-1)
    preprocess_attn = -((k_beta @ k.transpose(-1, -2)) * decay_mask * _strict_lower(query.device))
    wu_attn_fp32 = torch.linalg.inv(torch.eye(L, dtype=torch.float32, device=query.device) - preprocess_attn)
    wu_attn_bf16 = wu_attn_fp32.to(torch.bfloat16)
    wu_attn = wu_attn_bf16.float()
    value_wu = wu_attn @ (v * beta_f.unsqueeze(-1))
    k_cumdecay = wu_attn @ (k_beta * g_cumsum.exp().unsqueeze(-1))
    _, state_after_history = _state_after_history(k, g_cumsum, value_wu, k_cumdecay, None)
    return g_cumsum, decay_mask, wu_attn_bf16, value_wu, k_cumdecay, state_after_history


def _check_forward_tensors(query, key, value, beta, g, tensors):
    B, H, C = _check(query, key, value, beta, g)
    shapes = (
        (B, H, C, L), (B, H, C, L, L), (B, H, C, L, L),
        (B, H, C, L, D), (B, H, C, L, D), (B, H, C, D, D),
    )
    for name, tensor, shape in zip(GDN_BWD_FORWARD_TENSOR_NAMES, tensors, shapes):
        if tuple(tensor.shape) != shape:
            raise ValueError(f"{name} shape must be {shape}, got {tuple(tensor.shape)}")
        if name == "wu_attn_bf16" and tensor.dtype != torch.bfloat16:
            raise TypeError(f"{name} dtype must be torch.bfloat16, got {tensor.dtype}")
    return tuple(t.float() for t in tensors)


def _state_after_history(k, g_cumsum, value_wu, k_cumdecay, initial_state):
    B, H, C, _, _ = k.shape
    state = torch.zeros(B, H, D, D, dtype=torch.float32, device=k.device) if initial_state is None else initial_state.float()
    states = []

    for c in range(C):
        k_i, g_i = k[:, :, c], g_cumsum[:, :, c]
        v_new = value_wu[:, :, c] - k_cumdecay[:, :, c] @ state
        exp_g_last = g_i[:, :, -1].exp()
        exp_delta = (g_i[:, :, -1].unsqueeze(-1) - g_i).exp()
        k_weighted = k_i * exp_delta.unsqueeze(-1)
        state = state * exp_g_last[:, :, None, None] + k_weighted.transpose(-1, -2) @ v_new
        states.append(state)

    return state, torch.stack(states, dim=2)


def _forward_ref(query, key, value, beta, g, initial_state=None):
    mids = compute_gdn_bwd_forward_tensors(query, key, value, beta, g)
    q, k = _f(query), _f(key)
    final_state, state_after_history = _state_after_history(k, mids[0], mids[3], mids[4], initial_state)
    outputs = []
    for c in range(q.shape[2]):
        if c == 0:
            state = torch.zeros_like(final_state) if initial_state is None else initial_state.float()
        else:
            state = state_after_history[:, :, c - 1]
        q_i, k_i, g_i = q[:, :, c], k[:, :, c], mids[0][:, :, c]
        score_qk = q_i @ k_i.transpose(-1, -2)
        attn = score_qk * mids[1][:, :, c]
        v_new = mids[3][:, :, c] - mids[4][:, :, c] @ state
        outputs.append((q_i * g_i.exp().unsqueeze(-1)) @ state + attn @ v_new)
    output = torch.stack(outputs, dim=2)
    return output, final_state, mids[:-1] + (state_after_history,)


def gdn_bwd_full(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    grad_output: torch.Tensor,
    g_cumsum: torch.Tensor,
    decay_mask: torch.Tensor,
    wu_attn_bf16: torch.Tensor,
    value_wu: torch.Tensor,
    k_cumdecay: torch.Tensor,
    state_after_history: torch.Tensor,
    grad_final_state: Optional[torch.Tensor] = None,
    initial_state: Optional[torch.Tensor] = None,
    include_initial_state_grad: bool = False,
) -> Tuple[torch.Tensor, ...]:
    """Return `(d_query, d_key, d_value, d_beta, d_g)` for chunked GDN."""
    B, H, C = _check(query, key, value, beta, g, initial_state)
    if tuple(grad_output.shape) != (B, H, C, L, D):
        raise ValueError(f"grad_output must be {(B, H, C, L, D)}, got {tuple(grad_output.shape)}")

    g_cumsum, decay_mask, wu_attn, value_wu, k_cumdecay, state_after_history = _check_forward_tensors(
        query, key, value, beta, g, (g_cumsum, decay_mask, wu_attn_bf16, value_wu, k_cumdecay, state_after_history)
    )
    q, k, v, beta_f = _f(query), _f(key), _f(value), beta.float()
    exp_g_cumsum = g_cumsum.exp()
    k_beta = k * beta_f.unsqueeze(-1)
    v_beta = v * beta_f.unsqueeze(-1)
    k_beta_g = k_beta * exp_g_cumsum.unsqueeze(-1)
    preprocess_score = k_beta @ k.transpose(-1, -2)

    final_state = state_after_history[:, :, C - 1]
    d_state = torch.zeros_like(final_state) if grad_final_state is None else grad_final_state.float()
    d_core = grad_output.float()
    d_q, d_k, d_v = torch.zeros_like(q), torch.zeros_like(k), torch.zeros_like(v)
    d_beta, d_g_cumsum = torch.zeros_like(beta_f), torch.zeros_like(g_cumsum)
    d_decay_mask, d_value_wu, d_k_cumdecay = torch.zeros_like(decay_mask), torch.zeros_like(value_wu), torch.zeros_like(k_cumdecay)

    for c in range(C - 1, -1, -1):
        state = (
            torch.zeros_like(final_state) if c == 0 and initial_state is None
            else initial_state.float() if c == 0
            else state_after_history[:, :, c - 1]
        )
        q_i, k_i, d_out = q[:, :, c], k[:, :, c], d_core[:, :, c]
        g_i = g_cumsum[:, :, c]
        score_qk = q_i @ k_i.transpose(-1, -2)
        attn = score_qk * decay_mask[:, :, c]
        v_new = value_wu[:, :, c] - k_cumdecay[:, :, c] @ state
        exp_g_i = g_i.exp()
        q_exp = q_i * exp_g_i.unsqueeze(-1)
        exp_g_last = g_i[:, :, -1].exp()
        exp_delta = (g_i[:, :, -1].unsqueeze(-1) - g_i).exp()
        k_weighted = k_i * exp_delta.unsqueeze(-1)

        d_q_exp = d_out @ state.transpose(-1, -2)
        d_state_in = q_exp.transpose(-1, -2) @ d_out + d_state * exp_g_last[:, :, None, None]
        d_attn = d_out @ v_new.transpose(-1, -2)
        d_v_new = attn.transpose(-1, -2) @ d_out
        d_exp_g_last = (d_state * state).sum(dim=(-1, -2))
        d_k_weighted = v_new @ d_state.transpose(-1, -2)
        d_v_new = d_v_new + k_weighted @ d_state

        d_value_wu[:, :, c] = d_value_wu[:, :, c] + d_v_new
        d_v_prime = -d_v_new
        d_k_cumdecay[:, :, c] = d_k_cumdecay[:, :, c] + d_v_prime @ state.transpose(-1, -2)
        d_state_in = d_state_in + k_cumdecay[:, :, c].transpose(-1, -2) @ d_v_prime

        d_score_qk = d_attn * decay_mask[:, :, c]
        d_decay_mask[:, :, c] = d_decay_mask[:, :, c] + d_attn * score_qk
        d_q[:, :, c] = d_q[:, :, c] + d_score_qk @ k_i + d_q_exp * exp_g_i.unsqueeze(-1)
        d_k[:, :, c] = d_k[:, :, c] + d_score_qk.transpose(-1, -2) @ q_i
        d_g_cumsum[:, :, c] = d_g_cumsum[:, :, c] + (d_q_exp * q_i).sum(dim=-1) * exp_g_i

        d_k[:, :, c] = d_k[:, :, c] + d_k_weighted * exp_delta.unsqueeze(-1)
        d_delta = (d_k_weighted * k_i).sum(dim=-1) * exp_delta
        d_g_cumsum[:, :, c] = d_g_cumsum[:, :, c] - d_delta
        d_g_cumsum[:, :, c, -1] = d_g_cumsum[:, :, c, -1] + d_exp_g_last * exp_g_last + d_delta.sum(dim=-1)
        d_state = d_state_in

    d_wu = d_value_wu @ v_beta.transpose(-1, -2) + d_k_cumdecay @ k_beta_g.transpose(-1, -2)
    d_v_beta = wu_attn.transpose(-1, -2) @ d_value_wu
    d_k_beta_g = wu_attn.transpose(-1, -2) @ d_k_cumdecay
    d_k_beta = d_k_beta_g * exp_g_cumsum.unsqueeze(-1)
    d_g_cumsum = d_g_cumsum + (d_k_beta_g * k_beta).sum(dim=-1) * exp_g_cumsum

    d_attn_pre = wu_attn.transpose(-1, -2) @ d_wu @ wu_attn.transpose(-1, -2)
    d_score_pre = -d_attn_pre * decay_mask * _strict_lower(query.device)
    d_decay_mask = d_decay_mask - d_attn_pre * preprocess_score * _strict_lower(query.device)
    d_k_beta = d_k_beta + d_score_pre @ k
    d_k = d_k + d_score_pre.transpose(-1, -2) @ k_beta

    d_g_cumsum = d_g_cumsum + (d_decay_mask * decay_mask).sum(dim=-1) - (d_decay_mask * decay_mask).sum(dim=-2)
    d_v = d_v + d_v_beta * beta_f.unsqueeze(-1)
    d_beta = d_beta + (d_v_beta * v).sum(dim=-1)
    d_k = d_k + d_k_beta * beta_f.unsqueeze(-1)
    d_beta = d_beta + (d_k_beta * k).sum(dim=-1)

    outputs = (d_q, d_k, d_v, d_beta, _reverse_cumsum(d_g_cumsum))
    if include_initial_state_grad:
        if initial_state is None:
            raise ValueError("include_initial_state_grad=True requires initial_state")
        outputs = outputs + (d_state,)
    return outputs


golden = gdn_bwd_full


def _make_inputs(B=1, H=1, C=2, scale=0.05):
    query = torch.randn(B, H, C, L, D, dtype=torch.float32) * scale
    key = torch.randn(B, H, C, L, D, dtype=torch.float32) * scale
    value = torch.randn(B, H, C, L, D, dtype=torch.float32) * scale
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    g = torch.log(torch.sigmoid(torch.randn(B, H, C, L, dtype=torch.float32)))
    return query, key, value, beta, g


def _check_close(name, got, ref):
    diff = (got.float() - ref.float()).abs()
    ok = torch.allclose(got.float(), ref.float(), atol=5e-5, rtol=5e-5)
    print(f"{name}: max_abs={float(diff.max()):.3e} {'OK' if ok else 'DIFF'}")
    if not ok:
        raise AssertionError(name)


def _self_check(include_initial_state=True, seed=1):
    torch.manual_seed(seed)
    base = _make_inputs()
    inputs = [x.detach().clone().requires_grad_(True) for x in base]
    initial_state = (torch.randn(1, 1, D, D) * 0.02).requires_grad_(True) if include_initial_state else None
    output, final_state, mids = _forward_ref(*inputs, initial_state=initial_state)
    grad_output = torch.randn_like(output) * 0.1
    grad_final_state = torch.randn_like(final_state) * 0.1
    ((output * grad_output).sum() + (final_state * grad_final_state).sum()).backward()

    manual = gdn_bwd_full(
        *base, grad_output, *(x.detach() for x in mids),
        grad_final_state=grad_final_state,
        initial_state=initial_state.detach() if initial_state is not None else None,
        include_initial_state_grad=include_initial_state,
    )
    refs = [x.grad for x in inputs] + ([initial_state.grad] if include_initial_state else [])
    for name, got, ref in zip(GDN_BWD_OUTPUT_NAMES_WITH_INITIAL_STATE, manual, refs):
        _check_close(name, got, ref)


if __name__ == "__main__":
    _self_check(include_initial_state=True, seed=1)
    _self_check(include_initial_state=False, seed=3)
