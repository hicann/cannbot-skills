#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLAN_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

find_repo_root() {
  local dir="${PLAN_DIR}"
  while [[ "${dir}" != "/" ]]; do
    if [[ -f "${dir}/agent/ROUTER.md" && -f "${dir}/easyasc/a5.py" ]]; then
      printf '%s\n' "${dir}"
      return 0
    fi
    dir="$(dirname "${dir}")"
  done
  return 1
}

REPO_ROOT="$(find_repo_root)"

# Drives test_script/module_vs_ref.py on the Ascend box. Defaults match the KDA
# hardware-profile shape B=1, H=HV=32, C=16 (L=64, K=V=128 are the kernels'
# fixed specialization). Extra args after the env knobs are forwarded to
# module_vs_ref.py (e.g. --K, --V, --chunk-size, --atol).
#
# Usage:
#   projects/a5/kda_fwd/test_script/run_onboard_profile.sh
#   MODULE=leaf UPSTREAM=kernel projects/a5/kda_fwd/test_script/run_onboard_profile.sh
#   B=1 H=2 HV=2 C=2 MODULE=compose projects/a5/kda_fwd/test_script/run_onboard_profile.sh
#   PYTHON_CMD="conda run -n torch210npu python" projects/a5/kda_fwd/test_script/run_onboard_profile.sh
#
# Env knobs (all optional):
#   MODULE      module / alias for module_vs_ref.py (default compose; leaf/stage/all)
#   UPSTREAM    ref (isolate each kernel) | kernel (cascade) (default ref)
#   SEED        comma-separated torch seeds (default 2026)
#   B,H,HV,C    problem shape (default 1 / 32 / 32 / 16)
#   OUT_DIR     run directory (default hw_out/onboard_profile_*_<timestamp>)
#   PYTHON_CMD  python runner override (else torch210npu conda env, else python)
MODULE="${MODULE:-compose}"
UPSTREAM="${UPSTREAM:-ref}"
SEED="${SEED:-2026}"
B="${B:-1}"
H="${H:-32}"
HV="${HV:-32}"
C="${C:-16}"
OUT_DIR="${OUT_DIR:-${PLAN_DIR}/hw_out/onboard_profile_${MODULE}_b${B}h${H}hv${HV}c${C}_$(date +%Y%m%d_%H%M%S)}"

if [[ -n "${PYTHON_CMD:-}" ]]; then
  read -r -a PYTHON_RUNNER <<< "${PYTHON_CMD}"
elif command -v conda >/dev/null 2>&1 && conda env list | grep -qE '^torch210npu[[:space:]]'; then
  PYTHON_RUNNER=(conda run -n torch210npu python)
else
  PYTHON_RUNNER=(python)
fi

mkdir -p "${OUT_DIR}"
OUT_DIR="$(cd "${OUT_DIR}" && pwd)"

# Keep generated custom-op packages under this run directory. OpExec defaults
# custom_op_path to the current working directory for onboard runs.
cd "${OUT_DIR}"

echo "kda_fwd onboard profile"
echo "  module=${MODULE} upstream=${UPSTREAM} seed=${SEED} shape=(B=${B},H=${H},HV=${HV},C=${C})"
echo "  repo_root=${REPO_ROOT}"
echo "  out_dir=${OUT_DIR}"
echo "  workdir=$(pwd)"
echo "  python=${PYTHON_RUNNER[*]}"

# Capture the driver's exit code without tripping `set -e`, so the timing
# summary below still prints even when a marginal correctness miss flips the
# driver to a non-zero return.
RC=0
"${PYTHON_RUNNER[@]}" "${PLAN_DIR}/test_script/module_vs_ref.py" \
  --module "${MODULE}" \
  --mode onboard \
  --upstream "${UPSTREAM}" \
  --seed "${SEED}" \
  --B "${B}" \
  --H "${H}" \
  --HV "${HV}" \
  --C "${C}" \
  --out-dir "${OUT_DIR}" \
  --profile \
  --stop-on-fail \
  "$@" || RC=$?

# Per-kernel HW timings. a5 is the non-debug (debug=False) path, so each leaf's
# r.sh runs the aclnn test and parse_prof.py prints
#   ---- N_TESTS: <n>   AVG: <us>  FirstRun: <us>  ----
# into <module>_kernel_script/r.sh.log (AVG = per-call average over the timed
# window). "Time cost: <ms>" is the a2 debug-path token, kept as a fallback.
TIMING_RE="N_TESTS|Time cost"
echo
echo "===== per-kernel HW timings (AVG; 'Time cost' on a2) ====="
if grep -rsnE "${TIMING_RE}" "${OUT_DIR}" >/dev/null 2>&1; then
  grep -rsnE "${TIMING_RE}" "${OUT_DIR}" | sort
else
  echo "  (no timing lines found under ${OUT_DIR};"
  echo "   profiling disabled, or the run stopped before HW launch)"
fi

exit "${RC}"
