"""Sub-kernel reference: sub2_intra - KDA intra-chunk matrices.

I/O contract
------------
Inputs:
  - q:    torch.bfloat16/float16 [B, H,  C, L, K]
  - k:    torch.bfloat16/float16 [B, H,  C, L, K]
  - g:    torch.float32          [B, HV, C, L, K] cumulative gates in linear space
  - beta: torch.float32          [B, HV, C, L]

Outputs:
  - Aqk:  q.dtype [B, HV, C, L, L], lower-triangular inclusive
  - Akk:  k.dtype [B, HV, C, L, L], unit lower-triangular inverse without
          the final beta-column multiply used by `w/u`

Primitives used: [P1, P5, P6]
"""

import torch


def _expand_qk_to_value_heads(x, hv):
    h = x.shape[1]
    group = hv // h
    return x.repeat_interleave(group, dim=1)


def _solve_unit_lower_from_strict(strict_lower):
    # Mirrors upstream forward substitution over the strict lower matrix.
    out = strict_lower.clone()
    L = out.shape[-1]
    for i in range(1, L):
        prev = out[..., :i, :i].clone()
        row = out[..., i, :i].clone()
        correction = (out[..., i, :i, None].clone() * prev).sum(-2)
        out[..., i, :i] = row + correction
    eye = torch.eye(L, dtype=out.dtype, device=out.device)
    return out + eye


def subkernel(q, k, g, beta, scale):
    B, H, C, L, K = q.shape
    HV = g.shape[1]
    q_hv = _expand_qk_to_value_heads(q.float(), HV)
    k_hv = _expand_qk_to_value_heads(k.float(), HV)
    gf = g.float()
    betaf = beta.float()

    Aqk = torch.empty(B, HV, C, L, L, dtype=torch.float32, device=q.device)
    Akk_raw = torch.empty_like(Aqk)
    for j in range(L):
        k_j = k_hv[..., j, :]
        g_j = gf[..., j:j + 1, :]
        gate = gf / g_j
        Aqk[..., :, j] = (q_hv * gate * k_j[..., None, :]).sum(-1) * scale
        Akk_raw[..., :, j] = (k_hv * gate * k_j[..., None, :]).sum(-1)

    row = torch.arange(L, device=q.device)[:, None]
    col = torch.arange(L, device=q.device)[None, :]
    lower_inclusive = row >= col
    strict_lower = row > col

    Aqk = torch.where(lower_inclusive, Aqk, torch.zeros_like(Aqk))
    beta_weighted = Akk_raw * betaf[..., :, None]
    strict = torch.where(strict_lower, -beta_weighted, torch.zeros_like(beta_weighted))
    Akk = _solve_unit_lower_from_strict(strict)
    return Aqk.to(q.dtype), Akk.to(k.dtype)


if __name__ == "__main__":
    from oracle import sample_inputs, to_chunked_inputs
    from sub1_gate_ref import subkernel as gate_cumsum

    q, k, v, g_raw, beta, _ = sample_inputs(B=1, H=1, HV=1, C=1, L=32, K=32, V=32, seed=42)
    q_c, k_c, _v_c, g_raw_c, beta_c = to_chunked_inputs(q, k, v, g_raw, beta, chunk_size=32)
    result = subkernel(q_c, k_c, gate_cumsum(g_raw_c), beta_c, scale=32 ** -0.5)
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
