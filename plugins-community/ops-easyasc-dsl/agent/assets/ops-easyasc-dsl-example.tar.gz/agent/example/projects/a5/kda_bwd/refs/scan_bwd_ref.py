"""Pure PyTorch reference for the saved-cache scan backward stage."""

from common import KDAForwardCaches, scan_bwd, scan_mids_as_tuple


def subkernel(g_cumsum, Aqk, qg, kg, w, u, v_new, h, do, dht, chunk_size):
    caches = KDAForwardCaches(g_cumsum=g_cumsum, Aqk=Aqk, Akk=Aqk.new_zeros(Aqk.shape), w=w, u=u, qg=qg, kg=kg, v_new=v_new, h=h)
    return scan_mids_as_tuple(scan_bwd(do, dht, caches, chunk_size))


if __name__ == "__main__":
    from common import build_saved_forward, make_inputs

    inputs = make_inputs(B=1, H=2, HV=4, T=8, K=8, V=6, chunk_size=4, seed=0)
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    result = subkernel(
        caches.g_cumsum,
        caches.Aqk,
        caches.qg,
        caches.kg,
        caches.w,
        caches.u,
        caches.v_new,
        caches.h,
        inputs.do,
        inputs.dht,
        inputs.chunk_size,
    )
    print([tuple(item.shape) for item in result], [item.dtype for item in result])
