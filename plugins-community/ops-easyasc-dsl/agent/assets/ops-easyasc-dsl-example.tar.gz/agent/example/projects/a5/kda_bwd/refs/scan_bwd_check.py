"""Smoke-check the saved-cache scan backward stage wrapper."""

from common import _check_close, build_saved_forward, make_inputs, scan_bwd, scan_mids_as_tuple, scan_mids_from_tuple
from scan_bwd_ref import subkernel


def main():
    inputs = make_inputs(B=1, H=2, HV=4, T=8, K=8, V=6, chunk_size=4, seed=11)
    caches = build_saved_forward(inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, inputs.initial_state, inputs.chunk_size)
    expected = scan_bwd(inputs.do, inputs.dht, caches, inputs.chunk_size)
    actual = scan_mids_from_tuple(
        subkernel(
            caches.g_cumsum,
            caches.Aqk,
            caches.qg,
            caches.kg,
            caches.w,
            caches.u,
            caches.v_new,
            caches.h,
            inputs.do,
            inputs.dht,
            inputs.chunk_size,
        )
    )
    for name, got, ref in zip(("dAqk", "dh", "dv", "dh0"), scan_mids_as_tuple(actual), scan_mids_as_tuple(expected)):
        _check_close(name, got, ref, 1e-6, 1e-6)
    print("scan_bwd_check: OK")


if __name__ == "__main__":
    main()
