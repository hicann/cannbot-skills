"""Shared pure PyTorch formulas for the plan-local delta_rule backward refs.

This is `projects/a5/gdn_bwd/refs/common.py` with the per-token gate `g` removed
(the ungated delta rule = GDN with `g == 0`).  Removing `g` means:
  * `g_cumsum`, every `exp(g_cumsum)` factor, and `exp_delta = exp(g_last - g)`
    are gone (all == 1);
  * the intra-chunk `decay_mask` collapses to the constant causal keep
    `tril(ones)`, so it is no longer a saved input;
  * `k_weighted = key * exp_delta` degenerates to `key`, so `k_weighted_history`
    is dropped (the recurrence/state paths consume `key` directly);
  * the recurrent-state decay `S * exp(g_last)` vanishes (`S += k_i^T @ v_new`);
  * every `d_g` / `d_decay_mask` accumulator is removed — they only ever fed the
    gate gradient and never flow into `d_q/d_k/d_v/d_beta`.

Saved forward tensors shrink from gdn's set to
`(wu_attn_bf16, value_wu, k_cumdecay, state_after_history, v_new_history)`, and
the public outputs shrink to `(d_query, d_key, d_value, d_beta)`.

Precision model (same as gdn): cube matmuls use bf16 operands with fp32
accumulation (`bf16_cube_mm`); exps/masks/reductions/final accumulation stay fp32.
"""

import torch


L = 64
D = 128
ATOL = 5e-4
RTOL = 5e-4


def strict_lower(device):
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device), diagonal=-1)


def lower_eq(device):
    """The intra-chunk causal keep: GDN's `decay_mask` at g == 0."""
    return torch.tril(torch.ones(L, L, dtype=torch.float32, device=device))


def f32(x):
    return x if x.dtype == torch.float32 else x.float()


def bf16_cube_operand(x):
    return x.to(torch.bfloat16).float()


def bf16_cube_mm(lhs, rhs):
    """A5 cube contract for this plan: bf16 inputs, fp32 accumulation/output."""
    return bf16_cube_operand(lhs) @ bf16_cube_operand(rhs)


def make_inputs(B=1, H=2, C=2, scale=0.05):
    query = (torch.randn(B, H, C, L, D, dtype=torch.float32) * scale).to(torch.bfloat16)
    key = (torch.randn(B, H, C, L, D, dtype=torch.float32) * scale).to(torch.bfloat16)
    value = (torch.randn(B, H, C, L, D, dtype=torch.float32) * scale).to(torch.bfloat16)
    beta = torch.rand(B, H, C, L, dtype=torch.float32)
    grad_output = (torch.randn(B, H, C, L, D, dtype=torch.float32) * 0.1).to(torch.bfloat16)
    grad_final_state = torch.randn(B, H, D, D, dtype=torch.float32) * 0.1

    k = key.float()
    v = value.float()
    k_beta = k * beta.unsqueeze(-1)
    # A = -(k_beta @ key^T) on the strict lower triangle (decay_mask == 1 here).
    preprocess_attn = -(bf16_cube_mm(k_beta, k.transpose(-1, -2)) * strict_lower(query.device))
    wu_attn_fp32 = torch.linalg.inv(torch.eye(L, dtype=torch.float32, device=query.device) - preprocess_attn)
    wu_attn_bf16 = wu_attn_fp32.to(torch.bfloat16)
    v_beta = (v * beta.unsqueeze(-1)).to(torch.bfloat16).float()
    k_beta_bf = (k_beta).to(torch.bfloat16).float()  # no exp(g_cumsum) weight
    value_wu = bf16_cube_mm(wu_attn_bf16, v_beta).to(torch.bfloat16)
    k_cumdecay = bf16_cube_mm(wu_attn_bf16, k_beta_bf).to(torch.bfloat16)
    state_after_history, v_new_history = state_history_forward(key, value_wu, k_cumdecay)

    return (
        query, key, value, beta, grad_output,
        wu_attn_bf16, value_wu, k_cumdecay,
        state_after_history, v_new_history, grad_final_state,
    )


def state_history_forward(key, value_wu, k_cumdecay):
    """Per-chunk post-update state and `v_new`; gdn's at g == 0 (no decay, k_weighted == key)."""
    B, H, C, _, _ = key.shape
    state = torch.zeros(B, H, D, D, dtype=torch.bfloat16, device=key.device)
    states = []
    v_news = []
    for c in range(C):
        k_i = key[:, :, c].float()
        v_new = (value_wu[:, :, c].float() - bf16_cube_mm(k_cumdecay[:, :, c], state)).to(torch.bfloat16)
        v_news.append(v_new)
        state = (state.float() + bf16_cube_mm(k_i.transpose(-1, -2), v_new)).to(torch.bfloat16)
        states.append(state)
    return torch.stack(states, dim=2), torch.stack(v_news, dim=2)


def core_scan_bwd(query, key, grad_output, k_cumdecay, state_after_history, v_new_history, grad_final_state=None):
    """Monolithic reverse-C scan backward (gdn's `core_scan_bwd` at g == 0)."""
    B, H, C, _, _ = query.shape
    q = bf16_cube_operand(query)
    k = bf16_cube_operand(key)
    k_cumdecay = bf16_cube_operand(k_cumdecay)
    state_after_history = bf16_cube_operand(state_after_history)
    v_new_history = bf16_cube_operand(v_new_history)
    causal = lower_eq(query.device)
    final_state = state_after_history[:, :, C - 1]
    d_state = torch.zeros_like(final_state) if grad_final_state is None else grad_final_state.float()
    d_core = bf16_cube_operand(grad_output)

    d_q = torch.zeros_like(q)
    d_k = torch.zeros_like(k)
    d_value_wu = torch.zeros(B, H, C, L, D, dtype=torch.bfloat16, device=query.device)
    d_k_cumdecay = torch.zeros(B, H, C, L, D, dtype=torch.bfloat16, device=query.device)

    for c in range(C - 1, -1, -1):
        state = torch.zeros_like(final_state) if c == 0 else state_after_history[:, :, c - 1]
        q_i = q[:, :, c]
        k_i = k[:, :, c]
        d_out = d_core[:, :, c]
        score_qk = bf16_cube_mm(q_i, k_i.transpose(-1, -2))
        attn = score_qk * causal
        v_new = v_new_history[:, :, c]

        d_q_inter = bf16_cube_mm(d_out, state.transpose(-1, -2))
        d_state_in = bf16_cube_mm(q_i.transpose(-1, -2), d_out) + d_state  # no exp(g_last) decay
        d_attn = bf16_cube_mm(d_out, v_new.transpose(-1, -2))
        d_v_new = bf16_cube_mm(attn.transpose(-1, -2), d_out)
        d_k_from_state = bf16_cube_mm(v_new, d_state.transpose(-1, -2))
        d_v_new = d_v_new + bf16_cube_mm(k_i, d_state)  # k_weighted == k_i

        d_value_wu[:, :, c] = d_value_wu[:, :, c] + d_v_new
        d_v_prime = -d_v_new
        d_k_cumdecay[:, :, c] = d_k_cumdecay[:, :, c] + bf16_cube_mm(d_v_prime, state.transpose(-1, -2))
        d_state_in = d_state_in + bf16_cube_mm(k_cumdecay[:, :, c].transpose(-1, -2), d_v_prime)

        d_score_qk = d_attn * causal
        d_q[:, :, c] = d_q[:, :, c] + bf16_cube_mm(d_score_qk, k_i) + d_q_inter
        d_k[:, :, c] = d_k[:, :, c] + bf16_cube_mm(d_score_qk.transpose(-1, -2), q_i)
        d_k[:, :, c] = d_k[:, :, c] + d_k_from_state  # exp_delta == 1
        d_state = d_state_in

    return d_q, d_k, d_value_wu, d_k_cumdecay


def scan_local_bwd(query, key, grad_output, v_new_history):
    """BHC-parallel local products (gdn's `scan_local_bwd` at g == 0).

    Drops the `d_decay_mask` / `d_decay_masked` outputs (gate-gradient only).
    """
    B, H, C, _, _ = query.shape
    q = bf16_cube_operand(query)
    k = bf16_cube_operand(key)
    d_core = bf16_cube_operand(grad_output)
    v_new_history = bf16_cube_operand(v_new_history)
    causal = lower_eq(query.device)

    d_score_tmp = torch.zeros(B, H, C, L, L, dtype=torch.bfloat16, device=query.device)
    d_v_attn_tmp = torch.zeros(B, H, C, L, D, dtype=torch.float32, device=query.device)

    for c in range(C):
        q_i = q[:, :, c]
        k_i = k[:, :, c]
        d_out = d_core[:, :, c]
        score_qk = bf16_cube_mm(q_i, k_i.transpose(-1, -2))
        v_new = v_new_history[:, :, c]
        d_attn = bf16_cube_mm(d_out, v_new.transpose(-1, -2))
        attn = score_qk * causal

        d_score_tmp[:, :, c] = (d_attn * causal).to(torch.bfloat16)
        d_v_attn_tmp[:, :, c] = bf16_cube_mm(attn.transpose(-1, -2), d_out)

    return d_score_tmp, d_v_attn_tmp


def scan_state_bwd(query, key, grad_output, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, d_v_attn_tmp):
    """BH-parallel reverse-C state bridge (gdn's `scan_state_bwd` at g == 0).

    Consumes `key` directly (k_weighted == key), drops `g_cumsum`/`exp_delta`,
    and emits no `d_g`.  Arranged around the same cube/vec/cube/vec body.
    """
    B, H, C, _, _ = query.shape
    q = bf16_cube_operand(query)
    k = bf16_cube_operand(key)
    k_cumdecay = bf16_cube_operand(k_cumdecay)
    state_after_history = bf16_cube_operand(state_after_history)
    v_new_history = bf16_cube_operand(v_new_history)
    final_state = state_after_history[:, :, C - 1]
    d_state = torch.zeros_like(final_state) if grad_final_state is None else grad_final_state.float()
    d_core = bf16_cube_operand(grad_output)

    d_q = torch.zeros_like(q)
    d_k = torch.zeros_like(k)
    d_value_wu = torch.zeros(B, H, C, L, D, dtype=torch.bfloat16, device=query.device)
    d_k_cumdecay = torch.zeros(B, H, C, L, D, dtype=torch.bfloat16, device=query.device)

    for c in range(C - 1, -1, -1):
        state = torch.zeros_like(final_state) if c == 0 else state_after_history[:, :, c - 1]
        q_i = q[:, :, c]
        k_i = k[:, :, c]
        d_out = d_core[:, :, c]
        d_score = d_score_tmp[:, :, c].float()
        v_new = v_new_history[:, :, c]
        d_v_attn = d_v_attn_tmp[:, :, c].float()

        # cube0: products that do not need d_v_prime
        d_q_inter = bf16_cube_mm(d_out, state.transpose(-1, -2))
        d_state_q = bf16_cube_mm(q_i.transpose(-1, -2), d_out)   # q_exp == q_i
        d_k_from_state = bf16_cube_mm(v_new, d_state.transpose(-1, -2))
        d_v_state = bf16_cube_mm(k_i, d_state)                   # k_weighted == k_i
        # vec0: expose d_v_prime
        d_v_new = d_v_attn + d_v_state
        d_value_wu[:, :, c] = d_v_new
        d_v_prime = -d_v_new
        # cube1: score products + d_v_prime-dependent products
        d_q_score = bf16_cube_mm(d_score, k_i)
        d_k_score = bf16_cube_mm(d_score.transpose(-1, -2), q_i)
        d_k_cumdecay[:, :, c] = bf16_cube_mm(d_v_prime, state.transpose(-1, -2))
        d_state_k = bf16_cube_mm(k_cumdecay[:, :, c].transpose(-1, -2), d_v_prime)
        # vec1: accumulate public grads and the recurrent d_state
        d_q[:, :, c] = d_q_score + d_q_inter
        d_k[:, :, c] = d_k_score + d_k_from_state
        d_state = d_state_q + d_state + d_state_k               # no exp(g_last) decay

    return d_q, d_k, d_value_wu, d_k_cumdecay


def scan_split_bwd(query, key, grad_output, k_cumdecay, state_after_history, v_new_history, grad_final_state=None):
    """Wire the BHC-parallel local stage into the BH-parallel state stage."""
    d_score, d_v_attn_tmp = scan_local_bwd(query, key, grad_output, v_new_history)
    d_q, d_k, d_value_wu, d_k_cumdecay = scan_state_bwd(
        query, key, grad_output, k_cumdecay, state_after_history,
        grad_final_state, d_score, v_new_history, d_v_attn_tmp,
    )
    return d_q, d_k, d_value_wu, d_k_cumdecay


def wu_recompute_bwd(key, value, beta, wu_attn_bf16, d_value_wu, d_k_cumdecay):
    """WY-representation backward (gdn's `wu_recompute_bwd` at g == 0).

    Drops the `exp(g_cumsum)` weight on the key path and the `d_g_cumsum` output.
    """
    k = bf16_cube_operand(key)
    v = bf16_cube_operand(value)
    beta_f = beta.float()
    wu_attn = bf16_cube_operand(wu_attn_bf16)
    d_value_wu = d_value_wu.float()
    d_k_cumdecay = d_k_cumdecay.float()

    k_beta = k * beta_f.unsqueeze(-1)
    v_beta = v * beta_f.unsqueeze(-1)

    d_wu = bf16_cube_mm(d_value_wu, v_beta.transpose(-1, -2)) + bf16_cube_mm(d_k_cumdecay, k_beta.transpose(-1, -2))
    d_wu = d_wu.to(torch.bfloat16)
    d_v_beta = bf16_cube_mm(wu_attn.transpose(-1, -2), d_value_wu)
    d_k_beta = bf16_cube_mm(wu_attn.transpose(-1, -2), d_k_cumdecay)  # no exp(g_cumsum) factor
    return d_wu, d_v_beta, d_k_beta


def inverse_preprocess_bwd(key, beta, wu_attn_bf16, d_wu):
    """Inverse block backward `dA = W.T @ dW @ W.T` (gdn's at g == 0).

    `decay_mask * strict_lower` collapses to `strict_lower`; drops `d_decay_mask`
    and the `preprocess_score` it needed.
    """
    k = bf16_cube_operand(key)
    beta_f = beta.float()
    wu_attn = bf16_cube_operand(wu_attn_bf16)
    d_wu = d_wu.float()
    k_beta = k * beta_f.unsqueeze(-1)

    d_attn_pre = bf16_cube_mm(bf16_cube_mm(wu_attn.transpose(-1, -2), d_wu), wu_attn.transpose(-1, -2))
    d_score_pre = -d_attn_pre * strict_lower(key.device)
    # d_k (d_k_pre) and d_k_beta (d_k_beta_pre) are bf16 GM bridges to finalize_bwd
    # (the fixpipe casts fp32 L0C -> bf16 on store); model that bf16 rounding here.
    d_k_beta = bf16_cube_mm(d_score_pre, k).to(torch.bfloat16)
    d_k = bf16_cube_mm(d_score_pre.transpose(-1, -2), k_beta).to(torch.bfloat16)
    return d_k, d_k_beta


def finalize_grads(key, value, beta, d_q, d_k_core, d_v_beta, d_k_beta_wu, d_k_pre, d_k_beta_pre):
    """Final gradient accumulation (gdn's `finalize_grads` at g == 0).

    No `decay_mask`, no `d_g` / reverse-cumsum path.
    """
    k = f32(key)
    v = f32(value)
    beta_f = beta.float()
    d_k = d_k_core.float() + d_k_pre.float()
    d_k_beta = d_k_beta_wu.float() + d_k_beta_pre.float()
    d_v_beta = d_v_beta.float()

    d_v = d_v_beta * beta_f.unsqueeze(-1)
    d_beta = (d_v_beta * v).sum(dim=-1)
    d_k = d_k + d_k_beta * beta_f.unsqueeze(-1)
    d_beta = d_beta + (d_k_beta * k).sum(dim=-1)
    return d_q.float(), d_k, d_v, d_beta


def tail_fused_bwd(key, value, beta, wu_attn_bf16, scan_outputs):
    d_q, d_k_core, d_value_wu, d_k_cumdecay = scan_outputs[:4]
    d_wu, d_v_beta, d_k_beta_wu = wu_recompute_bwd(key, value, beta, wu_attn_bf16, d_value_wu, d_k_cumdecay)
    d_k_pre, d_k_beta_pre = inverse_preprocess_bwd(key, beta, wu_attn_bf16, d_wu)
    return finalize_grads(key, value, beta, d_q, d_k_core, d_v_beta, d_k_beta_wu, d_k_pre, d_k_beta_pre)


def oracle(*args):
    (
        query, key, value, beta, grad_output,
        wu_attn_bf16, _value_wu, k_cumdecay,
        state_after_history, v_new_history, grad_final_state,
    ) = args
    scan = core_scan_bwd(
        query, key, grad_output, k_cumdecay, state_after_history,
        v_new_history, grad_final_state,
    )
    return tail_fused_bwd(key, value, beta, wu_attn_bf16, scan)


def compare_tuple(actual, expected, atol=ATOL, rtol=RTOL):
    if len(actual) != len(expected):
        raise AssertionError(f"arity mismatch: actual={len(actual)} expected={len(expected)}")
    for idx, (act, exp) in enumerate(zip(actual, expected)):
        if not torch.isfinite(act).all() or not torch.isfinite(exp).all():
            raise AssertionError(f"non-finite output at index {idx}")
        torch.testing.assert_close(act.float(), exp.float(), atol=atol, rtol=rtol)
