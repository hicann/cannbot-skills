"""Kernel-local PyTorch formulas for the full-bf16 KDA backward kernels.

These helpers mirror the A5 kernel precision path:

- every public tensor (inputs, saved caches, stage handoffs, outputs) is bf16,
- every cube contraction uses BF16 @ BF16 -> FP32,
- in-kernel intermediates stay fp32; bf16 only at GM stage boundaries,
- `dv0` (scan_dav -> scan_state) and the inverse matmul fan-out
  (`d_qg`/`d_kg`/`d_vh`, `d_v_beta`/`d_k_beta_g`) are the only fp32 GM
  handoffs - they stay private inside their stage.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

import torch

from projects.a5.kda_bwd.refs.common import (
    IO_DTYPE,
    KDAOracleInputs,
    KDAOracleOutputs,
    build_saved_forward as build_saved_forward_ref,
)


L = 64
D = 128
ATOL = 1e-2
RTOL = 1e-2
RCP_LN2 = 1.0 / math.log(2.0)


@dataclass
class SavedForward:
    g_cumsum: torch.Tensor
    Aqk: torch.Tensor
    Akk: torch.Tensor
    w: torch.Tensor
    u: torch.Tensor
    qg: torch.Tensor
    kg: torch.Tensor
    v_new: torch.Tensor
    h: torch.Tensor


@dataclass
class ScanMids:
    dAqk: torch.Tensor
    dh: torch.Tensor
    dv: torch.Tensor
    dh0: torch.Tensor


@dataclass
class LocalMids:
    dq_hv: torch.Tensor
    dk_hv: torch.Tensor
    dv: torch.Tensor
    dbeta: torch.Tensor
    dg_core: torch.Tensor
    dAkk: torch.Tensor


def _exp2(x: torch.Tensor) -> torch.Tensor:
    return torch.exp2(x) if hasattr(torch, "exp2") else torch.pow(2.0, x)


def _to_io(x: torch.Tensor) -> torch.Tensor:
    return x.to(IO_DTYPE)


def _bf16_cube_operand(x: torch.Tensor) -> torch.Tensor:
    return x.to(torch.bfloat16).float()


def _bf16_cube_mm(lhs: torch.Tensor, rhs: torch.Tensor) -> torch.Tensor:
    return _bf16_cube_operand(lhs) @ _bf16_cube_operand(rhs)


def _chunk_bounds(total_length: int, chunk_size: int):
    return [(start, min(total_length, start + chunk_size)) for start in range(0, total_length, chunk_size)]


def _chunk_local_cumsum(x: torch.Tensor, chunk_size: int, reverse: bool = False) -> torch.Tensor:
    out = torch.empty_like(x, dtype=torch.float32)
    for start, end in _chunk_bounds(x.shape[1], chunk_size):
        block = x[:, start:end].float()
        if reverse:
            block = torch.flip(torch.cumsum(torch.flip(block, dims=(1,)), dim=1), dims=(1,))
        else:
            block = torch.cumsum(block, dim=1)
        out[:, start:end] = block
    return out


def _validate(inputs: KDAOracleInputs):
    B, T, H, K = inputs.q.shape
    HV, V = inputs.v.shape[2], inputs.v.shape[3]
    if K != 128 or V != 128:
        raise ValueError("first kernel formula assumes K=V=128")
    if inputs.chunk_size != L:
        raise ValueError("first kernel formula assumes chunk_size=64")
    if T % inputs.chunk_size != 0:
        raise ValueError("first kernel formula currently assumes aligned T")
    if inputs.v.shape[:2] != (B, T):
        raise ValueError("v shape mismatch")
    if inputs.g.shape != (B, T, HV, K):
        raise ValueError("g shape mismatch")
    if inputs.beta.shape != (B, T, HV):
        raise ValueError("beta shape mismatch")
    if inputs.initial_state.shape != (B, HV, K, V):
        raise ValueError("initial_state shape mismatch")
    if inputs.do.shape != inputs.v.shape:
        raise ValueError("do shape mismatch")
    if inputs.dht.shape != inputs.initial_state.shape:
        raise ValueError("dht shape mismatch")
    if HV % H != 0:
        raise ValueError("HV must be divisible by H")
    return B, T, H, HV, K, V, HV // H, K ** -0.5


def build_saved_forward(inputs: KDAOracleInputs) -> SavedForward:
    caches = build_saved_forward_ref(
        inputs.q,
        inputs.k,
        inputs.v,
        inputs.g,
        inputs.beta,
        inputs.initial_state,
        inputs.chunk_size,
    )
    return SavedForward(
        g_cumsum=caches.g_cumsum,
        Aqk=caches.Aqk,
        Akk=caches.Akk,
        w=caches.w,
        u=caches.u,
        qg=caches.qg,
        kg=caches.kg,
        v_new=caches.v_new,
        h=caches.h,
    )


def scan_dav_only(inputs: KDAOracleInputs, caches: SavedForward) -> Tuple[torch.Tensor, torch.Tensor]:
    """bf16 dAqk output and fp32 dv0 stage-private handoff."""
    B, T, _H, HV, K, V, _G, scale = _validate(inputs)
    dAqk = torch.zeros(B, T, HV, L, dtype=IO_DTYPE, device=inputs.q.device)
    dv0 = torch.empty(B, T, HV, V, dtype=torch.float32, device=inputs.q.device)
    do = inputs.do.float()
    for b in range(B):
        for start, end in _chunk_bounds(T, L):
            for hv in range(HV):
                do_blk = do[b, start:end, hv]
                v_new_blk = caches.v_new[b, start:end, hv].float()
                Aqk_blk = torch.tril(caches.Aqk[b, start:end, hv].float())
                dAqk[b, start:end, hv] = _to_io(torch.tril(_bf16_cube_mm(do_blk, v_new_blk.transpose(-1, -2)) * scale))
                dv0[b, start:end, hv] = _bf16_cube_mm(Aqk_blk.transpose(-1, -2), do_blk)
    return dAqk, dv0


def scan_state_only(
    inputs: KDAOracleInputs,
    caches: SavedForward,
    dv0: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """bf16 dh/dv/dh0 outputs; the running state stays fp32 inside."""
    B, T, _H, HV, K, V, _G, scale = _validate(inputs)
    C = T // L
    dv_f = dv0.float().clone()
    dv = torch.empty(B, T, HV, V, dtype=IO_DTYPE, device=inputs.q.device)
    dh = torch.empty(B, C, HV, K, V, dtype=IO_DTYPE, device=inputs.q.device)
    d_state = inputs.dht.float().clone()
    do = inputs.do.float()
    for b in range(B):
        for c in range(C - 1, -1, -1):
            start = c * L
            end = start + L
            for hv in range(HV):
                dh[b, c, hv] = _to_io(d_state[b, hv])
                dv_blk = dv_f[b, start:end, hv] + _bf16_cube_mm(caches.kg[b, start:end, hv].float(), d_state[b, hv])
                dv_f[b, start:end, hv] = dv_blk
                dv[b, start:end, hv] = _to_io(dv_blk)
                g_last = caches.g_cumsum[b, end - 1, hv].float()
                d_state[b, hv] = (
                    d_state[b, hv] * _exp2(g_last)[:, None]
                    + _bf16_cube_mm(caches.qg[b, start:end, hv].float().transpose(-1, -2), do[b, start:end, hv]) * scale
                    - _bf16_cube_mm(caches.w[b, start:end, hv].float().transpose(-1, -2), dv_blk)
                )
    return dh, dv, _to_io(d_state)


def scan_bwd(inputs: KDAOracleInputs, caches: SavedForward) -> ScanMids:
    dAqk, dv0 = scan_dav_only(inputs, caches)
    dh, dv, dh0 = scan_state_only(inputs, caches, dv0)
    return ScanMids(dAqk=dAqk, dh=dh, dv=dv, dh0=dh0)


def inverse_qkgw_only(
    inputs: KDAOracleInputs,
    caches: SavedForward,
    scan: ScanMids,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """fp32 stage-private matmul fan-out (d_qg, d_kg, d_vh)."""
    B, T, _H, HV, _K, V, _G, _scale = _validate(inputs)
    d_qg = torch.empty(B, T, HV, D, dtype=torch.float32, device=inputs.q.device)
    d_kg = torch.empty(B, T, HV, D, dtype=torch.float32, device=inputs.q.device)
    d_vh = torch.empty(B, T, HV, D, dtype=torch.float32, device=inputs.q.device)
    do = inputs.do.float()

    for b in range(B):
        for c in range(T // L):
            start = c * L
            end = start + L
            for hv in range(HV):
                h_blk = caches.h[b, c, hv].float()
                dh_blk = scan.dh[b, c, hv].float()
                do_blk = do[b, start:end, hv]
                v_new_blk = caches.v_new[b, start:end, hv].float()
                dv_blk = scan.dv[b, start:end, hv].float()
                d_qg[b, start:end, hv] = _bf16_cube_mm(do_blk, h_blk.transpose(-1, -2))
                d_kg[b, start:end, hv] = _bf16_cube_mm(v_new_blk, dh_blk.transpose(-1, -2))
                d_vh[b, start:end, hv] = _bf16_cube_mm(dv_blk, h_blk.transpose(-1, -2))
    return d_qg, d_kg, d_vh


def inverse_beta_only(
    inputs: KDAOracleInputs,
    caches: SavedForward,
    scan: ScanMids,
    d_w: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """fp32 stage-private products consumed by the host epilogue."""
    B, T, _H, HV, _K, V, _G, _scale = _validate(inputs)
    d_v_beta = torch.empty(B, T, HV, V, dtype=torch.float32, device=inputs.q.device)
    d_k_beta_g = torch.empty(B, T, HV, D, dtype=torch.float32, device=inputs.q.device)

    for b in range(B):
        for start, end in _chunk_bounds(T, L):
            for hv in range(HV):
                Akk_blk = caches.Akk[b, start:end, hv].float()
                dv_blk = scan.dv[b, start:end, hv].float()
                d_w_blk = d_w[b, start:end, hv]
                d_v_beta[b, start:end, hv] = _bf16_cube_mm(Akk_blk.transpose(-1, -2), dv_blk)
                d_k_beta_g[b, start:end, hv] = _bf16_cube_mm(Akk_blk.transpose(-1, -2), d_w_blk)
    return d_v_beta, d_k_beta_g


def inverse_bwd(inputs: KDAOracleInputs, caches: SavedForward, scan: ScanMids) -> LocalMids:
    B, T, H, HV, K, V, G, scale = _validate(inputs)
    dq_hv = torch.empty(B, T, HV, K, dtype=IO_DTYPE, device=inputs.q.device)
    dk_hv = torch.empty(B, T, HV, K, dtype=IO_DTYPE, device=inputs.q.device)
    dv = torch.empty(B, T, HV, V, dtype=IO_DTYPE, device=inputs.q.device)
    dbeta = torch.empty(B, T, HV, dtype=IO_DTYPE, device=inputs.q.device)
    dg_core = torch.empty(B, T, HV, K, dtype=IO_DTYPE, device=inputs.q.device)
    dAkk = torch.zeros(B, T, HV, L, dtype=IO_DTYPE, device=inputs.q.device)

    q = inputs.q.float()
    k = inputs.k.float()
    v = inputs.v.float()
    do = inputs.do.float()
    beta = inputs.beta.float()

    for b in range(B):
        for c in range(T // L):
            start = c * L
            end = start + L
            for hv in range(HV):
                hq = hv // G
                q_blk = q[b, start:end, hq]
                k_blk = k[b, start:end, hq]
                v_blk = v[b, start:end, hv]
                v_new_blk = caches.v_new[b, start:end, hv].float()
                g_blk = caches.g_cumsum[b, start:end, hv].float()
                beta_blk = beta[b, start:end, hv]
                Akk_blk = caches.Akk[b, start:end, hv].float()
                h_blk = caches.h[b, c, hv].float()
                dh_blk = scan.dh[b, c, hv].float()
                do_blk = do[b, start:end, hv]
                dv_blk = scan.dv[b, start:end, hv].float()

                exp_g = _exp2(g_blk)
                g_last = g_blk[L - 1]
                exp_last_minus_g = _exp2(g_last[None, :] - g_blk)

                d_qg = _bf16_cube_mm(do_blk, h_blk.transpose(-1, -2))
                dq_blk = d_qg * exp_g * scale
                d_kg = _bf16_cube_mm(v_new_blk, dh_blk.transpose(-1, -2))
                dk_from_kg = d_kg * exp_last_minus_g
                d_g_last = (h_blk * dh_blk).sum(dim=1) * _exp2(g_last)
                d_g_last = d_g_last + (k_blk * dk_from_kg).sum(dim=0)

                d_w = -_bf16_cube_mm(dv_blk, h_blk.transpose(-1, -2))
                k_exp = k_blk * exp_g
                dA_inv = _bf16_cube_mm(dv_blk, v_blk.transpose(-1, -2)) + _bf16_cube_mm(d_w, k_exp.transpose(-1, -2))

                d_v_beta = _bf16_cube_mm(Akk_blk.transpose(-1, -2), dv_blk)
                dv[b, start:end, hv] = _to_io(d_v_beta * beta_blk[:, None])
                dbeta_blk = (d_v_beta * v_blk).sum(dim=1)

                d_k_beta_g = _bf16_cube_mm(Akk_blk.transpose(-1, -2), d_w)
                dk_from_w = d_k_beta_g * beta_blk[:, None] * exp_g
                dbeta_blk = dbeta_blk + (d_k_beta_g * k_exp).sum(dim=1)
                dg_from_w = d_k_beta_g * k_exp * beta_blk[:, None]

                dg_blk = q_blk * dq_blk - k_blk * dk_from_kg + dg_from_w
                dg_blk[L - 1] = dg_blk[L - 1] + d_g_last

                D_tri = torch.tril(dA_inv * beta_blk[None, :], diagonal=-1)
                dL = -_bf16_cube_mm(Akk_blk.transpose(-1, -2), _bf16_cube_mm(D_tri, Akk_blk.transpose(-1, -2)))

                dq_hv[b, start:end, hv] = _to_io(dq_blk)
                dk_hv[b, start:end, hv] = _to_io(dk_from_kg + dk_from_w)
                dbeta[b, start:end, hv] = _to_io(dbeta_blk)
                dg_core[b, start:end, hv] = _to_io(dg_blk)
                dAkk[b, start:end, hv] = _to_io(torch.tril(dL, diagonal=-1))

    return LocalMids(dq_hv=dq_hv, dk_hv=dk_hv, dv=dv, dbeta=dbeta, dg_core=dg_core, dAkk=dAkk)


def finalize_bwd(inputs: KDAOracleInputs, caches: SavedForward, scan: ScanMids, local: LocalMids) -> KDAOracleOutputs:
    B, T, H, HV, K, _V, G, _scale = _validate(inputs)
    dq_hv = local.dq_hv.float()
    dk_hv = local.dk_hv.float()
    dbeta = local.dbeta.float()
    dg = local.dg_core.float()
    q = inputs.q.float()
    k = inputs.k.float()
    beta = inputs.beta.float()
    g_cumsum = caches.g_cumsum.float()
    dAqk = scan.dAqk.float()
    dAkk = local.dAkk.float()

    for b in range(B):
        for start, end in _chunk_bounds(T, L):
            for hv in range(HV):
                hq = hv // G
                q_blk = q[b, start:end, hq]
                k_blk = k[b, start:end, hq]
                g_blk = g_cumsum[b, start:end, hv]
                beta_blk = beta[b, start:end, hv]
                for row in range(L):
                    for col in range(row + 1):
                        decay = _exp2(g_blk[row] - g_blk[col])
                        coeff_qk = dAqk[b, start + row, hv, col]
                        pair_qk = coeff_qk * q_blk[row] * k_blk[col] * decay
                        dq_hv[b, start + row, hv] = dq_hv[b, start + row, hv] + coeff_qk * k_blk[col] * decay
                        dk_hv[b, start + col, hv] = dk_hv[b, start + col, hv] + coeff_qk * q_blk[row] * decay
                        dg[b, start + row, hv] = dg[b, start + row, hv] + pair_qk
                        dg[b, start + col, hv] = dg[b, start + col, hv] - pair_qk

                        if col < row:
                            coeff_kk = dAkk[b, start + row, hv, col]
                            pair_kk = coeff_kk * beta_blk[row] * k_blk[row] * k_blk[col] * decay
                            dk_hv[b, start + row, hv] = dk_hv[b, start + row, hv] + coeff_kk * beta_blk[row] * k_blk[col] * decay
                            dk_hv[b, start + col, hv] = dk_hv[b, start + col, hv] + coeff_kk * beta_blk[row] * k_blk[row] * decay
                            dbeta[b, start + row, hv] = dbeta[b, start + row, hv] + coeff_kk * (k_blk[row] * k_blk[col] * decay).sum()
                            dg[b, start + row, hv] = dg[b, start + row, hv] + pair_kk
                            dg[b, start + col, hv] = dg[b, start + col, hv] - pair_kk

    dq = dq_hv.reshape(B, T, H, G, K).sum(dim=3)
    dk = dk_hv.reshape(B, T, H, G, K).sum(dim=3)
    dg = _chunk_local_cumsum(dg, L, reverse=True)
    return KDAOracleOutputs(dq=_to_io(dq), dk=_to_io(dk), dv=local.dv, dbeta=_to_io(dbeta), dg=_to_io(dg), dh0=scan.dh0)


def run_reference(inputs: KDAOracleInputs) -> KDAOracleOutputs:
    caches = build_saved_forward(inputs)
    scan = scan_bwd(inputs, caches)
    local = inverse_bwd(inputs, caches, scan)
    return finalize_bwd(inputs, caches, scan, local)
