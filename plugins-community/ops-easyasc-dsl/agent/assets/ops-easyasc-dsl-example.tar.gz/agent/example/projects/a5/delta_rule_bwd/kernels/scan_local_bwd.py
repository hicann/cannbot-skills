"""scan_local_bwd (ungated): BHC-parallel local products for delta_rule backward.

Ungated port of `gdn_bwd/kernels/scan_local_bwd.py`.  GDN loads a data-dependent
`decay_mask` from GM and multiplies the scores by it; the delta rule has no gate,
so the mask is the constant lower-triangular causal keep (GDN's decay_mask at
g == 0), built per row in the vec stage from the absolute row index — the same
idiom as `delta_rule_fwd/kernels/chunk_delta_sub1.py`.

Per (b,h,c) tile:
  score_qk = q @ k^T                       (cube)
  d_attn   = grad_output @ v_new^T         (cube)
  attn     = score_qk * causal_keep        (vec)
  d_score  = (d_attn * causal_keep) -> bf16 (vec)            -> d_score_tmp
  d_v_attn = attn^T @ grad_output          (cube, lookahead) -> d_v_attn_tmp

Dropped vs GDN: the `decay_mask` input and the `d_decay_core`/`d_decay_core_masked`
outputs (gate-gradient only).
"""
import os

import torch

from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig


DEFAULT_CORE_COUNT = 32
DEFAULT_SIM_TIMEOUT_S = 180.0

L = 64
D = 128
HALF_L = L // 2

SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
    2: [0, 1, 2, None, None],
    3: [0, 1, 2, None, None],
    4: [0, 1, 2, None, None],
    5: [0, 1, 2, None, None],
}


@vf()
def cast_l_rows_float_to_bf16_nz_vf(src_ub: Tensor, dst_nz_ub: Tensor, rows: Var):
    """Cast [rows, L] float attn rows to the bf16 NZ layout L1 expects."""
    row_float = Reg(DT.float)
    lo_bf16 = Reg(DT.bfloat16)
    row_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    BF16_C0 = 16
    for r in range(rows):
        row_float <<= src_ub[r:r + 1, 0:L]
        lo_bf16 <<= row_float.astype(DT.bfloat16)
        deinterleave(row_bf16, dummy_bf16, lo_bf16, dummy_bf16)
        reg_to_ub(dst_nz_ub[r * BF16_C0], row_bf16, rows)


@vf()
def mask_attn_causal_vf(
    score_to_attn_ub: Tensor,
    d_attn_to_d_score_ub: Tensor,
    attn_out_ub: Tensor,
    d_score_bf16_out_ub: Tensor,
    row_begin: Var,
    rows: Var,
):
    """attn = score * causal_keep; d_score = (d_attn * causal_keep) -> bf16.

    The causal keep is GDN's decay_mask at g == 0: for absolute row `abs_r`, keep
    columns 0..abs_r (lower triangle incl. diagonal), zero the rest.
    """
    cols = Reg(DT.int)
    zero = Reg(DT.float)
    score_regs = Reg(DT.float)
    d_attn_regs = Reg(DT.float)
    tmp_regs = Reg(DT.float)
    score_bf16 = Reg(DT.bfloat16)
    dummy_bf16 = Reg(DT.bfloat16)
    score_row = Reg(DT.bfloat16)
    keep_mask = MaskReg(DT.int, init_mode=MaskType.NONE)
    bf16_lowhalf = MaskReg(DT.bfloat16, init_mode=MaskType.LOWHALF)

    zero <<= 0.0
    cols.arange(0)
    for r in range(rows):
        abs_r = Var(row_begin + r)
        score_regs <<= score_to_attn_ub[r:r + 1, 0:L]
        d_attn_regs <<= d_attn_to_d_score_ub[r:r + 1, 0:L]
        compare(keep_mask, cols, abs_r + 1, CompareMode.LT)

        select(tmp_regs, score_regs, zero, mask=keep_mask)
        attn_out_ub[r:r + 1, 0:L] <<= tmp_regs

        select(tmp_regs, d_attn_regs, zero, mask=keep_mask)
        score_bf16 <<= tmp_regs.astype(DT.bfloat16)
        deinterleave(score_row, dummy_bf16, score_bf16, dummy_bf16)
        reg_to_ub(d_score_bf16_out_ub[r:r + 1, 0:L], score_row, mask=bf16_lowhalf)
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def scan_local_bwd_kernel(
    query: GMTensor,
    key: GMTensor,
    grad_output: GMTensor,
    v_new_history: GMTensor,
    d_score_tmp: GMTensor,
    d_v_attn_tmp: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    cvmutex = CvMutex(0, depth=2, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    attn_mutex = VcMutex(1, depth=2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    l1_q = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_k = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_d_out = TBuff(DT.bfloat16, [L, D], Position.L1)
    l1_v_new = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_attn = DBuff(DT.bfloat16, [L, L], Position.L1)

    l0c_ll0 = DBuff(DT.float, [L, L], Position.L0C)
    l0c_ll1 = DBuff(DT.float, [L, L], Position.L0C)
    l0c_dv = DBuff(DT.float, [L, D], Position.L0C)

    bf16_full_ub = DBuff(DT.bfloat16, [L, D], Position.UB)
    float_half0_ub = DBuff(DT.float, [HALF_L, D], Position.UB)
    d_score_bf16_ub = DBuff(DT.bfloat16, [HALF_L, L], Position.UB)
    ll0_ub = DBuff(DT.float, [HALF_L, L], Position.UB)
    ll1_ub = DBuff(DT.float, [HALF_L, L], Position.UB)

    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    for pipe_bhc in range(bhc_begin, bhc_end + 1):
        if pipe_bhc < bhc_end:
            with auto_sync():
                pipe_slot = var_mod(pipe_bhc - bhc_begin, 2)
                dout_slot = var_mod(pipe_bhc - bhc_begin, 3)
                c_idx = Var(pipe_bhc % C)
                bh = Var(pipe_bhc // C)
                b_idx = Var(bh // H)
                h_idx = Var(bh % H)
                row_begin_l = Var(GetSubBlockIdx() * HALF_L)
                row_end_l = Var(row_begin_l + HALF_L)
                rows_l = Var(HALF_L)

                l1_q[pipe_slot][0:L, 0:D] <<= query[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_k[pipe_slot][0:L, 0:D] <<= key[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_d_out[dout_slot][0:L, 0:D] <<= grad_output[b_idx, h_idx, c_idx, 0:L, 0:D]
                l1_v_new[pipe_slot][0:L, 0:D] <<= v_new_history[b_idx, h_idx, c_idx, 0:L, 0:D]

                matmul(l0c_ll0[pipe_slot], l1_q[pipe_slot], l1_k[pipe_slot], m=L, n=L, k=D, splitn=L)
                matmul(l0c_ll1[pipe_slot], l1_d_out[dout_slot], l1_v_new[pipe_slot], m=L, n=L, k=D, splitn=L)

                cvmutex.lock()
                ll0_ub[pipe_slot] <<= l0c_ll0[pipe_slot]
                ll1_ub[pipe_slot] <<= l0c_ll1[pipe_slot]
                cvmutex.ready()
                cvmutex.wait()
                mask_attn_causal_vf(
                    ll0_ub[pipe_slot],
                    ll1_ub[pipe_slot],
                    float_half0_ub[pipe_slot],
                    d_score_bf16_ub[pipe_slot],
                    row_begin_l,
                    rows_l,
                )
                cvmutex.free()

                attn_mutex.lock()
                cast_l_rows_float_to_bf16_nz_vf(float_half0_ub[pipe_slot], bf16_full_ub[pipe_slot], rows_l)
                l1_attn[pipe_slot][row_begin_l:row_end_l, 0:L] <<= bf16_full_ub[pipe_slot][0:rows_l, 0:L].nz()
                attn_mutex.ready()

                d_score_tmp[b_idx, h_idx, c_idx, row_begin_l:row_end_l, 0:L] <<= d_score_bf16_ub[pipe_slot][0:rows_l, 0:L]

        if pipe_bhc > bhc_begin:
            with auto_sync():
                bhc = Var(pipe_bhc - 1)
                bhc_slot = var_mod(bhc - bhc_begin, 2)
                dout_slot = var_mod(bhc - bhc_begin, 3)
                c_idx = Var(bhc % C)
                bh = Var(bhc // C)
                b_idx = Var(bh // H)
                h_idx = Var(bh % H)

                attn_mutex.wait()
                matmul(l0c_dv[bhc_slot], l1_attn[bhc_slot].T, l1_d_out[dout_slot].T, m=L, n=D, k=L, splitn=D)
                attn_mutex.free()

                d_v_attn_tmp[b_idx, h_idx, c_idx, 0:L, 0:D] <<= l0c_dv[bhc_slot]

    return d_score_tmp, d_v_attn_tmp


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "delta_rule_bwd_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(query, key, grad_output, v_new_history, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    B = int(query.shape[0])
    H = int(query.shape[1])
    C = int(query.shape[2])
    device = query.device
    outputs = (
        torch.empty((B, H, C, L, L), dtype=torch.bfloat16, device=device),
        torch.empty((B, H, C, L, D), dtype=torch.float32, device=device),
    )
    trace_path = _trace_path(trace, out_dir, "scan_local_bwd")

    saved_sim_config = getattr(scan_local_bwd_kernel, "_simulator_config", None)
    if simulator:
        scan_local_bwd_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=trace_path is not None,
        )
    try:
        result = OpExec(
            scan_local_bwd_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
            profile=profile,
        )(
            query, key, grad_output, v_new_history,
            outputs[0], outputs[1], B, H, C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr(scan_local_bwd_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                scan_local_bwd_kernel._simulator_config = saved_sim_config
    return result


if __name__ == "__main__":
    import sys
    from pathlib import Path

    _ROOT = Path(__file__).resolve().parents[4]
    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
    _REFS = Path(__file__).resolve().parents[1] / "refs"
    if str(_REFS) not in sys.path:
        sys.path.insert(0, str(_REFS))
    from common import make_inputs, scan_local_bwd as ref_scan_local

    torch.manual_seed(42)
    B, H, C = 1, 1, int(os.environ.get("C_SIZE", "2"))
    full = make_inputs(B, H, C)
    query, key, grad_output, v_new_history = full[0], full[1], full[4], full[9]
    d_score_ref, d_v_attn_ref = ref_scan_local(query, key, grad_output, v_new_history)

    result = run(query, key, grad_output, v_new_history)
    d_score_got, d_v_attn_got = result
    ds_err = (d_score_got.float() - d_score_ref.float()).abs().max().item()
    dv_err = (d_v_attn_got.float() - d_v_attn_ref.float()).abs().max().item()
    print(f"scan_local_bwd C={C}: d_score max_abs={ds_err:.6e}  d_v_attn max_abs={dv_err:.6e}")
    torch.testing.assert_close(d_score_got.float(), d_score_ref.float(), rtol=2e-3, atol=2e-3)
    torch.testing.assert_close(d_v_attn_got.float(), d_v_attn_ref.float(), rtol=2e-3, atol=2e-3)
    print("scan_local_bwd OK")
