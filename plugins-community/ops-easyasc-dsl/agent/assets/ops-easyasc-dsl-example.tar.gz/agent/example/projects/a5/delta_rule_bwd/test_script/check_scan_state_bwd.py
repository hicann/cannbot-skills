"""Standalone simulator check for scan_state_bwd vs its ungated ref."""

import sys
from pathlib import Path

import torch

SCRIPT_DIR = Path(__file__).resolve().parent
PLAN_DIR = SCRIPT_DIR.parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)
for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import make_inputs, scan_local_bwd as ref_scan_local, scan_state_bwd as ref_scan_state  # noqa: E402
from scan_state_bwd import run as kernel_run  # noqa: E402


def main():
    B, H, C = 1, 1, 4  # C>=3 exercises the multi-update d_state recurrence
    torch.manual_seed(42)
    full = make_inputs(B, H, C)
    query, key, grad_output = full[0], full[1], full[4]
    k_cumdecay, state_after_history, v_new_history, grad_final_state = full[7], full[8], full[9], full[10]
    d_score_tmp, d_v_attn_tmp = ref_scan_local(query, key, grad_output, v_new_history)
    refs = ref_scan_state(query, key, grad_output, k_cumdecay, state_after_history, grad_final_state, d_score_tmp, v_new_history, d_v_attn_tmp)

    got = kernel_run(
        query, key, grad_output, k_cumdecay, state_after_history, grad_final_state,
        d_score_tmp, v_new_history, d_v_attn_tmp,
        simulator=True, out_dir="tmp/delta_bwd_scan_state",
    )
    names = ("d_q_core", "d_k_core", "d_value_wu", "d_k_cumdecay")
    all_ok = True
    for name, g, r in zip(names, got, refs):
        err = (g.float() - r.float()).abs().max().item()
        ok = bool(torch.allclose(g.float(), r.float(), atol=2e-3, rtol=2e-3))
        all_ok = all_ok and ok
        print(f"  [scan_state_bwd.{name}] {'OK' if ok else 'FAIL'} shape={tuple(g.shape)} dtype={g.dtype} max_abs={err:.3e}")
    print("scan_state_bwd %s" % ("OK" if all_ok else "FAIL"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
