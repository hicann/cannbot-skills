"""chunk-delta sub1 (ungated): attn = (q @ k^T) masked to the causal keep.

Ungated delta-rule port of `gdn_fwd/kernels/chunk_delta_sub1.py`.  GDN multiplies
the scores by a data-dependent `decay_mask` loaded from GM; the delta rule has no
gate, so there is no `decay_mask` input — the scores are masked by a constant
lower-triangular causal keep (incl. diagonal), which is exactly GDN's decay_mask
at `g == 0`.  The vec stage builds that keep per row from the absolute row index.
"""
import os

import torch


from easyasc.a5 import *  # noqa: F401, F403
from easyasc.simulator import SimulatorConfig


SIM_CORE_COUNT = 32
SIM_TIMEOUT_S = 180.0

SHAPE_BINDINGS = {
    0: [0, 1, 2, None, None],
    1: [0, 1, 2, None, None],
    2: [0, 1, 2, None, None],
}

# -----------------------------------------------------------------------------
TILE_M = 64
TILE_N = 64
TILE_K = 128

L = 64
D = 128
HALF_L = L // 2
M1_N = 64


@vf()
def attn_causal_keep_vf(attn_ub: Tensor, out_ub: Tensor, row_begin: Var, nrows: Var):
    cols = Reg(DT.int)
    zero = Reg(DT.float)
    a_reg = Reg(DT.float)
    keep_mask = MaskReg(DT.int, init_mode=MaskType.NONE)

    zero <<= 0.0
    cols.arange(0)

    for r in range(nrows):
        abs_r = Var(row_begin + r)
        a_reg <<= attn_ub[r * M1_N]
        # keep columns <= abs_r (lower triangle incl. diagonal), zero the rest.
        compare(keep_mask, cols, abs_r + 1, CompareMode.LT)
        select(a_reg, a_reg, zero, mask=keep_mask)
        out_ub[r * M1_N] <<= a_reg


@kernel()
def sub1_kernel(
    q_i: GMTensor,
    k_i: GMTensor,
    attn: GMTensor,
    B: Var,
    H: Var,
    C: Var,
):
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1_q = DBuff(DT.bfloat16, [L, D], Position.L1)
    l1_k = DBuff(DT.bfloat16, [M1_N, D], Position.L1)
    l0c_attn = DBuff(DT.float, [L, M1_N], Position.L0C)
    ub_attn = DBuff(DT.float, [HALF_L, M1_N], Position.UB)
    ub_out = DBuff(DT.bfloat16, [HALF_L, M1_N], Position.UB)

    bhc_count = B * H * C
    bhc_per_core = CeilDiv(bhc_count, GetCubeNum())
    bhc_begin = Var(bhc_per_core * GetCubeIdx())
    bhc_end = Min(bhc_begin + bhc_per_core, bhc_count)

    tile_cnt = Var(0)
    half_rows = CeilDiv(L, 2)

    with auto_sync():
        for bhc in range(bhc_begin, bhc_end):
            c_idx = Var(bhc // (B * H))
            bh_remainder = Var(bhc % (B * H))
            b_idx = Var(bh_remainder // H)
            h_idx = Var(bh_remainder % H)
            row_begin = Var(GetSubBlockIdx() * half_rows)
            row_end = Min(row_begin + half_rows, L)
            row_count = Var(row_end - row_begin)

            l1_q[tile_cnt] <<= q_i[b_idx, h_idx, c_idx, 0:L, 0:D]
            l1_k[tile_cnt] <<= k_i[b_idx, h_idx, c_idx, 0:L, 0:D]
            matmul(l0c_attn[tile_cnt], l1_q[tile_cnt], l1_k[tile_cnt])

            cvmutex.lock()
            ub_attn[tile_cnt] <<= l0c_attn[tile_cnt]
            cvmutex.ready()

            cvmutex.wait()
            attn_causal_keep_vf(ub_attn[tile_cnt], ub_out[tile_cnt], row_begin, row_count)
            cvmutex.free()

            attn[b_idx, h_idx, c_idx, row_begin:row_end, 0:M1_N] <<= ub_out[tile_cnt][0:row_count, 0:M1_N]
            tile_cnt += 1

    return attn


def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "chunk_delta_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace


def run(
    q_i, k_i,
    simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=True,
):
    B = int(q_i.shape[0])
    H = int(q_i.shape[1])
    C = int(q_i.shape[2])
    device = q_i.device
    attn = torch.empty((B, H, C, L, L), dtype=torch.bfloat16, device=device)
    trace_path = _trace_path(trace, out_dir, "sub1")

    saved_sim_config = getattr(sub1_kernel, "_simulator_config", None)
    if simulator:
        sub1_kernel._simulator_config = SimulatorConfig(
            core_count=SIM_CORE_COUNT,
            execution_timeout_s=SIM_TIMEOUT_S,
            trace_enabled=trace_path is not None,
        )

    try:
        result = OpExec(
            sub1_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            profile=profile,
            gen_only=gen_only,
            skip_compile=skip_compile,
        )(
            q_i,
            k_i,
            attn,
            B,
            H,
            C,
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr(sub1_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                sub1_kernel._simulator_config = saved_sim_config

    return result


if __name__ == "__main__":
    import sys
    from pathlib import Path

    _ROOT = Path(__file__).resolve().parents[4]
    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
    from projects.a5.delta_rule_fwd.refs.oracle import expected_sub1

    torch.manual_seed(42)
    B = 1
    H = 1
    C = 2
    q_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)
    k_i = (torch.randn((B, H, C, L, D), dtype=torch.float32) * 0.125).to(torch.bfloat16)

    result = run(q_i, k_i, simulator=True)
    outputs = result if isinstance(result, tuple) else (result,)
    attn_got = outputs[0]
    attn_ref = expected_sub1(q_i, k_i)
    max_abs = (attn_got.float() - attn_ref.float()).abs().max().item()
    print("sub1", tuple(attn_got.shape), attn_got.dtype, f"max_abs={max_abs:.6e}")
    torch.testing.assert_close(attn_got.float(), attn_ref.float(), rtol=2e-3, atol=2e-3)
    print("sub1 OK")
