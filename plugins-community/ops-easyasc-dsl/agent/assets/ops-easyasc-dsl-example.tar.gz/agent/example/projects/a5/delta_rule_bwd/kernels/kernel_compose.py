"""kernel_compose (ungated): the full chunked delta_rule backward = the 5 DSL stages wired.

scan_split (local + state) -> wu -> inverse_preprocess -> finalize, returning the
public gradients (d_query, d_key, d_value, d_beta). `value_wu` is accepted for
input-contract parity with the forward handoff but is not consumed by the backward.
"""
import sys
from pathlib import Path

import torch

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

L = 64
D = 128

from finalize_bwd import run as run_finalize_bwd  # noqa: E402
from inverse_preprocess_bwd import run as run_inverse_preprocess_bwd  # noqa: E402
from scan_split_bwd import run as run_scan_bwd  # noqa: E402
from wu_bwd import run as run_wu_bwd  # noqa: E402


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "delta_rule_bwd_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))
    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def _child_out_dir(out_dir, name):
    if not out_dir:
        return ""
    path = Path(out_dir) / name
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def run(query, key, value, beta, grad_output, wu_attn_bf16, value_wu, k_cumdecay, state_after_history, v_new_history, grad_final_state, simulator=True, trace=None, gen_only=False, out_dir="", skip_compile=False, profile=False):
    _ = value_wu  # forward handoff; not consumed by the backward
    scan = run_scan_bwd(
        query, key, grad_output, k_cumdecay, state_after_history, v_new_history,
        grad_final_state, simulator=simulator,
        trace=_child_trace(trace, out_dir, "scan_bwd"), gen_only=gen_only,
        out_dir=_child_out_dir(out_dir, "scan_bwd"), skip_compile=skip_compile,
        profile=profile,
    )
    wu = run_wu_bwd(
        key, value, beta, wu_attn_bf16, scan[2], scan[3],
        simulator=simulator, trace=_child_trace(trace, out_dir, "wu_bwd"),
        gen_only=gen_only, out_dir=_child_out_dir(out_dir, "wu_bwd"),
        skip_compile=skip_compile, profile=profile,
    )
    inv = run_inverse_preprocess_bwd(
        key, beta, wu_attn_bf16, wu[0],
        simulator=simulator, trace=_child_trace(trace, out_dir, "inverse_preprocess_bwd"),
        gen_only=gen_only, out_dir=_child_out_dir(out_dir, "inverse_preprocess_bwd"),
        skip_compile=skip_compile, profile=profile,
    )
    final_tail = run_finalize_bwd(
        key, value, beta, scan[1], wu[1], wu[2], inv[0], inv[1],
        simulator=simulator, trace=_child_trace(trace, out_dir, "finalize_bwd"),
        gen_only=gen_only, out_dir=_child_out_dir(out_dir, "finalize_bwd"),
        skip_compile=skip_compile, profile=profile,
    )
    return (scan[0],) + tuple(final_tail)
