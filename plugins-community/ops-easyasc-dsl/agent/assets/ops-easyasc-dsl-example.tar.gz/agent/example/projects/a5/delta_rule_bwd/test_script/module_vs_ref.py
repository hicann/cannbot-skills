"""Module-by-module kernel-vs-reference checks for canonical delta_rule_bwd.

Ungated analog of `gdn_bwd/test_script/module_vs_ref.py`. Each module is run in
the simulator and compared against its PyTorch reference, fed reference upstream
tensors by default so the first bad module is isolated.

Examples:
  python projects/a5/delta_rule_bwd/test_script/module_vs_ref.py --module scan_local_bwd
  python projects/a5/delta_rule_bwd/test_script/module_vs_ref.py --module all --B 1 --H 2 --C 2
"""

import argparse
import importlib
import sys
from pathlib import Path

import torch


SCRIPT_DIR = Path(__file__).resolve().parent
PLAN_DIR = SCRIPT_DIR.parent
REFS_DIR = PLAN_DIR / "refs"
KERNELS_DIR = PLAN_DIR / "kernels"


def _find_repo_root(start):
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


REPO_ROOT = _find_repo_root(SCRIPT_DIR)
for _path in (str(REPO_ROOT), str(REFS_DIR), str(KERNELS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from common import make_inputs  # noqa: E402
from common import core_scan_bwd, wu_recompute_bwd, inverse_preprocess_bwd as ref_inv_fn  # noqa: E402
from scan_local_bwd_ref import subkernel as ref_scan_local_bwd  # noqa: E402
from scan_split_bwd_ref import subkernel as ref_scan_split_bwd  # noqa: E402
from scan_state_bwd_ref import subkernel as ref_scan_state_bwd  # noqa: E402
from wu_bwd_ref import subkernel as ref_wu_bwd  # noqa: E402
from inverse_preprocess_bwd_ref import subkernel as ref_inverse_preprocess_bwd  # noqa: E402
from finalize_bwd_ref import subkernel as ref_finalize_bwd  # noqa: E402
from oracle import oracle as ref_oracle  # noqa: E402


# Default acceptance bar = the project's 2e-3 bf16 budget (the same bar
# check_compose_vs_ref.py uses). The kernels match the bf16-cube ref to ~float eps
# in the simulator, but on real hardware the cube/fixpipe rounding diverges from the
# simulated bf16 model by up to ~1e-3 (scales with input magnitude; make_inputs uses
# scale=0.05), which the 5e-4 common.ATOL/RTOL is too tight for. Pass --atol/--rtol
# to tighten back (e.g. 5e-4) for a strict simulator-only check.
TOL = 2e-3


# All modules have a DSL kernel implemented. Upstream tensors are fed from the
# refs (isolating the first bad module).
IMPLEMENTED = ["scan_local_bwd", "scan_state_bwd", "scan_split_bwd", "wu_bwd", "inverse_preprocess_bwd", "finalize_bwd", "compose"]
ALL_MODULES = ["scan_local_bwd", "scan_state_bwd", "scan_split_bwd", "wu_bwd", "inverse_preprocess_bwd", "finalize_bwd", "compose"]
MODULE_OUTPUT_NAMES = {
    "scan_local_bwd": ["d_score_tmp", "d_v_attn_tmp"],
    "scan_state_bwd": ["d_q_core", "d_k_core", "d_value_wu", "d_k_cumdecay"],
    "scan_split_bwd": ["d_q_core", "d_k_core", "d_value_wu", "d_k_cumdecay"],
    "wu_bwd": ["d_wu", "d_v_beta", "d_k_beta_wu"],
    "inverse_preprocess_bwd": ["d_k_pre", "d_k_beta_pre"],
    "finalize_bwd": ["d_key", "d_value", "d_beta"],
    "compose": ["d_query", "d_key", "d_value", "d_beta"],
}


def _as_tuple(value):
    return value if isinstance(value, tuple) else (value,)


def _kernel_run(name):
    return importlib.import_module(name).run


def _krun(name, args, options):
    """Invoke a kernel's run() with mode/profile/out_dir threaded from options."""
    out_dir = str(Path(options.out_dir) / name) if options.out_dir else ""
    return _kernel_run(name)(
        *args, simulator=(options.mode == "simulator"), profile=options.profile, out_dir=out_dir,
    )


def _compare(module_name, actual, expected, atol, rtol):
    actual = _as_tuple(actual)
    expected = _as_tuple(expected)
    names = MODULE_OUTPUT_NAMES.get(module_name, [])
    if len(actual) != len(expected):
        print("  [%s] arity FAIL actual=%d expected=%d" % (module_name, len(actual), len(expected)))
        return False
    ok = True
    for idx, (act, exp) in enumerate(zip(actual, expected)):
        name = names[idx] if idx < len(names) else "output%d" % idx
        act_f, exp_f = act.float(), exp.float()
        diff = (act_f - exp_f).abs()
        max_abs = float(diff.max()) if diff.numel() else 0.0
        max_rel = float((diff / exp_f.abs().clamp_min(1e-12)).max()) if diff.numel() else 0.0
        close = bool(torch.isclose(act_f, exp_f, atol=atol, rtol=rtol).all()) and bool(torch.isfinite(act_f).all())
        print("  [%s.%s] %s shape=%s dtype=%s max_abs=%.3e max_rel=%.3e"
              % (module_name, name, "OK" if close else "FAIL", tuple(act.shape), act.dtype, max_abs, max_rel))
        ok = ok and close
    return ok


def _ref_upstream(full):
    """Reference upstream tensors, computed once per case (make_inputs indices:
    0 query,1 key,2 value,3 beta,4 grad_output,5 wu_attn_bf16,6 value_wu,
    7 k_cumdecay,8 state_after_history,9 v_new_history,10 grad_final_state)."""
    local = ref_scan_local_bwd(full[0], full[1], full[4], full[9])  # (d_score_tmp, d_v_attn_tmp)
    scan = core_scan_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])  # (d_q,d_k,d_value_wu,d_k_cumdecay)
    wu = wu_recompute_bwd(full[1], full[2], full[3], full[5], scan[2], scan[3])  # (d_wu,d_v_beta,d_k_beta)
    inv = ref_inv_fn(full[1], full[3], full[5], wu[0])  # (d_k_pre, d_k_beta_pre)
    return local, scan, wu, inv


def run_module(module_name, full, options):
    local, scan, wu, inv = _ref_upstream(full)
    if module_name == "scan_local_bwd":
        actual = _krun("scan_local_bwd", (full[0], full[1], full[4], full[9]), options)
        expected = ref_scan_local_bwd(full[0], full[1], full[4], full[9])
    elif module_name == "scan_state_bwd":
        actual = _krun("scan_state_bwd", (full[0], full[1], full[4], full[7], full[8], full[10], local[0], full[9], local[1]), options)
        expected = ref_scan_state_bwd(full[0], full[1], full[4], full[7], full[8], full[10], local[0], full[9], local[1])
    elif module_name == "scan_split_bwd":
        actual = _krun("scan_split_bwd", (full[0], full[1], full[4], full[7], full[8], full[9], full[10]), options)
        expected = ref_scan_split_bwd(full[0], full[1], full[4], full[7], full[8], full[9], full[10])
    elif module_name == "wu_bwd":
        actual = _krun("wu_bwd", (full[1], full[2], full[3], full[5], scan[2], scan[3]), options)
        expected = ref_wu_bwd(full[1], full[2], full[3], full[5], scan[2], scan[3])
    elif module_name == "inverse_preprocess_bwd":
        actual = _krun("inverse_preprocess_bwd", (full[1], full[3], full[5], wu[0]), options)
        expected = ref_inverse_preprocess_bwd(full[1], full[3], full[5], wu[0])
    elif module_name == "finalize_bwd":
        actual = _krun("finalize_bwd", (full[1], full[2], full[3], scan[1], wu[1], wu[2], inv[0], inv[1]), options)
        expected = ref_finalize_bwd(full[1], full[2], full[3], scan[0], scan[1], wu[1], wu[2], inv[0], inv[1])[1:]  # drop d_q passthrough
    elif module_name == "compose":
        actual = _krun("kernel_compose", tuple(full), options)
        expected = ref_oracle(*full)
    else:
        raise ValueError("module %r not implemented" % module_name)
    return _compare(module_name, actual, expected, options.atol, options.rtol)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--module", action="append", default=None)
    parser.add_argument("--seed", type=int, default=20260519)
    parser.add_argument("--B", type=int, default=1)
    parser.add_argument("--H", type=int, default=2)
    parser.add_argument("--C", type=int, default=4)  # >=3 exercises the multi-update d_state recurrence
    parser.add_argument("--atol", type=float, default=TOL)
    parser.add_argument("--rtol", type=float, default=TOL)
    parser.add_argument("--stop-on-fail", action="store_true")
    parser.add_argument("--mode", choices=["simulator", "onboard"], default="simulator",
                        help="simulator runs locally; onboard builds+runs on the Ascend box")
    parser.add_argument("--profile", action="store_true",
                        help="profile the kernel (onboard: emit AVG timing; needs --out-dir)")
    parser.add_argument("--out-dir", default="",
                        help="base out_dir; each module writes to <out-dir>/<kernel>")
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)

    requested = args.module or IMPLEMENTED
    modules = []
    for item in requested:
        modules.extend(IMPLEMENTED if item == "all" else [item])

    torch.manual_seed(args.seed)
    full = make_inputs(args.B, args.H, args.C)
    print("=== seed=%d shape=(B=%d,H=%d,C=%d) ===" % (args.seed, args.B, args.H, args.C))
    all_ok = True
    for module_name in modules:
        print("[%s]" % module_name)
        ok = run_module(module_name, full, args)
        all_ok = ok and all_ok
        if not ok and args.stop_on_fail:
            break
    print("delta_rule_bwd module-vs-ref %s" % ("OK" if all_ok else "FAIL"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
