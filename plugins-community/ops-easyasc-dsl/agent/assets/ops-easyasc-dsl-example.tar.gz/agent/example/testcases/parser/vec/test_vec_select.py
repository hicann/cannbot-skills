import pytest

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


def test_vec_select_tensor_tensor_codegen_stages_addr_in_user_buffer() -> None:
    @kernel()
    def select_tensor_tensor_codegen(inp: GMTensor):
        dst = Tensor(DT.float, [1, 64], Position.UB)
        src1 = Tensor(DT.float, [1, 64], Position.UB)
        src2 = Tensor(DT.float, [1, 64], Position.UB)
        selmask = Tensor(DT.uint8, [1, 64], Position.UB)
        tmp_addr = Tensor(DT.uint32, [1, 8], Position.UB)  # one 32B block

        select(dst, selmask, src1, src2, SelectMode.TENSOR_TENSOR, tmp_addr_buf=tmp_addr)
        return inp

    inp = GMTensor(DT.float, [1, 1])
    select_tensor_tensor_codegen(inp)
    _, vec_code = translate_split(select_tensor_tensor_codegen.instructions, "select_tensor_tensor_codegen")

    # TENSOR_TENSOR stages the selMask address into the caller's tmp_addr_buf (mode 2,
    # per-repeat 256/sizeof(T) selMask bits): Duplicate the GetPhyAddr() into the buffer via the
    # count overload (writes exactly one 32B block / 8 uint32 and self-manages the vector mask),
    # SetCmpMask it, then the no-selMask-tensor Select reads the SPR. There is no
    # SetCmpMask(selmask) (the old contents-into-one-register path was wrong on HW for
    # repeat>1) and no implicit CANN TMP_UB_OFFSET scratch.
    dup_idx = vec_code.index("Duplicate(")
    assert ".GetPhyAddr()" in vec_code[dup_idx:dup_idx + 200]
    assert "(int32_t)8" in vec_code[dup_idx:dup_idx + 200]  # count overload, 32B not 256B
    setcmp_idx = vec_code.index("SetCmpMask(", dup_idx)
    select_idx = vec_code.index("Select<float, SELMODE::VSEL_TENSOR_TENSOR_MODE>", setcmp_idx)
    assert dup_idx < setcmp_idx < select_idx


def test_vec_select_tensor_tensor_requires_explicit_tmp_addr_buf() -> None:
    dst = Tensor(DT.float, [1, 64], Position.UB)
    src1 = Tensor(DT.float, [1, 64], Position.UB)
    src2 = Tensor(DT.float, [1, 64], Position.UB)
    selmask = Tensor(DT.uint8, [1, 64], Position.UB)

    # easyasc must NOT implicitly borrow CANN's TMP_UB_OFFSET scratch -- the caller is
    # required to supply the selMask-address staging buffer explicitly.
    with pytest.raises(ValueError, match="requires an explicit"):
        select(dst, selmask, src1, src2, SelectMode.TENSOR_TENSOR, tmp_addr_buf=None)


@pytest.mark.parametrize("alias_src", ["src1", "src2"])
def test_vec_select_tensor_tensor_stub_rejects_dst_src_alias(alias_src: str) -> None:
    dst = Tensor(DT.float, [1, 64], Position.UB)
    src = Tensor(DT.float, [1, 64], Position.UB)
    selmask = Tensor(DT.uint8, [1, 64], Position.UB)
    src1 = dst if alias_src == "src1" else src
    src2 = dst if alias_src == "src2" else src

    with pytest.raises(ValueError, match="requires dst address to differ"):
        select(dst, selmask, src1, src2, SelectMode.TENSOR_TENSOR)


def test_vec_select_tensor_tensor_rejects_undersized_tmp_addr_buf() -> None:
    dst = Tensor(DT.float, [1, 64], Position.UB)
    src1 = Tensor(DT.float, [1, 64], Position.UB)
    src2 = Tensor(DT.float, [1, 64], Position.UB)
    selmask = Tensor(DT.uint8, [1, 64], Position.UB)
    tmp_addr = Tensor(DT.uint32, [1, 4], Position.UB)  # 16B, < one 32B block

    # The Duplicate count overload writes 8 uint32 (32B); a smaller buffer overflows on HW, and
    # the simulator (which uses selmask directly) would not catch it -- so the stub must.
    with pytest.raises(ValueError, match="must hold >= 8 uint32"):
        select(dst, selmask, src1, src2, SelectMode.TENSOR_TENSOR, tmp_addr_buf=tmp_addr)
