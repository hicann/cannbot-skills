import warnings

import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import (
    MicroRuntime,
    VfPublicationWarning,
)
from easyasc.utils.instruction import Instruction


WIDTH = 64


@vf()
def vf_barrier_marker_for_sim(buf: Tensor):
    vf_barrier(VfPipe.STORE, VfPipe.LOAD)


@kernel()
def run_vf_barrier_passthrough(src: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.float, [1, WIDTH], Position.UB)
    with auto_sync():
        if GetVecIdx() == 0:
            ub <<= src[0:1, 0:WIDTH]
            vf_barrier_marker_for_sim(ub)
            dst[0:1, 0:WIDTH] <<= ub
    return dst


def _vf_warnings(records):
    return [r for r in records if "barrier" in str(r.message)]


# --- codegen + simulator no-op: barrier still lowers and runs ---

def test_vf_barrier_codegen_store_to_load() -> None:
    @vf()
    def barrier_only(buf: Tensor):
        vf_barrier(VfPipe.STORE, VfPipe.LOAD)

    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    barrier_only(buf)
    code = translate(barrier_only.instructions)
    assert (
        "MicroAPI::LocalMemBar<MicroAPI::MemType::VEC_STORE, "
        "MicroAPI::MemType::VEC_LOAD>();"
    ) in code


def test_vf_barrier_rejects_non_vf_pipe() -> None:
    @vf()
    def invalid_barrier(buf: Tensor):
        vf_barrier(Pipe.V, VfPipe.LOAD)  # type: ignore[arg-type]

    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    with pytest.raises(TypeError, match="src must be VfPipeType"):
        invalid_barrier(buf)


def test_vf_barrier_is_simulator_noop() -> None:
    src = torch.ones((1, WIDTH), dtype=torch.float32)
    dst = torch.zeros_like(src)
    out = OpExec(run_vf_barrier_passthrough, simulator=True)(src, dst, WIDTH)
    assert torch.equal(out, src)


# --- static lowering stays silent; simulator owns exact byte-range warnings ---

def test_static_vf_barrier_check_stays_silent_without_runtime_ranges() -> None:
    @vf()
    def missing(buf: Tensor):
        reg = Reg(DT.float)
        reg_to_ub(buf, reg)
        reg <<= buf

    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        missing(buf)
    assert not _vf_warnings(rec)


def test_static_vf_barrier_check_silent_for_disjoint_dbuff_slots() -> None:
    @vf()
    def two_slots(slot0: Tensor, slot1: Tensor):
        reg = Reg(DT.float)
        reg_to_ub(slot0, reg)
        reg_to_ub(slot1, reg)

    dbuf = DBuff(DT.float, [1, WIDTH], Position.UB)
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        two_slots(dbuf[0], dbuf[1])
    assert not _vf_warnings(rec)


# --- authoritative sim hazard detection: exact byte ranges, no false positives ---

def _rt():
    return MicroRuntime()


def test_sim_warns_store_then_overlapping_load() -> None:
    buf = torch.zeros(WIDTH, dtype=torch.float32)
    rt = _rt()
    rt._vf_on_store(buf[0:32], 32)
    with pytest.warns(UserWarning, match="RAW hazard: store -> load"):
        rt._vf_on_load(buf[16:48], 32)


def test_sim_silent_for_disjoint_store_load() -> None:
    buf = torch.zeros(WIDTH, dtype=torch.float32)
    rt = _rt()
    rt._vf_on_store(buf[0:32], 32)
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        rt._vf_on_load(buf[32:64], 32)
    assert not _vf_warnings(rec)


def test_sim_warns_store_then_overlapping_store() -> None:
    buf = torch.zeros(WIDTH, dtype=torch.float32)
    rt = _rt()
    rt._vf_on_store(buf[0:32], 32)
    with pytest.warns(UserWarning, match="WAW hazard: store -> store"):
        rt._vf_on_store(buf[0:32], 32)


def test_sim_silent_for_load_then_overlapping_store_war_is_ignored() -> None:
    buf = torch.zeros(WIDTH, dtype=torch.float32)
    rt = _rt()
    rt._vf_on_load(buf[0:32], 32)
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        rt._vf_on_store(buf[16:48], 32)
    assert not _vf_warnings(rec)


def test_sim_silent_for_disjoint_load_store() -> None:
    buf = torch.zeros(WIDTH, dtype=torch.float32)
    rt = _rt()
    rt._vf_on_load(buf[0:32], 32)
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        rt._vf_on_store(buf[32:64], 32)
    assert not _vf_warnings(rec)


def test_sim_warns_for_overlapping_multi_range_store_store() -> None:
    buf = torch.zeros(WIDTH, dtype=torch.float32)
    rt = _rt()
    rt._vf_on_store_indices(buf, torch.tensor([0, 2, 4], dtype=torch.long))
    with pytest.warns(UserWarning, match="WAW hazard: store -> store"):
        rt._vf_on_store_indices(buf, torch.tensor([1, 4], dtype=torch.long))


def test_sim_silent_for_disjoint_multi_range_store() -> None:
    buf = torch.zeros(WIDTH, dtype=torch.float32)
    rt = _rt()
    rt._vf_on_store_indices(buf, torch.tensor([0, 2, 4], dtype=torch.long))
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        rt._vf_on_store_indices(buf, torch.tensor([1, 3, 5], dtype=torch.long))
    assert not _vf_warnings(rec)


def test_sim_store_to_load_barrier_clears_raw_hazard() -> None:
    buf = torch.zeros(WIDTH, dtype=torch.float32)
    rt = _rt()
    rt._vf_on_store(buf[0:32], 32)
    rt._vf_store_to_load.clear()  # what micro_vf_barrier(STORE, LOAD) does
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        rt._vf_on_load(buf[0:32], 32)
    assert not _vf_warnings(rec)


def _dynamic_gather_scatter_program(output_name="buf"):
    buf_ref = type("TensorRef", (), {"name": "buf"})()
    output_ref = type("TensorRef", (), {"name": output_name})()
    index_i32 = Reg(DT.int, name="index_i32")
    index = Reg(DT.uint32, name="index")
    value = Reg(DT.float, name="value")
    active = MaskReg(DT.float, init_mode=MaskType.ALL, name="active")
    loop_index = Var(0, dtype=DT.uint16, name="iteration")
    return {
        "instructions": [
            Instruction("create_reg", reg=index_i32),
            Instruction("create_reg", reg=value),
            Instruction("create_maskreg", reg=active),
            Instruction("micro_arange", dst=index_i32, start=0, step=1),
            Instruction("micro_reg_reinterpret", dst=index, src=index_i32),
            Instruction(
                "micro_datacopygather", dst=value, src=buf_ref,
                index=index, mask=active,
            ),
            Instruction(
                "micro_datacopyscatter", dst=buf_ref, src=value,
                index=index, mask=active,
            ),
            Instruction(
                "micro_vf_barrier", src="VEC_STORE", dst="VEC_LOAD",
            ),
            Instruction(
                "micro_vf_barrier", src="VEC_STORE", dst="VEC_STORE",
            ),
            Instruction(
                "start_micro_loop", var=loop_index,
                start=0, stop=1, step=1,
            ),
            Instruction(
                "micro_datacopygather", dst=value, src=buf_ref,
                index=index, mask=active,
            ),
            Instruction(
                "micro_datacopyscatter", dst=output_ref, src=value,
                index=index, mask=active,
            ),
            Instruction("end_loop"),
        ],
    }


def test_sim_warns_for_barriered_same_base_dynamic_recurrence() -> None:
    buf = torch.arange(WIDTH, dtype=torch.float32)
    runtime = MicroRuntime()
    with pytest.warns(VfPublicationWarning, match="may not publish on A5"):
        runtime.execute_call_micro(
            _dynamic_gather_scatter_program(),
            {"buf": buf}, {}, SharedMemoryStore(),
        )


def test_sim_stays_silent_for_immutable_gather_and_separate_output() -> None:
    buf = torch.arange(WIDTH, dtype=torch.float32)
    output = torch.zeros_like(buf)
    runtime = MicroRuntime()
    with warnings.catch_warnings(record=True) as records:
        warnings.simplefilter("always")
        runtime.execute_call_micro(
            _dynamic_gather_scatter_program(output_name="output"),
            {"buf": buf, "output": output}, {}, SharedMemoryStore(),
        )
    assert not any(
        isinstance(record.message, VfPublicationWarning)
        for record in records
    )


def _large_dynamic_ub_program(loop_regions: int, opname="micro_ub2reg"):
    loop_index = Var(0, dtype=DT.uint16, name="block_iteration")
    buf = Tensor(DT.float, [1, WIDTH], Position.UB, name="block_buf")
    dynamic_buf = buf[loop_index]
    instructions = []
    for _ in [None] * loop_regions:
        instructions.extend((
            Instruction(
                "start_micro_loop", var=loop_index,
                start=0, stop=1, step=1,
            ),
            Instruction("end_loop"),
        ))
    ref_name = "src" if opname.startswith("micro_ub2reg") else "dst"
    instructions.append(Instruction(opname, **{ref_name: dynamic_buf}))
    return instructions


@pytest.mark.parametrize(
    "opname",
    ("micro_ub2reg", "micro_reg2ub", "micro_ub2regcont", "micro_reg2ubcont"),
)
def test_sim_warns_for_large_vf_dynamic_ub_access(opname) -> None:
    runtime = MicroRuntime()
    with pytest.warns(
        VfPublicationWarning, match="runtime-addressed UB load/store",
    ):
        runtime._vf_warn_large_dynamic_ub_access(
            _large_dynamic_ub_program(32, opname),
        )


def test_sim_stays_silent_below_large_vf_dynamic_ub_threshold() -> None:
    runtime = MicroRuntime()
    with warnings.catch_warnings(record=True) as records:
        warnings.simplefilter("always")
        runtime._vf_warn_large_dynamic_ub_access(
            _large_dynamic_ub_program(31),
        )
    assert not any(
        isinstance(record.message, VfPublicationWarning)
        for record in records
    )
