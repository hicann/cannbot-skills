"""The BT ping-pong slot is sized from ``bt_cap``, not a hardcoded device figure.

``bt_cap`` is the **total** depth-2 bias-table capacity, so one ``DBuff`` slot
owns half of it: A2/A3 0.5 KB -> 2 x 256 B (64 fp32), A5/A5PR 4 KB -> 2 x 2 KB
(512 fp32). Both hardcodings have shipped and both were wrong in one direction:
the A5 figure put A2's slot 1 at offset 2 KB, outside BT, and faulted on
hardware (2026-06-12); the A2 figure was later hardcoded in its place and gave
an A5 cube kernel an eighth of its bias table, silently, because nothing here
covered it.
"""
import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.kernelbase.kernelbase import _bt_slot_elements


@pytest.mark.parametrize("cap_kb, expected_elements", [(0.5, 64), (4, 512)])
def test_slot_is_half_the_total_depth2_capacity(cap_kb, expected_elements, monkeypatch) -> None:
    monkeypatch.setattr(globvars, "bt_cap", cap_kb)
    assert _bt_slot_elements() == expected_elements


@pytest.mark.parametrize("bad", [0, -1, "4", None, True, 0.5001])
def test_unusable_capacity_is_rejected(bad, monkeypatch) -> None:
    monkeypatch.setattr(globvars, "bt_cap", bad)
    with pytest.raises(ValueError):
        _bt_slot_elements()


@pytest.mark.parametrize("cap_kb, expected_elements", [(0.5, 64), (4, 512)])
def test_traced_kernel_allocates_the_derived_slot(cap_kb, expected_elements, monkeypatch) -> None:
    """The buffer a kernel actually gets follows the same rule.

    ``_btbuf`` is built while the kernel body is traced, so re-tracing under a
    different capacity must re-size it -- this is the value a cube kernel's
    bias ping-pong is bounded by.
    """
    @kernel()
    def bt_capacity_probe_kernel(inp: GMTensor, out: GMTensor):
        return out

    monkeypatch.setattr(globvars, "bt_cap", cap_kb)
    bt_capacity_probe_kernel(GMTensor(DT.half, [1, 16]), GMTensor(DT.half, [1, 16]))
    assert bt_capacity_probe_kernel._btbuf.shape == [1, expected_elements]
