from pathlib import Path

import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate_split

# The compiler requires a non-returned input tensor in the kernel entry; these
# kernels hand `src`/`out` back without reading a second buffer, so `gate` is
# never read.
GATE = torch.zeros((1, 1), dtype=torch.float16)


def _half_cols_for_kb(size_kb: int) -> int:
    return (int(size_kb) * 1024) // 2


def _tensor_specs_by_name(program):
    return {
        str(spec["name"]): spec
        for spec in program.metadata.get("tensor_specs", [])
    }


def _numel(shape) -> int:
    total = 1
    for dim in shape:
        total *= int(dim)
    return total


PLAIN_UB_KB = 150
DBUF_SLOT_KB = 80
TMP_UB_KB = 140


@kernel()
def run_reset_cache_large_ub(gate: GMTensor, src: GMTensor, contract: Var):
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage0")
    reset_cache()
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage1")
    if GetVecIdx() == 0:
        sim_print("reset-cache-plain")
    return src


@kernel()
def run_no_reset_large_ub(gate: GMTensor, src: GMTensor, contract: Var):
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage0")
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage1")
    if GetVecIdx() == 0:
        sim_print("no-reset-plain")
    return src


# Pass-through kernels: they only exercise UB allocation and hand the buffer
# back untouched, so the simulator seeds it rather than poisoning it.
run_reset_cache_large_ub._simulator_seed_outputs = True


@kernel()
def run_reset_cache_dbuf_then_tensor(gate: GMTensor, src: GMTensor, contract: Var):
    buf = DBuff(DT.half, [1, _half_cols_for_kb(DBUF_SLOT_KB)], Position.UB, name="buf")
    reset_cache()
    _ = Tensor(DT.half, [1, _half_cols_for_kb(TMP_UB_KB)], Position.UB, name="tmp")
    _ = buf[0]
    if GetVecIdx() == 0:
        sim_print("reset-cache-buffer")
    return src


run_reset_cache_dbuf_then_tensor._simulator_seed_outputs = True


@kernel()
def inspect_reset_cache_control_flow_offsets(src: GMTensor):
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage0")
    reset_cache()
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage1")
    if GetVecIdx() == 0:
        sim_print("inspect-reset-cache")
    return src


@kernel()
def inspect_reset_cache_linear_offsets(src: GMTensor):
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage0")
    reset_cache()
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage1")
    return src


@kernel()
def inspect_no_reset_linear_offsets(src: GMTensor):
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage0")
    _ = Tensor(DT.half, [1, _half_cols_for_kb(PLAIN_UB_KB)], Position.UB, name="stage1")
    return src


@kernel()
def inspect_no_reset_small_linear_offsets(src: GMTensor):
    _ = Tensor(DT.half, [1, 64], Position.UB, name="stage0")
    _ = Tensor(DT.half, [1, 64], Position.UB, name="stage1")
    return src


@kernel()
def inspect_mixed_dtype_linear_offsets(src: GMTensor):
    _ = Tensor(DT.float, [1, 64], Position.UB, name="f32_stage0")
    _ = Tensor(DT.half, [1, 64], Position.UB, name="f16_stage1")
    _ = Tensor(DT.uint8, [1, 64], Position.UB, name="u8_stage2")
    _ = Tensor(DT.float, [1, 64], Position.UB, name="f32_stage3")
    return src


@kernel()
def inspect_mixed_dtype_control_flow_offsets(src: GMTensor):
    _ = Tensor(DT.float, [1, 64], Position.UB, name="f32_stage0")
    _ = Tensor(DT.half, [1, 64], Position.UB, name="f16_stage1")
    _ = Tensor(DT.uint8, [1, 64], Position.UB, name="u8_stage2")
    _ = Tensor(DT.float, [1, 64], Position.UB, name="f32_stage3")
    if GetVecIdx() == 0:
        sim_print("inspect-mixed-dtype-offsets")
    return src


@kernel()
def inspect_qbuff_slots(src: GMTensor):
    qbuf = QBuff(DT.float, [1, 64], Position.UB, name="qbuf")
    _ = qbuf[3]
    return src


def test_sim_reset_cache_reuses_ub_capacity_for_plain_tensors() -> None:
    src = torch.randn((1, 16), dtype=torch.float16)
    out = OpExec(
        run_reset_cache_large_ub,
        "test_sim_reset_cache_reuses_ub_capacity_for_plain_tensors",
        simulator=True,
    )(GATE, src, -1)
    assert torch.equal(out, src)


def test_sim_without_reset_cache_still_enforces_ub_capacity() -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    op = OpExec(
        run_no_reset_large_ub,
        "test_sim_without_reset_cache_still_enforces_ub_capacity",
        simulator=True,
    )
    with pytest.raises(RuntimeError, match="local memory allocation exceeds bank capacity"):
        op(GATE, src, -1)


def test_sim_reset_cache_reuses_ub_capacity_for_buffer_decls() -> None:
    src = torch.randn((1, 16), dtype=torch.float16)
    out = OpExec(
        run_reset_cache_dbuf_then_tensor,
        "test_sim_reset_cache_reuses_ub_capacity_for_buffer_decls",
        simulator=True,
    )(GATE, src, -1)
    assert torch.equal(out, src)


def test_control_flow_bridge_reset_cache_resets_local_storage_offsets() -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    inspect_reset_cache_control_flow_offsets(src)
    program = inspect_reset_cache_control_flow_offsets.build_simulator_program()
    specs = _tensor_specs_by_name(program)
    assert specs["stage0"]["storage_offset_bytes"] == 0
    assert specs["stage1"]["storage_offset_bytes"] == 0
    assert "storage_offset_resolved" in specs["stage0"]["tags"]
    assert "storage_offset_resolved" in specs["stage1"]["tags"]


def test_legacy_bridge_reset_cache_resets_local_storage_offsets() -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    inspect_reset_cache_linear_offsets(src)
    reset_program = inspect_reset_cache_linear_offsets.build_simulator_program()
    reset_specs = _tensor_specs_by_name(reset_program)
    assert reset_specs["stage0"]["storage_offset_bytes"] == 0
    assert reset_specs["stage1"]["storage_offset_bytes"] == 0

    inspect_no_reset_small_linear_offsets(src)
    linear_program = inspect_no_reset_small_linear_offsets.build_simulator_program()
    linear_specs = _tensor_specs_by_name(linear_program)
    assert linear_specs["stage0"]["storage_offset_bytes"] == 0
    assert linear_specs["stage1"]["storage_offset_bytes"] == _numel(linear_specs["stage0"]["shape"]) * DT.half.size
    assert "storage_offset_resolved" in linear_specs["stage0"]["tags"]
    assert "storage_offset_resolved" in linear_specs["stage1"]["tags"]


def test_mixed_dtype_ub_offsets_are_byte_based_in_legacy_bridge() -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    inspect_mixed_dtype_linear_offsets(src)
    program = inspect_mixed_dtype_linear_offsets.build_simulator_program()
    specs = _tensor_specs_by_name(program)
    assert specs["f32_stage0"]["storage_offset_bytes"] == 0
    assert specs["f16_stage1"]["storage_offset_bytes"] == 64 * DT.float.size
    assert specs["u8_stage2"]["storage_offset_bytes"] == 64 * DT.float.size + 64 * DT.half.size
    assert specs["f32_stage3"]["storage_offset_bytes"] == 64 * DT.float.size + 64 * DT.half.size + 64 * DT.uint8.size


def test_mixed_dtype_ub_offsets_are_byte_based_in_control_flow_bridge() -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    inspect_mixed_dtype_control_flow_offsets(src)
    program = inspect_mixed_dtype_control_flow_offsets.build_simulator_program()
    specs = _tensor_specs_by_name(program)
    assert specs["f32_stage0"]["storage_offset_bytes"] == 0
    assert specs["f16_stage1"]["storage_offset_bytes"] == 64 * DT.float.size
    assert specs["u8_stage2"]["storage_offset_bytes"] == 64 * DT.float.size + 64 * DT.half.size
    assert specs["f32_stage3"]["storage_offset_bytes"] == 64 * DT.float.size + 64 * DT.half.size + 64 * DT.uint8.size


def test_legacy_bridge_allocates_four_qbuff_slots() -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    inspect_qbuff_slots(src)
    program = inspect_qbuff_slots.build_simulator_program()
    specs = _tensor_specs_by_name(program)
    slot_names = sorted(name for name in specs if name.startswith("__bufslot__qbuf_"))
    assert slot_names == [
        "__bufslot__qbuf_0",
        "__bufslot__qbuf_1",
        "__bufslot__qbuf_2",
        "__bufslot__qbuf_3",
    ]
    assert specs["__bufslot__qbuf_3"]["storage_offset_bytes"] == 3 * 64 * DT.float.size


def test_translate_split_keeps_reset_cache_prologue_raw() -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    inspect_reset_cache_linear_offsets(src)
    cube_code, vec_code = translate_split(
        inspect_reset_cache_linear_offsets.instructions,
        "inspect_reset_cache_linear_offsets",
    )

    for code in (cube_code, vec_code):
        stripped_lines = {line.strip() for line in code.splitlines()}
        assert "pipe_ptr->Reset();" in stripped_lines
        assert "OccupyMMTE1Events();" in stripped_lines


def _assert_auto_reset_cache_prologue_is_commented(*paths: Path) -> None:
    marker = "// END: Auto inserted buffers/events/GMTensors"
    for path in paths:
        text = path.read_text(encoding="utf-8")
        prefix, suffix = text.split(marker, 1)
        prefix_lines = {line.strip() for line in prefix.splitlines()}
        suffix_lines = {line.strip() for line in suffix.splitlines()}
        assert "// pipe_ptr->Reset();" in prefix
        assert "// OccupyMMTE1Events();" in prefix
        assert "pipe_ptr->Reset();" not in prefix_lines
        assert "OccupyMMTE1Events();" not in prefix_lines
        assert "pipe_ptr->Reset();" in suffix_lines
        assert "OccupyMMTE1Events();" in suffix_lines


def test_dump_asc_comments_reset_cache_prologue(tmp_path: Path) -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    inspect_reset_cache_linear_offsets(src)
    base = tmp_path / "inspect_reset_cache_linear_offsets"
    inspect_reset_cache_linear_offsets.dump_asc(str(base))
    _assert_auto_reset_cache_prologue_is_commented(
        tmp_path / "inspect_reset_cache_linear_offsets_cube.h",
        tmp_path / "inspect_reset_cache_linear_offsets_vec.h",
    )


def test_dump_kernel_comments_reset_cache_prologue(tmp_path: Path) -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    inspect_reset_cache_linear_offsets(src)
    base = tmp_path / "inspect_reset_cache_linear_offsets_kernel"
    inspect_reset_cache_linear_offsets.dump_kernel(str(base))
    _assert_auto_reset_cache_prologue_is_commented(
        tmp_path / "inspect_reset_cache_linear_offsets_kernel_cube.h",
        tmp_path / "inspect_reset_cache_linear_offsets_kernel_vec.h",
    )
