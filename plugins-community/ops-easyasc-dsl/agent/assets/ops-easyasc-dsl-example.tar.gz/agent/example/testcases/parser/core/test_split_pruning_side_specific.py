import importlib.util

from easyasc.a5 import *
from easyasc.parser.asc import split_instructions


BLK = 128


@vf()
def _abs_add1_vf(x: Tensor, out: Tensor, n_loops: Var, N: Var):
    xreg = Reg(DT.float)
    for i in range(n_loops):
        xreg <<= x[i * 64]
        xreg <<= xreg.abs() + 1.0
        out[i * 64] <<= xreg


@kernel()
def _vec_dead_matmul_counter_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0)

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    xbuf = DBuff(DT.float, [BLK // 2, N], Position.UB)
    outbuf = DBuff(DT.float, [BLK // 2, N], Position.UB)

    cnt = Var(0)
    m_per_core = CeilDiv(M, GetCubeNum())
    m1 = Var(m_per_core * GetCubeIdx())
    m2 = Min(m1 + m_per_core, M)

    with auto_sync():
        for m in range(m1, m2, BLK):
            l1x[cnt] <<= x[m:m + BLK, :]
            l1y[cnt] <<= y[:, :]
            matmul(l0c[cnt], l1x[cnt], l1y[cnt], splitn=True)
            matmul(l0c[cnt], l1x[cnt], l1y[cnt])

            cvmutex.lock()
            xbuf[cnt] <<= l0c[cnt]
            cvmutex.ready()

            cvmutex.wait()
            _abs_add1_vf(xbuf[cnt], outbuf[cnt], BLK // 2 * N // 64, N)
            cvmutex.free()

            valid_m = Min(BLK, m2 - m)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = GetSubBlockIdx()
            row_begin = sb_idx * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin
            z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cnt += 1

    return z


@kernel()
def _side_specific_local_decl_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0)

    keep_l1_dbuf = DBuff(DT.half, [BLK, K], Position.L1, name="keep_l1_dbuf")
    keep_l1_tensor = Tensor(DT.half, [BLK, K], Position.L1, name="keep_l1_tensor")
    keep_l1_tbuf = TBuff(DT.half, [BLK, K], Position.L1, name="keep_l1_tbuf")
    keep_ub_dbuf = DBuff(DT.float, [BLK // 2, N], Position.UB, name="keep_ub_dbuf")
    keep_ub_tensor = Tensor(DT.float, [BLK // 2, N], Position.UB, name="keep_ub_tensor")
    keep_ub_tbuf = TBuff(DT.float, [BLK // 2, N], Position.UB, name="keep_ub_tbuf")

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    xbuf = DBuff(DT.float, [BLK // 2, N], Position.UB)
    outbuf = DBuff(DT.float, [BLK // 2, N], Position.UB)

    _ = keep_l1_dbuf
    _ = keep_l1_tensor
    _ = keep_l1_tbuf
    _ = keep_ub_dbuf
    _ = keep_ub_tensor
    _ = keep_ub_tbuf

    cnt = Var(0)
    m_per_core = CeilDiv(M, GetCubeNum())
    m1 = Var(m_per_core * GetCubeIdx())
    m2 = Min(m1 + m_per_core, M)

    with auto_sync():
        for m in range(m1, m2, BLK):
            l1x[cnt] <<= x[m:m + BLK, :]
            l1y[cnt] <<= y[:, :]
            matmul(l0c[cnt], l1x[cnt], l1y[cnt])

            cvmutex.lock()
            xbuf[cnt] <<= l0c[cnt]
            cvmutex.ready()

            cvmutex.wait()
            _abs_add1_vf(xbuf[cnt], outbuf[cnt], BLK // 2 * N // 64, N)
            cvmutex.free()

            valid_m = Min(BLK, m2 - m)
            half_rows = CeilDiv(valid_m, 2)
            row_begin = GetSubBlockIdx() * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin
            z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cnt += 1

    return z


def _build_split(kernel_fn):
    x = GMTensor(DT.half, [BLK * 2, 128], name="x")
    y = GMTensor(DT.half, [64, 128], name="y")
    z = GMTensor(DT.float, [BLK * 2, 64], name="z")
    m = Var(BLK * 2, name="M")
    n = Var(64, name="N")
    k = Var(128, name="K")
    kernel_fn(x, y, z, m, n, k)
    return split_instructions(list(kernel_fn.instructions))


def _local_decl_names(instructions):
    names = set()
    for inst in instructions:
        if inst.opname not in ("create_dbuf", "create_tbuf", "create_qbuf", "create_tensor"):
            continue
        val = inst.kwargs.get("val", None)
        name = getattr(val, "name", None)
        if isinstance(name, str):
            names.add(name)
    return names


def _declared_var_names(instructions):
    names = set()
    for inst in instructions:
        if inst.opname != "create_var":
            continue
        val = inst.kwargs.get("val", None)
        name = getattr(val, "name", None)
        if isinstance(name, str):
            names.add(name)
    return names


def _load_kernel_module(path: str):
    spec = importlib.util.spec_from_file_location(path.replace("/", "_"), path)
    module = importlib.util.module_from_spec(spec)
    if spec.loader is None:
        raise RuntimeError(f"Failed to load module from {path}")
    spec.loader.exec_module(module)
    return module


def _assert_all_local_tensor_operands_have_defs(instructions) -> None:
    defined = set()
    for inst in instructions:
        if inst.opname == "create_tensor":
            val = inst.kwargs.get("val", None)
            name = getattr(val, "name", None)
            if isinstance(name, str):
                defined.add(name)
        elif inst.opname in ("get_buf", "slice_tensor", "micro_slice_tensor"):
            out = inst.kwargs.get("out", None)
            name = getattr(out, "name", None)
            if isinstance(name, str):
                defined.add(name)
        elif inst.opname == "reinterpret":
            dst = inst.kwargs.get("dst", None)
            name = getattr(dst, "name", None)
            if isinstance(name, str):
                defined.add(name)

        for value in inst.kwargs.values():
            if not isinstance(value, Tensor):
                continue
            if value.position not in (Position.L1, Position.L0A, Position.L0B, Position.L0C, Position.UB):
                continue
            if value.name in defined:
                continue
            source_buf = getattr(value, "source_buf", None)
            if isinstance(source_buf, (DBuff, TBuff, QBuff)):
                continue
            raise AssertionError(
                f"Tensor operand {value.name} used by {inst.opname} has no definition in split instructions"
            )


def test_split_prunes_dead_vec_matmul_counter_chain() -> None:
    _, vec_insts = _build_split(_vec_dead_matmul_counter_kernel)

    local_names = _local_decl_names(vec_insts)
    var_names = _declared_var_names(vec_insts)

    assert "_l0a" not in local_names
    assert "_l0b" not in local_names
    assert "_l0acnt" not in var_names
    assert "_l0bcnt" not in var_names
    assert not any(
        inst.opname == "get_buf" and getattr(inst.kwargs.get("buf", None), "name", None) in {"_l0a", "_l0b"}
        for inst in vec_insts
    )
    assert not any(
        inst.opname == "var_add" and getattr(inst.kwargs.get("out", None), "name", None) in {"_l0acnt", "_l0bcnt"}
        for inst in vec_insts
    )


def test_split_keeps_side_specific_local_decl_exceptions() -> None:
    cube_insts, vec_insts = _build_split(_side_specific_local_decl_kernel)

    cube_names = _local_decl_names(cube_insts)
    vec_names = _local_decl_names(vec_insts)

    for name in {
        "keep_l1_dbuf",
        "keep_l1_tensor",
        "keep_l1_tbuf",
        "keep_ub_dbuf",
        "keep_ub_tensor",
        "keep_ub_tbuf",
    }:
        assert name in cube_names
        assert name in vec_names


def test_split_keeps_cube_tensor_alias_defs_for_transpose_views() -> None:
    module = _load_kernel_module("agent/example/kernels/a5/matmul/matmul_kmkn_fp32_out.py")
    x = GMTensor(DT.half, [128, 128], name="x")
    y = GMTensor(DT.half, [128, 128], name="y")
    z = GMTensor(DT.float, [128, 128], name="z")
    m = Var(128, name="M")
    n = Var(128, name="N")
    k = Var(128, name="K")
    module.matmul_kmkn_fp32_out_kernel(x, y, z, m, n, k)
    cube_insts, _ = split_instructions(list(module.matmul_kmkn_fp32_out_kernel.instructions))
    _assert_all_local_tensor_operands_have_defs(cube_insts)


def test_split_routes_vec_writeback_helper_chain_to_vec_side() -> None:
    cube_insts, vec_insts = _build_split(_side_specific_local_decl_kernel)

    assert any(inst.opname == "ub_to_gm_pad" for inst in vec_insts)
    assert not any(inst.opname == "ub_to_gm_pad" for inst in cube_insts)
    assert any(
        inst.opname == "slice_gm_tensor" and getattr(inst.kwargs.get("src", None), "name", None) == "z"
        for inst in vec_insts
    )
    assert not any(
        inst.opname == "slice_gm_tensor" and getattr(inst.kwargs.get("src", None), "name", None) == "z"
        for inst in cube_insts
    )
    assert not any(
        any(name in str(inst.kwargs) for name in ("half_rows", "row_end", "row_begin", "row_count"))
        for inst in cube_insts
    )
