"""Generated-C++ identifier fences for DSL object names.

Names handed to GMTensor / Tensor / Var / Reg / ... are emitted verbatim as C++
identifiers. C++ keywords and emitted element type names such as ``half`` can
therefore generate code that does not compile. Reject them at the Python call
site.
Sibling of `test_stub_function_device_guard.py` (the `assert_valid_device` fence).
"""
import pytest

from easyasc import globvars
from easyasc.a2 import *  # noqa: F401,F403  (kernel, GMTensor, Tensor, DBuff/TBuff/QBuff, Var, VarList, SEvent, DEvent, reinterpret, split_workspace, Pipe, Position, DT)
from easyasc.parser.asc_utils import dtype_to_cpp
from easyasc.utils.datatype import DataTypeValue, Datatype
from easyasc.utils.reg import Reg, RegList, MaskReg
from easyasc.utils.naming import (
    assert_codegen_safe_identifier,
    assert_not_cpp_keyword,
    CPP_GENERATED_TYPE_IDENTIFIERS,
    CPP_RESERVED_KEYWORDS,
)

_MATCH = "reserved C"  # substring of "...is a reserved C++ keyword..." (no regex metachars)
_TYPE_MATCH = "collides with a generated C"


# --- the helper itself --------------------------------------------------------
def test_helper_rejects_keyword_and_allows_others() -> None:
    with pytest.raises(ValueError, match=_MATCH):
        assert_not_cpp_keyword("new", "Var")
    # case-sensitive: only exact-lowercase keywords match
    assert_not_cpp_keyword("New", "Var")
    assert_not_cpp_keyword("my_score", "Tensor")
    assert_not_cpp_keyword("", "Tensor")     # empty -> caller auto-names
    assert_not_cpp_keyword(None, "Tensor")   # non-str passes through (typed elsewhere)


def test_keyword_set_is_case_sensitive_and_populated() -> None:
    assert {"int", "new", "delete", "template", "class", "float"} <= CPP_RESERVED_KEYWORDS
    assert "Int" not in CPP_RESERVED_KEYWORDS
    assert "my_var" not in CPP_RESERVED_KEYWORDS


def test_generated_type_identifiers_are_separate_from_cpp_keywords() -> None:
    assert {"half", "bfloat16_t", "uint16_t", "float8_e4m3_t"} <= CPP_GENERATED_TYPE_IDENTIFIERS
    emitted_types = {
        dtype_to_cpp(value)
        for value in vars(Datatype).values()
        if isinstance(value, DataTypeValue)
    }
    assert emitted_types - CPP_RESERVED_KEYWORDS <= CPP_GENERATED_TYPE_IDENTIFIERS
    assert "half" not in CPP_RESERVED_KEYWORDS
    assert_not_cpp_keyword("half", "kernel argument")
    with pytest.raises(ValueError, match=_TYPE_MATCH):
        assert_codegen_safe_identifier("half", "kernel argument")
    assert_codegen_safe_identifier("half_width", "kernel argument")


# --- constructors -------------------------------------------------------------
@pytest.mark.parametrize("kw", ["new", "int", "delete", "template", "class"])
def test_buffer_constructors_reject_keyword(kw) -> None:
    with pytest.raises(ValueError, match=_MATCH):
        Tensor(DT.float, [1, 8], Position.UB, name=kw)
    with pytest.raises(ValueError, match=_MATCH):
        DBuff(DT.float, [1, 8], Position.UB, name=kw)
    with pytest.raises(ValueError, match=_MATCH):
        TBuff(DT.float, [1, 8], Position.UB, name=kw)
    with pytest.raises(ValueError, match=_MATCH):
        QBuff(DT.float, [1, 8], Position.UB, name=kw)
    with pytest.raises(ValueError, match=_MATCH):
        GMTensor(DT.float, [4, 8], name=kw)


def test_var_and_varlist_reject_keyword() -> None:
    with pytest.raises(ValueError, match=_MATCH):
        Var(name="new")
    with pytest.raises(ValueError, match=_MATCH):
        VarList(DT.int, 4, name="static")


def test_dsl_objects_reject_generated_type_names() -> None:
    with pytest.raises(ValueError, match=_TYPE_MATCH):
        Tensor(DT.float, [1, 8], Position.UB, name="half")
    with pytest.raises(ValueError, match=_TYPE_MATCH):
        GMTensor(DT.float, [4, 8], name="bfloat16_t")
    with pytest.raises(ValueError, match=_TYPE_MATCH):
        Var(name="uint16_t")


def test_reg_family_rejects_keyword() -> None:
    # Reg/RegList/MaskReg are a5-only micro constructs, so evaluate them under the
    # a5 device (not a2). The fence fires before the active_micro check, so no
    # MicroModule is needed.
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        with pytest.raises(ValueError, match=_MATCH):
            Reg(DT.float, name="float")
        with pytest.raises(ValueError, match=_MATCH):
            RegList(DT.float, 4, name="register")
        with pytest.raises(ValueError, match=_MATCH):
            MaskReg(DT.float, name="operator")
    finally:
        globvars.device_type = saved_device_type


def test_events_reject_keyword() -> None:
    with pytest.raises(ValueError, match=_MATCH):
        SEvent(Pipe.MTE2, Pipe.V, name="new")
    with pytest.raises(ValueError, match=_MATCH):
        DEvent(Pipe.MTE2, Pipe.V, name="delete")


def test_misc_views_reject_keyword() -> None:
    with pytest.raises(ValueError, match=_MATCH):
        split_workspace(DT.float, [1, 8], name="union")
    src = Tensor(DT.float, [1, 8], Position.UB, name="src_ok")
    with pytest.raises(ValueError, match=_MATCH):
        reinterpret(src, DT.int, name="goto")


# --- allowed: valid names construct fine (no false positives) -----------------
def test_valid_names_construct_fine() -> None:
    assert Tensor(DT.float, [1, 8], Position.UB, name="score").name == "score"
    assert Tensor(DT.float, [1, 8], Position.UB, name="New").name == "New"  # capitalized
    assert Var(name="cnt").name == "cnt"
    assert GMTensor(DT.float, [4, 8], name="out").name == "out"
    assert Tensor(DT.float, [1, 8], Position.UB).name.startswith("_tmp_tensor_")  # auto


# --- kernel-argument binding (param name -> GMTensor/Var name) ----------------
@kernel()
def _kw_param_kernel(delete: GMTensor):  # 'delete' is a C++ keyword, valid Python
    return delete


def test_kernel_argument_name_keyword_rejected() -> None:
    x = GMTensor(DT.float, [4, 8], name="x")
    with pytest.raises(ValueError, match=_MATCH):
        _kw_param_kernel(x)


@kernel()
def _generated_type_param_kernel(half: GMTensor):
    return half


def test_kernel_argument_generated_type_name_rejected() -> None:
    x = GMTensor(DT.float, [4, 8], name="x")
    with pytest.raises(ValueError, match=_TYPE_MATCH):
        _generated_type_param_kernel(x)


# --- AST-injected local name (the real-world trigger) -------------------------
@kernel()
def _kw_local_kernel(x: GMTensor, out: GMTensor):
    new = Tensor(DT.float, [1, 8], Position.UB)  # pythonic injects name="new"
    return out


def test_ast_injected_local_keyword_rejected() -> None:
    x = GMTensor(DT.float, [4, 8], name="x")
    out = GMTensor(DT.float, [4, 8], name="out")
    with pytest.raises(ValueError, match=_MATCH):
        _kw_local_kernel(x, out)


# --- a fully normal kernel still builds ---------------------------------------
@kernel()
def _normal_kernel(x: GMTensor, out: GMTensor):
    score = Tensor(DT.float, [1, 8], Position.UB)
    cnt = Var(0)
    return out


def test_normal_kernel_builds() -> None:
    x = GMTensor(DT.float, [4, 8], name="x")
    out = GMTensor(DT.float, [4, 8], name="out")
    assert _normal_kernel(x, out) is out
