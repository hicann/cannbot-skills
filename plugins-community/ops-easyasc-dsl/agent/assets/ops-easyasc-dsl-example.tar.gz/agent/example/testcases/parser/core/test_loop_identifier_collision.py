from types import SimpleNamespace

import pytest

from easyasc.a5 import *
from easyasc.parser.asc import split_instructions
from easyasc.utils.instruction import Instruction


@kernel()
def _tensor_loop_collision(x: GMTensor):
    acc = Tensor(DT.float, [1, 64], Position.UB)
    for row in range(0, 2, name="acc"):
        sim_print(row)
    return x


def test_loop_counter_rejects_tensor_name_collision() -> None:
    x = GMTensor(DT.float, [1, 1])
    _tensor_loop_collision(x)
    with pytest.raises(ValueError, match="Loop counter 'acc'.*create_tensor"):
        split_instructions(_tensor_loop_collision.instructions)


@pytest.mark.parametrize(
    ("opname", "operand"),
    [
        ("create_var", "val"),
        ("create_reg", "reg"),
        ("create_reglist", "reglist"),
        ("create_maskreg", "reg"),
    ],
)
def test_loop_counter_rejects_register_name_collision(opname: str, operand: str) -> None:
    loop_var = Var(0, name="acc")
    instructions = [
        Instruction(opname, **{operand: SimpleNamespace(name="acc")}),
        Instruction("start_micro_loop", var=loop_var, start=0, stop=2, step=1),
        Instruction("end_loop", var=loop_var),
    ]
    with pytest.raises(ValueError, match="Loop counter 'acc'.*%s" % opname):
        split_instructions(instructions)


def test_nested_loop_counter_reuse_is_rejected() -> None:
    outer = Var(0, name="idx")
    inner = Var(0, name="idx")
    instructions = [
        Instruction("start_loop", var=outer, start=0, stop=2, step=1),
        Instruction("start_loop", var=inner, start=0, stop=2, step=1),
        Instruction("end_loop", var=inner),
        Instruction("end_loop", var=outer),
    ]
    with pytest.raises(ValueError, match="Nested loop counter 'idx'"):
        split_instructions(instructions)


def test_sequential_loop_counter_reuse_is_legal() -> None:
    first = Var(0, name="idx")
    second = Var(0, name="idx")
    instructions = [
        Instruction("start_loop", var=first, start=0, stop=2, step=1),
        Instruction("end_loop", var=first),
        Instruction("start_loop", var=second, start=0, stop=2, step=1),
        Instruction("end_loop", var=second),
    ]
    split_instructions(instructions)
