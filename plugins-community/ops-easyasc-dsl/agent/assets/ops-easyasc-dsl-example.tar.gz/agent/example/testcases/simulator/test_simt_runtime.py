"""SIMT runtime simulator tests.

Direct-runtime tests construct a SIMT IR (or hand-crafted IR), call
SimtRuntime.execute_call_simt against a fresh torch UB tensor, and assert
against vectorized golden computations.  These are fast.

One end-to-end test exercises the full bridge → PipeS dispatch → vec
mailbox → SimtRuntime path via OpExec(simulator=True).

Note: @kernel / @simt parse the function source via AST and re-exec it
against `func.__globals__` (see easyasc/pythonic.transform_kernel and
easyasc/simt/simtmodule._extract_inputs).  That means closure variables
are not visible — type names like `Tensor` / `GMTensor` / `Var` and
helpers like `simt_thread_id` must resolve from this module's globals.
The @simt() decorator additionally requires those annotations to literally
say `Tensor` / `GMTensor` / `Var`.  Both constraints push the @simt /
@kernel definitions to module scope rather than inside test functions.
"""
from __future__ import annotations

import pytest
import torch

from easyasc import globvars

# Ensure the a5 module imports succeed (they gate on device_type).  Set
# device before importing a5; restore at module teardown.
_SAVED_DEVICE = globvars.device_type
globvars.device_type = "950"

from easyasc.a5 import (  # noqa: E402
    simt, kernel, auto_sync, cvt, simt_ffs, simt_fma,
    simt_thread_barrier,
    simt_thread_id, simt_thread_num,
    simt_block_idx, simt_block_num, DT, Tensor, GMTensor, Position, Var,
    OpExec, allvec_ready, allvec_wait, Pipe, GetVecIdx, GetVecNum,
)
from easyasc.simulator import SimulatorConfig, build_kernel_program  # noqa: E402
from easyasc.simulator.memory import SharedMemoryStore  # noqa: E402
from easyasc.simulator.physical_alias import PhysicalAlias  # noqa: E402
from easyasc.simulator.pipe_simt import SimtRuntime  # noqa: E402
from easyasc.utils.instruction import Instruction  # noqa: E402

# The compiler requires a non-returned input tensor in the kernel entry; the
# probe kernels below write their output from Vars alone, so `gate` is never
# read.  It is a tensor argument, so shape_bindings keys shift by one.
GATE = torch.zeros((1, 1), dtype=torch.int32)


def teardown_module(module):  # pytest hook
    globvars.device_type = _SAVED_DEVICE


# ---------------------------------------------------------------------------
# Module-level @simt / @kernel definitions (need module globals)
# ---------------------------------------------------------------------------

TILE = 64
SIMT_EXTERNAL_DENOM = 4
SIMT_UB_OVER_CAP_HALF_COLS = (220 * 1024) // 2


@simt()
def _axpy_simt(x_ub: Tensor, y_ub: Tensor, out_ub: Tensor, alpha: Var, n: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out_ub[i] = x_ub[i] * alpha + y_ub[i]


@kernel()
def _simt_axpy_kernel(x: GMTensor, y: GMTensor, out: GMTensor, alpha: Var, N: Var):
    x_ub = Tensor(DT.float, [1, TILE], Position.UB)
    y_ub = Tensor(DT.float, [1, TILE], Position.UB)
    out_ub = Tensor(DT.float, [1, TILE], Position.UB)
    n_iter = Var(TILE, DT.int)
    with auto_sync():
        x_ub <<= x[0:1, 0:TILE]
        y_ub <<= y[0:1, 0:TILE]
        _axpy_simt(x_ub, y_ub, out_ub, alpha, n_iter)
        out[0:1, 0:TILE] <<= out_ub
    return out


@simt()
def _ub_only(t: Tensor, n: Var):
    t[0] = n


@simt(num_threads=128)
def _fill_literal_vars_simt(out_ub: Tensor, count: Var, value: Var):
    for i in range(simt_thread_id(), count, simt_thread_num()):
        out_ub[i] = value


@kernel()
def _simt_literal_vars_kernel(gate: GMTensor, out: GMTensor, N: Var):
    out_ub = Tensor(DT.int, [1, TILE], Position.UB)
    with auto_sync():
        _fill_literal_vars_simt(out_ub, 16, 7)
        out[0:1, 0:TILE] <<= out_ub
    return out


_SIMT_PROBE_CORES = 4
_SIMT_PROBE_VEC = _SIMT_PROBE_CORES * 2
_SIMT_PROBE_CONFIG = SimulatorConfig(
    core_count=_SIMT_PROBE_CORES,
    process_start_method="fork",
    execution_timeout_s=10.0,
)


@simt(num_threads=128)
def _fill_i32_gm(out: GMTensor, n: Var, value: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out[i] = value


@simt(num_threads=128)
def _record_simt_block_intrinsics(out: GMTensor):
    if simt_thread_id() == 0:
        out[simt_block_idx()] = simt_block_num()


@simt(num_threads=128)
def _record_passed_vec_idx(out: GMTensor, vec_idx: Var, vec_num: Var):
    if simt_thread_id() == 0:
        out[vec_idx] = vec_num


@simt(num_threads=128)
def _floor_div_i32_gm(out: GMTensor, n: Var, denom: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out[i] = i // denom


@simt(num_threads=128)
def _external_const_floor_div_i32_gm(out: GMTensor, n: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out[i] = i // SIMT_EXTERNAL_DENOM


@simt(num_threads=128)
def _uint64_index_i32_gm(out: GMTensor, n: Var):
    idx = cvt(simt_thread_id(), DT.uint64)
    shifted = idx + 1
    if shifted < n:
        out[shifted] = cvt(shifted, DT.int)


@simt(num_threads=128)
def _fma_fp32_gm(x: GMTensor, y: GMTensor, addend: GMTensor, out: GMTensor):
    index = simt_thread_id()
    out[index] = simt_fma(x[index], y[index], addend[index])


@simt(num_threads=128)
def _ffs_i64_gm(bits: GMTensor, out: GMTensor):
    index = simt_thread_id()
    out[index] = simt_ffs(bits[index])


@simt(num_threads=128)
def _barrier_i32_gm(out: GMTensor):
    index = simt_thread_id()
    out[index] = index
    simt_thread_barrier()
    out[index] = out[index] + 1


@simt(num_threads=128)
def _divergent_barrier_i32_gm(out: GMTensor):
    if simt_thread_id() == 0:
        simt_thread_barrier()
        out[0] = 1


@simt(num_threads=128)
def _touch_ub_simt(buf: Tensor):
    if simt_thread_id() == 0:
        buf[0] = buf[0]


@kernel()
def _simt_block_intrinsics_kernel(gate: GMTensor, out: GMTensor, N: Var, fill: Var):
    with auto_sync():
        _fill_i32_gm(out, N, fill)
        allvec_ready(1, pipe=Pipe.V)
        allvec_wait(1, pipe=Pipe.V)
        _record_simt_block_intrinsics(out)
    return out


_simt_block_intrinsics_kernel._simulator_config = _SIMT_PROBE_CONFIG


@kernel()
def _simt_passed_vec_idx_kernel(gate: GMTensor, out: GMTensor, N: Var, fill: Var):
    with auto_sync():
        _fill_i32_gm(out, N, fill)
        allvec_ready(2, pipe=Pipe.V)
        allvec_wait(2, pipe=Pipe.V)
        _record_passed_vec_idx(out, GetVecIdx(), GetVecNum())
    return out


_simt_passed_vec_idx_kernel._simulator_config = _SIMT_PROBE_CONFIG


@kernel()
def _simt_floor_div_kernel(gate: GMTensor, out: GMTensor, N: Var, denom: Var):
    with auto_sync():
        _floor_div_i32_gm(out, N, denom)
    return out


_simt_floor_div_kernel._simulator_config = _SIMT_PROBE_CONFIG


@kernel()
def _simt_external_const_floor_div_kernel(gate: GMTensor, out: GMTensor, N: Var):
    with auto_sync():
        _external_const_floor_div_i32_gm(out, N)
    return out


_simt_external_const_floor_div_kernel._simulator_config = _SIMT_PROBE_CONFIG


@kernel()
def _simt_uint64_index_kernel(gate: GMTensor, out: GMTensor, dummy: Var):
    n = Var(TILE, DT.uint64)
    with auto_sync():
        _uint64_index_i32_gm(out, n)
    return out


_simt_uint64_index_kernel._simulator_config = _SIMT_PROBE_CONFIG


@kernel()
def _offending_kernel(x: GMTensor, n: Var):
    bad = Tensor(DT.int, [1, 16], Position.L1)  # not UB — should be rejected
    _ub_only(bad, n)
    return x


@kernel()
def _simt_large_ub_capacity_kernel(out: GMTensor, n: Var):
    ub = Tensor(DT.half, [1, SIMT_UB_OVER_CAP_HALF_COLS], Position.UB, name="simt_ub_over_216kb")
    with auto_sync():
        _touch_ub_simt(ub)
    return out


# ---------------------------------------------------------------------------
# Helpers for direct-runtime tests
# ---------------------------------------------------------------------------


def _run_simt(simt_def, tensor_views, var_values, *, T=1024, block_idx=0, block_num=1):
    rt = SimtRuntime()
    rt.execute_call_simt(
        simt_def,
        tensor_views,
        var_values,
        SharedMemoryStore(),
        block_idx=block_idx,
        block_num=block_num,
        thread_num=T,
    )


def _axpy_def():
    """Hand-crafted IR equivalent to _axpy_simt — keeps the direct runtime
    test independent of the lowering path (which is already covered by
    test_simt_ir_lowering smoke tests under tmp/)."""
    return {
        "input_list": [
            ("x_ub", "Tensor"), ("y_ub", "Tensor"), ("out_ub", "Tensor"),
            ("alpha", "Var"), ("n", "Var"),
        ],
        "locked_dtypes": ["float", "float", "float", "float", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out_ub",
                        "index": {"kind": "name", "id": "i"}},
                expr={
                    "kind": "binop", "op": "+",
                    "left": {
                        "kind": "binop", "op": "*",
                        "left": {"kind": "subscript", "base": "x_ub",
                                 "index": {"kind": "name", "id": "i"}},
                        "right": {"kind": "name", "id": "alpha"},
                    },
                    "right": {"kind": "subscript", "base": "y_ub",
                              "index": {"kind": "name", "id": "i"}},
                },
                decl_dtype=None,
            ),
            Instruction("simt_endfor"),
        ],
    }


def _atomic_cas_def():
    return {
        "input_list": [("out", "GMTensor")],
        "locked_dtypes": ["int64_t"],
        "instructions": [
            Instruction(
                "simt_atomic", op="cas", base="out",
                index={
                    "kind": "binop", "op": "%",
                    "left": {"kind": "intrinsic", "name": "simt_thread_id"},
                    "right": {"kind": "const", "value": 2, "dtype": "int"},
                },
                compare={"kind": "const", "value": 0, "dtype": "int64_t"},
                value={
                    "kind": "binop", "op": "+",
                    "left": {"kind": "cvt", "dtype": "int64_t", "expr": {
                        "kind": "intrinsic", "name": "simt_thread_id",
                    }},
                    "right": {"kind": "const", "value": 1, "dtype": "int64_t"},
                },
            ),
        ],
    }


# ---------------------------------------------------------------------------
# Direct SimtRuntime tests
# ---------------------------------------------------------------------------


def test_simt_runtime_axpy_uniform_trip() -> None:
    T = 1024
    torch.manual_seed(0)
    x = torch.randn(T, dtype=torch.float32)
    y = torch.randn(T, dtype=torch.float32)
    out = torch.zeros(T, dtype=torch.float32)

    _run_simt(_axpy_def(), {"x_ub": x, "y_ub": y, "out_ub": out},
              {"alpha": 2.5, "n": T}, T=T)

    torch.testing.assert_close(out, x * 2.5 + y, rtol=1e-6, atol=1e-6)


def test_simt_runtime_atomic_cas_allows_one_winner_per_collision() -> None:
    out = torch.zeros(2, dtype=torch.int64)

    _run_simt(_atomic_cas_def(), {"out": out}, {}, T=4)

    # Lanes execute one atomic phase in lane order.  Lanes 0/1 claim the two
    # slots; lanes 2/3 compare against stale zero and therefore lose.
    torch.testing.assert_close(
        out, torch.tensor([1, 2], dtype=torch.int64), rtol=0.0, atol=0.0,
    )


def test_simt_runtime_compares_uint64_above_signed_range_unsigned() -> None:
    left = torch.tensor([0, 1 << 63, (1 << 64) - 1], dtype=torch.uint64)
    right = torch.tensor([(1 << 64) - 1, 1, 1 << 63], dtype=torch.uint64)

    actual = SimtRuntime._apply_compare(">", left, right)

    torch.testing.assert_close(
        actual, torch.tensor([False, True, True]), rtol=0.0, atol=0.0,
    )


def test_simt_runtime_fma_rounds_only_once() -> None:
    T = 128
    x = torch.full((T,), 186.62123107910156, dtype=torch.float32)
    y = torch.full((T,), 92.42759704589844, dtype=torch.float32)
    addend = torch.full((T,), 118.35784912109375, dtype=torch.float32)
    out = torch.zeros((T,), dtype=torch.float32)
    gm = GMTensor(DT.float, [T])
    _fma_fp32_gm(gm, gm, gm, gm)
    simt_def = {
        "input_list": list(_fma_fp32_gm.input_list),
        "locked_dtypes": [dtype.name for dtype in _fma_fp32_gm._locked_dtypes],
        "instructions": _fma_fp32_gm.lower_to_ir(),
    }

    _run_simt(
        simt_def,
        {"x": x, "y": y, "addend": addend, "out": out},
        {}, T=T,
    )

    expected = torch.full((T,), 17367.310546875, dtype=torch.float32)
    separate = x * y + addend
    assert not torch.equal(separate, expected)
    torch.testing.assert_close(out, expected, rtol=0.0, atol=0.0)


def test_simt_runtime_ffs_matches_a5_one_based_signed_semantics() -> None:
    values = torch.tensor(
        [0, 1, 2, 4, 8, 1 << 31, 1 << 32, -1, -(1 << 63)],
        dtype=torch.int64,
    )
    bits = values.repeat(15)[:128].contiguous()
    out = torch.zeros(128, dtype=torch.int32)
    gm_i64 = GMTensor(DT.int64, [128])
    gm_i32 = GMTensor(DT.int, [128])
    _ffs_i64_gm(gm_i64, gm_i32)
    simt_def = {
        "input_list": list(_ffs_i64_gm.input_list),
        "locked_dtypes": [dtype.name for dtype in _ffs_i64_gm._locked_dtypes],
        "instructions": _ffs_i64_gm.lower_to_ir(),
    }

    _run_simt(simt_def, {"bits": bits, "out": out}, {}, T=128)

    expected_cycle = torch.tensor(
        [0, 1, 2, 3, 4, 32, 33, 1, 64], dtype=torch.int32,
    )
    torch.testing.assert_close(
        out, expected_cycle.repeat(15)[:128], rtol=0.0, atol=0.0,
    )


def test_simt_runtime_uniform_thread_barrier_delimits_phases() -> None:
    out = torch.zeros(128, dtype=torch.int32)
    gm = GMTensor(DT.int, [128])
    _barrier_i32_gm(gm)
    simt_def = {
        "input_list": list(_barrier_i32_gm.input_list),
        "locked_dtypes": [dtype.name for dtype in _barrier_i32_gm._locked_dtypes],
        "instructions": _barrier_i32_gm.lower_to_ir(),
    }

    _run_simt(simt_def, {"out": out}, {}, T=128)

    torch.testing.assert_close(
        out, torch.arange(1, 129, dtype=torch.int32), rtol=0.0, atol=0.0,
    )


def test_simt_runtime_rejects_divergent_thread_barrier() -> None:
    out = torch.zeros(128, dtype=torch.int32)
    gm = GMTensor(DT.int, [128])
    _divergent_barrier_i32_gm(gm)
    simt_def = {
        "input_list": list(_divergent_barrier_i32_gm.input_list),
        "locked_dtypes": [
            dtype.name for dtype in _divergent_barrier_i32_gm._locked_dtypes
        ],
        "instructions": _divergent_barrier_i32_gm.lower_to_ir(),
    }

    with pytest.raises(RuntimeError, match="every launch thread"):
        _run_simt(simt_def, {"out": out}, {}, T=128)


def test_simt_runtime_axpy_divergent_trip() -> None:
    T = 1024
    N = 137
    torch.manual_seed(1)
    x = torch.randn(N, dtype=torch.float32)
    y = torch.randn(N, dtype=torch.float32)
    out = torch.zeros(N, dtype=torch.float32)

    _run_simt(_axpy_def(), {"x_ub": x, "y_ub": y, "out_ub": out},
              {"alpha": -1.5, "n": N}, T=T)

    torch.testing.assert_close(out, x * -1.5 + y, rtol=1e-6, atol=1e-6)


@pytest.mark.parametrize("T", [128, 256, 512, 1024, 2048])
def test_simt_runtime_axpy_lane_count_matches_thread_num(T: int) -> None:
    """The runtime allocates per-lane state at width T.  An axpy over
    N >= T should cover every output index across multiple loop trips."""
    N = T * 3 + 7  # forces ceil(N/T) = 4 trips with a divergent tail.
    torch.manual_seed(2)
    x = torch.randn(N, dtype=torch.float32)
    y = torch.randn(N, dtype=torch.float32)
    out = torch.zeros(N, dtype=torch.float32)

    _run_simt(_axpy_def(), {"x_ub": x, "y_ub": y, "out_ub": out},
              {"alpha": 0.75, "n": N}, T=T)

    torch.testing.assert_close(out, x * 0.75 + y, rtol=1e-6, atol=1e-6)


@pytest.mark.parametrize("T", [128, 256, 512, 1024, 2048])
def test_simt_runtime_thread_num_intrinsic_returns_T(T: int) -> None:
    """simt_thread_num() must broadcast the runtime T value, so writing it
    to every lane gives a tensor full of T."""
    N = T  # one element per active lane
    out = torch.zeros(N, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("n", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "name", "id": "i"}},
                expr={"kind": "intrinsic", "name": "simt_thread_num"},
                decl_dtype=None,
            ),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": out}, {"n": N}, T=T)

    torch.testing.assert_close(out, torch.full((N,), T, dtype=torch.int32))


def test_simt_runtime_intrinsics_readback() -> None:
    T = 1024
    N = 256
    out = torch.zeros(N, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("n", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "name", "id": "i"}},
                expr={"kind": "name", "id": "i"},
                decl_dtype=None,
            ),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": out}, {"n": N}, T=T)

    torch.testing.assert_close(out, torch.arange(N, dtype=torch.int32))


def test_simt_runtime_accepts_physical_alias_logical_views() -> None:
    base = torch.zeros(8, dtype=torch.int32)
    logical = base[2:6]
    alias = PhysicalAlias(
        tensor=base,
        logical_view=logical,
        byte_offset=2 * int(base.element_size()),
        logical_offset_bytes=2 * int(base.element_size()),
        name="out",
        storage_name="base",
        role="ub",
        tags=("runtime_view", "slice_tensor"),
    )
    simt_def = {
        "input_list": [("out", "Tensor"), ("n", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out", "index": {"kind": "name", "id": "i"}},
                expr={
                    "kind": "binop",
                    "op": "+",
                    "left": {"kind": "name", "id": "i"},
                    "right": {"kind": "const", "value": 10, "dtype": "int"},
                },
                decl_dtype=None,
            ),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": alias}, {"n": 4}, T=4)

    expected = torch.zeros(8, dtype=torch.int32)
    expected[2:6] = torch.tensor([10, 11, 12, 13], dtype=torch.int32)
    torch.testing.assert_close(base, expected)


def test_simt_runtime_rejects_offset_only_alias_without_logical_materialization() -> None:
    base = torch.zeros(8, dtype=torch.int32)
    alias = PhysicalAlias(
        tensor=base,
        logical_view=base,
        byte_offset=2 * int(base.element_size()),
        logical_offset_bytes=2 * int(base.element_size()),
        name="out",
        storage_name="base",
        role="ub",
        tags=("runtime_view", "packed_local"),
    )
    simt_def = {
        "input_list": [("out", "Tensor"), ("n", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out", "index": {"kind": "name", "id": "i"}},
                expr={"kind": "const", "value": 1, "dtype": "int"},
                decl_dtype=None,
            ),
            Instruction("simt_endfor"),
        ],
    }

    with pytest.raises(RuntimeError, match="must be materialized before SIMT logical indexing"):
        _run_simt(simt_def, {"out": alias}, {"n": 4}, T=4)


def test_simt_runtime_if_elif_else_branches_by_thread() -> None:
    T = 1024
    N = 256
    out = torch.zeros(N, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("n", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction(
                "simt_assign", target_kind="name", target="m",
                expr={"kind": "binop", "op": "%",
                      "left": {"kind": "name", "id": "i"},
                      "right": {"kind": "const", "value": 3, "dtype": "int"}},
                decl_dtype="int",
            ),
            Instruction("simt_if",
                cond={"kind": "compare", "op": "==",
                      "left": {"kind": "name", "id": "m"},
                      "right": {"kind": "const", "value": 0, "dtype": "int"}}),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "name", "id": "i"}},
                expr={"kind": "binop", "op": "+",
                      "left": {"kind": "const", "value": 100, "dtype": "int"},
                      "right": {"kind": "name", "id": "i"}},
                decl_dtype=None,
            ),
            Instruction("simt_elif",
                cond={"kind": "compare", "op": "==",
                      "left": {"kind": "name", "id": "m"},
                      "right": {"kind": "const", "value": 1, "dtype": "int"}}),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "name", "id": "i"}},
                expr={"kind": "binop", "op": "+",
                      "left": {"kind": "const", "value": 200, "dtype": "int"},
                      "right": {"kind": "name", "id": "i"}},
                decl_dtype=None,
            ),
            Instruction("simt_else"),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "name", "id": "i"}},
                expr={"kind": "binop", "op": "+",
                      "left": {"kind": "const", "value": 300, "dtype": "int"},
                      "right": {"kind": "name", "id": "i"}},
                decl_dtype=None,
            ),
            Instruction("simt_endif"),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": out}, {"n": N}, T=T)

    expected = torch.zeros(N, dtype=torch.int32)
    idx = torch.arange(N, dtype=torch.int32)
    m = idx % 3
    expected = torch.where(m == 0, 100 + idx, expected)
    expected = torch.where(m == 1, 200 + idx, expected)
    expected = torch.where(m == 2, 300 + idx, expected)
    torch.testing.assert_close(out, expected)


def test_simt_runtime_break_and_continue() -> None:
    T = 1024
    N = 128
    out = torch.zeros(N, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("n", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction("simt_if",
                cond={"kind": "compare", "op": ">=",
                      "left": {"kind": "name", "id": "i"},
                      "right": {"kind": "const", "value": 64, "dtype": "int"}}),
            Instruction("simt_break"),
            Instruction("simt_endif"),
            Instruction("simt_if",
                cond={"kind": "compare", "op": "==",
                      "left": {"kind": "binop", "op": "%",
                               "left": {"kind": "name", "id": "i"},
                               "right": {"kind": "const", "value": 2, "dtype": "int"}},
                      "right": {"kind": "const", "value": 0, "dtype": "int"}}),
            Instruction("simt_continue"),
            Instruction("simt_endif"),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "name", "id": "i"}},
                expr={"kind": "binop", "op": "*",
                      "left": {"kind": "name", "id": "i"},
                      "right": {"kind": "const", "value": 10, "dtype": "int"}},
                decl_dtype=None,
            ),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": out}, {"n": N}, T=T)

    expected = torch.zeros(N, dtype=torch.int32)
    idx = torch.arange(N, dtype=torch.int32)
    write_mask = (idx < 64) & (idx % 2 == 1)
    expected[write_mask] = idx[write_mask] * 10
    torch.testing.assert_close(out, expected)


def test_simt_runtime_block_idx_intrinsic() -> None:
    T = 1024
    out = torch.zeros(T, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor")],
        "locked_dtypes": ["int"],
        "instructions": [
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "intrinsic", "name": "simt_thread_id"}},
                expr={"kind": "intrinsic", "name": "simt_block_idx"},
                decl_dtype=None,
            ),
        ],
    }

    _run_simt(simt_def, {"out": out}, {}, T=T, block_idx=7, block_num=20)

    torch.testing.assert_close(out, torch.full((T,), 7, dtype=torch.int32))


def test_simt_call_site_block_intrinsics_match_cube_identity() -> None:
    out = torch.empty((_SIMT_PROBE_VEC,), dtype=torch.int32)

    actual = OpExec(_simt_block_intrinsics_kernel, simulator=True)(
        GATE, out, _SIMT_PROBE_VEC, -1,
        shape_bindings={1: [0]},
    )

    expected = torch.full((_SIMT_PROBE_VEC,), -1, dtype=torch.int32)
    expected[:_SIMT_PROBE_CORES] = _SIMT_PROBE_CORES
    torch.testing.assert_close(actual, expected)


def test_simt_call_site_can_receive_global_vec_identity() -> None:
    out = torch.empty((_SIMT_PROBE_VEC,), dtype=torch.int32)

    actual = OpExec(_simt_passed_vec_idx_kernel, simulator=True)(
        GATE, out, _SIMT_PROBE_VEC, -1,
        shape_bindings={1: [0]},
    )

    expected = torch.full((_SIMT_PROBE_VEC,), _SIMT_PROBE_VEC, dtype=torch.int32)
    torch.testing.assert_close(actual, expected)


def test_simt_call_site_accepts_literal_var_actuals() -> None:
    out = torch.empty((1, TILE), dtype=torch.int32)

    actual = OpExec(_simt_literal_vars_kernel, simulator=True)(
        GATE, out, TILE,
        shape_bindings={1: [None, None]},
    )

    torch.testing.assert_close(actual[0, :16], torch.full((16,), 7, dtype=torch.int32))


# ---------------------------------------------------------------------------
# Nested + mixed control flow
# ---------------------------------------------------------------------------


def test_simt_runtime_nested_for_in_for() -> None:
    """for tid: for j in [0, K): out[tid*K + j] = tid*K + j."""
    T = 1024
    M, K = 8, 5
    out = torch.zeros(M * K, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("M", "Var"), ("K", "Var")],
        "locked_dtypes": ["int", "int", "int"],
        "instructions": [
            Instruction("simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "M"},
                step={"kind": "intrinsic", "name": "simt_thread_num"}),
            Instruction("simt_for_range", var_name="j",
                start={"kind": "const", "value": 0, "dtype": "int"},
                stop={"kind": "name", "id": "K"},
                step={"kind": "const", "value": 1, "dtype": "int"}),
            Instruction("simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "binop", "op": "+",
                                  "left": {"kind": "binop", "op": "*",
                                           "left": {"kind": "name", "id": "i"},
                                           "right": {"kind": "name", "id": "K"}},
                                  "right": {"kind": "name", "id": "j"}}},
                expr={"kind": "binop", "op": "+",
                      "left": {"kind": "binop", "op": "*",
                               "left": {"kind": "name", "id": "i"},
                               "right": {"kind": "name", "id": "K"}},
                      "right": {"kind": "name", "id": "j"}},
                decl_dtype=None),
            Instruction("simt_endfor"),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": out}, {"M": M, "K": K}, T=T)

    torch.testing.assert_close(out, torch.arange(M * K, dtype=torch.int32))


def test_simt_runtime_inner_break_does_not_break_outer() -> None:
    """for tid:
         for j in [0, 10):
           if j == 3: break
           out[tid*10 + j] = 1
         out[tid*10 + 9] = 99   # written every outer iter."""
    T = 1024
    M, K = 4, 10
    out = torch.zeros(M * K, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("M", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction("simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "M"},
                step={"kind": "intrinsic", "name": "simt_thread_num"}),
            Instruction("simt_for_range", var_name="j",
                start={"kind": "const", "value": 0, "dtype": "int"},
                stop={"kind": "const", "value": 10, "dtype": "int"},
                step={"kind": "const", "value": 1, "dtype": "int"}),
            Instruction("simt_if",
                cond={"kind": "compare", "op": "==",
                      "left": {"kind": "name", "id": "j"},
                      "right": {"kind": "const", "value": 3, "dtype": "int"}}),
            Instruction("simt_break"),
            Instruction("simt_endif"),
            Instruction("simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "binop", "op": "+",
                                  "left": {"kind": "binop", "op": "*",
                                           "left": {"kind": "name", "id": "i"},
                                           "right": {"kind": "const", "value": 10, "dtype": "int"}},
                                  "right": {"kind": "name", "id": "j"}}},
                expr={"kind": "const", "value": 1, "dtype": "int"},
                decl_dtype=None),
            Instruction("simt_endfor"),
            Instruction("simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "binop", "op": "+",
                                  "left": {"kind": "binop", "op": "*",
                                           "left": {"kind": "name", "id": "i"},
                                           "right": {"kind": "const", "value": 10, "dtype": "int"}},
                                  "right": {"kind": "const", "value": 9, "dtype": "int"}}},
                expr={"kind": "const", "value": 99, "dtype": "int"},
                decl_dtype=None),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": out}, {"M": M}, T=T)

    expected = torch.zeros(M * K, dtype=torch.int32)
    for tid in range(M):
        for j in range(3):
            expected[tid * K + j] = 1
        expected[tid * K + 9] = 99
    torch.testing.assert_close(out, expected)


def test_simt_runtime_nested_if_continue_propagates() -> None:
    """for tid:
         if tid < 64:
           if tid % 2 == 0: continue
           out[tid] = tid * 10
         else:
           out[tid] = -1."""
    T = 1024
    N = 96
    out = torch.zeros(N, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("N", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction("simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "N"},
                step={"kind": "intrinsic", "name": "simt_thread_num"}),
            Instruction("simt_if",
                cond={"kind": "compare", "op": "<",
                      "left": {"kind": "name", "id": "i"},
                      "right": {"kind": "const", "value": 64, "dtype": "int"}}),
            Instruction("simt_if",
                cond={"kind": "compare", "op": "==",
                      "left": {"kind": "binop", "op": "%",
                               "left": {"kind": "name", "id": "i"},
                               "right": {"kind": "const", "value": 2, "dtype": "int"}},
                      "right": {"kind": "const", "value": 0, "dtype": "int"}}),
            Instruction("simt_continue"),
            Instruction("simt_endif"),
            Instruction("simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "name", "id": "i"}},
                expr={"kind": "binop", "op": "*",
                      "left": {"kind": "name", "id": "i"},
                      "right": {"kind": "const", "value": 10, "dtype": "int"}},
                decl_dtype=None),
            Instruction("simt_else"),
            Instruction("simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "name", "id": "i"}},
                expr={"kind": "const", "value": -1, "dtype": "int"},
                decl_dtype=None),
            Instruction("simt_endif"),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": out}, {"N": N}, T=T)

    idx = torch.arange(N, dtype=torch.int32)
    expected = torch.zeros(N, dtype=torch.int32)
    expected = torch.where((idx < 64) & (idx % 2 == 1), idx * 10, expected)
    expected = torch.where(idx >= 64, torch.full_like(idx, -1), expected)
    torch.testing.assert_close(out, expected)


def test_simt_runtime_for_in_if_in_for() -> None:
    """Outer for with a guarded inner for: only first M/2 threads run the
    inner loop and fill their stripe, rest leave their stripe at zero."""
    T = 1024
    M, K = 6, 4
    out = torch.zeros(M * K, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("M", "Var"), ("K", "Var"), ("half", "Var")],
        "locked_dtypes": ["int", "int", "int", "int"],
        "instructions": [
            Instruction("simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "M"},
                step={"kind": "intrinsic", "name": "simt_thread_num"}),
            Instruction("simt_if",
                cond={"kind": "compare", "op": "<",
                      "left": {"kind": "name", "id": "i"},
                      "right": {"kind": "name", "id": "half"}}),
            Instruction("simt_for_range", var_name="j",
                start={"kind": "const", "value": 0, "dtype": "int"},
                stop={"kind": "name", "id": "K"},
                step={"kind": "const", "value": 1, "dtype": "int"}),
            Instruction("simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out",
                        "index": {"kind": "binop", "op": "+",
                                  "left": {"kind": "binop", "op": "*",
                                           "left": {"kind": "name", "id": "i"},
                                           "right": {"kind": "name", "id": "K"}},
                                  "right": {"kind": "name", "id": "j"}}},
                expr={"kind": "name", "id": "j"},
                decl_dtype=None),
            Instruction("simt_endfor"),
            Instruction("simt_endif"),
            Instruction("simt_endfor"),
        ],
    }

    _run_simt(simt_def, {"out": out}, {"M": M, "K": K, "half": M // 2}, T=T)

    expected = torch.zeros(M * K, dtype=torch.int32)
    for tid in range(M // 2):
        for j in range(K):
            expected[tid * K + j] = j
    torch.testing.assert_close(out, expected)


# ---------------------------------------------------------------------------
# Bridge UB-position validation
# ---------------------------------------------------------------------------


def test_simt_bridge_rejects_non_ub_tensor_formal() -> None:
    _offending_kernel(GMTensor(DT.int, [1, 16]), Var(0, DT.int))
    with pytest.raises(TypeError, match="requires UB position"):
        build_kernel_program(_offending_kernel)


def test_simt_kernel_metadata_reduces_ub_cap_to_216kb() -> None:
    out = GMTensor(DT.int, [1, TILE], name="simt_metadata_out")
    _simt_literal_vars_kernel(GMTensor(DT.int, [1, 1], name="simt_metadata_gate"), out, Var(TILE, DT.int))
    program = build_kernel_program(_simt_literal_vars_kernel)
    assert program.metadata["ub_cap"] == 216


def test_simt_kernel_enforces_216kb_ub_capacity() -> None:
    out = GMTensor(DT.half, [1, 16], name="simt_capacity_out")
    _simt_large_ub_capacity_kernel(out, Var(1, DT.int))
    with pytest.raises(RuntimeError, match="capacity=221184"):
        build_kernel_program(_simt_large_ub_capacity_kernel)


def test_simt_kernel_supports_floor_div_operator() -> None:
    N = 64
    denom = 3
    out = torch.zeros((N,), dtype=torch.int32)

    actual = OpExec(_simt_floor_div_kernel, simulator=True)(GATE, out, N, denom)

    expected = torch.arange(N, dtype=torch.int32) // denom
    torch.testing.assert_close(actual, expected)


def test_simt_kernel_supports_external_numeric_constants() -> None:
    N = 64
    out = torch.zeros((N,), dtype=torch.int32)

    actual = OpExec(_simt_external_const_floor_div_kernel, simulator=True)(GATE, out, N)

    expected = torch.arange(N, dtype=torch.int32) // SIMT_EXTERNAL_DENOM
    torch.testing.assert_close(actual, expected)


def test_simt_kernel_supports_uint64_index_arithmetic() -> None:
    out = torch.zeros((TILE,), dtype=torch.int32)

    actual = OpExec(_simt_uint64_index_kernel, simulator=True)(GATE, out, 1)

    # The kernel writes ``out[tid + 1]``, so lane 0 stays untouched and keeps
    # the simulator's poison; what the widened index has to get right is every
    # lane it does write.
    expected = torch.arange(1, TILE, dtype=torch.int32)
    torch.testing.assert_close(actual[1:], expected)


# ---------------------------------------------------------------------------
# End-to-end through the simulator harness (slow — kept to one case)
# ---------------------------------------------------------------------------


def test_simt_axpy_kernel_simulator_e2e() -> None:
    torch.manual_seed(0)
    x = torch.randn((1, TILE), dtype=torch.float32)
    y = torch.randn((1, TILE), dtype=torch.float32)
    out = torch.empty_like(x)

    actual = OpExec(_simt_axpy_kernel, simulator=True)(
        x, y, out, 2.5, TILE,
        shape_bindings={0: [None, 1], 1: [None, 1], 2: [None, 1]},
    )
    torch.testing.assert_close(actual, x * 2.5 + y, rtol=1e-5, atol=1e-5)
