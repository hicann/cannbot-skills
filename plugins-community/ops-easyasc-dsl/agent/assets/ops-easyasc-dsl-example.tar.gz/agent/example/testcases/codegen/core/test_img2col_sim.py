"""Simulator tests for l1_to_l0_img2col (U3): conv via img2col vs torch."""
import torch

from easyasc.a2 import *
from easyasc.stub_functions import l1_to_l0a_img2col

C0 = 16
C, H, W = 32, 4, 4
C1 = C // C0
KH = KW = 4
PAD = (1, 2, 1, 2)
COUT = 64
HO = (H + PAD[2] + PAD[3] - KH) + 1
WO = (W + PAD[0] + PAD[1] - KW) + 1
M, M_PAD = HO * WO, ((HO * WO + 15) // 16) * 16
K = C1 * KH * KW * C0
TILE_K = K  # single tile: bare K-loop without DBuff trips sim hazard


@kernel()
def _img2col_conv_sim(data: GMTensor, weight: GMTensor, out: GMTensor, nb: Var):
    conv = Conv2D(KH, KW, pad=PAD)
    with auto_sync():
        fm = Tensor(DT.half, [C1 * H * W, C0], Position.L1)
        fm <<= data[:, :]
        w_l1 = Tensor(DT.half, [COUT, K], Position.L1)
        w_l1 <<= weight[:, :]
        acc = img2col(fm, conv, h=H, w=W, c=C)
        l0a = Tensor(DT.half, [M_PAD, TILE_K], Position.L0A)
        l0b = Tensor(DT.half, [TILE_K, COUT], Position.L0B)
        l0c = Tensor(DT.float, [M_PAD, COUT], Position.L0C)
        for k0 in unroll(0, K, TILE_K):
            l1_to_l0a_img2col(l0a, acc[0:M_PAD, k0:k0 + TILE_K])
            l1_to_l0(l0b, w_l1[:, k0:k0 + TILE_K])
            mmad(l0c, l0a, l0b, M=M_PAD, N=COUT, K=TILE_K, is_init=(k0 == 0))
        out[:, :] <<= l0c
    return out


def test_img2col_conv_matches_torch():
    g = torch.Generator().manual_seed(0)
    x = (torch.rand((1, C, H, W), generator=g) * 2 - 1).half()
    w = (torch.rand((COUT, C, KH, KW), generator=g) * 2 - 1).half()
    data = x.reshape(C1, C0, H, W).permute(0, 2, 3, 1).reshape(C1 * H * W, C0).contiguous()
    wz = w.reshape(COUT, C1, C0, KH, KW).permute(0, 1, 3, 4, 2).reshape(COUT, K).contiguous()
    out = torch.zeros((M_PAD, COUT), dtype=torch.float32)
    got = OpExec(_img2col_conv_sim, simulator=True)(data, wz, out, 1)
    ref = torch.nn.functional.conv2d(
        torch.nn.functional.pad(x.float(), (PAD[0], PAD[1], PAD[2], PAD[3])), w.float())
    ref = ref.reshape(COUT, M).t()
    assert torch.allclose(got[:M], ref, rtol=3e-3, atol=3e-3), float((got[:M] - ref).abs().max())
    assert torch.all(got[M:] == 0)


def test_img2col_padding_does_not_multiply_clamped_inf():
    x = torch.zeros((1, C, H, W), dtype=torch.float16)
    x[0, 0, 0, 0] = float("inf")
    w = torch.ones((COUT, C, KH, KW), dtype=torch.float16)
    data = torch.from_numpy(pack_nc1hwc0(x.numpy()))
    wz = torch.from_numpy(pack_conv_weight(w.numpy()))
    out = torch.zeros((M_PAD, COUT), dtype=torch.float32)
    got = OpExec(_img2col_conv_sim, simulator=True)(data, wz, out, 1)
    ref = torch.nn.functional.conv2d(
        torch.nn.functional.pad(x.float(), (PAD[0], PAD[1], PAD[2], PAD[3])),
        w.float()).reshape(COUT, M).t()
    assert torch.equal(torch.isnan(got[:M]), torch.isnan(ref))
    torch.testing.assert_close(got[:M], ref, rtol=0, atol=0, equal_nan=True)
    assert torch.all(got[M:] == 0)


@kernel()
def _conv2d_shortcut_sim(data: GMTensor, weight: GMTensor, bias: GMTensor, out: GMTensor, nb: Var):
    conv = Conv2D(KH, KW, pad=PAD)
    fm = Tensor(DT.half, [C1 * H * W, C0], Position.L1)
    w_l1 = Tensor(DT.half, [COUT, K], Position.L1)
    b_l1 = Tensor(DT.float, [1, COUT], Position.L1, layout=Layout.ND)
    l0c = Tensor(DT.float, [M_PAD, COUT], Position.L0C)
    with auto_sync():
        fm <<= data[:, :]
        w_l1 <<= weight[:, :]
        b_l1 <<= bias[:, :]
        conv2d(l0c, fm, w_l1, conv, h=H, w=W, c=C, cout=COUT, m0=0, bias=b_l1)
        l0c_to_gm_nz2nz(out[0:M_PAD, :], l0c, m_pad=M_PAD)
    return out


def test_conv2d_shortcut_with_bias_matches_torch():
    g = torch.Generator().manual_seed(1)
    x = (torch.rand((1, C, H, W), generator=g) * 2 - 1).half()
    w = (torch.rand((COUT, C, KH, KW), generator=g) * 2 - 1).half()
    b = (torch.rand((COUT,), generator=g) * 2 - 1).float()
    data = torch.from_numpy(pack_nc1hwc0(x.numpy()))
    wz = torch.from_numpy(pack_conv_weight(w.numpy()))
    bp = b.reshape(1, COUT).contiguous()
    out = torch.zeros((COUT // C0 * M_PAD, C0), dtype=torch.float32)
    got = OpExec(_conv2d_shortcut_sim, simulator=True)(data, wz, bp, out, 1)
    got = got.reshape(COUT // C0, M_PAD, C0).permute(1, 0, 2).reshape(M_PAD, COUT)
    ref = torch.nn.functional.conv2d(
        torch.nn.functional.pad(x.float(), (PAD[0], PAD[1], PAD[2], PAD[3])), w.float(), b)
    ref = ref.reshape(COUT, M).t()
    assert torch.allclose(got[:M], ref, rtol=3e-3, atol=3e-3), float((got[:M] - ref).abs().max())


# ---- Var (runtime-shape) conv2d shortcut: sub-cap C/COUT through Var path ----

C_MAXV, H_MAXV, W_MAXV, COUT_MAXV = 32, 8, 8, 64    # C1*H*W stays 16-aligned (nd2nz)
C1_MAXV = (C_MAXV + C0 - 1) // C0
K_MAXV = C1_MAXV * KH * KW * C0
COUT_PV = (COUT_MAXV + 15) // 16 * 16
TILE_KV = 256


@kernel()
def _conv2d_var_sim(data: GMTensor, weight: GMTensor, bias: GMTensor, out: GMTensor,
                    h: Var, w: Var, c: Var, cout: Var, m_pad: Var):
    conv = Conv2D(KH, KW, pad=PAD)
    fm = Tensor(DT.half, [C1_MAXV * H_MAXV * W_MAXV, C0], Position.L1)
    w_l1 = Tensor(DT.half, [COUT_PV, K_MAXV], Position.L1)
    b_l1 = Tensor(DT.float, [1, COUT_PV], Position.L1, layout=Layout.ND)
    l0c = Tensor(DT.float, [16, COUT_PV], Position.L0C)
    with auto_sync():
        fm <<= data[:, :]
        w_l1 <<= weight[:, :]
        b_l1 <<= bias[:, :]
        for m0 in range(0, m_pad, 16):
            conv2d(l0c, fm, w_l1, conv, h=h, w=w, c=c, cout=cout, m0=m0,
                   tile_k=TILE_KV, bias=b_l1)
            l0c_to_gm_nz2nz(out[m0:m0 + 16, :], l0c, m_pad=m_pad)
    return out


def test_conv2d_var_shapes_match_torch():
    g = torch.Generator().manual_seed(2)
    Cv, Hv, Wv, COUTv = 20, 6, 6, 40          # runtime < static caps
    HOv = Hv + PAD[2] + PAD[3] - KH + 1
    WOv = Wv + PAD[0] + PAD[1] - KW + 1
    Mv, M_PADv = HOv * WOv, ((HOv * WOv + 15) // 16) * 16
    x = (torch.rand((1, Cv, Hv, Wv), generator=g) * 2 - 1).half()
    w = (torch.rand((COUTv, Cv, KH, KW), generator=g) * 2 - 1).half()
    b = (torch.rand((COUTv,), generator=g) * 2 - 1).float()
    data = torch.zeros((C1_MAXV * H_MAXV * W_MAXV, C0), dtype=torch.float16)
    data[:(Cv + C0 - 1) // C0 * Hv * Wv] = torch.from_numpy(pack_nc1hwc0(x.numpy()))
    wz = torch.zeros((COUT_PV, K_MAXV), dtype=torch.float16)
    wk = torch.from_numpy(pack_conv_weight(w.numpy()))
    wz[:wk.shape[0], :wk.shape[1]] = wk
    bp = torch.zeros((1, COUT_PV), dtype=torch.float32)
    bp[0, :COUTv] = b
    out = torch.zeros((COUT_PV // C0 * M_PADv, C0), dtype=torch.float32)
    got = OpExec(_conv2d_var_sim, simulator=True)(data, wz, bp, out, Hv, Wv, Cv, COUTv, M_PADv)
    got = got.reshape(COUT_PV // C0, M_PADv, C0).permute(1, 0, 2).reshape(M_PADv, COUT_PV)
    ref = torch.nn.functional.conv2d(
        torch.nn.functional.pad(x.float(), (PAD[0], PAD[1], PAD[2], PAD[3])), w.float(), b)
    ref = ref.reshape(COUTv, Mv).t()
    assert torch.allclose(got[:Mv, :COUTv], ref, rtol=3e-3, atol=3e-3), \
        float((got[:Mv, :COUTv] - ref).abs().max())
    assert torch.all(got[:, COUTv:] == 0)
