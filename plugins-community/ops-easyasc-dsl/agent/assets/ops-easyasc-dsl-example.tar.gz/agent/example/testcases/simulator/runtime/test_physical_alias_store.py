import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.physical_alias import PhysicalAlias


def test_shared_memory_store_snapshot_preserves_registered_alias() -> None:
    store = SharedMemoryStore()
    src = torch.arange(16, dtype=torch.float32).reshape(4, 4)
    view = src[1:3, 1:3]
    store.register_view("src", src)
    store.register_view(
        "tail",
        PhysicalAlias(
            tensor=src,
            logical_view=view,
            byte_offset=5 * 4,
            logical_offset_bytes=5 * 4,
            name="tail",
            storage_name="src",
            role="ub",
            tags=("runtime_view", "slice_tensor"),
        ),
    )

    snap = store.snapshot()
    restored = SharedMemoryStore()
    restored.load_snapshot(snap)

    alias = restored.alias("tail")
    assert alias is not None
    assert alias.storage_name == "src"
    assert alias.byte_offset == 5 * 4
    assert alias.logical_offset_bytes == 5 * 4
    torch.testing.assert_close(restored.tensor("tail"), view)
