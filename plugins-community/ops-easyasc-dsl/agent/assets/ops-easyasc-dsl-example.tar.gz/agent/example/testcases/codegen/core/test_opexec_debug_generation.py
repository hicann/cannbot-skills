from pathlib import Path

import torch
import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.kernelbase.kernelbase import _cann_version_ge, _custom_op_archive_name


@kernel()
def _debug_workspace_kernel(inp: GMTensor, out: GMTensor, m: Var):
    return out


@kernel()
def _debug_split_workspace_kernel(inp: GMTensor, out: GMTensor, m: Var):
    split_workspace(DT.half, [m, 16], name="debug_ws")
    return out


@kernel()
def _debug_split_workspace_helper_kernel(inp: GMTensor, out: GMTensor, m: Var):
    split_workspace(DT.float, [GetCubeNum(), GetVecNum(), m], name="debug_ws")
    return out


@kernel()
def _standard_generation_kernel(inp: GMTensor, out: GMTensor, m: Var):
    return out


@kernel()
def _nonfinite_float_var_kernel(inp: GMTensor, out: GMTensor, neg_inf: Var, pos_inf: Var, nan_val: Var):
    return out


def test_cann_version_parser_accepts_compiler_version_info(tmp_path) -> None:
    cann_path = tmp_path / "cann-9.0.0"
    compiler_dir = cann_path / "compiler"
    compiler_dir.mkdir(parents=True)
    (compiler_dir / "version.info").write_text("Version=9.0.0\nversion_dir=cann\n", encoding="utf-8")

    assert _cann_version_ge(str(cann_path), (9, 0))
    assert _custom_op_archive_name("b3", str(cann_path)) == "CustomOp_a2_cann9.tar.gz"
    assert _custom_op_archive_name("a3", str(cann_path)) == "CustomOp_a2_cann9.tar.gz"


def test_custom_op_archive_keeps_legacy_defaults_for_missing_version(tmp_path) -> None:
    cann_path = tmp_path / "cann-unknown"
    cann_path.mkdir()

    assert not _cann_version_ge(str(cann_path), (9, 0))
    assert _custom_op_archive_name("b3", str(cann_path)) == "CustomOp_a2.tar.gz"
    assert _custom_op_archive_name("a3", str(cann_path)) == "CustomOp_a2.tar.gz"
    assert _custom_op_archive_name("950", str(cann_path)) == "CustomOp.tar.gz"
    assert _custom_op_archive_name("950pr", str(cann_path)) == "CustomOp.tar.gz"


@pytest.mark.parametrize("device_type, expected_unit", [
    ("b3", "ascend910b"),
    ("a3", "ascend910_93"),
])
def test_generate_op_project_extracts_cann9_c220_template(
    tmp_path, device_type: str, expected_unit: str,
) -> None:
    cann_path = tmp_path / "cann-9.0.0"
    compiler_dir = cann_path / "compiler"
    compiler_dir.mkdir(parents=True)
    (compiler_dir / "version.info").write_text("Version=9.0.0\n", encoding="utf-8")

    out_dir = tmp_path / "custom_op"
    saved_device_type = globvars.device_type
    globvars.device_type = device_type
    try:
        _standard_generation_kernel.generate_op_project(str(out_dir), str(cann_path))
    finally:
        globvars.device_type = saved_device_type

    assert (out_dir / "build.sh").is_file()
    assert (out_dir / "op_host" / "CMakeLists.txt").is_file()
    assert not (out_dir / "op_host" / "add_custom.cpp").exists()
    assert not (out_dir / "op_kernel" / "add_custom.cpp").exists()
    preset_text = (out_dir / "CMakePresets.json").read_text(encoding="utf-8")
    assert str(cann_path) in preset_text
    assert expected_unit in preset_text


def test_gen_only_fills_missing_cann_path_with_empty_string(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("ASCEND_HOME_PATH", raising=False)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    OpExec(
        _standard_generation_kernel,
        out_dir="standard_out",
        gen_only=True,
    )(inp, out, 1)

    setup_text = (tmp_path / "standard_out_aclnn_test" / "setup_aclnn.py").read_text(encoding="utf-8")
    assert "ascend_toolkit_install_path = ''" in setup_text


def test_full_project_releases_workspace_after_stream_sync(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    OpExec(
        _standard_generation_kernel,
        out_dir="standard_out",
        gen_only=True,
        profile=True,
    )(inp, out, 1)

    main_text = (tmp_path / "standard_out_aclnn_test" / "test.cpp").read_text(encoding="utf-8")
    assert "RELEASE_OP_WORKSPACE(stream);" in main_text

    repo_root = Path(__file__).resolve().parents[5]
    macros_text = (repo_root / "easyasc" / "resources" / "macros.h").read_text(encoding="utf-8")
    assert "uint64_t workspaceCapacity = 0;" in macros_text
    assert "#define RELEASE_OP_WORKSPACE(stream)" in macros_text


def _assert_nonfinite_var_decls_use_cpp_builtins(text: str) -> None:
    assert "float neg_inf = -__builtin_inff();" in text
    assert "float pos_inf = __builtin_inff();" in text
    assert 'float nan_val = __builtin_nanf("");' in text
    assert " = -inf;" not in text
    assert " = inf;" not in text
    assert " = nan;" not in text


def test_full_project_formats_nonfinite_float_var_declarations(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    OpExec(
        _nonfinite_float_var_kernel,
        out_dir="nonfinite_out",
        gen_only=True,
    )(inp, out, float("-inf"), float("inf"), float("nan"))

    main_text = (tmp_path / "nonfinite_out_aclnn_test" / "test.cpp").read_text(encoding="utf-8")
    _assert_nonfinite_var_decls_use_cpp_builtins(main_text)


def test_debug_project_formats_nonfinite_float_var_declarations(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    OpExec(
        _nonfinite_float_var_kernel,
        out_dir="nonfinite_debug_out",
        gen_only=True,
        debug=True,
    )(inp, out, float("-inf"), float("inf"), float("nan"))

    main_text = (tmp_path / "nonfinite_debug_out" / "debug_workspace" / "main.cpp").read_text(encoding="utf-8")
    _assert_nonfinite_var_decls_use_cpp_builtins(main_text)


def test_opexec_debug_profile_includes_speed_test(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    OpExec(
        _debug_workspace_kernel,
        out_dir="debug_out",
        gen_only=True,
        debug=True,
        profile=True,
    )(inp, out, 1)

    main_text = (tmp_path / "debug_out" / "debug_workspace" / "main.cpp").read_text(encoding="utf-8")
    assert f"SPEED_TEST({_debug_workspace_kernel.name}," in main_text
    kernel_text = (
        tmp_path / "debug_out" / "debug_workspace" /
        "{}.cpp".format(_debug_workspace_kernel.name)
    ).read_text(encoding="utf-8")
    assert "SetSysWorkspaceForce" not in kernel_text
    assert "GetUserWorkspace" not in kernel_text


def test_debug_workspace_reserves_system_headroom_before_dtype_sized_user_area(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    inp = torch.randn(3, 16).half()
    out = torch.zeros(3, 16).half()

    OpExec(
        _debug_split_workspace_kernel,
        out_dir="debug_out",
        gen_only=True,
        debug=True,
    )(inp, out, 3)

    main_text = (tmp_path / "debug_out" / "debug_workspace" / "main.cpp").read_text(encoding="utf-8")
    assert "DEFINE_VARIABLE(workspace, 16 * 1024 * 1024 + m*16*sizeof(uint16_t));" in main_text
    kernel_text = (
        tmp_path / "debug_out" / "debug_workspace" /
        "{}.cpp".format(_debug_split_workspace_kernel.name)
    ).read_text(encoding="utf-8")
    assert "AscendC::SetSysWorkspaceForce(workspace);" in kernel_text
    # The entry registers the system region but hands the helpers the raw base;
    # `split_workspace` offsets past it once, inside the helper.
    assert "GetUserWorkspace" not in kernel_text
    assert "_debug_split_workspace_kernel_cube(inp, out, workspace, m);" in kernel_text
    assert "_debug_split_workspace_kernel_vec(inp, out, workspace, m);" in kernel_text


def test_debug_chipset_rejects_unsupported_device_type() -> None:
    with pytest.raises(ValueError, match="Unsupported device_type for debug scripts"):
        _debug_workspace_kernel._resolve_debug_chipset("foo")


def test_a3_debug_chipset_uses_exact_9362_soc() -> None:
    assert _debug_workspace_kernel._resolve_debug_chipset("a3") == "Ascend910_9362"
    repo_root = Path(__file__).resolve().parents[5]
    for script_name in ("build.sh", "run.sh"):
        script = repo_root / "easyasc" / "resources" / "debug" / script_name
        assert "Ascend910_9362" in script.read_text(encoding="utf-8")


@pytest.mark.parametrize("device_type, expected_cube, expected_vec", [
    ("b1", 24, 48),
    ("b3", 20, 40),
    ("a3", 20, 40),
    ("950", 32, 64),
    ("950pr", 28, 56),
])
def test_debug_workspace_uses_device_specific_helper_counts(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
    device_type: str,
    expected_cube: int,
    expected_vec: int,
) -> None:
    monkeypatch.chdir(tmp_path)
    saved_device_type = globvars.device_type
    globvars.device_type = device_type
    try:
        inp = torch.randn(1, 1).float()
        out = torch.zeros(1, 1).float()

        OpExec(
            _debug_split_workspace_helper_kernel,
            out_dir="debug_out",
            gen_only=True,
            debug=True,
        )(inp, out, 3)

        main_text = (tmp_path / "debug_out" / "debug_workspace" / "main.cpp").read_text(encoding="utf-8")
        workspace_expr = f"{expected_cube}*{expected_vec}*m*sizeof(float)"
        if device_type in ("950", "950pr"):
            workspace_expr = "16 * 1024 * 1024 + " + workspace_expr
        assert f"DEFINE_VARIABLE(workspace, {workspace_expr});" in main_text

        kernel_text = (
            tmp_path / "debug_out" / "debug_workspace" /
            "{}.cpp".format(_debug_split_workspace_helper_kernel.name)
        ).read_text(encoding="utf-8")
        if device_type in ("950", "950pr"):
            assert "AscendC::SetSysWorkspaceForce(workspace);" in kernel_text
        else:
            assert "SetSysWorkspaceForce" not in kernel_text
        # Whatever the device, the entry never pre-offsets the pointer it passes
        # down -- that would make every split_workspace offset a second time.
        assert "GetUserWorkspace" not in kernel_text
        assert "workspace_usr" not in kernel_text
    finally:
        globvars.device_type = saved_device_type
