import threading
from types import SimpleNamespace

import pytest
import torch

from easyasc.simulator.pipe_cube import CubeMTE1Pipe, CubeMTE2Pipe, FixPipe, MPipe
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe import PipeBase, PipeS
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.simulator.physical_alias import PhysicalAlias
from easyasc.simulator.pipe_vec import MTE3Pipe, VPipe, VecMTE2Pipe
from easyasc.simulator.program import ControlInstruction, PipeTask
from easyasc.simulator.sync import Mailbox
from easyasc.simulator.trace import TraceEventKind, TraceRecorder
from easyasc.utils.comparemode import CompareMode
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.instruction import Instruction
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.var import Var

from testcases.simulator.micro._micro_test_helpers import _TensorStore


def test_pipe_s_var_ops_preserve_float_values() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    values = {}

    pipe_s._handle_var_op(ControlInstruction("create_var", args={"name": "base", "value": 1.25}), values)
    pipe_s._handle_var_op(ControlInstruction("var_mul", args={"dst": "scale", "a": "base", "b": 0.5}), values)
    pipe_s._handle_var_op(ControlInstruction("var_add", args={"dst": "shifted", "a": "scale", "b": 0.125}), values)
    pipe_s._handle_var_op(ControlInstruction("var_div", args={"dst": "ratio", "a": "shifted", "b": 0.5}), values)

    assert values["scale"] == pytest.approx(0.625)
    assert values["shifted"] == pytest.approx(0.75)
    assert values["ratio"] == pytest.approx(1.5)
def test_pipe_s_dispatch_snapshots_var_values() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.mailboxes = {"V": Mailbox(maxsize=4)}
    pipe_s._atomic_mode = ""

    values = {"src_alias": "src0", "scalar": 7}
    inst = ControlInstruction("adds", args={"dst": "dst0", "src": "src_alias", "value": "scalar"}, pipe_name="V")

    pipe_s._dispatch(inst, values)
    values["src_alias"] = "src1"
    values["scalar"] = 9

    task = pipe_s.mailboxes["V"].get(block=False)
    assert isinstance(task, PipeTask)
    assert task.args["src"] == "src0"
    assert task.args["value"] == 7
def test_pipe_s_control_alias_helpers_reject_invalid_inputs() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s._vars = {}
    pipe_s.memory_store = _TensorStore()

    with pytest.raises(ValueError, match="get_buf requires view_name"):
        pipe_s._handle_get_buf(ControlInstruction("get_buf", args={"slot_names": ["buf0"]}))

    with pytest.raises(ValueError, match="non-empty slot_names"):
        pipe_s._handle_get_buf(ControlInstruction("get_buf", args={"view_name": "view", "slot_names": []}))

    with pytest.raises(ValueError, match="slice_gm_tensor requires view_name and source_name"):
        pipe_s._handle_slice_gm_tensor(ControlInstruction("slice_gm_tensor", args={"ndim": 1}))

    with pytest.raises(ValueError, match="slice_gm_tensor requires ndim > 0"):
        pipe_s._handle_slice_gm_tensor(
            ControlInstruction("slice_gm_tensor", args={"view_name": "view", "source_name": "gm", "ndim": 0})
        )

    with pytest.raises(KeyError, match="slice_gm_tensor source tensor not found"):
        pipe_s._handle_slice_gm_tensor(
            ControlInstruction("slice_gm_tensor", args={"view_name": "view", "source_name": "gm", "ndim": 1})
        )

    with pytest.raises(ValueError, match="reinterpret requires view_name and source_name"):
        pipe_s._handle_reinterpret(ControlInstruction("reinterpret", args={"view_name": "view"}))

    pipe_s._vars["not_tensor"] = 3
    with pytest.raises(KeyError, match="reinterpret source alias did not resolve"):
        pipe_s._handle_reinterpret(
            ControlInstruction("reinterpret", args={"view_name": "view", "source_name": "not_tensor"})
        )

    with pytest.raises(ValueError, match="slice_tensor requires view_name and source_name"):
        pipe_s._handle_slice_tensor(ControlInstruction("slice_tensor", args={"view_name": "view"}))

    with pytest.raises(KeyError, match="slice_tensor source alias did not resolve"):
        pipe_s._handle_slice_tensor(
            ControlInstruction("slice_tensor", args={"view_name": "view", "source_name": "not_tensor"})
        )
def test_pipe_s_get_buf_uses_runtime_index_value() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s._vars = {"slot_idx": 0}

    inst = ControlInstruction(
        "get_buf",
        args={"view_name": "view", "index": "slot_idx", "slot_names": ["buf0", "buf1"]},
    )

    pipe_s._handle_get_buf(inst)
    assert pipe_s._vars["view"] == "buf0"

    pipe_s._vars["slot_idx"] = 1
    pipe_s._handle_get_buf(inst)
    assert pipe_s._vars["view"] == "buf1"

    pipe_s._vars["slot_idx"] = 2
    pipe_s._handle_get_buf(inst)
    assert pipe_s._vars["view"] == "buf0"
def test_pipe_s_slice_tensor_registers_runtime_view() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32).reshape(4, 4)})
    pipe_s._vars = {}

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "view",
                "source_name": "src",
                "ndim": 2,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    view_name = pipe_s._vars["view"]
    assert view_name.startswith("view@src:1,1:2,2")
    expected = torch.tensor([[5.0, 6.0], [9.0, 10.0]], dtype=torch.float32)
    torch.testing.assert_close(pipe_s.memory_store.tensor(view_name), expected)


def test_pipe_s_slice_tensor_registers_runtime_alias_with_physical_offset() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32).reshape(4, 4)})
    pipe_s._vars = {}

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "view",
                "source_name": "src",
                "ndim": 2,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    alias = pipe_s.memory_store.alias(pipe_s._vars["view"])
    assert alias is not None
    assert isinstance(alias, PhysicalAlias)
    assert alias.storage_name == "src"
    assert alias.byte_offset == 5 * 4
    torch.testing.assert_close(alias.logical_tensor(), torch.tensor([[5.0, 6.0], [9.0, 10.0]], dtype=torch.float32))
def test_pipe_s_slice_tensor_reshapes_flat_storage_before_slicing() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32)})
    pipe_s._vars = {}

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "view",
                "source_name": "src",
                "ndim": 2,
                "src_dim_0": 4,
                "src_dim_1": 4,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    expected = torch.tensor([[5.0, 6.0], [9.0, 10.0]], dtype=torch.float32)
    view_name = pipe_s._vars["view"]
    assert view_name.startswith("view@src:1,1:2,2")
    torch.testing.assert_close(pipe_s.memory_store.tensor(view_name), expected)
def test_pipe_s_slice_tensor_registers_scoped_runtime_view() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {"view": "_vec1_view"}
    pipe_s.memory_store = _TensorStore(
        {
            "src": torch.arange(16, dtype=torch.float32).reshape(4, 4),
            "_vec1_view": torch.zeros((2, 2), dtype=torch.float32),
        }
    )
    pipe_s._vars = {}

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "view",
                "source_name": "src",
                "ndim": 2,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    view_name = pipe_s._vars["view"]
    assert view_name.startswith("_vec1_view@src:1,1:2,2")
    expected = torch.tensor([[5.0, 6.0], [9.0, 10.0]], dtype=torch.float32)
    torch.testing.assert_close(pipe_s.memory_store.tensor(view_name), expected)
def test_pipe_s_slice_tensor_keeps_distinct_views_for_reused_name() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.memory_store = _TensorStore(
        {
            "slot0": torch.arange(16, dtype=torch.float32).reshape(4, 4),
            "slot1": (torch.arange(16, dtype=torch.float32).reshape(4, 4) + 100.0),
        }
    )
    pipe_s._vars = {"src": "slot0"}

    inst = ControlInstruction(
        "slice_tensor",
        args={
            "view_name": "view",
            "source_name": "src",
            "ndim": 2,
            "offset_0": 1,
            "offset_1": 1,
            "span_0": 2,
            "span_1": 2,
            "step_0": 1,
            "step_1": 1,
        },
    )

    pipe_s._handle_slice_tensor(inst)
    first_view = pipe_s._vars["view"]

    pipe_s._vars["src"] = "slot1"
    pipe_s._handle_slice_tensor(inst)
    second_view = pipe_s._vars["view"]

    assert first_view != second_view
    torch.testing.assert_close(
        pipe_s.memory_store.tensor(first_view),
        torch.tensor([[5.0, 6.0], [9.0, 10.0]], dtype=torch.float32),
    )
    torch.testing.assert_close(
        pipe_s.memory_store.tensor(second_view),
        torch.tensor([[105.0, 106.0], [109.0, 110.0]], dtype=torch.float32),
    )


def test_pipe_s_slice_tensor_packed_local_alias_tracks_physical_offset() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32)})
    pipe_s.memory_store.specs["src"] = SimpleNamespace(role="l0a")
    pipe_s._vars = {}

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "view",
                "source_name": "src",
                "ndim": 2,
                "src_dim_0": 4,
                "src_dim_1": 4,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    view_name = pipe_s._vars["view"]
    alias = pipe_s.memory_store.alias(view_name)
    assert alias is not None
    assert alias.storage_name == "src"
    assert alias.byte_offset == 12 * 4
    torch.testing.assert_close(pipe_s.memory_store.tensor(view_name), pipe_s.memory_store.tensor("src").reshape(4, 4))


def test_pipe_s_get_value_from_reads_dense_slice_head() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32).reshape(4, 4)})
    pipe_s._vars = {}

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "view",
                "source_name": "src",
                "ndim": 2,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    pipe_s._handle_get_value_from(
        ControlInstruction("GetValueFrom", args={"dst": "scalar", "src": pipe_s._vars["view"], "dtype": "float"})
    )

    assert pipe_s._vars["scalar"] == pytest.approx(5.0)


def test_pipe_s_get_set_value_use_packed_local_alias_base_offset() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32)})
    pipe_s.memory_store.specs["src"] = SimpleNamespace(role="l0a")
    pipe_s._vars = {}

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "view",
                "source_name": "src",
                "ndim": 2,
                "src_dim_0": 4,
                "src_dim_1": 4,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    view_name = pipe_s._vars["view"]
    pipe_s._handle_get_value_from(
        ControlInstruction("GetValueFrom", args={"dst": "scalar", "src": view_name, "dtype": "float"})
    )
    assert pipe_s._vars["scalar"] == pytest.approx(12.0)

    pipe_s._vars["scalar"] = 77.0
    pipe_s._handle_set_value_to(
        ControlInstruction("SetValueTo", args={"src": view_name, "dst": "scalar", "dtype": "float"})
    )

    src = pipe_s.memory_store.tensor("src")
    assert float(src.reshape(-1)[12].item()) == pytest.approx(77.0)
    assert float(src.reshape(-1)[0].item()) == pytest.approx(0.0)


@pytest.mark.parametrize("dtype_name", ["int4", "fp4_e2m1", "hif8"])
def test_pipe_s_reinterpret_preserves_source_alias_logical_offset(dtype_name: str) -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    src = torch.arange(32, dtype=torch.uint8)
    pipe_s.memory_store = _TensorStore({"src": src})
    pipe_s._vars = {}
    pipe_s.memory_store.register_view(
        "src_tail",
        PhysicalAlias(
            tensor=src,
            logical_view=src,
            byte_offset=8,
            logical_offset_bytes=8,
            name="src_tail",
            storage_name="src",
            role="ub",
            tags=("runtime_view", "seed"),
        ),
    )
    pipe_s.memory_store.specs["view"] = SimpleNamespace(dtype=dtype_name, storage_offset=0, shape=(8,), view_shape=(8,))

    pipe_s._handle_reinterpret(
        ControlInstruction("reinterpret", args={"view_name": "view", "source_name": "src_tail"})
    )

    alias = pipe_s.memory_store.alias(pipe_s._vars["view"])
    assert alias is not None
    assert alias.storage_name == "src"
    assert alias.logical_offset_bytes == 8
    assert int(pipe_s.memory_store.tensor(pipe_s._vars["view"]).reshape(-1)[0].item()) == 8
def test_pipe_s_slice_tensor_keeps_l0c_alias() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32)})
    pipe_s.memory_store.specs["src"] = SimpleNamespace(role="l0c")
    pipe_s._vars = {}

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "view",
                "source_name": "src",
                "ndim": 2,
                "src_dim_0": 4,
                "src_dim_1": 4,
                "offset_0": 0,
                "offset_1": 0,
                "span_0": 4,
                "span_1": 4,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    assert pipe_s._vars["view"] == "src"


def test_pipe_s_dispatch_call_micro_binds_store_alias() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.mailboxes = {"V": Mailbox(maxsize=4)}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32).reshape(4, 4)})
    pipe_s._vars = {}
    pipe_s._atomic_mode = ""
    pipe_s.current_cycle = 0.0
    pipe_s.micro_defs = {
        "probe": {"input_list": [SimpleNamespace(name="src")]}
    }

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "tmp",
                "source_name": "src",
                "ndim": 2,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    pipe_s._dispatch_call_micro(
        ControlInstruction(
            "call_micro",
            pipe_name="V",
            args={
                "name": "probe",
                "call_bindings": [{"kind": "tensor", "actual_name": "tmp"}],
            },
        )
    )

    task = pipe_s.mailboxes["V"].get(block=False)
    alias = task.args["tensor_views"]["src"]
    assert isinstance(alias, PhysicalAlias)
    assert alias.storage_name == "src"
    assert alias.byte_offset == 5 * 4


def test_pipe_s_slice_gm_tensor_dispatch_call_micro_binds_offset_alias() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.mailboxes = {"V": Mailbox(maxsize=4)}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(256 * 128, dtype=torch.float32)})
    pipe_s._vars = {}
    pipe_s._atomic_mode = ""
    pipe_s.current_cycle = 0.0
    pipe_s.micro_defs = {
        "probe": {"input_list": [SimpleNamespace(name="src")]}
    }

    pipe_s._handle_slice_gm_tensor(
        ControlInstruction(
            "slice_gm_tensor",
            args={
                "view_name": "tmp",
                "source_name": "src",
                "ndim": 2,
                "offset_0": 128,
                "offset_1": 0,
                "src_dim_0": 256,
                "src_dim_1": 128,
                "span_0": 8,
                "span_1": 128,
            },
        )
    )

    pipe_s._dispatch_call_micro(
        ControlInstruction(
            "call_micro",
            pipe_name="V",
            args={
                "name": "probe",
                "call_bindings": [{"kind": "tensor", "actual_name": "tmp"}],
            },
        )
    )

    task = pipe_s.mailboxes["V"].get(block=False)
    alias = task.args["tensor_views"]["src"]
    assert isinstance(alias, PhysicalAlias)
    assert alias.storage_name == "src"
    assert alias.byte_offset == 128 * 128 * 4


def test_pipe_s_dispatch_call_simt_binds_store_alias() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    pipe_s.mailboxes = {"V": Mailbox(maxsize=4)}
    pipe_s.memory_store = _TensorStore({"src": torch.arange(16, dtype=torch.float32).reshape(4, 4)})
    pipe_s._vars = {}
    pipe_s._atomic_mode = ""
    pipe_s.current_cycle = 0.0
    pipe_s.core_idx = 0
    pipe_s.config = SimpleNamespace(core_count=1)
    pipe_s.simt_defs = {
        "probe": {"input_list": [("src", "Tensor")]}
    }

    pipe_s._handle_slice_tensor(
        ControlInstruction(
            "slice_tensor",
            args={
                "view_name": "tmp",
                "source_name": "src",
                "ndim": 2,
                "offset_0": 1,
                "offset_1": 1,
                "span_0": 2,
                "span_1": 2,
                "step_0": 1,
                "step_1": 1,
            },
        )
    )

    pipe_s._dispatch_call_simt(
        ControlInstruction(
            "call_simt",
            pipe_name="V",
            args={
                "name": "probe",
                "call_bindings": [{"kind": "tensor", "actual_name": "tmp"}],
            },
        )
    )

    task = pipe_s.mailboxes["V"].get(block=False)
    alias = task.args["tensor_views"]["src"]
    assert isinstance(alias, PhysicalAlias)
    assert alias.storage_name == "src"
    assert alias.byte_offset == 5 * 4


def test_pipe_base_trace_records_tensor_binding_summary_for_aliases() -> None:
    pipe = PipeBase(
        core_idx=0,
        lane_name="vec0",
        pipe_name="V",
        mailbox=Mailbox(maxsize=4),
        bar_all_barrier=threading.Barrier(1),
        memory_store=SharedMemoryStore(),
        trace_recorder=TraceRecorder(core_idx=0),
        cycle_model=SimpleNamespace(profile_name="unit"),
    )
    base = torch.arange(16, dtype=torch.float32).reshape(4, 4)
    alias = PhysicalAlias(
        tensor=base,
        logical_view=base[1:3, 1:3],
        byte_offset=5 * 4,
        logical_offset_bytes=5 * 4,
        name="src",
        storage_name="src_storage",
        role="ub",
        tags=("runtime_view", "slice_tensor"),
    )
    pipe._current_task = PipeTask(
        pipe_name="V",
        opname="call_simt",
        args={"tensor_views": {"src": alias}},
    )

    pipe._record_event(TraceEventKind.PIPE, "call_simt", wall_start_ts=1.0, cycle_start=10.0, cycle_end=14.0)

    events = pipe.trace_recorder.snapshot()
    assert len(events) == 1
    binding = events[0].args["tensor_bindings"]["src"]
    assert binding["storage_name"] == "src_storage"
    assert binding["byte_offset"] == 5 * 4
    assert binding["logical_shape"] == [2, 2]


def test_pipe_base_debug_descriptions_summarize_alias_bindings() -> None:
    pipe = PipeBase(
        core_idx=0,
        lane_name="vec0",
        pipe_name="V",
        mailbox=Mailbox(maxsize=4),
        bar_all_barrier=threading.Barrier(1),
        memory_store=SharedMemoryStore(),
    )
    base = torch.arange(16, dtype=torch.float32).reshape(4, 4)
    alias = PhysicalAlias(
        tensor=base,
        logical_view=base[1:3, 1:3],
        byte_offset=5 * 4,
        logical_offset_bytes=5 * 4,
        name="src",
        storage_name="src_storage",
        role="ub",
        tags=("runtime_view", "slice_tensor"),
    )
    task = PipeTask(pipe_name="V", opname="call_simt", args={"tensor_views": {"src": alias}})
    pipe.mailbox.put(task)

    pending = pipe.describe_pending_tasks(limit=1)

    assert len(pending) == 1
    assert "src_storage" in pending[0]
    assert "byte_offset" in pending[0]
    assert "logical_shape" in pending[0]
def test_pipe_s_division_by_zero_raises() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    values = {}

    with pytest.raises(ZeroDivisionError, match="var_div division by zero"):
        pipe_s._handle_var_op(ControlInstruction("var_div", args={"dst": "x", "a": 4, "b": 0}), values)

    with pytest.raises(ZeroDivisionError, match="var_mod division by zero"):
        pipe_s._handle_var_op(ControlInstruction("var_mod", args={"dst": "x", "a": 4, "b": 0}), values)

    with pytest.raises(ZeroDivisionError, match="CeilDiv division by zero"):
        pipe_s._handle_var_op(ControlInstruction("CeilDiv", args={"dst": "x", "a": 4, "b": 0}), values)
def test_pipe_s_align_suffix_must_be_numeric() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s.tensor_name_map = {}
    values = {}

    with pytest.raises(ValueError, match="Align opcode suffix must be numeric: AlignFoo"):
        pipe_s._handle_var_op(ControlInstruction("AlignFoo", args={"dst": "x", "a": 9}), values)
def test_pipe_s_resolve_bool_raises_on_unparseable_expression() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s._vars = {}
    pipe_s.tensor_name_map = {}

    with pytest.raises(ValueError, match="cannot resolve boolean expression"):
        pipe_s._resolve_bool("unknown_symbol")


def test_pipe_s_resolve_bool_supports_loop_var_arithmetic_comparisons() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s._vars = {"pipe_work": 1, "work_end": 3, "work_begin": 0}
    pipe_s.tensor_name_map = {}

    assert pipe_s._resolve_bool("pipe_work < work_end")
    assert pipe_s._resolve_bool("pipe_work + 1 <= work_end")
    assert pipe_s._resolve_bool("pipe_work - 1 >= work_begin")
    assert not pipe_s._resolve_bool("pipe_work + 2 < work_end")


def test_pipe_s_resolve_bool_rejects_default_boolization_inputs() -> None:
    pipe_s = object.__new__(PipeS)
    pipe_s._vars = {"n": 3}
    pipe_s.tensor_name_map = {}

    with pytest.raises(ValueError, match="boolean condition is required"):
        pipe_s._resolve_bool(None)

    with pytest.raises(TypeError, match="boolean condition must not be a bare number"):
        pipe_s._resolve_bool(1)

    with pytest.raises(TypeError, match="boolean condition must not resolve to a bare number"):
        pipe_s._resolve_bool("n")

    with pytest.raises(TypeError, match="cannot resolve boolean condition"):
        pipe_s._resolve_bool(object())
