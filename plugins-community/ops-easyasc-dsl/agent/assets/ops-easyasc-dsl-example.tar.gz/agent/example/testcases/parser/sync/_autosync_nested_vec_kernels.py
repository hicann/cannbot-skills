from easyasc.a5 import *

from testcases.parser.sync._autosync_test_helpers import (
    INNER_TILES,
    NESTED_WIDTH,
    OUTER_TILES,
    SAME_STREAM_INNER_REPEATS,
    TILES,
    WIDTH,
)
from testcases.parser.sync._autosync_vec_kernels import double_row_vf

@vf()
def nested_state_accum_vf(state: Tensor, token: Tensor, out: Tensor):
    state_reg = Reg(DT.float)
    token_reg = Reg(DT.float)

    state_reg <<= state[0:1, 0:NESTED_WIDTH]
    token_reg <<= token[0:1, 0:NESTED_WIDTH]
    state_reg <<= state_reg + token_reg
    state[0:1, 0:NESTED_WIDTH] <<= state_reg
    out[0:1, 0:NESTED_WIDTH] <<= state_reg


@kernel()
def autosync_vec_parent_preload_child_mixed(
    state_in: GMTensor, token_in: GMTensor, state_out: GMTensor, token_out: GMTensor, outer_tiles: Var, inner_tiles: Var,
):
    state_ub = DBuff(DT.float, [1, NESTED_WIDTH], Position.UB)
    token_ub = DBuff(DT.float, [1, NESTED_WIDTH], Position.UB)
    out_ub = DBuff(DT.float, [1, NESTED_WIDTH], Position.UB)
    state_idx = Var(0)
    token_idx = Var(0)

    with auto_sync():
        for outer_idx in range(0, outer_tiles):
            state_ub[state_idx][0:1, 0:NESTED_WIDTH] <<= state_in[outer_idx:outer_idx + 1, 0:NESTED_WIDTH]
            for inner_idx in range(0, inner_tiles):
                flat_idx = Var(outer_idx * inner_tiles + inner_idx)
                token_ub[token_idx][0:1, 0:NESTED_WIDTH] <<= token_in[flat_idx:flat_idx + 1, 0:NESTED_WIDTH]
                nested_state_accum_vf(state_ub[state_idx], token_ub[token_idx], out_ub[token_idx])
                token_out[flat_idx:flat_idx + 1, 0:NESTED_WIDTH] <<= out_ub[token_idx][0:1, 0:NESTED_WIDTH]
                token_idx += 1
            state_out[outer_idx:outer_idx + 1, 0:NESTED_WIDTH] <<= state_ub[state_idx][0:1, 0:NESTED_WIDTH]

    return state_out, token_out


def build_nested_vec_parent_preload_child_mixed() -> None:
    state_in = GMTensor(DT.float, [OUTER_TILES, NESTED_WIDTH])
    token_in = GMTensor(DT.float, [OUTER_TILES * INNER_TILES, NESTED_WIDTH])
    state_out = GMTensor(DT.float, [OUTER_TILES, NESTED_WIDTH])
    token_out = GMTensor(DT.float, [OUTER_TILES * INNER_TILES, NESTED_WIDTH])
    autosync_vec_parent_preload_child_mixed(
        state_in, token_in, state_out, token_out,
        Var(OUTER_TILES), Var(INNER_TILES),
    )

@kernel()
def autosync_vec_parent_child_same_ubout_stream(x: GMTensor, y: GMTensor, tiles: Var, n: Var, repeats: Var):
    in_ub = DBuff(DT.half, [1, WIDTH], Position.UB)
    out_ub = DBuff(DT.half, [1, WIDTH], Position.UB)
    cnt = Var(0)

    with auto_sync():
        for tile_idx in range(0, tiles):
            in_ub[cnt][0:1, 0:n] <<= x[tile_idx:tile_idx + 1, 0:n]
            for repeat_idx in range(0, repeats):
                double_row_vf(in_ub[cnt], out_ub[cnt], n)
                y[tile_idx:tile_idx + 1, 0:n] <<= out_ub[cnt][0:1, 0:n]
            double_row_vf(in_ub[cnt], out_ub[cnt], n)
            y[tile_idx:tile_idx + 1, 0:n] <<= out_ub[cnt][0:1, 0:n]
            cnt += 1

    return y


def build_nested_same_ubout_stream() -> None:
    x = GMTensor(DT.half, [TILES, WIDTH])
    y = GMTensor(DT.half, [TILES, WIDTH])
    autosync_vec_parent_child_same_ubout_stream(
        x, y, Var(TILES), Var(WIDTH), Var(SAME_STREAM_INNER_REPEATS),
    )
