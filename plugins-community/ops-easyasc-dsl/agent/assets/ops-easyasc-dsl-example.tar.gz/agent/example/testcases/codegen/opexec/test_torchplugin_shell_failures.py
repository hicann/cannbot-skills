from pathlib import Path

import pytest

from easyasc.torchplugin import _run_bash_with_progress


def test_run_bash_with_progress_surfaces_log_tail_on_failure(tmp_path: Path) -> None:
    script = tmp_path / "fail.sh"
    log_path = tmp_path / "fail.log"
    script.write_text(
        "#!/bin/bash\n"
        "echo build-start\n"
        "echo compiler exploded >&2\n"
        "exit 7\n",
        encoding="utf-8",
    )

    with pytest.raises(RuntimeError, match=r"return code 7") as excinfo:
        _run_bash_with_progress(str(script), str(log_path))

    message = str(excinfo.value)
    assert "Last log lines:" in message
    assert "build-start" in message
    assert "compiler exploded" in message
