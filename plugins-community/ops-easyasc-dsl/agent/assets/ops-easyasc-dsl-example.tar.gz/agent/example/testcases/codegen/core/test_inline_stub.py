import pytest

from easyasc.a5 import *
from easyasc.parser.asc import translate


COLS = 128


@kernel()
def run_inline_passthrough(src: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.half, [1, cols], Position.UB)
    ub <<= src[0:1, :]
    inline("/* inline codegen marker */")
    dst[0:1, :] <<= ub
    return dst


@vf()
def micro_inline_marker(src: Tensor):
    inline("/* micro inline codegen marker */")


@kernel()
def run_micro_inline_passthrough(src: GMTensor, dst: GMTensor, cols: Var):
    src_ub = Tensor(DT.float, [1, COLS], Position.UB)
    if GetVecIdx() == 0:
        src_ub <<= src[0:1, 0:COLS]
        micro_inline_marker(src_ub)
        dst[0:1, 0:COLS] <<= src_ub
    return dst


def test_inline_rejects_non_string_code() -> None:
    with pytest.raises(TypeError, match="code must be str type"):
        inline(123)  # type: ignore[arg-type]


def test_micro_inline_codegen_marker_is_emitted() -> None:
    src = Tensor(DT.float, [1, COLS], Position.UB)

    micro_inline_marker(src)
    code = translate(micro_inline_marker.instructions)

    assert "/* micro inline codegen marker */" in code


def test_simulator_program_drops_inline() -> None:
    # `inline(...)` is a codegen-only marker; the simulator must treat it as a
    # no-op. The bridge drops _NOOP_OPS (including "inline") when building the
    # lane programs, so it never becomes executable work. Assert that directly
    # in-process -- no multi-process simulation, hence none of the back-to-back
    # shared-memory contention that made the old full-sim check batch-flaky.
    # (Mirrors test_set_hf32_stub.py::test_simulator_program_drops_set_hf32.)
    src = GMTensor(DT.half, [1, COLS], name="src")
    dst = GMTensor(DT.half, [1, COLS], name="dst")
    run_inline_passthrough(src, dst, Var(COLS, DT.int, name="cols"))

    # The kernel IR captured the inline marker ...
    assert any(inst.opname == "inline" for inst in run_inline_passthrough.instructions)
    # ... but the built simulator program drops it from every lane.
    program = run_inline_passthrough.build_simulator_program()
    opnames = [inst.opname for lane in program.lane_programs for inst in lane.instructions]
    assert "inline" not in opnames


def test_simulator_program_drops_micro_inline() -> None:
    # A micro (@vf) inline marker is captured in the micro body but must not
    # surface as an executable lane instruction in the simulator program either.
    src = GMTensor(DT.float, [1, COLS], name="src")
    dst = GMTensor(DT.float, [1, COLS], name="dst")
    run_micro_inline_passthrough(src, dst, Var(COLS, DT.int, name="cols"))

    # The micro body captured the inline marker ...
    assert any(inst.opname == "inline" for inst in micro_inline_marker.instructions)
    # ... but it never appears as a standalone lane instruction.
    program = run_micro_inline_passthrough.build_simulator_program()
    opnames = [inst.opname for lane in program.lane_programs for inst in lane.instructions]
    assert "inline" not in opnames
