import contextlib
import io

from easyasc.a5 import *
from easyasc.parser.asc import translate_split


def _translate_silently(instructions, name: str):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        return translate_split(instructions, name)


@kernel()
def var_ctor_copy_inline_codegen_kernel(dst: GMTensor, n: Var):
    with cube_scope():
        Var(n + 1).SetValueTo(dst)
    return dst


@kernel()
def var_ctor_copy_named_codegen_kernel(dst: GMTensor, n: Var):
    with cube_scope():
        copied = Var(n * 2, DT.int64)
        copied.SetValueTo(dst)
    return dst


def test_var_ctor_copy_does_not_mutate_source_var() -> None:
    src = Var(3, DT.int, name="src")

    copied = Var(src, DT.int64, name="copied")

    assert src.name == "src"
    assert src.dtype is DT.int
    assert copied.name == "copied"
    assert copied.dtype is DT.int64
    assert copied.idx != src.idx


def test_var_ctor_copy_tmp_is_folded_in_codegen() -> None:
    dst = GMTensor(DT.int, [1, 1], name="dst")
    n = Var(7, DT.int, name="n")
    var_ctor_copy_inline_codegen_kernel(dst, n)

    cube_code, vec_code = _translate_silently(
        var_ctor_copy_inline_codegen_kernel.instructions,
        "var_ctor_copy_inline_codegen_kernel",
    )
    code = cube_code + "\n" + vec_code

    assert "dst.SetValue(0, (int)(n + 1));" in cube_code
    assert "_tmp_var_" not in code


def test_named_var_ctor_copy_decl_assign_is_folded_in_codegen() -> None:
    dst = GMTensor(DT.int64, [1, 1], name="dst")
    n = Var(7, DT.int, name="n")
    var_ctor_copy_named_codegen_kernel(dst, n)

    cube_code, vec_code = _translate_silently(
        var_ctor_copy_named_codegen_kernel.instructions,
        "var_ctor_copy_named_codegen_kernel",
    )
    code = cube_code + "\n" + vec_code

    assert "int64_t copied = 2*n;" in cube_code
    assert "dst.SetValue(0, (int64_t)(copied));" in cube_code
    assert "int64_t copied = 0;" not in code
    assert "copied = (int64_t)" not in code
    assert "_tmp_var_" not in code
