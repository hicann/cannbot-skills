import json
import subprocess
import sys
from pathlib import Path

import pytest

from agent.scripts.select_kernel_example import _entry_targets

ROOT = Path(__file__).resolve().parents[5]
SELECTOR = ROOT / "agent" / "scripts" / "select_kernel_example.py"


def _run_selector_json(*args: str):
    result = subprocess.run(
        [sys.executable, str(SELECTOR), *args, "--json"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


def test_selector_prefers_simple_add1_for_cube_vec_add1_query() -> None:
    payload = _run_selector_json("--query", "matmul add1", "--topology", "cube->vec", "--limit", "3")
    assert payload["result_count"] >= 1
    assert payload["results"][0]["path"] == "agent/example/kernels/a5/matmul/matmul_abs_add1_vf.py"



def test_selector_splitk_tag_finds_pure_cube_splitk_reference() -> None:
    payload = _run_selector_json("--topology", "cube-only", "--tag", "splitk", "--limit", "3")
    assert payload["result_count"] >= 1
    assert payload["results"][0]["path"] == "agent/example/kernels/a5/matmul/matmul_mknk_2dgrid_splitk.py"
    assert "splitk" in payload["results"][0]["tags"]



def test_selector_quant_tag_does_not_match_rowwise_norm_from_negative_guidance() -> None:
    payload = _run_selector_json("--topology", "cube->vec", "--tag", "quant", "--limit", "10")
    returned_paths = {item["path"] for item in payload["results"]}
    assert "agent/example/kernels/a5/matmul/matmul_kmkn_blockwise_quant128.py" in returned_paths
    assert "agent/example/kernels/a5/matmul/matmul_rowwise_norm.py" not in returned_paths
    assert "agent/example/kernels/a5/matmul/matmul_rowwise_norm_large_nk.py" not in returned_paths


def test_selector_prefers_normalized_flash_attn_for_online_softmax_query() -> None:
    payload = _run_selector_json("--query", "online softmax qk pv a2", "--topology", "cube->vec->cube->vec", "--limit", "4")
    assert payload["result_count"] >= 1
    assert payload["results"][0]["path"] == "agent/example/kernels/a2/attention/flash_attn_full.py"


def test_selector_filters_and_surfaces_dataflow_pattern() -> None:
    payload = _run_selector_json(
        "--pattern", "vec-row-reduce-broadcast", "--topology", "vec-only", "--limit", "3"
    )
    assert payload["result_count"] == 1
    assert payload["results"][0]["path"] == "agent/example/kernels/a2/vec_only/rowwise_reduce_broadcast.py"
    assert payload["results"][0]["patterns"] == ["vec-row-reduce-broadcast"]


def test_selector_combines_pattern_and_device_intent() -> None:
    payload = _run_selector_json(
        "--pattern", "online-softmax-tail", "--query", "a2 online softmax tail",
        "--topology", "cube->vec->cube->vec", "--limit", "3"
    )
    assert payload["result_count"] >= 1
    assert payload["results"][0]["path"] == "agent/example/kernels/a2/attention/flash_attn_full.py"
    assert "online-softmax-tail" in payload["results"][0]["patterns"]


def test_selector_device_option_excludes_other_target() -> None:
    payload = _run_selector_json(
        "--device", "a2", "--query", "matmul bias", "--limit", "20"
    )
    assert payload["result_count"] >= 1
    assert all("/a2/" in item["path"] for item in payload["results"])
    assert all(item["device"] == "a2" for item in payload["results"])


def test_selector_a5pr_option_uses_a5_family_examples_without_a2_results() -> None:
    payload = _run_selector_json(
        "--device", "a5pr", "--query", "matmul bias", "--limit", "20"
    )
    assert payload["result_count"] >= 1
    assert all("/a2/" not in item["path"] for item in payload["results"])
    # The existing JSON field continues to describe the catalog source family;
    # target compatibility is only a selector constraint.
    assert all(item["device"] in {"a5", "a5pr", "either"} for item in payload["results"])
    assert all("a5pr" in item["targets"] for item in payload["results"])


def test_selector_distinguishes_explicit_a5pr_only_example() -> None:
    target_path = "agent/example/kernels/a5/attention/pfa/qk_softmax_pv_flat.py"
    a5_payload = _run_selector_json(
        "--device", "a5", "--query", "qk_softmax_pv_flat", "--limit", "100"
    )
    assert target_path not in {item["path"] for item in a5_payload["results"]}

    a5pr_payload = _run_selector_json(
        "--device", "a5pr", "--query", "qk_softmax_pv_flat", "--limit", "100"
    )
    matches = [item for item in a5pr_payload["results"] if item["path"] == target_path]
    assert len(matches) == 1
    assert matches[0]["device"] == "a5pr"
    assert matches[0]["targets"] == ["a5pr"]


@pytest.mark.parametrize("targets", [[], "a5pr", ["unknown"], ["a5", "a5"]])
def test_selector_rejects_malformed_explicit_targets(targets) -> None:
    with pytest.raises(ValueError, match="targets|target"):
        _entry_targets({"path": "agent/example/kernels/a5/bad.py", "targets": targets})


def test_selector_a5pr_option_respects_legacy_incompatibility_guidance() -> None:
    a5_payload = _run_selector_json(
        "--device", "a5", "--query", "allhif8", "--limit", "100"
    )
    a5_paths = {item["path"] for item in a5_payload["results"]}
    assert "agent/example/kernels/a5/attention/pfa/v8_allhif8.py" in a5_paths
    assert "agent/example/kernels/a5/attention/pfa/v9_allhif8.py" in a5_paths

    payload = _run_selector_json(
        "--device", "a5pr", "--query", "allhif8", "--limit", "100"
    )
    returned_paths = {item["path"] for item in payload["results"]}
    assert "agent/example/kernels/a5/attention/pfa/v8_allhif8.py" not in returned_paths
    assert "agent/example/kernels/a5/attention/pfa/v9_allhif8.py" not in returned_paths


def test_selector_routes_lowbit_carrier_patterns() -> None:
    fp4 = _run_selector_json("--pattern", "a5-fp4-cast-pack", "--limit", "2")
    assert fp4["result_count"] == 1
    assert fp4["results"][0]["path"] == "agent/example/kernels/a5/vec_only/bf16_to_fp4_e1m2.py"

    uint2 = _run_selector_json("--pattern", "a5-uint2-pack-unpack", "--limit", "3")
    assert {
        result["path"] for result in uint2["results"]
    } == {
        "agent/example/kernels/a5/vec_only/bf16_to_uint2.py",
        "agent/example/kernels/a5/vec_only/uint2_to_bf16.py",
    }


def test_selector_routes_buffer_slot_lifetime_by_device() -> None:
    payload = _run_selector_json(
        "--pattern", "buffer-slot-lifetime", "--query", "a2 delayed slot reuse", "--limit", "3"
    )
    assert payload["result_count"] >= 1
    assert payload["results"][0]["path"] == "agent/example/kernels/a2/attention/flash_attn_full.py"


def test_selector_surfaces_deep_note_when_present() -> None:
    # The a5 fp8 causal flash-attn kernel is the only one with an
    # attached deep_note; this test verifies that when the selector
    # surfaces it, the deep_note travels along.  Ranking can shift as
    # related a2/a5 causal variants are added, so we don't pin the
    # exact position -- only that the entry appears among the results
    # with the right deep_note.
    payload = _run_selector_json("--query", "flash attn fp8 causal", "--topology", "cube->vec->cube->vec", "--limit", "10")
    target_path = "agent/example/kernels/a5/attention/flash_attn_full_fp8_causal.py"
    expected_note = "agent/references/examples/deep/a5-flash-attn-full-fp8-causal.md"
    matches = [r for r in payload["results"] if r["path"] == target_path]
    assert matches, f"expected {target_path} in results, got {[r['path'] for r in payload['results']]}"
    assert matches[0]["deep_note"] == expected_note
