import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.parser.asc import translate_split


def _with_device(device_type: str):
    saved = globvars.device_type
    globvars.device_type = device_type
    return saved


def _nz2dn_kwargs(kernel_fn):
    insts = [i for i in kernel_fn.instructions if i.opname == "l0c_to_gm_nz2dn"]
    assert len(insts) == 1
    return insts[0].kwargs


def test_sugar_gm_ilshift_l0c_T_emits_nz2dn_and_infers_dims() -> None:
    saved = _with_device("950")
    try:
        # L0C tile [M=32, N=128] -> transposed dst zt = [N=128, M=32].
        @kernel()
        def stub_only(zt: GMTensor):
            l0c = Tensor(DT.float, [32, 128], Position.L0C, name="src_l0c")
            zt[:, :] <<= l0c.T
            return zt

        zt = GMTensor(DT.float, [128, 32], name="zt")
        stub_only(zt)
        kw = _nz2dn_kwargs(stub_only)
        assert int(kw["M"]) == 32        # L0C rows (m)
        assert int(kw["N"]) == 128       # L0C cols (n)
        assert int(kw["M_dst"]) == 32    # row width / stride of [n, m] dst
        assert int(kw["M_src"]) == 32    # nz_M
        assert bool(kw["relu"]) is False
    finally:
        globvars.device_type = saved


def test_codegen_nz2dn_emits_cube_helper_on_950() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(zt: GMTensor):
            l0c = Tensor(DT.float, [32, 128], Position.L0C, name="src_l0c")
            zt[:, :] <<= l0c.T
            return zt

        zt = GMTensor(DT.float, [128, 32], name="zt")
        stub_only(zt)
        cube_code, vec_code = translate_split(stub_only.instructions, "l0c_to_gm_nz2dn_950")
        assert "L0C2GM_NZ2DN(" in cube_code
        assert "L0C2GM_NZ2DN(" not in vec_code
        assert "src_l0c" in cube_code
        # m=32, n=128, M_dst=32, M_src=32, relu=false
        assert ", 32, 128, 32, 32, false);" in cube_code
    finally:
        globvars.device_type = saved


def test_codegen_nz2dn_sliced_dst_stride_is_full_width() -> None:
    saved = _with_device("950")
    try:
        # dst plane is [256, 48]; write the [128, 32] transpose into a sub-block.
        # M_dst must be the FULL row width (48), not the sliced span (32).
        @kernel()
        def stub_only(zt: GMTensor):
            l0c = Tensor(DT.float, [32, 128], Position.L0C, name="src_l0c")
            zt[0:128, 0:32] <<= l0c.T
            return zt

        zt = GMTensor(DT.float, [256, 48], name="zt")
        stub_only(zt)
        kw = _nz2dn_kwargs(stub_only)
        assert int(kw["M_dst"]) == 48
        cube_code, _ = translate_split(stub_only.instructions, "l0c_to_gm_nz2dn_slice")
        assert ", 32, 128, 48, 32, false);" in cube_code
    finally:
        globvars.device_type = saved


def test_codegen_nz2dn_relu_propagates_through_T() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(zt: GMTensor):
            l0c = Tensor(DT.float, [32, 128], Position.L0C, name="src_l0c")
            l0c._is_relu = True
            zt[:, :] <<= l0c.T
            return zt

        zt = GMTensor(DT.float, [128, 32], name="zt")
        stub_only(zt)
        kw = _nz2dn_kwargs(stub_only)
        assert bool(kw["relu"]) is True
        cube_code, _ = translate_split(stub_only.instructions, "l0c_to_gm_nz2dn_relu")
        assert ", 32, 128, 32, 32, true);" in cube_code
    finally:
        globvars.device_type = saved


def test_codegen_nz2dn_requant_emits_scaled_form() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(zt: GMTensor):
            l0c = Tensor(DT.int, [32, 128], Position.L0C, name="src_l0c")
            l0c_to_gm_nz2dn(zt[:, :], l0c, scale=2.0, offset=3)
            return zt

        zt = GMTensor(DT.int8, [128, 32], name="zt")
        stub_only(zt)
        cube_code, _ = translate_split(stub_only.instructions, "l0c_to_gm_nz2dn_requant")
        assert "L0C2GM_NZ2DN(" in cube_code
        # scaled path: ..., relu, scale, offset, true, false)
        assert ", true, false);" in cube_code
    finally:
        globvars.device_type = saved


def test_codegen_nz2dn_unit_flag_reaches_fixpipe_parameter() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(zt: GMTensor):
            l0c = Tensor(DT.float, [32, 128], Position.L0C, name="src_l0c")
            l0c_to_gm_nz2dn(zt[:, :], l0c, unit_flag=3)
            return zt

        zt = GMTensor(DT.float, [128, 32], name="zt")
        stub_only(zt)
        kw = _nz2dn_kwargs(stub_only)
        assert kw["unit_flag"] == 3
        cube_code, _ = translate_split(
            stub_only.instructions, "l0c_to_gm_nz2dn_unit_flag",
        )
        assert ", false, 1.0f, 0, false, false, 3);" in cube_code
    finally:
        globvars.device_type = saved


@pytest.mark.parametrize("unit_flag", [True, 1, 4])
def test_stub_nz2dn_rejects_invalid_unit_flag(unit_flag) -> None:
    saved = _with_device("950")
    try:
        zt = GMTensor(DT.float, [128, 32])
        l0c = Tensor(DT.float, [32, 128], Position.L0C)
        with pytest.raises((TypeError, ValueError), match="unit_flag"):
            l0c_to_gm_nz2dn(zt[:, :], l0c, unit_flag=unit_flag)
    finally:
        globvars.device_type = saved


def test_stub_nz2dn_rejects_b_device() -> None:
    saved = _with_device("b3")
    try:
        @kernel()
        def stub_only(zt: GMTensor):
            l0c = Tensor(DT.float, [32, 128], Position.L0C, name="src_l0c")
            zt[:, :] <<= l0c.T
            return zt

        zt = GMTensor(DT.float, [128, 32], name="zt")
        with pytest.raises(Exception):
            stub_only(zt)
    finally:
        globvars.device_type = saved
