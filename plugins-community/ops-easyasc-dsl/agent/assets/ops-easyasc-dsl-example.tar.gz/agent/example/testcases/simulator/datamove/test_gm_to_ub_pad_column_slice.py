"""Regression: gm_to_ub_pad must handle column-sliced UB destinations.

When the kernel does `ub[:, 0:valid_n] <<= gm[...]` with `valid_n < ub.shape[-1]`,
the destination is a non-contiguous view. Earlier the V2 simulator materialized
the view via `.contiguous()` and compared `dst_need` against the materialized
numel, which fired a false "destination view is too small" error. The fix uses
`_linear_view_from_pointer` so the size check runs against the underlying
storage span and the burst writes propagate back through the strided view.
"""

from __future__ import annotations

import torch

from easyasc.a5 import *


TILE_M = 64
TILE_N = 256


@kernel()
def _gm_to_ub_tail_kernel(x: GMTensor, z: GMTensor, M: Var, N: Var):
    ubbuf = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    cnt = Var(0)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    for mt in range(tile_m_begin, tile_m_end):
        with auto_sync():
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = Var(GetSubBlockIdx())
            row_start = Var(m0 + sb_idx * half_rows)
            rows = Min(half_rows, valid_m - sb_idx * half_rows)

            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                ubbuf[cnt][0:rows, 0:valid_n] <<= x[row_start:row_start + rows, n0:n0 + valid_n]
                z[row_start:row_start + rows, n0:n0 + valid_n] <<= ubbuf[cnt][0:rows, 0:valid_n]
                cnt += 1
    return z


def _run_roundtrip(M: int, N: int) -> None:
    torch.manual_seed(0)
    x = torch.rand((M, N), dtype=torch.float32)
    z = torch.zeros((M, N), dtype=torch.float32)
    z_kernel = OpExec(_gm_to_ub_tail_kernel, simulator=True)(x, z, M, N)
    torch.testing.assert_close(z_kernel, x)


def test_gm_to_ub_pad_column_slice_tile_aligned() -> None:
    _run_roundtrip(M=128, N=TILE_N)


def test_gm_to_ub_pad_column_slice_tail_small() -> None:
    # N=300: tail tile valid_n=44 forces a column-sliced [rows, 44] UB view in the
    # 256-wide buffer. Pre-fix this fired `gm_to_ub_pad destination view is too small`.
    _run_roundtrip(M=128, N=300)


def test_gm_to_ub_pad_column_slice_tail_odd() -> None:
    # N=511: tail tile valid_n=255 (not 32B aligned).
    _run_roundtrip(M=128, N=511)
