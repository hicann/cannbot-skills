import pytest

from easyasc.a5 import DT, DualMode, GMTensor, Position, Tensor, Var, kernel, l0c_to_ub


def test_l0c_to_ub_accepts_static_l0c_slice() -> None:
    # A static L0C sub-tile (non-zero offset + partial span) is allowed so a tall L0C can be
    # split across several SINGLE-mode stores. M_src is inferred from the L0C *shape* (the full
    # 32-row tile, the fractal stride), NOT the sliced span (16).
    @kernel()
    def k(out: GMTensor):
        l0c = Tensor(DT.float, [32, 64], Position.L0C, name="l0c")
        ub = Tensor(DT.float, [16, 64], Position.UB, name="ub")
        l0c_to_ub(ub, l0c[16:32, :], M=16, N=64, N_dst=64, dual_mode=DualMode.SINGLE, sub_block_id=0)
        return out

    out = GMTensor(DT.float, [16, 64], name="out")
    k(out)   # must not raise
    found = [i for i in k.instructions if i.opname == "l0c_to_ub"]
    assert len(found) == 1
    assert found[0].kwargs["M_src"] == 32      # full L0C rows, not the sliced span (16)
    assert found[0].kwargs["M"] == 16


def test_l0c_to_ub_rejects_dynamic_l0c_offset_with_clear_error() -> None:
    # A dynamic (Var) base offset cannot be a static fixpipe source address, so it is rejected
    # with a clear error. (A dynamic *extent* like l0c[:v1, :] is fine -- it feeds runtime M.)
    @kernel()
    def stub(out: GMTensor, start: Var):
        dst = Tensor(DT.float, [8, 16], Position.UB, name="dst")
        src = Tensor(DT.float, [16, 16], Position.L0C, name="src")
        dst <<= src[start:, :]
        return out

    out = GMTensor(DT.float, [8, 16], name="out")
    with pytest.raises(ValueError) as exc_info:
        stub(out, Var(0, name="start"))

    message = str(exc_info.value)
    assert "l0c_to_ub src does not support this sliced source tensor" in message
    assert "offset must be static" in message
    assert "l0c[v1:, :]" in message
