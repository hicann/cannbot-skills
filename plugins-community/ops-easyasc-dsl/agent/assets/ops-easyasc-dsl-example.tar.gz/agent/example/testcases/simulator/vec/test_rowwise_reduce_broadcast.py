import pytest
import torch

from easyasc.a2 import OpExec
from kernels.a2.vec_only.rowwise_reduce_broadcast import (
    golden,
    make_input,
    rowwise_reduce_broadcast_kernel,
)


@pytest.mark.parametrize("rows,width", [(1, 64), (3, 256), (17, 1024), (33, 1536)])
def test_rowwise_reduce_broadcast_simulator(tmp_path, rows, width) -> None:
    x = make_input(rows, width)
    y = torch.empty_like(x)
    got = OpExec(
        rowwise_reduce_broadcast_kernel,
        simulator=True,
        out_dir=str(tmp_path / "rows{}_width{}".format(rows, width)),
    )(
        x,
        y,
        rows,
        width,
        shape_bindings={0: [0, 1], 1: [0, 1], "rows": rows, "width": width},
    )

    torch.testing.assert_close(got, golden(x), rtol=1e-5, atol=1e-6)
