from types import SimpleNamespace

import pytest
import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg


def _misaligned(dtype=torch.float32, n=512):
    return torch.zeros(n, dtype=dtype)[1:]


def _mask(dtype, name: str = "mask_all") -> MaskReg:
    return MaskReg(dtype, init_mode=MaskType.ALL, name=name)


def _all_mask(dtype: torch.dtype) -> torch.Tensor:
    return torch.ones(256 // torch.empty((), dtype=dtype).element_size(), dtype=torch.bool)


def test_micro_ub_to_reg_requires_aligned_ub_src() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.float, name="dst")
    src = SimpleNamespace(name="ub_src")
    mask = _mask(DT.float)

    ctx = MicroContext(
        masks={"mask_all": _all_mask(torch.float32)},
        tensor_views={"ub_src": _misaligned(torch.float32)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_ub2reg src address base"):
            runtime._dispatch("micro_ub2reg", {"dst": dst, "src": src, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


def test_micro_ub_to_reg_checks_logical_local_base_offset() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.float, name="dst")
    src = SimpleNamespace(name="ub_src")
    mask = _mask(DT.float)

    ctx = MicroContext(
        masks={"mask_all": _all_mask(torch.float32)},
        tensor_views={"ub_src": torch.zeros(128, dtype=torch.float32)},
        tensor_offsets_bytes={"ub_src": 4},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_ub2reg src address.*byte offset 4"):
            runtime._dispatch("micro_ub2reg", {"dst": dst, "src": src, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


def test_micro_reg_to_ub_requires_aligned_ub_dst() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = SimpleNamespace(name="ub_dst")
    mask = _mask(DT.float)

    ctx = MicroContext(
        regs={"src": torch.ones(64, dtype=torch.float32)},
        masks={"mask_all": _all_mask(torch.float32)},
        tensor_views={"ub_dst": _misaligned(torch.float32)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_reg2ub dst address base"):
            runtime._dispatch("micro_reg2ub", {"dst": dst, "src": src, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


def test_micro_reg_to_ub_checks_logical_local_base_offset() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = SimpleNamespace(name="ub_dst")
    mask = _mask(DT.float)

    ctx = MicroContext(
        regs={"src": torch.ones(64, dtype=torch.float32)},
        masks={"mask_all": _all_mask(torch.float32)},
        tensor_views={"ub_dst": torch.zeros(128, dtype=torch.float32)},
        tensor_offsets_bytes={"ub_dst": 4},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_reg2ub dst address.*byte offset 4"):
            runtime._dispatch("micro_reg2ub", {"dst": dst, "src": src, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "dtype,reg_dtype,mode",
    [
        (torch.float32, DT.float, "DIST_NORM"),
        (torch.float16, DT.half, "DIST_DS_B16"),
        (torch.float16, DT.half, "DIST_US_B16"),
        (torch.float32, DT.float, "DIST_UNPACK_B32"),
        (torch.float32, DT.float, "DIST_E2B_B32"),
    ],
)
def test_micro_ub_to_reg_cont_guarded_modes_require_aligned_ub_src(dtype, reg_dtype, mode: str) -> None:
    runtime = MicroRuntime()
    dst = SimpleNamespace(name="dst", dtype=reg_dtype, length=0)
    src = SimpleNamespace(name="ub_src")

    ctx = MicroContext(tensor_views={"ub_src": _misaligned(dtype)})
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_ub2regcont src address base"):
            runtime._dispatch("micro_ub2regcont", {"dst": dst, "src": src, "mode": mode}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


def test_micro_ub_to_reg_cont_guarded_modes_check_effective_offset() -> None:
    runtime = MicroRuntime()
    dst = SimpleNamespace(name="dst", dtype=DT.float, length=0)
    src = SimpleNamespace(name="ub_src")

    ctx = MicroContext(tensor_views={"ub_src": torch.zeros(128, dtype=torch.float32)})
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_ub2regcont src address access offset"):
            runtime._dispatch(
                "micro_ub2regcont",
                {"dst": dst, "src": src, "mode": "DIST_UNPACK_B32", "offset": 1},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "dtype,reg_dtype,mode",
    [
        (torch.float32, DT.float, "DIST_NORM"),
        (torch.float16, DT.half, "DIST_DS_B16"),
        (torch.float16, DT.half, "DIST_US_B16"),
        (torch.float32, DT.float, "DIST_UNPACK_B32"),
        (torch.float32, DT.float, "DIST_E2B_B32"),
        (torch.uint8, DT.uint8, "DIST_UNPACK4_B8"),
    ],
)
def test_micro_ub_to_reg_cont_guarded_modes_check_logical_local_base_offset(dtype, reg_dtype, mode: str) -> None:
    runtime = MicroRuntime()
    dst = SimpleNamespace(name="dst", dtype=reg_dtype, length=0)
    src = SimpleNamespace(name="ub_src")

    ctx = MicroContext(
        tensor_views={"ub_src": torch.zeros(128, dtype=dtype)},
        tensor_offsets_bytes={"ub_src": 4},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_ub2regcont src address.*byte offset 4"):
            runtime._dispatch("micro_ub2regcont", {"dst": dst, "src": src, "mode": mode}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "dtype,reg_dtype,mode",
    [
        (torch.uint8, DT.uint8, "DIST_DINTLV_B8"),
        (torch.float16, DT.half, "DIST_DINTLV_B16"),
        (torch.float32, DT.float, "DIST_DINTLV_B32"),
    ],
)
def test_micro_ub_to_reg_interleave_requires_aligned_ub_src(dtype, reg_dtype, mode: str) -> None:
    runtime = MicroRuntime()
    dst0 = SimpleNamespace(name="dst0", dtype=reg_dtype, length=0)
    dst1 = SimpleNamespace(name="dst1", dtype=reg_dtype, length=0)
    src = SimpleNamespace(name="ub_src")

    ctx = MicroContext(tensor_views={"ub_src": _misaligned(dtype, n=1024)})
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_ub2reginterleave src address base"):
            runtime._dispatch(
                "micro_ub2reginterleave",
                {"dst0": dst0, "dst1": dst1, "src": src, "mode": mode},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


def test_micro_ub_to_reg_interleave_checks_logical_local_base_offset() -> None:
    runtime = MicroRuntime()
    dst0 = SimpleNamespace(name="dst0", dtype=DT.float, length=0)
    dst1 = SimpleNamespace(name="dst1", dtype=DT.float, length=0)
    src = SimpleNamespace(name="ub_src")

    ctx = MicroContext(
        tensor_views={"ub_src": torch.zeros(128, dtype=torch.float32)},
        tensor_offsets_bytes={"ub_src": 4},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_ub2reginterleave src address.*byte offset 4"):
            runtime._dispatch(
                "micro_ub2reginterleave",
                {"dst0": dst0, "dst1": dst1, "src": src, "mode": "DIST_DINTLV_B32"},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


def test_micro_ub_to_reg_interleave_checks_effective_offset() -> None:
    runtime = MicroRuntime()
    dst0 = SimpleNamespace(name="dst0", dtype=DT.float, length=0)
    dst1 = SimpleNamespace(name="dst1", dtype=DT.float, length=0)
    src = SimpleNamespace(name="ub_src")

    ctx = MicroContext(tensor_views={"ub_src": torch.zeros(128, dtype=torch.float32)})
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_ub2reginterleave src address access offset"):
            runtime._dispatch(
                "micro_ub2reginterleave",
                {"dst0": dst0, "dst1": dst1, "src": src, "mode": "DIST_DINTLV_B32", "offset": 1},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


def test_micro_ub_to_reg_single_value_allows_unaligned_logical_base_offset() -> None:
    runtime = MicroRuntime()
    dst = SimpleNamespace(name="dst", dtype=DT.float, length=0)
    src = SimpleNamespace(name="ub_src")

    ctx = MicroContext(
        tensor_views={"ub_src": torch.ones(128, dtype=torch.float32)},
        tensor_offsets_bytes={"ub_src": 4},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_ub2regcont", {"dst": dst, "src": src, "mode": "DIST_BRC_B32"}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "dtype,reg_dtype,mode",
    [
        (torch.float16, DT.half, "DIST_PACK_B32"),
        (torch.uint8, DT.uint8, "DIST_PACK4_B32"),
    ],
)
def test_micro_reg_to_ub_cont_pack_modes_require_aligned_ub_dst(dtype, reg_dtype, mode: str) -> None:
    runtime = MicroRuntime()
    src = SimpleNamespace(name="src", dtype=reg_dtype, length=0)
    dst = SimpleNamespace(name="ub_dst")
    mask = _mask(reg_dtype)

    ctx = MicroContext(
        regs={"src": torch.ones(256 // torch.empty((), dtype=dtype).element_size(), dtype=dtype)},
        masks={"mask_all": _all_mask(dtype)},
        tensor_views={"ub_dst": _misaligned(dtype)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_reg2ubcont dst address base"):
            runtime._dispatch(
                "micro_reg2ubcont",
                {"dst": dst, "src": src, "mode": mode, "mask": mask},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


def test_micro_reg_to_ub_cont_pack_modes_check_effective_offset() -> None:
    runtime = MicroRuntime()
    src = SimpleNamespace(name="src", dtype=DT.half, length=0)
    dst = SimpleNamespace(name="ub_dst")
    mask = _mask(DT.half)

    ctx = MicroContext(
        regs={"src": torch.ones(128, dtype=torch.float16)},
        masks={"mask_all": _all_mask(torch.float16)},
        tensor_views={"ub_dst": torch.zeros(128, dtype=torch.float16)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_reg2ubcont dst address access offset"):
            runtime._dispatch(
                "micro_reg2ubcont",
                {"dst": dst, "src": src, "mode": "DIST_PACK_B32", "mask": mask, "offset": 1},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "dtype,reg_dtype,mode",
    [
        (torch.uint8, DT.uint8, "DIST_PACK_B16"),
        (torch.float16, DT.half, "DIST_PACK_B32"),
        (torch.float32, DT.float, "DIST_PACK_B64"),
        (torch.uint8, DT.uint8, "DIST_PACK4_B32"),
    ],
)
def test_micro_reg_to_ub_cont_pack_modes_check_logical_local_base_offset(dtype, reg_dtype, mode: str) -> None:
    runtime = MicroRuntime()
    src = SimpleNamespace(name="src", dtype=reg_dtype, length=0)
    dst = SimpleNamespace(name="ub_dst")
    mask = _mask(reg_dtype)

    ctx = MicroContext(
        regs={"src": torch.ones(256 // torch.empty((), dtype=dtype).element_size(), dtype=dtype)},
        masks={"mask_all": _all_mask(dtype)},
        tensor_views={"ub_dst": torch.zeros(128, dtype=dtype)},
        tensor_offsets_bytes={"ub_dst": 4},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(RuntimeError, match="micro_reg2ubcont dst address.*byte offset 4"):
            runtime._dispatch(
                "micro_reg2ubcont",
                {"dst": dst, "src": src, "mode": mode, "mask": mask},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


def test_micro_reg_to_ub_single_value_allows_unaligned_logical_base_offset() -> None:
    runtime = MicroRuntime()
    src = SimpleNamespace(name="src", dtype=DT.float, length=0)
    dst = SimpleNamespace(name="ub_dst")
    mask = _mask(DT.float)

    ctx = MicroContext(
        regs={"src": torch.ones(64, dtype=torch.float32)},
        masks={"mask_all": _all_mask(torch.float32)},
        tensor_views={"ub_dst": torch.zeros(128, dtype=torch.float32)},
        tensor_offsets_bytes={"ub_dst": 4},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_reg2ubcont",
            {"dst": dst, "src": src, "mode": "DIST_FIRST_ELEMENT_B32", "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()
