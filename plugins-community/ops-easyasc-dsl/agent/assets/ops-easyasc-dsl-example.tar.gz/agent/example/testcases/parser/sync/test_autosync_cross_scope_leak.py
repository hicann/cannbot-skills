"""Regression for the cross-scope V->MTE3 auto_sync gap.

A UB buffer produced inside a nested `if`/`for` scope but stored in the enclosing
loop (after the scope) must still get a parent-level producer->consumer handshake.
Before the fix, that store was emitted bare and the next outer iteration raced the
store on the single-buffer UB tensor.
"""
import contextlib
import io

import pytest
import torch

from easyasc.a5 import OpExec
from easyasc.parser.asc import split_instructions
from easyasc.parser.asc_autosync import insert_auto_sync
from testcases.parser.sync._autosync_cross_scope_kernels import (
    CROSS_TILES,
    CROSS_WIDTH,
    SHAPE_BINDINGS,
    autosync_cross_scope_leak_for,
    autosync_cross_scope_leak_if,
    build_cross_scope_leak_for,
    build_cross_scope_leak_if,
)


def _vec_autosync(kernel):
    _, vec_insts = split_instructions(list(kernel.instructions))
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        synced = insert_auto_sync(vec_insts, mode="vec")
    return synced, captured.getvalue()


def _event_name(inst):
    ev = inst.kwargs.get("event", inst.kwargs.get("val"))
    return getattr(ev, "name", "")


def _assert_parent_store_protected(kernel):
    """The parent-scope store of the leaked buffer (y1_ub) must be guarded by a
    ubout producer->consumer handshake, and the events must stay balanced."""
    synced, stdout = _vec_autosync(kernel)
    assert "NOT balanced auto_sync events" not in stdout

    # Locate the parent-scope store of the leaked single-buffer tensor y1_ub.
    store_idx = None
    for idx, inst in enumerate(synced):
        if inst.opname == "ub_to_gm_pad" and getattr(inst.kwargs.get("src"), "name", "") == "y1_ub":
            store_idx = idx
    assert store_idx is not None, "y1_ub store not found"

    # The store must wait on a ubout 'ready' (data-ready) signal right before it
    # (this is exactly the handshake that is missing when the bug is present).
    prev = synced[store_idx - 1]
    assert prev.opname == "event_wait" and "ready_ubout" in _event_name(prev), (
        f"y1_ub store at {store_idx} is not preceded by a ubout ready.wait; "
        f"preceding op is {prev.opname} {_event_name(prev)!r}"
    )

    # A producer window (valid.wait) for the same ubout family must be opened
    # before the nested scope that produces y1_ub, and released (valid.set) after
    # the store. Collect the ubout event family used around the store.
    ready_family = _event_name(prev).replace("ready_ubout", "ubout")
    names = [_event_name(i) for i in synced if i.opname in ("event_set", "event_wait")]
    valid_name = _event_name(prev).replace("ready_ubout", "valid_ubout")
    assert names.count(valid_name) >= 1, f"missing valid window {valid_name} for the leaked store"

    # The store's ready signal is published before it is awaited (set then wait).
    ready_name = _event_name(prev)
    set_positions = [i for i, inst in enumerate(synced)
                     if inst.opname == "event_set" and _event_name(inst) == ready_name and i < store_idx]
    assert set_positions, f"missing {ready_name}.set before the y1_ub store"


def test_cross_scope_leak_if_parent_store_protected() -> None:
    build_cross_scope_leak_if()
    _assert_parent_store_protected(autosync_cross_scope_leak_if)


def test_cross_scope_leak_for_parent_store_protected() -> None:
    build_cross_scope_leak_for()
    _assert_parent_store_protected(autosync_cross_scope_leak_for)


def _run_and_check(kernel):
    x1 = torch.arange(CROSS_TILES * CROSS_WIDTH, dtype=torch.float).reshape(CROSS_TILES, CROSS_WIDTH)
    x2 = (x1 + 1000.0).clone()
    y1 = torch.zeros_like(x1)
    y2 = torch.zeros_like(x2)
    out1, out2 = OpExec(kernel, simulator=True)(x1, x2, y1, y2, CROSS_TILES, shape_bindings=SHAPE_BINDINGS)
    torch.testing.assert_close(out1, x1)
    torch.testing.assert_close(out2, x2)


def test_cross_scope_leak_if_simulator_matches_reference() -> None:
    _run_and_check(autosync_cross_scope_leak_if)


def test_cross_scope_leak_for_simulator_matches_reference() -> None:
    _run_and_check(autosync_cross_scope_leak_for)
