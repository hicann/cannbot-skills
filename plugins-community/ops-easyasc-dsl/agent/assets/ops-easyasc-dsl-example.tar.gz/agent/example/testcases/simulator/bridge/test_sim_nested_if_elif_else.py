import os

import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate_split
from easyasc.utils.var import Expr


ROWS = 1
COLS = 64
FULL_SIM_MATRIX = os.environ.get("EASYASC_FULL_SIM_MATRIX") == "1"


@vf()
def _add_bias_row_vf(src: Tensor, dst: Tensor, bias: Var):
    reg = Reg(DT.float)
    reg <<= src[0:ROWS, 0:COLS]
    reg <<= reg + bias
    dst[0:ROWS, 0:COLS] <<= reg


# --- nested if/elif/else kernel ---

@kernel()
def _nested_if_elif_else_kernel(x: GMTensor, y: GMTensor, outer_flag: Var, inner_flag: Var):
    src_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    dst_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    with auto_sync():
        src_ub <<= x[0:ROWS, 0:COLS]
        if outer_flag > 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(10.0))
            if inner_flag > 0:
                _add_bias_row_vf(dst_ub, dst_ub, Var(1.0))
            elif inner_flag < 0:
                _add_bias_row_vf(dst_ub, dst_ub, Var(2.0))
            else:
                _add_bias_row_vf(dst_ub, dst_ub, Var(3.0))
        elif outer_flag < 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(20.0))
        else:
            _add_bias_row_vf(src_ub, dst_ub, Var(30.0))
        y[0:ROWS, 0:COLS] <<= dst_ub
    return y


def _nested_ref(x, outer_flag: int, inner_flag: int):
    if outer_flag > 0:
        bias = 11.0 if inner_flag > 0 else 12.0 if inner_flag < 0 else 13.0
    elif outer_flag < 0:
        bias = 20.0
    else:
        bias = 30.0
    return x + bias


# --- else-if subblock kernel ---

@kernel()
def _else_if_subblock_kernel(x: GMTensor, y: GMTensor, outer_flag: Var):
    src_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    dst_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    with auto_sync():
        src_ub <<= x[0:ROWS, 0:COLS]
        if outer_flag > 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(10.0))
        else:
            if GetSubBlockIdx() == 0:
                _add_bias_row_vf(src_ub, dst_ub, Var(20.0))
            else:
                _add_bias_row_vf(src_ub, dst_ub, Var(30.0))
        y[0:ROWS, 0:COLS] <<= dst_ub
    return y


# --- elif subblock kernel ---

@kernel()
def _elif_subblock_kernel(x: GMTensor, y: GMTensor, outer_flag: Var):
    src_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    dst_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    with auto_sync():
        src_ub <<= x[0:ROWS, 0:COLS]
        if outer_flag > 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(10.0))
        elif GetSubBlockIdx() == 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(20.0))
        else:
            _add_bias_row_vf(src_ub, dst_ub, Var(30.0))
        y[0:ROWS, 0:COLS] <<= dst_ub
    return y


# --- tests: nested if/elif/else ---

def test_root_nested_if_rewrite_emits_full_if_chain() -> None:
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _nested_if_elif_else_kernel(x, y, Var(1), Var(-1))

    opnames = [inst.opname for inst in _nested_if_elif_else_kernel.instructions]
    assert opnames.count("start_if") == 2
    assert opnames.count("start_elif") == 2
    assert opnames.count("start_else") == 2
    assert opnames.count("end_if") == 2


def test_root_nested_if_translate_split_succeeds() -> None:
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _nested_if_elif_else_kernel(x, y, Var(1), Var(0))

    _, vec_code = translate_split(
        _nested_if_elif_else_kernel.instructions, "nested_if_elif_else_codegen",
    )
    assert vec_code.count("else if") == 2
    assert vec_code.count("} else {") == 2


def test_root_nested_if_simulator_matches_reference() -> None:
    if FULL_SIM_MATRIX:
        cases = [(7, 7), (7, -7), (7, 0), (-7, 5), (0, -5)]
    else:
        cases = [(7, 0), (-7, 5), (0, -5)]
    for outer_flag, inner_flag in cases:
        x = torch.arange(ROWS * COLS, dtype=torch.float32).reshape(ROWS, COLS)
        y = torch.zeros_like(x)
        out = OpExec(_nested_if_elif_else_kernel, simulator=True)(x, y, outer_flag, inner_flag)
        ref = _nested_ref(x, outer_flag, inner_flag)
        torch.testing.assert_close(out, ref, rtol=1e-4, atol=1e-4)


# --- tests: else-if subblock ---

def test_root_else_if_subblock_rewrite_stays_nested_else() -> None:
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _else_if_subblock_kernel(x, y, Var(0))

    opnames = [inst.opname for inst in _else_if_subblock_kernel.instructions]
    assert opnames.count("start_if") == 2
    assert opnames.count("start_else") == 2
    assert opnames.count("start_elif") == 0
    assert opnames.count("end_if") == 2


def test_root_else_if_subblock_translate_split_succeeds() -> None:
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _else_if_subblock_kernel(x, y, Var(0))

    _, vec_code = translate_split(
        _else_if_subblock_kernel.instructions, "else_if_subblock_codegen",
    )
    assert "else if" not in vec_code
    assert vec_code.count("} else {") == 2


def test_root_else_if_subblock_keeps_lane_condition_symbolic() -> None:
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _else_if_subblock_kernel(x, y, Var(0))

    instructions = list(_else_if_subblock_kernel.instructions)
    subblock_idx = next(i for i, inst in enumerate(instructions) if inst.opname == "GetSubBlockIdx")
    branch = instructions[subblock_idx + 1]

    assert branch.opname == "start_if"
    assert isinstance(branch.kwargs.get("cond"), Expr)


# --- tests: elif subblock ---

def test_root_elif_subblock_rewrite_emits_elif_chain() -> None:
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _elif_subblock_kernel(x, y, Var(0))

    opnames = [inst.opname for inst in _elif_subblock_kernel.instructions]
    assert opnames.count("start_if") == 1
    assert opnames.count("start_elif") == 1
    assert opnames.count("start_else") == 1
    assert opnames.count("GetSubBlockIdx") == 1
    assert opnames.count("end_if") == 1


def test_root_elif_subblock_translate_split_succeeds() -> None:
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _elif_subblock_kernel(x, y, Var(0))

    _, vec_code = translate_split(
        _elif_subblock_kernel.instructions, "elif_subblock_codegen",
    )
    assert vec_code.count("else if") == 1
    assert vec_code.count("} else {") == 1
