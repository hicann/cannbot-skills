from easyasc import globvars
from easyasc.a2 import *
from easyasc.parser.asc import translate_split


def test_codegen_l1_to_l0_float_b_device_uses_zz_helpers_for_l0a() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "b3"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            src = Tensor(DT.float, [16, 16], Position.L1)
            dst0 = Tensor(DT.float, [16, 16], Position.L0A)
            dst1 = Tensor(DT.float, [16, 16], Position.L0A)
            dst0 <<= src
            dst1 <<= src.T
            return inp

        inp = GMTensor(DT.float, [1, 1])
        stub_only(inp)
        cube_code, vec_code = translate_split(stub_only.instructions, "l1_to_l0_float_b3_l0a")
        assert "L0ZZ2ZZ(" in cube_code
        assert "L0ZZ2NN(" in cube_code
        assert "L0NZ2ZZ(" not in cube_code
        assert "L0NZ2NN(" not in cube_code
        assert "L0ZZ2ZZ(" not in vec_code
        assert "L0ZZ2NN(" not in vec_code
    finally:
        globvars.device_type = saved_device_type


def test_codegen_l1_to_l0_float_b_device_uses_zz_helpers_for_l0b() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "b3"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            src = Tensor(DT.float, [16, 16], Position.L1)
            dst0 = Tensor(DT.float, [16, 16], Position.L0B)
            dst1 = Tensor(DT.float, [16, 16], Position.L0B)
            dst0 <<= src
            dst1 <<= src.T
            return inp

        inp = GMTensor(DT.float, [1, 1])
        stub_only(inp)
        cube_code, vec_code = translate_split(stub_only.instructions, "l1_to_l0_float_b3_l0b")
        assert "L0ZZ2NZ(" in cube_code
        assert "L0ZZ2ZN(" in cube_code
        assert "L0NZ2NZ(" not in cube_code
        assert "L0NZ2ZN(" not in cube_code
        assert "L0ZZ2NZ(" not in vec_code
        assert "L0ZZ2ZN(" not in vec_code
    finally:
        globvars.device_type = saved_device_type


def test_codegen_l1_to_l0_half_b_device_keeps_nz_helpers() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "b3"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            srca = Tensor(DT.half, [16, 16], Position.L1)
            srcb = Tensor(DT.half, [16, 16], Position.L1)
            dsta = Tensor(DT.half, [16, 16], Position.L0A)
            dstb = Tensor(DT.half, [16, 16], Position.L0B)
            dsta <<= srca
            dstb <<= srcb
            return inp

        inp = GMTensor(DT.half, [1, 1])
        stub_only(inp)
        cube_code, vec_code = translate_split(stub_only.instructions, "l1_to_l0_half_b3")
        assert "L0NZ2ZZ(" in cube_code
        assert "L0NZ2NZ(" in cube_code
        assert "L0ZZ2ZZ(" not in cube_code
        assert "L0ZZ2NZ(" not in cube_code
        assert "L0NZ2ZZ(" not in vec_code
        assert "L0NZ2NZ(" not in vec_code
    finally:
        globvars.device_type = saved_device_type
