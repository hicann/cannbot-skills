import re

import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.parser.asc import translate_split


@kernel()
def _mx_low_level_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [16, 64], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_b")
    l0a = Tensor(DT.mx_e4m3, [16, 64], Position.L0A, name="l0a")
    l0b = Tensor(DT.mx_e4m3, [16, 64], Position.L0B, name="l0b")
    l0c = Tensor(DT.float, [16, 16], Position.L0C, name="l0c")

    l1_to_l0_mx(l0a, l1a, scale_a, m_dst=16, n_dst=64, m_src=16, n_src=64)
    l1_to_l0_mx(l0b, l1b, scale_b, m_dst=16, n_dst=64, m_src=16, n_src=64)
    mmad_mx(l0c, l0a, l0b, M=16, N=16, K=64, is_init=True)
    return inp


@kernel()
def _mxfp4_low_level_codegen(inp: GMTensor):
    l1a_u8 = Tensor(DT.uint8, [16, 32], Position.L1, name="l1a_u8")
    l1b_u8 = Tensor(DT.uint8, [16, 32], Position.L1, name="l1b_u8")
    l1a = l1a_u8.reinterpret(DT.fp4_e2m1, name="l1a")
    l1b = l1b_u8.reinterpret(DT.fp4_e1m2, name="l1b")
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_b")
    l0a_u8 = Tensor(DT.uint8, [16, 32], Position.L0A, name="l0a_u8")
    l0b_u8 = Tensor(DT.uint8, [16, 32], Position.L0B, name="l0b_u8")
    l0a = l0a_u8.reinterpret(DT.fp4_e2m1, name="l0a")
    l0b = l0b_u8.reinterpret(DT.fp4_e1m2, name="l0b")
    l0c = Tensor(DT.float, [16, 16], Position.L0C, name="l0c")

    l1_to_l0_mx(l0a, l1a, scale_a, m_dst=16, n_dst=64, m_src=16, n_src=64)
    l1_to_l0_mx(l0b, l1b, scale_b, m_dst=16, n_dst=64, m_src=16, n_src=64)
    mmad_mx(l0c, l0a, l0b, M=16, N=16, K=64, is_init=True)
    return inp

@kernel()
def _mx_transpose_codegen(inp: GMTensor):
    l1b = Tensor(DT.e4m3, [64, 32], Position.L1, name="l1b")
    scale_b = Tensor(DT.uint8, [32, 2], Position.L1, name="scale_b")
    l0b = Tensor(DT.mx_e4m3, [64, 32], Position.L0B, name="l0b")

    l1_to_l0_mx(l0b, l1b.T, scale_b, m_dst=64, n_dst=32, m_src=64, n_src=32)
    return inp


@kernel()
def _mx_transpose_l0a_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [64, 32], Position.L1, name="l1a")
    scale_a = Tensor(DT.uint8, [32, 2], Position.L1, name="scale_a")
    l0a = Tensor(DT.mx_e4m3, [64, 32], Position.L0A, name="l0a")

    l1_to_l0_mx(l0a, l1a.T, scale_a, m_dst=64, n_dst=32, m_src=64, n_src=32)
    return inp


@kernel()
def _mx_padding_codegen(inp: GMTensor):
    l1_pad = Tensor(DT.e4m3, [64, 32], Position.L1, name="l1_pad")

    zero_mxfp8_l1_padding(l1_pad)
    return inp


@kernel()
def _mx_external_scale_codegen(inp: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [16, 64], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_b")
    l0a = Tensor(DT.mx_e4m3, [16, 64], Position.L0A, name="l0a")
    l0b = Tensor(DT.mx_e4m3, [16, 64], Position.L0B, name="l0b")
    l0c = Tensor(DT.float, [16, 16], Position.L0C, name="l0c")

    gm_to_l1_mx_scale(scale_a, scale_a_gm)
    gm_to_l1_mx_scale(scale_b, scale_b_gm)
    l1_to_l0_mx(l0a, l1a, scale_a, m_dst=16, n_dst=64, m_src=16, n_src=64)
    l1_to_l0_mx(l0b, l1b, scale_b, m_dst=16, n_dst=64, m_src=16, n_src=64)
    mmad_mx(l0c, l0a, l0b, M=16, N=16, K=64, is_init=True)
    return inp


@kernel()
def _mx_external_dense_scale_codegen(inp: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor):
    scale_a = Tensor(DT.uint8, [16, 4], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [16, 4], Position.L1, name="scale_b")

    gm_to_l1_mx_scale_nd2nz(scale_a, scale_a_gm)
    gm_to_l1_mx_scale_nd2nz(scale_b, scale_b_gm)
    return inp


@kernel()
def _mx_matmul_splitk_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 128], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [16, 128], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [16, 4], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [16, 4], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [16, 16], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitk=64, m=16, n=16, k=128, is_init=True)
    return inp


@kernel()
def _mxfp4_matmul_shortcut_codegen(inp: GMTensor):
    l1a_u8 = Tensor(DT.uint8, [16, 32], Position.L1, name="l1a_u8")
    l1b_u8 = Tensor(DT.uint8, [16, 32], Position.L1, name="l1b_u8")
    l1a = l1a_u8.reinterpret(DT.fp4_e2m1, name="l1a_fp4")
    l1b = l1b_u8.reinterpret(DT.fp4_e2m1, name="l1b_fp4")
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [16, 16], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a, l1b, scale_a, scale_b, m=16, n=16, k=64, is_init=True)
    return inp


@kernel()
def _mxfp4_matmul_transpose_shortcut_codegen(inp: GMTensor):
    l1a_u8 = Tensor(DT.uint8, [16, 32], Position.L1, name="l1a_u8")
    l1b_u8 = Tensor(DT.uint8, [64, 32], Position.L1, name="l1b_u8")
    l1a = l1a_u8.reinterpret(DT.fp4_e2m1, name="l1a_fp4")
    l1b = l1b_u8.reinterpret(DT.fp4_e1m2, name="l1b_fp4")
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [64, 2], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [16, 64], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, m=16, n=64, k=64, is_init=True)
    return inp


@kernel()
def _mx_matmul_splitn_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [32, 64], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [32, 2], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [16, 32], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitn=16, m=16, n=32, k=64, is_init=True)
    return inp


@kernel()
def _mx_matmul_transpose_nosplit_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [64, 32], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [32, 2], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [16, 32], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, m=16, n=32, k=64, is_init=True)
    return inp


@kernel()
def _mx_matmul_transposed_a_nosplit_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [64, 32], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [16, 64], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [32, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [32, 16], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a.T, l1b, scale_a, scale_b, m=32, n=16, k=64, is_init=True)
    return inp


@kernel()
def _mx_matmul_both_transposed_nosplit_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [64, 32], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [64, 32], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [32, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [32, 2], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [32, 32], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a.T, l1b.T, scale_a, scale_b, m=32, n=32, k=64, is_init=True)
    return inp


@kernel()
def _mx_matmul_transpose_splitk_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 128], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [128, 32], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [16, 4], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [32, 4], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [16, 32], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, splitk=64, m=16, n=32, k=128, is_init=True)
    return inp


@kernel()
def _mx_matmul_transpose_splitn_codegen(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1, name="l1a")
    l1b = Tensor(DT.e4m3, [64, 64], Position.L1, name="l1b")
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1, name="scale_a")
    scale_b = Tensor(DT.uint8, [64, 2], Position.L1, name="scale_b")
    l0c = Tensor(DT.float, [16, 64], Position.L0C, name="l0c")

    matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, splitn=32, m=16, n=64, k=64, is_init=True)
    return inp


@kernel()
def _mx_transpose_splitk_codegen(inp: GMTensor):
    l1b = Tensor(DT.e4m3, [128, 32], Position.L1, name="l1b")
    scale_b = Tensor(DT.uint8, [32, 4], Position.L1, name="scale_b")
    l0b = Tensor(DT.mx_e4m3, [64, 32], Position.L0B, name="l0b")

    for subk in range(0, 128, 64, name="subk"):
        valid_k = Min(128 - subk, 64)
        l1b_tile = l1b[subk : subk + valid_k, :]
        scale_offset = (subk // 64) * 32
        l1_to_l0_mx(
            l0b,
            l1b_tile.T,
            scale_b,
            m_dst=valid_k,
            n_dst=32,
            m_src=128,
            n_src=32,
            src_mx_offset_element=scale_offset,
        )
    return inp


@kernel()
def _mx_transpose_splitn_codegen(inp: GMTensor):
    l1b = Tensor(DT.e4m3, [64, 64], Position.L1, name="l1b")
    scale_b = Tensor(DT.uint8, [64, 2], Position.L1, name="scale_b")
    l0b = Tensor(DT.mx_e4m3, [64, 32], Position.L0B, name="l0b")

    k64_blocks = CeilDiv(64, 64)
    for subn in range(0, 64, 32, name="subn"):
        valid_n = Min(64 - subn, 32)
        l1b_tile = l1b[:, subn : subn + valid_n]
        scale_offset = (subn // 16) * k64_blocks * 32
        l1_to_l0_mx(
            l0b,
            l1b_tile.T,
            scale_b,
            m_dst=64,
            n_dst=valid_n,
            m_src=64,
            n_src=64,
            src_mx_offset_element=scale_offset,
        )
    return inp


def test_mx_dtypes_are_addressable_local_views() -> None:
    assert DT.mx_e4m3.C0 == 32
    assert DT.mx_e4m3.size == 1
    assert DT.mx_e5m2.C0 == 32
    assert DT.mx_e5m2.size == 1


def test_mxfp4_dtypes_are_packed_compute_views() -> None:
    assert DT.fp4_e2m1.C0 == 64
    assert DT.fp4_e1m2.C0 == 64
    with pytest.raises(ValueError, match="packed FP4"):
        _ = DT.fp4_e2m1.size
    with pytest.raises(ValueError, match="Tensor does not support"):
        Tensor(DT.fp4_e2m1, [16, 64], Position.L1)
    with pytest.raises(ValueError, match="DBuff does not support"):
        DBuff(DT.fp4_e1m2, [16, 64], Position.L0A)
    with pytest.raises(ValueError, match="GMTensor does not support"):
        GMTensor(DT.fp4_e2m1, [16, 64])
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        carrier = Tensor(DT.uint8, [64, 32], Position.L1)
        view = carrier.reinterpret(DT.fp4_e2m1)
        transposed = view.T
        assert transposed.shape == [64, 64]
        assert transposed.span == [64, 64]
        assert transposed.is_transpose
        assert transposed._fp4_carrier is carrier
        with pytest.raises(ValueError, match="split_workspace does not support"):
            split_workspace(DT.fp4_e2m1, [16, 64])
    finally:
        globvars.device_type = saved_device_type


def test_l1_to_l0_mx_and_mmad_mx_codegen() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_low_level_codegen(inp)
        cube_code, vec_code = translate_split(_mx_low_level_codegen.instructions, "mx_low_level_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "LocalTensor<mx_fp8_e4m3_t> l0a" in cube_code
    assert "LocalTensor<mx_fp8_e4m3_t> l0b" in cube_code
    assert "L0NZ2NZ_MX(l0a, l1a, scale_a, 16, 64, 16, 64);" in cube_code
    assert "L0NZ2NZ_MX(l0b, l1b, scale_b, 16, 64, 16, 64);" in cube_code
    assert "MMAD_MX(l0c, l0a, l0b, 16, 64, 16, true);" in cube_code
    assert "L0NZ2NZ_MX(" not in vec_code
    assert "MMAD_MX(" not in vec_code


def test_mxfp4_l1_to_l0_mx_and_mmad_mx_codegen() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mxfp4_low_level_codegen(inp)
        cube_code, vec_code = translate_split(_mxfp4_low_level_codegen.instructions, "mxfp4_low_level_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "LocalTensor<fp4x2_e2m1_t> l1a = l1a_u8.ReinterpretCast<fp4x2_e2m1_t>();" in cube_code
    assert "LocalTensor<fp4x2_e1m2_t> l1b = l1b_u8.ReinterpretCast<fp4x2_e1m2_t>();" in cube_code
    assert "LocalTensor<fp4x2_e2m1_t> l0a = l0a_u8.ReinterpretCast<fp4x2_e2m1_t>();" in cube_code
    assert "LocalTensor<fp4x2_e1m2_t> l0b = l0b_u8.ReinterpretCast<fp4x2_e1m2_t>();" in cube_code
    assert "L0NZ2NZ_MX(l0a, l1a, scale_a, 16, 64, 16, 64);" in cube_code
    assert "L0NZ2NZ_MX(l0b, l1b, scale_b, 16, 64, 16, 64);" in cube_code
    assert "MMAD_MX(l0c, l0a, l0b, 16, 64, 16, true);" in cube_code
    assert "fp4x2_" not in vec_code


def test_mxfp4_matmul_mx_shortcut_codegen_uses_default_l0_storage() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mxfp4_matmul_shortcut_codegen(inp)
        cube_code, vec_code = translate_split(
            _mxfp4_matmul_shortcut_codegen.instructions,
            "mxfp4_matmul_shortcut_codegen",
        )
    finally:
        globvars.device_type = saved_device_type

    assert "ReinterpretCast<fp4x2_e2m1_t>()" in cube_code
    assert "L0NZ2NZ_MX(" in cube_code
    assert "MMAD_MX(l0c" in cube_code
    assert "fp4x2_" not in vec_code


def test_mxfp4_matmul_mx_transpose_codegen_uses_64x64_nz2zn() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mxfp4_matmul_transpose_shortcut_codegen(inp)
        cube_code, vec_code = translate_split(
            _mxfp4_matmul_transpose_shortcut_codegen.instructions,
            "mxfp4_matmul_transpose_shortcut_codegen",
        )
    finally:
        globvars.device_type = saved_device_type

    assert "LocalTensor<fp4x2_e1m2_t> l1b_fp4 = l1b_u8.ReinterpretCast<fp4x2_e1m2_t>();" in cube_code
    assert "L0NZ2ZN_MX(" in cube_code
    assert "L0NZ2ZN_MX(" not in vec_code
    assert "MMAD_MX(l0c" in cube_code


def test_l1_to_l0_mx_transpose_codegen_uses_nz2zn_and_normal_scale() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_transpose_codegen(inp)
        cube_code, vec_code = translate_split(_mx_transpose_codegen.instructions, "mx_transpose_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "L0NZ2ZN_MX(l0b, l1b, scale_b, 64, 32, 64, 32);" in cube_code
    assert "L0NZ2NZ_MX(" not in cube_code
    assert "L0NZ2ZN_MX(" not in vec_code


def test_l1_to_l0_mx_transpose_to_l0a_codegen_uses_nz2zn_and_normal_scale() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_transpose_l0a_codegen(inp)
        cube_code, vec_code = translate_split(_mx_transpose_l0a_codegen.instructions, "mx_transpose_l0a_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "L0NZ2ZN_MX(l0a, l1a, scale_a, 64, 32, 64, 32);" in cube_code
    assert "L0NZ2ZN_MX(" not in vec_code


def test_zero_mxfp8_l1_padding_codegen_uses_uint16_carrier() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_padding_codegen(inp)
        cube_code, vec_code = translate_split(_mx_padding_codegen.instructions, "mx_padding_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "LocalTensor<uint16_t> l1_pad_zero_u16 = l1_pad.ReinterpretCast<uint16_t>();" in cube_code
    # The block count is parenthesised because it may arrive as an expression.
    assert "InitConstValue(l1_pad_zero_u16, {1, (uint16_t)(64), 0, 0});" in cube_code
    assert "PipeBarrier<PIPE_MTE2>();" in cube_code
    assert "InitConstValue(" not in vec_code


def test_mx_external_scale_codegen_uses_normal_gm_to_l1_pad() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        scale_a_gm = GMTensor(DT.uint8, [1, 32], name="scale_a_gm")
        scale_b_gm = GMTensor(DT.uint8, [1, 32], name="scale_b_gm")
        _mx_external_scale_codegen(inp, scale_a_gm, scale_b_gm)
        cube_code, vec_code = translate_split(_mx_external_scale_codegen.instructions, "mx_external_scale_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "GM2L1PAD(scale_a, scale_a_gm, 1, 32, 0, 0);" in cube_code
    assert "GM2L1PAD(scale_b, scale_b_gm, 1, 32, 0, 0);" in cube_code
    assert "GM2L1PAD(" not in vec_code


def test_mx_external_dense_scale_codegen_uses_mx_dn2nz_helper() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        scale_a_gm = GMTensor(DT.uint8, [16, 3], name="scale_a_gm")
        scale_b_gm = GMTensor(DT.uint8, [16, 3], name="scale_b_gm")
        _mx_external_dense_scale_codegen(inp, scale_a_gm, scale_b_gm)
        cube_code, vec_code = translate_split(
            _mx_external_dense_scale_codegen.instructions,
            "mx_external_dense_scale_codegen",
        )
    finally:
        globvars.device_type = saved_device_type

    assert "GM2L1_MX_SCALE_DN2NZ(scale_a, scale_a_gm, 16, 3, 3);" in cube_code
    assert "GM2L1_MX_SCALE_DN2NZ(scale_b, scale_b_gm, 16, 3, 3);" in cube_code
    assert "GM2L1_MX_SCALE_DN2NZ(" not in vec_code


def test_gm_to_l1_mx_scale_nd2nz_codegen_rows32_k128() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(src: GMTensor):
            dst = Tensor(DT.uint8, [32, 4], Position.L1, name="dst")
            gm_to_l1_mx_scale_nd2nz(dst, src)
            return src

        src = GMTensor(DT.uint8, [32, 4], name="src")
        stub_only(src)
        cube_code, _ = translate_split(stub_only.instructions, "gm_to_l1_mx_scale_nd2nz_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "GM2L1_MX_SCALE_DN2NZ(dst, src, 32, 4, 4);" in cube_code


def test_gm_to_l1_mx_scale_nd2nz_rejects_misaligned_rows_and_bad_dst_cols() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def bad_rows(src: GMTensor):
            dst = Tensor(DT.uint8, [24, 4], Position.L1)
            gm_to_l1_mx_scale_nd2nz(dst, src)
            return src

        @kernel()
        def bad_cols(src: GMTensor):
            dst = Tensor(DT.uint8, [16, 2], Position.L1)
            gm_to_l1_mx_scale_nd2nz(dst, src)
            return src

        with pytest.raises(ValueError, match="16-row aligned"):
            bad_rows(GMTensor(DT.uint8, [24, 4]))
        with pytest.raises(ValueError, match="2 \\* ceil\\(k_groups / 2\\)"):
            bad_cols(GMTensor(DT.uint8, [16, 3]))
    finally:
        globvars.device_type = saved_device_type


def test_gm_to_l1_mx_scale_codegen_for_k128_tile_offset() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(src: GMTensor):
            dst = Tensor(DT.uint8, [16, 4], Position.L1, name="dst")
            gm_to_l1_mx_scale(dst, src, row_tile_idx=3)
            return src

        src = GMTensor(DT.uint8, [16, 32], name="src")
        stub_only(src)
        cube_code, _ = translate_split(stub_only.instructions, "gm_to_l1_mx_scale_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "GM2L1PAD(dst, src[6 * 32], 2, 32, 0, 0);" in cube_code


def test_matmul_mx_splitk_codegen_accumulates_l0c() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_matmul_splitk_codegen(inp)
        cube_code, vec_code = translate_split(_mx_matmul_splitk_codegen.instructions, "mx_matmul_splitk_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "for (int _subk = 0; _subk < 128; _subk += 64)" in cube_code
    assert "L0NZ2NZ_MX(" in cube_code
    assert "MMAD_MX(l0c" in cube_code
    assert "MMAD_MX(" not in vec_code
    assert "if (_subk == 0)" in cube_code
    assert "MMAD_MX(l0c, " in cube_code
    assert "true);" in cube_code
    assert "false);" in cube_code


def test_matmul_mx_splitn_codegen_slices_n_and_scale_b() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_matmul_splitn_codegen(inp)
        cube_code, vec_code = translate_split(_mx_matmul_splitn_codegen.instructions, "mx_matmul_splitn_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "for (int _subn = 0; _subn < 32; _subn += 16)" in cube_code
    assert "if (_subn == 0)" in cube_code
    assert "L0NZ2NZ_MX(" in cube_code
    assert "scale_b[" in cube_code
    assert re.search(r"MMAD_MX\(l0c\[0\s*\*\s*16\s*\+\s*_subn\s*\*\s*16\],", cube_code) is not None
    assert "MMAD_MX(" not in vec_code


def test_matmul_mx_transposed_b_nosplit_codegen_uses_nz2zn() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_matmul_transpose_nosplit_codegen(inp)
        cube_code, vec_code = translate_split(
            _mx_matmul_transpose_nosplit_codegen.instructions,
            "mx_matmul_transpose_nosplit_codegen",
        )
    finally:
        globvars.device_type = saved_device_type

    assert "L0NZ2NZ_MX(" in cube_code
    assert re.search(r"L0NZ2ZN_MX\([^,]+, l1b, scale_b, 64, 32, 64, 32\);", cube_code) is not None
    assert re.search(r"MMAD_MX\(l0c, [^,]+, [^,]+, 16, 64, 32, true\);", cube_code) is not None
    assert "L0NZ2ZN_MX(" not in vec_code
    assert "MMAD_MX(" not in vec_code


def test_matmul_mx_transposed_a_nosplit_codegen_uses_nz2zn() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_matmul_transposed_a_nosplit_codegen(inp)
        cube_code, vec_code = translate_split(
            _mx_matmul_transposed_a_nosplit_codegen.instructions,
            "mx_matmul_transposed_a_nosplit_codegen",
        )
    finally:
        globvars.device_type = saved_device_type

    assert re.search(r"L0NZ2ZN_MX\([^,]+, l1a, scale_a, 64, 32, 64, 32\);", cube_code) is not None
    assert "L0NZ2NZ_MX(" in cube_code
    assert re.search(r"MMAD_MX\(l0c, [^,]+, [^,]+, 32, 64, 16, true\);", cube_code) is not None
    assert "L0NZ2ZN_MX(" not in vec_code


def test_matmul_mx_both_transposed_nosplit_codegen_uses_nz2zn_for_both_sides() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_matmul_both_transposed_nosplit_codegen(inp)
        cube_code, vec_code = translate_split(
            _mx_matmul_both_transposed_nosplit_codegen.instructions,
            "mx_matmul_both_transposed_nosplit_codegen",
        )
    finally:
        globvars.device_type = saved_device_type

    assert re.search(r"L0NZ2ZN_MX\([^,]+, l1a, scale_a, 64, 32, 64, 32\);", cube_code) is not None
    assert re.search(r"L0NZ2ZN_MX\([^,]+, l1b, scale_b, 64, 32, 64, 32\);", cube_code) is not None
    assert re.search(r"MMAD_MX\(l0c, [^,]+, [^,]+, 32, 64, 32, true\);", cube_code) is not None
    assert "L0NZ2ZN_MX(" not in vec_code


def test_matmul_mx_transposed_b_splitk_codegen_offsets_scale_stream() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_matmul_transpose_splitk_codegen(inp)
        cube_code, vec_code = translate_split(
            _mx_matmul_transpose_splitk_codegen.instructions,
            "mx_matmul_transpose_splitk_codegen",
        )
    finally:
        globvars.device_type = saved_device_type

    assert "for (int _subk = 0; _subk < 128; _subk += 64)" in cube_code
    assert re.search(
        r"L0NZ2ZN_MX\([^,]+, l1b\[_subk \* 32 \+ 0 \* 128\], "
        r"scale_b\[32\*\(\(_subk\) / \(64\)\)\], Min\(128 - _subk, 64\), 32, 128, 32\);",
        cube_code,
    ) is not None
    assert re.search(r"MMAD_MX\(l0c, [^,]+, [^,]+, 16, Min\(128 - _subk, 64\), 32, true\);", cube_code) is not None
    assert re.search(r"MMAD_MX\(l0c, [^,]+, [^,]+, 16, Min\(128 - _subk, 64\), 32, false\);", cube_code) is not None
    assert "L0NZ2ZN_MX(" not in vec_code


def test_matmul_mx_transposed_b_splitn_codegen_offsets_scale_stream() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_matmul_transpose_splitn_codegen(inp)
        cube_code, vec_code = translate_split(
            _mx_matmul_transpose_splitn_codegen.instructions,
            "mx_matmul_transpose_splitn_codegen",
        )
    finally:
        globvars.device_type = saved_device_type

    assert "for (int _subn = 0; _subn < 64; _subn += 32)" in cube_code
    assert re.search(
        r"L0NZ2ZN_MX\([^,]+, l1b\[0 \* 32 \+ _subn \* 64\], "
        r"scale_b\[32\*CeilDiv\(64, 64\)\*\(\(_subn\) / \(16\)\)\], 64, Min\(64 - _subn, 32\), 64, 64\);",
        cube_code,
    ) is not None
    assert re.search(r"MMAD_MX\(l0c\[0\s*\*\s*16\s*\+\s*_subn\s*\*\s*16\],", cube_code) is not None
    assert "L0NZ2ZN_MX(" not in vec_code


def test_l1_to_l0_mx_transpose_splitk_uses_physical_scale_offset() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_transpose_splitk_codegen(inp)
        cube_code, vec_code = translate_split(_mx_transpose_splitk_codegen.instructions, "mx_transpose_splitk_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "for (int subk = 0; subk < 128; subk += 64)" in cube_code
    assert "int valid_k = Min(128 - subk, 64);" in cube_code
    assert (
        "L0NZ2ZN_MX(l0b, l1b[subk * 32 + 0 * 128], "
        "scale_b[32*((subk) / (64))], valid_k, 32, 128, 32);"
    ) in cube_code
    assert "L0NZ2ZN_MX(" not in vec_code


def test_l1_to_l0_mx_transpose_splitn_uses_row_tile_scale_offset() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1], name="inp")
        _mx_transpose_splitn_codegen(inp)
        cube_code, vec_code = translate_split(_mx_transpose_splitn_codegen.instructions, "mx_transpose_splitn_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "for (int subn = 0; subn < 64; subn += 32)" in cube_code
    assert "int valid_n = Min(64 - subn, 32);" in cube_code
    assert (
        "L0NZ2ZN_MX(l0b, l1b[0 * 32 + subn * 64], "
        "scale_b[32*k64_blocks*((subn) / (16))], 64, valid_n, 64, 64);"
    ) in cube_code
    assert "L0NZ2ZN_MX(" not in vec_code


def test_l1_to_l0_mx_transpose_allows_full_scale_tile_with_explicit_offset() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def splitk_static(inp: GMTensor):
            l1b = Tensor(DT.e4m3, [128, 32], Position.L1, name="l1b")
            scale_b = Tensor(DT.uint8, [32, 4], Position.L1, name="scale_b")
            l0b = Tensor(DT.mx_e4m3, [64, 32], Position.L0B, name="l0b")
            l1_to_l0_mx(
                l0b,
                l1b[64:128, :].T,
                scale_b,
                m_dst=64,
                n_dst=32,
                m_src=128,
                n_src=32,
                src_mx_offset_element=32,
            )
            return inp

        @kernel()
        def splitn_static(inp: GMTensor):
            l1b = Tensor(DT.e4m3, [64, 64], Position.L1, name="l1b")
            scale_b = Tensor(DT.uint8, [64, 2], Position.L1, name="scale_b")
            l0b = Tensor(DT.mx_e4m3, [64, 32], Position.L0B, name="l0b")
            l1_to_l0_mx(
                l0b,
                l1b[:, 32:64].T,
                scale_b,
                m_dst=64,
                n_dst=32,
                m_src=64,
                n_src=64,
                src_mx_offset_element=64,
            )
            return inp

        inp = GMTensor(DT.float, [1, 1], name="inp")
        splitk_static(inp)
        splitk_code, _ = translate_split(splitk_static.instructions, "mx_transpose_splitk_static")
        splitn_static(inp)
        splitn_code, _ = translate_split(splitn_static.instructions, "mx_transpose_splitn_static")
    finally:
        globvars.device_type = saved_device_type

    assert "L0NZ2ZN_MX(l0b, l1b[64 * 32 + 0 * 128], scale_b[32], 64, 32, 128, 32);" in splitk_code
    assert "L0NZ2ZN_MX(l0b, l1b[0 * 32 + 32 * 64], scale_b[64], 64, 32, 64, 64);" in splitn_code


def test_matmul_mx_rejects_splitn_and_splitk_together() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            l1a = Tensor(DT.e4m3, [16, 128], Position.L1)
            l1b = Tensor(DT.e4m3, [32, 128], Position.L1)
            scale_a = Tensor(DT.uint8, [16, 4], Position.L1)
            scale_b = Tensor(DT.uint8, [32, 4], Position.L1)
            l0c = Tensor(DT.float, [16, 32], Position.L0C)
            matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitn=16, splitk=64, m=16, n=32, k=128)
            return inp

        with pytest.raises(ValueError, match="splitn and splitk"):
            stub_only(GMTensor(DT.float, [1, 1]))
    finally:
        globvars.device_type = saved_device_type


def test_matmul_mx_rejects_too_small_transposed_tiles_and_splitn() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def l1a_transpose_stub(inp: GMTensor):
            l1a = Tensor(DT.e4m3, [16, 64], Position.L1)
            l1b = Tensor(DT.e4m3, [16, 64], Position.L1)
            scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
            scale_b = Tensor(DT.uint8, [16, 2], Position.L1)
            l0c = Tensor(DT.float, [16, 16], Position.L0C)
            matmul_mx(l0c, l1a.T, l1b, scale_a, scale_b, m=16, n=16, k=64)
            return inp

        @kernel()
        def transposed_splitn_stub(inp: GMTensor):
            l1a = Tensor(DT.e4m3, [16, 64], Position.L1)
            l1b = Tensor(DT.e4m3, [64, 32], Position.L1)
            scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
            scale_b = Tensor(DT.uint8, [32, 2], Position.L1)
            l0c = Tensor(DT.float, [16, 32], Position.L0C)
            matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, splitn=16, m=16, n=32, k=64)
            return inp

        @kernel()
        def fp4_transposed_stub(inp: GMTensor):
            l1a_u8 = Tensor(DT.uint8, [16, 32], Position.L1)
            l1b_u8 = Tensor(DT.uint8, [64, 16], Position.L1)
            l1a = l1a_u8.reinterpret(DT.fp4_e2m1)
            l1b = l1b_u8.reinterpret(DT.fp4_e1m2)
            scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
            scale_b = Tensor(DT.uint8, [32, 2], Position.L1)
            l0c = Tensor(DT.float, [16, 32], Position.L0C)
            matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, m=16, n=32, k=64)
            return inp

        inp = GMTensor(DT.float, [1, 1])
        with pytest.raises(ValueError, match="32-element aligned"):
            l1a_transpose_stub(inp)
        with pytest.raises(ValueError, match="multiple of 32"):
            transposed_splitn_stub(inp)
        with pytest.raises(ValueError, match="64-element aligned"):
            fp4_transposed_stub(inp)
    finally:
        globvars.device_type = saved_device_type


def test_matmul_mx_splitn_requires_full_scale_b_rows() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            l1a = Tensor(DT.e4m3, [16, 64], Position.L1)
            l1b = Tensor(DT.e4m3, [32, 64], Position.L1)
            scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
            scale_b = Tensor(DT.uint8, [16, 2], Position.L1)
            l0c = Tensor(DT.float, [16, 32], Position.L0C)
            matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitn=16, m=16, n=32, k=64)
            return inp

        with pytest.raises(ValueError, match="full B logical row count"):
            stub_only(GMTensor(DT.float, [1, 1]))
    finally:
        globvars.device_type = saved_device_type


def test_matmul_mx_rejects_non_16row_scale_tile() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            l1a = Tensor(DT.e4m3, [32, 128], Position.L1)
            l1b = Tensor(DT.e4m3, [16, 128], Position.L1)
            scale_a = Tensor(DT.uint8, [32, 4], Position.L1)
            scale_b = Tensor(DT.uint8, [16, 4], Position.L1)
            l0c = Tensor(DT.float, [32, 16], Position.L0C)
            matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitk=64, m=32, n=16, k=128)
            return inp

        inp = GMTensor(DT.float, [1, 1])
        with pytest.raises(ValueError, match="16-row"):
            stub_only(inp)
    finally:
        globvars.device_type = saved_device_type


def test_gm_to_l1_mx_scale_allows_var_l1_shape() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(src: GMTensor, rows: Var, cols: Var):
            dst = Tensor(DT.uint8, [rows, cols], Position.L1, name="dst")
            gm_to_l1_mx_scale(dst, src)
            return src

        rows = Var(16, DT.int, name="rows")
        cols = Var(4, DT.int, name="cols")
        src = GMTensor(DT.uint8, [16, 32], name="src")
        stub_only(src, rows, cols)
        cube_code, _ = translate_split(stub_only.instructions, "gm_to_l1_mx_scale_var_shape_codegen")
    finally:
        globvars.device_type = saved_device_type

    assert "AllocateLocalTensor<TPosition::A1, uint8_t>(rows * cols);" in cube_code
    assert "GM2L1PAD(dst, src, ((cols) / (2)), 32, 0, 0);" in cube_code


def test_gm_to_l1_mx_scale_rejects_known_var_l1_shape_mismatch() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(src: GMTensor, rows: Var, cols: Var):
            dst = Tensor(DT.uint8, [rows, cols], Position.L1)
            gm_to_l1_mx_scale(dst, src)
            return src

        src = GMTensor(DT.uint8, [16, 32])
        with pytest.raises(ValueError, match="one 16-row"):
            stub_only(src, Var(8, DT.int, name="rows"), Var(4, DT.int, name="cols"))
        with pytest.raises(ValueError, match="even scale columns"):
            stub_only(src, Var(16, DT.int, name="rows2"), Var(3, DT.int, name="cols2"))
    finally:
        globvars.device_type = saved_device_type


def test_gm_to_l1_mx_scale_rejects_row_major_gm_shape() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(src: GMTensor):
            dst = Tensor(DT.uint8, [16, 4], Position.L1)
            gm_to_l1_mx_scale(dst, src)
            return src

        src = GMTensor(DT.uint8, [16, 4])
        with pytest.raises(ValueError, match="packed as"):
            stub_only(src)
    finally:
        globvars.device_type = saved_device_type


def test_gm_to_l1_pad_allows_unaligned_gm_burst_with_l1_padding() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(src: GMTensor):
            dst = Tensor(DT.uint8, [1, 32], Position.L1)
            gm_to_l1_pad(dst, src)
            return src

        src = GMTensor(DT.uint8, [1, 1])
        stub_only(src)
        found = [inst for inst in stub_only.instructions if inst.opname == "gm_to_l1_pad"]
        assert found[-1].kwargs["burst_len_byte"] == 1
    finally:
        globvars.device_type = saved_device_type


def test_gm_to_l1_pad_rejects_underallocated_l1_padding() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(src: GMTensor):
            dst = Tensor(DT.uint8, [1, 1], Position.L1)
            gm_to_l1_pad(dst, src)
            return src

        src = GMTensor(DT.uint8, [1, 1])
        with pytest.raises(ValueError, match="destination footprint"):
            stub_only(src)
    finally:
        globvars.device_type = saved_device_type


def test_l1_to_l0_mx_transpose_defaults_to_source_shape() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            l1 = Tensor(DT.e4m3, [64, 32], Position.L1, name="l1")
            scale = Tensor(DT.uint8, [32, 2], Position.L1, name="scale")
            l0 = Tensor(DT.mx_e4m3, [64, 32], Position.L0B, name="l0")
            l1_to_l0_mx(l0, l1.T, scale)
            return inp

        inp = GMTensor(DT.float, [1, 1])
        stub_only(inp)
        cube_code, _ = translate_split(stub_only.instructions, "l1_to_l0_mx_transpose_defaults")
    finally:
        globvars.device_type = saved_device_type

    assert "L0NZ2ZN_MX(l0, l1, scale, 64, 32, 64, 32);" in cube_code


def test_l1_to_l0_mx_rejects_scale_transpose() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        l1 = Tensor(DT.e4m3, [16, 64], Position.L1)
        scale = Tensor(DT.uint8, [16, 2], Position.L1)
        l0 = Tensor(DT.mx_e4m3, [16, 64], Position.L0A)
        with pytest.raises(ValueError, match="scale tensor cannot be transposed"):
            l1_to_l0_mx(l0, l1, scale.T)
    finally:
        globvars.device_type = saved_device_type


def test_zero_mxfp8_l1_padding_rejects_non_byte_tensor() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        l1 = Tensor(DT.half, [16, 16], Position.L1)
        with pytest.raises(TypeError, match="byte-sized"):
            zero_mxfp8_l1_padding(l1)
    finally:
        globvars.device_type = saved_device_type


def test_zero_mxfp8_l1_padding_rejects_unaligned_static_footprint() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        l1 = Tensor(DT.e4m3, [1, 1], Position.L1)
        with pytest.raises(ValueError, match="32B aligned"):
            zero_mxfp8_l1_padding(l1)
    finally:
        globvars.device_type = saved_device_type


def test_l1_to_l0_mx_allows_transpose_to_l0a() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        l1 = Tensor(DT.e4m3, [64, 32], Position.L1)
        scale = Tensor(DT.uint8, [32, 2], Position.L1)
        l0 = Tensor(DT.mx_e4m3, [64, 32], Position.L0A)
        l1_to_l0_mx(l0, l1.T, scale, m_dst=64, n_dst=32, m_src=64, n_src=32)
    finally:
        globvars.device_type = saved_device_type


def test_l1_to_l0_mx_rejects_transpose_tile_below_32x32() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        l1 = Tensor(DT.e4m3, [64, 16], Position.L1)
        scale = Tensor(DT.uint8, [16, 2], Position.L1)
        l0 = Tensor(DT.mx_e4m3, [64, 16], Position.L0B)
        with pytest.raises(ValueError, match="32-element aligned"):
            l1_to_l0_mx(l0, l1.T, scale, m_dst=64, n_dst=16, m_src=64, n_src=16)
    finally:
        globvars.device_type = saved_device_type


def test_l1_to_l0_mx_rejects_transpose_scale_in_source_order() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        l1 = Tensor(DT.e4m3, [64, 32], Position.L1)
        scale = Tensor(DT.uint8, [64, 2], Position.L1)
        l0 = Tensor(DT.mx_e4m3, [64, 32], Position.L0B)
        with pytest.raises(ValueError, match="scale shape"):
            l1_to_l0_mx(l0, l1.T, scale, m_dst=64, n_dst=32, m_src=64, n_src=32)
    finally:
        globvars.device_type = saved_device_type


def test_l1_to_l0_mx_rejects_swapped_scale_shape() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        l1 = Tensor(DT.e4m3, [16, 64], Position.L1)
        scale = Tensor(DT.uint8, [2, 16], Position.L1)
        l0 = Tensor(DT.mx_e4m3, [16, 64], Position.L0A)
        with pytest.raises(ValueError, match="scale shape"):
            l1_to_l0_mx(l0, l1, scale, m_dst=16, n_dst=64, m_src=16, n_src=64)
    finally:
        globvars.device_type = saved_device_type
