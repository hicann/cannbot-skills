from easyasc.a5 import DT, Pipe, Position
from easyasc.parser.asc import split_instructions
from easyasc.parser.asc_autosync import insert_auto_sync
from easyasc.stub_functions.misc import reinterpret
from testcases.parser.sync._autosync_test_helpers import device_type
from testcases.parser.sync._autosync_vec_kernels import (
    autosync_vec_b_device_manual_barrier,
    autosync_vec_b_device_value_dependency,
    build_b_device_manual_barrier_kernel,
    build_b_device_value_dependency_kernel,
)

def test_insert_auto_sync_b_device_inserts_bar_v_before_vec_read_after_vec_write() -> None:
    with device_type("b3"):
        build_b_device_value_dependency_kernel()
        _, vec_insts = split_instructions(list(autosync_vec_b_device_value_dependency.instructions))
        vec_insts = insert_auto_sync(vec_insts, mode="vec")

    add_indices = [idx for idx, inst in enumerate(vec_insts) if inst.opname == "add"]
    barrier_indices = [
        idx
        for idx, inst in enumerate(vec_insts)
        if inst.opname == "barrier" and str(inst.kwargs.get("pipe", "")) == str(Pipe.V)
    ]

    assert len(add_indices) == 2
    assert len(barrier_indices) == 1
    assert add_indices[0] < barrier_indices[0] < add_indices[1]

def test_insert_auto_sync_b_device_manual_bar_v_clears_pending_vec_writes() -> None:
    with device_type("b3"):
        build_b_device_manual_barrier_kernel()
        _, vec_insts = split_instructions(list(autosync_vec_b_device_manual_barrier.instructions))
        vec_insts = insert_auto_sync(vec_insts, mode="vec")

    barrier_indices = [
        idx
        for idx, inst in enumerate(vec_insts)
        if inst.opname == "barrier" and str(inst.kwargs.get("pipe", "")) == str(Pipe.V)
    ]
    add_indices = [idx for idx, inst in enumerate(vec_insts) if inst.opname == "add"]

    assert len(barrier_indices) == 1
    assert len(add_indices) == 2
    assert add_indices[0] < barrier_indices[0] < add_indices[1]

def test_insert_b_device_vec_barriers_war_hazard() -> None:
    from easyasc.parser.asc_autosync import _insert_b_device_vec_barriers
    from easyasc.utils.Tensor import Tensor
    from easyasc.utils.instruction import Instruction

    t_a = Tensor(DT.float, [1, 16], Position.UB, name="a")
    t_b = Tensor(DT.float, [1, 16], Position.UB, name="b")
    t_c = Tensor(DT.float, [1, 16], Position.UB, name="c")
    insts = [
        Instruction("add", src=t_a, dst=t_b),   # reads a, writes b
        Instruction("add", src=t_c, dst=t_a),   # reads c, writes a -> WAR on a
    ]

    with device_type("b3"):
        result = _insert_b_device_vec_barriers(insts)

    ops = [inst.opname for inst in result]
    assert ops == ["add", "barrier", "add"]

def test_insert_b_device_vec_barriers_waw_hazard() -> None:
    from easyasc.parser.asc_autosync import _insert_b_device_vec_barriers
    from easyasc.utils.Tensor import Tensor
    from easyasc.utils.instruction import Instruction

    t_a = Tensor(DT.float, [1, 16], Position.UB, name="a")
    t_b = Tensor(DT.float, [1, 16], Position.UB, name="b")
    insts = [
        Instruction("add", src=t_a, dst=t_b),   # reads a, writes b
        Instruction("add", src=t_a, dst=t_b),   # reads a, writes b -> WAW on b
    ]

    with device_type("b3"):
        result = _insert_b_device_vec_barriers(insts)

    ops = [inst.opname for inst in result]
    assert ops == ["add", "barrier", "add"]


def test_insert_b_device_vec_barriers_tracks_anonymous_tensor_slices() -> None:
    from easyasc.parser.asc_autosync import _insert_b_device_vec_barriers
    from easyasc.utils.Tensor import Tensor
    from easyasc.utils.instruction import Instruction
    from easyasc.utils.roundmode import RoundMode
    from easyasc.utils.var import Var

    valid_groups = Var(16)
    scale_s = Tensor(DT.float, [1, 64], Position.UB)
    abs_float = Tensor(DT.float, [16, 64], Position.UB)
    scale_bf16 = Tensor(DT.bfloat16, [1, 64], Position.UB)
    scale_view = scale_s[0:1, 0:valid_groups]
    bf16_view = scale_bf16[0:1, 0:valid_groups]
    insts = [
        Instruction("cmax", dst=scale_s, src=abs_float),
        Instruction("muls", dst=scale_view, src=scale_view),
        Instruction("cast", dst=bf16_view, src=scale_view, mode=RoundMode.AWAY_FROM_ZERO),
        Instruction("cast", dst=scale_view, src=bf16_view, mode=RoundMode.NONE),
    ]

    with device_type("b3"):
        result = _insert_b_device_vec_barriers(insts)

    ops = [inst.opname for inst in result]
    assert ops == ["cmax", "barrier", "muls", "barrier", "cast", "barrier", "cast"]


def test_insert_b_device_vec_barriers_tracks_reinterpret_aliases() -> None:
    from easyasc.parser.asc_autosync import _insert_b_device_vec_barriers
    from easyasc.utils.Tensor import Tensor
    from easyasc.utils.instruction import Instruction

    src = Tensor(DT.float, [1, 16], Position.UB, name="src")
    mask = Tensor(DT.uint16, [1, 32], Position.UB, name="mask")
    dst = reinterpret(src, DT.uint16, name="src_bits")

    insts = [
        Instruction("muls", dst=src, src=src),
        Instruction("vand", dst=dst, src1=dst, src2=mask),
    ]

    with device_type("b3"):
        result = _insert_b_device_vec_barriers(insts)

    ops = [inst.opname for inst in result]
    assert ops == ["muls", "barrier", "vand"]
