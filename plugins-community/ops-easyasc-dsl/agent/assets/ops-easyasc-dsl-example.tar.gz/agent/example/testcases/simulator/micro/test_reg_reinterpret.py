from itertools import product
from types import SimpleNamespace

import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate
from easyasc.simulator.memory import SharedMemoryStore, torch_dtype
from easyasc.simulator.pipe_micro import MicroRuntime
from easyasc.utils.instruction import Instruction
from easyasc.utils.reg import MaskReg, Reg


ROWS = 96
SRC_COLS = 64
DST_COLS = 256
HALF_COLS = 128
INT_COLS = 64

REINTERPRET_DTYPES = [
    DT.uint8,
    DT.int8,
    DT.e4m3,
    DT.e5m2,
    DT.mx_e4m3,
    DT.mx_e5m2,
    DT.hif8,
    DT.half,
    DT.bfloat16,
    DT.uint16,
    DT.int16,
    DT.float,
    DT.int,
    DT.uint32,
    DT.uint64,
    DT.int64,
]


@vf()
def reg_reinterpret_float_to_u8_vf(src: Tensor, dst: Tensor):
    src_reg = Reg(DT.float)
    src_reg <<= src[0:1, 0:SRC_COLS]
    bytes_reg = src_reg.reinterpret(DT.uint8)
    dst[0:1, 0:DST_COLS] <<= bytes_reg


@vf()
def reg_reinterpret_half_to_u8_vf(src: Tensor, dst: Tensor):
    src_reg = Reg(DT.half)
    src_reg <<= src[0:1, 0:HALF_COLS]
    bytes_reg = src_reg.reinterpret(DT.uint8)
    dst[0:1, 0:DST_COLS] <<= bytes_reg


@vf()
def reg_reinterpret_u8_to_half_vf(src: Tensor, dst: Tensor):
    src_reg = Reg(DT.uint8)
    src_reg <<= src[0:1, 0:DST_COLS]
    half_reg = src_reg.reinterpret(DT.half)
    dst[0:1, 0:HALF_COLS] <<= half_reg


@vf()
def reg_reinterpret_int_to_half_vf(src: Tensor, dst: Tensor):
    src_reg = Reg(DT.int)
    src_reg <<= src[0:1, 0:INT_COLS]
    half_reg = src_reg.reinterpret(DT.half)
    dst[0:1, 0:HALF_COLS] <<= half_reg


@vf()
def reg_reinterpret_half_to_int_vf(src: Tensor, dst: Tensor):
    src_reg = Reg(DT.half)
    src_reg <<= src[0:1, 0:HALF_COLS]
    int_reg = src_reg.reinterpret(DT.int)
    dst[0:1, 0:INT_COLS] <<= int_reg


@kernel()
def reg_reinterpret_kernel(src: GMTensor, out: GMTensor, rows: Var):
    ub_src = Tensor(DT.float, [1, SRC_COLS], Position.UB)
    ub_out = Tensor(DT.uint8, [1, DST_COLS], Position.UB)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(begin, end, 1):
            ub_src <<= src[row:row + 1, :]
            reg_reinterpret_float_to_u8_vf(ub_src, ub_out)
            out[row:row + 1, :] <<= ub_out
    return out


@kernel()
def reg_reinterpret_half_to_u8_kernel(src: GMTensor, out: GMTensor, rows: Var):
    ub_src = Tensor(DT.half, [1, HALF_COLS], Position.UB)
    ub_out = Tensor(DT.uint8, [1, DST_COLS], Position.UB)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(begin, end, 1):
            ub_src <<= src[row:row + 1, :]
            reg_reinterpret_half_to_u8_vf(ub_src, ub_out)
            out[row:row + 1, :] <<= ub_out
    return out


@kernel()
def reg_reinterpret_u8_to_half_kernel(src: GMTensor, out: GMTensor, rows: Var):
    ub_src = Tensor(DT.uint8, [1, DST_COLS], Position.UB)
    ub_out = Tensor(DT.half, [1, HALF_COLS], Position.UB)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(begin, end, 1):
            ub_src <<= src[row:row + 1, :]
            reg_reinterpret_u8_to_half_vf(ub_src, ub_out)
            out[row:row + 1, :] <<= ub_out
    return out


@kernel()
def reg_reinterpret_int_to_half_kernel(src: GMTensor, out: GMTensor, rows: Var):
    ub_src_int = Tensor(DT.int, [1, INT_COLS], Position.UB)
    ub_out_half = Tensor(DT.half, [1, HALF_COLS], Position.UB)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(begin, end, 1):
            ub_src_int <<= src[row:row + 1, :]
            reg_reinterpret_int_to_half_vf(ub_src_int, ub_out_half)
            out[row:row + 1, :] <<= ub_out_half
    return out


@kernel()
def reg_reinterpret_half_to_int_kernel(src: GMTensor, out: GMTensor, rows: Var):
    ub_src_half = Tensor(DT.half, [1, HALF_COLS], Position.UB)
    ub_out_int = Tensor(DT.int, [1, INT_COLS], Position.UB)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(begin, end, 1):
            ub_src_half <<= src[row:row + 1, :]
            reg_reinterpret_half_to_int_vf(ub_src_half, ub_out_int)
            out[row:row + 1, :] <<= ub_out_int
    return out


def _lanes_for(dtype) -> int:
    return 256 // torch.empty((), dtype=torch_dtype(dtype)).element_size()


def _raw_register_tensor(dtype) -> torch.Tensor:
    raw = torch.arange(256, dtype=torch.uint8)
    torch_dt = torch_dtype(dtype)
    if torch_dt is torch.uint8:
        return raw.clone()
    return raw.view(torch_dt).clone()


def _bytes(tensor: torch.Tensor) -> torch.Tensor:
    return tensor.contiguous().view(torch.uint8)


def _run_runtime_reinterpret(src_dtype, dst_dtype) -> torch.Tensor:
    runtime = MicroRuntime()
    src = Reg(src_dtype, name="src")
    dst = Reg(dst_dtype, name="dst")
    src_mask = MaskReg(src_dtype, init_mode=MaskType.ALL, name="src_mask")
    dst_mask = MaskReg(dst_dtype, init_mode=MaskType.ALL, name="dst_mask")
    src_ref = SimpleNamespace(name="src_tensor")
    out_ref = SimpleNamespace(name="out_tensor")
    src_tensor = _raw_register_tensor(src_dtype)
    out_tensor = torch.zeros(_lanes_for(dst_dtype), dtype=torch_dtype(dst_dtype))
    if src_tensor.element_size() == 8:
        load = Instruction("micro_ub2regcont", dst=src, src=src_ref, mode="DIST_NORM")
    else:
        load = Instruction("micro_ub2reg", dst=src, src=src_ref, blk_stride=1, mask=src_mask)
    if out_tensor.element_size() == 8:
        store = Instruction("micro_reg2ubcont", dst=out_ref, src=dst, mode="DIST_NORM", mask=dst_mask)
    else:
        store = Instruction("micro_reg2ub", dst=out_ref, src=dst, blk_stride=1, mask=dst_mask)
    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=src),
            Instruction("create_maskreg", reg=src_mask),
            Instruction("create_maskreg", reg=dst_mask),
            load,
            Instruction("micro_reg_reinterpret", dst=dst, src=src),
            store,
        ]
    }

    runtime.execute_call_micro(
        micro_def,
        {"src_tensor": src_tensor, "out_tensor": out_tensor},
        {},
        SharedMemoryStore(),
    )
    return out_tensor


def _assert_same_bytes(actual: torch.Tensor, expected: torch.Tensor) -> None:
    assert torch.equal(_bytes(actual), _bytes(expected))


def test_reg_reinterpret_ast_name_and_codegen() -> None:
    src = Tensor(DT.float, [1, SRC_COLS], Position.UB, name="src")
    dst = Tensor(DT.uint8, [1, DST_COLS], Position.UB, name="dst")
    reg_reinterpret_float_to_u8_vf(src, dst)

    inst = next(
        item for item in reg_reinterpret_float_to_u8_vf.instructions
        if item.opname == "micro_reg_reinterpret"
    )
    assert inst.dst.name == "bytes_reg"
    assert not any(
        item.opname == "create_reg" and getattr(item.reg, "name", "") == "bytes_reg"
        for item in reg_reinterpret_float_to_u8_vf.instructions
    )

    code = translate(reg_reinterpret_float_to_u8_vf.instructions)
    assert (
        "MicroAPI::RegTensor<uint8_t>& bytes_reg = "
        "*(MicroAPI::RegTensor<uint8_t>*) &src_reg;"
    ) in code


def test_sim_reg_reinterpret_float_to_uint8_roundtrip() -> None:
    src = torch.arange(ROWS * SRC_COLS, dtype=torch.float32).reshape(ROWS, SRC_COLS)
    out = torch.zeros((ROWS, DST_COLS), dtype=torch.uint8)

    actual = OpExec(
        reg_reinterpret_kernel,
        "test_sim_reg_reinterpret_float_to_uint8",
        simulator=True,
    )(src, out, ROWS, shape_bindings={0: [0, None], 1: [0, None]})

    expected = src.contiguous().view(torch.uint8).view(ROWS, DST_COLS)
    assert torch.equal(actual, expected)


def test_micro_reg_reinterpret_preserves_raw_bytes_across_dtype_matrix() -> None:
    for src_dtype, dst_dtype in product(REINTERPRET_DTYPES, REINTERPRET_DTYPES):
        actual = _run_runtime_reinterpret(src_dtype, dst_dtype)
        expected = _raw_register_tensor(src_dtype)
        try:
            _assert_same_bytes(actual, expected)
        except AssertionError as exc:
            raise AssertionError(f"reinterpret {src_dtype} -> {dst_dtype} changed raw bytes") from exc


def test_sim_reg_reinterpret_selected_dtype_kernels() -> None:
    src_half = _raw_register_tensor(DT.half).view(1, HALF_COLS).repeat(ROWS, 1)
    src_u8 = _raw_register_tensor(DT.uint8).view(1, DST_COLS).repeat(ROWS, 1)
    src_int = _raw_register_tensor(DT.int).view(1, INT_COLS).repeat(ROWS, 1)
    src_half_for_int = torch.arange(256, dtype=torch.uint8).flip(0)
    src_half_for_int = src_half_for_int.view(torch.float16).clone().view(1, HALF_COLS).repeat(ROWS, 1)
    out_u8 = torch.zeros((ROWS, DST_COLS), dtype=torch.uint8)
    out_half = torch.zeros((ROWS, HALF_COLS), dtype=torch.float16)
    out_half_from_int = torch.zeros((ROWS, HALF_COLS), dtype=torch.float16)
    out_int = torch.zeros((ROWS, INT_COLS), dtype=torch.int32)

    actual_u8 = OpExec(reg_reinterpret_half_to_u8_kernel, "test_sim_reg_reinterpret_half_to_u8", simulator=True)(
        src_half, out_u8, ROWS, shape_bindings={0: [0, None], 1: [0, None]}
    )
    actual_half = OpExec(reg_reinterpret_u8_to_half_kernel, "test_sim_reg_reinterpret_u8_to_half", simulator=True)(
        src_u8, out_half, ROWS, shape_bindings={0: [0, None], 1: [0, None]}
    )
    actual_half_from_int = OpExec(
        reg_reinterpret_int_to_half_kernel,
        "test_sim_reg_reinterpret_int_to_half",
        simulator=True,
    )(src_int, out_half_from_int, ROWS, shape_bindings={0: [0, None], 1: [0, None]})
    actual_int = OpExec(reg_reinterpret_half_to_int_kernel, "test_sim_reg_reinterpret_half_to_int", simulator=True)(
        src_half_for_int, out_int, ROWS, shape_bindings={0: [0, None], 1: [0, None]}
    )

    _assert_same_bytes(actual_u8, src_half)
    _assert_same_bytes(actual_half, src_u8)
    _assert_same_bytes(actual_half_from_int, src_int)
    _assert_same_bytes(actual_int, src_half_for_int)
