from easyasc.a5 import *

from testcases.parser.sync._autosync_test_helpers import WIDTH


@kernel()
def autosync_cube_reacquires_valid_between_rounds(x: GMTensor, y: GMTensor, z: GMTensor, n: Var, k: Var):
    l1a = DBuff(DT.half, [1, WIDTH], Position.L1)
    l1b = DBuff(DT.half, [WIDTH, WIDTH], Position.L1)
    l0c = DBuff(DT.float, [1, WIDTH], Position.L0C)
    cnt = Var(0)

    with auto_sync():
        l1a[cnt][0:1, 0:k] <<= x[0:1, 0:k]
        l1b[cnt][0:n, 0:k] <<= y[0:n, 0:k]
        matmul(
            l0c[cnt][0:1, 0:n],
            l1a[cnt],
            l1b[cnt],
            splitn=WIDTH,
            m=1,
            n=n,
            k=k,
            is_init=True,
        )
        z[0:1, 0:n] <<= l0c[cnt][0:1, 0:n]
        l1a[cnt][0:1, 0:k] <<= x[0:1, 0:k]
        l1b[cnt][0:n, 0:k] <<= y[0:n, 0:k]
        matmul(
            l0c[cnt][0:1, 0:n],
            l1a[cnt],
            l1b[cnt],
            splitn=WIDTH,
            m=1,
            n=n,
            k=k,
            is_init=True,
        )
        z[0:1, 0:n] <<= l0c[cnt][0:1, 0:n]

    return z


def build_cube_reacquire_valid_between_rounds() -> None:
    x = GMTensor(DT.half, [1, WIDTH])
    y = GMTensor(DT.half, [WIDTH, WIDTH])
    z = GMTensor(DT.float, [1, WIDTH])
    autosync_cube_reacquires_valid_between_rounds(x, y, z, Var(WIDTH), Var(WIDTH))


@kernel()
def autosync_cube_parent_child_same_l1_stream(
    q: GMTensor, k: GMTensor, q_tail: GMTensor, k_tail: GMTensor,
    out: GMTensor, chunks: Var,
):
    """First K tile outside a loop, remaining tiles inside, one L1 DBuff."""
    l1q = DBuff(DT.half, [WIDTH, WIDTH], Position.L1)
    l1k = DBuff(DT.half, [WIDTH, WIDTH], Position.L1)
    l1q_tail = DBuff(DT.half, [WIDTH, WIDTH], Position.L1)
    l1k_tail = DBuff(DT.half, [WIDTH, WIDTH], Position.L1)
    l0c = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)
    l1_cnt = Var(0)

    with auto_sync():
        l1q[l1_cnt] <<= q[0:WIDTH, 0:WIDTH]
        l1k[l1_cnt] <<= k[0:WIDTH, 0:WIDTH]
        matmul(l0c[0], l1q[l1_cnt], l1k[l1_cnt], m=WIDTH, n=WIDTH, k=WIDTH, is_init=True)
        l1_cnt += 1

        for chunk_idx in range(1, chunks):
            offset = Var(chunk_idx * WIDTH)
            l1q[l1_cnt] <<= q[0:WIDTH, offset:offset + WIDTH]
            l1k[l1_cnt] <<= k[0:WIDTH, offset:offset + WIDTH]
            matmul(l0c[0], l1q[l1_cnt], l1k[l1_cnt], m=WIDTH, n=WIDTH, k=WIDTH, is_init=False)
            l1_cnt += 1

        l1q_tail[l1_cnt] <<= q_tail[0:WIDTH, 0:WIDTH]
        l1k_tail[l1_cnt] <<= k_tail[0:WIDTH, 0:WIDTH]
        matmul(l0c[0], l1q_tail[l1_cnt], l1k_tail[l1_cnt], m=WIDTH, n=WIDTH, k=WIDTH, is_init=False)
        out[0:WIDTH, 0:WIDTH] <<= l0c[0]

    return out


def build_cube_parent_child_same_l1_stream() -> None:
    q = GMTensor(DT.half, [WIDTH, 3 * WIDTH])
    k = GMTensor(DT.half, [WIDTH, 3 * WIDTH])
    q_tail = GMTensor(DT.half, [WIDTH, WIDTH])
    k_tail = GMTensor(DT.half, [WIDTH, WIDTH])
    out = GMTensor(DT.float, [WIDTH, WIDTH])
    autosync_cube_parent_child_same_l1_stream(q, k, q_tail, k_tail, out, Var(3))


@kernel()
def autosync_cube_loop_pending_valid_stays_in_loop(x: GMTensor, y: GMTensor, loops: Var, n: Var):
    l1a = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1b = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l0a = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0b = DBuff(DT.half, [WIDTH, WIDTH], Position.L0B)
    l0a_tail = Tensor(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0b_tail = Tensor(DT.half, [WIDTH, WIDTH], Position.L0B)
    l0c = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)

    with auto_sync():
        l1a[0:n, 0:n] <<= x[0:n, 0:n]
        l1b[0:n, 0:n] <<= x[0:n, 0:n]
        with If(n > 0):
            for idx in range(0, loops):
                l0a[idx] <<= l1a
                l0b[idx] <<= l1b
                mmad(l0c[idx], l0a[idx], l0b[idx])
                y[0:n, 0:n] <<= l0c[idx][0:n, 0:n]
                l0a[idx] <<= l1a
                l0b[idx] <<= l1b
                mmad(l0c[idx], l0a[idx], l0b[idx])
                y[0:n, 0:n] <<= l0c[idx][0:n, 0:n]
                l0a_tail <<= l1a
                l0b_tail <<= l1b
                mmad(l0c[idx], l0a_tail, l0b_tail)
                y[0:n, 0:n] <<= l0c[idx][0:n, 0:n]

    return y


def build_cube_loop_pending_valid_stays_in_loop() -> None:
    x = GMTensor(DT.half, [WIDTH, WIDTH])
    y = GMTensor(DT.float, [WIDTH, WIDTH])
    autosync_cube_loop_pending_valid_stays_in_loop(x, y, Var(3), Var(WIDTH))


@kernel()
def autosync_cube_outer_l0_ready_before_child_loop(x: GMTensor, y: GMTensor, loops: Var, n: Var):
    outer_l1 = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    inner_l1 = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    outer_l0b = Tensor(DT.half, [WIDTH, WIDTH], Position.L0B)
    inner_l0a = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0c = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)

    with auto_sync():
        outer_l1[0:n, 0:n] <<= x[0:n, 0:n]
        inner_l1[0:n, 0:n] <<= x[0:n, 0:n]
        outer_l0b <<= outer_l1
        with If(n > 0):
            for idx in range(0, loops):
                inner_l0a[idx] <<= inner_l1
                mmad(l0c[idx], inner_l0a[idx], outer_l0b)
                y[0:n, 0:n] <<= l0c[idx][0:n, 0:n]

    return y


def build_cube_outer_l0_ready_before_child_loop() -> None:
    x = GMTensor(DT.half, [WIDTH, WIDTH])
    y = GMTensor(DT.float, [WIDTH, WIDTH])
    autosync_cube_outer_l0_ready_before_child_loop(x, y, Var(3), Var(WIDTH))


@kernel()
def autosync_cube_aggressive_l0_groups_adjacent_mte1_keys(x: GMTensor, y: GMTensor, n: Var):
    l1a = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1b = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1c = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1d = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l0a = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0b = DBuff(DT.half, [WIDTH, WIDTH], Position.L0B)
    l0c = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0d = DBuff(DT.half, [WIDTH, WIDTH], Position.L0B)
    acc0 = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)
    acc1 = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)
    cnt = Var(0)

    with auto_sync(mode="aggressive"):
        l1a[0:n, 0:n] <<= x[0:n, 0:n]
        l1b[0:n, 0:n] <<= x[0:n, 0:n]
        l1c[0:n, 0:n] <<= x[0:n, 0:n]
        l1d[0:n, 0:n] <<= x[0:n, 0:n]
        l0a[cnt] <<= l1a
        l0b[cnt] <<= l1b
        l0c[cnt] <<= l1c
        l0d[cnt] <<= l1d
        mmad(acc0[cnt], l0a[cnt], l0b[cnt])
        mmad(acc1[cnt], l0c[cnt], l0d[cnt])
        y[0:n, 0:n] <<= acc0[cnt][0:n, 0:n]
        y[0:n, 0:n] <<= acc1[cnt][0:n, 0:n]

    return y


def build_cube_aggressive_l0_groups_adjacent_mte1_keys() -> None:
    x = GMTensor(DT.half, [WIDTH, WIDTH])
    y = GMTensor(DT.float, [WIDTH, WIDTH])
    autosync_cube_aggressive_l0_groups_adjacent_mte1_keys(x, y, Var(WIDTH))


@kernel()
def autosync_cube_aggressive_l0_splits_mmad_separated_bursts(x: GMTensor, y: GMTensor, n: Var):
    l1a = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1b = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1c = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1d = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l0a = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0b = DBuff(DT.half, [WIDTH, WIDTH], Position.L0B)
    l0c = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0d = DBuff(DT.half, [WIDTH, WIDTH], Position.L0B)
    acc0 = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)
    acc1 = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)
    cnt = Var(0)

    with auto_sync(mode="aggressive"):
        l1a[0:n, 0:n] <<= x[0:n, 0:n]
        l1b[0:n, 0:n] <<= x[0:n, 0:n]
        l1c[0:n, 0:n] <<= x[0:n, 0:n]
        l1d[0:n, 0:n] <<= x[0:n, 0:n]
        l0a[cnt] <<= l1a
        l0b[cnt] <<= l1b
        mmad(acc0[cnt], l0a[cnt], l0b[cnt])
        l0c[cnt] <<= l1c
        l0d[cnt] <<= l1d
        mmad(acc1[cnt], l0c[cnt], l0d[cnt])
        y[0:n, 0:n] <<= acc0[cnt][0:n, 0:n]
        y[0:n, 0:n] <<= acc1[cnt][0:n, 0:n]

    return y


def build_cube_aggressive_l0_splits_mmad_separated_bursts() -> None:
    x = GMTensor(DT.half, [WIDTH, WIDTH])
    y = GMTensor(DT.float, [WIDTH, WIDTH])
    autosync_cube_aggressive_l0_splits_mmad_separated_bursts(x, y, Var(WIDTH))


@kernel()
def autosync_cube_fix_storage_keeps_conservative_l0(x: GMTensor, y: GMTensor, n: Var):
    l1a = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1b = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1c = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1d = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l0a = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0b = DBuff(DT.half, [WIDTH, WIDTH], Position.L0B)
    l0c = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0d = DBuff(DT.half, [WIDTH, WIDTH], Position.L0B)
    acc0 = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)
    acc1 = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)
    cnt = Var(0)

    with auto_sync(mode="fix_storage"):
        l1a[0:n, 0:n] <<= x[0:n, 0:n]
        l1b[0:n, 0:n] <<= x[0:n, 0:n]
        l1c[0:n, 0:n] <<= x[0:n, 0:n]
        l1d[0:n, 0:n] <<= x[0:n, 0:n]
        l0a[cnt] <<= l1a
        l0b[cnt] <<= l1b
        l0c[cnt] <<= l1c
        l0d[cnt] <<= l1d
        mmad(acc0[cnt], l0a[cnt], l0b[cnt])
        mmad(acc1[cnt], l0c[cnt], l0d[cnt])
        y[0:n, 0:n] <<= acc0[cnt][0:n, 0:n]
        y[0:n, 0:n] <<= acc1[cnt][0:n, 0:n]

    return y


def build_cube_fix_storage_keeps_conservative_l0() -> None:
    x = GMTensor(DT.half, [WIDTH, WIDTH])
    y = GMTensor(DT.float, [WIDTH, WIDTH])
    autosync_cube_fix_storage_keeps_conservative_l0(x, y, Var(WIDTH))


@kernel()
def autosync_cube_manual_fix_skips_fix_events(x: GMTensor, y: GMTensor, n: Var):
    l1a = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l1b = Tensor(DT.half, [WIDTH, WIDTH], Position.L1)
    l0a = DBuff(DT.half, [WIDTH, WIDTH], Position.L0A)
    l0b = DBuff(DT.half, [WIDTH, WIDTH], Position.L0B)
    acc = DBuff(DT.float, [WIDTH, WIDTH], Position.L0C)
    mmad_ready = DEvent(Pipe.M, Pipe.FIX, name="mmad_ready")
    cnt = Var(0)

    with auto_sync(mode="manual_fix"):
        l1a[0:n, 0:n] <<= x[0:n, 0:n]
        l1b[0:n, 0:n] <<= x[0:n, 0:n]
        l0a[cnt] <<= l1a
        l0b[cnt] <<= l1b
        mmad(acc[cnt], l0a[cnt], l0b[cnt])
        mmad_ready.set()
        mmad_ready.wait()
        y[0:n, 0:n] <<= acc[cnt][0:n, 0:n]

    return y


def build_cube_manual_fix_skips_fix_events() -> None:
    x = GMTensor(DT.half, [WIDTH, WIDTH])
    y = GMTensor(DT.float, [WIDTH, WIDTH])
    autosync_cube_manual_fix_skips_fix_events(x, y, Var(WIDTH))
