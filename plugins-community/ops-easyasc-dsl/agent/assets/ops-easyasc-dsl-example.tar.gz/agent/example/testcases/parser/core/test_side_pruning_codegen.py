import contextlib
import importlib.util
import io
import pathlib
import re

import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.a2 import reset_mask, set_mask
from easyasc.parser.asc import translate_split


MIX_WIDTH = 64
ROOT_TEST_PATH = pathlib.Path(__file__).resolve().parent / "side_pruning_root_case.py"
_BARRIER_ONLY_LOOP_RE = re.compile(r"for\s*\([^)]*\)\s*\{\s*(?:PipeBarrier<[^>]+>\(\);\s*)+\}", re.S)


def _translate_silently(instructions, name):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        return translate_split(instructions, name)


@vf()
def add_one_row_vf(src: Tensor, dst: Tensor):
    reg = Reg(DT.float)
    reg <<= src[0:1, 0:MIX_WIDTH]
    reg <<= reg + 1.0
    dst[0:1, 0:MIX_WIDTH] <<= reg


@kernel()
def mixed_cube_vec_dead_l0_views(x: GMTensor, y: GMTensor, z: GMTensor):
    l1a = DBuff(DT.half, [1, MIX_WIDTH], Position.L1)
    l1b = DBuff(DT.half, [MIX_WIDTH, MIX_WIDTH], Position.L1)
    l0c = DBuff(DT.float, [16, MIX_WIDTH], Position.L0C)
    ub_in = DBuff(DT.float, [1, MIX_WIDTH], Position.UB)
    ub_out = DBuff(DT.float, [1, MIX_WIDTH], Position.UB)
    cnt = Var(0)

    l1a[cnt][0:1, 0:MIX_WIDTH] <<= x[0:1, 0:MIX_WIDTH]
    l1b[cnt][0:MIX_WIDTH, 0:MIX_WIDTH] <<= y[0:MIX_WIDTH, 0:MIX_WIDTH]
    matmul(l0c[cnt], l1a[cnt], l1b[cnt], splitn=32, m=1, n=MIX_WIDTH, k=MIX_WIDTH, is_init=True)
    ub_in[cnt] <<= l0c[cnt]
    add_one_row_vf(ub_in[cnt], ub_out[cnt])
    z[0:1, 0:MIX_WIDTH] <<= ub_out[cnt][0:1, 0:MIX_WIDTH]

    return z


def _build_mixed_cube_vec_dead_l0_views():
    x = GMTensor(DT.half, [1, MIX_WIDTH])
    y = GMTensor(DT.half, [MIX_WIDTH, MIX_WIDTH])
    z = GMTensor(DT.float, [1, MIX_WIDTH])
    mixed_cube_vec_dead_l0_views(x, y, z)


def _load_root_test_module():
    return _load_module(ROOT_TEST_PATH, "easyasc_root_test_module")


def _load_module(path: pathlib.Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load module from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@kernel()
def vec_loop_barrier_only_for_cube(x: GMTensor):
    buf = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    for i in range(2):
        buf <<= buf + 1.0
        bar_v()
    return x


@kernel()
def vec_if_barrier_only_for_cube(x: GMTensor, flag: Var):
    buf = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    with If(flag > 0):
        buf <<= buf + 1.0
        bar_v()
    with Elif(flag < 0):
        buf <<= buf + 2.0
        bar_v()
    with Else():
        buf <<= buf + 3.0
        bar_v()
    return x


@kernel()
def cube_barrier_routes_only_to_cube(x: GMTensor):
    bar_m()
    return x


@kernel()
def cube_conditional_barrier_routes_only_to_cube(x: GMTensor, flag: Var):
    with If(flag > 0):
        bar_m()
    return x


@kernel()
def vec_var_assign_dependency_kernel(x: GMTensor):
    buf = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    alpha = Var(2.0)
    beta = Var(0.0)
    beta <<= alpha
    buf <<= buf + beta
    return x


@kernel()
def vec_tensor_div_var_kernel(x: GMTensor, y: GMTensor, scale: Var):
    src = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    dst = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    src <<= x[0:1, 0:MIX_WIDTH]
    dst <<= src / scale
    y[0:1, 0:MIX_WIDTH] <<= dst
    return y


@kernel()
def vec_loop_control_dependency_kernel(x: GMTensor):
    buf = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    mask = Var(0, DT.uint64)
    for i in range(4):
        mask <<= mask * 2 + 1
    set_mask(0, mask)
    buf <<= buf + 1.0
    reset_mask()
    return x


@kernel()
def vec_if_control_dependency_kernel(x: GMTensor):
    buf = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    flag = Var(1)
    alpha = Var(2.0)
    beta = Var(0.0)
    with If(flag > 0):
        beta <<= alpha
    buf <<= buf + beta
    return x


@kernel()
def vec_constant_mask_codegen_kernel(x: GMTensor):
    buf = Tensor(DT.half, [1, MIX_WIDTH], Position.UB)
    buf <<= x[0:1, 0:MIX_WIDTH]
    set_mask(0, -(1 << 64))
    buf <<= buf
    reset_mask()
    set_mask(0, -(1 << 63))
    buf <<= buf
    reset_mask()
    return x


def test_translate_split_prunes_dead_l0_views_from_vec_codegen() -> None:
    _build_mixed_cube_vec_dead_l0_views()
    _, vec_code = _translate_silently(
        mixed_cube_vec_dead_l0_views.instructions,
        "mixed_cube_vec_dead_l0_views_codegen",
    )

    assert "DBuff<half, TPosition::A1> l1a" in vec_code
    assert "DBuff<half, TPosition::A1> l1b" in vec_code
    assert "_l0acnt" not in vec_code
    assert "_l0bcnt" not in vec_code
    assert "_l0a" not in vec_code
    assert "_l0b" not in vec_code
    assert "ReinterpretCast<" not in vec_code


def test_translate_split_emits_mask_literals_as_uint64_words() -> None:
    saved_device_type = globvars.device_type
    try:
        globvars.device_type = "b3"
        x = GMTensor(DT.half, [1, MIX_WIDTH], name="x")
        vec_constant_mask_codegen_kernel(x)
        _, vec_code = _translate_silently(
            vec_constant_mask_codegen_kernel.instructions,
            "vec_constant_mask_codegen_kernel",
        )
    finally:
        globvars.device_type = saved_device_type

    assert "SetVectorMask<half, MaskMode::NORMAL>(0x0000000000000000ULL, 0x0000000000000000ULL);" in vec_code
    assert "SetVectorMask<half, MaskMode::NORMAL>(0x0000000000000000ULL, 0x8000000000000000ULL);" in vec_code
    assert "-18446744073709551616" not in vec_code
    assert "-9223372036854775808" not in vec_code


def test_root_test_cube_codegen_preserves_unused_ub_decls_only() -> None:
    root_test = _load_root_test_module()
    x = GMTensor(DT.half, [512, 128])
    y = GMTensor(DT.half, [256, 128])
    z = GMTensor(DT.float, [512, 256])
    root_test.cubefunc(x, y, z, Var(512), Var(256), Var(128))

    cube_code, _ = _translate_silently(
        root_test.cubefunc.instructions,
        "root_test_side_prune_codegen",
    )

    assert "DBuff<float, TPosition::VECCALC> xbuf" in cube_code
    assert "DBuff<float, TPosition::VECCALC> outbuf" in cube_code
    assert "int cnt =" in cube_code
    assert "int m_per_core =" in cube_code
    assert "_l0a" in cube_code
    assert "_l0b" in cube_code
    assert "GlobalTensor<half> x;" in cube_code
    assert "GlobalTensor<float> z;" not in cube_code


@pytest.mark.easyasc_device("b3")
def test_translate_split_prunes_barrier_only_loop_from_cube_codegen() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH])
    vec_loop_barrier_only_for_cube(x)

    cube_code, _ = _translate_silently(
        vec_loop_barrier_only_for_cube.instructions,
        "vec_loop_barrier_only_for_cube_codegen",
    )

    assert "for (" not in cube_code
    assert "PipeBarrier<" not in cube_code


@pytest.mark.easyasc_device("b3")
def test_translate_split_prunes_barrier_only_if_chain_from_cube_codegen() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH])
    vec_if_barrier_only_for_cube(x, Var(1))

    cube_code, _ = _translate_silently(
        vec_if_barrier_only_for_cube.instructions,
        "vec_if_barrier_only_for_cube_codegen",
    )

    assert "if (" not in cube_code
    assert "} else" not in cube_code
    assert "PipeBarrier<" not in cube_code


@pytest.mark.easyasc_device("b3")
def test_translate_split_routes_cube_barrier_only_to_cube_codegen() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH])
    cube_barrier_routes_only_to_cube(x)

    cube_code, vec_code = _translate_silently(
        cube_barrier_routes_only_to_cube.instructions,
        "cube_barrier_routes_only_to_cube_codegen",
    )

    assert "PipeBarrier<PIPE_M>();" in cube_code
    assert "PipeBarrier<PIPE_M>();" not in vec_code


@pytest.mark.easyasc_device("b3")
def test_translate_split_keeps_conditional_cube_barrier_codegen() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH])
    cube_conditional_barrier_routes_only_to_cube(x, Var(1, name="flag"))

    cube_code, vec_code = _translate_silently(
        cube_conditional_barrier_routes_only_to_cube.instructions,
        "cube_conditional_barrier_codegen",
    )

    assert "if (flag > 0)" in cube_code
    assert "PipeBarrier<PIPE_M>();" in cube_code
    assert "PipeBarrier<PIPE_M>();" not in vec_code


@pytest.mark.easyasc_device("b3")
def test_translate_split_keeps_live_var_assign_dependencies_on_vec_side() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH])
    vec_var_assign_dependency_kernel(x)

    cube_code, vec_code = _translate_silently(
        vec_var_assign_dependency_kernel.instructions,
        "vec_var_assign_dependency_codegen",
    )

    assert "alpha" not in cube_code
    assert "beta" not in cube_code
    assert "float alpha" in vec_code
    assert "float beta" in vec_code


@pytest.mark.easyasc_device("b3")
def test_translate_split_keeps_live_loop_control_dependencies_on_vec_side() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH])
    vec_loop_control_dependency_kernel(x)

    cube_code, vec_code = _translate_silently(
        vec_loop_control_dependency_kernel.instructions,
        "vec_loop_control_dependency_codegen",
    )

    assert "mask" not in cube_code
    assert "int i = 0;" in vec_code
    assert "uint64_t mask = 0;" in vec_code
    assert "for (int i = 0; i < 4; i += 1)" in vec_code
    assert "SetVectorMask<half, MaskMode::NORMAL>(0x0000000000000000ULL, mask);" in vec_code


@pytest.mark.easyasc_device("b3")
def test_translate_split_keeps_live_if_control_dependencies_on_vec_side() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH])
    vec_if_control_dependency_kernel(x)

    cube_code, vec_code = _translate_silently(
        vec_if_control_dependency_kernel.instructions,
        "vec_if_control_dependency_codegen",
    )

    assert "flag" not in cube_code
    assert "int flag = 1;" in vec_code
    assert "if (flag > 0)" in vec_code
    assert "float alpha" in vec_code
    assert "float beta" in vec_code


@pytest.mark.easyasc_device("b3")
def test_tensor_div_var_lowers_to_muls_reciprocal_on_vec_side() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH])
    y = GMTensor(DT.float, [1, MIX_WIDTH])
    vec_tensor_div_var_kernel(x, y, Var(2.0))

    opnames = [inst.opname for inst in vec_tensor_div_var_kernel.instructions]
    assert "muls" in opnames
    assert "var_div" in opnames
    assert "div" not in opnames

    cube_code, vec_code = _translate_silently(
        vec_tensor_div_var_kernel.instructions,
        "vec_tensor_div_var_codegen",
    )

    assert "Div<" not in cube_code
    assert "Div<" not in vec_code
    assert "Muls<" in vec_code
