import pytest

from easyasc import globvars
from easyasc.utils.Tensor import Tensor
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.positions import Position
from easyasc.stub_functions.vec.binary import mul
from easyasc.stub_functions.vec.sort import sort32


def _ub(dtype=DT.float):
    return Tensor(dtype, [1, 32], Position.UB)


def test_a2_vec_stub_accepts_declared_b_devices() -> None:
    saved_device_type = globvars.device_type
    try:
        for device_type in ("b1", "b2", "b3", "b4", "a3"):
            globvars.device_type = device_type
            mul(_ub(), _ub(), _ub(), repeat=1)
    finally:
        globvars.device_type = saved_device_type


def test_a2_vec_stub_rejects_a5_device() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        with pytest.raises(ValueError, match="valid device_type values: \\['b1', 'b2', 'b3', 'b4', 'a3'\\]"):
            mul(_ub(), _ub(), _ub(), repeat=1)
    finally:
        globvars.device_type = saved_device_type


def test_sort_stub_accepts_a2_and_a5_devices() -> None:
    saved_device_type = globvars.device_type
    try:
        for device_type in ("b3", "950", "950pr"):
            globvars.device_type = device_type
            sort32(_ub(), _ub(), _ub(DT.uint32), repeat=1)
    finally:
        globvars.device_type = saved_device_type


def test_a5_facade_exposes_sort_stub() -> None:
    saved_device_type = globvars.device_type
    try:
        import easyasc.a5 as a5

        globvars.device_type = "950"
        a5.sort32(_ub(), _ub(), _ub(DT.uint32), repeat=1)
    finally:
        globvars.device_type = saved_device_type


def test_a5pr_facade_exposes_sort_stub() -> None:
    saved_device_type = globvars.device_type
    try:
        import easyasc.a5pr as a5pr

        globvars.device_type = "950pr"
        a5pr.sort32(_ub(), _ub(), _ub(DT.uint32), repeat=1)
    finally:
        globvars.device_type = saved_device_type
