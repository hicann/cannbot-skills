import pytest

from easyasc.a5 import DT, Position, Reg, Tensor, vf
from easyasc.flowcontrol import range as asc_range
from easyasc.parser.asc import translate
from easyasc.utils.instruction import Instruction
from easyasc.utils.var import Var


MESSAGE = "Do not create Var out of kernel scope"
DANGLING_LOOP_BOUND = Var(1)


@vf()
def _dangling_bound_vf(src: Tensor) -> None:
    reg = Reg(DT.float)
    for i in asc_range(DANGLING_LOOP_BOUND):
        reg <<= src[i * 64]


@vf()
def _hidden_tensor_dim_vf(src: Tensor, rows: Var) -> None:
    reg = Reg(DT.float)
    for r in asc_range(rows):
        reg <<= src[r:r + 1, 0:64]


@vf()
def _explicit_tensor_dim_vf(src: Tensor, rows: Var, dim: Var) -> None:
    reg = Reg(DT.float)
    for r in asc_range(rows):
        reg <<= src[r:r + 1, 0:64]


@vf()
def _callsite_view_offset_vf(src: Tensor, rows: Var) -> None:
    reg = Reg(DT.float)
    for r in asc_range(rows):
        reg <<= src[r:r + 1, 0:64]


@vf()
def _hidden_tensor_span_vf(src: Tensor) -> None:
    reg = Reg(DT.float)
    reg <<= src[64]


def _loop_with_stop(stop):
    loop_var = Var(0)
    return [
        Instruction("create_var", val=loop_var),
        Instruction("start_micro_loop", var=loop_var, start=0, stop=stop, step=1),
        Instruction("end_loop", var=loop_var),
    ]


def test_translate_rejects_tmp_var_created_outside_codegen_scope() -> None:
    dangling = Var(8)

    with pytest.raises(ValueError, match=MESSAGE) as exc_info:
        translate(_loop_with_stop(dangling))
    message = str(exc_info.value)
    assert "Dangling Var(s)" in message
    assert "instruction" in message
    assert "offending operand(s)" in message


def test_translate_rejects_named_var_outside_explicit_scope() -> None:
    dangling = Var(8, name="bad_named")

    with pytest.raises(ValueError, match=MESSAGE):
        translate(_loop_with_stop(dangling), external_var_names=[])


def test_translate_allows_explicit_external_var() -> None:
    external = Var(8, name="n")

    code = translate(_loop_with_stop(external), external_var_names=["n"])

    assert "n" in code


def test_vf_codegen_rejects_module_scope_loop_bound(tmp_path) -> None:
    src = Tensor(DT.float, [1, 64], Position.UB)
    _dangling_bound_vf(src)

    with pytest.raises(ValueError, match=MESSAGE):
        _dangling_bound_vf.gen_code(str(tmp_path / "dangling_bound_vf.h"))


def test_vf_rejects_hidden_tensor_metadata_var() -> None:
    rows = Var(2, name="rows")
    dim = Var(128, name="dim")
    src = Tensor(DT.float, [rows, dim], Position.UB)

    with pytest.raises(ValueError, match="hidden Tensor-metadata Var\\(s\\): dim"):
        _hidden_tensor_dim_vf(src, rows)


def test_vf_rejects_hidden_tensor_metadata_span_var() -> None:
    dim = Var(128, name="dim")
    src = Tensor(DT.float, [8, dim], Position.UB)

    with pytest.raises(ValueError) as exc_info:
        _hidden_tensor_span_vf(src)

    message = str(exc_info.value)
    assert "vf _hidden_tensor_span_vf uses hidden Tensor-metadata Var(s): dim" in message
    assert "from slice span" in message
    assert "source=src" in message
    assert "Pass those Vars as explicit @vf Var arguments" in message


def test_vf_allows_explicit_tensor_metadata_var(tmp_path) -> None:
    rows = Var(2, name="rows")
    dim = Var(128, name="dim")
    src = Tensor(DT.float, [rows, dim], Position.UB)

    _explicit_tensor_dim_vf(src, rows, dim)
    out_path = tmp_path / "explicit_tensor_dim_vf.h"
    _explicit_tensor_dim_vf.gen_code(str(out_path))

    assert "const int &dim" in out_path.read_text()


def test_vf_treats_callsite_tensor_view_offset_as_new_base(tmp_path) -> None:
    rows = Var(2, name="rows")
    row_begin = Var(1, name="row_begin")
    src = Tensor(DT.float, [8, 64], Position.UB)
    view = src[row_begin:row_begin + rows, 0:64]

    _callsite_view_offset_vf(view, rows)
    out_path = tmp_path / "callsite_view_offset_vf.h"
    _callsite_view_offset_vf.gen_code(str(out_path))

    text = out_path.read_text()
    assert "const int &rows" in text
    assert "row_begin" not in text
