from __future__ import annotations

import builtins
import torch

from easyasc.a5 import *


def _nd_dma_reference(
    src: torch.Tensor,
    out_shape,
    loop_src_stride,
    loop_dst_stride,
    loop_size,
    loop_left_pad,
    loop_right_pad,
    *,
    constant_value: float,
    nearest_value_mode: bool,
) -> torch.Tensor:
    dst = torch.zeros(out_shape, dtype=src.dtype)
    src_flat = src.reshape(-1)
    dst_flat = dst.reshape(-1)
    total_inner = loop_size[0] + loop_left_pad[0] + loop_right_pad[0]
    total_outer = loop_size[1] + loop_left_pad[1] + loop_right_pad[1]
    for outer in builtins.range(total_outer):
        for inner in builtins.range(total_inner):
            dst_offset = inner * loop_dst_stride[0] + outer * loop_dst_stride[1]
            src_inner = inner - loop_left_pad[0]
            src_outer = outer - loop_left_pad[1]
            if nearest_value_mode:
                src_inner = min(max(src_inner, 0), loop_size[0] - 1)
                src_outer = min(max(src_outer, 0), loop_size[1] - 1)
                src_offset = src_inner * loop_src_stride[0] + src_outer * loop_src_stride[1]
                dst_flat[dst_offset] = src_flat[src_offset]
            elif 0 <= src_inner < loop_size[0] and 0 <= src_outer < loop_size[1]:
                src_offset = src_inner * loop_src_stride[0] + src_outer * loop_src_stride[1]
                dst_flat[dst_offset] = src_flat[src_offset]
            else:
                dst_flat[dst_offset] = constant_value
    return dst


@kernel()
def _gm_to_ub_nd_dma_padding_kernel(x: GMTensor, y: GMTensor, dummy: Var):
    ub = Tensor(DT.float, [4, 16], Position.UB)
    with auto_sync():
        gm_to_ub_nd_dma(
            ub,
            x,
            loop_src_stride=[1, 8],
            loop_dst_stride=[1, 16],
            loop_size=[8, 2],
            loop_left_pad=[3, 1],
            loop_right_pad=[5, 1],
            constant_value=0.0,
        )
        ub_to_gm_pad(y, ub, 4, 16, 0, 0)
    return y


@kernel()
def _gm_transpose_to_ub_kernel(x: GMTensor, y: GMTensor, dummy: Var):
    ub = Tensor(DT.float, [8, 8], Position.UB)
    with auto_sync():
        ub <<= x.T
        y[0:8, 0:4] <<= ub[0:8, 0:4]
    return y


@kernel()
def _gm_transpose_slice_to_ub_kernel(x: GMTensor, y: GMTensor, dummy: Var):
    ub = Tensor(DT.float, [8, 8], Position.UB)
    with auto_sync():
        ub[1:5, 0:3] <<= x[0:3, 0:4].T
        y[1:5, 0:3] <<= ub[1:5, 0:3]
    return y


@kernel()
def _gm_to_ub_nd_dma_nearest_kernel(x: GMTensor, y: GMTensor, dummy: Var):
    ub = Tensor(DT.float, [4, 8], Position.UB)
    with auto_sync():
        gm_to_ub_nd_dma(
            ub,
            x,
            loop_src_stride=[1, 3],
            loop_dst_stride=[1, 8],
            loop_size=[3, 2],
            loop_left_pad=[2, 1],
            loop_right_pad=[3, 1],
            constant_value=0.0,
            nearest_value_mode=True,
        )
        ub_to_gm_pad(y, ub, 4, 8, 0, 0)
    return y


@kernel()
def _gm_to_ub_nd_dma_dynamic_kernel(
    x: GMTensor, y: GMTensor, row_width: Var, row_count: Var,
):
    ub = Tensor(DT.float, [4, 16], Position.UB)
    with auto_sync():
        gm_to_ub_nd_dma(
            ub,
            x,
            loop_src_stride=[1, row_width],
            loop_dst_stride=[1, 16],
            loop_size=[row_width, row_count],
            loop_left_pad=[3, 1],
            loop_right_pad=[5, 1],
            constant_value=0.0,
        )
        ub_to_gm_pad(y, ub, 4, 16, 0, 0)
    return y


def test_gm_to_ub_nd_dma_padding_matches_official_2d_example() -> None:
    x = torch.arange(1, 17, dtype=torch.float32).reshape(2, 8)
    y = torch.zeros((4, 16), dtype=torch.float32)
    got = OpExec(_gm_to_ub_nd_dma_padding_kernel, simulator=True)(x, y, 0)
    expected = _nd_dma_reference(
        x,
        (4, 16),
        loop_src_stride=(1, 8),
        loop_dst_stride=(1, 16),
        loop_size=(8, 2),
        loop_left_pad=(3, 1),
        loop_right_pad=(5, 1),
        constant_value=0.0,
        nearest_value_mode=False,
    )
    torch.testing.assert_close(got, expected)


def test_gm_to_ub_nd_dma_nearest_padding_replicates_border_values() -> None:
    x = torch.tensor([[1.0, 2.0, 3.0], [10.0, 20.0, 30.0]], dtype=torch.float32)
    y = torch.zeros((4, 8), dtype=torch.float32)
    got = OpExec(_gm_to_ub_nd_dma_nearest_kernel, simulator=True)(x, y, 0)
    expected = _nd_dma_reference(
        x,
        (4, 8),
        loop_src_stride=(1, 3),
        loop_dst_stride=(1, 8),
        loop_size=(3, 2),
        loop_left_pad=(2, 1),
        loop_right_pad=(3, 1),
        constant_value=0.0,
        nearest_value_mode=True,
    )
    torch.testing.assert_close(got, expected)


def test_gm_to_ub_nd_dma_resolves_dynamic_sequence_members() -> None:
    x = torch.arange(1, 17, dtype=torch.float32).reshape(2, 8)
    y = torch.zeros((4, 16), dtype=torch.float32)
    got = OpExec(_gm_to_ub_nd_dma_dynamic_kernel, simulator=True)(x, y, 8, 2)
    expected = _nd_dma_reference(
        x,
        (4, 16),
        loop_src_stride=(1, 8),
        loop_dst_stride=(1, 16),
        loop_size=(8, 2),
        loop_left_pad=(3, 1),
        loop_right_pad=(5, 1),
        constant_value=0.0,
        nearest_value_mode=False,
    )
    torch.testing.assert_close(got, expected)


def test_gm_transpose_to_ub_sugar_matches_plain_transpose() -> None:
    x = torch.arange(1, 33, dtype=torch.float32).reshape(4, 8)
    y = torch.zeros((8, 4), dtype=torch.float32)
    got = OpExec(_gm_transpose_to_ub_kernel, simulator=True)(x, y, 0)
    torch.testing.assert_close(got, x.t().contiguous())


def test_gm_transpose_slice_to_ub_sugar_respects_source_slice_and_dst_offset() -> None:
    x = torch.arange(1, 33, dtype=torch.float32).reshape(4, 8)
    y = torch.zeros((8, 8), dtype=torch.float32)
    got = OpExec(_gm_transpose_slice_to_ub_kernel, simulator=True)(x, y, 0)
    expected = torch.zeros((8, 8), dtype=torch.float32)
    expected[1:5, 0:3] = x[0:3, 0:4].t().contiguous()
    torch.testing.assert_close(got[1:5, 0:3], expected[1:5, 0:3])
