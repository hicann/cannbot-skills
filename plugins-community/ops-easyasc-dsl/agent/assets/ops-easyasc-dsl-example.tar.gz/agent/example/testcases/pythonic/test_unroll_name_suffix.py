import builtins

from easyasc.pythonic import transform_kernel


def Reg(*args, name=""):
    return name


def unroll(*args):
    return builtins.range(*args)


class Source:
    def reinterpret(self, dtype, name=""):
        return name


src = Source()


def _tuple_unroll_names():
    names = []
    for offset in (1, 2, 4):
        item = Reg()
        names.append(item)
    return names


def _attribute_call_unroll_names():
    names = []
    for offset in (1, 2):
        item = src.reinterpret("u32")
        names.append(item)
    return names


def _nested_unroll_names():
    names = []
    for outer in (1, 2):
        for inner in unroll(3, 5):
            item = Reg()
            names.append(item)
    return names


def _explicit_name_is_preserved():
    names = []
    for offset in (1, 2):
        item = Reg(name="manual")
        names.append(item)
    return names


def test_static_tuple_unroll_suffixes_auto_names():
    transformed = transform_kernel(_tuple_unroll_names)

    assert transformed() == ["item_1", "item_2", "item_4"]


def test_static_unroll_suffixes_attribute_call_auto_names():
    transformed = transform_kernel(_attribute_call_unroll_names)

    assert transformed() == ["item_1", "item_2"]


def test_nested_static_unroll_suffixes_auto_names():
    transformed = transform_kernel(_nested_unroll_names)

    assert transformed() == [
        "item_1_3",
        "item_1_4",
        "item_2_3",
        "item_2_4",
    ]


def test_explicit_name_is_preserved_inside_static_unroll():
    transformed = transform_kernel(_explicit_name_is_preserved)

    assert transformed() == ["manual", "manual"]
