import torch
import pytest

from easyasc.a5 import *


@kernel()
def _valid_signature_kernel(inp: GMTensor, out: GMTensor, m: Var):
    return out


@kernel()
def _var_between_tensors_kernel(inp: GMTensor, m: Var, out: GMTensor):
    return out


@kernel()
def _output_before_input_kernel(out: GMTensor, inp: GMTensor, m: Var):
    return out


@kernel()
def _misordered_output_return_kernel(inp: GMTensor, out2: GMTensor, out1: GMTensor, m: Var):
    return out1, out2


@kernel()
def _aligned_multi_output_kernel(inp: GMTensor, out1: GMTensor, out2: GMTensor, m: Var):
    return out1, out2


@kernel()
def _no_var_kernel(inp: GMTensor, out: GMTensor):
    return out


@kernel()
def _no_input_kernel(out: GMTensor, m: Var):
    return out


@kernel()
def _no_output_kernel(inp: GMTensor, m: Var):
    return None


@kernel()
def _case_insensitive_duplicate_name_kernel(h: GMTensor, out: GMTensor, H: Var):
    return out


def _patch_generate(monkeypatch: pytest.MonkeyPatch, kernel_fn) -> None:
    monkeypatch.setattr(kernel_fn, "generate", lambda *args, **kwargs: None)


def test_opexec_accepts_input_output_var_order(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _patch_generate(monkeypatch, _valid_signature_kernel)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    result = OpExec(_valid_signature_kernel, out_dir=str(tmp_path), gen_only=True)(inp, out, 1)

    assert isinstance(result, torch.Tensor)
    assert result.shape == out.shape
    assert result.dtype == out.dtype
    assert torch.count_nonzero(result).item() == 0


def test_opexec_rejects_tensor_after_var_parameter(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _patch_generate(monkeypatch, _var_between_tensors_kernel)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    with pytest.raises(ValueError, match="GMTensor parameter after Var parameters"):
        OpExec(_var_between_tensors_kernel, out_dir=str(tmp_path), gen_only=True)(inp, out, 1)


def test_opexec_rejects_input_after_output_parameter(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _patch_generate(monkeypatch, _output_before_input_kernel)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    with pytest.raises(ValueError, match="input GMTensor after output/Var parameters"):
        OpExec(_output_before_input_kernel, out_dir=str(tmp_path), gen_only=True)(inp, out, 1)


def test_opexec_rejects_output_parameter_order_mismatch(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _patch_generate(monkeypatch, _misordered_output_return_kernel)
    inp = torch.randn(1, 1).float()
    out1 = torch.zeros(1, 1).float()
    out2 = torch.zeros(1, 1).float()

    with pytest.raises(ValueError, match="Output GMTensor/GMTensorList order in function signature does not match return order"):
        OpExec(_misordered_output_return_kernel, out_dir=str(tmp_path), gen_only=True)(inp, out2, out1, 1)


def test_opexec_accepts_aligned_multi_output_order(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _patch_generate(monkeypatch, _aligned_multi_output_kernel)
    inp = torch.randn(1, 1).float()
    out1 = torch.zeros(1, 1).float()
    out2 = torch.zeros(1, 1).float()

    result = OpExec(_aligned_multi_output_kernel, out_dir=str(tmp_path), gen_only=True)(inp, out1, out2, 1)

    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], torch.Tensor)
    assert isinstance(result[1], torch.Tensor)
    assert result[0].shape == out1.shape
    assert result[1].shape == out2.shape
    assert result[0].dtype == out1.dtype
    assert result[1].dtype == out2.dtype
    assert torch.count_nonzero(result[0]).item() == 0
    assert torch.count_nonzero(result[1]).item() == 0


def test_opexec_rejects_kernel_without_var_argument(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _patch_generate(monkeypatch, _no_var_kernel)
    inp = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    with pytest.raises(ValueError, match="at least one Var argument"):
        OpExec(_no_var_kernel, out_dir=str(tmp_path), gen_only=True)(inp, out)


def test_opexec_rejects_kernel_without_input_gmtensor(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _patch_generate(monkeypatch, _no_input_kernel)
    out = torch.zeros(1, 1).float()

    with pytest.raises(ValueError, match="at least one input GMTensor"):
        OpExec(_no_input_kernel, out_dir=str(tmp_path), gen_only=True)(out, 1)


def test_opexec_rejects_kernel_without_output_gmtensor(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _patch_generate(monkeypatch, _no_output_kernel)
    inp = torch.randn(1, 1).float()

    # A kernel that has a GMTensor parameter but returns no GM tensor-like output is rejected by
    # the KernelBase output guard while the kernel is being run to collect outputs,
    # i.e. before OpExec's own "at least one output GMTensor/GMTensorList" signature check can
    # run (that check needs the collected outputs). Either way the no-output kernel
    # is rejected with a ValueError.
    with pytest.raises(ValueError, match="returned no GMTensor/GMTensorList outputs"):
        OpExec(_no_output_kernel, out_dir=str(tmp_path), gen_only=True)(inp, 1)


def test_kernel_rejects_case_insensitive_duplicate_parameter_names() -> None:
    h = GMTensor(DT.float, [1, 1], name="h_arg")
    out = GMTensor(DT.float, [1, 1], name="out_arg")

    with pytest.raises(ValueError, match=r"unique under `name\.lower\(\)`") as exc_info:
        _case_insensitive_duplicate_name_kernel(h, out, Var(1))

    message = str(exc_info.value)
    assert "`h`, `H` -> `h`" in message
    assert "Rename one of the parameters" in message


def test_opexec_rejects_case_insensitive_duplicate_parameter_names(
    monkeypatch: pytest.MonkeyPatch, tmp_path
) -> None:
    _patch_generate(monkeypatch, _case_insensitive_duplicate_name_kernel)
    h = torch.randn(1, 1).float()
    out = torch.zeros(1, 1).float()

    with pytest.raises(ValueError, match=r"unique under `name\.lower\(\)`") as exc_info:
        OpExec(_case_insensitive_duplicate_name_kernel, out_dir=str(tmp_path), gen_only=True)(h, out, 1)

    assert "`h`, `H` -> `h`" in str(exc_info.value)
