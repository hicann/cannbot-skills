import pytest

from easyasc.a5 import *


def _build_reduce_instructions(length: int, op: str):
    if length not in (4, 5):
        raise ValueError(f"Unsupported length: {length}")
    if op not in ("cadd", "cmax", "cmin"):
        raise ValueError(f"Unsupported op: {op}")

    if length == 5 and op == "cadd":
        @vf()
        def reduce_micro(dummy: Tensor):
            _ = dummy
            src = RegList(DT.float, 5, name="src")
            dst = Reg(DT.float, name="dst")
            dst <<= src.cadd()
    elif length == 5 and op == "cmax":
        @vf()
        def reduce_micro(dummy: Tensor):
            _ = dummy
            src = RegList(DT.float, 5, name="src")
            dst = Reg(DT.float, name="dst")
            dst <<= src.cmax()
    elif length == 5 and op == "cmin":
        @vf()
        def reduce_micro(dummy: Tensor):
            _ = dummy
            src = RegList(DT.float, 5, name="src")
            dst = Reg(DT.float, name="dst")
            dst <<= src.cmin()
    elif length == 4 and op == "cadd":
        @vf()
        def reduce_micro(dummy: Tensor):
            _ = dummy
            src = RegList(DT.float, 4, name="src")
            dst = Reg(DT.float, name="dst")
            dst <<= src.cadd()
    elif length == 4 and op == "cmax":
        @vf()
        def reduce_micro(dummy: Tensor):
            _ = dummy
            src = RegList(DT.float, 4, name="src")
            dst = Reg(DT.float, name="dst")
            dst <<= src.cmax()
    else:
        @vf()
        def reduce_micro(dummy: Tensor):
            _ = dummy
            src = RegList(DT.float, 4, name="src")
            dst = Reg(DT.float, name="dst")
            dst <<= src.cmin()

    dummy = Tensor(DT.float, [1, 8], Position.UB, name="dummy")
    reduce_micro(dummy)
    return list(reduce_micro.instructions)


@pytest.mark.parametrize(
    "op,pair_op,reduce_op",
    [
        ("cadd", "micro_vadd", "micro_vcadd"),
        ("cmax", "micro_vmax", "micro_vcmax"),
        ("cmin", "micro_vmin", "micro_vcmin"),
    ],
)
def test_reglist_reduce_odd_length_emits_tree_in_place(op: str, pair_op: str, reduce_op: str) -> None:
    instructions = _build_reduce_instructions(5, op)

    temp_creates = [
        inst.reg.name
        for inst in instructions
        if inst.opname == "create_reg" and inst.reg.name.startswith("_tmp_reg_")
    ]
    pair_insts = [inst for inst in instructions if inst.opname == pair_op]
    assert len(pair_insts) == 4
    root_name = pair_insts[0].dst.name
    peer_name = pair_insts[1].dst.name
    assert root_name.startswith("_tmp_reg_")
    assert peer_name.startswith("_tmp_reg_")
    assert root_name != peer_name
    assert sorted(temp_creates) == sorted([root_name, peer_name])

    assert (pair_insts[0].dst.name, pair_insts[0].src1.name, pair_insts[0].src2.name) == (
        root_name,
        "src[0]",
        "src[1]",
    )
    assert (pair_insts[1].dst.name, pair_insts[1].src1.name, pair_insts[1].src2.name) == (
        peer_name,
        "src[2]",
        "src[3]",
    )
    assert (pair_insts[2].dst.name, pair_insts[2].src1.name, pair_insts[2].src2.name) == (
        root_name,
        root_name,
        peer_name,
    )
    assert (pair_insts[3].dst.name, pair_insts[3].src1.name, pair_insts[3].src2.name) == (
        root_name,
        root_name,
        "src[4]",
    )

    reduce_insts = [inst for inst in instructions if inst.opname == reduce_op]
    assert len(reduce_insts) == 1
    assert reduce_insts[0].dst.name == "dst"
    assert reduce_insts[0].src.name == root_name


def test_reglist_reduce_even_length_stays_tree_shaped() -> None:
    instructions = _build_reduce_instructions(4, "cadd")

    pair_insts = [inst for inst in instructions if inst.opname == "micro_vadd"]
    assert len(pair_insts) == 3
    root_name = pair_insts[0].dst.name
    peer_name = pair_insts[1].dst.name
    assert root_name.startswith("_tmp_reg_")
    assert peer_name.startswith("_tmp_reg_")
    assert root_name != peer_name
    assert (pair_insts[0].dst.name, pair_insts[0].src1.name, pair_insts[0].src2.name) == (
        root_name,
        "src[0]",
        "src[1]",
    )
    assert (pair_insts[1].dst.name, pair_insts[1].src1.name, pair_insts[1].src2.name) == (
        peer_name,
        "src[2]",
        "src[3]",
    )
    assert (pair_insts[2].dst.name, pair_insts[2].src1.name, pair_insts[2].src2.name) == (
        root_name,
        root_name,
        peer_name,
    )

    reduce_insts = [inst for inst in instructions if inst.opname == "micro_vcadd"]
    assert len(reduce_insts) == 1
    assert reduce_insts[0].src.name == root_name
