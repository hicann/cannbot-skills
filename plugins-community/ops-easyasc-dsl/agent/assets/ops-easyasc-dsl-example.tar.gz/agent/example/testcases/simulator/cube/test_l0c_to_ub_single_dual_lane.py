import pytest
import torch

from easyasc.a5 import *  # noqa: F401,F403


M = 128
N = 128
K = 128
SENTINEL = 7.0


def _make_l0c_to_ub_single_named_ub_kernel():
    @kernel()
    def l0c_to_ub_single_named_ub_kernel(
        x: GMTensor,
        y: GMTensor,
        sentinel: GMTensor,
        out0: GMTensor,
        out1: GMTensor,
        target_subblock: Var,
    ):
        cvmutex = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

        l1_x = Tensor(DT.half, [M, K], Position.L1)
        l1_y = Tensor(DT.half, [N, K], Position.L1)
        l0c = Tensor(DT.float, [M, N], Position.L0C)
        ub_out = Tensor(DT.float, [M, N], Position.UB)
        sentinel_ub = Tensor(DT.float, [M, N], Position.UB)

        with auto_sync():
            l1_x <<= x[0:M, 0:K]
            l1_y <<= y[0:N, 0:K]
            matmul(l0c, l1_x, l1_y, m=M, n=N, k=K, splitn=N)

            cvmutex.lock()
            l0c_to_ub(ub_out, l0c, M=M, N=N, N_dst=N, M_src=M, dual_mode=0, sub_block_id=target_subblock)
            cvmutex.ready()

            cvmutex.wait()
            if GetSubBlockIdx() == 0:
                if target_subblock == 0:
                    out0[0:M, 0:N] <<= ub_out[0:M, 0:N]
                if target_subblock == 1:
                    sentinel_ub[0:M, 0:N] <<= sentinel[0:M, 0:N]
                    out0[0:M, 0:N] <<= sentinel_ub[0:M, 0:N]
            if GetSubBlockIdx() == 1:
                if target_subblock == 0:
                    sentinel_ub[0:M, 0:N] <<= sentinel[0:M, 0:N]
                    out1[0:M, 0:N] <<= sentinel_ub[0:M, 0:N]
                if target_subblock == 1:
                    out1[0:M, 0:N] <<= ub_out[0:M, 0:N]
            cvmutex.free()

        return out0, out1

    return l0c_to_ub_single_named_ub_kernel


@pytest.mark.parametrize("target_subblock", [0, 1])
def test_l0c_to_ub_single_mode_selects_destination_subblock(target_subblock):
    torch.manual_seed(0)
    x = torch.randn(M, K, dtype=torch.float16)
    y = torch.randn(N, K, dtype=torch.float16)
    sentinel = torch.full((M, N), SENTINEL, dtype=torch.float32)
    out0 = torch.empty(M, N, dtype=torch.float32)
    out1 = torch.empty(M, N, dtype=torch.float32)

    actual0, actual1 = OpExec(_make_l0c_to_ub_single_named_ub_kernel(), simulator=True)(
        x,
        y,
        sentinel,
        out0,
        out1,
        target_subblock,
    )
    expected = x.float() @ y.float().t()

    if target_subblock == 0:
        torch.testing.assert_close(actual0, expected, rtol=1e-3, atol=1e-3)
        torch.testing.assert_close(actual1, sentinel, rtol=0.0, atol=0.0)
    else:
        torch.testing.assert_close(actual0, sentinel, rtol=0.0, atol=0.0)
        torch.testing.assert_close(actual1, expected, rtol=1e-3, atol=1e-3)
