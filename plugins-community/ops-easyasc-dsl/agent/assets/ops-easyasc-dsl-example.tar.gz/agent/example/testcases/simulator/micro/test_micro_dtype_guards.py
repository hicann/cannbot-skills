from contextlib import contextmanager
from types import SimpleNamespace

import pytest
import torch

from easyasc import globvars
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.stub_functions.micro.arange import arange as micro_arange
from easyasc.stub_functions.micro.cast import cast as micro_cast
from easyasc.stub_functions.micro.datamove import gather, reg_to_ub_scatter, ub_to_reg_gather
from easyasc.utils.castconfig import CastConfig, RegLayout
from easyasc.utils.Tensor import Tensor
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.instruction import Instruction
from easyasc.utils.mask import MaskType
from easyasc.utils.positions import Position
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.roundmode import RoundMode


class _FakeMicro(object):
    def __init__(self) -> None:
        self.instructions = []
        self.tmp_idx = 0

    def _register_reg_name(self, name: str, kind: str) -> None:
        return None

    def get_mask(self, dtype, reg_num=1):
        return MaskReg(dtype, init_mode=MaskType.ALL, name="mask", reg_num=reg_num)


@contextmanager
def _active_fake_micro(device_type="950"):
    old_micro = globvars.active_micro
    old_device = globvars.device_type
    fake = _FakeMicro()
    try:
        globvars.device_type = device_type
        globvars.active_micro = fake
        yield fake
    finally:
        globvars.active_micro = old_micro
        globvars.device_type = old_device


def test_stub_micro_arange_rejects_unsigned_destination() -> None:
    with _active_fake_micro():
        dst = Reg(DT.uint32, name="dst")
        with pytest.raises(TypeError, match="arange only supports"):
            micro_arange(dst, 0)


def test_stub_micro_cast_rejects_hybrid_for_non_hif8_destination() -> None:
    with _active_fake_micro():
        dst = Reg(DT.half, name="dst")
        src = Reg(DT.float, name="src")
        mask = MaskReg(DT.half, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=RoundMode.HYBRID, name="cfg")

        with pytest.raises(ValueError, match="float -> half cast supports round_mode"):
            micro_cast(dst, src, cfg, mask)


def test_stub_micro_cast_allows_hybrid_for_float_to_hif8() -> None:
    with _active_fake_micro() as fake:
        dst = Reg(DT.hif8, name="dst")
        src = Reg(DT.float, name="src")
        mask = MaskReg(DT.hif8, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=RoundMode.HYBRID, name="cfg")

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["config"].round_mode is RoundMode.HYBRID


def test_stub_micro_cast_allows_hybrid_for_half_to_hif8() -> None:
    with _active_fake_micro() as fake:
        dst = Reg(DT.hif8, name="dst")
        src = Reg(DT.half, name="src")
        mask = MaskReg(DT.hif8, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=RoundMode.HYBRID, name="cfg")

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["config"].round_mode is RoundMode.HYBRID


@pytest.mark.parametrize("src_dtype", [DT.float, DT.half])
def test_stub_micro_cast_rejects_non_round_hif8_encode_modes(src_dtype) -> None:
    with _active_fake_micro():
        dst = Reg(DT.hif8, name="dst")
        src = Reg(src_dtype, name="src")
        mask = MaskReg(DT.hif8, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=RoundMode.FLOOR, name="cfg")

        with pytest.raises(ValueError, match="-> hifloat8_t cast supports round_mode in CAST_HYBRID, CAST_ROUND"):
            micro_cast(dst, src, cfg, mask)


@pytest.mark.parametrize("dst_dtype", [DT.float, DT.half])
@pytest.mark.parametrize("round_mode", [RoundMode.NONE, RoundMode.FLOOR, RoundMode.HYBRID, RoundMode.ODD])
def test_stub_micro_cast_allows_any_round_mode_for_hif8_decode(dst_dtype, round_mode) -> None:
    with _active_fake_micro() as fake:
        dst = Reg(dst_dtype, name="dst")
        src = Reg(DT.hif8, name="src")
        mask = MaskReg(dst_dtype, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=round_mode, name="cfg")

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["config"].round_mode is round_mode


@pytest.mark.parametrize("dst_dtype", [DT.fp4_e2m1, DT.fp4_e1m2])
@pytest.mark.parametrize(
    "round_mode",
    [RoundMode.TO_EVEN, RoundMode.AWAY_FROM_ZERO, RoundMode.FLOOR, RoundMode.CEIL, RoundMode.TRUNC],
)
def test_stub_micro_cast_allows_bfloat16_to_fp4(dst_dtype, round_mode) -> None:
    with _active_fake_micro() as fake:
        dst = Reg(dst_dtype, name="dst")
        src = Reg(DT.bfloat16, name="src")
        mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=round_mode, reg_layout=RegLayout.ZERO, name="cfg")

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["config"].round_mode is round_mode


def test_stub_micro_cast_rejects_fp4_layout_unknown() -> None:
    with _active_fake_micro():
        dst = Reg(DT.fp4_e1m2, name="dst")
        src = Reg(DT.bfloat16, name="src")
        mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=RoundMode.TO_EVEN, reg_layout=RegLayout.UNKNOWN, name="cfg")

        with pytest.raises(ValueError, match="requires RegLayout.ZERO/ONE/TWO/THREE"):
            micro_cast(dst, src, cfg, mask)


@pytest.mark.parametrize("src_dtype", [DT.fp4_e2m1, DT.fp4_e1m2])
def test_stub_micro_cast_allows_fp4_to_bfloat16(src_dtype) -> None:
    with _active_fake_micro() as fake:
        dst = Reg(DT.bfloat16, name="dst")
        src = Reg(src_dtype, name="src")
        mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=RoundMode.NONE, reg_layout=RegLayout.ZERO, name="cfg")

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["dsrc"] is src_dtype


_C310_BROKEN_ONE_WIDENING_CASES = (
    (DT.int8, DT.half, RoundMode.NONE),
    (DT.half, DT.float, RoundMode.NONE),
    (DT.bfloat16, DT.float, RoundMode.NONE),
    (DT.float, DT.int64, RoundMode.TO_EVEN),
)


@pytest.mark.parametrize("device_type", ["950", "950pr"])
@pytest.mark.parametrize("src_dtype,dst_dtype,round_mode", _C310_BROKEN_ONE_WIDENING_CASES)
def test_stub_micro_cast_rejects_c310_broken_one_widening(
    device_type, src_dtype, dst_dtype, round_mode,
) -> None:
    old_device = globvars.device_type
    with _active_fake_micro(device_type):
        dst = Reg(dst_dtype, name="dst")
        src = Reg(src_dtype, name="src")
        mask = MaskReg(dst_dtype, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=round_mode, reg_layout=RegLayout.ONE, name="cfg")

        with pytest.raises(ValueError, match="RegLayout.ONE widening is hardware-broken"):
            micro_cast(dst, src, cfg, mask)

    assert globvars.device_type == old_device


@pytest.mark.parametrize(
    "device_order",
    [("950", "950pr"), ("950pr", "950")],
)
def test_c310_one_widening_guard_restores_target_across_call_order(device_order) -> None:
    old_device = globvars.device_type
    for device_type in device_order:
        with _active_fake_micro(device_type):
            dst = Reg(DT.float, name="dst")
            src = Reg(DT.half, name="src")
            cfg = CastConfig(
                round_mode=RoundMode.NONE,
                reg_layout=RegLayout.ONE,
                name="cfg",
            )
            with pytest.raises(ValueError, match="RegLayout.ONE widening is hardware-broken"):
                micro_cast(dst, src, cfg)
        assert globvars.device_type == old_device


@pytest.mark.parametrize("device_type", ["950", "950pr"])
@pytest.mark.parametrize("src_dtype,dst_dtype,round_mode", _C310_BROKEN_ONE_WIDENING_CASES)
def test_stub_micro_cast_allows_zero_for_c310_one_broken_pairs(
    device_type, src_dtype, dst_dtype, round_mode,
) -> None:
    with _active_fake_micro(device_type) as fake:
        dst = Reg(dst_dtype, name="dst")
        src = Reg(src_dtype, name="src")
        mask = MaskReg(dst_dtype, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=round_mode, reg_layout=RegLayout.ZERO, name="cfg")

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["config"].reg_layout is RegLayout.ZERO


@pytest.mark.parametrize(
    "src_dtype,dst_dtype,round_mode",
    [
        (DT.float, DT.float, RoundMode.TO_EVEN),
        (DT.float, DT.half, RoundMode.TO_EVEN),
        (DT.uint8, DT.half, RoundMode.NONE),
        (DT.int, DT.int64, RoundMode.NONE),
    ],
)
def test_stub_micro_cast_keeps_one_for_unaffected_or_unverified_pairs(
    src_dtype, dst_dtype, round_mode,
) -> None:
    with _active_fake_micro() as fake:
        dst = Reg(dst_dtype, name="dst")
        src = Reg(src_dtype, name="src")
        mask = MaskReg(dst_dtype, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(round_mode=round_mode, reg_layout=RegLayout.ONE, name="cfg")

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["config"].reg_layout is RegLayout.ONE


@pytest.mark.parametrize("dst_dtype", [DT.fp4_e2m1, DT.fp4_e1m2])
def test_stub_micro_cast_keeps_one_for_native_bfloat16_fp4(dst_dtype) -> None:
    with _active_fake_micro() as fake:
        dst = Reg(dst_dtype, name="dst")
        src = Reg(DT.bfloat16, name="src")
        mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(
            round_mode=RoundMode.TO_EVEN,
            reg_layout=RegLayout.ONE,
            name="cfg",
        )

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["config"].reg_layout is RegLayout.ONE


@pytest.mark.parametrize("src_dtype", [DT.fp4_e2m1, DT.fp4_e1m2])
def test_stub_micro_cast_keeps_one_for_native_fp4_bfloat16(src_dtype) -> None:
    with _active_fake_micro() as fake:
        dst = Reg(DT.bfloat16, name="dst")
        src = Reg(src_dtype, name="src")
        mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask")
        cfg = CastConfig(
            round_mode=RoundMode.NONE,
            reg_layout=RegLayout.ONE,
            name="cfg",
        )

        micro_cast(dst, src, cfg, mask)

    assert fake.instructions[-1].kwargs["config"].reg_layout is RegLayout.ONE


def test_stub_datacopy_gather_rejects_bad_index_dtype() -> None:
    with _active_fake_micro():
        dst = Reg(DT.float, name="dst")
        src = Tensor(DT.float, [1, 64], Position.UB, name="src")
        index = Reg(DT.uint16, name="index")
        mask = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask")

        with pytest.raises(ValueError, match="ub_to_reg_gather index for 32-bit data must be uint32_t"):
            ub_to_reg_gather(dst, src, index, mask=mask)


def test_stub_datacopy_gather_rejects_8bit_same_width_wrapper() -> None:
    # 8-bit gather is now supported as a b8->b16 zero-extend, so an 8-bit *dst*
    # (same-width b8->b8) is the rejected case -- it needs a 16-bit destination.
    with _active_fake_micro():
        dst = Reg(DT.e4m3, name="dst")
        src = Tensor(DT.e4m3, [1, 64], Position.UB, name="src")
        index = Reg(DT.uint16, name="index")
        mask = MaskReg(DT.e4m3, init_mode=MaskType.ALL, name="mask")

        with pytest.raises(ValueError, match="8-bit src.*requires a 16-bit dst"):
            ub_to_reg_gather(dst, src, index, mask=mask)


def test_stub_datacopy_scatter_rejects_bad_8bit_index_dtype() -> None:
    with _active_fake_micro():
        dst = Tensor(DT.e4m3, [1, 64], Position.UB, name="dst")
        src = Reg(DT.e4m3, name="src")
        index = Reg(DT.uint32, name="index")
        mask = MaskReg(DT.e4m3, init_mode=MaskType.ALL, name="mask")

        with pytest.raises(ValueError, match="reg_to_ub_scatter index for 8-bit data must be uint16_t"):
            reg_to_ub_scatter(dst, src, index, mask=mask)


def test_stub_gather_rejects_bad_index_dtype() -> None:
    with _active_fake_micro():
        dst = Reg(DT.float, name="dst")
        src = Reg(DT.float, name="src")
        index = Reg(DT.uint16, name="index")

        with pytest.raises(ValueError, match="gather index for 32-bit data must be uint32_t"):
            gather(dst, src, index)


def test_simulator_micro_arange_rejects_unsigned_destination() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.uint32, name="dst")
    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=dst),
            Instruction(
                "micro_arange",
                dst=dst,
                v=0,
                dtype=DT.uint32,
                mode="MicroAPI::IndexOrder::INCREASE_ORDER",
            ),
        ]
    }

    with pytest.raises(TypeError, match="micro_arange only supports"):
        runtime.execute_call_micro(micro_def, {}, {}, SharedMemoryStore())


def test_simulator_datacopy_gather_rejects_bad_index_dtype() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.float, name="dst")
    index = Reg(DT.uint16, name="index")
    ub_src = SimpleNamespace(name="ub_src")
    ctx = MicroContext(
        regs={
            "dst": torch.zeros(64, dtype=torch.float32),
            "index": torch.zeros(128, dtype=torch.uint16),
        },
        tensor_views={"ub_src": torch.zeros(64, dtype=torch.float32)},
    )

    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="micro_datacopygather index for 32-bit data must be uint32"):
            runtime._dispatch("micro_datacopygather", {"dst": dst, "src": ub_src, "index": index}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


def test_simulator_datacopy_gather_rejects_8bit_same_width_dst() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.uint8, name="dst")
    index = Reg(DT.uint16, name="index")
    ub_src = SimpleNamespace(name="ub_src")
    ctx = MicroContext(
        regs={
            "dst": torch.zeros(256, dtype=torch.uint8),
            "index": torch.zeros(128, dtype=torch.uint16),
        },
        tensor_views={"ub_src": torch.zeros(256, dtype=torch.uint8)},
    )

    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="8-bit source requires a 16-bit destination"):
            runtime._dispatch("micro_datacopygather", {"dst": dst, "src": ub_src, "index": index}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


def test_simulator_datacopy_scatter_rejects_bad_8bit_index_dtype() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.uint8, name="src")
    index = Reg(DT.uint32, name="index")
    ub_dst = SimpleNamespace(name="ub_dst")
    ctx = MicroContext(
        regs={
            "src": torch.arange(256, dtype=torch.uint8),
            "index": torch.zeros(128, dtype=torch.uint32),
        },
        tensor_views={"ub_dst": torch.zeros(256, dtype=torch.uint8)},
    )

    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="micro_datacopyscatter index for 8-bit data must be uint16"):
            runtime._dispatch("micro_datacopyscatter", {"dst": ub_dst, "src": src, "index": index}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


def test_simulator_gather_rejects_bad_index_dtype() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.float, name="dst")
    src = Reg(DT.float, name="src")
    index = Reg(DT.uint16, name="index")
    ctx = MicroContext(
        regs={
            "dst": torch.zeros(64, dtype=torch.float32),
            "src": torch.zeros(64, dtype=torch.float32),
            "index": torch.zeros(128, dtype=torch.uint16),
        },
    )

    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="micro_gather index for 32-bit data must be uint32"):
            runtime._dispatch("micro_gather", {"dst": dst, "src": src, "index": index}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
