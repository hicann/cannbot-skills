import threading
import time

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe import PipeBase
from easyasc.simulator.program import PipeTask
from easyasc.simulator.sync import Mailbox


class _SlowPipe(PipeBase):
    def execute(self, task: PipeTask) -> None:
        time.sleep(0.05)


def test_pipe_join_timeout_keeps_live_thread_handle() -> None:
    mailbox = Mailbox()
    pipe = _SlowPipe(
        core_idx=0,
        lane_name="vec0",
        pipe_name="MTE3",
        mailbox=mailbox,
        bar_all_barrier=threading.Barrier(1),
        memory_store=SharedMemoryStore(),
    )

    pipe.start()
    mailbox.put(PipeTask(pipe_name="MTE3", opname="slow"))
    pipe.stop()
    pipe.join(timeout=0.001)

    assert pipe._thread is not None
    assert pipe._thread.is_alive()

    pipe.join(timeout=1.0)
    assert pipe._thread is None
