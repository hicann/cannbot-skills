import torch

from easyasc.a5 import *

# These kernels compute from a Var alone, but the compiler requires an input
# tensor in the kernel entry, so each takes an unread one-element `src`.
SRC = torch.zeros((1, 1), dtype=torch.int32)


@kernel()
def run_vec_align8(src: GMTensor, dst: GMTensor, n: Var):
    with vec_scope():
        aligned = Align8(n, name="aligned")
        aligned.SetValueTo(dst)
    return dst


@kernel()
def run_cube_align8(src: GMTensor, dst: GMTensor, n: Var):
    with cube_scope():
        aligned = Align8(n, name="aligned")
        aligned.SetValueTo(dst)
    return dst


@vf()
def micro_align8_fill(dst: Tensor, n: Var):
    reg = Reg(DT.float)
    aligned = Align8(n, name="aligned")
    reg <<= aligned
    dst[0:1, 0:64] <<= reg


@kernel()
def run_micro_align8(src: GMTensor, dst: GMTensor, n: Var):
    ub = Tensor(DT.float, [1, 64], Position.UB)
    with auto_sync():
        micro_align8_fill(ub, n)
        dst[0:1, 0:64] <<= ub
    return dst


def test_sim_align8_on_vec_side() -> None:
    dst = torch.zeros((1, 1), dtype=torch.int32)
    op = OpExec(run_vec_align8, "test_sim_align8_on_vec_side", simulator=True)
    out = op(SRC, dst, 13)
    assert int(out[0, 0].item()) == 16


def test_sim_align8_on_cube_side() -> None:
    dst = torch.zeros((1, 1), dtype=torch.int32)
    op = OpExec(run_cube_align8, "test_sim_align8_on_cube_side", simulator=True)
    out = op(SRC, dst, 17)
    assert int(out[0, 0].item()) == 24


def test_sim_align8_inside_micro() -> None:
    dst = torch.zeros((1, 64), dtype=torch.float32)
    op = OpExec(run_micro_align8, "test_sim_align8_inside_micro", simulator=True)
    out = op(SRC, dst, 13)
    torch.testing.assert_close(out, torch.full_like(out, 16.0))
