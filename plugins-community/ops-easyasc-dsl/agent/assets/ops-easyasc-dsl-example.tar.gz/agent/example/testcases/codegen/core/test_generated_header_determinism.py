"""Generated helper headers must not depend on set iteration order.

``used_micros`` / ``used_simts`` are sets of objects, so iterating them raw
orders the ``#include`` lines by ``id()``. That varies between processes, so two
builds of byte-identical sources emit different headers and the packaged archive
checksum moves for no reason -- which makes "did the codegen actually change?"
unanswerable by diffing.

The assertion is one-sided on purpose: sorted output always passes, so the test
can never fail spuriously. Against unsorted output it fails whenever the set
does not happen to come out in name order, which for the four micros here is
almost always.
"""
from pathlib import Path

from easyasc.a5 import *


@vf()
def zulu_header_pass(src: Tensor, dst: Tensor, chunk_count: Var):
    reg = Reg(DT.float)
    for i in range(chunk_count):
        reg <<= src[i * 64]
        dst[i * 64] <<= reg


@vf()
def mike_header_pass(src: Tensor, dst: Tensor, chunk_count: Var):
    reg = Reg(DT.float)
    for i in range(chunk_count):
        reg <<= src[i * 64]
        dst[i * 64] <<= reg + 1.0


@vf()
def alpha_header_pass(src: Tensor, dst: Tensor, chunk_count: Var):
    reg = Reg(DT.float)
    for i in range(chunk_count):
        reg <<= src[i * 64]
        dst[i * 64] <<= reg + 2.0


@vf()
def tango_header_pass(src: Tensor, dst: Tensor, chunk_count: Var):
    reg = Reg(DT.float)
    for i in range(chunk_count):
        reg <<= src[i * 64]
        dst[i * 64] <<= reg + 3.0


@kernel()
def header_include_order_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [1, 64], Position.UB, name="src_ub")
    dst = Tensor(DT.float, [1, 64], Position.UB, name="dst_ub")
    # Called in an order that is neither sorted nor reverse-sorted, so a build
    # that merely preserved call order would not pass either.
    zulu_header_pass(src, dst, Var(1))
    alpha_header_pass(src, dst, Var(1))
    tango_header_pass(src, dst, Var(1))
    mike_header_pass(src, dst, Var(1))
    return out


def _micro_includes(header: str) -> list:
    names = []
    for line in header.splitlines():
        if line.startswith('#include "') and line.endswith('_header_pass.h"'):
            names.append(line[len('#include "'):-len('.h"')])
    return names


def test_micro_includes_are_emitted_in_name_order(tmp_path: Path) -> None:
    header_include_order_kernel(
        GMTensor(DT.float, [1, 64], name="inp"), GMTensor(DT.float, [1, 64], name="out")
    )
    base = tmp_path / header_include_order_kernel.name
    header_include_order_kernel.dump_kernel(str(base))
    header = base.with_name(base.name + "_vec.h").read_text(encoding="utf-8")

    includes = _micro_includes(header)
    assert len(includes) == 4, includes
    assert includes == sorted(includes), includes
