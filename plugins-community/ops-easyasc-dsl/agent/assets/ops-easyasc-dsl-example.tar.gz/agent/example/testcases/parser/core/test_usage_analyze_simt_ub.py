from easyasc import globvars
from easyasc.parser.asc import analyze_usage
from easyasc.utils.Tensor import Tensor
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.instruction import Instruction
from easyasc.utils.positions import Position


def test_usage_analyze_reports_simt_ub_cap_and_reserved_note(capsys) -> None:
    saved_ub_cap = globvars.ub_cap
    globvars.ub_cap = 256
    try:
        ub = Tensor(DT.half, [1, 64], Position.UB, name="ub")
        analyze_usage([Instruction("create_tensor", val=ub)], "demo_vec", uses_simt=True)
    finally:
        globvars.ub_cap = saved_ub_cap

    out = capsys.readouterr().out
    assert "216 KB" in out
    assert "SIMT present: UB cap becomes 216 KB" in out
    assert "Remaining UB reserved for SIMT functionality" in out


def test_usage_analyze_detects_call_simt_without_explicit_flag(capsys) -> None:
    saved_ub_cap = globvars.ub_cap
    globvars.ub_cap = 256
    try:
        ub = Tensor(DT.half, [1, 64], Position.UB, name="ub")
        analyze_usage([
            Instruction("create_tensor", val=ub),
            Instruction("call_simt", name="noop", args=[]),
        ], "demo_vec")
    finally:
        globvars.ub_cap = saved_ub_cap

    out = capsys.readouterr().out
    assert "Usage: 0.125 KB / 216 KB" in out
