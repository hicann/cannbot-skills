from easyasc.a5 import *


BLK = 128
LANES = 4

@vf()
def simple_micro(x: Tensor, out: Tensor, n_loops: Var, N: Var):
    xreg = Reg(DT.float)
    for i in range(n_loops):
        xreg <<= x[i*64]
        xreg <<= xreg.abs() + 1.0
        out[i*64] <<= xreg


@kernel()
def cubefunc(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    mm_work = split_workspace(DT.float, [BLK, N])

    cvmutex = CvMutex(0)

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    inbuf = DBuff(DT.half, [2, K], Position.UB)
    xbuf = DBuff(DT.float, [BLK//2, N], Position.UB)
    outbuf = DBuff(DT.float, [BLK//2, N], Position.UB)

    cnt = Var(0)

    m_per_core = CeilDiv(M, GetCubeNum())
    m1 = Var(m_per_core * GetCubeIdx())
    m2 = Min(m1 + m_per_core, M)

    val = Var(0.0)
    val <<= xbuf[0][1:, 3:]
    val >>= outbuf[0][2:, 5:]

    with auto_sync():
        for m in range(m1, m2, BLK):
            l1x[cnt] <<= x[m:m+BLK, :]
            l1y[cnt] <<= y[:, :]
            matmul(l0c[cnt], l1x[cnt], l1y[cnt], splitn=True)
            matmul(l0c[cnt], l1x[cnt], l1y[cnt])
            
            cvmutex.lock()
            xbuf[cnt] <<= l0c[cnt]
            cvmutex.ready()

            inbuf[cnt] <<= x[:2, :]
            valid_m = Min(BLK, m2 - m)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = GetSubBlockIdx()
            row_begin = sb_idx * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin

            for i in range(100):
                cvmutex.wait()
                simple_micro(xbuf[cnt], outbuf[cnt], BLK//2*N//64, N)
                cvmutex.free()
                z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cvmutex.wait()
            simple_micro(xbuf[cnt], outbuf[cnt], BLK//2*N//64, N)
            cvmutex.free()
            z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cnt += 1 

    return z


if __name__ == "__main__":
    import torch 

    out_dir = "test_cust_op"

    M = 64*64 
    N = 64
    K = 128 
    x = torch.ones(M, K).half()
    y = torch.ones(N, K).half()
    z = x.float() @ y.float().t()
    z = torch.abs(z) + 1.0 

    op = OpExec(cubefunc, out_dir, simulator=False, gen_only=True, debug=True)
    z_kernel = op(x, y, z, M, N, K)
