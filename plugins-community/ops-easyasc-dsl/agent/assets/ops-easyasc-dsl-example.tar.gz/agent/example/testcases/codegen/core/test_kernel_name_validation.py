import pytest

from easyasc.decorators import auto_sync, kernel


def test_kernel_rejects_uppercase_function_name() -> None:
    with pytest.raises(ValueError, match="kernel function name must not contain uppercase letters.*BadKernel"):
        @kernel()
        def BadKernel():
            pass


def test_kernel_rejects_uppercase_auto_sync_inner_name() -> None:
    with pytest.raises(ValueError, match="kernel function name must not contain uppercase letters.*BadAutoSyncKernel"):
        @kernel()
        @auto_sync()
        def BadAutoSyncKernel():
            pass
