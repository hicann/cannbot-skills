"""``MicroAPI::Axpy`` is a fused multiply-add on the board, so the simulator
must round once.

`axpy(dst, src, k)` computes `dst + src * k`. Evaluating that natively in the
lane dtype rounds twice -- once for the product, once for the sum -- and
disagrees with an Ascend 950 board on roughly 11 % of random fp32 lanes. The
board result is the exact product added to `dst` and rounded a single time,
which is what a genuine FMA produces (measured 2026-08-02: bit-exact against
the fp64 product rounded once, on all 65 536 probe lanes).

That mattered for `cann_bench/foreach_addcdiv_scalar`, whose kernel is
`x1 + (x2 / x3) * scalar`: the fused form carries one rounding where the
benchmark's own reference expression carries two, so a simulator that rounded
twice reported failures the board did not have.
"""
import pytest
import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.reg import Reg

_STORE = SharedMemoryStore()
_SCALAR = 0.30000001192092896  # fp32(0.3): not representable, so the product rounds


def _dispatch(regs, kw):
    rt = MicroRuntime()
    ctx = MicroContext(regs={k: v.clone() for k, v in regs.items()}, masks={})
    rt._stack.append(ctx)
    try:
        rt._dispatch("micro_vaxpy", kw, _STORE)
    finally:
        rt._stack.pop()
    return ctx.regs[kw["dst"].name]


@pytest.mark.parametrize("dt,torch_dt", [(DT.float, torch.float32), (DT.half, torch.float16)])
def test_axpy_rounds_once_like_the_board_fma(dt, torch_dt):
    lanes = 256 // torch.empty(0, dtype=torch_dt).element_size()
    gen = torch.Generator().manual_seed(20260802)
    src = torch.empty(lanes, dtype=torch_dt).uniform_(-2.0, 2.0, generator=gen)
    dst0 = torch.empty(lanes, dtype=torch_dt).uniform_(-2.0, 2.0, generator=gen)

    got = _dispatch(
        {"s0": src, "dst": dst0},
        {"dst": Reg(dt, name="dst"), "src": Reg(dt, name="s0"), "value": _SCALAR},
    )

    fused = (dst0.double() + src.double() * _SCALAR).to(torch_dt)
    twice = dst0 + (src * torch.tensor(_SCALAR, dtype=torch_dt))

    # The two orderings must actually disagree here, or the test proves nothing.
    assert not torch.equal(fused, twice), "pick inputs where double rounding differs"
    assert torch.equal(got, fused), (
        "axpy must round once: {} lanes differ from the fused result".format(
            int((got != fused).sum())
        )
    )
