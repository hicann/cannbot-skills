import pytest

from easyasc import globvars
from easyasc.parser.asc_handlers.pipe_ops import (
    handle_allcube_ready,
    handle_allcube_wait,
    handle_allvec_ready,
    handle_allvec_wait,
    handle_cube_ready,
    handle_intracore_allvec_wait,
    handle_intracore_allvec_ready,
    handle_wait_cube,
    handle_wait_vec,
    handle_vec_ready,
)
from easyasc.parser.helper import CodeHelper
from easyasc.utils.instruction import Instruction
from easyasc.utils.pipe import Pipe


@pytest.mark.parametrize(
    "handler,opname",
    [
        (handle_allcube_wait, "ALLCUBE_WAIT"),
        (handle_allvec_wait, "ALLVEC_WAIT"),
        (handle_wait_cube, "WAIT_CUBE"),
        (handle_wait_vec, "WAIT_VEC"),
        (handle_intracore_allvec_wait, "INTRACORE_ALLVEC_WAIT"),
    ],
)
@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_codegen_rejects_c220_wait_non_s_pipe(handler, opname: str, device_type: str) -> None:
    saved_device_type = globvars.device_type
    try:
        globvars.device_type = device_type
        with pytest.raises(
            ValueError,
            match=f"{opname} pipe must be Pipe.S on C220 devices",
        ):
            handler(Instruction(opname.lower(), flag_id=0, pipe=Pipe.MTE2), CodeHelper(), {})
    finally:
        globvars.device_type = saved_device_type


@pytest.mark.parametrize(
    "handler,opname",
    [
        (handle_allcube_wait, "ALLCUBE_WAIT"),
        (handle_allvec_wait, "ALLVEC_WAIT"),
        (handle_wait_cube, "WAIT_CUBE"),
        (handle_wait_vec, "WAIT_VEC"),
        (handle_intracore_allvec_wait, "INTRACORE_ALLVEC_WAIT"),
    ],
)
@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_codegen_allows_c220_wait_pipe_s(handler, opname: str, device_type: str) -> None:
    saved_device_type = globvars.device_type
    try:
        globvars.device_type = device_type
        helper = CodeHelper()
        handler(Instruction(opname.lower(), flag_id=0, pipe=Pipe.S), helper, {})
        assert str(helper) == f"{opname}(0, PIPE_S);\n"
    finally:
        globvars.device_type = saved_device_type


@pytest.mark.parametrize(
    "handler,opname",
    [
        (handle_cube_ready, "CUBE_READY"),
        (handle_allcube_ready, "ALLCUBE_READY"),
    ],
)
@pytest.mark.parametrize("pipe", [Pipe.S, Pipe.MTE3, Pipe.ALL])
def test_codegen_rejects_a5_cube_side_ready_bad_pipe(handler, opname: str, pipe: Pipe) -> None:
    saved_device_type = globvars.device_type
    try:
        globvars.device_type = "950"
        with pytest.raises(ValueError, match=f"{opname} pipe must be one of"):
            handler(Instruction(opname.lower(), flag_id=0, pipe=pipe), CodeHelper(), {})
    finally:
        globvars.device_type = saved_device_type


@pytest.mark.parametrize(
    "handler,opname",
    [
        (handle_vec_ready, "VEC_READY"),
        (handle_allvec_ready, "ALLVEC_READY"),
        (handle_intracore_allvec_ready, "INTRACORE_ALLVEC_READY"),
    ],
)
def test_codegen_allows_a5_vec_side_ready_mte3(handler, opname: str) -> None:
    saved_device_type = globvars.device_type
    try:
        globvars.device_type = "950"
        helper = CodeHelper()
        handler(Instruction(opname.lower(), flag_id=0, pipe=Pipe.MTE3), helper, {})
        assert str(helper) == f"{opname}(0, PIPE_MTE3);\n"
    finally:
        globvars.device_type = saved_device_type
