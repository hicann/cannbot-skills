import warnings

import pytest

from easyasc.a2 import *
from easyasc.parser.asc import (
    _validate_side_helper_view_references,
    split_instructions,
    translate_split,
)


WIDTH = 40


@kernel(mode="mix")
def dynamic_gm_read_through_helper_chain(src: GMTensor):
    vec_idx = GetVecIdx()
    src_view = src[0:1, vec_idx:vec_idx + 1].reinterpret(DT.uint32)
    value = Var(0, DT.uint32, name="dynamic_read_value")
    value.GetValueFrom(src_view)
    return src


@kernel(mode="mix")
def dynamic_gm_write_through_helper_chain(dst: GMTensor):
    vec_idx = GetVecIdx()
    dst_view = dst[0:1, vec_idx:vec_idx + 1].reinterpret(DT.uint32)
    value = Var(7, DT.uint32, name="dynamic_write_value")
    value.SetValueTo(dst_view)
    return dst


@kernel(mode="mix")
def dynamic_gm_read_controls_loop_and_if(src: GMTensor):
    vec_idx = GetVecIdx()
    count = Var(0, DT.int, name="dynamic_control_count")
    count.GetValueFrom(src[0:1, vec_idx:vec_idx + 1])
    chunks = CeilDiv(count, 2, name="dynamic_control_chunks")
    ub = Tensor(DT.int, [1, 8], Position.UB)
    for chunk_idx in range(chunks, name="dynamic_control_loop"):
        ub[0:1, 0:1] <<= src[0:1, 0:1]
        bar_all()
    if chunks > 0:
        ub[0:1, 0:1] <<= src[0:1, 0:1]
        bar_all()
    return src


@kernel(mode="mix")
def dynamic_gm_read_cannot_control_cube_op(control: GMTensor, data: GMTensor):
    vec_idx = GetVecIdx()
    count = Var(0, DT.int, name="illegal_dynamic_count")
    count.GetValueFrom(control[0:1, vec_idx:vec_idx + 1])
    l1 = Tensor(DT.half, [16, 16], Position.L1)
    if count > 0:
        l1 <<= data[0:16, 0:16]
    return data


@kernel(mode="mix")
def static_gm_read_remains_shared(src: GMTensor):
    value = Var(0, DT.int, name="static_read_value")
    value.GetValueFrom(src[0:1, 0:1])
    return src


def _opnames(instructions):
    return [inst.opname for inst in instructions]


def test_dynamic_gm_read_routes_entire_helper_chain_to_vec() -> None:
    src = GMTensor(DT.int, [1, WIDTH], name="src")
    dynamic_gm_read_through_helper_chain(src)

    cube_insts, vec_insts = split_instructions(dynamic_gm_read_through_helper_chain.instructions)
    cube_opnames = _opnames(cube_insts)
    vec_opnames = _opnames(vec_insts)
    for opname in ("GetVecIdx", "slice_gm_tensor", "reinterpret", "GetValueFrom"):
        assert opname not in cube_opnames
        assert opname in vec_opnames

    cube_code, vec_code = translate_split(
        dynamic_gm_read_through_helper_chain.instructions,
        "dynamic_gm_read_through_helper_chain",
    )
    assert ".GetValue(0)" not in cube_code
    assert ".GetValue(0)" in vec_code
    assert "ReinterpretCast<uint32_t>()" in vec_code


def test_dynamic_gm_set_value_to_routes_target_helper_chain_to_vec() -> None:
    dst = GMTensor(DT.int, [1, WIDTH], name="dst")
    dynamic_gm_write_through_helper_chain(dst)

    with warnings.catch_warnings():
        warnings.simplefilter("error")
        cube_insts, vec_insts = split_instructions(dynamic_gm_write_through_helper_chain.instructions)
    cube_opnames = _opnames(cube_insts)
    vec_opnames = _opnames(vec_insts)
    for opname in ("GetVecIdx", "slice_gm_tensor", "reinterpret", "SetValueTo"):
        assert opname not in cube_opnames
        assert opname in vec_opnames

    cube_code, vec_code = translate_split(
        dynamic_gm_write_through_helper_chain.instructions,
        "dynamic_gm_write_through_helper_chain",
    )
    assert ".SetValue(0" not in cube_code
    assert ".SetValue(0" in vec_code


def test_dynamic_gm_read_propagates_to_derived_loop_and_if_control() -> None:
    src = GMTensor(DT.int, [1, WIDTH], name="src")
    dynamic_gm_read_controls_loop_and_if(src)

    cube_insts, vec_insts = split_instructions(dynamic_gm_read_controls_loop_and_if.instructions)
    cube_opnames = _opnames(cube_insts)
    vec_opnames = _opnames(vec_insts)
    for opname in ("GetValueFrom", "CeilDiv", "start_loop", "start_if", "barrier"):
        assert opname not in cube_opnames
        assert opname in vec_opnames


def test_dynamic_gm_read_rejects_cube_op_under_loaded_control() -> None:
    control = GMTensor(DT.int, [1, WIDTH], name="control")
    data = GMTensor(DT.half, [16, 16], name="data")
    dynamic_gm_read_cannot_control_cube_op(control, data)

    with pytest.raises(ValueError, match="cube-only inside start_if"):
        split_instructions(dynamic_gm_read_cannot_control_cube_op.instructions)


def test_static_gm_read_keeps_existing_shared_semantics() -> None:
    src = GMTensor(DT.int, [1, WIDTH], name="src")
    static_gm_read_remains_shared(src)

    cube_insts, vec_insts = split_instructions(static_gm_read_remains_shared.instructions)
    assert "GetValueFrom" in _opnames(cube_insts)
    assert "GetValueFrom" in _opnames(vec_insts)


def test_helper_reference_validator_rejects_missing_definition() -> None:
    src = GMTensor(DT.int, [1, WIDTH], name="src")
    dynamic_gm_read_through_helper_chain(src)
    original = list(dynamic_gm_read_through_helper_chain.instructions)
    missing_reinterpret = [inst for inst in original if inst.opname != "reinterpret"]

    with pytest.raises(ValueError, match="helper view.*reinterpret.*no retained definition"):
        _validate_side_helper_view_references(missing_reinterpret, "cube", original)
