from easyasc.a5 import *


@kernel()
def _vcmutex_depth_kernel(x: GMTensor):
    vcmutex = VcMutex(3, depth=2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    vcmutex.lock()
    vcmutex.ready()
    vcmutex.wait()
    vcmutex.free()
    return x


def test_vcmutex_depth_only_primes_flag_counter() -> None:
    x = GMTensor(DT.float, [1, 1], name="x")
    _vcmutex_depth_kernel(x)
    instructions = list(_vcmutex_depth_kernel.instructions)

    head = instructions[:2]
    tail = instructions[-2:]

    assert [inst.opname for inst in head] == ["cube_ready", "cube_ready"]
    assert [inst.kwargs["flag_id"] for inst in head] == [3, 3]
    assert [inst.kwargs["pipe"] for inst in head] == [Pipe.MTE1, Pipe.MTE1]
    assert all(set(inst.kwargs.keys()) == {"flag_id", "pipe"} for inst in head)

    assert [inst.opname for inst in tail] == ["wait_cube", "wait_cube"]
    assert [inst.kwargs["flag_id"] for inst in tail] == [3, 3]
    assert [inst.kwargs["pipe"] for inst in tail] == [Pipe.S, Pipe.S]
    assert all(set(inst.kwargs.keys()) == {"flag_id", "pipe"} for inst in tail)
