import math

import pytest
import torch

from easyasc.a5 import *

# The compiler requires a non-returned input tensor in the kernel entry;
# this kernel writes its output from a Var alone, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.float32)


@kernel()
def scalar_sqrt_kernel(gate: GMTensor, output: GMTensor, value: Var):
    with vec_scope():
        value_float = Var(value, DT.float, name="sqrt_value_float")
        result = scalar_sqrt(value_float, name="sqrt_result")
        result.SetValueTo(output)
    return output


def test_scalar_sqrt_preserves_fraction_for_integer_valued_float() -> None:
    output = torch.zeros((1,), dtype=torch.float32)
    got = OpExec(scalar_sqrt_kernel, simulator=True)(GATE, output, 65)
    assert math.isclose(float(got[0]), math.sqrt(65.0), rel_tol=1.0e-6)


def test_scalar_sqrt_still_rejects_integer_vars() -> None:
    with pytest.raises(TypeError, match="only supports float Var"):
        scalar_sqrt(Var(65, DT.int))
