from easyasc.a5 import *
from easyasc.parser.asc import translate_split


@kernel()
def vec_scope_align8_codegen(dst: GMTensor, n: Var):
    with vec_scope():
        aligned = Align8(n, name="aligned")
        aligned.SetValueTo(dst)
    return dst


@kernel()
def cube_scope_align8_codegen(dst: GMTensor, n: Var):
    with cube_scope():
        aligned = Align8(n, name="aligned")
        aligned.SetValueTo(dst)
    return dst


def test_translate_split_emits_align8_on_vec_side() -> None:
    dst = GMTensor(DT.int, [1, 1], name="dst")
    n = Var(13, DT.int, name="n")
    vec_scope_align8_codegen(dst, n)

    cube_code, vec_code = translate_split(
        vec_scope_align8_codegen.instructions,
        "vec_scope_align8_codegen",
    )

    assert "int aligned = Align8B(n);" not in cube_code
    assert "int aligned = Align8B(n);" in vec_code
    assert "dst.SetValue(0, (int)(aligned));" in vec_code


def test_translate_split_emits_align8_on_cube_side() -> None:
    dst = GMTensor(DT.int, [1, 1], name="dst")
    n = Var(13, DT.int, name="n")
    cube_scope_align8_codegen(dst, n)

    cube_code, vec_code = translate_split(
        cube_scope_align8_codegen.instructions,
        "cube_scope_align8_codegen",
    )

    assert "int aligned = Align8B(n);" in cube_code
    assert "int aligned = Align8B(n);" not in vec_code
    assert "dst.SetValue(0, (int)(aligned));" in cube_code
