import pytest
import torch
from contextlib import contextmanager

from easyasc import globvars
from easyasc.a5 import *


def _with_a5_device():
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    return saved_device_type


def _restore_device(saved_device_type) -> None:
    globvars.device_type = saved_device_type


@contextmanager
def _device_bt_profile(device_type, bt_cap):
    saved = (globvars.device_type, globvars.bt_cap)
    globvars.device_type = device_type
    globvars.bt_cap = bt_cap
    try:
        yield
    finally:
        globvars.device_type, globvars.bt_cap = saved


@kernel()
def _empty_bt_kernel(inp: GMTensor):
    return inp


@kernel()
def _bias_static_64(inp: GMTensor):
    l1a = Tensor(DT.half, [16, 16], Position.L1)
    l1b = Tensor(DT.half, [64, 16], Position.L1)
    bias = Tensor(DT.float, [1, 64], Position.L1)
    l0c = Tensor(DT.float, [16, 64], Position.L0C)
    matmul(l0c, l1a, l1b, bias=bias)
    return inp


@kernel()
def _bias_static_65(inp: GMTensor):
    l1a = Tensor(DT.half, [16, 16], Position.L1)
    l1b = Tensor(DT.half, [65, 16], Position.L1)
    bias = Tensor(DT.float, [1, 65], Position.L1)
    l0c = Tensor(DT.float, [16, 65], Position.L0C)
    matmul(l0c, l1a, l1b, bias=bias)
    return inp


@kernel()
def _bias_static_512(inp: GMTensor):
    l1a = Tensor(DT.half, [16, 16], Position.L1)
    l1b = Tensor(DT.half, [512, 16], Position.L1)
    bias = Tensor(DT.float, [1, 512], Position.L1)
    l0c = Tensor(DT.float, [16, 512], Position.L0C)
    matmul(l0c, l1a, l1b, bias=bias)
    return inp


@kernel()
def _bias_static_513(inp: GMTensor):
    l1a = Tensor(DT.half, [16, 16], Position.L1)
    l1b = Tensor(DT.half, [513, 16], Position.L1)
    bias = Tensor(DT.float, [1, 513], Position.L1)
    l0c = Tensor(DT.float, [16, 513], Position.L0C)
    matmul(l0c, l1a, l1b, bias=bias)
    return inp


@kernel()
def _bias_splitk_65(inp: GMTensor):
    l1a = Tensor(DT.half, [16, 32], Position.L1)
    l1b = Tensor(DT.half, [65, 32], Position.L1)
    bias = Tensor(DT.float, [1, 65], Position.L1)
    l0c = Tensor(DT.float, [16, 65], Position.L0C)
    matmul(l0c, l1a, l1b, splitk=16, bias=bias)
    return inp


@kernel()
def _bias_splitn_128_by_64(inp: GMTensor):
    l1a = Tensor(DT.half, [16, 16], Position.L1)
    l1b = Tensor(DT.half, [128, 16], Position.L1)
    bias = Tensor(DT.float, [1, 128], Position.L1)
    l0c = Tensor(DT.float, [16, 128], Position.L0C)
    matmul(l0c, l1a, l1b, splitn=64, bias=bias)
    return inp


@kernel()
def _bias_splitn_128_by_65(inp: GMTensor):
    l1a = Tensor(DT.half, [16, 16], Position.L1)
    l1b = Tensor(DT.half, [128, 16], Position.L1)
    bias = Tensor(DT.float, [1, 128], Position.L1)
    l0c = Tensor(DT.float, [16, 128], Position.L0C)
    matmul(l0c, l1a, l1b, splitn=65, bias=bias)
    return inp


@kernel()
def _bias_splitn_1024_by_512(inp: GMTensor):
    l1a = Tensor(DT.half, [16, 16], Position.L1)
    l1b = Tensor(DT.half, [1024, 16], Position.L1)
    bias = Tensor(DT.float, [1, 1024], Position.L1)
    l0c = Tensor(DT.float, [16, 1024], Position.L0C)
    matmul(l0c, l1a, l1b, splitn=512, bias=bias)
    return inp


@kernel()
def _bias_dynamic_n(inp: GMTensor, n: Var):
    l1a = Tensor(DT.half, [16, 16], Position.L1)
    l1b = Tensor(DT.half, [n, 16], Position.L1)
    bias = Tensor(DT.float, [1, n], Position.L1)
    l0c = Tensor(DT.float, [16, n], Position.L0C)
    matmul(l0c, l1a, l1b, n=n, bias=bias)
    return inp


@kernel()
def _mx_bias_static_512(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1)
    l1b = Tensor(DT.e4m3, [64, 512], Position.L1)
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
    scale_b = Tensor(DT.uint8, [512, 2], Position.L1)
    bias = Tensor(DT.float, [1, 512], Position.L1)
    l0c = Tensor(DT.float, [16, 512], Position.L0C)
    matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, m=16, n=512, k=64, bias=bias)
    return inp


@kernel()
def _mx_bias_static_513(inp: GMTensor):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1)
    l1b = Tensor(DT.e4m3, [64, 528], Position.L1)
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
    scale_b = Tensor(DT.uint8, [528, 2], Position.L1)
    bias = Tensor(DT.float, [1, 528], Position.L1)
    l0c = Tensor(DT.float, [16, 528], Position.L0C)
    matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, m=16, n=513, k=64, bias=bias)
    return inp


@kernel()
def _conv_bias_64(inp: GMTensor):
    fmap = Tensor(DT.half, [1, 16], Position.L1)
    weight = Tensor(DT.half, [64, 16], Position.L1)
    bias = Tensor(DT.float, [1, 64], Position.L1)
    l0c = Tensor(DT.float, [16, 64], Position.L0C)
    conv2d(l0c, fmap, weight, Conv2D(1, 1), h=1, w=1, c=16, cout=64, tile_k=16, bias=bias)
    return inp


@kernel()
def _conv_bias_65(inp: GMTensor):
    fmap = Tensor(DT.half, [1, 16], Position.L1)
    weight = Tensor(DT.half, [80, 16], Position.L1)
    bias = Tensor(DT.float, [1, 80], Position.L1)
    l0c = Tensor(DT.float, [16, 80], Position.L0C)
    conv2d(l0c, fmap, weight, Conv2D(1, 1), h=1, w=1, c=16, cout=65, tile_k=16, bias=bias)
    return inp


@kernel()
def _conv_bias_512(inp: GMTensor):
    fmap = Tensor(DT.half, [1, 16], Position.L1)
    weight = Tensor(DT.half, [512, 16], Position.L1)
    bias = Tensor(DT.float, [1, 512], Position.L1)
    l0c = Tensor(DT.float, [16, 512], Position.L0C)
    conv2d(l0c, fmap, weight, Conv2D(1, 1), h=1, w=1, c=16, cout=512, tile_k=16, bias=bias)
    return inp


@kernel()
def _conv_bias_513(inp: GMTensor):
    fmap = Tensor(DT.half, [1, 16], Position.L1)
    weight = Tensor(DT.half, [528, 16], Position.L1)
    bias = Tensor(DT.float, [1, 528], Position.L1)
    l0c = Tensor(DT.float, [16, 528], Position.L0C)
    conv2d(l0c, fmap, weight, Conv2D(1, 1), h=1, w=1, c=16, cout=513, tile_k=16, bias=bias)
    return inp


def test_kernel_bt_slot_matches_device_bt_cap() -> None:
    # The auto `_btbuf` is a depth-2 ping-pong over the whole device bias
    # table, so one slot is `bt_cap` KB / 2 of fp32: 64 on the 0.5 KB b-series,
    # 512 on the 4 KB A5 family. Both historical hardcodings were wrong in one
    # direction: `[1, 512]` put b-series slot 1 outside BT and faulted on
    # hardware, `[1, 64]` gave an A5 cube kernel an eighth of its bias table.
    inp = GMTensor(DT.half, [1, 1])
    for device_type, bt_cap in (("b3", 0.5), ("950", 4), ("950pr", 4)):
        with _device_bt_profile(device_type, bt_cap):
            _empty_bt_kernel(inp)
            assert list(_empty_bt_kernel._btbuf.shape) == [1, int(bt_cap * 128)]


def test_matmul_bias_width_capped_at_one_bt_slot() -> None:
    inp = GMTensor(DT.half, [1, 1])
    with _device_bt_profile("b3", 0.5):
        _bias_static_64(inp)
        with pytest.raises(ValueError, match="maximum is 64"):
            _bias_static_65(inp)
        with pytest.raises(ValueError, match="maximum is 64"):
            _bias_splitk_65(inp)
        _bias_splitn_128_by_64(inp)
        with pytest.raises(ValueError, match="maximum is 64"):
            _bias_splitn_128_by_65(inp)
        with pytest.raises(ValueError, match="maximum is 64"):
            _bias_static_512(inp)
        with pytest.raises(ValueError, match="maximum is 64"):
            _bias_splitn_1024_by_512(inp)
    with _device_bt_profile("950", 4):
        # The A5 slot is 512 fp32, so the widths the b-series rejects fit.
        _bias_static_64(inp)
        _bias_static_65(inp)
        _bias_splitk_65(inp)
        _bias_splitn_128_by_64(inp)
        _bias_splitn_128_by_65(inp)
        _bias_static_512(inp)
        _bias_splitn_1024_by_512(inp)
        with pytest.raises(ValueError, match="maximum is 512"):
            _bias_static_513(inp)


def test_matmul_dynamic_bias_width_requires_static_splitn() -> None:
    inp = GMTensor(DT.half, [1, 1])
    with _device_bt_profile("b3", 0.5):
        with pytest.raises(ValueError, match="Use a static splitn tile"):
            _bias_dynamic_n(inp, Var(64))


def test_matmul_mx_bias_width_capped_at_one_bt_slot() -> None:
    inp = GMTensor(DT.half, [1, 1])
    with _device_bt_profile("950", 4):
        _mx_bias_static_512(inp)
        with pytest.raises(ValueError, match="maximum is 512"):
            _mx_bias_static_513(inp)


def test_conv2d_bias_width_capped_at_one_bt_slot() -> None:
    inp = GMTensor(DT.half, [1, 1])
    with _device_bt_profile("b3", 0.5):
        _conv_bias_64(inp)
        with pytest.raises(ValueError, match="maximum is 64"):
            _conv_bias_65(inp)
        with pytest.raises(ValueError, match="maximum is 64"):
            _conv_bias_512(inp)
    with _device_bt_profile("950", 4):
        _conv_bias_64(inp)
        _conv_bias_65(inp)
        _conv_bias_512(inp)
        with pytest.raises(ValueError, match="maximum is 512"):
            _conv_bias_513(inp)


def test_shortcut_matmul_passes_explicit_mnk_nosplit() -> None:
    @kernel()
    def stub(inp: GMTensor):
        l1a = Tensor(DT.half, [32, 16], Position.L1)
        l1b = Tensor(DT.half, [24, 16], Position.L1)
        l0c = Tensor(DT.float, [32, 24], Position.L0C)
        matmul(l0c, l1a, l1b, m=7, n=9, k=11, is_init=False)
        return inp

    inp = GMTensor(DT.half, [1, 1])
    stub(inp)
    found = [inst for inst in stub.instructions if inst.opname == "mmad"]
    assert len(found) == 1
    inst = found[0]
    assert int(inst.kwargs["M"]) == 7
    assert int(inst.kwargs["N"]) == 9
    assert int(inst.kwargs["K"]) == 11
    assert bool(inst.kwargs["is_init"]) is False


def test_shortcut_matmul_splitk_uses_explicit_k_for_mmad() -> None:
    @kernel()
    def stub(inp: GMTensor):
        l1a = Tensor(DT.half, [32, 32], Position.L1)
        l1b = Tensor(DT.half, [24, 32], Position.L1)
        l0c = Tensor(DT.float, [32, 24], Position.L0C)
        matmul(l0c, l1a, l1b, splitk=16, m=7, n=9, k=20)
        return inp

    inp = GMTensor(DT.half, [1, 1])
    stub(inp)
    found = [inst for inst in stub.instructions if inst.opname == "mmad"]
    assert len(found) == 2
    assert bool(found[0].kwargs["is_init"]) is True
    assert bool(found[1].kwargs["is_init"]) is False
    for inst in found:
        assert int(inst.kwargs["M"]) == 7
        assert int(inst.kwargs["N"]) == 9
        assert isinstance(inst.kwargs["K"], Var)
        assert int(inst.kwargs["K"].value) == 16


@kernel()
def _float_shortcut_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    l1x = Tensor(DT.float, [m, k], Position.L1)
    l1y = Tensor(DT.float, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y)
        z[:, :] <<= l0c
    return z


@kernel()
def _float_shortcut_accumulate_kernel(
    x0: GMTensor, y0: GMTensor, x1: GMTensor, y1: GMTensor, z: GMTensor, m: Var, n: Var, k: Var
):
    l1x0 = Tensor(DT.float, [m, k], Position.L1)
    l1y0 = Tensor(DT.float, [n, k], Position.L1)
    l1x1 = Tensor(DT.float, [m, k], Position.L1)
    l1y1 = Tensor(DT.float, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)
    with auto_sync():
        l1x0 <<= x0[:, :]
        l1y0 <<= y0[:, :]
        matmul(l0c, l1x0, l1y0, m=m, n=n, k=k, is_init=True)
        l1x1 <<= x1[:, :]
        l1y1 <<= y1[:, :]
        matmul(l0c, l1x1, l1y1, m=m, n=n, k=k, is_init=False)
        z[:, :] <<= l0c
    return z


@kernel()
def _half_correction_pipeline_kernel(
    w: GMTensor, h: GMTensor, k_in: GMTensor, v: GMTensor, z: GMTensor, m: Var, n: Var, k: Var, t: Var
):
    l1w = Tensor(DT.half, [m, k], Position.L1)
    l1h = Tensor(DT.half, [k, n], Position.L1)
    l1k = Tensor(DT.half, [t, k], Position.L1)
    l1v = Tensor(DT.half, [t, n], Position.L1)
    delta_l1 = Tensor(DT.half, [k, n], Position.L1)
    vprime_l0c = Tensor(DT.float, [m, n], Position.L0C)
    delta_l0c = Tensor(DT.float, [k, n], Position.L0C)
    delta_l1_ready = SEvent(Pipe.MTE1, Pipe.FIX, preset=True, name="delta_l1_ready")
    delta_l1_valid = SEvent(Pipe.FIX, Pipe.MTE1, name="delta_l1_valid")
    with auto_sync():
        l1w <<= w[:, :]
        l1h <<= h[:, :]
        matmul(vprime_l0c, l1w, l1h.T, m=m, n=n, k=k, is_init=True)
        l1k <<= k_in[:, :]
        l1v <<= v[:, :]
        matmul(delta_l0c, l1k.T, l1v.T, m=k, n=n, k=t, is_init=True)
        delta_l1_ready.wait()
        delta_l1[:, :] <<= delta_l0c
        delta_l1_valid.set()
        delta_l1_valid.wait()
        matmul(vprime_l0c, l1w, delta_l1.T, m=m, n=n, k=k, is_init=False)
        delta_l1_ready.set()
        z[:, :] <<= vprime_l0c
    return z


def test_shortcut_matmul_float_simulator() -> None:
    saved_device_type = _with_a5_device()
    try:
        m, n, k = 32, 16, 8
        torch.manual_seed(0)
        x = torch.randn((m, k), dtype=torch.float32)
        y = torch.randn((n, k), dtype=torch.float32)
        z = torch.zeros((m, n), dtype=torch.float32)

        out = OpExec(_float_shortcut_kernel, simulator=True)(
            x, y, z, m, n, k,
            shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1]},
        )
        ref = x @ y.t()
        torch.testing.assert_close(out, ref, rtol=1e-6, atol=1e-6)
    finally:
        _restore_device(saved_device_type)


def test_shortcut_matmul_float_accumulate_simulator() -> None:
    saved_device_type = _with_a5_device()
    try:
        m, n, k = 32, 16, 8
        torch.manual_seed(0)
        x0 = torch.randn((m, k), dtype=torch.float32)
        y0 = torch.randn((n, k), dtype=torch.float32)
        x1 = torch.randn((m, k), dtype=torch.float32)
        y1 = torch.randn((n, k), dtype=torch.float32)
        z = torch.zeros((m, n), dtype=torch.float32)

        out = OpExec(_float_shortcut_accumulate_kernel, simulator=True)(
            x0, y0, x1, y1, z, m, n, k,
            shape_bindings={
                0: [0, 2],
                1: [1, 2],
                2: [0, 2],
                3: [1, 2],
                4: [0, 1],
            },
        )
        ref0 = x0 @ y0.t()
        ref1 = x1 @ y1.t()
        ref = ref0 + ref1

        torch.testing.assert_close(out, ref, rtol=1e-6, atol=1e-6)
        assert not torch.allclose(out, ref1, rtol=1e-6, atol=1e-6)
    finally:
        _restore_device(saved_device_type)


def test_shortcut_matmul_half_correction_pipeline_simulator() -> None:
    saved_device_type = _with_a5_device()
    try:
        m, n, k, t = 32, 16, 16, 16
        torch.manual_seed(0)
        w = torch.randn((m, k), dtype=torch.float16)
        h = torch.randn((k, n), dtype=torch.float16)
        k_in = torch.randn((t, k), dtype=torch.float16)
        v = torch.randn((t, n), dtype=torch.float16)
        z = torch.zeros((m, n), dtype=torch.float32)

        out = OpExec(_half_correction_pipeline_kernel, simulator=True)(
            w, h, k_in, v, z, m, n, k, t,
            shape_bindings={
                0: [0, 2],
                1: [2, 1],
                2: [3, 2],
                3: [3, 1],
                4: [0, 1],
            },
        )

        delta = k_in.float().t() @ v.float()
        ref = w.float() @ h.float() + w.float() @ delta.half().float()

        torch.testing.assert_close(out, ref, rtol=1e-3, atol=1e-3)
    finally:
        _restore_device(saved_device_type)


def test_mmad_rejects_mixed_src_dtypes() -> None:
    @kernel()
    def stub(inp: GMTensor):
        l0a = Tensor(DT.half, [32, 16], Position.L0A)
        l0b = Tensor(DT.float, [24, 16], Position.L0B)
        l0c = Tensor(DT.float, [32, 24], Position.L0C)
        mmad(l0c, l0a, l0b)
        return inp

    inp = GMTensor(DT.half, [1, 1])
    with pytest.raises(ValueError, match="mmad requires src_a/src_b data types to match"):
        stub(inp)
