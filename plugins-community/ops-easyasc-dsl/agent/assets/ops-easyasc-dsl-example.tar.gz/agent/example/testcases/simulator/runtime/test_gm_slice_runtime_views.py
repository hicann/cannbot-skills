import pytest
import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe import PipeS
from easyasc.simulator.program import ControlInstruction


def _pipe_s_with_source(numel: int) -> PipeS:
    pipe_s = object.__new__(PipeS)
    pipe_s.memory_store = SharedMemoryStore()
    pipe_s.memory_store.register_view("src", torch.arange(numel, dtype=torch.float32))
    pipe_s.tensor_name_map = {}
    pipe_s._vars = {}
    return pipe_s


def _slice_inst(rows: int, row_offset: int = 128) -> ControlInstruction:
    return ControlInstruction(
        "slice_gm_tensor",
        args={
            "view_name": "tmp",
            "source_name": "src",
            "ndim": 2,
            "offset_0": row_offset,
            "offset_1": 0,
            "src_dim_0": 256,
            "src_dim_1": 128,
            "span_0": rows,
            "span_1": 128,
        },
    )


def test_slice_gm_tensor_runtime_view_key_includes_span() -> None:
    pipe_s = _pipe_s_with_source(256 * 128)

    pipe_s._handle_slice_gm_tensor(_slice_inst(rows=8))
    tail_name = pipe_s._vars["tmp"]
    assert pipe_s.memory_store.tensor(tail_name).numel() == 8 * 128

    pipe_s._handle_slice_gm_tensor(_slice_inst(rows=128))
    full_name = pipe_s._vars["tmp"]
    assert full_name != tail_name
    assert pipe_s.memory_store.tensor(full_name).numel() == 128 * 128


def test_slice_gm_tensor_rejects_logical_dim_overflow() -> None:
    pipe_s = _pipe_s_with_source(256 * 128)

    with pytest.raises(RuntimeError, match="slice_gm_tensor dim 0 out of bounds"):
        pipe_s._handle_slice_gm_tensor(_slice_inst(rows=128, row_offset=200))


def test_slice_gm_tensor_rejects_storage_overflow() -> None:
    pipe_s = _pipe_s_with_source(16)
    inst = ControlInstruction(
        "slice_gm_tensor",
        args={
            "view_name": "tmp",
            "source_name": "src",
            "ndim": 2,
            "offset_0": 3,
            "offset_1": 0,
            "src_dim_0": 4,
            "src_dim_1": 8,
            "span_0": 1,
            "span_1": 8,
        },
    )

    with pytest.raises(RuntimeError, match="slice_gm_tensor footprint exceeds tensor storage"):
        pipe_s._handle_slice_gm_tensor(inst)
