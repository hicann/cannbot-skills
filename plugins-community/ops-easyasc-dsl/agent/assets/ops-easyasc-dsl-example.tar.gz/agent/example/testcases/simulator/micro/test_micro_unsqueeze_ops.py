"""Simulator regression for ``unsqueeze`` (MicroAPI::Unsqueeze, PrefixSumImpl).

Board-verified 2026-07-21 (kernels/a5/vec_only/unsqueeze_onboard.py): Unsqueeze is an in-place
EXCLUSIVE prefix-sum (scan) of the mask bits -- dst[i] = number of active mask lanes strictly
before lane i (the rank of lane i among the active lanes). The input dst is ignored; the result
is a pure function of the mask. Despite the name it is NOT the inverse of squeeze; it is the
index-generation primitive that feeds Squeeze/GatherMask addressing.
"""
import pytest
import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg

_STORE = SharedMemoryStore()


def _dispatch(ops, regs, masks):
    rt = MicroRuntime()
    ctx = MicroContext(regs={k: v.clone() for k, v in regs.items()},
                       masks={k: v.clone() for k, v in masks.items()})
    rt._stack.append(ctx)
    try:
        for op, kw in ops:
            rt._dispatch(op, kw, _STORE)
    finally:
        rt._stack.pop()
    return ctx


def _exclusive_prefix(mask_bits):
    n = int(mask_bits.numel())
    excl = torch.zeros(n, dtype=torch.int64)
    if n > 1:
        excl[1:] = torch.cumsum(mask_bits.to(torch.int64), dim=0)[:-1]
    return excl


def test_unsqueeze_is_exclusive_prefix_sum_of_mask():
    n = 64
    mask = torch.zeros(n, dtype=torch.bool)
    mask[1] = mask[3] = mask[4] = True
    dst = Reg(DT.int, name="dst")
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    # input dst is arbitrary garbage -- it must be ignored
    ctx = _dispatch([("micro_unsqueeze", {"dst": dst, "mask": m})],
                    {"dst": torch.arange(100, 100 + n, dtype=torch.int32)}, {"m": mask})
    want = _exclusive_prefix(mask).to(torch.int32)
    assert torch.equal(ctx.regs["dst"], want)
    assert want[:8].tolist() == [0, 0, 1, 1, 2, 3, 3, 3]  # explicit board-observed prefix


def test_unsqueeze_strided_mask():
    n = 64
    mask = torch.zeros(n, dtype=torch.bool)
    mask[0:12:2] = True  # lanes 0,2,4,6,8,10
    dst = Reg(DT.int, name="dst")
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    ctx = _dispatch([("micro_unsqueeze", {"dst": dst, "mask": m})],
                    {"dst": torch.zeros(n, dtype=torch.int32)}, {"m": mask})
    assert ctx.regs["dst"][:13].tolist() == [0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6]


def test_unsqueeze_empty_mask_all_zero():
    n = 64
    dst = Reg(DT.int, name="dst")
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    ctx = _dispatch([("micro_unsqueeze", {"dst": dst, "mask": m})],
                    {"dst": torch.arange(n, dtype=torch.int32)}, {"m": torch.zeros(n, dtype=torch.bool)})
    assert torch.equal(ctx.regs["dst"], torch.zeros(n, dtype=torch.int32))


def test_unsqueeze_full_mask_is_iota():
    n = 64
    dst = Reg(DT.int, name="dst")
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    ctx = _dispatch([("micro_unsqueeze", {"dst": dst, "mask": m})],
                    {"dst": torch.zeros(n, dtype=torch.int32)}, {"m": torch.ones(n, dtype=torch.bool)})
    assert torch.equal(ctx.regs["dst"], torch.arange(n, dtype=torch.int32))


@pytest.mark.parametrize("dt,torch_dt", [
    (DT.int, torch.int32),
    (DT.int64, torch.int64),
    (DT.uint32, torch.int64),  # uint32 backed by signed view in sim; values are small counts
])
def test_unsqueeze_dtype_and_lane_count(dt, torch_dt):
    n = 256 // torch.empty(0, dtype=torch_dt).element_size()
    mask = torch.zeros(n, dtype=torch.bool)
    mask[::3] = True  # every 3rd lane
    dst = Reg(dt, name="dst")
    m = MaskReg(dt, init_mode=MaskType.NONE, name="m")
    ctx = _dispatch([("micro_unsqueeze", {"dst": dst, "mask": m})],
                    {"dst": torch.zeros(n, dtype=torch_dt)}, {"m": mask})
    want = _exclusive_prefix(mask)
    assert ctx.regs["dst"].to(torch.int64).tolist() == want.tolist()
