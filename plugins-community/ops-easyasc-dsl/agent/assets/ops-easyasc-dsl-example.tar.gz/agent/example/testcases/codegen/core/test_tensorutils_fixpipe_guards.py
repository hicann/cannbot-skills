from pathlib import Path


ROOT = Path(__file__).resolve().parents[5]
TENSORUTILS = ROOT / "easyasc" / "resources" / "tensorutils.h"


def _resolve_fixpipe_quant_body() -> str:
    text = TENSORUTILS.read_text(encoding="utf-8")
    start = text.index("template <typename T, typename T2>\n__aicore__ inline void ResolveFixpipeQuant")
    end = text.index("template <typename T, typename T2>\n__aicore__ inline void L0C2GM_NZ2ND")
    return text[start:end]


def _line_is_guarded_by_c310(body: str, needle: str) -> bool:
    guard_stack = []
    for line in body.splitlines():
        stripped = line.strip()
        if stripped.startswith("#ifdef"):
            guard_stack.append(stripped == "#ifdef __DAV_C310__")
        elif stripped.startswith("#if defined("):
            guard_stack.append("__DAV_C310__" in stripped)
        elif stripped.startswith("#elif"):
            if guard_stack:
                guard_stack[-1] = "__DAV_C310__" in stripped
        elif stripped == "#else":
            if guard_stack:
                guard_stack[-1] = False
        elif stripped == "#endif":
            if guard_stack:
                guard_stack.pop()
        if needle in line:
            return any(guard_stack)
    return False


def test_resolve_fixpipe_quant_guards_a5_only_fp32_scaled_float_mode() -> None:
    body = _resolve_fixpipe_quant_body()
    assert _line_is_guarded_by_c310(body, "QF322F32_PRE")


def test_resolve_fixpipe_quant_guards_a5_only_fp8_and_hif8_modes() -> None:
    body = _resolve_fixpipe_quant_body()
    assert _line_is_guarded_by_c310(body, "float8_e4m3_t")
    assert _line_is_guarded_by_c310(body, "QF322FP8_PRE")
    assert _line_is_guarded_by_c310(body, "hifloat8_t")
    assert _line_is_guarded_by_c310(body, "QF322HIF8_PRE")
