from easyasc.simulator import ControlInstruction, KernelProgram, LaneProgram, SimulatorConfig
from easyasc.simulator.core import _default_pipe_factory
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe import PipeS
from easyasc.simulator.sync import CrossCoreSync, IntraCoreSync, LocalEventBank, LocalSync


def _run_scalar_lane(
    lane_name: str, opname: str, *, kernel_mode: str = "mix",
    core_idx: int = 0, core_count: int = 1,
) -> PipeS:
    program = KernelProgram(
        name="subblock_lane_guard",
        core_count=1,
        lane_programs=[
            LaneProgram(
                lane_name=lane_name,
                pipe_names=[],
                instructions=[ControlInstruction(opname, args={"dst": "value"})],
            )
        ],
    )
    cross_sync = CrossCoreSync(core_count=core_count)
    cross_sync.prepare()
    pipe_s = PipeS(
        core_idx=core_idx,
        lane_name=lane_name,
        lane_program=program.get_lane_program(lane_name),
        config=SimulatorConfig(core_count=core_count, execution_timeout_s=1.0),
        memory_store=SharedMemoryStore(),
        intra_sync=IntraCoreSync(),
        cross_sync=cross_sync,
        local_sync=LocalSync(),
        event_bank=LocalEventBank(),
        pipe_factory=_default_pipe_factory,
        kernel_mode=kernel_mode,
    )
    pipe_s.run()
    return pipe_s


def test_vec_idx_runs_on_vec_lane() -> None:
    pipe_s = _run_scalar_lane("vec1", "GetVecIdx")

    assert pipe_s._failure is None
    assert pipe_s._vars["value"] == 1


def test_vec_num_runs_on_vec_lane() -> None:
    pipe_s = _run_scalar_lane("vec0", "GetVecNum")

    assert pipe_s._failure is None
    assert pipe_s._vars["value"] == 2


def test_subblock_idx_runs_on_vec_lane() -> None:
    pipe_s = _run_scalar_lane("vec1", "GetSubBlockIdx")

    assert pipe_s._failure is None
    assert pipe_s._vars["value"] == 1


def test_subblock_num_runs_on_vec_lane() -> None:
    pipe_s = _run_scalar_lane("vec0", "GetSubBlockNum")

    assert pipe_s._failure is None
    assert pipe_s._vars["value"] == 2


def test_vec_only_topology_uses_one_vector_lane_per_block() -> None:
    vec_idx = _run_scalar_lane(
        "vec0", "GetVecIdx", kernel_mode="vec", core_idx=3, core_count=4,
    )
    vec_num = _run_scalar_lane(
        "vec0", "GetVecNum", kernel_mode="vec", core_idx=3, core_count=4,
    )
    subblock_idx = _run_scalar_lane(
        "vec0", "GetSubBlockIdx", kernel_mode="vec", core_idx=3, core_count=4,
    )
    subblock_num = _run_scalar_lane(
        "vec0", "GetSubBlockNum", kernel_mode="vec", core_idx=3, core_count=4,
    )

    assert vec_idx._vars["value"] == 3
    assert vec_num._vars["value"] == 4
    assert subblock_idx._vars["value"] == 0
    assert subblock_num._vars["value"] == 1


def test_vec_idx_rejects_cube_lane() -> None:
    pipe_s = _run_scalar_lane("cube", "GetVecIdx")

    assert pipe_s._failure is not None
    assert "GetVecIdx is only supported on vec lanes" in pipe_s._failure


def test_vec_num_rejects_cube_lane() -> None:
    pipe_s = _run_scalar_lane("cube", "GetVecNum")

    assert pipe_s._failure is not None
    assert "GetVecNum is only supported on vec lanes" in pipe_s._failure


def test_subblock_idx_rejects_cube_lane() -> None:
    pipe_s = _run_scalar_lane("cube", "GetSubBlockIdx")

    assert pipe_s._failure is not None
    assert "GetSubBlockIdx is only supported on vec lanes" in pipe_s._failure


def test_subblock_num_rejects_cube_lane() -> None:
    pipe_s = _run_scalar_lane("cube", "GetSubBlockNum")

    assert pipe_s._failure is not None
    assert "GetSubBlockNum is only supported on vec lanes" in pipe_s._failure
