import torch

from easyasc.a5 import (
    DT,
    GMTensor,
    GetSubBlockIdx,
    OpExec,
    Pipe,
    Position,
    SEvent,
    Tensor,
    Var,
    kernel,
)
from easyasc.simulator import SimulatorConfig, build_kernel_program
from easyasc.utils.instruction import Instruction


def _make_kernel(instructions, kernel_mode="mix"):
    class FakeKernel:
        name = "manual_vec_side_split"

    kernel_obj = FakeKernel()
    kernel_obj.instructions = instructions
    kernel_obj.kernel_mode = kernel_mode
    return kernel_obj


def test_vec_only_program_has_one_vector_lane_and_no_cube_lane() -> None:
    program = build_kernel_program(_make_kernel([], kernel_mode="vec"))

    assert program.metadata["kernel_mode"] == "vec"
    assert [lane.lane_name for lane in program.lane_programs] == ["vec0"]


def test_manual_vec_event_routes_to_vec_lane_without_autosync() -> None:
    event = SEvent(Pipe.MTE2, Pipe.MTE3, name="load_ready")
    program = build_kernel_program(
        _make_kernel(
            [
                Instruction("create_sevent", val=event),
                Instruction("event_set", event=event),
                Instruction("event_wait", event=event),
            ]
        )
    )

    cube_event_ops = [
        inst.opname
        for inst in program.get_lane_program("cube").instructions
        if inst.opname.startswith("event") or inst.opname == "create_sevent"
    ]
    vec_event_ops = [
        inst.opname
        for inst in program.get_lane_program("vec0").instructions
        if inst.opname.startswith("event") or inst.opname == "create_sevent"
    ]

    assert cube_event_ops == []
    assert vec_event_ops == ["create_sevent", "event_set", "event_wait"]


@kernel()
def manual_vec_slice_copy_kernel(src: GMTensor, out: GMTensor, rows: Var):
    ub = Tensor(DT.float, [1, 8], Position.UB)
    load_ready = SEvent(Pipe.MTE2, Pipe.MTE3, name="load_ready")
    row = Var(GetSubBlockIdx())

    ub[0:1, 0:8] <<= src[row:row + 1, 0:8]
    load_ready.set()
    load_ready.wait()
    out[row:row + 1, 0:8] <<= ub[0:1, 0:8]
    return out


def test_manual_vec_dynamic_gm_slice_runs_on_vec_lanes_without_scope() -> None:
    src = torch.stack(
        (
            torch.arange(8, dtype=torch.float32),
            torch.arange(100, 108, dtype=torch.float32),
        )
    )
    out = torch.full_like(src, -1.0)

    previous_config = getattr(manual_vec_slice_copy_kernel, "_simulator_config", None)
    manual_vec_slice_copy_kernel._simulator_config = SimulatorConfig(core_count=1, execution_timeout_s=10.0)
    try:
        got = OpExec(manual_vec_slice_copy_kernel, simulator=True)(
            src,
            out,
            2,
            shape_bindings={0: [0, None], 1: [0, None]},
        )
    finally:
        if previous_config is None:
            delattr(manual_vec_slice_copy_kernel, "_simulator_config")
        else:
            manual_vec_slice_copy_kernel._simulator_config = previous_config

    torch.testing.assert_close(got, src, rtol=0.0, atol=0.0)
