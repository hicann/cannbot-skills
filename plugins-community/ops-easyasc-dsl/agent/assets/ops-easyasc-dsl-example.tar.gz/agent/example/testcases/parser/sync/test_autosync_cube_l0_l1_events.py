import contextlib
import io

from easyasc.parser.asc import split_instructions
from easyasc.parser.asc_autosync import insert_auto_sync
from testcases.parser.sync._autosync_cube_kernels import (
    autosync_cube_aggressive_l0_groups_adjacent_mte1_keys,
    autosync_cube_aggressive_l0_splits_mmad_separated_bursts,
    autosync_cube_fix_storage_keeps_conservative_l0,
    autosync_cube_manual_fix_skips_fix_events,
    autosync_cube_loop_pending_valid_stays_in_loop,
    autosync_cube_outer_l0_ready_before_child_loop,
    autosync_cube_parent_child_same_l1_stream,
    autosync_cube_reacquires_valid_between_rounds,
    build_cube_aggressive_l0_groups_adjacent_mte1_keys,
    build_cube_aggressive_l0_splits_mmad_separated_bursts,
    build_cube_fix_storage_keeps_conservative_l0,
    build_cube_manual_fix_skips_fix_events,
    build_cube_loop_pending_valid_stays_in_loop,
    build_cube_outer_l0_ready_before_child_loop,
    build_cube_parent_child_same_l1_stream,
    build_cube_reacquire_valid_between_rounds,
)


def _created_devent_valid_l0_names(instructions):
    return {
        inst.kwargs["val"].name
        for inst in instructions
        if inst.opname == "create_devent"
        and inst.kwargs["val"].name.startswith("_tmp_devent_valid_l0_")
    }


def _created_devent_valid_fix_names(instructions):
    return {
        inst.kwargs["val"].name
        for inst in instructions
        if inst.opname == "create_devent"
        and inst.kwargs["val"].name.startswith("_tmp_devent_valid_fix_")
    }

def test_insert_auto_sync_cube_reacquires_valid_between_rounds() -> None:
    build_cube_reacquire_valid_between_rounds()
    cube_insts, _ = split_instructions(list(autosync_cube_reacquires_valid_between_rounds.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        cube_insts = insert_auto_sync(cube_insts, mode="cube")

    assert "NOT balanced auto_sync events" not in captured.getvalue()

    counts = {}
    for inst in cube_insts:
        if inst.opname not in ("event_wait", "event_set"):
            continue
        event = inst.kwargs["event"]
        if event.name not in ("_tmp_devent_valid_l0_0", "_tmp_devent_valid_fix_0"):
            continue
        key = (event.name, inst.opname)
        counts[key] = counts.get(key, 0) + 1

    assert counts.get(("_tmp_devent_valid_l0_0", "event_wait"), 0) == 2
    assert counts.get(("_tmp_devent_valid_l0_0", "event_set"), 0) == 2
    assert counts.get(("_tmp_devent_valid_fix_0", "event_wait"), 0) == 2
    assert counts.get(("_tmp_devent_valid_fix_0", "event_set"), 0) == 2


def test_insert_auto_sync_cube_parent_child_same_l1_stream_reuses_event_group() -> None:
    build_cube_parent_child_same_l1_stream()
    cube_insts, _ = split_instructions(list(autosync_cube_parent_child_same_l1_stream.instructions))
    cube_insts = insert_auto_sync(cube_insts, mode="cube")

    created_valid_l1 = {
        inst.kwargs["val"].name
        for inst in cube_insts
        if inst.opname == "create_devent"
        and inst.kwargs["val"].name.startswith("_tmp_devent_valid_l1_")
    }
    created_ready_l1 = {
        inst.kwargs["val"].name
        for inst in cube_insts
        if inst.opname == "create_devent"
        and inst.kwargs["val"].name.startswith("_tmp_devent_ready_l1_")
    }

    assert created_valid_l1 == {"_tmp_devent_valid_l1_0"}
    assert created_ready_l1 == {"_tmp_devent_ready_l1_0"}


def test_insert_auto_sync_cube_loop_pending_valid_set_stays_inside_loop() -> None:
    build_cube_loop_pending_valid_stays_in_loop()
    cube_insts, _ = split_instructions(list(autosync_cube_loop_pending_valid_stays_in_loop.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        cube_insts = insert_auto_sync(cube_insts, mode="cube")

    assert "NOT balanced auto_sync events" not in captured.getvalue()

    loop_start = next(idx for idx, inst in enumerate(cube_insts) if inst.opname == "start_loop")
    loop_end = next(idx for idx, inst in enumerate(cube_insts) if inst.opname == "end_loop")
    if_end = next(idx for idx, inst in enumerate(cube_insts) if inst.opname == "end_if")
    valid_sets = [
        idx
        for idx, inst in enumerate(cube_insts)
        if inst.opname == "event_set" and inst.kwargs["event"].name == "_tmp_sevent_valid_l0_0"
    ]

    assert any(loop_start < idx < loop_end for idx in valid_sets), valid_sets
    assert not any(loop_end < idx < if_end for idx in valid_sets), valid_sets

def test_insert_auto_sync_cube_outer_l0_ready_set_before_child_loop() -> None:
    build_cube_outer_l0_ready_before_child_loop()
    cube_insts, _ = split_instructions(list(autosync_cube_outer_l0_ready_before_child_loop.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        cube_insts = insert_auto_sync(cube_insts, mode="cube")

    assert "NOT balanced auto_sync events" not in captured.getvalue()

    loop_start = next(idx for idx, inst in enumerate(cube_insts) if inst.opname == "start_loop")
    loop_end = next(idx for idx, inst in enumerate(cube_insts) if inst.opname == "end_loop")
    if_end = next(idx for idx, inst in enumerate(cube_insts) if inst.opname == "end_if")
    ready_sets = [
        idx
        for idx, inst in enumerate(cube_insts)
        if inst.opname == "event_set" and inst.kwargs["event"].name == "_tmp_sevent_ready_l0_0"
    ]
    ready_waits = [
        idx
        for idx, inst in enumerate(cube_insts)
        if inst.opname == "event_wait" and inst.kwargs["event"].name == "_tmp_sevent_ready_l0_0"
    ]

    assert ready_sets and max(ready_sets) < loop_start, ready_sets
    assert ready_waits and max(ready_waits) < loop_start, ready_waits
    assert not any(loop_end < idx < if_end for idx in ready_sets), ready_sets

def test_insert_auto_sync_cube_aggressive_l0_groups_adjacent_mte1_keys() -> None:
    build_cube_aggressive_l0_groups_adjacent_mte1_keys()
    cube_insts, _ = split_instructions(list(autosync_cube_aggressive_l0_groups_adjacent_mte1_keys.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        cube_insts = insert_auto_sync(cube_insts, mode="cube")

    assert "NOT balanced auto_sync events" not in captured.getvalue()

    assert len(_created_devent_valid_l0_names(cube_insts)) == 1
    assert len(_created_devent_valid_fix_names(cube_insts)) == 2

def test_insert_auto_sync_cube_aggressive_l0_splits_mmad_separated_bursts() -> None:
    build_cube_aggressive_l0_splits_mmad_separated_bursts()
    cube_insts, _ = split_instructions(list(autosync_cube_aggressive_l0_splits_mmad_separated_bursts.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        cube_insts = insert_auto_sync(cube_insts, mode="cube")

    assert "NOT balanced auto_sync events" not in captured.getvalue()
    assert len(_created_devent_valid_l0_names(cube_insts)) == 2
    assert len(_created_devent_valid_fix_names(cube_insts)) == 2


def test_insert_auto_sync_cube_fix_storage_keeps_conservative_l0() -> None:
    build_cube_fix_storage_keeps_conservative_l0()
    cube_insts, _ = split_instructions(list(autosync_cube_fix_storage_keeps_conservative_l0.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        cube_insts = insert_auto_sync(cube_insts, mode="cube")

    assert "NOT balanced auto_sync events" not in captured.getvalue()
    assert len(_created_devent_valid_l0_names(cube_insts)) == 1
    assert len(_created_devent_valid_fix_names(cube_insts)) == 2


def test_insert_auto_sync_cube_manual_fix_skips_fix_events() -> None:
    build_cube_manual_fix_skips_fix_events()
    cube_insts, _ = split_instructions(list(autosync_cube_manual_fix_skips_fix_events.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        cube_insts = insert_auto_sync(cube_insts, mode="cube")

    assert "NOT balanced auto_sync events" not in captured.getvalue()
    assert len(_created_devent_valid_l0_names(cube_insts)) == 1
    assert not _created_devent_valid_fix_names(cube_insts)
