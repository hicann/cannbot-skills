# Testcases Guide

This directory holds the repository's automated pytest coverage.
Use it for stable regression checks, not for one-off manual runners.

## Directory layout

Top-level organization is by primary assertion type:

| Subdirectory | Scope |
|---|---|
| `codegen/` | Static generation, emitted source shape, tool output, and non-runtime API validation |
| `parser/` | Splitting, pruning, autosync insertion, stub/lowering metadata, and parser-adjacent helpers |
| `pythonic/` | Python-to-DSL AST rewriting and decorator-source transformation |
| `simulator/` | Runtime semantics, simulator roundtrips, bridge behavior, and V2 execution invariants |
| `tools/` | Tool-specific regressions for repository utilities |
| `utils/` | Focused host-side helper and reference-codec tests |

Current `codegen/` buckets are:
- `core/`: generic codegen and skeleton-generation regressions
- `datamove/`: datamove-oriented generated code and ignored-op generation behavior
- `opexec/`: generation-facing `OpExec` and repository-tool checks
- `sort/`: mergesort4, mergesort_2seq, and sort32 static regression coverage
- `tensor_buffer/`: tensor metadata and layout-related generated code checks
- `var/`: `Var` and `Align8` codegen behavior

Current `parser/` buckets are:
- `core/`: split, pruning, scope, side-specific rewriting, constant-Python-`if` rejection, and generated-identifier collision checks
- `datamove/`: datamove stub emission and type-validation checks
- `sync/`: autosync insertion split by vec events, B-device barriers, nested vec regions, and cube L0/L1 events
- `var/`: `VarList` pruning and non-runtime structural behavior
- `vec/`: vec and micro instruction classification, target guards, and handler metadata

Current `simulator/` buckets are:
- `bridge/`: control-flow bridge, compat adapter, mixed-lane emission, and debug-op routing
- `cube/`: focused cube functional blocks such as matmul shortcuts, split behavior, and dtype-carrier MMAD paths
- `datamove/`: datamove and workspace roundtrip behavior
- `micro/`: V2 micro runtime, vec-pipe op behavior, and focused micro semantic blocks
- `opexec/`: runtime-facing `OpExec` bridge and shape-binding behavior
- `runtime/`: runtime activation, planning, worker lifecycle, cleanup, and device-profile checks
- `sync/`: wait/ready/flag timeout semantics
- `tensor_buffer/`: tensor, DBuff, TBuff, QBuff, GMTensor, and reinterpret runtime behavior
- `timing/`: simulator cycle-model and instruction-cost regressions
- `trace/`: trace merging and Chrome/Perfetto export
- `var/`: simulator-side scalar and `Var` value I/O
- `vec/`: focused vec-pipe functional semantics outside the micro buckets

Choose the top-level directory by the test's primary assertion type, then use the feature subdirectory to show the affected area.
If a full kernel example already carries a runnable assertion story under `kernels/`, keep that end-to-end coverage with the kernel and extract only smaller reusable regressions into `testcases/`.

## What belongs here

- parser, splitting, pruning, and codegen regression tests
- focused functional-block tests for cube, datamove, micro, tensor-buffer, and API semantics
- simulator semantics and runtime invariant checks
- synchronization coverage such as autosync, barriers, atomics, and coordination helpers
- tool-level CLI and metadata regression tests
- A2 DataCopyPad boundary coverage belongs in both static codegen tests and simulator runtime tests so dynamic `n_burst` values cannot bypass the stub check
- agent-documentation tool tests belong under `codegen/opexec/`; they exercise index freshness, router cardinality, and documentation hygiene without mutating the repository

## What does not belong here

- manual runners or compile/integration demos that should be invoked explicitly
  - keep those under `kernels/a2/` or `kernels/a5/` (or `projects/a5/gdn_fwd/` / `projects/a5/gdn_bwd/` if the script is part of a GDN multi-file project)
- end-to-end replays of example kernels that already have runnable assertions under `kernels/`
  - keep the self-check with the kernel unless there is a smaller behavior worth extracting here
- disposable scratch scripts
- root-level ad-hoc test runners

If a useful root-level script appears during development, either:
1. convert it into a focused pytest test here, or
2. move it under `kernels/a2/` or `kernels/a5/` if it is intentionally manual/integration-style (or `projects/a5/gdn_fwd/` / `projects/a5/gdn_bwd/` for GDN system kernels)

## Authoring guidance

- prefer focused tests over giant all-in-one reproductions
- use `tmp_path` for generated outputs instead of writing artifacts into the repository tree
- keep single-consumer assets alongside their consuming test
- when moving files around, update the tests and docs that reference them
- choose `codegen/`, `parser/`, or `simulator/` by the dominant assertion type before choosing a feature bucket
- tests run with an autouse global-state fixture from `testcases/conftest.py`; use `@pytest.mark.easyasc_device("b3")`, `@pytest.mark.easyasc_device("a3")`, or `@pytest.mark.easyasc_device("950")` when a mixed facade/stub test needs a specific device baseline
- slow simulator matrix tests should run a representative smoke subset by default; set `EASYASC_FULL_SIM_MATRIX=1` when you need the full branch/pipe matrix
- for synchronization or buffer-lifetime regressions, include shapes that exercise reuse across outer tiles on the same active core, not only small one-tile-per-core cases; for M-tiled attention kernels, check `ceil(BH * ceil(S1 / TILE_M) / core_count) > 1` so cross-tile UB source reuse is covered
