import contextlib
import io

from easyasc.a5 import *
from easyasc.parser.asc import translate_split


def _translate_silently(instructions, name: str):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        return translate_split(instructions, name)


@kernel()
def int64_ctor_override_kernel(y: GMTensor):
    a = Var(0, name='a')
    b = Var(1, name='b')
    c = Var(a * b, DT.int64, name='c')
    kernel_print('c=%lld\\n', c)
    return y


@kernel()
def var_name_inherit_kernel(y: GMTensor):
    a = Var(2, name='a')
    tmp = a + 1
    kept = Var(tmp)
    kernel_print('kept=%d\\n', kept)
    return y


def test_var_ctor_overrides_existing_expr_dtype_for_codegen() -> None:
    y = GMTensor(DT.int64, [1, 1], name='y')
    int64_ctor_override_kernel(y)
    cube_code, vec_code = _translate_silently(int64_ctor_override_kernel.instructions, 'int64_ctor_override_kernel')
    code = cube_code + '\n' + vec_code
    assert 'int64_t c = a*b;' in code
    assert 'int c = a*b;' not in code


def test_var_ctor_without_name_keeps_wrapped_var_name() -> None:
    y = GMTensor(DT.int, [1, 1], name='y')
    var_name_inherit_kernel(y)
    cube_code, vec_code = _translate_silently(var_name_inherit_kernel.instructions, 'var_name_inherit_kernel')
    code = cube_code + '\n' + vec_code
    assert 'printf("kept=%d\\n", );' not in code
    assert 'int  =' not in code
