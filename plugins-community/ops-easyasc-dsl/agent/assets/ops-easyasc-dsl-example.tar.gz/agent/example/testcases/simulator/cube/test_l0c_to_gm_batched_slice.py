import torch

from easyasc import globvars
from easyasc.a5 import *


TILE = 16
OUT = 64
SHAPE_BINDINGS = {
    0: [0, None, None],
    1: [0, None, None],
    2: [0, None, None],
}


@kernel()
def _batched_l0c_to_gm_slice_kernel(x: GMTensor, y: GMTensor, out: GMTensor, batches: Var):
    l1x = DBuff(DT.float, [TILE, TILE], Position.L1)
    l1y = DBuff(DT.float, [TILE, TILE], Position.L1)
    l0c = DBuff(DT.float, [TILE, TILE], Position.L0C)

    per_core = CeilDiv(batches, GetCubeNum())
    begin = Var(per_core * GetCubeIdx())
    end = Min(begin + per_core, batches)
    cnt = Var(0)

    with auto_sync():
        for batch in range(begin, end):
            l1x[cnt] <<= x[batch, 0:TILE, 0:TILE]
            l1y[cnt] <<= y[batch, 0:TILE, 0:TILE]
            matmul(l0c[cnt], l1x[cnt], l1y[cnt].T, m=TILE, n=TILE, k=TILE)
            out[batch, TILE:2 * TILE, 0:TILE] <<= l0c[cnt][0:TILE, 0:TILE]
            cnt += 1

    return out


@kernel()
def _l0c_to_gm_source_slice_kernel(x: GMTensor, y: GMTensor, out: GMTensor, batches: Var):
    l1x = DBuff(DT.float, [TILE, TILE], Position.L1)
    l1y = DBuff(DT.float, [TILE, TILE], Position.L1)
    l0c = DBuff(DT.float, [TILE, TILE], Position.L0C)

    per_core = CeilDiv(batches, GetCubeNum())
    begin = Var(per_core * GetCubeIdx())
    end = Min(begin + per_core, batches)
    cnt = Var(0)

    with auto_sync():
        for batch in range(begin, end):
            l1x[cnt] <<= x[batch, 0:TILE, 0:TILE]
            l1y[cnt] <<= y[batch, 0:TILE, 0:TILE]
            matmul(l0c[cnt], l1x[cnt], l1y[cnt].T, m=TILE, n=TILE, k=TILE)
            out[batch, 0:1, 0:TILE] <<= l0c[cnt][2:3, 0:TILE]
            cnt += 1

    return out


def test_l0c_to_gm_supports_batched_2d_slice_with_row_stride(tmp_path):
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        batches = 2
        torch.manual_seed(0)
        x = torch.randn((batches, TILE, TILE), dtype=torch.float32)
        y = torch.eye(TILE, dtype=torch.float32).expand(batches, TILE, TILE).contiguous()
        out = torch.zeros((batches, OUT, OUT), dtype=torch.float32)

        got = OpExec(
            _batched_l0c_to_gm_slice_kernel,
            out_dir=str(tmp_path / "l0c_to_gm_batched_slice"),
            simulator=True,
        )(x, y, out, batches, shape_bindings=SHAPE_BINDINGS)

        torch.testing.assert_close(got[:, TILE:2 * TILE, 0:TILE], x, rtol=1e-5, atol=1e-5)
    finally:
        globvars.device_type = saved_device_type


def test_l0c_to_gm_reads_nonzero_l0c_source_slice(tmp_path):
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        batches = 2
        torch.manual_seed(0)
        x = torch.randn((batches, TILE, TILE), dtype=torch.float32)
        y = torch.eye(TILE, dtype=torch.float32).expand(batches, TILE, TILE).contiguous()
        out = torch.zeros((batches, OUT, OUT), dtype=torch.float32)

        got = OpExec(
            _l0c_to_gm_source_slice_kernel,
            out_dir=str(tmp_path / "l0c_to_gm_source_slice"),
            simulator=True,
        )(x, y, out, batches, shape_bindings=SHAPE_BINDINGS)

        torch.testing.assert_close(got[:, 0:1, 0:TILE], x[:, 2:3, :], rtol=1e-5, atol=1e-5)
    finally:
        globvars.device_type = saved_device_type
