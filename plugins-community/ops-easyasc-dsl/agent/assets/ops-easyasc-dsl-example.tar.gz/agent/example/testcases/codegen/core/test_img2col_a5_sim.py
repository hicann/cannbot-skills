"""Simulator tests for a5/950 l1_to_l0a_img2col: multi-C0 and kernel>1 conv.

a5 load3d materializes one C0 K-fractal per call, so the L12L0A_IMG2COL helper
loops the C0 chunks; a single l1_to_l0a_img2col(kext>C0) + one mmad then reproduces
the full img2col window. These cases drive the real DSL helper through
OpExec(simulator=True) on a5 (conftest sets device_type=950 from the a5 import) and
compare the conv result to torch.conv2d. The same shapes were also validated
on real A5 hardware during bring-up; here we lock in the simulator NZ L0A
model.
"""
import torch

from easyasc.a5 import *
from easyasc.parser.asc import split_instructions
from easyasc.parser.asc_autosync import insert_auto_sync
from easyasc.stub_functions import l1_to_l0a_img2col

C0 = 16  # bf16

# --- Case A: 1x1 conv, C=32 -> K=32 spans two C0 channel blocks (kext > C0) ---
A_C, A_H, A_W, A_COUT = 32, 4, 4, 64
A_C1 = A_C // C0
A_M = A_H * A_W
A_M_PAD = (A_M + 15) // 16 * 16
A_K = A_C1 * 1 * 1 * C0  # 32


@kernel()
def _a5_img2col_1x1_c32(data: GMTensor, weight: GMTensor, out: GMTensor, nb: Var):
    conv = Conv2D(1, 1)
    fm = Tensor(DT.bfloat16, [A_C1 * A_H * A_W, C0], Position.L1)
    w_l1 = Tensor(DT.bfloat16, [A_COUT, A_K], Position.L1)
    l0a = Tensor(DT.bfloat16, [A_M_PAD, A_K], Position.L0A)
    l0b = Tensor(DT.bfloat16, [A_COUT, A_K], Position.L0B)
    l0c = Tensor(DT.float, [A_M_PAD, A_COUT], Position.L0C)
    acc = img2col(fm, conv, h=A_H, w=A_W, c=A_C)
    with auto_sync():
        fm <<= data[:, :]
        w_l1 <<= weight[:, :]
        l1_to_l0a_img2col(l0a, acc[0:A_M_PAD, 0:A_K])
        l1_to_l0(l0b, w_l1)
        mmad(l0c, l0a, l0b, M=A_M_PAD, N=A_COUT, K=A_K, is_init=True)
        l0c_to_gm_nz2nd(out, l0c, M=A_M_PAD, N=A_COUT, N_dst=A_COUT, M_src=A_M_PAD)
    return out


def test_a5_img2col_1x1_c32_matches_torch():
    g = torch.Generator().manual_seed(0)
    x = (torch.rand((1, A_C, A_H, A_W), generator=g) * 2 - 1).bfloat16()
    w = (torch.rand((A_COUT, A_C, 1, 1), generator=g) * 2 - 1).bfloat16()
    data = x.reshape(A_C1, C0, A_H, A_W).permute(0, 2, 3, 1).reshape(A_C1 * A_H * A_W, C0).contiguous()
    wz = w.reshape(A_COUT, A_C1, C0, 1, 1).permute(0, 1, 3, 4, 2).reshape(A_COUT, A_K).contiguous()
    out = torch.zeros((A_M_PAD, A_COUT), dtype=torch.float32)
    got = OpExec(_a5_img2col_1x1_c32, simulator=True)(data, wz, out, 1)
    ref = torch.nn.functional.conv2d(x.float(), w.float()).reshape(A_COUT, A_M).t()
    assert torch.allclose(got[:A_M], ref, rtol=3e-2, atol=3e-2), float((got[:A_M] - ref).abs().max())
    assert torch.all(got[A_M:] == 0)


# --- Case B: 3x3 conv, C=16 -> K=144 (nine C0 K-fractals from filter taps).
# H*W stays 16-aligned (32) so the NC1HWC0 fmap loads via nd2nz without padding. ---
B_C, B_H, B_W, B_COUT = 16, 4, 8, 32
B_C1 = (B_C + C0 - 1) // C0
B_KH = B_KW = 3
B_HO = B_H - B_KH + 1
B_WO = B_W - B_KW + 1
B_M = B_HO * B_WO
B_M_PAD = (B_M + 15) // 16 * 16
B_K = B_C1 * B_KH * B_KW * C0  # 144


@kernel()
def _a5_img2col_3x3_c16(data: GMTensor, weight: GMTensor, out: GMTensor, nb: Var):
    conv = Conv2D(B_KH, B_KW)
    fm = Tensor(DT.bfloat16, [B_C1 * B_H * B_W, C0], Position.L1)
    w_l1 = Tensor(DT.bfloat16, [B_COUT, B_K], Position.L1)
    l0a = Tensor(DT.bfloat16, [B_M_PAD, B_K], Position.L0A)
    l0b = Tensor(DT.bfloat16, [B_COUT, B_K], Position.L0B)
    l0c = Tensor(DT.float, [B_M_PAD, B_COUT], Position.L0C)
    acc = img2col(fm, conv, h=B_H, w=B_W, c=B_C)
    with auto_sync():
        fm <<= data[:, :]
        w_l1 <<= weight[:, :]
        l1_to_l0a_img2col(l0a, acc[0:B_M_PAD, 0:B_K])
        l1_to_l0(l0b, w_l1)
        mmad(l0c, l0a, l0b, M=B_M_PAD, N=B_COUT, K=B_K, is_init=True)
        l0c_to_gm_nz2nd(out, l0c, M=B_M_PAD, N=B_COUT, N_dst=B_COUT, M_src=B_M_PAD)
    return out


def test_a5_img2col_3x3_c16_matches_torch():
    g = torch.Generator().manual_seed(1)
    x = (torch.rand((1, B_C, B_H, B_W), generator=g) * 2 - 1).bfloat16()
    w = (torch.rand((B_COUT, B_C, B_KH, B_KW), generator=g) * 2 - 1).bfloat16()
    data = x.reshape(B_C1, C0, B_H, B_W).permute(0, 2, 3, 1).reshape(B_C1 * B_H * B_W, C0).contiguous()
    wz = w.reshape(B_COUT, B_C1, C0, B_KH, B_KW).permute(0, 1, 3, 4, 2).reshape(B_COUT, B_K).contiguous()
    out = torch.zeros((B_M_PAD, B_COUT), dtype=torch.float32)
    got = OpExec(_a5_img2col_3x3_c16, simulator=True)(data, wz, out, 1)
    ref = torch.nn.functional.conv2d(x.float(), w.float()).reshape(B_COUT, B_M).t()
    assert torch.allclose(got[:B_M], ref, rtol=3e-2, atol=3e-2), float((got[:B_M] - ref).abs().max())
    assert torch.all(got[B_M:] == 0)


def test_a5_conv_half_bias_reuses_single_l0_event_family():
    from kernels.a5.conv.compute.conv_half_bias import (
        C0 as V_C0,
        C1O as V_C1O,
        C1_MAX as V_C1_MAX,
        COUT_P as V_COUT_P,
        COUT_MAX as V_COUT_MAX,
        H_MAX as V_H_MAX,
        W_MAX as V_W_MAX,
        conv_half_bias,
    )

    data = GMTensor(DT.half, [V_C1_MAX * V_H_MAX * V_W_MAX, V_C0])
    weight = GMTensor(DT.half, [V_COUT_P, 288])
    bias = GMTensor(DT.float, [1, V_COUT_P])
    out = GMTensor(DT.float, [V_C1O * 64, V_C0])
    conv_half_bias(data, weight, bias, out, Var(V_H_MAX), Var(V_W_MAX), Var(31), Var(V_COUT_MAX - 1), Var(64))

    cube_insts, _ = split_instructions(list(conv_half_bias.instructions))
    cube_insts = insert_auto_sync(cube_insts, mode="cube")
    valid_l0_names = {
        inst.kwargs["val"].name
        for inst in cube_insts
        if inst.opname == "create_devent"
        and inst.kwargs["val"].name.startswith("_tmp_devent_valid_l0_")
    }
    assert valid_l0_names == {"_tmp_devent_valid_l0_0"}
