import torch

from easyasc.a2 import *


@kernel()
def _shiftleft_int16(src: GMTensor, out: GMTensor, contract: Var):
    src_ub = Tensor(DT.int16, [1, 128], Position.UB)
    out_ub = Tensor(DT.int16, [1, 128], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            src_ub <<= src[0:1, 0:128]
            shiftls(out_ub, src_ub, contract, count=128)
            out[0:1, 0:128] <<= out_ub
    return out


@kernel()
def _shiftleft_uint16(src: GMTensor, out: GMTensor, contract: Var):
    src_ub = Tensor(DT.uint16, [1, 128], Position.UB)
    out_ub = Tensor(DT.uint16, [1, 128], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            src_ub <<= src[0:1, 0:128]
            shiftls(out_ub, src_ub, 3, repeat=1, count_per_rep=128)
            out[0:1, 0:128] <<= out_ub
    return out


@kernel()
def _shiftright_int32_round(src: GMTensor, out: GMTensor, contract: Var):
    src_ub = Tensor(DT.int, [1, 64], Position.UB)
    out_ub = Tensor(DT.int, [1, 64], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            src_ub <<= src[0:1, 0:64]
            shiftrs(out_ub, src_ub, 5, repeat=1, count_per_rep=64, round_en=True)
            out[0:1, 0:64] <<= out_ub
    return out


@kernel()
def _shiftright_uint32(src: GMTensor, out: GMTensor, contract: Var):
    src_ub = Tensor(DT.uint32, [1, 64], Position.UB)
    out_ub = Tensor(DT.uint32, [1, 64], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            src_ub <<= src[0:1, 0:64]
            shiftrs(out_ub, src_ub, 4, count=64, round_en=True)
            out[0:1, 0:64] <<= out_ub
    return out


def test_sim_shiftleft_int16_matches_real_a2_full_width_bits() -> None:
    # Real A2 count and repeat modes both produce 0xAAAA -> 0x5554.
    src = torch.full((1, 128), -21846, dtype=torch.int16)
    got = OpExec(_shiftleft_int16, simulator=True)(src, torch.zeros_like(src), 1)
    expected = torch.full_like(src, 21844)
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


def test_sim_shiftleft_uint16_is_logical_and_width_limited() -> None:
    base = torch.tensor([0x0001, 0x1FFF, 0x8000, 0xFFFF], dtype=torch.uint16)
    src = base.repeat(32).reshape(1, 128)
    got = OpExec(_shiftleft_uint16, simulator=True)(src, torch.zeros_like(src), -1)
    expected = torch.bitwise_and(src.to(torch.int32) << 3, 0xFFFF).to(torch.uint16)
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


def test_sim_shiftright_int32_rounds_from_highest_discarded_bit() -> None:
    base = torch.tensor([47, 48, 49, -16, -17, -47, -48, -49], dtype=torch.int32)
    src = base.repeat(8).reshape(1, 64)
    got = OpExec(_shiftright_int32_round, simulator=True)(src, torch.zeros_like(src), -1)
    shifted = torch.bitwise_right_shift(src.to(torch.int64), 5)
    round_bit = torch.bitwise_and(torch.bitwise_right_shift(src.to(torch.int64), 4), 1)
    expected = (shifted + round_bit).to(torch.int32)
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


def test_sim_shiftright_uint32_is_logical_and_ignores_rounding_enable() -> None:
    base = torch.tensor([0, 1, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF], dtype=torch.uint32)
    src = base.repeat(13)[:64].reshape(1, 64)
    got = OpExec(_shiftright_uint32, simulator=True)(src, torch.zeros_like(src), -1)
    expected = torch.bitwise_right_shift(src.to(torch.int64), 4).to(torch.uint32)
    torch.testing.assert_close(got, expected, rtol=0, atol=0)
