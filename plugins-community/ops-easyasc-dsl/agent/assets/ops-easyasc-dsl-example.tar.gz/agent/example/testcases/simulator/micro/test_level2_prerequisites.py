"""Focused regressions for A5 CANN Bench Level-2 prerequisites."""

from types import SimpleNamespace

import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime


def test_b64_normal_codegen_and_block_copy_fence() -> None:
    @vf()
    def max_int64(src0: Tensor, src1: Tensor, dst: Tensor):
        lhs = Reg(DT.int64, name="lhs")
        rhs = Reg(DT.int64, name="rhs")
        out = Reg(DT.int64, name="out")
        lhs <<= src0[0:1, 0:32]
        rhs <<= src1[0:1, 0:32]
        vmax(out, lhs, rhs)
        dst[0:1, 0:32] <<= out

    src0 = Tensor(DT.int64, [1, 32], Position.UB)
    src1 = Tensor(DT.int64, [1, 32], Position.UB)
    dst = Tensor(DT.int64, [1, 32], Position.UB)
    max_int64(src0, src1, dst)
    code = translate(max_int64.instructions)

    assert "MicroAPI::LoadAlign<int64_t, MicroAPI::LoadDist::DIST_NORM>" in code
    assert "MicroAPI::Max(" in code
    assert "MicroAPI::StoreAlign<int64_t, MicroAPI::StoreDist::DIST_NORM>" in code
    assert "MicroAPI::DataCopyMode::DATA_BLOCK_COPY" not in code

    @vf()
    def invalid_block_copy(src: Tensor, out: Tensor):
        reg = Reg(DT.int64)
        ub_to_reg(reg, src)
        reg_to_ub(out, reg)

    with pytest.raises(ValueError, match="DATA_BLOCK_COPY only supports b8/b16/b32"):
        invalid_block_copy(src0, dst)


def test_trait_two_int32_to_int64_codegen() -> None:
    @vf()
    def widen_indices(src: Tensor, dst: Tensor):
        src_reg = Reg(DT.int, name="src_reg")
        dst_reg = Reg(DT.int64, name="dst_reg", reg_num=2)
        active = MaskReg(
            DT.int64, init_mode=MaskType.LOWEST32,
            name="active", reg_num=2,
        )
        config = CastConfig(
            round_mode=RoundMode.NONE, reg_layout=RegLayout.ZERO,
            name="widen",
        )
        ub_to_reg(src_reg, src)
        cast(dst_reg, src_reg, config, mask=active)
        reg_to_ub_normal(dst, dst_reg, mask=active)

    src = Tensor(DT.int, [1, 64], Position.UB)
    dst = Tensor(DT.int64, [1, 64], Position.UB)
    widen_indices(src, dst)
    code = translate(widen_indices.instructions)

    assert "MicroAPI::RegTensor<int64_t, MicroAPI::RegTraitNumTwo> dst_reg;" in code
    assert (
        "MicroAPI::CreateMask<int64_t, MicroAPI::MaskPattern::VL32, "
        "MicroAPI::RegTraitNumTwo>()" in code
    )
    assert "MicroAPI::Cast<int64_t, int," in code
    assert "MicroAPI::StoreAlign<int64_t, MicroAPI::StoreDist::DIST_NORM>" in code


def test_b64_simulator_vmax_preserves_extrema_and_tail_mask() -> None:
    lhs_values = torch.tensor(
        [-(2 ** 63), 2 ** 63 - 1, 2 ** 53 + 1, -(2 ** 53 + 1)] * 8,
        dtype=torch.int64,
    )
    rhs_values = torch.tensor(
        [2 ** 63 - 1, -(2 ** 63), 2 ** 53, -(2 ** 53)] * 8,
        dtype=torch.int64,
    )
    destination = torch.full((32,), -777, dtype=torch.int64)
    runtime = MicroRuntime()
    lhs_reg = Reg(DT.int64, name="lhs_reg")
    rhs_reg = Reg(DT.int64, name="rhs_reg")
    out_reg = Reg(DT.int64, name="out_reg")
    active = MaskReg(DT.int64, init_mode=MaskType.NONE, name="active")
    lhs_ub = SimpleNamespace(name="lhs_ub")
    rhs_ub = SimpleNamespace(name="rhs_ub")
    dst_ub = SimpleNamespace(name="dst_ub")
    mask = torch.arange(32) < 29
    context = MicroContext(
        masks={"active": mask},
        tensor_views={
            "lhs_ub": lhs_values,
            "rhs_ub": rhs_values,
            "dst_ub": destination,
        },
    )

    runtime._stack.append(context)
    try:
        runtime._dispatch(
            "micro_ub2regcont",
            {"dst": lhs_reg, "src": lhs_ub, "mode": "DIST_NORM"},
            SharedMemoryStore(),
        )
        runtime._dispatch(
            "micro_ub2regcont",
            {"dst": rhs_reg, "src": rhs_ub, "mode": "DIST_NORM"},
            SharedMemoryStore(),
        )
        runtime._dispatch(
            "micro_vmax",
            {"dst": out_reg, "src1": lhs_reg, "src2": rhs_reg, "mask": active},
            SharedMemoryStore(),
        )
        runtime._dispatch(
            "micro_reg2ubcont",
            {"dst": dst_ub, "src": out_reg, "mode": "DIST_NORM", "mask": active},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = torch.full((32,), -777, dtype=torch.int64)
    expected[:29] = torch.maximum(lhs_values, rhs_values)[:29]
    assert torch.equal(context.tensor_views["dst_ub"], expected)


def test_trait_two_simulator_cast_preserves_all_lanes() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.int, name="src")
    dst = Reg(DT.int64, name="dst", reg_num=2)
    mask = MaskReg(DT.int64, init_mode=MaskType.ALL, name="mask", reg_num=2)
    config = CastConfig(
        round_mode=RoundMode.NONE, reg_layout=RegLayout.ZERO,
        name="widen",
    )
    values = torch.arange(-32, 32, dtype=torch.int32)
    context = MicroContext(
        regs={"src": values, "dst": torch.zeros(64, dtype=torch.int64)},
        masks={"mask": torch.ones(64, dtype=torch.bool)},
    )

    runtime._stack.append(context)
    try:
        runtime._dispatch(
            "micro_cast",
            {"dst": dst, "src": src, "config": config, "mask": mask, "ddst": DT.int64},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    torch.testing.assert_close(
        context.regs["dst"], values.to(torch.int64), rtol=0, atol=0,
    )
