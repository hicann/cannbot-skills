import pytest

from easyasc import globvars
from easyasc.simulator import ControlInstruction, KernelProgram, LaneProgram, SharedTensorSpec, SimulatorConfig
from easyasc.simulator.simulator import Simulator


def _hazard_program(with_barrier: bool = False) -> KernelProgram:
    instructions = [
        ControlInstruction(
            "dup",
            pipe_name="V",
            args={
                "dst": "ub_value",
                "repeat": 1,
                "dst_blk_stride": 1,
                "dst_rep_stride": 8,
                "src": 1.0,
            },
        ),
    ]
    if with_barrier:
        instructions.append(ControlInstruction("bar_all", args={}))
    instructions.append(
        ControlInstruction(
            "ub_to_gm_pad",
            pipe_name="MTE3",
            args={
                "dst": "out",
                "src": "ub_value",
                "n_burst": 1,
                "burst_len_byte": 1024,
                "dst_stride_byte": 0,
                "src_stride": 0,
            },
        )
    )
    return KernelProgram(
        name="local_memory_hazard_probe",
        core_count=1,
        lane_programs=[
            LaneProgram(lane_name="vec0", pipe_names=["MTE2", "V", "MTE3"], instructions=instructions),
        ],
        metadata={
            "tensor_specs": [
                SharedTensorSpec(name="ub_value", shape=(256,), dtype="float32", role="ub").to_dict(),
                SharedTensorSpec(name="out", shape=(256,), dtype="float32", role="output").to_dict(),
            ],
        },
    )


def _source_reuse_program() -> KernelProgram:
    return KernelProgram(
        name="local_memory_source_reuse_probe",
        core_count=1,
        lane_programs=[
            LaneProgram(
                lane_name="vec0",
                pipe_names=["MTE2", "V", "MTE3"],
                instructions=[
                    ControlInstruction(
                        "ub_to_gm_pad",
                        pipe_name="MTE3",
                        args={
                            "dst": "out",
                            "src": "ub_value",
                            "n_burst": 1,
                            "burst_len_byte": 1024,
                            "dst_stride_byte": 0,
                            "src_stride": 0,
                        },
                    ),
                    ControlInstruction("bar_all", args={}),
                    ControlInstruction(
                        "dup",
                        pipe_name="V",
                        args={
                            "dst": "ub_value",
                            "repeat": 1,
                            "dst_blk_stride": 1,
                            "dst_rep_stride": 8,
                            "src": 1.0,
                        },
                    ),
                ],
            ),
        ],
        metadata={
            "tensor_specs": [
                SharedTensorSpec(name="ub_value", shape=(256,), dtype="float32", role="ub").to_dict(),
                SharedTensorSpec(name="out", shape=(256,), dtype="float32", role="output").to_dict(),
            ],
        },
    )


def _bandwidth_gap_program(delay_ops: int = 30) -> KernelProgram:
    instructions = [
        ControlInstruction(
            "ub_to_gm_pad",
            pipe_name="MTE3",
            args={
                "dst": "out",
                "src": "ub_value",
                "n_burst": 1,
                "burst_len_byte": 1024,
                "dst_stride_byte": 0,
                "src_stride": 0,
            },
        ),
    ]
    for _ in range(delay_ops):
        instructions.append(
            ControlInstruction(
                "dup",
                pipe_name="V",
                args={
                    "dst": "ub_scratch",
                    "repeat": 1,
                    "dst_blk_stride": 1,
                    "dst_rep_stride": 8,
                    "src": 2.0,
                },
            )
        )
    instructions.append(
        ControlInstruction(
            "dup",
            pipe_name="V",
            args={
                "dst": "ub_value",
                "repeat": 1,
                "dst_blk_stride": 1,
                "dst_rep_stride": 8,
                "src": 1.0,
            },
        )
    )
    return KernelProgram(
        name="local_memory_bandwidth_gap_probe",
        core_count=1,
        lane_programs=[
            LaneProgram(lane_name="vec0", pipe_names=["MTE2", "V", "MTE3"], instructions=instructions),
        ],
        metadata={
            "tensor_specs": [
                SharedTensorSpec(name="ub_value", shape=(256,), dtype="float32", role="ub").to_dict(),
                SharedTensorSpec(
                    name="ub_scratch", shape=(256,), dtype="float32", role="ub", storage_offset_bytes=1024,
                ).to_dict(),
                SharedTensorSpec(name="out", shape=(256,), dtype="float32", role="output").to_dict(),
            ],
        },
    )


def _l1_mte3_mte1_program() -> KernelProgram:
    return KernelProgram(
        name="local_memory_l1_ownership_probe",
        core_count=1,
        lane_programs=[
            LaneProgram(
                lane_name="vec0",
                pipe_names=["MTE3"],
                instructions=[
                    ControlInstruction(
                        "ub_to_l1",
                        pipe_name="MTE3",
                        args={
                            "dst": "l1_value",
                            "src": "ub_value",
                            "n_burst": 1,
                            "burst_len": 16,
                            "src_stride": 0,
                            "dst_stride": 0,
                        },
                    ),
                ],
            ),
            LaneProgram(
                lane_name="cube",
                pipe_names=["MTE1"],
                instructions=[
                    ControlInstruction(
                        "l1_to_l0",
                        pipe_name="MTE1",
                        args={
                            "dst": "l0a_value",
                            "src": "l1_value",
                            "m_dst": 16,
                            "n_dst": 16,
                            "m_src": 16,
                            "n_src": 16,
                            "dst_position": "L0A",
                        },
                    ),
                ],
            ),
        ],
        metadata={
            "tensor_specs": [
                SharedTensorSpec(name="ub_value", shape=(256,), dtype="float16", role="ub").to_dict(),
                SharedTensorSpec(name="l1_value", shape=(256,), dtype="float16", role="l1").to_dict(),
                SharedTensorSpec(name="l0a_value", shape=(256,), dtype="float16", role="l0a").to_dict(),
            ],
        },
    )


def _l0c_fix_v_program() -> KernelProgram:
    return KernelProgram(
        name="local_memory_l0c_to_ub_ownership_probe",
        core_count=1,
        lane_programs=[
            LaneProgram(
                lane_name="cube",
                pipe_names=["FIX"],
                instructions=[
                    ControlInstruction(
                        "l0c_to_ub",
                        pipe_name="FIX",
                        args={
                            "dst": "ub_value",
                            "src": "l0c_value",
                            "M": 16,
                            "N": 16,
                            "M_src": 16,
                            "dual_mode": 0,
                            "sub_block_id": 0,
                        },
                    ),
                ],
            ),
            LaneProgram(
                lane_name="vec0",
                pipe_names=["V"],
                instructions=[
                    ControlInstruction(
                        "dup",
                        pipe_name="V",
                        args={
                            "dst": "ub_value",
                            "repeat": 1,
                            "dst_blk_stride": 1,
                            "dst_rep_stride": 8,
                            "src": 1.0,
                        },
                    ),
                ],
            ),
        ],
        metadata={
            "tensor_specs": [
                SharedTensorSpec(name="l0c_value", shape=(256,), dtype="float32", role="l0c").to_dict(),
                SharedTensorSpec(name="ub_value", shape=(256,), dtype="float32", role="ub").to_dict(),
            ],
        },
    )


def test_local_memory_hazard_checker_rejects_unsynced_cross_pipe_reuse() -> None:
    sim = Simulator(
        config=SimulatorConfig(
            core_count=1,
            execution_timeout_s=5.0,
            process_start_method="fork",
            local_memory_hazard_check="error",
        )
    )

    with pytest.raises(RuntimeError, match="UB V->MTE3"):
        sim.run(_hazard_program(with_barrier=False))


def test_local_memory_hazard_checker_accepts_bar_all_drain() -> None:
    sim = Simulator(
        config=SimulatorConfig(
            core_count=1,
            execution_timeout_s=5.0,
            process_start_method="fork",
            local_memory_hazard_check="error",
        )
    )

    sim.run(_hazard_program(with_barrier=True))

    bandwidth_stress = Simulator(
        config=SimulatorConfig(
            core_count=1,
            execution_timeout_s=5.0,
            process_start_method="fork",
            local_memory_hazard_check="error",
            local_memory_hazard_memory_cycle_scale=3.0,
        )
    )
    bandwidth_stress.run(_hazard_program(with_barrier=True))


def test_local_memory_hazard_checker_accepts_post_consumer_reuse() -> None:
    sim = Simulator(
        config=SimulatorConfig(
            core_count=1,
            execution_timeout_s=5.0,
            process_start_method="fork",
            local_memory_hazard_check="error",
        )
    )

    sim.run(_source_reuse_program())


def test_local_memory_hazard_checker_rejects_l1_mte3_mte1_overlap(monkeypatch) -> None:
    monkeypatch.setattr(globvars, "device_type", "950", raising=False)
    sim = Simulator(
        config=SimulatorConfig(
            core_count=1,
            execution_timeout_s=5.0,
            process_start_method="fork",
            local_memory_hazard_check="error",
        )
    )

    with pytest.raises(RuntimeError, match="L1 MTE3->MTE1"):
        sim.run(_l1_mte3_mte1_program())


def test_local_memory_hazard_checker_rejects_l0c_fix_v_overlap(monkeypatch) -> None:
    monkeypatch.setattr(globvars, "device_type", "950", raising=False)
    sim = Simulator(
        config=SimulatorConfig(
            core_count=1,
            execution_timeout_s=5.0,
            process_start_method="fork",
            local_memory_hazard_check="error",
        )
    )

    with pytest.raises(RuntimeError, match="UB FIX->V"):
        sim.run(_l0c_fix_v_program())


def test_local_memory_hazard_checker_can_stress_memory_bandwidth_cycles() -> None:
    baseline = Simulator(
        config=SimulatorConfig(
            core_count=1,
            execution_timeout_s=5.0,
            process_start_method="fork",
            local_memory_hazard_check="error",
        )
    )
    baseline.run(_bandwidth_gap_program())

    sim = Simulator(
        config=SimulatorConfig(
            core_count=1,
            execution_timeout_s=5.0,
            process_start_method="fork",
            local_memory_hazard_check="error",
            local_memory_hazard_memory_cycle_scale=3.0,
        )
    )

    with pytest.raises(RuntimeError, match="UB V->MTE3"):
        sim.run(_bandwidth_gap_program())
