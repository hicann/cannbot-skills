import pytest

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


def _make_mergesort4_tensors(
    *,
    dst_pos=Position.UB,
    src_pos=Position.UB,
    dst_dtype=DT.float,
    src_dtype=DT.float,
):
    dst = Tensor(dst_dtype, [1, 256], dst_pos)
    src = Tensor(src_dtype, [1, 256], src_pos)
    return dst, src


def test_mergesort4_rejects_non_tensor_inputs() -> None:
    dst, src = _make_mergesort4_tensors()
    with pytest.raises(TypeError, match="dst must be Tensor"):
        mergesort4("bad", src, 32, 1)  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="src must be Tensor"):
        mergesort4(dst, "bad", 32, 1)  # type: ignore[arg-type]


def test_mergesort4_rejects_non_ub_tensors() -> None:
    dst, src = _make_mergesort4_tensors(dst_pos=Position.L1)
    with pytest.raises(ValueError, match="dst must be at UB position"):
        mergesort4(dst, src, 32, 1)

    dst, src = _make_mergesort4_tensors(src_pos=Position.L1)
    with pytest.raises(ValueError, match="src must be at UB position"):
        mergesort4(dst, src, 32, 1)


def test_mergesort4_requires_float_src_and_dst() -> None:
    dst, src = _make_mergesort4_tensors(dst_dtype=DT.half, src_dtype=DT.half)
    with pytest.raises(ValueError, match="only supports float dtype"):
        mergesort4(dst, src, 32, 1)

    dst, src = _make_mergesort4_tensors(dst_dtype=DT.float, src_dtype=DT.half)
    with pytest.raises(ValueError, match="src/dst data types must match"):
        mergesort4(dst, src, 32, 1)


def test_mergesort4_rejects_invalid_length_or_repeat_types() -> None:
    dst, src = _make_mergesort4_tensors()
    with pytest.raises(TypeError, match="length_per_seq must be Var or int"):
        mergesort4(dst, src, 1.5, 1)  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="repeat must be Var or int"):
        mergesort4(dst, src, 32, 1.5)  # type: ignore[arg-type]


def test_mergesort4_rejects_invalid_ranges() -> None:
    dst, src = _make_mergesort4_tensors()
    with pytest.raises(ValueError, match="length_per_seq must be positive"):
        mergesort4(dst, src, 0, 1)
    with pytest.raises(ValueError, match="length_per_seq must be positive"):
        mergesort4(dst, src, -1, 1)
    with pytest.raises(ValueError, match="repeat must be non-negative"):
        mergesort4(dst, src, 32, -1)


def test_mergesort4_requires_explicit_args() -> None:
    dst, src = _make_mergesort4_tensors()
    with pytest.raises(TypeError):
        mergesort4(dst, src)  # type: ignore[call-arg]
    with pytest.raises(TypeError):
        mergesort4(dst, src, 32)  # type: ignore[call-arg]


def test_mergesort4_instruction_capture() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [1, 256], Position.UB)
        src = Tensor(DT.float, [1, 256], Position.UB)
        mergesort4(dst, src, 32, 2)
        return inp

    inp = GMTensor(DT.float, [1, 1])
    stub_only(inp)
    found = [inst for inst in stub_only.instructions if inst.opname == "mergesort4"]
    assert len(found) == 1
    assert found[0].kwargs["length_per_seq"] == 32
    assert found[0].kwargs["repeat"] == 2


def test_mergesort4_codegen_emits_vec_side_call() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [1, 256], Position.UB)
        src = Tensor(DT.float, [1, 256], Position.UB)
        mergesort4(dst, src, 32, 1)
        return inp

    inp = GMTensor(DT.float, [1, 1])
    stub_only(inp)
    cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_mergesort4_codegen")
    assert "MERGESORT4(" not in cube_code
    assert "MERGESORT4(" in vec_code
