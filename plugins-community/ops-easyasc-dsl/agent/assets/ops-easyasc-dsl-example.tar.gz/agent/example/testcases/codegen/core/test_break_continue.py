import builtins as _builtins
import os

import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate_split

_builtin_range = _builtins.range

ROWS = 1
COLS = 64
FULL_SIM_MATRIX = os.environ.get("EASYASC_FULL_SIM_MATRIX") == "1"

BREAK_SIM_CASES = (
    [
        pytest.param(0, id="limit_0"),
        pytest.param(3, id="limit_3"),
        pytest.param(20, id="limit_exceeds_loop"),
    ]
    if FULL_SIM_MATRIX
    else [pytest.param(3, id="limit_3")]
)
CONTINUE_SIM_CASES = (
    [
        pytest.param(1, id="skip_1"),
        pytest.param(99, id="skip_out_of_range"),
    ]
    if FULL_SIM_MATRIX
    else [pytest.param(1, id="skip_1")]
)


@vf()
def _add_one_vf(src: Tensor, dst: Tensor):
    reg = Reg(DT.float)
    reg <<= src[0:ROWS, 0:COLS]
    reg <<= reg + 1.0
    dst[0:ROWS, 0:COLS] <<= reg


@vf()
def _copy_vf(src: Tensor, dst: Tensor):
    reg = Reg(DT.float)
    reg <<= src[0:ROWS, 0:COLS]
    dst[0:ROWS, 0:COLS] <<= reg


@kernel()
def _break_loop_kernel(x: GMTensor, y: GMTensor, limit: Var):
    ub_a = DBuff(DT.float, [ROWS, COLS], Position.UB)
    ub_b = DBuff(DT.float, [ROWS, COLS], Position.UB)
    cnt = Var(0)
    with auto_sync():
        ub_a[cnt] <<= x[0:ROWS, 0:COLS]
        for i in range(0, 10):
            if i >= limit:
                break
            _add_one_vf(ub_a[cnt], ub_b[cnt])
            _copy_vf(ub_b[cnt], ub_a[cnt])
        y[0:ROWS, 0:COLS] <<= ub_a[cnt]
    return y


@kernel()
def _continue_loop_kernel(x: GMTensor, y: GMTensor, skip_val: Var):
    ub_a = DBuff(DT.float, [ROWS, COLS], Position.UB)
    ub_b = DBuff(DT.float, [ROWS, COLS], Position.UB)
    cnt = Var(0)
    with auto_sync():
        ub_a[cnt] <<= x[0:ROWS, 0:COLS]
        for i in range(0, 4):
            if i == skip_val:
                continue
            _add_one_vf(ub_a[cnt], ub_b[cnt])
            _copy_vf(ub_b[cnt], ub_a[cnt])
        y[0:ROWS, 0:COLS] <<= ub_a[cnt]
    return y


@kernel()
def _nested_break_kernel(x: GMTensor, y: GMTensor, contract: Var):
    ub_a = DBuff(DT.float, [ROWS, COLS], Position.UB)
    ub_b = DBuff(DT.float, [ROWS, COLS], Position.UB)
    cnt = Var(0)
    with auto_sync():
        ub_a[cnt] <<= x[0:ROWS, 0:COLS]
        for i in range(0, 4):
            for j in range(0, 4):
                if j >= 2:
                    break
                _add_one_vf(ub_a[cnt], ub_b[cnt])
                _copy_vf(ub_b[cnt], ub_a[cnt])
        y[0:ROWS, 0:COLS] <<= ub_a[cnt]
    return y


def _run_break(limit: int):
    x = torch.zeros(ROWS, COLS, dtype=torch.float32)
    y = torch.zeros_like(x)
    out = OpExec(_break_loop_kernel, simulator=True)(x, y, limit)
    ref = x + float(min(limit, 10))
    return out, ref


def _run_continue(skip_val: int):
    x = torch.zeros(ROWS, COLS, dtype=torch.float32)
    y = torch.zeros_like(x)
    out = OpExec(_continue_loop_kernel, simulator=True)(x, y, skip_val)
    count = sum(1 for i in _builtin_range(4) if i != skip_val)
    ref = x + float(count)
    return out, ref


def _run_nested_break():
    x = torch.zeros(ROWS, COLS, dtype=torch.float32)
    y = torch.zeros_like(x)
    out = OpExec(_nested_break_kernel, simulator=True)(x, y, -1)
    ref = x + 8.0
    return out, ref


# ---- Instruction recording ----

def test_break_emits_break_loop_instruction():
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _break_loop_kernel(x, y, Var(3))
    opnames = [inst.opname for inst in _break_loop_kernel.instructions]
    assert "break_loop" in opnames


def test_continue_emits_continue_loop_instruction():
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _continue_loop_kernel(x, y, Var(1))
    opnames = [inst.opname for inst in _continue_loop_kernel.instructions]
    assert "continue_loop" in opnames


# ---- Codegen ----

def test_break_codegen_emits_break_statement():
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _break_loop_kernel(x, y, Var(3))
    _, vec_code = translate_split(_break_loop_kernel.instructions, "break_codegen")
    assert "break;" in vec_code


def test_continue_codegen_emits_continue_statement():
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _continue_loop_kernel(x, y, Var(1))
    _, vec_code = translate_split(_continue_loop_kernel.instructions, "continue_codegen")
    assert "continue;" in vec_code


# ---- Simulator ----

@pytest.mark.parametrize("limit", BREAK_SIM_CASES)
def test_break_simulator(limit):
    out, ref = _run_break(limit)
    torch.testing.assert_close(out, ref, rtol=1e-4, atol=1e-4)


@pytest.mark.parametrize("skip_val", CONTINUE_SIM_CASES)
def test_continue_simulator(skip_val):
    out, ref = _run_continue(skip_val)
    torch.testing.assert_close(out, ref, rtol=1e-4, atol=1e-4)


def test_nested_break_simulator():
    out, ref = _run_nested_break()
    torch.testing.assert_close(out, ref, rtol=1e-4, atol=1e-4)


# ---- unroll() forbids break / continue / if ----

def test_unroll_break_raises():
    with pytest.raises(SyntaxError, match="break.*unroll"):
        @kernel()
        def bad_kernel(x: GMTensor, y: GMTensor):
            ub = Tensor(DT.float, [1, 64], Position.UB)
            for i in unroll(10):
                break
            return y


def test_unroll_continue_raises():
    with pytest.raises(SyntaxError, match="continue.*unroll"):
        @kernel()
        def bad_kernel(x: GMTensor, y: GMTensor):
            ub = Tensor(DT.float, [1, 64], Position.UB)
            for i in unroll(4):
                continue
            return y


def test_unroll_if_raises():
    with pytest.raises(SyntaxError, match="if.*unroll"):
        @kernel()
        def bad_kernel(x: GMTensor, y: GMTensor, flag: Var):
            ub = Tensor(DT.float, [1, 64], Position.UB)
            for i in unroll(4):
                if flag > 0:
                    ub <<= ub + 1.0
            return y


def test_unroll_nested_dsl_loop_allows_break_continue_if():
    @kernel()
    def ok_kernel(x: GMTensor, y: GMTensor, limit: Var):
        ub_a = DBuff(DT.float, [1, 64], Position.UB)
        ub_b = DBuff(DT.float, [1, 64], Position.UB)
        cnt = Var(0)
        ub_a[cnt] <<= x[0:1, 0:64]
        for i in unroll(2):
            for j in range(0, 10):
                if j >= limit:
                    break
        y[0:1, 0:64] <<= ub_a[cnt]
        return y

    x = GMTensor(DT.float, [1, 64])
    y = GMTensor(DT.float, [1, 64])
    ok_kernel(x, y, Var(3))
    opnames = [inst.opname for inst in ok_kernel.instructions]
    assert "break_loop" in opnames
    assert "start_if" in opnames
