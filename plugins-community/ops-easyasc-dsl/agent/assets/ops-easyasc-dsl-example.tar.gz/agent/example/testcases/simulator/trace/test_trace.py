import json

import torch

from easyasc import globvars
from easyasc.a5 import *
from easyasc.simulator.pipe import _record_intra_sync_stall
from easyasc.simulator.trace import TraceRecorder


BLK = 128
LANES = 4


@vf()
def simple_micro(x: Tensor, out: Tensor, n_loops: Var, N: Var):
    xreg = Reg(DT.float)
    for i in range(n_loops):
        xreg <<= x[i * 64]
        xreg <<= xreg.abs() + 1.0
        out[i * 64] <<= xreg


@kernel()
def cubefunc(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    # Producer: l0c_to_ub finishes on FIX. Consumer: simple_micro runs on V.
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    xbuf = DBuff(DT.float, [BLK // 2, N], Position.UB)
    outbuf = DBuff(DT.float, [BLK // 2, N], Position.UB)

    cnt = Var(0)

    m_per_core = CeilDiv(M, GetCubeNum())
    m1 = Var(m_per_core * GetCubeIdx())
    m2 = Min(m1 + m_per_core, M)

    with auto_sync():
        for m in range(m1, m2, BLK):
            l1x[cnt] <<= x[m:m + BLK, :]
            l1y[cnt] <<= y[:, :]
            matmul(l0c[cnt], l1x[cnt], l1y[cnt])

            cvmutex.lock()
            xbuf[cnt] <<= l0c[cnt]
            cvmutex.ready()

            cvmutex.wait()
            simple_micro(xbuf[cnt], outbuf[cnt], BLK // 2 * N // 64, N)
            cvmutex.free()
            valid_m = Min(BLK, m2 - m)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = GetSubBlockIdx()
            row_begin = sb_idx * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin
            z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cnt += 1

    return z


@kernel()
def intra_core_wait_stall_trace_kernel(gate: GMTensor, out: GMTensor, N: Var):
    cube_ready(flag_id=0, pipe=Pipe.FIX)
    wait_cube(flag_id=0, pipe=Pipe.S)
    return out


class _TraceStallCycleModel:
    profile_name = "trace_stall_test"


def test_intra_core_wait_stall_trace_only_shows_blocking_latency_overlap() -> None:
    recorder = TraceRecorder(core_idx=0)
    model = _TraceStallCycleModel()
    _record_intra_sync_stall(
        recorder, model, "vec0", "S", "wait_cube", 0,
        arrival_cycle=150.0, signal_cycle=100.0, visible_cycle=300.0,
    )

    events = recorder.snapshot()
    assert len(events) == 1
    event = events[0]
    assert event.name == "stall:wait_cube"
    assert event.ts == 150.0
    assert event.dur == 150.0
    assert event.args["stall_cycles"] == 150.0
    assert event.args["latency_cycles"] == 200.0
    assert event.args["consumer_stall_cycles"] == 150.0
    assert event.args["blocked_latency_start_cycle"] == 150.0
    assert event.args["blocked_latency_cycles"] == 150.0
    assert event.args["post_ready_arrival_lag_cycles"] == 50.0


def test_intra_core_wait_stall_trace_starts_at_ready_when_consumer_is_already_waiting() -> None:
    recorder = TraceRecorder(core_idx=0)
    model = _TraceStallCycleModel()
    _record_intra_sync_stall(
        recorder, model, "vec0", "S", "wait_cube", 0,
        arrival_cycle=50.0, signal_cycle=100.0, visible_cycle=300.0,
    )

    event = recorder.snapshot()[0]
    assert event.ts == 100.0
    assert event.dur == 200.0
    assert event.args["stall_cycles"] == 200.0
    assert event.args["consumer_stall_cycles"] == 250.0
    assert event.args["pre_ready_wait_cycles"] == 50.0


def test_intra_core_wait_stall_trace_hides_fully_hidden_latency() -> None:
    recorder = TraceRecorder(core_idx=0)
    model = _TraceStallCycleModel()
    _record_intra_sync_stall(
        recorder, model, "vec0", "S", "wait_cube", 0,
        arrival_cycle=350.0, signal_cycle=100.0, visible_cycle=300.0,
    )

    assert recorder.snapshot() == []


def test_trace_generation(tmp_path) -> None:
    saved_device_type = globvars.device_type
    saved_trace_event = getattr(globvars, "trace_event", False)
    globvars.device_type = "950"
    globvars.trace_event = True
    try:
        out_dir = tmp_path / "trace_case"
        trace_path = out_dir / "trace.json"

        M = 64 * 64 * 2
        N = 64
        K = 128
        torch.manual_seed(0)
        x = torch.randn(M, K).half()
        y = torch.randn(N, K).half()
        z = torch.abs(x.float() @ y.float().t()) + 1.0

        op = OpExec(cubefunc, str(out_dir), simulator=True, trace=str(trace_path))
        z_kernel = op(x, y, z, M, N, K)

        torch.testing.assert_close(z_kernel, z, rtol=1e-3, atol=1e-3)
        assert trace_path.is_file(), f"trace file was not generated: {trace_path}"
        trace_data = json.loads(trace_path.read_text(encoding="utf-8"))
        trace_events = trace_data.get("traceEvents", [])
        assert isinstance(trace_events, list) and len(trace_events) > 0, "traceEvents is empty"
        timed_events = [event for event in trace_events if event.get("ph") == "X"]
        assert timed_events, "trace does not contain timed instruction events"
        if trace_data.get("easyasc_time_domain") == "cycle":
            by_core_then_name = {}
            sync_by_core_then_name = {}
            for event in timed_events:
                if event.get("cat") not in ("MTE2", "MTE1", "M", "FIX", "V", "MTE3"):
                    if event.get("cat") != "sync":
                        continue
                core_idx = int(event.get("args", {}).get("core_idx", -1))
                if event.get("cat") == "sync":
                    sync_by_core_then_name.setdefault(core_idx, {}).setdefault(event.get("name"), []).append(event)
                else:
                    by_core_then_name.setdefault(core_idx, {}).setdefault(event.get("name"), []).append(event)

            def _earliest_start(core_idx: int, name: str) -> float:
                return min(float(event["ts"]) for event in by_core_then_name[core_idx][name])

            def _earliest_end(core_idx: int, name: str) -> float:
                return min(float(event["ts"]) + float(event["dur"]) for event in by_core_then_name[core_idx][name])

            for core_idx, by_name in by_core_then_name.items():
                required = {"gm_to_l1_nd2nz", "l1_to_l0", "mmad", "l0c_to_ub", "call_micro"}
                if not required.issubset(set(by_name)):
                    continue
                gm_events = sorted(by_name["gm_to_l1_nd2nz"], key=lambda event: (float(event["ts"]), float(event["dur"])))
                l1_events = sorted(by_name["l1_to_l0"], key=lambda event: (float(event["ts"]), float(event["dur"])))
                mmad_events = sorted(by_name["mmad"], key=lambda event: (float(event["ts"]), float(event["dur"])))
                assert _earliest_start(core_idx, "l1_to_l0") >= _earliest_end(core_idx, "gm_to_l1_nd2nz")
                assert _earliest_start(core_idx, "mmad") >= _earliest_end(core_idx, "l1_to_l0")
                assert _earliest_start(core_idx, "l0c_to_ub") >= _earliest_end(core_idx, "mmad")
                assert _earliest_start(core_idx, "call_micro") >= _earliest_end(core_idx, "l0c_to_ub")
                assert len(gm_events) >= 2
                assert len(l1_events) >= 2
                assert len(mmad_events) >= 1
                first_l1_start = float(l1_events[0]["ts"])
                first_mmad_start = float(mmad_events[0]["ts"])
                first_gm_batch_end = max(float(event["ts"]) + float(event["dur"]) for event in gm_events[:2])
                first_l1_batch_end = max(float(event["ts"]) + float(event["dur"]) for event in l1_events[:2])
                assert first_l1_start >= first_gm_batch_end
                assert first_mmad_start >= first_l1_batch_end

                sync_events = sync_by_core_then_name.get(core_idx, {}).get("event_set", [])
                valid_l1_ready = sorted(
                    float(event["ts"])
                    for event in sync_events
                    if event.get("args", {}).get("event_name") == "_tmp_devent_valid_l1_0"
                )
                valid_fix_ready = sorted(
                    float(event["ts"])
                    for event in sync_events
                    if event.get("args", {}).get("event_name") == "_tmp_devent_valid_fix_0"
                )
                traced_event_waits = [
                    event for event in timed_events
                    if event.get("name") == "event_wait"
                    and event.get("args", {}).get("core_idx") == core_idx
                ]
                assert traced_event_waits
                if len(gm_events) >= 4 and valid_fix_ready:
                    second_gm_batch_start = float(gm_events[2]["ts"])
                    assert second_gm_batch_start < valid_fix_ready[0]
    finally:
        globvars.device_type = saved_device_type
        globvars.trace_event = saved_trace_event


def test_intra_core_wait_stall_is_traced_when_sync_events_are_hidden(tmp_path) -> None:
    saved_device_type = globvars.device_type
    saved_trace_event = getattr(globvars, "trace_event", False)
    saved_trace_pipe_s = getattr(globvars, "trace_pipe_s", False)
    globvars.device_type = "950"
    globvars.trace_event = False
    globvars.trace_pipe_s = False
    try:
        out_dir = tmp_path / "intra_stall_trace_case"
        trace_path = out_dir / "trace.json"
        out = torch.empty((1,), dtype=torch.float16)

        op = OpExec(intra_core_wait_stall_trace_kernel, str(out_dir), simulator=True, trace=str(trace_path))
        op(torch.zeros((1, 1), dtype=torch.float16), out, 1)

        trace_data = json.loads(trace_path.read_text(encoding="utf-8"))
        trace_events = trace_data.get("traceEvents", [])
        timed_events = [event for event in trace_events if event.get("ph") == "X"]
        wait_events = [event for event in timed_events if event.get("name") == "wait_cube"]
        ready_events = [event for event in timed_events if event.get("name") == "cube_ready"]
        stall_events = [event for event in timed_events if event.get("name") == "stall:wait_cube"]

        assert not wait_events
        assert not ready_events
        assert stall_events
        first_stall = stall_events[0]
        assert first_stall.get("cat") == "stall"
        assert float(first_stall.get("dur", 0.0)) == 200.0
        args = first_stall.get("args", {})
        assert args.get("reason") == "intra_core_sync_latency"
        assert args.get("producer_op") == "cube_ready"
        assert args.get("wait_op") == "wait_cube"
        assert args.get("flag_id") == 0
        assert args.get("visible_cycle") - args.get("signal_cycle") == 200.0
        assert args.get("latency_cycles") == 200.0
    finally:
        globvars.device_type = saved_device_type
        globvars.trace_event = saved_trace_event
        globvars.trace_pipe_s = saved_trace_pipe_s
