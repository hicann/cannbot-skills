"""Behavioral simulator coverage for the a2 fixpipe scalar requant feature.

A matmul fills L0C with known per-row values (x[:,0]=probe, y[:,0]=1 => l0c[i,j]=probe[i]),
then the store quantizes them via l0c.requant(scale=, offset=). The byte output is checked
against (a) a reference model of the validated HW flow and (b) golden anchors captured from
Ascend910B3 cannsim.

Validated flow (deqScalar packed bitfield, signed bit = dst dtype):
  s9 = clamp(round_half_even(src * scale_fp19), -256, 255); s9 += offset;
  out = signed ? clamp(s9, -128, 127) : clamp(s9, 0, 255)

Signedness is data-driven by the *output* dtype: int8 z -> signed (bit46=1), uint8 z -> unsigned.
QF322B8_PRE (fp32 L0C -> 8bit) and REQ8 (int32 L0C -> 8bit) share this pipeline, differing only
in the L0C source dtype.

NOTE: `from easyasc.a2 import *` shadows builtin range() AND abs(); host code below avoids both.
"""
import struct

import torch

from easyasc.a2 import *

# Distinct dims -> no shape_bindings. M, N multiples of 16 (cube fractal width); a
# sub-16 N deadlocks the sim. K differs per dtype: 48 (half c0=16) vs 64 (int8 c0=32).
M, N = 16, 32
K_HALF = 48
K_INT8 = 64

# 16 half-exact probes spanning sign, half-to-even rounding, and s8/u8 saturation.
VALS = [-300.0, -129.0, -128.0, -1.0, -0.5, 0.5, 1.5, 2.5, 3.5,
        126.5, 127.0, 128.0, 200.0, 255.0, 300.0, 0.0]

# int32-valued probes for REQ8 (within int8 input range so a single K term reproduces them).
VALS_I32 = [-128, -100, -54, -20, -1, 0, 1, 5, 30, 50, 100, 120, 125, 126, 127, -50]

# --- golden anchors captured from Ascend910B3 cannsim (decimal of the produced byte) ---
# QF322B8 signed, scale=0.5, offset=10 -- full vector straight from the cannsim hex dump
# (0x80 CA CA 0A 0A 0A 0B 0B 0C 49 4A 4A 6E 7F 7F 0A).
GOLDEN_S8_HALF_TEN = [-128, -54, -54, 10, 10, 10, 11, 11, 12, 73, 74, 74, 110, 127, 127, 10]


def _fp19(scale):
    """Truncate an fp32 scale to the top 19 bits, as HW reads deqScalar[31:13]."""
    u = struct.unpack("<I", struct.pack("<f", float(scale)))[0] & 0xFFFFE000
    return struct.unpack("<f", struct.pack("<I", u))[0]


def _ref_byte(val, signed, scale, offset):
    r = round(val * _fp19(scale))          # python round() == round-half-to-even
    r = max(-256, min(255, r))             # int9 saturate, before offset
    r = r + int(offset)
    if signed:
        return max(-128, min(127, r))      # s8 (returned as signed -128..127)
    return max(0, min(255, r))             # u8 (returned as 0..255)


def _ref_vec(vals, signed, scale, offset):
    return [_ref_byte(v, signed, scale, offset) for v in vals]


def _half_inputs(vals):
    x = torch.zeros((M, K_HALF), dtype=torch.float16)
    y = torch.zeros((N, K_HALF), dtype=torch.float16)
    x[:, 0] = torch.tensor(vals, dtype=torch.float16)
    y[:, 0] = 1.0
    return x, y


def _int8_inputs(vals):
    x = torch.zeros((M, K_INT8), dtype=torch.int8)
    y = torch.zeros((N, K_INT8), dtype=torch.int8)
    x[:, 0] = torch.tensor(vals, dtype=torch.int8)
    y[:, 0] = 1
    return x, y


# ---- kernels: signedness comes from the z dtype passed at call time, not the kernel ----
@kernel()
def _qf322b8_default_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    l1x = Tensor(DT.half, [m, k], Position.L1)
    l1y = Tensor(DT.half, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=m, n=n, k=k, is_init=True)
        z[:, :] <<= l0c                      # int8/uint8 z -> QF322B8 with scale=1, offset=0
    return z


@kernel()
def _qf322b8_requant_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    l1x = Tensor(DT.half, [m, k], Position.L1)
    l1y = Tensor(DT.half, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=m, n=n, k=k, is_init=True)
        z[:, :] <<= l0c.requant(scale=0.5, offset=10)
    return z


@kernel()
def _qf322b8_var_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    l1x = Tensor(DT.half, [m, k], Position.L1)
    l1y = Tensor(DT.half, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)
    scl = Var(0.5)
    ofs = Var(10)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=m, n=n, k=k, is_init=True)
        z[:, :] <<= l0c.requant(scale=scl, offset=ofs)
    return z


@kernel()
def _req8_requant_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    l1x = Tensor(DT.int8, [m, k], Position.L1)
    l1y = Tensor(DT.int8, [n, k], Position.L1)
    l0c = Tensor(DT.int, [m, n], Position.L0C)        # int32 accumulator
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=m, n=n, k=k, is_init=True)
        z[:, :] <<= l0c.requant(scale=1.0, offset=30)
    return z


def _run_half(kernel, z_dtype, tmp_path, name):
    x, y = _half_inputs(VALS)
    z = torch.zeros((M, N), dtype=z_dtype)
    got = OpExec(kernel, out_dir=str(tmp_path / name), simulator=True)(x, y, z, M, N, K_HALF)
    return got[:, 0].tolist()


def _run_int8(kernel, z_dtype, tmp_path, name):
    x, y = _int8_inputs(VALS_I32)
    z = torch.zeros((M, N), dtype=z_dtype)
    got = OpExec(kernel, out_dir=str(tmp_path / name), simulator=True)(x, y, z, M, N, K_INT8)
    return got[:, 0].tolist()


def test_qf322b8_signed_default_scale(tmp_path):
    got = _run_half(_qf322b8_default_kernel, torch.int8, tmp_path, "qf_s8_default")
    assert got == _ref_vec(VALS, signed=True, scale=1.0, offset=0)
    # anchors: -1 -> 0xFF(-1), -128 -> 0x80(-128), 128/255/300 saturate to 0x7F(127)
    assert got[3] == -1 and got[2] == -128 and got[11] == 127 and got[13] == 127 and got[14] == 127


def test_qf322b8_unsigned_default_scale(tmp_path):
    got = _run_half(_qf322b8_default_kernel, torch.uint8, tmp_path, "qf_u8_default")
    assert got == _ref_vec(VALS, signed=False, scale=1.0, offset=0)
    # anchors: -1 -> 0x00; round-half-even on .5/1.5/2.5/3.5 -> 0/2/2/4
    assert got[3] == 0
    assert [got[4], got[5], got[6], got[7], got[8]] == [0, 0, 2, 2, 4]


def test_qf322b8_signed_scale_half_offset_ten(tmp_path):
    got = _run_half(_qf322b8_requant_kernel, torch.int8, tmp_path, "qf_s8_half_ten")
    assert got == GOLDEN_S8_HALF_TEN                       # full HW-captured vector
    assert got == _ref_vec(VALS, signed=True, scale=0.5, offset=10)


def test_qf322b8_unsigned_scale_half_offset_ten(tmp_path):
    got = _run_half(_qf322b8_requant_kernel, torch.uint8, tmp_path, "qf_u8_half_ten")
    assert got == _ref_vec(VALS, signed=False, scale=0.5, offset=10)
    # anchors from cannsim: 255 -> 0x8A(138), 300 -> 0xA0(160)
    assert got[13] == 138 and got[14] == 160


def test_qf322b8_var_scale_offset_matches_const(tmp_path):
    """A Var(0.5)/Var(10) requant resolves to the same bytes as the constant form."""
    got = _run_half(_qf322b8_var_kernel, torch.int8, tmp_path, "qf_s8_var")
    assert got == GOLDEN_S8_HALF_TEN


def test_req8_int32_to_int8_signed_offset(tmp_path):
    got = _run_int8(_req8_requant_kernel, torch.int8, tmp_path, "req8_s8_off30")
    assert got == _ref_vec(VALS_I32, signed=True, scale=1.0, offset=30)
    # anchors from cannsim build D (REQ8 signed, off+30): 0 -> 0x1E(30), -50 -> 0xEC(-20)
    assert got[5] == 30 and got[15] == -20
