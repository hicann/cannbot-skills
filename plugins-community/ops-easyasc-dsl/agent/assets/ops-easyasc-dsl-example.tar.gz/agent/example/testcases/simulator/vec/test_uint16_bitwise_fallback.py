import torch

from easyasc.a2 import *
from easyasc.stub_functions.vec.vecmask import set_mask_by_count


@kernel()
def _uint16_vand_masked_kernel(src: GMTensor, mask_src: GMTensor, out: GMTensor, contract: Var):
    src_ub = Tensor(DT.float, [1, 64], Position.UB)
    mask_ub = Tensor(DT.uint32, [1, 64], Position.UB)
    out_ub = Tensor(DT.float, [1, 64], Position.UB)

    if GetVecIdx() == 0:
        with auto_sync():
            src_ub <<= src[0:1, 0:64]
            mask_ub <<= mask_src[0:1, 0:64]
            dup(out_ub, 0.0)

            src_u16 = reinterpret(src_ub, DT.uint16)
            mask_u16 = reinterpret(mask_ub, DT.uint16)
            out_u16 = reinterpret(out_ub, DT.uint16)

            set_mask_by_count(32)
            vand(out_u16, src_u16, mask_u16, repeat=1)
            out[0:1, 0:64] <<= out_ub
    return out


def test_sim_uint16_vand_with_partial_mask_uses_fallback() -> None:
    src = (torch.arange(64, dtype=torch.float32).reshape(1, 64) + 0.25).contiguous()
    mask_src = torch.full((1, 64), 0x00FF00FF, dtype=torch.uint32)
    out = torch.zeros_like(src)

    got = OpExec(_uint16_vand_masked_kernel, simulator=True)(src, mask_src, out, -1)

    src_u16 = src.contiguous().view(torch.uint16)
    mask_u16 = mask_src.contiguous().view(torch.uint16)
    expected_u16 = torch.zeros_like(src_u16)
    expected_u16[:, 0:32] = src_u16[:, 0:32].to(torch.int16).bitwise_and(mask_u16[:, 0:32].to(torch.int16)).view(torch.uint16)
    expected = expected_u16.view(torch.float32).reshape_as(src)

    torch.testing.assert_close(got, expected, rtol=0, atol=0)
