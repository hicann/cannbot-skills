import re

from easyasc import globvars
from easyasc.a2 import *
from easyasc.parser.asc import translate_split
from easyasc.parser.asc_utils import build_offset_expr_nz
from easyasc.utils.vecop import VecOP


# --- Tensor slice metadata ---

def test_nested_slice_metadata_offset_accumulates() -> None:
    base = Tensor(DT.half, [128, 256], Position.UB)
    first = base[2:100, 3:200]
    second = first[5:20, 7:30]

    assert second.offset == [7, 10]
    assert second.span == [15, 23]
    assert second.shape == [128, 256]


def test_nested_slice_instruction_offset_stays_relative() -> None:
    @kernel()
    def stub(inp: GMTensor):
        base = Tensor(DT.half, [128, 256], Position.UB)
        first = base[2:100, 3:200]
        _ = first[5:20, 7:30]
        return inp

    inp = GMTensor(DT.half, [1, 1])
    stub(inp)

    slice_insts = [inst for inst in stub.instructions if inst.opname == "slice_tensor"]
    assert len(slice_insts) == 2
    assert slice_insts[0].kwargs["offset"] == [2, 3]
    assert slice_insts[1].kwargs["offset"] == [5, 7]

    second_view = slice_insts[1].kwargs["out"]
    assert isinstance(second_view, Tensor)
    assert second_view.offset == [7, 10]


def test_scalar_second_index_accumulates_last_dim_metadata() -> None:
    @kernel()
    def stub(inp: GMTensor):
        base = Tensor(DT.half, [64, 128], Position.UB)
        first = base[10:40, 20:90]
        _ = first[5]
        return inp

    inp = GMTensor(DT.half, [1, 1])
    stub(inp)

    slice_insts = [inst for inst in stub.instructions if inst.opname == "slice_tensor"]
    assert len(slice_insts) == 2
    assert slice_insts[1].kwargs["offset"] == [0, 5]

    second_view = slice_insts[1].kwargs["out"]
    assert isinstance(second_view, Tensor)
    assert second_view.offset == [10, 25]
    assert second_view.span == [30, 70]


def test_nested_l1_codegen_stays_stable_with_accumulated_metadata() -> None:
    @kernel()
    def stub(inp: GMTensor):
        l1 = Tensor(DT.half, [128, 256], Position.L1)
        first = l1[2:100, 3:200]
        second = first[5:20, 7:30]
        l0a = Tensor(DT.half, [16, 16], Position.L0A)
        l0a <<= second
        return inp

    inp = GMTensor(DT.half, [1, 1])
    stub(inp)
    cube_code, _ = translate_split(stub.instructions, "tensor_slice_metadata_codegen")

    assert "L0NZ2ZZ(" in cube_code or "L0NZ2NZ(" in cube_code
    assert "l1[2 * 16 + 3 * 128][5 * 16 + 7 * 128]" in cube_code


def test_nested_l1_float_b_device_codegen_uses_zz_offset() -> None:
    from easyasc import globvars

    saved_device_type = globvars.device_type
    globvars.device_type = "b3"
    try:
        @kernel()
        def stub(inp: GMTensor):
            l1 = Tensor(DT.float, [64, 96], Position.L1)
            first = l1[17:57, 5:75]
            second = first[3:23, 4:34]
            l0a = Tensor(DT.float, [16, 16], Position.L0A)
            l0a <<= second
            return inp

        inp = GMTensor(DT.float, [1, 1])
        stub(inp)
        cube_code, _ = translate_split(stub.instructions, "tensor_slice_metadata_float_b3_codegen")

        assert "17 * 96 + 5 * 16" in cube_code
        assert "3 * 96 + 4 * 16" in cube_code
        assert "L0ZZ2ZZ(" in cube_code
    finally:
        globvars.device_type = saved_device_type


def test_splitn_l0c_codegen_uses_nz_offset() -> None:
    @kernel()
    def stub(inp: GMTensor):
        l1x = Tensor(DT.half, [16, 128], Position.L1)
        l1y = Tensor(DT.half, [256, 128], Position.L1)
        l0c = Tensor(DT.float, [16, 256], Position.L0C, name="l0c")
        matmul(l0c, l1x, l1y, splitn=128)
        return inp

    inp = GMTensor(DT.half, [1, 1])
    stub(inp)
    cube_code, _ = translate_split(stub.instructions, "tensor_slice_l0c_codegen")

    assert re.search(r"MMAD\(l0c\[0\s*\*\s*16\s*\+\s*_subn\s*\*\s*16\],", cube_code) is not None


def test_l1_to_l0_does_not_mutate_shared_l0_buffer_shape() -> None:
    @kernel()
    def stub(inp: GMTensor):
        l1_small = Tensor(DT.half, [16, 64], Position.L1)
        l1_large = Tensor(DT.half, [16, 256], Position.L1)
        l0a_small = reinterpret(globvars.active_kernel._l0a[0], DT.half)
        l0a_large = reinterpret(globvars.active_kernel._l0a[1], DT.half)
        l0b_small = reinterpret(globvars.active_kernel._l0b[0], DT.half)
        l0b_large = reinterpret(globvars.active_kernel._l0b[1], DT.half)
        l0a_small <<= l1_small
        l0a_large <<= l1_large
        l0b_small <<= l1_small
        l0b_large <<= l1_large
        return inp

    inp = GMTensor(DT.half, [1, 1])
    stub(inp)

    assert stub._l0a.shape == [128, 128]
    assert stub._l0b.shape == [128, 128]


def test_l0c_column_offset_uses_shape0_stride_by_definition() -> None:
    rows = Var(32, DT.int, "rows")
    cols = Var(512, DT.int, "cols")
    subn = Var(128, DT.int, "_subn")

    expr = build_offset_expr_nz([rows, cols], [0, subn], DT.float, {}, position=Position.L0C)

    assert "_subn * rows" in expr or "rows * _subn" in expr
    assert "16 * _subn" not in expr
    assert "_subn * 16" not in expr


# --- Tensor relu metadata ---

def test_tensor_relu_keeps_ub_vecop_behavior() -> None:
    src = Tensor(DT.half, [16, 16], Position.UB, name="src_ub")

    out = src.relu()

    assert isinstance(out, VecOP)
    assert out.op == "relu"
    assert out.src1 is src
