import contextlib
import io

import pytest

from easyasc.a5 import *
from easyasc.parser.asc import translate_split
from easyasc.parser.asc_utils import render_cpp_expr, simplify_expr


MIX_WIDTH = 64


@kernel()
def vec_idiv_loop_kernel(x: GMTensor, n: Var):
    buf = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    for i in range(((n + 127) / 128) + 1):
        buf <<= buf + 1.0
    return x


def _translate_silently(instructions, name):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        return translate_split(instructions, name)


def test_simplify_expr_keeps_opaque_int_div_nested() -> None:
    expr = "IDiv(a + 127, 128) + 1"
    assert simplify_expr(expr) == expr
    assert render_cpp_expr(expr) == "((a + 127) / (128)) + 1"


def test_simplify_expr_keeps_opaque_int_div_under_mul() -> None:
    expr = "2 * IDiv(a + 127, 128)"
    assert simplify_expr(expr) == "2*IDiv(a + 127, 128)"
    assert render_cpp_expr(simplify_expr(expr)) == "2*((a + 127) / (128))"


def test_simplify_expr_keeps_opaque_int_mod_under_mul() -> None:
    expr = "x * IMod(a + 1, 16)"
    assert simplify_expr(expr) == "x*IMod(a + 1, 16)"
    assert render_cpp_expr(simplify_expr(expr)) == "x*((a + 1) % (16))"


@pytest.mark.easyasc_device("b3")
def test_translate_split_keeps_int_div_loop_bound_semantics() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH], name="x")
    n = Var(1024, name="n")
    vec_idiv_loop_kernel(x, n)

    _, vec_code = _translate_silently(
        vec_idiv_loop_kernel.instructions,
        "vec_idiv_loop_kernel_codegen",
    )

    assert "a/128 + 127/128" not in vec_code
    assert "n/128 + 127/128" not in vec_code
    assert "n/64 + 127/64" not in vec_code
    assert "((n + 127) / (128)) + 1" in vec_code
