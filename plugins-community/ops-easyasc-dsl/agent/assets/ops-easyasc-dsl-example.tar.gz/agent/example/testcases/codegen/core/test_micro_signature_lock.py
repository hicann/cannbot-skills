import pytest

from easyasc.a5 import *


WIDTH = 64


def test_vf_allows_same_dtype_position_with_different_shapes() -> None:
    @vf()
    def copy_row_vf(src: Tensor, dst: Tensor):
        reg = Reg(DT.float)
        reg <<= src[0]
        dst[0] <<= reg

    src_a = Tensor(DT.float, [1, WIDTH], Position.UB)
    dst_a = Tensor(DT.float, [1, WIDTH], Position.UB)
    src_b = Tensor(DT.float, [2, WIDTH * 2], Position.UB)
    dst_b = Tensor(DT.float, [2, WIDTH * 2], Position.UB)

    copy_row_vf(src_a, dst_a)
    copy_row_vf(src_b, dst_b)


def test_vf_rejects_tensor_dtype_signature_change() -> None:
    @vf()
    def cast_row_vf(src: Tensor, dst: Tensor):
        reg = Reg(DT.float)
        reg <<= src[0]
        dst[0] <<= reg

    src_bf16 = Tensor(DT.bfloat16, [1, WIDTH], Position.UB)
    dst_float = Tensor(DT.float, [1, WIDTH], Position.UB)
    src_float = Tensor(DT.float, [1, WIDTH], Position.UB)

    cast_row_vf(src_bf16, dst_float)
    with pytest.raises(TypeError, match="Define a separate @vf for each signature"):
        cast_row_vf(src_float, dst_float)


def test_vf_rejects_var_dtype_signature_change() -> None:
    @vf()
    def var_arg_vf(dst: Tensor, n: Var):
        reg = Reg(DT.float)
        for i in range(n):
            reg <<= dst[i * WIDTH]
            dst[i * WIDTH] <<= reg
            vf_barrier(VfPipe.STORE, VfPipe.LOAD)

    dst = Tensor(DT.float, [2, WIDTH], Position.UB)

    var_arg_vf(dst, Var(1, DT.int))
    with pytest.raises(TypeError, match="Define a separate @vf for each signature"):
        var_arg_vf(dst, Var(1.0, DT.float))
