"""Simulator + codegen regression for the reg-reg (per-lane) variable shifts
``shiftl`` / ``shiftr`` (MicroAPI::ShiftLeft / ShiftRight).

Unlike the scalar ``shiftls`` / ``shiftrs`` (shift amount is a scalar), these take
the shift amount from a second Reg -- lane ``i`` shifts ``src[i]`` by ``shift[i]``.
Right shift is logical for unsigned dtypes and arithmetic for signed. Coverage runs
int32 / int64 / uint32 / uint64 with magnitudes above ``2**32`` and bit-exact
integer goldens, mirroring the native-int approach in ``test_micro_int64_ops.py``.
"""
import pytest
import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.reg import Reg

_STORE = SharedMemoryStore()

# (Datatype, torch dtype, unsigned, width-bits). uint32/uint64 arithmetic is
# unavailable on some torch CPU builds; the simulator handles them through a
# signed view, so only run those rows when this torch exposes the dtype.
_DTYPES = [(DT.int, torch.int32, False, 32), (DT.int64, torch.int64, False, 64)]
if hasattr(torch, "uint32"):
    _DTYPES.append((DT.uint32, torch.uint32, True, 32))
if hasattr(torch, "uint64"):
    _DTYPES.append((DT.uint64, torch.uint64, True, 64))


def _wrap(x, width, unsigned):
    mod = 1 << width
    x %= mod
    if not unsigned and x >= (1 << (width - 1)):
        x -= mod
    return x


def _tensor(vals, torch_dt, unsigned, width):
    if unsigned and width == 64:
        signed = [v - (1 << 64) if v >= (1 << 63) else v for v in vals]
        return torch.tensor(signed, dtype=torch.int64).view(torch.uint64)
    if unsigned:  # uint32 (and any narrower unsigned)
        return torch.tensor(vals, dtype=torch.int64).to(torch_dt)
    return torch.tensor(vals, dtype=torch_dt)


def _uview(t, unsigned, width):
    if unsigned and width == 64:
        return [int(x) % (1 << 64) for x in t.view(torch.int64).tolist()]
    if unsigned:
        return [int(x) for x in t.to(torch.int64).tolist()]
    return [int(x) for x in t.tolist()]


def _dispatch(op, regs, kw):
    rt = MicroRuntime()
    ctx = MicroContext(regs={k: v.clone() for k, v in regs.items()}, masks={})
    rt._stack.append(ctx)
    try:
        rt._dispatch(op, kw, _STORE)
    finally:
        rt._stack.pop()
    return ctx.regs[kw["dst"].name]


def _data_shift(torch_dt, unsigned, width):
    n = 256 // torch.empty(0, dtype=torch_dt).element_size()
    if unsigned:
        pat = [1, (1 << width) - 1, (1 << (width - 8)) + 5, 0xA5 << (width - 12)]
    else:
        pat = [1, -1, (1 << (width - 2)) - 1, -((1 << (width - 3)) + 3)]
    data_vals = [_wrap(pat[i % 4], width, unsigned) for i in range(n)]
    shift_vals = [(i * 7) % width for i in range(n)]  # per-lane 0..width-1 spread
    data = _tensor(data_vals, torch_dt, unsigned, width)
    shift = _tensor(shift_vals, torch_dt, unsigned, width)
    return data, shift, shift_vals


def _golden(data_ints, shift_vals, left, width, unsigned):
    out = []
    for x, s in zip(data_ints, shift_vals):
        r = (x << s) if left else (x >> s)  # x>=0 (unsigned) -> logical; x<0 (signed) -> arithmetic
        out.append(_wrap(r, width, unsigned))
    return out


@pytest.mark.parametrize("dt,torch_dt,unsigned,width", _DTYPES)
@pytest.mark.parametrize("left,op", [(True, "micro_shiftl"), (False, "micro_shiftr")])
def test_shift_reg_native(dt, torch_dt, unsigned, width, left, op):
    data, shift, shift_vals = _data_shift(torch_dt, unsigned, width)
    dst = Reg(dt, name="dst")
    s0 = Reg(dt, name="s0")
    s1 = Reg(dt, name="s1")
    got = _dispatch(op, {"s0": data, "s1": shift}, {"dst": dst, "src1": s0, "src2": s1})
    di = _uview(data, unsigned, width)
    want = _tensor(_golden(di, shift_vals, left, width, unsigned), torch_dt, unsigned, width)
    assert torch.equal(got, want), f"{dt} {op}: got {_uview(got, unsigned, width)} want {_uview(want, unsigned, width)}"


def test_shift_reg_zero_and_full_shift():
    # shift 0 is a no-op; a wide shift within [0,width) exercises the mask/where paths.
    data = torch.tensor([0x1234_5678, -1, 0x7FFF_FFFF, 2], dtype=torch.int32)
    shift = torch.tensor([0, 31, 1, 4], dtype=torch.int32)
    dst, s0, s1 = Reg(DT.int, name="dst"), Reg(DT.int, name="s0"), Reg(DT.int, name="s1")
    got = _dispatch("micro_shiftr", {"s0": data, "s1": shift}, {"dst": dst, "src1": s0, "src2": s1})
    want = torch.tensor([0x1234_5678, -1 >> 31, 0x7FFF_FFFF >> 1, 2 >> 4], dtype=torch.int32)
    assert torch.equal(got, want)
