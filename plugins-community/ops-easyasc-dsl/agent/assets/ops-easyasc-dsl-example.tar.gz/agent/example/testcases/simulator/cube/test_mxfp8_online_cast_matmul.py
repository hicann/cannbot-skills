import torch
import pytest

from easyasc.a5 import OpExec
from kernels.a5.matmul.float_to_mxfp8_online_cast_matmul import (
    K, M, N, float_to_mxfp8_online_cast_matmul_kernel, online_mxfp8_e4m3_ref,
)
from kernels.a5.matmul.float_to_mxfp8_online_cast_transpose_matmul import (
    K as K_TRANSPOSE,
    M as M_TRANSPOSE,
    N as N_TRANSPOSE,
    float_to_mxfp8_online_cast_transpose_matmul_kernel,
    online_mxfp8_e4m3_ref as online_mxfp8_e4m3_transpose_ref,
)


pytestmark = pytest.mark.easyasc_device("a5")


def test_online_cast_f32_to_mxfp8_e4m3_then_matmul_mx() -> None:
    if not hasattr(torch, "float8_e4m3fn"):
        pytest.skip("Current torch build does not support torch.float8_e4m3fn")

    torch.manual_seed(1)
    x = torch.randn((M, K), dtype=torch.float32) * 16.0
    y = torch.randn((N, K), dtype=torch.float32) * 16.0
    z = torch.zeros((M, N), dtype=torch.float32)

    out = OpExec(float_to_mxfp8_online_cast_matmul_kernel, simulator=True)(x, y, z, 0)

    ref = online_mxfp8_e4m3_ref(x) @ online_mxfp8_e4m3_ref(y).t()
    torch.testing.assert_close(out, ref, rtol=2e-3, atol=2e-3)


def test_online_cast_transposed_f32_to_mxfp8_e4m3_then_matmul_mx() -> None:
    if not hasattr(torch, "float8_e4m3fn"):
        pytest.skip("Current torch build does not support torch.float8_e4m3fn")

    torch.manual_seed(2)
    x = torch.randn((K_TRANSPOSE, M_TRANSPOSE), dtype=torch.float32) * 16.0
    y = torch.randn((K_TRANSPOSE, N_TRANSPOSE), dtype=torch.float32) * 16.0
    z = torch.zeros((M_TRANSPOSE, N_TRANSPOSE), dtype=torch.float32)

    out = OpExec(float_to_mxfp8_online_cast_transpose_matmul_kernel, simulator=True)(x, y, z, 0)

    ref_x = online_mxfp8_e4m3_transpose_ref(x.t().contiguous())
    ref_y = online_mxfp8_e4m3_transpose_ref(y.t().contiguous())
    torch.testing.assert_close(out, ref_x @ ref_y.t(), rtol=2e-3, atol=2e-3)
