import os

import pytest
import torch

from easyasc import globvars
from easyasc.a5 import *


# The compiler requires a non-returned input tensor in the kernel entry;
# these kernels only hand `src` straight back, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.float16)


FULL_SIM_MATRIX = os.environ.get("EASYASC_FULL_SIM_MATRIX") == "1"

_ALL_CUBE_TO_VEC_WAIT_PIPES = (Pipe.S, Pipe.MTE2, Pipe.V, Pipe.MTE3)
_ALL_VEC_TO_CUBE_WAIT_PIPES = (Pipe.S, Pipe.MTE2, Pipe.MTE1, Pipe.M, Pipe.FIX)
_ALL_CUBE_READY_PIPES = (Pipe.MTE2, Pipe.MTE1, Pipe.M, Pipe.FIX)
_ALL_VEC_READY_PIPES = (Pipe.MTE2, Pipe.V, Pipe.MTE3)

CUBE_TO_VEC_WAIT_PIPES = _ALL_CUBE_TO_VEC_WAIT_PIPES if FULL_SIM_MATRIX else (Pipe.S, Pipe.MTE2)
VEC_TO_CUBE_WAIT_PIPES = _ALL_VEC_TO_CUBE_WAIT_PIPES if FULL_SIM_MATRIX else (Pipe.S, Pipe.MTE2)
CUBE_READY_PIPES = _ALL_CUBE_READY_PIPES if FULL_SIM_MATRIX else (Pipe.MTE2, Pipe.FIX)
VEC_READY_PIPES = _ALL_VEC_READY_PIPES if FULL_SIM_MATRIX else (Pipe.MTE2, Pipe.MTE3)


def _make_cube_to_vec_kernel(wait_pipe: PipeType, ready_pipe: PipeType, emit_ready: bool):
    wait_name = str(wait_pipe)
    ready_name = str(ready_pipe)
    emit_literal = "True" if emit_ready else "False"
    namespace = {}
    code = (
        "@kernel()\n"
        "def run_cube_to_vec(gate: GMTensor, src: GMTensor, contract: Var):\n"
        f"    if {emit_literal}:\n"
        f"        cube_ready(flag_id=3, pipe=Pipe.{ready_name})\n"
        f"    wait_cube(flag_id=3, pipe=Pipe.{wait_name})\n"
        "    return src\n"
    )
    exec(code, globals(), namespace)
    fn = namespace["run_cube_to_vec"]
    # Pass-through kernel; see the note in test_sim_allcore_wait_pipes.
    fn._simulator_seed_outputs = True
    return fn


def _make_vec_to_cube_kernel(wait_pipe: PipeType, ready_pipe: PipeType, emit_ready: bool):
    wait_name = str(wait_pipe)
    ready_name = str(ready_pipe)
    emit_literal = "True" if emit_ready else "False"
    namespace = {}
    code = (
        "@kernel()\n"
        "def run_vec_to_cube(gate: GMTensor, src: GMTensor, contract: Var):\n"
        f"    if {emit_literal}:\n"
        f"        vec_ready(flag_id=5, pipe=Pipe.{ready_name})\n"
        f"    wait_vec(flag_id=5, pipe=Pipe.{wait_name})\n"
        "    return src\n"
    )
    exec(code, globals(), namespace)
    fn = namespace["run_vec_to_cube"]
    fn._simulator_seed_outputs = True
    return fn


@pytest.mark.parametrize("wait_pipe", CUBE_TO_VEC_WAIT_PIPES)
def test_sim_wait_cube_wait_pipes_with_ready(wait_pipe: PipeType) -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    fn = _make_cube_to_vec_kernel(wait_pipe=wait_pipe, ready_pipe=Pipe.FIX, emit_ready=True)
    op = OpExec(fn, "test_sim_wait_cube_wait_pipes_with_ready", simulator=True)
    out = op(GATE, src, -1)
    if not torch.equal(out, src):
        raise AssertionError(f"wait_cube with ready changed tensor unexpectedly for wait_pipe={wait_pipe}")


@pytest.mark.parametrize("wait_pipe", VEC_TO_CUBE_WAIT_PIPES)
def test_sim_wait_vec_wait_pipes_with_ready(wait_pipe: PipeType) -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    fn = _make_vec_to_cube_kernel(wait_pipe=wait_pipe, ready_pipe=Pipe.MTE3, emit_ready=True)
    op = OpExec(fn, "test_sim_wait_vec_wait_pipes_with_ready", simulator=True)
    out = op(GATE, src, -1)
    if not torch.equal(out, src):
        raise AssertionError(f"wait_vec with ready changed tensor unexpectedly for wait_pipe={wait_pipe}")


@pytest.mark.parametrize("ready_pipe", CUBE_READY_PIPES)
def test_sim_cube_ready_pipe_variants(ready_pipe: PipeType) -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    fn = _make_cube_to_vec_kernel(wait_pipe=Pipe.S, ready_pipe=ready_pipe, emit_ready=True)
    op = OpExec(fn, "test_sim_cube_ready_pipe_variants", simulator=True)
    out = op(GATE, src, -1)
    if not torch.equal(out, src):
        raise AssertionError(f"cube_ready pipe variant changed tensor unexpectedly for ready_pipe={ready_pipe}")


@pytest.mark.parametrize("ready_pipe", VEC_READY_PIPES)
def test_sim_vec_ready_pipe_variants(ready_pipe: PipeType) -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    fn = _make_vec_to_cube_kernel(wait_pipe=Pipe.S, ready_pipe=ready_pipe, emit_ready=True)
    op = OpExec(fn, "test_sim_vec_ready_pipe_variants", simulator=True)
    out = op(GATE, src, -1)
    if not torch.equal(out, src):
        raise AssertionError(f"vec_ready pipe variant changed tensor unexpectedly for ready_pipe={ready_pipe}")


@pytest.mark.parametrize(
    "op",
    [
        cube_ready,
        vec_ready,
        wait_cube,
        wait_vec,
        allcube_ready,
        allvec_ready,
        allcube_wait,
        allvec_wait,
        intracore_allvec_ready,
        intracore_allvec_wait,
    ],
)
def test_crosscore_ops_reject_flag_id_out_of_range(op) -> None:
    with pytest.raises(ValueError, match="flag_id must be in range \\[0, 7\\]"):
        op(flag_id=8)


@pytest.mark.parametrize(
    "op,label",
    [
        (allcube_wait, "allcube_wait"),
        (allvec_wait, "allvec_wait"),
        (wait_cube, "wait_cube"),
        (wait_vec, "wait_vec"),
        (intracore_allvec_wait, "intracore_allvec_wait"),
    ],
)
@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_c220_crosscore_waits_only_accept_pipe_s(op, label: str, device_type: str) -> None:
    saved_device_type = globvars.device_type
    try:
        globvars.device_type = device_type
        op(flag_id=0, pipe=Pipe.S)

        with pytest.raises(ValueError, match=f"{label} pipe must be Pipe.S on C220 devices"):
            op(flag_id=0, pipe=Pipe.MTE2)
    finally:
        globvars.device_type = saved_device_type


@pytest.mark.parametrize(
    "mutex_cls,kw_name",
    [
        (CvMutex, "src_start_pipe"),
        (CvMutex, "dst_start_pipe"),
        (VcMutex, "src_start_pipe"),
        (VcMutex, "dst_start_pipe"),
    ],
)
@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_c220_mutex_start_pipes_only_accept_pipe_s(
    mutex_cls, kw_name: str, device_type: str,
) -> None:
    saved_device_type = globvars.device_type
    try:
        globvars.device_type = device_type
        mutex_cls(0, **{kw_name: Pipe.S})
        with pytest.raises(
            ValueError,
            match=f"{mutex_cls.__name__} {kw_name} must be Pipe.S on C220 devices",
        ):
            mutex_cls(0, **{kw_name: Pipe.MTE2})
    finally:
        globvars.device_type = saved_device_type


def test_a5_mutex_start_pipe_variants_remain_allowed() -> None:
    saved_device_type = globvars.device_type
    try:
        globvars.device_type = "950"
        CvMutex(0, src_start_pipe=Pipe.FIX, dst_start_pipe=Pipe.V)
        VcMutex(1, src_start_pipe=Pipe.MTE3, dst_start_pipe=Pipe.MTE1)
    finally:
        globvars.device_type = saved_device_type
