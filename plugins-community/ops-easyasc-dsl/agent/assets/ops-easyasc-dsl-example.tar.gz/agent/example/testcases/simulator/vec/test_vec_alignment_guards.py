import pytest
import torch

from easyasc.simulator.pipe_vec import VPipe
from easyasc.simulator.program import PipeTask


class _TensorStore(object):
    def __init__(self, tensors=None):
        self._tensors = dict(tensors or {})

    def tensor(self, name):
        return self._tensors[name]


def _pipe(tensors):
    pipe = object.__new__(VPipe)
    pipe.memory_store = _TensorStore(tensors)
    pipe.vector_mode = "repeat"
    pipe.count_register = 0
    pipe.current_mask = torch.ones(256, dtype=torch.uint8)
    return pipe


def _misaligned(dtype=torch.float32):
    return torch.zeros(128, dtype=dtype)[1:]


def _task(opname, **args):
    base = {
        "dst": "dst",
        "repeat": 1,
        "dst_blk_stride": 1,
        "dst_rep_stride": 8,
    }
    base.update(args)
    return PipeTask(pipe_name="V", opname=opname, args=base)


def test_vec_unary_rejects_misaligned_src_view() -> None:
    pipe = _pipe({"dst": torch.zeros(128, dtype=torch.float32), "src": _misaligned()})

    with pytest.raises(RuntimeError, match="sqrt src address must be 32-byte aligned"):
        pipe.execute(_task("sqrt", src="src", src_blk_stride=1, src_rep_stride=8))


def test_vec_unary_scalar_rejects_misaligned_dst_view() -> None:
    pipe = _pipe({"dst": _misaligned(), "src": torch.ones(128, dtype=torch.float32)})

    with pytest.raises(RuntimeError, match="muls dst address must be 32-byte aligned"):
        pipe.execute(_task("muls", src="src", val=2.0, src_blk_stride=1, src_rep_stride=8))


def test_vec_binary_rejects_misaligned_src2_view() -> None:
    pipe = _pipe({"dst": torch.zeros(128, dtype=torch.float32), "src1": torch.ones(128), "src2": _misaligned()})

    with pytest.raises(RuntimeError, match="add src2 address must be 32-byte aligned"):
        pipe.execute(_task("add", src1="src1", src2="src2", src1_blk_stride=1, src1_rep_stride=8, src2_blk_stride=1, src2_rep_stride=8))


@pytest.mark.parametrize(
    "opname,args,tensors,match",
    [
        ("dup", {}, {"dst": _misaligned()}, "dup dst address"),
        ("cast", {"src": "src", "src_blk_stride": 1, "src_rep_stride": 8}, {"dst": torch.zeros(128), "src": _misaligned()}, "cast src address"),
        ("brcb", {"src": "src"}, {"dst": torch.zeros(128), "src": _misaligned()}, "brcb src address"),
        ("cpadd", {"src": "src", "src_blk_stride": 1, "src_rep_stride": 8}, {"dst": torch.zeros(128), "src": _misaligned()}, "cpadd src address"),
        ("muladddst", {"src1": "src1", "src2": "src2", "src1_blk_stride": 1, "src1_rep_stride": 8, "src2_blk_stride": 1, "src2_rep_stride": 8}, {"dst": torch.zeros(128), "src1": torch.ones(128), "src2": _misaligned()}, "muladddst src2 address"),
    ],
)
def test_vec_other_repeat_ops_reject_misaligned_views(opname, args, tensors, match) -> None:
    pipe = _pipe(tensors)

    with pytest.raises(RuntimeError, match=match):
        pipe.execute(_task(opname, **args))


def test_vec_compare_scalar_rejects_misaligned_dst_view() -> None:
    pipe = _pipe({"dst": _misaligned(torch.uint8), "src1": torch.ones(128, dtype=torch.float32)})

    with pytest.raises(RuntimeError, match="compare_scalar dst address"):
        pipe.execute(_task("compare_scalar", src1="src1", src2=1.0, mode="LT", src1_blk_stride=1, src1_rep_stride=8))


def test_vec_compare_rejects_misaligned_src2_view() -> None:
    pipe = _pipe({"dst": torch.zeros(128, dtype=torch.uint8), "src1": torch.ones(128), "src2": _misaligned()})

    with pytest.raises(RuntimeError, match="compare src2 address"):
        pipe.execute(_task("compare", src1="src1", src2="src2", mode="LT", src1_blk_stride=1, src1_rep_stride=8, src2_blk_stride=1, src2_rep_stride=8))


def test_vec_select_rejects_misaligned_selmask_view() -> None:
    pipe = _pipe({"dst": torch.zeros(128), "src1": torch.ones(128), "src2": torch.zeros(128), "selmask": _misaligned(torch.uint8)})

    with pytest.raises(RuntimeError, match="select selmask address"):
        pipe.execute(_task("select", src1="src1", src2="src2", selmask="selmask", mode="TENSOR_SCALAR", src1_blk_stride=1, src1_rep_stride=8, src2_blk_stride=1, src2_rep_stride=8))


def test_vec_select_tensor_tensor_selects_distinct_buffers() -> None:
    dst = torch.zeros(128)
    src1 = torch.full((128,), 3.0)
    src2 = torch.full((128,), -2.0)
    selmask = torch.zeros(128, dtype=torch.uint8)
    selmask[:8] = 255
    pipe = _pipe({"dst": dst, "src1": src1, "src2": src2, "selmask": selmask})

    pipe.execute(_task("select", src1="src1", src2="src2", selmask="selmask", mode="TENSOR_TENSOR", src1_blk_stride=1, src1_rep_stride=8, src2_blk_stride=1, src2_rep_stride=8))

    assert torch.equal(dst[:64], src1[:64])


def test_vec_select_tensor_tensor_rejects_dst_src_alias() -> None:
    shared = torch.zeros(128)
    pipe = _pipe({"dst": shared, "src1": shared, "src2": torch.zeros(128), "selmask": torch.ones(128, dtype=torch.uint8)})

    with pytest.raises(ValueError, match="requires dst address to differ"):
        pipe.execute(_task("select", src1="src1", src2="src2", selmask="selmask", mode="TENSOR_TENSOR", src1_blk_stride=1, src1_rep_stride=8, src2_blk_stride=1, src2_rep_stride=8))



def test_vec_reduce_scalar_requires_dtype_size_alignment() -> None:
    # cadd/cmax/cmin only require sizeof(dtype) alignment; float32 offset 4 is OK.
    pipe = _pipe({"dst": _misaligned(torch.float32), "src": torch.ones(128, dtype=torch.float32)})
    pipe.execute(_task("cadd", src="src", src_blk_stride=1, src_rep_stride=8, dst_rep_stride=1))


def test_vec_reduce_group_requires_eight_dtype_size_alignment() -> None:
    # cgadd/cgmax/cgmin require 8 * sizeof(dtype); float32 offset 4 must fail.
    pipe = _pipe({"dst": _misaligned(torch.float32), "src": torch.ones(128, dtype=torch.float32)})
    with pytest.raises(RuntimeError, match="cgadd dst address must be 32-byte aligned"):
        pipe.execute(_task("cgadd", src="src", src_blk_stride=1, src_rep_stride=8, dst_rep_stride=1))
