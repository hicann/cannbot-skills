import pytest
import torch

from easyasc import globvars
from easyasc.a5 import *


BLK = 1
SRC_HALF_COLS = 128
DST_INT_COLS = 64
SRC_INT_COLS = 64
DST_HALF_COLS = 128


@kernel()
def run_reinterpret_half_to_int(src: GMTensor, out: GMTensor, rows: Var):
    ub_src = DBuff(src.dtype, [BLK, SRC_HALF_COLS], Position.UB)
    idx = Var(0)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(begin, end, BLK):
            ub_src[idx] <<= src[row : row + BLK, :]
            ub_int = reinterpret(ub_src[idx], DT.int)
            out[row : row + BLK, :] <<= ub_int
            idx += 1
    return out


@kernel()
def run_reinterpret_int_to_half(src: GMTensor, out: GMTensor, rows: Var):
    ub_src = DBuff(src.dtype, [BLK, SRC_INT_COLS], Position.UB)
    idx = Var(0)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)

    with auto_sync():
        for row in range(begin, end, BLK):
            ub_src[idx] <<= src[row : row + BLK, :]
            ub_half = reinterpret(ub_src[idx], DT.half)
            out[row : row + BLK, :] <<= ub_half
            idx += 1
    return out


def _vec_num_for_device() -> int:
    device = str(globvars.device_type).lower()
    if device in ("b3", "b4"):
        return 40
    if device in ("b1", "b2"):
        return 48
    if device == "950":
        return 64
    raise ValueError(f"Unsupported device_type for simulator test: {device}")


def _assert_equal(actual: torch.Tensor, expected: torch.Tensor, label: str) -> None:
    if torch.equal(actual, expected):
        return
    mismatch = actual != expected
    if bool(mismatch.any()):
        idx = mismatch.nonzero(as_tuple=False)[0].tolist()
        raise AssertionError(
            f"{label} mismatch at index {idx}: "
            f"actual={actual[tuple(idx)].item()} expected={expected[tuple(idx)].item()}"
        )
    raise AssertionError(f"{label} mismatch with no explicit mismatch index")


def test_sim_reinterpret_half_to_int_rescales_second_dim() -> None:
    rows = BLK * _vec_num_for_device()
    src = (
        torch.arange(rows * SRC_HALF_COLS, dtype=torch.float32)
        .reshape(rows, SRC_HALF_COLS)
        .to(torch.float16)
    )
    out = torch.zeros((rows, DST_INT_COLS), dtype=torch.int32)

    op = OpExec(run_reinterpret_half_to_int, "test_sim_reinterpret_half_to_int", simulator=True)
    out_sim = op(src, out, rows)

    expected = src.contiguous().view(torch.int32).view(rows, DST_INT_COLS)
    _assert_equal(out_sim, expected, "reinterpret half->int")


def test_sim_reinterpret_int_to_half_rescales_second_dim() -> None:
    rows = BLK * _vec_num_for_device()
    src = torch.arange(rows * SRC_INT_COLS, dtype=torch.int32).view(rows, SRC_INT_COLS)
    out = torch.zeros((rows, DST_HALF_COLS), dtype=torch.float16)

    op = OpExec(run_reinterpret_int_to_half, "test_sim_reinterpret_int_to_half", simulator=True)
    out_sim = op(src, out, rows)

    roundtrip = out_sim.contiguous().view(torch.int32).view(rows, SRC_INT_COLS)
    _assert_equal(roundtrip, src, "reinterpret int->half roundtrip bytes")


def test_reinterpret_rejects_l0c_position() -> None:
    src = Tensor(DT.float, [16, 16], Position.L0C)
    with pytest.raises(ValueError, match="reinterpret does not support L0C position"):
        reinterpret(src, DT.half)


def test_reinterpret_preserves_buffer_source_index() -> None:
    idx = Var(3)
    ub = DBuff(DT.half, [1, SRC_HALF_COLS], Position.UB)
    view = ub[idx]

    reinterpreted = reinterpret(view, DT.int)

    assert reinterpreted.source_buf is ub
    assert reinterpreted.source_index is idx
