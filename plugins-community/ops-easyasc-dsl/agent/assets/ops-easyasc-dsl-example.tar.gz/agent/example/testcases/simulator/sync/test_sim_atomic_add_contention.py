import pytest
import torch

from easyasc import globvars
from easyasc.a2 import *


CUBE_M = 64
CUBE_N = 64
CUBE_K = 128
VEC_COLS = 64
# The compiler requires a non-returned input tensor in the kernel entry.  The
# vec kernels below accumulate into `out` alone, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.float32)
INIT_DONE_FLAG = 0


@kernel()
def _atomic_add_cube_contention_kernel(
    x: GMTensor, y: GMTensor, y_zero: GMTensor, out: GMTensor,
    M: Var, N: Var, K: Var, repeats: Var,
):
    l1x = DBuff(DT.half, [CUBE_M, CUBE_K], Position.L1)
    l1y = DBuff(DT.half, [CUBE_N, CUBE_K], Position.L1)
    l0c = DBuff(DT.float, [CUBE_M, CUBE_N], Position.L0C)

    with cube_scope():
        core_begin = Var(GetCubeIdx())
        core_end = Min(core_begin + 1, GetCubeNum())
        for _ in range(core_begin, core_end):
            with auto_sync():
                l1x[0] <<= x[0:M, 0:K]
                l1y[0] <<= y_zero[0:N, 0:K]
                matmul(l0c[0], l1x[0], l1y[0], m=M, n=N, k=K, is_init=True)
                out[0:M, 0:N] <<= l0c[0]

            allcube_ready(INIT_DONE_FLAG)
            allcube_wait(INIT_DONE_FLAG)

            with auto_sync():
                l1y[0] <<= y[0:N, 0:K]
                matmul(l0c[0], l1x[0], l1y[0], m=M, n=N, k=K, is_init=True)
                for _rep in range(repeats):
                    with atomic_add():
                        out[0:M, 0:N] <<= l0c[0]

    return out


@kernel()
def _atomic_add_vec_contention_kernel(gate: GMTensor, out: GMTensor, cols: Var, repeats: Var):
    ones = Tensor(DT.float, [1, VEC_COLS], Position.UB)

    with vec_scope():
        lane_begin = Var(GetVecIdx())
        lane_end = Min(lane_begin + 1, GetVecNum())
        for _ in range(lane_begin, lane_end):
            with auto_sync():
                dup(ones, 1.0)
                for _rep in range(repeats):
                    with atomic_add():
                        out[0:1, 0:cols] <<= ones[0:1, 0:cols]

    return out


@kernel()
def _atomic_max_cube_keeps_larger_existing_kernel(
    x: GMTensor, y: GMTensor, out: GMTensor,
    M: Var, N: Var, K: Var,
):
    l1x = DBuff(DT.half, [CUBE_M, CUBE_K], Position.L1)
    l1y = DBuff(DT.half, [CUBE_N, CUBE_K], Position.L1)
    l0c = DBuff(DT.float, [CUBE_M, CUBE_N], Position.L0C)

    with cube_scope():
        core_begin = Var(GetCubeIdx())
        core_end = Min(core_begin + 1, GetCubeNum())
        for _ in range(core_begin, core_end):
            with auto_sync():
                l1x[0] <<= x[0:M, 0:K]
                l1y[0] <<= y[0:N, 0:K]
                matmul(l0c[0], l1x[0], l1y[0], m=M, n=N, k=K, is_init=True)
                matmul(l0c[0], l1x[0], l1y[0], m=M, n=N, k=K, is_init=False)
                out[0:M, 0:N] <<= l0c[0]

            allcube_ready(INIT_DONE_FLAG)
            allcube_wait(INIT_DONE_FLAG)

            with auto_sync():
                matmul(l0c[0], l1x[0], l1y[0], m=M, n=N, k=K, is_init=True)
                with atomic_max():
                    out[0:M, 0:N] <<= l0c[0]

    return out


@kernel()
def _atomic_min_cube_keeps_smaller_existing_kernel(
    x: GMTensor, y: GMTensor, out: GMTensor,
    M: Var, N: Var, K: Var,
):
    l1x = DBuff(DT.half, [CUBE_M, CUBE_K], Position.L1)
    l1y = DBuff(DT.half, [CUBE_N, CUBE_K], Position.L1)
    l0c = DBuff(DT.float, [CUBE_M, CUBE_N], Position.L0C)

    with cube_scope():
        core_begin = Var(GetCubeIdx())
        core_end = Min(core_begin + 1, GetCubeNum())
        for _ in range(core_begin, core_end):
            with auto_sync():
                l1x[0] <<= x[0:M, 0:K]
                l1y[0] <<= y[0:N, 0:K]
                matmul(l0c[0], l1x[0], l1y[0], m=M, n=N, k=K, is_init=True)
                out[0:M, 0:N] <<= l0c[0]

            allcube_ready(INIT_DONE_FLAG)
            allcube_wait(INIT_DONE_FLAG)

            with auto_sync():
                matmul(l0c[0], l1x[0], l1y[0], m=M, n=N, k=K, is_init=False)
                with atomic_min():
                    out[0:M, 0:N] <<= l0c[0]

    return out


@kernel()
def _atomic_max_vec_keeps_larger_existing_kernel(gate: GMTensor, out: GMTensor, cols: Var):
    ones = Tensor(DT.float, [1, VEC_COLS], Position.UB)

    with vec_scope():
        lane_begin = Var(GetVecIdx())
        lane_end = Min(lane_begin + 1, GetVecNum())
        for _ in range(lane_begin, lane_end):
            with auto_sync():
                dup(ones, 1.0)
                with atomic_max():
                    out[0:1, 0:cols] <<= ones[0:1, 0:cols]

    return out


@kernel()
def _atomic_min_vec_keeps_smaller_existing_kernel(gate: GMTensor, out: GMTensor, cols: Var):
    ones = Tensor(DT.float, [1, VEC_COLS], Position.UB)

    with vec_scope():
        lane_begin = Var(GetVecIdx())
        lane_end = Min(lane_begin + 1, GetVecNum())
        for _ in range(lane_begin, lane_end):
            with auto_sync():
                dup(ones, 1.0)
                with atomic_min():
                    out[0:1, 0:cols] <<= ones[0:1, 0:cols]

    return out


# A GM atomic is a read-modify-write, so these three read the buffer the caller
# passed in.  The cube kernels above seed themselves with a first non-atomic
# store; the vec ones accumulate straight into the caller's zeros, which the
# simulator has to hand them instead of the poison.
for _accumulating in (
    _atomic_add_vec_contention_kernel,
    _atomic_max_vec_keeps_larger_existing_kernel,
    _atomic_min_vec_keeps_smaller_existing_kernel,
):
    _accumulating._simulator_seed_outputs = True


def test_sim_atomic_add_cube_contention_keeps_all_updates() -> None:
    repeats = 256
    x = torch.ones(CUBE_M, CUBE_K, dtype=torch.float16)
    y = torch.ones(CUBE_N, CUBE_K, dtype=torch.float16)
    y_zero = torch.zeros(CUBE_N, CUBE_K, dtype=torch.float16)
    out = torch.zeros(CUBE_M, CUBE_N, dtype=torch.float32)

    out_kernel = OpExec(_atomic_add_cube_contention_kernel, simulator=True)(
        x, y, y_zero, out, CUBE_M, CUBE_N, CUBE_K, repeats,
        shape_bindings={0: [0, 2], 1: [1, 2], 2: [1, 2], 3: [0, 1]},
    )

    expected = torch.full_like(out_kernel, float(globvars.core_num * repeats * CUBE_K))
    if not torch.equal(out_kernel, expected):
        diff = expected - out_kernel
        raise AssertionError(
            "cube atomic_add lost updates under contention: expected={} actual_min={} actual_max={} max_missing={}".format(
                float(expected[0, 0].item()),
                float(out_kernel.min().item()),
                float(out_kernel.max().item()),
                float(diff.max().item()),
            )
        )


def test_sim_atomic_max_cube_keeps_larger_existing_values() -> None:
    x = torch.ones(CUBE_M, CUBE_K, dtype=torch.float16)
    y = torch.ones(CUBE_N, CUBE_K, dtype=torch.float16)
    out = torch.empty(CUBE_M, CUBE_N, dtype=torch.float32)

    out_kernel = OpExec(_atomic_max_cube_keeps_larger_existing_kernel, simulator=True)(
        x, y, out, CUBE_M, CUBE_N, CUBE_K,
        shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1]},
    )

    expected = torch.full_like(out_kernel, float(CUBE_K * 2))
    torch.testing.assert_close(out_kernel, expected, rtol=1e-4, atol=1e-4)


def test_sim_atomic_min_cube_keeps_smaller_existing_values() -> None:
    x = torch.ones(CUBE_M, CUBE_K, dtype=torch.float16)
    y = torch.ones(CUBE_N, CUBE_K, dtype=torch.float16)
    out = torch.empty(CUBE_M, CUBE_N, dtype=torch.float32)

    out_kernel = OpExec(_atomic_min_cube_keeps_smaller_existing_kernel, simulator=True)(
        x, y, out, CUBE_M, CUBE_N, CUBE_K,
        shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1]},
    )

    expected = torch.full_like(out_kernel, float(CUBE_K))
    torch.testing.assert_close(out_kernel, expected, rtol=1e-4, atol=1e-4)


def test_sim_atomic_add_vec_contention_keeps_all_updates() -> None:
    repeats = 2048
    out = torch.zeros(1, VEC_COLS, dtype=torch.float32)

    out_kernel = OpExec(_atomic_add_vec_contention_kernel, simulator=True)(GATE, out, VEC_COLS, repeats)

    expected = torch.full_like(out_kernel, float(globvars.core_num * 2 * repeats))
    if not torch.equal(out_kernel, expected):
        diff = expected - out_kernel
        raise AssertionError(
            "vec atomic_add lost updates under contention: expected={} actual_min={} actual_max={} max_missing={}".format(
                float(expected[0, 0].item()),
                float(out_kernel.min().item()),
                float(out_kernel.max().item()),
                float(diff.max().item()),
            )
        )


def test_sim_atomic_max_vec_keeps_larger_existing_values() -> None:
    out = torch.full((1, VEC_COLS), 2.0, dtype=torch.float32)

    out_kernel = OpExec(_atomic_max_vec_keeps_larger_existing_kernel, simulator=True)(GATE, out, VEC_COLS)

    torch.testing.assert_close(out_kernel, out, rtol=1e-4, atol=1e-4)


def test_sim_atomic_min_vec_keeps_smaller_existing_values() -> None:
    out = torch.zeros(1, VEC_COLS, dtype=torch.float32)

    out_kernel = OpExec(_atomic_min_vec_keeps_smaller_existing_kernel, simulator=True)(GATE, out, VEC_COLS)

    torch.testing.assert_close(out_kernel, out, rtol=1e-4, atol=1e-4)
