"""Simulator regression for native 64-bit integer micro ops.

Before this coverage several integer micro ops routed through fp32 in
``pipe_micro`` (``vmin`` / ``abs`` / ``neg`` / ``copy`` / scalar
``adds``/``muls``/``vmaxs``/``vmins`` / ``axpy`` / group reduces / ``vcpadd``),
which silently dropped bits above ``2**24`` and diverged from the generated
MicroAPI integer instruction (and therefore from cannsim / hardware). These
tests exercise each fixed path at the micro-runtime dispatch level with
magnitudes above ``2**24`` and assert bit-exact integer results for both
``int64_t`` and ``uint64_t``.
"""
from contextlib import contextmanager

import pytest
import torch

from easyasc import globvars
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.stub_functions.micro.fused import abssub
from easyasc.stub_functions.micro.group import cgadd, cgmax, cgmin, cpadd
from easyasc.stub_functions.micro.unaryscalar import axpy
from easyasc.utils.comparemode import CompareMode
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.var import Var

_STORE = SharedMemoryStore()
_MOD = 1 << 64

# (Datatype, torch dtype, unsigned). uint64 arithmetic is unavailable on some
# torch CPU builds; the simulator handles it through a signed view, so only run
# the unsigned matrix when this torch exposes the dtype at all.
_INT_DTYPES = [(DT.int64, torch.int64, False)]
if hasattr(torch, "uint64"):
    _INT_DTYPES.append((DT.uint64, torch.uint64, True))


def _wrap(x, unsigned):
    """Wrap a python int into the register-width two's-complement value."""
    x %= _MOD
    if not unsigned and x >= (1 << 63):
        x -= _MOD
    return x


def _tensor(values, torch_dt, unsigned):
    """Build a 1-D tensor. Element assignment overflows for uint64 > 2**63, so
    unsigned tensors are materialised through a same-width signed view."""
    if unsigned:
        signed = [v - _MOD if v >= (1 << 63) else v for v in values]
        return torch.tensor(signed, dtype=torch.int64).view(torch.uint64)
    return torch.tensor(values, dtype=torch_dt)


def _uview(t, unsigned):
    if unsigned:
        return [int(x) % _MOD for x in t.view(torch.int64).tolist()]
    return [int(x) for x in t.tolist()]


def _lanes(torch_dt):
    return 256 // torch.empty(0, dtype=torch_dt).element_size()  # int64/uint64 -> 32


def _dispatch(op, regs, kw):
    rt = MicroRuntime()
    ctx = MicroContext(regs={k: v.clone() for k, v in regs.items()}, masks={})
    rt._stack.append(ctx)
    try:
        rt._dispatch(op, kw, _STORE)
    finally:
        rt._stack.pop()
    return ctx.regs[kw["dst"].name]


def _make_ab(torch_dt, unsigned):
    n = _lanes(torch_dt)
    if unsigned:
        av = [3, (1 << 63) + 7, (1 << 64) - 1, 2 ** 40]
        bv = [5, (1 << 63) + 1, 2 ** 40, (1 << 64) - 9]
    else:
        av = [100000007, -(2 ** 40), 2 ** 53 + 1, -16777219]
        bv = [5, -(2 ** 40) - 1, 2 ** 40, 70]
    a = _tensor([_wrap(x, unsigned) for x in av * (n // 4)], torch_dt, unsigned)
    b = _tensor([_wrap(x, unsigned) for x in bv * (n // 4)], torch_dt, unsigned)
    return a, b


_SCALAR = 123456789


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_vmin_native(dt, torch_dt, unsigned):
    a, b = _make_ab(torch_dt, unsigned)
    dst, s0, s1 = Reg(dt, name="dst"), Reg(dt, name="s0"), Reg(dt, name="s1")
    got = _dispatch("micro_vmin", {"s0": a, "s1": b}, {"dst": dst, "src": s0, "src1": s1})
    ai, bi = _uview(a, unsigned), _uview(b, unsigned)
    want = _tensor([_wrap(min(x, y), unsigned) for x, y in zip(ai, bi)], torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_vmax_native(dt, torch_dt, unsigned):
    a, b = _make_ab(torch_dt, unsigned)
    dst, s0, s1 = Reg(dt, name="dst"), Reg(dt, name="s0"), Reg(dt, name="s1")
    got = _dispatch("micro_vmax", {"s0": a, "s1": b}, {"dst": dst, "src": s0, "src1": s1})
    ai, bi = _uview(a, unsigned), _uview(b, unsigned)
    want = _tensor([_wrap(max(x, y), unsigned) for x, y in zip(ai, bi)], torch_dt, unsigned)
    assert torch.equal(got, want)


def test_abs_neg_native_int64():
    a, _ = _make_ab(torch.int64, unsigned=False)
    dst, s0 = Reg(DT.int64, name="dst"), Reg(DT.int64, name="s0")
    ai = _uview(a, False)
    got = _dispatch("micro_vabs", {"s0": a}, {"dst": dst, "src": s0})
    assert torch.equal(got, _tensor([_wrap(abs(x), False) for x in ai], torch.int64, False))
    got = _dispatch("micro_vneg", {"s0": a}, {"dst": dst, "src": s0})
    assert torch.equal(got, _tensor([_wrap(-x, False) for x in ai], torch.int64, False))


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_copy_native(dt, torch_dt, unsigned):
    a, _ = _make_ab(torch_dt, unsigned)
    dst, s0 = Reg(dt, name="dst"), Reg(dt, name="s0")
    got = _dispatch("micro_vcopy", {"s0": a}, {"dst": dst, "src": s0})
    assert torch.equal(got, a)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
@pytest.mark.parametrize("op,ref", [
    ("micro_vadds", lambda x, s: x + s),
    ("micro_vmuls", lambda x, s: x * s),
    ("micro_vmaxs", lambda x, s: max(x, s)),
    ("micro_vmins", lambda x, s: min(x, s)),
])
def test_scalar_native(dt, torch_dt, unsigned, op, ref):
    a, _ = _make_ab(torch_dt, unsigned)
    dst, s0 = Reg(dt, name="dst"), Reg(dt, name="s0")
    got = _dispatch(op, {"s0": a}, {"dst": dst, "src": s0, "value": _SCALAR})
    ai = _uview(a, unsigned)
    want = _tensor([_wrap(ref(x, _SCALAR), unsigned) for x in ai], torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_axpy_native(dt, torch_dt, unsigned):
    # axpy (dst = dst + src * scalar) is int64/uint64-supported on-board once the
    # scalar carries its C++ type (format_scalar emits `(int64_t)K`).
    a, d0 = _make_ab(torch_dt, unsigned)
    dst, s0 = Reg(dt, name="dst"), Reg(dt, name="s0")
    got = _dispatch("micro_vaxpy", {"s0": a, "dst": d0}, {"dst": dst, "src": s0, "value": _SCALAR})
    ai, di = _uview(a, unsigned), _uview(d0, unsigned)
    want = _tensor([_wrap(d + x * _SCALAR, unsigned) for d, x in zip(di, ai)], torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_whole_register_reduce_native(dt, torch_dt, unsigned):
    # cadd/cmax/cmin (whole-register Reduce, doc 0411) DO support int64/uint64 on
    # hardware; they were already native in the simulator, so confirm the value.
    a, _ = _make_ab(torch_dt, unsigned)
    n = _lanes(torch_dt)
    ai = _uview(a, unsigned)
    for op, ref in (("micro_vcadd", sum), ("micro_vcmax", max), ("micro_vcmin", min)):
        dst, s0 = Reg(dt, name="dst"), Reg(dt, name="s0")
        got = _dispatch(op, {"s0": a, "dst": torch.zeros(n, dtype=torch_dt)},
                        {"dst": dst, "src": s0})
        assert _uview(got, unsigned)[0] == _wrap(ref(ai), unsigned)


# ---------------------------------------------------------------------------
# DSL guards: ops the Ascend950 board does NOT implement for int64/uint64 must be
# rejected at trace time so the simulator/DSL stay aligned with hardware instead
# of only failing at board build (verified on-board: SupportType static_assert).
# ---------------------------------------------------------------------------


class _FakeMicro:
    def __init__(self):
        self.instructions = []

    def _register_reg_name(self, name, kind):
        return None

    def get_mask(self, dtype, reg_num=1):
        return MaskReg(dtype, init_mode=MaskType.ALL, name="mask", reg_num=reg_num)


@contextmanager
def _active_micro():
    old_micro, old_device = globvars.active_micro, globvars.device_type
    try:
        globvars.device_type = "950"
        globvars.active_micro = _FakeMicro()
        yield
    finally:
        globvars.active_micro = old_micro
        globvars.device_type = old_device


_GUARDED_OPS = [
    ("cgadd", lambda dst, src: cgadd(dst, src)),
    ("cgmax", lambda dst, src: cgmax(dst, src)),
    ("cgmin", lambda dst, src: cgmin(dst, src)),
    ("cpadd", lambda dst, src: cpadd(dst, src)),
]


@pytest.mark.parametrize("dt", [d[0] for d in _INT_DTYPES])
@pytest.mark.parametrize("name,call", _GUARDED_OPS)
def test_board_unsupported_int64_ops_rejected(name, call, dt):
    with _active_micro():
        dst, src = Reg(dt, name="dst"), Reg(dt, name="src")
        with pytest.raises(TypeError, match="does not support 64-bit"):
            call(dst, src)


def test_axpy_rejects_narrow_var_scalar():
    # MicroAPI Axpy needs a scalar of type int64/uint64/half/float. A Var keeps its
    # own dtype, so the int32 default of Var(v) must be rejected at trace time
    # rather than failing at board build; an int64 Var is accepted.
    with _active_micro():
        dst, src = Reg(DT.int64, name="dst"), Reg(DT.int64, name="src")
        with pytest.raises(TypeError, match="axpy Var scalar dtype"):
            axpy(dst, src, Var(5, name="k32"))              # int32 default
        axpy(dst, src, Var(5, dtype=DT.int64, name="k64"))  # int64: accepted


# ---------------------------------------------------------------------------
# Group 2: ops that were already "native" in the simulator for int64 but hit
# torch-CPU uint64 gaps -- ~ / << / >> / ordered-compare / where are unimplemented
# for UInt64, so these route through a same-width signed view. Validated bit-exact
# on the Ascend950 board for both int64 and uint64 (int64_native_ops_onboard.py /
# uint64_native_ops_onboard.py); these lock in the signed-view simulator paths.
# ---------------------------------------------------------------------------


def _run_seq(instrs, regs):
    """Run [(op, kw), ...] in ONE MicroContext so compare's mask reaches select."""
    rt = MicroRuntime()
    ctx = MicroContext(regs={k: v.clone() for k, v in regs.items()}, masks={})
    rt._stack.append(ctx)
    try:
        for op, kw in instrs:
            rt._dispatch(op, kw, _STORE)
    finally:
        rt._stack.pop()
    return ctx


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_vnot_native(dt, torch_dt, unsigned):
    # torch CPU has no bitwise_not for uint64: invert through the signed view.
    a, _ = _make_ab(torch_dt, unsigned)
    dst, s0 = Reg(dt, name="dst"), Reg(dt, name="s0")
    got = _dispatch("micro_vnot", {"s0": a}, {"dst": dst, "src": s0})
    au = [x % _MOD for x in _uview(a, unsigned)]
    want = _tensor([_wrap(_MOD - 1 - u, unsigned) for u in au], torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
@pytest.mark.parametrize("op,pyfn", [
    ("micro_vand", lambda x, y: x & y),
    ("micro_vor", lambda x, y: x | y),
    ("micro_vxor", lambda x, y: x ^ y),
])
def test_bitwise_binary_native(dt, torch_dt, unsigned, op, pyfn):
    a, b = _make_ab(torch_dt, unsigned)
    dst, s0, s1 = Reg(dt, name="dst"), Reg(dt, name="s0"), Reg(dt, name="s1")
    got = _dispatch(op, {"s0": a, "s1": b}, {"dst": dst, "src1": s0, "src2": s1})
    au = [x % _MOD for x in _uview(a, unsigned)]
    bu = [x % _MOD for x in _uview(b, unsigned)]
    want = _tensor([_wrap(pyfn(x, y), unsigned) for x, y in zip(au, bu)], torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
@pytest.mark.parametrize("op,pyfn", [
    ("micro_vadd", lambda x, y: x + y),
    ("micro_vsub", lambda x, y: x - y),
    ("micro_vmul", lambda x, y: x * y),
])
def test_arith_binary_native(dt, torch_dt, unsigned, op, pyfn):
    a, b = _make_ab(torch_dt, unsigned)
    dst, s0, s1 = Reg(dt, name="dst"), Reg(dt, name="s0"), Reg(dt, name="s1")
    got = _dispatch(op, {"s0": a, "s1": b}, {"dst": dst, "src1": s0, "src2": s1})
    au = [x % _MOD for x in _uview(a, unsigned)]
    bu = [x % _MOD for x in _uview(b, unsigned)]
    want = _tensor([_wrap(pyfn(x, y) % _MOD, unsigned) for x, y in zip(au, bu)], torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_shift_native(dt, torch_dt, unsigned):
    # shiftls is bit-identical; shiftrs must be ARITHMETIC for int64 (python >> on a
    # signed int) and LOGICAL for uint64 (>> on the non-negative unsigned value).
    a, _ = _make_ab(torch_dt, unsigned)
    shift = 5
    dst, s0 = Reg(dt, name="dst"), Reg(dt, name="s0")
    got_ls = _dispatch("micro_shiftls", {"s0": a}, {"dst": dst, "src": s0, "value": shift})
    au = [x % _MOD for x in _uview(a, unsigned)]
    want_ls = _tensor([_wrap((u << shift) % _MOD, unsigned) for u in au], torch_dt, unsigned)
    assert torch.equal(got_ls, want_ls)
    got_rs = _dispatch("micro_shiftrs", {"s0": a}, {"dst": dst, "src": s0, "value": shift})
    if unsigned:
        rs_vals = [u >> shift for u in au]                       # logical
    else:
        rs_vals = [x >> shift for x in _uview(a, unsigned)]      # arithmetic (signed)
    want_rs = _tensor([_wrap(w, unsigned) for w in rs_vals], torch_dt, unsigned)
    assert torch.equal(got_rs, want_rs)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_dup_large_immediate(dt, torch_dt, unsigned):
    # dup must keep a float-lossy (>2**53) / uint64 (>2**63) immediate bit-exact --
    # it resolves the format_scalar-typed literal as an int through a signed carrier.
    val = (1 << 63) + (1 << 40) + 7 if unsigned else (1 << 40) + 12345
    lit = f"({dt.name}){val}"                                    # e.g. (uint64_t)...
    dst = Reg(dt, name="dst")
    got = _dispatch("micro_vdup", {}, {"dst": dst, "src": lit})
    want = _tensor([_wrap(val, unsigned)] * _lanes(torch_dt), torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_muladddst_native(dt, torch_dt, unsigned):
    # MulAddDst dst = src0*src1 + dst, wrapping in the register width (uint64 via a
    # signed view). src0=src1=a, dst seeded with d0 -> a*a + d0.
    a, d0 = _make_ab(torch_dt, unsigned)
    dst, s0, s1 = Reg(dt, name="dst"), Reg(dt, name="s0"), Reg(dt, name="s1")
    got = _dispatch("micro_muladddst", {"dst": d0, "s0": a, "s1": a},
                    {"dst": dst, "src1": s0, "src2": s1})
    au = [x % _MOD for x in _uview(a, unsigned)]
    du = [x % _MOD for x in _uview(d0, unsigned)]
    want = _tensor([_wrap((x * x + d) % _MOD, unsigned) for x, d in zip(au, du)], torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_compare_select_native(dt, torch_dt, unsigned):
    # compare (GT) writes a mask that select consumes; for uint64 the compare uses
    # UNSIGNED ordering (a bit-63-set value is the largest, not negative). The
    # composition picks max(a, b) so it doubles as an unsigned-order check.
    a, b = _make_ab(torch_dt, unsigned)
    dst = Reg(dt, name="dst")
    s0, s1 = Reg(dt, name="s0"), Reg(dt, name="s1")
    m = MaskReg(dt, init_mode=MaskType.NONE, name="m")
    ctx = _run_seq([
        ("micro_compare", {"dst": m, "src1": s0, "src2": s1, "mode": CompareMode.GT}),
        ("micro_select", {"dst": dst, "src1": s0, "src2": s1, "mask": m}),
    ], {"s0": a, "s1": b})
    got = ctx.regs[dst.name]
    # _uview yields signed ints for int64 and unsigned reps for uint64, so ``>``
    # here is in the same domain the register compares in (that's the point).
    au, bu = _uview(a, unsigned), _uview(b, unsigned)
    want = _tensor([_wrap(x if x > y else y, unsigned) for x, y in zip(au, bu)], torch_dt, unsigned)
    assert torch.equal(got, want)


@pytest.mark.parametrize("dt,torch_dt,unsigned", _INT_DTYPES)
def test_compares_scalar_unsigned_order(dt, torch_dt, unsigned):
    # compares against a compile-time typed scalar; the uint64 path compares with
    # unsigned ordering. select then keeps a where a > scalar else b.
    a, b = _make_ab(torch_dt, unsigned)
    scalar = 1 << 62
    lit = f"({dt.name}){scalar}"
    dst = Reg(dt, name="dst")
    s0, s1 = Reg(dt, name="s0"), Reg(dt, name="s1")
    m = MaskReg(dt, init_mode=MaskType.NONE, name="m")
    ctx = _run_seq([
        ("micro_compares", {"dst": m, "src1": s0, "src2": lit, "mode": CompareMode.GT}),
        ("micro_select", {"dst": dst, "src1": s0, "src2": s1, "mask": m}),
    ], {"s0": a, "s1": b})
    got = ctx.regs[dst.name]
    au, bu = _uview(a, unsigned), _uview(b, unsigned)
    want = _tensor([_wrap(x if x > scalar else y, unsigned) for x, y in zip(au, bu)], torch_dt, unsigned)
    assert torch.equal(got, want)


def test_abssub_rejects_uint64():
    # MicroAPI AbsSub is {half, float, int64}; a uint64 abssub must be rejected at
    # trace time (int64 is accepted -- covered end-to-end by the on-board runner).
    with _active_micro():
        u = [Reg(DT.uint64, name=n) for n in ("d", "a", "b")]
        with pytest.raises(ValueError, match="abssub dtype"):
            abssub(*u)
