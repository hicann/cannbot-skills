import torch

from easyasc import globvars
from easyasc.a2 import OpExec, pack_signed_int4
from easyasc.a2 import *  # noqa: F401,F403


SHAPE_BINDINGS = {
    0: [0, 3],
    1: [1, 3],
    2: [0, 1],
}
TILE_M = 64
TILE_N = 64


@kernel()
def _wide_tail_int4_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var, KC_LOAD: Var):
    l1x = DBuff(DT.int, [TILE_M, 16], Position.L1)
    l1y = DBuff(DT.int, [TILE_N, 16], Position.L1)
    l0c = DBuff(DT.int, [TILE_M, TILE_N], Position.L0C)
    l1_cnt = Var(0)
    l0c_cnt = Var(0)
    with auto_sync():
        l1x[l1_cnt] <<= x[0:M, 0:KC_LOAD]
        l1y[l1_cnt] <<= y[0:N, 0:KC_LOAD]
        matmul(
            l0c[l0c_cnt],
            l1x[l1_cnt].reinterpret(DT.int4),
            l1y[l1_cnt].reinterpret(DT.int4),
            k=K,
            is_init=True,
        )
        z[0:M, 0:N] <<= l0c[l0c_cnt][0:M, 0:N]
    return z


def test_int4_wide_tail_path_zeroes_last_partial_row_block_like_910b3() -> None:
    saved_device = globvars.device_type
    globvars.device_type = "b3"
    try:
        m, n, k = 18, 19, 9
        torch.manual_seed(m * 1000000 + n * 1000 + k)
        x_logical = torch.randint(-8, 8, (m, k), dtype=torch.int32)
        y_logical = torch.randint(-8, 8, (n, k), dtype=torch.int32)
        x = pack_signed_int4(x_logical)
        y = pack_signed_int4(y_logical)
        z = torch.zeros((m, n), dtype=torch.int32)

        out = OpExec(_wide_tail_int4_kernel, simulator=True)(
            x, y, z, m, n, k, x.shape[1], shape_bindings=SHAPE_BINDINGS
        )

        assert torch.count_nonzero(out[16:18]).item() == 0
        assert torch.count_nonzero(out[:16]).item() > 0
    finally:
        globvars.device_type = saved_device


def test_int4_wide_tail_path_keeps_tail_rows_when_logical_k_exceeds_64() -> None:
    saved_device = globvars.device_type
    globvars.device_type = "b3"
    try:
        m, n, k = 18, 19, 65
        torch.manual_seed(m * 1000000 + n * 1000 + k)
        x_logical = torch.randint(-8, 8, (m, k), dtype=torch.int32)
        y_logical = torch.randint(-8, 8, (n, k), dtype=torch.int32)
        x = pack_signed_int4(x_logical)
        y = pack_signed_int4(y_logical)
        z = torch.zeros((m, n), dtype=torch.int32)

        out = OpExec(_wide_tail_int4_kernel, simulator=True)(
            x, y, z, m, n, k, x.shape[1], shape_bindings=SHAPE_BINDINGS
        )

        torch.testing.assert_close(out, x_logical @ y_logical.t())
    finally:
        globvars.device_type = saved_device
