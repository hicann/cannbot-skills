"""Pure-python replica of the fixed nms_sort_simt (key-compare introsort).

Mirrors nms.py line-by-line: GCC libstdc++ introsort structure with the
unsigned sortable-key comparator. Used to fuzz against torch 2.10's
std::sort + KeyValueCompDesc golden ordering.
"""
import struct

SORT_THRESHOLD = 16

def f32_key(x):
    u = struct.unpack('<I', struct.pack('<f', x))[0]
    if (u & 0x7fffffff) > 0x7f800000:
        return 0xFFC00000
    if u == 0x80000000:
        u = 0
    if u >= 0x80000000:
        return (~u) & 0xFFFFFFFF
    return u | 0x80000000

def depth_limit_of(n):
    fl = 0
    v = n
    while v > 1:
        v >>= 1
        fl += 1
    return 2 * fl

def introsort(scores):
    n = len(scores)
    keys = [f32_key(s) for s in scores]
    order = list(range(n))
    if n <= 0:
        return order
    stack = [(0, n, depth_limit_of(n))]
    while stack:
        first, last, depth = stack.pop()
        while True:
            if last - first <= SORT_THRESHOLD:
                break
            if depth == 0:
                # partial_sort(first,last,last) = make_heap + sort_heap (min-heap w/ desc comp)
                heap_length = last - first
                if heap_length >= 2:
                    def adjust(hole, length, value):
                        top = hole
                        second = hole
                        while second < (length - 1) // 2:
                            second = 2 * (second + 1)
                            if keys[order[first + second]] > keys[order[first + second - 1]]:
                                second -= 1
                            order[first + hole] = order[first + second]
                            hole = second
                        if length % 2 == 0 and second == (length - 2) // 2:
                            second = 2 * (second + 1)
                            order[first + hole] = order[first + second - 1]
                            hole = second - 1
                        # push_heap
                        parent = (hole - 1) // 2
                        while hole > top:
                            if keys[order[first + parent]] > keys[value]:
                                order[first + hole] = order[first + parent]
                                hole = parent
                                parent = (hole - 1) // 2
                            else:
                                break
                        order[first + hole] = value
                    parent = (heap_length - 2) // 2
                    while True:
                        value = order[first + parent]
                        adjust(parent, heap_length, value)
                        if parent == 0:
                            break
                        parent -= 1
                    heap_last = last
                    while heap_last - first > 1:
                        heap_last -= 1
                        value = order[heap_last]
                        order[heap_last] = order[first]
                        adjust(0, heap_last - first, value)
                break
            depth -= 1
            middle = first + (last - first) // 2
            a, b, c = order[first + 1], order[middle], order[last - 1]
            if keys[a] > keys[b]:
                if keys[b] > keys[c]:
                    order[first], order[middle] = order[middle], order[first]
                elif keys[a] > keys[c]:
                    order[first], order[last - 1] = order[last - 1], order[first]
                else:
                    order[first], order[first + 1] = order[first + 1], order[first]
            elif keys[a] > keys[c]:
                order[first], order[first + 1] = order[first + 1], order[first]
            elif keys[b] > keys[c]:
                order[first], order[last - 1] = order[last - 1], order[first]
            else:
                order[first], order[middle] = order[middle], order[first]
            # unguarded partition around pivot at first
            left = first + 1
            right = last
            while True:
                while keys[order[left]] > keys[order[first]]:
                    left += 1
                right -= 1
                while keys[order[first]] > keys[order[right]]:
                    right -= 1
                if left < right:
                    order[left], order[right] = order[right], order[left]
                    left += 1
                else:
                    break
            cut = left
            stack.append((first, cut, depth))
            first = cut
    # final insertion passes
    final_limit = min(n, SORT_THRESHOLD)
    pos = 1
    while pos < final_limit:
        value = order[pos]
        if keys[value] > keys[order[0]]:
            cur = pos
            while cur > 0:
                order[cur] = order[cur - 1]
                cur -= 1
            order[0] = value
        else:
            cur = pos
            prev = cur - 1
            while keys[value] > keys[order[prev]]:
                order[cur] = order[prev]
                cur = prev
                prev -= 1
            order[cur] = value
        pos += 1
    if n > SORT_THRESHOLD:
        pos = SORT_THRESHOLD
        while pos < n:
            value = order[pos]
            cur = pos
            prev = cur - 1
            while keys[value] > keys[order[prev]]:
                order[cur] = order[prev]
                cur = prev
                prev -= 1
            order[cur] = value
            pos += 1
    return order
