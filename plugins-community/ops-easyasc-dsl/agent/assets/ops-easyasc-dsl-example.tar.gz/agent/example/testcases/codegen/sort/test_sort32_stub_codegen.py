import pytest

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


def _make_sort32_tensors(
    *,
    dst_pos=Position.UB,
    src_pos=Position.UB,
    idx_pos=Position.UB,
    dst_dtype=DT.float,
    src_dtype=DT.float,
    idx_dtype=DT.uint32,
):
    dst = Tensor(dst_dtype, [1, 64], dst_pos)
    src = Tensor(src_dtype, [1, 32], src_pos)
    idx = Tensor(idx_dtype, [1, 32], idx_pos)
    return dst, src, idx


def test_sort32_rejects_non_tensor_inputs() -> None:
    dst, src, idx = _make_sort32_tensors()
    with pytest.raises(TypeError, match="dst must be Tensor"):
        sort32("bad", src, idx, 1)  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="src must be Tensor"):
        sort32(dst, "bad", idx, 1)  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="idx must be Tensor"):
        sort32(dst, src, "bad", 1)  # type: ignore[arg-type]


def test_sort32_rejects_non_ub_tensors() -> None:
    dst, src, idx = _make_sort32_tensors(dst_pos=Position.L1)
    with pytest.raises(ValueError, match="dst must be at UB position"):
        sort32(dst, src, idx, 1)

    dst, src, idx = _make_sort32_tensors(src_pos=Position.L1)
    with pytest.raises(ValueError, match="src must be at UB position"):
        sort32(dst, src, idx, 1)

    dst, src, idx = _make_sort32_tensors(idx_pos=Position.L1)
    with pytest.raises(ValueError, match="idx must be at UB position"):
        sort32(dst, src, idx, 1)


def test_sort32_requires_float_src_and_dst() -> None:
    dst, src, idx = _make_sort32_tensors(dst_dtype=DT.half, src_dtype=DT.half)
    with pytest.raises(ValueError, match="only supports float dtype"):
        sort32(dst, src, idx, 1)

    dst, src, idx = _make_sort32_tensors(dst_dtype=DT.float, src_dtype=DT.half)
    with pytest.raises(ValueError, match="src/dst data types must match"):
        sort32(dst, src, idx, 1)


def test_sort32_requires_uint32_idx() -> None:
    dst, src, idx = _make_sort32_tensors(idx_dtype=DT.int)
    with pytest.raises(ValueError, match="idx must be uint32 type"):
        sort32(dst, src, idx, 1)


def test_sort32_rejects_invalid_repeat_type() -> None:
    dst, src, idx = _make_sort32_tensors()
    with pytest.raises(TypeError, match="repeat must be Var or int"):
        sort32(dst, src, idx, 1.5)  # type: ignore[arg-type]


def test_sort32_codegen_emits_vec_side_call() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [1, 64], Position.UB)
        src = Tensor(DT.float, [1, 32], Position.UB)
        idx = Tensor(DT.uint32, [1, 32], Position.UB)
        sort32(dst, src, idx, 1)
        return inp

    inp = GMTensor(DT.float, [1, 1])
    stub_only(inp)
    cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_sort32_codegen")
    assert "Sort32(" not in cube_code
    assert "Sort32(" in vec_code
