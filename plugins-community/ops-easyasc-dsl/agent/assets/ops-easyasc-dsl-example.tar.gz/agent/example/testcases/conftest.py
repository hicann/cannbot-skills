from pathlib import Path

import pytest

from easyasc import globvars


_A2_DEFAULTS = {
    "device_type": "b3",
    "core_num": 20,
    "l1_cap": 512,
    "l0a_cap": 64,
    "l0b_cap": 64,
    "l0amx_cap": 4,
    "l0bmx_cap": 4,
    "l0c_cap": 128,
    "bt_cap": 0.5,
    "ub_cap": 192,
}

_A3_DEFAULTS = {
    "device_type": "a3",
    "core_num": 20,
    "l1_cap": 512,
    "l0a_cap": 64,
    "l0b_cap": 64,
    "l0amx_cap": 4,
    "l0bmx_cap": 4,
    "l0c_cap": 128,
    "bt_cap": 0.5,
    "ub_cap": 192,
}

_A5_DEFAULTS = {
    "device_type": "950",
    "core_num": 32,
    "l1_cap": 512,
    "l0a_cap": 64,
    "l0b_cap": 64,
    "l0amx_cap": 4,
    "l0bmx_cap": 4,
    "l0c_cap": 256,
    "bt_cap": 4,
    "ub_cap": 256,
}

_A5PR_DEFAULTS = {
    "device_type": "950pr",
    "core_num": 28,
    "l1_cap": 512,
    "l0a_cap": 64,
    "l0b_cap": 64,
    "l0amx_cap": 4,
    "l0bmx_cap": 4,
    "l0c_cap": 256,
    "bt_cap": 4,
    "ub_cap": 256,
}

_TRANSIENT_DEFAULTS = {
    "active_kernel": None,
    "active_micro": None,
    "tmp_idx": 0,
    "atomic_enabled": False,
    "atomic_type": None,
    "trace_event": False,
    "trace_pipe_s": False,
}


def _source_for_item(item) -> str:
    path = Path(str(item.path))
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _defaults_for_item(item):
    marker = item.get_closest_marker("easyasc_device")
    if marker:
        device = str(marker.args[0])
        if device in ("a5", "950"):
            return _A5_DEFAULTS
        if device in ("a5pr", "950pr"):
            return _A5PR_DEFAULTS
        if device in ("a2", "b3"):
            return _A2_DEFAULTS
        if device in ("a3", "910c", "9362"):
            return _A3_DEFAULTS
        raise ValueError(f"unknown easyasc_device marker value: {device}")

    source = _source_for_item(item)

    uses_a5pr = "from easyasc.a5pr" in source or "import easyasc.a5pr" in source
    if uses_a5pr:
        return _A5PR_DEFAULTS

    uses_a5 = "from easyasc.a5" in source or "import easyasc.a5" in source
    uses_autosync_a5_helpers = "testcases.parser.sync._autosync" in source
    if uses_a5 or uses_autosync_a5_helpers:
        return _A5_DEFAULTS

    uses_a3 = "from easyasc.a3" in source or "import easyasc.a3" in source
    if uses_a3:
        return _A3_DEFAULTS

    uses_a2 = "from easyasc.a2" in source or "import easyasc.a2" in source
    if uses_a2:
        return _A2_DEFAULTS

    return _A2_DEFAULTS


def _apply_defaults(defaults) -> None:
    for name, value in defaults.items():
        setattr(globvars, name, value)
    for name, value in _TRANSIENT_DEFAULTS.items():
        setattr(globvars, name, value)


@pytest.fixture(autouse=True)
def isolate_easyasc_global_state(request):
    defaults = _defaults_for_item(request.node)
    _apply_defaults(defaults)
    try:
        yield
    finally:
        _apply_defaults(defaults)
