from easyasc.simulator import build_kernel_program
from easyasc.utils.Tensor import DBuff
from easyasc.utils.Tensor import Tensor
from easyasc.utils.datatype import Datatype
from easyasc.utils.instruction import Instruction
from easyasc.utils.pipe import Pipe
from easyasc.utils.positions import Position
from easyasc.utils.var import Var


def _make_kernel(instructions):
    class FakeKernel:
        name = "legacy_sim_debug_pipe_bridge"

    kernel = FakeKernel()
    kernel.instructions = instructions
    return kernel


def test_legacy_sim_dump_tensor_lowers_to_requested_cube_pipe() -> None:
    l1 = Tensor(Datatype.float, [4, 4], Position.L1, name="l1_debug")
    program = build_kernel_program(
        _make_kernel(
            [
                Instruction("create_tensor", val=l1),
                Instruction("sim_dump_tensor", tensor=l1, filename="cube_dump.pt", pipe=Pipe.FIX),
            ]
        )
    )

    cube_insts = [inst for inst in program.get_lane_program("cube").instructions if inst.opname == "sim_dump_tensor"]
    vec_insts = [inst for inst in program.get_lane_program("vec0").instructions if inst.opname == "sim_dump_tensor"]

    assert len(cube_insts) == 1
    assert cube_insts[0].pipe_name == "FIX"
    assert cube_insts[0].args == {"tensor": "l1_debug", "filename": "cube_dump.pt"}
    assert vec_insts == []


def test_legacy_sim_print_lowers_to_requested_vec_pipe_with_typed_payload() -> None:
    counter = Var(7, name="counter")
    ub = Tensor(Datatype.float, [1, 8], Position.UB, name="ub_debug")
    program = build_kernel_program(
        _make_kernel(
            [
                Instruction("create_var", val=counter),
                Instruction("create_tensor", val=ub),
                Instruction("sim_print", payload=["counter=", "counter", counter], pipe=Pipe.V),
            ]
        )
    )

    cube_insts = [inst for inst in program.get_lane_program("cube").instructions if inst.opname == "sim_print"]
    vec_insts = [inst for inst in program.get_lane_program("vec0").instructions if inst.opname == "sim_print"]

    assert cube_insts == []
    assert len(vec_insts) == 1
    assert vec_insts[0].pipe_name == "V"
    assert vec_insts[0].args == {
        "payload": [
            {"kind": "literal", "value": "counter="},
            {"kind": "literal", "value": "counter"},
            {"kind": "var", "value": "counter"},
        ]
    }


def test_legacy_sim_slice_tensor_uses_instruction_relative_offsets() -> None:
    row_begin = Var(16, name="row_begin")
    row_span = Var(16, name="row_span")
    stale_accumulated_offset = Var(16, name="_tmp_var_35")
    l0c = Tensor(Datatype.float, [32, 128], Position.L0C, name="l0c_src")
    src = Tensor(Datatype.float, [32, 128], Position.UB, name="ub_src")
    view = Tensor(Datatype.float, [32, 128], Position.UB, name="ub_view")
    view.offset = [stale_accumulated_offset, 0]
    view.span = [row_span, 128]
    view.step = [1, 1]

    program = build_kernel_program(
        _make_kernel(
            [
                Instruction("create_var", val=row_begin),
                Instruction("create_var", val=row_span),
                Instruction("create_tensor", val=l0c),
                Instruction("create_tensor", val=src),
                Instruction(
                    "slice_tensor",
                    src=src,
                    out=view,
                    offset=[row_begin, 0],
                    span=[row_span, 128],
                    step=[1, 1],
                ),
                Instruction(
                    "l0c_to_ub",
                    dst=view,
                    src=l0c,
                    M=32,
                    N=128,
                    N_dst=128,
                    M_src=32,
                    dual_mode=1,
                    sub_block_id=0,
                    relu=False,
                ),
            ]
        )
    )

    slice_inst = next(inst for inst in program.get_lane_program("cube").instructions if inst.opname == "slice_tensor")
    assert slice_inst.args["offset_0"] == "row_begin"
    assert slice_inst.args["span_0"] == "row_span"
    assert "_tmp_var_35" not in slice_inst.args.values()


def test_legacy_l0c_to_ub_lowers_explicit_vec_lane_destinations_for_ub_views() -> None:
    l0c = Tensor(Datatype.float, [128, 128], Position.L0C, name="delta_l0c")
    ub = Tensor(Datatype.float, [64, 128], Position.UB, name="delta_ub")
    ub_view = Tensor(Datatype.float, [64, 128], Position.UB, name="_tmp_tensor_30")

    program = build_kernel_program(
        _make_kernel(
            [
                Instruction("create_tensor", val=l0c),
                Instruction("create_tensor", val=ub),
                Instruction(
                    "slice_tensor",
                    src=ub,
                    out=ub_view,
                    offset=[0, 0],
                    span=[64, 128],
                    step=[1, 1],
                ),
                Instruction(
                    "l0c_to_ub",
                    dst=ub_view,
                    src=l0c,
                    M=128,
                    N=128,
                    N_dst=128,
                    M_src=128,
                    dual_mode=1,
                    sub_block_id=0,
                    relu=False,
                ),
            ]
        )
    )

    l0c_to_ub_inst = next(inst for inst in program.get_lane_program("cube").instructions if inst.opname == "l0c_to_ub")
    assert l0c_to_ub_inst.args["dst"] == "_tmp_tensor_30"
    assert l0c_to_ub_inst.args["dst_vec0"] == "_tmp_tensor_30"
    assert l0c_to_ub_inst.args["dst_vec1"] == "_vec1__tmp_tensor_30"


def test_legacy_l0c_to_ub_keeps_get_buf_backed_ub_slots_on_implicit_lane_mapping() -> None:
    l0c = Tensor(Datatype.float, [128, 128], Position.L0C, name="delta_l0c")
    tile_cnt = Var(0, name="tile_cnt")
    xbuf = DBuff(Datatype.float, [64, 128], Position.UB, name="xbuf")
    slot = xbuf[tile_cnt]

    program = build_kernel_program(
        _make_kernel(
            [
                Instruction("create_tensor", val=l0c),
                Instruction("create_dbuf", val=xbuf),
                Instruction("create_var", val=tile_cnt),
                Instruction("get_buf", buf=xbuf, index=tile_cnt, out=slot),
                Instruction(
                    "l0c_to_ub",
                    dst=slot,
                    src=l0c,
                    M=128,
                    N=128,
                    N_dst=128,
                    M_src=128,
                    dual_mode=1,
                    sub_block_id=0,
                    relu=False,
                ),
            ]
        )
    )

    l0c_to_ub_inst = next(inst for inst in program.get_lane_program("cube").instructions if inst.opname == "l0c_to_ub")
    assert l0c_to_ub_inst.args["dst"] == str(slot.name)
    assert "dst_vec0" not in l0c_to_ub_inst.args
    assert "dst_vec1" not in l0c_to_ub_inst.args


def test_legacy_l0c_to_ub_lowers_explicit_vec_lane_destinations_for_get_buf_slices() -> None:
    l0c = Tensor(Datatype.float, [128, 128], Position.L0C, name="delta_l0c")
    tile_cnt = Var(0, name="tile_cnt")
    xbuf = DBuff(Datatype.float, [64, 128], Position.UB, name="xbuf")
    slot = xbuf[tile_cnt]
    view = slot[:, 64:128]

    program = build_kernel_program(
        _make_kernel(
            [
                Instruction("create_tensor", val=l0c),
                Instruction("create_dbuf", val=xbuf),
                Instruction("create_var", val=tile_cnt),
                Instruction("get_buf", buf=xbuf, index=tile_cnt, out=slot),
                Instruction(
                    "slice_tensor",
                    src=slot,
                    out=view,
                    offset=[0, 64],
                    span=[64, 64],
                    step=[1, 1],
                ),
                Instruction(
                    "l0c_to_ub",
                    dst=view,
                    src=l0c,
                    M=64,
                    N=64,
                    N_dst=128,
                    M_src=128,
                    dual_mode=0,
                    sub_block_id=1,
                    relu=False,
                ),
            ]
        )
    )

    l0c_to_ub_inst = next(inst for inst in program.get_lane_program("cube").instructions if inst.opname == "l0c_to_ub")
    assert l0c_to_ub_inst.args["dst"] == str(view.name)
    assert l0c_to_ub_inst.args["dst_vec0"] == str(view.name)
    assert l0c_to_ub_inst.args["dst_vec1"] == "_vec1_" + str(view.name)
