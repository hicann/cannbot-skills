import re

import torch

from easyasc import globvars


_SAVED_DEVICE = globvars.device_type
globvars.device_type = "950"

from easyasc.a5 import *  # noqa: E402,F403
from easyasc.parser.asc import translate_split  # noqa: E402
from easyasc.simulator import SimulatorConfig  # noqa: E402


WIDTH = 8


@kernel()
def _runtime_index_view_kernel(src: GMTensor, out: GMTensor, contract: Var):
    buf = DBuff(DT.float, [1, WIDTH], Position.UB, name="level3_view_buf")
    slot_idx = Var(0, name="level3_view_slot_idx")

    with vec_scope():
        if GetVecIdx() == 0:
            with auto_sync():
                slot = buf[slot_idx]
                slot <<= src[:, :]
                slot_idx += 1
                out[:, :] <<= slot
    return out


_runtime_index_view_kernel._simulator_config = SimulatorConfig(
    core_count=1, process_start_method="fork", execution_timeout_s=10.0,
)


def teardown_module(module):
    globvars.device_type = _SAVED_DEVICE


def test_runtime_indexed_view_keeps_saved_slot_in_simulator() -> None:
    src = torch.arange(WIDTH, dtype=torch.float32).reshape(1, WIDTH)
    out = torch.zeros_like(src)
    got = OpExec(_runtime_index_view_kernel, simulator=True)(src, out, -1)
    torch.testing.assert_close(got, src, rtol=0.0, atol=0.0)


def test_runtime_indexed_view_materializes_localtensor_before_mutation() -> None:
    src = GMTensor(DT.float, [1, WIDTH], name="src")
    out = GMTensor(DT.float, [1, WIDTH], name="out")
    _runtime_index_view_kernel(src, out, Var(-1, name="contract"))

    _, vec_code = translate_split(
        _runtime_index_view_kernel.instructions,
        "level3_runtime_index_view_codegen",
    )
    match = re.search(
        r"LocalTensor<[^>]+>\s+(\w+)\s*=\s*"
        r"level3_view_buf\.get\(level3_view_slot_idx\);",
        vec_code,
    )
    assert match is not None
    view_name = match.group(1)
    declaration = match.start()
    producer = vec_code.index("GM2UBPAD({}".format(view_name))
    advance = vec_code.index(
        "level3_view_slot_idx = level3_view_slot_idx + 1;"
    )
    consumer = vec_code.index(", {},".format(view_name), advance)
    assert vec_code.count("level3_view_buf.get(level3_view_slot_idx)") == 1
    assert declaration < producer < advance < consumer
    assert re.search(r"\bTensor<", vec_code) is None
