import time

import pytest

from easyasc.simulator import ControlInstruction, KernelProgram, LaneProgram, SharedTensorSpec, SimulatorConfig
from easyasc.simulator.simulator import Simulator
from easyasc.simulator.core import Core, CoreState, _core_entry
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe import PipeBase
from easyasc.simulator.sync import CrossCoreSync, Mailbox


class _HangingFixPipe(PipeBase):
    def execute(self, task) -> None:
        if task.opname == "hang":
            time.sleep(2.0)
            return
        raise NotImplementedError("unexpected task: " + task.opname)


class _FailingFixPipe(PipeBase):
    def execute(self, task) -> None:
        raise ValueError("pipe exploded: " + task.opname)


def _hang_pipe_factory(core_idx, lane_name, pipe_name, mailbox, barrier, memory_store, event_bank=None, intra_sync=None, **kwargs):
    if lane_name == "cube" and pipe_name == "FIX":
        return _HangingFixPipe(
            core_idx=core_idx,
            lane_name=lane_name,
            pipe_name=pipe_name,
            mailbox=mailbox,
            bar_all_barrier=barrier,
            memory_store=memory_store,
            event_bank=event_bank,
            intra_sync=intra_sync,
            **kwargs,
        )
    raise NotImplementedError("unexpected lane/pipe in timeout test")


def _failing_pipe_factory(core_idx, lane_name, pipe_name, mailbox, barrier, memory_store, event_bank=None, intra_sync=None, **kwargs):
    if lane_name == "cube" and pipe_name == "FIX":
        return _FailingFixPipe(
            core_idx=core_idx,
            lane_name=lane_name,
            pipe_name=pipe_name,
            mailbox=mailbox,
            bar_all_barrier=barrier,
            memory_store=memory_store,
            event_bank=event_bank,
            intra_sync=intra_sync,
            **kwargs,
        )
    raise NotImplementedError("unexpected lane/pipe in failure test")


class _StatusConn(object):
    def __init__(self):
        self.messages = []

    def send(self, msg):
        self.messages.append(msg)

    def close(self):
        return None


class _EofStatusConn(object):
    def poll(self):
        return True

    def recv(self):
        raise EOFError

    def close(self):
        return None


class _GracePeriodCore(object):
    def __init__(self):
        self.core_idx = 0
        self.state = CoreState.RUNNING
        self.failure = ""
        self.terminated = False

    def join(self, timeout):
        if timeout > 0.0:
            self.state = CoreState.STOPPED

    def wait_handles(self):
        return []

    def terminate(self):
        self.terminated = True


def test_legacy_core_timeout_reports_inflight_pipe_task() -> None:
    program = KernelProgram(
        name="hang_timeout_reporting",
        core_count=1,
        lane_programs=[
            LaneProgram(
                lane_name="cube",
                pipe_names=["FIX"],
                instructions=[ControlInstruction("hang", pipe_name="FIX", args={"payload": "x"})],
            ),
        ],
        metadata={"tensor_specs": [SharedTensorSpec(name="dummy", shape=(1,), dtype="float32", role="input").to_dict()]},
    )
    memory_store = SharedMemoryStore()
    memory_store.register(SharedTensorSpec(name="dummy", shape=(1,), dtype="float32", role="input"))
    memory_store.allocate("dummy")
    cross_sync = CrossCoreSync(core_count=1)
    cross_sync.prepare()
    status = _StatusConn()

    _core_entry(
        core_idx=0,
        config=SimulatorConfig(core_count=1, execution_timeout_s=0.5),
        program=program,
        memory_snapshot=memory_store.snapshot(),
        cross_sync_snapshot=cross_sync.snapshot(),
        status_conn=status,
        pipe_factory=_hang_pipe_factory,
    )

    assert status.messages
    msg = status.messages[-1]
    assert msg["state"] == "failed"
    assert "active pipe tasks:" in msg["failure"]
    assert "cube/FIX running hang" in msg["failure"]
    assert "args={'payload': 'x'}" in msg["failure"]


def test_legacy_simulator_raise_also_writes_traceback_to_stderr(capsys) -> None:
    program = KernelProgram(
        name="legacy_raise_stderr",
        core_count=1,
        lane_programs=[
            LaneProgram(
                lane_name="cube",
                pipe_names=["FIX"],
                instructions=[ControlInstruction("explode", pipe_name="FIX", args={"payload": "x"})],
            ),
        ],
    )
    sim = Simulator(
        config=SimulatorConfig(core_count=1, execution_timeout_s=1.0),
        pipe_factory=_failing_pipe_factory,
    )

    with pytest.raises(RuntimeError, match="core 0:"):
        sim.run(program)

    err = capsys.readouterr().err
    assert "Traceback (most recent call last):" in err
    assert "ValueError: pipe exploded: explode" in err
    assert "RuntimeError: core 0:" in err


def test_legacy_core_consume_status_ignores_closed_pipe(capsys) -> None:
    core = object.__new__(Core)
    core.core_idx = 0
    core.state = CoreState.RUNNING
    core.failure = ""
    core._status_conn = _EofStatusConn()

    core._consume_status()

    captured = capsys.readouterr()
    assert captured.err == ""


def test_legacy_simulator_accepts_core_finishing_during_timeout_grace() -> None:
    sim = Simulator(SimulatorConfig(core_count=1, execution_timeout_s=-1.0))
    core = _GracePeriodCore()
    sim.cores = [core]

    sim._wait(KernelProgram(
        name="timeout_grace_completion", core_count=1, lane_programs=[],
    ))

    assert core.state == CoreState.STOPPED
    assert not core.terminated
