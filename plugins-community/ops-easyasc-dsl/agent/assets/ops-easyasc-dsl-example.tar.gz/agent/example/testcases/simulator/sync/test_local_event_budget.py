import pytest

from easyasc.simulator import Simulator, SimulatorConfig, build_kernel_program
from easyasc.simulator.sync import LocalEventBank, MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR
from easyasc.utils.events import DEvent, QEvent, TEvent
from easyasc.utils.instruction import Instruction
from easyasc.utils.pipe import Pipe


def test_local_event_bank_counts_sevent_as_one_and_devent_as_two() -> None:
    bank = LocalEventBank()
    for index in range(3):
        bank.create_event("d{}".format(index), "d", "MTE2", "V")
    for index in range(2):
        bank.create_event("s{}".format(index), "s", "MTE2", "V")

    assert bank._next_flag_id[("MTE2", "V")] == MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR
    with pytest.raises(RuntimeError, match=r"MTE2->V: 8/8 IDs.*SEvent=1, DEvent=2"):
        bank.create_event("overflow", "s", "MTE2", "V")

    bank = LocalEventBank()
    for index in range(7):
        bank.create_event("s{}".format(index), "s", "MTE2", "V")
    with pytest.raises(RuntimeError, match=r"MTE2->V: 7/8 IDs.*DEvent.*requires 2 more"):
        bank.create_event("overflow", "d", "MTE2", "V")


def test_local_event_budget_is_independent_for_each_ordered_pipe_pair() -> None:
    bank = LocalEventBank()
    for index in range(MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR):
        bank.create_event("forward{}".format(index), "s", "MTE2", "V")
        bank.create_event("reverse{}".format(index), "s", "V", "MTE2")

    assert bank._next_flag_id[("MTE2", "V")] == MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR
    assert bank._next_flag_id[("V", "MTE2")] == MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR


def test_local_event_bank_tevent_uses_three_fifo_flags() -> None:
    bank = LocalEventBank()
    bank.create_event("triple", "t", "M", "FIX")

    bank.set_event("triple")
    bank.set_event("triple")
    bank.set_event("triple")
    assert bank._next_flag_id[("M", "FIX")] == 3
    with pytest.raises(RuntimeError, match="set on already-set flag"):
        bank.set_event("triple")

    assert bank.wait_event("triple")
    bank.set_event("triple")
    assert bank.wait_event("triple")
    assert bank.wait_event("triple")
    assert bank.wait_event("triple")


def test_local_event_bank_counts_tevent_as_three() -> None:
    bank = LocalEventBank()
    bank.create_event("triple0", "t", "M", "FIX")
    bank.create_event("triple1", "t", "M", "FIX")
    bank.create_event("double", "d", "M", "FIX")
    assert bank._next_flag_id[("M", "FIX")] == MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR
    with pytest.raises(RuntimeError, match=r"M->FIX: 8/8 IDs.*TEvent.*requires 3 more"):
        bank.create_event("overflow", "t", "M", "FIX")


def test_local_event_bank_qevent_uses_four_fifo_flags() -> None:
    bank = LocalEventBank()
    bank.create_event("quad", "q", "M", "FIX")

    for _ in range(4):
        bank.set_event("quad")
    assert bank._next_flag_id[("M", "FIX")] == 4
    with pytest.raises(RuntimeError, match="set on already-set flag"):
        bank.set_event("quad")

    assert bank.wait_event("quad")
    bank.set_event("quad")
    for _ in range(4):
        assert bank.wait_event("quad")


def test_local_event_bank_counts_qevent_as_four() -> None:
    bank = LocalEventBank()
    bank.create_event("quad0", "q", "M", "FIX")
    bank.create_event("quad1", "q", "M", "FIX")
    assert bank._next_flag_id[("M", "FIX")] == MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR
    with pytest.raises(RuntimeError, match=r"M->FIX: 8/8 IDs.*QEvent.*requires 4 more"):
        bank.create_event("overflow", "q", "M", "FIX")


def _make_over_budget_kernel():
    class FakeKernel:
        name = "over_budget_local_events"
        kernel_mode = "mix"

    events = [
        DEvent(Pipe.MTE2, Pipe.V, name="_tmp_devent_ready_{}".format(index))
        for index in range(5)
    ]
    instructions = []
    for event in events:
        instructions.extend([
            Instruction("create_devent", val=event),
            Instruction("event_setall", event=event),
            Instruction("event_release", event=event),
        ])
    kernel = FakeKernel()
    kernel.instructions = instructions
    return kernel


def test_simulator_preflight_rejects_over_budget_lowered_events() -> None:
    program = build_kernel_program(_make_over_budget_kernel())
    vec_creates = [
        inst for inst in program.get_lane_program("vec0").instructions
        if inst.opname == "create_devent"
    ]
    assert len(vec_creates) == 5

    simulator = Simulator(SimulatorConfig(core_count=1, cycle_model_enabled=False))
    with pytest.raises(
        RuntimeError,
        match=r"kernel 'over_budget_local_events' lane 'vec0'.*MTE2->V: 8/8 IDs",
    ):
        simulator._prepare(program)
    assert simulator.cores == []
