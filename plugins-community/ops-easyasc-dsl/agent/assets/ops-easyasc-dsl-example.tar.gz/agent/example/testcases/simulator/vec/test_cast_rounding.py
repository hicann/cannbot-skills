from types import SimpleNamespace

import pytest
import torch

from easyasc import globvars
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.simulator.pipe_vec import VPipe
from easyasc.simulator.program import PipeTask
from easyasc.stub_functions.micro.cast import cast as micro_cast
from easyasc.stub_functions.vec.cast import cast as vec_cast
from easyasc.utils.Tensor import Tensor
from easyasc.utils.castconfig import CastConfig, RegLayout
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.positions import Position
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.roundmode import RoundMode


_BASE_VALUES = torch.tensor(
    [-2.75, -2.5, -2.25, -1.5, -1.25, -0.5, -0.25, 0.25,
     0.5, 1.25, 1.5, 1.75, 2.25, 2.5, 2.75, 3.5],
    dtype=torch.float32,
)

_ROUND_MODES = [
    RoundMode.TO_EVEN,
    RoundMode.FLOOR,
    RoundMode.CEIL,
    RoundMode.AWAY_FROM_ZERO,
    RoundMode.TRUNC,
]
_ROUND_MODES_WITH_NONE = _ROUND_MODES + [RoundMode.NONE]
_FLOAT_TO_HALF_MODES = _ROUND_MODES + [RoundMode.ODD, RoundMode.NONE]

_CAST_PAIRS = [
    ("half_to_int32", DT.half, torch.float16, DT.int, torch.int32, _ROUND_MODES),
    ("half_to_int16", DT.half, torch.float16, DT.int16, torch.int16, _ROUND_MODES),
    ("half_to_int8", DT.half, torch.float16, DT.int8, torch.int8, _ROUND_MODES_WITH_NONE),
    ("half_to_uint8", DT.half, torch.float16, DT.uint8, torch.uint8, _ROUND_MODES_WITH_NONE),
    ("float_to_int32", DT.float, torch.float32, DT.int, torch.int32, _ROUND_MODES),
    ("float_to_int64", DT.float, torch.float32, DT.int64, torch.int64, _ROUND_MODES),
    ("float_to_int16", DT.float, torch.float32, DT.int16, torch.int16, _ROUND_MODES),
    ("bfloat16_to_int32", DT.bfloat16, torch.bfloat16, DT.int, torch.int32, _ROUND_MODES),
]
_FLOAT_REDUCE_PAIRS = [
    ("float_to_half", DT.float, torch.float32, DT.half, torch.float16, _FLOAT_TO_HALF_MODES),
    ("float_to_bfloat16", DT.float, torch.float32, DT.bfloat16, torch.bfloat16, _ROUND_MODES),
]
_FLOAT_TO_FLOAT_PAIRS = [
    ("float_to_float", DT.float, torch.float32, DT.float, torch.float32, _ROUND_MODES),
]
_INT_TO_FLOAT_PAIRS = [
    ("int16_to_half", DT.int16, torch.int16, DT.half, torch.float16, _ROUND_MODES_WITH_NONE),
    ("int32_to_float", DT.int, torch.int32, DT.float, torch.float32, _ROUND_MODES_WITH_NONE),
    ("int64_to_float", DT.int64, torch.int64, DT.float, torch.float32, _ROUND_MODES),
]
_NO_ROUND_PAIRS = [
    ("half_to_float", DT.half, torch.float16, DT.float, torch.float32),
    ("bfloat16_to_float", DT.bfloat16, torch.bfloat16, DT.float, torch.float32),
    ("uint8_to_half", DT.uint8, torch.uint8, DT.half, torch.float16),
    ("int8_to_half", DT.int8, torch.int8, DT.half, torch.float16),
    ("int16_to_float", DT.int16, torch.int16, DT.float, torch.float32),
    ("int32_to_int16", DT.int, torch.int32, DT.int16, torch.int16),
    ("int32_to_int64", DT.int, torch.int32, DT.int64, torch.int64),
    ("int64_to_int32", DT.int64, torch.int64, DT.int, torch.int32),
]

_FLOAT_REDUCE_VALUES = {
    torch.float16: torch.tensor([4098.0, -4098.0, 4097.0, -4097.0], dtype=torch.float32),
    torch.bfloat16: torch.tensor([257.0, -257.0, 256.5, -256.5], dtype=torch.float32),
}
_FLOAT_REDUCE_EXPECTED = {
    torch.float16: {
        "CAST_RINT": torch.tensor([4096.0, -4096.0, 4096.0, -4096.0], dtype=torch.float16),
        "CAST_FLOOR": torch.tensor([4096.0, -4100.0, 4096.0, -4100.0], dtype=torch.float16),
        "CAST_CEIL": torch.tensor([4100.0, -4096.0, 4100.0, -4096.0], dtype=torch.float16),
        "CAST_ROUND": torch.tensor([4100.0, -4100.0, 4096.0, -4096.0], dtype=torch.float16),
        "CAST_TRUNC": torch.tensor([4096.0, -4096.0, 4096.0, -4096.0], dtype=torch.float16),
        "CAST_ODD": torch.tensor([4100.0, -4100.0, 4100.0, -4100.0], dtype=torch.float16),
        "CAST_NONE": torch.tensor([4096.0, -4096.0, 4096.0, -4096.0], dtype=torch.float16),
    },
    torch.bfloat16: {
        "CAST_RINT": torch.tensor([256.0, -256.0, 256.0, -256.0], dtype=torch.bfloat16),
        "CAST_FLOOR": torch.tensor([256.0, -258.0, 256.0, -258.0], dtype=torch.bfloat16),
        "CAST_CEIL": torch.tensor([258.0, -256.0, 258.0, -256.0], dtype=torch.bfloat16),
        "CAST_ROUND": torch.tensor([258.0, -258.0, 256.0, -256.0], dtype=torch.bfloat16),
        "CAST_TRUNC": torch.tensor([256.0, -256.0, 256.0, -256.0], dtype=torch.bfloat16),
    },
}
_INT32_FLOAT_LOWER = 2 ** 24
_INT32_FLOAT_UPPER = 2 ** 24 + 2
_INT32_FLOAT_MID = 2 ** 24 + 1
_INT64_FLOAT_LOWER = 2 ** 40
_INT64_FLOAT_UPPER = 2 ** 40 + 2 ** 17
_INT64_FLOAT_MID = 2 ** 40 + 2 ** 16
_INT_TO_FLOAT_VALUES = {
    (torch.int16, torch.float16): torch.tensor([4098, -4098], dtype=torch.int16),
    (torch.int32, torch.float32): torch.tensor([_INT32_FLOAT_MID, -_INT32_FLOAT_MID], dtype=torch.int32),
    (torch.int64, torch.float32): torch.tensor([_INT64_FLOAT_MID, -_INT64_FLOAT_MID], dtype=torch.int64),
}
_INT_TO_FLOAT_EXPECTED = {
    (torch.int16, torch.float16): {
        "CAST_RINT": torch.tensor([4096.0, -4096.0], dtype=torch.float16),
        "CAST_FLOOR": torch.tensor([4096.0, -4100.0], dtype=torch.float16),
        "CAST_CEIL": torch.tensor([4100.0, -4096.0], dtype=torch.float16),
        "CAST_ROUND": torch.tensor([4100.0, -4100.0], dtype=torch.float16),
        "CAST_TRUNC": torch.tensor([4096.0, -4096.0], dtype=torch.float16),
        "CAST_NONE": torch.tensor([4096.0, -4096.0], dtype=torch.float16),
    },
    (torch.int32, torch.float32): {
        "CAST_RINT": torch.tensor([_INT32_FLOAT_LOWER, -_INT32_FLOAT_LOWER], dtype=torch.float32),
        "CAST_FLOOR": torch.tensor([_INT32_FLOAT_LOWER, -_INT32_FLOAT_UPPER], dtype=torch.float32),
        "CAST_CEIL": torch.tensor([_INT32_FLOAT_UPPER, -_INT32_FLOAT_LOWER], dtype=torch.float32),
        "CAST_ROUND": torch.tensor([_INT32_FLOAT_UPPER, -_INT32_FLOAT_UPPER], dtype=torch.float32),
        "CAST_TRUNC": torch.tensor([_INT32_FLOAT_LOWER, -_INT32_FLOAT_LOWER], dtype=torch.float32),
        "CAST_NONE": torch.tensor([_INT32_FLOAT_LOWER, -_INT32_FLOAT_LOWER], dtype=torch.float32),
    },
    (torch.int64, torch.float32): {
        "CAST_RINT": torch.tensor([_INT64_FLOAT_LOWER, -_INT64_FLOAT_LOWER], dtype=torch.float32),
        "CAST_FLOOR": torch.tensor([_INT64_FLOAT_LOWER, -_INT64_FLOAT_UPPER], dtype=torch.float32),
        "CAST_CEIL": torch.tensor([_INT64_FLOAT_UPPER, -_INT64_FLOAT_LOWER], dtype=torch.float32),
        "CAST_ROUND": torch.tensor([_INT64_FLOAT_UPPER, -_INT64_FLOAT_UPPER], dtype=torch.float32),
        "CAST_TRUNC": torch.tensor([_INT64_FLOAT_LOWER, -_INT64_FLOAT_LOWER], dtype=torch.float32),
    },
}
_NO_ROUND_VALUES = {
    torch.float16: torch.tensor([-3.5, -1.0, 0.0, 1.5, 2.0], dtype=torch.float16),
    torch.bfloat16: torch.tensor([-3.5, -1.0, 0.0, 1.5, 2.0], dtype=torch.bfloat16),
    torch.uint8: torch.tensor([0, 1, 2, 127, 255], dtype=torch.uint8),
    torch.int8: torch.tensor([-128, -2, 0, 3, 127], dtype=torch.int8),
    torch.int16: torch.tensor([-32768, -1024, 0, 1024, 32767], dtype=torch.int16),
    torch.int32: torch.tensor([-32768, -1024, 0, 1024, 32767], dtype=torch.int32),
    torch.int64: torch.tensor([-32768, -1024, 0, 1024, 32767], dtype=torch.int64),
}


class _TensorStore(object):
    def __init__(self, tensors):
        self._tensors = dict(tensors)

    def tensor(self, name):
        return self._tensors[name]


def _emit_micro_cast_stub(dst_dt, src_dt):
    dst = Reg(dst_dt, name="dst")
    src = Reg(src_dt, name="src")
    mask = MaskReg(dst_dt, init_mode=MaskType.ALL, name="mask")
    config = CastConfig(name="cfg")
    fake = SimpleNamespace(instructions=[])
    prev_micro = globvars.active_micro
    prev_device = globvars.device_type
    try:
        globvars.device_type = "950"
        globvars.active_micro = fake
        micro_cast(dst, src, config, mask)
        return fake.instructions[-1]
    finally:
        globvars.active_micro = prev_micro
        globvars.device_type = prev_device


def _mode_name(mode) -> str:
    return str(getattr(mode, "name", mode))


def _dtype_size(dtype: torch.dtype) -> int:
    return int(torch.empty((), dtype=dtype).element_size())


def _lanes(dtype: torch.dtype) -> int:
    return 256 // _dtype_size(dtype)


def _tile_values(count: int, dtype: torch.dtype) -> torch.Tensor:
    reps = (count + int(_BASE_VALUES.numel()) - 1) // int(_BASE_VALUES.numel())
    return _BASE_VALUES.to(dtype).repeat(reps)[:count]


def _tile_reduce_values(count: int, dtype: torch.dtype, dst_dtype: torch.dtype) -> torch.Tensor:
    values = _FLOAT_REDUCE_VALUES[dst_dtype]
    reps = (count + int(values.numel()) - 1) // int(values.numel())
    return values.to(dtype).repeat(reps)[:count]


def _expected_float_to_float(values: torch.Tensor, mode) -> torch.Tensor:
    return _round_values(values, mode).to(values.dtype)


def _tile_int_to_float_values(count: int, src_dtype: torch.dtype, dst_dtype: torch.dtype) -> torch.Tensor:
    values = _INT_TO_FLOAT_VALUES[(src_dtype, dst_dtype)]
    reps = (count + int(values.numel()) - 1) // int(values.numel())
    return values.repeat(reps)[:count]


def _tile_no_round_values(count: int, src_dtype: torch.dtype) -> torch.Tensor:
    values = _NO_ROUND_VALUES[src_dtype]
    reps = (count + int(values.numel()) - 1) // int(values.numel())
    return values.repeat(reps)[:count]


def _next_float32(value: float, direction: float) -> float:
    src = torch.tensor(value, dtype=torch.float32)
    dst = torch.tensor(direction, dtype=torch.float32)
    return float(torch.nextafter(src, dst).item())


def _round_values(values: torch.Tensor, mode) -> torch.Tensor:
    mode_name = _mode_name(mode)
    work = values.to(torch.float32)
    if mode_name in ("CAST_NONE", "CAST_RINT"):
        return torch.round(work)
    if mode_name == "CAST_FLOOR":
        return torch.floor(work)
    if mode_name == "CAST_CEIL":
        return torch.ceil(work)
    if mode_name == "CAST_ROUND":
        return torch.sign(work) * torch.floor(torch.abs(work) + 0.5)
    if mode_name == "CAST_TRUNC":
        return torch.trunc(work)
    raise AssertionError("unexpected round mode: " + mode_name)


def _expected_cast(values: torch.Tensor, mode, dst_dtype: torch.dtype) -> torch.Tensor:
    rounded = _round_values(values, mode).to(torch.float64)
    info = torch.iinfo(dst_dtype)
    finite = torch.isfinite(rounded)
    if bool(finite.any().item()):
        rounded[finite] = torch.clamp(rounded[finite], min=float(info.min), max=float(info.max))
    rounded[rounded == float("inf")] = float(info.max)
    rounded[rounded == float("-inf")] = float(info.min)
    rounded[torch.isnan(rounded)] = 0.0
    return rounded.to(dst_dtype)


def _vpipe_count_cast(src: torch.Tensor, dst_dtype: torch.dtype, mode) -> torch.Tensor:
    dst = torch.zeros(int(src.numel()), dtype=dst_dtype)
    pipe = object.__new__(VPipe)
    pipe.memory_store = _TensorStore({"src": src, "dst": dst})
    pipe.vector_mode = "count"
    pipe.count_register = int(src.numel())
    pipe.current_mask = torch.ones(256, dtype=torch.uint8)

    pipe.execute(
        PipeTask(
            pipe_name="V",
            opname="cast",
            args={"dst": "dst", "src": "src", "mode": mode, "count": int(src.numel())},
        )
    )
    return dst


def _vec_rep_strides(src_dtype: torch.dtype, dst_dtype: torch.dtype):
    src_c0 = 32 // _dtype_size(src_dtype)
    dst_c0 = 32 // _dtype_size(dst_dtype)
    if src_c0 > dst_c0:
        return 8, 8 * dst_c0 // src_c0
    if src_c0 < dst_c0:
        return 8 * src_c0 // dst_c0, 8
    return 8, 8


def _logical_elems_per_repeat(src_dtype: torch.dtype, dst_dtype: torch.dtype) -> int:
    dst_rep, src_rep = _vec_rep_strides(src_dtype, dst_dtype)
    return src_rep * (32 // _dtype_size(src_dtype))


def _micro_src_and_expected(src_dtype: torch.dtype, dst_dtype: torch.dtype, mode):
    src_lanes = _lanes(src_dtype)
    dst_lanes = _lanes(dst_dtype)
    src_size = _dtype_size(src_dtype)
    dst_size = _dtype_size(dst_dtype)
    src = torch.zeros(src_lanes, dtype=src_dtype)
    expected = torch.zeros(dst_lanes, dtype=dst_dtype)
    if src_size == dst_size:
        values = _tile_values(dst_lanes, src_dtype)
        src.copy_(values)
        expected.copy_(_expected_cast(values, mode, dst_dtype))
    elif src_size < dst_size:
        ratio = dst_size // src_size
        values = _tile_values(dst_lanes, src_dtype)
        src[torch.arange(dst_lanes) * ratio] = values
        expected.copy_(_expected_cast(values, mode, dst_dtype))
    else:
        ratio = src_size // dst_size
        values = _tile_values(src_lanes, src_dtype)
        src.copy_(values)
        dst_idx = torch.arange(src_lanes) * ratio
        expected[dst_idx] = _expected_cast(values, mode, dst_dtype)
    return src, expected


def _micro_reduce_src_and_expected(src_dtype: torch.dtype, dst_dtype: torch.dtype, mode):
    src_lanes = _lanes(src_dtype)
    dst_lanes = _lanes(dst_dtype)
    src_size = _dtype_size(src_dtype)
    dst_size = _dtype_size(dst_dtype)
    src = torch.zeros(src_lanes, dtype=src_dtype)
    expected = torch.zeros(dst_lanes, dtype=dst_dtype)
    mode_expected = _FLOAT_REDUCE_EXPECTED[dst_dtype][_mode_name(mode)]
    if src_size <= dst_size:
        values = _tile_reduce_values(dst_lanes, src_dtype, dst_dtype)
        src[:dst_lanes].copy_(values)
        reps = (dst_lanes + int(mode_expected.numel()) - 1) // int(mode_expected.numel())
        expected.copy_(mode_expected.repeat(reps)[:dst_lanes])
        return src, expected

    ratio = src_size // dst_size
    values = _tile_reduce_values(src_lanes, src_dtype, dst_dtype)
    src.copy_(values)
    reps = (src_lanes + int(mode_expected.numel()) - 1) // int(mode_expected.numel())
    dst_idx = torch.arange(src_lanes) * ratio
    expected[dst_idx] = mode_expected.repeat(reps)[:src_lanes]
    return src, expected


def _micro_int_to_float_src_and_expected(src_dtype: torch.dtype, dst_dtype: torch.dtype, mode):
    src_lanes = _lanes(src_dtype)
    dst_lanes = _lanes(dst_dtype)
    src_size = _dtype_size(src_dtype)
    dst_size = _dtype_size(dst_dtype)
    src = torch.zeros(src_lanes, dtype=src_dtype)
    expected = torch.zeros(dst_lanes, dtype=dst_dtype)
    mode_expected = _INT_TO_FLOAT_EXPECTED[(src_dtype, dst_dtype)][_mode_name(mode)]
    if src_size <= dst_size:
        values = _tile_int_to_float_values(dst_lanes, src_dtype, dst_dtype)
        src[:dst_lanes].copy_(values)
        reps = (dst_lanes + int(mode_expected.numel()) - 1) // int(mode_expected.numel())
        expected.copy_(mode_expected.repeat(reps)[:dst_lanes])
        return src, expected

    ratio = src_size // dst_size
    values = _tile_int_to_float_values(src_lanes, src_dtype, dst_dtype)
    src.copy_(values)
    reps = (src_lanes + int(mode_expected.numel()) - 1) // int(mode_expected.numel())
    dst_idx = torch.arange(src_lanes) * ratio
    expected[dst_idx] = mode_expected.repeat(reps)[:src_lanes]
    return src, expected


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _CAST_PAIRS)
def test_vec_cast_float_to_int_preserves_requested_round_mode(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    active = SimpleNamespace(instructions=[], vector_mode="repeat")
    globvars.active_kernel = active
    src = Tensor(src_dt, [1, 64], Position.UB, name="src")
    dst = Tensor(dst_dt, [1, 64], Position.UB, name="dst")

    vec_cast(dst, src, round_mode=RoundMode.TRUNC)

    assert active.instructions[-1].opname == "cast"
    assert active.instructions[-1].kwargs["mode"] is RoundMode.TRUNC


@pytest.mark.parametrize(
    "name,src_dt,src_torch,dst_dt,dst_torch,modes",
    [pair for pair in _CAST_PAIRS if RoundMode.NONE not in pair[5]],
)
def test_vec_cast_float_to_int_rejects_unsupported_cast_none(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    src = Tensor(src_dt, [1, 64], Position.UB, name="src")
    dst = Tensor(dst_dt, [1, 64], Position.UB, name="dst")

    with pytest.raises(ValueError, match="cast supports round_mode"):
        vec_cast(dst, src, round_mode=RoundMode.NONE)


@pytest.mark.parametrize(
    "name,src_dt,src_torch,dst_dt,dst_torch,modes",
    [pair for pair in _CAST_PAIRS if RoundMode.NONE in pair[5]],
)
def test_vec_cast_float_to_int_accepts_supported_cast_none(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    active = SimpleNamespace(instructions=[], vector_mode="repeat")
    globvars.active_kernel = active
    src = Tensor(src_dt, [1, 128], Position.UB, name="src")
    dst = Tensor(dst_dt, [1, 128], Position.UB, name="dst")

    vec_cast(dst, src, round_mode=RoundMode.NONE)

    assert active.instructions[-1].kwargs["mode"] is RoundMode.NONE


def test_vec_cast_rejects_unsupported_float_to_int_pair() -> None:
    src = Tensor(DT.float, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.uint8, [1, 64], Position.UB, name="dst")

    with pytest.raises(ValueError, match="A2 cast only supports listed Cast pairs"):
        vec_cast(dst, src, round_mode=RoundMode.TRUNC)


def test_vec_cast_forces_none_for_listed_widening_pair() -> None:
    active = SimpleNamespace(instructions=[], vector_mode="repeat")
    globvars.active_kernel = active
    src = Tensor(DT.half, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.float, [1, 64], Position.UB, name="dst")

    vec_cast(dst, src)

    assert active.instructions[-1].kwargs["mode"] is RoundMode.NONE


def test_vec_cast_accepts_listed_odd_round_mode() -> None:
    active = SimpleNamespace(instructions=[], vector_mode="repeat")
    globvars.active_kernel = active
    src = Tensor(DT.float, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.half, [1, 64], Position.UB, name="dst")

    vec_cast(dst, src, round_mode=RoundMode.ODD)

    assert active.instructions[-1].kwargs["mode"] is RoundMode.ODD


def test_vec_cast_rejects_hybrid_round_mode() -> None:
    src = Tensor(DT.float, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.half, [1, 64], Position.UB, name="dst")

    with pytest.raises(ValueError, match="float -> half cast supports round_mode"):
        vec_cast(dst, src, round_mode=RoundMode.HYBRID)


def test_vec_cast_rejects_unlisted_pair() -> None:
    src = Tensor(DT.half, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.uint16, [1, 64], Position.UB, name="dst")

    with pytest.raises(ValueError, match="A2 cast only supports listed Cast pairs"):
        vec_cast(dst, src, round_mode=RoundMode.TRUNC)


def test_micro_cast_stub_allows_listed_non_int4_pair() -> None:
    inst = _emit_micro_cast_stub(DT.float, DT.half)

    assert inst.opname == "micro_cast"
    assert inst.kwargs["ddst"] is DT.float
    assert inst.kwargs["dsrc"] is DT.half


@pytest.mark.parametrize(
    "dst_dt,src_dt",
    [
        (DT.e5m2, DT.float),
        (DT.e4m3, DT.float),
        (DT.float, DT.e5m2),
        (DT.float, DT.e4m3),
    ],
)
def test_micro_cast_stub_allows_a5_fp8_float32_pairs(dst_dt, src_dt) -> None:
    inst = _emit_micro_cast_stub(dst_dt, src_dt)

    assert inst.opname == "micro_cast"
    assert inst.kwargs["ddst"] is dst_dt
    assert inst.kwargs["dsrc"] is src_dt


def test_micro_cast_stub_rejects_unlisted_pair() -> None:
    with pytest.raises(ValueError, match="A5 cast only supports listed Cast pairs"):
        _emit_micro_cast_stub(DT.uint8, DT.float)


def test_micro_cast_stub_rejects_int4_related_pair() -> None:
    with pytest.raises(ValueError, match="A5 micro cast does not support int4-related"):
        _emit_micro_cast_stub(DT.half, DT.int4)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _FLOAT_REDUCE_PAIRS)
def test_vec_cast_float_reduce_preserves_requested_round_mode(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    active = SimpleNamespace(instructions=[], vector_mode="repeat")
    globvars.active_kernel = active
    src = Tensor(src_dt, [1, 64], Position.UB, name="src")
    dst = Tensor(dst_dt, [1, 64], Position.UB, name="dst")

    vec_cast(dst, src, round_mode=RoundMode.TRUNC)

    assert active.instructions[-1].opname == "cast"
    assert active.instructions[-1].kwargs["mode"] is RoundMode.TRUNC


def test_vec_cast_float_to_bfloat16_rejects_odd_and_none() -> None:
    src = Tensor(DT.float, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.bfloat16, [1, 64], Position.UB, name="dst")

    with pytest.raises(ValueError, match="float -> bfloat16_t cast supports round_mode"):
        vec_cast(dst, src, round_mode=RoundMode.ODD)
    with pytest.raises(ValueError, match="float -> bfloat16_t cast supports round_mode"):
        vec_cast(dst, src, round_mode=RoundMode.NONE)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _FLOAT_TO_FLOAT_PAIRS)
def test_vec_cast_float_to_float_preserves_requested_round_mode(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    active = SimpleNamespace(instructions=[], vector_mode="repeat")
    globvars.active_kernel = active
    src = Tensor(src_dt, [1, 64], Position.UB, name="src")
    dst = Tensor(dst_dt, [1, 64], Position.UB, name="dst")

    vec_cast(dst, src, round_mode=RoundMode.TRUNC)

    assert active.instructions[-1].opname == "cast"
    assert active.instructions[-1].kwargs["mode"] is RoundMode.TRUNC


def test_vec_cast_float_to_float_rejects_none() -> None:
    src = Tensor(DT.float, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.float, [1, 64], Position.UB, name="dst")

    with pytest.raises(ValueError, match="float -> float cast supports round_mode"):
        vec_cast(dst, src, round_mode=RoundMode.NONE)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _INT_TO_FLOAT_PAIRS)
def test_vec_cast_int_to_float_preserves_requested_round_mode(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    active = SimpleNamespace(instructions=[], vector_mode="repeat")
    globvars.active_kernel = active
    src = Tensor(src_dt, [1, 64], Position.UB, name="src")
    dst = Tensor(dst_dt, [1, 64], Position.UB, name="dst")

    vec_cast(dst, src, round_mode=RoundMode.TRUNC)

    assert active.instructions[-1].opname == "cast"
    assert active.instructions[-1].kwargs["mode"] is RoundMode.TRUNC


def test_vec_cast_int32_to_float_accepts_none() -> None:
    active = SimpleNamespace(instructions=[], vector_mode="repeat")
    globvars.active_kernel = active
    src = Tensor(DT.int, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.float, [1, 64], Position.UB, name="dst")

    vec_cast(dst, src, round_mode=RoundMode.NONE)

    assert active.instructions[-1].kwargs["mode"] is RoundMode.NONE


def test_vec_cast_int64_to_float_rejects_none() -> None:
    src = Tensor(DT.int64, [1, 64], Position.UB, name="src")
    dst = Tensor(DT.float, [1, 64], Position.UB, name="dst")

    with pytest.raises(ValueError, match="int64_t -> float cast supports round_mode"):
        vec_cast(dst, src, round_mode=RoundMode.NONE)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _FLOAT_REDUCE_PAIRS)
def test_vpipe_cast_float_reduce_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    logical = _logical_elems_per_repeat(src_torch, dst_torch)
    dst_rep, src_rep = _vec_rep_strides(src_torch, dst_torch)
    for mode in modes:
        src = _tile_reduce_values(logical, src_torch, dst_torch)
        dst = torch.zeros(logical, dtype=dst_torch)
        pipe = object.__new__(VPipe)
        pipe.memory_store = _TensorStore({"src": src, "dst": dst})
        pipe.vector_mode = "repeat"
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)

        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="cast",
                args={
                    "dst": "dst",
                    "src": "src",
                    "mode": mode,
                    "repeat": 1,
                    "dst_blk_stride": 1,
                    "src_blk_stride": 1,
                    "dst_rep_stride": dst_rep,
                    "src_rep_stride": src_rep,
                },
            )
        )

        expected_base = _FLOAT_REDUCE_EXPECTED[dst_torch][_mode_name(mode)]
        reps = (logical + int(expected_base.numel()) - 1) // int(expected_base.numel())
        torch.testing.assert_close(dst, expected_base.repeat(reps)[:logical])


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _FLOAT_REDUCE_PAIRS)
def test_vpipe_count_mode_float_reduce_rounding_modes(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    count = 16
    for mode in modes:
        src = _tile_reduce_values(count, src_torch, dst_torch)
        dst = torch.zeros(count, dtype=dst_torch)
        pipe = object.__new__(VPipe)
        pipe.memory_store = _TensorStore({"src": src, "dst": dst})
        pipe.vector_mode = "count"
        pipe.count_register = count
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)

        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="cast",
                args={"dst": "dst", "src": "src", "mode": mode, "count": count},
            )
        )

        expected_base = _FLOAT_REDUCE_EXPECTED[dst_torch][_mode_name(mode)]
        reps = (count + int(expected_base.numel()) - 1) // int(expected_base.numel())
        torch.testing.assert_close(dst, expected_base.repeat(reps)[:count])


def test_vpipe_count_mode_float_to_half_midpoint_neighbors() -> None:
    src = torch.tensor(
        [
            _next_float32(4098.0, float("-inf")),
            4098.0,
            _next_float32(4098.0, float("inf")),
            _next_float32(-4098.0, float("-inf")),
            -4098.0,
            _next_float32(-4098.0, float("inf")),
        ],
        dtype=torch.float32,
    )

    expected_rint = torch.tensor([4096.0, 4096.0, 4100.0, -4100.0, -4096.0, -4096.0], dtype=torch.float16)
    expected_round = torch.tensor([4096.0, 4100.0, 4100.0, -4100.0, -4100.0, -4096.0], dtype=torch.float16)
    expected_odd = torch.tensor([4100.0, 4100.0, 4100.0, -4100.0, -4100.0, -4100.0], dtype=torch.float16)

    torch.testing.assert_close(_vpipe_count_cast(src, torch.float16, RoundMode.TO_EVEN), expected_rint, rtol=0, atol=0)
    torch.testing.assert_close(_vpipe_count_cast(src, torch.float16, RoundMode.AWAY_FROM_ZERO), expected_round, rtol=0, atol=0)
    torch.testing.assert_close(_vpipe_count_cast(src, torch.float16, RoundMode.ODD), expected_odd, rtol=0, atol=0)


def test_vpipe_count_mode_float_to_bfloat16_midpoint_neighbors() -> None:
    src = torch.tensor(
        [
            _next_float32(257.0, float("-inf")),
            257.0,
            _next_float32(257.0, float("inf")),
            _next_float32(-257.0, float("-inf")),
            -257.0,
            _next_float32(-257.0, float("inf")),
        ],
        dtype=torch.float32,
    )

    expected_rint = torch.tensor([256.0, 256.0, 258.0, -258.0, -256.0, -256.0], dtype=torch.bfloat16)
    expected_round = torch.tensor([256.0, 258.0, 258.0, -258.0, -258.0, -256.0], dtype=torch.bfloat16)

    torch.testing.assert_close(_vpipe_count_cast(src, torch.bfloat16, RoundMode.TO_EVEN), expected_rint, rtol=0, atol=0)
    torch.testing.assert_close(_vpipe_count_cast(src, torch.bfloat16, RoundMode.AWAY_FROM_ZERO), expected_round, rtol=0, atol=0)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _FLOAT_REDUCE_PAIRS)
def test_micro_cast_float_reduce_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    for mode in modes:
        src, expected = _micro_reduce_src_and_expected(src_torch, dst_torch, mode)
        src_reg = Reg(src_dt, name="src")
        dst_reg = Reg(dst_dt, name="dst")
        mask = MaskReg(dst_dt, init_mode=MaskType.ALL, name="mask")
        config = CastConfig(round_mode=mode, reg_layout=RegLayout.ZERO, saturate=True, name="cfg")
        ctx = MicroContext(
            regs={"src": src},
            masks={"mask": torch.ones(_lanes(dst_torch), dtype=torch.bool)},
        )
        runtime = MicroRuntime()

        runtime._stack.append(ctx)
        try:
            runtime._dispatch(
                "micro_cast",
                {"dst": dst_reg, "src": src_reg, "config": config, "mask": mask, "ddst": dst_dt},
                SharedMemoryStore(),
            )
        finally:
            runtime._stack.pop()

        torch.testing.assert_close(ctx.regs["dst"], expected)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _FLOAT_TO_FLOAT_PAIRS)
def test_vpipe_cast_float_to_float_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    logical = _logical_elems_per_repeat(src_torch, dst_torch)
    dst_rep, src_rep = _vec_rep_strides(src_torch, dst_torch)
    for mode in modes:
        src = _tile_values(logical, src_torch)
        dst = torch.zeros(logical, dtype=dst_torch)
        pipe = object.__new__(VPipe)
        pipe.memory_store = _TensorStore({"src": src, "dst": dst})
        pipe.vector_mode = "repeat"
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)

        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="cast",
                args={
                    "dst": "dst",
                    "src": "src",
                    "mode": mode,
                    "repeat": 1,
                    "dst_blk_stride": 1,
                    "src_blk_stride": 1,
                    "dst_rep_stride": dst_rep,
                    "src_rep_stride": src_rep,
                },
            )
        )

        torch.testing.assert_close(dst, _expected_float_to_float(src, mode), rtol=0, atol=0)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _FLOAT_TO_FLOAT_PAIRS)
def test_vpipe_count_mode_float_to_float_rounding_modes(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    count = 16
    for mode in modes:
        src = _tile_values(count, src_torch)
        dst = torch.zeros(count, dtype=dst_torch)
        pipe = object.__new__(VPipe)
        pipe.memory_store = _TensorStore({"src": src, "dst": dst})
        pipe.vector_mode = "count"
        pipe.count_register = count
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)

        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="cast",
                args={"dst": "dst", "src": "src", "mode": mode, "count": count},
            )
        )

        torch.testing.assert_close(dst, _expected_float_to_float(src, mode), rtol=0, atol=0)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _FLOAT_TO_FLOAT_PAIRS)
def test_micro_cast_float_to_float_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    for mode in modes:
        src = _tile_values(_lanes(src_torch), src_torch)
        expected = _expected_float_to_float(src, mode)
        src_reg = Reg(src_dt, name="src")
        dst_reg = Reg(dst_dt, name="dst")
        mask = MaskReg(dst_dt, init_mode=MaskType.ALL, name="mask")
        config = CastConfig(round_mode=mode, reg_layout=RegLayout.ZERO, saturate=True, name="cfg")
        ctx = MicroContext(
            regs={"src": src},
            masks={"mask": torch.ones(_lanes(dst_torch), dtype=torch.bool)},
        )
        runtime = MicroRuntime()

        runtime._stack.append(ctx)
        try:
            runtime._dispatch(
                "micro_cast",
                {"dst": dst_reg, "src": src_reg, "config": config, "mask": mask, "ddst": dst_dt},
                SharedMemoryStore(),
            )
        finally:
            runtime._stack.pop()

        torch.testing.assert_close(ctx.regs["dst"], expected, rtol=0, atol=0)


@pytest.mark.parametrize(
    "dst_dt,dst_torch_attr",
    [
        (DT.e5m2, "float8_e5m2"),
        (DT.e4m3, "float8_e4m3fn"),
    ],
)
def test_micro_cast_float32_to_fp8_uses_fp8_rounding(dst_dt, dst_torch_attr) -> None:
    if not hasattr(torch, dst_torch_attr):
        pytest.skip("Current torch build does not support " + dst_torch_attr)
    dst_torch = getattr(torch, dst_torch_attr)
    src = torch.linspace(-4.0, 4.0, _lanes(torch.float32), dtype=torch.float32)
    expected = torch.zeros(_lanes(dst_torch), dtype=dst_torch)
    expected[torch.arange(_lanes(torch.float32)) * 4] = src.to(dst_torch)
    src_reg = Reg(DT.float, name="src")
    dst_reg = Reg(dst_dt, name="dst")
    mask = MaskReg(dst_dt, init_mode=MaskType.ALL, name="mask")
    config = CastConfig(round_mode=RoundMode.NONE, reg_layout=RegLayout.ZERO, saturate=True, name="cfg")
    ctx = MicroContext(
        regs={"src": src},
        masks={"mask": torch.ones(_lanes(dst_torch), dtype=torch.bool)},
    )
    runtime = MicroRuntime()

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {"dst": dst_reg, "src": src_reg, "config": config, "mask": mask, "ddst": dst_dt},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    torch.testing.assert_close(
        ctx.regs["dst"].to(torch.float32), expected.to(torch.float32), rtol=0, atol=0, equal_nan=True
    )


@pytest.mark.parametrize(
    "src_dt,src_torch_attr",
    [
        (DT.e5m2, "float8_e5m2"),
        (DT.e4m3, "float8_e4m3fn"),
    ],
)
def test_micro_cast_fp8_to_float32_uses_layout_zero(src_dt, src_torch_attr) -> None:
    if not hasattr(torch, src_torch_attr):
        pytest.skip("Current torch build does not support " + src_torch_attr)
    src_torch = getattr(torch, src_torch_attr)
    values = torch.linspace(-4.0, 4.0, _lanes(torch.float32), dtype=torch.float32).to(src_torch)
    src = torch.zeros(_lanes(src_torch), dtype=src_torch)
    src[torch.arange(_lanes(torch.float32)) * 4] = values
    expected = values.to(torch.float32)
    src_reg = Reg(src_dt, name="src")
    dst_reg = Reg(DT.float, name="dst")
    mask = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask")
    config = CastConfig(round_mode=RoundMode.NONE, reg_layout=RegLayout.ZERO, saturate=True, name="cfg")
    ctx = MicroContext(
        regs={"src": src},
        masks={"mask": torch.ones(_lanes(torch.float32), dtype=torch.bool)},
    )
    runtime = MicroRuntime()

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {"dst": dst_reg, "src": src_reg, "config": config, "mask": mask, "ddst": DT.float},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    torch.testing.assert_close(ctx.regs["dst"], expected, rtol=0, atol=0, equal_nan=True)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _INT_TO_FLOAT_PAIRS)
def test_vpipe_cast_int_to_float_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    logical = _logical_elems_per_repeat(src_torch, dst_torch)
    dst_rep, src_rep = _vec_rep_strides(src_torch, dst_torch)
    for mode in modes:
        src = _tile_int_to_float_values(logical, src_torch, dst_torch)
        dst = torch.zeros(logical, dtype=dst_torch)
        pipe = object.__new__(VPipe)
        pipe.memory_store = _TensorStore({"src": src, "dst": dst})
        pipe.vector_mode = "repeat"
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)

        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="cast",
                args={
                    "dst": "dst",
                    "src": "src",
                    "mode": mode,
                    "repeat": 1,
                    "dst_blk_stride": 1,
                    "src_blk_stride": 1,
                    "dst_rep_stride": dst_rep,
                    "src_rep_stride": src_rep,
                },
            )
        )

        expected_base = _INT_TO_FLOAT_EXPECTED[(src_torch, dst_torch)][_mode_name(mode)]
        reps = (logical + int(expected_base.numel()) - 1) // int(expected_base.numel())
        torch.testing.assert_close(dst, expected_base.repeat(reps)[:logical], rtol=0, atol=0)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _INT_TO_FLOAT_PAIRS)
def test_vpipe_count_mode_int_to_float_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    count = 8
    for mode in modes:
        src = _tile_int_to_float_values(count, src_torch, dst_torch)
        dst = torch.zeros(count, dtype=dst_torch)
        pipe = object.__new__(VPipe)
        pipe.memory_store = _TensorStore({"src": src, "dst": dst})
        pipe.vector_mode = "count"
        pipe.count_register = count
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)

        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="cast",
                args={"dst": "dst", "src": "src", "mode": mode, "count": count},
            )
        )

        expected_base = _INT_TO_FLOAT_EXPECTED[(src_torch, dst_torch)][_mode_name(mode)]
        reps = (count + int(expected_base.numel()) - 1) // int(expected_base.numel())
        torch.testing.assert_close(dst, expected_base.repeat(reps)[:count], rtol=0, atol=0)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _INT_TO_FLOAT_PAIRS)
def test_micro_cast_int_to_float_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    for mode in modes:
        src, expected = _micro_int_to_float_src_and_expected(src_torch, dst_torch, mode)
        src_reg = Reg(src_dt, name="src")
        dst_reg = Reg(dst_dt, name="dst")
        mask = MaskReg(dst_dt, init_mode=MaskType.ALL, name="mask")
        config = CastConfig(round_mode=mode, reg_layout=RegLayout.ZERO, saturate=True, name="cfg")
        ctx = MicroContext(
            regs={"src": src},
            masks={"mask": torch.ones(_lanes(dst_torch), dtype=torch.bool)},
        )
        runtime = MicroRuntime()

        runtime._stack.append(ctx)
        try:
            runtime._dispatch(
                "micro_cast",
                {"dst": dst_reg, "src": src_reg, "config": config, "mask": mask, "ddst": dst_dt},
                SharedMemoryStore(),
            )
        finally:
            runtime._stack.pop()

        torch.testing.assert_close(ctx.regs["dst"], expected, rtol=0, atol=0)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _CAST_PAIRS)
def test_vpipe_cast_float_to_int_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    logical = _logical_elems_per_repeat(src_torch, dst_torch)
    dst_rep, src_rep = _vec_rep_strides(src_torch, dst_torch)
    for mode in modes:
        src = _tile_values(logical, src_torch)
        dst = torch.zeros(logical, dtype=dst_torch)
        pipe = object.__new__(VPipe)
        pipe.memory_store = _TensorStore({"src": src, "dst": dst})
        pipe.vector_mode = "repeat"
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)

        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="cast",
                args={
                    "dst": "dst",
                    "src": "src",
                    "mode": mode,
                    "repeat": 1,
                    "dst_blk_stride": 1,
                    "src_blk_stride": 1,
                    "dst_rep_stride": dst_rep,
                    "src_rep_stride": src_rep,
                },
            )
        )

        torch.testing.assert_close(dst, _expected_cast(src, mode, dst_torch))


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _CAST_PAIRS)
def test_vpipe_count_mode_float_to_int_rounding_modes(
    name, src_dt, src_torch, dst_dt, dst_torch, modes
) -> None:
    count = 16
    for mode in modes:
        src = _tile_values(count, src_torch)
        dst = torch.zeros(count, dtype=dst_torch)
        pipe = object.__new__(VPipe)
        pipe.memory_store = _TensorStore({"src": src, "dst": dst})
        pipe.vector_mode = "count"
        pipe.count_register = count
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)

        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="cast",
                args={"dst": "dst", "src": "src", "mode": mode, "count": count},
            )
        )

        torch.testing.assert_close(dst, _expected_cast(src, mode, dst_torch))


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch,modes", _CAST_PAIRS)
def test_micro_cast_float_to_int_rounding_modes(name, src_dt, src_torch, dst_dt, dst_torch, modes) -> None:
    for mode in modes:
        src, expected = _micro_src_and_expected(src_torch, dst_torch, mode)
        src_reg = Reg(src_dt, name="src")
        dst_reg = Reg(dst_dt, name="dst")
        mask = MaskReg(dst_dt, init_mode=MaskType.ALL, name="mask")
        config = CastConfig(round_mode=mode, reg_layout=RegLayout.ZERO, saturate=True, name="cfg")
        ctx = MicroContext(
            regs={"src": src},
            masks={"mask": torch.ones(_lanes(dst_torch), dtype=torch.bool)},
        )
        runtime = MicroRuntime()

        runtime._stack.append(ctx)
        try:
            runtime._dispatch(
                "micro_cast",
                {"dst": dst_reg, "src": src_reg, "config": config, "mask": mask, "ddst": dst_dt},
                SharedMemoryStore(),
            )
        finally:
            runtime._stack.pop()

        torch.testing.assert_close(ctx.regs["dst"], expected)


@pytest.mark.parametrize("name,src_dt,src_torch,dst_dt,dst_torch", _NO_ROUND_PAIRS)
def test_vpipe_count_mode_no_round_and_integer_pairs(name, src_dt, src_torch, dst_dt, dst_torch) -> None:
    count = 10
    src = _tile_no_round_values(count, src_torch)
    dst = torch.zeros(count, dtype=dst_torch)
    pipe = object.__new__(VPipe)
    pipe.memory_store = _TensorStore({"src": src, "dst": dst})
    pipe.vector_mode = "count"
    pipe.count_register = count
    pipe.current_mask = torch.ones(256, dtype=torch.uint8)

    pipe.execute(
        PipeTask(
            pipe_name="V",
            opname="cast",
            args={"dst": "dst", "src": "src", "mode": RoundMode.NONE, "count": count},
        )
    )

    torch.testing.assert_close(dst, src.to(dst_torch), rtol=0, atol=0)


def test_vpipe_cast_float_to_small_int_saturates_special_values() -> None:
    src = torch.tensor([-200.0, -129.0, 127.0, 128.0, float("inf"), float("-inf"), float("nan")], dtype=torch.float16)
    dst = torch.zeros(int(src.numel()), dtype=torch.int8)
    pipe = object.__new__(VPipe)
    pipe.memory_store = _TensorStore({"src": src, "dst": dst})
    pipe.vector_mode = "count"
    pipe.count_register = int(src.numel())
    pipe.current_mask = torch.ones(256, dtype=torch.uint8)

    pipe.execute(
        PipeTask(
            pipe_name="V",
            opname="cast",
            args={"dst": "dst", "src": "src", "mode": RoundMode.TO_EVEN, "count": int(src.numel())},
        )
    )

    expected = torch.tensor([-128, -128, 127, 127, 127, -128, 0], dtype=torch.int8)
    torch.testing.assert_close(dst, expected)
