import contextlib
import io

import pytest

from easyasc.a5 import *
from easyasc.parser.asc import translate_split


def _translate_silently(instructions, name: str):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        return translate_split(instructions, name)


@kernel()
def iadd_codegen_counter_kernel(y: GMTensor):
    cnt = Var(0, DT.int64, name='cnt')
    cnt += 1
    kernel_print('cnt=%lld\n', cnt)
    return y


def test_iadd_keeps_float_dtype_for_float_rhs() -> None:
    acc = Var(0.0, DT.float, name='acc')
    acc += 1.0
    assert acc.dtype is DT.float


def test_iadd_rejects_int_rhs_for_float_var() -> None:
    acc = Var(0.0, DT.float, name='acc')
    with pytest.raises(TypeError, match=r'only supports \+= int'):
        acc += 1
    assert acc.dtype is DT.float


def test_iadd_accepts_int_rhs_for_int64_var_without_overwriting_dtype() -> None:
    acc = Var(0, DT.int64, name='acc')
    acc += 1
    assert acc.dtype is DT.int64


def test_iadd_rejects_mismatched_var_dtype() -> None:
    acc = Var(0, DT.int64, name='acc')
    other = Var(1, DT.int, name='other')
    with pytest.raises(TypeError, match=r'only supports \+= Var'):
        acc += other
    assert acc.dtype is DT.int64


def test_iadd_accepts_matching_var_dtype() -> None:
    acc = Var(0, DT.int64, name='acc')
    other = Var(1, DT.int64, name='other')
    acc += other
    assert acc.dtype is DT.int64


def test_iadd_codegen_preserves_self_dtype() -> None:
    y = GMTensor(DT.int64, [1, 1], name='y')
    iadd_codegen_counter_kernel(y)
    cube_code, vec_code = _translate_silently(iadd_codegen_counter_kernel.instructions, 'iadd_codegen_counter_kernel')
    code = cube_code + '\n' + vec_code
    assert 'int64_t cnt = 0;' in code
    assert 'cnt = cnt + 1;' in code
