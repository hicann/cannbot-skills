import os

import torch

from easyasc.a5 import *


ROWS = 1
COLS = 64
FULL_SIM_MATRIX = os.environ.get("EASYASC_FULL_SIM_MATRIX") == "1"


def _sim_cases(smoke_cases, full_cases):
    return full_cases if FULL_SIM_MATRIX else smoke_cases


def _run_sim_case(kernel_fn, ref_fn, *args) -> None:
    x = torch.arange(ROWS * COLS, dtype=torch.float32).reshape(ROWS, COLS)
    y = torch.zeros_like(x)
    out = OpExec(kernel_fn, simulator=True)(x, y, *args)
    ref = ref_fn(x, *args)
    torch.testing.assert_close(out, ref, rtol=1e-4, atol=1e-4)


@vf()
def _add_bias_row_vf(src: Tensor, dst: Tensor, bias: Var):
    reg = Reg(DT.float)
    reg <<= src[0:ROWS, 0:COLS]
    reg <<= reg + bias
    dst[0:ROWS, 0:COLS] <<= reg


# --- and kernel ---

@kernel()
def _and_kernel(x: GMTensor, y: GMTensor, a: Var, b: Var):
    src_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    dst_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    with auto_sync():
        src_ub <<= x[0:ROWS, 0:COLS]
        if a > 0 and b > 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(10.0))
        else:
            _add_bias_row_vf(src_ub, dst_ub, Var(20.0))
        y[0:ROWS, 0:COLS] <<= dst_ub
    return y


def _and_ref(x, a: int, b: int):
    bias = 10.0 if (a > 0 and b > 0) else 20.0
    return x + bias


# --- or kernel ---

@kernel()
def _or_kernel(x: GMTensor, y: GMTensor, a: Var, b: Var):
    src_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    dst_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    with auto_sync():
        src_ub <<= x[0:ROWS, 0:COLS]
        if a > 0 or b > 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(10.0))
        else:
            _add_bias_row_vf(src_ub, dst_ub, Var(20.0))
        y[0:ROWS, 0:COLS] <<= dst_ub
    return y


def _or_ref(x, a: int, b: int):
    bias = 10.0 if (a > 0 or b > 0) else 20.0
    return x + bias


# --- not kernel ---

@kernel()
def _not_kernel(x: GMTensor, y: GMTensor, a: Var):
    src_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    dst_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    with auto_sync():
        src_ub <<= x[0:ROWS, 0:COLS]
        if not (a > 0):
            _add_bias_row_vf(src_ub, dst_ub, Var(10.0))
        else:
            _add_bias_row_vf(src_ub, dst_ub, Var(20.0))
        y[0:ROWS, 0:COLS] <<= dst_ub
    return y


def _not_ref(x, a: int):
    bias = 10.0 if (not (a > 0)) else 20.0
    return x + bias


# --- mixed (precedence) kernel ---

@kernel()
def _mixed_kernel(x: GMTensor, y: GMTensor, a: Var, b: Var, c: Var):
    src_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    dst_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    with auto_sync():
        src_ub <<= x[0:ROWS, 0:COLS]
        if (a > 0 and b > 0) or c == 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(10.0))
        else:
            _add_bias_row_vf(src_ub, dst_ub, Var(20.0))
        y[0:ROWS, 0:COLS] <<= dst_ub
    return y


def _mixed_ref(x, a: int, b: int, c: int):
    bias = 10.0 if ((a > 0 and b > 0) or c == 0) else 20.0
    return x + bias


# --- var-truthy kernel ---

@kernel()
def _var_truthy_kernel(x: GMTensor, y: GMTensor, a: Var, b: Var):
    src_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    dst_ub = Tensor(DT.float, [ROWS, COLS], Position.UB)
    with auto_sync():
        src_ub <<= x[0:ROWS, 0:COLS]
        if a and b > 0:
            _add_bias_row_vf(src_ub, dst_ub, Var(10.0))
        else:
            _add_bias_row_vf(src_ub, dst_ub, Var(20.0))
        y[0:ROWS, 0:COLS] <<= dst_ub
    return y


def _var_truthy_ref(x, a: int, b: int):
    bias = 10.0 if (bool(a) and b > 0) else 20.0
    return x + bias


# --- AST regression guard ---

def test_and_kernel_emits_single_composite_cond_on_start_if() -> None:
    x = GMTensor(DT.float, [ROWS, COLS])
    y = GMTensor(DT.float, [ROWS, COLS])
    _and_kernel(x, y, Var(1), Var(1))

    opnames = [inst.opname for inst in _and_kernel.instructions]
    assert opnames.count("start_if") == 1
    assert opnames.count("start_else") == 1
    assert opnames.count("end_if") == 1

    start_if = next(inst for inst in _and_kernel.instructions if inst.opname == "start_if")
    cond_text = str(start_if.kwargs.get("cond"))
    assert "&&" in cond_text


# --- simulator tests ---

def test_and_simulator_matches_reference() -> None:
    cases = _sim_cases(
        smoke_cases=[(7, 7), (7, -3)],
        full_cases=[(7, 7), (7, -3), (-5, 3), (-7, -3), (3, -2), (-1, 5)],
    )
    for a, b in cases:
        _run_sim_case(_and_kernel, _and_ref, a, b)


def test_or_simulator_matches_reference() -> None:
    cases = _sim_cases(
        smoke_cases=[(7, -3), (-5, 3), (-7, -3)],
        full_cases=[(7, 7), (7, -3), (-5, 3), (-7, -3), (3, -2), (-1, -5)],
    )
    for a, b in cases:
        _run_sim_case(_or_kernel, _or_ref, a, b)


def test_not_simulator_matches_reference() -> None:
    cases = _sim_cases(
        smoke_cases=[7, -3],
        full_cases=[7, -3, -7, 5],
    )
    for a in cases:
        _run_sim_case(_not_kernel, _not_ref, a)


def test_mixed_simulator_matches_reference() -> None:
    cases = _sim_cases(
        smoke_cases=[
            (7, 3, 5),    # and-branch true
            (7, -3, 0),   # c==0 branch true
            (7, -3, 5),   # both false
        ],
        full_cases=[
            (7, 3, 5),    # and-branch true (a>0 && b>0) -> bias 10
            (7, -3, 0),   # or-branch true via c==0 -> bias 10
            (-7, -3, 5),  # both false -> bias 20
            (7, -3, 5),   # both false -> bias 20
            (-1, 5, 0),   # or-branch true via c==0 -> bias 10
            (5, 3, 3),    # and-branch true -> bias 10
        ],
    )
    for a, b, c in cases:
        _run_sim_case(_mixed_kernel, _mixed_ref, a, b, c)


def test_var_truthy_simulator_matches_reference() -> None:
    cases = _sim_cases(
        smoke_cases=[(-5, 3), (0, 3), (7, -3)],
        full_cases=[(7, 3), (7, -3), (-5, 3), (-7, -3), (0, 3), (5, 3)],
    )
    for a, b in cases:
        _run_sim_case(_var_truthy_kernel, _var_truthy_ref, a, b)
