from types import SimpleNamespace

import pytest
import torch

from easyasc.simulator.pipe_cube import CubeMTE1Pipe, CubeMTE2Pipe, FixPipe, MPipe
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe import PipeS
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.simulator.pipe_vec import MTE3Pipe, VPipe, VecMTE2Pipe
from easyasc.simulator.program import ControlInstruction, PipeTask
from easyasc.simulator.sync import Mailbox
from easyasc.utils.comparemode import CompareMode
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.instruction import Instruction
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.var import Var

from testcases.simulator.micro._micro_test_helpers import _TensorStore


def test_micro_movemaskspr_requires_spr_snapshot() -> None:
    # move_mask_spr (MoveMask<T>()) reads the vector-mask SPR handed in by the vec pipe; a bare
    # MicroRuntime with no SPR snapshot must raise a clear error rather than silently returning junk.
    runtime = MicroRuntime()
    runtime._stack.append(MicroContext())  # spr_mask defaults to None
    dst = MaskReg(DT.int, init_mode=MaskType.NONE, name="dst")
    try:
        with pytest.raises(RuntimeError, match="no vector-mask SPR snapshot"):
            runtime._dispatch("micro_movemaskspr", {"dst": dst}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_micro_cast_requires_dtype_or_ddst() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")

    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=src),
            Instruction("create_reg", reg=dst),
            Instruction("micro_vdup", dst=src, src=1.0),
            Instruction("micro_cast", dst=dst, src=src),
        ]
    }

    with pytest.raises(KeyError, match="micro_cast requires dtype or ddst"):
        runtime.execute_call_micro(micro_def, {}, {}, SharedMemoryStore())
def test_micro_cast_rejects_invalid_mode() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.int, name="dst")
    mask_all = MaskReg(DT.int, init_mode=MaskType.ALL, name="mask_all")

    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=src),
            Instruction("create_reg", reg=dst),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("micro_vdup", dst=src, src=1.25),
            Instruction("micro_cast", dst=dst, src=src, ddst=DT.int, mode="BAD_MODE", mask=mask_all),
        ]
    }

    with pytest.raises(ValueError, match="unsupported micro_cast mode"):
        runtime.execute_call_micro(micro_def, {}, {}, SharedMemoryStore())
def test_micro_cast_rejects_invalid_reg_layout() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.int8, name="dst")
    mask_all = MaskReg(DT.int8, init_mode=MaskType.ALL, name="mask_all")
    bad_cfg = SimpleNamespace(
        reg_layout=SimpleNamespace(name="BAD_LAYOUT"),
        round_mode=SimpleNamespace(name="CAST_TRUNC"),
        saturate=False,
    )

    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=src),
            Instruction("create_reg", reg=dst),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("micro_vdup", dst=src, src=1.25),
            Instruction("micro_cast", dst=dst, src=src, ddst=DT.int8, config=bad_cfg, mask=mask_all),
        ]
    }

    with pytest.raises(ValueError, match="unsupported RegLayout"):
        runtime.execute_call_micro(micro_def, {}, {}, SharedMemoryStore())
def test_micro_unknown_op_raises() -> None:
    runtime = MicroRuntime()

    with pytest.raises(NotImplementedError, match="unhandled micro op: micro_totally_unknown"):
        runtime._dispatch("micro_totally_unknown", {}, SharedMemoryStore())
@pytest.mark.parametrize(
    "pipe_cls, opname, message",
    [
        (VecMTE2Pipe, "totally_unknown", "VecMTE2 unhandled op: totally_unknown"),
        (MTE3Pipe, "totally_unknown", "MTE3 unhandled op: totally_unknown"),
        (CubeMTE2Pipe, "totally_unknown", "CubeMTE2 unhandled op: totally_unknown"),
        (CubeMTE1Pipe, "totally_unknown", "CubeMTE1 unhandled op: totally_unknown"),
        (MPipe, "totally_unknown", "MPipe unhandled op: totally_unknown"),
        (FixPipe, "totally_unknown", "FixPipe unhandled op: totally_unknown"),
    ],
)
def test_pipe_execute_unknown_op_raises(pipe_cls, opname: str, message: str) -> None:
    pipe = object.__new__(pipe_cls)

    with pytest.raises(NotImplementedError, match=message):
        pipe.execute(PipeTask(pipe_name="X", opname=opname, args={}))
def test_vpipe_repeat_unknown_op_raises() -> None:
    pipe = object.__new__(VPipe)
    pipe.vector_mode = "repeat"
    pipe._get_tensor = lambda name: torch.zeros(8, dtype=torch.float32)

    with pytest.raises(NotImplementedError, match="VPipe unhandled op: totally_unknown"):
        pipe.execute(PipeTask(pipe_name="V", opname="totally_unknown", args={"dst": "dst"}))
def test_vpipe_count_unknown_op_raises() -> None:
    pipe = object.__new__(VPipe)
    pipe.vector_mode = "count"
    pipe.count_register = 4
    pipe._get_tensor = lambda name: torch.zeros(8, dtype=torch.float32)

    with pytest.raises(NotImplementedError, match="VPipe count-mode unhandled op: totally_unknown"):
        pipe.execute(PipeTask(pipe_name="V", opname="totally_unknown", args={"dst": "dst"}))
def test_pipe_s_unknown_control_instruction_raises() -> None:
    pipe_s = object.__new__(PipeS)

    with pytest.raises(NotImplementedError, match="PipeS unhandled instruction: totally_unknown"):
        pipe_s._exec_inst(ControlInstruction("totally_unknown", args={}))
def test_vpipe_count_mode_zero_count_raises() -> None:
    pipe = object.__new__(VPipe)
    pipe.vector_mode = "count"
    pipe.count_register = 0
    pipe._get_tensor = lambda name: torch.zeros(8, dtype=torch.float32)

    with pytest.raises(ValueError, match="count-mode vector op requires count_register > 0"):
        pipe.execute(PipeTask(pipe_name="V", opname="vec_v_add", args={"dst": "dst", "src": "src", "src1": "src1"}))
@pytest.mark.parametrize(
    "op, args, message",
    [
        ("create_reg", {"reg": Reg(DT.float, name="dst")}, "micro op requires active context: create_reg"),
        (
            "micro_ub2reg",
            {"dst": Reg(DT.float, name="dst"), "src": SimpleNamespace(name="ub")},
            "micro op requires active context: micro_ub2reg",
        ),
        (
            "micro_datacopygather",
            {"dst": Reg(DT.float, name="dst"), "src": SimpleNamespace(name="ub"), "index": Reg(DT.uint32, name="idx")},
            "micro op requires active context: micro_datacopygather",
        ),
        (
            "micro_gathermask",
            {"dst": Reg(DT.float, name="dst"), "src": Reg(DT.float, name="src")},
            "micro op requires active context: micro_gathermask",
        ),
        (
            "micro_interleave",
            {
                "dst0": Reg(DT.float, name="dst0"),
                "dst1": Reg(DT.float, name="dst1"),
                "src0": Reg(DT.float, name="src0"),
                "src1": Reg(DT.float, name="src1"),
            },
            "micro op requires active context: micro_interleave",
        ),
        (
            "micro_maskpack",
            {"dst": MaskReg(DT.float, init_mode=MaskType.NONE, name="dst"), "src": MaskReg(DT.float, init_mode=MaskType.NONE, name="src")},
            "micro op requires active context: micro_maskpack",
        ),
        ("micro_updatemask", {"dst": MaskReg(DT.float, init_mode=MaskType.NONE, name="dst")}, "micro op requires active context: micro_updatemask"),
        ("micro_vdup", {"dst": Reg(DT.float, name="dst"), "src": 1.0}, "micro op requires active context: micro_vdup"),
    ],
)
def test_micro_requires_active_context(op: str, args, message: str) -> None:
    runtime = MicroRuntime()

    with pytest.raises(RuntimeError, match=message):
        runtime._dispatch(op, args, SharedMemoryStore())
@pytest.mark.parametrize(
    "op, args, message",
    [
        ("create_var", {}, "create_var requires var"),
        ("create_reg", {}, "create_reg requires reg"),
        ("create_reglist", {}, "create_reglist requires reglist"),
        ("create_maskreg", {}, "create_maskreg requires reg"),
        ("micro_slice_tensor", {"src": SimpleNamespace(name="src")}, "micro_slice_tensor requires out"),
        ("micro_ub2reg", {"dst": Reg(DT.float, name="dst")}, "micro_ub2reg requires src"),
        ("micro_reg2ub", {"src": Reg(DT.float, name="src")}, "micro_reg2ub requires dst"),
        ("micro_ub2regcont", {"src": SimpleNamespace(name="ub")}, "micro_ub2regcont requires dst"),
        ("micro_reg2ubcont", {"dst": SimpleNamespace(name="ub")}, "micro_reg2ubcont requires src"),
        (
            "micro_datacopygather",
            {"dst": Reg(DT.float, name="dst"), "src": SimpleNamespace(name="ub")},
            "micro_datacopygather requires index",
        ),
        (
            "micro_datacopyscatter",
            {"dst": SimpleNamespace(name="ub"), "src": Reg(DT.float, name="src")},
            "micro_datacopyscatter requires index",
        ),
        ("micro_gather", {"dst": Reg(DT.float, name="dst"), "src": Reg(DT.float, name="src")}, "micro_gather requires index"),
        ("micro_gathermask", {"dst": Reg(DT.float, name="dst")}, "micro_gathermask requires src"),
        (
            "micro_interleave",
            {"dst0": Reg(DT.float, name="dst0"), "dst1": Reg(DT.float, name="dst1"), "src0": Reg(DT.float, name="src0")},
            "micro_interleave requires src1",
        ),
        (
            "micro_maskinterl",
            {
                "dst0": MaskReg(DT.float, init_mode=MaskType.NONE, name="dst0"),
                "dst1": MaskReg(DT.float, init_mode=MaskType.NONE, name="dst1"),
                "src0": MaskReg(DT.float, init_mode=MaskType.NONE, name="src0"),
            },
            "micro_maskinterl requires src1",
        ),
        (
            "micro_maskpack",
            {"dst": MaskReg(DT.float, init_mode=MaskType.NONE, name="dst")},
            "micro_maskpack requires src",
        ),
        ("micro_updatemask", {}, "micro_updatemask requires dst"),
        ("micro_vdup", {"src": 1.0}, "micro_vdup requires dst"),
        ("micro_vaxpy", {"dst": Reg(DT.float, name="dst")}, "micro_vaxpy requires src"),
        ("micro_compare", {"dst": MaskReg(DT.float, init_mode=MaskType.NONE, name="dst")}, "micro_compare requires lhs"),
        ("micro_select", {"dst": Reg(DT.float, name="dst")}, "micro_select requires src1"),
        ("micro_vcadd", {"dst": Reg(DT.float, name="dst")}, "micro_vcadd requires src"),
        ("micro_shiftls", {"dst": Reg(DT.float, name="dst")}, "micro_shiftls requires src"),
        (
            "micro_vand",
            {"dst": Reg(DT.float, name="dst"), "src1": Reg(DT.float, name="src1")},
            "micro_vand requires src2",
        ),
        ("micro_vnot", {"dst": Reg(DT.float, name="dst")}, "micro_vnot requires src"),
        ("micro_cast", {"dst": Reg(DT.float, name="dst")}, "micro_cast requires src"),
    ],
)
def test_micro_rejects_missing_required_args(op: str, args, message: str) -> None:
    runtime = MicroRuntime()
    runtime._stack.append(MicroContext())
    try:
        with pytest.raises(ValueError, match=message):
            runtime._dispatch(op, args, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_micro_run_loop_requires_active_context() -> None:
    runtime = MicroRuntime()

    with pytest.raises(RuntimeError, match="micro op requires active context: start_micro_loop"):
        runtime._run_loop({"var": "i", "start": 0, "stop": 1, "step": 1}, [], 0, 0, SharedMemoryStore())
@pytest.mark.parametrize(
    "op, ctx, args, message",
    [
        (
            "micro_slice_tensor",
            MicroContext(),
            {"src": SimpleNamespace(name="ub"), "out": SimpleNamespace(name="view")},
            "micro_slice_tensor source view not found: ub",
        ),
        (
            "micro_ub2reg",
            MicroContext(regs={"dst": torch.zeros(64, dtype=torch.float32)}),
            {"dst": Reg(DT.float, name="dst"), "src": SimpleNamespace(name="ub")},
            "micro_ub2reg source view not found: ub",
        ),
        (
            "micro_reg2ub",
            MicroContext(regs={"src": torch.zeros(64, dtype=torch.float32)}),
            {"dst": SimpleNamespace(name="ub"), "src": Reg(DT.float, name="src")},
            "micro_reg2ub destination view not found: ub",
        ),
        (
            "micro_ub2regcont",
            MicroContext(),
            {"dst": SimpleNamespace(name="regs", length=1, dtype=DT.float), "src": SimpleNamespace(name="ub")},
            "micro_ub2regcont source view not found: ub",
        ),
        (
            "micro_reg2ubcont",
            MicroContext(),
            {"dst": SimpleNamespace(name="ub"), "src": SimpleNamespace(name="src", dtype=DT.float)},
            "micro_reg2ubcont destination view not found: ub",
        ),
        (
            "micro_datacopygather",
            MicroContext(regs={"dst": torch.zeros(64, dtype=torch.float32), "idx": torch.zeros(64, dtype=torch.int32)}),
            {"dst": Reg(DT.float, name="dst"), "src": SimpleNamespace(name="ub"), "index": Reg(DT.uint32, name="idx")},
            "micro_datacopygather source view not found: ub",
        ),
        (
            "micro_datacopyscatter",
            MicroContext(regs={"src": torch.zeros(64, dtype=torch.float32), "idx": torch.zeros(64, dtype=torch.int32)}),
            {"dst": SimpleNamespace(name="ub"), "src": Reg(DT.float, name="src"), "index": Reg(DT.uint32, name="idx")},
            "micro_datacopyscatter destination view not found: ub",
        ),
    ],
)
def test_micro_rejects_missing_views(op: str, ctx: MicroContext, args, message: str) -> None:
    runtime = MicroRuntime()
    runtime._stack.append(ctx)
    try:
        with pytest.raises(KeyError, match=message):
            runtime._dispatch(op, args, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_micro_reg2ubcont_requires_existing_source_register() -> None:
    runtime = MicroRuntime()
    ctx = MicroContext(tensor_views={"ub": torch.zeros(64, dtype=torch.float32)})
    runtime._stack.append(ctx)
    try:
        with pytest.raises(KeyError, match="micro_reg2ubcont source register not found: src"):
            runtime._dispatch(
                "micro_reg2ubcont",
                {"dst": SimpleNamespace(name="ub"), "src": SimpleNamespace(name="src", dtype=DT.float)},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()
def test_micro_loop_requires_matching_end_loop() -> None:
    runtime = MicroRuntime()
    micro_def = {"instructions": [Instruction("start_micro_loop", var="i", start=0, stop=1, step=1)]}

    with pytest.raises(ValueError, match="without matching end_loop"):
        runtime.execute_call_micro(micro_def, {}, {}, SharedMemoryStore())
def test_micro_missing_mask_register_raises() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    src2 = Reg(DT.float, name="src2")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    ub_ref = SimpleNamespace(name="ub")

    ctx = MicroContext(
        regs={
            "src": torch.ones(64, dtype=torch.float32),
            "src2": torch.zeros(64, dtype=torch.float32),
            "dst": torch.zeros(64, dtype=torch.float32),
        },
        tensor_views={"ub": torch.zeros(64, dtype=torch.float32)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(KeyError, match="mask register not found: mask"):
            runtime._dispatch("micro_reg2ub", {"dst": ub_ref, "src": src, "mask": mask, "blk_stride": 2}, SharedMemoryStore())

        with pytest.raises(KeyError, match="mask/register selector not found: mask"):
            runtime._dispatch("micro_select", {"dst": dst, "src1": src, "src2": src2, "mask": mask}, SharedMemoryStore())

        with pytest.raises(KeyError, match="mask register not found: mask"):
            runtime._dispatch("micro_gathermask", {"dst": dst, "src": src, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_vpipe_compare_rejects_invalid_mode() -> None:
    # Post vec-migration contract: compare dst must be uint8/int8 (bit-packed bool),
    # src1/src2 are the two comparison streams, mode names are upper-case
    # CompareModeType names. An unknown mode must still raise ValueError.
    tensors = {
        "dst": torch.zeros(32, dtype=torch.uint8),
        "src1": torch.zeros(64, dtype=torch.float32),
        "src2": torch.zeros(64, dtype=torch.float32),
    }

    pipe = object.__new__(VPipe)
    pipe.vector_mode = "repeat"
    pipe.current_mask = torch.ones(256, dtype=torch.uint8)
    pipe._get_tensor = lambda name: tensors[name]

    with pytest.raises(ValueError, match="unsupported vec compare mode: BAD_MODE"):
        pipe.execute(
            PipeTask(
                pipe_name="V",
                opname="vec_v_compare",
                args={
                    "dst": "dst", "src1": "src1", "src2": "src2",
                    "repeat": 1, "mode": "BAD_MODE",
                    "dst_blk_stride": 1, "dst_rep_stride": 8,
                    "src1_blk_stride": 1, "src1_rep_stride": 8,
                    "src2_blk_stride": 1, "src2_rep_stride": 8,
                },
            )
        )

    # Post-migration: count-mode compare is not supported by the stub
    # (compare.py calls ensure_repeat_mode); v1 now raises NotImplementedError.
    pipe_count = object.__new__(VPipe)
    pipe_count.vector_mode = "count"
    pipe_count.count_register = 4
    pipe_count._get_tensor = lambda name: tensors[name]

    with pytest.raises(NotImplementedError, match="count-mode compare is not supported"):
        pipe_count.execute(
            PipeTask(
                pipe_name="V",
                opname="vec_v_compare",
                args={"dst": "dst", "src1": "src1", "src2": "src2", "mode": "BAD_MODE"},
            )
        )
def test_vpipe_set_mask_from_low_high_uint64() -> None:
    # Post-migration: _set_mask reads `low`/`high` uint64 kwargs and unpacks
    # them LSB-first into current_mask[0:128]. Truncation warnings on deprecated
    # list/int forms no longer exist (the input contract is different now).
    pipe = object.__new__(VPipe)
    pipe.current_mask = torch.zeros(256, dtype=torch.uint8)

    pipe._set_mask({"low": 0xF, "high": 0x3})
    assert [int(v) for v in pipe.current_mask[0:4].tolist()] == [1, 1, 1, 1]
    assert [int(v) for v in pipe.current_mask[4:64].tolist()] == [0] * 60
    assert [int(v) for v in pipe.current_mask[64:66].tolist()] == [1, 1]
    assert [int(v) for v in pipe.current_mask[66:128].tolist()] == [0] * 62
    # Bits 128-255 are not touched by set_mask
    assert [int(v) for v in pipe.current_mask[128:256].tolist()] == [0] * 128
def test_micro_create_maskreg_rejects_unknown_init_mode() -> None:
    runtime = MicroRuntime()
    runtime._stack.append(MicroContext())
    try:
        bad_mask = SimpleNamespace(name="bad_mask", dtype=DT.float, init_mode="BAD_MODE")
        with pytest.raises(ValueError, match="unsupported mask init_mode: BAD_MODE"):
            runtime._dispatch("create_maskreg", {"reg": bad_mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_micro_requires_explicit_mask_when_no_default_full_mask_allowed() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    src2 = Reg(DT.float, name="src2")
    ub_ref = SimpleNamespace(name="ub")
    mask_a = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask_a")
    mask_b = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask_b")
    mask_dst = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask_dst")

    ctx = MicroContext(
        regs={
            "src": torch.ones(64, dtype=torch.float32),
            "src2": torch.zeros(64, dtype=torch.float32),
            "dst": torch.zeros(64, dtype=torch.float32),
        },
        masks={
            "mask_a": torch.ones(64, dtype=torch.bool),
            "mask_b": torch.zeros(64, dtype=torch.bool),
        },
        tensor_views={"ub": torch.zeros(64, dtype=torch.float32)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="mask is required"):
            runtime._dispatch("micro_reg2ub", {"dst": ub_ref, "src": src, "blk_stride": 1}, SharedMemoryStore())

        with pytest.raises(ValueError, match="micro_gathermask requires mask"):
            runtime._dispatch("micro_gathermask", {"dst": dst, "src": src}, SharedMemoryStore())

        with pytest.raises(ValueError, match="mask/register selector is required"):
            runtime._dispatch("micro_select", {"dst": dst, "src1": src, "src2": src2}, SharedMemoryStore())

        with pytest.raises(ValueError, match="micro_masksel requires mask"):
            runtime._dispatch("micro_masksel", {"dst": mask_dst, "src1": mask_a, "src2": mask_b}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_micro_create_var_rejects_non_numeric_value() -> None:
    runtime = MicroRuntime()
    runtime._stack.append(MicroContext())
    try:
        bad_var = SimpleNamespace(name="bad_var", value=object())
        with pytest.raises(TypeError, match="create_var requires numeric value"):
            runtime._dispatch("create_var", {"val": bad_var}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_micro_compare_requires_rhs_operand() -> None:
    runtime = MicroRuntime()
    lhs = Reg(DT.float, name="lhs")
    dst = MaskReg(DT.float, init_mode=MaskType.NONE, name="dst")

    ctx = MicroContext(regs={"lhs": torch.ones(64, dtype=torch.float32)})
    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="micro_compare requires rhs"):
            runtime._dispatch("micro_compare", {"dst": dst, "src": lhs}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_micro_compare_and_compares_enforce_rhs_kind() -> None:
    runtime = MicroRuntime()
    lhs = Reg(DT.float, name="lhs")
    rhs = Reg(DT.float, name="rhs")
    dst = MaskReg(DT.float, init_mode=MaskType.NONE, name="dst")
    threshold = Var(3.0, name="threshold")

    ctx = MicroContext(
        regs={
            "lhs": torch.ones(64, dtype=torch.float32),
            "rhs": torch.zeros(64, dtype=torch.float32),
        },
        var_values={"threshold": 3.0},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(TypeError, match="micro_compare requires register rhs"):
            runtime._dispatch("micro_compare", {"dst": dst, "src1": lhs, "src2": threshold}, SharedMemoryStore())

        with pytest.raises(TypeError, match="micro_compares requires scalar rhs"):
            runtime._dispatch("micro_compares", {"dst": dst, "src1": lhs, "src2": rhs}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
def test_micro_select_requires_register_operands() -> None:
    runtime = MicroRuntime()
    src1 = Reg(DT.float, name="src1")
    src2 = Reg(DT.float, name="src2")
    dst = Reg(DT.float, name="dst")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    threshold = Var(3.0, name="threshold")

    ctx = MicroContext(
        regs={
            "src1": torch.ones(64, dtype=torch.float32),
            "src2": torch.zeros(64, dtype=torch.float32),
            "dst": torch.zeros(64, dtype=torch.float32),
        },
        masks={"mask": torch.ones(64, dtype=torch.bool)},
        var_values={"threshold": 3.0},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(TypeError, match="micro_select requires register src2"):
            runtime._dispatch("micro_select", {"dst": dst, "src1": src1, "src2": threshold, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
