"""Trace-level tests for Conv2D / img2col / l1_to_l0a_img2col (load3d DSL U1+U2)."""
import pytest

from easyasc.a2 import *

C0 = 16
H, W, C = 4, 4, 32
C1 = C // C0
KH = KW = 4
PAD = (1, 2, 1, 2)
COUT = 64


def _make_view():
    conv = Conv2D(kh=KH, kw=KW, pad=PAD)
    fm = Tensor(DT.half, [C1 * H * W, C0], Position.L1)
    return conv, fm, img2col(fm, conv, h=H, w=W, c=C)


# ---- Conv2D / view geometry ----

def test_view_geometry():
    _, _, acc = _make_view()
    assert (acc.ho, acc.wo) == (4, 4)
    assert acc.M == 16
    assert acc.K == C1 * KH * KW * C0  # 512
    assert acc.shape == (16, 512)


def test_conv_param_ranges():
    with pytest.raises(ValueError, match="stride"):
        Conv2D(kh=3, kw=3, stride=(64, 1))
    with pytest.raises(ValueError, match="pad"):
        Conv2D(kh=3, kw=3, pad=(0, 0, 0, 256))
    with pytest.raises(ValueError, match="kh"):
        Conv2D(kh=0, kw=3)


def test_fmap_shape_mismatch():
    conv = Conv2D(kh=KH, kw=KW, pad=PAD)
    fm = Tensor(DT.half, [C1 * H * W - 1, C0], Position.L1)
    with pytest.raises(ValueError, match="elements"):
        img2col(fm, conv, h=H, w=W, c=C)


# ---- slicing constraints ----

def test_slice_alignment_checks():
    _, _, acc = _make_view()
    with pytest.raises(ValueError, match="multiple of 16"):
        acc[0:8, 0:256]
    with pytest.raises(ValueError, match="multiple of C0"):
        acc[0:16, 0:250]
    with pytest.raises(ValueError, match="multiple of 16"):
        acc[8:24, 0:256]
    with pytest.raises(ValueError, match="exceeds K"):
        acc[0:16, 256:1024]
    s = acc[0:16, 256:512]
    assert (s.m0, s.k0, s.m_ext, s.k_ext) == (0, 256, 16, 256)


# ---- stub instruction emission ----

@kernel()
def _img2col_kernel(data: GMTensor, out: GMTensor):
    conv = Conv2D(kh=KH, kw=KW, pad=PAD)
    fm = Tensor(DT.half, [C1 * H * W, C0], Position.L1)
    gm_to_l1(fm, data, 1, C1 * H * W * C0 * 2 // 32, 0, 0)
    acc = img2col(fm, conv, h=H, w=W, c=C)
    l0a = Tensor(DT.half, [16, 256], Position.L0A)
    l0c = Tensor(DT.float, [16, COUT], Position.L0C)
    for k0 in (0, 256):
        l1_to_l0a_img2col(l0a, acc[0:16, k0:k0 + 256])
        # weight path omitted; mmad wiring tested separately
    l0c_to_gm_nz2nd(out, l0c, 16, COUT, COUT, 16)
    return out


def test_stub_emits_instruction_with_fields():
    data = GMTensor(DT.half, [C1 * H * W, C0])
    out = GMTensor(DT.float, [16, COUT])
    _img2col_kernel(data, out)
    insts = [i for i in _img2col_kernel.instructions if i.opname == "l1_to_l0_img2col"]
    assert len(insts) == 2
    i0, i1 = insts
    assert i0.kwargs["k0"] == 0 and i1.kwargs["k0"] == 256
    for i in insts:
        kw = i.kwargs
        assert (kw["h"], kw["w"], kw["c"], kw["c0"]) == (H, W, C, C0)
        assert (kw["kh"], kw["kw"]) == (KH, KW)
        assert (kw["pad_l"], kw["pad_r"], kw["pad_t"], kw["pad_b"]) == PAD
        assert (kw["m_ext"], kw["k_ext"]) == (16, 256)
        assert kw["dst_position"] == "L0A"


def test_stub_rejects_bad_dst():
    conv, fm, acc = _make_view()
    l0b = Tensor(DT.half, [16, 256], Position.L0B)
    with pytest.raises(ValueError, match="L0A"):
        l1_to_l0a_img2col(l0b, acc[0:16, 0:256])
    small = Tensor(DT.half, [16, 128], Position.L0A)
    with pytest.raises(ValueError, match="elements"):
        l1_to_l0a_img2col(small, acc[0:16, 0:256])
    fm_f = Tensor(DT.float, [C1 * H * W * 2, 8], Position.L1)
    acc_f = img2col(fm_f, conv, h=H, w=W, c=C)
    l0a = Tensor(DT.half, [16, 256], Position.L0A)
    with pytest.raises(ValueError, match="match"):
        l1_to_l0a_img2col(l0a, acc_f[0:16, 0:256])


# ---- l0c_to_gm_nz2nz (NC1HWC0 store) trace checks ----

def test_nz2nz_auto_infer_and_emit():
    from easyasc.stub_functions import l0c_to_gm_nz2nz

    @kernel()
    def _nz_store(out: GMTensor, nb: Var):
        l0c = Tensor(DT.float, [32, COUT], Position.L0C)
        l0c_to_gm_nz2nz(out[16:48, :], l0c)
        return out

    out = GMTensor(DT.float, [COUT // 16 * 64, 16])     # 4 strips x M_pad=64
    _nz_store(out, Var(1))
    insts = [i for i in _nz_store.instructions if i.opname == "l0c_to_gm_nz2nz"]
    assert len(insts) == 1
    kw = insts[0].kwargs
    assert (kw["M"], kw["N"], kw["M_pad"]) == (32, COUT, 64)


def test_nz2nz_rejects_bad_geometry():
    import pytest
    from easyasc.stub_functions import l0c_to_gm_nz2nz

    @kernel()
    def _bad(out: GMTensor, wide: GMTensor, nb: Var):
        l0c = Tensor(DT.float, [32, COUT], Position.L0C)
        with pytest.raises(ValueError, match="16"):
            l0c_to_gm_nz2nz(wide[0:32, :], l0c)          # not a [*, 16] plane
        with pytest.raises(ValueError, match="rows"):
            l0c_to_gm_nz2nz(out[0:16, :], l0c)           # slice rows != tile m
        return out

    _bad(GMTensor(DT.float, [COUT // 16 * 64, 16]), GMTensor(DT.float, [64, COUT]), Var(1))


def test_nz2nz_eight_bit_dst_uses_c0_32():
    import pytest
    from easyasc.stub_functions import l0c_to_gm_nz2nz

    @kernel()
    def _q8(out: GMTensor, wide16: GMTensor, nb: Var):
        l0c = Tensor(DT.float, [32, COUT], Position.L0C)
        l0c_to_gm_nz2nz(out[0:32, :], l0c, m_pad=64, scale=0.5, offset=3)
        with pytest.raises(ValueError, match=r"\[\*, 32\]"):
            l0c_to_gm_nz2nz(wide16[0:32, :], l0c, m_pad=64, scale=0.5, offset=3)
        return out

    _q8(GMTensor(DT.int8, [COUT // 32 * 64, 32]), GMTensor(DT.int8, [COUT // 16 * 64, 16]), Var(1))
    insts = [i for i in _q8.instructions if i.opname == "l0c_to_gm_nz2nz"]
    assert len(insts) == 1 and insts[0].kwargs["scale"] == 0.5


# ---- Var (runtime-shape) trace paths ----

def test_var_view_window_and_slice_reject():
    conv = Conv2D(kh=KH, kw=KW, pad=PAD)
    fm = Tensor(DT.half, [C1 * H * W, C0], Position.L1)
    acc = img2col(fm, conv, h=Var(H), w=Var(W), c=Var(C))
    assert isinstance(acc.M, Var) and isinstance(acc.K, Var)
    s = acc.window(Var(16), Var(256), 16, 256)
    assert (s.m_ext, s.k_ext) == (16, 256)
    with pytest.raises(ValueError, match="multiple of 16"):
        acc.window(0, 0, 8, 256)
    with pytest.raises(TypeError, match="window"):
        acc[Var(0):Var(0) + 16, 0:256]


def test_var_stub_rounds_c_and_emits_vars():
    @kernel()
    def _var_img2col(data: GMTensor, out: GMTensor, h: Var, w: Var, c: Var):
        conv = Conv2D(kh=KH, kw=KW, pad=PAD)
        fm = Tensor(DT.half, [C1 * H * W, C0], Position.L1)
        gm_to_l1(fm, data, 1, C1 * H * W * C0 * 2 // 32, 0, 0)
        acc = img2col(fm, conv, h=h, w=w, c=c)
        l0a = Tensor(DT.half, [16, 256], Position.L0A)
        l1_to_l0a_img2col(l0a, acc.window(0, 0, 16, 256))
        return out

    data = GMTensor(DT.half, [C1 * H * W, C0])
    out = GMTensor(DT.float, [16, COUT])
    _var_img2col(data, out, Var(H), Var(W), Var(C))
    insts = [i for i in _var_img2col.instructions if i.opname == "l1_to_l0_img2col"]
    assert len(insts) == 1
    kw = insts[0].kwargs
    # h/w pass through; Var c rounds via the always-legal step (fp16 -> 8)
    assert isinstance(kw["h"], Var) and isinstance(kw["w"], Var) and isinstance(kw["c"], Var)
    assert (kw["m_ext"], kw["k_ext"]) == (16, 256)


def test_var_nz2nz_m_pad_and_infer_reject():
    from easyasc.stub_functions import l0c_to_gm_nz2nz

    @kernel()
    def _nz_store_var(out: GMTensor, m_pad: Var):
        l0c = Tensor(DT.float, [32, COUT], Position.L0C)
        row0 = m_pad - m_pad + 16          # Var start slice
        l0c_to_gm_nz2nz(out[row0:row0 + 32, :], l0c, m_pad=m_pad)
        return out

    out = GMTensor(DT.float, [COUT // 16 * 64, 16])
    _nz_store_var(out, Var(64))
    insts = [i for i in _nz_store_var.instructions if i.opname == "l0c_to_gm_nz2nz"]
    assert len(insts) == 1 and isinstance(insts[0].kwargs["M_pad"], Var)

    @kernel()
    def _nz_store_bad(out: GMTensor, m_pad: Var):
        l0c = Tensor(DT.float, [32, COUT], Position.L0C)
        l0c_to_gm_nz2nz(out[0:32, :], l0c)   # Var-shaped plane, no m_pad
        return out

    out_var = GMTensor(DT.float, [Var(256), 16])
    with pytest.raises(ValueError, match="explicit"):
        _nz_store_bad(out_var, Var(64))
