import re

import pytest

from easyasc.parser.asc import translate
from easyasc.parser.asc_buffer_view_liveness import BufferViewDecision, plan_runtime_buffer_views
from easyasc.parser.asc_utils import build_expr_state
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.instruction import Instruction
from easyasc.utils.positions import Position
from easyasc.utils.Tensor import DBuff, GMTensor, QBuff, TBuff, Tensor
from easyasc.utils.var import Expr, Var, VarList


BUFFER_CREATE_OP = {
    DBuff: "create_dbuf",
    TBuff: "create_tbuf",
    QBuff: "create_qbuf",
}


def _consumer(view: Tensor, name: str = "out") -> Instruction:
    out = GMTensor(DT.float, [1, 8], name=name)
    return Instruction(
        "ub_to_gm_pad",
        dst=out,
        src=view,
        n_burst=1,
        burst_len_byte=32,
        src_stride=0,
        dst_stride_byte=0,
    )


def _runtime_view(buffer_type=DBuff, prefix: str = "live"):
    buffer = buffer_type(DT.float, [1, 8], Position.UB, name=f"{prefix}_buf")
    index = Var(0, name=f"{prefix}_idx")
    view = buffer[index]
    instructions = [
        Instruction(BUFFER_CREATE_OP[buffer_type], val=buffer, shape=[1, 8]),
        Instruction("create_var", val=index, init_value=0),
        Instruction("get_buf", buf=buffer, index=index, out=view),
    ]
    return buffer, index, view, instructions


def _decision(instructions, view):
    return plan_runtime_buffer_views(instructions)[view.name]


@pytest.mark.parametrize("buffer_type", [DBuff, TBuff, QBuff])
def test_single_runtime_buffer_view_use_is_inlined(buffer_type) -> None:
    buffer, index, view, instructions = _runtime_view(buffer_type, buffer_type.__name__.lower())
    instructions.append(_consumer(view))

    decision = _decision(instructions, view)
    code = translate(instructions, kernel_mode="vec")

    assert decision.mode == "inline"
    assert decision.reason == "single_use_same_index_version"
    assert decision.use_count == 1
    assert code.count(f"{buffer.name}.get({index.name})") == 1
    assert not re.search(rf"LocalTensor<[^>]+>\s+{view.name}\s*=", code)


def test_runtime_view_mutation_after_last_use_is_inlined() -> None:
    buffer, index, view, instructions = _runtime_view(prefix="after")
    instructions.extend(
        [
            _consumer(view),
            Instruction("var_add", a=index, b=1, out=index),
        ]
    )

    decision = _decision(instructions, view)
    code = translate(instructions, kernel_mode="vec")

    assert decision.mode == "inline"
    assert code.index(f"{buffer.name}.get({index.name})") < code.index(f"{index.name} = {index.name} + 1;")


def test_runtime_view_mutation_before_use_is_materialized() -> None:
    buffer, index, view, instructions = _runtime_view(prefix="before")
    instructions.extend(
        [
            Instruction("var_add", a=index, b=1, out=index),
            _consumer(view),
        ]
    )

    decision = _decision(instructions, view)
    code = translate(instructions, kernel_mode="vec")

    declaration = f"LocalTensor<float> {view.name} = {buffer.name}.get({index.name});"
    assert decision == BufferViewDecision("materialize", "index_mutated", 1)
    assert declaration in code
    assert code.index(declaration) < code.index(f"{index.name} = {index.name} + 1;")


def test_runtime_view_multiple_uses_keep_one_materialized_alias() -> None:
    buffer, index, view, instructions = _runtime_view(prefix="multiple")
    instructions.extend([_consumer(view, "out0"), _consumer(view, "out1")])

    decision = _decision(instructions, view)
    code = translate(instructions, kernel_mode="vec")

    assert decision == BufferViewDecision("materialize", "multiple_consumers", 2)
    assert code.count(f"{buffer.name}.get({index.name})") == 1
    assert code.count(view.name) == 3


def test_runtime_view_single_use_inside_same_loop_body_is_inlined() -> None:
    buffer = DBuff(DT.float, [1, 8], Position.UB, name="loop_buf")
    loop_index = Var(0, name="loop_index")
    view = buffer[loop_index]
    instructions = [
        Instruction("create_dbuf", val=buffer, shape=[1, 8]),
        Instruction("create_var", val=loop_index, init_value=0),
        Instruction("start_loop", var=loop_index, start=0, stop=2, step=1),
        Instruction("get_buf", buf=buffer, index=loop_index, out=view),
        _consumer(view),
        Instruction("end_loop"),
    ]

    decision = _decision(instructions, view)
    code = translate(instructions, kernel_mode="vec")

    assert decision.mode == "inline"
    assert f"{buffer.name}.get({loop_index.name})" in code
    assert f"LocalTensor<float> {view.name}" not in code


def test_runtime_view_crossing_if_mutation_is_materialized() -> None:
    buffer, index, view, instructions = _runtime_view(prefix="branch")
    flag = Var(1, name="branch_flag")
    instructions.extend(
        [
            Instruction("create_var", val=flag, init_value=1),
            Instruction("start_if", cond=Expr(f"{flag.name} != 0")),
            Instruction("var_add", a=index, b=1, out=index),
            Instruction("end_if"),
            _consumer(view),
        ]
    )

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "control_flow", 1)


@pytest.mark.parametrize("derived_op", ["slice_tensor", "micro_slice_tensor", "reinterpret"])
def test_runtime_view_derived_chain_is_materialized(derived_op: str) -> None:
    _, _, view, instructions = _runtime_view(prefix=derived_op)
    derived = view[:, :]
    if derived_op in ("slice_tensor", "micro_slice_tensor"):
        derived_inst = Instruction(
            "slice_tensor",
            src=view,
            out=derived,
            offset=[0, 0],
            span=[1, 8],
            step=[1, 1],
        )
    else:
        derived.dtype = DT.int
        derived_inst = Instruction(
            "reinterpret",
            src=view,
            dst=derived,
            dst_shape=[1, 8],
            dst_span=[1, 8],
            packed_view_axis=None,
        )
    instructions.extend([derived_inst, _consumer(derived)])

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "derived_view", 1)


def test_runtime_view_nested_operand_escape_is_materialized() -> None:
    _, _, view, instructions = _runtime_view(prefix="escape")
    instructions.append(Instruction("opaque_consumer", tensors=[view]))

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "escaped_view", 1)


def test_runtime_view_tmp_index_tracks_rendered_expression_dependencies() -> None:
    buffer = DBuff(DT.float, [1, 8], Position.UB, name="expr_buf")
    counter = Var(0, name="expr_counter")
    index = Var(0)
    view = buffer[index]
    instructions = [
        Instruction("create_dbuf", val=buffer, shape=[1, 8]),
        Instruction("create_var", val=counter, init_value=0),
        Instruction("create_var", val=index, init_value=0),
        Instruction("var_mod", a=counter, b=2, out=index),
        Instruction("get_buf", buf=buffer, index=index, out=view),
        Instruction("var_add", a=counter, b=1, out=counter),
        _consumer(view),
    ]

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "index_mutated", 1)


def test_runtime_view_tmp_index_tracks_external_var_dependency() -> None:
    buffer = DBuff(DT.float, [1, 8], Position.UB, name="external_expr_buf")
    external_counter = Var(0, name="external_counter")
    index = Var(0)
    view = buffer[index]
    instructions = [
        Instruction("create_dbuf", val=buffer, shape=[1, 8]),
        Instruction("create_var", val=index, init_value=0),
        Instruction("var_mod", a=external_counter, b=2, out=index),
        Instruction("get_buf", buf=buffer, index=index, out=view),
        Instruction("var_add", a=external_counter, b=1, out=external_counter),
        _consumer(view),
    ]

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "index_mutated", 1)


def test_runtime_view_tmp_index_from_tensor_read_is_materialized() -> None:
    buffer = DBuff(DT.float, [1, 8], Position.UB, name="tensor_index_buf")
    index_source = Tensor(DT.int, [1, 1], Position.UB, name="tensor_index_source")
    index = Var(0)
    view = buffer[index]
    instructions = [
        Instruction("create_dbuf", val=buffer, shape=[1, 8]),
        Instruction("create_tensor", val=index_source, shape=[1, 1]),
        Instruction("create_var", val=index, init_value=0),
        Instruction("GetValueFrom", dst=index, out=index, src=index_source),
        Instruction("get_buf", buf=buffer, index=index, out=view),
        _consumer(view),
    ]

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "unstable_index_expression", 1)


def test_runtime_view_tmp_index_from_varref_expression_is_materialized() -> None:
    buffer = DBuff(DT.float, [1, 8], Position.UB, name="indirect_varref_buf")
    indices = VarList(DT.int, 2, name="indirect_indices")
    index = Var(0)
    view = buffer[index]
    instructions = [
        Instruction("create_dbuf", val=buffer, shape=[1, 8]),
        Instruction("create_varlist", varlist=indices),
        Instruction("create_var", val=index, init_value=0),
        Instruction("var_add", a=indices[0], b=0, out=index),
        Instruction("get_buf", buf=buffer, index=index, out=view),
        _consumer(view),
    ]

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "unstable_index_expression", 1)


def test_runtime_view_varref_index_is_materialized() -> None:
    buffer = DBuff(DT.float, [1, 8], Position.UB, name="varref_buf")
    indices = VarList(DT.int, 2, name="indices")
    index = indices[0]
    view = buffer[index]
    instructions = [
        Instruction("create_dbuf", val=buffer, shape=[1, 8]),
        Instruction("create_varlist", varlist=indices),
        Instruction("get_buf", buf=buffer, index=index, out=view),
        _consumer(view),
    ]

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "unsupported_index", 1)


def test_runtime_view_crossing_loop_boundary_is_materialized() -> None:
    _, _, view, instructions = _runtime_view(prefix="cross_loop")
    loop_index = Var(0, name="cross_loop_iter")
    instructions.extend(
        [
            Instruction("create_var", val=loop_index, init_value=0),
            Instruction("start_loop", var=loop_index, start=0, stop=2, step=1),
            _consumer(view),
            Instruction("end_loop"),
        ]
    )

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "control_flow", 1)


def test_runtime_view_crossing_branch_boundary_is_materialized() -> None:
    _, _, view, instructions = _runtime_view(prefix="cross_branch")
    flag = Var(1, name="cross_branch_flag")
    instructions.extend(
        [
            Instruction("create_var", val=flag, init_value=1),
            Instruction("start_if", cond=Expr(f"{flag.name} != 0")),
            _consumer(view),
            Instruction("end_if"),
        ]
    )

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "control_flow", 1)


def test_runtime_view_single_use_inside_same_branch_is_inlined() -> None:
    buffer, index, view, instructions = _runtime_view(prefix="same_branch")
    flag = Var(1, name="same_branch_flag")
    instructions.extend(
        [
            Instruction("create_var", val=flag, init_value=1),
            Instruction("start_if", cond=Expr(f"{flag.name} != 0")),
            _consumer(view),
            Instruction("end_if"),
        ]
    )
    get_buf = instructions.pop(2)
    instructions.insert(4, get_buf)

    decision = _decision(instructions, view)
    code = translate(instructions, kernel_mode="vec")

    assert decision == BufferViewDecision("inline", "single_use_same_index_version", 1)
    assert f"{buffer.name}.get({index.name})" in code
    assert f"LocalTensor<float> {view.name}" not in code


def test_runtime_view_consumer_that_writes_index_is_materialized() -> None:
    _, index, view, instructions = _runtime_view(prefix="consumer_write")
    instructions.append(Instruction("GetValueFrom", dst=index, out=index, src=view))

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "index_mutated", 1)


def test_runtime_view_without_consumer_is_materialized() -> None:
    _, _, view, instructions = _runtime_view(prefix="unused")

    decision = _decision(instructions, view)

    assert decision == BufferViewDecision("materialize", "no_material_consumer", 0)


def test_constant_index_behavior_is_unchanged() -> None:
    buffer = DBuff(DT.float, [1, 8], Position.UB, name="constant_buf")
    view = buffer[0]
    instructions = [
        Instruction("create_dbuf", val=buffer, shape=[1, 8]),
        Instruction("get_buf", buf=buffer, index=0, out=view),
        _consumer(view, "constant_out0"),
        _consumer(view, "constant_out1"),
    ]

    plan = plan_runtime_buffer_views(instructions)
    code = translate(instructions, kernel_mode="vec")

    assert view.name not in plan
    assert code.count("constant_buf.get(0)") == 2
    assert f"LocalTensor<float> {view.name}" not in code


def test_build_expr_state_default_keeps_runtime_view_materialized() -> None:
    buffer, _, view, instructions = _runtime_view(prefix="default")
    instructions.append(_consumer(view))

    expr_map, _, tmp_tensor_names, _ = build_expr_state(instructions)
    plan = plan_runtime_buffer_views(instructions)
    planned_expr_map, _, planned_tmp_tensor_names, _ = build_expr_state(
        instructions,
        buffer_view_plan=plan,
    )

    assert view.name not in expr_map
    assert view.name not in tmp_tensor_names
    assert planned_expr_map[view.name].startswith(f"{buffer.name}.get(")
    assert view.name in planned_tmp_tensor_names
