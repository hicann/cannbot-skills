import contextlib
import os
from pathlib import Path

import pytest

from easyasc import globvars
from easyasc.a5 import *


@kernel()
def _host_blockdim_kernel(inp: GMTensor, out: GMTensor, m: Var):
    return out


@kernel()
def _host_tiling_int_kernel(inp: GMTensor, out: GMTensor, m: Var):
    return out


@kernel()
def _host_tiling_float_kernel(inp: GMTensor, out: GMTensor, scale: Var):
    return out


@kernel()
def _host_workspace_helper_kernel(inp: GMTensor, out: GMTensor, m: Var):
    per_core = CeilDiv(m, GetCubeNum(), name="per_core")
    split_workspace(DT.half, [per_core, GetVecNum()], name="ws")
    return out


@kernel(mode="vec")
def _host_blockdim_vec_kernel(inp: GMTensor, out: GMTensor, m: Var):
    return out


@kernel(mode="cube")
def _host_blockdim_cube_kernel(inp: GMTensor, out: GMTensor, m: Var):
    return out


@kernel(mode="vec")
def _host_workspace_helper_vec_kernel(inp: GMTensor, out: GMTensor, m: Var):
    split_workspace(DT.half, [m, GetVecNum()], name="ws")
    return out


@contextlib.contextmanager
def _pushd(path: Path):
    prev = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(prev)


def _render_op_host(tmp_path: Path, device_type: str) -> str:
    saved_device_type = globvars.device_type
    globvars.device_type = device_type
    try:
        inp = GMTensor(DT.float, [1, 1])
        out = GMTensor(DT.float, [1, 1])
        m = Var(1)
        _host_blockdim_kernel(inp, out, m)
        with _pushd(tmp_path):
            _host_blockdim_kernel.generate_op_host()
            return (tmp_path / "_host_blockdim_kernel.cpp").read_text(encoding="utf-8")
    finally:
        globvars.device_type = saved_device_type


def _render_kernel_op_host(tmp_path: Path, kernel_obj, scalar: Var, device_type: str = "950") -> str:
    saved_device_type = globvars.device_type
    globvars.device_type = device_type
    try:
        inp = GMTensor(DT.float, [1, 1])
        out = GMTensor(DT.float, [1, 1])
        kernel_obj(inp, out, scalar)
        with _pushd(tmp_path):
            kernel_obj.generate_op_host()
            tiling_h = (tmp_path / f"{kernel_obj.name}_tiling.h").read_text(encoding="utf-8")
            cpp = (tmp_path / f"{kernel_obj.name}.cpp").read_text(encoding="utf-8")
            return tiling_h + "\n===CPP===\n" + cpp
    finally:
        globvars.device_type = saved_device_type


def _render_debug_main(tmp_path: Path, kernel_obj, scalar: Var, device_type: str = "950") -> str:
    saved_device_type = globvars.device_type
    globvars.device_type = device_type
    try:
        inp = GMTensor(DT.float, [1, 1])
        out = GMTensor(DT.float, [1, 1])
        kernel_obj(inp, out, scalar)
        kernel_obj._generate_debug_main(str(tmp_path))
        return (tmp_path / "main.cpp").read_text(encoding="utf-8")
    finally:
        globvars.device_type = saved_device_type


@pytest.mark.parametrize("kernel_obj, expected_method", [
    (_host_blockdim_kernel, "GetCoreNumAic"),
    (_host_blockdim_cube_kernel, "GetCoreNumAic"),
    (_host_blockdim_vec_kernel, "GetCoreNumAiv"),
])
@pytest.mark.parametrize("device_type", ["950", "950pr", "b3", "a3"])
def test_generate_op_host_uses_runtime_core_count_for_kernel_mode(
    tmp_path: Path,
    kernel_obj,
    expected_method: str,
    device_type: str,
) -> None:
    cpp = _render_kernel_op_host(
        tmp_path, kernel_obj, Var(1, DT.int), device_type=device_type,
    )
    assert f"uint32_t coreNum = ascendcPlatform.{expected_method}();" in cpp
    assert "context->SetBlockDim(coreNum);" in cpp
    assert "context->SetBlockDim(20);" not in cpp
    assert "context->SetBlockDim(32);" not in cpp
    assert "context->SetBlockDim(64);" not in cpp


@pytest.mark.parametrize("kernel_obj", [
    _host_blockdim_kernel,
    _host_blockdim_vec_kernel,
    _host_blockdim_cube_kernel,
])
@pytest.mark.parametrize("device_type", ["950", "950pr", "b3", "a3"])
def test_generate_op_host_sets_dyn_ubuf_only_for_a5_vector_side(
    tmp_path: Path,
    kernel_obj,
    device_type: str,
) -> None:
    cpp = _render_kernel_op_host(
        tmp_path, kernel_obj, Var(1, DT.int), device_type=device_type,
    )
    line = "context->SetDynUBufSize(221184);"
    expect_dyn_ubuf = device_type in ("950", "950pr") and kernel_obj.kernel_mode != "cube"
    assert (line in cpp) is expect_dyn_ubuf


def test_generate_op_host_output_has_no_init_value_zero(tmp_path: Path) -> None:
    cpp = _render_op_host(tmp_path, "950")
    assert ".InitValue(0);" not in cpp


@pytest.mark.parametrize("device_type, expected_unit", [
    ("950", "ascend950"),
    ("950pr", "ascend950"),
    ("b3", "ascend910b"),
    ("a3", "ascend910_93"),
])
def test_generate_op_host_registers_only_profile_compile_unit(
    tmp_path: Path,
    device_type: str,
    expected_unit: str,
) -> None:
    content = _render_kernel_op_host(
        tmp_path, _host_blockdim_kernel, Var(1, DT.int), device_type=device_type,
    )
    assert "OpAICoreConfig aicoreConfig;" in content
    expected = f'this->AICore().AddConfig("{expected_unit}", aicoreConfig);'
    assert expected in content
    assert content.count("this->AICore().AddConfig(") == 1


@pytest.mark.parametrize("kernel_obj, device_type, expected_block_dim", [
    (_host_blockdim_kernel, "950", 32),
    (_host_blockdim_cube_kernel, "950", 32),
    (_host_blockdim_vec_kernel, "950", 64),
    (_host_blockdim_kernel, "b3", 20),
    (_host_blockdim_cube_kernel, "b3", 20),
    (_host_blockdim_vec_kernel, "b3", 40),
    (_host_blockdim_kernel, "a3", 20),
    (_host_blockdim_cube_kernel, "a3", 20),
    (_host_blockdim_vec_kernel, "a3", 40),
])
def test_generate_debug_main_respects_kernel_mode_block_dim(
    tmp_path: Path,
    kernel_obj,
    device_type: str,
    expected_block_dim: int,
) -> None:
    content = _render_debug_main(tmp_path, kernel_obj, Var(1, DT.int), device_type=device_type)
    assert f"uint32_t blockDim = {expected_block_dim};" in content


def test_generate_op_host_uses_int32_t_tiling_for_int_var(tmp_path: Path) -> None:
    content = _render_kernel_op_host(tmp_path, _host_tiling_int_kernel, Var(1, DT.int))
    assert "TILING_DATA_FIELD_DEF(int32_t, m);" in content
    assert "SET_ATTR_TO_TILING(m, int32_t, 0);" in content
    assert 'this->Attr("m")' in content
    assert ".Int(0);" in content
    assert "uint32_t, m" not in content


def test_generate_op_host_uses_float_tiling_for_non_int_var(tmp_path: Path) -> None:
    content = _render_kernel_op_host(tmp_path, _host_tiling_float_kernel, Var(1.5, DT.float))
    assert "TILING_DATA_FIELD_DEF(float, scale);" in content
    assert "SET_ATTR_TO_TILING(scale, float, 0);" in content
    assert 'this->Attr("scale")' in content
    assert ".Float(0);" in content
    assert "uint32_t, scale" not in content


@pytest.mark.parametrize("device_type, expected_cube, expected_vec", [
    ("b1", 24, 48),
    ("b3", 20, 40),
    ("a3", 20, 40),
    ("950", 32, 64),
    ("950pr", 28, 56),
])
def test_generate_op_host_workspace_size_uses_device_specific_helper_counts(
    tmp_path: Path,
    device_type: str,
    expected_cube: int,
    expected_vec: int,
) -> None:
    content = _render_kernel_op_host(tmp_path, _host_workspace_helper_kernel, Var(128, DT.int), device_type=device_type)
    assert (
        f"size_t userWorkspaceSize = (CeilDiv(m, {expected_cube}) * {expected_vec}) * sizeof(uint16_t);"
        in content
    )


@pytest.mark.parametrize("device_type, expected_vec", [
    ("b3", 40),
    ("a3", 40),
    ("950", 64),
    ("950pr", 56),
])
def test_generate_op_host_workspace_size_uses_mode_specific_vec_count(
    tmp_path: Path,
    device_type: str,
    expected_vec: int,
) -> None:
    content = _render_kernel_op_host(
        tmp_path,
        _host_workspace_helper_vec_kernel,
        Var(128, DT.int),
        device_type=device_type,
    )
    assert f"size_t userWorkspaceSize = (m * {expected_vec}) * sizeof(uint16_t);" in content
