from pathlib import Path

import torch

from easyasc.simulator import SimulatorConfig, build_kernel_program
from easyasc.simulator.core import _default_pipe_factory
from easyasc.simulator.memory import SharedMemoryStore, SharedTensorSpec
from easyasc.simulator.pipe import PipeS
from easyasc.simulator.sync import CrossCoreSync, IntraCoreSync, LocalEventBank, LocalSync
from easyasc.utils.Tensor import Tensor
from easyasc.utils.datatype import Datatype
from easyasc.utils.instruction import Instruction
from easyasc.utils.pipe import Pipe
from easyasc.utils.positions import Position
from easyasc.utils.var import Var


def _make_kernel(instructions):
    class FakeKernel:
        name = "legacy_sim_debug_pipe_runtime"

    kernel = FakeKernel()
    kernel.instructions = instructions
    return kernel


def _prepare_store(program) -> SharedMemoryStore:
    store = SharedMemoryStore()
    for item in program.metadata.get("tensor_specs", []):
        spec = item if isinstance(item, SharedTensorSpec) else SharedTensorSpec.from_dict(item)
        store.register(spec)
        store.allocate(spec.name)
    return store


def test_legacy_sim_debug_ops_run_on_requested_vec_pipe(tmp_path: Path, capsys) -> None:
    counter = Var(7, name="counter")
    ub = Tensor(Datatype.float, [1, 8], Position.UB, name="ub_debug")
    dump_path = tmp_path / "ub_debug.pt"
    program = build_kernel_program(
        _make_kernel(
            [
                Instruction("create_var", val=counter),
                Instruction("create_tensor", val=ub),
                Instruction("sim_print", payload=["counter=", "counter", counter], pipe=Pipe.V),
                Instruction("sim_dump_tensor", tensor=ub, filename=str(dump_path), pipe=Pipe.V),
            ]
        )
    )

    store = _prepare_store(program)
    expected = torch.arange(8, dtype=torch.float32).reshape(1, 8)
    store.tensor("ub_debug").copy_(expected)

    cross_sync = CrossCoreSync(core_count=1)
    cross_sync.prepare()
    pipe_s = PipeS(
        core_idx=0,
        lane_name="vec0",
        lane_program=program.get_lane_program("vec0"),
        config=SimulatorConfig(core_count=1, execution_timeout_s=1.0),
        memory_store=store,
        intra_sync=IntraCoreSync(),
        cross_sync=cross_sync,
        local_sync=LocalSync(),
        event_bank=LocalEventBank(),
        pipe_factory=_default_pipe_factory,
    )

    pipe_s.run()

    assert pipe_s._failure is None
    executed = pipe_s.pipes["V"].executed_tasks
    assert [task.opname for task in executed] == ["sim_print", "sim_dump_tensor"]

    dumped = torch.load(dump_path)
    torch.testing.assert_close(dumped, expected)

    err = capsys.readouterr().err
    assert "[sim_print][core=0][lane=vec0][pipe=V] counter=counter7" in err
