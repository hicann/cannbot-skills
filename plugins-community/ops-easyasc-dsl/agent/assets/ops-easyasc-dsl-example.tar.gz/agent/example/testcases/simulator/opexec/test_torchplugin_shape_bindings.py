import pytest
import torch

from easyasc.a2 import *


@kernel()
def _shape_binding_kernel(
    x: GMTensor,
    y: GMTensor,
    z: GMTensor,
    m: Var,
    n: Var,
    k: Var,
):
    return z


def test_shape_bindings_strict_ambiguity_for_unbound_tensor_dim(tmp_path) -> None:
    m = 5
    n = 9
    k = 5
    x = torch.randn((m, k), dtype=torch.float16)
    y = torch.randn((n, k), dtype=torch.float16)
    z = torch.randn((m, n), dtype=torch.float16)

    op = OpExec(_shape_binding_kernel, out_dir=str(tmp_path / "shape_bind_amb"), simulator=True)
    with pytest.raises(ValueError, match=r"Ambiguous scalar match for tensor #1 dim #1"):
        op(
            x,
            y,
            z,
            m,
            n,
            k,
            shape_bindings={
                0: [0, 2],
                2: [0, 1],
            },
        )


def test_shape_bindings_partial_bindings_succeed_when_unbound_dims_are_unique(tmp_path) -> None:
    m = 5
    n = 5
    k = 3
    x = torch.randn((m, n), dtype=torch.float16)
    y = torch.randn((k, k), dtype=torch.float16)
    z = torch.randn((n, n), dtype=torch.float16)

    op = OpExec(_shape_binding_kernel, out_dir=str(tmp_path / "shape_bind_ok"), simulator=True)
    out = op(
        x,
        y,
        z,
        m,
        n,
        k,
        shape_bindings={
            0: [0, 1],
            2: [1, 1],
        },
    )
    assert isinstance(out, torch.Tensor)
    assert out.shape == z.shape
    assert out.dtype == z.dtype


def test_shape_bindings_reject_explicit_mismatch(tmp_path) -> None:
    m = 5
    n = 7
    k = 3
    x = torch.randn((m, n), dtype=torch.float16)
    y = torch.randn((k, k), dtype=torch.float16)
    z = torch.randn((n, n), dtype=torch.float16)

    op = OpExec(_shape_binding_kernel, out_dir=str(tmp_path / "shape_bind_mismatch"), simulator=True)
    with pytest.raises(ValueError, match=r"shape_bindings\[0\]\[1\] mismatches tensor dim value"):
        op(
            x,
            y,
            z,
            m,
            n,
            k,
            shape_bindings={
                0: [0, 2],
            },
        )


def test_shape_bindings_auto_match_ignores_float_scalars(tmp_path) -> None:
    m = 5
    n = 7
    scale = 5.0
    x = torch.randn((m, n), dtype=torch.float16)
    y = torch.randn((n, m), dtype=torch.float16)
    z = torch.randn((m, n), dtype=torch.float16)

    op = OpExec(_shape_binding_kernel, out_dir=str(tmp_path / "shape_bind_float_auto"), simulator=True)
    out = op(
        x,
        y,
        z,
        m,
        n,
        scale,
        shape_bindings={
            0: [0, 1],
            2: [0, 1],
        },
    )
    assert isinstance(out, torch.Tensor)
    assert out.shape == z.shape


def test_shape_bindings_reject_explicit_float_scalar(tmp_path) -> None:
    m = 5
    n = 7
    scale = 5.0
    x = torch.randn((m, n), dtype=torch.float16)
    y = torch.randn((n, m), dtype=torch.float16)
    z = torch.randn((m, n), dtype=torch.float16)

    op = OpExec(_shape_binding_kernel, out_dir=str(tmp_path / "shape_bind_float_explicit"), simulator=True)
    with pytest.raises(TypeError, match=r"shape_bindings\[0\]\[0\] refers to non-int scalar #2"):
        op(
            x,
            y,
            z,
            m,
            n,
            scale,
            shape_bindings={
                0: [2, 1],
                1: [1, 0],
                2: [0, 1],
            },
        )
