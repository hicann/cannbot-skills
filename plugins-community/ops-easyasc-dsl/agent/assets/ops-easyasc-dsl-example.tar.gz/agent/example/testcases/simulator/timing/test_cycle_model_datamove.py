import threading
from dataclasses import replace

import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.physical_alias import PhysicalAlias
from easyasc.simulator.pipe import Mailbox, PipeBase
from easyasc.simulator.program import PipeTask
from easyasc.simulator.timing import estimate_task_cycles, load_cycle_model_for_device
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.instruction import Instruction
from easyasc.utils.reg import Reg
from easyasc.utils.Tensor import Tensor
from easyasc.utils.var import Var


def _legacy_micro_model():
    """A5 model with the scheduled VF path disabled, to pin the legacy serial-sum
    call_micro estimator (still used by A2 and as the fallback)."""
    return replace(load_cycle_model_for_device("950"), vf_fixed_overhead_cycles=0.0)


def _micro_tensor(name):
    tensor = object.__new__(Tensor)
    tensor.name = name
    tensor.dtype = DT.float
    return tensor


def _store_with_bf16_tensors():
    store = SharedMemoryStore()
    store.register_view("dst", torch.empty((16, 16), dtype=torch.bfloat16))
    store.register_view("src", torch.empty((16, 16), dtype=torch.bfloat16))
    return store


def _ub_to_l1_task(opname):
    return PipeTask(
        pipe_name="MTE3",
        opname=opname,
        args={
            "dst": "dst",
            "src": "src",
            "m_dst": 16,
            "n_dst": 16,
            "m_src": 16,
            "n_src": 16,
        },
    )


def _ub_to_l1_raw_task(bytes_count=1024):
    return PipeTask(
        pipe_name="MTE3",
        opname="ub_to_l1",
        args={
            "n_burst": 1,
            "burst_len": bytes_count // 32,
            "src_stride": 0,
            "dst_stride": 0,
        },
    )


def _gm_to_ub_task(bytes_count=1024):
    return PipeTask(
        pipe_name="MTE2",
        opname="gm_to_ub_pad",
        args={
            "n_burst": 1,
            "burst_len_byte": bytes_count,
            "src_stride_byte": 0,
            "dst_stride": 0,
        },
    )


def _ub_to_gm_task(bytes_count=1024):
    return PipeTask(
        pipe_name="MTE3",
        opname="ub_to_gm_pad",
        args={
            "n_burst": 1,
            "burst_len_byte": bytes_count,
            "dst_stride_byte": 0,
            "src_stride": 0,
        },
    )


def _ub_to_ub_task(bytes_count=1024):
    return PipeTask(
        pipe_name="V",
        opname="ub_to_ub",
        args={
            "n_burst": 1,
            "burst_len": bytes_count // 32,
            "src_stride": 0,
            "dst_stride": 0,
        },
    )


def _set_constant_task(bytes_count=1024):
    return PipeTask(
        pipe_name="MTE2",
        opname="set_constant_to_l1",
        args={
            "tensor": "dst",
            "val": 1.0,
            "n_blocks": bytes_count // 32,
        },
    )


def _store_with_gm_to_l1_tensors():
    store = SharedMemoryStore()
    store.register_view("dst", torch.empty((16, 4, 16, 16), dtype=torch.float16))
    store.register_view("src", torch.empty((16, 64), dtype=torch.float16))
    return store


def _gm_to_l1_task(m=16, n=64):
    return PipeTask(
        pipe_name="MTE2",
        opname="gm_to_l1_nd2nz",
        args={
            "dst": "dst",
            "src": "src",
            "M": m,
            "N": n,
            "N_src": n,
            "M_dst": m,
        },
    )


def _store_with_l0c_to_gm_tensors(bytes_count=1024):
    store = SharedMemoryStore()
    n = bytes_count // (16 * 4)
    store.register_view("src", torch.empty((16, n), dtype=torch.float32))
    store.register_view("dst", torch.empty((16, n), dtype=torch.float16))
    return store


def _l0c_to_gm_task(bytes_count=1024):
    n = bytes_count // (16 * 4)
    return PipeTask(
        pipe_name="FIX",
        opname="l0c_to_gm_nz2nd",
        args={
            "dst": "dst",
            "src": "src",
            "M": 16,
            "N": n,
            "N_dst": n,
            "M_src": 16,
        },
    )


def _sort32_task(bytes_count=1024):
    return PipeTask(
        pipe_name="V",
        opname="sort32",
        args={"dst": "dst", "src": "src", "idx": "idx", "repeat": bytes_count // 128},
    )


def _mergesort4_task(bytes_count=1024):
    return PipeTask(
        pipe_name="V",
        opname="mergesort4",
        args={"dst": "dst", "src": "src", "length_per_seq": bytes_count // 32, "repeat": 1},
    )


def _mergesort_2seq_task(bytes_count=1024):
    return PipeTask(
        pipe_name="V",
        opname="mergesort_2seq",
        args={"dst": "dst", "src1": "src", "src2": "src", "size1": bytes_count // 16, "size2": bytes_count // 16},
    )


def _dtype_numel_for_bytes(dtype, bytes_count):
    elem_size = torch.empty((), dtype=dtype).element_size()
    return bytes_count // elem_size


def _store_with_vec_tensors(dtype=torch.float16, metric_bytes=1024):
    store = SharedMemoryStore()
    numel = _dtype_numel_for_bytes(dtype, metric_bytes)
    store.register_view("dst", torch.empty((numel,), dtype=dtype))
    store.register_view("src", torch.empty((numel,), dtype=dtype))
    return store


def _vec_task(opname, repeat=4):
    return PipeTask(
        pipe_name="V",
        opname=opname,
        args={
            "dst": "dst",
            "src": "src",
            "src1": "src",
            "src2": "src",
            "repeat": repeat,
        },
    )


def _store_with_cast_tensors(src_dtype, dst_dtype, metric_bytes=1024):
    store = SharedMemoryStore()
    store.register_view("src", torch.empty((_dtype_numel_for_bytes(src_dtype, metric_bytes),), dtype=src_dtype))
    store.register_view("dst", torch.empty((_dtype_numel_for_bytes(dst_dtype, metric_bytes),), dtype=dst_dtype))
    return store


def _cast_task(repeat=4):
    return PipeTask(
        pipe_name="V",
        opname="cast",
        args={
            "dst": "dst",
            "src": "src",
            "repeat": repeat,
        },
    )


def _store_with_mmad_operands(dtype):
    store = SharedMemoryStore()
    store.register_view("dst", torch.empty((64, 64), dtype=torch.float32))
    store.register_view("src_a", torch.empty((64, 64), dtype=dtype))
    store.register_view("src_b", torch.empty((64, 64), dtype=dtype))
    return store


def _mmad_task(m=64, n=64, k=64):
    return PipeTask(
        pipe_name="M",
        opname="mmad",
        args={
            "dst": "dst",
            "src_a": "src_a",
            "src_b": "src_b",
            "M": m,
            "N": n,
            "K": k,
        },
    )


def _call_micro_task(instructions):
    return PipeTask(
        pipe_name="V",
        opname="call_micro",
        args={
            "micro_def": {"instructions": instructions},
            "var_values": {},
        },
    )


def _reg(dtype, name):
    return Reg(dtype, name=name)


class _NoopPipe(PipeBase):
    def execute(self, task):
        return None


def _pipe_for_cycle_estimates(store):
    model = load_cycle_model_for_device("950")
    return _NoopPipe(
        core_idx=0,
        lane_name="cube",
        pipe_name="M",
        mailbox=Mailbox(),
        bar_all_barrier=threading.Barrier(1),
        memory_store=store,
        cycle_model=model,
    )


def test_a5_ub_to_l1_nd2nz_uses_32_byte_bandwidth():
    model = load_cycle_model_for_device("950")
    estimate = estimate_task_cycles(_ub_to_l1_task("ub_to_l1_nd2nz"), _store_with_bf16_tensors(), model)

    assert estimate.cycles == 16
    assert estimate.details["bandwidth_source"] == "ub_to_l1_nd2nz_bandwidth_bytes_per_cycle"


def test_a5_ub_to_l1_nz_keeps_256_byte_bandwidth():
    model = load_cycle_model_for_device("950")
    estimate = estimate_task_cycles(_ub_to_l1_task("ub_to_l1_nz"), _store_with_bf16_tensors(), model)

    assert estimate.cycles == 2
    assert estimate.details["bandwidth_source"] == "ub_to_l1_bandwidth_bytes_per_cycle"


def test_a5_raw_ub_to_l1_uses_32b_units_and_ub_to_l1_bandwidth():
    model = load_cycle_model_for_device("950")
    estimate = estimate_task_cycles(_ub_to_l1_raw_task(1024), SharedMemoryStore(), model)

    assert estimate.cycles == 4
    assert estimate.details["bandwidth_source"] == "ub_to_l1_bandwidth_bytes_per_cycle"
    assert estimate.details["payload_bytes"] == 1024


def test_a2_vec_datamove_uses_hardware_calibrated_models():
    model = load_cycle_model_for_device("b3")

    mte2 = estimate_task_cycles(_gm_to_ub_task(1024), SharedMemoryStore(), model)
    mte3 = estimate_task_cycles(_ub_to_gm_task(1024), SharedMemoryStore(), model)

    assert mte2.cycles == 417
    assert mte2.details["bandwidth_source"] == "gm_to_ub_pad_bandwidth_bytes_per_cycle"
    assert mte2.details["overhead_source"] == "gm_to_ub_pad_overhead_cycles"
    assert mte2.details["no_instruction_overhead"] is True

    assert mte3.cycles == 264
    assert mte3.details["bandwidth_source"] == "ub_to_gm_pad_bandwidth_bytes_per_cycle"
    assert mte3.details["overhead_source"] == "ub_to_gm_pad_overhead_cycles"
    assert mte3.details["no_instruction_overhead"] is True


def test_a2_vec_datamove_pipe_estimate_does_not_double_count_head_overhead():
    model = load_cycle_model_for_device("b3")
    pipe = _NoopPipe(
        core_idx=0,
        lane_name="vec0",
        pipe_name="MTE2",
        mailbox=Mailbox(),
        bar_all_barrier=threading.Barrier(1),
        memory_store=SharedMemoryStore(),
        cycle_model=model,
    )

    assert pipe._estimate_task_cycles(_gm_to_ub_task(1024)) == 417.0


def test_a2_vec_compute_uses_measured_formula_without_generic_head_overhead():
    model = load_cycle_model_for_device("b3")
    store = _store_with_vec_tensors(torch.float16, metric_bytes=1024)
    task = _vec_task("add", repeat=4)

    estimate = estimate_task_cycles(task, store, model)

    assert estimate.cycles == 21 + 1024 // 256
    assert estimate.details["model_kind"] == "vpipe_formula"
    assert estimate.details["formula_key"] == "add:half"
    assert estimate.details["no_instruction_overhead"] is True

    pipe = _NoopPipe(
        core_idx=0,
        lane_name="vec0",
        pipe_name="V",
        mailbox=Mailbox(),
        bar_all_barrier=threading.Barrier(1),
        memory_store=store,
        cycle_model=model,
    )
    assert pipe._estimate_task_cycles(task) == 25.0


def test_a2_vec_compute_uses_dtype_specific_formula():
    model = load_cycle_model_for_device("b3")

    fp32_div = estimate_task_cycles(_vec_task("div", repeat=4), _store_with_vec_tensors(torch.float32), model)
    fp16_div = estimate_task_cycles(_vec_task("div", repeat=4), _store_with_vec_tensors(torch.float16), model)
    fp32_gather = estimate_task_cycles(_vec_task("gather", repeat=4), _store_with_vec_tensors(torch.float32), model)

    assert fp32_div.cycles == 28 + 1024 // 128
    assert fp32_div.details["formula_key"] == "div:float"
    assert fp16_div.cycles == 28 + 1024 // 64
    assert fp16_div.details["formula_key"] == "div:half"
    assert fp32_gather.cycles == 72
    assert fp32_gather.details["formula_key"] == "gather:float"


def test_a2_vec_formula_uses_requested_metric_bytes_for_brcb_and_group_ops():
    model = load_cycle_model_for_device("b3")
    store = SharedMemoryStore()
    store.register_view("dst", torch.empty((_dtype_numel_for_bytes(torch.float16, 128),), dtype=torch.float16))
    store.register_view("src", torch.empty((_dtype_numel_for_bytes(torch.float16, 1024),), dtype=torch.float16))

    group = estimate_task_cycles(PipeTask(pipe_name="V", opname="cadd", args={"dst": "dst", "src": "src"}), store, model)
    assert group.details["formula_key"] == "cadd:half"
    assert group.details["metric_source"] == "src_tensor_bytes"
    assert group.details["metric_bytes"] == 1024

    store = SharedMemoryStore()
    store.register_view("dst", torch.empty((_dtype_numel_for_bytes(torch.float32, 1024),), dtype=torch.float32))
    store.register_view("src", torch.empty((_dtype_numel_for_bytes(torch.float32, 32),), dtype=torch.float32))
    brcb = estimate_task_cycles(PipeTask(pipe_name="V", opname="brcb", args={"dst": "dst", "src": "src"}), store, model)
    assert brcb.details["formula_key"] == "brcb:float"
    assert brcb.details["metric_source"] == "dst_tensor_bytes"
    assert brcb.details["metric_bytes"] == 1024


def test_a2_cast_uses_exact_pair_then_width_formula_fallback():
    model = load_cycle_model_for_device("b3")
    exact = estimate_task_cycles(
        _cast_task(repeat=4),
        _store_with_cast_tensors(torch.float32, torch.float16, metric_bytes=1024),
        model,
    )

    assert exact.cycles == 21
    assert exact.details["formula_key"] == "cast:float->half"

    fallback = estimate_task_cycles(
        _cast_task(repeat=4),
        _store_with_cast_tensors(torch.bfloat16, torch.float16, metric_bytes=1024),
        model,
    )

    assert fallback.cycles == 23
    assert fallback.details["formula_key"] == "cast:16->16"


def test_a2_cube_gm_to_l1_uses_hardware_calibrated_model():
    model = load_cycle_model_for_device("b3")
    store = _store_with_gm_to_l1_tensors()
    estimate = estimate_task_cycles(_gm_to_l1_task(), store, model)

    assert estimate.cycles == 401
    assert estimate.details["bandwidth_source"] == "gm_to_l1_nd2nz_bandwidth_bytes_per_cycle"
    assert estimate.details["overhead_source"] == "gm_to_l1_nd2nz_overhead_cycles"
    assert estimate.details["overhead_cycles"] == 350
    assert estimate.details["bandwidth_bytes_per_cycle"] == 40
    assert estimate.details["payload_bytes"] == 2048
    assert estimate.details["no_instruction_overhead"] is True

    pipe = _NoopPipe(
        core_idx=0,
        lane_name="cube",
        pipe_name="MTE2",
        mailbox=Mailbox(),
        bar_all_barrier=threading.Barrier(1),
        memory_store=store,
        cycle_model=model,
    )
    assert pipe._estimate_task_cycles(_gm_to_l1_task()) == 401.0


def test_a2_pending_datamove_and_sort_ops_use_measured_models():
    model = load_cycle_model_for_device("b3")

    set_const_store = SharedMemoryStore()
    set_const_store.register_view("dst", torch.empty((16, 32), dtype=torch.float16))
    set_const = estimate_task_cycles(_set_constant_task(1024), set_const_store, model)
    assert set_const.cycles == 18
    assert set_const.details["overhead_source"] == "set_constant_to_l1_overhead_cycles"
    assert set_const.details["no_instruction_overhead"] is True

    l0c_to_gm = estimate_task_cycles(_l0c_to_gm_task(1024), _store_with_l0c_to_gm_tensors(1024), model)
    assert l0c_to_gm.cycles == 292
    assert l0c_to_gm.details["overhead_source"] == "l0c_to_gm_overhead_cycles"
    assert l0c_to_gm.details["no_instruction_overhead"] is True

    ub_to_ub = estimate_task_cycles(_ub_to_ub_task(16384), SharedMemoryStore(), model)
    assert ub_to_ub.cycles == 16
    assert ub_to_ub.details["model_kind"] == "fixed"
    assert ub_to_ub.details["no_instruction_overhead"] is True

    vec_store = _store_with_vec_tensors(torch.float32, metric_bytes=2048)
    vec_store.register_view("idx", torch.empty((512,), dtype=torch.int32))
    sort32 = estimate_task_cycles(_sort32_task(1024), vec_store, model)
    assert sort32.cycles == 146
    assert sort32.details["bandwidth_source"] == "sort32_bandwidth_bytes_per_cycle"

    mergesort4 = estimate_task_cycles(_mergesort4_task(1024), vec_store, model)
    assert mergesort4.cycles == 148
    assert mergesort4.details["overhead_source"] == "mergesort4_overhead_cycles"

    mergesort_2seq = estimate_task_cycles(_mergesort_2seq_task(1024), vec_store, model)
    assert mergesort_2seq.cycles == 146
    assert mergesort_2seq.details["overhead_source"] == "mergesort_2seq_overhead_cycles"


def test_a2_mmad_uses_measured_dtype_throughput_and_overhead():
    model = load_cycle_model_for_device("b3")
    cases = [
        (torch.int8, 4096.0, "matmul_macs_per_cycle_8bit", 23),
        (torch.float16, 2048.0, "matmul_macs_per_cycle_16bit", 25),
        (torch.bfloat16, 2048.0, "matmul_macs_per_cycle_16bit", 25),
        (torch.float32, 512.0, "matmul_macs_per_cycle_32bit", 37),
    ]

    for dtype, macs_per_cycle, source, cycles in cases:
        estimate = estimate_task_cycles(_mmad_task(m=16, n=16, k=32), _store_with_mmad_operands(dtype), model)

        assert estimate.cycles == cycles
        assert estimate.details["compute_source"] == source
        assert estimate.details["overhead_source"] == "mmad_overhead_cycles"
        assert estimate.details["macs_per_cycle"] == macs_per_cycle
        assert estimate.details["no_instruction_overhead"] is True


def test_a5_pending_datamove_sort_and_mmad_ops_use_measured_models():
    model = load_cycle_model_for_device("950")

    gm_to_l1 = estimate_task_cycles(_gm_to_l1_task(), _store_with_gm_to_l1_tensors(), model)
    assert gm_to_l1.cycles == 364
    assert gm_to_l1.details["bandwidth_source"] == "gm_to_l1_nd2nz_bandwidth_bytes_per_cycle"
    assert gm_to_l1.details["overhead_source"] == "gm_to_l1_nd2nz_overhead_cycles"
    assert gm_to_l1.details["no_instruction_overhead"] is True

    gm_to_ub = estimate_task_cycles(_gm_to_ub_task(1024), SharedMemoryStore(), model)
    assert gm_to_ub.cycles == 332
    assert gm_to_ub.details["bandwidth_source"] == "gm_to_ub_pad_bandwidth_bytes_per_cycle"
    assert gm_to_ub.details["overhead_source"] == "gm_to_ub_pad_overhead_cycles"

    ub_to_gm = estimate_task_cycles(_ub_to_gm_task(1024), SharedMemoryStore(), model)
    assert ub_to_gm.cycles == 332
    assert ub_to_gm.details["bandwidth_source"] == "ub_to_gm_pad_bandwidth_bytes_per_cycle"
    assert ub_to_gm.details["overhead_source"] == "ub_to_gm_pad_overhead_cycles"

    set_const_store = SharedMemoryStore()
    set_const_store.register_view("dst", torch.empty((16, 32), dtype=torch.float16))
    set_const = estimate_task_cycles(_set_constant_task(1024), set_const_store, model)
    assert set_const.cycles == 18
    assert set_const.details["overhead_source"] == "set_constant_to_l1_overhead_cycles"

    l0c_to_gm = estimate_task_cycles(_l0c_to_gm_task(1024), _store_with_l0c_to_gm_tensors(1024), model)
    assert l0c_to_gm.cycles == 332
    assert l0c_to_gm.details["bandwidth_source"] == "l0c_to_gm_bandwidth_bytes_per_cycle"
    assert l0c_to_gm.details["overhead_source"] == "l0c_to_gm_overhead_cycles"

    ub_to_ub = estimate_task_cycles(_ub_to_ub_task(1024), SharedMemoryStore(), model)
    assert ub_to_ub.cycles == 33
    assert ub_to_ub.details["overhead_source"] == "ub_to_ub_overhead_cycles"

    vec_store = _store_with_vec_tensors(torch.float32, metric_bytes=2048)
    vec_store.register_view("idx", torch.empty((512,), dtype=torch.int32))
    sort32 = estimate_task_cycles(_sort32_task(1024), vec_store, model)
    assert sort32.cycles == 151
    assert sort32.details["bandwidth_source"] == "sort32_bandwidth_bytes_per_cycle"

    mergesort4 = estimate_task_cycles(_mergesort4_task(1024), vec_store, model)
    assert mergesort4.cycles == 102
    assert mergesort4.details["bandwidth_source"] == "mergesort4_bandwidth_bytes_per_cycle"

    mergesort_2seq = estimate_task_cycles(_mergesort_2seq_task(1024), vec_store, model)
    assert mergesort_2seq.cycles == 102
    assert mergesort_2seq.details["bandwidth_source"] == "mergesort_2seq_bandwidth_bytes_per_cycle"

    mmad = estimate_task_cycles(_mmad_task(m=16, n=16, k=32), _store_with_mmad_operands(torch.float16), model)
    assert mmad.cycles == 69
    assert mmad.details["compute_source"] == "matmul_macs_per_cycle_16bit"
    assert mmad.details["overhead_source"] == "mmad_overhead_cycles"


def test_mmad_cycle_model_uses_32bit_operand_throughput():
    model = load_cycle_model_for_device("950")
    estimate = estimate_task_cycles(_mmad_task(), _store_with_mmad_operands(torch.float32), model)

    assert estimate.cycles == 1091
    assert estimate.details["operand_bits"] == 32
    assert estimate.details["compute_source"] == "matmul_macs_per_cycle_32bit"
    assert estimate.details["macs_per_cycle"] == 256


def test_mmad_cycle_model_uses_16bit_operand_throughput():
    model = load_cycle_model_for_device("950")
    estimate = estimate_task_cycles(_mmad_task(), _store_with_mmad_operands(torch.bfloat16), model)

    assert estimate.cycles == 131
    assert estimate.details["operand_bits"] == 16
    assert estimate.details["compute_source"] == "matmul_macs_per_cycle_16bit"
    assert estimate.details["macs_per_cycle"] == 4096


def test_mmad_cycle_model_counts_aligned_tile_volume():
    model = load_cycle_model_for_device("950")
    estimate = estimate_task_cycles(_mmad_task(m=17, n=33, k=65), _store_with_mmad_operands(torch.bfloat16), model)

    assert estimate.details["m_aligned"] == 32
    assert estimate.details["n_aligned"] == 48
    assert estimate.details["k_aligned"] == 80
    assert estimate.details["k_align"] == 16
    assert estimate.details["macs"] == 32 * 48 * 80
    assert estimate.cycles == 97


def test_mmad_cycle_model_uses_8bit_operand_throughput():
    model = load_cycle_model_for_device("950")
    estimate = estimate_task_cycles(_mmad_task(), _store_with_mmad_operands(torch.uint8), model)

    assert estimate.cycles == 99
    assert estimate.details["operand_bits"] == 8
    assert estimate.details["compute_source"] == "matmul_macs_per_cycle_8bit"
    assert estimate.details["macs_per_cycle"] == 8192


def test_mmad_cycle_model_keeps_legacy_fallback_when_operand_dtype_is_unknown():
    model = load_cycle_model_for_device("950")
    estimate = estimate_task_cycles(_mmad_task(), SharedMemoryStore(), model)

    assert estimate.cycles == 131
    assert estimate.details["operand_bits"] == 0
    assert estimate.details["compute_source"] == "mmad_macs_per_cycle"
    assert estimate.details["macs_per_cycle"] == 4096


def test_legacy_call_micro_uses_measured_dtype_specific_cycles():
    # Legacy serial-sum path (scheduled VF disabled): still exercised by A2 and
    # as the fallback when a profile has no vf_fixed_overhead_cycles.
    model = _legacy_micro_model()
    instructions = [
        Instruction("micro_vadd", dst=_reg(DT.float, "add_dst"), src=_reg(DT.float, "add_a"), src1=_reg(DT.float, "add_b")),
        Instruction("micro_vdiv", dst=_reg(DT.half, "div_dst"), src=_reg(DT.half, "div_a"), src1=_reg(DT.half, "div_b")),
        Instruction("micro_cast", dst=_reg(DT.uint8, "cast_u8"), src=_reg(DT.half, "cast_h"), ddst=DT.uint8, dsrc=DT.half),
        Instruction("micro_cast", dst=_reg(DT.float, "cast_f0"), src=_reg(DT.float, "cast_f1"), ddst=DT.float, dsrc=DT.float),
        Instruction("micro_arange", dst=_reg(DT.float, "arange_dst"), dtype=DT.float),
    ]

    estimate = estimate_task_cycles(_call_micro_task(instructions), SharedMemoryStore(), model)

    assert estimate.cycles == 3 + 19 + 4 + 2 + 3
    assert estimate.details["instruction_count"] == 5
    assert estimate.details["instruction_cycle_counts"]["micro_vadd:float"] == 1
    assert estimate.details["instruction_cycle_counts"]["micro_vdiv:half"] == 1
    assert estimate.details["instruction_cycle_counts"]["micro_cast:half->uint8"] == 1
    assert estimate.details["instruction_cycle_counts"]["micro_cast:float->float"] == 1
    assert estimate.details["instruction_cycle_counts"]["micro_arange"] == 1


def test_call_micro_ignores_reg_reinterpret_cycles():
    for model in (load_cycle_model_for_device("950"), _legacy_micro_model()):
        instructions = [
            Instruction("micro_reg_reinterpret", dst=_reg(DT.uint8, "bytes"), src=_reg(DT.float, "src")),
        ]
        estimate = estimate_task_cycles(_call_micro_task(instructions), SharedMemoryStore(), model)
        assert estimate.cycles == 0


def test_legacy_call_micro_loop_sums_measured_micro_cycles():
    model = _legacy_micro_model()
    instructions = [
        Instruction("start_micro_loop", var="i", start=0, stop=4, step=1),
        Instruction("micro_vadd", dst=_reg(DT.float, "dst"), src=_reg(DT.float, "a"), src1=_reg(DT.float, "b")),
        Instruction("end_loop"),
    ]

    estimate = estimate_task_cycles(_call_micro_task(instructions), SharedMemoryStore(), model)

    assert estimate.cycles == 4 * 3
    assert estimate.details["instruction_count"] == 4
    assert estimate.details["instruction_cycle_counts"]["micro_vadd:float"] == 4


def test_a5_scheduled_vf_adds_fixed_overhead():
    # A tiny VF is dominated by the fixed launch/drain overhead (~46), not the
    # single op's latency -- the legacy serial sum missed this entirely.
    model = load_cycle_model_for_device("950")
    instructions = [
        Instruction("micro_vadd", dst=_reg(DT.float, "d"), src=_reg(DT.float, "a"), src1=_reg(DT.float, "b")),
    ]

    estimate = estimate_task_cycles(_call_micro_task(instructions), SharedMemoryStore(), model)

    assert estimate.details["model_kind"] == "vpipe_micro_scheduled"
    assert estimate.cycles == int(round(model.vf_fixed_overhead_cycles + 7))  # vadd latency 7


def test_a5_scheduled_vf_overlaps_independent_pipes():
    # 20 independent loads + 20 independent EX ops: the pipes run concurrently, so
    # the cost is the busiest pipe (LD), NOT the serial sum of both.
    model = load_cycle_model_for_device("950")
    loads = [Instruction("micro_ub2reg", dst=_reg(DT.float, f"r{i}"), src=_micro_tensor(f"t{i}")) for i in range(20)]
    execs = [Instruction("micro_vmax", dst=_reg(DT.float, f"m{i}"), src1=_reg(DT.float, f"p{i}"), src2=_reg(DT.float, f"q{i}")) for i in range(20)]

    estimate = estimate_task_cycles(_call_micro_task(loads + execs), SharedMemoryStore(), model)

    busy = estimate.details["pipe_busy"]
    # 20 explicit ub2reg loads at the contiguous bank-base interval (vf_ld_bank_base=3.5);
    # the merged model charges explicit reg2ub/ub2reg a UB bank-conflict interval, not flat 1.
    assert busy["LD"] == 20 * model.vf_ld_bank_base
    assert busy["EX"] < busy["LD"]                  # light vmax ops dual-issue
    # makespan is the busiest pipe, so total < fixed + LD_busy + EX_busy (no serialisation)
    assert estimate.cycles < model.vf_fixed_overhead_cycles + busy["LD"] + busy["EX"]


def test_a5_scheduled_vf_constant_loop_folds_address_su_but_variable_loop_does_not():
    model = load_cycle_model_for_device("950")

    def loop(bound):
        return [
            Instruction("start_micro_loop", var=Var(0, name="i"), start=0, stop=bound, step=1),
            Instruction("create_var", val=Var(0, name="off")),
            Instruction("var_mul", a=Var(0, name="i"), b=4, out=Var(0, name="off")),
            Instruction("var_add", a=Var(0, name="off"), b=1, out=Var(0, name="off2")),
            Instruction("micro_vadd", dst=_reg(DT.float, "d"), src=_reg(DT.float, "a"), src1=_reg(DT.float, "b")),
            Instruction("end_loop", var=Var(0, name="i")),
        ]

    const_est = estimate_task_cycles(_call_micro_task(loop(8)), SharedMemoryStore(), model)
    var_task = PipeTask(pipe_name="V", opname="call_micro",
                        args={"micro_def": {"instructions": loop(Var(8, name="N"))}, "var_values": {"N": 8}})
    var_est = estimate_task_cycles(var_task, SharedMemoryStore(), model)

    # constant bound -> address arithmetic folds to immediates (no SU work)
    assert const_est.details["pipe_counts"]["SU"] == 0
    # variable bound -> the two address var-ops execute on SU every iteration
    assert var_est.details["pipe_counts"]["SU"] == 2 * 8
    assert var_est.cycles > const_est.cycles


def test_a5_scheduled_vf_propagates_var_div_into_loop_bound():
    model = load_cycle_model_for_device("950")
    chunks = Var(0, name="chunks")
    pairs = Var(0, name="pairs")
    instructions = [
        Instruction("var_div", a=chunks, b=2, out=pairs),
        Instruction("start_micro_loop", var=Var(0, name="i"), start=0, stop=pairs, step=1),
        Instruction(
            "micro_vadd", dst=_reg(DT.float, "d"),
            src=_reg(DT.float, "a"), src1=_reg(DT.float, "b"),
        ),
        Instruction("end_loop", var=Var(0, name="i")),
    ]
    task = PipeTask(
        pipe_name="V", opname="call_micro",
        args={"micro_def": {"instructions": instructions}, "var_values": {"chunks": 10}},
    )

    estimate = estimate_task_cycles(task, SharedMemoryStore(), model)

    assert estimate.details["pipe_counts"]["SU"] == 1
    assert estimate.details["pipe_counts"]["EX"] == 5


def test_a5_scheduled_vf_squeeze_runs_on_ex_pipe():
    # micro_squeeze lowers to RV_VSQZ on the vector EX pipe, not the store pipe.
    model = load_cycle_model_for_device("950")
    instructions = [
        Instruction("micro_squeeze", dst=_reg(DT.int8, "p"), src=_reg(DT.int8, "s"), mask=_reg(DT.uint32, "mk")),
    ]

    estimate = estimate_task_cycles(_call_micro_task(instructions), SharedMemoryStore(), model)

    assert estimate.details["pipe_counts"]["EX"] == 1
    assert estimate.details["pipe_counts"]["ST"] == 0


def test_event_and_cross_intra_sync_markers_request_no_instruction_overhead():
    model = load_cycle_model_for_device("950")
    sync_ops = (
        "event_set",
        "event_wait",
        "event_setall",
        "event_release",
        "cube_ready",
        "vec_ready",
        "wait_cube",
        "wait_vec",
        "allcube_ready",
        "allvec_ready",
        "allcube_wait",
        "allvec_wait",
    )

    for opname in sync_ops:
        task = PipeTask(pipe_name="MTE3", opname=opname, args={})
        estimate = estimate_task_cycles(task, SharedMemoryStore(), model)

        assert estimate.cycles == 1
        assert estimate.details["model_kind"] == "sync_marker"
        assert estimate.details["no_instruction_overhead"] is True


def test_call_simt_cycle_model_counts_dynamic_loop_iterations():
    model = load_cycle_model_for_device("950")
    out = torch.zeros(10, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor"), ("n", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out", "index": {"kind": "name", "id": "i"}},
                expr={"kind": "const", "value": 1, "dtype": "int"},
            ),
            Instruction("simt_endfor"),
        ],
    }
    task = PipeTask(
        pipe_name="V", opname="call_simt",
        args={
            "simt_def": simt_def,
            "tensor_views": {"out": out},
            "var_values": {"n": 10},
            "thread_num": 4,
        },
    )

    estimate = estimate_task_cycles(task, SharedMemoryStore(), model)

    assert estimate.cycles == 12
    assert estimate.details["model_kind"] == "vpipe_simt"
    assert estimate.details["instruction_count"] == 3
    assert estimate.details["cycles_per_instruction"] == 4
    assert "no_instruction_overhead" not in estimate.details
    assert _pipe_for_cycle_estimates(SharedMemoryStore())._estimate_task_cycles(task) == 22.0

    deferred_args = dict(task.args)
    deferred_args["_simt_defer_cycle_count"] = True
    deferred_task = PipeTask(pipe_name="V", opname="call_simt", args=deferred_args)
    assert estimate_task_cycles(deferred_task, SharedMemoryStore(), model).cycles == 0
    deferred_task.args["_simt_instruction_count"] = 3
    assert _pipe_for_cycle_estimates(SharedMemoryStore())._estimate_task_cycles(deferred_task) == 22.0
    assert out.tolist() == [0] * 10


def test_call_simt_cycle_model_counts_divergent_branches_as_masked_instructions():
    model = load_cycle_model_for_device("950")
    out = torch.zeros(4, dtype=torch.int32)
    simt_def = {
        "input_list": [("out", "Tensor")],
        "locked_dtypes": ["int"],
        "instructions": [
            Instruction(
                "simt_if",
                cond={
                    "kind": "compare",
                    "op": "<",
                    "left": {"kind": "intrinsic", "name": "simt_thread_id"},
                    "right": {"kind": "const", "value": 2, "dtype": "int"},
                },
            ),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={
                    "kind": "subscript", "base": "out",
                    "index": {"kind": "intrinsic", "name": "simt_thread_id"},
                },
                expr={"kind": "const", "value": 1, "dtype": "int"},
            ),
            Instruction("simt_else"),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={
                    "kind": "subscript", "base": "out",
                    "index": {"kind": "intrinsic", "name": "simt_thread_id"},
                },
                expr={"kind": "const", "value": 2, "dtype": "int"},
            ),
            Instruction("simt_endif"),
        ],
    }
    task = PipeTask(
        pipe_name="V", opname="call_simt",
        args={"simt_def": simt_def, "tensor_views": {"out": out}, "thread_num": 4},
    )

    estimate = estimate_task_cycles(task, SharedMemoryStore(), model)

    assert estimate.cycles == 8
    assert estimate.details["instruction_count"] == 2
    assert out.tolist() == [0] * 4


def test_call_simt_cycle_model_accepts_physical_alias_bindings():
    model = load_cycle_model_for_device("950")
    base = torch.zeros(8, dtype=torch.int32)
    logical = base[2:6]
    alias = PhysicalAlias(
        tensor=base,
        logical_view=logical,
        byte_offset=2 * int(base.element_size()),
        logical_offset_bytes=2 * int(base.element_size()),
        name="out",
        storage_name="base",
        role="ub",
        tags=("runtime_view", "slice_tensor"),
    )
    simt_def = {
        "input_list": [("out", "Tensor"), ("n", "Var")],
        "locked_dtypes": ["int", "int"],
        "instructions": [
            Instruction(
                "simt_for_range", var_name="i",
                start={"kind": "intrinsic", "name": "simt_thread_id"},
                stop={"kind": "name", "id": "n"},
                step={"kind": "intrinsic", "name": "simt_thread_num"},
            ),
            Instruction(
                "simt_assign", target_kind="subscript",
                target={"kind": "subscript", "base": "out", "index": {"kind": "name", "id": "i"}},
                expr={"kind": "const", "value": 1, "dtype": "int"},
            ),
            Instruction("simt_endfor"),
        ],
    }
    task = PipeTask(
        pipe_name="V", opname="call_simt",
        args={
            "simt_def": simt_def,
            "tensor_views": {"out": alias},
            "var_values": {"n": 4},
            "thread_num": 4,
        },
    )
    raw_task = PipeTask(
        pipe_name="V", opname="call_simt",
        args={
            "simt_def": simt_def,
            "tensor_views": {"out": logical},
            "var_values": {"n": 4},
            "thread_num": 4,
        },
    )

    estimate = estimate_task_cycles(task, SharedMemoryStore(), model)
    raw_estimate = estimate_task_cycles(raw_task, SharedMemoryStore(), model)

    assert estimate.cycles == raw_estimate.cycles
    assert estimate.details["instruction_count"] == raw_estimate.details["instruction_count"]
    assert base.tolist() == [0] * 8


def test_intra_core_sync_latency_is_separate_from_sync_marker_cycles():
    a5_model = load_cycle_model_for_device("950")
    a2_model = load_cycle_model_for_device("b3")

    assert a5_model.sync_marker_cycles == 1
    assert a5_model.intra_core_sync_latency_cycles == 200
    assert a2_model.sync_marker_cycles == 1
    assert a2_model.intra_core_sync_latency_cycles == 1000


def test_pipe_cycle_estimate_skips_head_overhead_for_event_and_sync_ops():
    pipe = _pipe_for_cycle_estimates(_store_with_mmad_operands(torch.float32))

    event_set = PipeTask(pipe_name="MTE3", opname="event_set", args={})
    cube_ready = PipeTask(pipe_name="M", opname="cube_ready", args={})
    allcube_wait = PipeTask(pipe_name="S", opname="allcube_wait", args={})

    assert pipe._estimate_task_cycles(event_set) == 1.0
    assert pipe._estimate_task_cycles(cube_ready) == 1.0
    assert pipe._estimate_task_cycles(allcube_wait) == 1.0
    assert pipe._estimate_task_cycles(_mmad_task()) == 1091.0


# --- Merged model: UB bank conflict on explicit strided reg2ub/ub2reg (grafted from the
#     scoreboard branch onto the 4-pipe schedule). Contiguous `<<=` cont ops stay flat. ---
def _bank_interval(model, opname, stride, pipe):
    if opname == "micro_reg2ub":
        inst = [Instruction(opname, dst=_micro_tensor("d"), src=_reg(DT.bfloat16, "s"), blk_stride=stride)]
    else:
        inst = [Instruction(opname, dst=_reg(DT.bfloat16, "d"), src=_micro_tensor("s"), blk_stride=stride)]
    est = estimate_task_cycles(_call_micro_task(inst), SharedMemoryStore(), load_cycle_model_for_device("950"))
    return est.details["pipe_busy"][pipe]


def test_a5_merged_reg2ub_store_bank_conflict_scales_with_pow2_stride():
    model = load_cycle_model_for_device("950")
    def itv(s):
        return _bank_interval(model, "micro_reg2ub", s, "ST")
    assert itv(1) == 3      # contiguous
    assert itv(3) == 3      # odd stride: store keeps the fast path (no penalty)
    assert itv(2) == 4      # 2-way conflict
    assert itv(4) == 6      # 4-way
    assert itv(8) == 10     # 8-way
    assert itv(16) == 10    # saturated at 8 ways
    assert itv(32) == 10


def test_a5_merged_ub2reg_load_bank_conflict_and_strided_penalty():
    model = load_cycle_model_for_device("950")
    def itv(s):
        return _bank_interval(model, "micro_ub2reg", s, "LD")
    assert itv(1) == 3.5    # contiguous fast path
    assert itv(3) == 5.75   # any stride>1 loses the fast path even when odd
    assert itv(2) == 7.75   # + 2-way conflict
    assert itv(4) == 11.75  # + 4-way (saturated)
    assert itv(8) == 11.75  # load saturates at 4 ways, not 8


def test_a5_merged_contiguous_cont_datamove_stays_flat():
    # The `<<=` sugar lowers to micro_ub2regcont / micro_reg2ubcont -- a separate fast path
    # that keeps the flat vf_pipe_issue_interval (measured ~1 on cannsim), NOT the bank curve.
    model = load_cycle_model_for_device("950")
    ld = estimate_task_cycles(_call_micro_task(
        [Instruction("micro_ub2regcont", dst=_reg(DT.bfloat16, "d"), src=_micro_tensor("s"), blk_stride=32)]),
        SharedMemoryStore(), model)
    st = estimate_task_cycles(_call_micro_task(
        [Instruction("micro_reg2ubcont", dst=_micro_tensor("d"), src=_reg(DT.bfloat16, "s"), blk_stride=32)]),
        SharedMemoryStore(), model)
    assert ld.details["pipe_busy"]["LD"] == model.vf_pipe_issue_interval["LD"]   # flat, not bank-charged
    assert st.details["pipe_busy"]["ST"] == model.vf_pipe_issue_interval["ST"]


def test_a5_merged_crit_slack_lifts_a_raw_chain_but_not_independent_ops():
    # The bounded RAW critical-path term (grafted from the scoreboard branch), gated by
    # vf_crit_slack (A5 json calibrates 0.46). With slack>0 a genuine register RAW chain (acc
    # reused) is lifted toward its latency bound; independent ops (no chain) stay
    # throughput-bound. A reused reg written from fresh operands does NOT create a WAR chain --
    # only true reads-after-writes count.
    off = replace(load_cycle_model_for_device("950"), vf_crit_slack=0.0)
    slacked = replace(off, vf_crit_slack=0.5)
    chain = [Instruction("micro_vadd", dst=_reg(DT.float, "acc"), src=_reg(DT.float, "acc"),
                         src1=_reg(DT.float, f"x{i}")) for i in range(16)]
    indep = [Instruction("micro_vadd", dst=_reg(DT.float, f"d{i}"), src=_reg(DT.float, f"a{i}"),
                         src1=_reg(DT.float, f"b{i}")) for i in range(16)]
    chain_off = estimate_task_cycles(_call_micro_task(chain), SharedMemoryStore(), off).cycles
    chain_on = estimate_task_cycles(_call_micro_task(chain), SharedMemoryStore(), slacked).cycles
    indep_on = estimate_task_cycles(_call_micro_task(indep), SharedMemoryStore(), slacked).cycles
    indep_off = estimate_task_cycles(_call_micro_task(indep), SharedMemoryStore(), off).cycles
    assert chain_on > chain_off          # slack lifts the RAW chain
    assert indep_on == indep_off         # independent ops unaffected (no chain, no WAR)


def test_a5_merged_per_op_ex_interval_override_splits_alu_from_rearrange():
    # The EX issue-interval line (slope*lat+intercept) over-charges plain elementwise ALU and
    # under-charges data-rearrange ops (RV_VSQZ/VDINTLV/VPACK serialize). vf_ex_interval_override
    # (cannsim marginal A/B) replaces the line per-op: micro_squeeze is DEARER than its latency
    # line implies, micro_vmuls is CHEAPER, and an unlisted op still follows the line.
    base = load_cycle_model_for_device("950")           # A5 json ships the override
    plain = replace(base, vf_ex_interval_override={})    # fall back to the slope/intercept line
    n = 64

    def busy(model, opname, dt=DT.float):
        inst = [Instruction(opname, dst=_reg(dt, f"d{i}"), src=_reg(dt, f"a{i}"),
                            src1=_reg(dt, f"b{i}")) for i in range(n)]
        est = estimate_task_cycles(_call_micro_task(inst), SharedMemoryStore(), model)
        return est.details["pipe_busy"]["EX"]

    # rearrange op dearer under override, ALU op cheaper, both vs the bare line
    assert busy(base, "micro_squeeze") > busy(plain, "micro_squeeze") * 1.5
    assert busy(base, "micro_vmuls") < busy(plain, "micro_vmuls")
    # an EX op with no override entry is identical with/without the override table
    # (micro_vabs is cheap ALU measured but deliberately left on the line -- see cheap-ALU note)
    assert busy(base, "micro_vabs") == busy(plain, "micro_vabs")
