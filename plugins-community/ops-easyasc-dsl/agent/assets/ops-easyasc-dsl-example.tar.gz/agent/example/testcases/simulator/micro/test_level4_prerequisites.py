"""Focused regressions for A5 CANN Bench Level-4 prerequisites."""

import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate
from easyasc.simulator import build_kernel_program
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime


@kernel()
def _multiple_workspace_kernel(out: GMTensor):
    split_workspace(DT.float, [3], name="level4_float_workspace")
    split_workspace(DT.half, [5], name="level4_half_workspace")
    return out


def test_multiple_workspaces_receive_disjoint_byte_offsets() -> None:
    out = GMTensor(DT.half, [1], name="out")
    _multiple_workspace_kernel(out)
    program = build_kernel_program(_multiple_workspace_kernel)
    specs = {
        item["name"]: item
        for item in program.metadata.get("tensor_specs", [])
    }

    first = specs["level4_float_workspace"]
    second = specs["level4_half_workspace"]
    assert first["storage_offset_bytes"] == 0
    assert first["storage_size_bytes"] == 3 * DT.float.size
    assert second["storage_offset_bytes"] == 3 * DT.float.size
    assert second["storage_size_bytes"] == 5 * DT.half.size


@pytest.mark.parametrize(
    ("opname", "expected"),
    (
        ("micro_vadd", (2 ** 40 + 3) + (2 ** 20 + 1)),
        ("micro_vsub", (2 ** 40 + 3) - (2 ** 20 + 1)),
        ("micro_vmul", (2 ** 30 + 3) * 1025),
    ),
)
def test_micro_int64_binary_preserves_low_bits(opname: str, expected: int) -> None:
    lhs_value = 2 ** 30 + 3 if opname == "micro_vmul" else 2 ** 40 + 3
    rhs_value = 1025 if opname == "micro_vmul" else 2 ** 20 + 1
    runtime = MicroRuntime()
    lhs = Reg(DT.int64, name="lhs")
    rhs = Reg(DT.int64, name="rhs")
    out = Reg(DT.int64, name="out")
    mask = MaskReg(DT.int64, init_mode=MaskType.ALL, name="mask")
    context = MicroContext(
        regs={
            "lhs": torch.full((32,), lhs_value, dtype=torch.int64),
            "rhs": torch.full((32,), rhs_value, dtype=torch.int64),
        },
        masks={"mask": torch.ones(32, dtype=torch.bool)},
    )

    runtime._stack.append(context)
    try:
        runtime._dispatch(
            opname,
            {"dst": out, "src1": lhs, "src2": rhs, "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    torch.testing.assert_close(
        context.regs["out"],
        torch.full((32,), expected, dtype=torch.int64),
        rtol=0, atol=0,
    )


def test_mask_interleave_codegen_has_explicit_template_type() -> None:
    @vf()
    def interleave_masks():
        source0 = MaskReg(DT.float, init_mode=MaskType.ALL, name="source0")
        source1 = MaskReg(DT.float, init_mode=MaskType.NONE, name="source1")
        destination0 = MaskReg(DT.float, init_mode=MaskType.NONE, name="destination0")
        destination1 = MaskReg(DT.float, init_mode=MaskType.NONE, name="destination1")
        mask_interleave(destination0, destination1, source0, source1)

    interleave_masks()
    code = translate(interleave_masks.instructions)
    assert "MicroAPI::MaskInterleave<float>(" in code
