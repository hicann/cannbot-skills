"""Anonymous L0 buffers reused across If gates must share depth-1 sync events.

Regression for the multicore conv WAR hazard: every If-gated M-tile reuses one
anonymous L0A/L0B/L0C set; with the old `_tmp_* -> no sync key` rule each gate
minted fresh preset events, leaving FIX(read L0C, gate n) -> M(write L0C,
gate n+1) unsynchronized (lost tiles at 20 cores).
"""
import re

from easyasc.a2 import *

C0 = 16
H, W, C, COUT = 8, 8, 32, 32
KH = KW = 3
PAD = (1, 1, 1, 1)
C1 = C // C0
K = C1 * KH * KW * C0
HO, WO = H, W
M_PAD = (HO * WO + 15) // 16 * 16


@kernel()
def _gated_conv_kernel(data: GMTensor, weight: GMTensor, out: GMTensor, nb: Var):
    conv = Conv2D(KH, KW, pad=PAD)
    fm = Tensor(DT.half, [C1 * H * W, C0], Position.L1)
    w_l1 = Tensor(DT.half, [COUT, K], Position.L1)
    l0c = Tensor(DT.float, [16, COUT], Position.L0C)
    cube_idx = GetCubeIdx()
    with auto_sync():
        fm <<= data[:, :]
        w_l1 <<= weight[:, :]
        for m0 in unroll(0, M_PAD, 16):
            with If(cube_idx == (m0 // 16) % 4):
                conv2d(l0c, fm, w_l1, conv, h=H, w=W, c=C, cout=COUT,
                       m0=m0, tile_k=144)
                l0c_to_gm_nz2nz(out[m0:m0 + 16, :], l0c, m_pad=M_PAD)
    return out


def _synced_cube_instructions():
    from easyasc.parser.asc import split_instructions
    from easyasc.parser.asc_autosync import insert_auto_sync

    data = GMTensor(DT.half, [C1 * H * W, C0])
    weight = GMTensor(DT.half, [COUT, K])
    out = GMTensor(DT.float, [COUT // 16 * M_PAD, 16])   # NZ plane for l0c_to_gm_nz2nz
    _gated_conv_kernel(data, weight, out, Var(1))
    cube_raw, _ = split_instructions(_gated_conv_kernel.instructions)
    return insert_auto_sync(cube_raw, mode="cube")


def test_gated_l0_round_trips_share_one_event_index():
    insts = _synced_cube_instructions()
    idx = {"l0": set(), "fix": set()}
    for inst in insts:
        if "event" not in inst.opname or "create" in inst.opname:
            continue
        ev = getattr(inst, "val", None) or inst.kwargs.get("event")
        m = re.match(r"_tmp_[sd]event_(?:ready|valid)_(l0|fix)_(\d+)", getattr(ev, "name", ""))
        if m:
            idx[m.group(1)].add(int(m.group(2)))
    # 4 M-tiles x 2 K-tiles all reuse the same anonymous L0A/L0B/L0C, so all
    # gates must fold onto one event index per buffer class.
    assert idx["l0"] == {0}, idx["l0"]
    assert idx["fix"] == {0}, idx["fix"]


def test_every_l0c_write_waits_prior_fix_read():
    insts = _synced_cube_instructions()
    armed = True  # valid_fix preset arms the first mmad round
    for inst in insts:
        op = inst.opname
        ev = getattr(inst, "val", None) or inst.kwargs.get("event")
        name = getattr(ev, "name", "")
        if op == "event_wait" and "valid_fix" in name:
            armed = True
        elif op == "mmad" and inst.kwargs.get("is_init"):
            assert armed, "mmad is_init reuses L0C without waiting prior FIX read"
            armed = False
