import pytest
import torch

from easyasc.a5 import (
    fp32_to_fp4_e1m2,
    fp32_to_fp4_e2m1,
    fp4_e1m2_to_fp32,
    fp4_e2m1_to_fp32,
)


def test_fp32_to_fp4_e2m1_packs_low_nibble_first_and_rounds_ties_up() -> None:
    values = torch.tensor([[0.0, 0.25, -0.25, 0.75, 5.0]], dtype=torch.float32)
    carrier = fp32_to_fp4_e2m1(values)

    torch.testing.assert_close(
        carrier,
        torch.tensor([[0x10, 0x29, 0x07]], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )
    decoded_default = fp4_e2m1_to_fp32(carrier)
    torch.testing.assert_close(
        decoded_default,
        torch.tensor([[0.0, 0.5, -0.5, 1.0, 6.0, 0.0]], dtype=torch.float32),
        rtol=0,
        atol=0,
    )
    decoded_shape = fp4_e2m1_to_fp32(carrier, logical_shape=values.shape)
    torch.testing.assert_close(
        decoded_shape,
        torch.tensor([[0.0, 0.5, -0.5, 1.0, 6.0]], dtype=torch.float32),
        rtol=0,
        atol=0,
    )


def test_fp32_to_fp4_e1m2_saturates_and_supports_pack_axis_zero() -> None:
    values = torch.tensor([[0.125, -1.625], [2.0, -0.125], [0.0, 0.25]], dtype=torch.float32)
    carrier = fp32_to_fp4_e1m2(values, pack_axis=0)

    torch.testing.assert_close(
        carrier,
        torch.tensor([[0x71, 0x9F], [0x00, 0x01]], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )
    decoded = fp4_e1m2_to_fp32(carrier, logical_shape=values.shape, pack_axis=0)
    torch.testing.assert_close(
        decoded,
        torch.tensor([[0.25, -1.75], [1.75, -0.25], [0.0, 0.25]], dtype=torch.float32),
        rtol=0,
        atol=0,
    )


def test_fp32_to_fp4_e1m2_rint_uses_ties_to_even() -> None:
    values = torch.tensor([[0.125, 0.375, 0.625, 0.875]], dtype=torch.float32)
    carrier = fp32_to_fp4_e1m2(values, round_mode="CAST_RINT")

    torch.testing.assert_close(carrier, torch.tensor([[0x20, 0x42]], dtype=torch.uint8), rtol=0, atol=0)

    signed_zero = fp32_to_fp4_e1m2(
        torch.tensor([[-0.125, 0.125]], dtype=torch.float32), round_mode="CAST_RINT"
    )
    torch.testing.assert_close(signed_zero, torch.tensor([[0x08]], dtype=torch.uint8), rtol=0, atol=0)


def test_fp32_to_fp4_e1m2_directed_round_modes() -> None:
    values = torch.tensor([[0.1, -0.1]], dtype=torch.float32)

    torch.testing.assert_close(
        fp32_to_fp4_e1m2(values, round_mode="CAST_FLOOR"),
        torch.tensor([[0x90]], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )
    torch.testing.assert_close(
        fp32_to_fp4_e1m2(values, round_mode="CAST_CEIL"),
        torch.tensor([[0x81]], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )
    torch.testing.assert_close(
        fp32_to_fp4_e1m2(values, round_mode="CAST_TRUNC"),
        torch.tensor([[0x80]], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )


def test_fp4_decode_rejects_shape_mismatch() -> None:
    with pytest.raises(ValueError, match="carrier shape mismatch"):
        fp4_e2m1_to_fp32(torch.zeros((2, 2), dtype=torch.uint8), logical_shape=(2, 5))


def test_fp4_encode_rejects_nan_unless_requested() -> None:
    values = torch.tensor([float("nan"), 1.0], dtype=torch.float32)
    with pytest.raises(ValueError, match="FP4 has no NaN payload"):
        fp32_to_fp4_e2m1(values)

    carrier = fp32_to_fp4_e2m1(values, nan_to_zero=True)
    decoded = fp4_e2m1_to_fp32(carrier, logical_shape=values.shape)
    torch.testing.assert_close(decoded, torch.tensor([0.0, 1.0], dtype=torch.float32), rtol=0, atol=0)
