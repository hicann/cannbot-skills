import pytest

from easyasc import globvars
from easyasc.a2 import *
from easyasc.parser.asc import translate_split


def test_stub_gm_to_l1_nd2nz_rejects_dtype_mismatch() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [16, 16], Position.L1)
        gm_to_l1_nd2nz(dst, inp[0:16, 0:16])
        return inp

    inp = GMTensor(DT.half, [16, 16])
    with pytest.raises(ValueError, match="dst/src data types must match"):
        stub_only(inp)


def test_codegen_gm_to_l1_nd2nz_uses_float_zz_helper_on_b_device() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "b3"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [16, 16], Position.L1)
            dst <<= inp[0:16, 0:16]
            return inp

        inp = GMTensor(DT.float, [16, 16])
        stub_only(inp)
        cube_code, vec_code = translate_split(stub_only.instructions, "gm_to_l1_float_b3")
        assert "GM2L1_ND2ZZ(" in cube_code
        assert "GM2L1_ND2NZ(" not in cube_code
        assert "GM2L1_ND2ZZ(" not in vec_code
    finally:
        globvars.device_type = saved_device_type


def test_codegen_gm_to_l1_nd2nz_keeps_nz_helper_for_non_float_on_b_device() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "b3"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.half, [16, 16], Position.L1)
            dst <<= inp[0:16, 0:16]
            return inp

        inp = GMTensor(DT.half, [16, 16])
        stub_only(inp)
        cube_code, vec_code = translate_split(stub_only.instructions, "gm_to_l1_half_b3")
        assert "GM2L1_ND2NZ(" in cube_code
        assert "GM2L1_ND2ZZ(" not in cube_code
        assert "GM2L1_ND2NZ(" not in vec_code
    finally:
        globvars.device_type = saved_device_type
