from easyasc.simulator.physical_alias import PhysicalAlias, as_physical_alias


class _TensorStore(object):
    def __init__(self, tensors=None):
        self._tensors = dict(tensors or {})
        self._aliases = {}
        self._logical_offsets = {}
        self.specs = {}

    def tensor(self, name):
        return self._tensors[name]

    def alias(self, name):
        if name in self._aliases:
            return self._aliases[name]
        if name not in self._tensors:
            return None
        logical_offset = self._logical_offsets.get(name)
        return as_physical_alias(self._tensors[name], logical_offset_bytes=logical_offset, name=name, storage_name=name)

    def contains(self, name):
        return name in self._tensors or name in self._aliases

    def register_view(self, name, view, logical_offset_bytes=None):
        if isinstance(view, PhysicalAlias):
            self._aliases[name] = view
            self._tensors[name] = view.logical_tensor()
            if view.logical_offset_bytes is not None:
                self._logical_offsets[name] = int(view.logical_offset_bytes)
            elif logical_offset_bytes is not None:
                self._logical_offsets[name] = int(logical_offset_bytes)
            else:
                self._logical_offsets.pop(name, None)
            return
        self._aliases.pop(name, None)
        self._tensors[name] = view
        if logical_offset_bytes is not None:
            self._logical_offsets[name] = int(logical_offset_bytes)
        else:
            self._logical_offsets.pop(name, None)

    def logical_offset_bytes(self, name):
        return self._logical_offsets.get(name)
