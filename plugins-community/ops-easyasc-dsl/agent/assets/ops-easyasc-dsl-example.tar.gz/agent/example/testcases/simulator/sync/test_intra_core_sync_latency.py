from easyasc.simulator.sync import IntraCoreSync


def test_cube_ready_visible_cycles_are_consumed_fifo_per_vec_lane() -> None:
    sync = IntraCoreSync()

    sync.cube_ready(0, ready_cycle=1000, visible_cycle=1300)
    sync.cube_ready(0, ready_cycle=1100, visible_cycle=1400)

    assert sync.wait_cube(0, 0, timeout=0.01)
    assert sync.cube_ready_signal_cycle(0, 0) == 1000
    assert sync.cube_ready_cycle(0, 0) == 1300

    assert sync.wait_cube(0, 0, timeout=0.01)
    assert sync.cube_ready_signal_cycle(0, 0) == 1100
    assert sync.cube_ready_cycle(0, 0) == 1400


def test_vec_ready_wait_vec_uses_latest_visible_cycle_for_barrier_round() -> None:
    sync = IntraCoreSync()

    sync.vec_ready(0, 1, ready_cycle=1000, visible_cycle=1300)
    sync.vec_ready(1, 1, ready_cycle=1100, visible_cycle=1400)

    assert sync.wait_vec(1, timeout=0.01)
    assert sync.vec_ready_signal_cycle(1) == 1100
    assert sync.vec_ready_cycle(1) == 1400
