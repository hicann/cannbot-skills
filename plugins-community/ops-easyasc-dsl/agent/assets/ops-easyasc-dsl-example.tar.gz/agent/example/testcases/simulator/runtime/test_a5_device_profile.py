"""Focused facade tests for simulator-facing device profiles."""

import importlib

from easyasc import globvars
from easyasc.device_profile import (
    compile_unit_for,
    core_num_for,
    debug_chipset_for,
    get_device_profile,
    is_c220_family,
    vec_num_for,
)
from easyasc.simulator import SimulatorConfig


def test_a2_import_resets_complete_device_profile() -> None:
    saved = (
        globvars.device_type, globvars.core_num, globvars.l1_cap,
        globvars.l0a_cap, globvars.l0b_cap, globvars.l0amx_cap,
        globvars.l0bmx_cap, globvars.l0c_cap, globvars.bt_cap, globvars.ub_cap,
    )
    try:
        globvars.device_type = "950"
        globvars.core_num = 32
        globvars.l0c_cap = 256
        globvars.bt_cap = 4
        globvars.ub_cap = 256
        importlib.reload(importlib.import_module("easyasc.a2"))
        assert (
            globvars.device_type, globvars.core_num, globvars.l1_cap,
            globvars.l0a_cap, globvars.l0b_cap, globvars.l0amx_cap,
            globvars.l0bmx_cap, globvars.l0c_cap, globvars.bt_cap, globvars.ub_cap,
        ) == ("b3", 20, 512, 64, 64, 4, 4, 128, 0.5, 192)
    finally:
        (
            globvars.device_type, globvars.core_num, globvars.l1_cap,
            globvars.l0a_cap, globvars.l0b_cap, globvars.l0amx_cap,
            globvars.l0bmx_cap, globvars.l0c_cap, globvars.bt_cap, globvars.ub_cap,
        ) = saved


def test_a3_import_applies_9362_device_profile() -> None:
    saved = (
        globvars.device_type, globvars.core_num, globvars.l1_cap,
        globvars.l0a_cap, globvars.l0b_cap, globvars.l0amx_cap,
        globvars.l0bmx_cap, globvars.l0c_cap, globvars.bt_cap, globvars.ub_cap,
    )
    try:
        importlib.reload(importlib.import_module("easyasc.a3"))
        assert (
            globvars.device_type, globvars.core_num, globvars.l1_cap,
            globvars.l0a_cap, globvars.l0b_cap, globvars.l0amx_cap,
            globvars.l0bmx_cap, globvars.l0c_cap, globvars.bt_cap, globvars.ub_cap,
        ) == ("a3", 20, 512, 64, 64, 4, 4, 128, 0.5, 192)
    finally:
        (
            globvars.device_type, globvars.core_num, globvars.l1_cap,
            globvars.l0a_cap, globvars.l0b_cap, globvars.l0amx_cap,
            globvars.l0bmx_cap, globvars.l0c_cap, globvars.bt_cap, globvars.ub_cap,
        ) = saved


def test_a3_profile_maps_to_ascend910_93_c220() -> None:
    assert get_device_profile("a3").family == "a2"
    assert core_num_for("a3") == 20
    assert vec_num_for("a3") == 40
    assert compile_unit_for("a3") == "ascend910_93"
    assert debug_chipset_for("a3") == "Ascend910_9362"
    assert is_c220_family("a3")


def test_a5_import_applies_expected_device_profile() -> None:
    saved = (
        globvars.device_type,
        globvars.core_num,
        globvars.ub_cap,
        globvars.l0amx_cap,
        globvars.l0bmx_cap,
        globvars.l0c_cap,
        globvars.bt_cap,
    )
    try:
        importlib.reload(importlib.import_module("easyasc.a5"))
        assert globvars.device_type == "950"
        assert globvars.core_num == 32
        assert globvars.ub_cap == 256
        assert globvars.l0amx_cap == 4
        assert globvars.l0bmx_cap == 4
        assert globvars.l0c_cap == 256
        assert globvars.bt_cap == 4
    finally:
        (
            globvars.device_type,
            globvars.core_num,
            globvars.ub_cap,
            globvars.l0amx_cap,
            globvars.l0bmx_cap,
            globvars.l0c_cap,
            globvars.bt_cap,
        ) = saved


def test_a5pr_import_applies_expected_device_profile() -> None:
    saved = (
        globvars.device_type,
        globvars.core_num,
        globvars.ub_cap,
        globvars.l0amx_cap,
        globvars.l0bmx_cap,
        globvars.l0c_cap,
        globvars.bt_cap,
    )
    try:
        importlib.reload(importlib.import_module("easyasc.a5pr"))
        assert globvars.device_type == "950pr"
        assert globvars.core_num == 28
        assert globvars.ub_cap == 256
        assert globvars.l0amx_cap == 4
        assert globvars.l0bmx_cap == 4
        assert globvars.l0c_cap == 256
        assert globvars.bt_cap == 4
    finally:
        (
            globvars.device_type,
            globvars.core_num,
            globvars.ub_cap,
            globvars.l0amx_cap,
            globvars.l0bmx_cap,
            globvars.l0c_cap,
            globvars.bt_cap,
        ) = saved


def test_legacy_simulator_config_defaults_core_count_from_globvars() -> None:
    saved = (globvars.device_type, globvars.core_num)
    try:
        globvars.device_type = "b3"
        globvars.core_num = 7
        assert SimulatorConfig().core_count == 7

        globvars.core_num = 0
        globvars.device_type = "950"
        assert SimulatorConfig().core_count == 32

        globvars.device_type = "950pr"
        assert SimulatorConfig().core_count == 28

        globvars.device_type = "a3"
        assert SimulatorConfig().core_count == 20

        assert SimulatorConfig(core_count=3).core_count == 3
    finally:
        globvars.device_type, globvars.core_num = saved


def test_legacy_simulator_config_defaults_process_start_method_to_auto() -> None:
    assert SimulatorConfig().process_start_method == "auto"
    assert SimulatorConfig(process_start_method="fork").process_start_method == "fork"
