import pytest

from easyasc.a5 import *
from easyasc.parser.asc import split_instructions, translate_split
from easyasc.stub_functions.vec.unaryscalar import adds as vec_adds
from easyasc.utils.instruction import Instruction


MIX_WIDTH = 64
L1_ROWS = 16
L1_COLS = 16


@kernel()
def vec_scope_kernel(x: GMTensor, y: GMTensor):
    src = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    dst = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    alpha = Var(9.0, name="alpha")
    with vec_scope():
        beta = scalar_sqrt(alpha, name="beta")
        src <<= x[0:1, 0:MIX_WIDTH]
        vec_adds(dst, src, beta)
    y[0:1, 0:MIX_WIDTH] <<= dst
    return y


@kernel()
def cube_scope_kernel(src: GMTensor):
    l1 = Tensor(DT.half, [L1_ROWS, L1_COLS], Position.L1)
    blocks = Var(1, name="blocks")
    with cube_scope():
        limited = Min(blocks, 2, name="limited")
        l1 <<= src[0:L1_ROWS, 0:L1_COLS]
        set_constant_to_l1(l1, 1.0, limited)
    return src


@kernel()
def illegal_cube_inside_vec_scope(src: GMTensor):
    l1 = Tensor(DT.half, [L1_ROWS, L1_COLS], Position.L1)
    with vec_scope():
        l1 <<= src[0:L1_ROWS, 0:L1_COLS]
        set_constant_to_l1(l1, 1.0, 1)
    return src


@kernel()
def illegal_vec_inside_cube_scope(x: GMTensor, y: GMTensor):
    src = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    dst = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    with cube_scope():
        src <<= x[0:1, 0:MIX_WIDTH]
        vec_adds(dst, src, 1.0)
    y[0:1, 0:MIX_WIDTH] <<= dst
    return y


@kernel()
def unscoped_set_value_to_gm(dst: GMTensor):
    scalar = Var(5.0, DT.float, name="scalar")
    scalar.SetValueTo(dst)
    return dst


@kernel()
def cube_scope_set_value_to_gm(dst: GMTensor):
    scalar = Var(7.0, DT.float, name="scalar")
    with cube_scope():
        scalar.SetValueTo(dst)
    return dst


@kernel()
def illegal_tensor_set_value_inside_cube_scope(dst: GMTensor):
    ub = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    scalar = Var(3.0, DT.float, name="scalar")
    with cube_scope():
        scalar.SetValueTo(ub)
    dst[0:1, 0:MIX_WIDTH] <<= ub
    return dst


@kernel()
def illegal_shared_if_depends_on_vec_scalar(src: GMTensor):
    ub = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    l1 = Tensor(DT.half, [L1_ROWS, L1_COLS], Position.L1)
    seed = Var(1.0, DT.float, name="seed")
    flag = Var(0.0, DT.float, name="flag")
    keep = Var(1.0, DT.float, name="keep")
    for i in range(1):
        seed.SetValueTo(ub)
        flag.GetValueFrom(ub)
        if flag > 0:
            keep <<= 1.0
        else:
            keep <<= 0.0
        if keep > 0:
            set_constant_to_l1(l1, 1.0, 1)
    return src


@kernel()
def illegal_subblock_derived_if_wraps_cube_load(src: GMTensor):
    l1 = Tensor(DT.half, [L1_ROWS, L1_COLS], Position.L1)
    sb_idx = Var(GetSubBlockIdx(), name="sb_idx")
    gate = Var(sb_idx + 0, name="subblock_gate")
    if gate == 0:
        l1 <<= src[0:L1_ROWS, 0:L1_COLS]
    return src


@kernel()
def illegal_vec_idx_derived_if_wraps_cube_load(src: GMTensor):
    l1 = Tensor(DT.half, [L1_ROWS, L1_COLS], Position.L1)
    vec_idx = Var(GetVecIdx(), name="vec_idx")
    gate = Var(vec_idx + 0, name="vec_gate")
    if gate == 0:
        l1 <<= src[0:L1_ROWS, 0:L1_COLS]
    return src


@kernel()
def illegal_subblock_scalar_as_cube_operand(src: GMTensor):
    l0c = Tensor(DT.float, [L1_ROWS, L1_COLS], Position.L0C)
    ub = Tensor(DT.float, [L1_ROWS, L1_COLS], Position.UB)
    l0c_to_ub(
        ub,
        l0c,
        M=L1_ROWS,
        N=L1_COLS,
        N_dst=L1_COLS,
        M_src=L1_ROWS,
        dual_mode=DualMode.SINGLE,
        sub_block_id=GetSubBlockIdx(),
    )
    return src


@kernel()
def illegal_if_branch_local_var_reuse(src: GMTensor):
    flag = Var(1, name="flag")
    keep = Var(0, name="keep")
    if flag > 0:
        branch_only = Var(flag + 1, name="branch_only")
        keep <<= branch_only
    if flag > 0:
        keep <<= branch_only
    return src


@kernel()
def unscoped_vec_control_loop_kernel(x: GMTensor, y: GMTensor, rows: Var):
    src = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    dst = Tensor(DT.float, [1, MIX_WIDTH], Position.UB)
    rows_per_core = CeilDiv(rows, GetVecNum())
    row_start = Var(rows_per_core * GetVecIdx(), name="row_start")
    row_end = Min(row_start + rows_per_core, rows, name="row_end")
    for t in range(row_start, row_end):
        src <<= x[t:t + 1, 0:MIX_WIDTH]
        vec_adds(dst, src, 1.0)
        y[t:t + 1, 0:MIX_WIDTH] <<= dst
    return y


@pytest.mark.easyasc_device("b3")
def test_vec_scope_emits_markers_and_routes_both_plus_vec_to_vec_side() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH], name="x")
    y = GMTensor(DT.float, [1, MIX_WIDTH], name="y")
    vec_scope_kernel(x, y)

    opnames = [inst.opname for inst in vec_scope_kernel.instructions]
    assert "enter_vec_scope" in opnames
    assert "end_vec_scope" in opnames

    cube_insts, vec_insts = split_instructions(list(vec_scope_kernel.instructions))
    cube_opnames = [inst.opname for inst in cube_insts]
    vec_opnames = [inst.opname for inst in vec_insts]

    assert "enter_vec_scope" not in cube_opnames
    assert "end_vec_scope" not in cube_opnames
    assert "enter_vec_scope" not in vec_opnames
    assert "end_vec_scope" not in vec_opnames
    assert "scalar_sqrt" not in cube_opnames
    assert "adds" not in cube_opnames
    assert "scalar_sqrt" in vec_opnames
    assert "adds" in vec_opnames

    cube_code, vec_code = translate_split(vec_scope_kernel.instructions, "vec_scope_kernel")
    assert "float alpha" not in cube_code
    assert "float beta" not in cube_code
    assert "float alpha = 9.0f;" in vec_code
    assert "float beta = sqrt(alpha);" in vec_code



def test_cube_scope_routes_both_plus_cube_to_cube_side() -> None:
    src = GMTensor(DT.half, [L1_ROWS, L1_COLS], name="src")
    cube_scope_kernel(src)

    opnames = [inst.opname for inst in cube_scope_kernel.instructions]
    assert "enter_cube_scope" in opnames
    assert "end_cube_scope" in opnames

    cube_insts, vec_insts = split_instructions(list(cube_scope_kernel.instructions))
    cube_opnames = [inst.opname for inst in cube_insts]
    vec_opnames = [inst.opname for inst in vec_insts]

    assert "enter_cube_scope" not in cube_opnames
    assert "end_cube_scope" not in cube_opnames
    assert "enter_cube_scope" not in vec_opnames
    assert "end_cube_scope" not in vec_opnames
    assert "Min" in cube_opnames
    assert "set_constant_to_l1" in cube_opnames
    assert "Min" not in vec_opnames
    assert "set_constant_to_l1" not in vec_opnames

    cube_code, vec_code = translate_split(cube_scope_kernel.instructions, "cube_scope_kernel")
    assert "int blocks = 1;" in cube_code
    assert "int limited = Min(blocks, 2);" in cube_code
    assert "blocks" not in vec_code
    assert "limited" not in vec_code


def test_unscoped_set_value_to_gm_warns_and_routes_to_both_sides() -> None:
    dst = GMTensor(DT.float, [1, MIX_WIDTH], name="dst")
    unscoped_set_value_to_gm(dst)

    with pytest.warns(UserWarning, match="SetValueTo .*not limited by vec_scope"):
        cube_insts, vec_insts = split_instructions(list(unscoped_set_value_to_gm.instructions))

    cube_opnames = [inst.opname for inst in cube_insts]
    vec_opnames = [inst.opname for inst in vec_insts]
    assert "SetValueTo" in cube_opnames
    assert "SetValueTo" in vec_opnames


def test_cube_scope_set_value_to_gm_routes_to_cube_only() -> None:
    dst = GMTensor(DT.float, [1, MIX_WIDTH], name="dst")
    cube_scope_set_value_to_gm(dst)

    cube_insts, vec_insts = split_instructions(list(cube_scope_set_value_to_gm.instructions))
    cube_opnames = [inst.opname for inst in cube_insts]
    vec_opnames = [inst.opname for inst in vec_insts]
    assert "SetValueTo" in cube_opnames
    assert "SetValueTo" not in vec_opnames



def test_vec_scope_rejects_cube_only_instruction() -> None:
    src = GMTensor(DT.half, [L1_ROWS, L1_COLS], name="src")
    illegal_cube_inside_vec_scope(src)

    with pytest.raises(ValueError, match="cube-only inside enter_vec_scope"):
        split_instructions(list(illegal_cube_inside_vec_scope.instructions))



@pytest.mark.easyasc_device("b3")
def test_cube_scope_rejects_vec_only_instruction() -> None:
    x = GMTensor(DT.float, [1, MIX_WIDTH], name="x")
    y = GMTensor(DT.float, [1, MIX_WIDTH], name="y")
    illegal_vec_inside_cube_scope(x, y)

    with pytest.raises(ValueError, match="vec-only inside enter_cube_scope"):
        split_instructions(list(illegal_vec_inside_cube_scope.instructions))


def test_cube_scope_rejects_set_value_to_tensor_destination() -> None:
    dst = GMTensor(DT.float, [1, MIX_WIDTH], name="dst")
    illegal_tensor_set_value_inside_cube_scope(dst)

    with pytest.raises(ValueError, match="cube-side SetValueTo only supports GMTensor src"):
        split_instructions(list(illegal_tensor_set_value_inside_cube_scope.instructions))


def test_split_rejects_unbalanced_scope_markers() -> None:
    with pytest.raises(ValueError, match="has no matching scope start"):
        split_instructions([Instruction("end_vec_scope")])

    with pytest.raises(ValueError, match="is not closed before the instruction stream ends"):
        split_instructions([Instruction("enter_cube_scope")])


def test_split_rejects_shared_if_using_pruned_vec_scalar() -> None:
    src = GMTensor(DT.half, [L1_ROWS, L1_COLS], name="src")
    illegal_shared_if_depends_on_vec_scalar(src)

    with pytest.raises(ValueError, match="flag.*no retained writer reaches this control point"):
        split_instructions(list(illegal_shared_if_depends_on_vec_scalar.instructions))


def test_split_rejects_cube_instruction_under_subblock_derived_control() -> None:
    src = GMTensor(DT.half, [L1_ROWS, L1_COLS], name="src")
    illegal_subblock_derived_if_wraps_cube_load(src)

    with pytest.raises(ValueError, match="cube-only inside start_if"):
        split_instructions(list(illegal_subblock_derived_if_wraps_cube_load.instructions))


def test_split_rejects_cube_instruction_under_vec_idx_derived_control() -> None:
    src = GMTensor(DT.half, [L1_ROWS, L1_COLS], name="src")
    illegal_vec_idx_derived_if_wraps_cube_load(src)

    with pytest.raises(ValueError, match="cube-only inside start_if"):
        split_instructions(list(illegal_vec_idx_derived_if_wraps_cube_load.instructions))


def test_split_rejects_subblock_scalar_as_cube_operand() -> None:
    src = GMTensor(DT.half, [L1_ROWS, L1_COLS], name="src")
    illegal_subblock_scalar_as_cube_operand(src)

    with pytest.raises(ValueError, match="cube-side.*vec-only scalar Var"):
        split_instructions(list(illegal_subblock_scalar_as_cube_operand.instructions))


def test_split_rejects_branch_local_var_reuse_in_later_if() -> None:
    src = GMTensor(DT.half, [L1_ROWS, L1_COLS], name="src")
    illegal_if_branch_local_var_reuse(src)

    with pytest.raises(ValueError) as exc_info:
        split_instructions(list(illegal_if_branch_local_var_reuse.instructions))

    message = str(exc_info.value)
    assert "Local Var 'branch_only' is declared inside an if/elif/else branch" in message
    assert "Illegal use" in message
    assert "Hoist the Var declaration before that block" in message

    with pytest.raises(ValueError, match="Local Var 'branch_only'"):
        translate_split(illegal_if_branch_local_var_reuse.instructions, "illegal_if_branch_local_var_reuse")


@pytest.mark.easyasc_device("b3")
def test_unscoped_vec_control_loop_routes_to_vec_side() -> None:
    x = GMTensor(DT.float, [4, MIX_WIDTH], name="x")
    y = GMTensor(DT.float, [4, MIX_WIDTH], name="y")
    rows = Var(4, name="rows")
    unscoped_vec_control_loop_kernel(x, y, rows)

    opnames = [inst.opname for inst in unscoped_vec_control_loop_kernel.instructions]
    assert "enter_vec_scope" not in opnames
    assert "end_vec_scope" not in opnames

    cube_insts, vec_insts = split_instructions(list(unscoped_vec_control_loop_kernel.instructions))
    cube_opnames = [inst.opname for inst in cube_insts]
    vec_opnames = [inst.opname for inst in vec_insts]

    assert "GetVecNum" not in cube_opnames
    assert "GetVecIdx" not in cube_opnames
    assert "CeilDiv" not in cube_opnames
    assert "Min" not in cube_opnames
    assert "start_loop" not in cube_opnames
    assert "GetVecNum" in vec_opnames
    assert "GetVecIdx" in vec_opnames
    assert "CeilDiv" in vec_opnames
    assert "Min" in vec_opnames
    assert "start_loop" in vec_opnames

    cube_code, vec_code = translate_split(
        unscoped_vec_control_loop_kernel.instructions,
        "unscoped_vec_control_loop_kernel",
    )
    assert "GetVecNum()" not in cube_code
    assert "GetVecIdx()" not in cube_code
    assert "rows_per_core" not in cube_code
    assert "row_start" not in cube_code
    assert "row_end" not in cube_code
    assert "int rows_per_core = CeilDiv(rows," in vec_code
    assert "int row_start = rows_per_core*" in vec_code
    assert "int row_end = Min(row_start + rows_per_core, rows);" in vec_code
