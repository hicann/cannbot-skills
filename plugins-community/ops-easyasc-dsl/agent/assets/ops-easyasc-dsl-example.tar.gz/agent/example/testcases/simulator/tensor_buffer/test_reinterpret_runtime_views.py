import torch

from easyasc.a2 import *
from easyasc.simulator import SimulatorConfig


@kernel()
def reinterpret_int_add_autosync_kernel(src: GMTensor, out: GMTensor, contract: Var):
    buf = DBuff(DT.float, [1, 128], Position.UB)

    if GetVecIdx() == 0:
        with auto_sync():
            buf_t = buf[0]
            buf_t <<= src[0:1, 0:128]
            int_view = reinterpret(buf_t, DT.int)
            adds(int_view, int_view, -0x00800000)
            out[0:1, 0:128] <<= buf_t
    return out


def test_reinterpret_int_arithmetic_uses_runtime_typed_view() -> None:
    saved = getattr(reinterpret_int_add_autosync_kernel, "_simulator_config", None)
    reinterpret_int_add_autosync_kernel._simulator_config = SimulatorConfig(
        core_count=1,
        process_start_method="fork",
        execution_timeout_s=10.0,
    )
    try:
        src = torch.full((1, 128), 32.0, dtype=torch.float32)
        out = torch.zeros_like(src)
        out_sim = OpExec(reinterpret_int_add_autosync_kernel, simulator=True)(src, out, -1)

        expected_bits = src.contiguous().view(torch.int32) + (-0x00800000)
        expected = expected_bits.view(torch.float32)
        torch.testing.assert_close(out_sim, expected, rtol=1e-4, atol=1e-4)
    finally:
        if saved is None:
            delattr(reinterpret_int_add_autosync_kernel, "_simulator_config")
        else:
            reinterpret_int_add_autosync_kernel._simulator_config = saved
