"""Trace + simulator tests for the transdata5hd (vnchwconv) primitive."""
import pytest
import torch

from easyasc.a2 import *


def test_trace_fields_and_defaults():
    @kernel()
    def _t(out: GMTensor, nb: Var):
        src = Tensor(DT.half, [16, 64], Position.UB)
        dst = Tensor(DT.half, [64, 16], Position.UB)
        transdata5hd(dst, src)
        return out

    _t(GMTensor(DT.half, [16, 64]), Var(1))
    insts = [i for i in _t.instructions if i.opname == "transdata5hd"]
    assert len(insts) == 1
    kw = insts[0].kwargs
    assert (kw["repeat"], kw["src_row_stride"], kw["dst_row_stride"]) == (4, 64, 16)
    assert (kw["src_rep_stride"], kw["dst_rep_stride"]) == (1, 16)


def test_trace_rejects():
    @kernel()
    def _t(out: GMTensor, nb: Var):
        src = Tensor(DT.half, [16, 64], Position.UB)
        dst = Tensor(DT.half, [64, 16], Position.UB)
        srcf = Tensor(DT.float, [16, 64], Position.UB)
        dstf = Tensor(DT.float, [64, 16], Position.UB)
        with pytest.raises(ValueError, match="b16"):
            transdata5hd(dstf, srcf)
        with pytest.raises(ValueError, match="repeat"):
            transdata5hd(dst, src, repeat=256)
        with pytest.raises(ValueError, match="multiple of 16"):
            transdata5hd(dst, src, repeat=1, src_row_stride=24)
        return out

    _t(GMTensor(DT.half, [16, 64]), Var(1))


@kernel()
def _t5_sim(x: GMTensor, y: GMTensor, nb: Var):
    src = Tensor(DT.half, [16, 32], Position.UB)
    dst = Tensor(DT.half, [32, 16], Position.UB)
    with auto_sync():
        src <<= x[:, :]
        transdata5hd(dst, src, repeat=2, src_row_stride=32)
        y[:, :] <<= dst
    return y


def test_sim_transpose_matches_torch():
    x = torch.arange(16 * 32, dtype=torch.float16).reshape(16, 32)
    y = torch.zeros((32, 16), dtype=torch.float16)
    got = OpExec(_t5_sim, simulator=True)(x, y, 1)
    assert torch.equal(got, x.t().contiguous())
