import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate_split


COLS = 128
# The compiler requires a non-returned input tensor in the kernel entry; the
# kernels below either write `dst` from a Var or hand `src` back, so `gate`
# is never read.
GATE = torch.zeros((1, 1), dtype=torch.float16)


@kernel()
def run_vec_get_set_ub(gate: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.half, [1, cols], Position.UB)
    seed = Var(3.75, DT.float)
    scalar = Var(0, DT.int)
    seed.SetValueTo(ub)
    scalar.GetValueFrom(ub)
    scalar.SetValueTo(ub)
    dst[0:1, :] <<= ub
    return dst


@kernel()
def run_vec_set_with_rshift(gate: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.half, [1, cols], Position.UB)
    seed = Var(3.75, DT.float)
    seed >>= ub
    dst[0:1, :] <<= ub
    return dst


@kernel()
def run_vec_get_from_gm(src: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.half, [1, cols], Position.UB)
    scalar = Var(0, DT.int)
    scalar.GetValueFrom(src)
    scalar.SetValueTo(ub)
    dst[0:1, :] <<= ub
    return dst


@kernel()
def run_vec_set_to_gm(gate: GMTensor, dst: GMTensor, contract: Var):
    scalar = Var(5, DT.int, name="scalar")
    with vec_scope():
        scalar.SetValueTo(dst)
    return dst


@kernel()
def run_cube_set_to_gm(gate: GMTensor, dst: GMTensor, contract: Var):
    scalar = Var(7.0, DT.float, name="scalar")
    with cube_scope():
        scalar.SetValueTo(dst)
    return dst


@kernel()
def run_cube_get_from_gm(gate: GMTensor, src: GMTensor, contract: Var):
    scalar = Var(0, DT.int)
    scalar.GetValueFrom(src)

    q = var_div(1, scalar, name="q")

    l1 = Tensor(DT.half, [16, 16], Position.L1)
    l0a = Tensor(DT.half, [16, 16], Position.L0A)
    for i in range(0, q, 1):
        l0a <<= l1
    return src


# ``GetValueFrom`` reads the buffer the kernel also returns, so the simulator
# has to seed it instead of poisoning it.
run_cube_get_from_gm._simulator_seed_outputs = True


@vf()
def micro_get_value_reject(src: Tensor):
    scalar = Var(0, DT.int)
    scalar.GetValueFrom(src)


@vf()
def micro_set_value_reject(src: Tensor):
    scalar = Var(1, DT.int)
    scalar.SetValueTo(src)


@kernel()
def run_vf_get_reject(src: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.half, [1, cols], Position.UB)
    ub <<= src[0:1, :]
    micro_get_value_reject(ub)
    dst[0:1, :] <<= ub
    return dst


@kernel()
def run_vf_set_reject(src: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.half, [1, cols], Position.UB)
    ub <<= src[0:1, :]
    micro_set_value_reject(ub)
    dst[0:1, :] <<= ub
    return dst


@kernel()
def run_vec_get_from_dbuf_view_codegen(dst: GMTensor, cols: Var):
    xbuf = DBuff(DT.float, [4, cols], Position.UB)
    outbuf = DBuff(DT.float, [4, cols], Position.UB)
    scalar = Var(0.0, DT.float)
    scalar.GetValueFrom(xbuf[0][1:, 3:])
    scalar.SetValueTo(outbuf[0][2:, 5:])
    dst[0:1, :] <<= outbuf[0][0:1, :]
    return dst


@kernel()
def run_var_literal_ilshift_codegen(dst: GMTensor):
    v = Var(0.0, DT.float, name="v")
    t = Var(0, DT.int, name="t")
    v <<= 1.0
    t <<= 2
    return dst


def test_sim_var_get_set_from_ub_roundtrip() -> None:
    dst = torch.zeros((1, COLS), dtype=torch.float16)

    op = OpExec(run_vec_get_set_ub, "test_sim_var_get_set_from_ub_roundtrip", simulator=True)
    out = op(GATE, dst, COLS)

    first = float(out[0, 0].item())
    diff = first - 3.0
    if diff < 0:
        diff = -diff
    if diff > 1e-3:
        raise AssertionError(f"unexpected first element after GetValueFrom/SetValueTo: got={first}, expected=3.0")


def test_sim_var_rshift_to_ub_roundtrip() -> None:
    dst = torch.zeros((1, COLS), dtype=torch.float16)

    op = OpExec(run_vec_set_with_rshift, "test_sim_var_rshift_to_ub_roundtrip", simulator=True)
    out = op(GATE, dst, COLS)

    first = float(out[0, 0].item())
    diff = first - 3.75
    if diff < 0:
        diff = -diff
    if diff > 1e-3:
        raise AssertionError(f"unexpected first element after Var >>= Tensor: got={first}, expected=3.75")


def test_sim_var_get_from_gm_on_vec() -> None:
    src = torch.zeros((1, COLS), dtype=torch.float16)
    src[0, 0] = -2.5
    dst = torch.zeros_like(src)

    op = OpExec(run_vec_get_from_gm, "test_sim_var_get_from_gm_on_vec", simulator=True)
    out = op(src, dst, COLS)

    first = float(out[0, 0].item())
    diff = first - (-2.0)
    if diff < 0:
        diff = -diff
    if diff > 1e-3:
        raise AssertionError(f"unexpected GM first element after vec SetValueTo: got={first}, expected=-2.0")


def test_sim_var_get_from_gm_on_cube_pass() -> None:
    src = torch.ones((1, COLS), dtype=torch.float16)

    op = OpExec(run_cube_get_from_gm, "test_sim_var_get_from_gm_on_cube_pass", simulator=True)
    out = op(GATE, src, -1)

    if not torch.equal(out, src):
        diff = torch.max(torch.abs(out - src)).item()
        raise AssertionError(f"cube GetValueFrom changed source unexpectedly, max_abs_diff={diff}")


def test_var_get_value_from_tensor_requires_ub() -> None:
    tensor_l1 = Tensor(DT.half, [1, COLS], Position.L1)
    scalar = Var(0, DT.int)
    with pytest.raises(ValueError, match="UB position"):
        scalar.GetValueFrom(tensor_l1)


def test_get_value_from_clears_constructor_value_hint() -> None:
    src = GMTensor(DT.int64, [1, 4], name="src_runtime_value")
    scalar = Var(0, DT.int64)

    scalar.GetValueFrom(src[0:1, 2:3])

    assert scalar.value is None


def test_var_set_value_to_requires_ub_tensor() -> None:
    tensor_l1 = Tensor(DT.half, [1, COLS], Position.L1)
    scalar = Var(1, DT.int)
    with pytest.raises(ValueError, match="UB Tensor"):
        scalar.SetValueTo(tensor_l1)


def test_sim_var_set_value_to_gm_tensor() -> None:
    dst = torch.zeros((1, COLS), dtype=torch.float16)

    op = OpExec(run_vec_set_to_gm, "test_sim_var_set_value_to_gm_tensor", simulator=True)
    out = op(GATE, dst, -1)

    first = float(out[0, 0].item())
    diff = first - 5.0
    if diff < 0:
        diff = -diff
    if diff > 1e-3:
        raise AssertionError(f"unexpected GM first element after SetValueTo: got={first}, expected=5.0")


def test_var_set_value_to_gm_codegen() -> None:
    dst = GMTensor(DT.float, [1, 1], name="dst")
    run_vec_set_to_gm(GMTensor(DT.float, [1, 1], name="gate"), dst, Var(-1))

    cube_code, vec_code = translate_split(
        run_vec_set_to_gm.instructions,
        "run_vec_set_to_gm",
    )

    if "dst.SetValue(0, (float)(scalar));" in cube_code:
        raise AssertionError(f"vec-scoped SetValueTo leaked into cube code:\n{cube_code}")
    if "dst.SetValue(0, (float)(scalar));" not in vec_code:
        raise AssertionError(f"unexpected GMTensor SetValueTo codegen:\n{vec_code}")


def test_sim_var_set_value_to_gm_tensor_on_cube() -> None:
    dst = torch.zeros((1, COLS), dtype=torch.float32)

    op = OpExec(run_cube_set_to_gm, "test_sim_var_set_value_to_gm_tensor_on_cube", simulator=True)
    out = op(GATE, dst, -1)

    first = float(out[0, 0].item())
    diff = first - 7.0
    if diff < 0:
        diff = -diff
    if diff > 1e-6:
        raise AssertionError(f"unexpected GM first element after cube SetValueTo: got={first}, expected=7.0")


def test_var_set_value_to_gm_codegen_on_cube_scope() -> None:
    dst = GMTensor(DT.float, [1, 1], name="dst")
    run_cube_set_to_gm(GMTensor(DT.float, [1, 1], name="gate"), dst, Var(-1))

    cube_code, vec_code = translate_split(
        run_cube_set_to_gm.instructions,
        "run_cube_set_to_gm",
    )

    if "dst.SetValue(0, (float)(scalar));" not in cube_code:
        raise AssertionError(f"unexpected cube-scoped GMTensor SetValueTo codegen:\n{cube_code}")
    if "dst.SetValue(0, (float)(scalar));" in vec_code:
        raise AssertionError(f"cube-scoped SetValueTo leaked into vec code:\n{vec_code}")


def test_var_get_value_from_rejects_vf_context() -> None:
    src = torch.ones((1, COLS), dtype=torch.float16)
    dst = torch.zeros_like(src)
    op = OpExec(run_vf_get_reject, "test_var_get_value_from_rejects_vf_context", simulator=True)
    with pytest.raises(ValueError, match="vf context"):
        op(src, dst, COLS)


def test_var_set_value_to_rejects_vf_context() -> None:
    src = torch.ones((1, COLS), dtype=torch.float16)
    dst = torch.zeros_like(src)
    op = OpExec(run_vf_set_reject, "test_var_set_value_to_rejects_vf_context", simulator=True)
    with pytest.raises(ValueError, match="vf context"):
        op(src, dst, COLS)


def test_get_value_from_tensor_view_codegen_keeps_view_chain() -> None:
    cols = Var(COLS, DT.int, name="cols")
    dst = GMTensor(DT.float, [1, cols], name="dst")
    run_vec_get_from_dbuf_view_codegen(dst, cols)

    _, vec_code = translate_split(
        run_vec_get_from_dbuf_view_codegen.instructions,
        "run_vec_get_from_dbuf_view_codegen",
    )

    if (
        "float scalar = (float) xbuf.get(0)[cols + 3].GetValue(0);" not in vec_code
        and "float scalar = (float) xbuf.get(0)[1 * cols + 3].GetValue(0);" not in vec_code
    ):
        raise AssertionError(f"unexpected GetValueFrom codegen:\n{vec_code}")
    if "float scalar = (float) _tmp_tensor_" in vec_code:
        raise AssertionError(f"GetValueFrom kept an unresolved temporary tensor:\n{vec_code}")
