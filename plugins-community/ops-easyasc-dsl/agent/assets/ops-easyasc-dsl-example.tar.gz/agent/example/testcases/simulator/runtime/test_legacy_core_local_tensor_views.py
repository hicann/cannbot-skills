from easyasc.simulator.core import _plan_local_tensor_specs
from easyasc.simulator.program import ControlInstruction, KernelProgram, LaneProgram


def test_plan_local_tensor_specs_preserves_vec1_view_metadata() -> None:
    program = KernelProgram(
        name="legacy_core_local_tensor_views",
        core_count=1,
        lane_programs=[
            LaneProgram(lane_name="cube", pipe_names=["MTE2", "MTE1", "M", "FIX"], instructions=[]),
            LaneProgram(
                lane_name="vec0",
                pipe_names=["MTE2", "V", "MTE3"],
                instructions=[ControlInstruction("slice_tensor", args={})],
            ),
            LaneProgram(
                lane_name="vec1",
                pipe_names=["MTE2", "V", "MTE3"],
                instructions=[ControlInstruction("slice_tensor", args={})],
            ),
        ],
        metadata={
            "tensor_specs": [
                {
                    "name": "delta_ub",
                    "shape": [8192],
                    "dtype": "float32",
                    "role": "ub",
                },
                {
                    "name": "_tmp_tensor_216",
                    "shape": [4096],
                    "dtype": "float32",
                    "role": "ub",
                    "source_name": "delta_ub",
                    "storage_offset": 0,
                    "view_shape": [64, 128],
                    "view_strides": [128, 1],
                },
            ],
        },
    )

    specs, lane_name_maps = _plan_local_tensor_specs(program)
    by_name = {spec.name: spec for spec in specs}

    assert lane_name_maps["vec1"]["delta_ub"] == "_vec1_delta_ub"
    assert lane_name_maps["vec1"]["_tmp_tensor_216"] == "_vec1__tmp_tensor_216"

    vec1_view = by_name["_vec1__tmp_tensor_216"]
    assert vec1_view.source_name == "_vec1_delta_ub"
    assert vec1_view.storage_offset == 0
    assert vec1_view.view_shape == (64, 128)
    assert vec1_view.view_strides == (128, 1)
