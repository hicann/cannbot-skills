import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate_split
from easyasc.utils.var import VarRef


@kernel()
def _varlist_auto_name_kernel(dst: GMTensor):
    vals = VarList(DT.float, 2)
    vals[0] <<= 3.0
    x = Var(0.0, DT.float)
    x <<= vals[0]
    x.SetValueTo(dst)
    return dst


@kernel()
def _varlist_codegen_kernel(src: GMTensor, dst: GMTensor, contract: Var):
    with cube_scope():
        vals = VarList(DT.float, 2, name="vals")
        x = Var(0.0, DT.float, name="x")
        vals[0] <<= 7.0
        x <<= vals[0]
        x.SetValueTo(dst)
    return dst


def test_varlist_getitem_returns_varref_without_create_var() -> None:
    vals = VarList(DT.int, 4, name="vals_ref")
    item = vals[0]

    assert isinstance(item, VarRef)
    assert isinstance(item, Var)
    assert item.name == "vals_ref[0]"
    assert item.parent is vals
    assert item.index == 0


def test_varlist_assignment_gets_auto_name_from_ast() -> None:
    dst = GMTensor(DT.float, [1, 1], name="dst")
    _varlist_auto_name_kernel(dst)

    create_varlist = [
        inst for inst in _varlist_auto_name_kernel.instructions if inst.opname == "create_varlist"
    ]
    assert len(create_varlist) == 1
    assert create_varlist[0].kwargs["varlist"].name == "vals"


def test_varlist_codegen_emits_cpp_array_and_element_assignments() -> None:
    src = GMTensor(DT.float, [1, 1], name="src")
    dst = GMTensor(DT.float, [1, 1], name="dst")
    _varlist_codegen_kernel(src, dst, Var(-1))

    create_var_insts = [
        inst for inst in _varlist_codegen_kernel.instructions
        if inst.opname == "create_var" and getattr(inst.kwargs.get("val"), "name", None) == "vals[0]"
    ]
    assert not create_var_insts

    cube_code, vec_code = translate_split(_varlist_codegen_kernel.instructions, "varlist_codegen")
    generated = cube_code + vec_code

    assert "float vals[2] = {};" in generated
    assert "vals[0] = (float) 7.0f;" in generated
    assert "x = (float) vals[0];" in generated


def test_varlist_simulator_reads_back_array_element() -> None:
    src = torch.zeros((1, 1), dtype=torch.float32)
    dst = torch.zeros((1, 1), dtype=torch.float32)

    out = OpExec(_varlist_codegen_kernel, out_dir="test_varlist_sim", simulator=True)(src, dst, -1)

    assert torch.allclose(out, torch.tensor([[7.0]], dtype=torch.float32))


@kernel()
def _varlist_dynamic_index_kernel(src: GMTensor, dst: GMTensor, contract: Var):
    with cube_scope():
        vals = VarList(DT.int, 4, name="vals")
        idx = Var(1, DT.int, name="idx")
        out = Var(0, DT.int, name="out")
        vals[idx] <<= 9
        with If(vals[idx] > 8):
            out <<= vals[idx]
        with Else():
            out <<= 0
        out.SetValueTo(dst)
    return dst


def test_varlist_dynamic_var_index_codegen_and_simulator() -> None:
    src = GMTensor(DT.int, [1, 1], name="src")
    dst = GMTensor(DT.int, [1, 1], name="dst")
    _varlist_dynamic_index_kernel(src, dst, Var(-1))

    cube_code, _ = translate_split(_varlist_dynamic_index_kernel.instructions, "varlist_dynamic_index")
    assert "vals[idx] = (int) 9;" in cube_code
    assert "if (vals[idx] > 8)" in cube_code
    assert "out = (int) vals[idx];" in cube_code

    out = OpExec(_varlist_dynamic_index_kernel, out_dir="test_varlist_dynamic_sim", simulator=True)(
        torch.zeros((1, 1), dtype=torch.int32), torch.zeros((1, 1), dtype=torch.int32), -1
    )
    assert torch.equal(out, torch.tensor([[9]], dtype=torch.int32))


@kernel()
def _varlist_prune_live_dependency_kernel(dst: GMTensor):
    with cube_scope():
        x = Var(2, DT.int, name="x")
        arr = VarList(DT.int, 4, name="arr")
        y = Var(0, DT.int, name="y")
        arr[x] <<= 3
        y <<= arr[1]
        y.SetValueTo(dst)
    return dst


@kernel()
def _varlist_prune_dead_dependency_kernel(dst: GMTensor):
    with cube_scope():
        x = Var(2, DT.int, name="x")
        arr = VarList(DT.int, 4, name="arr")
        arr[x] <<= 3
    return dst


def test_varlist_pruning_keeps_index_var_and_related_ops_when_array_is_live() -> None:
    dst = GMTensor(DT.int, [1, 1], name="dst")
    _varlist_prune_live_dependency_kernel(dst)

    cube_code, _ = translate_split(
        _varlist_prune_live_dependency_kernel.instructions,
        "varlist_prune_live_dependency",
    )

    assert "int x = 2;" in cube_code
    assert "int arr[4] = {};" in cube_code
    assert "int y = 0;" in cube_code
    assert "arr[x] = (int) 3;" in cube_code
    assert "y = (int) arr[1];" in cube_code


def test_varlist_pruning_drops_dead_array_and_index_var_together() -> None:
    dst = GMTensor(DT.int, [1, 1], name="dst")
    _varlist_prune_dead_dependency_kernel(dst)

    cube_code, _ = translate_split(
        _varlist_prune_dead_dependency_kernel.instructions,
        "varlist_prune_dead_dependency",
    )

    assert "int x = 2;" not in cube_code
    assert "int arr[4] = {};" not in cube_code
    assert "arr[x] = (int) 3;" not in cube_code


@kernel()
def _varlist_alias_index_kernel(src: GMTensor, dst: GMTensor, contract: Var):
    with cube_scope():
        vals = VarList(DT.int, 4, name="vals")
        i = Var(0, DT.int, name="i")
        out = Var(0, DT.int, name="out")
        vals[0] <<= 11
        out <<= vals[i]
        out.SetValueTo(dst)
    return dst


def test_varlist_simulator_aliases_literal_and_var_indices() -> None:
    """Write vals[0], read vals[i] with i==0 — must yield the written value."""
    src = torch.zeros((1, 1), dtype=torch.int32)
    dst = torch.zeros((1, 1), dtype=torch.int32)
    out = OpExec(_varlist_alias_index_kernel, out_dir="test_varlist_alias_sim", simulator=True)(src, dst, -1)
    assert torch.equal(out, torch.tensor([[11]], dtype=torch.int32))


@kernel()
def _varlist_index_arith_kernel(src: GMTensor, dst: GMTensor, contract: Var):
    with cube_scope():
        vals = VarList(DT.int, 4, name="vals_arith")
        i = Var(1, DT.int, name="i_arith")
        out = Var(0, DT.int, name="out_arith")
        vals[i + 1] <<= 22
        out <<= vals[2]
        out.SetValueTo(dst)
    return dst


def test_varlist_simulator_handles_index_arithmetic() -> None:
    """Write vals[i+1] with i==1, read vals[2] — must yield the written value."""
    src = torch.zeros((1, 1), dtype=torch.int32)
    dst = torch.zeros((1, 1), dtype=torch.int32)
    out = OpExec(_varlist_index_arith_kernel, out_dir="test_varlist_index_arith_sim", simulator=True)(src, dst, -1)
    assert torch.equal(out, torch.tensor([[22]], dtype=torch.int32))


@kernel()
def _varlist_uninitialized_read_kernel(src: GMTensor, dst: GMTensor, contract: Var):
    with cube_scope():
        vals = VarList(DT.int, 4, name="vals_uninit")
        out = Var(99, DT.int, name="out_uninit")
        out <<= vals[3]
        out.SetValueTo(dst)
    return dst


def test_varlist_simulator_zero_initializes_unwritten_slots() -> None:
    """Read from a never-written slot — must yield zero (matching codegen `arr[N] = {}`)."""
    src = torch.zeros((1, 1), dtype=torch.int32)
    dst = torch.zeros((1, 1), dtype=torch.int32)
    out = OpExec(_varlist_uninitialized_read_kernel, out_dir="test_varlist_uninit_sim", simulator=True)(src, dst, -1)
    assert torch.equal(out, torch.tensor([[0]], dtype=torch.int32))
