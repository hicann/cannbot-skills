import pytest
import torch

from easyasc.a2 import *
from easyasc.simulator import SimulatorConfig


M = 16
N = 64
K = 16


@kernel()
def _per_core_bt_bias(x: GMTensor, weight: GMTensor, bias: GMTensor, y: GMTensor, contract: Var):
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1w = Tensor(DT.half, [K, N], Position.L1)
    l1bias = Tensor(DT.float, [1, N], Position.L1, layout=Layout.ND)
    l0a = Tensor(DT.half, [M, K], Position.L0A)
    l0b = Tensor(DT.half, [K, N], Position.L0B)
    bt = Tensor(DT.float, [1, N], Position.BT)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    cube_idx = GetCubeIdx()
    row0 = Var(cube_idx * M)

    with auto_sync():
        l1x <<= x[:, :]
        l1w <<= weight[:, :]
        gm_to_l1(l1bias, bias[cube_idx:cube_idx + 1, :])
        l1_to_l0(l0a, l1x)
        l1_to_l0(l0b, l1w.T)
        l1_to_bt(bt, l1bias, n=N)

        # Drain each core's MTE1 write, then hold both cores here. If BT were
        # accidentally shared, both MMADs below would read the same last writer.
        allcube_ready(flag_id=0, pipe=Pipe.MTE1)
        allcube_wait(flag_id=0, pipe=Pipe.S)

        mmad(l0c, l0a, l0b, M=M, N=N, K=K, is_init=True, bias=bt)
        y[row0:row0 + M, :] <<= l0c
    return y


_per_core_bt_bias._simulator_config = SimulatorConfig(core_count=2, execution_timeout_s=10.0)


@pytest.mark.easyasc_device("b3")
def test_bt_storage_is_private_to_each_simulated_core() -> None:
    x = torch.zeros((M, K), dtype=torch.float16)
    weight = torch.zeros((K, N), dtype=torch.float16)
    bias = torch.stack([
        torch.linspace(0.25, 1.0, N, dtype=torch.float32),
        torch.linspace(-1.0, -0.25, N, dtype=torch.float32),
    ])
    y = torch.zeros((2 * M, N), dtype=torch.float32)

    got = OpExec(_per_core_bt_bias, simulator=True)(x, weight, bias, y, 0)
    expected = bias[:, None, :].expand(2, M, N).reshape(2 * M, N)

    torch.testing.assert_close(got, expected, rtol=0.0, atol=0.0)
