import torch

from easyasc.a5 import *


# The compiler requires a non-returned input tensor in the kernel entry;
# these kernels only hand `src` straight back, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.float16)


def _make_allcube_kernel(wait_pipe: PipeType, ready_pipe: PipeType, emit_ready: bool):
    wait_name = str(wait_pipe)
    ready_name = str(ready_pipe)
    emit_literal = "True" if emit_ready else "False"
    namespace = {}
    code = (
        "@kernel()\n"
        "def run_allcube(gate: GMTensor, src: GMTensor, contract: Var):\n"
        f"    if {emit_literal}:\n"
        f"        allcube_ready(flag_id=1, pipe=Pipe.{ready_name})\n"
        f"    allcube_wait(flag_id=1, pipe=Pipe.{wait_name})\n"
        "    return src\n"
    )
    exec(code, globals(), namespace)
    fn = namespace["run_allcube"]
    # A pass-through kernel: it hands its input buffer straight back
    # without writing it, so the simulator has to seed the buffer
    # instead of leaving the poison the caller would never see on
    # hardware.
    fn._simulator_seed_outputs = True
    return fn


def _make_allvec_kernel(wait_pipe: PipeType, ready_pipe: PipeType, emit_ready: bool):
    wait_name = str(wait_pipe)
    ready_name = str(ready_pipe)
    emit_literal = "True" if emit_ready else "False"
    namespace = {}
    code = (
        "@kernel()\n"
        "def run_allvec(gate: GMTensor, src: GMTensor, contract: Var):\n"
        f"    if {emit_literal}:\n"
        f"        allvec_ready(flag_id=2, pipe=Pipe.{ready_name})\n"
        f"    allvec_wait(flag_id=2, pipe=Pipe.{wait_name})\n"
        "    return src\n"
    )
    exec(code, globals(), namespace)
    fn = namespace["run_allvec"]
    fn._simulator_seed_outputs = True
    return fn


def test_sim_allcube_wait_main_loop_with_ready() -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    fn = _make_allcube_kernel(wait_pipe=Pipe.S, ready_pipe=Pipe.FIX, emit_ready=True)
    op = OpExec(fn, "test_sim_allcube_wait_main_loop_with_ready", simulator=True)
    out = op(GATE, src, -1)
    if not torch.equal(out, src):
        raise AssertionError("allcube_wait main-loop path changed tensor unexpectedly")


def test_sim_allcube_wait_pipe_queue_with_ready() -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    fn = _make_allcube_kernel(wait_pipe=Pipe.MTE2, ready_pipe=Pipe.FIX, emit_ready=True)
    op = OpExec(fn, "test_sim_allcube_wait_pipe_queue_with_ready", simulator=True)
    out = op(GATE, src, -1)
    if not torch.equal(out, src):
        raise AssertionError("allcube_wait pipe-queue path changed tensor unexpectedly")


def test_sim_allvec_wait_main_loop_with_ready() -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    fn = _make_allvec_kernel(wait_pipe=Pipe.S, ready_pipe=Pipe.MTE3, emit_ready=True)
    op = OpExec(fn, "test_sim_allvec_wait_main_loop_with_ready", simulator=True)
    out = op(GATE, src, -1)
    if not torch.equal(out, src):
        raise AssertionError("allvec_wait main-loop path changed tensor unexpectedly")


def test_sim_allvec_wait_pipe_queue_with_ready() -> None:
    src = torch.zeros((1, 16), dtype=torch.float16)
    fn = _make_allvec_kernel(wait_pipe=Pipe.MTE2, ready_pipe=Pipe.MTE3, emit_ready=True)
    op = OpExec(fn, "test_sim_allvec_wait_pipe_queue_with_ready", simulator=True)
    out = op(GATE, src, -1)
    if not torch.equal(out, src):
        raise AssertionError("allvec_wait pipe-queue path changed tensor unexpectedly")
