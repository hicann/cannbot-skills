"""Simulator regression for move_mask_spr (MicroAPI::MoveMask<T>()).

Board-verified 2026-07-21 (kernels/a5/vec_only/movemask_probe.py, codegen SetVectorMask<half> +
MoveMask<int>): MoveMask reads the vector-mask SPR into a T-typed MaskReg with a LANE-GRANULAR
direct-index mapping -- MaskReg lane i takes SPR lane i (the bit SetVectorMask/set_mask set for
lane i, or the first `count` lanes for set_mask_by_count). VL follows the MaskReg dtype
(b32 -> 64 lanes read from SPR[0:64], b16 -> 128 from SPR[0:128]).
"""
import pytest
import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime, _VL_BYTES
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg

_STORE = SharedMemoryStore()


def _dispatch_with_spr(dst, spr_mask):
    rt = MicroRuntime()
    ctx = MicroContext(spr_mask=spr_mask.clone())
    rt._stack.append(ctx)
    try:
        rt._dispatch("micro_movemaskspr", {"dst": dst}, _STORE)
    finally:
        rt._stack.pop()
    return ctx


@pytest.mark.parametrize("dt,vl", [(DT.int, 64), (DT.int16, 128), (DT.int64, 32)])
def test_move_mask_is_lane_granular_direct_index(dt, vl):
    spr = torch.zeros(_VL_BYTES, dtype=torch.uint8)
    active = [i for i in (0, 1, 3, 4, 20, 31, 63, 96, 127) if i < vl]
    spr[active] = 1
    m = MaskReg(dt, init_mode=MaskType.NONE, name="m")
    ctx = _dispatch_with_spr(m, spr)
    want = torch.zeros(vl, dtype=torch.bool)
    want[active] = True
    assert torch.equal(ctx.masks["m"], want)


def test_move_mask_reads_only_dst_vl_lanes():
    # A b32 read (VL=64) must ignore SPR lanes >= 64 even when they are set.
    spr = torch.zeros(_VL_BYTES, dtype=torch.uint8)
    spr[70] = spr[200] = 1  # only high lanes set
    spr[5] = 1
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    ctx = _dispatch_with_spr(m, spr)
    want = torch.zeros(64, dtype=torch.bool)
    want[5] = True
    assert torch.equal(ctx.masks["m"], want)


def test_move_mask_without_spr_snapshot_raises():
    rt = MicroRuntime()
    rt._stack.append(MicroContext())  # spr_mask is None
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    try:
        with pytest.raises(RuntimeError, match="no vector-mask SPR snapshot"):
            rt._dispatch("micro_movemaskspr", {"dst": m}, _STORE)
    finally:
        rt._stack.pop()
