import contextlib

from easyasc import globvars


TILES = 2
WIDTH = 16
NESTED_WIDTH = 64
OUTER_TILES = 2
INNER_TILES = 3
SAME_STREAM_INNER_REPEATS = 3


@contextlib.contextmanager
def device_type(device_type: str):
    saved_device_type = globvars.device_type
    globvars.device_type = device_type
    try:
        yield
    finally:
        globvars.device_type = saved_device_type
