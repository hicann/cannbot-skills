import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.parser.asc import translate_split


def _with_device(device_type: str):
    saved = globvars.device_type
    globvars.device_type = device_type
    return saved


def _find_inst(kernel_fn):
    insts = [inst for inst in kernel_fn.instructions if inst.opname == "gm_to_ub_nd_dma"]
    assert len(insts) == 1
    return insts[0]


def test_stub_gm_to_ub_nd_dma_rejects_dtype_mismatch() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [4, 16], Position.UB)
            gm_to_ub_nd_dma(dst, inp, [1, 8], [1, 16], [8, 2])
            return inp

        inp = GMTensor(DT.half, [2, 8])
        with pytest.raises(ValueError, match="dst/src data types must match"):
            stub_only(inp)
    finally:
        globvars.device_type = saved


def test_stub_gm_to_ub_nd_dma_rejects_b_device() -> None:
    saved = _with_device("b3")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [4, 16], Position.UB)
            gm_to_ub_nd_dma(dst, inp, [1, 8], [1, 16], [8, 2])
            return inp

        inp = GMTensor(DT.float, [2, 8])
        with pytest.raises(Exception):
            stub_only(inp)
    finally:
        globvars.device_type = saved


def test_stub_gm_to_ub_nd_dma_rejects_length_mismatch() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [4, 16], Position.UB)
            gm_to_ub_nd_dma(dst, inp, [1, 8], [1], [8, 2])
            return inp

        inp = GMTensor(DT.float, [2, 8])
        with pytest.raises(ValueError, match="loop_dst_stride must have length 2"):
            stub_only(inp)
    finally:
        globvars.device_type = saved


def test_stub_gm_to_ub_nd_dma_defaults_and_config_are_captured() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [4, 16], Position.UB)
            gm_to_ub_nd_dma(
                dst,
                inp,
                [1, 8],
                [1, 16],
                [8, 2],
                loop_left_pad=[3, 1],
                loop_right_pad=[5, 1],
                constant_value=0.0,
                nearest_value_mode=True,
                config_left_pad=2,
                config_right_pad=4,
            )
            return inp

        inp = GMTensor(DT.float, [2, 8])
        stub_only(inp)
        inst = _find_inst(stub_only)
        assert inst.kwargs["dim"] == 2
        assert inst.kwargs["loop_src_stride"] == (1, 8)
        assert inst.kwargs["loop_dst_stride"] == (1, 16)
        assert inst.kwargs["loop_size"] == (8, 2)
        assert inst.kwargs["loop_left_pad"] == (3, 1)
        assert inst.kwargs["loop_right_pad"] == (5, 1)
        assert inst.kwargs["nearest_value_mode"] is True
        assert inst.kwargs["config_left_pad"] == 2
        assert inst.kwargs["config_right_pad"] == 4
    finally:
        globvars.device_type = saved


def test_stub_gm_to_ub_nd_dma_rejects_asc_optimize() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [4, 16], Position.UB)
            gm_to_ub_nd_dma(dst, inp, [1, 8], [1, 16], [8, 2], asc_optimize=True)
            return inp

        inp = GMTensor(DT.float, [2, 8])
        with pytest.raises(NotImplementedError, match="asc_optimize=True"):
            stub_only(inp)
    finally:
        globvars.device_type = saved


def test_codegen_gm_to_ub_nd_dma_emits_vec_helper_only() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [4, 16], Position.UB)
            gm_to_ub_nd_dma(
                dst,
                inp,
                [1, 8],
                [1, 16],
                [8, 2],
                loop_left_pad=[3, 1],
                loop_right_pad=[5, 1],
            )
            return inp

        inp = GMTensor(DT.float, [2, 8])
        stub_only(inp)
        cube_code, vec_code = translate_split(stub_only.instructions, "gm_to_ub_nd_dma_950")
        assert "GM2UB_ND_DMA<float, 2," in vec_code
        assert "NdDmaLoopInfo<2>" in vec_code
        assert "GM2UB_ND_DMA<float, 2," not in cube_code
    finally:
        globvars.device_type = saved


def test_sugar_gm_transpose_to_ub_dispatches_to_nd_dma_full_window() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [96, 32], Position.UB)
            dst <<= inp.T
            return inp

        inp = GMTensor(DT.float, [32, 96])
        stub_only(inp)
        inst = _find_inst(stub_only)
        assert inst.kwargs["loop_src_stride"] == (96, 1)
        assert inst.kwargs["loop_dst_stride"] == (1, 32)
        assert inst.kwargs["loop_size"] == (32, 96)
        assert inst.kwargs["loop_left_pad"] == (0, 0)
        assert inst.kwargs["loop_right_pad"] == (0, 0)
    finally:
        globvars.device_type = saved


def test_sugar_gm_transpose_to_ub_dispatches_to_nd_dma_slice() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [64, 64], Position.UB)
            dst[4:52, 3:27] <<= inp[0:24, 0:48].T
            return inp

        inp = GMTensor(DT.float, [32, 96])
        stub_only(inp)
        inst = _find_inst(stub_only)
        assert inst.kwargs["loop_src_stride"] == (96, 1)
        assert inst.kwargs["loop_dst_stride"] == (1, 64)
        assert inst.kwargs["loop_size"] == (24, 48)
    finally:
        globvars.device_type = saved


def test_sugar_gm_transpose_to_ub_infers_single_row_slice() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [48, 8], Position.UB)
            dst <<= inp[0, 0:48].T
            return inp

        inp = GMTensor(DT.float, [32, 96])
        stub_only(inp)
        inst = _find_inst(stub_only)
        assert inst.kwargs["loop_src_stride"] == (96, 1)
        assert inst.kwargs["loop_dst_stride"] == (1, 8)
        assert inst.kwargs["loop_size"] == (1, 48)
    finally:
        globvars.device_type = saved


def test_sugar_gm_transpose_to_ub_rejects_nz_layout_destination() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [96, 32], Position.UB, layout=Layout.NZ)
            dst <<= inp.T
            return inp

        inp = GMTensor(DT.float, [32, 96])
        with pytest.raises(ValueError, match="ND-layout UB"):
            stub_only(inp)
    finally:
        globvars.device_type = saved
