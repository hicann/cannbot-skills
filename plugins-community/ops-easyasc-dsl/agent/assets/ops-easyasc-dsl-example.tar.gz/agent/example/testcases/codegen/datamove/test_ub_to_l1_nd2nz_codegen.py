import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.parser.asc import translate_split


def _to_int(value: object) -> int:
    if isinstance(value, Var):
        if not isinstance(value.value, (int, float, bool)):
            raise TypeError(f"Var value must be numeric, got: {type(value.value)}")
        return int(value.value)
    if isinstance(value, bool):
        return int(value)
    if not isinstance(value, (int, float)):
        raise TypeError(f"value must be numeric, got: {type(value)}")
    return int(value)


def test_stub_ub_to_l1_nd2nz_default_inference_uses_dst_shape_for_m_dst() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.half, [32, 32], Position.L1)
            src = Tensor(DT.half, [32, 32], Position.UB)
            ub_to_l1_nd2nz(dst[4:20, 3:15], src[1:17, 2:14])
            return inp

        inp = GMTensor(DT.half, [1, 1])
        stub_only(inp)
        found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_l1_nd2nz"]
        assert len(found) == 1
        inst = found[0]
        assert _to_int(inst.kwargs["m_dst"]) == 32
        assert _to_int(inst.kwargs["n_dst"]) == 12
        assert _to_int(inst.kwargs["m_src"]) == 16
        assert _to_int(inst.kwargs["n_src"]) == 12
        # N_src defaults to src.shape[1], not the slice span.
        assert _to_int(inst.kwargs["N_src"]) == 32
    finally:
        globvars.device_type = saved_device_type


def test_stub_ub_to_l1_nd2nz_explicit_N_src_overrides_default() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.half, [32, 32], Position.L1)
            src = Tensor(DT.half, [32, 32], Position.UB)
            ub_to_l1_nd2nz(dst, src, m_dst=32, n_dst=12, m_src=16, n_src=12, N_src=24)
            return inp

        inp = GMTensor(DT.half, [1, 1])
        stub_only(inp)
        found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_l1_nd2nz"]
        assert len(found) == 1
        inst = found[0]
        assert _to_int(inst.kwargs["n_src"]) == 12
        assert _to_int(inst.kwargs["N_src"]) == 24
    finally:
        globvars.device_type = saved_device_type


def test_stub_ub_to_l1_nz_default_inference_uses_dst_shape_for_m_dst() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.half, [32, 32], Position.L1)
            src = Tensor(DT.half, [32, 32], Position.UB)
            ub_to_l1_nz(dst[4:20, 3:15], src[1:17, 2:14])
            return inp

        inp = GMTensor(DT.half, [1, 1])
        stub_only(inp)
        found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_l1_nz"]
        assert len(found) == 1
        inst = found[0]
        assert _to_int(inst.kwargs["m_dst"]) == 32
        assert _to_int(inst.kwargs["n_dst"]) == 12
        assert _to_int(inst.kwargs["m_src"]) == 16
        assert _to_int(inst.kwargs["n_src"]) == 12
    finally:
        globvars.device_type = saved_device_type


def test_codegen_ub_to_l1_nd2nz_emits_vec_side_call() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.half, [16, 16], Position.L1)
            src = Tensor(DT.half, [16, 16], Position.UB)
            ub_to_l1_nd2nz(dst, src, m_dst=16, n_dst=16, m_src=16, n_src=16)
            return inp

        inp = GMTensor(DT.half, [1, 1])
        stub_only(inp)
        cube_code, vec_code = translate_split(stub_only.instructions, "stub_only")
        assert "UB2L1_ND2NZ(" not in cube_code
        assert "UB2L1_ND2NZ(" in vec_code
        # The macro signature is (dst, src, m_dst, n_dst, m_src, n_src, N_src).
        # n_src and N_src both equal src.shape[1] = 16 here.
        assert ", 16, 16, 16, 16, 16);" in vec_code
    finally:
        globvars.device_type = saved_device_type


def test_codegen_ub_to_l1_nd2nz_explicit_N_src_appears_as_seventh_arg() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.half, [16, 16], Position.L1)
            src = Tensor(DT.half, [16, 32], Position.UB)
            ub_to_l1_nd2nz(dst, src, m_dst=16, n_dst=16, m_src=16, n_src=16, N_src=32)
            return inp

        inp = GMTensor(DT.half, [1, 1])
        stub_only(inp)
        _, vec_code = translate_split(stub_only.instructions, "stub_only_Nsrc")
        # N_src=32 is the row stride of src (src.shape[1]) while n_src=16 is
        # the column span being moved.
        assert ", 16, 16, 16, 16, 32);" in vec_code
    finally:
        globvars.device_type = saved_device_type


def test_tensor_nz_lshift_routes_to_ub_to_l1_nz_and_codegen() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.half, [32, 32], Position.L1)
            src = Tensor(DT.half, [32, 32], Position.UB)
            dst <<= src.nz()
            return inp

        inp = GMTensor(DT.half, [1, 1])
        stub_only(inp)
        found_nz = [inst for inst in stub_only.instructions if inst.opname == "ub_to_l1_nz"]
        found_nd2nz = [inst for inst in stub_only.instructions if inst.opname == "ub_to_l1_nd2nz"]
        assert len(found_nz) == 1
        assert len(found_nd2nz) == 0
        inst = found_nz[0]
        assert _to_int(inst.kwargs["m_dst"]) == 32
        assert _to_int(inst.kwargs["n_dst"]) == 32
        assert _to_int(inst.kwargs["m_src"]) == 32
        assert _to_int(inst.kwargs["n_src"]) == 32

        cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_nz")
        assert "UB2L1_NZ(" not in cube_code
        assert "UB2L1_NZ(" in vec_code
        assert "UB2L1_ND2NZ(" not in vec_code
    finally:
        globvars.device_type = saved_device_type


def test_tensor_ilshift_ub_to_l1_slice_infers_same_nd2nz_defaults() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.half, [32, 32], Position.L1)
            src = Tensor(DT.half, [32, 32], Position.UB)
            dst[4:20, 3:15] <<= src[1:17, 2:14]
            return inp

        inp = GMTensor(DT.half, [1, 1])
        stub_only(inp)
        found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_l1_nd2nz"]
        assert len(found) == 1
        inst = found[0]
        assert _to_int(inst.kwargs["m_dst"]) == 32
        assert _to_int(inst.kwargs["n_dst"]) == 12
        assert _to_int(inst.kwargs["m_src"]) == 16
        assert _to_int(inst.kwargs["n_src"]) == 12

        cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_lshift_slice")
        assert "UB2L1_ND2NZ(" not in cube_code
        assert "UB2L1_ND2NZ(" in vec_code
    finally:
        globvars.device_type = saved_device_type


def test_tensor_ilshift_ub_to_ub_routes_and_codegen() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.half, [16, 32], Position.UB)
        src = Tensor(DT.half, [16, 32], Position.UB)
        dst <<= src
        return inp

    inp = GMTensor(DT.half, [1, 1])
    stub_only(inp)
    found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_ub"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 16
    assert _to_int(inst.kwargs["burst_len"]) == 2
    assert _to_int(inst.kwargs["src_stride"]) == 0
    assert _to_int(inst.kwargs["dst_stride"]) == 0

    cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_ub_to_ub")
    assert "UB2UB(" not in cube_code
    assert "UB2UB(" in vec_code


def test_codegen_ub_to_l1_emits_vec_side_raw_copy_32b_units() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [8, 64], Position.L1)
            src = Tensor(DT.float, [8, 64], Position.UB)
            ub_to_l1(dst, src, n_burst=2, burst_len=3, src_stride=4, dst_stride=5)
            return inp

        inp = GMTensor(DT.float, [1, 1])
        stub_only(inp)
        found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_l1"]
        assert len(found) == 1
        inst = found[0]
        assert _to_int(inst.kwargs["n_burst"]) == 2
        assert _to_int(inst.kwargs["burst_len"]) == 3
        assert _to_int(inst.kwargs["src_stride"]) == 4
        assert _to_int(inst.kwargs["dst_stride"]) == 5

        cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_ub_to_l1")
        assert "UB2L1(" not in cube_code
        assert "UB2L1(dst, src, 2, 3, 4, 5);" in vec_code
    finally:
        globvars.device_type = saved_device_type


def test_stub_ub_to_l1_default_inference_uses_32b_units() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [4, 24], Position.L1)
            src = Tensor(DT.float, [4, 24], Position.UB)
            ub_to_l1(dst[0:4, 0:16], src[0:4, 8:24])
            return inp

        inp = GMTensor(DT.float, [1, 1])
        stub_only(inp)
        found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_l1"]
        assert len(found) == 1
        inst = found[0]
        assert _to_int(inst.kwargs["n_burst"]) == 4
        # float C0 is 8 elements, so 16 copied elements are two 32B blocks.
        assert _to_int(inst.kwargs["burst_len"]) == 2
        assert _to_int(inst.kwargs["src_stride"]) == 1
        assert _to_int(inst.kwargs["dst_stride"]) == 1
    finally:
        globvars.device_type = saved_device_type


def test_stub_ub_to_gm_pad_multidim_slice_infers_burst_and_stride() -> None:
    @kernel()
    def stub_only(out: GMTensor):
        src = Tensor(DT.float, [8, 512], Position.UB)
        out[0, 6:8, :] <<= src
        return out

    out = GMTensor(DT.float, [1, 64, 512])
    stub_only(out)
    found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_gm_pad"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 2
    assert _to_int(inst.kwargs["burst_len_byte"]) == 2048
    assert _to_int(inst.kwargs["src_stride"]) == 0
    assert _to_int(inst.kwargs["dst_stride_byte"]) == 0

    cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_ub_to_gm_pad_rank3")
    assert "UB2GMPAD(" not in cube_code
    assert "UB2GMPAD(" in vec_code
    assert ", 2, 2048, 0, 0);" in vec_code


def test_stub_gm_to_ub_pad_multidim_slice_infers_burst_and_stride() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [2, 512], Position.UB)
        dst <<= inp[0, 6:8, :]
        return inp

    inp = GMTensor(DT.float, [1, 64, 512])
    stub_only(inp)
    found = [inst for inst in stub_only.instructions if inst.opname == "gm_to_ub_pad"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 2
    assert _to_int(inst.kwargs["burst_len_byte"]) == 2048
    assert _to_int(inst.kwargs["src_stride_byte"]) == 0
    assert _to_int(inst.kwargs["dst_stride"]) == 0

    cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_gm_to_ub_pad_rank3")
    assert "GM2UBPAD(" not in cube_code
    assert "GM2UBPAD(" in vec_code
    assert ", 2, 2048, 0, 0);" in vec_code


def test_stub_gm_to_ub_pad_rejects_dtype_mismatch() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [2, 32], Position.UB)
        gm_to_ub_pad(dst, inp[0:2, 0:16])
        return inp

    inp = GMTensor(DT.half, [2, 16])
    with pytest.raises(ValueError, match="dst/src data types must match"):
        stub_only(inp)


def test_stub_ub_to_gm_pad_rejects_dtype_mismatch() -> None:
    @kernel()
    def stub_only(out: GMTensor):
        src = Tensor(DT.half, [2, 32], Position.UB)
        ub_to_gm_pad(out[0:2, 0:16], src)
        return out

    out = GMTensor(DT.float, [2, 16])
    with pytest.raises(ValueError, match="dst/src data types must match"):
        stub_only(out)


def test_stub_ub_to_gm_pad_explicit_parameters_skip_multidim_inference() -> None:
    @kernel()
    def stub_only(out: GMTensor):
        src = Tensor(DT.float, [2, 32], Position.UB)
        ub_to_gm_pad(out[0:2, 1:3, 4], src, 2, 3, 0, 13)
        return out

    out = GMTensor(DT.float, [2, 8, 16])
    stub_only(out)
    found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_gm_pad"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 2
    assert _to_int(inst.kwargs["burst_len_byte"]) == 12
    assert _to_int(inst.kwargs["src_stride"]) == 0
    assert _to_int(inst.kwargs["dst_stride_byte"]) == 52


def test_stub_gm_to_ub_pad_explicit_parameters_skip_multidim_inference() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [2, 32], Position.UB)
        gm_to_ub_pad(dst, inp[0:2, 1:3, 4], 2, 3, 13, 0)
        return inp

    inp = GMTensor(DT.float, [2, 8, 16])
    stub_only(inp)
    found = [inst for inst in stub_only.instructions if inst.opname == "gm_to_ub_pad"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 2
    assert _to_int(inst.kwargs["burst_len_byte"]) == 12
    assert _to_int(inst.kwargs["src_stride_byte"]) == 52
    assert _to_int(inst.kwargs["dst_stride"]) == 0


def test_stub_gm_to_ub_pad_rank1_infers_single_burst_zero_stride() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [2, 32], Position.UB)
        dst <<= inp
        return inp

    inp = GMTensor(DT.float, [16])
    stub_only(inp)
    found = [inst for inst in stub_only.instructions if inst.opname == "gm_to_ub_pad"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 1
    assert _to_int(inst.kwargs["burst_len_byte"]) == 64
    assert _to_int(inst.kwargs["src_stride_byte"]) == 0
    assert _to_int(inst.kwargs["dst_stride"]) == 0


def test_stub_ub_to_gm_pad_rank1_infers_single_burst_zero_stride() -> None:
    @kernel()
    def stub_only(out: GMTensor):
        src = Tensor(DT.float, [2, 32], Position.UB)
        out <<= src
        return out

    out = GMTensor(DT.float, [16])
    stub_only(out)
    found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_gm_pad"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 1
    assert _to_int(inst.kwargs["burst_len_byte"]) == 64
    assert _to_int(inst.kwargs["src_stride"]) == 0
    assert _to_int(inst.kwargs["dst_stride_byte"]) == 0


def test_stub_gm_to_ub_pad_rank1_explicit_parameters_are_used_as_is() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [2, 32], Position.UB)
        gm_to_ub_pad(dst, inp, 3, 4, 5, 6)
        return inp

    inp = GMTensor(DT.float, [16])
    stub_only(inp)
    found = [inst for inst in stub_only.instructions if inst.opname == "gm_to_ub_pad"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 3
    assert _to_int(inst.kwargs["burst_len_byte"]) == 16
    assert _to_int(inst.kwargs["src_stride_byte"]) == 20
    assert _to_int(inst.kwargs["dst_stride"]) == 6


def test_stub_ub_to_gm_pad_rank1_explicit_parameters_are_used_as_is() -> None:
    @kernel()
    def stub_only(out: GMTensor):
        src = Tensor(DT.float, [2, 32], Position.UB)
        ub_to_gm_pad(out, src, 3, 4, 5, 6)
        return out

    out = GMTensor(DT.float, [16])
    stub_only(out)
    found = [inst for inst in stub_only.instructions if inst.opname == "ub_to_gm_pad"]
    assert len(found) == 1
    inst = found[0]
    assert _to_int(inst.kwargs["n_burst"]) == 3
    assert _to_int(inst.kwargs["burst_len_byte"]) == 16
    assert _to_int(inst.kwargs["src_stride"]) == 5
    assert _to_int(inst.kwargs["dst_stride_byte"]) == 24


def test_ub_to_l1_helpers_accept_950pr_device() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950pr"
    try:
        dst = Tensor(DT.half, [8, 16], Position.L1)
        src = Tensor(DT.half, [8, 16], Position.UB)
        ub_to_l1(dst, src)
        ub_to_l1_nd2nz(dst, src, 8, 16, 8, 16)
        ub_to_l1_nz(dst, src, 8, 16, 8, 16)
    finally:
        globvars.device_type = saved_device_type


@pytest.mark.parametrize("use_operator", [False, True], ids=["explicit_stub", "operator"])
def test_ub_to_l1_rejects_non_a5_device(use_operator) -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "b3"
    try:
        dst = Tensor(DT.half, [8, 16], Position.L1)
        src = Tensor(DT.half, [8, 16], Position.UB)
        with pytest.raises(ValueError, match="valid device_type values: \\['950', '950pr'\\]"):
            if use_operator:
                dst <<= src
            else:
                ub_to_l1_nz(dst, src)
    finally:
        globvars.device_type = saved_device_type


def test_raw_ub_to_l1_rejects_non_a5_device() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "b3"
    try:
        dst = Tensor(DT.half, [8, 16], Position.L1)
        src = Tensor(DT.half, [8, 16], Position.UB)
        with pytest.raises(ValueError, match="valid device_type values: \\['950', '950pr'\\]"):
            ub_to_l1(dst, src)
    finally:
        globvars.device_type = saved_device_type
