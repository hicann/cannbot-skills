from types import SimpleNamespace
import warnings

import torch

from easyasc.simulator.memory import SharedMemoryStore, SharedTensorSpec
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime


def _register_all(store, specs):
    for spec in specs:
        store.register(spec)


def test_local_ub_tensors_share_their_lane_bank_backing_storage() -> None:
    store = SharedMemoryStore()
    specs = [
        SharedTensorSpec(
            name="score",
            shape=(4,),
            dtype="uint8",
            role="ub",
            storage_bank="UB",
            storage_offset_bytes=0,
            storage_size_bytes=4,
        ),
        SharedTensorSpec(
            name="decay",
            shape=(4,),
            dtype="uint8",
            role="ub",
            storage_bank="UB",
            storage_offset_bytes=4,
            storage_size_bytes=4,
        ),
    ]
    try:
        _register_all(store, specs)
        score = store.allocate("score")
        decay = store.allocate("decay")

        assert score.untyped_storage().data_ptr() == decay.untyped_storage().data_ptr()
        raw = score.as_strided((8,), (1,), storage_offset=0)
        raw[4:8].copy_(torch.tensor([3, 4, 5, 6], dtype=torch.uint8))

        assert torch.equal(decay, torch.tensor([3, 4, 5, 6], dtype=torch.uint8))
    finally:
        store.clear()


def test_ub0_and_ub1_are_distinct_backing_banks() -> None:
    store = SharedMemoryStore()
    specs = [
        SharedTensorSpec(
            name="lane0",
            shape=(4,),
            dtype="uint8",
            role="ub",
            storage_bank="UB",
            storage_offset_bytes=0,
            storage_size_bytes=4,
        ),
        SharedTensorSpec(
            name="_vec1_lane0",
            shape=(4,),
            dtype="uint8",
            role="ub",
            storage_bank="UB",
            storage_offset_bytes=0,
            storage_size_bytes=4,
        ),
    ]
    try:
        _register_all(store, specs)
        lane0 = store.allocate("lane0")
        lane1 = store.allocate("_vec1_lane0")

        assert lane0.untyped_storage().data_ptr() != lane1.untyped_storage().data_ptr()
        lane0.zero_()
        assert torch.equal(lane1, torch.full_like(lane1, 0xFF))
    finally:
        store.clear()


def test_different_local_memory_kinds_use_distinct_backing_banks() -> None:
    store = SharedMemoryStore()
    specs = [
        SharedTensorSpec(
            name="ub_tensor",
            shape=(4,),
            dtype="uint8",
            role="ub",
            storage_bank="UB",
            storage_offset_bytes=0,
            storage_size_bytes=4,
        ),
        SharedTensorSpec(
            name="l1_tensor",
            shape=(4,),
            dtype="uint8",
            role="l1",
            storage_bank="L1",
            storage_offset_bytes=0,
            storage_size_bytes=4,
        ),
    ]
    try:
        _register_all(store, specs)
        ub_tensor = store.allocate("ub_tensor")
        l1_tensor = store.allocate("l1_tensor")

        assert ub_tensor.untyped_storage().data_ptr() != l1_tensor.untyped_storage().data_ptr()
        ub_tensor.zero_()
        assert torch.equal(l1_tensor, torch.full_like(l1_tensor, 0xFF))
    finally:
        store.clear()


def test_micro_reg2ub_warns_when_touching_adjacent_ub_allocation_in_same_bank() -> None:
    store = SharedMemoryStore()
    specs = [
        SharedTensorSpec(
            name="score",
            shape=(64,),
            dtype="bfloat16",
            role="ub",
            storage_bank="UB",
            storage_offset_bytes=0,
            storage_size_bytes=128,
        ),
        SharedTensorSpec(
            name="decay",
            shape=(64,),
            dtype="bfloat16",
            role="ub",
            storage_bank="UB",
            storage_offset_bytes=128,
            storage_size_bytes=128,
        ),
    ]
    try:
        _register_all(store, specs)
        score = store.allocate("score")
        decay = store.allocate("decay")
        values = torch.arange(128, dtype=torch.float32).to(torch.bfloat16)

        runtime = MicroRuntime()
        ctx = MicroContext(
            regs={"src": values},
            masks={"mask": torch.ones(128, dtype=torch.bool)},
            tensor_views={"score": score},
            tensor_offsets_bytes={"score": 0},
        )
        runtime._stack.append(ctx)
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                runtime._dispatch(
                    "micro_reg2ub",
                    {
                        "dst": SimpleNamespace(name="score"),
                        "src": SimpleNamespace(name="src"),
                        "mask": SimpleNamespace(name="mask"),
                        "blk_stride": 1,
                    },
                    store,
                )
            assert any(
                "micro_reg2ub dst writes past UB tensor view: dst=score active_index=64 view_elements=64" in str(item.message)
                and "add an explicit mask" in str(item.message)
                and "padding buffer" in str(item.message)
                for item in caught
            )
        finally:
            runtime._stack.pop()

        torch.testing.assert_close(score, values[:64])
        torch.testing.assert_close(decay, values[64:128])
    finally:
        store.clear()
