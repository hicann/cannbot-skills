import pytest
import torch

from easyasc.a5 import *
from easyasc.simulator.pipe_cube import FixPipe
from easyasc.simulator.program import PipeTask


class _TensorStore(object):
    def __init__(self, tensors=None):
        self._tensors = dict(tensors or {})

    def tensor(self, name):
        return self._tensors[name]


def test_l0c_to_gm_rejects_static_m_src_beyond_declared_l0c_storage() -> None:
    @kernel()
    def stub(inp: GMTensor, out: GMTensor, one: Var):
        l0c = Tensor(DT.float, [16, 64], Position.L0C)
        l0c_to_gm_nz2nd(out, l0c, M=5, N=64, N_dst=64, M_src=256)
        return out

    inp = GMTensor(DT.float, [1, 1])
    out = GMTensor(DT.float, [5, 64])
    with pytest.raises(ValueError, match="L0C source footprint exceeds declared src tensor storage"):
        stub(inp, out, Var(1))


def test_l0c_to_l1_rejects_static_m_src_beyond_declared_l0c_storage() -> None:
    dst = Tensor(DT.float, [256, 64], Position.L1)
    src = Tensor(DT.float, [16, 64], Position.L0C)
    with pytest.raises(ValueError, match="L0C source footprint exceeds declared src tensor storage"):
        l0c_to_l1(dst, src, M=256, N=64, M_dst=256, M_src=256)


def test_l0c_to_ub_rejects_static_m_src_beyond_declared_l0c_storage() -> None:
    dst = Tensor(DT.float, [8, 64], Position.UB)
    src = Tensor(DT.float, [16, 64], Position.L0C)
    with pytest.raises(ValueError, match="L0C source footprint exceeds declared src tensor storage"):
        l0c_to_ub(dst, src, M=16, N=64, N_dst=64, M_src=256)


def test_fixpipe_rejects_runtime_l0c_source_footprint_overflow() -> None:
    pipe = object.__new__(FixPipe)
    pipe.memory_store = _TensorStore({
        "dst": torch.zeros((5, 64), dtype=torch.float32),
        "src": torch.zeros((16, 64), dtype=torch.float32),
    })

    with pytest.raises(RuntimeError, match="L0C source footprint exceeds tensor storage"):
        pipe.execute(
            PipeTask(
                "FIX",
                "l0c_to_gm_nz2nd",
                {"dst": "dst", "src": "src", "M": 5, "N": 64, "N_dst": 64, "M_src": 256},
            )
        )
