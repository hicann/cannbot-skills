import pytest
import torch

from easyasc import globvars
from easyasc.simulator.pipe_cube import CubeMTE1Pipe, CubeMTE2Pipe, FixPipe, MPipe
from easyasc.simulator.pipe_vec import MTE3Pipe, VecMTE2Pipe, VPipe
from easyasc.simulator.program import PipeTask


class _TensorStore(object):
    def __init__(self, tensors=None):
        self._tensors = dict(tensors or {})

    def tensor(self, name):
        return self._tensors[name]

    def contains(self, name):
        return name in self._tensors


def _pipe(pipe_cls, tensors):
    pipe = object.__new__(pipe_cls)
    pipe.memory_store = _TensorStore(tensors)
    if pipe_cls is VPipe:
        pipe.vector_mode = "repeat"
        pipe.count_register = 0
        pipe.current_mask = torch.ones(256, dtype=torch.uint8)
    return pipe


def _misaligned(dtype=torch.float32, n=256):
    return torch.zeros(n, dtype=dtype)[1:]


def test_gm_to_ub_requires_aligned_ub_dst() -> None:
    pipe = _pipe(VecMTE2Pipe, {"dst": _misaligned(), "src": torch.zeros(256)})
    with pytest.raises(RuntimeError, match="gm_to_ub_pad dst address"):
        pipe.execute(PipeTask("MTE2", "gm_to_ub_pad", {"dst": "dst", "src": "src", "n_burst": 1, "burst_len_byte": 32, "src_stride_byte": 0, "dst_stride": 0}))


def test_ub_to_gm_requires_aligned_ub_src() -> None:
    pipe = _pipe(MTE3Pipe, {"dst": torch.zeros(256), "src": _misaligned()})
    with pytest.raises(RuntimeError, match="ub_to_gm_pad src address"):
        pipe.execute(PipeTask("MTE3", "ub_to_gm_pad", {"dst": "dst", "src": "src", "n_burst": 1, "burst_len_byte": 32, "dst_stride_byte": 0, "src_stride": 0}))


def test_ub_to_l1_requires_aligned_src() -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        pipe = _pipe(MTE3Pipe, {"dst": torch.zeros(256), "src": _misaligned()})
        with pytest.raises(RuntimeError, match="ub_to_l1 src address"):
            pipe.execute(PipeTask("MTE3", "ub_to_l1", {"dst": "dst", "src": "src", "n_burst": 1, "burst_len": 1, "src_stride": 0, "dst_stride": 0}))
    finally:
        globvars.device_type = saved_device_type


def test_ub_to_ub_requires_aligned_src() -> None:
    pipe = _pipe(VPipe, {"dst": torch.zeros(256), "src": _misaligned()})
    with pytest.raises(RuntimeError, match="ub_to_ub src address"):
        pipe.execute(PipeTask("V", "ub_to_ub", {"dst": "dst", "src": "src", "n_burst": 1, "burst_len": 1, "src_stride": 0, "dst_stride": 0}))


def test_sort_requires_aligned_idx() -> None:
    pipe = _pipe(VPipe, {"dst": torch.zeros(128), "src": torch.zeros(64), "idx": _misaligned(torch.int32)})
    with pytest.raises(RuntimeError, match="sort32 idx address"):
        pipe.execute(PipeTask("V", "sort32", {"dst": "dst", "src": "src", "idx": "idx", "repeat": 1}))


def test_gather_scatter_require_aligned_offset() -> None:
    pipe = _pipe(VPipe, {"dst": torch.zeros(256), "src": torch.zeros(256), "offset": _misaligned(torch.int32)})
    with pytest.raises(RuntimeError, match="gather offset address"):
        pipe.execute(PipeTask("V", "gather", {"dst": "dst", "src": "src", "offset": "offset", "repeat": 1}))
    with pytest.raises(RuntimeError, match="scatter offset address"):
        pipe.execute(PipeTask("V", "scatter", {"dst": "dst", "src": "src", "offset": "offset", "repeat": 1}))


def test_gm_to_l1_requires_aligned_l1_dst() -> None:
    pipe = _pipe(CubeMTE2Pipe, {"dst": _misaligned(), "src": torch.zeros(256)})
    with pytest.raises(RuntimeError, match="gm_to_l1_nd2nz dst address"):
        pipe.execute(PipeTask("MTE2", "gm_to_l1_nd2nz", {"dst": "dst", "src": "src", "M": 1, "N": 16, "N_src": 16}))


def test_l1_to_l0_requires_aligned_l0_dst() -> None:
    pipe = _pipe(CubeMTE1Pipe, {"dst": _misaligned(), "src": torch.zeros(4096)})
    with pytest.raises(RuntimeError, match="l1_to_l0 dst address"):
        pipe.execute(PipeTask("MTE1", "l1_to_l0", {"dst": "dst", "src": "src", "m_dst": 16, "n_dst": 16, "m_src": 16, "n_src": 16}))


def test_l0c_to_ub_requires_aligned_ub_dst() -> None:
    pipe = _pipe(FixPipe, {"dst": _misaligned(), "src": torch.zeros(4096)})
    with pytest.raises(RuntimeError, match="l0c_to_ub dst address"):
        pipe.execute(PipeTask("FIX", "l0c_to_ub", {"dst": "dst", "src": "src", "M": 16, "N": 16, "M_src": 16}))



def test_mmad_requires_aligned_sources_and_dst() -> None:
    pipe = _pipe(MPipe, {"dst": torch.zeros(4096), "src_a": _misaligned(), "src_b": torch.zeros(4096)})
    with pytest.raises(RuntimeError, match="mmad src_a address"):
        pipe.execute(PipeTask("M", "mmad", {"dst": "dst", "src_a": "src_a", "src_b": "src_b", "M": 16, "N": 16, "K": 16}))
