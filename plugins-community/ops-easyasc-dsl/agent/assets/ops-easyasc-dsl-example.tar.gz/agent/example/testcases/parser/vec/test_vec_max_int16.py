import pytest

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


pytestmark = pytest.mark.easyasc_device("b3")


def test_a2_vmax_accepts_int16_and_codegen_uses_int16_t() -> None:
    @kernel(mode="vec")
    def vmax_int16_codegen(x1: GMTensor, x2: GMTensor, y: GMTensor):
        x1_ub = Tensor(DT.int16, [1, 128], Position.UB)
        x2_ub = Tensor(DT.int16, [1, 128], Position.UB)
        y_ub = Tensor(DT.int16, [1, 128], Position.UB)
        x1_ub <<= x1
        x2_ub <<= x2
        vmax(y_ub, x1_ub, x2_ub)
        y <<= y_ub
        return y

    x1 = GMTensor(DT.int16, [1, 128])
    x2 = GMTensor(DT.int16, [1, 128])
    y = GMTensor(DT.int16, [1, 128])
    vmax_int16_codegen(x1, x2, y)
    _, vec_code = translate_split(vmax_int16_codegen.instructions, "vmax_int16_codegen")

    assert "Max<int16_t, false>" in vec_code
