import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate_split


COLS = 128


@kernel()
def run_clean_dcache_passthrough(src: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.half, [1, cols], Position.UB)
    ub <<= src[0:1, :]
    clean_dcache(dst, EntireType.entire, DcciDst.atomic)
    dst[0:1, :] <<= ub
    return dst


def test_clean_dcache_rejects_invalid_dst_type() -> None:
    with pytest.raises(TypeError, match="dst must be GMTensor type"):
        clean_dcache("bad")  # type: ignore[arg-type]


def test_clean_dcache_rejects_invalid_entire_type() -> None:
    dst = GMTensor(DT.half, [1, COLS])
    with pytest.raises(TypeError, match="entire_type must be EntireTypeValue type"):
        clean_dcache(dst, "bad")  # type: ignore[arg-type]


def test_clean_dcache_rejects_invalid_dcci_dst() -> None:
    dst = GMTensor(DT.half, [1, COLS])
    with pytest.raises(TypeError, match="dcci_dst must be DcciDstType type"):
        clean_dcache(dst, EntireType.single, "bad")  # type: ignore[arg-type]


def test_clean_dcache_rejects_invalid_mode_type() -> None:
    dst = GMTensor(DT.half, [1, COLS])
    with pytest.raises(TypeError, match="mode must be str type"):
        clean_dcache(dst, EntireType.single, DcciDst.all, 1)  # type: ignore[arg-type]


def test_clean_dcache_rejects_invalid_mode_value() -> None:
    dst = GMTensor(DT.half, [1, COLS])
    with pytest.raises(ValueError, match="mode must be one of"):
        clean_dcache(dst, EntireType.single, DcciDst.all, "bad")


def test_clean_dcache_codegen_emits_backend_call() -> None:
    @kernel()
    def stub_only(global_tensor: GMTensor):
        clean_dcache(global_tensor, EntireType.entire, DcciDst.atomic)
        return global_tensor

    global_tensor = GMTensor(DT.float, [1, 1])
    stub_only(global_tensor)

    found = [inst for inst in stub_only.instructions if inst.opname == "clean_dcache"]
    assert len(found) == 1

    cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_clean_dcache_codegen")
    expected = (
        "DataCacheCleanAndInvalid<float, AscendC::CacheLine::ENTIRE_DATA_CACHE, "
        "AscendC::DcciDst::CACHELINE_ATOMIC>(global_tensor);"
    )
    assert expected in cube_code
    assert expected in vec_code


def test_clean_dcache_codegen_honors_mode() -> None:
    @kernel()
    def stub_mode_all(global_tensor: GMTensor):
        clean_dcache(global_tensor, EntireType.entire, DcciDst.atomic, mode="all")
        return global_tensor

    @kernel()
    def stub_mode_vec(global_tensor: GMTensor):
        clean_dcache(global_tensor, EntireType.entire, DcciDst.atomic, mode="vec")
        return global_tensor

    @kernel()
    def stub_mode_cube(global_tensor: GMTensor):
        clean_dcache(global_tensor, EntireType.entire, DcciDst.atomic, mode="cube")
        return global_tensor

    expected = (
        "DataCacheCleanAndInvalid<float, AscendC::CacheLine::ENTIRE_DATA_CACHE, "
        "AscendC::DcciDst::CACHELINE_ATOMIC>(global_tensor);"
    )

    global_tensor = GMTensor(DT.float, [1, 1], name="global_tensor")

    stub_mode_all(global_tensor)
    cube_code_all, vec_code_all = translate_split(stub_mode_all.instructions, "stub_mode_all")
    assert expected in cube_code_all
    assert expected in vec_code_all

    stub_mode_vec(global_tensor)
    cube_code_vec, vec_code_vec = translate_split(stub_mode_vec.instructions, "stub_mode_vec")
    assert expected not in cube_code_vec
    assert expected in vec_code_vec

    stub_mode_cube(global_tensor)
    cube_code_cube, vec_code_cube = translate_split(stub_mode_cube.instructions, "stub_mode_cube")
    assert expected in cube_code_cube
    assert expected not in vec_code_cube


