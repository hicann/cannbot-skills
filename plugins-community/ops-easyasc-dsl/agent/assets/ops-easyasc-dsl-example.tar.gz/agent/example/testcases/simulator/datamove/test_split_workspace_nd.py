import torch

from easyasc.a5 import *


BLK = 1
COLS = 128


@kernel()
def split_workspace_nd_kernel(src: GMTensor, out: GMTensor, depth: Var, rows: Var, cols: Var):
    workspace = split_workspace(DT.half, [depth, rows, cols], name="workspace_nd")
    ub = Tensor(DT.half, [BLK, cols], Position.UB)

    if GetVecIdx() == 0:
        # Write only [0, 0]; the rest of the workspace stays at its 0xFF init.
        ub <<= src[0, 0:BLK, :]
        workspace[0, 0:BLK, :] <<= ub
        bar_all()
        # Read the whole workspace back so unwritten cells surface as 0xFF.
        for depth_idx in range(depth):
            for row in range(rows):
                ub <<= workspace[depth_idx, row : row + BLK, :]
                bar_all()
                out[depth_idx, row : row + BLK, :] <<= ub
    return out


def test_split_workspace_nd_non_autosync_preserves_unwritten_ff_init(tmp_path) -> None:
    torch.manual_seed(0)

    depth = 3
    rows = 4
    cols = COLS
    src = torch.randn(depth, rows, cols, dtype=torch.float16)
    out_init = torch.zeros_like(src)

    out = OpExec(
        split_workspace_nd_kernel,
        str(tmp_path / "split_workspace_nd"),
        simulator=True,
    )(
        src,
        out_init,
        depth,
        rows,
        cols,
    )

    # Every cell except the written [0, 0] tile must surface its 0xFF init.
    unwritten = out.view(torch.uint8).clone()
    unwritten[0, 0, :] = 0xFF
    assert torch.equal(unwritten, torch.full_like(unwritten, 0xFF))


def test_split_workspace_codegen_uses_dtype_sized_workspace(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("ASCEND_HOME_PATH", "/tmp/fake_cann")
    torch.manual_seed(0)

    depth = 3
    rows = 4
    cols = COLS
    src = torch.randn(depth, rows, cols, dtype=torch.float16)
    out_init = torch.zeros_like(src)
    out_dir = tmp_path / "split_workspace_nd_codegen"

    OpExec(
        split_workspace_nd_kernel,
        str(out_dir),
        gen_only=True,
    )(
        src,
        out_init,
        depth,
        rows,
        cols,
    )

    host_text = (out_dir / "op_host" / "split_workspace_nd_kernel.cpp").read_text(encoding="utf-8")
    assert "size_t userWorkspaceSize = (depth * rows * cols) * sizeof(uint16_t);" in host_text
