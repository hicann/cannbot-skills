import torch

from easyasc.a2 import *

# The compiler requires a non-returned input tensor in the kernel entry;
# this kernel writes its output from a Var alone, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.float32)


@kernel(mode="vec")
def run_mixed_var_div(gate: GMTensor, dst: GMTensor, width: Var):
    with vec_scope():
        inv_width = 1.0 / width
        inv_width.SetValueTo(dst)
    return dst


def test_sim_mixed_var_div_uses_float_division() -> None:
    dst = torch.zeros((1, 1), dtype=torch.float32)
    op = OpExec(run_mixed_var_div, "test_sim_mixed_var_div_uses_float_division", simulator=True)
    out = op(GATE, dst, 4)
    torch.testing.assert_close(out, torch.full_like(out, 0.25))
