import torch

from easyasc.a5 import *
from easyasc.simulator import SimulatorConfig, build_simulator
from easyasc.simulator.memory import SharedMemoryStore, SharedTensorSpec

# The compiler requires a non-returned input tensor in the kernel entry; these
# kernels hand `src`/`out` back without reading a second buffer, so `gate` is
# never read.
GATE = torch.zeros((1, 1), dtype=torch.float32)


_ONE_CORE_CONFIG = SimulatorConfig(core_count=1, process_start_method="fork", execution_timeout_s=5.0)
_COLS = 128


def _all_bytes_are(tensor: torch.Tensor, value: int) -> bool:
    byte_tensor = tensor.contiguous().view(torch.uint8)
    return bool(torch.all(byte_tensor == value).item())


@kernel()
def _unwritten_output_kernel(src: GMTensor, out: GMTensor, contract: Var):
    return out


_unwritten_output_kernel._simulator_config = _ONE_CORE_CONFIG


@kernel()
def _uninitialized_workspace_kernel(out: GMTensor, contract: Var):
    ws = split_workspace(DT.uint8, [1, _COLS], name="random_ws")
    ub = Tensor(DT.uint8, [1, _COLS], Position.UB)

    if GetVecIdx() == 0:
        ub <<= ws[0:1, 0:_COLS]
        out[0:1, 0:_COLS] <<= ub
    return out


_uninitialized_workspace_kernel._simulator_config = _ONE_CORE_CONFIG


@kernel()
def _uninitialized_local_kernel(gate: GMTensor, out: GMTensor, contract: Var):
    ub = Tensor(DT.uint8, [1, _COLS], Position.UB)

    if GetVecIdx() == 0:
        out[0:1, 0:_COLS] <<= ub
    return out


_uninitialized_local_kernel._simulator_config = _ONE_CORE_CONFIG


def test_simulator_initializes_unwritten_output_to_bitwise_ones() -> None:
    src = torch.arange(_COLS, dtype=torch.uint8).reshape(1, _COLS)
    out_init = torch.zeros((1, _COLS), dtype=torch.uint8)

    out = OpExec(_unwritten_output_kernel, simulator=True)(src, out_init, -1)

    assert _all_bytes_are(out, 0xFF)
    assert not torch.equal(out, out_init)


def test_simulator_initializes_workspace_to_bitwise_ones() -> None:
    out = GMTensor(DT.uint8, [1, _COLS])

    _uninitialized_workspace_kernel(out, Var(-1))
    program = _uninitialized_workspace_kernel.build_simulator_program()
    sim = build_simulator(_ONE_CORE_CONFIG)
    try:
        sim._prepare(program)
        workspace = sim.memory_store.tensor("random_ws")
        assert _all_bytes_are(workspace, 0xFF)
    finally:
        sim.shutdown()


def test_simulator_initializes_unwritten_ub_to_bitwise_ones() -> None:
    out_init = torch.zeros((1, _COLS), dtype=torch.uint8)

    out = OpExec(_uninitialized_local_kernel, simulator=True)(GATE, out_init, -1)

    assert _all_bytes_are(out, 0xFF)
    assert not torch.equal(out, out_init)


def test_simulator_initializes_l1_l0_ub_allocations_to_bitwise_ones() -> None:
    store = SharedMemoryStore()
    specs = [
        SharedTensorSpec(name="l1_f32", shape=(4,), dtype="float32", role="l1"),
        SharedTensorSpec(name="l0a_f16", shape=(4,), dtype="float16", role="l0a"),
        SharedTensorSpec(name="l0b_u8", shape=(4,), dtype="uint8", role="l0b"),
        SharedTensorSpec(name="l0c_bf16", shape=(4,), dtype="bfloat16", role="l0c"),
        SharedTensorSpec(name="ub_bool", shape=(4,), dtype="bool", role="ub"),
    ]
    try:
        for spec in specs:
            store.register(spec)
            tensor = store.allocate(spec.name)
            assert _all_bytes_are(tensor, 0xFF)
    finally:
        store.clear()
