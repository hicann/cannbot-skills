import pytest
import torch
from types import SimpleNamespace

from easyasc.a5 import *
from easyasc.parser.asc import translate_split
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.bridge import build_kernel_program
from easyasc.simulator.pipe_micro import MicroRuntime
from easyasc.stub_functions.vec.unaryscalar import adds as vec_adds
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.instruction import Instruction
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.var import Var
from easyasc import globvars


COLS = 64


# ------------------------------------------------------------------
# Stub-level: constant-fold + type dispatch
# ------------------------------------------------------------------

def test_scalar_abs_constant_folds_int_var() -> None:
    result = scalar_abs(Var(-7, DT.int))
    assert result.dtype is DT.int
    assert result.value == 7


@pytest.mark.parametrize("dtype", [DT.int16, DT.int64])
def test_scalar_abs_preserves_wide_integer_dtype(dtype) -> None:
    result = scalar_abs(Var(-7, dtype))
    assert result.dtype is dtype
    assert result.value == 7


@pytest.mark.parametrize("dtype", [DT.uint8, DT.uint16, DT.uint32, DT.uint64])
def test_scalar_abs_rejects_unsigned_integer_dtype(dtype) -> None:
    with pytest.raises(TypeError, match="signed integer or float"):
        scalar_abs(Var(7, dtype))


def test_scalar_abs_constant_folds_float_var() -> None:
    result = scalar_abs(Var(-3.5, DT.float))
    assert result.dtype is DT.float
    assert result.value == pytest.approx(3.5)


def test_scalar_abs_constant_folds_python_int() -> None:
    result = scalar_abs(-12)
    assert result.dtype is DT.int
    assert result.value == 12


def test_scalar_abs_constant_folds_python_float() -> None:
    result = scalar_abs(-1.25)
    assert result.dtype is DT.float
    assert result.value == pytest.approx(1.25)


def test_scalar_abs_rejects_non_numeric() -> None:
    with pytest.raises(TypeError):
        scalar_abs("oops")


def test_scalar_abs_rejects_bool() -> None:
    with pytest.raises(TypeError):
        scalar_abs(True)


# ------------------------------------------------------------------
# Stub-level in vf context: float rejected
# ------------------------------------------------------------------

def test_scalar_abs_inside_vf_rejects_float_var() -> None:
    class _FakeMicro:
        def __init__(self):
            self.instructions = []

    prev = globvars.active_micro
    globvars.active_micro = _FakeMicro()
    try:
        with pytest.raises(TypeError, match="scalar_abs inside vf only supports int"):
            scalar_abs(Var(1.5, DT.float))
    finally:
        globvars.active_micro = prev


def test_scalar_abs_inside_vf_rejects_float_literal() -> None:
    class _FakeMicro:
        def __init__(self):
            self.instructions = []

    prev = globvars.active_micro
    globvars.active_micro = _FakeMicro()
    try:
        with pytest.raises(TypeError, match="scalar_abs inside vf only supports int"):
            scalar_abs(-1.25)
    finally:
        globvars.active_micro = prev


def test_scalar_abs_inside_vf_accepts_int() -> None:
    class _FakeMicro:
        def __init__(self):
            self.instructions = []

    prev = globvars.active_micro
    fake = _FakeMicro()
    globvars.active_micro = fake
    try:
        result = scalar_abs(Var(-4, DT.int))
        assert result.dtype is DT.int
        assert result.value == 4
        assert any(inst.opname == "scalar_abs" for inst in fake.instructions)
    finally:
        globvars.active_micro = prev


# ------------------------------------------------------------------
# Codegen: emits abs(...) in C++ for both vec and cube scopes
# ------------------------------------------------------------------

@kernel()
def _scalar_abs_vec_kernel(y: GMTensor):
    ub = Tensor(DT.float, [1, COLS], Position.UB)
    seed = Var(-2.5, DT.float, name="seed")
    with vec_scope():
        mag = scalar_abs(seed, name="mag")
        ub <<= y[0:1, 0:COLS]
        vec_adds(ub, ub, mag)
    y[0:1, 0:COLS] <<= ub
    return y


@pytest.mark.easyasc_device("b3")
def test_scalar_abs_emits_abs_in_vec_code() -> None:
    y = GMTensor(DT.float, [1, COLS], name="y_abs_vec")
    _scalar_abs_vec_kernel(y)
    cube_code, vec_code = translate_split(
        _scalar_abs_vec_kernel.instructions, "_scalar_abs_vec_kernel"
    )
    assert "abs(" in vec_code
    # Must not leak into cube code
    assert "abs(seed)" not in cube_code
    assert "float seed" not in cube_code


@pytest.mark.easyasc_device("b3")
def test_scalar_abs_is_preserved_in_simulator_bridge() -> None:
    y = GMTensor(DT.float, [1, COLS], name="y_abs_bridge")
    _scalar_abs_vec_kernel(y)

    program = build_kernel_program(_scalar_abs_vec_kernel)
    vec_program = next(lane for lane in program.lane_programs if lane.lane_name == "vec0")

    assert any(inst.opname == "scalar_abs" for inst in vec_program.instructions)


@kernel()
def _scalar_abs_cube_kernel(src: GMTensor):
    l1 = Tensor(DT.half, [16, 16], Position.L1)
    n = Var(-3, name="n")
    with cube_scope():
        m = scalar_abs(n, name="m")
        l1 <<= src[0:16, 0:16]
        set_constant_to_l1(l1, 1.0, m)
    return src


def test_scalar_abs_emits_abs_in_cube_code() -> None:
    src = GMTensor(DT.half, [16, 16], name="src_abs_cube")
    _scalar_abs_cube_kernel(src)
    cube_code, vec_code = translate_split(
        _scalar_abs_cube_kernel.instructions, "_scalar_abs_cube_kernel"
    )
    assert "abs(" in cube_code
    assert "abs(n)" not in vec_code


# ------------------------------------------------------------------
# Micro runtime: int supported, float rejected at runtime (defensive)
# ------------------------------------------------------------------

def test_micro_runtime_supports_scalar_abs_int() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    n = Var(-5, name="n")
    out_var = Var(0, name="out_var")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=n),
            Instruction("create_var", val=out_var),
            Instruction("create_reg", reg=src),
            Instruction("create_reg", reg=dst),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("scalar_abs", a=n, out=out_var),  # 5
            Instruction("micro_vdup", dst=src, value=1.0),
            Instruction("micro_vmuls", dst=dst, src=src, v=out_var),
            Instruction("micro_reg2ub", dst=out_ref, src=dst, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    torch.testing.assert_close(out, torch.full_like(out, 5.0))


def test_micro_runtime_scalar_abs_rejects_float() -> None:
    runtime = MicroRuntime()
    n = Var(-2.0, dtype=DT.float, name="n")
    out_var = Var(0.0, dtype=DT.float, name="out_var")

    micro_def = {
        "instructions": [
            Instruction("create_var", val=n),
            Instruction("create_var", val=out_var),
            Instruction("scalar_abs", a=n, out=out_var),
        ]
    }

    with pytest.raises(TypeError, match="scalar_abs inside vf only supports int"):
        runtime.execute_call_micro(micro_def, {}, {}, SharedMemoryStore())
