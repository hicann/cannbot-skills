import torch

from easyasc import globvars
from easyasc.a2 import OpExec, pack_signed_int4, unpack_signed_int4
from kernels.a2.matmul.matmul_int4_splitk import (
    SHAPE_BINDINGS,
    matmul_int4_splitk_kernel,
)


def test_pack_signed_int4_low_nibble_first_roundtrip() -> None:
    logical = torch.tensor([[-8, -7, -1, 0, 1, 2, 6, 7, -3]], dtype=torch.int32)
    packed = pack_signed_int4(logical)
    assert packed.shape == (1, 2)
    assert unpack_signed_int4(packed, logical.shape[1]).equal(logical)


def test_int4_splitk_simulator_full_tails() -> None:
    saved_device = globvars.device_type
    globvars.device_type = "b3"
    try:
        m, n, k = 17, 19, 137
        torch.manual_seed(137)
        x_logical = torch.randint(-8, 8, (m, k), dtype=torch.int32)
        y_logical = torch.randint(-8, 8, (n, k), dtype=torch.int32)
        x = pack_signed_int4(x_logical)
        y = pack_signed_int4(y_logical)
        z = torch.zeros((m, n), dtype=torch.int32)
        kc = x.shape[1]

        out = OpExec(matmul_int4_splitk_kernel, simulator=True)(
            x, y, z, m, n, k, kc, shape_bindings=SHAPE_BINDINGS
        )
        ref = x_logical @ y_logical.t()

        torch.testing.assert_close(out, ref)
    finally:
        globvars.device_type = saved_device
