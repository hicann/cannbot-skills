import contextlib
import io

import pytest

from easyasc.a5 import *
from easyasc.parser.asc import translate, translate_split


WIDTH = 64


def _translate_split_silently(instructions, name: str):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        return translate_split(instructions, name)


@kernel()
def duplicate_named_vars_kernel(dst: GMTensor):
    dup = Var(7, DT.int, name="dup")
    dup_other = Var(9, DT.int, name="dup")
    kernel_print("dup=%d dup_other=%d\n", dup, dup_other)
    return dst


@vf()
def duplicate_named_vars_micro(dst: Tensor):
    bias = Var(1.0, DT.float, name="bias")
    bias_other = Var(2.0, DT.float, name="bias")
    dst[0:1, 0:WIDTH] <<= dst[0:1, 0:WIDTH] + bias
    dst[0:1, 0:WIDTH] <<= dst[0:1, 0:WIDTH] + bias_other


def test_duplicate_local_var_names_get_postfix_in_kernel_codegen() -> None:
    dst = GMTensor(DT.int, [1, 1], name="dst")
    duplicate_named_vars_kernel(dst)

    cube_code, vec_code = _translate_split_silently(
        duplicate_named_vars_kernel.instructions,
        "duplicate_named_vars_kernel",
    )
    expected_print = 'printf("dup=%d dup_other=%d\\n", dup, dup_1);'

    assert "int dup = 7;" in cube_code
    assert "int dup_1 = 9;" in cube_code
    assert expected_print in cube_code

    assert "int dup = 7;" in vec_code
    assert "int dup_1 = 9;" in vec_code
    assert expected_print in vec_code


@pytest.mark.easyasc_device("b3")
def test_duplicate_local_var_names_get_postfix_in_micro_codegen() -> None:
    dst = Tensor(DT.float, [1, WIDTH], Position.UB)
    duplicate_named_vars_micro(dst)

    code = translate(duplicate_named_vars_micro.instructions)

    assert "float bias = 1.0f;" in code
    assert "float bias_1 = 2.0f;" in code
    assert code.count("float bias = 1.0f;") == 1
    assert "float bias = 2.0f;" not in code
