from pathlib import Path

import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.decorators import kernel


@kernel()
def _mode_mix_kernel(inp: GMTensor, out: GMTensor, m: Var):
    lanes = Var(GetVecNum(), name="lanes")
    lanes.SetValueTo(out)
    return out


@kernel(mode="vec")
def _mode_vec_kernel(inp: GMTensor, out: GMTensor, m: Var):
    lanes = Var(GetVecNum(), name="lanes")
    lanes.SetValueTo(out)
    return out


@kernel(mode="cube")
def _mode_cube_kernel(inp: GMTensor, out: GMTensor, m: Var):
    blocks = Var(GetCubeNum(), name="blocks")
    with cube_scope():
        blocks.SetValueTo(out)
    return out


@kernel(mode="vec")
def _mode_vec_bad_getcubenun_kernel(inp: GMTensor, out: GMTensor, m: Var):
    blocks = Var(GetCubeNum(), name="blocks")
    blocks.SetValueTo(out)
    return out


def _render_kernel_sources(tmp_path: Path, kernel_obj, *, device_type: str = "950") -> tuple[str, str, str]:
    saved_device_type = globvars.device_type
    globvars.device_type = device_type
    try:
        inp = GMTensor(DT.float, [1, 1])
        out = GMTensor(DT.float, [1, 1])
        kernel_obj(inp, out, Var(1, DT.int))
        base = tmp_path / kernel_obj.name
        kernel_obj.dump_kernel(str(base))
        cpp = (tmp_path / f"{kernel_obj.name}.cpp").read_text(encoding="utf-8")
        cube_h = (tmp_path / f"{kernel_obj.name}_cube.h").read_text(encoding="utf-8")
        vec_h = (tmp_path / f"{kernel_obj.name}_vec.h").read_text(encoding="utf-8")
        return cpp, cube_h, vec_h
    finally:
        globvars.device_type = saved_device_type


def test_kernel_accepts_default_mix_mode() -> None:
    assert _mode_mix_kernel.kernel_mode == "mix"


def test_mix_mode_validation_skips_redundant_split(monkeypatch) -> None:
    def fail_split(*args, **kwargs):
        raise AssertionError("mix validation should not pre-split instructions")

    monkeypatch.setattr("easyasc.parser.asc.split_instructions", fail_split)
    _mode_mix_kernel._validate_codegen_kernel_mode()


def test_kernel_rejects_bare_decorator() -> None:
    with pytest.raises(TypeError, match="kernel decorator requires parentheses"):
        exec(
            "@kernel\n"
            "def bare_kernel(inp, out, m):\n"
            "    return out\n",
            {"kernel": kernel},
        )


def test_kernel_rejects_invalid_mode() -> None:
    with pytest.raises(ValueError, match="kernel mode must be one of"):
        @kernel(mode="bad")
        def _bad_mode_kernel(inp, out, m):
            return out


@pytest.mark.parametrize("kernel_obj, expected_task_type, expect_cube_call, expect_vec_call", [
    (_mode_mix_kernel, "KERNEL_TYPE_MIX_AIC_1_2", True, True),
    (_mode_cube_kernel, "KERNEL_TYPE_AIC_ONLY", True, False),
    (_mode_vec_kernel, "KERNEL_TYPE_AIV_ONLY", False, True),
])
def test_dump_kernel_uses_mode_specific_task_type_and_side_calls(
    tmp_path: Path,
    kernel_obj,
    expected_task_type: str,
    expect_cube_call: bool,
    expect_vec_call: bool,
) -> None:
    cpp, _, _ = _render_kernel_sources(tmp_path, kernel_obj)
    assert f"KERNEL_TASK_TYPE_DEFAULT({expected_task_type});" in cpp
    assert (f"{kernel_obj.name}_cube(" in cpp) is expect_cube_call
    assert (f"{kernel_obj.name}_vec(" in cpp) is expect_vec_call


def test_vec_mode_codegen_uses_get_block_num_without_double(tmp_path: Path) -> None:
    _, cube_h, vec_h = _render_kernel_sources(tmp_path, _mode_vec_kernel)
    assert "GetBlockNum() * 2" not in vec_h
    assert "GetBlockNum();" in vec_h
    assert "cube side omitted for kernel mode 'vec'" in cube_h


def test_vec_mode_rejects_get_cube_num(tmp_path: Path) -> None:
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        inp = GMTensor(DT.float, [1, 1])
        out = GMTensor(DT.float, [1, 1])
        _mode_vec_bad_getcubenun_kernel(inp, out, Var(1, DT.int))
        with pytest.raises(ValueError, match="GetCubeNum is not allowed when kernel mode is 'vec'"):
            _mode_vec_bad_getcubenun_kernel.dump_kernel(str(tmp_path / "bad_vec_kernel"))
    finally:
        globvars.device_type = saved_device_type
