import pytest

from easyasc.a2 import set_hf32 as a2_set_hf32
from easyasc.a5 import *
from easyasc.a5 import set_hf32 as a5_set_hf32
from easyasc.parser.asc import translate_split


COLS = 128


@kernel()
def run_hf32_passthrough(src: GMTensor, dst: GMTensor, cols: Var):
    set_hf32()
    ub = Tensor(DT.float, [1, cols], Position.UB)
    if GetVecIdx() == 0:
        ub <<= src[0:1, :]
        set_hf32(False)
        dst[0:1, :] <<= ub
    return dst


def test_a2_and_a5_export_set_hf32() -> None:
    assert callable(a2_set_hf32)
    assert callable(a5_set_hf32)


def test_set_hf32_rejects_non_bool_enable() -> None:
    with pytest.raises(TypeError, match="enable must be bool type"):
        set_hf32(1)  # type: ignore[arg-type]


def test_set_hf32_codegen_emits_backend_call() -> None:
    @kernel()
    def stub_only(global_tensor: GMTensor):
        set_hf32()
        set_hf32(False)
        return global_tensor

    global_tensor = GMTensor(DT.float, [1, 1], name="global_tensor")
    stub_only(global_tensor)

    found = [inst for inst in stub_only.instructions if inst.opname == "set_hf32"]
    assert [inst.kwargs["enable"] for inst in found] == [True, False]

    cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_set_hf32_codegen")
    assert "SetHF32Mode(true);" in cube_code
    assert "SetHF32Mode(false);" in cube_code
    assert "SetHF32Mode(true);" in vec_code
    assert "SetHF32Mode(false);" in vec_code


def test_simulator_program_drops_set_hf32() -> None:
    src = GMTensor(DT.float, [1, COLS], name="src")
    dst = GMTensor(DT.float, [1, COLS], name="dst")
    run_hf32_passthrough(src, dst, Var(COLS, DT.int, name="cols"))

    program = run_hf32_passthrough.build_simulator_program()
    opnames = [inst.opname for lane in program.lane_programs for inst in lane.instructions]
    assert "set_hf32" not in opnames
