from easyasc.a2 import *
from easyasc.parser.asc import split_instructions


BLK = 128


@kernel()
def _inline_varmod_tbuff_transpose_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, K: Var):
    keep = TBuff(DT.half, [BLK, K], Position.L1)
    lhs = DBuff(DT.half, [BLK, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, BLK], Position.L0C)
    ub = Tensor(DT.float, [1, 64], Position.UB)

    stage2_cnt = Var(0, name="stage2_cnt")

    lhs[0] <<= x[0:BLK, 0:K]
    keep[var_mod(stage2_cnt, 3)] <<= y[0:BLK, 0:K]
    matmul(l0c[0], lhs[0], keep[var_mod(stage2_cnt, 3)].T, is_init=True)

    dup(ub, 0.0)
    z[0:1, 0:64] <<= ub
    return z


def _build_split(kernel_fn):
    x = GMTensor(DT.half, [BLK, BLK], name="x")
    y = GMTensor(DT.half, [BLK, BLK], name="y")
    z = GMTensor(DT.float, [1, 64], name="z")
    m = Var(BLK, name="M")
    k = Var(BLK, name="K")
    kernel_fn(x, y, z, m, k)
    return split_instructions(list(kernel_fn.instructions))


def test_split_prunes_dead_inline_varmod_tbuff_index_chain() -> None:
    cube_insts, vec_insts = _build_split(_inline_varmod_tbuff_transpose_kernel)

    assert any(inst.opname == "var_mod" for inst in cube_insts)
    assert not any(inst.opname == "var_mod" for inst in vec_insts)
    assert not any(
        inst.opname == "get_buf" and isinstance(inst.kwargs.get("buf", None), TBuff)
        for inst in vec_insts
    )
    assert not any(
        inst.opname == "create_var" and getattr(inst.kwargs.get("val", None), "name", None) == "stage2_cnt"
        for inst in vec_insts
    )
