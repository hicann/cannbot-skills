import threading

from easyasc.simulator.sync import CycleBarrier


def test_cycle_barrier_releases_all_participants_at_max_arrival_cycle():
    barrier = CycleBarrier(parties=3)
    results = []

    def wait_with_cycle(cycle):
        results.append(barrier.wait_cycle(cycle))

    threads = [
        threading.Thread(target=wait_with_cycle, args=(10.0,)),
        threading.Thread(target=wait_with_cycle, args=(25.0,)),
    ]
    for thread in threads:
        thread.start()

    results.append(barrier.wait_cycle(3.0))

    for thread in threads:
        thread.join(timeout=1.0)
        assert not thread.is_alive()

    assert sorted(results) == [25.0, 25.0, 25.0]
