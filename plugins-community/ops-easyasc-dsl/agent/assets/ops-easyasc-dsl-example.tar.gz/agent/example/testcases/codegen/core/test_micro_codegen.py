import re
from pathlib import Path

import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.micro.micromodule import MicroModule
from easyasc.parser.asc import translate
from easyasc.utils.instruction import Instruction


def test_temp_reg_is_declared_before_use_in_micro_codegen() -> None:
    @vf()
    def simple_micro(x: Tensor, out: Tensor, n_loops: Var):
        xreg = Reg(DT.float)
        for i in range(n_loops):
            xreg <<= x[i * 64]
            xreg <<= xreg.abs() + 1.0
            out[i * 64] <<= xreg

    x = Tensor(DT.float, [128, 64], Position.UB)
    out = Tensor(DT.float, [128, 64], Position.UB)
    n_loops = Var(1)

    simple_micro(x, out, n_loops)
    code = translate(simple_micro.instructions)

    decl_match = re.search(r"MicroAPI::RegTensor<float>\s+(_tmp_reg_\d+);", code)
    assert decl_match is not None
    tmp_reg_name = decl_match.group(1)

    abs_use = f"MicroAPI::Abs({tmp_reg_name}, xreg, "
    adds_use = f"MicroAPI::Adds(xreg, {tmp_reg_name}, 1.0f, "

    assert abs_use in code
    assert adds_use in code
    assert code.find(decl_match.group(0)) < code.find(abs_use)


def test_micro_arange_folds_loop_derived_start_expr() -> None:
    @vf()
    def arange_with_chunk_offset(out: Tensor):
        cols = Reg(DT.int)
        for chunk in range(8, name="chunk"):
            cols.arange(chunk * 64)

    out = Tensor(DT.float, [1, 64], Position.UB)

    arange_with_chunk_offset(out)
    code = translate(arange_with_chunk_offset.instructions)

    assert "_tmp_var_" not in code
    assert re.search(
        r"MicroAPI::Arange<int, MicroAPI::IndexOrder::INCREASE_ORDER>\([^,]+,\s*(?:64\s*\*\s*chunk|chunk\s*\*\s*64)\);",
        code,
    )


def test_micro_arange_decrease_shifts_scalar_by_vl_minus_one() -> None:
    # The hardware Arange<DECREASE_ORDER>(s) ends the ramp AT s ([s+VL-1..s]); the codegen
    # shifts the emitted scalar by -(VL-1) so `start` is the first/max lane (== sim ==
    # [start, start-1, ...]). VL = 256/itemsize -> int32:63, int16:127. INCREASE is unshifted.
    @vf()
    def dec_arange(out: Tensor):
        c32 = Reg(DT.int)
        arange(c32, 10, increase=False)      # int32, VL=64 -> shift -63
        c16 = Reg(DT.int16)
        arange(c16, 100, increase=False)     # int16, VL=128 -> shift -127
        c32i = Reg(DT.int)
        arange(c32i, 5, increase=True)       # INCREASE -> no shift

    out = Tensor(DT.float, [1, 64], Position.UB)
    dec_arange(out)
    code = translate(dec_arange.instructions)

    assert re.search(
        r"MicroAPI::Arange<int, MicroAPI::IndexOrder::DECREASE_ORDER>\([^,]+,\s*\(\(10\)\s*-\s*63\)\);", code
    ), code
    assert re.search(
        r"MicroAPI::Arange<int16_t, MicroAPI::IndexOrder::DECREASE_ORDER>\([^,]+,\s*\(\(100\)\s*-\s*127\)\);", code
    ), code
    # INCREASE stays a bare scalar (no -(VL-1) shift)
    assert re.search(
        r"MicroAPI::Arange<int, MicroAPI::IndexOrder::INCREASE_ORDER>\([^,]+,\s*5\);", code
    ), code


def test_micro_unit_step_loop_uses_hardware_loop_increment() -> None:
    @vf()
    def unit_step_loop(src: Tensor):
        reg = Reg(DT.float)
        for chunk in range(128, name="chunk"):
            reg <<= src[chunk * 64]

    src = Tensor(DT.float, [1, 8192], Position.UB)
    unit_step_loop(src)
    code = translate(unit_step_loop.instructions)

    assert "for (uint16_t chunk = (uint16_t)0;" in code
    assert "++chunk)" in code
    assert "chunk += (uint16_t)1" not in code


def test_micro_loop_handler_uses_increment_only_for_static_unit_step() -> None:
    unit_var = Var(0, name="_tmp_var_unit_loop")
    step_two_var = Var(0, name="_tmp_var_step_two_loop")
    instructions = [
        Instruction("create_var", val=unit_var),
        Instruction("start_micro_loop", var=unit_var, start=0, stop=8, step=1),
        Instruction("end_loop", var=unit_var),
        Instruction("create_var", val=step_two_var),
        Instruction("start_micro_loop", var=step_two_var, start=0, stop=8, step=2),
        Instruction("end_loop", var=step_two_var),
    ]

    code = translate(instructions)

    assert "++_tmp_var_unit_loop)" in code
    assert "_tmp_var_unit_loop += (uint16_t)1" not in code
    assert "_tmp_var_step_two_loop += (uint16_t)2" in code


def test_micro_cast_hif8_hybrid_codegen(tmp_path: Path) -> None:
    @vf()
    def cast_hybrid(src: Tensor, dst: Tensor):
        src_reg = Reg(DT.float)
        dst_reg = Reg(DT.hif8)
        mask = MaskReg(DT.hif8)
        cfg = CastConfig(round_mode=RoundMode.HYBRID, name="hybrid")

        src_reg <<= src[0]
        cast(dst_reg, src_reg, cfg, mask)
        dst[0] <<= dst_reg.pack4()

    src = Tensor(DT.float, [1, 64], Position.UB)
    dst = Tensor(DT.hif8, [1, 64], Position.UB)
    cast_hybrid(src, dst)

    micro_path = tmp_path / "cast_hybrid.h"
    cast_hybrid.gen_code(str(micro_path))
    code = micro_path.read_text(encoding="utf-8")

    assert "RoundMode::CAST_HYBRID" in code


def test_micro_ieee_div_codegen(tmp_path: Path) -> None:
    @vf()
    def ieee_div(src: Tensor, dst: Tensor):
        numerator = Reg(DT.float, name="ieee_numerator")
        denominator = Reg(DT.float, name="ieee_denominator")
        quotient = Reg(DT.float, name="ieee_quotient")
        config = DivConfig(
            algo=DivAlgo.PRECISION_0ULP_FTZ_FALSE,
            name="ieee_division",
        )
        numerator <<= src[0:1, 0:64]
        denominator <<= src[0:1, 64:128]
        div(quotient, numerator, denominator, config=config)
        dst[0:1, 0:64] <<= quotient

    src = Tensor(DT.float, [1, 128], Position.UB)
    dst = Tensor(DT.float, [1, 64], Position.UB)
    ieee_div(src, dst)

    micro_path = tmp_path / "ieee_div.h"
    ieee_div.gen_code(str(micro_path))
    code = micro_path.read_text(encoding="utf-8")

    assert "MicroAPI::DivSpecificMode ieee_div_ieee_division" in code
    assert "DivAlgo::PRECISION_0ULP_FTZ_FALSE" in code
    assert "MicroAPI::Div<float, &ieee_div_ieee_division>" in code


def test_micro_cast_half_hif8_hybrid_downsample_codegen(tmp_path: Path) -> None:
    @vf()
    def cast_half_hybrid(src: Tensor, dst: Tensor):
        src_reg = Reg(DT.half)
        dst_reg = Reg(DT.hif8)
        mask = MaskReg(DT.hif8)
        cfg = CastConfig(round_mode=RoundMode.HYBRID, name="hybrid")

        src_reg <<= src[0]
        cast(dst_reg, src_reg, cfg, mask)
        dst[0] <<= dst_reg.downsample()

    src = Tensor(DT.half, [1, 128], Position.UB)
    dst = Tensor(DT.hif8, [1, 128], Position.UB)
    cast_half_hybrid(src, dst)

    micro_path = tmp_path / "cast_half_hybrid.h"
    cast_half_hybrid.gen_code(str(micro_path))
    code = micro_path.read_text(encoding="utf-8")

    assert "RoundMode::CAST_HYBRID" in code
    assert "StoreDist::DIST_PACK_B16" in code


def test_micro_cast_bfloat16_to_fp4_e1m2_codegen(tmp_path: Path) -> None:
    @vf()
    def cast_bfloat16_fp4(src: Tensor, dst: Tensor):
        src_reg = Reg(DT.bfloat16)
        dst_reg = Reg(DT.fp4_e1m2)
        carrier_reg = dst_reg.reinterpret(DT.uint8)
        mask = MaskReg(DT.bfloat16)
        cfg = CastConfig(
            round_mode=RoundMode.TO_EVEN,
            reg_layout=RegLayout.ZERO,
            name="rint",
        )

        src_reg <<= src[0]
        cast(dst_reg, src_reg, cfg, mask)
        dst[0] <<= carrier_reg.pack4()

    src = Tensor(DT.bfloat16, [1, 128], Position.UB)
    dst = Tensor(DT.uint8, [1, 64], Position.UB)
    cast_bfloat16_fp4(src, dst)

    micro_path = tmp_path / "cast_bfloat16_fp4.h"
    cast_bfloat16_fp4.gen_code(str(micro_path))
    code = micro_path.read_text(encoding="utf-8")

    assert "MicroAPI::RegLayout::ZERO" in code
    assert "RoundMode::CAST_RINT" in code
    assert "MicroAPI::RegTensor<fp4x2_e1m2_t>" in code
    assert "MicroAPI::Cast<fp4x2_e1m2_t, bfloat16_t" in code
    assert "MicroAPI::RegTensor<uint8_t>&" in code
    assert "MicroAPI::StoreAlign<uint8_t, MicroAPI::StoreDist::DIST_PACK4_B32>" in code


def test_tensor_reg_assignment_uses_normal_continuous_align_copy() -> None:
    @vf()
    def copy_via_reg(src: Tensor, dst: Tensor):
        reg = Reg(DT.float)
        reg <<= src[0:1, 0:64]
        dst[0:1, 0:64] <<= reg

    src = Tensor(DT.float, [1, 64], Position.UB)
    dst = Tensor(DT.float, [1, 64], Position.UB)
    copy_via_reg(src, dst)
    code = translate(copy_via_reg.instructions)

    assert "MicroAPI::LoadAlign<float, MicroAPI::LoadDist::DIST_NORM>" in code
    assert "MicroAPI::StoreAlign<float, MicroAPI::StoreDist::DIST_NORM_B32>" in code
    assert "MicroAPI::DataCopyMode::DATA_BLOCK_COPY" not in code


def test_explicit_ub_to_reg_keeps_block_copy_codegen() -> None:
    @vf()
    def explicit_block_copy(src: Tensor):
        reg = Reg(DT.float)
        ub_to_reg(reg, src[0:1, 0:64])

    src = Tensor(DT.float, [1, 64], Position.UB)
    explicit_block_copy(src)
    code = translate(explicit_block_copy.instructions)

    assert "MicroAPI::DataCopyMode::DATA_BLOCK_COPY" in code


def test_ub_to_reg_interleave_codegen_uses_dual_loadalign() -> None:
    @vf()
    def interleave_load(src: Tensor):
        reg0 = Reg(DT.float)
        reg1 = Reg(DT.float)
        ub_to_reg_interleave(reg0, reg1, src[0:1, 0:128])

    src = Tensor(DT.float, [1, 128], Position.UB)
    interleave_load(src)
    code = translate(interleave_load.instructions)

    assert "MicroAPI::LoadAlign<float, MicroAPI::LoadDist::DIST_DINTLV_B32>(reg0, reg1, src);" in code


def test_reg_to_ub_interleave_codegen_uses_dual_storealign() -> None:
    @vf()
    def interleave_store(dst: Tensor):
        reg0 = Reg(DT.float)
        reg1 = Reg(DT.float)
        reg_to_ub_interleave(dst[0:1, 0:128], reg0, reg1)

    dst = Tensor(DT.float, [1, 128], Position.UB)
    interleave_store(dst)
    code = translate(interleave_store.instructions)

    assert "MicroAPI::StoreAlign<float, MicroAPI::StoreDist::DIST_INTLV_B32>(dst, reg0, reg1," in code


def test_reg_to_ub_interleave_stub_rejects_mixed_types() -> None:
    @vf()
    def mixed(dst: Tensor):
        reg0 = Reg(DT.float)
        reg1 = Reg(DT.half)
        reg_to_ub_interleave(dst[0:1, 0:128], reg0, reg1)

    dst = Tensor(DT.float, [1, 128], Position.UB)

    with pytest.raises(ValueError, match="dst/src0/src1 data types must match"):
        mixed(dst)


def test_ub_to_reg_interleave_stub_rejects_mixed_types() -> None:
    @vf()
    def mixed(src: Tensor):
        reg0 = Reg(DT.float)
        reg1 = Reg(DT.half)
        ub_to_reg_interleave(reg0, reg1, src[0:1, 0:128])

    src = Tensor(DT.float, [1, 128], Position.UB)

    with pytest.raises(ValueError, match="dst0/dst1/src data types must match"):
        mixed(src)


_MICRO_BITWISE_DTYPES = [
    DT.uint8,
    DT.int8,
    DT.uint16,
    DT.int16,
    DT.uint32,
    DT.int,
    DT.uint64,
    DT.int64,
]


def _with_active_micro(fn):
    micro = MicroModule("test_micro_bitwise", lambda: None)
    prev_micro = globvars.active_micro
    globvars.active_micro = micro
    try:
        fn(micro)
    finally:
        globvars.active_micro = prev_micro
    return micro


def _emit_micro_bitwise(opname: str, dtype) -> None:
    dst = Reg(dtype)
    src0 = Reg(dtype)
    src1 = Reg(dtype)
    if opname == "vnot":
        vnot(dst, src0)
    elif opname == "vand":
        vand(dst, src0, src1)
    elif opname == "vor":
        vor(dst, src0, src1)
    elif opname == "vxor":
        vxor(dst, src0, src1)
    else:
        raise ValueError(f"unknown micro bitwise op: {opname}")


@pytest.mark.parametrize("dtype", _MICRO_BITWISE_DTYPES)
@pytest.mark.parametrize(
    "opname, cpp_name",
    [
        ("vnot", "Not"),
        ("vand", "And"),
        ("vor", "Or"),
        ("vxor", "Xor"),
    ],
)
def test_micro_bitwise_stubs_accept_integer_dtypes(dtype, opname: str, cpp_name: str) -> None:
    micro = _with_active_micro(lambda _: _emit_micro_bitwise(opname, dtype))
    code = translate(micro.instructions)

    assert f"MicroAPI::{cpp_name}(" in code


@pytest.mark.parametrize("dtype", [DT.float, DT.half, DT.bfloat16])
@pytest.mark.parametrize("opname", ["vnot", "vand", "vor", "vxor"])
def test_micro_bitwise_stubs_reject_non_integer_dtypes(dtype, opname: str) -> None:
    with pytest.raises(TypeError, match="only supports integer bitwise dtypes"):
        _with_active_micro(lambda _: _emit_micro_bitwise(opname, dtype))


def test_micro_slice_keeps_int_div_offset_shape() -> None:
    @vf()
    def micro_keep(dst: Tensor, n: Var):
        reg = Reg(DT.float)
        keep = n // 64 * 64 // 2
        reg <<= dst[0:1, keep:keep + WIDTH]

    buf = Tensor(DT.float, [1, 256], Position.UB)
    micro_keep(buf, Var(123, DT.int, name="n"))
    code = translate(micro_keep.instructions)

    assert "dst + n/2" not in code
    assert "64*((n) / (64))" in code
    assert "dst + (((64*((n) / (64))) / (2)))" in code


WIDTH = 64


@vf()
def _add_once_vf(dst: Tensor, src: Tensor):
    dst_reg = Reg(DT.float)
    src_reg = Reg(DT.float)
    dst_reg <<= dst[0:1, 0:WIDTH]
    src_reg <<= src[0:1, 0:WIDTH]
    dst_reg <<= dst_reg + src_reg
    dst[0:1, 0:WIDTH] <<= dst_reg


@kernel()
def _call_add_twice_kernel(src: GMTensor, dst: GMTensor, n: Var):
    lhs = Tensor(DT.float, [1, WIDTH], Position.UB)
    rhs = Tensor(DT.float, [1, WIDTH], Position.UB)
    with If(GetSubBlockIdx() == 0):
        lhs[0:1, 0:n] <<= src[0:1, 0:n]
        rhs[0:1, 0:n] <<= src[0:1, 0:n]
        _add_once_vf(lhs[0:1, 0:n], rhs[0:1, 0:n])
        _add_once_vf(lhs[0:1, 0:n], rhs[0:1, 0:n])
        dst[0:1, 0:n] <<= lhs[0:1, 0:n]
    return dst


def test_micro_module_body_is_built_once_when_called_twice(tmp_path: Path) -> None:
    src = GMTensor(DT.float, [1, WIDTH])
    dst = GMTensor(DT.float, [1, WIDTH])
    _call_add_twice_kernel(src, dst, Var(WIDTH))

    call_count = sum(
        1
        for inst in _call_add_twice_kernel.instructions
        if inst.opname == "call_micro" and inst.kwargs.get("name") == _add_once_vf.name
    )
    assert call_count == 2

    micro_path = tmp_path / "add_once_vf.h"
    _add_once_vf.gen_code(str(micro_path))
    code = micro_path.read_text(encoding="utf-8")
    assert code.count("MicroAPI::Add(") == 1


def test_micro_reg_shift_emits_shiftleft_shiftright() -> None:
    @vf()
    def shift_kernel(x: Tensor, sh: Tensor, out: Tensor):
        xr = Reg(DT.int)
        sr = Reg(DT.int)
        yr = Reg(DT.int)
        xr <<= x[0]
        sr <<= sh[0]
        shiftl(yr, xr, sr)   # reg-reg (per-lane) shift, distinct from scalar shiftls
        out[0] <<= yr
        shiftr(yr, xr, sr)
        out[64] <<= yr

    x = Tensor(DT.int, [1, 64], Position.UB)
    sh = Tensor(DT.int, [1, 64], Position.UB)
    out = Tensor(DT.int, [2, 64], Position.UB)
    shift_kernel(x, sh, out)
    code = translate(shift_kernel.instructions)
    # reg-reg form: shift operand is a RegTensor, no scalar cast (contrast ShiftLefts)
    assert re.search(r"MicroAPI::ShiftLeft\(yr, xr, sr, ", code)
    assert re.search(r"MicroAPI::ShiftRight\(yr, xr, sr, ", code)


def test_micro_reg_shift_rejects_float_and_dtype_mismatch() -> None:
    @vf()
    def bad_float(out: Tensor):
        a = Reg(DT.float)
        b = Reg(DT.float)
        c = Reg(DT.float)
        shiftl(c, a, b)  # shifts are integer-only

    with pytest.raises((TypeError, ValueError)):
        bad_float(Tensor(DT.float, [1, 64], Position.UB))

    @vf()
    def bad_mismatch(out: Tensor):
        a = Reg(DT.int)
        b = Reg(DT.int16)
        c = Reg(DT.int)
        shiftr(c, a, b)  # dst/src/shift dtypes must match

    with pytest.raises((TypeError, ValueError)):
        bad_mismatch(Tensor(DT.int, [1, 64], Position.UB))

    @vf()
    def bad_unsigned(out: Tensor):
        a = Reg(DT.uint32)
        b = Reg(DT.uint32)
        c = Reg(DT.uint32)
        # C310 asserts SupportType<ActualU, int8_t, int16_t, int32_t, int64_t>
        # on the reg-reg shift amount, so the whole op is signed-only.
        shiftr(c, a, b)

    with pytest.raises(TypeError):
        bad_unsigned(Tensor(DT.uint32, [1, 64], Position.UB))


def test_micro_unsqueeze_emits_unsqueeze() -> None:
    @vf()
    def unsq(x: Tensor, out: Tensor):
        r = Reg(DT.int)
        r <<= x[0]
        unsqueeze(r)  # default mask -> ALL; in-place exclusive prefix-sum of the mask
        out[0] <<= r

    unsq(Tensor(DT.int, [1, 64], Position.UB), Tensor(DT.int, [1, 64], Position.UB))
    code = translate(unsq.instructions)
    assert re.search(r"MicroAPI::Unsqueeze\(r, ", code)


def test_micro_gatherb_emits_gatherb_and_gates() -> None:
    @vf()
    def gb(src: Tensor, idx: Tensor, out: Tensor):
        i = Reg(DT.uint32)
        i <<= idx[0]
        d = Reg(DT.int)
        ub_to_reg_gatherb(d, src, i)  # 32B-block gather, byte offset per out-block from lane i
        out[0] <<= d

    gb(Tensor(DT.int, [1, 128], Position.UB), Tensor(DT.uint32, [1, 64], Position.UB),
       Tensor(DT.int, [1, 64], Position.UB))
    assert "MicroAPI::GatherB(" in translate(gb.instructions)

    @vf()
    def bad_idx(src: Tensor, out: Tensor):
        i = Reg(DT.int)   # index must be uint32
        d = Reg(DT.int)
        ub_to_reg_gatherb(d, src, i)

    with pytest.raises((TypeError, ValueError)):
        bad_idx(Tensor(DT.int, [1, 128], Position.UB), Tensor(DT.int, [1, 64], Position.UB))

    @vf()
    def bad_width(src: Tensor, out: Tensor):
        i = Reg(DT.uint32)
        d = Reg(DT.int)   # dst(b32)/src(b8) byte width must match for a 32B block gather
        ub_to_reg_gatherb(d, src, i)

    with pytest.raises((TypeError, ValueError)):
        bad_width(Tensor(DT.int8, [1, 128], Position.UB), Tensor(DT.int, [1, 64], Position.UB))


def test_micro_mask_ub_emits_maskreg_loadalign_storealign() -> None:
    @vf()
    def mub(pat: Tensor, ub: Tensor, sel: Tensor):
        r = Reg(DT.int, name="mr")
        r <<= pat[0]
        z = Reg(DT.int, name="mz")
        dup(z, 0)
        m1 = MaskReg(DT.int, name="mm1")
        compare(m1, r, z, CompareMode.GT)
        mask_to_ub(ub, m1)          # StoreAlign(ub, m1) -- MaskReg overload, no dist template
        m2 = MaskReg(DT.int, name="mm2")
        ub_to_mask(m2, ub)          # LoadAlign(m2, ub) -- MaskReg overload
        seven = Reg(DT.int, name="ms"); dup(seven, 7)
        zr = Reg(DT.int, name="mzr"); dup(zr, 0)
        outr = Reg(DT.int, name="mo")
        select(outr, seven, zr, m2)
        sel[0] <<= outr

    mub(Tensor(DT.int, [1, 64], Position.UB), Tensor(DT.uint8, [1, 256], Position.UB),
        Tensor(DT.int, [1, 64], Position.UB))
    code = translate(mub.instructions)
    # MaskReg overloads carry no <T, Dist> template args (contrast the reg LoadAlign/StoreAlign):
    # StoreAlign(ub, mask) with dst first + mask second, LoadAlign(mask, ub) with mask first.
    assert re.search(r"MicroAPI::StoreAlign\(\w+, mm1\);", code)
    assert re.search(r"MicroAPI::LoadAlign\(mm2, \w+\);", code)


def test_micro_updatemask_passes_named_counter_by_reference() -> None:
    @vf()
    def named_counter(out: Tensor):
        mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="named_mask")
        remaining = Var(70, dtype=DT.uint32, name="remaining")
        update_mask(mask, remaining)

    named_counter(Tensor(DT.float, [1, 64], Position.UB))
    code = translate(named_counter.instructions)

    assert "named_mask = MicroAPI::UpdateMask<float>(remaining);" in code
    assert "_update_mask_cnt" not in code


def test_micro_updatemask_materializes_folded_temporary_counter() -> None:
    @vf()
    def temporary_counter(out: Tensor, valid: Var):
        mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="temporary_mask")
        update_mask(mask, Var(Min(valid, 64), dtype=DT.uint32))

    temporary_counter(
        Tensor(DT.float, [1, 64], Position.UB),
        Var(value=None, dtype=DT.uint32, name="valid"),
    )
    code = translate(temporary_counter.instructions)

    assert "uint32_t _update_mask_cnt = (uint32_t)(" in code
    assert "temporary_mask = MicroAPI::UpdateMask<float>(_update_mask_cnt);" in code


def test_micro_move_mask_spr_emits_movemask() -> None:
    @vf()
    def mm(out: Tensor):
        m = MaskReg(DT.int, name="mmspr")
        move_mask_spr(m)          # m = MoveMask<int>() -- read the vector-mask SPR
        seven = Reg(DT.int, name="sv"); dup(seven, 7)
        zr = Reg(DT.int, name="zr"); dup(zr, 0)
        o = Reg(DT.int, name="mo"); dup(o, 0)
        select(o, seven, zr, m)
        out[0] <<= o

    mm(Tensor(DT.int, [1, 64], Position.UB))
    code = translate(mm.instructions)
    assert re.search(r"mmspr = MicroAPI::MoveMask<int>\(\);", code)
