import pytest
import torch

from easyasc.a5 import E8M0_MIN_VALUE, e8m0_to_fp32, fp32_to_e8m0


def test_e8m0_to_fp32_decodes_power_of_two_scale_bytes() -> None:
    codes = torch.tensor([0, 126, 127, 128], dtype=torch.uint8)
    decoded = e8m0_to_fp32(codes)

    torch.testing.assert_close(
        decoded,
        torch.tensor([E8M0_MIN_VALUE, 0.5, 1.0, 2.0], dtype=torch.float32),
        rtol=0,
        atol=0,
    )


def test_fp32_to_e8m0_floors_exponent_and_saturates() -> None:
    values = torch.tensor([0.0, E8M0_MIN_VALUE, 1.0, 1.4, 1.5, 2.0, float("inf")], dtype=torch.float32)
    encoded = fp32_to_e8m0(values)

    torch.testing.assert_close(
        encoded,
        torch.tensor([0, 0, 127, 127, 127, 128, 255], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )


def test_fp32_to_e8m0_rejects_negative_and_nan_by_default() -> None:
    with pytest.raises(ValueError, match="non-negative scale values"):
        fp32_to_e8m0(torch.tensor([-1.0], dtype=torch.float32))

    with pytest.raises(ValueError, match="e8m0 has no NaN payload"):
        fp32_to_e8m0(torch.tensor([float("nan")], dtype=torch.float32))

    torch.testing.assert_close(
        fp32_to_e8m0(torch.tensor([float("nan")], dtype=torch.float32), nan_to_zero=True),
        torch.tensor([0], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )
