"""Robustness coverage for vec mask-mode (count / normal / count_per_rep) across
control flow (if / elif / else / loop / nesting).

Two layers:

* Emission tests drive the stub helpers under a fake b3 kernel and assert the exact
  emitted instruction sequence. They pin the fix mechanism directly:
    - `SetMaskCount()` is emitted before *every* counted op (not lazily once), so the
      switch can never land in a dead arm (`easyasc/stub_functions/vec/vecutils.py`).
    - an `if/elif/else` arm that *itself* switches into count mode emits a
      `set_mask_normal` + `reset_mask` at arm exit, so count mode does not leak past the
      construct (`easyasc/flowcontrol.py`); the reset is suppressed when count mode was
      already active at arm entry (the external/straight-line reset owns that case).

* Simulator value tests build real kernels, place count / normal / count_per_rep ops in
  nested control flow, and assert the full stored tile against a torch reference. They
  are designed to be value-observable: the counted op covers only `[0:valid]` while the
  whole tile is stored, so a missing/leaked mask-mode switch changes the stored bytes the
  simulator can see. (Verified to fail against the pre-fix lowering.)
"""

import builtins
from types import SimpleNamespace

import torch

from easyasc import globvars
from easyasc.a2 import *
from easyasc.flowcontrol import If, Elif, Else
from easyasc.flowcontrol import range as dsl_range


# --------------------------------------------------------------------------------------
# Emission tests (fake kernel, assert emitted instruction stream)
# --------------------------------------------------------------------------------------

_MASK_OPS = frozenset({
    "set_mask_count", "set_mask_counter", "set_mask_normal", "reset_mask",
    "set_mask_by_count", "adds",
    "start_if", "start_elif", "start_else", "end_if", "start_loop", "end_loop",
})


def _drive(body) -> list:
    """Install a fake b3 kernel, run body(), return the mask-relevant opname stream."""
    prev_kernel = globvars.active_kernel
    prev_micro = globvars.active_micro
    prev_device = globvars.device_type
    fake = SimpleNamespace(instructions=[], vector_mode="repeat")
    try:
        globvars.device_type = "b3"
        globvars.active_micro = None
        globvars.active_kernel = fake
        body()
        return [i.opname for i in fake.instructions if i.opname in _MASK_OPS]
    finally:
        globvars.active_kernel = prev_kernel
        globvars.active_micro = prev_micro
        globvars.device_type = prev_device


def _ub_pair():
    a = Tensor(DT.float, [1, 64], Position.UB, name="a")
    b = Tensor(DT.float, [1, 64], Position.UB, name="b")
    return a, b


def test_emit_count_in_if_else_both_arms_get_switch_and_exit_reset() -> None:
    def body():
        a, b = _ub_pair()
        with If(False):
            adds(b, a, 0.0, count=8)
        with Else():
            adds(b, a, 0.0, count=8)

    arm = ["set_mask_count", "set_mask_counter", "adds", "set_mask_normal", "reset_mask"]
    assert _drive(body) == (
        ["start_if"] + arm + ["start_else"] + arm + ["end_if"]
    )


def test_emit_count_in_if_elif_else_all_arms_get_switch_and_exit_reset() -> None:
    def body():
        a, b = _ub_pair()
        with If(False):
            adds(b, a, 0.0, count=8)
        with Elif(False):
            adds(b, a, 0.0, count=8)
        with Else():
            adds(b, a, 0.0, count=8)

    arm = ["set_mask_count", "set_mask_counter", "adds", "set_mask_normal", "reset_mask"]
    assert _drive(body) == (
        ["start_if"] + arm + ["start_elif"] + arm + ["start_else"] + arm + ["end_if"]
    )


def test_emit_count_active_before_construct_suppresses_exit_reset() -> None:
    # Count mode entered *before* the if/else (leaked in). The arms must still get their
    # own SetMaskCount (always-emit), but the branch-exit reset must NOT fire -- the
    # external straight-line reset (which runs on all paths) owns this case.
    def body():
        a, b = _ub_pair()
        adds(b, a, 0.0, count=8)          # straight-line: enters count mode
        with If(False):
            adds(b, a, 0.0, count=8)
        with Else():
            adds(b, a, 0.0, count=8)

    arm = ["set_mask_count", "set_mask_counter", "adds"]      # no exit reset
    assert _drive(body) == (
        ["set_mask_count", "set_mask_counter", "adds"]        # the pre-construct count op
        + ["start_if"] + arm + ["start_else"] + arm + ["end_if"]
    )


def test_emit_nested_if_inner_arm_resets_outer_stays_clean() -> None:
    def body():
        a, b = _ub_pair()
        with If(True):
            with If(False):
                adds(b, a, 0.0, count=8)
            with Else():
                adds(b, a, 0.0, count=8)
            # back in the outer arm, mask mode is normal again (inner arms reset it),
            # so the outer arm adds no further reset of its own.

    inner_arm = ["set_mask_count", "set_mask_counter", "adds", "set_mask_normal", "reset_mask"]
    assert _drive(body) == (
        ["start_if"]
        + ["start_if"] + inner_arm + ["start_else"] + inner_arm + ["end_if"]
        + ["end_if"]
    )


def test_emit_count_normal_count_per_rep_alternation_switches() -> None:
    def body():
        a, b = _ub_pair()
        adds(b, a, 0.0, count=8)            # repeat -> count
        adds(b, a, 0.0)                     # count -> normal
        adds(b, a, 0.0, count_per_rep=8)    # normal + by-count mask (+ trailing reset)

    assert _drive(body) == [
        "set_mask_count", "set_mask_counter", "adds",      # count
        "set_mask_normal", "reset_mask", "adds",           # normal (count->repeat reset)
        "set_mask_by_count", "adds", "reset_mask",         # count_per_rep (+ auto reset)
    ]


def test_explicit_set_mask_normal_is_available_from_a2() -> None:
    assert _drive(set_mask_normal) == ["set_mask_normal"]


def test_explicit_set_mask_by_count_is_available_from_a2() -> None:
    def body():
        set_mask_by_count(17)

    assert _drive(body) == ["set_mask_by_count"]


def test_emit_count_in_loop_switch_inside_body_reset_once_after_loop() -> None:
    def body():
        a, b = _ub_pair()
        for _ in dsl_range(0, 2):
            adds(b, a, 0.0, count=8)

    # SetMaskCount inside the loop body (re-runs each iteration), and a single
    # count->normal reset emitted *after* end_loop (outside the loop, not per-iteration)
    # so count mode does not leak past the loop.
    assert _drive(body) == [
        "start_loop",
        "set_mask_count", "set_mask_counter", "adds",
        "end_loop",
        "set_mask_normal", "reset_mask",
    ]


def test_emit_loop_with_count_active_before_suppresses_post_loop_reset() -> None:
    # Count active before the loop (leaked in) -> the post-loop reset is suppressed; the
    # external straight-line reset owns that case (same guard as if/elif/else arms).
    def body():
        a, b = _ub_pair()
        adds(b, a, 0.0, count=8)          # straight-line: enters count mode
        for _ in dsl_range(0, 2):
            adds(b, a, 0.0, count=8)

    assert _drive(body) == [
        "set_mask_count", "set_mask_counter", "adds",     # pre-loop count op
        "start_loop",
        "set_mask_count", "set_mask_counter", "adds",     # loop body
        "end_loop",                                       # no post-loop reset
    ]


# --------------------------------------------------------------------------------------
# Simulator value tests (build kernels, assert stored tile vs torch reference)
# --------------------------------------------------------------------------------------

TILE = 256
WINDOW = 64          # fp32 per-repeat element window
SENTINEL = -7.0      # prefill marker; distinct from any src+const result (src >= 1)


def _rand_row(seed: int) -> torch.Tensor:
    g = torch.Generator().manual_seed(seed)
    return (torch.rand((1, TILE), generator=g, dtype=torch.float32) + 1.0).contiguous()


def _ref_count(src: torch.Tensor, val: float, valid: int) -> torch.Tensor:
    y = torch.full((1, TILE), SENTINEL, dtype=torch.float32)
    y[0, :valid] = src[0, :valid] + val
    return y


def _ref_normal(src: torch.Tensor, val: float) -> torch.Tensor:
    return (src + val).clone()


def _ref_cpr(src: torch.Tensor, val: float, cpr: int) -> torch.Tensor:
    y = torch.full((1, TILE), SENTINEL, dtype=torch.float32)
    for w in builtins.range(0, TILE, WINDOW):
        y[0, w:w + cpr] = src[0, w:w + cpr] + val
    return y


@kernel()
def _k_count_if_false_else(src: GMTensor, out: GMTensor, valid: Var):
    st = Tensor(DT.float, [1, TILE], Position.UB)
    ot = Tensor(DT.float, [1, TILE], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            dup(ot, SENTINEL)
            st[0:1, 0:TILE] <<= src[0:1, 0:TILE]
            with If(False):
                adds(ot, st, 5.0, count=valid)
            with Else():
                adds(ot, st, 5.0, count=valid)
            out[0:1, 0:TILE] <<= ot[0:1, 0:TILE]
    return out


def test_sim_count_in_if_false_else_branch() -> None:
    src = _rand_row(1)
    out = torch.empty((1, TILE), dtype=torch.float32)
    got = OpExec(_k_count_if_false_else, simulator=True)(src, out, 100)
    torch.testing.assert_close(got, _ref_count(src, 5.0, 100), rtol=0, atol=0)


@kernel()
def _k_count_if_elif_else(src: GMTensor, out: GMTensor, valid: Var, c1: Var, c2: Var):
    st = Tensor(DT.float, [1, TILE], Position.UB)
    ot = Tensor(DT.float, [1, TILE], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            dup(ot, SENTINEL)
            st[0:1, 0:TILE] <<= src[0:1, 0:TILE]
            if c1 == 1:
                adds(ot, st, 1.0, count=valid)
            elif c2 == 1:
                adds(ot, st, 2.0, count=valid)
            else:
                adds(ot, st, 3.0, count=valid)
            out[0:1, 0:TILE] <<= ot[0:1, 0:TILE]
    return out


def test_sim_count_in_elif_arm_taken() -> None:
    src = _rand_row(2)
    out = torch.empty((1, TILE), dtype=torch.float32)
    got = OpExec(_k_count_if_elif_else, simulator=True)(src, out, 100, 0, 1)  # elif taken
    torch.testing.assert_close(got, _ref_count(src, 2.0, 100), rtol=0, atol=0)


def test_sim_count_in_else_arm_taken() -> None:
    src = _rand_row(3)
    out = torch.empty((1, TILE), dtype=torch.float32)
    got = OpExec(_k_count_if_elif_else, simulator=True)(src, out, 100, 0, 0)  # else taken
    torch.testing.assert_close(got, _ref_count(src, 3.0, 100), rtol=0, atol=0)


@kernel()
def _k_count_if_inside_for(src: GMTensor, out: GMTensor, valid: Var, take_else: Var):
    NITER = 2
    st = Tensor(DT.float, [1, TILE], Position.UB)
    ot = Tensor(DT.float, [1, TILE], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            for i in range(0, NITER):
                base = Var(i * TILE)
                dup(ot, SENTINEL)
                st[0:1, 0:TILE] <<= src[0:1, base:base + TILE]
                if take_else == 1:
                    adds(ot, st, 4.0, count=valid)   # source-order-first, untaken
                else:
                    adds(ot, st, 4.0, count=valid)   # taken: must still get SetMaskCount
                out[0:1, base:base + TILE] <<= ot[0:1, 0:TILE]
    return out


def test_sim_count_if_inside_loop_multi_iter() -> None:
    NITER = 2
    src = torch.cat([_rand_row(10), _rand_row(11)], dim=1)   # [1, 2*TILE]
    out = torch.empty((1, NITER * TILE), dtype=torch.float32)
    got = OpExec(_k_count_if_inside_for, simulator=True)(src, out, 100, 0)  # else taken
    ref = torch.empty((1, NITER * TILE), dtype=torch.float32)
    for i in builtins.range(NITER):
        tile = src[:, i * TILE:(i + 1) * TILE]
        ref[:, i * TILE:(i + 1) * TILE] = _ref_count(tile, 4.0, 100)
    torch.testing.assert_close(got, ref, rtol=0, atol=0)


@kernel()
def _k_loop_inside_if(src: GMTensor, out: GMTensor, valid: Var):
    NITER = 2
    st = Tensor(DT.float, [1, TILE], Position.UB)
    ot = Tensor(DT.float, [1, TILE], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            with If(True):
                for i in range(0, NITER):
                    base = Var(i * TILE)
                    dup(ot, SENTINEL)
                    st[0:1, 0:TILE] <<= src[0:1, base:base + TILE]
                    adds(ot, st, 6.0, count=valid)
                    out[0:1, base:base + TILE] <<= ot[0:1, 0:TILE]
    return out


def test_sim_loop_inside_if() -> None:
    NITER = 2
    src = torch.cat([_rand_row(20), _rand_row(21)], dim=1)
    out = torch.empty((1, NITER * TILE), dtype=torch.float32)
    got = OpExec(_k_loop_inside_if, simulator=True)(src, out, 100)
    ref = torch.empty((1, NITER * TILE), dtype=torch.float32)
    for i in builtins.range(NITER):
        tile = src[:, i * TILE:(i + 1) * TILE]
        ref[:, i * TILE:(i + 1) * TILE] = _ref_count(tile, 6.0, 100)
    torch.testing.assert_close(got, ref, rtol=0, atol=0)


@kernel()
def _k_alternation(srcA: GMTensor, srcB: GMTensor, srcC: GMTensor,
                   outA: GMTensor, outB: GMTensor, outC: GMTensor,
                   valid: Var, cpr: Var):
    sA = Tensor(DT.float, [1, TILE], Position.UB)
    sB = Tensor(DT.float, [1, TILE], Position.UB)
    sC = Tensor(DT.float, [1, TILE], Position.UB)
    oA = Tensor(DT.float, [1, TILE], Position.UB)
    oB = Tensor(DT.float, [1, TILE], Position.UB)
    oC = Tensor(DT.float, [1, TILE], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            dup(oA, SENTINEL)
            dup(oB, SENTINEL)
            dup(oC, SENTINEL)
            sA[0:1, 0:TILE] <<= srcA[0:1, 0:TILE]
            sB[0:1, 0:TILE] <<= srcB[0:1, 0:TILE]
            sC[0:1, 0:TILE] <<= srcC[0:1, 0:TILE]
            # count (in a branch) -> normal -> count_per_rep (in a branch)
            with If(True):
                adds(oA, sA, 1.0, count=valid)
            adds(oB, sB, 2.0)
            with If(True):
                adds(oC, sC, 3.0, count_per_rep=cpr)
            outA[0:1, 0:TILE] <<= oA[0:1, 0:TILE]
            outB[0:1, 0:TILE] <<= oB[0:1, 0:TILE]
            outC[0:1, 0:TILE] <<= oC[0:1, 0:TILE]
    return outA, outB, outC


def test_sim_count_normal_count_per_rep_alternation() -> None:
    srcA, srcB, srcC = _rand_row(30), _rand_row(31), _rand_row(32)
    outA = torch.empty((1, TILE), dtype=torch.float32)
    outB = torch.empty((1, TILE), dtype=torch.float32)
    outC = torch.empty((1, TILE), dtype=torch.float32)
    gotA, gotB, gotC = OpExec(_k_alternation, simulator=True)(
        srcA, srcB, srcC, outA, outB, outC, 100, 40
    )
    torch.testing.assert_close(gotA, _ref_count(srcA, 1.0, 100), rtol=0, atol=0)
    torch.testing.assert_close(gotB, _ref_normal(srcB, 2.0), rtol=0, atol=0)
    torch.testing.assert_close(gotC, _ref_cpr(srcC, 3.0, 40), rtol=0, atol=0)


@kernel()
def _k_leak_into_external_normal(srcA: GMTensor, srcC: GMTensor,
                                 outA: GMTensor, outB: GMTensor, outC: GMTensor,
                                 valid: Var, ca: Var, cb: Var):
    # ca=1, cb=0: the count arm runs (enters count mode); the normal arm in `cb` is
    # skipped (its lazy reset never runs); the external normal op must still process the
    # FULL tile -> only correct if count mode was reset at the count arm's exit.
    sA = Tensor(DT.float, [1, TILE], Position.UB)
    sC = Tensor(DT.float, [1, TILE], Position.UB)
    oA = Tensor(DT.float, [1, TILE], Position.UB)
    oB = Tensor(DT.float, [1, TILE], Position.UB)
    oC = Tensor(DT.float, [1, TILE], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            dup(oA, SENTINEL)
            dup(oB, SENTINEL)
            dup(oC, SENTINEL)
            sA[0:1, 0:TILE] <<= srcA[0:1, 0:TILE]
            sC[0:1, 0:TILE] <<= srcC[0:1, 0:TILE]
            if ca == 1:
                adds(oA, sA, 1.0, count=valid)
            if cb == 1:
                adds(oB, sA, 2.0)            # skipped at runtime (cb=0)
            adds(oC, sC, 9.0)               # external normal op: must cover full tile
            outA[0:1, 0:TILE] <<= oA[0:1, 0:TILE]
            outB[0:1, 0:TILE] <<= oB[0:1, 0:TILE]
            outC[0:1, 0:TILE] <<= oC[0:1, 0:TILE]
    return outA, outB, outC


def test_sim_count_arm_does_not_leak_into_external_normal_op() -> None:
    srcA, srcC = _rand_row(40), _rand_row(41)
    outA = torch.empty((1, TILE), dtype=torch.float32)
    outB = torch.empty((1, TILE), dtype=torch.float32)
    outC = torch.empty((1, TILE), dtype=torch.float32)
    gotA, gotB, gotC = OpExec(_k_leak_into_external_normal, simulator=True)(
        srcA, srcC, outA, outB, outC, 100, 1, 0
    )
    torch.testing.assert_close(gotA, _ref_count(srcA, 1.0, 100), rtol=0, atol=0)
    torch.testing.assert_close(gotB, torch.full((1, TILE), SENTINEL), rtol=0, atol=0)
    # the load-bearing assertion: external normal op covered the whole tile
    torch.testing.assert_close(gotC, _ref_normal(srcC, 9.0), rtol=0, atol=0)


@kernel()
def _k_loop_leak_into_external_normal(srcA: GMTensor, srcC: GMTensor,
                                      outA: GMTensor, outC: GMTensor,
                                      valid: Var, cb: Var):
    # count op in a loop body (enters count mode); a normal op guarded by cb (=0,
    # skipped, so its lazy reset never runs); then an external straight-line normal op
    # that must cover the FULL tile -> only correct if count mode is reset after the loop.
    NITER = 2
    sA = Tensor(DT.float, [1, TILE], Position.UB)
    sC = Tensor(DT.float, [1, TILE], Position.UB)
    oA = Tensor(DT.float, [1, TILE], Position.UB)
    oB = Tensor(DT.float, [1, TILE], Position.UB)
    oC = Tensor(DT.float, [1, TILE], Position.UB)
    if GetVecIdx() == 0:
        with auto_sync():
            dup(oA, SENTINEL)
            dup(oB, SENTINEL)
            dup(oC, SENTINEL)
            sA[0:1, 0:TILE] <<= srcA[0:1, 0:TILE]
            sC[0:1, 0:TILE] <<= srcC[0:1, 0:TILE]
            for _ in range(0, NITER):
                adds(oA, sA, 1.0, count=valid)
            if cb == 1:
                adds(oB, sA, 2.0)            # skipped at runtime (cb=0)
            adds(oC, sC, 9.0)               # external normal op: must cover full tile
            outA[0:1, 0:TILE] <<= oA[0:1, 0:TILE]
            outC[0:1, 0:TILE] <<= oC[0:1, 0:TILE]
    return outA, outC


def test_sim_count_loop_does_not_leak_into_external_normal_op() -> None:
    srcA, srcC = _rand_row(50), _rand_row(51)
    outA = torch.empty((1, TILE), dtype=torch.float32)
    outC = torch.empty((1, TILE), dtype=torch.float32)
    gotA, gotC = OpExec(_k_loop_leak_into_external_normal, simulator=True)(
        srcA, srcC, outA, outC, 100, 0
    )
    torch.testing.assert_close(gotA, _ref_count(srcA, 1.0, 100), rtol=0, atol=0)
    # the load-bearing assertion: count mode did not leak past the loop
    torch.testing.assert_close(gotC, _ref_normal(srcC, 9.0), rtol=0, atol=0)
