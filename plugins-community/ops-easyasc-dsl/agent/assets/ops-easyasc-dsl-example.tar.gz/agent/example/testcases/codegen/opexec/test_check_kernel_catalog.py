import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[5]
SCRIPT = ROOT / "agent" / "scripts" / "check_kernel_catalog.py"
BUILD_SCRIPT = ROOT / "agent" / "scripts" / "build_agent_index.py"


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _write_repo(tmp_path: Path, catalog_text: str, kernel_files=None, index_entries=None):
    kernel_files = kernel_files or []
    (tmp_path / "agent" / "references" / "examples").mkdir(parents=True, exist_ok=True)
    (tmp_path / "agent" / "index").mkdir(parents=True, exist_ok=True)
    (tmp_path / "agent" / "example" / "kernels").mkdir(parents=True, exist_ok=True)
    (tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md").write_text(catalog_text, encoding="utf-8")
    for rel_path in kernel_files:
        target = tmp_path / rel_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("@kernel()\ndef test_kernel():\n    pass\n", encoding="utf-8")
    if index_entries is not None:
        payload = {
            "schema_version": 1,
            "generated_by": "agent/scripts/build_agent_index.py",
            "source": "agent/references/examples/kernel-catalog.md",
            "entry_count": len(index_entries),
            "entries": index_entries,
        }
        (tmp_path / "agent" / "index" / "kernels.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


GOOD_CATALOG = """# Kernel Catalog

## Baselines

### `agent/example/kernels/a.py`
- formula: `z = x @ y.t()`
- topology: `cube-only`
- study_for:
  - baseline
- do_not_copy_when:
  - mixed pipeline

### `agent/example/kernels/b.py`
- formula: `z = abs(x @ y.t()) + 1`
- topology: `cube->vec`
- study_for:
  - mixed baseline
- do_not_copy_when:
  - pure cube
"""


BAD_CATALOG = """# Kernel Catalog

## Baselines

### `agent/example/kernels/a.py`
- formula: `z = x @ y.t()`
- topology: `cube-only`
- study_for:
  - baseline

### `agent/example/kernels/missing.py`
- formula: `z = x @ y.t()`
- topology: `cube-only`
- study_for:
  - missing file example
- do_not_copy_when:
  - none
"""


def test_checker_accepts_consistent_catalog_repo(tmp_path: Path) -> None:
    build_mod = _load_module(BUILD_SCRIPT, "build_index_mod")
    checker_mod = _load_module(SCRIPT, "check_kernel_catalog_mod")
    _write_repo(tmp_path, GOOD_CATALOG, kernel_files=["agent/example/kernels/a.py", "agent/example/kernels/b.py"])
    payload = build_mod.parse_catalog(tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md", kind="kernel", root=tmp_path)
    (tmp_path / "agent" / "index" / "kernels.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    result = checker_mod.analyze_repo(
        root=tmp_path,
        catalog_path=tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md",
        index_path=tmp_path / "agent" / "index" / "kernels.json",
        kernel_dir=tmp_path / "agent" / "example" / "kernels",
    )
    assert result["warning_count"] == 0



def test_checker_flags_missing_field_missing_file_and_uncataloged_kernel(tmp_path: Path) -> None:
    checker_mod = _load_module(SCRIPT, "check_kernel_catalog_mod_bad")
    _write_repo(tmp_path, BAD_CATALOG, kernel_files=["agent/example/kernels/a.py", "agent/example/kernels/extra.py"])

    result = checker_mod.analyze_repo(
        root=tmp_path,
        catalog_path=tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md",
        index_path=tmp_path / "agent" / "index" / "kernels.json",
        kernel_dir=tmp_path / "agent" / "example" / "kernels",
    )
    warning_codes = {item["code"] for item in result["warnings"]}
    assert "missing-field" in warning_codes
    assert "missing-file" in warning_codes
    assert "uncataloged-kernel" in warning_codes
    assert "missing-index" in warning_codes



def test_checker_flags_stale_index(tmp_path: Path) -> None:
    checker_mod = _load_module(SCRIPT, "check_kernel_catalog_mod_stale")
    _write_repo(
        tmp_path,
        GOOD_CATALOG,
        kernel_files=["agent/example/kernels/a.py", "agent/example/kernels/b.py"],
        index_entries=[
            {
                "kind": "kernel",
                "path": "agent/example/kernels/a.py",
                "category": "Baselines",
                "formula": "z = x @ y.t()",
                "topology": "cube-only",
                "study_for": ["baseline"],
                "do_not_copy_when": ["mixed pipeline"],
                "name": "a.py",
                "order": 0,
            }
        ],
    )

    result = checker_mod.analyze_repo(
        root=tmp_path,
        catalog_path=tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md",
        index_path=tmp_path / "agent" / "index" / "kernels.json",
        kernel_dir=tmp_path / "agent" / "example" / "kernels",
    )
    warning_codes = {item["code"] for item in result["warnings"]}
    assert "stale-index" in warning_codes


def test_checker_flags_ub_second_dim_one_guardrail(tmp_path: Path) -> None:
    build_mod = _load_module(BUILD_SCRIPT, "build_index_mod_guardrail")
    checker_mod = _load_module(SCRIPT, "check_kernel_catalog_mod_guardrail")
    _write_repo(tmp_path, GOOD_CATALOG, kernel_files=["agent/example/kernels/a.py", "agent/example/kernels/b.py", "agent/example/kernels/a2/bad.py"])
    (tmp_path / "agent" / "example" / "kernels" / "a2" / "bad.py").write_text(
        """from easyasc.a2 import *

HALF_M = 64
SCALAR_COLS = 1


@kernel()
def bad_scalar_layout(x: GMTensor, out: GMTensor, M: Var):
    bad = Tensor(DT.float, [HALF_M, SCALAR_COLS], Position.UB)
    out[0:M] <<= x[0:M]
    return out
""",
        encoding="utf-8",
    )
    (tmp_path / "agent" / "example" / "kernels" / "b.py").write_text(
        """from easyasc.a2 import *

HALF_M = 64


@kernel()
def good_scalar_layout(x: GMTensor, out: GMTensor, M: Var):
    good = Tensor(DT.float, [1, HALF_M], Position.UB)
    lanes = Tensor(DT.float, [HALF_M, 8], Position.UB)
    out[0:M] <<= x[0:M]
    return out
""",
        encoding="utf-8",
    )
    payload = build_mod.parse_catalog(tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md", kind="kernel", root=tmp_path)
    (tmp_path / "agent" / "index" / "kernels.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    result = checker_mod.analyze_repo(
        root=tmp_path,
        catalog_path=tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md",
        index_path=tmp_path / "agent" / "index" / "kernels.json",
        kernel_dir=tmp_path / "agent" / "example" / "kernels",
    )

    warnings = result["warnings"]
    assert [item["code"] for item in warnings] == [
        "uncataloged-kernel",
        "ub-second-dim-one",
    ]
    ub_warning = warnings[1]
    assert ub_warning["path"] == "agent/example/kernels/a2/bad.py"
    assert ub_warning["line"] == 9


def test_checker_rejects_invalid_and_mismatched_target_metadata(tmp_path: Path) -> None:
    build_mod = _load_module(BUILD_SCRIPT, "build_index_mod_targets")
    checker_mod = _load_module(SCRIPT, "check_kernel_catalog_mod_targets")
    catalog = """# Kernel Catalog

## Baselines

### `agent/example/kernels/a5/invalid.py`
- targets:
  - unknown
- formula: identity
- topology: `vec-only`
- study_for:
  - target validation
- do_not_copy_when:
  - never

### `agent/example/kernels/a5/a5pr_only.py`
- targets:
  - a5
- formula: identity
- topology: `vec-only`
- study_for:
  - target validation
- do_not_copy_when:
  - never
"""
    _write_repo(
        tmp_path, catalog,
        kernel_files=["agent/example/kernels/a5/invalid.py", "agent/example/kernels/a5/a5pr_only.py"],
    )
    (tmp_path / "agent" / "example" / "kernels" / "a5" / "a5pr_only.py").write_text(
        "from easyasc.a5pr import *\n\n@kernel()\ndef test_kernel():\n    pass\n",
        encoding="utf-8",
    )
    payload = build_mod.parse_catalog(
        tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md",
        kind="kernel", root=tmp_path,
    )
    (tmp_path / "agent" / "index" / "kernels.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )

    result = checker_mod.analyze_repo(
        root=tmp_path,
        catalog_path=tmp_path / "agent" / "references" / "examples" / "kernel-catalog.md",
        index_path=tmp_path / "agent" / "index" / "kernels.json",
        kernel_dir=tmp_path / "agent" / "example" / "kernels",
    )
    assert {item["code"] for item in result["warnings"]} == {
        "malformed-targets", "target-metadata",
    }
