"""Simulator regression for the MaskReg<->UB overloads: ``mask_to_ub`` (StoreAlign) and
``ub_to_mask`` (LoadAlign).

Board-verified 2026-07-21 (kernels/a5/vec_only/mask_probe.py): the A5 vector mask is a
byte-granular 256-bit (32-byte) register. StoreAlign always emits the full 32 bytes; a mask
whose element size is S bytes places element-lane i's bit at bit position i*S (LSB-first),
leaving the in-between bits (for S>1) and inactive lanes zero. LoadAlign is the exact inverse.
"""
from types import SimpleNamespace

import pytest
import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime, VfBarrierWarning
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg

_STORE = SharedMemoryStore()

# (easyasc dtype, element size S, lane count VL = 256 / S)
_DTYPES = [(DT.int8, 1, 256), (DT.int16, 2, 128), (DT.int, 4, 64), (DT.int64, 8, 32)]
_CANDIDATE_LANES = (0, 1, 3, 7, 15, 31, 63, 127, 255)


def _run(ops, masks, tensor_views):
    rt = MicroRuntime()
    # tensor_views is intentionally NOT cloned: a store must write back into the caller's tensor.
    ctx = MicroContext(masks={k: v.clone() for k, v in masks.items()}, tensor_views=tensor_views)
    rt._stack.append(ctx)
    try:
        for op, kw in ops:
            rt._dispatch(op, kw, _STORE)
    finally:
        rt._stack.pop()
    return ctx


def _active_for(vl):
    return [i for i in _CANDIDATE_LANES if i < vl]


def _expected_bytes(active, s):
    b = [0] * 32
    for lane in active:
        pos = lane * s
        b[pos // 8] |= 1 << (pos % 8)
    return b


def _bits(active, vl):
    t = torch.zeros(vl, dtype=torch.bool)
    for i in active:
        t[i] = True
    return t


@pytest.mark.parametrize("dt,s,vl", _DTYPES)
def test_mask_to_ub_packing(dt, s, vl):
    active = _active_for(vl)
    ub = torch.zeros(64, dtype=torch.uint8)  # 64 bytes, larger than the 32-byte mask register
    m = MaskReg(dt, init_mode=MaskType.NONE, name="m")
    _run([("micro_mask_to_ub", {"dst": SimpleNamespace(name="ub"), "src": m})],
         {"m": _bits(active, vl)}, {"ub": ub})
    assert ub[:32].tolist() == _expected_bytes(active, s)
    assert int(ub[32:].to(torch.int64).abs().sum()) == 0  # exactly 32 bytes written


@pytest.mark.parametrize("dt,s,vl", _DTYPES)
def test_mask_ub_roundtrip(dt, s, vl):
    active = _active_for(vl)
    bits = _bits(active, vl)
    ub = torch.zeros(64, dtype=torch.uint8)
    m_in = MaskReg(dt, init_mode=MaskType.NONE, name="min")
    m_out = MaskReg(dt, init_mode=MaskType.NONE, name="mout")
    # store->load on the same UB is a genuine RAW hazard; the footprint tracker must flag the
    # missing vf_barrier(STORE, LOAD) (the on-board probe includes that barrier).
    with pytest.warns(VfBarrierWarning, match="store -> load"):
        ctx = _run(
            [
                ("micro_mask_to_ub", {"dst": SimpleNamespace(name="ub"), "src": m_in}),
                ("micro_ub_to_mask", {"dst": m_out, "src": SimpleNamespace(name="ub")}),
            ],
            {"min": bits}, {"ub": ub},
        )
    assert torch.equal(ctx.masks["mout"], bits)


def test_mask_to_ub_writes_through_nonbyte_ub_dtype():
    # StoreAlign emits raw bytes regardless of the UB tensor dtype: an int32 UB view must receive
    # the same 32 mask bytes at its base.
    active = _active_for(64)
    ub = torch.zeros(16, dtype=torch.int32)  # 64 bytes
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    _run([("micro_mask_to_ub", {"dst": SimpleNamespace(name="ub"), "src": m})],
         {"m": _bits(active, 64)}, {"ub": ub})
    got = ub.view(torch.uint8)[:32].tolist()
    assert got == _expected_bytes(active, 4)


def test_mask_to_ub_empty_mask_zeroes_32_bytes():
    ub = torch.full((64,), 0xFF, dtype=torch.uint8)  # pre-fill to see the 32-byte clear
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    _run([("micro_mask_to_ub", {"dst": SimpleNamespace(name="ub"), "src": m})],
         {"m": torch.zeros(64, dtype=torch.bool)}, {"ub": ub})
    assert ub[:32].tolist() == [0] * 32
    assert ub[32:].tolist() == [0xFF] * 32  # bytes past the mask register are untouched


def test_ub_to_mask_ignores_in_between_bits():
    # For a b32 mask only bits at i*4 are meaningful; setting an in-between bit (e.g. bit 1) must
    # NOT flip any lane. Byte0=0b00010011 has bit0 (lane0) + bit1 (noise) + bit4 (lane1).
    ub = torch.zeros(64, dtype=torch.uint8)
    ub[0] = 0b00010011
    m_out = MaskReg(DT.int, init_mode=MaskType.NONE, name="mout")
    ctx = _run([("micro_ub_to_mask", {"dst": m_out, "src": SimpleNamespace(name="ub")})],
               {}, {"ub": ub})
    want = torch.zeros(64, dtype=torch.bool)
    want[0] = want[1] = True  # bit0 -> lane0, bit4 -> lane1; bit1 ignored
    assert torch.equal(ctx.masks["mout"], want)


def test_mask_to_ub_rejects_undersized_ub():
    ub = torch.zeros(16, dtype=torch.uint8)  # only 16 bytes < 32
    m = MaskReg(DT.int, init_mode=MaskType.NONE, name="m")
    with pytest.raises(IndexError, match="fewer than 32 bytes"):
        _run([("micro_mask_to_ub", {"dst": SimpleNamespace(name="ub"), "src": m})],
             {"m": _bits(_active_for(64), 64)}, {"ub": ub})
