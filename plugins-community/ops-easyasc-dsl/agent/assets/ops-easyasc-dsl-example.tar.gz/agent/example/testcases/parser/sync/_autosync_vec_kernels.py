from easyasc.a5 import *

from testcases.parser.sync._autosync_test_helpers import TILES, WIDTH

@vf()
def double_row_vf(src: Tensor, dst: Tensor, n: Var):
    value = Reg(DT.half)
    for col in range(n):
        ub_to_reg_single(value, src[0:1, col:col + 1])
        value <<= value + value
        reg_to_ub_single(dst[0:1, col:col + 1], value)


@kernel()
def autosync_vec_roundtrip(x: GMTensor, y: GMTensor, tiles: Var, n: Var):
    in_ub = DBuff(DT.half, [1, WIDTH], Position.UB)
    out_ub = DBuff(DT.half, [1, WIDTH], Position.UB)

    cnt = Var(0)

    with auto_sync():
        if GetVecIdx() == 0:
            if GetSubBlockIdx() == 0:
                for tile_idx in range(0, tiles, 1):
                    in_ub[cnt] <<= x[tile_idx:tile_idx + 1, 0:n]
                    double_row_vf(in_ub[cnt], out_ub[cnt], n)
                    y[tile_idx:tile_idx + 1, 0:n] <<= out_ub[cnt]
                    cnt += 1

    return y


def build_vec_roundtrip():
    x = GMTensor(DT.half, [TILES, WIDTH])
    y = GMTensor(DT.half, [TILES, WIDTH])
    autosync_vec_roundtrip(x, y, Var(TILES), Var(WIDTH))


@kernel()
def autosync_vec_dma_roundtrip(x: GMTensor, y: GMTensor, tiles: Var, n: Var):
    relay_ub = DBuff(DT.half, [1, WIDTH], Position.UB)
    cnt = Var(0)

    with auto_sync():
        if GetVecIdx() == 0:
            if GetSubBlockIdx() == 0:
                for tile_idx in range(0, tiles, 1):
                    relay_ub[cnt] <<= x[tile_idx:tile_idx + 1, 0:n]
                    y[tile_idx:tile_idx + 1, 0:n] <<= relay_ub[cnt]
                    cnt += 1

    return y


def build_vec_dma_roundtrip() -> None:
    x = GMTensor(DT.half, [TILES, WIDTH])
    y = GMTensor(DT.half, [TILES, WIDTH])
    autosync_vec_dma_roundtrip(x, y, Var(TILES), Var(WIDTH))


@kernel()
def autosync_vec_b_device_value_dependency(x: GMTensor, y: GMTensor, n: Var):
    in_ub = DBuff(DT.float, [1, WIDTH], Position.UB)
    mid_ub = DBuff(DT.float, [1, WIDTH], Position.UB)
    out_ub = DBuff(DT.float, [1, WIDTH], Position.UB)
    cnt = Var(0)

    with auto_sync():
        in_ub[cnt][0:1, 0:n] <<= x[0:1, 0:n]
        mid_ub[cnt][0:1, 0:n] <<= in_ub[cnt][0:1, 0:n] + in_ub[cnt][0:1, 0:n]
        out_ub[cnt][0:1, 0:n] <<= mid_ub[cnt][0:1, 0:n] + mid_ub[cnt][0:1, 0:n]
        y[0:1, 0:n] <<= out_ub[cnt][0:1, 0:n]

    return y


def build_b_device_value_dependency_kernel() -> None:
    x = GMTensor(DT.float, [1, WIDTH])
    y = GMTensor(DT.float, [1, WIDTH])
    autosync_vec_b_device_value_dependency(x, y, Var(WIDTH))


@kernel()
def autosync_vec_b_device_manual_barrier(x: GMTensor, y: GMTensor, n: Var):
    in_ub = DBuff(DT.float, [1, WIDTH], Position.UB)
    mid_ub = DBuff(DT.float, [1, WIDTH], Position.UB)
    out_ub = DBuff(DT.float, [1, WIDTH], Position.UB)
    cnt = Var(0)

    with auto_sync():
        in_ub[cnt][0:1, 0:n] <<= x[0:1, 0:n]
        mid_ub[cnt][0:1, 0:n] <<= in_ub[cnt][0:1, 0:n] + in_ub[cnt][0:1, 0:n]
        bar_v()
        out_ub[cnt][0:1, 0:n] <<= mid_ub[cnt][0:1, 0:n] + mid_ub[cnt][0:1, 0:n]
        y[0:1, 0:n] <<= out_ub[cnt][0:1, 0:n]

    return y


def build_b_device_manual_barrier_kernel() -> None:
    x = GMTensor(DT.float, [1, WIDTH])
    y = GMTensor(DT.float, [1, WIDTH])
    autosync_vec_b_device_manual_barrier(x, y, Var(WIDTH))

@kernel()
def autosync_vec_loop_reused_ubin_single_buffer(x: GMTensor, y: GMTensor, repeats: Var, n: Var):
    in_ub = Tensor(DT.half, [1, WIDTH], Position.UB)
    out_ub = Tensor(DT.half, [1, WIDTH], Position.UB)

    with auto_sync():
        for rep in range(0, repeats):
            in_ub[0:1, 0:n] <<= x[0:1, 0:n]
            double_row_vf(in_ub, out_ub, n)
            y[0:1, 0:n] <<= out_ub[0:1, 0:n]
            in_ub[0:1, 0:n] <<= x[0:1, 0:n]
            double_row_vf(in_ub, out_ub, n)
            y[0:1, 0:n] <<= out_ub[0:1, 0:n]

    return y


def build_vec_loop_reused_ubin_single_buffer() -> None:
    x = GMTensor(DT.half, [1, WIDTH])
    y = GMTensor(DT.half, [1, WIDTH])
    autosync_vec_loop_reused_ubin_single_buffer(x, y, Var(3), Var(WIDTH))
