"""Cross-scope producer/consumer kernels for auto_sync regression coverage.

Each kernel produces a single-buffer UB tensor (`y1_ub`) INSIDE a nested scope
(an `if` block or a nested `for` loop) but stores it in the OUTER loop, AFTER the
nested scope exits. The nested scope also produces and consumes a second buffer
(`y2_ub`) entirely within itself, so the child owns a complete internal handshake
while still leaking the `y1_ub` producer to the parent.

Without the parent-level producer window, the V->MTE3 store of `y1_ub` is emitted
bare: the next outer iteration overwrites `y1_ub` before the store consumes it
(off-by-one-row race). These kernels pin that scenario for both nesting forms.
"""
from easyasc.a5 import *

# Width is a multiple of the 64-lane register so the copy is a few wide Reg moves
# (fast V-side production); tiles exceed a5 core_num (32) by enough that each
# active core reuses the single-buffer y1_ub across several outer tiles. Both are
# needed for the unprotected store to actually lose the race in the simulator
# (a narrow/slow copy or too-few tiles can hide the missing event).
CROSS_WIDTH = 256
CROSS_TILES = 64  # 2 x a5 core_num (32): every active core reuses y1_ub across tiles


@vf()
def copy_row_vf(src: Tensor, dst: Tensor):
    value = Reg(DT.float)
    for i in range(0, CROSS_WIDTH, 64):
        value <<= src[i]
        dst[i] <<= value


@kernel()
def autosync_cross_scope_leak_if(x1: GMTensor, x2: GMTensor, y1: GMTensor, y2: GMTensor, tiles: Var):
    x1_ub = Tensor(DT.float, [1, CROSS_WIDTH], Position.UB)
    x2_ub = Tensor(DT.float, [1, CROSS_WIDTH], Position.UB)
    y1_ub = Tensor(DT.float, [1, CROSS_WIDTH], Position.UB)
    y2_ub = Tensor(DT.float, [1, CROSS_WIDTH], Position.UB)

    with auto_sync():
        for t in range(0, tiles):
            x1_ub <<= x1[t:t + 1, 0:CROSS_WIDTH]
            if tiles > 0:
                x2_ub <<= x2[t:t + 1, 0:CROSS_WIDTH]
                copy_row_vf(x1_ub, y1_ub)             # V: produces y1_ub (leaks to parent)
                copy_row_vf(x2_ub, y2_ub)             # V: produces y2_ub (consumed in scope)
                y2[t:t + 1, 0:CROSS_WIDTH] <<= y2_ub  # MTE3: consumes y2_ub inside the scope
            y1[t:t + 1, 0:CROSS_WIDTH] <<= y1_ub      # MTE3: consumes y1_ub in the PARENT scope

    return y1, y2


@kernel()
def autosync_cross_scope_leak_for(x1: GMTensor, x2: GMTensor, y1: GMTensor, y2: GMTensor, tiles: Var):
    x1_ub = Tensor(DT.float, [1, CROSS_WIDTH], Position.UB)
    x2_ub = Tensor(DT.float, [1, CROSS_WIDTH], Position.UB)
    y1_ub = Tensor(DT.float, [1, CROSS_WIDTH], Position.UB)
    y2_ub = Tensor(DT.float, [1, CROSS_WIDTH], Position.UB)

    with auto_sync():
        for t in range(0, tiles):
            x1_ub <<= x1[t:t + 1, 0:CROSS_WIDTH]
            for _ in range(0, 1):                     # nested loop instead of `if`
                x2_ub <<= x2[t:t + 1, 0:CROSS_WIDTH]
                copy_row_vf(x1_ub, y1_ub)             # V: produces y1_ub (leaks to parent)
                copy_row_vf(x2_ub, y2_ub)             # V: produces y2_ub (consumed in scope)
                y2[t:t + 1, 0:CROSS_WIDTH] <<= y2_ub  # MTE3: consumes y2_ub inside the scope
            y1[t:t + 1, 0:CROSS_WIDTH] <<= y1_ub      # MTE3: consumes y1_ub in the PARENT scope

    return y1, y2


SHAPE_BINDINGS = {0: [0, None], 1: [0, None], 2: [0, None], 3: [0, None]}


def _make_args():
    x1 = GMTensor(DT.float, [CROSS_TILES, CROSS_WIDTH])
    x2 = GMTensor(DT.float, [CROSS_TILES, CROSS_WIDTH])
    y1 = GMTensor(DT.float, [CROSS_TILES, CROSS_WIDTH])
    y2 = GMTensor(DT.float, [CROSS_TILES, CROSS_WIDTH])
    return x1, x2, y1, y2


def build_cross_scope_leak_if() -> None:
    autosync_cross_scope_leak_if(*_make_args(), Var(CROSS_TILES))


def build_cross_scope_leak_for() -> None:
    autosync_cross_scope_leak_for(*_make_args(), Var(CROSS_TILES))
