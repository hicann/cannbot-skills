import torch

from easyasc.a5 import *
from easyasc.parser.asc import split_instructions, translate_split


COLS = 16


@kernel()
def _kernel_print_vars_only(dst: GMTensor):
    var1 = Var(7, DT.int, name="var1")
    var2 = Var(1.5, DT.float, name="var2")
    kernel_print("abc %d dee %f\n", var1, var2)
    return dst


@kernel()
def _kernel_dump_tensor_keeps_local_and_vars(src: GMTensor):
    ub = Tensor(DT.half, [1, COLS], Position.UB, name="ub")
    desc = Var(4, DT.int, name="desc")
    dump_size = Var(COLS, DT.int, name="dump_size")
    kernel_dump_tensor(ub, desc, dump_size)
    return src


@kernel()
def _kernel_dump_tensor_keeps_gm_view_and_vars(src: GMTensor):
    desc = Var(5, DT.int, name="desc")
    dump_size = Var(COLS, DT.int, name="dump_size")
    view = src[0:1, 0:COLS]
    kernel_dump_tensor(view, desc, dump_size)
    return src


@kernel()
def _kernel_dump_tensor_keeps_local_view_int_div(src: GMTensor, a: Var):
    ub = Tensor(DT.half, [1, 256], Position.UB, name="ub")
    keep = a // 64 * 64 // 2
    view = ub[0:1, keep:keep + 64]
    kernel_dump_tensor(view, 6, 64)
    return src


@kernel()
def _kernel_dump_tensor_keeps_gm_view_int_div(src: GMTensor, a: Var):
    keep = a // 64 * 64 // 2
    view = src[0:1, keep:keep + 64]
    kernel_dump_tensor(view, 7, 64)
    return src


@kernel()
def _kernel_print_passthrough(src: GMTensor):
    kernel_print("hello %d\n", 3)
    return src


def test_kernel_print_rejects_non_string_format() -> None:
    try:
        kernel_print(123)  # type: ignore[arg-type]
    except TypeError as exc:
        assert "fmt must be str type" in str(exc)
        return
    raise AssertionError("kernel_print should reject non-string fmt")


def test_kernel_print_codegen_uses_printf_and_keeps_vars_alive() -> None:
    dst = GMTensor(DT.float, [1, 1], name="dst")
    _kernel_print_vars_only(dst)

    cube_insts, vec_insts = split_instructions(list(_kernel_print_vars_only.instructions))
    assert "create_var" in [inst.opname for inst in cube_insts]
    assert "create_var" in [inst.opname for inst in vec_insts]
    assert "kernel_print" in [inst.opname for inst in cube_insts]
    assert "kernel_print" in [inst.opname for inst in vec_insts]

    cube_code, vec_code = translate_split(_kernel_print_vars_only.instructions, "kernel_print_vars_only")
    expected = 'printf("abc %d dee %f\\n", var1, var2);'
    assert "int var1 = 7;" in cube_code
    assert "float var2 = 1.5f;" in cube_code
    assert expected in cube_code
    assert "int var1 = 7;" in vec_code
    assert "float var2 = 1.5f;" in vec_code
    assert expected in vec_code


def test_kernel_dump_tensor_keeps_local_tensor_and_vars_alive() -> None:
    src = GMTensor(DT.half, [1, COLS], name="src")
    _kernel_dump_tensor_keeps_local_and_vars(src)

    cube_insts, vec_insts = split_instructions(list(_kernel_dump_tensor_keeps_local_and_vars.instructions))
    assert "kernel_dump_tensor" not in [inst.opname for inst in cube_insts]
    vec_opnames = [inst.opname for inst in vec_insts]
    assert "create_tensor" in vec_opnames
    assert "create_var" in vec_opnames
    assert "kernel_dump_tensor" in vec_opnames

    _, vec_code = translate_split(
        _kernel_dump_tensor_keeps_local_and_vars.instructions,
        "kernel_dump_tensor_keepalive_local",
    )
    assert "int desc = 4;" in vec_code
    assert "int dump_size = 16;" in vec_code
    assert "DumpTensor(ub, (uint32_t) desc, (uint32_t) dump_size);" in vec_code


def test_kernel_dump_tensor_keeps_gm_view_and_vars_alive() -> None:
    src = GMTensor(DT.half, [1, COLS], name="src")
    _kernel_dump_tensor_keeps_gm_view_and_vars(src)

    cube_insts, vec_insts = split_instructions(list(_kernel_dump_tensor_keeps_gm_view_and_vars.instructions))
    cube_opnames = [inst.opname for inst in cube_insts]
    vec_opnames = [inst.opname for inst in vec_insts]
    assert "slice_gm_tensor" in cube_opnames
    assert "slice_gm_tensor" in vec_opnames
    assert "create_var" in cube_opnames
    assert "create_var" in vec_opnames
    assert "kernel_dump_tensor" in cube_opnames
    assert "kernel_dump_tensor" in vec_opnames


def test_kernel_dump_tensor_keeps_local_view_int_div_shape() -> None:
    src = GMTensor(DT.half, [1, 256], name="src")
    _kernel_dump_tensor_keeps_local_view_int_div(src, Var(123, DT.int, name="a"))

    _, vec_code = translate_split(
        _kernel_dump_tensor_keeps_local_view_int_div.instructions,
        "kernel_dump_tensor_keepalive_local_view_int_div",
    )
    assert "a/2" not in vec_code
    assert "64*((a) / (64))" in vec_code
    assert "DumpTensor(ub[(((64*((a) / (64))) / (2)))], (uint32_t) 6, (uint32_t) 64);" in vec_code


def test_kernel_dump_tensor_keeps_gm_view_int_div_shape() -> None:
    src = GMTensor(DT.half, [1, 256], name="src")
    _kernel_dump_tensor_keeps_gm_view_int_div(src, Var(123, DT.int, name="a"))

    cube_code, vec_code = translate_split(
        _kernel_dump_tensor_keeps_gm_view_int_div.instructions,
        "kernel_dump_tensor_keepalive_gm_view_int_div",
    )
    expected = "DumpTensor(src[(((64*((a) / (64))) / (2)))], (uint32_t) 7, (uint32_t) 64);"
    assert "a/2" not in cube_code
    assert "a/2" not in vec_code
    assert "64*((a) / (64))" in cube_code
    assert "64*((a) / (64))" in vec_code
    assert expected in cube_code
    assert expected in vec_code
