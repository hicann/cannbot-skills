import contextlib
import io

import pytest

from easyasc.a2 import *
from easyasc.parser.asc import translate_split
from easyasc.parser.asc_handlers.math_ops import handle_div
from easyasc.utils.instruction import Instruction


@kernel(mode="vec")
def mixed_var_div_codegen(dst: GMTensor, width: Var, scale: Var):
    with vec_scope():
        inv_width = var_div(1.0, width, name="inv_width")
        scale_over_width = var_div(scale, width, name="scale_over_width")
        width_over_scale = var_div(width, scale, name="width_over_scale")
        chunks = var_div(width, 2, name="chunks")
        total = inv_width + scale_over_width + width_over_scale + chunks
        total.SetValueTo(dst)
    return dst


def _translate_silently(instructions, name: str):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        return translate_split(instructions, name)


def test_var_div_promotes_float_and_int_operands() -> None:
    width = Var(value=None, dtype=DT.int, name="stub_width")
    wide_width = Var(value=None, dtype=DT.int64, name="stub_wide_width")
    scale = Var(value=None, dtype=DT.float, name="stub_scale")

    assert var_div(1.0, width).dtype is DT.float
    assert var_div(1.0, wide_width).dtype is DT.float
    assert var_div(scale, width).dtype is DT.float
    assert var_div(width, scale).dtype is DT.float
    assert var_div(width, 2).dtype is DT.int


def test_var_div_matching_int64_operands_preserve_dtype() -> None:
    numerator = Var(9, DT.int64, name="wide_numerator")
    denominator = Var(2, DT.int64, name="wide_denominator")
    result = var_div(numerator, denominator)
    assert result.dtype is DT.int64
    assert result.value == 4


def test_var_div_mixed_constant_folding_uses_float_division() -> None:
    result = var_div(1.0, Var(4, DT.int, name="constant_width"))
    assert result.dtype is DT.float
    assert result.value == pytest.approx(0.25)


def test_var_div_direct_handler_casts_integer_var_denominator() -> None:
    width = Var(value=None, dtype=DT.int, name="handler_width")
    out = Var(value=None, dtype=DT.float, name="handler_inv_width")
    inst = Instruction("var_div", a=1.0, b=width, out=out)
    lines = []

    handle_div(inst, lines.append, {})

    assert lines == ["handler_inv_width = 1.0f / (float) handler_width;"]


@pytest.mark.easyasc_device("b3")
def test_var_div_codegen_emits_float_cpp_expressions() -> None:
    dst = GMTensor(DT.float, [1, 1], name="dst")
    width = Var(value=None, dtype=DT.int, name="width")
    scale = Var(value=None, dtype=DT.float, name="scale")
    mixed_var_div_codegen(dst, width, scale)

    _, vec_code = _translate_silently(mixed_var_div_codegen.instructions, "mixed_var_div_codegen")

    assert "float inv_width = 1.0f / (float) width;" in vec_code
    assert "float scale_over_width = scale / (float) width;" in vec_code
    assert "float width_over_scale = width/scale;" in vec_code
    assert "int chunks = ((width) / (2));" in vec_code
    assert "IDiv(1.0f" not in vec_code
