import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.parser.asc import translate_split


def _with_device(device_type: str):
    saved = globvars.device_type
    globvars.device_type = device_type
    return saved


def test_stub_gm_to_l1_dn2nz_rejects_dtype_mismatch() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [16, 16], Position.L1)
            gm_to_l1_dn2nz(dst, inp[0:16, 0:16])
            return inp

        inp = GMTensor(DT.half, [16, 16])
        with pytest.raises(ValueError, match="dst/src data types must match"):
            stub_only(inp)
    finally:
        globvars.device_type = saved


def test_stub_gm_to_l1_dn2nz_rejects_b_device() -> None:
    saved = _with_device("b3")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [16, 16], Position.L1)
            gm_to_l1_dn2nz(dst, inp[0:16, 0:16])
            return inp

        inp = GMTensor(DT.float, [16, 16])
        with pytest.raises(Exception):
            stub_only(inp)
    finally:
        globvars.device_type = saved


def _infer_kwargs(kernel_fn):
    insts = [i for i in kernel_fn.instructions if i.opname == "gm_to_l1_dn2nz"]
    assert len(insts) == 1
    return insts[0].kwargs


def test_stub_gm_to_l1_dn2nz_infers_transposed_window_from_2d_slice() -> None:
    saved = _with_device("950")
    try:
        # GM holds xt = [K_total=32, M_total=96]; slice [0:24, 0:48] -> dst [M=48, N=24].
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [48, 24], Position.L1)
            gm_to_l1_dn2nz(dst, inp[0:24, 0:48])
            return inp

        inp = GMTensor(DT.float, [32, 96])
        stub_only(inp)
        kwargs = _infer_kwargs(stub_only)
        assert kwargs["M"] == 48      # dst rows  = GM column span
        assert kwargs["N"] == 24      # dst cols  = GM row span
        assert kwargs["N_src"] == 96  # GM row stride = full GM width
        assert kwargs["M_dst"] == 48  # dst row capacity
    finally:
        globvars.device_type = saved


def test_stub_gm_to_l1_dn2nz_infers_single_column_from_1d_slice() -> None:
    saved = _with_device("950")
    try:
        # One sliced dim = one GM row -> a single dst column [span, 1] (nd2nz's [1, span] transposed).
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [48, 8], Position.L1)
            gm_to_l1_dn2nz(dst, inp[0, 0:48])
            return inp

        inp = GMTensor(DT.float, [32, 96])
        stub_only(inp)
        kwargs = _infer_kwargs(stub_only)
        assert kwargs["M"] == 48
        assert kwargs["N"] == 1
        assert kwargs["N_src"] == 96
        assert kwargs["M_dst"] == 48
    finally:
        globvars.device_type = saved


def test_sugar_gm_transpose_ilshift_dispatches_to_dn2nz() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [48, 24], Position.L1)
            dst <<= inp[0:24, 0:48].T
            return inp

        inp = GMTensor(DT.float, [32, 96])
        stub_only(inp)
        kwargs = _infer_kwargs(stub_only)
        assert kwargs["M"] == 48
        assert kwargs["N"] == 24
        assert kwargs["N_src"] == 96
    finally:
        globvars.device_type = saved


def test_sugar_bare_gm_transpose_infers_full_window() -> None:
    saved = _with_device("950")
    try:
        # Bare gm.T synthesizes a full [:, :] slice so auto-infer works.
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [96, 32], Position.L1)
            dst <<= inp.T
            return inp

        inp = GMTensor(DT.float, [32, 96])
        stub_only(inp)
        kwargs = _infer_kwargs(stub_only)
        assert kwargs["M"] == 96
        assert kwargs["N"] == 32
        assert kwargs["N_src"] == 96
        assert kwargs["M_dst"] == 96
    finally:
        globvars.device_type = saved


def test_sugar_gm_transpose_rejects_ub_and_nd_destinations() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def to_nd_l1(inp2: GMTensor):
            dst = Tensor(DT.float, [96, 32], Position.L1, layout=Layout.ND)
            dst <<= inp2.T
            return inp2

        inp2 = GMTensor(DT.float, [32, 96])
        with pytest.raises(ValueError, match="NZ-layout L1"):
            to_nd_l1(inp2)
    finally:
        globvars.device_type = saved


def test_gm_transpose_view_blocks_slice_reshape_store() -> None:
    saved = _with_device("950")
    try:
        inp = GMTensor(DT.float, [32, 96])
        t = inp.T
        with pytest.raises(ValueError, match="slice first"):
            _ = t[0:8, 0:8]
        with pytest.raises(ValueError, match="reshape first"):
            t.reshape([96, 32])
        assert t.T.is_transpose is False  # double transpose flips back
    finally:
        globvars.device_type = saved


def test_codegen_gm_to_l1_dn2nz_emits_cube_helper_on_950() -> None:
    saved = _with_device("950")
    try:
        @kernel()
        def stub_only(inp: GMTensor):
            dst = Tensor(DT.float, [16, 16], Position.L1)
            gm_to_l1_dn2nz(dst, inp[0:16, 0:16])
            return inp

        inp = GMTensor(DT.float, [16, 16])
        stub_only(inp)
        cube_code, vec_code = translate_split(stub_only.instructions, "gm_to_l1_dn2nz_950")
        assert "GM2L1_DN2NZ(" in cube_code
        assert "GM2L1_DN2NZ(" not in vec_code
    finally:
        globvars.device_type = saved
