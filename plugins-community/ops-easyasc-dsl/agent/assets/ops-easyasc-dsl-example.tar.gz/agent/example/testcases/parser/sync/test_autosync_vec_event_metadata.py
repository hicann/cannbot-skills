import contextlib
import io

import torch

from easyasc.a5 import OpExec
from easyasc.parser.asc import split_instructions, translate_split
from easyasc.parser.asc_autosync import AutosyncNode, insert_auto_sync
from easyasc.utils.pipe import Pipe
from testcases.parser.sync._autosync_test_helpers import TILES, WIDTH
from testcases.parser.sync._autosync_vec_kernels import (
    autosync_vec_dma_roundtrip,
    autosync_vec_loop_reused_ubin_single_buffer,
    autosync_vec_roundtrip,
    build_vec_dma_roundtrip,
    build_vec_loop_reused_ubin_single_buffer,
    build_vec_roundtrip,
)

def test_insert_auto_sync_event_metadata_matches_create_ops() -> None:
    build_vec_roundtrip()
    _, vec_insts = split_instructions(list(autosync_vec_roundtrip.instructions))
    vec_insts = insert_auto_sync(vec_insts, mode="vec")

    created = {}
    for inst in vec_insts:
        if inst.opname not in ("create_devent", "create_sevent"):
            continue
        event = inst.kwargs["val"]
        created[event.name] = (
            str(event.src_pipe),
            str(event.dst_pipe),
            bool(getattr(event, "preset", False)),
        )

    checked = 0
    for inst in vec_insts:
        if inst.opname not in ("event_wait", "event_set"):
            continue
        event = inst.kwargs["event"]
        assert event.name in created
        assert created[event.name] == (
            str(event.src_pipe),
            str(event.dst_pipe),
            bool(getattr(event, "preset", False)),
        )
        checked += 1

    assert checked > 0


def test_create_events_preserves_first_trace_order() -> None:
    node = object.__new__(AutosyncNode)
    node.events_to_be_created = [
        "_tmp_devent_valid_first_0",
        "_tmp_devent_ready_first_0",
        "_tmp_sevent_valid_second_0",
        "_tmp_devent_valid_first_0",
    ]
    node.src_pipe = Pipe.MTE2
    node.dst_pipe = Pipe.V
    node.new_insts = []
    created = []

    node.create_events(created)

    assert [inst.kwargs["val"].name for inst in created] == [
        "_tmp_devent_valid_first_0",
        "_tmp_devent_ready_first_0",
        "_tmp_sevent_valid_second_0",
    ]

def test_translate_split_emits_expected_vec_event_declarations() -> None:
    build_vec_roundtrip()
    _, vec_code = translate_split(
        autosync_vec_roundtrip.instructions,
        "autosync_vec_roundtrip_codegen",
    )

    assert "DEvent<PIPE_V, PIPE_MTE2, true> _tmp_devent_valid_ubin_0;" in vec_code
    assert "DEvent<PIPE_MTE2, PIPE_V, false> _tmp_devent_ready_ubin_0;" in vec_code
    assert "DEvent<PIPE_MTE3, PIPE_V, true> _tmp_devent_valid_ubout_0;" in vec_code
    assert "DEvent<PIPE_V, PIPE_MTE3, false> _tmp_devent_ready_ubout_0;" in vec_code

def test_simulator_runs_vec_autosync_roundtrip() -> None:
    torch.manual_seed(0)
    x = torch.randn((TILES, WIDTH), dtype=torch.float16)
    y = torch.zeros((TILES, WIDTH), dtype=torch.float16)

    out = OpExec(autosync_vec_roundtrip, simulator=True)(
        x,
        y,
        TILES,
        WIDTH,
        shape_bindings={
            0: [0, 1],
            1: [0, 1],
        },
    )

    torch.testing.assert_close(out, x + x, rtol=1e-4, atol=1e-4)

def test_insert_auto_sync_vec_dma_scope_uses_direct_mte2_mte3_events() -> None:
    build_vec_dma_roundtrip()
    _, vec_insts = split_instructions(list(autosync_vec_dma_roundtrip.instructions))
    vec_insts = insert_auto_sync(vec_insts, mode="vec")

    created = {
        inst.kwargs["val"].name
        for inst in vec_insts
        if inst.opname in ("create_devent", "create_sevent")
    }
    assert "_tmp_devent_valid_ubrelay_0" in created
    assert "_tmp_devent_ready_ubrelay_0" in created
    assert "_tmp_devent_valid_ubin_0" not in created
    assert "_tmp_devent_ready_ubin_0" not in created
    assert "_tmp_devent_valid_ubout_0" not in created
    assert "_tmp_devent_ready_ubout_0" not in created

def test_translate_split_emits_expected_vec_dma_event_declarations() -> None:
    build_vec_dma_roundtrip()
    _, vec_code = translate_split(
        autosync_vec_dma_roundtrip.instructions,
        "autosync_vec_dma_roundtrip_codegen",
    )

    assert "DEvent<PIPE_MTE3, PIPE_MTE2, true> _tmp_devent_valid_ubrelay_0;" in vec_code
    assert "DEvent<PIPE_MTE2, PIPE_MTE3, false> _tmp_devent_ready_ubrelay_0;" in vec_code
    assert "_tmp_devent_valid_ubin_0" not in vec_code
    assert "_tmp_devent_valid_ubout_0" not in vec_code

def test_simulator_runs_vec_dma_autosync_roundtrip() -> None:
    torch.manual_seed(0)
    x = torch.randn((TILES, WIDTH), dtype=torch.float16)
    y = torch.zeros((TILES, WIDTH), dtype=torch.float16)

    out = OpExec(autosync_vec_dma_roundtrip, simulator=True)(
        x,
        y,
        TILES,
        WIDTH,
        shape_bindings={
            0: [0, 1],
            1: [0, 1],
        },
    )

    torch.testing.assert_close(out, x, rtol=1e-4, atol=1e-4)

def test_insert_auto_sync_vec_loop_reused_ubin_single_buffer_keeps_tail_valid_set() -> None:
    build_vec_loop_reused_ubin_single_buffer()
    _, vec_insts = split_instructions(list(autosync_vec_loop_reused_ubin_single_buffer.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        vec_insts = insert_auto_sync(vec_insts, mode="vec")

    assert "NOT balanced auto_sync events" not in captured.getvalue()

    actions = []
    for inst in vec_insts:
        if inst.opname not in ("event_wait", "event_set"):
            continue
        event = inst.kwargs["event"]
        if event.name != "_tmp_sevent_valid_ubin_0":
            continue
        actions.append(inst.opname)

    assert actions.count("event_wait") >= 2, actions
    assert actions[0] == "event_wait", actions
    assert actions[-1] == "event_set", actions

def test_insert_auto_sync_vec_scope_with_v_does_not_use_direct_mte2_mte3_events() -> None:
    build_vec_roundtrip()
    _, vec_insts = split_instructions(list(autosync_vec_roundtrip.instructions))
    vec_insts = insert_auto_sync(vec_insts, mode="vec")

    created = {
        inst.kwargs["val"].name
        for inst in vec_insts
        if inst.opname in ("create_devent", "create_sevent")
    }
    assert "_tmp_devent_valid_ubrelay_0" not in created
    assert "_tmp_devent_ready_ubrelay_0" not in created
    assert "_tmp_devent_valid_ubin_0" in created
    assert "_tmp_devent_ready_ubout_0" in created
