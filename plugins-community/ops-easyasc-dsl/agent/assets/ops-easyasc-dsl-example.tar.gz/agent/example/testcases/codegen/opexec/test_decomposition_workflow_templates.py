import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[5]
DECOMPOSE = ROOT / "agent" / "playbooks" / "decompose-pytorch.md"
AUTHOR = ROOT / "agent" / "playbooks" / "author-kernel-from-decomposition.md"
DECOMPOSE_TEMPLATES = ROOT / "agent" / "references" / "templates" / "decompose-pytorch"
AUTHOR_TEMPLATES = ROOT / "agent" / "references" / "templates" / "author-kernel-from-decomposition"


def _render(template: Path, destination: Path, values) -> None:
    text = template.read_text(encoding="utf-8")
    for key, value in values.items():
        text = text.replace("{%s}" % key, str(value))
    destination.write_text(text, encoding="utf-8")


def _run(path: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(path)], cwd=str(path.parent),
        check=False, capture_output=True, text=True,
    )


def test_two_node_reference_handoff_templates_run_independently(tmp_path: Path) -> None:
    refs = tmp_path / "refs"
    refs.mkdir()

    _render(
        DECOMPOSE_TEMPLATES / "oracle.py.template", refs / "oracle.py",
        {
            "function_name": "two_stage",
            "oracle_body": "x = args[0]\n    return (x + 1.0) * 2.0",
            "sample_inputs": "x = torch.randn(4)",
            "sample_call_args": "x",
        },
    )
    for name, body in (("add_one", "return x + 1.0"), ("double", "return x * 2.0")):
        _render(
            DECOMPOSE_TEMPLATES / "subkernel.py.template", refs / (name + "_ref.py"),
            {
                "sub_name": name,
                "args": "x",
                "body": body,
                "sample_inputs": "x = torch.randn(4)",
                "sample_call_args": "x",
            },
        )
        _render(
            DECOMPOSE_TEMPLATES / "subkernel_check.py.template", refs / (name + "_check.py"),
            {
                "sub_name": name,
                "atol": "0.0",
                "rtol": "0.0",
                "args": "x",
                "expected_body": body,
                "sample_body": "x = torch.randn(4)",
                "sample_return": "(x,)",
            },
        )
    _render(
        DECOMPOSE_TEMPLATES / "compose.py.template", refs / "compose.py",
        {
            "function_name": "two_stage",
            "plan_id": "default",
            "sub_imports": (
                "from add_one_ref import subkernel as add_one\n"
                "from double_ref import subkernel as double"
            ),
            "plan_atol": "0.0",
            "plan_rtol": "0.0",
            "input_args": "x",
            "compose_body": "return double(add_one(x))",
            "sample_body": "x = torch.randn(4)",
            "sample_return": "(x,)",
        },
    )

    subprocess.run(
        [sys.executable, "-m", "py_compile"] + [str(path) for path in sorted(refs.glob("*.py"))],
        check=True, cwd=str(tmp_path),
    )
    for name in ("add_one_check.py", "double_check.py", "compose.py"):
        result = _run(refs / name)
        assert result.returncode == 0, result.stderr


def test_workflow_contract_is_small_immutable_and_gated() -> None:
    decompose_text = DECOMPOSE.read_text(encoding="utf-8")
    author_text = AUTHOR.read_text(encoding="utf-8")
    assert len(decompose_text.splitlines()) <= 180
    assert len(author_text.splitlines()) <= 200
    assert len(decompose_text.splitlines()) + len(author_text.splitlines()) <= 380
    assert "refs/` becomes immutable" in decompose_text
    assert "check fails, stop before authoring" in author_text
    assert "never edit a" in author_text
    assert "reference to hide a DSL mismatch" in author_text
    assert "candidates" in decompose_text and "Do not add" in decompose_text


def test_templates_keep_tolerance_roles_separate_and_one_kernel_skeleton() -> None:
    plan = (DECOMPOSE_TEMPLATES / "plan.md").read_text(encoding="utf-8")
    compose = (DECOMPOSE_TEMPLATES / "compose.py.template").read_text(encoding="utf-8")
    final_check = (
        AUTHOR_TEMPLATES / "check_simulator_vs_ref.py.template"
    ).read_text(encoding="utf-8")
    assert "plan_tolerance" in plan
    assert "implementation_tolerance" in plan
    assert "PLAN_ATOL" in compose and "IMPLEMENTATION_ATOL" not in compose
    assert "actual, planned, IMPLEMENTATION_ATOL, IMPLEMENTATION_RTOL" in final_check
    assert "actual, oracle(*inputs), PLAN_ATOL, PLAN_RTOL" in final_check
    assert len(list(AUTHOR_TEMPLATES.glob("kernel*.template"))) == 1
    assert "_REPO_ROOT" not in "\n".join(
        path.read_text(encoding="utf-8") for path in AUTHOR_TEMPLATES.glob("*.template")
    )
