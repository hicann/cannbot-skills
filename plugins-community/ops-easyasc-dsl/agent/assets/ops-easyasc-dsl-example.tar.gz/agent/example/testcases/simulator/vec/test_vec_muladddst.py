"""Functional coverage for the A2 vec-layer muladddst (MulAddDst): dst = dst + src1*src2.

Two layers:
* Stub dtype validation -- the accepted mixed-precision matrix (float/half same-dtype plus
  the half-src -> float-dst high-precision accumulate) and the rejected combinations.
* Simulator value tests -- run the in/out-separated demo kernels (c seeded into a
  store-only accumulator, then muladddst) and assert the stored tile against a torch
  reference across float / half / half->float-mixed, including a non-divisible tail. The
  mixed path exercises the repeat-mode {1,1,1,8,4,4} form + the simulator's mixed-precision
  contiguous model.
"""
from types import SimpleNamespace

import pytest
import torch

from easyasc import globvars
from easyasc.a2 import *
from kernels.a2.vec_only.fma_muladddst import (
    fma_float_kernel, fma_half_kernel, fma_mixed_kernel, fma_reference,
)


# --------------------------------------------------------------------------------------
# Stub dtype validation (fake b3 kernel; assert accept / reject)
# --------------------------------------------------------------------------------------
class _fake_b3:
    def __enter__(self):
        self._k, self._m, self._d = (
            globvars.active_kernel, globvars.active_micro, globvars.device_type)
        globvars.device_type = "b3"
        globvars.active_micro = None
        globvars.active_kernel = SimpleNamespace(instructions=[], vector_mode="repeat")
        return globvars.active_kernel

    def __exit__(self, *a):
        globvars.active_kernel, globvars.active_micro, globvars.device_type = (
            self._k, self._m, self._d)


def _ub(dt):
    return Tensor(dt, [1, 64], Position.UB, name="t")


@pytest.mark.parametrize("dt", [DT.float, DT.half])
def test_muladddst_accepts_same_dtype(dt) -> None:
    with _fake_b3() as k:
        muladddst(_ub(dt), _ub(dt), _ub(dt))
        assert sum(i.opname == "muladddst" for i in k.instructions) == 1


def test_muladddst_accepts_mixed_half_src_float_dst() -> None:
    # The CANN half-input / float-output high-precision accumulate mode.
    with _fake_b3() as k:
        muladddst(_ub(DT.float), _ub(DT.half), _ub(DT.half))
        assert sum(i.opname == "muladddst" for i in k.instructions) == 1


def test_muladddst_rejects_half_dst_float_src() -> None:
    # Accumulator lower-precision than its sources is not a doc mode.
    with _fake_b3():
        with pytest.raises(ValueError, match="supports"):
            muladddst(_ub(DT.half), _ub(DT.float), _ub(DT.float))


def test_muladddst_rejects_mismatched_src() -> None:
    with _fake_b3():
        with pytest.raises(ValueError, match="src1/src2"):
            muladddst(_ub(DT.float), _ub(DT.half), _ub(DT.float))


def test_muladddst_rejects_non_ub() -> None:
    with _fake_b3():
        l1 = Tensor(DT.float, [1, 64], Position.L1, name="l1")
        with pytest.raises(ValueError, match="UB"):
            muladddst(l1, _ub(DT.float), _ub(DT.float))


# --------------------------------------------------------------------------------------
# Simulator value tests (run demo kernels, assert stored tile vs torch reference)
# --------------------------------------------------------------------------------------
_KERNELS = {
    (torch.float32, torch.float32): fma_float_kernel,
    (torch.float16, torch.float16): fma_half_kernel,
    (torch.float16, torch.float32): fma_mixed_kernel,
}


def _run_sim(in_dtype, acc_dtype, n, tile, seed):
    torch.manual_seed(seed)
    a = torch.empty((1, n), dtype=in_dtype).uniform_(-1.0, 1.0)
    b = torch.empty((1, n), dtype=in_dtype).uniform_(-1.0, 1.0)
    c = torch.empty((1, n), dtype=acc_dtype).uniform_(-1.0, 1.0)
    y = torch.zeros((1, n), dtype=acc_dtype)
    ref = fma_reference(a, b, c).to(acc_dtype)
    out = OpExec(_KERNELS[(in_dtype, acc_dtype)], simulator=True)(
        a, b, c, y, n, tile,
        shape_bindings={0: [None, 0], 1: [None, 0], 2: [None, 0], 3: [None, 0]})
    tol = 1e-5 if (in_dtype, acc_dtype) == (torch.float32, torch.float32) else 2e-3
    torch.testing.assert_close(out, ref, rtol=tol, atol=tol)


def test_sim_fma_float_single_tile() -> None:
    _run_sim(torch.float32, torch.float32, n=1024, tile=1024, seed=0)


def test_sim_fma_half_single_tile() -> None:
    _run_sim(torch.float16, torch.float16, n=1024, tile=1024, seed=1)


def test_sim_fma_mixed_single_tile() -> None:
    # half src -> fp32 acc, repeat-mode {1,1,1,8,4,4}; exercises the sim mixed model.
    _run_sim(torch.float16, torch.float32, n=1024, tile=1024, seed=2)


def test_sim_fma_float_tail() -> None:
    _run_sim(torch.float32, torch.float32, n=549, tile=128, seed=3)


def test_sim_fma_mixed_tail() -> None:
    # 777 is not a multiple of 64 -> the mixed repeat over-runs into scratch that the
    # store ignores; the stored [0:valid] must still match.
    _run_sim(torch.float16, torch.float32, n=777, tile=256, seed=4)


def test_sim_fma_mixed_cross_tile() -> None:
    # tiles_per_core > 1: same-core buffer reuse across tiles.
    _run_sim(torch.float16, torch.float32, n=40000, tile=256, seed=5)
