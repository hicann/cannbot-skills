import warnings
from types import SimpleNamespace

import pytest
import torch

from easyasc.simulator.pipe_cube import CubeMTE1Pipe, CubeMTE2Pipe, FixPipe, MPipe
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe import PipeS
from easyasc.simulator.pipe_micro import (
    MicroContext,
    MicroDivPrecisionWarning,
    MicroRuntime,
)
from easyasc.simulator.pipe_vec import MTE3Pipe, VPipe, VecMTE2Pipe
from easyasc.simulator.program import ControlInstruction, PipeTask
from easyasc.simulator.sync import Mailbox
from easyasc.dtypehelper.hif8_codec import fp16_to_hif8, fp32_to_hif8, hif8_to_fp32
from easyasc.dtypehelper.fp4_fp32 import fp32_to_fp4_e1m2, fp4_e1m2_to_fp32
from easyasc.utils.castconfig import CastConfig, RegLayout
from easyasc.utils.comparemode import CompareMode
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.divconfig import DivAlgo, DivConfig
from easyasc.utils.instruction import Instruction
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.roundmode import RoundMode
from easyasc.utils.var import Expr, Var

from testcases.simulator.micro._micro_test_helpers import _TensorStore


def test_micro_runtime_preserves_float_var_arithmetic() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    base = Var(1.25, name="base")
    scale = Var(0.0, dtype=DT.float, name="scale")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=base),
            Instruction("create_var", val=scale),
            Instruction("create_reg", reg=src),
            Instruction("create_reg", reg=dst),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("var_mul", a=base, b=0.5, out=scale),
            Instruction("micro_vdup", dst=src, value=2.0),
            Instruction("micro_vmuls", dst=dst, src=src, v=scale),
            Instruction("micro_reg2ub", dst=out_ref, src=dst, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    torch.testing.assert_close(out, torch.full_like(out, 1.25))


def test_micro_runtime_supports_div_mod_and_ceildiv() -> None:
    runtime = MicroRuntime()
    int_div = Var(0, dtype=DT.int, name="int_div")
    float_div = Var(0.0, dtype=DT.float, name="float_div")
    remainder = Var(0, dtype=DT.int, name="remainder")
    ceil_div = Var(0, dtype=DT.int, name="ceil_div")
    ctx = MicroContext()
    store = SharedMemoryStore()

    runtime._stack.append(ctx)
    try:
        runtime._dispatch("var_div", {"a": 9, "b": 2, "out": int_div}, store)
        runtime._dispatch("var_div", {"a": 9.0, "b": 2, "out": float_div}, store)
        runtime._dispatch("var_mod", {"a": -9, "b": 2, "out": remainder}, store)
        runtime._dispatch("CeilDiv", {"a": 9, "b": 2, "out": ceil_div}, store)
    finally:
        runtime._stack.pop()

    assert ctx.var_values == {
        "int_div": 4,
        "float_div": 4.5,
        "remainder": -1,
        "ceil_div": 5,
    }


def test_micro_runtime_warns_when_intrinsic_division_hides_a5_rounding() -> None:
    runtime = MicroRuntime()
    numerator = Reg(DT.float, name="numerator")
    denominator = Reg(DT.float, name="denominator")
    quotient = Reg(DT.float, name="quotient")
    ctx = MicroContext(regs={
        "numerator": torch.full((64,), 7.0, dtype=torch.float32),
        "denominator": torch.full((64,), 3.0, dtype=torch.float32),
    })
    runtime._stack.append(ctx)
    try:
        with pytest.warns(MicroDivPrecisionWarning, match="0-ULP"):
            runtime._dispatch(
                "micro_vdiv",
                {"dst": quotient, "src1": numerator, "src2": denominator},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


def test_micro_runtime_accepts_exact_division_mode_without_advisory() -> None:
    runtime = MicroRuntime()
    numerator = Reg(DT.float, name="numerator")
    denominator = Reg(DT.float, name="denominator")
    quotient = Reg(DT.float, name="quotient")
    config = DivConfig(
        algo=DivAlgo.PRECISION_0ULP_FTZ_TRUE,
        precision_mode=True,
        name="exact_normal",
    )
    ctx = MicroContext(regs={
        "numerator": torch.full((64,), 7.0, dtype=torch.float32),
        "denominator": torch.full((64,), 3.0, dtype=torch.float32),
    })
    runtime._stack.append(ctx)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch(
                "micro_vdiv",
                {
                    "dst": quotient,
                    "src1": numerator,
                    "src2": denominator,
                    "config": config,
                },
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()

    assert not [
        item for item in caught
        if item.category is MicroDivPrecisionWarning
    ]
    torch.testing.assert_close(
        ctx.regs["quotient"],
        torch.full((64,), 7.0 / 3.0, dtype=torch.float32),
    )


def test_micro_runtime_skips_div_advisory_for_normal_exponent_shift() -> None:
    runtime = MicroRuntime()
    numerator = Reg(DT.float, name="numerator")
    denominator = Reg(DT.float, name="denominator")
    quotient = Reg(DT.float, name="quotient")
    ctx = MicroContext(regs={
        "numerator": torch.arange(1, 65, dtype=torch.float32),
        "denominator": torch.full((64,), 4.0, dtype=torch.float32),
    })
    runtime._stack.append(ctx)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch(
                "micro_vdiv",
                {"dst": quotient, "src1": numerator, "src2": denominator},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()

    assert not [
        item for item in caught
        if item.category is MicroDivPrecisionWarning
    ]


@pytest.mark.parametrize("op", ["var_div", "var_mod", "CeilDiv"])
def test_micro_runtime_scalar_division_by_zero_raises(op: str) -> None:
    runtime = MicroRuntime()
    out = Var(0, dtype=DT.int, name="out")
    runtime._stack.append(MicroContext())
    try:
        with pytest.raises(ZeroDivisionError, match="division by zero"):
            runtime._dispatch(op, {"a": 1, "b": 0, "out": out}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "flag, expected",
    [(0, 11.0), (1, 7.0)],
)
def test_micro_runtime_executes_if_else(flag: int, expected: float) -> None:
    runtime = MicroRuntime()
    branch_flag = Var(flag, name="branch_flag")
    selected = Var(0.0, dtype=DT.float, name="selected")
    src = Reg(DT.float, name="src")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)
    micro_def = {
        "instructions": [
            Instruction("create_var", val=branch_flag),
            Instruction("create_var", val=selected),
            Instruction("create_reg", reg=src),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("start_if", cond=Expr("branch_flag != 0")),
            Instruction("var_assign", out=selected, src=7.0),
            Instruction("start_else"),
            Instruction("var_assign", out=selected, src=11.0),
            Instruction("end_if"),
            Instruction("micro_vdup", dst=src, value=selected),
            Instruction(
                "micro_reg2ub", dst=out_ref, src=src,
                blk_stride=1, mask=mask_all,
            ),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    torch.testing.assert_close(out, torch.full_like(out, expected))


def test_micro_runtime_executes_nested_if_inside_loop() -> None:
    runtime = MicroRuntime()
    loop_var = Var(0, name="loop_var")
    total = Var(0, name="total")
    src = Reg(DT.float, name="src")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)
    micro_def = {
        "instructions": [
            Instruction("create_var", val=loop_var),
            Instruction("create_var", val=total),
            Instruction("create_reg", reg=src),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("start_micro_loop", var=loop_var, start=0, stop=4, step=1),
            Instruction("start_if", cond=Expr("(loop_var % 2) == 0")),
            Instruction("var_add", a=total, b=3, out=total),
            Instruction("start_else"),
            Instruction("var_add", a=total, b=5, out=total),
            Instruction("end_if"),
            Instruction("end_loop", var=loop_var),
            Instruction("micro_vdup", dst=src, value=total),
            Instruction(
                "micro_reg2ub", dst=out_ref, src=src,
                blk_stride=1, mask=mask_all,
            ),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    torch.testing.assert_close(out, torch.full_like(out, 16.0))


def test_micro_cast_bfloat16_to_fp4_e1m2_packs_rint_carriers() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.bfloat16, name="src")
    dst = Reg(DT.fp4_e1m2, name="dst")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask")
    cfg = CastConfig(
        round_mode=RoundMode.TO_EVEN,
        reg_layout=RegLayout.ZERO,
        name="cfg",
    )
    values = torch.linspace(-2.0, 2.0, 128, dtype=torch.bfloat16)
    ctx = MicroContext(
        regs={"src": values},
        masks={"mask": torch.ones(128, dtype=torch.bool)},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {"dst": dst, "src": src, "config": cfg, "mask": mask, "ddst": DT.fp4_e1m2},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = fp32_to_fp4_e1m2(values.float(), round_mode=RoundMode.TO_EVEN)
    torch.testing.assert_close(ctx.regs["dst"][0::4], expected, rtol=0, atol=0)
    nonzero_slots = torch.cat(
        [ctx.regs["dst"][1::4], ctx.regs["dst"][2::4], ctx.regs["dst"][3::4]]
    )
    torch.testing.assert_close(nonzero_slots, torch.zeros(192, dtype=torch.uint8), rtol=0, atol=0)


def test_micro_runtime_keeps_ideal_half_to_float_layout_one_semantics() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.half, name="src")
    dst = Reg(DT.float, name="dst")
    mask = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask")
    cfg = CastConfig(
        round_mode=RoundMode.NONE,
        reg_layout=RegLayout.ONE,
        name="cfg",
    )
    values = torch.arange(128, dtype=torch.float16)
    ctx = MicroContext(
        regs={"src": values},
        masks={"mask": torch.ones(64, dtype=torch.bool)},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {"dst": dst, "src": src, "config": cfg, "mask": mask, "ddst": DT.float},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    torch.testing.assert_close(ctx.regs["dst"], values[1::2].float(), rtol=0, atol=0)


def test_micro_cast_fp4_e1m2_to_bfloat16_decodes_layout_zero() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.fp4_e1m2, name="src")
    dst = Reg(DT.bfloat16, name="dst")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask")
    cfg = CastConfig(round_mode=RoundMode.NONE, reg_layout=RegLayout.ZERO, name="cfg")
    values = torch.linspace(-2.0, 2.0, 128, dtype=torch.bfloat16)
    carrier = fp32_to_fp4_e1m2(values.float(), round_mode=RoundMode.TO_EVEN)
    src_storage = torch.zeros(256, dtype=torch.uint8)
    src_storage[0::4] = carrier
    ctx = MicroContext(
        regs={"src": src_storage},
        masks={"mask": torch.ones(128, dtype=torch.bool)},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {"dst": dst, "src": src, "config": cfg, "mask": mask, "ddst": DT.bfloat16},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = fp4_e1m2_to_fp32(carrier, logical_shape=(128,)).to(torch.bfloat16)
    torch.testing.assert_close(ctx.regs["dst"], expected, rtol=0, atol=0)


def test_micro_runtime_supports_min_max() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    a = Var(3.0, name="a")
    b = Var(7.0, name="b")
    lo = Var(0.0, dtype=DT.float, name="lo")
    hi = Var(0.0, dtype=DT.float, name="hi")
    combined = Var(0.0, dtype=DT.float, name="combined")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=a),
            Instruction("create_var", val=b),
            Instruction("create_var", val=lo),
            Instruction("create_var", val=hi),
            Instruction("create_var", val=combined),
            Instruction("create_reg", reg=src),
            Instruction("create_reg", reg=dst),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("Min", a=a, b=b, out=lo),       # 3.0
            Instruction("Max", a=a, b=b, out=hi),       # 7.0
            Instruction("var_add", a=lo, b=hi, out=combined),  # 10.0
            Instruction("micro_vdup", dst=src, value=1.0),
            Instruction("micro_vmuls", dst=dst, src=src, v=combined),
            Instruction("micro_reg2ub", dst=out_ref, src=dst, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    torch.testing.assert_close(out, torch.full_like(out, 10.0))


def test_micro_runtime_supports_ceil_div_and_integer_division() -> None:
    runtime = MicroRuntime()
    numerator = Var(257, name="numerator")
    groups = Var(0, name="groups")
    quotient = Var(0, name="quotient")
    remainder = Var(0, name="remainder")
    micro_def = {
        "instructions": [
            Instruction("create_var", val=numerator),
            Instruction("create_var", val=groups),
            Instruction("create_var", val=quotient),
            Instruction("create_var", val=remainder),
            Instruction("CeilDiv", a=numerator, b=128, out=groups),
            Instruction("var_div", a=numerator, b=128, out=quotient),
            Instruction("var_mod", a=numerator, b=128, out=remainder),
        ]
    }

    runtime.execute_call_micro(micro_def, {}, {}, SharedMemoryStore())
    assert runtime._ctx is None
    # Exercise the same handlers directly to inspect their destination state.
    context = MicroContext(var_values={"numerator": 257})
    runtime._stack.append(context)
    try:
        runtime._dispatch(
            "CeilDiv", {"a": numerator, "b": 128, "out": groups},
            SharedMemoryStore(),
        )
        runtime._dispatch(
            "var_div", {"a": numerator, "b": 128, "out": quotient},
            SharedMemoryStore(),
        )
        runtime._dispatch(
            "var_mod", {"a": numerator, "b": 128, "out": remainder},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()
    assert context.var_values["groups"] == 3
    assert context.var_values["quotient"] == 2
    assert context.var_values["remainder"] == 1


def test_micro_cast_hif8_to_float_uses_hif8_decode() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.hif8, name="src")
    dst = Reg(DT.float, name="dst")
    mask = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask")
    codes = torch.zeros(256, dtype=torch.uint8)
    codes[torch.arange(64) * 4] = torch.arange(64, dtype=torch.uint8)
    ctx = MicroContext(
        regs={"src": codes},
        masks={"mask": torch.ones(64, dtype=torch.bool)},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {
                "dst": dst,
                "src": src,
                "config": CastConfig(round_mode=RoundMode.NONE, reg_layout=RegLayout.ZERO, name="cfg"),
                "mask": mask,
                "ddst": DT.float,
            },
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    torch.testing.assert_close(ctx.regs["dst"], hif8_to_fp32(torch.arange(64, dtype=torch.uint8)), rtol=0, atol=0)


@pytest.mark.parametrize("round_mode", [RoundMode.FLOOR, RoundMode.HYBRID, RoundMode.ODD])
def test_micro_cast_hif8_to_float_ignores_round_mode(round_mode) -> None:
    runtime = MicroRuntime()
    src = Reg(DT.hif8, name="src")
    dst = Reg(DT.float, name="dst")
    mask = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask")
    codes = torch.zeros(256, dtype=torch.uint8)
    codes[torch.arange(64) * 4] = torch.arange(64, dtype=torch.uint8)
    ctx = MicroContext(
        regs={"src": codes},
        masks={"mask": torch.ones(64, dtype=torch.bool)},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {
                "dst": dst,
                "src": src,
                "config": CastConfig(round_mode=round_mode, reg_layout=RegLayout.ZERO, name="cfg"),
                "mask": mask,
                "ddst": DT.float,
            },
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    torch.testing.assert_close(ctx.regs["dst"], hif8_to_fp32(torch.arange(64, dtype=torch.uint8)), rtol=0, atol=0)


def test_micro_cast_float_to_hif8_uses_requested_hif8_round_mode() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.hif8, name="dst")
    mask = MaskReg(DT.hif8, init_mode=MaskType.ALL, name="mask")
    values = torch.tensor([1.0, 8.0, 16.0, 20.0, 2.0 ** -22, 32768.0, -16.0, 0.0], dtype=torch.float32)
    values = torch.cat([values, torch.zeros(56, dtype=torch.float32)])
    ctx = MicroContext(
        regs={"src": values},
        masks={"mask": torch.ones(256, dtype=torch.bool)},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {
                "dst": dst,
                "src": src,
                "config": CastConfig(round_mode=RoundMode.HYBRID, reg_layout=RegLayout.ZERO, name="cfg"),
                "mask": mask,
                "ddst": DT.hif8,
            },
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    packed_lanes = ctx.regs["dst"][torch.arange(64) * 4]
    torch.testing.assert_close(packed_lanes, fp32_to_hif8(values, round_mode=RoundMode.HYBRID), rtol=0, atol=0)


def test_micro_cast_hif8_to_half_uses_hif8_decode() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.hif8, name="src")
    dst = Reg(DT.half, name="dst")
    mask = MaskReg(DT.half, init_mode=MaskType.ALL, name="mask")
    codes = torch.zeros(256, dtype=torch.uint8)
    codes[torch.arange(128) * 2] = torch.arange(128, dtype=torch.uint8)
    ctx = MicroContext(
        regs={"src": codes},
        masks={"mask": torch.ones(128, dtype=torch.bool)},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {
                "dst": dst,
                "src": src,
                "config": CastConfig(round_mode=RoundMode.NONE, reg_layout=RegLayout.ZERO, name="cfg"),
                "mask": mask,
                "ddst": DT.half,
            },
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = hif8_to_fp32(torch.arange(128, dtype=torch.uint8)).to(torch.float16)
    torch.testing.assert_close(ctx.regs["dst"], expected, rtol=0, atol=0, equal_nan=True)


def test_micro_cast_half_to_hif8_uses_requested_hif8_round_mode() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.half, name="src")
    dst = Reg(DT.hif8, name="dst")
    mask = MaskReg(DT.hif8, init_mode=MaskType.ALL, name="mask")
    values = torch.tensor(
        [2.0 ** -23, 5 * 2.0 ** -24, 0.005352020263671875, 16.0, -16.0, -2.2709369659423828e-05],
        dtype=torch.float16,
    )
    values = torch.cat([values, torch.zeros(122, dtype=torch.float16)])
    ctx = MicroContext(
        regs={"src": values},
        masks={"mask": torch.ones(256, dtype=torch.bool)},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_cast",
            {
                "dst": dst,
                "src": src,
                "config": CastConfig(round_mode=RoundMode.HYBRID, reg_layout=RegLayout.ZERO, name="cfg"),
                "mask": mask,
                "ddst": DT.hif8,
            },
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    packed_lanes = ctx.regs["dst"][torch.arange(128) * 2]
    torch.testing.assert_close(packed_lanes, fp16_to_hif8(values, round_mode=RoundMode.HYBRID), rtol=0, atol=0)


def test_micro_runtime_supports_uint32_mask_reduce_and_shift() -> None:
    runtime = MicroRuntime()
    src_ref = SimpleNamespace(name="src")
    out_ref = SimpleNamespace(name="out")
    src = Reg(DT.uint32, name="src_reg")
    mask_reg = Reg(DT.uint32, name="mask_reg")
    exp_reg = Reg(DT.uint32, name="exp_reg")
    max_reg = Reg(DT.uint32, name="max_reg")
    scale_reg = Reg(DT.uint32, name="scale_reg")
    mask_low32 = MaskReg(DT.uint32, init_mode=MaskType.LOWEST32, name="mask_low32")
    mask_all = MaskReg(DT.uint32, init_mode=MaskType.ALL, name="mask_all")

    src_tensor = torch.zeros(64, dtype=torch.uint32)
    src_tensor[:4] = torch.tensor([0x3F800000, 0x42000000, 0x41000000, 0xC1800000], dtype=torch.uint32)
    out = torch.zeros(64, dtype=torch.uint32)

    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=src),
            Instruction("create_reg", reg=mask_reg),
            Instruction("create_reg", reg=exp_reg),
            Instruction("create_reg", reg=max_reg),
            Instruction("create_reg", reg=scale_reg),
            Instruction("create_maskreg", reg=mask_low32),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("micro_ub2reg", dst=src, src=src_ref, blk_stride=1, mask=mask_low32),
            Instruction("micro_vdup", dst=mask_reg, value=0x7F800000),
            Instruction("micro_vand", dst=exp_reg, src1=src, src2=mask_reg, mask=mask_low32),
            Instruction("micro_vcmax", dst=max_reg, src=exp_reg, mask=mask_low32),
            Instruction("micro_shiftrs", dst=scale_reg, src=max_reg, v=23, mask=mask_all),
            Instruction("micro_reg2ub", dst=out_ref, src=scale_reg, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(micro_def, {"src": src_tensor, "out": out}, {}, SharedMemoryStore())

    assert int(out[0].item()) == 132
    assert torch.equal(out[1:], torch.zeros_like(out[1:]))


def test_micro_runtime_supports_align_ops() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    n8 = Var(1, DT.int, name="n8")
    n16 = Var(9, DT.int, name="n16")
    n32 = Var(33, DT.int, name="n32")
    n64 = Var(64, DT.int, name="n64")
    n128 = Var(129, DT.int, name="n128")
    n256 = Var(257, DT.int, name="n256")
    a8 = Var(0, DT.int, name="a8")
    a16 = Var(0, DT.int, name="a16")
    a32 = Var(0, DT.int, name="a32")
    a64 = Var(0, DT.int, name="a64")
    a128 = Var(0, DT.int, name="a128")
    a256 = Var(0, DT.int, name="a256")
    total = Var(0, DT.int, name="total")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=n8),
            Instruction("create_var", val=n16),
            Instruction("create_var", val=n32),
            Instruction("create_var", val=n64),
            Instruction("create_var", val=n128),
            Instruction("create_var", val=n256),
            Instruction("create_var", val=a8),
            Instruction("create_var", val=a16),
            Instruction("create_var", val=a32),
            Instruction("create_var", val=a64),
            Instruction("create_var", val=a128),
            Instruction("create_var", val=a256),
            Instruction("create_var", val=total),
            Instruction("create_reg", reg=src),
            Instruction("create_reg", reg=dst),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("Align8", a=n8, out=a8),
            Instruction("Align16", a=n16, out=a16),
            Instruction("Align32", a=n32, out=a32),
            Instruction("Align64", a=n64, out=a64),
            Instruction("Align128", a=n128, out=a128),
            Instruction("Align256", a=n256, out=a256),
            Instruction("var_add", a=a8, b=a16, out=total),
            Instruction("var_add", a=total, b=a32, out=total),
            Instruction("var_add", a=total, b=a64, out=total),
            Instruction("var_add", a=total, b=a128, out=total),
            Instruction("var_add", a=total, b=a256, out=total),
            Instruction("micro_vdup", dst=src, value=1.0),
            Instruction("micro_vmuls", dst=dst, src=src, v=total),
            Instruction("micro_reg2ub", dst=out_ref, src=dst, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    torch.testing.assert_close(out, torch.full_like(out, 920.0))


def test_micro_runtime_align_suffix_must_be_numeric() -> None:
    runtime = MicroRuntime()
    n = Var(9, DT.int, name="n")
    out_var = Var(0, DT.int, name="out_var")
    micro_def = {
        "instructions": [
            Instruction("create_var", val=n),
            Instruction("create_var", val=out_var),
            Instruction("AlignFoo", a=n, out=out_var),
        ]
    }

    with pytest.raises(ValueError, match="Align opcode suffix must be numeric: AlignFoo"):
        runtime.execute_call_micro(micro_def, {}, {}, SharedMemoryStore())


def test_micro_arange_uses_current_v_and_mode_protocol() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.float, name="dst")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=dst),
            Instruction("create_maskreg", reg=mask_all),
            Instruction(
                "micro_arange",
                dst=dst,
                v=1.5,
                dtype=DT.float,
                mode="MicroAPI::IndexOrder::DECREASE_ORDER",
            ),
            Instruction("micro_reg2ub", dst=out_ref, src=dst, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    expected = 1.5 - torch.arange(64, dtype=torch.float32)
    torch.testing.assert_close(out, expected)
def test_micro_compare_select_supports_current_mask_protocol() -> None:
    runtime = MicroRuntime()
    cols = Reg(DT.float, name="cols")
    limit = Reg(DT.float, name="limit")
    fill = Reg(DT.float, name="fill")
    out_reg = Reg(DT.float, name="out_reg")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=cols),
            Instruction("create_reg", reg=limit),
            Instruction("create_reg", reg=fill),
            Instruction("create_reg", reg=out_reg),
            Instruction("create_maskreg", reg=mask),
            Instruction("create_maskreg", reg=mask_all),
            Instruction(
                "micro_arange",
                dst=cols,
                v=0.0,
                dtype=DT.float,
                mode="MicroAPI::IndexOrder::INCREASE_ORDER",
            ),
            Instruction("micro_vdup", dst=limit, src=4.0),
            Instruction("micro_vdup", dst=fill, src=-1.0),
            Instruction("micro_compare", dst=mask, src1=cols, src2=limit, mode=CompareMode.LT),
            Instruction("micro_select", dst=out_reg, src1=cols, src2=fill, mask=mask),
            Instruction("micro_reg2ub", dst=out_ref, src=out_reg, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    expected = torch.where(torch.arange(64, dtype=torch.float32) < 4.0, torch.arange(64, dtype=torch.float32), torch.full((64,), -1.0))
    torch.testing.assert_close(out, expected)
def test_micro_compares_supports_scalar_compare_and_vdup_src_var() -> None:
    runtime = MicroRuntime()
    cols = Reg(DT.float, name="cols")
    fill = Reg(DT.float, name="fill")
    out_reg = Reg(DT.float, name="out_reg")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    threshold = Var(3.5, name="threshold")
    out_ref = SimpleNamespace(name="out")
    out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=threshold),
            Instruction("create_reg", reg=cols),
            Instruction("create_reg", reg=fill),
            Instruction("create_reg", reg=out_reg),
            Instruction("create_maskreg", reg=mask),
            Instruction("create_maskreg", reg=mask_all),
            Instruction(
                "micro_arange",
                dst=cols,
                v=0.0,
                dtype=DT.float,
                mode="MicroAPI::IndexOrder::INCREASE_ORDER",
            ),
            Instruction("micro_vdup", dst=fill, src=threshold),
            Instruction("micro_compares", dst=mask, src1=cols, src2=threshold, mode=CompareMode.LT),
            Instruction("micro_select", dst=out_reg, src1=cols, src2=fill, mask=mask),
            Instruction("micro_reg2ub", dst=out_ref, src=out_reg, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(micro_def, {"out": out}, {}, SharedMemoryStore())

    expected = torch.where(
        torch.arange(64, dtype=torch.float32) < 3.5,
        torch.arange(64, dtype=torch.float32),
        torch.full((64,), 3.5, dtype=torch.float32),
    )
    torch.testing.assert_close(out, expected)


def test_micro_math_masks_zero_inactive_dst_lanes_and_var_assigns() -> None:
    runtime = MicroRuntime()
    a = Reg(DT.float, name="a")
    b = Reg(DT.float, name="b")
    binary = Reg(DT.float, name="binary")
    unary = Reg(DT.float, name="unary")
    scalar = Reg(DT.float, name="scalar")
    exec_mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="exec_mask")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    rows = Var(17, DT.int, name="rows")
    n_valid = Var(0, DT.uint32, name="n_valid")
    binary_ref = SimpleNamespace(name="binary")
    unary_ref = SimpleNamespace(name="unary")
    scalar_ref = SimpleNamespace(name="scalar")
    src_ref = SimpleNamespace(name="src")
    binary_out = torch.full((64,), -1.0, dtype=torch.float32)
    unary_out = torch.full((64,), -1.0, dtype=torch.float32)
    scalar_out = torch.full((64,), -1.0, dtype=torch.float32)
    src_out = torch.full((64,), -1.0, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=rows),
            Instruction("create_var", val=n_valid),
            Instruction("create_reg", reg=a),
            Instruction("create_reg", reg=b),
            Instruction("create_reg", reg=binary),
            Instruction("create_reg", reg=unary),
            Instruction("create_reg", reg=scalar),
            Instruction("create_maskreg", reg=exec_mask),
            Instruction("create_maskreg", reg=mask_all),
            Instruction(
                "micro_arange",
                dst=a,
                v=0.0,
                dtype=DT.float,
                mode="MicroAPI::IndexOrder::INCREASE_ORDER",
            ),
            Instruction("micro_vdup", dst=b, src=2.0),
            Instruction("var_assign", out=n_valid, src=rows),
            Instruction("micro_updatemask", dst=exec_mask, cnt=n_valid),
            Instruction("micro_vadd", dst=binary, src1=a, src2=b, mask=exec_mask),
            Instruction("micro_vneg", dst=unary, src=a, mask=exec_mask),
            Instruction("micro_vadds", dst=scalar, src=a, v=10.0, mask=exec_mask),
            Instruction("micro_reg2ub", dst=binary_ref, src=binary, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=unary_ref, src=unary, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=scalar_ref, src=scalar, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=src_ref, src=a, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(
        micro_def,
        {"binary": binary_out, "unary": unary_out, "scalar": scalar_out, "src": src_out},
        {},
        SharedMemoryStore(),
    )

    lanes = torch.arange(64, dtype=torch.float32)
    active = lanes < 17
    torch.testing.assert_close(binary_out, torch.where(active, lanes + 2.0, torch.zeros_like(lanes)))
    torch.testing.assert_close(unary_out, torch.where(active, -lanes, torch.zeros_like(lanes)))
    torch.testing.assert_close(scalar_out, torch.where(active, lanes + 10.0, torch.zeros_like(lanes)))
    torch.testing.assert_close(src_out, lanes)


def test_micro_var_assign_rejects_int_float_conversions() -> None:
    runtime = MicroRuntime()
    src_int = Var(7, DT.int, name="src_int")
    src_float = Var(1.5, DT.float, name="src_float")
    dst_float = Var(0.0, DT.float, name="dst_float")
    dst_int = Var(0, DT.int, name="dst_int")

    with pytest.raises(TypeError, match="int -> float"):
        runtime.execute_call_micro(
            {
                "instructions": [
                    Instruction("create_var", val=src_int),
                    Instruction("create_var", val=dst_float),
                    Instruction("var_assign", out=dst_float, src=src_int),
                ]
            },
            {},
            {},
            SharedMemoryStore(),
        )

    with pytest.raises(TypeError, match="float -> int"):
        runtime.execute_call_micro(
            {
                "instructions": [
                    Instruction("create_var", val=src_float),
                    Instruction("create_var", val=dst_int),
                    Instruction("var_assign", out=dst_int, src=src_float),
                ]
            },
            {},
            {},
            SharedMemoryStore(),
        )
def test_micro_mask_binary_ops_support_current_protocol() -> None:
    runtime = MicroRuntime()
    cols = Reg(DT.float, name="cols")
    ones = Reg(DT.float, name="ones")
    zeros = Reg(DT.float, name="zeros")
    and_reg = Reg(DT.float, name="and_reg")
    or_reg = Reg(DT.float, name="or_reg")
    xor_reg = Reg(DT.float, name="xor_reg")
    sel_reg = Reg(DT.float, name="sel_reg")

    m_lt8 = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_lt8")
    m_lt16 = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_lt16")
    m_lt32 = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_lt32")
    m_ge32 = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_ge32")
    m_and = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_and")
    m_or = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_or")
    m_xor = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_xor")
    m_sel = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_sel")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")

    threshold8 = Var(8.0, name="threshold8")
    threshold16 = Var(16.0, name="threshold16")
    threshold32 = Var(32.0, name="threshold32")

    and_out_ref = SimpleNamespace(name="and_out")
    or_out_ref = SimpleNamespace(name="or_out")
    xor_out_ref = SimpleNamespace(name="xor_out")
    sel_out_ref = SimpleNamespace(name="sel_out")
    and_out = torch.zeros(64, dtype=torch.float32)
    or_out = torch.zeros(64, dtype=torch.float32)
    xor_out = torch.zeros(64, dtype=torch.float32)
    sel_out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=threshold8),
            Instruction("create_var", val=threshold16),
            Instruction("create_var", val=threshold32),
            Instruction("create_reg", reg=cols),
            Instruction("create_reg", reg=ones),
            Instruction("create_reg", reg=zeros),
            Instruction("create_reg", reg=and_reg),
            Instruction("create_reg", reg=or_reg),
            Instruction("create_reg", reg=xor_reg),
            Instruction("create_reg", reg=sel_reg),
            Instruction("create_maskreg", reg=m_lt8),
            Instruction("create_maskreg", reg=m_lt16),
            Instruction("create_maskreg", reg=m_lt32),
            Instruction("create_maskreg", reg=m_ge32),
            Instruction("create_maskreg", reg=m_and),
            Instruction("create_maskreg", reg=m_or),
            Instruction("create_maskreg", reg=m_xor),
            Instruction("create_maskreg", reg=m_sel),
            Instruction("create_maskreg", reg=mask_all),
            Instruction(
                "micro_arange",
                dst=cols,
                v=0.0,
                dtype=DT.float,
                mode="MicroAPI::IndexOrder::INCREASE_ORDER",
            ),
            Instruction("micro_vdup", dst=ones, src=1.0),
            Instruction("micro_vdup", dst=zeros, src=0.0),
            Instruction("micro_compares", dst=m_lt8, src1=cols, src2=threshold8, mode=CompareMode.LT),
            Instruction("micro_compares", dst=m_lt16, src1=cols, src2=threshold16, mode=CompareMode.LT),
            Instruction("micro_compares", dst=m_lt32, src1=cols, src2=threshold32, mode=CompareMode.LT),
            Instruction("micro_compares", dst=m_ge32, src1=cols, src2=threshold32, mode=CompareMode.GE),
            Instruction("micro_maskand", dst=m_and, src1=m_lt8, src2=m_lt16, mask=m_lt32),
            Instruction("micro_maskor", dst=m_or, src1=m_lt8, src2=m_ge32, mask=m_lt32),
            Instruction("micro_maskxor", dst=m_xor, src1=m_lt16, src2=m_lt32, mask=m_lt32),
            Instruction("micro_masksel", dst=m_sel, src1=m_lt8, src2=m_ge32, mask=m_lt32),
            Instruction("micro_select", dst=and_reg, src1=ones, src2=zeros, mask=m_and),
            Instruction("micro_select", dst=or_reg, src1=ones, src2=zeros, mask=m_or),
            Instruction("micro_select", dst=xor_reg, src1=ones, src2=zeros, mask=m_xor),
            Instruction("micro_select", dst=sel_reg, src1=ones, src2=zeros, mask=m_sel),
            Instruction("micro_reg2ub", dst=and_out_ref, src=and_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=or_out_ref, src=or_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=xor_out_ref, src=xor_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=sel_out_ref, src=sel_reg, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(
        micro_def,
        {
            "and_out": and_out,
            "or_out": or_out,
            "xor_out": xor_out,
            "sel_out": sel_out,
        },
        {},
        SharedMemoryStore(),
    )

    cols_ref = torch.arange(64, dtype=torch.float32)
    ones_ref = torch.ones(64, dtype=torch.float32)
    zeros_ref = torch.zeros(64, dtype=torch.float32)
    lt8 = cols_ref < 8.0
    lt16 = cols_ref < 16.0
    lt32 = cols_ref < 32.0
    ge32 = cols_ref >= 32.0

    # mask_and / mask_or / mask_xor carry an execution mask (m_lt32, active on
    # lanes 0..31). Active lanes take the computed result; inactive lanes 32..63
    # preserve the destination mask's initial NONE (all-False) value. mask_sel's
    # mask argument is the selector, not an execution mask, so it writes all lanes.
    none_bits = torch.zeros(64, dtype=torch.bool)
    and_bits = torch.where(lt32, lt8 & lt16, none_bits)
    or_bits = torch.where(lt32, lt8 | ge32, none_bits)
    xor_bits = torch.where(lt32, torch.logical_xor(lt16, lt32), none_bits)
    sel_bits = torch.where(lt32, lt8, ge32)

    and_expected = torch.where(and_bits, ones_ref, zeros_ref)
    or_expected = torch.where(or_bits, ones_ref, zeros_ref)
    xor_expected = torch.where(xor_bits, ones_ref, zeros_ref)
    sel_expected = torch.where(sel_bits, ones_ref, zeros_ref)

    torch.testing.assert_close(and_out, and_expected)
    torch.testing.assert_close(or_out, or_expected)
    torch.testing.assert_close(xor_out, xor_expected)
    torch.testing.assert_close(sel_out, sel_expected)


def test_micro_masked_reductions_and_dup_honor_execution_mask() -> None:
    runtime = MicroRuntime()
    cols = Reg(DT.float, name="cols")
    ones = Reg(DT.float, name="ones")
    zeros = Reg(DT.float, name="zeros")
    dup_reg = Reg(DT.float, name="dup_reg")
    cadd_reg = Reg(DT.float, name="cadd_reg")
    cmax_reg = Reg(DT.float, name="cmax_reg")
    cpadd_reg = Reg(DT.float, name="cpadd_reg")
    cmp_sel_reg = Reg(DT.float, name="cmp_sel_reg")
    m_active = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_active")
    m_cmp = MaskReg(DT.float, init_mode=MaskType.NONE, name="m_cmp")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    threshold4 = Var(4.0, name="threshold4")
    threshold2 = Var(2.0, name="threshold2")

    dup_out_ref = SimpleNamespace(name="dup_out")
    cadd_out_ref = SimpleNamespace(name="cadd_out")
    cmax_out_ref = SimpleNamespace(name="cmax_out")
    cpadd_out_ref = SimpleNamespace(name="cpadd_out")
    cmp_out_ref = SimpleNamespace(name="cmp_out")
    dup_out = torch.zeros(64, dtype=torch.float32)
    cadd_out = torch.zeros(64, dtype=torch.float32)
    cmax_out = torch.zeros(64, dtype=torch.float32)
    cpadd_out = torch.zeros(64, dtype=torch.float32)
    cmp_out = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=threshold4),
            Instruction("create_var", val=threshold2),
            Instruction("create_reg", reg=cols),
            Instruction("create_reg", reg=ones),
            Instruction("create_reg", reg=zeros),
            Instruction("create_reg", reg=dup_reg),
            Instruction("create_reg", reg=cadd_reg),
            Instruction("create_reg", reg=cmax_reg),
            Instruction("create_reg", reg=cpadd_reg),
            Instruction("create_reg", reg=cmp_sel_reg),
            Instruction("create_maskreg", reg=m_active),
            Instruction("create_maskreg", reg=m_cmp),
            Instruction("create_maskreg", reg=mask_all),
            Instruction(
                "micro_arange",
                dst=cols,
                v=0.0,
                dtype=DT.float,
                mode="MicroAPI::IndexOrder::INCREASE_ORDER",
            ),
            Instruction("micro_vdup", dst=ones, src=1.0),
            Instruction("micro_vdup", dst=zeros, src=0.0),
            # m_active = cols < 4 -> active lanes 0..3 (built with no execution mask)
            Instruction("micro_compares", dst=m_active, src1=cols, src2=threshold4, mode=CompareMode.LT),
            # masked dup: active lanes take 7.0, inactive lanes are zeroed
            Instruction("micro_vdup", dst=dup_reg, src=7.0, mask=m_active),
            # masked reductions over the active lanes only
            Instruction("micro_vcadd", dst=cadd_reg, src=cols, mask=m_active),
            Instruction("micro_vcmax", dst=cmax_reg, src=cols, mask=m_active),
            Instruction("micro_vcpadd", dst=cpadd_reg, src=cols, mask=m_active),
            # masked compare into a NONE mask: active lanes compute cols>=2, inactive preserve False
            Instruction("micro_compares", dst=m_cmp, src1=cols, src2=threshold2, mode=CompareMode.GE, mask=m_active),
            Instruction("micro_select", dst=cmp_sel_reg, src1=ones, src2=zeros, mask=m_cmp),
            Instruction("micro_reg2ub", dst=dup_out_ref, src=dup_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=cadd_out_ref, src=cadd_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=cmax_out_ref, src=cmax_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=cpadd_out_ref, src=cpadd_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=cmp_out_ref, src=cmp_sel_reg, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(
        micro_def,
        {
            "dup_out": dup_out,
            "cadd_out": cadd_out,
            "cmax_out": cmax_out,
            "cpadd_out": cpadd_out,
            "cmp_out": cmp_out,
        },
        {},
        SharedMemoryStore(),
    )

    # dup: active lanes 0..3 take 7.0; inactive lanes are zeroed.
    dup_expected = torch.zeros(64, dtype=torch.float32)
    dup_expected[:4] = 7.0
    torch.testing.assert_close(dup_out, dup_expected)

    # cadd over active lanes -> 0+1+2+3 = 6 written to dst[0].
    cadd_expected = torch.zeros(64, dtype=torch.float32)
    cadd_expected[0] = 6.0
    torch.testing.assert_close(cadd_out, cadd_expected)

    # cmax over active lanes -> max(0,1,2,3) = 3 written to dst[0].
    cmax_expected = torch.zeros(64, dtype=torch.float32)
    cmax_expected[0] = 3.0
    torch.testing.assert_close(cmax_out, cmax_expected)

    # cpadd: pair0 = 0+1 = 1, pair1 = 2+3 = 5; inactive lanes contribute 0.
    cpadd_expected = torch.zeros(64, dtype=torch.float32)
    cpadd_expected[0] = 1.0
    cpadd_expected[1] = 5.0
    torch.testing.assert_close(cpadd_out, cpadd_expected)

    # masked compare: active lanes 2,3 satisfy cols>=2; inactive lanes preserve False.
    cmp_expected = torch.zeros(64, dtype=torch.float32)
    cmp_expected[2] = 1.0
    cmp_expected[3] = 1.0
    torch.testing.assert_close(cmp_out, cmp_expected)


@pytest.mark.parametrize(
    ("counter_name", "active_counts"),
    [("cnt", (64, 6, 0)), ("", (64, 64, 64))],
)
def test_micro_updatemask_matches_named_and_temporary_codegen(
    counter_name: str, active_counts: tuple,
) -> None:
    runtime = MicroRuntime()
    ones = Reg(DT.float, name="ones")
    zeros = Reg(DT.float, name="zeros")
    out_reg = Reg(DT.float, name="out_reg")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    cnt = Var(70, dtype=DT.uint32, name=counter_name)

    out0_ref = SimpleNamespace(name="out0")
    out1_ref = SimpleNamespace(name="out1")
    out2_ref = SimpleNamespace(name="out2")
    out0 = torch.zeros(64, dtype=torch.float32)
    out1 = torch.zeros(64, dtype=torch.float32)
    out2 = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_var", val=cnt),
            Instruction("create_reg", reg=ones),
            Instruction("create_reg", reg=zeros),
            Instruction("create_reg", reg=out_reg),
            Instruction("create_maskreg", reg=mask),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("micro_vdup", dst=ones, src=1.0),
            Instruction("micro_vdup", dst=zeros, src=0.0),
            Instruction("micro_updatemask", dst=mask, cnt=cnt),
            Instruction("micro_select", dst=out_reg, src1=ones, src2=zeros, mask=mask),
            Instruction("micro_reg2ub", dst=out0_ref, src=out_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_updatemask", dst=mask, cnt=cnt),
            Instruction("micro_select", dst=out_reg, src1=ones, src2=zeros, mask=mask),
            Instruction("micro_reg2ub", dst=out1_ref, src=out_reg, blk_stride=1, mask=mask_all),
            Instruction("micro_updatemask", dst=mask, cnt=cnt),
            Instruction("micro_select", dst=out_reg, src1=ones, src2=zeros, mask=mask),
            Instruction("micro_reg2ub", dst=out2_ref, src=out_reg, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(
        micro_def,
        {"out0": out0, "out1": out1, "out2": out2},
        {},
        SharedMemoryStore(),
    )

    expected = []
    for active_count in active_counts:
        value = torch.zeros(64, dtype=torch.float32)
        value[:active_count] = 1.0
        expected.append(value)

    torch.testing.assert_close(out0, expected[0])
    torch.testing.assert_close(out1, expected[1])
    torch.testing.assert_close(out2, expected[2])


def test_micro_gathermask_compacts_active_lanes() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")

    ctx = MicroContext(
        regs={
            "src": torch.tensor([10.0, 20.0, 30.0, 40.0] + [0.0] * 60, dtype=torch.float32),
            "dst": torch.full((64,), -1.0, dtype=torch.float32),
        },
        masks={
            "mask": torch.tensor([True, False, True, False] + [False] * 60, dtype=torch.bool),
        },
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_gathermask", {"dst": dst, "src": src, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()

    expected = torch.zeros(64, dtype=torch.float32)
    expected[:2] = torch.tensor([10.0, 30.0], dtype=torch.float32)
    torch.testing.assert_close(ctx.regs["dst"], expected)
def test_micro_create_maskreg_supports_m3_m4_like_v2() -> None:
    runtime = MicroRuntime()
    ones = Reg(DT.float, name="ones")
    zeros = Reg(DT.float, name="zeros")
    out_m3 = Reg(DT.float, name="out_m3")
    out_m4 = Reg(DT.float, name="out_m4")
    mask_m3 = MaskReg(DT.float, init_mode=MaskType.MULTI3, name="mask_m3")
    mask_m4 = MaskReg(DT.float, init_mode=MaskType.MULTI4, name="mask_m4")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")

    out_m3_ref = SimpleNamespace(name="out_m3_ref")
    out_m4_ref = SimpleNamespace(name="out_m4_ref")
    buf_m3 = torch.zeros(64, dtype=torch.float32)
    buf_m4 = torch.zeros(64, dtype=torch.float32)

    micro_def = {
        "instructions": [
            Instruction("create_reg", reg=ones),
            Instruction("create_reg", reg=zeros),
            Instruction("create_reg", reg=out_m3),
            Instruction("create_reg", reg=out_m4),
            Instruction("create_maskreg", reg=mask_m3),
            Instruction("create_maskreg", reg=mask_m4),
            Instruction("create_maskreg", reg=mask_all),
            Instruction("micro_vdup", dst=ones, src=1.0),
            Instruction("micro_vdup", dst=zeros, src=0.0),
            Instruction("micro_select", dst=out_m3, src1=ones, src2=zeros, mask=mask_m3),
            Instruction("micro_select", dst=out_m4, src1=ones, src2=zeros, mask=mask_m4),
            Instruction("micro_reg2ub", dst=out_m3_ref, src=out_m3, blk_stride=1, mask=mask_all),
            Instruction("micro_reg2ub", dst=out_m4_ref, src=out_m4, blk_stride=1, mask=mask_all),
        ]
    }

    runtime.execute_call_micro(
        micro_def,
        {"out_m3_ref": buf_m3, "out_m4_ref": buf_m4},
        {},
        SharedMemoryStore(),
    )

    expected_m3 = torch.zeros(64, dtype=torch.float32)
    expected_m3[::3] = 1.0
    expected_m4 = torch.zeros(64, dtype=torch.float32)
    expected_m4[::4] = 1.0

    torch.testing.assert_close(buf_m3, expected_m3)
    torch.testing.assert_close(buf_m4, expected_m4)


def test_micro_runtime_executes_ceildiv_for_runtime_loop_bounds() -> None:
    runtime = MicroRuntime()
    numerator = Var(65, DT.int, name="numerator")
    blocks = Var(0, DT.int, name="blocks")
    ctx = MicroContext(var_values={"numerator": 65, "blocks": 0})
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "CeilDiv", {"a": numerator, "b": 64, "out": blocks},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()
    assert ctx.var_values["blocks"] == 2
