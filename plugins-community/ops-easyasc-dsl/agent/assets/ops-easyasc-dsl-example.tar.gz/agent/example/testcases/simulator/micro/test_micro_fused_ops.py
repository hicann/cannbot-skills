from contextlib import contextmanager

import pytest
import torch

from easyasc import globvars
from easyasc.parser.asc import translate
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.stub_functions.micro.fused import abssub, expsub, muladddst, mulscast
from easyasc.utils.Tensor import Tensor
from easyasc.utils.castconfig import RegLayout
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.positions import Position
from easyasc.utils.reg import MaskReg, Reg
from easyasc.decorators import vf


class _FakeMicro(object):
    def __init__(self) -> None:
        self.instructions = []
        self.tmp_idx = 0

    def _register_reg_name(self, name: str, kind: str) -> None:
        return None

    def get_mask(self, dtype, reg_num=1):
        return MaskReg(dtype, init_mode=MaskType.ALL, name="mask", reg_num=reg_num)


@contextmanager
def _active_fake_micro():
    old_micro = globvars.active_micro
    old_device = globvars.device_type
    fake = _FakeMicro()
    try:
        globvars.device_type = "950"
        globvars.active_micro = fake
        yield fake
    finally:
        globvars.active_micro = old_micro
        globvars.device_type = old_device


def test_stub_expsub_one_remains_outside_plain_cast_guard() -> None:
    with _active_fake_micro() as fake:
        dst = Reg(DT.float, name="dst")
        src0 = Reg(DT.half, name="src0")
        src1 = Reg(DT.half, name="src1")
        expsub(dst, src0, src1, layout=RegLayout.ONE)

    inst = fake.instructions[-1]
    assert inst.opname == "micro_expsub"
    assert inst.kwargs["layout"] == RegLayout.ONE


@pytest.mark.parametrize("dtype", [DT.half, DT.float, DT.int64])
def test_stub_abssub_accepts_doc_dtypes(dtype) -> None:
    with _active_fake_micro() as fake:
        dst = Reg(dtype, name="dst")
        src0 = Reg(dtype, name="src0")
        src1 = Reg(dtype, name="src1")
        abssub(dst, src0, src1)

    inst = fake.instructions[-1]
    assert inst.opname == "micro_abssub"
    assert inst.kwargs["dst"] is dst
    assert inst.kwargs["src1"] is src0
    assert inst.kwargs["src2"] is src1


def test_stub_abssub_rejects_unsupported_dtype() -> None:
    with _active_fake_micro():
        dst = Reg(DT.int, name="dst")
        src0 = Reg(DT.int, name="src0")
        src1 = Reg(DT.int, name="src1")
        with pytest.raises(ValueError, match="abssub dtype must be"):
            abssub(dst, src0, src1)


def test_stub_abssub_rejects_mixed_dtype() -> None:
    with _active_fake_micro():
        dst = Reg(DT.float, name="dst")
        src0 = Reg(DT.float, name="src0")
        src1 = Reg(DT.half, name="src1")
        with pytest.raises(ValueError, match="data types must match"):
            abssub(dst, src0, src1)


def test_micro_abssub_runtime_float_zeroing() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.float, name="dst")
    src0 = Reg(DT.float, name="src0")
    src1 = Reg(DT.float, name="src1")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    bits = torch.tensor([True, False, True, False] + [False] * 60, dtype=torch.bool)
    ctx = MicroContext(
        regs={
            "src0": torch.tensor([1.0, 2.0, -3.0, 4.0] + [0.0] * 60, dtype=torch.float32),
            "src1": torch.tensor([5.0, -4.0, 1.0, 7.0] + [0.0] * 60, dtype=torch.float32),
        },
        masks={"mask": bits},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_abssub",
            {"dst": dst, "src1": src0, "src2": src1, "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = torch.zeros(64, dtype=torch.float32)
    expected[0] = 4.0
    expected[2] = 4.0
    torch.testing.assert_close(ctx.regs["dst"], expected)


def test_micro_abssub_runtime_int64_zeroing() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.int64, name="dst")
    src0 = Reg(DT.int64, name="src0")
    src1 = Reg(DT.int64, name="src1")
    mask = MaskReg(DT.int64, init_mode=MaskType.NONE, name="mask")
    bits = torch.tensor([True, False, True, False] + [False] * 28, dtype=torch.bool)
    ctx = MicroContext(
        regs={
            "src0": torch.tensor([10, -20, -30, 40] + [0] * 28, dtype=torch.int64),
            "src1": torch.tensor([-1, -50, 5, 70] + [0] * 28, dtype=torch.int64),
        },
        masks={"mask": bits},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_abssub",
            {"dst": dst, "src1": src0, "src2": src1, "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = torch.zeros(32, dtype=torch.int64)
    expected[0] = 11
    expected[2] = 35
    assert torch.equal(ctx.regs["dst"], expected)


def test_micro_abssub_codegen_emits_cann_call() -> None:
    @vf()
    def abssub_vf(src0_t: Tensor, src1_t: Tensor, out_t: Tensor):
        dst = Reg(DT.float)
        src0 = Reg(DT.float)
        src1 = Reg(DT.float)
        src0 <<= src0_t[0]
        src1 <<= src1_t[0]
        abssub(dst, src0, src1)
        out_t[0] <<= dst

    old_device = globvars.device_type
    try:
        globvars.device_type = "950"
        abssub_vf(
            Tensor(DT.float, [1, 64], Position.UB),
            Tensor(DT.float, [1, 64], Position.UB),
            Tensor(DT.float, [1, 64], Position.UB),
        )
    finally:
        globvars.device_type = old_device
    code = translate(abssub_vf.instructions)
    assert "MicroAPI::AbsSub(" in code


@pytest.mark.parametrize(
    "dtype",
    [DT.uint16, DT.int16, DT.uint32, DT.int, DT.half, DT.float, DT.bfloat16, DT.uint64, DT.int64],
)
def test_stub_muladddst_accepts_doc_dtypes(dtype) -> None:
    with _active_fake_micro() as fake:
        dst = Reg(dtype, name="dst")
        src0 = Reg(dtype, name="src0")
        src1 = Reg(dtype, name="src1")
        muladddst(dst, src0, src1)

    inst = fake.instructions[-1]
    assert inst.opname == "micro_muladddst"
    assert inst.kwargs["dst"] is dst
    assert inst.kwargs["src1"] is src0
    assert inst.kwargs["src2"] is src1


def test_stub_muladddst_rejects_unsupported_dtype() -> None:
    with _active_fake_micro():
        dst = Reg(DT.uint8, name="dst")
        src0 = Reg(DT.uint8, name="src0")
        src1 = Reg(DT.uint8, name="src1")
        with pytest.raises(ValueError, match="muladddst dtype must be"):
            muladddst(dst, src0, src1)


def test_stub_muladddst_rejects_mixed_dtype() -> None:
    with _active_fake_micro():
        dst = Reg(DT.float, name="dst")
        src0 = Reg(DT.float, name="src0")
        src1 = Reg(DT.half, name="src1")
        with pytest.raises(ValueError, match="data types must match"):
            muladddst(dst, src0, src1)


def test_micro_muladddst_runtime_float_zeroing() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.float, name="dst")
    src0 = Reg(DT.float, name="src0")
    src1 = Reg(DT.float, name="src1")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    bits = torch.tensor([True, False, True, False] + [False] * 60, dtype=torch.bool)
    ctx = MicroContext(
        regs={
            "dst": torch.arange(64, dtype=torch.float32),
            "src0": torch.full((64,), 2.0, dtype=torch.float32),
            "src1": torch.full((64,), 3.0, dtype=torch.float32),
        },
        masks={"mask": bits},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_muladddst",
            {"dst": dst, "src1": src0, "src2": src1, "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = torch.zeros(64, dtype=torch.float32)
    expected[0] = 2.0 * 3.0 + 0.0
    expected[2] = 2.0 * 3.0 + 2.0
    torch.testing.assert_close(ctx.regs["dst"], expected)


def test_micro_muladddst_runtime_float_rounds_once() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.float, name="dst")
    src0 = Reg(DT.float, name="src0")
    src1 = Reg(DT.float, name="src1")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    bits = torch.tensor([True] + [False] * 63, dtype=torch.bool)
    ctx = MicroContext(
        regs={
            "dst": torch.full((64,), 0.9970703125, dtype=torch.float32),
            "src0": torch.full((64,), -0.7283421754837036, dtype=torch.float32),
            "src1": torch.full((64,), 1.3689587116241455, dtype=torch.float32),
        },
        masks={"mask": bits},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_muladddst",
            {"dst": dst, "src1": src0, "src2": src1, "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    fused_bits = int(ctx.regs["dst"][0].view(torch.int32)) & 0xFFFFFFFF
    nonfused = (
        torch.tensor(-0.7283421754837036, dtype=torch.float32)
        * torch.tensor(1.3689587116241455, dtype=torch.float32)
        + torch.tensor(0.9970703125, dtype=torch.float32)
    )
    nonfused_bits = int(nonfused.view(torch.int32)) & 0xFFFFFFFF
    assert fused_bits == 0xB36684A8
    assert nonfused_bits == 0xB3800000
    assert fused_bits != nonfused_bits
    assert torch.count_nonzero(ctx.regs["dst"][1:]) == 0


@pytest.mark.parametrize(("dsl_dtype", "torch_name"), [(DT.uint32, "uint32"), (DT.uint64, "uint64")])
def test_micro_muladddst_runtime_unsigned_zeroing(dsl_dtype, torch_name) -> None:
    if not hasattr(torch, torch_name):
        pytest.skip(f"torch.{torch_name} is unavailable")
    torch_dtype = getattr(torch, torch_name)
    runtime = MicroRuntime()
    dst = Reg(dsl_dtype, name="dst")
    src0 = Reg(dsl_dtype, name="src0")
    src1 = Reg(dsl_dtype, name="src1")
    mask = MaskReg(dsl_dtype, init_mode=MaskType.NONE, name="mask")
    bits = torch.tensor([True, False, True, False] + [False] * 60, dtype=torch.bool)
    ctx = MicroContext(
        regs={
            "dst": torch.tensor([1, 2, 3, 4] + [0] * 60, dtype=torch_dtype),
            "src0": torch.tensor([2, 2, 2, 2] + [0] * 60, dtype=torch_dtype),
            "src1": torch.tensor([5, 5, 5, 5] + [0] * 60, dtype=torch_dtype),
        },
        masks={"mask": bits},
    )

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_muladddst",
            {"dst": dst, "src1": src0, "src2": src1, "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = torch.zeros(64, dtype=torch_dtype)
    expected[0] = 11
    expected[2] = 13
    assert torch.equal(ctx.regs["dst"], expected)


def test_micro_muladddst_codegen_emits_cann_call() -> None:
    @vf()
    def muladddst_vf(src0_t: Tensor, src1_t: Tensor, out_t: Tensor):
        acc = Reg(DT.float)
        src0 = Reg(DT.float)
        src1 = Reg(DT.float)
        acc <<= out_t[0]
        src0 <<= src0_t[0]
        src1 <<= src1_t[0]
        muladddst(acc, src0, src1)
        out_t[0] <<= acc

    old_device = globvars.device_type
    try:
        globvars.device_type = "950"
        muladddst_vf(
            Tensor(DT.float, [1, 64], Position.UB),
            Tensor(DT.float, [1, 64], Position.UB),
            Tensor(DT.float, [1, 64], Position.UB),
        )
    finally:
        globvars.device_type = old_device
    code = translate(muladddst_vf.instructions)
    assert "MicroAPI::MulAddDst(" in code


def test_stub_mulscast_accepts_doc_signature() -> None:
    with _active_fake_micro() as fake:
        dst = Reg(DT.half, name="dst")
        src = Reg(DT.float, name="src")
        mulscast(dst, src, 1.5, layout=RegLayout.ONE)

    inst = fake.instructions[-1]
    assert inst.opname == "micro_mulscast"
    assert inst.kwargs["dst"] is dst
    assert inst.kwargs["src"] is src
    assert inst.kwargs["v"] == "1.5f"
    assert inst.kwargs["mask"].dtype == DT.float
    assert inst.kwargs["layout"] == RegLayout.ONE


def test_stub_mulscast_rejects_wrong_dst_dtype() -> None:
    with _active_fake_micro():
        dst = Reg(DT.float, name="dst")
        src = Reg(DT.float, name="src")
        with pytest.raises(ValueError, match="dst dtype must be half"):
            mulscast(dst, src, 1.5)


def test_stub_mulscast_rejects_wrong_src_dtype() -> None:
    with _active_fake_micro():
        dst = Reg(DT.half, name="dst")
        src = Reg(DT.half, name="src")
        with pytest.raises(ValueError, match="src dtype must be float"):
            mulscast(dst, src, 1.5)


def test_stub_mulscast_rejects_int_scalar() -> None:
    with _active_fake_micro():
        dst = Reg(DT.half, name="dst")
        src = Reg(DT.float, name="src")
        with pytest.raises(TypeError, match="value must be Var or float"):
            mulscast(dst, src, 1)


def test_micro_mulscast_runtime_float_mask_zeroing() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.half, name="dst")
    src = Reg(DT.float, name="src")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    src_values = torch.zeros(64, dtype=torch.float32)
    src_values[0] = 1.25
    src_values[1] = 9.0
    src_values[2] = -2.0
    bits = torch.tensor([True, False, True, False] + [False] * 60, dtype=torch.bool)
    ctx = MicroContext(regs={"src": src_values}, masks={"mask": bits})

    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_mulscast",
            {"dst": dst, "src": src, "v": "2.0f", "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    expected = torch.zeros(128, dtype=torch.float16)
    expected[0] = torch.tensor(2.5, dtype=torch.float16)
    expected[4] = torch.tensor(-4.0, dtype=torch.float16)
    torch.testing.assert_close(ctx.regs["dst"], expected, rtol=0, atol=0)


def test_micro_mulscast_codegen_emits_cann_call() -> None:
    @vf()
    def mulscast_vf(src_t: Tensor, out_t: Tensor):
        dst = Reg(DT.half)
        src = Reg(DT.float)
        src <<= src_t[0]
        mulscast(dst, src, 1.5, layout=RegLayout.ONE)
        out_t[0] <<= dst

    old_device = globvars.device_type
    try:
        globvars.device_type = "950"
        mulscast_vf(
            Tensor(DT.float, [1, 64], Position.UB),
            Tensor(DT.half, [1, 128], Position.UB),
        )
    finally:
        globvars.device_type = old_device
    code = translate(mulscast_vf.instructions)
    assert "MicroAPI::MulsCast<half, float, float, MicroAPI::RegLayout::ONE>(" in code
