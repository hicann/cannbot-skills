"""The a5-only fixpipe scalar quant modes must be rejected on a2.

int32->bf16 (QS322BF16_PRE) and the *scaled* fp32->half/bf16/fp32 casts
(QF322F16/BF16/F32_PRE) are wired only for a5/C310. The stub gates them to
A5_DEVICES; on a2 tracing such a store must raise. The a2+a5 modes (plain casts,
int32->fp16 DEQF16, and 8-bit QF322B8/REQ8) must still trace cleanly on a2.
"""
import pytest

from easyasc.a2 import *


@kernel()
def _int32_to_bf16(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.int, [32, 16], Position.L0C, name="src_l0c")
    out[:, :] <<= src.requant(scale=0.5)
    return out


@kernel()
def _scaled_fp32_to_half(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    out[:, :] <<= src.requant(scale=0.5)
    return out


@kernel()
def _scaled_fp32_to_bf16(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    out[:, :] <<= src.requant(scale=0.5)
    return out


@kernel()
def _scaled_fp32_to_fp32(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    out[:, :] <<= src.requant(scale=0.5)
    return out


@kernel()
def _fp32_to_e4m3(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    out[:, :] <<= src.requant(scale=0.5)   # QF322FP8_PRE (a5-only)
    return out


@kernel()
def _fp32_to_hif8(inp: GMTensor, out: GMTensor):
    # out is a uint8 carrier reinterpreted to hif8 (torch has no hif8 dtype to bind).
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    oh = out.reinterpret(DT.hif8, name="o_hif8")
    oh[:, :] <<= src.requant(scale=0.5)    # QF322HIF8_PRE (a5-only)
    return out


@kernel()
def _plain_fp32_to_half(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    out[:, :] <<= src                      # no requant -> F322F16 cast (a2+a5)
    return out


@kernel()
def _fp32_to_int8_requant(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    out[:, :] <<= src.requant(scale=0.5)   # QF322B8_PRE (a2+a5)
    return out


def _gm(dtype):
    return GMTensor(dtype, [32, 16], name="out")


@pytest.mark.parametrize("kern, dst_dtype", [
    (_int32_to_bf16, DT.bfloat16),
    (_scaled_fp32_to_half, DT.half),
    (_scaled_fp32_to_bf16, DT.bfloat16),
    (_scaled_fp32_to_fp32, DT.float),
    (_fp32_to_e4m3, DT.e4m3),
    (_fp32_to_hif8, DT.uint8),             # carrier dtype; reinterpreted to hif8 in-kernel
])
def test_a5_only_scaled_modes_rejected_on_a2(kern, dst_dtype):
    inp = GMTensor(DT.half, [1, 1], name="inp")
    with pytest.raises(ValueError, match="device_type"):
        kern(inp, _gm(dst_dtype))


@pytest.mark.parametrize("kern, dst_dtype", [
    (_plain_fp32_to_half, DT.half),        # unscaled cast stays a2+a5
    (_fp32_to_int8_requant, DT.int8),      # 8-bit quant stays a2+a5
])
def test_shared_modes_allowed_on_a2(kern, dst_dtype):
    inp = GMTensor(DT.half, [1, 1], name="inp")
    kern(inp, _gm(dst_dtype))              # must not raise
    found = [i for i in kern.instructions if i.opname == "l0c_to_gm_nz2nd"]
    assert len(found) == 1


@pytest.mark.easyasc_device("a5")
def test_a5_only_scaled_modes_allowed_on_a5():
    inp = GMTensor(DT.half, [1, 1], name="inp")
    for kern, dst in ((_int32_to_bf16, DT.bfloat16), (_scaled_fp32_to_half, DT.half),
                      (_scaled_fp32_to_bf16, DT.bfloat16), (_scaled_fp32_to_fp32, DT.float),
                      (_fp32_to_e4m3, DT.e4m3), (_fp32_to_hif8, DT.uint8)):
        kern(inp, _gm(dst))                # must not raise on a5
        found = [i for i in kern.instructions if i.opname == "l0c_to_gm_nz2nd"]
        assert len(found) == 1
