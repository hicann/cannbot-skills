import pytest
import torch

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


pytestmark = pytest.mark.easyasc_device("b3")


@pytest.mark.parametrize("dtype", [DT.int16, DT.int, DT.int64])
def test_var_mod_preserves_integer_dtype_and_cpp_signed_semantics(dtype) -> None:
    result = var_mod(Var(-10, dtype), Var(3, dtype))

    assert result.dtype is dtype
    assert result.value == -1


def test_var_mod_rejects_mixed_var_dtypes() -> None:
    with pytest.raises(TypeError, match="matching integer data types"):
        var_mod(Var(10, DT.int16), Var(3, DT.int))


@kernel(mode="vec")
def _int64_mod_kernel(x: GMTensor, y: GMTensor, contract: Var):
    value = Var(0, DT.int64, name="value")
    divisor = Var(3, DT.int64, name="divisor")
    with vec_scope():
        value.GetValueFrom(x[0:1, 0:1])
        remainder = var_mod(value, divisor, name="remainder")
        remainder.SetValueTo(y[0:1, 0:1])
    return y


def test_var_mod_int64_codegen_uses_native_cpp_remainder() -> None:
    x = GMTensor(DT.int64, [1, 1], name="x")
    y = GMTensor(DT.int64, [1, 1], name="y")
    _int64_mod_kernel(x, y, Var(-1))

    _, vec_code = translate_split(
        _int64_mod_kernel.instructions, "_int64_mod_kernel", kernel_mode="vec"
    )

    assert "int64_t value" in vec_code
    assert "int64_t value = 0;" in vec_code
    assert "int64_t remainder" in vec_code
    assert "remainder = ((value) % (divisor));" in vec_code


def test_sim_var_mod_int64_negative_value() -> None:
    x = torch.tensor([[-10]], dtype=torch.int64)
    y = torch.zeros_like(x)

    got = OpExec(
        _int64_mod_kernel,
        out_dir="./tmp/test_sim_var_mod_int64_negative_value",
        simulator=True,
    )(x, y, -1)

    torch.testing.assert_close(got, torch.tensor([[-1]], dtype=torch.int64), rtol=0, atol=0)
