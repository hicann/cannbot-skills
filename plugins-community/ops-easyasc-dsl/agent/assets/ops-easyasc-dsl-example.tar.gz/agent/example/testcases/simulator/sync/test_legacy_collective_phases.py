import threading

import pytest

from easyasc.simulator.sync import CrossCoreSync


def test_legacy_allcube_wait_is_phase_safe() -> None:
    sync = CrossCoreSync(core_count=2)
    sync.prepare()

    sync.allcube_ready(0, 1)
    sync.allcube_ready(1, 1)

    assert sync.allcube_wait(0, 1, timeout=0.01)
    assert sync.allcube_wait(1, 1, timeout=0.01)


def test_legacy_allvec_wait_tracks_per_vec_participant() -> None:
    sync = CrossCoreSync(core_count=2)
    sync.prepare()

    sync.allvec_ready(0, 0, 2)
    sync.allvec_ready(1, 0, 2)
    assert not sync.allvec_wait(0, 0, 2, timeout=0.01)

    sync.allvec_ready(0, 1, 2)
    sync.allvec_ready(1, 1, 2)

    assert sync.allvec_wait(0, 0, 2, timeout=0.01)
    assert sync.allvec_wait(1, 0, 2, timeout=0.01)
    assert sync.allvec_wait(0, 1, 2, timeout=0.01)
    assert sync.allvec_wait(1, 1, 2, timeout=0.01)


def test_legacy_allcube_wait_wakes_when_all_participants_are_ready() -> None:
    sync = CrossCoreSync(core_count=2)
    sync.prepare()
    entered = threading.Event()
    done = threading.Event()
    result = []

    def waiter() -> None:
        entered.set()
        result.append(sync.allcube_wait(0, 1, timeout=1.0))
        done.set()

    thread = threading.Thread(target=waiter)
    thread.start()
    assert entered.wait(timeout=1.0)
    assert not done.wait(timeout=0.01)

    sync.allcube_ready(0, 1)
    assert not done.wait(timeout=0.01)
    sync.allcube_ready(1, 1)

    assert done.wait(timeout=1.0)
    thread.join(timeout=1.0)
    assert result == [True]


def test_legacy_allvec_wait_wakes_when_all_participants_are_ready() -> None:
    sync = CrossCoreSync(core_count=2)
    sync.prepare()
    entered = threading.Event()
    done = threading.Event()
    result = []

    def waiter() -> None:
        entered.set()
        result.append(sync.allvec_wait(0, 0, 2, timeout=1.0))
        done.set()

    thread = threading.Thread(target=waiter)
    thread.start()
    assert entered.wait(timeout=1.0)
    assert not done.wait(timeout=0.01)

    sync.allvec_ready(0, 0, 2)
    sync.allvec_ready(0, 1, 2)
    sync.allvec_ready(1, 0, 2)
    assert not done.wait(timeout=0.01)
    sync.allvec_ready(1, 1, 2)

    assert done.wait(timeout=1.0)
    thread.join(timeout=1.0)
    assert result == [True]


def test_legacy_collective_phase_counters_allow_more_than_15_rounds_when_consumed() -> None:
    sync = CrossCoreSync(core_count=2)
    sync.prepare()

    for flag_round in range(20):
        sync.allcube_ready(0, 1)
        sync.allcube_ready(1, 1)
        assert sync.allcube_wait(0, 1, timeout=0.01)
        assert sync.allcube_wait(1, 1, timeout=0.01)

        sync.allvec_ready(0, 0, 2)
        sync.allvec_ready(0, 1, 2)
        sync.allvec_ready(1, 0, 2)
        sync.allvec_ready(1, 1, 2)
        assert sync.allvec_wait(0, 0, 2, timeout=0.01)
        assert sync.allvec_wait(0, 1, 2, timeout=0.01)
        assert sync.allvec_wait(1, 0, 2, timeout=0.01)
        assert sync.allvec_wait(1, 1, 2, timeout=0.01)


def test_legacy_collective_phase_counters_enforce_ahead_window() -> None:
    sync = CrossCoreSync(core_count=2)
    sync.prepare()

    for _ in range(15):
        sync.allcube_ready(0, 3)
    with pytest.raises(RuntimeError, match="ahead overflow"):
        sync.allcube_ready(0, 3)

    for _ in range(15):
        sync.allvec_ready(0, 0, 4)
    with pytest.raises(RuntimeError, match="ahead overflow"):
        sync.allvec_ready(0, 0, 4)
