"""Codegen tests for the @simt(num_threads=...) decorator parameter.

The header-rendering test calls SimtModule.render() directly.  The
call-site test uses translate_split to confirm that Simt::Dim3 carries
the same num_threads value as __launch_bounds__.
"""
from __future__ import annotations

import re

import pytest

from easyasc import globvars
from easyasc.parser.asc import translate_split

# device_type is read at decorator/import time for several stub
# functions; switch to a5 before importing.
_SAVED_DEVICE = globvars.device_type
globvars.device_type = "950"

from easyasc.a5 import (  # noqa: E402
    DT, GMTensor, Position, Tensor, Var,
    auto_sync, cvt, kernel, simt, simt_ffs, simt_fma, simt_thread_barrier,
    simt_thread_id, simt_thread_num, simt_atomic_cas,
)


SIMT_RENDER_DIVISOR = 2


def teardown_module(module):  # pytest hook
    globvars.device_type = _SAVED_DEVICE


# ---------------------------------------------------------------------------
# Module-level @simt / @kernel definitions used by the call-site test.
# transform_kernel re-execs against func.__globals__ so these need module
# scope.
# ---------------------------------------------------------------------------


@simt(num_threads=512)
def _simt_512(t: Tensor, n: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        t[i] = i


@kernel()
def _kernel_calls_simt_512(out: GMTensor, N: Var):
    ub = Tensor(DT.int, [1, 64], Position.UB)
    n_iter = Var(64, DT.int)
    with auto_sync():
        _simt_512(ub, n_iter)
        out[0:1, 0:64] <<= ub
    return out


# ---------------------------------------------------------------------------
# render() — function-body header
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("num_threads", [128, 256, 512, 1024, 2048])
def test_simt_render_emits_launch_bounds_for_num_threads(num_threads: int) -> None:
    @simt(num_threads=num_threads)
    def body(t: Tensor, n: Var):
        for i in range(simt_thread_id(), n, simt_thread_num()):
            t[i] = i

    # SimtModule.render() requires a locked dtype signature; lock it by
    # invoking the module once (no active kernel, so no instruction is
    # emitted, but locked_dtypes is set as a side effect).
    ub = Tensor(DT.int, [1, 64], Position.UB)
    n_iter = Var(64, DT.int)
    body(ub, n_iter)

    code = body.render()
    assert f"__simt_vf__ __launch_bounds__({num_threads}) inline void body(" in code


def test_simt_render_default_num_threads_is_1024() -> None:
    @simt()
    def body(t: Tensor, n: Var):
        for i in range(simt_thread_id(), n, simt_thread_num()):
            t[i] = i

    ub = Tensor(DT.int, [1, 64], Position.UB)
    n_iter = Var(64, DT.int)
    body(ub, n_iter)

    code = body.render()
    assert "__simt_vf__ __launch_bounds__(1024) inline void body(" in code


def test_simt_render_floor_div_uses_cpp_division() -> None:
    @simt()
    def body(t: Tensor, n: Var):
        for i in range(simt_thread_id(), n, simt_thread_num()):
            t[i] = i // SIMT_RENDER_DIVISOR

    ub = Tensor(DT.int, [1, 64], Position.UB)
    n_iter = Var(64, DT.int)
    body(ub, n_iter)

    code = body.render()
    assert "t[i] = i / 2;" in code


def test_simt_render_promotes_uint64_index_arithmetic() -> None:
    @simt()
    def body(out: GMTensor, n: Var):
        idx = cvt(simt_thread_id(), DT.uint64) + 1
        if idx < n:
            out[idx] = cvt(idx, DT.int)

    out = GMTensor(DT.int, [1, 64])
    n = Var(64, DT.uint64)
    body(out, n)

    code = body.render()
    assert "uint64_t idx = (uint64_t)(Simt::GetThreadIdx<0>()) + 1;" in code
    assert "if (idx < n) {" in code
    assert "out[idx] = (int)(idx);" in code
    body.lower_to_ir()


def test_simt_render_parenthesizes_bitwise_comparison_operands() -> None:
    @simt()
    def body(out: GMTensor, n: Var):
        raw = cvt(out[0], DT.uint64)
        mask = cvt(255, DT.uint64)
        zero = cvt(0, DT.uint64)
        if (raw & mask) == zero:
            out[0] = raw
        if (raw & mask) != zero:
            out[0] = mask
        if raw == (mask & raw):
            out[0] = mask

    out = GMTensor(DT.uint64, [1, 1])
    n = Var(1, DT.int)
    body(out, n)

    code = body.render()
    assert "if ((raw & mask) == zero) {" in code
    assert "if ((raw & mask) != zero) {" in code
    assert "if (raw == (mask & raw)) {" in code
    assert "if (raw & mask == zero) {" not in code
    assert "if (raw & mask != zero) {" not in code
    body.lower_to_ir()


def test_simt_render_parenthesizes_arithmetic_shift_operands() -> None:
    @simt()
    def body(out: GMTensor, n: Var):
        low = cvt(out[0], DT.uint64)
        high = cvt(out[1], DT.uint64)
        middle = (low + high) >> 1
        mask = low << (high - 1)
        out[n] = middle | mask

    out = GMTensor(DT.uint64, [1, 64])
    n = Var(2, DT.int)
    body(out, n)

    code = body.render()
    assert "uint64_t middle = (low + high) >> 1;" in code
    assert "uint64_t mask = low << (high - 1);" in code
    assert "low + high >> 1" not in code
    assert "low << high - 1" not in code
    body.lower_to_ir()


def test_simt_render_keeps_fma_as_one_expression() -> None:
    @simt()
    def body(x: GMTensor, y: GMTensor, out: GMTensor):
        out[0] = simt_fma(x[0], y[0], out[0])

    tensor = GMTensor(DT.float, [1])
    body(tensor, tensor, tensor)

    code = body.render()
    assert "out[0] = ((x[0]) * (y[0]) + (out[0]));" in code
    ir = body.lower_to_ir()
    assert ir[0].kwargs["expr"]["kind"] == "fma"


def test_simt_ffs_emits_native_signed_intrinsic() -> None:
    @simt()
    def body(bits: GMTensor, out: GMTensor):
        signed_bits = cvt(bits[0], DT.int64)
        out[0] = simt_ffs(signed_bits)

    bits = GMTensor(DT.uint64, [1])
    out = GMTensor(DT.int, [1])
    body(bits, out)

    code = body.render()
    assert "out[0] = Simt::Ffs(signed_bits);" in code
    ir = body.lower_to_ir()
    assert ir[1].kwargs["expr"]["kind"] == "ffs"


def test_simt_ffs_rejects_unsigned_operand_without_explicit_cast() -> None:
    @simt()
    def body(bits: GMTensor, out: GMTensor):
        out[0] = simt_ffs(bits[0])

    bits = GMTensor(DT.uint64, [1])
    out = GMTensor(DT.int, [1])
    body(bits, out)
    with pytest.raises(TypeError, match="signed int32/int64"):
        body.render()


def test_simt_thread_barrier_emits_uniform_block_barrier() -> None:
    @simt()
    def body(values: GMTensor):
        values[simt_thread_id()] = simt_thread_id()
        simt_thread_barrier()
        values[simt_thread_id()] = values[simt_thread_id()]

    values = GMTensor(DT.int, [1024])
    body(values)

    code = body.render()
    assert "Simt::ThreadBarrier();" in code
    ir = body.lower_to_ir()
    assert ir[1].opname == "simt_thread_barrier"


def test_simt_atomic_cas_emits_compare_and_value() -> None:
    @simt()
    def body(values: GMTensor):
        index = simt_thread_id()
        observed = values[index]
        replacement = observed + cvt(1, DT.uint64)
        simt_atomic_cas(values[index], observed, replacement)

    values = GMTensor(DT.uint64, [1024])
    body(values)

    code = body.render()
    assert "Simt::AtomicCas(values + (index), observed, replacement);" in code
    ir = body.lower_to_ir()
    assert ir[-1].opname == "simt_atomic"
    assert ir[-1].kwargs["op"] == "cas"
    assert ir[-1].kwargs["compare"]["id"] == "observed"


def test_simt_fma_rejects_non_fp32_operands() -> None:
    @simt()
    def body(x: GMTensor, y: GMTensor, out: GMTensor):
        out[0] = simt_fma(x[0], y[0], out[0])

    tensor = GMTensor(DT.half, [1])
    body(tensor, tensor, tensor)
    with pytest.raises(TypeError, match="supports three fp32 operands"):
        body.render()


# ---------------------------------------------------------------------------
# call site — Simt::Dim3{<n>, 1, 1}
# ---------------------------------------------------------------------------


def test_simt_call_site_dim3_uses_num_threads() -> None:
    out = GMTensor(DT.int, [1, 64])
    N = Var(64, DT.int)
    _kernel_calls_simt_512(out, N)
    _, vec_code = translate_split(
        _kernel_calls_simt_512.instructions, "kernel_calls_simt_512"
    )
    assert "Simt::VF_CALL<_simt_512>(Simt::Dim3{512, 1, 1}, " in vec_code


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("bad_value", [0, 64, 100, 300, 1000, 4096, -1024])
def test_simt_decorator_rejects_unsupported_num_threads(bad_value: int) -> None:
    with pytest.raises(ValueError, match="num_threads"):
        @simt(num_threads=bad_value)
        def body(t: Tensor, n: Var):
            t[0] = n


def test_simt_decorator_rejects_non_int_num_threads() -> None:
    with pytest.raises(TypeError, match="num_threads"):
        @simt(num_threads="1024")  # type: ignore[arg-type]
        def body(t: Tensor, n: Var):
            t[0] = n


def test_simt_render_error_reports_source_line() -> None:
    @simt()
    def body(t: Tensor, n: Var):
        for i in range(simt_thread_id(), n, simt_thread_num()):
            foo(i)

    ub = Tensor(DT.int, [1, 64], Position.UB)
    n_iter = Var(64, DT.int)
    body(ub, n_iter)

    with pytest.raises(NotImplementedError) as exc_info:
        body.render()

    message = str(exc_info.value)
    assert "unsupported call foo(...)" in message
    assert re.search(r"test_simt_codegen\.py:\d+", message)
    assert ">> foo(i)" in message


def test_simt_ir_error_reports_source_line() -> None:
    @simt()
    def body(t: Tensor, n: Var):
        for i in range(simt_thread_id(), n, simt_thread_num()):
            foo(i)

    ub = Tensor(DT.int, [1, 64], Position.UB)
    n_iter = Var(64, DT.int)
    body(ub, n_iter)

    with pytest.raises(NotImplementedError) as exc_info:
        body.lower_to_ir()

    message = str(exc_info.value)
    assert "unsupported call foo(...)" in message
    assert re.search(r"test_simt_codegen\.py:\d+", message)
    assert ">> foo(i)" in message
