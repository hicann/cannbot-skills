import torch

from easyasc.simulator.pipe_vec import VPipe
from easyasc.simulator.program import PipeTask


class _TensorStore(object):
    def __init__(self, tensors=None):
        self._tensors = dict(tensors or {})

    def tensor(self, name):
        return self._tensors[name]


def _pipe(tensors):
    pipe = object.__new__(VPipe)
    pipe.memory_store = _TensorStore(tensors)
    pipe.vector_mode = "repeat"
    pipe.count_register = 0
    pipe.current_mask = torch.ones(256, dtype=torch.uint8)
    return pipe


def test_vec_compare_ne_treats_nan_as_unordered_false() -> None:
    dst = torch.zeros(32, dtype=torch.uint8)
    src = torch.zeros(128, dtype=torch.float32)
    src[0] = float("nan")
    src[1] = float("inf")
    src[2] = float("-inf")
    src[3] = 1.0

    pipe = _pipe({"dst": dst, "src": src})
    pipe.execute(
        PipeTask(
            pipe_name="V",
            opname="vec_v_compare",
            args={
                "dst": "dst",
                "src1": "src",
                "src2": "src",
                "mode": "NE",
                "repeat": 1,
                "dst_blk_stride": 1,
                "src1_blk_stride": 1,
                "src2_blk_stride": 1,
                "dst_rep_stride": 8,
                "src1_rep_stride": 8,
                "src2_rep_stride": 8,
            },
        )
    )

    # Byte 0 packs the first 8 compare lanes. The hardware-compatible contract is
    # unordered-false, so NaN != NaN must not set bit 0.
    assert (int(dst[0].item()) & 0x01) == 0
