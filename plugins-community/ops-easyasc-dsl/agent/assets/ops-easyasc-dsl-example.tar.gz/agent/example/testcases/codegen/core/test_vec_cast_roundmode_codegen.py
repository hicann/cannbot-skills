import re
from types import SimpleNamespace

import pytest

from easyasc import globvars
from easyasc.parser.asc import translate_split
from easyasc.stub_functions.vec.cast import cast as vec_cast
from easyasc.utils.Tensor import Tensor
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.positions import Position
from easyasc.utils.roundmode import RoundMode


_ROUND_MODE_CASES = [
    (RoundMode.NONE, "CAST_NONE", DT.float, DT.half),
    (RoundMode.TO_EVEN, "CAST_RINT", DT.float, DT.float),
    (RoundMode.AWAY_FROM_ZERO, "CAST_ROUND", DT.float, DT.float),
    (RoundMode.FLOOR, "CAST_FLOOR", DT.float, DT.float),
    (RoundMode.CEIL, "CAST_CEIL", DT.float, DT.float),
    (RoundMode.TRUNC, "CAST_TRUNC", DT.float, DT.float),
    (RoundMode.ODD, "CAST_ODD", DT.float, DT.half),
]


def _translate_vec_cast_roundmode(round_mode, src_dtype, dst_dtype) -> str:
    prev_kernel = globvars.active_kernel
    prev_device = globvars.device_type
    fake_kernel = SimpleNamespace(instructions=[], vector_mode="repeat")
    try:
        globvars.device_type = "b3"
        globvars.active_kernel = fake_kernel
        src = Tensor(src_dtype, [1, 64], Position.UB, name="src")
        dst = Tensor(dst_dtype, [1, 64], Position.UB, name="dst")

        vec_cast(dst, src, round_mode=round_mode)

        _, vec_code = translate_split(
            fake_kernel.instructions,
            "vec_cast_roundmode_codegen",
        )
        return vec_code
    finally:
        globvars.active_kernel = prev_kernel
        globvars.device_type = prev_device


@pytest.mark.parametrize("round_mode,expected_token,src_dtype,dst_dtype", _ROUND_MODE_CASES)
def test_vec_cast_codegen_emits_matching_roundmode_token(
    round_mode, expected_token, src_dtype, dst_dtype
) -> None:
    vec_code = _translate_vec_cast_roundmode(round_mode, src_dtype, dst_dtype)

    tokens = re.findall(r"RoundMode::(CAST_[A-Z]+)", vec_code)
    assert tokens == [expected_token]
