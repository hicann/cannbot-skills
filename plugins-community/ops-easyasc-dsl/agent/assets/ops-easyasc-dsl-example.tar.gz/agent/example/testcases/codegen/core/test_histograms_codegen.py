import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.parser.asc import translate


LANES32 = 64
BINS = 128


def _with_device(device_type: str):
    saved = globvars.device_type
    globvars.device_type = device_type
    return saved


# The kernel AST rewrite resolves names in module scope, so every vf a kernel
# calls has to live here rather than in the test body.
@vf()
def acc_bin1_vf(src_ub: Tensor, out_ub: Tensor):
    word = Reg(DT.uint32)
    halfword = Reg(DT.uint16)
    byte = Reg(DT.uint8)
    counts = Reg(DT.uint16)
    live = MaskReg(DT.uint8, init_mode=MaskType.ALL)
    dup(counts, 0)
    ub_to_reg(word, src_ub[0])
    pack(halfword, word, HighLowPart.LOWEST)
    pack(byte, halfword, HighLowPart.LOWEST)
    histograms(counts, byte, HistBin.BIN1, HistMode.ACCUMULATE, mask=live)
    reg_to_ub(out_ub[0], counts)


@vf()
def freq_bin0_vf(src_ub: Tensor, out_ub: Tensor):
    word = Reg(DT.uint32)
    halfword = Reg(DT.uint16)
    byte = Reg(DT.uint8)
    counts = Reg(DT.uint16)
    live = MaskReg(DT.uint8, init_mode=MaskType.ALL)
    dup(counts, 0)
    ub_to_reg(word, src_ub[0])
    pack(halfword, word, HighLowPart.LOWEST)
    pack(byte, halfword, HighLowPart.LOWEST)
    histograms(counts, byte, HistBin.BIN0, HistMode.FREQUENCY, mask=live)
    reg_to_ub(out_ub[0], counts)


@kernel(mode="vec")
def acc_bin1_kernel(src: GMTensor, out: GMTensor):
    src_ub = Tensor(DT.int, [1, LANES32], Position.UB)
    out_ub = Tensor(DT.int16, [1, BINS], Position.UB)
    src_u32 = reinterpret(src_ub, DT.uint32)
    out_u16 = reinterpret(out_ub, DT.uint16)
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        acc_bin1_vf(src_u32, out_u16)
        out[0:1, :] <<= out_ub
    return out


@kernel(mode="vec")
def freq_bin0_kernel(src: GMTensor, out: GMTensor):
    src_ub = Tensor(DT.int, [1, LANES32], Position.UB)
    out_ub = Tensor(DT.int16, [1, BINS], Position.UB)
    src_u32 = reinterpret(src_ub, DT.uint32)
    out_u16 = reinterpret(out_ub, DT.uint16)
    with auto_sync():
        src_ub[:, :] <<= src[0:1, :]
        freq_bin0_vf(src_u32, out_u16)
        out[0:1, :] <<= out_ub
    return out


def test_histograms_emits_the_cann_micro_api_call() -> None:
    saved = _with_device("950")
    try:
        acc_bin1_kernel(GMTensor(DT.int, [1, LANES32]), GMTensor(DT.int16, [1, BINS]))
        code = translate(acc_bin1_vf.instructions)
        assert (
            "MicroAPI::Histograms<uint8_t, uint16_t, "
            "MicroAPI::HistogramsBinType::BIN1, "
            "MicroAPI::HistogramsType::ACCUMULATE>(" in code
        )
    finally:
        globvars.device_type = saved


def test_histograms_frequency_bin0_selects_the_other_template_arguments() -> None:
    saved = _with_device("950")
    try:
        freq_bin0_kernel(GMTensor(DT.int, [1, LANES32]), GMTensor(DT.int16, [1, BINS]))
        code = translate(freq_bin0_vf.instructions)
        assert "MicroAPI::HistogramsBinType::BIN0" in code
        assert "MicroAPI::HistogramsType::FREQUENCY" in code
    finally:
        globvars.device_type = saved


@vf()
def wide_dst_vf(out_ub: Tensor):
    counts = Reg(DT.uint32)
    byte = Reg(DT.uint8)
    live = MaskReg(DT.uint8, init_mode=MaskType.ALL)
    histograms(counts, byte, HistBin.BIN0, HistMode.FREQUENCY, mask=live)


@vf()
def wide_src_vf(out_ub: Tensor):
    counts = Reg(DT.uint16)
    word = Reg(DT.uint16)
    live = MaskReg(DT.uint8, init_mode=MaskType.ALL)
    histograms(counts, word, HistBin.BIN0, HistMode.FREQUENCY, mask=live)


@pytest.mark.parametrize(
    "bad_vf, message",
    [
        (wide_dst_vf, "dst must be uint16"),
        (wide_src_vf, "src must be uint8"),
    ],
)
def test_histograms_rejects_unsupported_register_widths(bad_vf, message) -> None:
    saved = _with_device("950")
    try:
        with pytest.raises(TypeError, match=message):
            bad_vf(Tensor(DT.uint16, [1, BINS], Position.UB))
    finally:
        globvars.device_type = saved
