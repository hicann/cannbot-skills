import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import translate_split

# The compiler requires a non-returned input tensor in the kernel entry.
# The `_sim` kernels below only hand `src` back, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.float16)


@kernel()
def run_waitflag_mainloop_vec(src: GMTensor):
    setflag(Pipe.V, Pipe.S, 1)
    waitflag(Pipe.V, Pipe.S, 1)
    return src


@kernel()
def run_waitflag_mainloop_vec_deadlock(src: GMTensor):
    waitflag(Pipe.V, Pipe.S, 2)
    return src


@kernel()
def run_waitflag_mainloop_cube(src: GMTensor):
    setflag(Pipe.M, Pipe.S, 3)
    waitflag(Pipe.M, Pipe.S, 3)
    return src


@kernel()
def run_waitflag_mainloop_vec_sim(gate: GMTensor, src: GMTensor, dummy: Var):
    setflag(Pipe.V, Pipe.S, 1)
    waitflag(Pipe.V, Pipe.S, 1)
    return src


@kernel()
def run_waitflag_mainloop_cube_sim(gate: GMTensor, src: GMTensor, dummy: Var):
    setflag(Pipe.M, Pipe.S, 3)
    waitflag(Pipe.M, Pipe.S, 3)
    return src


@kernel()
def run_waitflag_vec_pipe_sim(gate: GMTensor, src: GMTensor, dummy: Var):
    setflag(Pipe.MTE2, Pipe.V, 4)
    waitflag(Pipe.MTE2, Pipe.V, 4)
    return src


# Pass-through kernels: the sync primitives never touch the buffer, so
# the simulator seeds it instead of handing the test its poison.
for _passthrough in (
    run_waitflag_mainloop_vec_sim,
    run_waitflag_mainloop_cube_sim,
    run_waitflag_vec_pipe_sim,
):
    _passthrough._simulator_seed_outputs = True


def test_setflag_rejects_pipe_s_source() -> None:
    with pytest.raises(ValueError, match="source pipe cannot be Pipe.S"):
        setflag(Pipe.S, Pipe.V, 0)


def test_waitflag_rejects_pipe_s_source() -> None:
    with pytest.raises(ValueError, match="source pipe cannot be Pipe.S"):
        waitflag(Pipe.S, Pipe.V, 0)


def test_setflag_rejects_pipe_all_source() -> None:
    with pytest.raises(ValueError, match="source pipe cannot be Pipe.ALL"):
        setflag(Pipe.ALL, Pipe.V, 0)


def test_setflag_rejects_pipe_all_destination() -> None:
    with pytest.raises(ValueError, match="destination pipe cannot be Pipe.ALL"):
        setflag(Pipe.V, Pipe.ALL, 0)


def test_waitflag_rejects_pipe_all_source() -> None:
    with pytest.raises(ValueError, match="source pipe cannot be Pipe.ALL"):
        waitflag(Pipe.ALL, Pipe.V, 0)


def test_waitflag_rejects_pipe_all_destination() -> None:
    with pytest.raises(ValueError, match="destination pipe cannot be Pipe.ALL"):
        waitflag(Pipe.V, Pipe.ALL, 0)


def test_setflag_rejects_event_id_out_of_range_int() -> None:
    with pytest.raises(ValueError, match="event_id must be in range \\[0, 7\\]"):
        setflag(Pipe.V, Pipe.S, 8)


def test_setflag_rejects_event_id_out_of_range_var() -> None:
    with pytest.raises(ValueError, match="event_id must be in range \\[0, 7\\]"):
        setflag(Pipe.V, Pipe.S, Var(8))


def test_waitflag_rejects_event_id_out_of_range_int() -> None:
    with pytest.raises(ValueError, match="event_id must be in range \\[0, 7\\]"):
        waitflag(Pipe.V, Pipe.S, 8)


def test_waitflag_rejects_event_id_out_of_range_var() -> None:
    with pytest.raises(ValueError, match="event_id must be in range \\[0, 7\\]"):
        waitflag(Pipe.V, Pipe.S, Var(8))


def test_setflag_waitflag_codegen_uses_snake_case_function_form() -> None:
    src = GMTensor(DT.half, [1, 16], name="src")
    run_waitflag_mainloop_vec(src)

    cube_code, vec_code = translate_split(
        run_waitflag_mainloop_vec.instructions,
        "run_waitflag_mainloop_vec_codegen",
    )
    generated = cube_code + vec_code
    assert "set_flag(PIPE_V, PIPE_S, (event_t)(1));" in generated
    assert "wait_flag(PIPE_V, PIPE_S, (event_t)(1));" in generated
    assert "SetFlag<" not in generated
    assert "WaitFlag<" not in generated


def test_sim_setflag_waitflag_mainloop_vec_pipe_s() -> None:
    src = torch.arange(16, dtype=torch.float16).reshape(1, 16)
    out = OpExec(run_waitflag_mainloop_vec_sim, "test_sim_setflag_waitflag_mainloop_vec_pipe_s", simulator=True)(GATE, src, -1)
    assert torch.equal(out, src)


def test_sim_setflag_waitflag_mainloop_cube_pipe_s() -> None:
    src = torch.arange(16, dtype=torch.float16).reshape(1, 16)
    out = OpExec(run_waitflag_mainloop_cube_sim, "test_sim_setflag_waitflag_mainloop_cube_pipe_s", simulator=True)(GATE, src, -1)
    assert torch.equal(out, src)


def test_sim_setflag_waitflag_vec_pipe_pair() -> None:
    src = torch.arange(16, dtype=torch.float16).reshape(1, 16)
    out = OpExec(run_waitflag_vec_pipe_sim, "test_sim_setflag_waitflag_vec_pipe_pair", simulator=True)(GATE, src, -1)
    assert torch.equal(out, src)
