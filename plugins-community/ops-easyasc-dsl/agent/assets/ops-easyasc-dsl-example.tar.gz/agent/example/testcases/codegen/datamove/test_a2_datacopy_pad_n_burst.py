import pytest

from easyasc import globvars
from easyasc.a2 import *


@kernel()
def _gm_to_ub_pad_kernel(src: GMTensor, n_burst: Var):
    dst = Tensor(DT.float, [1, 8], Position.UB)
    gm_to_ub_pad(
        dst, src, n_burst=n_burst, burst_len_element=0,
        src_stride_element=0, dst_stride=0,
    )
    return src


@kernel()
def _ub_to_gm_pad_kernel(dst: GMTensor, n_burst: Var):
    src = Tensor(DT.float, [1, 8], Position.UB)
    ub_to_gm_pad(
        dst, src, n_burst=n_burst, burst_len_element=0,
        src_stride=0, dst_stride_element=0,
    )
    return dst


@kernel()
def _gm_to_ub_pad_static_4096(src: GMTensor):
    dst = Tensor(DT.float, [1, 8], Position.UB)
    gm_to_ub_pad(
        dst, src, n_burst=4096, burst_len_element=0,
        src_stride_element=0, dst_stride=0,
    )
    return src


@kernel()
def _ub_to_gm_pad_static_4096(dst: GMTensor):
    src = Tensor(DT.float, [1, 8], Position.UB)
    ub_to_gm_pad(
        dst, src, n_burst=4096, burst_len_element=0,
        src_stride=0, dst_stride_element=0,
    )
    return dst


@pytest.mark.parametrize("kernel_obj", [_gm_to_ub_pad_kernel, _ub_to_gm_pad_kernel])
@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_c220_stub_accepts_n_burst_boundaries(kernel_obj, device_type) -> None:
    saved = globvars.device_type
    globvars.device_type = device_type
    try:
        tensor = GMTensor(DT.float, [1, 8])
        kernel_obj(tensor, Var(0))
        kernel_obj(tensor, Var(4095))
    finally:
        globvars.device_type = saved


@pytest.mark.parametrize("kernel_obj", [_gm_to_ub_pad_kernel, _ub_to_gm_pad_kernel])
@pytest.mark.parametrize("n_burst", [-1, 4096])
@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_c220_stub_rejects_out_of_range_known_var(kernel_obj, n_burst, device_type) -> None:
    saved = globvars.device_type
    globvars.device_type = device_type
    try:
        tensor = GMTensor(DT.float, [1, 8])
        with pytest.raises(ValueError, match=r"on C220 requires n_burst in \[0, 4095\]"):
            kernel_obj(tensor, Var(n_burst))
    finally:
        globvars.device_type = saved


@pytest.mark.parametrize(
    "kernel_obj", [_gm_to_ub_pad_static_4096, _ub_to_gm_pad_static_4096]
)
@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_c220_stub_rejects_out_of_range_python_int(kernel_obj, device_type) -> None:
    saved = globvars.device_type
    globvars.device_type = device_type
    try:
        tensor = GMTensor(DT.float, [1, 8])
        with pytest.raises(ValueError, match=r"on C220 requires n_burst in \[0, 4095\]"):
            kernel_obj(tensor)
    finally:
        globvars.device_type = saved


@pytest.mark.parametrize("kernel_obj", [_gm_to_ub_pad_kernel, _ub_to_gm_pad_kernel])
def test_a5_stub_keeps_n_burst_4096(kernel_obj) -> None:
    saved = globvars.device_type
    globvars.device_type = "950"
    try:
        tensor = GMTensor(DT.float, [1, 8])
        kernel_obj(tensor, Var(4096))
    finally:
        globvars.device_type = saved
