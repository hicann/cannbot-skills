import pytest

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


def _make_mergesort2seq_tensors(
    *,
    dst_pos=Position.UB,
    src1_pos=Position.UB,
    src2_pos=Position.UB,
    dst_dtype=DT.float,
    src1_dtype=DT.float,
    src2_dtype=DT.float,
):
    dst = Tensor(dst_dtype, [1, 256], dst_pos)
    src1 = Tensor(src1_dtype, [1, 256], src1_pos)
    src2 = Tensor(src2_dtype, [1, 256], src2_pos)
    return dst, src1, src2


def test_mergesort2seq_rejects_non_tensor_inputs() -> None:
    dst, src1, src2 = _make_mergesort2seq_tensors()
    with pytest.raises(TypeError, match="dst must be Tensor"):
        mergesort_2seq("bad", src1, src2, 4, 3)  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="src1 must be Tensor"):
        mergesort_2seq(dst, "bad", src2, 4, 3)  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="src2 must be Tensor"):
        mergesort_2seq(dst, src1, "bad", 4, 3)  # type: ignore[arg-type]


def test_mergesort2seq_rejects_non_ub_tensors() -> None:
    dst, src1, src2 = _make_mergesort2seq_tensors(dst_pos=Position.L1)
    with pytest.raises(ValueError, match="dst must be at UB position"):
        mergesort_2seq(dst, src1, src2, 4, 3)

    dst, src1, src2 = _make_mergesort2seq_tensors(src1_pos=Position.L1)
    with pytest.raises(ValueError, match="src1 must be at UB position"):
        mergesort_2seq(dst, src1, src2, 4, 3)

    dst, src1, src2 = _make_mergesort2seq_tensors(src2_pos=Position.L1)
    with pytest.raises(ValueError, match="src2 must be at UB position"):
        mergesort_2seq(dst, src1, src2, 4, 3)


def test_mergesort2seq_requires_float_src_and_dst() -> None:
    dst, src1, src2 = _make_mergesort2seq_tensors(
        dst_dtype=DT.half,
        src1_dtype=DT.half,
        src2_dtype=DT.half,
    )
    with pytest.raises(ValueError, match="only supports float dtype"):
        mergesort_2seq(dst, src1, src2, 4, 3)

    dst, src1, src2 = _make_mergesort2seq_tensors(src2_dtype=DT.half)
    with pytest.raises(ValueError, match="src1/src2/dst data types must match"):
        mergesort_2seq(dst, src1, src2, 4, 3)


def test_mergesort2seq_rejects_invalid_size_types() -> None:
    dst, src1, src2 = _make_mergesort2seq_tensors()
    with pytest.raises(TypeError, match="size1 must be Var or int"):
        mergesort_2seq(dst, src1, src2, 1.5, 3)  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="size2 must be Var or int"):
        mergesort_2seq(dst, src1, src2, 4, 1.5)  # type: ignore[arg-type]


def test_mergesort2seq_rejects_invalid_size_ranges() -> None:
    dst, src1, src2 = _make_mergesort2seq_tensors()
    with pytest.raises(ValueError, match="size1 must be positive"):
        mergesort_2seq(dst, src1, src2, 0, 3)
    with pytest.raises(ValueError, match="size1 must be positive"):
        mergesort_2seq(dst, src1, src2, -1, 3)
    with pytest.raises(ValueError, match="size2 must be positive"):
        mergesort_2seq(dst, src1, src2, 4, 0)
    with pytest.raises(ValueError, match="size2 must be positive"):
        mergesort_2seq(dst, src1, src2, 4, -1)


def test_mergesort2seq_instruction_capture() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [1, 256], Position.UB)
        src1 = Tensor(DT.float, [1, 256], Position.UB)
        src2 = Tensor(DT.float, [1, 256], Position.UB)
        mergesort_2seq(dst, src1, src2, 4, 3)
        return inp

    inp = GMTensor(DT.float, [1, 1])
    stub_only(inp)
    found = [inst for inst in stub_only.instructions if inst.opname == "mergesort_2seq"]
    assert len(found) == 1
    assert found[0].kwargs["size1"] == 4
    assert found[0].kwargs["size2"] == 3


def test_mergesort2seq_codegen_emits_vec_side_call() -> None:
    @kernel()
    def stub_only(inp: GMTensor):
        dst = Tensor(DT.float, [1, 256], Position.UB)
        src1 = Tensor(DT.float, [1, 256], Position.UB)
        src2 = Tensor(DT.float, [1, 256], Position.UB)
        mergesort_2seq(dst, src1, src2, 4, 3)
        return inp

    inp = GMTensor(DT.float, [1, 1])
    stub_only(inp)
    cube_code, vec_code = translate_split(stub_only.instructions, "stub_only_mergesort2seq_codegen")
    assert "MERGESORT2SEQ(" not in cube_code
    assert "MERGESORT2SEQ(" in vec_code
