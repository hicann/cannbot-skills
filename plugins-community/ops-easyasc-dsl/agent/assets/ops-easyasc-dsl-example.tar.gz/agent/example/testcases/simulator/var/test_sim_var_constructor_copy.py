import torch

from easyasc.a5 import *

# The compiler requires a non-returned input tensor in the kernel entry;
# this kernel writes its output from a Var alone, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.int32)


@kernel()
def var_ctor_copy_loop_var_kernel(gate: GMTensor, dst: GMTensor, n: Var):
    with cube_scope():
        for pipe_work in range(0, n):
            if pipe_work < n:
                slot = Var(pipe_work)
                slot.SetValueTo(dst[pipe_work:pipe_work + 1, 0:1])
    return dst


def test_var_ctor_copy_does_not_rename_loop_var_in_simulator() -> None:
    dst = torch.full((4, 1), -1, dtype=torch.int32)

    out = OpExec(var_ctor_copy_loop_var_kernel, simulator=True)(GATE, dst, 4)

    assert torch.equal(out, torch.tensor([[0], [1], [2], [3]], dtype=torch.int32))
