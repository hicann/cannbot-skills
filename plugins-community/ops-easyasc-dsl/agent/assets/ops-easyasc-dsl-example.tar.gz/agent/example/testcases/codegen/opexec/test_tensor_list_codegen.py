import contextlib
import os
from pathlib import Path

from easyasc.a2 import *


@kernel(mode="vec")
def _tensor_list_codegen_kernel(xs: GMTensorList, out: GMTensor, dummy: Var):
    ub = Tensor(DT.half, [1, 16], Position.UB)
    with auto_sync():
        for i in range(xs.size()):
            item = xs[i]
            gm_to_ub_pad(ub, item, 1, 16, 0, 0)
            ub_to_gm_pad(out, ub, 1, 16, 0, 0)
    return out


@kernel(mode="vec")
def _tensor_list_output_codegen_kernel(xs: GMTensorList, ys: GMTensorList, dummy: Var):
    ub = Tensor(DT.half, [1, 16], Position.UB)
    with auto_sync():
        for i in range(xs.size()):
            item = xs[i]
            dst = ys[i]
            gm_to_ub_pad(ub, item, 1, 16, 0, 0)
            ub_to_gm_pad(dst, ub, 1, 16, 0, 0)
    return ys


@kernel(mode="vec")
def _tensor_list_item_numel_codegen_kernel(
    xs: GMTensorList, ys: GMTensorList, item_count: Var,
):
    ub = Tensor(DT.half, [1, 32], Position.UB)
    with auto_sync():
        for i in range(item_count):
            item_numel = xs.item_numel(i)
            src = xs[i].reshape([1, item_numel])
            dst = ys[i].reshape([1, item_numel])
            gm_to_ub_pad(ub[0:1, 0:item_numel], src[0:1, 0:item_numel])
            ub_to_gm_pad(dst[0:1, 0:item_numel], ub[0:1, 0:item_numel])
            bar_all()
    return ys


@contextlib.contextmanager
def _pushd(path: Path):
    prev = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(prev)


def _bind_tensor_list_kernel():
    items = [GMTensor(DT.half, [1, 16]) for _ in range(3)]
    xs = GMTensorList(DT.half, [1, 16], items=items)
    out = GMTensor(DT.half, [1, 16])
    dummy = Var(0)
    _tensor_list_codegen_kernel(xs, out, dummy)


def _bind_tensor_list_output_kernel():
    xs_items = [GMTensor(DT.half, [1, 16]) for _ in range(3)]
    ys_items = [GMTensor(DT.half, [1, 16]) for _ in range(3)]
    xs = GMTensorList(DT.half, [1, 16], items=xs_items)
    ys = GMTensorList(DT.half, [1, 16], items=ys_items)
    dummy = Var(0)
    _tensor_list_output_codegen_kernel(xs, ys, dummy)


def _bind_tensor_list_item_numel_kernel():
    xs_items = [
        GMTensor(DT.half, [2, 8]),
        GMTensor(DT.half, [4, 8]),
    ]
    ys_items = [
        GMTensor(DT.half, [2, 8]),
        GMTensor(DT.half, [4, 8]),
    ]
    xs = GMTensorList(DT.half, [2, 8], items=xs_items)
    ys = GMTensorList(DT.half, [2, 8], items=ys_items)
    item_count = Var(2)
    _tensor_list_item_numel_codegen_kernel(xs, ys, item_count)


def test_tensor_list_codegen_uses_list_tensor_desc_get_size_and_data_ptr(tmp_path: Path) -> None:
    _bind_tensor_list_kernel()
    with _pushd(tmp_path):
        _tensor_list_codegen_kernel.dump_kernel(_tensor_list_codegen_kernel.name)
        vec_h = (tmp_path / f"{_tensor_list_codegen_kernel.name}_vec.h").read_text(encoding="utf-8")

    assert '#include "interface/kernel_operator_list_tensor_intf.h"' in vec_h
    assert "ListTensorDesc xs_desc((__gm__ void*) xs_);" in vec_h
    assert "xs_desc.GetSize()" in vec_h
    assert "xs_desc.GetDataPtr<half>(" in vec_h


def test_tensor_list_item_numel_codegen_uses_runtime_item_shape(tmp_path: Path) -> None:
    _bind_tensor_list_item_numel_kernel()
    with _pushd(tmp_path):
        _tensor_list_item_numel_codegen_kernel.dump_kernel(
            _tensor_list_item_numel_codegen_kernel.name
        )
        vec_h = (
            tmp_path / f"{_tensor_list_item_numel_codegen_kernel.name}_vec.h"
        ).read_text(encoding="utf-8")

    assert "uint64_t _easyasc_tensorlist_shape_" in vec_h
    assert "TensorDesc<half> _easyasc_tensorlist_desc_" in vec_h
    assert "xs_desc.GetDesc(_easyasc_tensorlist_desc_" in vec_h
    assert ".GetShape(0)" in vec_h
    assert ".GetShape(1)" in vec_h
    assert "= static_cast<int32_t>(" in vec_h


def test_tensor_list_op_host_declares_dynamic_input(tmp_path: Path) -> None:
    _bind_tensor_list_kernel()
    with _pushd(tmp_path):
        _tensor_list_codegen_kernel.generate_op_host()
        op_host = (tmp_path / f"{_tensor_list_codegen_kernel.name}.cpp").read_text(encoding="utf-8")

    assert 'this->Input("xs")' in op_host
    assert ".ParamType(DYNAMIC)" in op_host
    assert 'this->Output("out")' in op_host


def test_tensor_list_op_host_declares_dynamic_output(tmp_path: Path) -> None:
    _bind_tensor_list_output_kernel()
    with _pushd(tmp_path):
        _tensor_list_output_codegen_kernel.generate_op_host()
        op_host = (tmp_path / f"{_tensor_list_output_codegen_kernel.name}.cpp").read_text(encoding="utf-8")

    assert 'this->Input("xs")' in op_host
    assert 'this->Output("ys")' in op_host
    assert ".ParamType(DYNAMIC)" in op_host
    assert "ys_shape = context->GetOutputShape(0)" in op_host
    assert "context->SetOutputDataType(0, ge::DT_FLOAT16)" in op_host


def test_tensor_list_aclnn_test_creates_acl_tensor_list(tmp_path: Path) -> None:
    _bind_tensor_list_kernel()
    with _pushd(tmp_path):
        _tensor_list_codegen_kernel.generate_aclnn_test(
            "aclnn_test",
            cann_path="/tmp/fake_cann",
            custom_op_path="/tmp/fake_cann",
        )
        test_cpp = (tmp_path / "aclnn_test" / "test.cpp").read_text(encoding="utf-8")

    assert 'fillHostWithBinFile("./input/input_xs_item0.bin")' in test_cpp
    assert "std::vector<const aclTensor*> xs_acl_items" in test_cpp
    assert "aclCreateTensorList(xs_acl_items.data(), xs_acl_items.size())" in test_cpp
    assert "EXECOP(aclnnTensorListCodegenKernel, stream, xs_acl, dummy, out_acl);" in test_cpp
    assert "aclDestroyTensorList(xs_acl);" in test_cpp


def test_tensor_list_output_aclnn_test_creates_output_acl_tensor_list(tmp_path: Path) -> None:
    _bind_tensor_list_output_kernel()
    with _pushd(tmp_path):
        _tensor_list_output_codegen_kernel.generate_aclnn_test(
            "aclnn_test",
            cann_path="/tmp/fake_cann",
            custom_op_path="/tmp/fake_cann",
        )
        test_cpp = (tmp_path / "aclnn_test" / "test.cpp").read_text(encoding="utf-8")

    assert 'fillHostWithBinFile("./input/input_xs_item0.bin")' in test_cpp
    assert 'fillHostWithBinFile("./input/input_ys_item0.bin")' not in test_cpp
    assert "std::vector<const aclTensor*> ys_acl_items" in test_cpp
    assert "aclCreateTensorList(ys_acl_items.data(), ys_acl_items.size())" in test_cpp
    assert "EXECOP(aclnnTensorListOutputCodegenKernel, stream, xs_acl, dummy, ys_acl);" in test_cpp
    assert 'ys_item0.saveHostToBinFile("output/output_ys_item0.bin")' in test_cpp
    assert "aclDestroyTensorList(ys_acl);" in test_cpp


def test_tensor_list_aclnn_test_preserves_each_item_shape(tmp_path: Path) -> None:
    _bind_tensor_list_item_numel_kernel()
    with _pushd(tmp_path):
        _tensor_list_item_numel_codegen_kernel.generate_aclnn_test(
            "aclnn_test",
            cann_path="/tmp/fake_cann",
            custom_op_path="/tmp/fake_cann",
        )
        test_cpp = (tmp_path / "aclnn_test" / "test.cpp").read_text(encoding="utf-8")

    assert "TensorX<FP16> xs_item0({2, 8});" in test_cpp
    assert "TensorX<FP16> xs_item1({4, 8});" in test_cpp
    assert "TensorX<FP16> ys_item0({2, 8});" in test_cpp
    assert "TensorX<FP16> ys_item1({4, 8});" in test_cpp
