from types import SimpleNamespace
import warnings

import pytest
import torch

from easyasc.simulator.pipe_cube import CubeMTE1Pipe, CubeMTE2Pipe, FixPipe, MPipe
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe import PipeS
from easyasc.simulator.pipe_micro import (
    LogicalViewAdvisoryWarning,
    MicroContext,
    MicroRuntime,
    VfBarrierWarning,
)
from easyasc.simulator.pipe_vec import MTE3Pipe, VPipe, VecMTE2Pipe
from easyasc.simulator.program import ControlInstruction, PipeTask
from easyasc.simulator.sync import Mailbox
from easyasc.utils.comparemode import CompareMode
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.instruction import Instruction
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.var import Var

from testcases.simulator.micro._micro_test_helpers import _TensorStore


def test_micro_gather_scatter_support_current_index_protocol() -> None:
    runtime = MicroRuntime()
    gather_idx = Reg(DT.uint32, name="gather_idx")
    scatter_idx = Reg(DT.uint32, name="scatter_idx")
    dst_reg = Reg(DT.float, name="dst_reg")
    src_reg = Reg(DT.float, name="src_reg")
    ub_src_ref = SimpleNamespace(name="ub_src")
    ub_dst_ref = SimpleNamespace(name="ub_dst")

    ctx = MicroContext(
        regs={
            "gather_idx": torch.tensor([3, 0, 1, 2] + [0] * 60, dtype=torch.int32),
            "scatter_idx": torch.tensor([1, 1, 2, 2] + [0] * 60, dtype=torch.int32),
            "dst_reg": torch.zeros(64, dtype=torch.float32),
            "src_reg": torch.tensor([10.0, 20.0, 30.0, 40.0] + [0.0] * 60, dtype=torch.float32),
        },
        tensor_views={
            "ub_src": torch.tensor([5.0, 6.0, 7.0, 8.0] + [0.0] * 60, dtype=torch.float32),
            "ub_dst": torch.zeros(64, dtype=torch.float32),
        },
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_datacopygather", {"dst": dst_reg, "src": ub_src_ref, "index": gather_idx}, SharedMemoryStore())
        runtime._dispatch("micro_datacopyscatter", {"dst": ub_dst_ref, "src": src_reg, "index": scatter_idx}, SharedMemoryStore())
    finally:
        runtime._stack.pop()

    gather_expected = torch.tensor([8.0, 5.0, 6.0, 7.0] + [5.0] * 60, dtype=torch.float32)
    scatter_expected = torch.zeros(64, dtype=torch.float32)
    scatter_expected[1] = 20.0
    scatter_expected[2] = 40.0

    torch.testing.assert_close(ctx.regs["dst_reg"], gather_expected)
    torch.testing.assert_close(ctx.tensor_views["ub_dst"], scatter_expected)
def test_micro_gather_uses_source_snapshot_with_current_index_protocol() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    index = Reg(DT.uint32, name="index")

    ctx = MicroContext(
        regs={
            "src": torch.tensor([10.0, 20.0, 30.0, 40.0] + [0.0] * 60, dtype=torch.float32),
            "index": torch.tensor([1, 0, 3, 2] + [0] * 60, dtype=torch.int32),
        },
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_gather", {"dst": src, "src": src, "index": index}, SharedMemoryStore())
    finally:
        runtime._stack.pop()

    expected = torch.tensor([20.0, 10.0, 40.0, 30.0] + [10.0] * 60, dtype=torch.float32)
    torch.testing.assert_close(ctx.regs["src"], expected)
def test_micro_datamove_empty_work_rejects_zero_active_masks() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="mask")
    ub_ref = SimpleNamespace(name="ub")

    ctx = MicroContext(
        regs={
            "src": torch.ones(64, dtype=torch.float32),
            "dst": torch.zeros(64, dtype=torch.float32),
        },
        masks={"mask": torch.zeros(64, dtype=torch.bool)},
        tensor_views={"ub": torch.zeros(64, dtype=torch.float32)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="micro_ub2reg resolved to an empty active mask"):
            runtime._dispatch("micro_ub2reg", {"dst": dst, "src": ub_ref, "mask": mask, "blk_stride": 2}, SharedMemoryStore())

        with pytest.raises(ValueError, match="micro_reg2ub resolved to an empty active mask"):
            runtime._dispatch("micro_reg2ub", {"dst": ub_ref, "src": src, "mask": mask, "blk_stride": 2}, SharedMemoryStore())

        # A Cast is different: an all-false mask is a well-defined predicated
        # Cast on device (ZEROING clears every lane, MERGING keeps the prior
        # value), and an exhausted UpdateMask tail group hits it every time, so
        # it must succeed rather than raise.
        runtime._dispatch("micro_cast", {"dst": dst, "src": src, "ddst": DT.float, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()


def test_micro_reg2ub_hazard_tracks_masked_store_footprint() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.bfloat16, name="src")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.LOWHALF, name="lowhalf")
    row0_ref = SimpleNamespace(name="row0")
    row1_ref = SimpleNamespace(name="row1")
    ub = torch.zeros((2, 64), dtype=torch.bfloat16)
    lowhalf = torch.cat([torch.ones(64, dtype=torch.bool), torch.zeros(64, dtype=torch.bool)])

    ctx = MicroContext(
        regs={"src": torch.arange(128, dtype=torch.float32).to(torch.bfloat16)},
        masks={"lowhalf": lowhalf},
        tensor_views={"row0": ub[0:1, 0:64], "row1": ub[1:2, 0:64]},
    )
    runtime._stack.append(ctx)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch("micro_reg2ub", {"dst": row0_ref, "src": src, "blk_stride": 1, "mask": mask}, SharedMemoryStore())
            runtime._dispatch("micro_reg2ub", {"dst": row1_ref, "src": src, "blk_stride": 1, "mask": mask}, SharedMemoryStore())
        barrier_warnings = [item for item in caught if item.category is VfBarrierWarning]
        assert not barrier_warnings
    finally:
        runtime._stack.pop()

    expected = torch.arange(64, dtype=torch.float32).to(torch.bfloat16)
    torch.testing.assert_close(ub[0], expected)
    torch.testing.assert_close(ub[1], expected)


def test_micro_reg2ub_warns_unmasked_bf16_store_past_tensor_view_before_hazard() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.bfloat16, name="src")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask_all")
    row0_ref = SimpleNamespace(name="row0")
    ub = torch.zeros((2, 64), dtype=torch.bfloat16)

    ctx = MicroContext(
        regs={"src": torch.arange(128, dtype=torch.float32).to(torch.bfloat16)},
        masks={"mask_all": torch.ones(128, dtype=torch.bool)},
        tensor_views={"row0": ub[0:1, 0:64]},
    )
    runtime._stack.append(ctx)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch("micro_reg2ub", {"dst": row0_ref, "src": src, "blk_stride": 1, "mask": mask}, SharedMemoryStore())
        assert any(
            item.category is LogicalViewAdvisoryWarning
            and
            "micro_reg2ub dst writes past UB tensor view: dst=row0 active_index=64 view_elements=64" in str(item.message)
            and "logical densification not guaranteed by hardware" in str(item.message)
            and "add an explicit mask" in str(item.message)
            and "padding buffer" in str(item.message)
            for item in caught
        )
        assert not [item for item in caught if item.category is VfBarrierWarning]
    finally:
        runtime._stack.pop()


def test_micro_ub2reg_warns_unmasked_bf16_load_past_tensor_view() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.bfloat16, name="dst")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask_all")
    row0_ref = SimpleNamespace(name="row0")
    ub = torch.arange(128, dtype=torch.float32).to(torch.bfloat16).view(2, 64)

    ctx = MicroContext(
        masks={"mask_all": torch.ones(128, dtype=torch.bool)},
        tensor_views={"row0": ub[0:1, 0:64]},
    )
    runtime._stack.append(ctx)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch("micro_ub2reg", {"dst": dst, "src": row0_ref, "blk_stride": 1, "mask": mask}, SharedMemoryStore())
        assert any(
            item.category is LogicalViewAdvisoryWarning
            and
            "micro_ub2reg src reads past UB tensor view: src=row0 active_index=64 view_elements=64" in str(item.message)
            and "logical densification not guaranteed by hardware" in str(item.message)
            and "add an explicit mask" in str(item.message)
            and "padding buffer" in str(item.message)
            for item in caught
        )
    finally:
        runtime._stack.pop()


def test_micro_reg2ub_warns_strided_bf16_store_past_tensor_view() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.bfloat16, name="src")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask_all")
    dst_ref = SimpleNamespace(name="dst_nz")
    dst_backing = torch.zeros(4096, dtype=torch.bfloat16)
    dst = dst_backing[:2048]

    ctx = MicroContext(
        regs={"src": torch.arange(128, dtype=torch.float32).to(torch.bfloat16)},
        masks={"mask_all": torch.ones(128, dtype=torch.bool)},
        tensor_views={"dst_nz": dst},
    )
    runtime._stack.append(ctx)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch("micro_reg2ub", {"dst": dst_ref, "src": src, "blk_stride": 32, "mask": mask}, SharedMemoryStore())
        assert any(
            item.category is LogicalViewAdvisoryWarning
            and
            "micro_reg2ub dst writes past UB tensor view: dst=dst_nz active_index=2048 view_elements=2048" in str(item.message)
            and "add an explicit mask" in str(item.message)
            and "padding buffer" in str(item.message)
            for item in caught
        )
    finally:
        runtime._stack.pop()


def test_micro_ub2reg_warns_strided_bf16_load_past_tensor_view() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.bfloat16, name="dst")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask_all")
    src_ref = SimpleNamespace(name="src_nz")
    src_backing = torch.zeros(4096, dtype=torch.bfloat16)
    src = src_backing[:2048]

    ctx = MicroContext(
        masks={"mask_all": torch.ones(128, dtype=torch.bool)},
        tensor_views={"src_nz": src},
    )
    runtime._stack.append(ctx)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch("micro_ub2reg", {"dst": dst, "src": src_ref, "blk_stride": 32, "mask": mask}, SharedMemoryStore())
        assert any(
            item.category is LogicalViewAdvisoryWarning
            and
            "micro_ub2reg src reads past UB tensor view: src=src_nz active_index=2048 view_elements=2048" in str(item.message)
            and "add an explicit mask" in str(item.message)
            and "padding buffer" in str(item.message)
            for item in caught
        )
    finally:
        runtime._stack.pop()


def test_micro_slice_preserves_logical_tensor_view_for_strided_bf16_store_guard() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.bfloat16, name="src")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask_all")
    dst_ref = SimpleNamespace(name="dst_nz")
    dst_tail_ref = SimpleNamespace(name="dst_tail")
    dst_backing = torch.zeros(4096, dtype=torch.bfloat16)
    dst = dst_backing[:2048]

    ctx = MicroContext(
        regs={"src": torch.arange(128, dtype=torch.float32).to(torch.bfloat16)},
        masks={"mask_all": torch.ones(128, dtype=torch.bool)},
        tensor_views={"dst_nz": dst},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_slice_tensor", {"src": dst_ref, "out": dst_tail_ref, "offset": 0}, SharedMemoryStore())
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch("micro_reg2ub", {"dst": dst_tail_ref, "src": src, "blk_stride": 32, "mask": mask}, SharedMemoryStore())
        assert any(
            item.category is LogicalViewAdvisoryWarning
            and
            "micro_reg2ub dst writes past UB tensor view: dst=dst_tail active_index=2048 view_elements=2048" in str(item.message)
            and "add an explicit mask" in str(item.message)
            and "padding buffer" in str(item.message)
            for item in caught
        )
    finally:
        runtime._stack.pop()


def test_micro_strided_bf16_datamove_accepts_masked_nz_footprint() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.bfloat16, name="src")
    dst = Reg(DT.bfloat16, name="dst")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.LOWHALF, name="mask_lowhalf")
    src_ref = SimpleNamespace(name="src_nz")
    dst_ref = SimpleNamespace(name="dst_nz")
    mask_lowhalf = torch.cat([torch.ones(64, dtype=torch.bool), torch.zeros(64, dtype=torch.bool)])
    values = torch.arange(128, dtype=torch.float32).to(torch.bfloat16)
    src_nz = torch.zeros(2048, dtype=torch.bfloat16)
    dst_nz = torch.zeros(2048, dtype=torch.bfloat16)
    for block in range(4):
        src_nz[block * 512:block * 512 + 16] = values[block * 16:block * 16 + 16]

    ctx = MicroContext(
        regs={
            "src": values.clone(),
            "dst": torch.zeros(128, dtype=torch.bfloat16),
        },
        masks={"mask_lowhalf": mask_lowhalf},
        tensor_views={"src_nz": src_nz, "dst_nz": dst_nz},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_reg2ub", {"dst": dst_ref, "src": src, "blk_stride": 32, "mask": mask}, SharedMemoryStore())
        runtime._dispatch("micro_ub2reg", {"dst": dst, "src": src_ref, "blk_stride": 32, "mask": mask}, SharedMemoryStore())
    finally:
        runtime._stack.pop()

    expected_nz = torch.zeros(2048, dtype=torch.bfloat16)
    for block in range(4):
        expected_nz[block * 512:block * 512 + 16] = values[block * 16:block * 16 + 16]
    torch.testing.assert_close(dst_nz, expected_nz)
    torch.testing.assert_close(ctx.regs["dst"][:64], values[:64])
    torch.testing.assert_close(ctx.regs["dst"][64:], torch.zeros(64, dtype=torch.bfloat16))


def test_micro_slice_then_single_value_read_uses_physical_pointer_order() -> None:
    runtime = MicroRuntime()
    dst = Reg(DT.bfloat16, name="dst")
    src_ref = SimpleNamespace(name="src")
    tail_ref = SimpleNamespace(name="tail")

    packed = torch.full((64, 16), -1.0, dtype=torch.bfloat16)
    packed[:, 0] = torch.arange(64, dtype=torch.float32).to(torch.bfloat16)
    logical_row = packed[:, 0].unsqueeze(0)

    ctx = MicroContext(tensor_views={"src": logical_row})
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_slice_tensor", {"src": src_ref, "out": tail_ref, "offset": 1}, SharedMemoryStore())
        runtime._dispatch("micro_ub2regcont", {"dst": dst, "src": tail_ref, "mode": "DIST_BRC_B16"}, SharedMemoryStore())
    finally:
        runtime._stack.pop()

    got = ctx.regs["dst"]
    assert float(logical_row[0, 1]) == 1.0
    assert float(got[0]) == -1.0
    torch.testing.assert_close(got, torch.full((128,), -1.0, dtype=torch.bfloat16))


def test_micro_slice_then_single_value_store_uses_physical_pointer_order() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.bfloat16, name="src")
    mask = MaskReg(DT.bfloat16, init_mode=MaskType.ALL, name="mask_all")
    dst_ref = SimpleNamespace(name="dst")
    tail_ref = SimpleNamespace(name="tail")

    packed = torch.zeros((64, 16), dtype=torch.bfloat16)
    logical_row = packed[:, 0].unsqueeze(0)
    src_reg = torch.arange(128, dtype=torch.float32).to(torch.bfloat16)

    ctx = MicroContext(
        regs={"src": src_reg.clone()},
        masks={"mask_all": torch.ones(128, dtype=torch.bool)},
        tensor_views={"dst": logical_row},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_slice_tensor", {"src": dst_ref, "out": tail_ref, "offset": 1}, SharedMemoryStore())
        runtime._dispatch(
            "micro_reg2ubcont",
            {"dst": tail_ref, "src": src, "mode": "DIST_FIRST_ELEMENT_B16", "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    assert float(logical_row[0, 1]) == 0.0
    assert float(packed[0, 1]) == float(src_reg[0])
    assert float(packed[1, 0]) == 0.0


def test_micro_datacopygather_uses_physical_pointer_order_for_sparse_logical_view() -> None:
    runtime = MicroRuntime()
    gather_idx = Reg(DT.uint32, name="gather_idx")
    dst_reg = Reg(DT.float, name="dst_reg")
    src_ref = SimpleNamespace(name="src")
    mask = MaskReg(DT.float, init_mode=MaskType.LOWEST4, name="mask_low4")

    packed = torch.full((64, 8), -1.0, dtype=torch.float32)
    packed[:, 0] = torch.arange(64, dtype=torch.float32)
    logical_row = packed[:, 0].unsqueeze(0)

    idx_values = torch.zeros(64, dtype=torch.int32)
    idx_values[:4] = torch.tensor([1, 2, 3, 4], dtype=torch.int32)
    expected = torch.zeros(64, dtype=torch.float32)
    expected[:4] = -1.0

    ctx = MicroContext(
        regs={
            "gather_idx": idx_values,
            "dst_reg": torch.zeros(64, dtype=torch.float32),
        },
        masks={"mask_low4": torch.tensor([True, True, True, True] + [False] * 60)},
        tensor_views={"src": logical_row},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_datacopygather",
            {"dst": dst_reg, "src": src_ref, "index": gather_idx, "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    assert float(logical_row[0, 1]) == 1.0
    torch.testing.assert_close(ctx.regs["dst_reg"], expected)


def test_micro_datacopyscatter_uses_physical_pointer_order_for_sparse_logical_view() -> None:
    runtime = MicroRuntime()
    scatter_idx = Reg(DT.uint32, name="scatter_idx")
    src_reg = Reg(DT.float, name="src_reg")
    dst_ref = SimpleNamespace(name="dst")
    mask = MaskReg(DT.float, init_mode=MaskType.LOWEST4, name="mask_low4")

    packed = torch.zeros((64, 8), dtype=torch.float32)
    logical_row = packed[:, 0].unsqueeze(0)

    idx_values = torch.zeros(64, dtype=torch.int32)
    idx_values[:4] = torch.tensor([1, 2, 3, 4], dtype=torch.int32)
    src_values = torch.zeros(64, dtype=torch.float32)
    src_values[:4] = torch.tensor([10.0, 20.0, 30.0, 40.0], dtype=torch.float32)

    ctx = MicroContext(
        regs={
            "scatter_idx": idx_values,
            "src_reg": src_values,
        },
        masks={"mask_low4": torch.tensor([True, True, True, True] + [False] * 60)},
        tensor_views={"dst": logical_row},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_datacopyscatter",
            {"dst": dst_ref, "src": src_reg, "index": scatter_idx, "mask": mask},
            SharedMemoryStore(),
        )
    finally:
        runtime._stack.pop()

    assert float(logical_row[0, 1]) == 0.0
    torch.testing.assert_close(packed[0, 1:5], torch.tensor([10.0, 20.0, 30.0, 40.0], dtype=torch.float32))
    torch.testing.assert_close(packed[1:5, 0], torch.zeros(4, dtype=torch.float32))


def test_micro_datamove_empty_views_raise() -> None:
    runtime = MicroRuntime()
    src = Reg(DT.float, name="src")
    dst = Reg(DT.float, name="dst")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")
    ub_ref = SimpleNamespace(name="ub")

    ctx = MicroContext(
        regs={"src": torch.ones(64, dtype=torch.float32), "dst": torch.zeros(64, dtype=torch.float32)},
        masks={"mask_all": torch.ones(64, dtype=torch.bool)},
        tensor_views={"ub": torch.zeros(0, dtype=torch.float32)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="micro_ub2reg source view is empty"):
            runtime._dispatch("micro_ub2reg", {"dst": dst, "src": ub_ref, "blk_stride": 1, "mask": mask_all}, SharedMemoryStore())

        with pytest.raises(ValueError, match="micro_reg2ub destination view is empty"):
            runtime._dispatch("micro_reg2ub", {"dst": ub_ref, "src": src, "blk_stride": 1, "mask": mask_all}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
@pytest.mark.parametrize(
    "pipe_cls, opname, args, message",
    [
        (
            MTE3Pipe,
            "ub_to_l1_nd2nz",
            {"dst": "dst", "src": "src", "m_dst": 8, "n_src": 0, "m_src": 8},
            "ub_to_l1_nd2nz requires non-zero m_src and n_src",
        ),
        (
            MTE3Pipe,
            "ub_to_l1_nz",
            {"dst": "dst", "src": "src", "m_dst": 8, "m_src": 8, "n_src": 0},
            "ub_to_l1_nz requires non-zero m_src and n_src",
        ),
        (
            CubeMTE2Pipe,
            "gm_to_l1_nd2nz",
            {"dst": "dst", "src": "src", "M": 0, "N": 8, "N_src": 8},
            "gm_to_l1_nd2nz requires non-zero M and N",
        ),
        (
            CubeMTE1Pipe,
            "l1_to_l0",
            {
                "dst": "dst",
                "src": "src",
                "m_dst": 0,
                "n_dst": 8,
                "m_src": 8,
                "n_src": 8,
                "dst_position": "L0A",
            },
            "l1_to_l0 requires non-zero m_dst and n_dst",
        ),
    ],
)
def test_pipe_zero_workloads_raise(pipe_cls, opname: str, args, message: str) -> None:
    from easyasc import globvars

    pipe = object.__new__(pipe_cls)
    pipe.memory_store = _TensorStore(
        {
            "dst": torch.zeros(256, dtype=torch.float32),
            "src": torch.zeros(256, dtype=torch.float32),
        }
    )

    old_device_type = getattr(globvars, "device_type", None)
    globvars.device_type = "950"
    try:
        with pytest.raises(ValueError, match=message):
            pipe.execute(PipeTask(pipe_name="X", opname=opname, args=args))
    finally:
        globvars.device_type = old_device_type
@pytest.mark.parametrize(
    "pipe_cls, opname, args",
    [
        (
            VecMTE2Pipe,
            "gm_to_ub_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 0,
                "burst_len_byte": 32,
                "src_stride_byte": 0,
                "dst_stride": 0,
            },
        ),
        (
            VecMTE2Pipe,
            "gm_to_ub_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 1,
                "burst_len_byte": 0,
                "src_stride_byte": 0,
                "dst_stride": 0,
            },
        ),
        (
            MTE3Pipe,
            "ub_to_gm_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 0,
                "burst_len_byte": 32,
                "dst_stride_byte": 0,
                "src_stride": 0,
            },
        ),
        (
            MTE3Pipe,
            "ub_to_gm_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 1,
                "burst_len_byte": 0,
                "dst_stride_byte": 0,
                "src_stride": 0,
            },
        ),
    ],
)
def test_burst_datamove_zero_workloads_skip(pipe_cls, opname: str, args) -> None:
    pipe = object.__new__(pipe_cls)
    dst = torch.arange(256, dtype=torch.float32)
    src = torch.arange(256, dtype=torch.float32) + 1000
    pipe.memory_store = _TensorStore({"dst": dst.clone(), "src": src.clone()})

    before_dst = pipe.memory_store.tensor("dst").clone()
    before_src = pipe.memory_store.tensor("src").clone()
    pipe.execute(PipeTask(pipe_name="X", opname=opname, args=args))
    torch.testing.assert_close(pipe.memory_store.tensor("dst"), before_dst)
    torch.testing.assert_close(pipe.memory_store.tensor("src"), before_src)
@pytest.mark.parametrize(
    "pipe_cls, opname, args, message",
    [
        (
            VecMTE2Pipe,
            "gm_to_ub_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": -1,
                "burst_len_byte": 32,
                "src_stride_byte": 0,
                "dst_stride": 0,
            },
            "gm_to_ub_pad requires non-negative n_burst, burst_len_byte, src_stride_byte, and dst_stride",
        ),
        (
            VecMTE2Pipe,
            "gm_to_ub_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 1,
                "burst_len_byte": 32,
                "src_stride_byte": -1,
                "dst_stride": 0,
            },
            "gm_to_ub_pad requires non-negative n_burst, burst_len_byte, src_stride_byte, and dst_stride",
        ),
        (
            MTE3Pipe,
            "ub_to_gm_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": -1,
                "burst_len_byte": 32,
                "dst_stride_byte": 0,
                "src_stride": 0,
            },
            "ub_to_gm_pad requires non-negative n_burst, burst_len_byte, dst_stride_byte, and src_stride",
        ),
        (
            MTE3Pipe,
            "ub_to_gm_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 1,
                "burst_len_byte": 32,
                "dst_stride_byte": -1,
                "src_stride": 0,
            },
            "ub_to_gm_pad requires non-negative n_burst, burst_len_byte, dst_stride_byte, and src_stride",
        ),
    ],
)
def test_burst_datamove_negative_values_raise(pipe_cls, opname: str, args, message: str) -> None:
    pipe = object.__new__(pipe_cls)
    pipe.memory_store = _TensorStore(
        {
            "dst": torch.zeros(256, dtype=torch.float32),
            "src": torch.zeros(256, dtype=torch.float32),
        }
    )

    with pytest.raises(ValueError, match=message):
        pipe.execute(PipeTask(pipe_name="X", opname=opname, args=args))
def test_micro_regcont_rejects_mode_fallbacks() -> None:
    runtime = MicroRuntime()
    dst_ref = SimpleNamespace(name="dst_ref", dtype=DT.float, length=0)
    src_ref = SimpleNamespace(name="src_ref", dtype=DT.float, length=0)
    ub_src = SimpleNamespace(name="ub_src")
    ub_dst = SimpleNamespace(name="ub_dst")
    mask_all = MaskReg(DT.float, init_mode=MaskType.ALL, name="mask_all")

    ctx = MicroContext(
        regs={
            "src_ref": torch.ones(64, dtype=torch.float32),
        },
        masks={"mask_all": torch.ones(64, dtype=torch.bool)},
        tensor_views={
            "ub_src": torch.ones(64, dtype=torch.float32),
            "ub_dst": torch.zeros(64, dtype=torch.float32),
        },
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(ValueError, match="unsupported micro_ub2regcont mode: BAD_MODE"):
            runtime._dispatch("micro_ub2regcont", {"dst": dst_ref, "src": ub_src, "mode": "BAD_MODE"}, SharedMemoryStore())

        with pytest.raises(ValueError, match="micro_ub2regcont mode DIST_PACK_B32 is incompatible with element size 4"):
            runtime._dispatch("micro_ub2regcont", {"dst": dst_ref, "src": ub_src, "mode": "DIST_PACK_B32"}, SharedMemoryStore())

        with pytest.raises(ValueError, match="unsupported micro_reg2ubcont mode: BAD_MODE"):
            runtime._dispatch(
                "micro_reg2ubcont",
                {"dst": ub_dst, "src": src_ref, "mode": "BAD_MODE", "mask": mask_all},
                SharedMemoryStore(),
            )

        with pytest.raises(ValueError, match="micro_reg2ubcont mode DIST_PACK_B32 is incompatible with element size 4"):
            runtime._dispatch(
                "micro_reg2ubcont",
                {"dst": ub_dst, "src": src_ref, "mode": "DIST_PACK_B32", "mask": mask_all},
                SharedMemoryStore(),
            )
    finally:
        runtime._stack.pop()


def _run_ub2regcont_mode(mode: str, torch_dtype, reg_dtype, src_values: torch.Tensor) -> torch.Tensor:
    runtime = MicroRuntime()
    dst_ref = SimpleNamespace(name="dst_ref", dtype=reg_dtype, length=0)
    ub_src = SimpleNamespace(name="ub_src")
    ctx = MicroContext(tensor_views={"ub_src": src_values.clone()})
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_ub2regcont", {"dst": dst_ref, "src": ub_src, "mode": mode}, SharedMemoryStore())
        return ctx.regs["dst_ref"].clone()
    finally:
        runtime._stack.pop()


def _run_ub2reginterleave_mode(mode: str, reg_dtype, src_values: torch.Tensor):
    runtime = MicroRuntime()
    dst0_ref = SimpleNamespace(name="dst0_ref", dtype=reg_dtype, length=0)
    dst1_ref = SimpleNamespace(name="dst1_ref", dtype=reg_dtype, length=0)
    ub_src = SimpleNamespace(name="ub_src")
    ctx = MicroContext(tensor_views={"ub_src": src_values.clone()})
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_ub2reginterleave",
            {"dst0": dst0_ref, "dst1": dst1_ref, "src": ub_src, "mode": mode},
            SharedMemoryStore(),
        )
        return ctx.regs["dst0_ref"].clone(), ctx.regs["dst1_ref"].clone()
    finally:
        runtime._stack.pop()


def _run_reg2ubinterleave_mode(mode: str, torch_dtype, reg_dtype, src0, src1):
    runtime = MicroRuntime()
    src0_ref = SimpleNamespace(name="src0_ref", dtype=reg_dtype, length=0)
    src1_ref = SimpleNamespace(name="src1_ref", dtype=reg_dtype, length=0)
    ub_dst = SimpleNamespace(name="ub_dst")
    mask_all = MaskReg(reg_dtype, init_mode=MaskType.ALL, name="mask_all")
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    ctx = MicroContext(
        regs={"src0_ref": src0.clone(), "src1_ref": src1.clone()},
        masks={"mask_all": torch.ones(lanes, dtype=torch.bool)},
        tensor_views={"ub_dst": torch.zeros(lanes * 2, dtype=torch_dtype)},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_reg2ubinterleave",
            {
                "dst": ub_dst, "src0": src0_ref, "src1": src1_ref, "mode": mode,
                "mask": mask_all,
            },
            SharedMemoryStore(),
        )
        return ctx.tensor_views["ub_dst"].clone()
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "torch_dtype,reg_dtype,mode",
    [
        (torch.uint8, DT.uint8, "DIST_INTLV_B8"),
        (torch.float16, DT.half, "DIST_INTLV_B16"),
        (torch.float32, DT.float, "DIST_INTLV_B32"),
    ],
)
def test_micro_reg2ubinterleave_writes_two_registers_interleaved(
    torch_dtype, reg_dtype, mode,
) -> None:
    """The dual store is the exact inverse of ``ub_to_reg_interleave``."""
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    values = torch.arange(lanes * 2, dtype=torch.int32).to(torch_dtype)
    src0 = values[0::2].clone()
    src1 = values[1::2].clone()
    got = _run_reg2ubinterleave_mode(mode, torch_dtype, reg_dtype, src0, src1)
    torch.testing.assert_close(got, values, rtol=0, atol=0)


def test_micro_reg2ubinterleave_rejects_mismatched_element_size() -> None:
    src = torch.zeros(64, dtype=torch.float32)
    with pytest.raises(
        ValueError,
        match="micro_reg2ubinterleave mode DIST_INTLV_B16 is incompatible",
    ):
        _run_reg2ubinterleave_mode("DIST_INTLV_B16", torch.float32, DT.float, src, src)


def _run_reg2ubcont_mode(mode: str, torch_dtype, reg_dtype, src_values: torch.Tensor) -> torch.Tensor:
    runtime = MicroRuntime()
    src_ref = SimpleNamespace(name="src_ref", dtype=reg_dtype, length=0)
    ub_dst = SimpleNamespace(name="ub_dst")
    mask_all = MaskReg(reg_dtype, init_mode=MaskType.ALL, name="mask_all")
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    ctx = MicroContext(
        regs={"src_ref": src_values.clone()},
        masks={"mask_all": torch.ones(lanes, dtype=torch.bool)},
        tensor_views={"ub_dst": torch.zeros(lanes, dtype=torch_dtype)},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_reg2ubcont",
            {"dst": ub_dst, "src": src_ref, "mode": mode, "mask": mask_all},
            SharedMemoryStore(),
        )
        return ctx.tensor_views["ub_dst"].clone()
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "torch_dtype,reg_dtype",
    [
        (torch.uint8, DT.uint8),
        (torch.float16, DT.half),
        (torch.float32, DT.float),
    ],
)
def test_micro_ub2regcont_norm_mode_semantics(torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    src_values = torch.arange(lanes, dtype=torch.int32).to(torch_dtype)
    got = _run_ub2regcont_mode("DIST_NORM", torch_dtype, reg_dtype, src_values)
    torch.testing.assert_close(got, src_values, rtol=0, atol=0)


def test_micro_ub2regcont_norm_warns_when_full_vl_exceeds_logical_view() -> None:
    runtime = MicroRuntime()
    dst_ref = SimpleNamespace(name="dst_ref", dtype=DT.float, length=0)
    ub_src = SimpleNamespace(name="ub_src")
    backing = torch.arange(64, dtype=torch.float32)
    ctx = MicroContext(tensor_views={"ub_src": backing[:32]})
    runtime._stack.append(ctx)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            runtime._dispatch(
                "micro_ub2regcont",
                {"dst": dst_ref, "src": ub_src, "mode": "DIST_NORM"},
                SharedMemoryStore(),
            )
        assert any(
            item.category is LogicalViewAdvisoryWarning
            and
            "micro_ub2regcont src reads past UB tensor view: src=ub_src active_index=32 view_elements=32"
            in str(item.message)
            for item in caught
        )
        torch.testing.assert_close(ctx.regs["dst_ref"], backing, rtol=0, atol=0)
    finally:
        runtime._stack.pop()


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_DINTLV_B8", torch.uint8, DT.uint8),
        ("DIST_DINTLV_B16", torch.float16, DT.half),
        ("DIST_DINTLV_B32", torch.float32, DT.float),
    ],
)
def test_micro_ub2reginterleave_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    base = torch.arange(lanes * 2, dtype=torch.int32)
    if torch_dtype is torch.uint8:
        src_values = base.remainder(251).to(torch.uint8)
    else:
        src_values = base.to(torch_dtype)
    got0, got1 = _run_ub2reginterleave_mode(mode, reg_dtype, src_values)
    torch.testing.assert_close(got0, src_values[0::2], rtol=0, atol=0)
    torch.testing.assert_close(got1, src_values[1::2], rtol=0, atol=0)


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_BRC_B8", torch.uint8, DT.uint8),
        ("DIST_BRC_B16", torch.float16, DT.half),
        ("DIST_BRC_B32", torch.float32, DT.float),
    ],
)
def test_micro_ub2regcont_brc_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    src_values = torch.arange(4, dtype=torch.int32).to(torch_dtype)
    got = _run_ub2regcont_mode(mode, torch_dtype, reg_dtype, src_values)
    expected = torch.full((lanes,), src_values[0].item(), dtype=torch_dtype)
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_DS_B8", torch.uint8, DT.uint8),
        ("DIST_DS_B16", torch.float16, DT.half),
    ],
)
def test_micro_ub2regcont_downsample_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    src_values = torch.arange(lanes * 2, dtype=torch.int32).to(torch_dtype)
    got = _run_ub2regcont_mode(mode, torch_dtype, reg_dtype, src_values)
    expected = src_values[0 : lanes * 2 : 2]
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_US_B8", torch.uint8, DT.uint8),
        ("DIST_US_B16", torch.float16, DT.half),
    ],
)
def test_micro_ub2regcont_upsample_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    src_values = torch.arange(lanes // 2, dtype=torch.int32).to(torch_dtype)
    got = _run_ub2regcont_mode(mode, torch_dtype, reg_dtype, src_values)
    expected = src_values.repeat_interleave(2)
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_UNPACK_B8", torch.uint8, DT.uint8),
        ("DIST_UNPACK_B16", torch.float16, DT.half),
        ("DIST_UNPACK_B32", torch.float32, DT.float),
    ],
)
def test_micro_ub2regcont_unpack_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    src_values = torch.arange(lanes // 2, dtype=torch.int32).to(torch_dtype)
    got = _run_ub2regcont_mode(mode, torch_dtype, reg_dtype, src_values)
    expected = torch.zeros(lanes, dtype=torch_dtype)
    expected[0::2] = src_values
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


def test_micro_ub2regcont_unpack4_mode_semantics() -> None:
    lanes = 256
    src_values = torch.arange(lanes // 4, dtype=torch.uint8)
    got = _run_ub2regcont_mode("DIST_UNPACK4_B8", torch.uint8, DT.uint8, src_values)
    expected = torch.zeros(lanes, dtype=torch.uint8)
    expected[0::4] = src_values
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_E2B_B16", torch.float16, DT.half),
        ("DIST_E2B_B32", torch.float32, DT.float),
    ],
)
def test_micro_ub2regcont_e2b_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    c0 = 32 // torch.empty((), dtype=torch_dtype).element_size()
    block_count = lanes // c0
    src_values = torch.arange(block_count, dtype=torch.int32).to(torch_dtype)
    got = _run_ub2regcont_mode(mode, torch_dtype, reg_dtype, src_values)
    expected = src_values.repeat_interleave(c0)
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_PACK_B16", torch.uint8, DT.uint8),
        ("DIST_PACK_B32", torch.float16, DT.half),
        ("DIST_PACK_B64", torch.float32, DT.float),
    ],
)
def test_micro_reg2ubcont_pack_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    src_values = torch.arange(lanes, dtype=torch.int32).to(torch_dtype)
    got = _run_reg2ubcont_mode(mode, torch_dtype, reg_dtype, src_values)
    expected = torch.zeros(lanes, dtype=torch_dtype)
    expected[: lanes // 2] = src_values[0::2]
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


def test_micro_reg2ubcont_pack4_mode_semantics() -> None:
    lanes = 256
    src_values = torch.arange(lanes, dtype=torch.uint8)
    got = _run_reg2ubcont_mode("DIST_PACK4_B32", torch.uint8, DT.uint8, src_values)
    expected = torch.zeros(lanes, dtype=torch.uint8)
    expected[: lanes // 4] = src_values[0::4]
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_FIRST_ELEMENT_B8", torch.uint8, DT.uint8),
        ("DIST_FIRST_ELEMENT_B16", torch.float16, DT.half),
        ("DIST_FIRST_ELEMENT_B32", torch.float32, DT.float),
    ],
)
def test_micro_reg2ubcont_first_element_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    src_values = torch.arange(lanes, dtype=torch.int32).to(torch_dtype)
    got = _run_reg2ubcont_mode(mode, torch_dtype, reg_dtype, src_values)
    expected = torch.zeros(lanes, dtype=torch_dtype)
    expected[0] = src_values[0]
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


@pytest.mark.parametrize(
    "mode,torch_dtype,reg_dtype",
    [
        ("DIST_NORM_B8", torch.uint8, DT.uint8),
        ("DIST_NORM_B16", torch.float16, DT.half),
        ("DIST_NORM_B32", torch.float32, DT.float),
    ],
)
def test_micro_reg2ubcont_norm_modes_semantics(mode: str, torch_dtype, reg_dtype) -> None:
    lanes = 256 // torch.empty((), dtype=torch_dtype).element_size()
    src_values = torch.arange(lanes, dtype=torch.int32).to(torch_dtype)
    got = _run_reg2ubcont_mode(mode, torch_dtype, reg_dtype, src_values)
    torch.testing.assert_close(got, src_values, rtol=0, atol=0)


def test_micro_reg2ubcont_supports_float8_norm_mode() -> None:
    if not hasattr(torch, "float8_e5m2"):
        pytest.skip("Current torch build does not support torch.float8_e5m2")

    runtime = MicroRuntime()
    src_ref = SimpleNamespace(name="src_ref", dtype=DT.e5m2, length=0)
    ub_dst = SimpleNamespace(name="ub_dst")
    mask_all = MaskReg(DT.e5m2, init_mode=MaskType.ALL, name="mask_all")

    src_values = torch.linspace(-4.0, 4.0, 64, dtype=torch.float32).to(torch.float8_e5m2)
    dst_values = torch.zeros(64, dtype=torch.float8_e5m2)
    ctx = MicroContext(
        regs={"src_ref": src_values.clone()},
        masks={"mask_all": torch.ones(64, dtype=torch.bool)},
        tensor_views={"ub_dst": dst_values},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_reg2ubcont",
            {"dst": ub_dst, "src": src_ref, "mode": "DIST_NORM_B8", "mask": mask_all},
            SharedMemoryStore(),
        )
        torch.testing.assert_close(ctx.tensor_views["ub_dst"].float(), src_values.float(), rtol=1e-4, atol=1e-4)
    finally:
        runtime._stack.pop()
def test_micro_reg2ub_supports_float8_block_stride() -> None:
    if not hasattr(torch, "float8_e4m3fn"):
        pytest.skip("Current torch build does not support torch.float8_e4m3fn")

    runtime = MicroRuntime()
    src_ref = SimpleNamespace(name="src_ref", dtype=DT.e4m3)
    ub_dst = SimpleNamespace(name="ub_dst")
    mask_all = MaskReg(DT.e4m3, init_mode=MaskType.ALL, name="mask_all")

    src_values = torch.linspace(-4.0, 4.0, 64, dtype=torch.float32).to(torch.float8_e4m3fn)
    dst_values = torch.zeros(96, dtype=torch.float8_e4m3fn)
    ctx = MicroContext(
        regs={"src_ref": src_values.clone()},
        masks={"mask_all": torch.ones(64, dtype=torch.bool)},
        tensor_views={"ub_dst": dst_values},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_reg2ub",
            {"dst": ub_dst, "src": src_ref, "blk_stride": 2, "mask": mask_all},
            SharedMemoryStore(),
        )
        expected = torch.zeros(96, dtype=torch.float8_e4m3fn)
        expected[:32].copy_(src_values[:32])
        expected[64:96].copy_(src_values[32:64])
        torch.testing.assert_close(ctx.tensor_views["ub_dst"].float(), expected.float(), rtol=1e-4, atol=1e-4)
    finally:
        runtime._stack.pop()
def test_micro_ub2reg_supports_float8_block_stride() -> None:
    if not hasattr(torch, "float8_e4m3fn"):
        pytest.skip("Current torch build does not support torch.float8_e4m3fn")

    runtime = MicroRuntime()
    dst_ref = Reg(DT.e4m3, name="dst_ref")
    ub_src = SimpleNamespace(name="ub_src")
    mask_all = MaskReg(DT.e4m3, init_mode=MaskType.ALL, name="mask_all")

    src_values = torch.linspace(-4.0, 4.0, 256, dtype=torch.float32).to(torch.float8_e4m3fn)
    ub_values = torch.zeros(480, dtype=torch.float8_e4m3fn)
    for block in range(8):
        src0 = block * 32
        dst0 = block * 64
        ub_values[dst0:dst0 + 32].copy_(src_values[src0:src0 + 32])
    ctx = MicroContext(
        regs={"dst_ref": torch.zeros(256, dtype=torch.float8_e4m3fn)},
        masks={"mask_all": torch.ones(256, dtype=torch.bool)},
        tensor_views={"ub_src": ub_values},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch(
            "micro_ub2reg",
            {"dst": dst_ref, "src": ub_src, "blk_stride": 2, "mask": mask_all},
            SharedMemoryStore(),
        )
        torch.testing.assert_close(ctx.regs["dst_ref"].float(), src_values.float(), rtol=1e-4, atol=1e-4)
    finally:
        runtime._stack.pop()
def test_micro_reg2ubcont_reglist_requires_all_source_registers() -> None:
    runtime = MicroRuntime()
    src_ref = SimpleNamespace(name="src_ref", dtype=DT.float, length=2)
    ub_dst = SimpleNamespace(name="ub_dst")

    ctx = MicroContext(
        regs={
            "src_ref[0]": torch.ones(64, dtype=torch.float32),
        },
        tensor_views={"ub_dst": torch.zeros(128, dtype=torch.float32)},
    )
    runtime._stack.append(ctx)
    try:
        with pytest.raises(KeyError, match="micro_reg2ubcont source register not found: src_ref\\[1\\]"):
            runtime._dispatch("micro_reg2ubcont", {"dst": ub_dst, "src": src_ref}, SharedMemoryStore())
    finally:
        runtime._stack.pop()
