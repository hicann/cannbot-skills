"""A2 vector shift stub and code-generation coverage."""

import pytest

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


def test_a2_shift_codegen_uses_ascendc_memory_vector_apis() -> None:
    @kernel()
    def shift_codegen(inp: GMTensor):
        src = Tensor(DT.int16, [1, 128], Position.UB)
        dst = Tensor(DT.int16, [1, 128], Position.UB)
        shiftls(dst, src, 2, repeat=1)
        shiftrs(dst, src, 3, repeat=1, round_en=True)
        return inp

    inp = GMTensor(DT.int16, [1, 128])
    shift_codegen(inp)
    _, vec_code = translate_split(shift_codegen.instructions, "shift_codegen")

    assert "ShiftLeft<int16_t, false>" in vec_code
    assert "(int16_t)2, MASK_PLACEHOLDER, 1" in vec_code
    assert "ShiftRight<int16_t, false>" in vec_code
    assert "(int16_t)3, MASK_PLACEHOLDER, 1" in vec_code
    assert "}, true);" in vec_code


def test_a2_shift_codegen_casts_dynamic_integer_var_to_tensor_dtype() -> None:
    @kernel()
    def dynamic_shift_codegen(inp: GMTensor, shift: Var):
        src = Tensor(DT.int16, [1, 128], Position.UB)
        dst = Tensor(DT.int16, [1, 128], Position.UB)
        shiftls(dst, src, shift, repeat=1)
        return inp

    inp = GMTensor(DT.int16, [1, 128])
    dynamic_shift_codegen(inp, Var(2, DT.int))
    _, vec_code = translate_split(dynamic_shift_codegen.instructions, "dynamic_shift_codegen")

    assert "ShiftLeft<int16_t, false>" in vec_code
    assert "(int16_t)shift, MASK_PLACEHOLDER, 1" in vec_code


def test_a2_existing_logical_ops_codegen_to_and_or_not() -> None:
    @kernel()
    def logical_codegen(inp: GMTensor):
        src0 = Tensor(DT.uint16, [1, 128], Position.UB)
        src1 = Tensor(DT.uint16, [1, 128], Position.UB)
        dst = Tensor(DT.uint16, [1, 128], Position.UB)
        dst <<= src0 & src1
        dst <<= src0 | src1
        dst <<= src0.vnot()
        return inp

    inp = GMTensor(DT.uint16, [1, 128])
    logical_codegen(inp)
    _, vec_code = translate_split(logical_codegen.instructions, "logical_codegen")

    assert "And<uint16_t, false>" in vec_code
    assert "Or<uint16_t, false>" in vec_code
    assert "Not<uint16_t, false>" in vec_code


def test_a2_int32_logical_ops_use_explicit_uint16_reinterpret_path() -> None:
    @kernel()
    def logical_int32_view_codegen(inp: GMTensor):
        src0 = Tensor(DT.uint32, [1, 64], Position.UB)
        src1 = Tensor(DT.uint32, [1, 64], Position.UB)
        dst = Tensor(DT.uint32, [1, 64], Position.UB)
        src0_u16 = reinterpret(src0, DT.uint16)
        src1_u16 = reinterpret(src1, DT.uint16)
        dst_u16 = reinterpret(dst, DT.uint16)
        dst_u16 <<= src0_u16 & src1_u16
        dst_u16 <<= src0_u16 | src1_u16
        dst_u16 <<= src0_u16.vnot()
        return inp

    inp = GMTensor(DT.uint32, [1, 64])
    logical_int32_view_codegen(inp)
    _, vec_code = translate_split(
        logical_int32_view_codegen.instructions, "logical_int32_view_codegen"
    )

    assert "And<uint16_t, false>" in vec_code
    assert "Or<uint16_t, false>" in vec_code
    assert "Not<uint16_t, false>" in vec_code


@pytest.mark.parametrize("dtype", [DT.int16, DT.uint16, DT.int, DT.uint32])
def test_a2_shift_stubs_accept_documented_dtypes(dtype) -> None:
    dst = Tensor(dtype, [1, 128], Position.UB)
    src = Tensor(dtype, [1, 128], Position.UB)
    shiftls(dst, src, 1, repeat=1)
    shiftrs(dst, src, 1, repeat=1)


def test_a2_shift_stubs_reject_unsupported_dtype_and_static_range() -> None:
    float_dst = Tensor(DT.float, [1, 64], Position.UB)
    float_src = Tensor(DT.float, [1, 64], Position.UB)
    with pytest.raises(ValueError, match="does not support data type"):
        shiftls(float_dst, float_src, 1)

    int16_dst = Tensor(DT.int16, [1, 128], Position.UB)
    int16_src = Tensor(DT.int16, [1, 128], Position.UB)
    with pytest.raises(ValueError, match=r"\[0, 16\]"):
        shiftls(int16_dst, int16_src, 17)

    int32_dst = Tensor(DT.int, [1, 64], Position.UB)
    int32_src = Tensor(DT.int, [1, 64], Position.UB)
    with pytest.raises(ValueError, match=r"\[0, 32\]"):
        shiftrs(int32_dst, int32_src, -1)


def test_a2_shift_var_and_rounding_guards_match_ascendc_contract() -> None:
    int16_dst = Tensor(DT.int16, [1, 128], Position.UB)
    int16_src = Tensor(DT.int16, [1, 128], Position.UB)
    shiftls(int16_dst, int16_src, Var(1, DT.int))
    with pytest.raises(ValueError, match="must have an integer dtype"):
        shiftls(int16_dst, int16_src, Var(1.0, DT.float))

    uint16_dst = Tensor(DT.uint16, [1, 128], Position.UB)
    uint16_src = Tensor(DT.uint16, [1, 128], Position.UB)
    # AscendC accepts the bool for unsigned tensors; it is only effective for
    # signed int16/int32 inputs.
    shiftrs(uint16_dst, uint16_src, 1, round_en=True)
    with pytest.raises(TypeError, match="round_en must be bool"):
        shiftrs(int16_dst, int16_src, 1, round_en=1)


def test_a2_vor_expression_rejects_non_native_int32_path() -> None:
    dst = Tensor(DT.int, [1, 64], Position.UB)
    src0 = Tensor(DT.int, [1, 64], Position.UB)
    src1 = Tensor(DT.int, [1, 64], Position.UB)
    with pytest.raises(TypeError, match="vor only supports int16_t/uint16_t"):
        dst <<= src0 | src1
