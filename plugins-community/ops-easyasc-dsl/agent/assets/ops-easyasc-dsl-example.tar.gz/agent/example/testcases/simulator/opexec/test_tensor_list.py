import pytest
import torch

from easyasc.a2 import *


@kernel(mode="vec")
def _tensor_list_last_copy_kernel(xs: GMTensorList, out: GMTensor, dummy: Var):
    ub = Tensor(DT.half, [1, 16], Position.UB)
    with auto_sync():
        for i in range(xs.size()):
            item = xs[i]
            gm_to_ub_pad(ub, item, 1, 16, 0, 0)
            ub_to_gm_pad(out, ub, 1, 16, 0, 0)
    return out


@kernel(mode="vec")
def _tensor_list_shape_binding_kernel(xs: GMTensorList, out: GMTensor, m: Var, n: Var):
    return out


@kernel(mode="vec")
def _tensor_list_output_copy_kernel(xs: GMTensorList, ys: GMTensorList, dummy: Var):
    ub = Tensor(DT.half, [1, 16], Position.UB)
    with auto_sync():
        for i in range(xs.size()):
            src = xs[i]
            dst = ys[i]
            gm_to_ub_pad(ub, src, 1, 16, 0, 0)
            ub_to_gm_pad(dst, ub, 1, 16, 0, 0)
    return ys


@kernel(mode="vec")
def _tensor_list_variable_item_copy_kernel(
    xs: GMTensorList, ys: GMTensorList, item_count: Var,
):
    ub = Tensor(DT.half, [1, 32], Position.UB)
    with auto_sync():
        for i in range(item_count):
            item_numel = xs.item_numel(i)
            src = xs[i].reshape([1, item_numel])
            dst = ys[i].reshape([1, item_numel])
            gm_to_ub_pad(ub[0:1, 0:item_numel], src[0:1, 0:item_numel])
            ub_to_gm_pad(dst[0:1, 0:item_numel], ub[0:1, 0:item_numel])
            bar_all()
    return ys


def test_tensor_list_size_and_var_getitem_simulator(tmp_path) -> None:
    xs = [
        torch.full((1, 16), 1.0, dtype=torch.float16),
        torch.full((1, 16), 2.0, dtype=torch.float16),
        torch.full((1, 16), 3.0, dtype=torch.float16),
    ]
    out = torch.zeros((1, 16), dtype=torch.float16)

    got = OpExec(
        _tensor_list_last_copy_kernel,
        out_dir=str(tmp_path / "tensor_list_last_copy"),
        simulator=True,
    )(xs, out, 0)

    torch.testing.assert_close(got, xs[-1])


def test_tensor_list_shape_bindings_apply_to_item_shape(tmp_path) -> None:
    xs = [
        torch.ones((1, 16), dtype=torch.float16),
        torch.full((1, 16), 2.0, dtype=torch.float16),
    ]
    out = torch.zeros((1, 16), dtype=torch.float16)

    got = OpExec(
        _tensor_list_shape_binding_kernel,
        out_dir=str(tmp_path / "tensor_list_shape_bind"),
        simulator=True,
    )(
        xs,
        out,
        1,
        16,
        shape_bindings={
            0: {"item": [0, 1]},
            1: [0, 1],
        },
    )

    assert got.shape == out.shape


def test_tensor_list_output_simulator(tmp_path) -> None:
    xs = [
        torch.full((1, 16), 4.0, dtype=torch.float16),
        torch.full((1, 16), 5.0, dtype=torch.float16),
    ]
    ys = [torch.zeros((1, 16), dtype=torch.float16) for _ in xs]

    got = OpExec(
        _tensor_list_output_copy_kernel,
        out_dir=str(tmp_path / "tensor_list_output_copy"),
        simulator=True,
    )(
        xs,
        ys,
        0,
        shape_bindings={
            0: {"item": [None, None]},
            1: {"item": [None, None]},
        },
    )

    assert isinstance(got, list)
    assert len(got) == len(xs)
    for actual, expected in zip(got, xs):
        torch.testing.assert_close(actual, expected)


def test_tensor_list_items_may_have_different_shapes_with_same_rank(tmp_path) -> None:
    xs = [
        torch.arange(16, dtype=torch.float16).reshape(2, 8),
        torch.arange(32, dtype=torch.float16).reshape(4, 8),
    ]
    ys = [torch.zeros_like(item) for item in xs]

    got = OpExec(
        _tensor_list_variable_item_copy_kernel,
        out_dir=str(tmp_path / "tensor_list_variable_item_copy"),
        simulator=True,
    )(
        xs,
        ys,
        len(xs),
        shape_bindings={
            0: {"item": [None, None]},
            1: {"item": [None, None]},
        },
    )

    assert [tuple(item.shape) for item in got] == [(2, 8), (4, 8)]
    for actual, expected in zip(got, xs):
        torch.testing.assert_close(actual, expected)


def test_tensor_list_items_still_require_one_rank(tmp_path) -> None:
    xs = [
        torch.ones((1, 16), dtype=torch.float16),
        torch.ones((16,), dtype=torch.float16),
    ]
    out = torch.zeros((1, 16), dtype=torch.float16)

    with pytest.raises(
        ValueError,
        match=r"TensorList argument #0 item #1 rank mismatch: 1 vs 2",
    ):
        OpExec(
            _tensor_list_shape_binding_kernel,
            out_dir=str(tmp_path / "tensor_list_rank_mismatch"),
            simulator=True,
        )(xs, out, 1, 16)


def test_tensor_list_shared_shape_binding_is_checked_per_item(tmp_path) -> None:
    xs = [
        torch.ones((1, 16), dtype=torch.float16),
        torch.ones((1, 32), dtype=torch.float16),
    ]
    out = torch.zeros((1, 16), dtype=torch.float16)

    with pytest.raises(
        ValueError,
        match=r"shape_bindings\[0\]\.item \(item #1\)\[1\] mismatches tensor dim value",
    ):
        OpExec(
            _tensor_list_shape_binding_kernel,
            out_dir=str(tmp_path / "tensor_list_per_item_binding"),
            simulator=True,
        )(
            xs,
            out,
            1,
            16,
            shape_bindings={
                0: {"item": [0, 1]},
                1: [0, 1],
            },
        )


def test_tensor_list_item_numel_validates_static_index() -> None:
    xs = GMTensorList(DT.half, [1, 16], length=2)

    with pytest.raises(IndexError, match=r"must be non-negative"):
        xs.item_numel(-1)
    with pytest.raises(IndexError, match=r"out of range: 2"):
        xs.item_numel(2)
    with pytest.raises(TypeError, match=r"only supports int or Var"):
        xs.item_numel(1.0)
