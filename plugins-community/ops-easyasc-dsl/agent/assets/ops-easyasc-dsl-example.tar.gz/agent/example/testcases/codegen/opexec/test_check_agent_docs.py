import io
import tarfile
from pathlib import Path

from agent.scripts.check_agent_docs import analyze_repo


def _write_minimal_repo(root: Path) -> None:
    (root / "agent" / "playbooks").mkdir(parents=True)
    (root / "AGENTS.md").write_text(
        "Read `agent/common-language.md` in full after routing.\n", encoding="utf-8"
    )
    (root / "agent" / "common-language.md").write_text(
        "# Common Language\n", encoding="utf-8"
    )
    (root / "agent" / "ROUTER.md").write_text(
        "# Router\n\n[Build](playbooks/build.md)\n", encoding="utf-8"
    )
    (root / "agent" / "playbooks" / "build.md").write_text(
        "# Build\n\n## Valid anchor\n", encoding="utf-8"
    )


def test_docs_checker_accepts_valid_links_paths_and_router(tmp_path: Path) -> None:
    _write_minimal_repo(tmp_path)
    (tmp_path / "README.md").write_text(
        "[Build](agent/playbooks/build.md#valid-anchor) and "
        "`agent/playbooks/build.md`. Use `tmp/<task>/run.py`.\n",
        encoding="utf-8",
    )
    result = analyze_repo(tmp_path, run_generated_checks=False)
    assert result["warnings"] == []


def test_docs_checker_reports_broken_and_nonportable_references(tmp_path: Path) -> None:
    _write_minimal_repo(tmp_path)
    removed_role = "libr" + "arian"
    (tmp_path / "README.md").write_text(
        "[Missing](agent/missing.md)\n"
        "[Bad anchor](agent/playbooks/build.md#absent)\n"
        "`agent/scripts/not_here.py`\n"
        "tmp/concrete/result.json\n"
        "/home/alice/repo 192.0.2.10\n"
        "agent/playbooks/onnx-to-" + "kernel.md\n"
        + removed_role + "\n",
        encoding="utf-8",
    )
    result = analyze_repo(tmp_path, run_generated_checks=False)
    codes = {item["code"] for item in result["warnings"]}
    assert {
        "broken-link", "broken-anchor", "missing-repo-path", "concrete-tmp-path",
        "machine-path", "machine-ip", "legacy-doc-path", "removed-role-reference",
    }.issubset(codes)


def test_docs_checker_reports_non_markdown_machine_references(tmp_path: Path) -> None:
    _write_minimal_repo(tmp_path)
    (tmp_path / "script.py").write_text(
        'ROOT = "/home/alice/repo"\nHOST = "198.51.100.12"\n',
        encoding="utf-8",
    )
    result = analyze_repo(tmp_path, run_generated_checks=False)
    codes = {item["code"] for item in result["warnings"]}
    assert {"machine-path", "machine-ip"}.issubset(codes)


def test_docs_checker_reports_archive_privacy_and_generated_junk(tmp_path: Path) -> None:
    _write_minimal_repo(tmp_path)
    archive_path = tmp_path / "payload.tar.gz"
    with tarfile.open(archive_path, "w:gz") as archive:
        payload = b'ROOT = "/home/alice/repo"\nHOST = "198.51.100.12"\n'
        member = tarfile.TarInfo("payload/__pycache__/tool.pyc")
        member.size = len(payload)
        member.uid = 501
        member.gid = 20
        member.uname = "alice"
        member.gname = "staff"
        archive.addfile(member, io.BytesIO(payload))
        apple_double = tarfile.TarInfo("payload/._tool.py")
        archive.addfile(apple_double, io.BytesIO())

    result = analyze_repo(tmp_path, run_generated_checks=False)
    codes = {item["code"] for item in result["warnings"]}
    assert {
        "archive-generated-junk", "archive-owner-metadata",
        "archive-machine-path", "archive-machine-ip",
    }.issubset(codes)


def test_docs_checker_requires_each_playbook_once_in_router(tmp_path: Path) -> None:
    _write_minimal_repo(tmp_path)
    (tmp_path / "agent" / "playbooks" / "extra.md").write_text("# Extra\n", encoding="utf-8")
    result = analyze_repo(tmp_path, run_generated_checks=False)
    assert any(
        item["code"] == "router-cardinality" and "extra.md" in item["message"]
        for item in result["warnings"]
    )


def test_docs_checker_requires_common_language_initial_load(tmp_path: Path) -> None:
    _write_minimal_repo(tmp_path)
    (tmp_path / "AGENTS.md").write_text("# Agents\n", encoding="utf-8")
    result = analyze_repo(tmp_path, run_generated_checks=False)
    assert any(item["code"] == "common-language-not-baseline" for item in result["warnings"])


def test_docs_checker_limits_common_language_lines(tmp_path: Path) -> None:
    _write_minimal_repo(tmp_path)
    (tmp_path / "agent" / "common-language.md").write_text(
        "\n".join(["term"] * 251) + "\n", encoding="utf-8"
    )
    result = analyze_repo(tmp_path, run_generated_checks=False)
    assert any(item["code"] == "common-language-line-budget" for item in result["warnings"])


def test_docs_checker_limits_common_language_bytes(tmp_path: Path) -> None:
    _write_minimal_repo(tmp_path)
    (tmp_path / "agent" / "common-language.md").write_text(
        "# Common Language\n" + ("x" * (15 * 1024)), encoding="utf-8"
    )
    result = analyze_repo(tmp_path, run_generated_checks=False)
    assert any(item["code"] == "common-language-byte-budget" for item in result["warnings"])
