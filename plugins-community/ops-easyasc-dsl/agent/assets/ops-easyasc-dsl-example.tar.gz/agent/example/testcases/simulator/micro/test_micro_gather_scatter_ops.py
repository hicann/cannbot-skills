"""Full dtype-combination coverage for ub_to_reg_gather / reg_to_ub_scatter.

MicroAPI::DataCopyGather (vgather2) and DataCopyScatter (vscatter) on dav_c310
(Ascend950) support these combinations, keyed on the UB byte width
(kernel_micro_datacopy_impl.h DataCopyGather/ScatterImpl static_asserts):

    gather   b8 src  -> b16 dst, u16 idx   (byte ZERO-extend: dst = 0x00<byte>)
             b16 -> b16, u16 | b32 -> b32, u32 | b64 -> b64, u32|u64
    scatter  b8, u16  (EVEN source lanes: flat[idx[k]] = src[2k])
             b16, u16 | b32, u32 | b64, u32|u64

Two b8 runtime semantics are board-verified (Ascend950, 2026-07-21) and asserted
here so the simulator stays bit-identical to the hardware:
  * b8 -> b16 gather ZERO-extends the source byte (NOT sign-extend / numeric cast);
  * b8 scatter moves only the EVEN source lanes -- flat[idx[k]] = src[2k].

Layered like the other micro tests: MicroRuntime value semantics + DSL trace-time
gate acceptance/rejection. End-to-end OpExec(simulator=True) and the board are
covered by kernels/a5/vec_only/gather_scatter_onboard.py.
"""
from contextlib import contextmanager
from types import SimpleNamespace

import pytest
import torch

from easyasc import globvars
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.stub_functions.micro.datamove import reg_to_ub_scatter, ub_to_reg_gather
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.positions import Position
from easyasc.utils.reg import MaskReg, Reg
from easyasc.utils.Tensor import Tensor


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _u64(int64_tensor: torch.Tensor) -> torch.Tensor:
    # torch CPU lacks most uint64 ops (copy_/index_put/compare); build in int64
    # and reinterpret the bits.
    return int64_tensor.view(torch.uint64)


def _eq(got: torch.Tensor, want: torch.Tensor) -> bool:
    if got.is_floating_point():
        return torch.allclose(got.float(), want.float(), rtol=0, atol=0)
    gi = got.view(torch.int64) if got.dtype is torch.uint64 else got.to(torch.int64)
    wi = want.view(torch.int64) if want.dtype is torch.uint64 else want.to(torch.int64)
    return bool(torch.equal(gi, wi))


def _run_gather(dst_dt, dst_torch, ub_torch, idx_dt, idx_torch, mask=None, masks=None):
    runtime = MicroRuntime()
    dst = Reg(dst_dt, name="gd")
    index = Reg(idx_dt, name="gi")
    ub = SimpleNamespace(name="gub")
    kw = {"dst": dst, "src": ub, "index": index}
    if mask is not None:
        kw["mask"] = mask
    ctx = MicroContext(
        regs={"gd": dst_torch.clone(), "gi": idx_torch.clone()},
        tensor_views={"gub": ub_torch.clone()},
        masks=masks or {},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_datacopygather", kw, SharedMemoryStore())
        return ctx.regs["gd"]
    finally:
        runtime._stack.pop()


def _run_scatter(src_dt, src_torch, ub_torch, idx_dt, idx_torch, mask=None, masks=None):
    runtime = MicroRuntime()
    src = Reg(src_dt, name="ss")
    index = Reg(idx_dt, name="si")
    ub = SimpleNamespace(name="sub")
    kw = {"dst": ub, "src": src, "index": index}
    if mask is not None:
        kw["mask"] = mask
    ctx = MicroContext(
        regs={"ss": src_torch.clone(), "si": idx_torch.clone()},
        tensor_views={"sub": ub_torch.clone()},
        masks=masks or {},
    )
    runtime._stack.append(ctx)
    try:
        runtime._dispatch("micro_datacopyscatter", kw, SharedMemoryStore())
        return ctx.tensor_views["sub"]
    finally:
        runtime._stack.pop()


# =========================================================================== #
# (1) b8 -> b16 gather: ZERO-extend (board-verified, NOT sign-extend)
# =========================================================================== #
def test_gather_b8_to_b16_zero_extends_signed_source() -> None:
    # source bytes [0,1,...,255] as int8; index picks the HIGH bytes 128..255.
    ub = torch.arange(256, dtype=torch.int64).remainder(256).to(torch.uint8).view(torch.int8)
    idx = torch.arange(128, 256, dtype=torch.int64).to(torch.uint16)  # [128..255]
    out = _run_gather(DT.int16, torch.zeros(128, dtype=torch.int16), ub, DT.uint16, idx)
    # zero-extend -> dst = 128,129,...,255 (all positive); sign-extend would give -128,-127,...
    assert _eq(out, torch.arange(128, 256, dtype=torch.int16))
    assert int(out[0]) == 128  # 0x80 -> 128, not -128


def test_gather_b8_to_b16_zero_extends_unsigned_source() -> None:
    ub = torch.arange(256, dtype=torch.int64).remainder(256).to(torch.uint8)
    idx = torch.arange(128, 256, dtype=torch.int64).to(torch.uint16)
    out = _run_gather(DT.uint16, torch.zeros(128, dtype=torch.uint16), ub, DT.uint16, idx)
    assert _eq(out, torch.arange(128, 256, dtype=torch.int64).to(torch.uint16))


def test_gather_b8_to_b16_reinterprets_bits_into_half_dst() -> None:
    # any 1-byte source into a 2-byte dst is a raw byte zero-extend, not a numeric
    # convert: byte 0x3c -> half bits 0x003c (a tiny subnormal), NOT 60.0.
    ub = torch.full((256,), 0x3C, dtype=torch.uint8)
    idx = torch.zeros(128, dtype=torch.uint16)
    out = _run_gather(DT.half, torch.zeros(128, dtype=torch.float16), ub, DT.uint16, idx)
    expect = torch.tensor([0x003C], dtype=torch.int16).view(torch.float16)[0]
    assert torch.equal(out.view(torch.int16), torch.full((128,), 0x003C, dtype=torch.int16))
    assert float(out[0]) == float(expect)


def test_gather_mask_is_lane_wise_and_does_not_read_inactive_indices() -> None:
    src = torch.tensor([10.0, 20.0, 30.0, 40.0], dtype=torch.float32)
    idx = torch.full((64,), 1000, dtype=torch.uint32)
    idx[3] = 2
    mask = MaskReg(DT.float, init_mode=MaskType.NONE, name="lane3")
    mask_bits = torch.zeros(64, dtype=torch.bool)
    mask_bits[3] = True

    out = _run_gather(
        DT.float, torch.zeros(64, dtype=torch.float32), src,
        DT.uint32, idx, mask=mask, masks={"lane3": mask_bits},
    )

    expected = torch.zeros(64, dtype=torch.float32)
    expected[3] = 30.0
    torch.testing.assert_close(out, expected)


# =========================================================================== #
# (2) same-width gather: bit-copy permutation over every width / index dtype
# =========================================================================== #
_GATHER_SAME = [
    ("half.u16", DT.half, torch.float16, DT.uint16, torch.uint16, 128, 128),
    ("int16.u16", DT.int16, torch.int16, DT.uint16, torch.uint16, 128, 128),
    ("uint16.u16", DT.uint16, torch.uint16, DT.uint16, torch.uint16, 128, 128),
    ("bf16.u16", DT.bfloat16, torch.bfloat16, DT.uint16, torch.uint16, 128, 128),
    ("float.u32", DT.float, torch.float32, DT.uint32, torch.uint32, 64, 64),
    ("int.u32", DT.int, torch.int32, DT.uint32, torch.uint32, 64, 64),
    ("uint32.u32", DT.uint32, torch.uint32, DT.uint32, torch.uint32, 64, 64),
    ("int64.u32", DT.int64, torch.int64, DT.uint32, torch.uint32, 32, 64),
    ("int64.u64", DT.int64, torch.int64, DT.uint64, torch.uint64, 32, 32),
    ("uint64.u32", DT.uint64, torch.uint64, DT.uint32, torch.uint32, 32, 64),
    ("uint64.u64", DT.uint64, torch.uint64, DT.uint64, torch.uint64, 32, 32),
]


@pytest.mark.parametrize("tag,dt,tdt,idt,itdt,n,idx_lanes", _GATHER_SAME)
def test_gather_same_width_permutation(tag, dt, tdt, idt, itdt, n, idx_lanes) -> None:
    base = torch.arange(n, dtype=torch.int64)
    src = _u64(base * 0x100000001) if tdt is torch.uint64 else base.to(tdt)
    perm = torch.arange(n - 1, -1, -1, dtype=torch.int64)  # reversed
    if itdt is torch.uint64:
        idx = torch.zeros(idx_lanes, dtype=torch.int64); idx[:n] = perm; idx = _u64(idx)
    else:
        idx = torch.zeros(idx_lanes, dtype=torch.int64); idx[:n] = perm; idx = idx.to(itdt)
    out = _run_gather(dt, torch.zeros(n, dtype=tdt), src, idt, idx)
    want = _u64(base.flip(0) * 0x100000001) if tdt is torch.uint64 else base.flip(0).to(tdt)
    assert _eq(out, want), tag


# =========================================================================== #
# (3) b8 scatter: EVEN source lanes (board-verified) flat[idx[k]] = src[2k]
# =========================================================================== #
def test_scatter_b8_uses_even_source_lanes() -> None:
    src = torch.arange(256, dtype=torch.int64).remainder(256).to(torch.uint8)  # [0..255]
    idx = torch.arange(128, dtype=torch.int64).to(torch.uint16)                # identity k
    out = _run_scatter(DT.uint8, src, torch.zeros(256, dtype=torch.uint8), DT.uint16, idx)
    want = torch.zeros(256, dtype=torch.uint8)
    want[:128] = torch.arange(0, 256, 2, dtype=torch.int64).to(torch.uint8)    # src[2k]
    assert _eq(out, want)
    assert out[:4].tolist() == [0, 2, 4, 6]  # NOT [0,1,2,3]


def test_scatter_b8_even_source_with_permuted_index() -> None:
    src = torch.arange(256, dtype=torch.int64).remainder(256).to(torch.uint8)
    idx = torch.arange(127, -1, -1, dtype=torch.int64).to(torch.uint16)   # reversed: dst[127-k]=src[2k]
    out = _run_scatter(DT.uint8, src, torch.zeros(256, dtype=torch.uint8), DT.uint16, idx)
    want = torch.zeros(256, dtype=torch.uint8)
    for k in range(128):
        want[127 - k] = 2 * k
    assert _eq(out, want)


# =========================================================================== #
# (4) same-width scatter: every width / index dtype
# =========================================================================== #
_SCATTER_SAME = [
    ("half.u16", DT.half, torch.float16, DT.uint16, torch.uint16, 128, 128),
    ("int16.u16", DT.int16, torch.int16, DT.uint16, torch.uint16, 128, 128),
    ("bf16.u16", DT.bfloat16, torch.bfloat16, DT.uint16, torch.uint16, 128, 128),
    ("float.u32", DT.float, torch.float32, DT.uint32, torch.uint32, 64, 64),
    ("int.u32", DT.int, torch.int32, DT.uint32, torch.uint32, 64, 64),
    ("int64.u32", DT.int64, torch.int64, DT.uint32, torch.uint32, 32, 64),
    ("int64.u64", DT.int64, torch.int64, DT.uint64, torch.uint64, 32, 32),
    ("uint64.u64", DT.uint64, torch.uint64, DT.uint64, torch.uint64, 32, 32),
]


@pytest.mark.parametrize("tag,dt,tdt,idt,itdt,n,idx_lanes", _SCATTER_SAME)
def test_scatter_same_width_permutation(tag, dt, tdt, idt, itdt, n, idx_lanes) -> None:
    base = torch.arange(n, dtype=torch.int64)
    src = _u64(base * 0x100000001) if tdt is torch.uint64 else base.to(tdt)
    perm = torch.arange(n - 1, -1, -1, dtype=torch.int64)   # dst[n-1-k] = src[k]
    if itdt is torch.uint64:
        idx = torch.zeros(idx_lanes, dtype=torch.int64); idx[:n] = perm; idx = _u64(idx)
    else:
        idx = torch.zeros(idx_lanes, dtype=torch.int64); idx[:n] = perm; idx = idx.to(itdt)
    out = _run_scatter(dt, src, torch.zeros(n, dtype=tdt), idt, idx)
    want = _u64(base.flip(0) * 0x100000001) if tdt is torch.uint64 else base.flip(0).to(tdt)
    assert _eq(out, want), tag


# =========================================================================== #
# (5) DSL trace-time gates
# =========================================================================== #
class _FakeMicro:
    def __init__(self) -> None:
        self.instructions = []
        self.tmp_idx = 0

    def _register_reg_name(self, name, kind) -> None:
        return None

    def get_mask(self, dtype, reg_num=1):
        return MaskReg(dtype, init_mode=MaskType.ALL, name="mask")


@contextmanager
def _fake_micro():
    old_micro, old_dev = globvars.active_micro, globvars.device_type
    fake = _FakeMicro()
    try:
        globvars.device_type = "950"
        globvars.active_micro = fake
        yield fake
    finally:
        globvars.active_micro = old_micro
        globvars.device_type = old_dev


# ---- gather acceptance: every supported combo emits micro_datacopygather ---- #
_GATHER_OK = [
    (DT.int8, DT.int16, DT.uint16),      # b8 -> b16 zero-extend
    (DT.uint8, DT.uint16, DT.uint16),
    (DT.e4m3, DT.int16, DT.uint16),      # any 1-byte src -> any 2-byte dst
    (DT.half, DT.half, DT.uint16),
    (DT.bfloat16, DT.bfloat16, DT.uint16),
    (DT.float, DT.float, DT.uint32),
    (DT.int, DT.int, DT.uint32),
    (DT.int64, DT.int64, DT.uint32),     # b64, u32 index
    (DT.int64, DT.int64, DT.uint64),     # b64, u64 index
    (DT.uint64, DT.uint64, DT.uint32),
    (DT.uint64, DT.uint64, DT.uint64),
]


@pytest.mark.parametrize("src_dt,dst_dt,idx_dt", _GATHER_OK)
def test_stub_gather_accepts_supported_combos(src_dt, dst_dt, idx_dt) -> None:
    with _fake_micro() as fake:
        dst = Reg(dst_dt, name="dst")
        src = Tensor(src_dt, [1, 256], Position.UB, name="src")
        index = Reg(idx_dt, name="index")
        ub_to_reg_gather(dst, src, index)
    assert fake.instructions[-1].opname == "micro_datacopygather"


_SCATTER_OK = [
    (DT.int8, DT.uint16),
    (DT.uint8, DT.uint16),
    (DT.half, DT.uint16),
    (DT.bfloat16, DT.uint16),
    (DT.float, DT.uint32),
    (DT.int, DT.uint32),
    (DT.int64, DT.uint32),
    (DT.int64, DT.uint64),
    (DT.uint64, DT.uint32),
    (DT.uint64, DT.uint64),
]


@pytest.mark.parametrize("dt,idx_dt", _SCATTER_OK)
def test_stub_scatter_accepts_supported_combos(dt, idx_dt) -> None:
    with _fake_micro() as fake:
        dst = Tensor(dt, [1, 256], Position.UB, name="dst")
        src = Reg(dt, name="src")
        index = Reg(idx_dt, name="index")
        reg_to_ub_scatter(dst, src, index)
    assert fake.instructions[-1].opname == "micro_datacopyscatter"


# ---- gather rejection ---- #
def test_stub_gather_rejects_8bit_src_with_non_16bit_dst() -> None:
    with _fake_micro():
        dst = Reg(DT.e4m3, name="dst")       # 1-byte dst
        src = Tensor(DT.int8, [1, 256], Position.UB, name="src")
        index = Reg(DT.uint16, name="index")
        with pytest.raises(ValueError, match="8-bit src.*requires a 16-bit dst"):
            ub_to_reg_gather(dst, src, index)


def test_stub_gather_rejects_dst_src_mismatch_same_width() -> None:
    with _fake_micro():
        dst = Reg(DT.float, name="dst")
        src = Tensor(DT.int, [1, 64], Position.UB, name="src")
        index = Reg(DT.uint32, name="index")
        with pytest.raises(ValueError, match="dst/src data types must match"):
            ub_to_reg_gather(dst, src, index)


@pytest.mark.parametrize(
    "src_dt,idx_dt,msg",
    [
        (DT.int8, DT.uint32, "8-bit data must be uint16_t"),   # b8 needs u16
        (DT.half, DT.uint32, "16-bit data must be uint16_t"),
        (DT.float, DT.uint16, "32-bit data must be uint32_t"),
        (DT.int64, DT.uint16, "64-bit data must be uint32_t or uint64_t"),
    ],
)
def test_stub_gather_rejects_bad_index_dtype(src_dt, idx_dt, msg) -> None:
    with _fake_micro():
        dst_dt = DT.int16 if src_dt is DT.int8 else src_dt
        dst = Reg(dst_dt, name="dst")
        src = Tensor(src_dt, [1, 256], Position.UB, name="src")
        index = Reg(idx_dt, name="index")
        with pytest.raises(ValueError, match=msg):
            ub_to_reg_gather(dst, src, index)


# =========================================================================== #
# scatter mask granularity: LANE-WISE, not expanded to whole C0 blocks
# (board-verified 2026-07-29, kernels/a5/vec_only/scatter_mask_probe.py).  A
# scatter writes individual elements, so unlike the continuous reg <-> UB paths
# it must not round the active lane count up to a 32-byte block.
# =========================================================================== #
def test_scatter_mask_is_lane_wise_not_c0_expanded_b32() -> None:
    # 5 active lanes out of an 8-lane b32 C0 block: exactly 5 elements move.
    src = torch.arange(1, 65, dtype=torch.float32)
    idx = torch.arange(64, dtype=torch.int64).to(torch.uint32)
    mask = torch.zeros(64, dtype=torch.bool)
    mask[:5] = True
    out = _run_scatter(DT.float, src, torch.full((64,), -1.0), DT.uint32, idx,
                       mask=SimpleNamespace(name="m"), masks={"m": mask})
    assert _eq(out[:5], torch.arange(1, 6, dtype=torch.float32))
    assert bool((out[5:] == -1.0).all())


def test_scatter_mask_is_lane_wise_not_c0_expanded_b16() -> None:
    # Even lanes of a 16-lane b16 C0 block active, index[2i] == index[2i+1] == i:
    # the layout `cast` produces when it narrows a b32 register.  With the mask
    # expanded to the block, the odd lanes would win the duplicate-index race.
    src = torch.zeros(128, dtype=torch.float16)
    src[0::2] = torch.arange(1, 65, dtype=torch.float16)
    idx = (torch.arange(128, dtype=torch.int64) // 2).to(torch.uint16)
    mask = torch.zeros(128, dtype=torch.bool)
    mask[0:22:2] = True  # even lanes 0..20 -> elements 0..10
    out = _run_scatter(DT.half, src, torch.full((64,), -1.0, dtype=torch.float16),
                       DT.uint16, idx, mask=SimpleNamespace(name="m"), masks={"m": mask})
    assert _eq(out[:11], torch.arange(1, 12, dtype=torch.float16))
    assert bool((out[11:] == -1.0).all())


# ---- scatter rejection ---- #
def test_stub_scatter_rejects_dst_src_mismatch() -> None:
    with _fake_micro():
        dst = Tensor(DT.float, [1, 64], Position.UB, name="dst")
        src = Reg(DT.int, name="src")
        index = Reg(DT.uint32, name="index")
        with pytest.raises(ValueError, match="dst/src data types must match"):
            reg_to_ub_scatter(dst, src, index)


@pytest.mark.parametrize(
    "dt,idx_dt,msg",
    [
        (DT.uint8, DT.uint32, "8-bit data must be uint16_t"),
        (DT.half, DT.uint32, "16-bit data must be uint16_t"),
        (DT.float, DT.uint16, "32-bit data must be uint32_t"),
        (DT.int64, DT.uint16, "64-bit data must be uint32_t or uint64_t"),
    ],
)
def test_stub_scatter_rejects_bad_index_dtype(dt, idx_dt, msg) -> None:
    with _fake_micro():
        dst = Tensor(dt, [1, 256], Position.UB, name="dst")
        src = Reg(dt, name="src")
        index = Reg(idx_dt, name="index")
        with pytest.raises(ValueError, match=msg):
            reg_to_ub_scatter(dst, src, index)
