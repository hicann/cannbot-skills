"""Generated-entry regressions for A5 user workspace addressing."""

from pathlib import Path

import pytest

from easyasc.a5 import *


@kernel()
def _workspace_entry_kernel(src: GMTensor, out: GMTensor):
    split_workspace(DT.half, [4], name="half_stage")
    split_workspace(DT.float, [3], name="float_stage")
    return out


@kernel()
def _no_workspace_entry_kernel(src: GMTensor, out: GMTensor):
    return out


def _dump_entry(tmp_path: Path, kernel_obj) -> tuple:
    """Return the entry ``.cpp`` and its vector helper header."""
    src = GMTensor(DT.half, [1, 16], name="src")
    out = GMTensor(DT.half, [1, 16], name="out")
    kernel_obj(src, out)
    base = tmp_path / kernel_obj.name
    kernel_obj.dump_kernel(str(base))
    vec_header = base.with_name(base.name + "_vec.h")
    return (
        base.with_suffix(".cpp").read_text(encoding="utf-8"),
        vec_header.read_text(encoding="utf-8"),
    )


@pytest.mark.easyasc_device("a5")
def test_a5_entry_registers_the_system_workspace_and_offsets_once(tmp_path: Path) -> None:
    """The system region is registered at the entry, offset past at each split.

    C310 hands the entry one combined system-plus-user workspace.
    ``SetSysWorkspaceForce`` registers the system region so the AscendC library
    APIs can find it, and each ``split_workspace`` reaches the user region
    through ``GetUserWorkspace``. Those are two different jobs: the entry must
    NOT also offset the pointer it passes down, or every split would offset a
    second time and hand out memory past the user area.
    """
    cpp, vec = _dump_entry(tmp_path, _workspace_entry_kernel)
    set_sys = "AscendC::SetSysWorkspaceForce(workspace);"
    cube_call = "_workspace_entry_kernel_cube(src, out, workspace);"
    vec_call = "_workspace_entry_kernel_vec(src, out, workspace);"

    assert cpp.count(set_sys) == 1
    assert cpp.count(cube_call) == 1
    assert cpp.count(vec_call) == 1
    assert cpp.index(set_sys) < cpp.index(cube_call) < cpp.index(vec_call)

    # The entry hands down the raw base; it does not pre-offset it.
    assert "GetUserWorkspace" not in cpp
    assert "workspace_usr" not in cpp

    # One offset per split_workspace, applied where the split happens.
    assert vec.count("GetUserWorkspace(workspace)") == 2


@pytest.mark.easyasc_device("a5")
def test_a5_entry_without_user_workspace_is_unchanged(tmp_path: Path) -> None:
    cpp, _ = _dump_entry(tmp_path, _no_workspace_entry_kernel)

    assert "SetSysWorkspaceForce" not in cpp
    assert "GetUserWorkspace" not in cpp
    assert "_no_workspace_entry_kernel_cube(src, out, workspace);" in cpp
    assert "_no_workspace_entry_kernel_vec(src, out, workspace);" in cpp


@pytest.mark.easyasc_device("b3")
def test_a2_workspace_entry_keeps_existing_raw_pointer_contract(tmp_path: Path) -> None:
    cpp, _ = _dump_entry(tmp_path, _workspace_entry_kernel)

    assert "SetSysWorkspaceForce" not in cpp
    assert "GetUserWorkspace" not in cpp
    assert "_workspace_entry_kernel_cube(src, out, workspace);" in cpp
    assert "_workspace_entry_kernel_vec(src, out, workspace);" in cpp
