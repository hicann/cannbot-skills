import pytest
import torch

from easyasc import globvars
from easyasc.simulator.pipe_cube import CubeMTE2Pipe, MPipe
from easyasc.simulator.pipe_vec import MTE3Pipe, VecMTE2Pipe
from easyasc.simulator.program import PipeTask
from easyasc.simulator.util import decode_nz_to_nd


class _TensorStore(object):
    def __init__(self, tensors=None):
        self._tensors = dict(tensors or {})

    def tensor(self, name):
        return self._tensors[name]


def _pipe(pipe_cls, tensors):
    pipe = object.__new__(pipe_cls)
    pipe.memory_store = _TensorStore(tensors)
    return pipe


class _Device(object):
    def __init__(self, device_type):
        self.device_type = device_type
        self.saved = None

    def __enter__(self):
        self.saved = globvars.device_type
        globvars.device_type = self.device_type

    def __exit__(self, exc_type, exc, tb):
        globvars.device_type = self.saved


def test_gm_to_ub_pad_source_uses_burst_footprint_not_dense_rectangle() -> None:
    src = torch.arange(116, dtype=torch.uint8)
    dst = torch.full((64,), 0xAA, dtype=torch.uint8)
    pipe = _pipe(VecMTE2Pipe, {"dst": dst, "src": src})

    pipe.execute(PipeTask("MTE2", "gm_to_ub_pad", {
        "dst": "dst", "src": "src",
        "n_burst": 2, "burst_len_byte": 8, "src_stride_byte": 100, "dst_stride": 0,
    }))

    torch.testing.assert_close(dst[0:8], src[0:8])
    torch.testing.assert_close(dst[32:40], src[108:116])
    # GM2UBPAD passes isPad=false, so the transfer moves whole 32-byte blocks
    # and the bytes past burst_len inside the last one hold what that block
    # carried in memory rather than zeros.  Board-measured 2026-08-04 on
    # DepthwiseConv2D: staging a zero band directly after a row whose width is
    # not a multiple of C0 read this dirt instead of its zeros, and failed only
    # for those shapes while every simulated case passed.
    torch.testing.assert_close(dst[8:32], src[8:32])
    # Past the end of the source there is nothing to model, so the simulator
    # poisons instead of leaving the destination readable.
    torch.testing.assert_close(
        dst[40:64], torch.full((24,), 0x7F, dtype=torch.uint8))


def test_gm_to_ub_pad_rejects_actual_source_overflow() -> None:
    pipe = _pipe(VecMTE2Pipe, {
        "dst": torch.zeros(64, dtype=torch.uint8),
        "src": torch.zeros(115, dtype=torch.uint8),
    })

    with pytest.raises(RuntimeError, match="gm_to_ub_pad src byte footprint"):
        pipe.execute(PipeTask("MTE2", "gm_to_ub_pad", {
            "dst": "dst", "src": "src",
            "n_burst": 2, "burst_len_byte": 8, "src_stride_byte": 100, "dst_stride": 0,
        }))


def test_ub_to_gm_pad_rejects_actual_destination_overflow() -> None:
    pipe = _pipe(MTE3Pipe, {
        "dst": torch.zeros(115, dtype=torch.uint8),
        "src": torch.zeros(116, dtype=torch.uint8),
    })

    with pytest.raises(RuntimeError, match="ub_to_gm_pad dst byte footprint"):
        pipe.execute(PipeTask("MTE3", "ub_to_gm_pad", {
            "dst": "dst", "src": "src",
            "n_burst": 2, "burst_len_byte": 8, "dst_stride_byte": 100, "src_stride": 0,
        }))


def test_ub_to_l1_uses_32b_burst_and_stride_units() -> None:
    with _Device("950"):
        src = torch.arange(160, dtype=torch.uint8)
        dst = torch.full((256,), 0xAA, dtype=torch.uint8)
        pipe = _pipe(MTE3Pipe, {"dst": dst, "src": src})

        pipe.execute(PipeTask("MTE3", "ub_to_l1", {
            "dst": "dst", "src": "src",
            "n_burst": 2, "burst_len": 2, "src_stride": 1, "dst_stride": 2,
        }))

    torch.testing.assert_close(dst[0:64], src[0:64])
    torch.testing.assert_close(dst[64:128], torch.full((64,), 0xAA, dtype=torch.uint8))
    torch.testing.assert_close(dst[128:192], src[96:160])
    torch.testing.assert_close(dst[192:256], torch.full((64,), 0xAA, dtype=torch.uint8))


def test_ub_to_l1_rejects_actual_destination_overflow() -> None:
    with _Device("950"):
        pipe = _pipe(MTE3Pipe, {
            "dst": torch.zeros(127, dtype=torch.uint8),
            "src": torch.zeros(64, dtype=torch.uint8),
        })

        with pytest.raises(RuntimeError, match="ub_to_l1 dst byte footprint"):
            pipe.execute(PipeTask("MTE3", "ub_to_l1", {
                "dst": "dst", "src": "src",
                "n_burst": 2, "burst_len": 1, "src_stride": 0, "dst_stride": 2,
            }))


@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_ub_to_l1_rejects_c220_device(device_type) -> None:
    with _Device(device_type):
        pipe = _pipe(MTE3Pipe, {
            "dst": torch.zeros(64, dtype=torch.uint8),
            "src": torch.zeros(64, dtype=torch.uint8),
        })

        with pytest.raises(RuntimeError, match="ub_to_l1 not supported on C220 device"):
            pipe.execute(PipeTask("MTE3", "ub_to_l1", {
                "dst": "dst", "src": "src",
                "n_burst": 1, "burst_len": 1, "src_stride": 0, "dst_stride": 0,
            }))


@pytest.mark.parametrize(
    "pipe_cls, opname, args",
    [
        (
            VecMTE2Pipe,
            "gm_to_ub_pad",
            {
                "dst": "dst", "src": "src", "n_burst": 4096,
                "burst_len_byte": 0, "src_stride_byte": 0, "dst_stride": 0,
            },
        ),
        (
            MTE3Pipe,
            "ub_to_gm_pad",
            {
                "dst": "dst", "src": "src", "n_burst": 4096,
                "burst_len_byte": 0, "dst_stride_byte": 0, "src_stride": 0,
            },
        ),
    ],
)
@pytest.mark.parametrize("n_burst", [-1, 4096])
@pytest.mark.parametrize("device_type", ["b3", "a3"])
def test_c220_datacopy_pad_runtime_rejects_out_of_range(
    pipe_cls, opname, args, n_burst, device_type,
) -> None:
    with _Device(device_type):
        pipe = _pipe(pipe_cls, {
            "dst": torch.zeros(32, dtype=torch.uint8),
            "src": torch.zeros(32, dtype=torch.uint8),
        })
        message = (
            "requires non-negative"
            if n_burst < 0
            else rf"{opname} on C220 requires n_burst in \[0, 4095\]"
        )
        with pytest.raises(ValueError, match=message):
            pipe.execute(PipeTask("X", opname, dict(args, n_burst=n_burst)))


@pytest.mark.parametrize(
    "pipe_cls, opname, args",
    [
        (
            VecMTE2Pipe,
            "gm_to_ub_pad",
            {
                "dst": "dst", "src": "src", "n_burst": 4095,
                "burst_len_byte": 0, "src_stride_byte": 0, "dst_stride": 0,
            },
        ),
        (
            MTE3Pipe,
            "ub_to_gm_pad",
            {
                "dst": "dst", "src": "src", "n_burst": 4095,
                "burst_len_byte": 0, "dst_stride_byte": 0, "src_stride": 0,
            },
        ),
    ],
)
@pytest.mark.parametrize("n_burst", [0, 4095])
def test_a2_datacopy_pad_runtime_accepts_boundaries(pipe_cls, opname, args, n_burst) -> None:
    with _Device("b3"):
        pipe = _pipe(pipe_cls, {
            "dst": torch.zeros(32, dtype=torch.uint8),
            "src": torch.zeros(32, dtype=torch.uint8),
        })
        pipe.execute(PipeTask("X", opname, dict(args, n_burst=n_burst)))


@pytest.mark.parametrize(
    "pipe_cls, opname, args",
    [
        (
            VecMTE2Pipe,
            "gm_to_ub_pad",
            {
                "dst": "dst", "src": "src", "n_burst": 4096,
                "burst_len_byte": 0, "src_stride_byte": 0, "dst_stride": 0,
            },
        ),
        (
            MTE3Pipe,
            "ub_to_gm_pad",
            {
                "dst": "dst", "src": "src", "n_burst": 4096,
                "burst_len_byte": 0, "dst_stride_byte": 0, "src_stride": 0,
            },
        ),
    ],
)
def test_a5_datacopy_pad_runtime_keeps_n_burst_4096(pipe_cls, opname, args) -> None:
    with _Device("950"):
        pipe = _pipe(pipe_cls, {
            "dst": torch.zeros(32, dtype=torch.uint8),
            "src": torch.zeros(32, dtype=torch.uint8),
        })
        pipe.execute(PipeTask("X", opname, args))


def test_ub_to_l1_nz_hif8_reinterpret_slice_keeps_parent_base() -> None:
    """A runtime HIF8 view keeps its carrier whole; src_col0 is applied once."""
    with _Device("950"):
        src = torch.arange(33 * 256, dtype=torch.int64).to(torch.uint8)
        dst = torch.zeros(128 * 128, dtype=torch.uint8)
        src_name = "slice@carrier:hif8:0,64:32,64"
        pipe = _pipe(MTE3Pipe, {"dst": dst, src_name: src})

        pipe.execute(PipeTask("MTE3", "ub_to_l1_nz", {
            "dst": "dst", "src": src_name,
            "m_dst": 128, "n_dst": 64, "m_src": 32, "n_src": 64,
            "M_src": 33, "dst_row0": 0, "dst_col0": 0,
            "src_row0": 0, "src_col0": 64,
        }))

    src_block = 33 * 32
    dst_block = 128 * 32
    torch.testing.assert_close(dst[0:32 * 32], src[2 * src_block:2 * src_block + 32 * 32])
    torch.testing.assert_close(
        dst[dst_block:dst_block + 32 * 32],
        src[3 * src_block:3 * src_block + 32 * 32],
    )


def test_ub_to_l1_nd2nz_tail_block_uses_touched_tail_only() -> None:
    with _Device("950"):
        src = torch.arange(33, dtype=torch.uint8)
        dst = torch.zeros(513, dtype=torch.uint8)
        pipe = _pipe(MTE3Pipe, {"dst": dst, "src": src})

        pipe.execute(PipeTask("MTE3", "ub_to_l1_nd2nz", {
            "dst": "dst", "src": "src",
            "m_dst": 1, "n_dst": 33, "m_src": 1, "n_src": 33,
        }))

    torch.testing.assert_close(dst[0:32], src[0:32])
    assert int(dst[512].item()) == int(src[32].item())


def test_ub_to_l1_nd2nz_rejects_actual_tail_write_overflow() -> None:
    with _Device("950"):
        pipe = _pipe(MTE3Pipe, {
            "dst": torch.zeros(512, dtype=torch.uint8),
            "src": torch.zeros(33, dtype=torch.uint8),
        })

        with pytest.raises(RuntimeError, match="ub_to_l1_nd2nz dst footprint"):
            pipe.execute(PipeTask("MTE3", "ub_to_l1_nd2nz", {
                "dst": "dst", "src": "src",
                "m_dst": 1, "n_dst": 33, "m_src": 1, "n_src": 33,
            }))


def test_ub_to_l1_nd2nz_uses_N_src_for_strided_source_rows() -> None:
    """Source is logically [m_src=2, N_src=8] half but only the leading
    [2, 4] window is moved.  Row 1 must read src[8:12], not src[4:8]."""
    with _Device("950"):
        src = torch.arange(16, dtype=torch.float16)
        dst = torch.zeros(512, dtype=torch.float16)
        pipe = _pipe(MTE3Pipe, {"dst": dst, "src": src})

        pipe.execute(PipeTask("MTE3", "ub_to_l1_nd2nz", {
            "dst": "dst", "src": "src",
            "m_dst": 16, "n_dst": 4, "m_src": 2, "n_src": 4, "N_src": 8,
        }))

    # half c0 = 16, stride_m = align16(16) = 16.  Block 0 row 0 lands at
    # dst[0:4] (cols 0..3 of row 0); block 0 row 1 at dst[16:20].
    torch.testing.assert_close(dst[0:4], torch.tensor([0, 1, 2, 3], dtype=torch.float16))
    torch.testing.assert_close(dst[16:20], torch.tensor([8, 9, 10, 11], dtype=torch.float16))


def test_ub_to_l1_nd2nz_default_N_src_matches_n_src_back_compat() -> None:
    """When N_src is omitted, the simulator must behave identically to the
    pre-change implementation that walked the source as a dense (m_src,
    n_src) tile."""
    with _Device("950"):
        src = torch.arange(8, dtype=torch.float16)
        dst = torch.zeros(512, dtype=torch.float16)
        pipe = _pipe(MTE3Pipe, {"dst": dst, "src": src})

        pipe.execute(PipeTask("MTE3", "ub_to_l1_nd2nz", {
            "dst": "dst", "src": "src",
            "m_dst": 16, "n_dst": 4, "m_src": 2, "n_src": 4,
        }))

    torch.testing.assert_close(dst[0:4], torch.tensor([0, 1, 2, 3], dtype=torch.float16))
    torch.testing.assert_close(dst[16:20], torch.tensor([4, 5, 6, 7], dtype=torch.float16))


def test_ub_to_l1_nd2nz_rejects_n_src_greater_than_N_src() -> None:
    with _Device("950"):
        pipe = _pipe(MTE3Pipe, {
            "dst": torch.zeros(512, dtype=torch.float16),
            "src": torch.zeros(16, dtype=torch.float16),
        })

        with pytest.raises(ValueError, match="ub_to_l1_nd2nz requires n_src <= N_src"):
            pipe.execute(PipeTask("MTE3", "ub_to_l1_nd2nz", {
                "dst": "dst", "src": "src",
                "m_dst": 16, "n_dst": 4, "m_src": 2, "n_src": 8, "N_src": 4,
            }))


def test_ub_to_l1_nd2nz_strided_source_overflow_caught() -> None:
    """Source storage too small to back up a strided (m_src, n_src) view
    at row stride N_src must error."""
    with _Device("950"):
        pipe = _pipe(MTE3Pipe, {
            "dst": torch.zeros(512, dtype=torch.float16),
            # Only 12 elements, but strided view needs (m_src-1)*N_src + n_src
            # = 1*8 + 4 = 12 -> exactly fits.  Make src 11 to overflow.
            "src": torch.zeros(11, dtype=torch.float16),
        })

        with pytest.raises(RuntimeError, match="ub_to_l1_nd2nz src footprint"):
            pipe.execute(PipeTask("MTE3", "ub_to_l1_nd2nz", {
                "dst": "dst", "src": "src",
                "m_dst": 16, "n_dst": 4, "m_src": 2, "n_src": 4, "N_src": 8,
            }))


def test_gm_to_l1_source_uses_strided_footprint_not_full_rows() -> None:
    with _Device("950"):
        src = torch.arange(104, dtype=torch.float16)
        dst = torch.zeros(256, dtype=torch.float16)
        pipe = _pipe(CubeMTE2Pipe, {"dst": dst, "src": src})

        pipe.execute(PipeTask("MTE2", "gm_to_l1_nd2nz", {
            "dst": "dst", "src": "src", "M": 2, "N": 4, "N_src": 100, "M_dst": 2,
        }))

    torch.testing.assert_close(dst[0:4], src[0:4])
    torch.testing.assert_close(dst[16:20], src[100:104])


def test_gm_to_l1_nd2nz_partial_row_writes_compose_without_clearing_peer_rows() -> None:
    with _Device("950"):
        rows, cols = 64, 128
        stride_m = rows
        c0 = 16
        src_lo = torch.arange(32 * cols, dtype=torch.float16).reshape(32, cols)
        src_hi = (10000 + torch.arange(32 * cols, dtype=torch.float16)).reshape(32, cols)
        dst = torch.full((8 * stride_m * c0,), -7.0, dtype=torch.float16)
        pipe = _pipe(CubeMTE2Pipe, {
            "dst_lo": dst,
            "dst_hi": dst[32 * c0:],
            "src_lo": src_lo.reshape(-1),
            "src_hi": src_hi.reshape(-1),
        })

        pipe.execute(PipeTask("MTE2", "gm_to_l1_nd2nz", {
            "dst": "dst_lo", "src": "src_lo", "M": 32, "N": cols, "N_src": cols, "M_dst": rows,
        }))
        pipe.execute(PipeTask("MTE2", "gm_to_l1_nd2nz", {
            "dst": "dst_hi", "src": "src_hi", "M": 32, "N": cols, "N_src": cols, "M_dst": rows,
        }))

    decoded = decode_nz_to_nd(dst, rows, cols, stride_m, c0)
    expected = torch.cat([src_lo, src_hi], dim=0)
    torch.testing.assert_close(decoded, expected)


def test_gm_to_l1_nd2nz_partial_row_write_uses_local_slice_suffix() -> None:
    with _Device("950"):
        rows, cols = 64, 128
        stride_m = rows
        c0 = 16
        src_lo = torch.arange(32 * cols, dtype=torch.float16).reshape(32, cols)
        src_hi = (10000 + torch.arange(32 * cols, dtype=torch.float16)).reshape(32, cols)
        dst = torch.full((8 * stride_m * c0,), -7.0, dtype=torch.float16)
        pipe = _pipe(CubeMTE2Pipe, {
            "dst@l1:0,0:32,128": dst,
            "dst@l1:32,0:32,128": dst,
            "src_lo": src_lo.reshape(-1),
            "src_hi": src_hi.reshape(-1),
        })

        pipe.execute(PipeTask("MTE2", "gm_to_l1_nd2nz", {
            "dst": "dst@l1:0,0:32,128", "src": "src_lo",
            "M": 32, "N": cols, "N_src": cols, "M_dst": rows,
        }))
        pipe.execute(PipeTask("MTE2", "gm_to_l1_nd2nz", {
            "dst": "dst@l1:32,0:32,128", "src": "src_hi",
            "M": 32, "N": cols, "N_src": cols, "M_dst": rows,
        }))

    decoded = decode_nz_to_nd(dst, rows, cols, stride_m, c0)
    expected = torch.cat([src_lo, src_hi], dim=0)
    torch.testing.assert_close(decoded, expected)


def test_gm_to_l1_rejects_actual_source_overflow() -> None:
    with _Device("950"):
        pipe = _pipe(CubeMTE2Pipe, {
            "dst": torch.zeros(256, dtype=torch.float16),
            "src": torch.zeros(103, dtype=torch.float16),
        })

        with pytest.raises(RuntimeError, match="gm_to_l1_nd2nz src footprint"):
            pipe.execute(PipeTask("MTE2", "gm_to_l1_nd2nz", {
                "dst": "dst", "src": "src", "M": 2, "N": 4, "N_src": 100, "M_dst": 2,
            }))


def test_mmad_rejects_actual_l0c_destination_overflow() -> None:
    with _Device("950"):
        pipe = _pipe(MPipe, {
            "dst": torch.zeros(511, dtype=torch.float32),
            "src_a": torch.zeros(256, dtype=torch.float16),
            "src_b": torch.zeros(512, dtype=torch.float16),
        })

        with pytest.raises(RuntimeError, match="mmad dst footprint"):
            pipe.execute(PipeTask("M", "mmad", {
                "dst": "dst", "src_a": "src_a", "src_b": "src_b",
                "M": 16, "N": 32, "K": 16,
            }))
