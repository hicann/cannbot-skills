"""Focused A2 vec/datamove stub validation."""

import importlib

import pytest

from easyasc import globvars


_A2_TEST = None


def _install_a2():
    global _A2_TEST
    saved_device_type = globvars.device_type
    _A2_TEST = importlib.import_module("easyasc.a2")
    globvars.device_type = "b3"
    return saved_device_type


def _restore_a2(saved_device_type):
    global _A2_TEST
    _A2_TEST = None
    globvars.device_type = saved_device_type

def test_a2_scatter_stub_emits_start_idx() -> None:
    saved_device_type = _install_a2()
    try:
        @_A2_TEST.kernel()
        def scatter_stub_only(dst, src, offset):
            dst_ub = _A2_TEST.Tensor(_A2_TEST.DT.float, [4, 64], _A2_TEST.Position.UB)
            src_ub = _A2_TEST.Tensor(_A2_TEST.DT.float, [4, 64], _A2_TEST.Position.UB)
            off_ub = _A2_TEST.Tensor(_A2_TEST.DT.uint32, [4, 64], _A2_TEST.Position.UB)
            dst_ub <<= dst[:, :]
            src_ub <<= src[:, :]
            off_ub <<= offset[:, :]
            _A2_TEST.scatter(dst_ub, src_ub, off_ub, start_idx=32, repeat=4, src_rep_stride=8)
            return dst

        dst = _A2_TEST.GMTensor(_A2_TEST.DT.float, [4, 64])
        src = _A2_TEST.GMTensor(_A2_TEST.DT.float, [4, 64])
        offset = _A2_TEST.GMTensor(_A2_TEST.DT.uint32, [4, 64])
        scatter_stub_only(dst, src, offset)

        scatter_insts = [inst for inst in scatter_stub_only.instructions if inst.opname == "scatter"]
        assert len(scatter_insts) == 1
        inst = scatter_insts[0]
        assert inst.kwargs.get("start_idx") == 32
        assert inst.kwargs.get("repeat") == 4
        assert inst.kwargs.get("src_rep_stride") == 8
    finally:
        _restore_a2(saved_device_type)


def test_a2_dup_stub_accepts_uint32() -> None:
    saved_device_type = _install_a2()
    try:
        @_A2_TEST.kernel()
        def dup_stub_only(dst):
            dst_ub = _A2_TEST.Tensor(_A2_TEST.DT.uint32, [4, 64], _A2_TEST.Position.UB)
            dst_ub <<= dst[:, :]
            _A2_TEST.dup(dst_ub, 7)
            return dst

        dst = _A2_TEST.GMTensor(_A2_TEST.DT.uint32, [4, 64])
        dup_stub_only(dst)

        dup_insts = [inst for inst in dup_stub_only.instructions if inst.opname == "dup"]
        assert len(dup_insts) == 1
        assert dup_insts[0].kwargs.get("src") == 7
    finally:
        _restore_a2(saved_device_type)


def test_a2_vnot_stub_rejects_int32_tensor() -> None:
    saved_device_type = _install_a2()
    try:
        dst = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        src = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        with pytest.raises(ValueError, match="does not support data type: int"):
            _A2_TEST.vnot(dst, src)
    finally:
        _restore_a2(saved_device_type)


def test_a2_vand_stub_rejects_int32_tensor() -> None:
    saved_device_type = _install_a2()
    try:
        dst = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        src1 = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        src2 = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        with pytest.raises(ValueError, match="does not support data type: int"):
            _A2_TEST.vand(dst, src1, src2)
    finally:
        _restore_a2(saved_device_type)


def test_a2_vnot_vecop_rejects_int32_tensor() -> None:
    saved_device_type = _install_a2()
    try:
        dst = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        src = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        with pytest.raises(TypeError, match="vnot only supports int16_t/uint16_t vec tensors"):
            dst <<= src.vnot()
    finally:
        _restore_a2(saved_device_type)


def test_a2_vand_vecop_rejects_int32_tensor() -> None:
    saved_device_type = _install_a2()
    try:
        dst = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        src1 = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        src2 = _A2_TEST.Tensor(_A2_TEST.DT.int, [4, 64], _A2_TEST.Position.UB)
        with pytest.raises(TypeError, match="vand only supports int16_t/uint16_t vec tensors"):
            dst <<= src1 & src2
    finally:
        _restore_a2(saved_device_type)
