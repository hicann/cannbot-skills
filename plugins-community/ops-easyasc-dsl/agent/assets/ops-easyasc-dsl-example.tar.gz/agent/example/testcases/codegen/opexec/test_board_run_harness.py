"""CPU-only tests for board-run-harness-v1 watchdog and idle-check behaviour.

Does not require an NPU or npu-smi binary.  Fixtures capture realistic
910B3 (card id 7) output shapes, including pipe-delimited process rows
from general ``npu-smi info``.
"""
from pathlib import Path
from unittest import mock

import pytest

from easyasc.torchplugin import (
    _run_bash_with_progress,
    _source_fingerprint,
    _check_board_idle,
    _board_idle_config,
    _parse_aicore_usage,
    _parse_process_table,
    _detect_npu_card_id,
    _NpuExecLock,
)


# ---------------------------------------------------------------------------
# _run_bash_with_progress — timeout + descendant kill
# ---------------------------------------------------------------------------

def test_run_bash_timeout_kills_descendant(tmp_path: Path) -> None:
    """A script that spawns a long-lived child must both be killed on timeout."""
    script = tmp_path / "spawn.sh"
    log_path = tmp_path / "timeout.log"
    script.write_text(
        "#!/bin/bash\n"
        "sleep 60 &\n"
        "CHILD=$!\n"
        "echo child_pid=$CHILD\n"
        "wait $CHILD\n",
        encoding="utf-8",
    )
    script.chmod(0o755)

    import os
    import signal

    with pytest.raises(RuntimeError, match=r"timed out after") as excinfo:
        _run_bash_with_progress(str(script), str(log_path), timeout=1.0)

    msg = str(excinfo.value)
    assert "timed out after" in msg
    assert "Termination signals were sent" in msg
    assert f"bash {script}" in msg
    assert "Log:" in msg
    assert "Last log lines:" in msg
    assert "child_pid=" in msg
    pgid = _run_bash_with_progress._last_pgid
    assert isinstance(pgid, int)

    # The process group should be dead by now.
    try:
        os.killpg(pgid, 0)
        dead = False
    except OSError:
        dead = True
    assert dead, f"Process group {pgid} survived timeout kill"


def test_run_bash_timeout_short_script_succeeds(tmp_path: Path) -> None:
    """A fast script finishing before the timeout must succeed normally."""
    script = tmp_path / "ok.sh"
    log_path = tmp_path / "ok.log"
    script.write_text(
        "#!/bin/bash\necho hello world\nexit 0\n", encoding="utf-8"
    )
    script.chmod(0o755)

    _run_bash_with_progress(str(script), str(log_path), timeout=5.0)
    content = log_path.read_text(encoding="utf-8")
    assert "hello world" in content


def test_run_bash_nonzero_exit_log_tail_preserved(tmp_path: Path) -> None:
    """Existing behaviour: nonzero exit appends log tail to RuntimeError."""
    script = tmp_path / "fail.sh"
    log_path = tmp_path / "fail.log"
    script.write_text(
        "#!/bin/bash\n"
        "echo build-start\n"
        "echo compiler exploded >&2\n"
        "exit 7\n",
        encoding="utf-8",
    )

    with pytest.raises(RuntimeError, match=r"return code 7") as excinfo:
        _run_bash_with_progress(str(script), str(log_path))

    message = str(excinfo.value)
    assert "Last log lines:" in message
    assert "build-start" in message
    assert "compiler exploded" in message


def test_run_bash_no_timeout_does_not_start_session(tmp_path: Path) -> None:
    """Without timeout, the child is NOT in its own session."""
    script = tmp_path / "s.sh"
    log_path = tmp_path / "no_to.log"
    script.write_text("#!/bin/bash\necho ok\nexit 0\n", encoding="utf-8")
    script.chmod(0o755)

    _run_bash_with_progress(str(script), str(log_path), timeout=None)
    assert _run_bash_with_progress._last_pgid is None


# ---------------------------------------------------------------------------
# Completion evidence — only on success
# ---------------------------------------------------------------------------

def test_run_npu_script_prints_completion_on_success(tmp_path: Path, capsys) -> None:
    """A successful NPU run emits exactly one unambiguous completion line."""
    from easyasc.torchplugin import _run_npu_script

    script = tmp_path / "r.sh"
    log_path = tmp_path / "r.sh.log"
    script.write_text("#!/bin/bash\necho done\nexit 0\n", encoding="utf-8")
    script.chmod(0o755)

    import os as _os
    with mock.patch.dict(_os.environ, {"EASYASC_NPU_SAFETY_OVERRIDE": "1"}):
        _run_npu_script(str(script), str(log_path), timeout_s=5.0,
                        idle_samples=3, idle_interval_s=0.1)

    captured = capsys.readouterr()
    assert f"script={script}" in captured.out
    assert f"log={log_path}" in captured.out
    assert "elapsed=" in captured.out
    assert "[easyasc] r.sh completed" in captured.out


def test_run_npu_script_does_not_print_completion_on_failure(tmp_path: Path, capsys) -> None:
    """A failing run must raise RuntimeError and NOT print 'r.sh completed'."""
    from easyasc.torchplugin import _run_npu_script

    script = tmp_path / "fail.sh"
    log_path = tmp_path / "fail.log"
    script.write_text("#!/bin/bash\necho FAIL\nexit 5\n", encoding="utf-8")
    script.chmod(0o755)

    import os as _os
    with pytest.raises(RuntimeError, match=r"return code 5"):
        with mock.patch.dict(_os.environ, {"EASYASC_NPU_SAFETY_OVERRIDE": "1"}):
            _run_npu_script(str(script), str(log_path), timeout_s=5.0,
                            idle_samples=3, idle_interval_s=0.1)

    captured = capsys.readouterr()
    assert "[easyasc] r.sh completed" not in captured.out


def test_run_npu_script_does_not_print_completion_on_timeout(tmp_path: Path, capsys) -> None:
    """A timeout must raise RuntimeError and NOT print 'r.sh completed'."""
    from easyasc.torchplugin import _run_npu_script

    script = tmp_path / "slow.sh"
    log_path = tmp_path / "slow.log"
    script.write_text("#!/bin/bash\nsleep 60\n", encoding="utf-8")
    script.chmod(0o755)

    import os as _os
    with pytest.raises(RuntimeError, match=r"timed out after"):
        with mock.patch.dict(_os.environ, {"EASYASC_NPU_SAFETY_OVERRIDE": "1"}):
            _run_npu_script(str(script), str(log_path), timeout_s=1.0,
                            idle_samples=3, idle_interval_s=0.1)

    captured = capsys.readouterr()
    assert "[easyasc] r.sh completed" not in captured.out


# ---------------------------------------------------------------------------
# Realistic 910B3 npu-smi fixtures (card id 7)
# ---------------------------------------------------------------------------

# usages: key/value format (real 910B3 output)
USAGE_IDLE_KV = "Aicore Usage Rate(%) : 0\n"
USAGE_BUSY_KV = "Aicore Usage Rate(%) : 45\n"

# general info output with pipe-delimited process section (real 910B3 shape)
INFO_PIPE_IDLE = (
    "+------------------------------+---------------+-------------------------------+\n"
    "| NPU   Name         AICore(%) | AICore Memory BW(%) | HBM Memory(MB)          |\n"
    "+------------------------------+---------------+-------------------------------+\n"
    "| 7     910B3         0        | 0            | 60546 / 65536              |\n"
    "+------------------------------+---------------+-------------------------------+\n"
    "\n"
    "No running processes found in NPU 7.\n"
)

INFO_PIPE_BUSY = (
    "+------------------------------+---------------+-------------------------------+\n"
    "| NPU   Name         AICore(%) | AICore Memory BW(%) | HBM Memory(MB)          |\n"
    "+------------------------------+---------------+-------------------------------+\n"
    "| 7     910B3         45       | 12           | 60546 / 65536              |\n"
    "+------------------------------+---------------+-------------------------------+\n"
    "\n"
    "| NPU Chip | Process id | Process name  | Process memory(MB) |\n"
    "| 7 0      | 12345      | my_training   | 1024               |\n"
)

INFO_PIPE_0PCT_WITH_PROC = (
    "+------------------------------+---------------+-------------------------------+\n"
    "| NPU   Name         AICore(%) | AICore Memory BW(%) | HBM Memory(MB)          |\n"
    "+------------------------------+---------------+-------------------------------+\n"
    "| 7     910B3         0        | 0            | 60546 / 65536              |\n"
    "+------------------------------+---------------+-------------------------------+\n"
    "\n"
    "| NPU Chip | Process id | Process name  | Process memory(MB) |\n"
    "| 7 0      | 12345      | my_training   | 1024               |\n"
)

# npu-smi -l output for card detection
LIST_SINGLE_CARD = "Total Count : 1\nNPU ID : 7\n"
LIST_MULTI_CARD = "Total Count : 2\nNPU ID : 0\nNPU ID : 1\n"
LIST_NO_CARD = "Total Count : 0\n"


def _make_mock_check_output(usages_output, info_output):
    """Return a mock for subprocess.check_output dispatching by command."""

    def fake_co(cmd, **kwargs):
        cmd_str = " ".join(cmd) if cmd else ""
        if "usages" in cmd_str:
            return usages_output.encode()
        if "info" in cmd_str and "-l" not in cmd_str:
            return info_output.encode()
        if "-l" in cmd_str:
            return LIST_SINGLE_CARD.encode()
        raise RuntimeError(f"unexpected mock subprocess call: {cmd_str}")

    return fake_co


# ---------------------------------------------------------------------------
# AICore parser — key/value and table formats
# ---------------------------------------------------------------------------

def test_parse_aicore_usage_keyvalue_format() -> None:
    """910B3 key/value: 'Aicore Usage Rate(%) : 0'."""
    assert _parse_aicore_usage("Aicore Usage Rate(%) : 0\n") == 0.0
    assert _parse_aicore_usage("Aicore Usage Rate(%) : 45\n") == 45.0
    assert _parse_aicore_usage("Aicore Usage Rate(%) : 0.5\n") == 0.5


def test_parse_aicore_usage_table_format() -> None:
    """Table header: '| AICore (%) …', data row with value."""
    out = (
        "+----+-----------------+----------------------------+\n"
        "| NPU  Name           |  AICore (%)     |  AICore Memory BW (%)      |\n"
        "+----+-----------------+----------------------------+\n"
        "|  0    910B3          |  12             |  5                         |\n"
        "+----+-----------------+----------------------------+\n"
    )
    assert _parse_aicore_usage(out) == 12.0


def test_parse_aicore_usage_unparseable_returns_none() -> None:
    assert _parse_aicore_usage("garbage") is None
    assert _parse_aicore_usage("") is None


# ---------------------------------------------------------------------------
# Process table parser — pipe-delimited and plain-space formats
# ---------------------------------------------------------------------------

def test_parse_process_table_no_processes_explicit() -> None:
    """Explicit 'No running processes found in NPU 7' → False."""
    out = "No running processes found in NPU 7.\n"
    assert _parse_process_table(out, "7") is False


def test_parse_process_table_pipe_delimited_busy() -> None:
    """Pipe-delimited process row for our card → True."""
    out = (
        "| NPU Chip | Process id | Process name  | Process memory(MB) |\n"
        "| 7 0      | 12345      | my_training   | 1024               |\n"
    )
    assert _parse_process_table(out, "7") is True


def test_parse_process_table_pipe_delimited_idle() -> None:
    """Pipe-delimited section with 'No running processes' for our card → False."""
    out = (
        "| NPU Chip | Process id | Process name  | Process memory(MB) |\n"
        "No running processes found in NPU 7.\n"
    )
    assert _parse_process_table(out, "7") is False


def test_parse_process_table_pipe_delimited_different_card() -> None:
    """Processes listed for card 0, none for card 7 → unknown (None)."""
    out = (
        "| NPU Chip | Process id | Process name  | Process memory(MB) |\n"
        "| 0 0      | 12345      | my_training   | 1024               |\n"
    )
    assert _parse_process_table(out, "7") is None


def test_parse_process_table_plain_space_busy() -> None:
    """Plain-space: '<npu> <pid> <name>' → True."""
    out = (
        "Process Information:\n"
        "NPU   Process ID   Process Name\n"
        "7     12345        my_training\n"
    )
    assert _parse_process_table(out, "7") is True


def test_parse_process_table_no_section_at_all() -> None:
    """No process section → None (ambiguous)."""
    out = "some unrelated output\n"
    assert _parse_process_table(out, "7") is None


def test_check_board_idle_fails_closed_on_unknown_process_state(monkeypatch) -> None:
    """When process state cannot be determined, _check_board_idle must raise."""
    # Info output that has a process section for a different card but
    # nothing about our card → _parse_process_table returns None.
    info_ambig = (
        "| NPU Chip | Process id | Process name  | Process memory(MB) |\n"
        "| 0 0      | 12345      | my_training   | 1024               |\n"
    )
    monkeypatch.setattr(
        "subprocess.check_output",
        _make_mock_check_output(USAGE_IDLE_KV, info_ambig),
    )
    with pytest.raises(RuntimeError, match="Could not determine process state"):
        _check_board_idle(samples=1, interval_s=0.01, card_id="7")


# ---------------------------------------------------------------------------
# Card-id detection
# ---------------------------------------------------------------------------

def test_detect_card_id_from_env(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_CARD_ID", "5")
    assert _detect_npu_card_id() == "5"


def test_detect_card_id_rejects_non_integer(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_CARD_ID", "abc")
    with pytest.raises(ValueError, match="non-negative integer"):
        _detect_npu_card_id()


def test_detect_card_id_rejects_negative(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_CARD_ID", "-1")
    with pytest.raises(ValueError, match="non-negative integer"):
        _detect_npu_card_id()


def test_detect_card_id_single_card_auto(monkeypatch) -> None:
    monkeypatch.delenv("EASYASC_NPU_CARD_ID", raising=False)
    monkeypatch.setattr(
        "subprocess.check_output",
        mock.Mock(return_value=LIST_SINGLE_CARD.encode()),
    )
    assert _detect_npu_card_id() == "7"


def test_detect_card_id_multi_card_fails(monkeypatch) -> None:
    monkeypatch.delenv("EASYASC_NPU_CARD_ID", raising=False)
    monkeypatch.setattr(
        "subprocess.check_output",
        mock.Mock(return_value=LIST_MULTI_CARD.encode()),
    )
    with pytest.raises(RuntimeError, match="2 NPU cards detected"):
        _detect_npu_card_id()


def test_detect_card_id_no_card_fails(monkeypatch) -> None:
    monkeypatch.delenv("EASYASC_NPU_CARD_ID", raising=False)
    monkeypatch.setattr(
        "subprocess.check_output",
        mock.Mock(return_value=LIST_NO_CARD.encode()),
    )
    with pytest.raises(RuntimeError, match="No NPU cards found"):
        _detect_npu_card_id()


def test_detect_card_id_missing_binary_fails(monkeypatch) -> None:
    monkeypatch.delenv("EASYASC_NPU_CARD_ID", raising=False)
    monkeypatch.setattr(
        "subprocess.check_output",
        mock.Mock(side_effect=FileNotFoundError("no npu-smi")),
    )
    with pytest.raises(RuntimeError, match="npu-smi not found"):
        _detect_npu_card_id()


# ---------------------------------------------------------------------------
# Board-idle precondition — with realistic 910B3 fixtures
# ---------------------------------------------------------------------------

def test_check_board_idle_accepts_consecutive_idle(monkeypatch) -> None:
    """Multiple consecutive idle samples pass (key/value + pipe-delimited info)."""
    monkeypatch.setattr(
        "subprocess.check_output",
        _make_mock_check_output(USAGE_IDLE_KV, INFO_PIPE_IDLE),
    )
    assert _check_board_idle(samples=3, interval_s=0.01, card_id="7") is True


def test_check_board_idle_rejects_sustained_utilization(monkeypatch) -> None:
    """Any non-zero AICore utilization must fail."""
    monkeypatch.setattr(
        "subprocess.check_output",
        _make_mock_check_output(USAGE_BUSY_KV, INFO_PIPE_IDLE),
    )

    with pytest.raises(RuntimeError, match="not idle"):
        _check_board_idle(samples=2, interval_s=0.01, card_id="7")


def test_check_board_idle_rejects_0pct_with_process(monkeypatch) -> None:
    """0% utilization with a process for our card must fail."""
    monkeypatch.setattr(
        "subprocess.check_output",
        _make_mock_check_output(USAGE_IDLE_KV, INFO_PIPE_0PCT_WITH_PROC),
    )

    with pytest.raises(RuntimeError, match="not idle"):
        _check_board_idle(samples=1, interval_s=0.01, card_id="7")


def test_check_board_idle_fails_closed_on_missing_binary(monkeypatch) -> None:
    """If npu-smi is not found, fail closed (not silently pass)."""
    monkeypatch.setattr(
        "subprocess.check_output",
        mock.Mock(side_effect=FileNotFoundError("no npu-smi")),
    )
    with pytest.raises(RuntimeError, match="npu-smi not found"):
        _check_board_idle(samples=1, interval_s=0.01, card_id="7")


def test_check_board_idle_fails_closed_on_parse_failure(monkeypatch) -> None:
    """Unparseable output must fail, not silently pass."""
    monkeypatch.setattr(
        "subprocess.check_output",
        mock.Mock(return_value=b"garbage output\nno aicore line\n"),
    )
    with pytest.raises(RuntimeError, match="Could not parse AICore"):
        _check_board_idle(samples=1, interval_s=0.01, card_id="7")


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------

def test_board_idle_config_defaults() -> None:
    timeout_s, samples, interval_s, override = _board_idle_config()
    assert timeout_s == 600.0
    assert samples == 3
    assert interval_s == 1.0
    assert override is False


def test_board_idle_config_override_from_env(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_SAFETY_OVERRIDE", "1")
    _, _, _, override = _board_idle_config()
    assert override is True


def test_board_idle_config_rejects_zero_timeout(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_RUN_TIMEOUT", "0")
    with pytest.raises(ValueError, match="must be a finite positive"):
        _board_idle_config()


def test_board_idle_config_rejects_negative_timeout(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_RUN_TIMEOUT", "-5")
    with pytest.raises(ValueError, match="must be a finite positive"):
        _board_idle_config()


def test_board_idle_config_rejects_nan_timeout(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_RUN_TIMEOUT", "nan")
    with pytest.raises(ValueError, match="must be a finite positive"):
        _board_idle_config()


def test_board_idle_config_rejects_inf_interval(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_IDLE_INTERVAL", "inf")
    with pytest.raises(ValueError, match="must be a finite non-negative"):
        _board_idle_config()


def test_board_idle_config_rejects_zero_samples(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_IDLE_SAMPLES", "0")
    with pytest.raises(ValueError, match="must be >= 1"):
        _board_idle_config()


def test_board_idle_config_rejects_negative_interval(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_IDLE_INTERVAL", "-0.1")
    with pytest.raises(ValueError, match="must be a finite non-negative"):
        _board_idle_config()


def test_board_idle_config_allows_zero_interval(monkeypatch) -> None:
    monkeypatch.setenv("EASYASC_NPU_IDLE_INTERVAL", "0")
    timeout_s, samples, interval_s, override = _board_idle_config()
    assert interval_s == 0.0


# ---------------------------------------------------------------------------
# Escape hatch
# ---------------------------------------------------------------------------

def test_run_npu_script_skips_idle_with_override(tmp_path, capsys) -> None:
    """When override is set, board-idle check is skipped with a message."""
    from easyasc.torchplugin import _run_npu_script
    import os as _os

    script = tmp_path / "r.sh"
    log_path = tmp_path / "r.sh.log"
    script.write_text("#!/bin/bash\necho ok\nexit 0\n", encoding="utf-8")
    script.chmod(0o755)

    with mock.patch.dict(_os.environ, {"EASYASC_NPU_SAFETY_OVERRIDE": "1"}):
        _run_npu_script(str(script), str(log_path), timeout_s=5.0,
                        idle_samples=3, idle_interval_s=0.1)

    captured = capsys.readouterr()
    assert "skipping board-idle check" in captured.out


# ---------------------------------------------------------------------------
# _NpuExecLock — fail-closed on real Linux
# ---------------------------------------------------------------------------

def test_npu_exec_lock_degrade_import_error() -> None:
    """When fcntl is not importable (non-Unix), lock degrades silently."""
    import builtins
    _orig_import = builtins.__import__

    def _fake_import(name, *args, **kwargs):
        if name == "fcntl":
            raise ImportError("no fcntl")
        return _orig_import(name, *args, **kwargs)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(builtins, "__import__", _fake_import)
    try:
        lock = _NpuExecLock()
        with lock:
            assert lock._fd is None
    finally:
        monkeypatch.undo()


def test_npu_exec_lock_fails_closed_on_lockfile_error(monkeypatch, tmp_path) -> None:
    """When fcntl is available but lockfile can't be opened, fail closed."""
    bad_path = str(tmp_path / "nonexistent_dir" / "lock")
    monkeypatch.setenv("EASYASC_NPU_LOCK", bad_path)

    with pytest.raises(RuntimeError, match="Failed to open NPU lockfile"):
        with _NpuExecLock():
            pass


def test_npu_exec_lock_allow_degrade_env(monkeypatch, tmp_path) -> None:
    """EASYASC_NPU_LOCK_ALLOW_DEGRADE=1 reverts to old best-effort behaviour."""
    bad_path = str(tmp_path / "nonexistent_dir" / "lock")
    monkeypatch.setenv("EASYASC_NPU_LOCK", bad_path)
    monkeypatch.setenv("EASYASC_NPU_LOCK_ALLOW_DEGRADE", "1")

    lock = _NpuExecLock()
    with lock:
        assert lock._fd is None


# ---------------------------------------------------------------------------
# _source_fingerprint
# ---------------------------------------------------------------------------

def test_source_fingerprint_stable_identical_sources(tmp_path: Path) -> None:
    """Same source content yields the same fingerprint."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "kernel.cpp").write_text("int main() {}", encoding="utf-8")

    h1 = _source_fingerprint(str(src), [], "test")
    h2 = _source_fingerprint(str(src), [], "test")
    assert h1 == h2


def test_source_fingerprint_changes_with_content(tmp_path: Path) -> None:
    """Different source content yields a different fingerprint."""
    src = tmp_path / "src"
    src.mkdir()
    f = src / "kernel.cpp"
    f.write_text("int main() {}", encoding="utf-8")
    h1 = _source_fingerprint(str(src), [], "test")

    f.write_text("int main() { return 0; }", encoding="utf-8")
    h2 = _source_fingerprint(str(src), [], "test")
    assert h1 != h2


def test_source_fingerprint_changes_with_file_set(tmp_path: Path) -> None:
    """Adding a source file changes the fingerprint."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "kernel.cpp").write_text("int main() {}", encoding="utf-8")
    h1 = _source_fingerprint(str(src), [], "test")

    (src / "kernel2.cpp").write_text("int other() {}", encoding="utf-8")
    h2 = _source_fingerprint(str(src), [], "test")
    assert h1 != h2


def test_source_fingerprint_ignores_build_artifacts(tmp_path: Path) -> None:
    """Build output directories and artifacts are excluded from the hash."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "kernel.cpp").write_text("int main() {}", encoding="utf-8")
    h1 = _source_fingerprint(str(src), [], "test")

    build = src / "build_out"
    build.mkdir()
    (build / "kernel.o").write_text("binary junk here" * 100, encoding="utf-8")
    (build / "CMakeFiles").mkdir()
    (build / "CMakeFiles" / "stuff.cmake").write_text("cmake config" * 50, encoding="utf-8")

    (src / "input").mkdir()
    (src / "input" / "data.bin").write_text("binary data" * 200, encoding="utf-8")
    (src / "output").mkdir()
    (src / "output" / "output.bin").write_text("output data" * 200, encoding="utf-8")
    (src / "traces").mkdir()
    (src / "traces" / "trace.json").write_text("trace data" * 200, encoding="utf-8")

    h2 = _source_fingerprint(str(src), [], "test")
    assert h1 == h2


def test_source_fingerprint_tag_affects_hash(tmp_path: Path) -> None:
    """Different tags yield different fingerprints."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "kernel.cpp").write_text("int main() {}", encoding="utf-8")

    h1 = _source_fingerprint(str(src), [], "debug")
    h2 = _source_fingerprint(str(src), [], "profile")
    assert h1 != h2


def test_source_fingerprint_handles_missing_aux_dir(tmp_path: Path) -> None:
    """Missing aux_dirs are silently ignored."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "kernel.cpp").write_text("int main() {}", encoding="utf-8")

    h = _source_fingerprint(str(src), ["/nonexistent/path/12345"], "test")
    assert len(h) == 64  # SHA-256 hex digest
