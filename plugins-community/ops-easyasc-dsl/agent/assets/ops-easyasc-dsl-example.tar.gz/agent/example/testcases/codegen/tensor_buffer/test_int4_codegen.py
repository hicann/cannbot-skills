import pytest

from easyasc import globvars
from easyasc.a2 import *
from easyasc.parser.asc import translate_split


def _restore_device(saved_device: str) -> None:
    globvars.device_type = saved_device


@kernel()
def _int4_splitk_codegen(inp: GMTensor):
    l1a = Tensor(DT.int, [16, 16], Position.L1, name="l1a_carrier")
    l1b = Tensor(DT.int, [16, 16], Position.L1, name="l1b_carrier")
    l0c = Tensor(DT.int, [16, 16], Position.L0C, name="l0c")
    split_k = Var(128, name="split_k")
    logical_k = Var(130, name="logical_k")
    matmul(l0c, l1a.reinterpret(DT.int4), l1b.reinterpret(DT.int4), splitk=split_k, m=16, n=16, k=logical_k)
    kernel_dump_tensor(l0c, 11, 256)
    return inp


@kernel()
def _int4_low_level_codegen(inp: GMTensor):
    l1a = Tensor(DT.int, [16, 4], Position.L1, name="low_l1a")
    l1b = Tensor(DT.int, [16, 4], Position.L1, name="low_l1b")
    l0a = Tensor(DT.int, [16, 4], Position.L0A, name="low_l0a")
    l0b = Tensor(DT.int, [16, 4], Position.L0B, name="low_l0b")
    l0c = Tensor(DT.int, [16, 16], Position.L0C, name="low_l0c")
    l0a <<= l1a
    l0b <<= l1b
    a4 = l0a.reinterpret(DT.int4, name="low_a4")
    b4 = l0b.reinterpret(DT.int4, name="low_b4")
    mmad(l0c, a4, b4, M=16, N=16, K=17, is_init=True)
    kernel_dump_tensor(l0c, 13, 256)
    return inp


@kernel()
def _plain_int_matmul(inp: GMTensor):
    l1a = Tensor(DT.int, [16, 16], Position.L1)
    l1b = Tensor(DT.int, [16, 16], Position.L1)
    l0c = Tensor(DT.int, [16, 16], Position.L0C)
    matmul(l0c, l1a, l1b, m=16, n=16, k=16)
    return inp


@kernel()
def _plain_int_mmad(inp: GMTensor):
    l0a = Tensor(DT.int, [16, 16], Position.L0A)
    l0b = Tensor(DT.int, [16, 16], Position.L0B)
    l0c = Tensor(DT.int, [16, 16], Position.L0C)
    mmad(l0c, l0a, l0b, M=16, N=16, K=16)
    return inp


@kernel()
def _unconsumed_int4_view(inp: GMTensor):
    l1 = Tensor(DT.int, [16, 16], Position.L1)
    l1.reinterpret(DT.int4, name="unused_l1_int4")
    return inp


def test_int4_dtype_and_allocation_rules() -> None:
    assert DT.int4.C0 == 64
    with pytest.raises(ValueError, match="addressable byte size"):
        _ = DT.int4.size
    with pytest.raises(ValueError, match="Tensor does not support DT.int4"):
        Tensor(DT.int4, [16, 16], Position.L1)
    with pytest.raises(ValueError, match="DBuff does not support DT.int4"):
        DBuff(DT.int4, [16, 16], Position.L1)
    with pytest.raises(ValueError, match="TBuff does not support DT.int4"):
        TBuff(DT.int4, [16, 16], Position.L1)
    with pytest.raises(ValueError, match="QBuff does not support DT.int4"):
        QBuff(DT.int4, [16, 16], Position.L1)
    with pytest.raises(ValueError, match="GMTensor does not support DT.int4"):
        GMTensor(DT.int4, [16, 128])
    with pytest.raises(ValueError, match="split_workspace does not support DT.int4"):
        split_workspace(DT.int4, [16, 16])


def test_int4_reinterpret_shape_and_transpose_marker() -> None:
    saved = globvars.device_type
    globvars.device_type = "b3"
    try:
        l1 = Tensor(DT.int, [16, 16], Position.L1)
        view = l1.reinterpret(DT.int4)
        assert view.dtype is DT.int4
        assert view.shape == [16, 128]
        assert view.span == [16, 128]
        assert view._int4_carrier is l1

        transposed_view = l1.T.reinterpret(DT.int4)
        assert transposed_view.shape == [128, 16]
        assert transposed_view.span == [128, 16]
        assert transposed_view._int4_carrier.is_transpose
    finally:
        _restore_device(saved)


def test_int4_reinterpret_is_a2_only() -> None:
    saved = globvars.device_type
    globvars.device_type = "950"
    try:
        l1 = Tensor(DT.int, [16, 16], Position.L1)
        with pytest.raises(ValueError, match="only supported on a2"):
            l1.reinterpret(DT.int4)
    finally:
        _restore_device(saved)


def test_int4_splitk_codegen_uses_l0_marker_only() -> None:
    saved = globvars.device_type
    globvars.device_type = "b3"
    try:
        inp = GMTensor(DT.int, [1, 1], name="inp")
        _int4_splitk_codegen(inp)
        cube_code, vec_code = translate_split(_int4_splitk_codegen.instructions, "int4_splitk_codegen")
    finally:
        _restore_device(saved)

    assert "LocalTensor<int4b_t>" in cube_code
    assert "ReinterpretCast<int4b_t>" in cube_code
    assert "l1a_carrier.ReinterpretCast<int4b_t>" not in cube_code
    assert "l1b_carrier.ReinterpretCast<int4b_t>" not in cube_code
    assert "GlobalTensor<int4b_t>" not in cube_code + vec_code
    assert "ACL_INT4" not in cube_code + vec_code
    assert "ge::DT_INT4" not in cube_code + vec_code
    assert "CeilDiv" in cube_code
    assert "MMAD(" in cube_code
    assert "int4b_t" not in vec_code


def test_low_level_int4_mmad_keeps_explicit_k_unpadded() -> None:
    saved = globvars.device_type
    globvars.device_type = "b3"
    try:
        inp = GMTensor(DT.int, [1, 1], name="inp")
        _int4_low_level_codegen(inp)
        cube_code, vec_code = translate_split(_int4_low_level_codegen.instructions, "int4_low_level_codegen")
    finally:
        _restore_device(saved)

    assert "LocalTensor<int4b_t> low_a4 = low_l0a.ReinterpretCast<int4b_t>();" in cube_code
    assert "LocalTensor<int4b_t> low_b4 = low_l0b.ReinterpretCast<int4b_t>();" in cube_code
    assert "MMAD(low_l0c, low_a4, low_b4, 16, 17, 16" in cube_code
    assert "MMAD(low_l0c, low_a4, low_b4, 16, 24, 16" not in cube_code
    assert "int4b_t" not in vec_code


def test_plain_int_cube_matmul_is_rejected() -> None:
    inp = GMTensor(DT.int, [1, 1], name="inp")
    with pytest.raises(TypeError, match="DT.int cube matmul is unsupported"):
        _plain_int_matmul(inp)
    with pytest.raises(TypeError, match="DT.int cube matmul is unsupported"):
        _plain_int_mmad(inp)


def test_int4_matmul_requires_both_inputs_and_aligned_splitk() -> None:
    saved = globvars.device_type
    globvars.device_type = "b3"
    try:
        inp = GMTensor(DT.int, [1, 1], name="inp")

        @kernel()
        def one_sided_marker(x: GMTensor):
            l1a = Tensor(DT.int, [16, 16], Position.L1)
            l1b = Tensor(DT.int, [16, 16], Position.L1)
            l0c = Tensor(DT.int, [16, 16], Position.L0C)
            matmul(l0c, l1a.reinterpret(DT.int4), l1b, m=16, n=16, k=128)
            return x

        @kernel()
        def bad_splitk(x: GMTensor):
            l1a = Tensor(DT.int, [16, 16], Position.L1)
            l1b = Tensor(DT.int, [16, 16], Position.L1)
            l0c = Tensor(DT.int, [16, 16], Position.L0C)
            matmul(l0c, l1a.reinterpret(DT.int4), l1b.reinterpret(DT.int4), splitk=7, m=16, n=16, k=128)
            return x

        with pytest.raises(TypeError, match="requires both l1a and l1b"):
            one_sided_marker(inp)
        with pytest.raises(ValueError, match="splitk must be a multiple of 8"):
            bad_splitk(inp)
    finally:
        _restore_device(saved)


def test_unconsumed_int4_view_is_rejected_during_codegen() -> None:
    saved = globvars.device_type
    globvars.device_type = "b3"
    try:
        inp = GMTensor(DT.int, [1, 1], name="inp")
        _unconsumed_int4_view(inp)
        with pytest.raises(ValueError, match="must be consumed by matmul/mmad"):
            translate_split(_unconsumed_int4_view.instructions, "unconsumed_int4_view")
    finally:
        _restore_device(saved)
