import pytest
import numpy as np
import torch

from easyasc.a5 import (
    HIF8_MAX_NEGATIVE_NORMAL,
    HIF8_MAX_POSITIVE_NORMAL,
    HIF8_NAN,
    HIF8_NEGATIVE_INF,
    HIF8_OVERFLOW_THRESHOLD,
    HIF8_POSITIVE_INF,
    fp16_to_hif8,
    fp32_to_hif8,
    hif8_to_fp32,
)
from easyasc.utils.roundmode import RoundMode


def _half_from_bits(bits) -> torch.Tensor:
    arr = np.asarray(bits, dtype=np.uint16).view(np.float16).copy()
    return torch.from_numpy(arr)


def test_hif8_decode_paper_table_values() -> None:
    codes = torch.tensor(
        [
            0x00,
            0x80,
            0x6F,
            0xEF,
            0x6E,
            0x7E,
            0x07,
            0x01,
            0x08,
            0x0F,
            0x10,
            0x18,
            0x81,
        ],
        dtype=torch.uint8,
    )
    out = hif8_to_fp32(codes)

    assert out[0].item() == 0.0
    assert torch.isnan(out[1])
    assert out[2].item() == float("inf")
    assert out[3].item() == float("-inf")
    assert out[4].item() == 2.0 ** 15
    assert out[5].item() == 2.0 ** -15
    assert out[6].item() == 2.0 ** -16
    assert out[7].item() == 2.0 ** -22
    assert out[8].item() == 1.0
    assert out[9].item() == 1.875
    assert out[10].item() == 2.0
    assert out[11].item() == 0.5
    assert out[12].item() == -(2.0 ** -22)


def test_fp32_to_hif8_rounds_ties_away_from_zero() -> None:
    values = torch.tensor(
        [
            0.0,
            -0.0,
            2.0 ** -24,
            2.0 ** -23,
            1.0625,
            -1.0625,
        ],
        dtype=torch.float32,
    )

    encoded = fp32_to_hif8(values)

    torch.testing.assert_close(
        encoded,
        torch.tensor([0x00, 0x00, 0x00, 0x01, 0x09, 0x89], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )


def test_fp32_to_hif8_specials_and_options() -> None:
    values = torch.tensor(
        [float("nan"), float("inf"), float("-inf"), HIF8_OVERFLOW_THRESHOLD],
        dtype=torch.float32,
    )

    encoded = fp32_to_hif8(values)
    torch.testing.assert_close(
        encoded,
        torch.tensor([HIF8_NAN, HIF8_POSITIVE_INF, HIF8_NEGATIVE_INF, HIF8_POSITIVE_INF], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )

    saturated = fp32_to_hif8(values, saturate=True, nan_to_zero=True)
    torch.testing.assert_close(
        saturated,
        torch.tensor(
            [0x00, HIF8_MAX_POSITIVE_NORMAL, HIF8_MAX_NEGATIVE_NORMAL, HIF8_MAX_POSITIVE_NORMAL],
            dtype=torch.uint8,
        ),
        rtol=0,
        atol=0,
    )


def test_fp32_to_hif8_hybrid_uses_ssr_outside_small_exponents() -> None:
    values = torch.tensor(
        [
            1.0,
            8.0,
            16.0,
            20.0,
            2.0 ** -22,
            2.0 ** -16,
            2.0 ** -15,
            32768.0,
            -16.0,
        ],
        dtype=torch.float32,
    )

    encoded = fp32_to_hif8(values, round_mode=RoundMode.HYBRID)

    torch.testing.assert_close(
        encoded,
        torch.tensor([0x08, 0x28, 0x41, 0x42, 0x02, 0x7E, 0x7F, 0x6F, 0xC1], dtype=torch.uint8),
        rtol=0,
        atol=0,
    )


def test_fp32_to_hif8_rejects_unknown_round_mode() -> None:
    with pytest.raises(ValueError, match="supports round_mode CAST_ROUND or CAST_HYBRID"):
        fp32_to_hif8(torch.tensor([1.0], dtype=torch.float32), round_mode=RoundMode.FLOOR)


def test_fp16_to_hif8_round_matches_fp32_for_all_half_bit_patterns() -> None:
    bits = np.arange(65536, dtype=np.uint16)
    values = torch.from_numpy(bits.view(np.float16).copy())

    encoded = fp16_to_hif8(values)
    expected = fp32_to_hif8(values.to(torch.float32))

    torch.testing.assert_close(encoded, expected, rtol=0, atol=0)


def test_fp16_to_hif8_hybrid_matches_cannsim_boundary_cases() -> None:
    values = _half_from_bits(
        [
            0x0002,
            0x0005,
            0x017D,
            0x0180,
            0x0373,
            0x0380,
            0x4C00,
            0xCC00,
            0x817D,
            0x8373,
            0x7C00,
            0xFC00,
            0x7E00,
        ]
    )

    encoded = fp16_to_hif8(values, round_mode=RoundMode.HYBRID)

    torch.testing.assert_close(
        encoded,
        torch.tensor(
            [0x01, 0x01, 0x07, 0x7E, 0x7F, 0x7C, 0x40, 0xC0, 0x87, 0xFF, 0x6F, 0xEF, 0x80],
            dtype=torch.uint8,
        ),
        rtol=0,
        atol=0,
    )


def test_hif8_roundtrip_all_bit_patterns() -> None:
    codes = torch.arange(256, dtype=torch.uint8)
    values = hif8_to_fp32(codes)
    encoded = fp32_to_hif8(values)

    torch.testing.assert_close(encoded, codes, rtol=0, atol=0)


def test_hif8_decode_rejects_out_of_range_integer_codes() -> None:
    with pytest.raises(ValueError, match=r"codes must be in \[0, 255\]"):
        hif8_to_fp32(torch.tensor([256], dtype=torch.int32))
