import pytest
import torch

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


@kernel()
def _gm_reshape_copy_kernel(src: GMTensor, dst: GMTensor):
    reshaped = src.reshape([6, 8])
    ub = Tensor(DT.float, [6, 8], Position.UB, name="ub")
    ub <<= reshaped
    dst <<= ub
    return dst


@kernel()
def _gm_flatten_copy_kernel(src: GMTensor, dst: GMTensor):
    flattened = src.flatten(0, 1)
    ub = Tensor(DT.float, [6, 8], Position.UB, name="ub_flat")
    ub <<= flattened
    dst <<= ub
    return dst


def test_gmtensor_reshape_returns_alias_without_mutating_source() -> None:
    src = GMTensor(DT.float, [2, 3, 4], name="src")

    reshaped = src.reshape([6, 4])

    assert src.shape == [2, 3, 4]
    assert src.span == [2, 3, 4]
    assert reshaped.shape == [6, 4]
    assert reshaped.span == [6, 4]
    assert reshaped.offset == [0, 0]
    assert reshaped.step == [1, 1]
    assert reshaped.slice_mask == [False, False]
    assert reshaped.dtype == src.dtype
    assert reshaped is not src


def test_gmtensor_reshape_rejects_non_plain_view() -> None:
    src = GMTensor(DT.float, [2, 3, 4], name="src")
    sliced = src[0, 1:3, :]

    with pytest.raises(ValueError, match="plain_view"):
        sliced.reshape([2, 4])


def test_gmtensor_flatten_is_reshape_syntax_sugar() -> None:
    src = GMTensor(DT.float, [2, 3, 4], name="src")

    flattened = src.flatten(0, 1)

    assert src.shape == [2, 3, 4]
    assert flattened.shape == [6, 4]
    assert flattened.span == [6, 4]
    assert flattened.offset == [0, 0]
    assert flattened.step == [1, 1]
    assert flattened.slice_mask == [False, False]
    assert flattened is not src


def test_gmtensor_flatten_supports_negative_dims() -> None:
    src = GMTensor(DT.float, [2, 3, 4], name="src")

    flattened = src.flatten(-2, -1)

    assert flattened.shape == [2, 12]
    assert flattened.span == [2, 12]


def test_gmtensor_flatten_rejects_invalid_dim_range() -> None:
    src = GMTensor(DT.float, [2, 3, 4], name="src")

    with pytest.raises(ValueError, match="start_dim must be <= end_dim"):
        src.flatten(2, 1)

    with pytest.raises(ValueError, match="out of range"):
        src.flatten(0, 3)


def test_gmtensor_reshape_rejects_static_numel_mismatch() -> None:
    src = GMTensor(DT.float, [2, 3, 4], name="src")

    with pytest.raises(ValueError, match="same numel"):
        src.reshape([5, 5])


def test_gmtensor_reshape_translate_split_smoke() -> None:
    src = GMTensor(DT.float, [2, 3, 8], name="src")
    dst = GMTensor(DT.float, [6, 8], name="dst")

    _gm_reshape_copy_kernel(src, dst)
    cube_code, vec_code = translate_split(_gm_reshape_copy_kernel.instructions, "gm_reshape_copy")

    assert isinstance(cube_code, str)
    assert "GlobalTensor<float>" in vec_code
    assert "GM2UBPAD" in vec_code
    assert "UB2GMPAD" in vec_code


