import pytest

from easyasc import globvars
from easyasc.a5 import *
from easyasc.parser.asc import translate_split


def _with_device(device_type: str):
    saved = globvars.device_type
    globvars.device_type = device_type
    return saved


def test_mmad_unit_flag_codegen_covers_bias_and_accumulate() -> None:
    saved = _with_device("950")
    try:
        @kernel(mode="cube")
        def stub_only(out: GMTensor, runtime_flag: Var):
            a = Tensor(DT.half, [16, 16], Position.L0A, name="unit_a")
            b = Tensor(DT.half, [16, 16], Position.L0B, name="unit_b")
            c = Tensor(DT.float, [16, 16], Position.L0C, name="unit_c")
            bias = Tensor(DT.float, [1, 16], Position.BT, name="unit_bias")
            mmad(c, a, b, M=16, N=16, K=16,
                 is_init=True, bias=bias, unit_flag=2)
            mmad(c, a, b, M=16, N=16, K=16,
                 is_init=False, unit_flag=runtime_flag)
            return out

        out = GMTensor(DT.float, [1], name="out")
        stub_only(out, Var(3, name="runtime_flag"))
        cube_code, vec_code = translate_split(
            stub_only.instructions, "mmad_unit_flag",
        )
        assert "MMAD_BIAS(unit_c, unit_a, unit_b, unit_bias, 16, 16, 16, 2);" in cube_code
        assert "MMAD(unit_c, unit_a, unit_b, 16, 16, 16, false, runtime_flag);" in cube_code
        assert "MMAD(" not in vec_code
    finally:
        globvars.device_type = saved


def test_mmad_default_codegen_stays_unextended() -> None:
    saved = _with_device("950")
    try:
        @kernel(mode="cube")
        def stub_only(out: GMTensor):
            a = Tensor(DT.half, [16, 16], Position.L0A, name="default_a")
            b = Tensor(DT.half, [16, 16], Position.L0B, name="default_b")
            c = Tensor(DT.float, [16, 16], Position.L0C, name="default_c")
            mmad(c, a, b, M=16, N=16, K=16, is_init=True)
            return out

        stub_only(GMTensor(DT.float, [1], name="out"))
        cube_code, _ = translate_split(
            stub_only.instructions, "mmad_default_unit_flag",
        )
        assert "MMAD(default_c, default_a, default_b, 16, 16, 16, true);" in cube_code
    finally:
        globvars.device_type = saved


@pytest.mark.parametrize("unit_flag", [False, 1, 7])
def test_mmad_rejects_invalid_unit_flag(unit_flag) -> None:
    saved = _with_device("950")
    try:
        a = Tensor(DT.half, [16, 16], Position.L0A)
        b = Tensor(DT.half, [16, 16], Position.L0B)
        c = Tensor(DT.float, [16, 16], Position.L0C)
        with pytest.raises((TypeError, ValueError), match="unit_flag"):
            mmad(c, a, b, M=16, N=16, K=16, unit_flag=unit_flag)
    finally:
        globvars.device_type = saved
