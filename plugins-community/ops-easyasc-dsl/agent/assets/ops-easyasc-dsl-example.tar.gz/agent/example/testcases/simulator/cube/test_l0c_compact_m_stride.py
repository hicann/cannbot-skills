import torch

from easyasc import globvars
from easyasc.a5 import *


M = 5
M_PAD = 16
K = 32
N = 32
BAD_M_SRC = 64


@kernel()
def _small_m_bad_stride_kernel(a: GMTensor, b: GMTensor, out: GMTensor, dummy: Var):
    l1_a = Tensor(DT.float, [M_PAD, K], Position.L1)
    l1_b = Tensor(DT.float, [K, N], Position.L1)
    l0c = Tensor(DT.float, [BAD_M_SRC, N], Position.L0C)

    with auto_sync():
        set_constant_to_l1(l1_a, 0.0)
        l1_a[0:M, 0:K] <<= a[0:M, 0:K]
        l1_b[0:K, 0:N] <<= b[0:K, 0:N]
        matmul(l0c, l1_a, l1_b.T, m=M, n=N, k=K)
        l0c_to_gm_nz2nd(out, l0c, M=M, N=N, N_dst=N, M_src=BAD_M_SRC)

    return out


@kernel()
def _small_m_compact_stride_kernel(a: GMTensor, b: GMTensor, out: GMTensor, dummy: Var):
    l1_a = Tensor(DT.float, [M_PAD, K], Position.L1)
    l1_b = Tensor(DT.float, [K, N], Position.L1)
    l0c = Tensor(DT.float, [M_PAD, N], Position.L0C)

    with auto_sync():
        set_constant_to_l1(l1_a, 0.0)
        l1_a[0:M, 0:K] <<= a[0:M, 0:K]
        l1_b[0:K, 0:N] <<= b[0:K, 0:N]
        matmul(l0c, l1_a, l1_b.T, m=M, n=N, k=K)
        l0c_to_gm_nz2nd(out, l0c, M=M, N=N, N_dst=N, M_src=M_PAD)

    return out


def _with_a5_device():
    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    return saved_device_type


def _make_inputs():
    torch.manual_seed(0)
    a = torch.randn((M, K), dtype=torch.float32)
    b = torch.randn((K, N), dtype=torch.float32)
    out = torch.zeros((M, N), dtype=torch.float32)
    return a, b, out


def test_small_m_l0c_wrong_m_src_matches_hardware_stride_hole(tmp_path) -> None:
    saved_device_type = _with_a5_device()
    try:
        a, b, out = _make_inputs()
        ref = a @ b

        got = OpExec(
            _small_m_bad_stride_kernel,
            out_dir=str(tmp_path / "small_m_bad_stride"),
            simulator=True,
        )(a, b, out, 1)

        torch.testing.assert_close(got[:, 0:16], ref[:, 0:16], rtol=1e-5, atol=1e-5)
        torch.testing.assert_close(got[:, 16:N], torch.zeros_like(ref[:, 16:N]), rtol=0, atol=0)
        assert not torch.allclose(got, ref, rtol=1e-5, atol=1e-5)
    finally:
        globvars.device_type = saved_device_type


def test_small_m_l0c_compact_m_src_matches_reference(tmp_path) -> None:
    saved_device_type = _with_a5_device()
    try:
        a, b, out = _make_inputs()
        ref = a @ b

        got = OpExec(
            _small_m_compact_stride_kernel,
            out_dir=str(tmp_path / "small_m_compact_stride"),
            simulator=True,
        )(a, b, out, 1)

        torch.testing.assert_close(got, ref, rtol=1e-5, atol=1e-5)
    finally:
        globvars.device_type = saved_device_type
