import os

import pytest
import torch

from easyasc.a5 import *  # noqa: F401,F403
from easyasc.parser.asc import translate_split
from easyasc.simulator.sync import IntraCoreSync


TILE = 64
SHAPE_BINDINGS = {
    0: [None, 0],
    1: [None, 0],
}


@kernel()
def _intracore_allvec_pair_kernel(src: GMTensor, dst: GMTensor, cols: Var):
    ub = Tensor(DT.float, [1, TILE], Position.UB)

    with auto_sync():
        if GetCubeIdx() == 0:
            row = Var(GetSubBlockIdx())
            ub[:, 0:cols] <<= src[row:row + 1, 0:cols]
            intracore_allvec_ready(3, pipe=Pipe.MTE2)
            intracore_allvec_wait(3, pipe=Pipe.MTE3)
            dst[row:row + 1, 0:cols] <<= ub[:, 0:cols]

    return dst


def _make_inputs():
    src = torch.arange(2 * TILE, dtype=torch.float32).reshape(2, TILE)
    dst = torch.empty_like(src)
    return src, dst


def test_intracore_allvec_wait_is_per_vec_lane_phase_barrier() -> None:
    sync = IntraCoreSync()

    sync.intracore_allvec_ready(0, 4, ready_cycle=1000, visible_cycle=1200)
    assert not sync.intracore_allvec_wait(0, 4, timeout=0.01)

    sync.intracore_allvec_ready(1, 4, ready_cycle=1100, visible_cycle=1400)
    assert sync.intracore_allvec_wait(0, 4, timeout=0.01)
    assert sync.intracore_allvec_ready_signal_cycle(0, 4) == 1100
    assert sync.intracore_allvec_ready_cycle(0, 4) == 1400

    assert sync.intracore_allvec_wait(1, 4, timeout=0.01)
    assert sync.intracore_allvec_ready_signal_cycle(1, 4) == 1100
    assert sync.intracore_allvec_ready_cycle(1, 4) == 1400


def test_intracore_allvec_codegen_uses_mode_one_macros() -> None:
    src = GMTensor(DT.float, [2, TILE])
    dst = GMTensor(DT.float, [2, TILE])
    _intracore_allvec_pair_kernel(src, dst, Var(TILE))

    cube_code, vec_code = translate_split(
        _intracore_allvec_pair_kernel.instructions,
        "intracore_allvec_pair_codegen",
    )

    assert "INTRACORE_ALLVEC_READY(3, PIPE_MTE2);" in vec_code
    assert "INTRACORE_ALLVEC_WAIT(3, PIPE_MTE3);" in vec_code
    assert "INTRACORE_ALLVEC_READY" not in cube_code
    assert "INTRACORE_ALLVEC_WAIT" not in cube_code


def test_sim_intracore_allvec_sync_only_waits_same_core_pair() -> None:
    src, dst = _make_inputs()
    actual = OpExec(
        _intracore_allvec_pair_kernel,
        "test_sim_intracore_allvec_sync_only_waits_same_core_pair",
        simulator=True,
    )(src, dst, TILE, shape_bindings=SHAPE_BINDINGS)

    torch.testing.assert_close(actual, src, rtol=0.0, atol=0.0)


@pytest.mark.skipif(
    os.environ.get("EASYASC_RUN_CANNSIM") != "1",
    reason="set EASYASC_RUN_CANNSIM=1 to run the CANNSIM integration smoke",
)
def test_cannsim_intracore_allvec_sync_only_waits_same_core_pair(tmp_path) -> None:
    src, dst = _make_inputs()
    actual = OpExec(
        _intracore_allvec_pair_kernel,
        out_dir=str(tmp_path / "intracore_allvec_cannsim"),
        simulator=False,
        cannsim=True,
    )(src, dst, TILE, shape_bindings=SHAPE_BINDINGS)

    torch.testing.assert_close(actual, src, rtol=0.0, atol=0.0)
