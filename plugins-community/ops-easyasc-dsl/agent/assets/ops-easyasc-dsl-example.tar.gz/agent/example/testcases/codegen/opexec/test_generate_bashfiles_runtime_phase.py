from pathlib import Path

from easyasc import globvars
from easyasc.a5 import *


@kernel()
def _bashfile_kernel(inp: GMTensor, out: GMTensor, m: Var):
    return out


def test_generate_bashfiles_keeps_setup_aclnn_in_runtime_script(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)

    _bashfile_kernel.generate_bashfiles(
        "generated_kernel",
        "/tmp/fake_cann",
        custom_op_path="/tmp/fake_custom_op",
    )

    script_dir = tmp_path / "generated_kernel_kernel_script"
    build_text = (script_dir / "b.sh").read_text(encoding="utf-8")
    run_text = (script_dir / "r.sh").read_text(encoding="utf-8")

    assert "python setup_aclnn.py" not in build_text
    assert "python setup_aclnn.py" in run_text


def test_generate_bashfiles_uses_950pr_cannsim_chipset(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    saved_device_type = globvars.device_type
    globvars.device_type = "950pr"
    try:
        _bashfile_kernel.generate_bashfiles(
            "generated_kernel",
            "/tmp/fake_cann",
            custom_op_path="/tmp/fake_custom_op",
            cannsim=True,
        )
    finally:
        globvars.device_type = saved_device_type

    run_text = (tmp_path / "generated_kernel_kernel_script" / "r.sh").read_text(encoding="utf-8")
    assert "cannsim record ./test_aclnnop -s Ascend950PR_9589" in run_text
