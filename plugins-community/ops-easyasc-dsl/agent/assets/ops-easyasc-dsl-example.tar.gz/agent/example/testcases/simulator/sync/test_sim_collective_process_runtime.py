import torch
import pytest

from easyasc.a2 import *
from easyasc.simulator import SimulatorConfig


_SHORT_COLLECTIVE_CONFIG = SimulatorConfig(core_count=2, execution_timeout_s=5.0)
# The compiler requires a non-returned input tensor in the kernel entry; these
# kernels hand `src` straight back, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.float16)


@kernel()
def _allvec_process_barrier(gate: GMTensor, src: GMTensor, contract: Var):
    allvec_ready(flag_id=0, pipe=Pipe.MTE3)
    allvec_wait(flag_id=0, pipe=Pipe.S)
    return src


# Pass-through kernels: the sync primitives never touch the buffer, so
# the simulator seeds it instead of handing the test its poison.
_allvec_process_barrier._simulator_seed_outputs = True
_allvec_process_barrier._simulator_config = _SHORT_COLLECTIVE_CONFIG


@kernel(mode="vec")
def _invalid_vec_mode_allvec_barrier(gate: GMTensor, src: GMTensor, contract: Var):
    allvec_ready(flag_id=0, pipe=Pipe.MTE3)
    allvec_wait(flag_id=0, pipe=Pipe.S)
    return src


@kernel()
def _allcube_process_barrier(gate: GMTensor, src: GMTensor, contract: Var):
    allcube_ready(flag_id=0, pipe=Pipe.FIX)
    allcube_wait(flag_id=0, pipe=Pipe.S)
    return src


_allcube_process_barrier._simulator_seed_outputs = True
_allcube_process_barrier._simulator_config = _SHORT_COLLECTIVE_CONFIG


def test_sim_allvec_collective_sync_across_core_processes() -> None:
    src = torch.arange(16, dtype=torch.float16).reshape(1, 16)
    op = OpExec(_allvec_process_barrier, "test_sim_allvec_collective_sync_across_core_processes", simulator=True)
    out = op(GATE, src, -1)
    assert torch.equal(out, src)


def test_sim_rejects_allvec_collective_in_vec_kernel_mode() -> None:
    src = torch.arange(16, dtype=torch.float16).reshape(1, 16)
    op = OpExec(
        _invalid_vec_mode_allvec_barrier,
        "test_sim_rejects_allvec_collective_in_vec_kernel_mode",
        simulator=True,
    )
    with pytest.raises(ValueError, match=r"kernel\(mode='vec'\).*allvec_ready/allvec_wait.*mode='mix'"):
        op(GATE, src, -1)


def test_sim_allcube_collective_sync_across_core_processes() -> None:
    src = torch.arange(16, dtype=torch.float16).reshape(1, 16)
    op = OpExec(_allcube_process_barrier, "test_sim_allcube_collective_sync_across_core_processes", simulator=True)
    out = op(GATE, src, -1)
    assert torch.equal(out, src)
