"""Simulator regression for ``histograms`` (MicroAPI::Histograms, dhistv2/chistv2).

Board-verified 2026-08-02 (kernels/a5/vec_only/histograms_probe.py, Ascend950PR):
the probe's simulator and board runs are byte-identical, which pins the three
things the CANN header leaves unsaid.

* The destination is **read-modify-write**: every call adds into the counters
  already in the register, so looping the instruction accumulates a tile.
* ``BIN_n`` maps the byte values ``[128*n, 128*n + 128)`` onto the destination's
  128 counters, so ``BIN0`` and ``BIN1`` together cover the whole byte range.
* ``FREQUENCY`` (``dhistv2``) counts the bytes **equal** to a bin.
  ``ACCUMULATE`` (``chistv2``) counts the bytes **<=** it, and does so over the
  whole byte range rather than the window -- ``BIN1``'s counters continue
  ``BIN0``'s totals, which is what lets the two concatenate into one 256-entry
  inclusive prefix count.
"""
import torch

from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.stub_functions.micro.histograms import HistBin, HistMode
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg

_STORE = SharedMemoryStore()
LANES8 = 256
BINS = 128


def _run(src_bytes, mask_bits, bin_group, mode, dst_init=None):
    rt = MicroRuntime()
    dst = Reg(DT.uint16, name="dst")
    src = Reg(DT.uint8, name="src")
    m = MaskReg(DT.uint8, init_mode=MaskType.NONE, name="m")
    init = (torch.zeros(BINS, dtype=torch.uint8).to(torch.int16)
            if dst_init is None else dst_init)
    ctx = MicroContext(
        regs={"dst": init.clone().view(torch.int16),
              "src": src_bytes.clone()},
        masks={"m": mask_bits.clone()},
    )
    rt._stack.append(ctx)
    try:
        rt._dispatch("micro_histograms",
                     {"dst": dst, "src": src, "mask": m,
                      "bin_group": bin_group, "mode": mode}, _STORE)
    finally:
        rt._stack.pop()
    return ctx.regs["dst"].to(torch.int64) & 0xFFFF


def _sample():
    values = ([5] * 7 + [6] + [127] * 3 + [128] * 5 + [200] + [255] * 2
              + [77] * 45)
    src = torch.zeros(LANES8, dtype=torch.uint8)
    src[:len(values)] = torch.tensor(values, dtype=torch.uint8)
    mask = torch.zeros(LANES8, dtype=torch.bool)
    mask[:len(values)] = True          # the padding lanes must not be counted
    freq = [0] * 256
    for v in values:
        freq[v] += 1
    return src, mask, freq


def test_frequency_counts_its_own_window_only():
    src, mask, freq = _sample()
    low = _run(src, mask, HistBin.BIN0, HistMode.FREQUENCY)
    high = _run(src, mask, HistBin.BIN1, HistMode.FREQUENCY)
    assert low.tolist() == freq[:128]
    assert high.tolist() == freq[128:]
    # the 200 and 255 bytes belong to BIN1 and must be absent from BIN0
    assert int(low.sum()) == 7 + 1 + 3 + 45
    assert int(high.sum()) == 5 + 1 + 2


def test_accumulate_is_an_inclusive_prefix_over_the_whole_byte_range():
    src, mask, freq = _sample()
    incl = [sum(freq[: b + 1]) for b in range(256)]
    low = _run(src, mask, HistBin.BIN0, HistMode.ACCUMULATE)
    high = _run(src, mask, HistBin.BIN1, HistMode.ACCUMULATE)
    assert low.tolist() == incl[:128]
    assert high.tolist() == incl[128:]
    # BIN1 continues BIN0's running total rather than restarting at 128
    assert int(high[0]) == incl[128]
    assert int(high[-1]) == sum(freq)


def test_destination_is_read_modify_write():
    src, mask, freq = _sample()
    once = _run(src, mask, HistBin.BIN0, HistMode.FREQUENCY)
    twice = _run(src, mask, HistBin.BIN0, HistMode.FREQUENCY,
                 dst_init=once.to(torch.int16))
    assert twice.tolist() == [2 * c for c in freq[:128]]


def test_masked_out_lanes_are_not_counted():
    src, mask, _ = _sample()
    half = mask.clone()
    half[8:] = False                    # keep only the seven 5s and the single 6
    low = _run(src, half, HistBin.BIN0, HistMode.FREQUENCY)
    assert int(low[5]) == 7
    assert int(low[6]) == 1
    assert int(low.sum()) == 8


def test_uint16_masked_whole_register_reductions():
    """Unsigned counters remain reducible on torch without uint16 indexing."""
    rt = MicroRuntime()
    src = Reg(DT.uint16, name="src")
    dst = Reg(DT.uint16, name="dst")
    mask = MaskReg(DT.uint16, init_mode=MaskType.NONE, name="mask")
    active = torch.zeros(128, dtype=torch.bool)
    active[[1, 7, 93]] = True
    values = torch.arange(128, dtype=torch.int64).to(torch.uint16)

    for opname, expected in (
        ("micro_vcadd", 101),
        ("micro_vcmax", 93),
        ("micro_vcmin", 1),
    ):
        ctx = MicroContext(
            regs={"src": values.clone(),
                  "dst": torch.zeros(128, dtype=torch.uint16)},
            masks={"mask": active.clone()},
        )
        rt._stack.append(ctx)
        try:
            rt._dispatch(opname, {"dst": dst, "src": src, "mask": mask},
                         _STORE)
        finally:
            rt._stack.pop()
        assert int(ctx.regs["dst"][0]) == expected
