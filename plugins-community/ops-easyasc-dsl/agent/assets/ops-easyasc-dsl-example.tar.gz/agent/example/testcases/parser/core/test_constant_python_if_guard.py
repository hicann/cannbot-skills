import pytest

from easyasc.a5 import *


@kernel()
def _constant_true(x: GMTensor):
    if True:
        sim_print("constant")
    return x


@kernel()
def _constant_false(x: GMTensor):
    if False:
        sim_print("constant")
    return x


@kernel()
def _constant_int(x: GMTensor):
    if 1:
        sim_print("constant")
    return x


@kernel()
def _constant_elif(x: GMTensor, flag: Var):
    if flag == 0:
        sim_print("runtime")
    elif True:
        sim_print("constant")
    return x


@kernel()
def _runtime_condition(x: GMTensor, flag: Var):
    if flag == 0:
        sim_print("runtime")
    return x


@kernel()
def _explicit_low_level_if(x: GMTensor):
    with If(True):
        sim_print("explicit")
    return x


@pytest.mark.parametrize("kernel_obj", [_constant_true, _constant_false, _constant_int])
def test_python_constant_if_is_rejected(kernel_obj) -> None:
    x = GMTensor(DT.float, [1, 1])
    with pytest.raises(SyntaxError, match=r"Python if/elif condition at line \d+.*compile-time constant"):
        kernel_obj(x)


def test_python_constant_elif_is_rejected() -> None:
    x = GMTensor(DT.float, [1, 1])
    with pytest.raises(SyntaxError, match="compile-time constant"):
        _constant_elif(x, Var(0))


def test_runtime_condition_remains_legal() -> None:
    x = GMTensor(DT.float, [1, 1])
    assert _runtime_condition(x, Var(0)) is x
    conds = [inst.kwargs["cond"] for inst in _runtime_condition.instructions if inst.opname == "start_if"]
    assert len(conds) == 1
    assert not isinstance(conds[0], (bool, int))


def test_explicit_low_level_constant_if_remains_legal() -> None:
    x = GMTensor(DT.float, [1, 1])
    assert _explicit_low_level_if(x) is x
    conds = [inst.kwargs["cond"] for inst in _explicit_low_level_if.instructions if inst.opname == "start_if"]
    assert conds == [True]
