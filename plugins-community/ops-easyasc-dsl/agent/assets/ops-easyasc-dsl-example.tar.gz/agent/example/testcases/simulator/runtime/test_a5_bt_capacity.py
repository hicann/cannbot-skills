import torch

from easyasc.a5 import *
from easyasc.simulator import SimulatorConfig


@kernel(mode="cube")
def _a5_large_bt_kernel(x: GMTensor, y: GMTensor, dummy: Var):
    l1 = Tensor(
        DT.float, [1, 256], Position.L1, layout=Layout.ND,
        name="a5_large_bt_l1",
    )
    bt = Tensor(DT.float, [1, 256], Position.BT, name="a5_large_bt")
    with auto_sync():
        gm_to_l1_pad(
            l1, x, n_burst=1, burst_len_element=256,
            src_stride_element=0, dst_stride=0,
        )
        l1_to_bt(bt, l1, n=256)
    return y


_a5_large_bt_kernel._simulator_config = SimulatorConfig(
    core_count=1, cycle_model_enabled=False,
)


@kernel(mode="cube")
def _a5_bfloat16_bt_bias_kernel(
    x: GMTensor, weight: GMTensor, bias: GMTensor, y: GMTensor, dummy: Var,
):
    l1x = Tensor(DT.bfloat16, [16, 16], Position.L1)
    l1w = Tensor(DT.bfloat16, [16, 128], Position.L1)
    l1bias = Tensor(DT.bfloat16, [1, 128], Position.L1, layout=Layout.ND)
    l0a = Tensor(DT.bfloat16, [16, 16], Position.L0A)
    l0b = Tensor(DT.bfloat16, [16, 128], Position.L0B)
    bt = Tensor(DT.float, [1, 128], Position.BT)
    l0c = Tensor(DT.float, [16, 128], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1w <<= weight[:, :]
        gm_to_l1_pad(
            l1bias, bias, n_burst=1, burst_len_element=128,
            src_stride_element=0, dst_stride=0,
        )
        l1_to_l0(l0a, l1x)
        l1_to_l0(l0b, l1w.T)
        l1_to_bt(bt, l1bias, n=128)
        mmad(l0c, l0a, l0b, M=16, N=128, K=16, is_init=True, bias=bt)
        y[:, :] <<= l0c
    return y


_a5_bfloat16_bt_bias_kernel._simulator_config = SimulatorConfig(
    core_count=1, cycle_model_enabled=False,
)


def test_a5_simulator_uses_four_kilobyte_bt_profile() -> None:
    x = torch.arange(256, dtype=torch.float32)
    y = torch.zeros(1, dtype=torch.float32)
    got = OpExec(_a5_large_bt_kernel, simulator=True, debug=False)(x, y, 0)
    assert got.shape == y.shape


def test_a5_l1_to_bt_widens_bfloat16_bias_to_float() -> None:
    x = torch.zeros((16, 16), dtype=torch.bfloat16)
    weight = torch.zeros((16, 128), dtype=torch.bfloat16)
    bias = torch.linspace(-2.0, 2.0, 128, dtype=torch.float32).to(torch.bfloat16)
    y = torch.zeros((16, 128), dtype=torch.float32)

    got = OpExec(_a5_bfloat16_bt_bias_kernel, simulator=True, debug=False)(
        x, weight, bias, y, 0,
    )
    expected = bias.float().view(1, 128).expand(16, 128)
    torch.testing.assert_close(got, expected, rtol=0.0, atol=0.0)
