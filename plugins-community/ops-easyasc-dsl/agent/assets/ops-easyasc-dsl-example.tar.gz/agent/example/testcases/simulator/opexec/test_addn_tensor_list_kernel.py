import torch

from easyasc.a2 import OpExec
from kernels.a2.vec_only.addn_tensor_list import addn_reference, addn_tensor_list_kernel


def _run_case(tmp_path, n: int, list_size: int, dtype: torch.dtype, seed: int) -> None:
    torch.manual_seed(seed)
    xs = [
        torch.empty((1, n), dtype=dtype).uniform_(-1.0, 1.0)
        for _ in range(list_size)
    ]
    out = torch.zeros((1, n), dtype=dtype)
    expected = addn_reference(xs)

    got = OpExec(
        addn_tensor_list_kernel,
        out_dir=str(tmp_path / f"addn_{dtype}_{n}_{list_size}"),
        simulator=True,
    )(
        xs,
        out,
        n,
        shape_bindings={0: {"item": [None, 0]}, 1: [None, 0]},
    )

    rtol = 2e-3 if dtype is torch.float16 else 1e-4
    atol = 2e-3 if dtype is torch.float16 else 1e-4
    torch.testing.assert_close(got, expected, rtol=rtol, atol=atol)


def test_addn_tensor_list_single_input(tmp_path) -> None:
    _run_case(tmp_path, n=257, list_size=1, dtype=torch.float16, seed=0)


def test_addn_tensor_list_half_tail(tmp_path) -> None:
    _run_case(tmp_path, n=2113, list_size=4, dtype=torch.float16, seed=1)


def test_addn_tensor_list_float_tail(tmp_path) -> None:
    _run_case(tmp_path, n=2305, list_size=3, dtype=torch.float32, seed=2)
