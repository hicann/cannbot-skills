from easyasc.a2 import *
from easyasc.parser.asc import translate_split


@kernel()
def _gm_l0c_relu_direct_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    src._is_relu = True
    full_view = out[:, :]
    full_view <<= src
    return out


@kernel()
def _gm_l0c_relu_slice_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [16, 16], Position.L0C, name="src_l0c")
    src._is_relu = True
    out[0:16, :] <<= src
    return out


def test_gmtensor_ilshift_l0c_to_gm_propagates_relu_and_codegen() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.half, [32, 16], name="out")

    _gm_l0c_relu_direct_kernel(inp, out)

    found = [inst for inst in _gm_l0c_relu_direct_kernel.instructions if inst.opname == "l0c_to_gm_nz2nd"]
    assert len(found) == 1
    assert bool(found[0].kwargs["relu"]) is True

    cube_code, _ = translate_split(_gm_l0c_relu_direct_kernel.instructions, "gm_l0c_relu_direct_codegen")
    assert "L0C2GM_NZ2ND(" in cube_code
    assert "src_l0c" in cube_code
    assert ", 32, 16, 16, 32, true);" in cube_code


def test_gmtensor_setitem_l0c_to_gm_propagates_relu() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.half, [32, 16], name="out")

    _gm_l0c_relu_slice_kernel(inp, out)

    found = [inst for inst in _gm_l0c_relu_slice_kernel.instructions if inst.opname == "l0c_to_gm_nz2nd"]
    assert len(found) == 1
    assert bool(found[0].kwargs["relu"]) is True
