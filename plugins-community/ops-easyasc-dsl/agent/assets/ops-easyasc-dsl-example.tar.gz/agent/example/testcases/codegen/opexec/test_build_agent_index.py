import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[5]
SCRIPT = ROOT / "agent" / "scripts" / "build_agent_index.py"


def _load_module():
    spec = importlib.util.spec_from_file_location("build_agent_index_test_mod", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_rendered_lean_index_is_derived_from_catalog_payload() -> None:
    module = _load_module()
    payload = {
        "entry_count": 2,
        "entries": [
            {
                "path": "agent/example/kernels/a2/vec.py",
                "topology": "vec-only",
                "formula": "x | y",
            },
            {
                "path": "agent/example/projects/a5/op/kernel.py",
                "targets": ["a5pr"],
                "topology": "cube->vec",
                "formula": "z = x @ y.t()",
            },
        ],
    }
    text = module.render_kernel_lean_index(payload)
    assert "Generated entries: 2." in text
    assert "--device <a2|a5|a5pr>" in text
    assert "| a2 | vec-only | `agent/example/kernels/a2/vec.py` | x \\| y |" in text
    assert "| a5pr | cube->vec | `agent/example/projects/a5/op/kernel.py`" in text


def test_check_indexes_reports_only_mismatched_outputs(tmp_path: Path, monkeypatch) -> None:
    module = _load_module()
    current = tmp_path / "current.txt"
    stale = tmp_path / "stale.txt"
    current.write_text("ok\n", encoding="utf-8")
    stale.write_text("old\n", encoding="utf-8")
    monkeypatch.setattr(
        module, "build_outputs", lambda: {current: "ok\n", stale: "new\n"}
    )
    assert module.check_indexes() == [stale]
