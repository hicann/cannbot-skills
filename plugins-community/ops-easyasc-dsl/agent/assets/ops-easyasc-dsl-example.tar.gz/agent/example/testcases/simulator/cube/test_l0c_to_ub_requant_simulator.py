"""Simulator behavioral check for the fixpipe scalar requant on the L0C -> UB store (a5-only).

A matmul fills L0C, ``ub <<= l0c.requant(...)`` quantizes on the SINGLE-mode store (the rider
forces SINGLE), and UB is copied back to GM for comparison. The cube(FIX) -> vector(V) hand-off
uses a CvMutex and the SINGLE store lands in subblock 0, so the read-back is guarded by
GetSubBlockIdx() == 0. Mirrors test_l0c_to_gm_requant_simulator.py's reference model.
"""
import struct

import torch

from easyasc.a5 import *   # noqa: F401,F403 -- @kernel rewrites `if` to the DSL `If` construct

M, N, K_HALF, K_INT8 = 16, 32, 48, 64


def _fp19(scale):
    u = struct.unpack("<I", struct.pack("<f", float(scale)))[0] & 0xFFFFE000
    return struct.unpack("<f", struct.pack("<I", u))[0]


@kernel()
def _ub_quant_int8_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    ub = Tensor(z.dtype, [M, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cvmutex.lock()
        ub <<= l0c.requant(scale=0.5, offset=8).subblk(0)
        cvmutex.ready()
        cvmutex.wait()
        if GetSubBlockIdx() == 0:
            z[0:M, 0:N] <<= ub[0:M, 0:N]
        cvmutex.free()
    return z


@kernel()
def _ub_dequant_fp16_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    l1x = Tensor(DT.int8, [M, K], Position.L1)
    l1y = Tensor(DT.int8, [N, K], Position.L1)
    l0c = Tensor(DT.int, [M, N], Position.L0C)
    ub = Tensor(DT.half, [M, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cvmutex.lock()
        ub <<= l0c.requant(scale=0.25).subblk(0)
        cvmutex.ready()
        cvmutex.wait()
        if GetSubBlockIdx() == 0:
            z[0:M, 0:N] <<= ub[0:M, 0:N]
        cvmutex.free()
    return z


def test_ub_qf322b8_single_quantizes_on_store() -> None:
    torch.manual_seed(0)
    x = torch.randint(-3, 4, (M, K_HALF)).to(torch.float16)
    y = torch.randint(-3, 4, (N, K_HALF)).to(torch.float16)
    acc = x.float() @ y.float().t()
    r = torch.clamp(torch.round(acc * _fp19(0.5)), -256.0, 255.0) + 8.0
    ref = torch.clamp(r, -128.0, 127.0).to(torch.int8)

    z = torch.zeros((M, N), dtype=torch.int8)
    got = OpExec(_ub_quant_int8_kernel, simulator=True)(x, y, z, M, N, K_HALF)
    assert torch.equal(got, ref)


def test_ub_deqf16_single_dequantizes_on_store() -> None:
    torch.manual_seed(1)
    x = torch.randint(-3, 4, (M, K_INT8), dtype=torch.int8)
    y = torch.randint(-3, 4, (N, K_INT8), dtype=torch.int8)
    acc = x.int() @ y.int().t()
    ref = (acc.float() * _fp19(0.25)).to(torch.float16)

    z = torch.zeros((M, N), dtype=torch.float16)
    got = OpExec(_ub_dequant_fp16_kernel, simulator=True)(x, y, z, M, N, K_INT8)
    torch.testing.assert_close(got.float(), ref.float(), rtol=4e-3, atol=4e-3)


# A tall (M=32) L0C requant-stored to UB in two halves via static L0C row slices -- each a
# SINGLE-mode store of l0c[0:16, :] / l0c[16:32, :]. N=64 (a multiple of 32, the UB row align).
SPLIT_M, SPLIT_N, SPLIT_K = 32, 64, 48


@kernel()
def _ub_split_rows_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cv0 = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    cv1 = CvMutex(1, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    l1x = Tensor(DT.half, [M, K], Position.L1)
    l1y = Tensor(DT.half, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    ub0 = Tensor(z.dtype, [16, N], Position.UB)
    ub1 = Tensor(z.dtype, [16, N], Position.UB)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        cv0.lock()
        ub0 <<= l0c[0:16, :].requant(scale=0.5, offset=8).subblk(0)      # static L0C row sub-tile (offset 0)
        cv0.ready()
        cv1.lock()
        ub1 <<= l0c[16:32, :].requant(scale=0.5, offset=8).subblk(0)     # static L0C row sub-tile (offset 16)
        cv1.ready()
        cv0.wait()
        if GetSubBlockIdx() == 0:
            z[0:16, :] <<= ub0[0:16, :]
        cv0.free()
        cv1.wait()
        if GetSubBlockIdx() == 0:
            z[16:32, :] <<= ub1[0:16, :]
        cv1.free()
    return z


def test_ub_split_tall_l0c_by_row_slices() -> None:
    torch.manual_seed(2)
    x = torch.randint(-3, 4, (SPLIT_M, SPLIT_K)).to(torch.float16)
    y = torch.randint(-3, 4, (SPLIT_N, SPLIT_K)).to(torch.float16)
    acc = x.float() @ y.float().t()
    r = torch.clamp(torch.round(acc * _fp19(0.5)), -256.0, 255.0) + 8.0
    ref = torch.clamp(r, -128.0, 127.0).to(torch.int8)

    z = torch.zeros((SPLIT_M, SPLIT_N), dtype=torch.int8)
    got = OpExec(_ub_split_rows_kernel, simulator=True)(x, y, z, SPLIT_M, SPLIT_N, SPLIT_K)
    assert torch.equal(got, ref)            # both halves, from the two sliced stores
