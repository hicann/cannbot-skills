import pytest
import torch

from easyasc.a5 import *
from easyasc.parser.asc import split_instructions, translate_split


COLS = 64
ROWS = 16


@kernel()
def _kernel_dump_gm(src: GMTensor):
    kernel_dump_tensor(src, 3, 64)
    return src


@kernel()
def _kernel_dump_ub(src: GMTensor, cols: Var):
    ub = Tensor(DT.half, [1, cols], Position.UB, name="ub")
    ub <<= src[0:1, 0:cols]
    kernel_dump_tensor(ub, 4, cols)
    return src


@kernel()
def _kernel_dump_l1(src: GMTensor):
    l1 = Tensor(DT.half, [ROWS, ROWS], Position.L1, name="l1")
    l1 <<= src[0:ROWS, 0:ROWS]
    kernel_dump_tensor(l1, 5, 256)
    return src


@kernel()
def _kernel_dump_l0c(dst: GMTensor):
    l0c = Tensor(DT.float, [ROWS, 16], Position.L0C, name="l0c")
    kernel_dump_tensor(l0c, 6, 256)
    return dst


def test_kernel_dump_tensor_rejects_invalid_src_type() -> None:
    with pytest.raises(TypeError, match="src must be GMTensor or Tensor"):
        kernel_dump_tensor("bad", 1, 16)  # type: ignore[arg-type]


def test_kernel_dump_tensor_rejects_invalid_tensor_position() -> None:
    l0a = Tensor(DT.half, [ROWS, 16], Position.L0A)
    with pytest.raises(ValueError, match="only supports UB/L1/L0C"):
        kernel_dump_tensor(l0a, 1, 16)


def test_kernel_dump_tensor_rejects_invalid_desc_type() -> None:
    src = GMTensor(DT.half, [1, COLS])
    with pytest.raises(TypeError, match="desc must be int or Var"):
        kernel_dump_tensor(src, "bad", 16)  # type: ignore[arg-type]


def test_kernel_dump_tensor_rejects_invalid_dump_size_type() -> None:
    src = GMTensor(DT.half, [1, COLS])
    with pytest.raises(TypeError, match="dumpSize must be int or Var"):
        kernel_dump_tensor(src, 1, "bad")  # type: ignore[arg-type]


def test_kernel_dump_tensor_gmtensor_routes_to_both_and_codegen() -> None:
    src = GMTensor(DT.half, [1, COLS], name="src")
    _kernel_dump_gm(src)

    cube_insts, vec_insts = split_instructions(list(_kernel_dump_gm.instructions))
    assert "kernel_dump_tensor" in [inst.opname for inst in cube_insts]
    assert "kernel_dump_tensor" in [inst.opname for inst in vec_insts]

    cube_code, vec_code = translate_split(_kernel_dump_gm.instructions, "kernel_dump_gm_codegen")
    expected = "DumpTensor(src, (uint32_t) 3, (uint32_t) 64);"
    assert expected in cube_code
    assert expected in vec_code


def test_kernel_dump_tensor_ub_routes_to_vec_only_and_codegen() -> None:
    src = GMTensor(DT.half, [1, COLS], name="src")
    _kernel_dump_ub(src, Var(COLS))

    cube_insts, vec_insts = split_instructions(list(_kernel_dump_ub.instructions))
    assert "kernel_dump_tensor" not in [inst.opname for inst in cube_insts]
    assert "kernel_dump_tensor" in [inst.opname for inst in vec_insts]

    cube_code, vec_code = translate_split(_kernel_dump_ub.instructions, "kernel_dump_ub_codegen")
    expected = "DumpTensor(ub, (uint32_t) 4, (uint32_t) cols);"
    assert expected not in cube_code
    assert expected in vec_code


def test_kernel_dump_tensor_l1_routes_to_cube_only_and_codegen() -> None:
    src = GMTensor(DT.half, [ROWS, ROWS], name="src")
    _kernel_dump_l1(src)

    cube_insts, vec_insts = split_instructions(list(_kernel_dump_l1.instructions))
    assert "kernel_dump_tensor" in [inst.opname for inst in cube_insts]
    assert "kernel_dump_tensor" not in [inst.opname for inst in vec_insts]

    cube_code, vec_code = translate_split(_kernel_dump_l1.instructions, "kernel_dump_l1_codegen")
    expected = "DumpTensor(l1, (uint32_t) 5, (uint32_t) 256);"
    assert expected in cube_code
    assert expected not in vec_code


def test_kernel_dump_tensor_l0c_routes_to_cube_only() -> None:
    dst = GMTensor(DT.float, [ROWS, 16], name="dst")
    _kernel_dump_l0c(dst)

    cube_insts, vec_insts = split_instructions(list(_kernel_dump_l0c.instructions))
    assert "kernel_dump_tensor" in [inst.opname for inst in cube_insts]
    assert "kernel_dump_tensor" not in [inst.opname for inst in vec_insts]


