import torch
import pytest

from easyasc.a5 import (
    CeilDiv, DT, GMTensor, OpExec, Position, Tensor, Var,
    auto_sync, fp4_e1m2_to_fp32, fp4_e2m1_to_fp32, gm_to_l1_mx_scale,
    gm_to_l1_mx_scale_nd2nz, gm_to_l1_pad, kernel, l1_to_l0_mx, matmul_mx, mmad_mx,
)
from easyasc.simulator.memory import L0AMX_BUFFER_NAME, L0BMX_BUFFER_NAME
from easyasc.simulator.pipe_cube import CubeMTE1Pipe, MPipe
from easyasc.simulator.program import PipeTask
from easyasc.simulator.util import align16, decode_nz_to_nd, encode_nd_to_nz, nz_footprint


pytestmark = pytest.mark.easyasc_device("a5")

M_TRANSPOSE = 16
N_TRANSPOSE = 32
K_TRANSPOSE = 64
K_TRANSPOSE_SPLITK = 128
N_TRANSPOSE_SPLITN = 64
M_A_TRANSPOSE = 32
N_A_TRANSPOSE = 16
N_A_TRANSPOSE_SPLITN = 32
M_BOTH_TRANSPOSE = 32
N_BOTH_TRANSPOSE = 32
N_BOTH_TRANSPOSE_SPLITN = 64


class _TensorStore(object):
    def __init__(self, tensors=None):
        self._tensors = dict(tensors or {})
        self.specs = {}

    def tensor(self, name):
        return self._tensors[name]

    def contains(self, name):
        return name in self._tensors

    def register_view(self, name, tensor):
        self._tensors[name] = tensor


def _pipe(tensors):
    pipe = object.__new__(CubeMTE1Pipe)
    pipe.memory_store = _TensorStore(tensors)
    return pipe


def _mpipe(tensors):
    pipe = object.__new__(MPipe)
    pipe.memory_store = _TensorStore(tensors)
    return pipe


def _nz_u8_tile(rows=16, cols=64):
    logical = torch.arange(rows * cols, dtype=torch.uint8).reshape(rows, cols)
    flat = torch.zeros(nz_footprint(cols, align16(rows), 32), dtype=torch.uint8)
    encode_nd_to_nz(logical, flat, rows, cols, align16(rows), 32)
    return flat


def _require_float8_e4m3():
    if not hasattr(torch, "float8_e4m3fn"):
        pytest.skip("Current torch build does not support torch.float8_e4m3fn")
    return torch.float8_e4m3fn


def _nz_fp8_tile(logical):
    dtype = _require_float8_e4m3()
    rows, cols = logical.shape
    flat = torch.zeros(nz_footprint(cols, align16(rows), 32), dtype=dtype)
    encode_nd_to_nz(logical.to(dtype), flat, rows, cols, align16(rows), 32)
    return flat


def _pack_mx_scale(values, k):
    rows = int(values.shape[0])
    groups = (int(k) + 31) // 32
    row_blocks = (rows + 15) // 16
    col_blocks = (int(k) + 63) // 64
    values = values.to(torch.uint8)
    assert values.shape == (rows, groups)
    padded = torch.full((row_blocks * 16, col_blocks * 2), 127, dtype=torch.uint8)
    padded[:rows, :groups] = values
    blocks = []
    for row_block in range(row_blocks):
        for col_block in range(col_blocks):
            block = padded[row_block * 16 : (row_block + 1) * 16, col_block * 2 : col_block * 2 + 2]
            blocks.append(block.contiguous().reshape(32))
    return torch.cat(blocks).contiguous()


def _expand_scale(values, k):
    groups = torch.arange(int(k), dtype=torch.long) // 32
    exponents = values[:, groups].to(torch.float32) - 127.0
    return torch.pow(torch.full_like(exponents, 2.0), exponents)


def _make_scale(rows, groups, offset):
    row = torch.arange(rows, dtype=torch.int16).reshape(rows, 1)
    col = torch.arange(groups, dtype=torch.int16).reshape(1, groups)
    return (125 + ((row + 2 * col + offset) % 5)).to(torch.uint8)


def _decode_l0c(flat, m, n):
    return decode_nz_to_nd(flat, m, n, align16(m), 16)


def _mx_ref(a, b_nk, scale_a_values, scale_b_values, k):
    return torch.matmul(
        a.to(torch.float32) * _expand_scale(scale_a_values, k),
        (b_nk.to(torch.float32) * _expand_scale(scale_b_values, k)).transpose(0, 1),
    )


def _fp4_values(nibbles, dtype_name):
    if dtype_name == "fp4_e2m1":
        table = torch.tensor([0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0], dtype=torch.float32)
    elif dtype_name == "fp4_e1m2":
        table = torch.tensor([0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75], dtype=torch.float32)
    else:
        raise ValueError(dtype_name)
    low = (nibbles.to(torch.long) & 0x7).reshape(-1)
    sign = (nibbles & 0x8) != 0
    values = table.index_select(0, low).reshape(nibbles.shape)
    return torch.where(sign, -values, values)


def _pack_fp4_cols(nibbles):
    nibbles = nibbles.to(torch.uint8) & 0x0F
    rows, cols = nibbles.shape
    if cols % 2 != 0:
        nibbles = torch.cat([nibbles, torch.zeros((rows, 1), dtype=torch.uint8)], dim=1)
    return (nibbles[:, 0::2] | (nibbles[:, 1::2] << 4)).contiguous()


def _nz_fp4_tile(nibbles):
    rows, logical_cols = nibbles.shape
    carrier = _pack_fp4_cols(nibbles)
    flat = torch.zeros(nz_footprint(carrier.shape[1], align16(rows), 32), dtype=torch.uint8)
    encode_nd_to_nz(carrier, flat, rows, carrier.shape[1], align16(rows), 32)
    return flat


@kernel()
def _mx_matmul_shortcut_sim_kernel(
    x: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, M: Var, N: Var, K: Var,
):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1)
    l1b = Tensor(DT.e4m3, [16, 64], Position.L1)
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1)
    l0c = Tensor(DT.float, [16, 16], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(l0c, l1a, l1b, scale_a, scale_b, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mxfp4_matmul_shortcut_sim_kernel(
    x: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a_u8 = Tensor(DT.uint8, [16, 32], Position.L1)
    l1b_u8 = Tensor(DT.uint8, [16, 32], Position.L1)
    l1a = l1a_u8.reinterpret(DT.fp4_e2m1)
    l1b = l1b_u8.reinterpret(DT.fp4_e1m2)
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1)
    l0c = Tensor(DT.float, [16, 16], Position.L0C)

    with auto_sync():
        l1a_u8 <<= x[:, :]
        l1b_u8 <<= y[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(l0c, l1a, l1b, scale_a, scale_b, m=16, n=16, k=64, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mxfp4_dense_scale_low_level_sim_kernel(
    x: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a_u8 = Tensor(DT.uint8, [32, 64], Position.L1)
    l1b_u8 = Tensor(DT.uint8, [32, 64], Position.L1)
    l1a = l1a_u8.reinterpret(DT.fp4_e2m1)
    l1b = l1b_u8.reinterpret(DT.fp4_e1m2)
    scale_a = Tensor(DT.uint8, [32, 4], Position.L1)
    scale_b = Tensor(DT.uint8, [32, 4], Position.L1)
    l0a_u8 = Tensor(DT.uint8, [32, 64], Position.L0A)
    l0b_u8 = Tensor(DT.uint8, [32, 64], Position.L0B)
    l0a = l0a_u8.reinterpret(DT.fp4_e2m1)
    l0b = l0b_u8.reinterpret(DT.fp4_e1m2)
    l0c = Tensor(DT.float, [32, 32], Position.L0C)

    with auto_sync():
        l1a_u8 <<= x[:, :]
        l1b_u8 <<= y[:, :]
        gm_to_l1_mx_scale_nd2nz(scale_a, scale_a_gm)
        gm_to_l1_mx_scale_nd2nz(scale_b, scale_b_gm)
        l1_to_l0_mx(l0a, l1a, scale_a, m_dst=32, n_dst=128, m_src=32, n_src=128)
        l1_to_l0_mx(l0b, l1b, scale_b, m_dst=32, n_dst=128, m_src=32, n_src=128)
        mmad_mx(l0c, l0a, l0b, M=32, N=32, K=128, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_nosplit_fixed_sim_kernel(
    x: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_TRANSPOSE, M_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(l0c, l1a, l1b, scale_a, scale_b, m=M_TRANSPOSE, n=M_TRANSPOSE, k=K_TRANSPOSE, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_splitk_shortcut_sim_kernel(
    x: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE_SPLITK], Position.L1)
    l1b = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE_SPLITK], Position.L1)
    scale_a = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_TRANSPOSE, M_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitk=64, m=M_TRANSPOSE, n=M_TRANSPOSE, k=K_TRANSPOSE_SPLITK, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_splitn_shortcut_sim_kernel(
    x: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [N_A_TRANSPOSE_SPLITN, K_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_A_TRANSPOSE_SPLITN, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_TRANSPOSE, N_A_TRANSPOSE_SPLITN], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_A_TRANSPOSE_SPLITN, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitn=16, m=M_TRANSPOSE, n=N_A_TRANSPOSE_SPLITN, k=K_TRANSPOSE, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_transpose_shortcut_sim_kernel(
    x: GMTensor, y_kn: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [K_TRANSPOSE, N_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_TRANSPOSE, N_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y_kn[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(l0c, l1a, l1b.T, scale_a, scale_b, m=M_TRANSPOSE, n=N_TRANSPOSE, k=K_TRANSPOSE, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_transposed_a_shortcut_sim_kernel(
    x_km: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [K_TRANSPOSE, M_A_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [N_A_TRANSPOSE, K_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_A_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_A_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_A_TRANSPOSE, N_A_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x_km[:, :]
        l1b <<= y[:, :]
        gm_to_l1_pad(
            scale_a,
            scale_a_gm,
            n_burst=CeilDiv(M_A_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(l0c, l1a.T, l1b, scale_a, scale_b, m=M_A_TRANSPOSE, n=N_A_TRANSPOSE, k=K_TRANSPOSE, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_transposed_a_splitk_shortcut_sim_kernel(
    x_km: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [K_TRANSPOSE_SPLITK, M_A_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [N_A_TRANSPOSE, K_TRANSPOSE_SPLITK], Position.L1)
    scale_a = Tensor(DT.uint8, [M_A_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_A_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_A_TRANSPOSE, N_A_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x_km[:, :]
        l1b <<= y[:, :]
        gm_to_l1_pad(
            scale_a,
            scale_a_gm,
            n_burst=CeilDiv(M_A_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE_SPLITK, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(
            l0c,
            l1a.T,
            l1b,
            scale_a,
            scale_b,
            splitk=64,
            m=M_A_TRANSPOSE,
            n=N_A_TRANSPOSE,
            k=K_TRANSPOSE_SPLITK,
            is_init=True,
        )
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_transposed_a_splitn_shortcut_sim_kernel(
    x_km: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [K_TRANSPOSE, M_A_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [N_A_TRANSPOSE_SPLITN, K_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_A_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_A_TRANSPOSE_SPLITN, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_A_TRANSPOSE, N_A_TRANSPOSE_SPLITN], Position.L0C)

    with auto_sync():
        l1a <<= x_km[:, :]
        l1b <<= y[:, :]
        gm_to_l1_pad(
            scale_a,
            scale_a_gm,
            n_burst=CeilDiv(M_A_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_A_TRANSPOSE_SPLITN, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(
            l0c,
            l1a.T,
            l1b,
            scale_a,
            scale_b,
            splitn=16,
            m=M_A_TRANSPOSE,
            n=N_A_TRANSPOSE_SPLITN,
            k=K_TRANSPOSE,
            is_init=True,
        )
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_both_transposed_shortcut_sim_kernel(
    x_km: GMTensor, y_kn: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [K_TRANSPOSE, M_BOTH_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [K_TRANSPOSE, N_BOTH_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_BOTH_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_BOTH_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_BOTH_TRANSPOSE, N_BOTH_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x_km[:, :]
        l1b <<= y_kn[:, :]
        gm_to_l1_pad(
            scale_a,
            scale_a_gm,
            n_burst=CeilDiv(M_BOTH_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_BOTH_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(l0c, l1a.T, l1b.T, scale_a, scale_b, m=M_BOTH_TRANSPOSE, n=N_BOTH_TRANSPOSE, k=K_TRANSPOSE, is_init=True)
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_both_transposed_splitk_shortcut_sim_kernel(
    x_km: GMTensor, y_kn: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [K_TRANSPOSE_SPLITK, M_BOTH_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [K_TRANSPOSE_SPLITK, N_BOTH_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_BOTH_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_BOTH_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_BOTH_TRANSPOSE, N_BOTH_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x_km[:, :]
        l1b <<= y_kn[:, :]
        gm_to_l1_pad(
            scale_a,
            scale_a_gm,
            n_burst=CeilDiv(M_BOTH_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE_SPLITK, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_BOTH_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE_SPLITK, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(
            l0c,
            l1a.T,
            l1b.T,
            scale_a,
            scale_b,
            splitk=64,
            m=M_BOTH_TRANSPOSE,
            n=N_BOTH_TRANSPOSE,
            k=K_TRANSPOSE_SPLITK,
            is_init=True,
        )
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_both_transposed_splitn_shortcut_sim_kernel(
    x_km: GMTensor, y_kn: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [K_TRANSPOSE, M_BOTH_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [K_TRANSPOSE, N_BOTH_TRANSPOSE_SPLITN], Position.L1)
    scale_a = Tensor(DT.uint8, [M_BOTH_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_BOTH_TRANSPOSE_SPLITN, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_BOTH_TRANSPOSE, N_BOTH_TRANSPOSE_SPLITN], Position.L0C)

    with auto_sync():
        l1a <<= x_km[:, :]
        l1b <<= y_kn[:, :]
        gm_to_l1_pad(
            scale_a,
            scale_a_gm,
            n_burst=CeilDiv(M_BOTH_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_BOTH_TRANSPOSE_SPLITN, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(
            l0c,
            l1a.T,
            l1b.T,
            scale_a,
            scale_b,
            splitn=32,
            m=M_BOTH_TRANSPOSE,
            n=N_BOTH_TRANSPOSE_SPLITN,
            k=K_TRANSPOSE,
            is_init=True,
        )
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_transpose_wide_k_shortcut_sim_kernel(
    x: GMTensor, y_kn: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE_SPLITK], Position.L1)
    l1b = Tensor(DT.e4m3, [K_TRANSPOSE_SPLITK, N_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_TRANSPOSE, N_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y_kn[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE_SPLITK, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(
            l0c,
            l1a,
            l1b.T,
            scale_a,
            scale_b,
            m=M_TRANSPOSE,
            n=N_TRANSPOSE,
            k=K_TRANSPOSE_SPLITK,
            is_init=True,
        )
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_transpose_splitk_shortcut_sim_kernel(
    x: GMTensor, y_kn: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE_SPLITK], Position.L1)
    l1b = Tensor(DT.e4m3, [K_TRANSPOSE_SPLITK, N_TRANSPOSE], Position.L1)
    scale_a = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE_SPLITK, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_TRANSPOSE, N_TRANSPOSE], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y_kn[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_TRANSPOSE, 16) * CeilDiv(K_TRANSPOSE_SPLITK, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(
            l0c,
            l1a,
            l1b.T,
            scale_a,
            scale_b,
            splitk=64,
            m=M_TRANSPOSE,
            n=N_TRANSPOSE,
            k=K_TRANSPOSE_SPLITK,
            is_init=True,
        )
        z[:, :] <<= l0c
    return z


@kernel()
def _mx_matmul_transpose_splitn_shortcut_sim_kernel(
    x: GMTensor, y_kn: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
    z: GMTensor, dummy: Var,
):
    l1a = Tensor(DT.e4m3, [M_TRANSPOSE, K_TRANSPOSE], Position.L1)
    l1b = Tensor(DT.e4m3, [K_TRANSPOSE, N_TRANSPOSE_SPLITN], Position.L1)
    scale_a = Tensor(DT.uint8, [M_TRANSPOSE, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    scale_b = Tensor(DT.uint8, [N_TRANSPOSE_SPLITN, 2 * CeilDiv(K_TRANSPOSE, 64)], Position.L1)
    l0c = Tensor(DT.float, [M_TRANSPOSE, N_TRANSPOSE_SPLITN], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y_kn[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_pad(
            scale_b,
            scale_b_gm,
            n_burst=CeilDiv(N_TRANSPOSE_SPLITN, 16) * CeilDiv(K_TRANSPOSE, 64),
            burst_len_element=32,
            src_stride_element=0,
            dst_stride=0,
        )
        matmul_mx(
            l0c,
            l1a,
            l1b.T,
            scale_a,
            scale_b,
            splitn=32,
            m=M_TRANSPOSE,
            n=N_TRANSPOSE_SPLITN,
            k=K_TRANSPOSE,
            is_init=True,
        )
        z[:, :] <<= l0c
    return z


def test_l1_to_l0_mx_loads_l0a_data_and_scale_buffer() -> None:
    src = _nz_u8_tile()
    dst = torch.zeros_like(src)
    scale = torch.arange(64, dtype=torch.uint8)
    pipe = _pipe({"dst": dst, "src": src, "scale": scale})

    pipe.execute(PipeTask("MTE1", "l1_to_l0_mx", {
        "dst": "dst",
        "src": "src",
        "src_mx": "scale",
        "m_dst": 16,
        "n_dst": 64,
        "m_src": 16,
        "n_src": 64,
        "dst_position": "L0A",
    }))

    torch.testing.assert_close(pipe.memory_store.tensor("dst"), src)
    l0amx = pipe.memory_store.tensor(L0AMX_BUFFER_NAME)
    torch.testing.assert_close(l0amx[:32], scale[:32])
    assert torch.count_nonzero(l0amx[32:]).item() == 0


def test_l1_to_l0_mx_fp4_copies_packed_payload_and_scale() -> None:
    logical = (torch.arange(16 * 64, dtype=torch.uint8).reshape(16, 64) % 16)
    src = _nz_fp4_tile(logical)
    dst = torch.zeros(nz_footprint(32, align16(16), 32), dtype=torch.uint8)
    scale = torch.arange(64, dtype=torch.uint8)
    pipe = _pipe({"dst:fp4_e2m1:axis1": dst, "src:fp4_e2m1:axis1": src, "scale": scale})

    pipe.execute(PipeTask("MTE1", "l1_to_l0_mx", {
        "dst": "dst:fp4_e2m1:axis1",
        "src": "src:fp4_e2m1:axis1",
        "src_mx": "scale",
        "m_dst": 16,
        "n_dst": 64,
        "m_src": 16,
        "n_src": 64,
        "dst_position": "L0A",
    }))

    decoded_carrier = decode_nz_to_nd(pipe.memory_store.tensor("dst:fp4_e2m1:axis1"), 16, 32, align16(16), 32)
    torch.testing.assert_close(decoded_carrier, _pack_fp4_cols(logical))
    l0amx = pipe.memory_store.tensor(L0AMX_BUFFER_NAME)
    torch.testing.assert_close(l0amx[:32], scale[:32])


def test_l1_to_l0_mx_uses_scale_slice_offset_for_l0bmx() -> None:
    src = _nz_u8_tile()
    dst = torch.zeros_like(src)
    scale = torch.arange(64, dtype=torch.uint8)
    pipe = _pipe({"dst": dst, "src": src, "scale": scale})

    pipe.execute(PipeTask("MTE1", "l1_to_l0_mx", {
        "dst": "dst",
        "src": "src",
        "src_mx": "scale",
        "m_dst": 16,
        "n_dst": 64,
        "m_src": 16,
        "n_src": 64,
        "src_mx_col0": 2,
        "dst_position": "L0B",
    }))

    l0bmx = pipe.memory_store.tensor(L0BMX_BUFFER_NAME)
    torch.testing.assert_close(l0bmx[:32], scale[32:64])
    assert torch.count_nonzero(l0bmx[32:]).item() == 0


def test_l1_to_l0_mx_transpose_gathers_scale_by_row_tile_and_k_block() -> None:
    dtype = _require_float8_e4m3()
    m_src, n_src, valid_k = 128, 32, 64
    logical_kn = (((torch.arange(m_src * n_src, dtype=torch.float32).reshape(m_src, n_src) * 3) % 19) - 9.0) / 8.0
    src = _nz_fp8_tile(logical_kn)
    dst = torch.zeros(nz_footprint(valid_k, align16(n_src), 32), dtype=dtype)
    scale_values = torch.arange(n_src * 4, dtype=torch.uint8).reshape(n_src, 4)
    scale = _pack_mx_scale(scale_values, m_src)
    pipe = _pipe({"dst": dst, "src": src, "scale": scale})

    pipe.execute(PipeTask("MTE1", "l1_to_l0_mx", {
        "dst": "dst",
        "src": "src",
        "src_mx": "scale",
        "m_dst": valid_k,
        "n_dst": n_src,
        "m_src": m_src,
        "n_src": n_src,
        "src_row0": 64,
        "src_mx_offset_element": 32,
        "src_is_transpose": True,
        "dst_position": "L0B",
    }))

    expected_b = logical_kn[64:128, :].transpose(0, 1).to(dtype)
    decoded_b = decode_nz_to_nd(pipe.memory_store.tensor("dst"), n_src, valid_k, align16(n_src), 32)
    torch.testing.assert_close(decoded_b, expected_b.to(torch.float32))

    expected_scale = _pack_mx_scale(scale_values[:, 2:4], valid_k)
    l0bmx = pipe.memory_store.tensor(L0BMX_BUFFER_NAME)
    torch.testing.assert_close(l0bmx[: expected_scale.numel()], expected_scale)
    assert torch.count_nonzero(l0bmx[expected_scale.numel() :]).item() == 0


def test_mmad_mx_identity_scale_matches_float8_matmul() -> None:
    m, n, k = 16, 16, 64
    a = ((torch.arange(m * k, dtype=torch.float32).reshape(m, k) % 9) - 4.0) / 4.0
    b = ((torch.arange(n * k, dtype=torch.float32).reshape(n, k) % 7) - 3.0) / 5.0
    src_a = _nz_fp8_tile(a)
    src_b = _nz_fp8_tile(b)
    dst = torch.zeros(nz_footprint(n, align16(m), 16), dtype=torch.float32)
    scale_a = _pack_mx_scale(torch.full((m, 2), 127, dtype=torch.uint8), k)
    scale_b = _pack_mx_scale(torch.full((n, 2), 127, dtype=torch.uint8), k)
    pipe = _mpipe({"dst": dst, "a": src_a, "b": src_b, L0AMX_BUFFER_NAME: scale_a, L0BMX_BUFFER_NAME: scale_b})

    pipe.execute(PipeTask("M", "mmad_mx", {"dst": "dst", "src_a": "a", "src_b": "b", "M": m, "N": n, "K": k}))

    a_q = decode_nz_to_nd(src_a, m, k, align16(m), 32).to(torch.float32)
    b_q = decode_nz_to_nd(src_b, n, k, align16(n), 32).to(torch.float32)
    torch.testing.assert_close(_decode_l0c(dst, m, n), torch.matmul(a_q, b_q.transpose(0, 1)))


def test_mmad_mx_fp4_decodes_e2m1_and_e1m2_sources() -> None:
    m, n, k = 16, 16, 64
    a_nibbles = (torch.arange(m * k, dtype=torch.uint8).reshape(m, k) % 16)
    b_nibbles = ((torch.arange(n * k, dtype=torch.uint8).reshape(n, k) * 3 + 1) % 16)
    src_a = _nz_fp4_tile(a_nibbles)
    src_b = _nz_fp4_tile(b_nibbles)
    dst = torch.zeros(nz_footprint(n, align16(m), 16), dtype=torch.float32)
    scale_a_values = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_b_values = torch.full((n, 2), 127, dtype=torch.uint8)
    pipe = _mpipe({
        "dst": dst,
        "a:fp4_e2m1:axis1": src_a,
        "b:fp4_e1m2:axis1": src_b,
        L0AMX_BUFFER_NAME: _pack_mx_scale(scale_a_values, k),
        L0BMX_BUFFER_NAME: _pack_mx_scale(scale_b_values, k),
    })

    pipe.execute(PipeTask("M", "mmad_mx", {
        "dst": "dst",
        "src_a": "a:fp4_e2m1:axis1",
        "src_b": "b:fp4_e1m2:axis1",
        "M": m,
        "N": n,
        "K": k,
    }))

    expected = torch.matmul(
        _fp4_values(a_nibbles, "fp4_e2m1"),
        _fp4_values(b_nibbles, "fp4_e1m2").transpose(0, 1),
    )
    torch.testing.assert_close(_decode_l0c(dst, m, n), expected)


def test_mmad_mx_fp4_e2m1_e2m1_has_no_extra_product_factor() -> None:
    m, n, k = 16, 16, 64
    a_nibbles = (torch.arange(m * k, dtype=torch.uint8).reshape(m, k) % 16)
    b_nibbles = ((torch.arange(n * k, dtype=torch.uint8).reshape(n, k) * 5 + 2) % 16)
    src_a = _nz_fp4_tile(a_nibbles)
    src_b = _nz_fp4_tile(b_nibbles)
    dst = torch.zeros(nz_footprint(n, align16(m), 16), dtype=torch.float32)
    scale_a_values = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_b_values = torch.full((n, 2), 127, dtype=torch.uint8)
    pipe = _mpipe({
        "dst": dst,
        "a:fp4_e2m1:axis1": src_a,
        "b:fp4_e2m1:axis1": src_b,
        L0AMX_BUFFER_NAME: _pack_mx_scale(scale_a_values, k),
        L0BMX_BUFFER_NAME: _pack_mx_scale(scale_b_values, k),
    })

    pipe.execute(PipeTask("M", "mmad_mx", {
        "dst": "dst",
        "src_a": "a:fp4_e2m1:axis1",
        "src_b": "b:fp4_e2m1:axis1",
        "M": m,
        "N": n,
        "K": k,
    }))

    expected = torch.matmul(
        _fp4_values(a_nibbles, "fp4_e2m1"),
        _fp4_values(b_nibbles, "fp4_e2m1").transpose(0, 1),
    )
    torch.testing.assert_close(_decode_l0c(dst, m, n), expected)


def test_mmad_mx_fp4_e1m2_e1m2_uses_scaled_codebook() -> None:
    m, n, k = 16, 16, 64
    a_nibbles = (torch.arange(m * k, dtype=torch.uint8).reshape(m, k) % 16)
    b_nibbles = ((torch.arange(n * k, dtype=torch.uint8).reshape(n, k) * 7 + 3) % 16)
    src_a = _nz_fp4_tile(a_nibbles)
    src_b = _nz_fp4_tile(b_nibbles)
    dst = torch.zeros(nz_footprint(n, align16(m), 16), dtype=torch.float32)
    scale_a_values = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_b_values = torch.full((n, 2), 127, dtype=torch.uint8)
    pipe = _mpipe({
        "dst": dst,
        "a:fp4_e1m2:axis1": src_a,
        "b:fp4_e1m2:axis1": src_b,
        L0AMX_BUFFER_NAME: _pack_mx_scale(scale_a_values, k),
        L0BMX_BUFFER_NAME: _pack_mx_scale(scale_b_values, k),
    })

    pipe.execute(PipeTask("M", "mmad_mx", {
        "dst": "dst",
        "src_a": "a:fp4_e1m2:axis1",
        "src_b": "b:fp4_e1m2:axis1",
        "M": m,
        "N": n,
        "K": k,
    }))

    expected = torch.matmul(
        _fp4_values(a_nibbles, "fp4_e1m2"),
        _fp4_values(b_nibbles, "fp4_e1m2").transpose(0, 1),
    )
    torch.testing.assert_close(_decode_l0c(dst, m, n), expected)


def test_mxfp4_matmul_shortcut_op_exec_outputs_fp32_gm() -> None:
    m, n, k = 16, 16, 64
    a_nibbles = (torch.arange(m * k, dtype=torch.uint8).reshape(m, k) % 16)
    b_nibbles = ((torch.arange(n * k, dtype=torch.uint8).reshape(n, k) * 5 + 2) % 16)
    x = _pack_fp4_cols(a_nibbles)
    y = _pack_fp4_cols(b_nibbles)
    scale_a_values = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_b_values = torch.full((n, 2), 127, dtype=torch.uint8)
    scale_a_gm = _pack_mx_scale(scale_a_values, k).reshape(1, 32)
    scale_b_gm = _pack_mx_scale(scale_b_values, k).reshape(1, 32)
    z = torch.zeros((m, n), dtype=torch.float32)

    out = OpExec(_mxfp4_matmul_shortcut_sim_kernel, simulator=True)(
        x, y, scale_a_gm, scale_b_gm, z, 0,
    )

    expected = torch.matmul(
        _fp4_values(a_nibbles, "fp4_e2m1"),
        _fp4_values(b_nibbles, "fp4_e1m2").transpose(0, 1),
    )
    torch.testing.assert_close(out, expected)


def test_mxfp4_dense_scale_low_level_op_exec_outputs_fp32_gm() -> None:
    m, n, k = 32, 32, 128
    scale_groups = (k + 31) // 32
    a_nibbles = (torch.arange(m * k, dtype=torch.uint8).reshape(m, k) % 16)
    b_nibbles = ((torch.arange(n * k, dtype=torch.uint8).reshape(n, k) * 5 + 2) % 16)
    x = _pack_fp4_cols(a_nibbles)
    y = _pack_fp4_cols(b_nibbles)
    scale_a_gm = _make_scale(m, scale_groups, 0)
    scale_b_gm = _make_scale(n, scale_groups, 1)
    z = torch.zeros((m, n), dtype=torch.float32)

    out = OpExec(_mxfp4_dense_scale_low_level_sim_kernel, simulator=True)(
        x, y, scale_a_gm, scale_b_gm, z, 0,
    )

    a_q = fp4_e2m1_to_fp32(x, logical_shape=(m, k), pack_axis=-1)
    b_q = fp4_e1m2_to_fp32(y, logical_shape=(n, k), pack_axis=-1)
    expected = torch.matmul(
        a_q * _expand_scale(scale_a_gm, k),
        (b_q * _expand_scale(scale_b_gm, k)).transpose(0, 1),
    )
    torch.testing.assert_close(out, expected, rtol=1e-5, atol=1e-5)


def test_mmad_mx_applies_e8m0_scale_groups() -> None:
    m, n, k = 16, 16, 64
    a = ((torch.arange(m * k, dtype=torch.float32).reshape(m, k) % 11) - 5.0) / 8.0
    b = ((torch.arange(n * k, dtype=torch.float32).reshape(n, k) % 13) - 6.0) / 8.0
    src_a = _nz_fp8_tile(a)
    src_b = _nz_fp8_tile(b)
    dst = torch.zeros(nz_footprint(n, align16(m), 16), dtype=torch.float32)
    scale_a_values = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_a_values[:, 0] = 128
    scale_a_values[:, 1] = 126
    scale_b_values = torch.full((n, 2), 127, dtype=torch.uint8)
    pipe = _mpipe({
        "dst": dst,
        "a": src_a,
        "b": src_b,
        L0AMX_BUFFER_NAME: _pack_mx_scale(scale_a_values, k),
        L0BMX_BUFFER_NAME: _pack_mx_scale(scale_b_values, k),
    })

    pipe.execute(PipeTask("M", "mmad_mx", {"dst": "dst", "src_a": "a", "src_b": "b", "M": m, "N": n, "K": k}))

    a_q = decode_nz_to_nd(src_a, m, k, align16(m), 32).to(torch.float32)
    b_q = decode_nz_to_nd(src_b, n, k, align16(n), 32).to(torch.float32)
    expected = torch.matmul(
        a_q * _expand_scale(scale_a_values, k),
        (b_q * _expand_scale(scale_b_values, k)).transpose(0, 1),
    )
    torch.testing.assert_close(_decode_l0c(dst, m, n), expected)


def test_mmad_mx_accumulates_l0c_for_splitk_chunks() -> None:
    m, n, chunk_k = 16, 16, 64
    total_k = 128
    a = ((torch.arange(m * total_k, dtype=torch.float32).reshape(m, total_k) % 17) - 8.0) / 8.0
    b = ((torch.arange(n * total_k, dtype=torch.float32).reshape(n, total_k) % 19) - 9.0) / 8.0
    src_a0 = _nz_fp8_tile(a[:, :chunk_k])
    src_b0 = _nz_fp8_tile(b[:, :chunk_k])
    src_a1 = _nz_fp8_tile(a[:, chunk_k:])
    src_b1 = _nz_fp8_tile(b[:, chunk_k:])
    dst = torch.zeros(nz_footprint(n, align16(m), 16), dtype=torch.float32)
    scale_a0 = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_b0 = torch.full((n, 2), 127, dtype=torch.uint8)
    scale_a1 = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_b1 = torch.full((n, 2), 127, dtype=torch.uint8)
    scale_a0[:, 1] = 128
    scale_b1[:, 0] = 126
    pipe = _mpipe({
        "dst": dst,
        "a0": src_a0,
        "b0": src_b0,
        L0AMX_BUFFER_NAME: _pack_mx_scale(scale_a0, chunk_k),
        L0BMX_BUFFER_NAME: _pack_mx_scale(scale_b0, chunk_k),
    })

    pipe.execute(PipeTask("M", "mmad_mx", {"dst": "dst", "src_a": "a0", "src_b": "b0", "M": m, "N": n, "K": chunk_k}))
    pipe.memory_store._tensors["a1"] = src_a1
    pipe.memory_store._tensors["b1"] = src_b1
    pipe.memory_store._tensors[L0AMX_BUFFER_NAME] = _pack_mx_scale(scale_a1, chunk_k)
    pipe.memory_store._tensors[L0BMX_BUFFER_NAME] = _pack_mx_scale(scale_b1, chunk_k)
    pipe.execute(PipeTask("M", "mmad_mx", {
        "dst": "dst", "src_a": "a1", "src_b": "b1",
        "M": m, "N": n, "K": chunk_k, "is_init": False,
    }))

    a0_q = decode_nz_to_nd(src_a0, m, chunk_k, align16(m), 32).to(torch.float32)
    b0_q = decode_nz_to_nd(src_b0, n, chunk_k, align16(n), 32).to(torch.float32)
    a1_q = decode_nz_to_nd(src_a1, m, chunk_k, align16(m), 32).to(torch.float32)
    b1_q = decode_nz_to_nd(src_b1, n, chunk_k, align16(n), 32).to(torch.float32)
    expected = torch.matmul(
        a0_q * _expand_scale(scale_a0, chunk_k),
        (b0_q * _expand_scale(scale_b0, chunk_k)).transpose(0, 1),
    )
    expected += torch.matmul(
        a1_q * _expand_scale(scale_a1, chunk_k),
        (b1_q * _expand_scale(scale_b1, chunk_k)).transpose(0, 1),
    )
    torch.testing.assert_close(_decode_l0c(dst, m, n), expected)


def test_mmad_mx_preserves_previous_l0c_columns_for_splitn_slices() -> None:
    m, n_total, split_n, k = 16, 32, 16, 64
    a = ((torch.arange(m * k, dtype=torch.float32).reshape(m, k) % 9) - 4.0) / 6.0
    b = ((torch.arange(n_total * k, dtype=torch.float32).reshape(n_total, k) % 15) - 7.0) / 8.0
    src_a = _nz_fp8_tile(a)
    src_b0 = _nz_fp8_tile(b[:split_n, :])
    src_b1 = _nz_fp8_tile(b[split_n:, :])
    dst = torch.zeros(nz_footprint(n_total, align16(m), 16), dtype=torch.float32)
    scale_a_values = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_b_values = torch.full((split_n, 2), 127, dtype=torch.uint8)
    pipe = _mpipe({
        "dst": dst,
        "a": src_a,
        "b0": src_b0,
        L0AMX_BUFFER_NAME: _pack_mx_scale(scale_a_values, k),
        L0BMX_BUFFER_NAME: _pack_mx_scale(scale_b_values, k),
    })

    pipe.execute(PipeTask("M", "mmad_mx", {
        "dst": "dst", "src_a": "a", "src_b": "b0",
        "M": m, "N": split_n, "K": k, "dst_cols": n_total,
    }))
    pipe.memory_store._tensors["b1"] = src_b1
    pipe.memory_store._tensors[L0BMX_BUFFER_NAME] = _pack_mx_scale(scale_b_values, k)
    pipe.execute(PipeTask("M", "mmad_mx", {
        "dst": "dst", "src_a": "a", "src_b": "b1", "M": m, "N": split_n, "K": k,
        "dst_col0": split_n, "dst_cols": n_total,
    }))

    a_q = decode_nz_to_nd(src_a, m, k, align16(m), 32).to(torch.float32)
    b_q0 = decode_nz_to_nd(src_b0, split_n, k, align16(split_n), 32).to(torch.float32)
    b_q1 = decode_nz_to_nd(src_b1, split_n, k, align16(split_n), 32).to(torch.float32)
    expected = torch.cat((
        torch.matmul(a_q, b_q0.transpose(0, 1)),
        torch.matmul(a_q, b_q1.transpose(0, 1)),
    ), dim=1)
    torch.testing.assert_close(_decode_l0c(dst, m, n_total), expected)


def test_matmul_mx_shortcut_simulator_end_to_end_with_external_scale() -> None:
    dtype = _require_float8_e4m3()
    m, n, k = 16, 16, 64
    a = (((torch.arange(m * k, dtype=torch.float32).reshape(m, k) * 3) % 17) - 8.0) / 8.0
    b = (((torch.arange(n * k, dtype=torch.float32).reshape(n, k) * 5) % 19) - 9.0) / 8.0
    scale_a_values = torch.full((m, 2), 127, dtype=torch.uint8)
    scale_b_values = torch.full((n, 2), 127, dtype=torch.uint8)
    scale_a_values[:, 1] = 128
    scale_b_values[:, 0] = 126

    x = a.to(dtype)
    y = b.to(dtype)
    scale_a_gm = _pack_mx_scale(scale_a_values, k).reshape(1, 32)
    scale_b_gm = _pack_mx_scale(scale_b_values, k).reshape(1, 32)
    z = torch.zeros((m, n), dtype=torch.float32)

    out = OpExec(_mx_matmul_shortcut_sim_kernel, simulator=True)(
        x, y, scale_a_gm, scale_b_gm, z, m, n, k,
        shape_bindings={0: [0, 2], 1: [1, 2], 2: [None, None], 3: [None, None], 4: [0, 1]},
    )

    expected = torch.matmul(
        x.to(torch.float32) * _expand_scale(scale_a_values, k),
        (y.to(torch.float32) * _expand_scale(scale_b_values, k)).transpose(0, 1),
    )
    torch.testing.assert_close(out, expected, rtol=1e-5, atol=1e-5)


@pytest.mark.parametrize(
    "kernel_fn,m,n,k,a_transpose,b_transpose",
    [
        (_mx_matmul_nosplit_fixed_sim_kernel, M_TRANSPOSE, M_TRANSPOSE, K_TRANSPOSE, False, False),
        (_mx_matmul_splitk_shortcut_sim_kernel, M_TRANSPOSE, M_TRANSPOSE, K_TRANSPOSE_SPLITK, False, False),
        (_mx_matmul_splitn_shortcut_sim_kernel, M_TRANSPOSE, N_A_TRANSPOSE_SPLITN, K_TRANSPOSE, False, False),
        (_mx_matmul_transpose_shortcut_sim_kernel, M_TRANSPOSE, N_TRANSPOSE, K_TRANSPOSE, False, True),
        (_mx_matmul_transpose_wide_k_shortcut_sim_kernel, M_TRANSPOSE, N_TRANSPOSE, K_TRANSPOSE_SPLITK, False, True),
        (_mx_matmul_transpose_splitk_shortcut_sim_kernel, M_TRANSPOSE, N_TRANSPOSE, K_TRANSPOSE_SPLITK, False, True),
        (_mx_matmul_transpose_splitn_shortcut_sim_kernel, M_TRANSPOSE, N_TRANSPOSE_SPLITN, K_TRANSPOSE, False, True),
        (_mx_matmul_transposed_a_shortcut_sim_kernel, M_A_TRANSPOSE, N_A_TRANSPOSE, K_TRANSPOSE, True, False),
        (_mx_matmul_transposed_a_splitk_shortcut_sim_kernel, M_A_TRANSPOSE, N_A_TRANSPOSE, K_TRANSPOSE_SPLITK, True, False),
        (_mx_matmul_transposed_a_splitn_shortcut_sim_kernel, M_A_TRANSPOSE, N_A_TRANSPOSE_SPLITN, K_TRANSPOSE, True, False),
        (_mx_matmul_both_transposed_shortcut_sim_kernel, M_BOTH_TRANSPOSE, N_BOTH_TRANSPOSE, K_TRANSPOSE, True, True),
        (_mx_matmul_both_transposed_splitk_shortcut_sim_kernel, M_BOTH_TRANSPOSE, N_BOTH_TRANSPOSE, K_TRANSPOSE_SPLITK, True, True),
        (_mx_matmul_both_transposed_splitn_shortcut_sim_kernel, M_BOTH_TRANSPOSE, N_BOTH_TRANSPOSE_SPLITN, K_TRANSPOSE, True, True),
    ],
)
def test_matmul_mx_shortcut_simulator_transpose_split_matrix(kernel_fn, m, n, k, a_transpose, b_transpose) -> None:
    dtype = _require_float8_e4m3()
    if a_transpose:
        a_physical = (((torch.arange(k * m, dtype=torch.float32).reshape(k, m) * 3) % 17) - 8.0) / 8.0
        a_logical = a_physical.transpose(0, 1).contiguous()
    else:
        a_physical = (((torch.arange(m * k, dtype=torch.float32).reshape(m, k) * 3) % 17) - 8.0) / 8.0
        a_logical = a_physical
    if b_transpose:
        b_physical = (((torch.arange(k * n, dtype=torch.float32).reshape(k, n) * 5) % 19) - 9.0) / 8.0
        b_logical = b_physical.transpose(0, 1).contiguous()
    else:
        b_physical = (((torch.arange(n * k, dtype=torch.float32).reshape(n, k) * 5) % 19) - 9.0) / 8.0
        b_logical = b_physical
    x = a_physical.to(dtype)
    y = b_physical.to(dtype)
    scale_a_values = _make_scale(m, (k + 31) // 32, 0)
    scale_b_values = _make_scale(n, (k + 31) // 32, 1)
    scale_a_gm = _pack_mx_scale(scale_a_values, k).reshape(-1, 32)
    scale_b_gm = _pack_mx_scale(scale_b_values, k).reshape(-1, 32)
    z = torch.zeros((m, n), dtype=torch.float32)

    out = OpExec(kernel_fn, simulator=True)(x, y, scale_a_gm, scale_b_gm, z, 0)
    expected = _mx_ref(a_logical.to(dtype), b_logical.to(dtype), scale_a_values, scale_b_values, k)
    torch.testing.assert_close(out, expected, rtol=1e-5, atol=1e-5)
