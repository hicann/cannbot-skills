import pytest
import torch

from easyasc import globvars
from easyasc.simulator.pipe_cube import CubeMTE1Pipe, CubeMTE2Pipe
from easyasc.simulator.pipe_vec import MTE3Pipe, VecMTE2Pipe
from easyasc.simulator.program import PipeTask


class _TensorStore(object):
    def __init__(self, tensors=None):
        self._tensors = dict(tensors or {})

    def tensor(self, name):
        return self._tensors[name]


@pytest.mark.parametrize(
    "pipe_cls, opname, args, message",
    [
        (
            CubeMTE2Pipe,
            "gm_to_l1_nd2nz",
            {"dst": "dst", "src": "src", "M": 8, "N": 8, "N_src": 8},
            "gm_to_l1_nd2nz requires dst/src data types to match",
        ),
        (
            VecMTE2Pipe,
            "gm_to_ub_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 1,
                "burst_len_byte": 32,
                "src_stride_byte": 0,
                "dst_stride": 0,
            },
            "gm_to_ub_pad requires dst/src data types to match",
        ),
        (
            MTE3Pipe,
            "ub_to_gm_pad",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 1,
                "burst_len_byte": 32,
                "dst_stride_byte": 0,
                "src_stride": 0,
            },
            "ub_to_gm_pad requires dst/src data types to match",
        ),
        (
            MTE3Pipe,
            "ub_to_l1",
            {
                "dst": "dst",
                "src": "src",
                "n_burst": 1,
                "burst_len": 1,
                "src_stride": 0,
                "dst_stride": 0,
            },
            "ub_to_l1 requires dst/src data types to match",
        ),
    ],
)
def test_datamove_pipes_reject_dtype_mismatch(pipe_cls, opname: str, args, message: str) -> None:
    pipe = object.__new__(pipe_cls)
    pipe.memory_store = _TensorStore(
        {
            "dst": torch.zeros(256, dtype=torch.float32),
            "src": torch.zeros(256, dtype=torch.float16),
        }
    )

    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        with pytest.raises(ValueError, match=message):
            pipe.execute(PipeTask(pipe_name="X", opname=opname, args=args))
    finally:
        globvars.device_type = saved_device_type


def test_a5_set_constant_to_l1_rejects_64_bit_dtype() -> None:
    # 8-bit fills are legal on A5 -- InitConstValue is a plain template over the
    # tensor dtype, and shipped kernels zero L1 through a .reinterpret(uint8)
    # view on hardware. Only the 64-bit widths stay rejected.
    pipe = object.__new__(CubeMTE2Pipe)
    pipe.memory_store = _TensorStore({"dst": torch.zeros(64, dtype=torch.int64)})

    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        with pytest.raises(
            RuntimeError,
            match="set_constant_to_l1 on A5 does not support tensor dtype torch.int64",
        ):
            pipe.execute(PipeTask(
                pipe_name="MTE2", opname="set_constant_to_l1",
                args={"tensor": "dst", "n_blocks": 2, "val": 7},
            ))
    finally:
        globvars.device_type = saved_device_type


def test_a5_set_constant_to_l1_accepts_uint8() -> None:
    dst = torch.zeros(64, dtype=torch.uint8)
    pipe = object.__new__(CubeMTE2Pipe)
    pipe.memory_store = _TensorStore({"dst": dst})

    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        pipe.execute(PipeTask(
            pipe_name="MTE2", opname="set_constant_to_l1",
            args={"tensor": "dst", "n_blocks": 2, "val": 7},
        ))
    finally:
        globvars.device_type = saved_device_type
    assert int(dst[0].item()) == 7


def test_a5_set_constant_to_l1_accepts_uint16() -> None:
    dst = torch.zeros(64, dtype=torch.uint16)
    pipe = object.__new__(CubeMTE2Pipe)
    pipe.memory_store = _TensorStore({"dst": dst})

    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        pipe.execute(PipeTask(
            pipe_name="MTE2", opname="set_constant_to_l1",
            args={"tensor": "dst", "n_blocks": 2, "val": 7},
        ))
    finally:
        globvars.device_type = saved_device_type

    torch.testing.assert_close(dst[:32], torch.full((32,), 7, dtype=torch.uint16))
    torch.testing.assert_close(dst[32:], torch.zeros(32, dtype=torch.uint16))


@pytest.mark.parametrize(
    "args",
    [
        {
            "dst": "dst", "src": "src", "m_dst": 256, "n_dst": 1,
            "m_src": 256, "n_src": 512, "src_row0": 0, "src_col0": 256,
            "src_is_transpose": False, "dst_position": "L0A",
        },
        {
            "dst": "dst", "src": "src", "m_dst": 1, "n_dst": 128,
            "m_src": 512, "n_src": 128, "src_row0": 256, "src_col0": 0,
            "src_is_transpose": True, "dst_position": "L0B",
        },
    ],
)
def test_a5_l1_to_l0_rejects_nonzero_offset_byte_tail(args) -> None:
    pipe = object.__new__(CubeMTE1Pipe)
    pipe.memory_store = _TensorStore({
        "dst": torch.zeros(32768, dtype=torch.int8),
        "src": torch.zeros(131072, dtype=torch.int8),
    })

    saved_device_type = globvars.device_type
    globvars.device_type = "950"
    try:
        with pytest.raises(
            RuntimeError,
            match="l1_to_l0 on A5 requires a nonzero-offset byte tail to be C0-aligned",
        ):
            pipe.execute(PipeTask(
                pipe_name="MTE1", opname="l1_to_l0", args=args,
            ))
    finally:
        globvars.device_type = saved_device_type
