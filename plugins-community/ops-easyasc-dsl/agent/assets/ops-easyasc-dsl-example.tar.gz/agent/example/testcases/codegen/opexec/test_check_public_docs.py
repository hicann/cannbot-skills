import json
from pathlib import Path

from agent.scripts.check_public_docs import analyze_repo


ROOT = Path(__file__).resolve().parents[5]


def _manifest():
    return {
        "schema_version": 1,
        "docs": {
            "path_parity": {"english_only": [], "chinese_only": []},
            "navigation": {
                "english": {
                    "root": "README.md",
                    "index": "doc/index.md",
                    "doc_root": "doc",
                    "unreachable_allowlist": [],
                    "orphan_allowlist": [],
                },
                "chinese": {
                    "root": "README_CN.md",
                    "index": "doc_cn/index.md",
                    "doc_root": "doc_cn",
                    "unreachable_allowlist": [],
                    "orphan_allowlist": [],
                },
            },
            "contracts": {"id_strategy": "relative_path", "overrides": {}},
        },
        "public_api": {
            "groups": {
                "shared": ["Api", "add", "shared_stub"],
                "a2_only": [],
                "a5_family_only": ["A5Api", "a5_only", "micro"],
            },
            "facades": {
                "a2": {
                    "source": "easyasc/a2.py",
                    "groups": ["shared", "a2_only"],
                    "exclude": ["globvars"],
                },
                "a3": {
                    "source": "easyasc/a3.py",
                    "inherits": "a2",
                    "groups": ["shared", "a2_only"],
                    "exclude": ["globvars"],
                },
                "a5": {
                    "source": "easyasc/a5.py",
                    "groups": ["shared", "a5_family_only"],
                    "exclude": ["globvars"],
                },
                "a5pr": {
                    "source": "easyasc/a5pr.py",
                    "inherits": "a5",
                    "groups": ["shared", "a5_family_only"],
                    "exclude": ["globvars"],
                },
            },
        },
        "stub_to_codegen": {
            "mode": "public_stub_name_presence",
            "documents": [
                "doc/12_stub_to_codegen_name_map.md",
                "doc_cn/12_stub_to_codegen_name_map.md",
            ],
            "facades": ["a2", "a5"],
            "exclusions": {"a2": [], "a5": ["micro"]},
        },
    }


def _stub_map() -> str:
    return """# Stub map

| Helper | Generated name |
| --- | --- |
| `add`, `shared_stub` | shared |
| `a5_only` | a5 |
"""


def _write_fixture(root: Path) -> Path:
    (root / "doc").mkdir(parents=True)
    (root / "doc_cn").mkdir(parents=True)
    (root / "easyasc").mkdir(parents=True)
    (root / "agent" / "scripts" / "data").mkdir(parents=True)

    (root / "README.md").write_text("[Documentation](doc/index.md)\n", encoding="utf-8")
    (root / "README_CN.md").write_text("[文档](doc_cn/index.md)\n", encoding="utf-8")
    (root / "doc" / "index.md").write_text("[Guide](guide.md)\n", encoding="utf-8")
    (root / "doc" / "guide.md").write_text("[Index](index.md)\n", encoding="utf-8")
    (root / "doc_cn" / "index.md").write_text("[指南](guide.md)\n", encoding="utf-8")
    (root / "doc_cn" / "guide.md").write_text("[索引](index.md)\n", encoding="utf-8")
    (root / "doc" / "12_stub_to_codegen_name_map.md").write_text(_stub_map(), encoding="utf-8")
    (root / "doc_cn" / "12_stub_to_codegen_name_map.md").write_text(_stub_map(), encoding="utf-8")
    (root / "doc" / "index.md").write_text(
        "[Guide](guide.md)\n[Stub map](12_stub_to_codegen_name_map.md)\n", encoding="utf-8"
    )
    (root / "doc_cn" / "index.md").write_text(
        "[指南](guide.md)\n[名字表](12_stub_to_codegen_name_map.md)\n", encoding="utf-8"
    )

    (root / "easyasc" / "a2.py").write_text(
        "from .stub_functions import add, shared_stub\n"
        "from .other import Api\n"
        "from . import globvars\n"
        "globvars.device_type = 'a2'\n",
        encoding="utf-8",
    )
    (root / "easyasc" / "a5.py").write_text(
        "from .stub_functions import add, shared_stub, a5_only, micro\n"
        "from .other import Api, A5Api\n"
        "from . import globvars\n"
        "globvars.device_type = 'a5'\n",
        encoding="utf-8",
    )
    (root / "easyasc" / "a3.py").write_text(
        "from .a2 import *\n"
        "from . import globvars\n"
        "globvars.device_type = 'a3'\n",
        encoding="utf-8",
    )
    (root / "easyasc" / "a5pr.py").write_text(
        "from .a5 import *\n"
        "from . import globvars\n"
        "globvars.device_type = 'a5pr'\n",
        encoding="utf-8",
    )

    manifest_path = root / "agent" / "scripts" / "data" / "public_docs_manifest.json"
    manifest_path.write_text(json.dumps(_manifest(), indent=2), encoding="utf-8")
    return manifest_path


def _codes(root: Path):
    return {warning["code"] for warning in analyze_repo(root)["warnings"]}


def test_public_docs_checker_accepts_consistent_fixture(tmp_path: Path) -> None:
    _write_fixture(tmp_path)
    result = analyze_repo(tmp_path)
    assert result["warnings"] == []
    assert result["stats"]["paired_contract_count"] == 3
    assert result["stats"]["facade_exports"] == {
        "a2": 3, "a3": 3, "a5": 6, "a5pr": 6,
    }
    assert result["stats"]["stub_coverage_mode"] == "public_stub_name_presence"


def test_path_parity_allowlist_is_explicit_and_stale_entries_fail(tmp_path: Path) -> None:
    manifest_path = _write_fixture(tmp_path)
    (tmp_path / "doc_cn" / "guide.md").unlink()
    assert "doc-path-parity" in _codes(tmp_path)

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["docs"]["path_parity"]["english_only"] = ["guide.md"]
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    assert "doc-path-parity" not in _codes(tmp_path)
    assert "stale-parity-allowlist" not in _codes(tmp_path)

    (tmp_path / "doc_cn" / "guide.md").write_text("[索引](index.md)\n", encoding="utf-8")
    assert "stale-parity-allowlist" in _codes(tmp_path)


def test_navigation_requires_readme_index_reachability_and_inbound_links(tmp_path: Path) -> None:
    _write_fixture(tmp_path)
    (tmp_path / "README.md").write_text("[Guide](doc/guide.md)\n", encoding="utf-8")
    assert "navigation-index-not-linked" in _codes(tmp_path)

    (tmp_path / "README.md").write_text("[Documentation](doc/index.md)\n", encoding="utf-8")
    (tmp_path / "doc" / "index.md").write_text(
        "[Stub map](12_stub_to_codegen_name_map.md)\n", encoding="utf-8"
    )
    (tmp_path / "doc" / "guide.md").write_text("# Unlinked guide\n", encoding="utf-8")
    codes = _codes(tmp_path)
    assert {"navigation-unreachable", "navigation-index-unreachable", "navigation-orphan"}.issubset(codes)


def test_facade_surface_manifest_detects_new_exports_and_wrong_inheritance(tmp_path: Path) -> None:
    _write_fixture(tmp_path)
    (tmp_path / "easyasc" / "a2.py").write_text(
        "from .stub_functions import add, shared_stub\n"
        "from .other import Api, undocumented\n"
        "from . import globvars\n",
        encoding="utf-8",
    )
    result = analyze_repo(tmp_path)
    mismatches = [warning for warning in result["warnings"] if warning["code"] == "public-surface-mismatch"]
    assert any("source-only=undocumented" in warning["message"] for warning in mismatches)

    (tmp_path / "easyasc" / "a5pr.py").write_text("from .a2 import *\n", encoding="utf-8")
    assert "facade-inheritance" in _codes(tmp_path)


def test_contract_overrides_and_optional_markers_must_match(tmp_path: Path) -> None:
    manifest_path = _write_fixture(tmp_path)
    (tmp_path / "doc" / "guide.md").write_text(
        "<!-- contract-id: guide.behavior -->\n[Index](index.md)\n", encoding="utf-8"
    )
    assert "contract-marker-mismatch" in _codes(tmp_path)

    (tmp_path / "doc_cn" / "guide.md").write_text(
        "<!-- contract-id: guide.behavior -->\n[索引](index.md)\n", encoding="utf-8"
    )
    assert "contract-marker-mismatch" not in _codes(tmp_path)

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["docs"]["contracts"]["overrides"] = {
        "index.md": "duplicate.id",
        "guide.md": "duplicate.id",
    }
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    assert "contract-id-duplicate" in _codes(tmp_path)


def test_stub_map_requires_exact_first_column_names_not_prose_mentions(tmp_path: Path) -> None:
    _write_fixture(tmp_path)
    misleading = """# Stub map

`shared_stub` appears in prose, but not in a mapping key.

| Helper | Generated name |
| --- | --- |
| `add` | shared |
| `a5_only` | a5 |
"""
    (tmp_path / "doc" / "12_stub_to_codegen_name_map.md").write_text(misleading, encoding="utf-8")
    result = analyze_repo(tmp_path)
    warnings = [warning for warning in result["warnings"] if warning["code"] == "stub-map-coverage"]
    assert warnings
    assert all("shared_stub" in warning["message"] for warning in warnings)
    assert all("micro" not in warning["message"] for warning in warnings)


def test_manifest_cannot_remove_required_facade_or_stub_gates(tmp_path: Path) -> None:
    manifest_path = _write_fixture(tmp_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    del manifest["public_api"]["facades"]["a3"]
    manifest["stub_to_codegen"]["documents"] = []
    manifest["stub_to_codegen"]["facades"] = []
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

    codes = _codes(tmp_path)
    assert "manifest-required-facade" in codes
    assert "stub-map-config" in codes


def test_stub_map_rejects_extra_first_column_drift_between_languages(tmp_path: Path) -> None:
    _write_fixture(tmp_path)
    chinese_map = tmp_path / "doc_cn" / "12_stub_to_codegen_name_map.md"
    chinese_map.write_text(
        _stub_map() + "| `cn_only_extra` | extra |\n", encoding="utf-8"
    )
    assert "stub-map-parity" in _codes(tmp_path)


def test_repository_public_docs_gate() -> None:
    result = analyze_repo(ROOT)
    assert result["warnings"] == []
