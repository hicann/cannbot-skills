"""Codegen + dual-mode gating for the fixpipe scalar requant on l0c_to_ub (L0C->UB, a5-only).

Mirrors test_l0c_to_gm_requant_codegen.py: requant rides on the L0C tensor and the emitted
L0C2UB_NZ2ND call gains the trailing (scale, offset, scaledQuant, hif8Hybrid) args ONLY when
non-default, so plain dual-lane stores stay byte-identical. The fixpipe deqScalar/reluEn are
only available with the dual destination control off (SINGLE), so requant/relu require
dual_mode=SINGLE; SPLITM/SPLITN reject them (and the quant/dequant dtypes).
"""
import pytest

from easyasc.a5 import DT, DualMode, GMTensor, Position, Tensor, Var, kernel, l0c_to_ub
from easyasc.parser.asc import translate_split


@kernel()
def _ub_requant_rider_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    ub = Tensor(DT.int8, [32, 16], Position.UB, name="ub_out")
    ub[:, :] <<= src.requant(scale=0.5, offset=10).subblk(0)   # rider -> SINGLE, explicit subblock
    return out


@kernel()
def _ub_requant_direct_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    ub = Tensor(DT.int8, [32, 16], Position.UB, name="ub_out")
    l0c_to_ub(ub, src, dual_mode=DualMode.SINGLE, sub_block_id=0, scale=0.5, offset=10)
    return out


@kernel()
def _ub_plain_dual_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    ub = Tensor(DT.float, [16, 16], Position.UB, name="ub_out")
    ub <<= src                                         # plain SPLITM cast (no requant)
    return out


@kernel()
def _ub_requant_var_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    ub = Tensor(DT.int8, [32, 16], Position.UB, name="ub_out")
    scl = Var(0.5, name="scl")
    ofs = Var(10, name="ofs")
    l0c_to_ub(ub, src, dual_mode=DualMode.SINGLE, sub_block_id=0, scale=scl, offset=ofs)
    return out


def _l0c_call_line(code: str) -> str:
    lines = [ln for ln in code.splitlines() if "L0C2UB_NZ2ND(" in ln]
    assert len(lines) == 1, f"expected one L0C2UB_NZ2ND call, got {len(lines)}"
    return lines[0]


def test_ub_requant_rider_forces_single_and_emits_quant_args() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.int8, [32, 16], name="out")
    _ub_requant_rider_kernel(inp, out)

    found = [i for i in _ub_requant_rider_kernel.instructions if i.opname == "l0c_to_ub"]
    assert len(found) == 1
    assert found[0].kwargs["dual_mode"] == DualMode.SINGLE.value      # rider forced SINGLE
    assert found[0].kwargs["scale"] == 0.5
    assert found[0].kwargs["offset"] == 10

    cube_code, _ = translate_split(_ub_requant_rider_kernel.instructions, "ub_requant_rider")
    line = _l0c_call_line(cube_code)
    # 13-arg: m, n, n_dst, m_src, dualMode=0(SINGLE), subBlk=0, relu=false, scale, offset,
    # scaledQuant=true, hif8Hybrid=false
    assert ", 32, 16, 16, 32, 0, 0, false, 0.5f, 10, true, false);" in line


def test_ub_requant_direct_single_emits_quant_args() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.int8, [32, 16], name="out")
    _ub_requant_direct_kernel(inp, out)

    cube_code, _ = translate_split(_ub_requant_direct_kernel.instructions, "ub_requant_direct")
    line = _l0c_call_line(cube_code)
    assert ", 32, 16, 16, 32, 0, 0, false, 0.5f, 10, true, false);" in line


def test_ub_plain_store_stays_nine_arg_byte_identical() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.float, [16, 16], name="out")
    _ub_plain_dual_kernel(inp, out)

    cube_code, _ = translate_split(_ub_plain_dual_kernel.instructions, "ub_plain")
    line = _l0c_call_line(cube_code)
    # 9-arg form (dualMode=1 SPLITM, subBlk, relu) -- no requant tail, unchanged from before
    assert line.rstrip().endswith(", 1, 0, false);")
    args = line.split("L0C2UB_NZ2ND(", 1)[1]
    assert "true" not in args                       # no scaledQuant / hif8Hybrid args


def test_ub_requant_var_renders_var_exprs_not_literals() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.int8, [32, 16], name="out")
    _ub_requant_var_kernel(inp, out)

    cube_code, _ = translate_split(_ub_requant_var_kernel.instructions, "ub_requant_var")
    line = _l0c_call_line(cube_code)
    assert "scl" in line and "ofs" in line
    assert "0.5f" not in line


# --------------------------------------------------------------------------------------------
# Dual-mode gating: requant/relu/quant-dtype are SINGLE-only.
# --------------------------------------------------------------------------------------------
def _mk(dst_dtype, src_dtype=DT.float):
    dst = Tensor(dst_dtype, [32, 16], Position.UB, name="ub_out")
    src = Tensor(src_dtype, [32, 16], Position.L0C, name="src_l0c")
    return dst, src


@pytest.mark.parametrize("mode", [DualMode.SPLITM, DualMode.SPLITN])
def test_dual_mode_rejects_requant_params(mode) -> None:
    dst, src = _mk(DT.float)
    with pytest.raises(ValueError, match="require dual_mode=SINGLE"):
        l0c_to_ub(dst, src, dual_mode=mode, scale=0.5)


@pytest.mark.parametrize("mode", [DualMode.SPLITM, DualMode.SPLITN])
def test_dual_mode_rejects_relu(mode) -> None:
    dst, src = _mk(DT.float)
    with pytest.raises(ValueError, match="relu requires dual_mode=SINGLE"):
        l0c_to_ub(dst, src, dual_mode=mode, relu=True)


@pytest.mark.parametrize("mode", [DualMode.SPLITM, DualMode.SPLITN])
def test_dual_mode_rejects_quant_dtype(mode) -> None:
    dst, src = _mk(DT.int8)            # int8 dst needs a deqScalar -> quant -> SINGLE only
    with pytest.raises(ValueError, match="only supports the same-type plain copy"):
        l0c_to_ub(dst, src, dual_mode=mode)


@pytest.mark.parametrize("mode", [DualMode.SPLITM, DualMode.SPLITN])
@pytest.mark.parametrize("dst_dtype", [DT.half, DT.bfloat16])
def test_dual_mode_rejects_float_downcast(mode, dst_dtype) -> None:
    # fp32 -> fp16/bf16 is a deqScalar-free cast, but split mode allows ONLY the same-type
    # fp32 -> fp32 copy; the float downcast must use dual_mode=SINGLE.
    dst, src = _mk(dst_dtype)          # fp32 L0C -> fp16/bf16 UB
    with pytest.raises(ValueError, match="float downcasts"):
        l0c_to_ub(dst, src, dual_mode=mode)


@kernel()
def _ub_split_rows_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 64], Position.L0C, name="src_l0c")
    ub0 = Tensor(DT.int8, [16, 64], Position.UB, name="ub0")
    ub1 = Tensor(DT.int8, [16, 64], Position.UB, name="ub1")
    # split a tall L0C across two SINGLE-mode stores via static row slices
    l0c_to_ub(ub0, src[0:16, :], M=16, N=64, N_dst=64, dual_mode=DualMode.SINGLE, sub_block_id=0, scale=0.5, offset=8)
    l0c_to_ub(ub1, src[16:32, :], M=16, N=64, N_dst=64, dual_mode=DualMode.SINGLE, sub_block_id=0, scale=0.5, offset=8)
    return out


def test_ub_split_rows_emits_static_offsets_and_full_msrc() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.int8, [32, 64], name="out")
    _ub_split_rows_kernel(inp, out)

    found = [i for i in _ub_split_rows_kernel.instructions if i.opname == "l0c_to_ub"]
    assert len(found) == 2
    # M_src is the full L0C height (32) for BOTH stores -- the fractal stride, not the span (16)
    assert found[0].kwargs["M_src"] == 32 and found[1].kwargs["M_src"] == 32

    cube_code, _ = translate_split(_ub_split_rows_kernel.instructions, "ub_split_rows")
    lines = [ln for ln in cube_code.splitlines() if "L0C2UB_NZ2ND(" in ln]
    assert len(lines) == 2
    # first half reads from the L0C base (no row offset); second from row 16 (16 * C0)
    assert "16 * 16" not in lines[0]
    assert "16 * 16" in lines[1]
    # both carry the 13-arg requant tail with M_src=32 as nz_M
    for ln in lines:
        assert ", 16, 64, 64, 32, 0, 0, false, 0.5f, 8, true, false);" in ln


def test_single_mode_allows_requant() -> None:
    dst, src = _mk(DT.int8)
    l0c_to_ub(dst, src, dual_mode=DualMode.SINGLE, sub_block_id=0, scale=0.5, offset=8)   # must not raise


def test_splitm_allows_plain_dual_cast() -> None:
    # SPLITM halves M across the two subblocks, so a 32-row L0C feeds a 16-row UB dst.
    dst = Tensor(DT.float, [16, 16], Position.UB, name="ub_out")
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    l0c_to_ub(dst, src, dual_mode=DualMode.SPLITM)        # plain fp32->fp32 dual cast is fine


def test_splitm_allows_int32_passthrough() -> None:
    # int32 -> int32 is the other same-type plain copy allowed in split mode.
    dst = Tensor(DT.int, [16, 16], Position.UB, name="ub_out")
    src = Tensor(DT.int, [32, 16], Position.L0C, name="src_l0c")
    l0c_to_ub(dst, src, dual_mode=DualMode.SPLITM)        # must not raise
