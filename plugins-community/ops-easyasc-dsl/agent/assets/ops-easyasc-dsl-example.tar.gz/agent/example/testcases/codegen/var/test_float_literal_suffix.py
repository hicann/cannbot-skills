"""Scalar float constants must lower to single-precision C++ float literals
(``5.0f``), not bare ``5.0`` doubles.

A bare ``5.0`` is a *double* literal, so ``vi * 5.0`` promotes the whole
expression to double and narrows back to ``float`` on assignment (also tripping
``-Wdouble-promotion``). The ``f`` suffix keeps scalar math in single precision.
"""
import contextlib
import io

import pytest

from easyasc.a2 import *
from easyasc.parser.asc import translate_split


WIDTH = 64


def _gen(kernel_obj, name):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        cube, vec = translate_split(kernel_obj.instructions, name)
    return cube + "\n" + vec


@kernel()
def _float_literal_scalar_ops(x: GMTensor):
    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    buf <<= x[0:1, 0:WIDTH]
    vi = Var(value=None, dtype=DT.int)       # runtime int -> no const fold
    vf = Var(value=None, dtype=DT.float)     # runtime float
    a = Var(vi * 5.0)         # int-left binary op   (the user's example)
    b = Var(5.0 * vi)         # const-left binary op
    d = Var(vi + 1.5)         # add with float const
    g = Var(Min(vf, 4.0))     # Min with float const
    muls(buf, buf, a)
    adds(buf, buf, b)
    adds(buf, buf, d)
    adds(buf, buf, g)
    x[0:1, 0:WIDTH] <<= buf
    return x


@pytest.mark.easyasc_device("b3")
def test_scalar_float_constants_get_f_suffix() -> None:
    x = GMTensor(DT.float, [1, WIDTH], name="x")
    _float_literal_scalar_ops(x)
    code = _gen(_float_literal_scalar_ops, "float_literal_scalar_ops")

    # Single-precision literals in every operand position / op.
    assert "vi * 5.0f" in code
    assert "5.0f * vi" in code
    assert "vi + 1.5f" in code
    assert "Min(vf, 4.0f)" in code

    # The bare-double forms must not survive.
    assert "vi * 5.0;" not in code
    assert "5.0 * vi" not in code
    assert "vi + 1.5;" not in code
    assert "Min(vf, 4.0)" not in code


@kernel()
def _non_finite_scalar_ops(x: GMTensor):
    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    buf <<= x[0:1, 0:WIDTH]
    dup(buf, float("-inf"))        # the masking idiom: fill with -inf
    adds(buf, buf, float("inf"))   # +inf scalar operand
    muls(buf, buf, float("nan"))   # nan scalar operand
    x[0:1, 0:WIDTH] <<= buf
    return x


@pytest.mark.easyasc_device("b3")
def test_non_finite_scalar_constants_lower_to_builtins() -> None:
    """``inf`` / ``-inf`` / ``nan`` must lower to valid C++ float constant
    expressions, not the bare Python ``repr`` words ``inf`` / ``nan`` (which are
    undeclared identifiers in C++)."""
    x = GMTensor(DT.float, [1, WIDTH], name="x")
    _non_finite_scalar_ops(x)
    code = _gen(_non_finite_scalar_ops, "non_finite_scalar_ops")

    assert "-__builtin_inff()" in code
    assert "__builtin_inff()" in code
    assert '__builtin_nanf("")' in code

    # The bare Python repr spellings must not survive into the C++ source.
    assert "-inf" not in code
    assert "nan" not in code.replace('__builtin_nanf("")', "")


@kernel()
def _float_left_mixed_ops(x: GMTensor):
    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    buf <<= x[0:1, 0:WIDTH]
    vi = Var(value=None, dtype=DT.int)
    vf = Var(value=None, dtype=DT.float)
    p = Var(vf * vi)      # float-Var * int-Var   -> explicit (float) cast
    r = Var(vf * vf)      # float-Var * float-Var -> no cast (already float)
    s = Var(vf * 5.0)     # float-Var * float-lit -> no cast (f-suffix suffices)
    z = Var(vf + 2)       # float-Var + int-lit   -> no cast (literal promotes)
    muls(buf, buf, p)
    muls(buf, buf, r)
    adds(buf, buf, s)
    adds(buf, buf, z)
    x[0:1, 0:WIDTH] <<= buf
    return x


@pytest.mark.easyasc_device("b3")
def test_float_left_casts_only_int_vars() -> None:
    """The (float) widening cast fires only for an integer-Var RHS, not for a
    float Var, float literal, or int literal (which need no cast)."""
    x = GMTensor(DT.float, [1, WIDTH], name="x")
    _float_left_mixed_ops(x)
    code = _gen(_float_left_mixed_ops, "float_left_mixed_ops")

    # int-Var RHS: widening to float made explicit.
    assert "vf * (float) vi" in code
    # float literal RHS: f-suffix only, no redundant cast.
    assert "vf * 5.0f" in code
    # no redundant cast on a float Var, an f-suffixed literal, or an int literal.
    assert "(float) vf" not in code
    assert "(float) 5.0f" not in code
    assert "(float) 2" not in code
