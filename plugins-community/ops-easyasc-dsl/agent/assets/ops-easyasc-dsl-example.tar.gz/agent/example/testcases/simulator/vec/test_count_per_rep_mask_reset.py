import builtins
from types import SimpleNamespace

import pytest
import torch

from easyasc import globvars
from easyasc.a2 import *
from easyasc.stub_functions.vec import vecutils
from easyasc.stub_functions.vec.vecmask import set_mask_by_count

# The compiler requires a non-returned input tensor in the kernel entry;
# this kernel writes its output from a Var alone, so `gate` is never read.
GATE = torch.zeros((1, 1), dtype=torch.float32)


def _build_probe_input() -> torch.Tensor:
    x = torch.zeros((1, 160), dtype=torch.float32)
    for seg in builtins.range(5):
        base = float(seg * 1000)
        x[0, seg * 32 : (seg + 1) * 32] = base + torch.arange(32, dtype=torch.float32)
    return x


def test_dup_count_per_rep_emits_auto_reset_mask() -> None:
    prev_kernel = globvars.active_kernel
    prev_device = globvars.device_type
    fake_kernel = SimpleNamespace(instructions=[], vector_mode="repeat")
    try:
        globvars.device_type = "b3"
        globvars.active_kernel = fake_kernel
        buf = Tensor(DT.float, [1, 64], Position.UB, name="buf")
        dup(buf, 0.0, repeat=1, count_per_rep=32)
        opnames = [inst.opname for inst in fake_kernel.instructions if inst.opname in ("set_mask_by_count", "dup", "reset_mask")]
        assert opnames == ["set_mask_by_count", "dup", "reset_mask"]
    finally:
        globvars.active_kernel = prev_kernel
        globvars.device_type = prev_device


def test_cmax_count_per_rep_emits_auto_reset_mask() -> None:
    prev_kernel = globvars.active_kernel
    prev_device = globvars.device_type
    fake_kernel = SimpleNamespace(instructions=[], vector_mode="repeat")
    try:
        globvars.device_type = "b3"
        globvars.active_kernel = fake_kernel
        src = Tensor(DT.float, [1, 64], Position.UB, name="src")
        dst = Tensor(DT.float, [1, 64], Position.UB, name="dst")
        cmax(dst, src, repeat=1, count_per_rep=32)
        opnames = [inst.opname for inst in fake_kernel.instructions if inst.opname in ("set_mask_by_count", "cmax", "reset_mask")]
        assert opnames == ["set_mask_by_count", "cmax", "reset_mask"]
    finally:
        globvars.active_kernel = prev_kernel
        globvars.device_type = prev_device


def test_count_semantics_reminder_is_global_once(monkeypatch, capsys) -> None:
    monkeypatch.setattr(vecutils, "_count_semantics_warning", True)
    vecutils.apply_vector_mode_transition(96)
    vecutils.apply_vector_mode_transition(None, 32, count_per_rep_limit=64)

    output = capsys.readouterr().out
    assert output.count("A2 vec reminder:") == 1
    assert "count is the total element count" in output
    assert "count_per_rep is the active lane count inside each repeat" in output
    assert "repeat + rep_stride" in output


def test_count_and_count_per_rep_remain_mutually_exclusive() -> None:
    with pytest.raises(ValueError, match="mutually exclusive"):
        vecutils.apply_vector_mode_transition(96, 32, count_per_rep_limit=64)


@pytest.mark.parametrize(
    "dtype,limit",
    [(DT.float, 64), (DT.half, 128)],
)
def test_dup_rejects_static_count_per_rep_above_dtype_lane_limit(dtype, limit) -> None:
    prev_kernel = globvars.active_kernel
    prev_device = globvars.device_type
    fake_kernel = SimpleNamespace(instructions=[], vector_mode="repeat")
    try:
        globvars.device_type = "b3"
        globvars.active_kernel = fake_kernel
        buf = Tensor(dtype, [1, limit], Position.UB, name="buf")
        with pytest.raises(ValueError, match="active lane count inside one repeat"):
            dup(buf, 0.0, repeat=1, count_per_rep=limit + 1)
    finally:
        globvars.active_kernel = prev_kernel
        globvars.device_type = prev_device


def test_cadd_rejects_total_tile_length_as_static_count_per_rep() -> None:
    prev_kernel = globvars.active_kernel
    prev_device = globvars.device_type
    fake_kernel = SimpleNamespace(instructions=[], vector_mode="repeat")
    try:
        globvars.device_type = "b3"
        globvars.active_kernel = fake_kernel
        src = Tensor(DT.float, [1, 512], Position.UB, name="src")
        dst = Tensor(DT.float, [1, 8], Position.UB, name="dst")
        with pytest.raises(ValueError, match="do not pass a total tile length"):
            cadd(dst, src, count_per_rep=512)
    finally:
        globvars.active_kernel = prev_kernel
        globvars.device_type = prev_device


def test_cast_count_per_rep_limit_uses_wider_dtype() -> None:
    prev_kernel = globvars.active_kernel
    prev_device = globvars.device_type
    fake_kernel = SimpleNamespace(instructions=[], vector_mode="repeat")
    try:
        globvars.device_type = "b3"
        globvars.active_kernel = fake_kernel
        src = Tensor(DT.float, [1, 64], Position.UB, name="src")
        dst = Tensor(DT.half, [1, 64], Position.UB, name="dst")
        with pytest.raises(ValueError, match=r"valid range for this op is \[0, 64\]"):
            cast(dst, src, repeat=1, count_per_rep=65)
    finally:
        globvars.active_kernel = prev_kernel
        globvars.device_type = prev_device


@kernel(mode="vec")
def _strided_masked_cast_kernel(src: GMTensor, dst: GMTensor, contract: Var):
    src_ub = Tensor(DT.bfloat16, [11, 16], Position.UB)
    dst_ub = Tensor(DT.float, [15, 8], Position.UB)

    if GetVecIdx() == 0:
        with auto_sync():
            src_ub[0:8, 0:16] <<= src
            dup(dst_ub, -777.0, count=15 * 8)
            cast(
                dst_ub, src_ub, repeat=8,
                dst_rep_stride=1, src_rep_stride=1,
                count_per_rep=2, round_mode=RoundMode.NONE,
            )
            dst <<= dst_ub[0:8, 0:8]
    return dst


def test_cast_repeat_strides_are_addresses_not_logical_lane_counts() -> None:
    src = torch.arange(8 * 16, dtype=torch.float32).reshape(8, 16).to(torch.bfloat16)
    dst = torch.empty((8, 8), dtype=torch.float32)

    got = OpExec(_strided_masked_cast_kernel, simulator=True)(src, dst, -1)

    expected = torch.full_like(dst, -777.0)
    expected[:, 0:2] = src[:, 0:2].float()
    torch.testing.assert_close(got, expected, rtol=0, atol=0)


@kernel()
def _count_per_rep_local_only_kernel(src: GMTensor, out_cmax: GMTensor, out_dup: GMTensor, contract: Var):
    x_ub = Tensor(DT.float, [1, 160], Position.UB)
    cmax_s = Tensor(DT.float, [1, 64], Position.UB)
    dup_ub = Tensor(DT.float, [1, 64], Position.UB)

    if GetVecIdx() == 0:
        with auto_sync():
            x_ub <<= src[0:1, 0:160]
            dup(cmax_s, 0.0)
            dup(dup_ub, -1.0)
            cmax(cmax_s, x_ub, repeat=4, src_rep_stride=4, count_per_rep=32)
            dup(dup_ub, 7.0)
            out_cmax[0:1, 0:4] <<= cmax_s[0:1, 0:4]
            out_dup[0:1, 0:64] <<= dup_ub
    return out_cmax, out_dup


@kernel()
def _explicit_set_mask_by_count_sticky_kernel(gate: GMTensor, out_dup: GMTensor, contract: Var):
    dup_ub = Tensor(DT.float, [1, 64], Position.UB)

    if GetVecIdx() == 0:
        with auto_sync():
            dup(dup_ub, -1.0)
            set_mask_by_count(32)
            dup(dup_ub, 7.0)
            out_dup[0:1, 0:64] <<= dup_ub
    return out_dup


def test_count_per_rep_mask_is_local_to_current_op_in_simulator() -> None:
    x = _build_probe_input()
    out_cmax = torch.zeros((1, 4), dtype=torch.float32)
    out_dup = torch.zeros((1, 64), dtype=torch.float32)

    got_cmax, got_dup = OpExec(_count_per_rep_local_only_kernel, simulator=True)(
        x, out_cmax, out_dup, -1
    )

    torch.testing.assert_close(got_cmax, torch.tensor([[31.0, 1031.0, 2031.0, 3031.0]], dtype=torch.float32), rtol=0, atol=0)
    torch.testing.assert_close(got_dup, torch.full((1, 64), 7.0, dtype=torch.float32), rtol=0, atol=0)


def test_explicit_set_mask_by_count_remains_sticky_in_simulator() -> None:
    out_dup = torch.zeros((1, 64), dtype=torch.float32)
    got_dup = OpExec(_explicit_set_mask_by_count_sticky_kernel, simulator=True)(GATE, out_dup, -1)

    expected = torch.full((1, 64), -1.0, dtype=torch.float32)
    expected[0, 0:32] = 7.0
    torch.testing.assert_close(got_dup, expected, rtol=0, atol=0)
