import pytest
import torch

from easyasc.a2 import (
    pack_int4_to_int32,
    pack_signed_int4,
    pack_signed_int4_to_int32,
    unpack_int32_to_int4,
    unpack_int32_to_signed_int4,
    unpack_signed_int4,
)


def test_int4_int32_aliases_are_exposed_on_a2() -> None:
    assert pack_int4_to_int32 is pack_signed_int4_to_int32
    assert pack_signed_int4 is pack_signed_int4_to_int32
    assert unpack_int32_to_int4 is unpack_int32_to_signed_int4
    assert unpack_signed_int4 is unpack_int32_to_signed_int4


def test_signed_int4_int32_roundtrip_low_nibble_first() -> None:
    logical = torch.tensor([[-8, -7, -1, 0, 1, 2, 6, 7, -3]], dtype=torch.int32)
    packed = pack_int4_to_int32(logical)

    assert packed.shape == (1, 2)
    assert packed[0, 0].item() == 0x76210F98
    assert unpack_int32_to_int4(packed, logical.shape[-1]).equal(logical)


def test_signed_int4_pack_rejects_out_of_range_values() -> None:
    with pytest.raises(ValueError, match=r"signed int4 values must be in \[-8, 7\]"):
        pack_int4_to_int32(torch.tensor([[8]], dtype=torch.int32))

    with pytest.raises(ValueError, match=r"signed int4 values must be in \[-8, 7\]"):
        pack_int4_to_int32(torch.tensor([[-9]], dtype=torch.int32))


def test_signed_int4_unpack_rejects_too_short_carrier() -> None:
    with pytest.raises(ValueError, match="packed carrier last dimension is too small"):
        unpack_int32_to_int4(torch.zeros((2, 1), dtype=torch.int32), logical_k=9)
