from easyasc.a2 import (
    DcciDst as A2DcciDst,
    DcciDstType as A2DcciDstType,
    EntireType as A2EntireType,
    EntireTypeValue as A2EntireTypeValue,
    clean_dcache as a2_clean_dcache,
)
from easyasc.a5 import (
    DcciDst as A5DcciDst,
    DcciDstType as A5DcciDstType,
    EntireType as A5EntireType,
    EntireTypeValue as A5EntireTypeValue,
    clean_dcache as a5_clean_dcache,
)


def test_a2_exports_entire_type():
    assert isinstance(A2EntireType.single, A2EntireTypeValue)
    assert isinstance(A2EntireType.entire, A2EntireTypeValue)
    assert str(A2EntireType.single) == "SINGLE_CACHE_LINE"
    assert str(A2EntireType.entire) == "ENTIRE_DATA_CACHE"


def test_a5_exports_entire_type():
    assert isinstance(A5EntireType.single, A5EntireTypeValue)
    assert isinstance(A5EntireType.entire, A5EntireTypeValue)
    assert A5EntireType.single == A2EntireType.single
    assert A5EntireType.entire == A2EntireType.entire


def test_a2_exports_dcci_dst():
    assert isinstance(A2DcciDst.all, A2DcciDstType)
    assert isinstance(A2DcciDst.ub, A2DcciDstType)
    assert isinstance(A2DcciDst.out, A2DcciDstType)
    assert isinstance(A2DcciDst.atomic, A2DcciDstType)
    assert str(A2DcciDst.all) == "CACHELINE_ALL"
    assert str(A2DcciDst.ub) == "CACHELINE_UB"
    assert str(A2DcciDst.out) == "CACHELINE_OUT"
    assert str(A2DcciDst.atomic) == "CACHELINE_ATOMIC"


def test_a5_exports_dcci_dst():
    assert isinstance(A5DcciDst.all, A5DcciDstType)
    assert isinstance(A5DcciDst.ub, A5DcciDstType)
    assert isinstance(A5DcciDst.out, A5DcciDstType)
    assert isinstance(A5DcciDst.atomic, A5DcciDstType)
    assert A5DcciDst.all == A2DcciDst.all
    assert A5DcciDst.ub == A2DcciDst.ub
    assert A5DcciDst.out == A2DcciDst.out
    assert A5DcciDst.atomic == A2DcciDst.atomic


def test_a2_and_a5_export_clean_dcache():
    assert callable(a2_clean_dcache)
    assert callable(a5_clean_dcache)
