"""Codegen for the fixpipe scalar requant rider (l0c.requant(scale=, offset=)).

Mirrors test_l0c_to_gm_relu_codegen.py: requant rides on the L0C tensor like relu.
The emitted L0C2GM_NZ2ND call gains a trailing (scale, offset) pair ONLY when they
are non-default, so existing stores stay byte-identical. scale/offset may be a
Python constant or a Var, and both must render.
"""
from easyasc.a2 import *
from easyasc.parser.asc import translate_split


@kernel()
def _requant_const_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    full_view = out[:, :]
    full_view <<= src.requant(scale=0.5, offset=10)
    return out


@kernel()
def _requant_slice_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [16, 16], Position.L0C, name="src_l0c")
    out[0:16, :] <<= src.requant(scale=0.25, offset=-3)
    return out


@kernel()
def _no_requant_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    full_view = out[:, :]
    full_view <<= src                     # default scale=1.0 / offset=0
    return out


@kernel()
def _requant_var_kernel(inp: GMTensor, out: GMTensor):
    src = Tensor(DT.float, [32, 16], Position.L0C, name="src_l0c")
    scl = Var(0.5, name="scl")
    ofs = Var(10, name="ofs")
    full_view = out[:, :]
    full_view <<= src.requant(scale=scl, offset=ofs)
    return out


def _l0c_call_line(code: str) -> str:
    lines = [ln for ln in code.splitlines() if "L0C2GM_NZ2ND(" in ln]
    assert len(lines) == 1, f"expected one L0C2GM_NZ2ND call, got {len(lines)}"
    return lines[0]


def test_requant_const_records_kwargs_and_emits_scale_offset() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.int8, [32, 16], name="out")
    _requant_const_kernel(inp, out)

    found = [i for i in _requant_const_kernel.instructions if i.opname == "l0c_to_gm_nz2nd"]
    assert len(found) == 1
    assert found[0].kwargs["scale"] == 0.5
    assert found[0].kwargs["offset"] == 10

    cube_code, _ = translate_split(_requant_const_kernel.instructions, "requant_const_codegen")
    # 11-arg form: dst, src, m, n, n_dst, m_src, relu, scale, offset, scaledQuant, hif8Hybrid
    assert ", 32, 16, 16, 32, false, 0.5f, 10, true, false);" in cube_code


def test_requant_slice_setitem_threads_scale_offset() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.int8, [32, 16], name="out")
    _requant_slice_kernel(inp, out)

    found = [i for i in _requant_slice_kernel.instructions if i.opname == "l0c_to_gm_nz2nd"]
    assert len(found) == 1
    assert found[0].kwargs["scale"] == 0.25
    assert found[0].kwargs["offset"] == -3

    cube_code, _ = translate_split(_requant_slice_kernel.instructions, "requant_slice_codegen")
    line = _l0c_call_line(cube_code)
    assert "0.25f" in line and "-3" in line


def test_default_store_stays_seven_arg_byte_identical() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.half, [32, 16], name="out")
    _no_requant_kernel(inp, out)

    found = [i for i in _no_requant_kernel.instructions if i.opname == "l0c_to_gm_nz2nd"]
    assert len(found) == 1
    assert float(found[0].kwargs["scale"]) == 1.0
    assert int(found[0].kwargs["offset"]) == 0

    cube_code, _ = translate_split(_no_requant_kernel.instructions, "no_requant_codegen")
    # 7-arg form, no trailing scale/offset -> unchanged from before the feature
    assert ", 32, 16, 16, 32, false);" in cube_code
    assert _l0c_call_line(cube_code).count(",") == 6   # dst,src,m,n,n_dst,m_src,relu


def test_requant_var_renders_var_exprs_not_literals() -> None:
    inp = GMTensor(DT.half, [1, 1], name="inp")
    out = GMTensor(DT.int8, [32, 16], name="out")
    _requant_var_kernel(inp, out)

    found = [i for i in _requant_var_kernel.instructions if i.opname == "l0c_to_gm_nz2nd"]
    assert len(found) == 1
    assert isinstance(found[0].kwargs["scale"], Var)
    assert isinstance(found[0].kwargs["offset"], Var)

    cube_code, _ = translate_split(_requant_var_kernel.instructions, "requant_var_codegen")
    line = _l0c_call_line(cube_code)
    # the scale/offset args render as the Var names, not float literals
    assert "scl" in line and "ofs" in line
    assert "0.5f" not in line
