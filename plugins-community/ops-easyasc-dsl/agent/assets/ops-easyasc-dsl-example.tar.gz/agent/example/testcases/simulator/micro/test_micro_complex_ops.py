"""Simulator regression for complex micro ops (complex32 / complex64).

The documented complex-capable reg surface is exactly eight ops -- Add/Sub/Mul/Div,
Adds/Muls, Abs and Duplicate. The simulator computes them in ``complex64`` (torch's
``complex32`` / ComplexHalf is experimental and has no ``div`` kernel), then the
per-op mask-writeback demotes the result to the destination register's declared
complex width. ``Abs`` is special: ``|z|`` is real, so ``complex32 -> half`` and
``complex64 -> float`` (the one complex unary whose output dtype differs from its
input).

These tests drive the micro-runtime dispatch directly (values, with a per-dtype
tolerance) and assert the DSL gates: the eight ops accept complex, ``abs`` enforces
the complex->real dtype pairing, and every other op rejects complex at trace time.
End-to-end OpExec(simulator=True) coverage lives in
``kernels/a5/vec_only/complex_ops_onboard.py`` (which also carries the deferred
on-board path).
"""
import warnings
from contextlib import contextmanager

import pytest
import torch

from easyasc import globvars
from easyasc.simulator.memory import SharedMemoryStore
from easyasc.simulator.pipe_micro import MicroContext, MicroRuntime
from easyasc.stub_functions.micro.binary import add, div, mul, prelu, sub, vmax, vmin
from easyasc.stub_functions.micro.dup import dup
from easyasc.stub_functions.micro.unary import abs as vabs
from easyasc.stub_functions.micro.unary import exp, neg, relu, sqrt, vcopy
from easyasc.stub_functions.micro.unaryscalar import adds, lrelu, muls, shiftls, vmaxs, vmins
from easyasc.utils.datatype import Datatype as DT
from easyasc.utils.mask import MaskType
from easyasc.utils.reg import MaskReg, Reg

warnings.filterwarnings("ignore", message=".*ComplexHalf.*")

_STORE = SharedMemoryStore()

# (Datatype, torch complex dtype, torch real dtype for |z|, tolerance).
# complex32 computes in complex64 then demotes to fp16 precision -> looser tol.
_C_DTYPES = [
    (DT.complex64, torch.complex64, torch.float32, 3e-6),
    (DT.complex32, torch.complex32, torch.float16, 4e-3),
]


def _lanes(torch_dt):
    return 256 // torch.empty(0, dtype=torch_dt).element_size()  # c64->32, c32->64


def _seed(torch_dt):
    """A full-width register with non-zero, non-degenerate complex lanes (no zero
    denominators, so div has no 0/0 NaN lane)."""
    n = _lanes(torch_dt)
    re = torch.arange(1, n + 1, dtype=torch.float32) * 0.5 - 3.0
    im = torch.cos(torch.arange(n, dtype=torch.float32)) * 2.0 + 1.25
    return (re + 1j * im).to(torch_dt)


def _seed_b(torch_dt):
    n = _lanes(torch_dt)
    re = torch.sin(torch.arange(n, dtype=torch.float32)) * 1.5 + 2.0  # |.| >= 0.5, no zero
    im = torch.arange(1, n + 1, dtype=torch.float32) * 0.25 - 1.0
    return (re + 1j * im).to(torch_dt)


def _dispatch(op, regs, kw):
    rt = MicroRuntime()
    ctx = MicroContext(regs={k: v.clone() for k, v in regs.items()}, masks={})
    rt._stack.append(ctx)
    try:
        rt._dispatch(op, kw, _STORE)
    finally:
        rt._stack.pop()
    return ctx.regs[kw["dst"].name]


def _assert_close(got, want, tol):
    g = got.to(torch.complex64) if got.is_complex() else got.to(torch.float32)
    w = want.to(torch.complex64) if want.is_complex() else want.to(torch.float32)
    assert torch.allclose(g, w, rtol=tol, atol=tol), (g[:4].tolist(), w[:4].tolist())


# ---------------------------------------------------------------------------
# Micro-runtime dispatch: values + demotion + result dtype.
# ---------------------------------------------------------------------------
_BINARY = [
    ("micro_vadd", lambda a, b: a + b),
    ("micro_vsub", lambda a, b: a - b),
    ("micro_vmul", lambda a, b: a * b),
    ("micro_vdiv", lambda a, b: a / b),
]


@pytest.mark.parametrize("dt,cdt,rdt,tol", _C_DTYPES)
@pytest.mark.parametrize("op,ref", _BINARY)
def test_complex_binary_native(dt, cdt, rdt, tol, op, ref):
    a, b = _seed(cdt), _seed_b(cdt)
    dst, s0, s1 = Reg(dt, name="dst"), Reg(dt, name="s0"), Reg(dt, name="s1")
    got = _dispatch(op, {"s0": a, "s1": b}, {"dst": dst, "src": s0, "src1": s1})
    assert got.dtype == cdt, got.dtype
    _assert_close(got, ref(a.to(torch.complex64), b.to(torch.complex64)), tol)


@pytest.mark.parametrize("dt,cdt,rdt,tol", _C_DTYPES)
def test_complex_abs_to_real(dt, cdt, rdt, tol):
    a = _seed(cdt)
    # abs of a complex reg writes a REAL register (half<-c32, float<-c64).
    dst, src = Reg(rdt is torch.float32 and DT.float or DT.half, name="dst"), Reg(dt, name="src")
    got = _dispatch("micro_vabs", {"src": a}, {"dst": dst, "src": src})
    assert got.dtype == rdt, got.dtype
    _assert_close(got, torch.abs(a.to(torch.complex64)), tol)


@pytest.mark.parametrize("dt,cdt,rdt,tol", _C_DTYPES)
@pytest.mark.parametrize("op,sval,ref", [
    ("micro_vadds", 1.5 - 0.5j, lambda a, s: a + s),
    ("micro_vmuls", 2.0 + 1.0j, lambda a, s: a * s),
])
def test_complex_scalar_native(dt, cdt, rdt, tol, op, sval, ref):
    a = _seed(cdt)
    dst, src = Reg(dt, name="dst"), Reg(dt, name="src")
    got = _dispatch(op, {"src": a}, {"dst": dst, "src": src, "v": sval})
    assert got.dtype == cdt, got.dtype
    _assert_close(got, ref(a.to(torch.complex64), sval), tol)


@pytest.mark.parametrize("dt,cdt,rdt,tol", _C_DTYPES)
def test_complex_dup_immediate(dt, cdt, rdt, tol):
    val = 3.0 - 2.0j
    dst = Reg(dt, name="dst")
    got = _dispatch("micro_vdup", {}, {"dst": dst, "src": val})
    assert got.dtype == cdt and got.numel() == _lanes(cdt), (got.dtype, got.numel())
    _assert_close(got, torch.full((_lanes(cdt),), val, dtype=torch.complex64), tol)


# ---------------------------------------------------------------------------
# DSL trace gates: the eight ops accept complex; everything else rejects it.
# ---------------------------------------------------------------------------
class _FakeMicro:
    def __init__(self):
        self.instructions = []

    def _register_reg_name(self, name, kind):
        return None

    def get_mask(self, dtype, reg_num=1):
        return MaskReg(dtype, init_mode=MaskType.ALL, name="mask", reg_num=reg_num)


@contextmanager
def _active_micro():
    old_micro, old_device = globvars.active_micro, globvars.device_type
    try:
        globvars.device_type = "950"
        globvars.active_micro = _FakeMicro()
        yield globvars.active_micro
    finally:
        globvars.active_micro = old_micro
        globvars.device_type = old_device


@pytest.mark.parametrize("dt", [DT.complex32, DT.complex64])
def test_binary_arith_accepts_complex(dt):
    with _active_micro() as micro:
        d, a, b = Reg(dt, name="d"), Reg(dt, name="a"), Reg(dt, name="b")
        for fn, opname in ((add, "micro_vadd"), (sub, "micro_vsub"),
                           (mul, "micro_vmul"), (div, "micro_vdiv")):
            fn(d, a, b)
            assert micro.instructions[-1].opname == opname
            assert micro.instructions[-1].dst.dtype == dt


@pytest.mark.parametrize("dt", [DT.complex32, DT.complex64])
def test_scalar_and_dup_accept_complex(dt):
    with _active_micro() as micro:
        d, a = Reg(dt, name="d"), Reg(dt, name="a")
        adds(d, a, 1 + 2j)
        assert micro.instructions[-1].opname == "micro_vadds"
        muls(d, a, 2 - 1j)
        assert micro.instructions[-1].opname == "micro_vmuls"
        dup(d, 3 + 0.5j)
        assert micro.instructions[-1].opname == "micro_vdup"


def test_abs_complex_to_real_dtype_pairing():
    with _active_micro() as micro:
        # complex32 -> half, complex64 -> float
        vabs(Reg(DT.half, name="oh"), Reg(DT.complex32, name="a32"))
        assert micro.instructions[-1].opname == "micro_vabs"
        vabs(Reg(DT.float, name="of"), Reg(DT.complex64, name="a64"))
        assert micro.instructions[-1].opname == "micro_vabs"
        # wrong real width is rejected
        with pytest.raises(ValueError, match="must write a"):
            vabs(Reg(DT.float, name="bad"), Reg(DT.complex32, name="a32b"))
        with pytest.raises(ValueError, match="must write a"):
            vabs(Reg(DT.half, name="bad2"), Reg(DT.complex64, name="a64b"))


def _binary_call(fn):
    return lambda dt: fn(Reg(dt, name="d"), Reg(dt, name="a"), Reg(dt, name="b"))


def _scalar_call(fn, val=1):
    return lambda dt: fn(Reg(dt, name="d"), Reg(dt, name="a"), val)


def _unary_call(fn):
    return lambda dt: fn(Reg(dt, name="d"), Reg(dt, name="a"))


_REJECTED = [
    ("vmin", _binary_call(vmin)),
    ("vmax", _binary_call(vmax)),
    ("prelu", _binary_call(prelu)),
    ("exp", _unary_call(exp)),
    ("relu", _unary_call(relu)),
    ("sqrt", _unary_call(sqrt)),
    ("neg", _unary_call(neg)),
    ("vcopy", _unary_call(vcopy)),
    ("vmaxs", _scalar_call(vmaxs)),
    ("vmins", _scalar_call(vmins)),
    ("lrelu", _scalar_call(lrelu)),
    ("shiftls", _scalar_call(shiftls, 1)),
]


@pytest.mark.parametrize("dt", [DT.complex32, DT.complex64])
@pytest.mark.parametrize("name,call", _REJECTED)
def test_non_arith_ops_reject_complex(name, call, dt):
    with _active_micro():
        with pytest.raises((TypeError, ValueError)):
            call(dt)
