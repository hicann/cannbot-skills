from easyasc import globvars
from easyasc.a2 import *
from easyasc.simulator import Simulator, SimulatorConfig, build_kernel_program


@kernel()
def _legacy_workspace_view_kernel(src: GMTensor, out: GMTensor, b: Var, h: Var, s: Var, d: Var):
    rows = Var(b * h * s)
    src_flat = src.reshape([rows, d], name="src_flat")
    split_workspace(DT.float, [GetCubeNum(), rows, d], name="ws")
    return out


def test_legacy_bridge_registers_split_workspace_and_gm_view(monkeypatch) -> None:
    monkeypatch.setattr(globvars, "core_num", 3, raising=False)

    b = Var(1, name="b")
    h = Var(1, name="h")
    s = Var(4, name="s")
    d = Var(16, name="d")
    src = GMTensor(DT.float, [b, h, s, d], name="src")
    out = GMTensor(DT.float, [1, 1], name="out")

    _legacy_workspace_view_kernel(src, out, b, h, s, d)
    program = build_kernel_program(_legacy_workspace_view_kernel)
    specs = {item["name"]: item for item in program.metadata.get("tensor_specs", [])}

    assert specs["ws"]["role"] == "workspace"
    assert specs["ws"]["shape"] == (3 * 4 * 16,)

    sim = Simulator(config=SimulatorConfig(core_count=3, execution_timeout_s=1.0))
    sim._prepare(program)
    try:
        assert sim.memory_store.contains("src")
        assert sim.memory_store.contains("ws")
    finally:
        sim.shutdown()
