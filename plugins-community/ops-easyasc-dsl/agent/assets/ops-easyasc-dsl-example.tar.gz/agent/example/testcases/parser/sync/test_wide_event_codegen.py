from easyasc.a5 import DT, GMTensor, Pipe, QEvent, TEvent, kernel
from easyasc.parser.asc import translate_split


@kernel()
def wide_event_codegen_kernel(x: GMTensor, y: GMTensor):
    triple = TEvent(Pipe.MTE2, Pipe.MTE1, preset=True, name="triple")
    quad = QEvent(Pipe.M, Pipe.FIX, name="quad")
    triple.wait()
    triple.set()
    quad.setall()
    quad.release()
    return y


def test_translate_split_emits_tevent_and_qevent_declarations() -> None:
    x = GMTensor(DT.half, [16, 16])
    y = GMTensor(DT.half, [16, 16])
    wide_event_codegen_kernel(x, y)

    cube_code, _ = translate_split(
        wide_event_codegen_kernel.instructions,
        "wide_event_codegen",
    )

    assert "TEvent<PIPE_MTE2, PIPE_MTE1, true> triple;" in cube_code
    assert "QEvent<PIPE_M, PIPE_FIX, false> quad;" in cube_code
    assert "triple.wait();" in cube_code
    assert "triple.set();" in cube_code
    assert "quad.setall();" in cube_code
    assert "quad.release();" in cube_code
