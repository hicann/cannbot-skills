import pytest
import torch

from easyasc.a5 import OpExec
from kernels.a5.matmul.hif8_carrier_matmul import (
    CASE_NAMES,
    _build_matrix_inputs,
    hif8_carrier_matmul_matrix_kernel,
)


pytestmark = pytest.mark.easyasc_device("a5")


def test_hif8_carrier_mmad_simulator() -> None:
    a_nt_carrier, a_t_carrier, b_nt_carrier, b_t_carrier, outputs, expected = _build_matrix_inputs()

    actual = OpExec(hif8_carrier_matmul_matrix_kernel, simulator=True)(
        a_nt_carrier,
        a_t_carrier,
        b_nt_carrier,
        b_t_carrier,
        *outputs,
        0,
    )

    assert len(actual) == len(CASE_NAMES)
    for out in actual:
        torch.testing.assert_close(out, expected, rtol=2e-3, atol=2e-2)
