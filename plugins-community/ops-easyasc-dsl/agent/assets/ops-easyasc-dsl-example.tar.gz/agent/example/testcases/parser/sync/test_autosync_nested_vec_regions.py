import contextlib
import io

from easyasc.parser.asc import split_instructions, translate_split
from easyasc.parser.asc_autosync import insert_auto_sync
from testcases.parser.sync._autosync_nested_vec_kernels import (
    autosync_vec_parent_child_same_ubout_stream,
    autosync_vec_parent_preload_child_mixed,
    build_nested_same_ubout_stream,
    build_nested_vec_parent_preload_child_mixed,
)

def test_insert_auto_sync_nested_vec_parent_preload_child_mixed_has_no_warning() -> None:
    build_nested_vec_parent_preload_child_mixed()
    _, vec_insts = split_instructions(list(autosync_vec_parent_preload_child_mixed.instructions))

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        vec_insts = insert_auto_sync(vec_insts, mode="vec")

    assert "NOT balanced auto_sync events" not in captured.getvalue()

    created = {
        inst.kwargs["val"].name
        for inst in vec_insts
        if inst.opname in ("create_devent", "create_sevent")
    }
    # Parent-preloaded `state_ub` and child-loaded `token_ub` are distinct UB
    # families. They must not collapse onto one shared ubin event stream just
    # because both use MTE2->V inside one nested region.
    assert "_tmp_devent_valid_ubin_0" in created
    assert "_tmp_devent_ready_ubin_0" in created
    assert "_tmp_devent_valid_ubin_1" in created
    assert "_tmp_devent_ready_ubin_1" in created

def test_translate_split_nested_vec_parent_preload_child_mixed_codegen_has_no_warning() -> None:
    build_nested_vec_parent_preload_child_mixed()

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        _, vec_code = translate_split(
            autosync_vec_parent_preload_child_mixed.instructions,
            "autosync_vec_parent_preload_child_mixed_codegen",
        )

    assert "NOT balanced auto_sync events" not in captured.getvalue()
    assert "DEvent<PIPE_V, PIPE_MTE2, true> _tmp_devent_valid_ubin_0;" in vec_code
    assert "DEvent<PIPE_MTE2, PIPE_V, false> _tmp_devent_ready_ubin_0;" in vec_code
    assert "DEvent<PIPE_V, PIPE_MTE2, true> _tmp_devent_valid_ubin_1;" in vec_code
    assert "DEvent<PIPE_MTE2, PIPE_V, false> _tmp_devent_ready_ubin_1;" in vec_code

def test_insert_auto_sync_nested_same_ubout_stream_reuses_event_group() -> None:
    build_nested_same_ubout_stream()
    _, vec_insts = split_instructions(list(autosync_vec_parent_child_same_ubout_stream.instructions))
    vec_insts = insert_auto_sync(vec_insts, mode="vec")

    created = {
        inst.kwargs["val"].name
        for inst in vec_insts
        if inst.opname in ("create_devent", "create_sevent")
    }
    assert "_tmp_devent_valid_ubout_0" in created
    assert "_tmp_devent_ready_ubout_0" in created
    assert "_tmp_devent_valid_ubout_1" not in created
    assert "_tmp_devent_ready_ubout_1" not in created
