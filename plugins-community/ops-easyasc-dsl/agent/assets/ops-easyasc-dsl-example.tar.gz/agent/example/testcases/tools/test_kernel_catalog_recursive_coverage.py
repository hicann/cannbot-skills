"""Recursive kernel-catalog coverage tests."""

import json
from pathlib import Path

from agent.scripts.build_agent_index import parse_catalog
from agent.scripts.check_kernel_catalog import analyze_repo


CATALOG_ENTRY = """\
## Test kernels

### `{path}`
- formula: identity
- topology: `vec-only`
- study_for:
  - catalog checker tests
- do_not_copy_when:
  - production behavior matters
"""


def _write_index(root: Path, catalog: Path, index: Path) -> None:
    payload = parse_catalog(catalog, kind="kernel", root=root)
    index.write_text(json.dumps({"entries": payload["entries"]}), encoding="utf-8")


def _write_lean_index(path: Path, *kernel_paths: str) -> None:
    rows = [f"| a2 | vec-only | `{kernel_path}` | test |" for kernel_path in kernel_paths]
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")


def test_nested_kernel_is_required_but_runner_is_not(tmp_path: Path) -> None:
    kernel_dir = tmp_path / "agent" / "example" / "kernels"
    nested = kernel_dir / "nested"
    nested.mkdir(parents=True)
    (kernel_dir / "base.py").write_text("@kernel()\ndef base():\n    pass\n", encoding="utf-8")
    (nested / "new_kernel.py").write_text("@kernel(mode='vec')\ndef new_kernel():\n    pass\n", encoding="utf-8")
    (nested / "run_tests.py").write_text("def main():\n    pass\n", encoding="utf-8")

    catalog = tmp_path / "kernel-catalog.md"
    catalog.write_text(CATALOG_ENTRY.format(path="agent/example/kernels/base.py"), encoding="utf-8")
    index = tmp_path / "kernels.json"
    _write_index(tmp_path, catalog, index)
    lean = tmp_path / "kernel-index.md"
    _write_lean_index(lean, "agent/example/kernels/base.py")

    result = analyze_repo(tmp_path, catalog, index, kernel_dir, lean)
    uncataloged = [item["path"] for item in result["warnings"] if item["code"] == "uncataloged-kernel"]

    assert uncataloged == ["agent/example/kernels/nested/new_kernel.py"]
    assert "agent/example/kernels/nested/run_tests.py" not in result["kernel_files"]


def test_private_and_preserved_original_kernels_are_not_selectable(tmp_path: Path) -> None:
    kernel_dir = tmp_path / "agent" / "example" / "kernels"
    baseline = kernel_dir / "op" / "baseline_original"
    baseline.mkdir(parents=True)
    (kernel_dir / "base.py").write_text("@kernel()\ndef base():\n    pass\n", encoding="utf-8")
    (kernel_dir / "_diagnostic.py").write_text("@kernel()\ndef diagnostic():\n    pass\n", encoding="utf-8")
    (kernel_dir / "saved_original.py").write_text("@kernel()\ndef saved():\n    pass\n", encoding="utf-8")
    (baseline / "copy.py").write_text("@kernel()\ndef copy():\n    pass\n", encoding="utf-8")

    catalog = tmp_path / "kernel-catalog.md"
    catalog.write_text(CATALOG_ENTRY.format(path="agent/example/kernels/base.py"), encoding="utf-8")
    index = tmp_path / "kernels.json"
    _write_index(tmp_path, catalog, index)
    lean = tmp_path / "kernel-index.md"
    _write_lean_index(lean, "agent/example/kernels/base.py")

    result = analyze_repo(tmp_path, catalog, index, kernel_dir, lean)

    assert result["kernel_files"] == ["agent/example/kernels/base.py"]
    assert not [item for item in result["warnings"] if item["code"] == "uncataloged-kernel"]


def test_catalog_and_lean_index_must_cover_the_same_paths(tmp_path: Path) -> None:
    kernel_dir = tmp_path / "agent" / "example" / "kernels"
    kernel_dir.mkdir(parents=True)
    (kernel_dir / "base.py").write_text("@kernel()\ndef base():\n    pass\n", encoding="utf-8")

    catalog = tmp_path / "kernel-catalog.md"
    catalog.write_text(CATALOG_ENTRY.format(path="agent/example/kernels/base.py"), encoding="utf-8")
    index = tmp_path / "kernels.json"
    _write_index(tmp_path, catalog, index)
    lean = tmp_path / "kernel-index.md"
    _write_lean_index(lean, "agent/example/kernels/orphan.py")

    result = analyze_repo(tmp_path, catalog, index, kernel_dir, lean)
    warnings = {(item["code"], item["path"]) for item in result["warnings"]}

    assert ("missing-lean-entry", "agent/example/kernels/base.py") in warnings
    assert ("orphan-lean-entry", "agent/example/kernels/orphan.py") in warnings


def test_lean_index_prose_reference_does_not_count_as_a_table_entry(tmp_path: Path) -> None:
    kernel_dir = tmp_path / "agent" / "example" / "kernels"
    kernel_dir.mkdir(parents=True)
    (kernel_dir / "base.py").write_text("@kernel()\ndef base():\n    pass\n", encoding="utf-8")

    catalog = tmp_path / "kernel-catalog.md"
    catalog.write_text(CATALOG_ENTRY.format(path="agent/example/kernels/base.py"), encoding="utf-8")
    index = tmp_path / "kernels.json"
    _write_index(tmp_path, catalog, index)
    lean = tmp_path / "kernel-index.md"
    lean.write_text("See `kernels/base.py` for details.\n", encoding="utf-8")

    result = analyze_repo(tmp_path, catalog, index, kernel_dir, lean)

    assert ("missing-lean-entry", "agent/example/kernels/base.py") in {
        (item["code"], item["path"]) for item in result["warnings"]
    }
