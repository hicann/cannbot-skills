import contextlib
import io

import pytest

from easyasc.a5 import *
from easyasc.parser.asc import translate_split


WIDTH = 64


def _translate_silently(instructions, name):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        return translate_split(instructions, name)


@kernel()
def plain_var_if_kernel(x: GMTensor):
    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    flag = Var(1)
    if flag < 4:
        buf <<= buf + 1.0
    else:
        buf <<= buf + 2.0
    return x


@kernel()
def assigned_var_if_kernel(x: GMTensor, src_flag: Var):
    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    flag = Var(dtype=DT.int)
    flag <<= src_flag
    if flag < 4:
        buf <<= buf + 1.0
    else:
        buf <<= buf + 2.0
    return x


@kernel()
def loop_derived_if_kernel(x: GMTensor, S: Var):
    buf = Tensor(DT.float, [1, WIDTH], Position.UB)
    for s in range(0, S + 8, 8):
        if s < S:
            valid_cols = Min(8, S - s)
            if valid_cols < 8:
                buf <<= buf + 1.0
            else:
                buf <<= buf + 2.0
    return x


def _if_conditions(kernel_obj):
    return [str(inst.kwargs.get("cond")) for inst in kernel_obj.instructions if inst.opname == "start_if"]


@pytest.mark.easyasc_device("b3")
def test_plain_var_if_condition_stays_symbolic() -> None:
    x = GMTensor(DT.float, [1, WIDTH])
    plain_var_if_kernel(x)

    conds = _if_conditions(plain_var_if_kernel)
    assert "flag < 4" in conds
    assert "True" not in conds
    assert "False" not in conds

    _, vec_code = _translate_silently(plain_var_if_kernel.instructions, "plain_var_if_kernel_codegen")
    assert "if (flag < 4)" in vec_code
    assert "if (true)" not in vec_code.lower()
    assert "if (false)" not in vec_code.lower()


@pytest.mark.easyasc_device("b3")
def test_assigned_var_if_condition_stays_symbolic() -> None:
    x = GMTensor(DT.float, [1, WIDTH])
    assigned_var_if_kernel(x, Var(321))

    conds = _if_conditions(assigned_var_if_kernel)
    assert "flag < 4" in conds
    assert "True" not in conds
    assert "False" not in conds

    _, vec_code = _translate_silently(assigned_var_if_kernel.instructions, "assigned_var_if_kernel_codegen")
    assert "if (flag < 4)" in vec_code
    assert "if (true)" not in vec_code.lower()
    assert "if (false)" not in vec_code.lower()


@pytest.mark.easyasc_device("b3")
def test_loop_derived_if_condition_stays_symbolic() -> None:
    x = GMTensor(DT.float, [1, WIDTH])
    loop_derived_if_kernel(x, Var(321))

    conds = _if_conditions(loop_derived_if_kernel)
    assert "s < S" in conds
    assert "valid_cols < 8" in conds
    assert "True" not in conds
    assert "False" not in conds

    _, vec_code = _translate_silently(loop_derived_if_kernel.instructions, "loop_derived_if_kernel_codegen")
    assert "if (s < S)" in vec_code
    assert "if (valid_cols < 8)" in vec_code
    assert "if (true)" not in vec_code.lower()
    assert "if (false)" not in vec_code.lower()
