#!/usr/bin/env python3
# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Analyze easyasc simulator Chrome trace JSON pipe utilization."""

import argparse
import json
import logging
from collections import defaultdict
from dataclasses import dataclass
from typing import Any, DefaultDict, Dict, List, Optional, Sequence, Tuple


SYNC_OPS = frozenset([
    "bar_all",
    "event_set", "event_setall", "event_wait", "event_release",
    "cube_ready", "vec_ready", "wait_vec", "wait_cube",
    "intracore_allvec_ready", "intracore_allvec_wait",
    "allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait",
    "setflag", "waitflag",
])

PIPE_ORDER = {
    "S": 0,
    "MTE2": 1,
    "MTE1": 2,
    "M": 3,
    "FIX": 4,
    "V": 5,
    "MTE3": 6,
}

LANE_ORDER = {
    "cube": 0,
    "vec": 1,
    "vec0": 1,
    "vec1": 2,
    "runtime": 3,
}


@dataclass(frozen=True)
class TraceEvent:
    core_idx: int
    lane_name: str
    pipe_name: str
    opname: str
    cat: str
    ts: float
    dur: float
    time_domain: str

    @property
    def end(self) -> float:
        return self.ts + self.dur

    @property
    def track_key(self) -> Tuple[int, str, str]:
        return self.core_idx, self.lane_name, self.pipe_name


@dataclass(frozen=True)
class TrackStats:
    core_idx: int
    lane_name: str
    pipe_name: str
    label: str
    event_count: int
    active_event_count: int
    active_cycles: float
    first_ts: float
    last_end: float
    makespan: float

    @property
    def span(self) -> float:
        return max(self.last_end - self.first_ts, 0.0)

    @property
    def active_over_span(self) -> float:
        if self.span <= 0.0:
            return 0.0
        return self.active_cycles / self.span

    @property
    def active_over_makespan(self) -> float:
        if self.makespan <= 0.0:
            return 0.0
        return self.active_cycles / self.makespan


@dataclass(frozen=True)
class GroupStats:
    core_idx: Optional[int]
    label: str
    core_count: int
    track_count: int
    event_count: int
    active_event_count: int
    avg_active_cycles: float
    avg_span: float
    avg_active_over_span: float
    avg_active_over_makespan: float


def _as_float(value: Any, field: str, event_idx: int) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("event {idx} has invalid {field}: {value!r}".format(
            idx=event_idx, field=field, value=value)) from exc


def _as_int(value: Any, default: int = -1) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return default


def load_timed_events(path: str) -> Tuple[List[TraceEvent], str]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    raw_events = data.get("traceEvents")
    if not isinstance(raw_events, list):
        raise ValueError("trace JSON does not contain a traceEvents list")

    events: List[TraceEvent] = []
    for idx, item in enumerate(raw_events):
        if not isinstance(item, dict) or item.get("ph") != "X":
            continue
        args = item.get("args", {})
        if not isinstance(args, dict):
            args = {}
        ts = _as_float(item.get("ts"), "ts", idx)
        dur = max(_as_float(item.get("dur", 0.0), "dur", idx), 0.0)
        pipe_name = str(args.get("pipe_name", item.get("cat", "unknown")))
        opname = str(args.get("opname", item.get("name", "")))
        events.append(TraceEvent(
            core_idx=_as_int(args.get("core_idx"), default=-1),
            lane_name=str(args.get("lane_name", "runtime")),
            pipe_name=pipe_name,
            opname=opname,
            cat=str(item.get("cat", args.get("cat", pipe_name))),
            ts=ts,
            dur=dur,
            time_domain=str(args.get("time_domain", "")),
        ))

    return events, _detect_unit(events, str(data.get("displayTimeUnit", "trace units")))


def _detect_unit(events: Sequence[TraceEvent], display_unit: str) -> str:
    domains = set(event.time_domain for event in events if event.time_domain)
    if domains == set(["cycle"]):
        return "cycles"
    if not domains:
        return display_unit
    return "mixed trace units"


def event_track_included(event: TraceEvent, include_s: bool) -> bool:
    return include_s or event.pipe_name != "S"


def event_is_active(event: TraceEvent, include_sync: bool, include_stall: bool) -> bool:
    name = event.opname or ""
    cat = event.cat or ""
    if not include_stall and (cat.lower() == "stall" or name.startswith("stall:")):
        return False
    if not include_sync and (cat.lower() == "sync" or name in SYNC_OPS):
        return False
    return True


def group_label(event: TraceEvent, group_by: str) -> str:
    if group_by == "lane-pipe":
        return event.lane_name + "." + event.pipe_name
    if event.pipe_name == "MTE2" and event.lane_name in ("cube", "vec0", "vec1"):
        side = "cube" if event.lane_name == "cube" else "vec"
        return side + "." + event.pipe_name
    return event.pipe_name


def compute_makespan(events: Sequence[TraceEvent]) -> float:
    if not events:
        return 0.0
    first_ts = min(event.ts for event in events)
    last_end = max(event.end for event in events)
    return max(last_end - first_ts, 0.0)


def compute_track_stats(
    events: Sequence[TraceEvent],
    makespan: float,
    group_by: str,
    include_s: bool,
    include_sync: bool,
    include_stall: bool,
) -> List[TrackStats]:
    by_track: DefaultDict[Tuple[int, str, str], List[TraceEvent]] = defaultdict(list)
    for event in events:
        if event_track_included(event, include_s):
            by_track[event.track_key].append(event)

    stats: List[TrackStats] = []
    for (core_idx, lane_name, pipe_name), track_events in by_track.items():
        first_ts = min(event.ts for event in track_events)
        last_end = max(event.end for event in track_events)
        active_events = [
            event for event in track_events
            if event_is_active(event, include_sync=include_sync, include_stall=include_stall)
        ]
        active_cycles = sum(event.dur for event in active_events)
        label = group_label(track_events[0], group_by)
        stats.append(TrackStats(
            core_idx=core_idx,
            lane_name=lane_name,
            pipe_name=pipe_name,
            label=label,
            event_count=len(track_events),
            active_event_count=len(active_events),
            active_cycles=active_cycles,
            first_ts=first_ts,
            last_end=last_end,
            makespan=makespan,
        ))
    return sorted(stats, key=lambda stat: (stat.core_idx, _label_sort_key(stat.label), stat.lane_name))


def summarize_group(core_idx: Optional[int], label: str, tracks: Sequence[TrackStats]) -> GroupStats:
    if not tracks:
        return GroupStats(core_idx, label, 0, 0, 0, 0, 0.0, 0.0, 0.0, 0.0)
    core_count = len(set(track.core_idx for track in tracks))
    count = float(len(tracks))
    return GroupStats(
        core_idx=core_idx,
        label=label,
        core_count=core_count,
        track_count=len(tracks),
        event_count=sum(track.event_count for track in tracks),
        active_event_count=sum(track.active_event_count for track in tracks),
        avg_active_cycles=sum(track.active_cycles for track in tracks) / count,
        avg_span=sum(track.span for track in tracks) / count,
        avg_active_over_span=sum(track.active_over_span for track in tracks) / count,
        avg_active_over_makespan=sum(track.active_over_makespan for track in tracks) / count,
    )


def summarize_core_pipe(track_stats: Sequence[TrackStats]) -> List[GroupStats]:
    groups: DefaultDict[Tuple[int, str], List[TrackStats]] = defaultdict(list)
    for stat in track_stats:
        groups[(stat.core_idx, stat.label)].append(stat)
    rows = [
        summarize_group(core_idx, label, tracks)
        for (core_idx, label), tracks in groups.items()
    ]
    return sorted(rows, key=lambda row: (row.core_idx if row.core_idx is not None else -1, _label_sort_key(row.label)))


def summarize_pipe_across_cores(core_pipe_rows: Sequence[GroupStats]) -> List[GroupStats]:
    grouped: DefaultDict[str, List[GroupStats]] = defaultdict(list)
    for row in core_pipe_rows:
        grouped[row.label].append(row)

    rows: List[GroupStats] = []
    for label, per_core_rows in grouped.items():
        count = float(len(per_core_rows))
        rows.append(GroupStats(
            core_idx=None,
            label=label,
            core_count=len(per_core_rows),
            track_count=sum(row.track_count for row in per_core_rows),
            event_count=sum(row.event_count for row in per_core_rows),
            active_event_count=sum(row.active_event_count for row in per_core_rows),
            avg_active_cycles=sum(row.avg_active_cycles for row in per_core_rows) / count,
            avg_span=sum(row.avg_span for row in per_core_rows) / count,
            avg_active_over_span=sum(row.avg_active_over_span for row in per_core_rows) / count,
            avg_active_over_makespan=sum(row.avg_active_over_makespan for row in per_core_rows) / count,
        ))
    return sorted(rows, key=lambda row: _label_sort_key(row.label))


def _label_sort_key(label: str) -> Tuple[int, int, str]:
    if "." in label:
        lane, pipe = label.rsplit(".", 1)
        return LANE_ORDER.get(lane, 99), PIPE_ORDER.get(pipe, 99), label
    return 0, PIPE_ORDER.get(label, 99), label


def format_number(value: float) -> str:
    if abs(value - round(value)) < 0.0005:
        return str(int(round(value)))
    return "{:.3f}".format(value)


def format_percent(value: float) -> str:
    return "{:.2f}%".format(value * 100.0)


def render_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    widths = [len(header) for header in headers]
    for row in rows:
        for idx, cell in enumerate(row):
            widths[idx] = max(widths[idx], len(cell))

    def render_row(row: Sequence[str]) -> str:
        return "  ".join(cell.rjust(widths[idx]) if idx > 0 else cell.ljust(widths[idx])
                         for idx, cell in enumerate(row))

    lines = [render_row(headers), "  ".join("-" * width for width in widths)]
    lines.extend(render_row(row) for row in rows)
    return "\n".join(lines)


def group_row(row: GroupStats, include_core: bool = False) -> List[str]:
    cells: List[str] = []
    if include_core:
        cells.append(str(row.core_idx))
    cells.extend([
        row.label,
        str(row.core_count) if not include_core else str(row.track_count),
        str(row.track_count) if not include_core else str(row.event_count),
        format_number(row.avg_active_cycles),
        format_number(row.avg_span),
        format_percent(row.avg_active_over_span),
        format_percent(row.avg_active_over_makespan),
    ])
    return cells


try:
    from _logutil import configure_tool_logging
except ImportError:  # imported as agent.scripts.<tool> rather than as a script
    from ._logutil import configure_tool_logging

LOG = logging.getLogger("analyze_sim_trace")

def print_report(path: str, events: Sequence[TraceEvent], unit: str, makespan: float,
                 pipe_rows: Sequence[GroupStats], core_rows: Sequence[GroupStats]) -> None:
    if not LOG.handlers:
        configure_tool_logging(LOG)
    LOG.info("Trace: %s", path)
    LOG.info("Timed events: %s", len(events))
    LOG.info("Time unit: %s", unit)
    LOG.info("Total time taken: %s %s", format_number(makespan), unit)
    LOG.info("")

    LOG.info("Average utilization by pipe across cores")
    LOG.info(render_table(
        ["pipe", "cores", "tracks", "avg_active", "avg_span", "active/span", "active/makespan"],
        [group_row(row) for row in pipe_rows],
    ))
    LOG.info("")

    LOG.info("Utilization by core and pipe")
    LOG.info(render_table(
        ["core", "pipe", "tracks", "events", "avg_active", "avg_span", "active/span", "active/makespan"],
        [group_row(row, include_core=True) for row in core_rows],
    ))


def build_json(path: str, events: Sequence[TraceEvent], unit: str, makespan: float,
               pipe_rows: Sequence[GroupStats], core_rows: Sequence[GroupStats]) -> Dict[str, Any]:
    def encode(row: GroupStats) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "pipe": row.label,
            "core_count": row.core_count,
            "track_count": row.track_count,
            "event_count": row.event_count,
            "active_event_count": row.active_event_count,
            "avg_active_cycles": row.avg_active_cycles,
            "avg_span": row.avg_span,
            "avg_active_over_span": row.avg_active_over_span,
            "avg_active_over_makespan": row.avg_active_over_makespan,
        }
        if row.core_idx is not None:
            out["core_idx"] = row.core_idx
        return out

    return {
        "trace_path": path,
        "timed_event_count": len(events),
        "time_unit": unit,
        "total_time": makespan,
        "average_by_pipe": [encode(row) for row in pipe_rows],
        "by_core": [encode(row) for row in core_rows],
    }


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Report total time and pipe utilization from an easyasc simulator trace JSON.")
    parser.add_argument("trace_json", help="Path to simulator Chrome trace JSON")
    parser.add_argument(
        "--group-by", choices=("pipe", "lane-pipe"), default="pipe",
        help="Use pipe labels, splitting MTE2 into cube.MTE2 and vec.MTE2, "
             "or split all labels by lane and pipe. Default: pipe")
    parser.add_argument(
        "--include-s", action="store_true",
        help="Include PipeS/control tracks. They are omitted by default.")
    parser.add_argument(
        "--include-sync", action="store_true",
        help="Count sync events such as event_wait/bar_all as active time.")
    parser.add_argument(
        "--include-stall", action="store_true",
        help="Count stall:* events as active time.")
    parser.add_argument(
        "--json", action="store_true",
        help="Emit machine-readable JSON instead of tables.")
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    configure_tool_logging(LOG)
    args = parse_args(argv)
    try:
        events, unit = load_timed_events(args.trace_json)
        if not events:
            raise ValueError("trace contains no timed events with ph == 'X'")
        makespan = compute_makespan(events)
        track_stats = compute_track_stats(
            events, makespan,
            group_by=args.group_by,
            include_s=args.include_s,
            include_sync=args.include_sync,
            include_stall=args.include_stall,
        )
        if not track_stats:
            raise ValueError("no tracks matched the selected filters")
        core_rows = summarize_core_pipe(track_stats)
        pipe_rows = summarize_pipe_across_cores(core_rows)
        if args.json:
            LOG.info(json.dumps(build_json(args.trace_json, events, unit, makespan, pipe_rows, core_rows), indent=2))
        else:
            print_report(args.trace_json, events, unit, makespan, pipe_rows, core_rows)
        return 0
    except Exception as exc:
        LOG.error("error: %s", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
