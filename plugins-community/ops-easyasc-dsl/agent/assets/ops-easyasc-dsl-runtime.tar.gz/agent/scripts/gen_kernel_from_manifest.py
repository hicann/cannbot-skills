#!/usr/bin/env python3
# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Legacy helper: generate DSL kernel validation scaffolds from author_manifest.json."""

import argparse
import hashlib
import json
import keyword
import logging
import pprint
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple


ROOT = Path(__file__).resolve().parent.parent.parent
VALID_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
ORACLE_HASH_LINE_RE = re.compile(r"^_ORACLE_HASH\s*=.*$", re.MULTILINE)
COMPOSE_IMPORT_RE = re.compile(r"^from\s+([A-Za-z_][A-Za-z0-9_]*)\s+import\s+subkernel", re.MULTILINE)
EXCLUDED_REF_NAMES = {"oracle_slices.py", "__init__.py"}
SUPPORTED_HW_TARGETS = {"a2", "a5"}
TENSOR_KINDS = {"input", "output"}
SUPPORTED_DISTRIBUTION_KINDS = {"normal", "uniform"}
SUPPORTED_TORCH_DTYPES = {
    "torch.float16",
    "torch.float32",
    "torch.int32",
    "torch.int64",
    "torch.int8",
    "torch.uint8",
    "torch.int16",
    "torch.bfloat16",
    "torch.float8_e4m3fn",
    "torch.float8_e5m2",
    "torch.uint16",
    "torch.uint32",
    "torch.uint64",
}


class ManifestError(ValueError):
    pass


def _is_valid_identifier(name: str) -> bool:
    return bool(VALID_NAME_RE.match(name)) and not keyword.iskeyword(name)


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ManifestError(message)


def _load_manifest(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    _require(isinstance(payload, dict), "manifest root must be a JSON object")
    return payload


def _as_list(value: Any, label: str) -> List[Any]:
    _require(isinstance(value, list), f"{label} must be a list")
    return value


def _as_dict(value: Any, label: str) -> Dict[str, Any]:
    _require(isinstance(value, dict), f"{label} must be an object")
    return value


def _shape_rank(shape: Any, label: str) -> int:
    _require(isinstance(shape, list), f"{label}.shape must be a list")
    return len(shape)


def _check_ref_path(path_value: Any, label: str, candidate_dir: Path, allow_missing_paths: bool) -> str:
    _require(isinstance(path_value, str) and path_value, f"{label} must be a non-empty string")
    path = Path(path_value)
    name = path.name
    _require(path.suffix == ".py", f"{label} must point to a .py file: {path_value}")
    _require(name not in EXCLUDED_REF_NAMES, f"{label} is not a sub-kernel reference: {path_value}")
    _require(not name.endswith("_check.py"), f"{label} points to a check file, not a sub-kernel: {path_value}")
    if not allow_missing_paths:
        _require((candidate_dir / path).is_file(), f"{label} does not exist: {candidate_dir / path}")
    return path_value


def _validate_arg_specs(arg_specs: Sequence[Any], label: str) -> List[Dict[str, Any]]:
    specs: List[Dict[str, Any]] = []
    for idx, raw in enumerate(arg_specs):
        spec = _as_dict(raw, f"{label}[{idx}]")
        name = spec.get("name")
        _require(
            isinstance(name, str) and _is_valid_identifier(name),
            f"{label}[{idx}].name is not a valid Python identifier: {name!r}",
        )
        if "shape" in spec:
            _shape_rank(spec["shape"], f"{label}[{idx}]")
        specs.append(spec)
    return specs


def _validate_dtype(dtype: Any, label: str) -> None:
    _require(isinstance(dtype, str) and dtype, f"{label} must be a non-empty string")
    normalized = dtype if dtype.startswith("torch.") else "torch." + dtype
    _require(
        normalized in SUPPORTED_TORCH_DTYPES,
        f"{label} uses dtype unsupported by OpExec scaffold generation: {dtype!r}",
    )


def _validate_tile_hints(sub_name: str, raw: Any) -> None:
    if raw is None:
        return
    _require(isinstance(raw, list), f"{sub_name}.tile_hints must be a list when present")
    seen_indices: Set[int] = set()
    for idx, entry in enumerate(raw):
        label = f"{sub_name}.tile_hints[{idx}]"
        spec = _as_dict(entry, label)
        matmul_index = spec.get("matmul_index")
        _require(
            isinstance(matmul_index, int) and matmul_index >= 0,
            f"{label}.matmul_index must be a non-negative int",
        )
        _require(matmul_index not in seen_indices, f"{label}.matmul_index duplicates an earlier entry: {matmul_index}")
        seen_indices.add(matmul_index)
        for field in ("tile_m", "tile_n", "tile_k"):
            value = spec.get(field)
            _require(isinstance(value, int) and value > 0, f"{label}.{field} must be a positive int")
        split_mode = spec.get("split_mode", "none")
        _require(
            split_mode in {"none", "splitk", "splitn", "mix"},
            f"{label}.split_mode must be one of none/splitk/splitn/mix",
        )
        for field in ("split_k", "split_n"):
            value = spec.get(field)
            _require(
                value is None
                or (isinstance(value, int) and value >= 32)
                or (isinstance(value, int) and value == 0),
                f"{label}.{field} must be null or an int >= 32 (per facts-authoring.md splitk/splitn floor)",
            )


def _validate_input_distribution(sub_name: str, raw: Any, op_args: Sequence[Dict[str, Any]]) -> None:
    if raw is None:
        return
    _require(isinstance(raw, list), f"{sub_name}.input_distribution_assumptions must be a list when present")
    tensor_names = {str(spec["name"]) for spec in op_args if spec.get("kind") in TENSOR_KINDS}
    seen_tensors: Set[str] = set()
    for idx, entry in enumerate(raw):
        label = f"{sub_name}.input_distribution_assumptions[{idx}]"
        spec = _as_dict(entry, label)
        tensor = spec.get("tensor")
        _require(isinstance(tensor, str) and tensor, f"{label}.tensor must be a non-empty string")
        _require(tensor in tensor_names, f"{label}.tensor {tensor!r} is not an op_args tensor")
        _require(tensor not in seen_tensors, f"{label}.tensor duplicates an earlier entry: {tensor}")
        seen_tensors.add(str(tensor))
        kind = spec.get("kind", "normal")
        _require(
            kind in SUPPORTED_DISTRIBUTION_KINDS,
            f"{label}.kind must be one of {sorted(SUPPORTED_DISTRIBUTION_KINDS)}",
        )
        if kind == "normal":
            for field in ("mean", "std"):
                if field in spec:
                    _require(isinstance(spec[field], (int, float)), f"{label}.{field} must be numeric")
            if "std" in spec:
                _require(float(spec["std"]) >= 0.0, f"{label}.std must be non-negative")
        elif kind == "uniform":
            for field in ("low", "high"):
                _require(
                    field in spec and isinstance(spec[field], (int, float)),
                    f"{label}.{field} is required and numeric for uniform",
                )
            _require(float(spec["low"]) <= float(spec["high"]), f"{label}.low must be <= high")


def _validate_subkernel(sub: Dict[str, Any], candidate_dir: Path, allow_missing_paths: bool) -> None:
    name = sub.get("name")
    _require(isinstance(name, str) and _is_valid_identifier(name), f"subkernel name is invalid: {name!r}")
    _check_ref_path(sub.get("reference"), f"{name}.reference", candidate_dir, allow_missing_paths)
    check_path = sub.get("check")
    if check_path is not None and not allow_missing_paths:
        _require(
            (candidate_dir / str(check_path)).is_file(),
            f"{name}.check does not exist: {candidate_dir / str(check_path)}",
        )

    io = _as_dict(sub.get("io"), f"{name}.io")
    ref_args = _validate_arg_specs(_as_list(io.get("ref_args"), f"{name}.io.ref_args"), f"{name}.io.ref_args")
    op_args = _validate_arg_specs(_as_list(io.get("op_args"), f"{name}.io.op_args"), f"{name}.io.op_args")
    returns = _validate_arg_specs(_as_list(io.get("returns"), f"{name}.io.returns"), f"{name}.io.returns")
    shape_bindings = _as_dict(io.get("shape_bindings", {}), f"{name}.io.shape_bindings")

    _require(op_args, f"{name}.io.op_args must not be empty")
    seen_output = False
    seen_var = False
    tensor_arg_count = 0
    scalar_count = 0
    output_names: List[str] = []
    output_name_set: Set[str] = set()
    tensor_ranks: Dict[int, int] = {}
    scalar_dim_to_indices: Dict[str, List[int]] = {}
    parsed_bindings: Dict[int, List[Any]] = {}
    for arg_idx, spec in enumerate(op_args):
        kind = spec.get("kind")
        _require(kind in ("input", "output", "var"), f"{name}.io.op_args[{arg_idx}].kind must be input/output/var")
        if kind in TENSOR_KINDS:
            _validate_dtype(spec.get("dtype"), f"{name}.io.op_args[{arg_idx}].dtype")
            rank = _shape_rank(spec.get("shape"), f"{name}.io.op_args[{arg_idx}]")
            tensor_ranks[tensor_arg_count] = rank
            tensor_arg_count += 1
            if kind == "input":
                _require(
                    not seen_output and not seen_var,
                    f"{name}.io.op_args must be input tensors, then output tensors, then vars",
                )
            else:
                seen_output = True
                _require(not seen_var, f"{name}.io.op_args output tensor appears after a var")
                output_names.append(str(spec["name"]))
                output_name_set.add(str(spec["name"]))
        else:
            seen_var = True
            value_from = spec.get("value_from", "shape:" + str(spec["name"]))
            if isinstance(value_from, str) and value_from.startswith("shape:"):
                dim_name = value_from.split(":", 1)[1]
                scalar_dim_to_indices.setdefault(dim_name, []).append(scalar_count)
            else:
                scalar_dim_to_indices.setdefault(str(spec["name"]), []).append(scalar_count)
            scalar_count += 1
    _require(scalar_count > 0, f"{name}.io.op_args must include at least one var")

    return_names = [str(spec["name"]) for spec in returns]
    _require(return_names, f"{name}.io.returns must not be empty")
    for return_name in return_names:
        _require(return_name in output_name_set, f"{name}.io.returns references non-output arg: {return_name}")

    for key, binding in shape_bindings.items():
        try:
            tensor_idx = int(key)
        except (TypeError, ValueError) as exc:
            raise ManifestError(f"{name}.io.shape_bindings key must be an integer string: {key!r}") from exc
        _require(tensor_idx in tensor_ranks, f"{name}.io.shape_bindings[{key}] references missing tensor arg")
        _require(isinstance(binding, list), f"{name}.io.shape_bindings[{key}] must be a list")
        _require(len(binding) == tensor_ranks[tensor_idx], f"{name}.io.shape_bindings[{key}] rank mismatch")
        parsed_bindings[tensor_idx] = binding
        for dim_idx, scalar_idx in enumerate(binding):
            if scalar_idx is None:
                continue
            _require(isinstance(scalar_idx, int), f"{name}.io.shape_bindings[{key}][{dim_idx}] must be int or null")
            _require(
                0 <= scalar_idx < scalar_count,
                f"{name}.io.shape_bindings[{key}][{dim_idx}] scalar index out of range",
            )

    tensor_idx = 0
    for spec in op_args:
        if spec.get("kind") not in TENSOR_KINDS:
            continue
        shape = spec.get("shape", [])
        for dim_idx, dim in enumerate(shape):
            if not isinstance(dim, str) or dim not in scalar_dim_to_indices:
                continue
            binding = parsed_bindings.get(tensor_idx)
            _require(
                binding is not None,
                f"{name}.io.shape_bindings must explicitly bind symbolic shape {dim!r} "
                f"for tensor arg {tensor_idx}",
            )
            chosen = binding[dim_idx]
            _require(
                isinstance(chosen, int) and chosen in scalar_dim_to_indices[dim],
                f"{name}.io.shape_bindings[{tensor_idx}][{dim_idx}] must bind symbolic shape {dim!r} to scalar index "
                f"{scalar_dim_to_indices[dim]}, got {chosen!r}",
            )
        tensor_idx += 1

    ref_names = {str(spec["name"]) for spec in ref_args}
    op_tensor_names = {str(spec["name"]) for spec in op_args if spec.get("kind") in TENSOR_KINDS}
    missing_ref_names = sorted(ref_names - op_tensor_names)
    _require(
        not missing_ref_names,
        f"{name}.io.ref_args are not available as op tensor args: {', '.join(missing_ref_names)}",
    )

    test_shapes = _merged_test_shapes(sub)
    _require("aligned" in test_shapes, f"{name} must provide test_shapes.aligned or sample_shapes.aligned")
    for case_name, dims in test_shapes.items():
        _require(isinstance(dims, dict), f"{name}.test_shapes.{case_name} must be an object")
        for dim_name, value in dims.items():
            _require(isinstance(dim_name, str) and dim_name, f"{name}.test_shapes.{case_name} has empty dim name")
            _require(
                isinstance(value, int) and value > 0,
                f"{name}.test_shapes.{case_name}.{dim_name} must be a positive int",
            )

    tail_axes = sub.get("tail_axes", [])
    if tail_axes:
        _require("tail" in test_shapes, f"{name} has tail_axes but no tail test shape")

    _validate_tile_hints(name, sub.get("tile_hints"))
    _validate_input_distribution(name, sub.get("input_distribution_assumptions"), op_args)


def _resolve_relative_path(manifest_path: Path, paths_block: Dict[str, Any], key: str, default: str) -> Path:
    raw = paths_block.get(key, default) if isinstance(paths_block, dict) else default
    if not isinstance(raw, str) or not raw:
        raw = default
    return (manifest_path.parent / raw).resolve()


def _hash_oracle_body(text: str) -> str:
    stripped = ORACLE_HASH_LINE_RE.sub("", text)
    return hashlib.sha256(stripped.encode("utf-8")).hexdigest()


def _validate_oracle_hash(manifest: Dict[str, Any], manifest_path: Path) -> None:
    declared = manifest.get("oracle_hash")
    if declared is None or declared == "" or declared == "{sha256_of_oracle_body}":
        return
    _require(isinstance(declared, str), "oracle_hash must be a string when present")
    paths_block = manifest.get("paths") if isinstance(manifest.get("paths"), dict) else {}
    oracle_path = _resolve_relative_path(manifest_path, paths_block, "oracle", "../oracle.py")
    _require(oracle_path.is_file(), f"oracle file not found for hash check: {oracle_path}")
    body = oracle_path.read_text(encoding="utf-8")
    actual = _hash_oracle_body(body)
    embedded = None
    for line in body.splitlines():
        match = re.match(r"^_ORACLE_HASH\s*=\s*['\"]([0-9a-fA-F]+)['\"]\s*$", line)
        if match:
            embedded = match.group(1)
            break
    _require(
        actual == declared,
        f"oracle_hash mismatch: manifest declares {declared!r}, oracle.py body hashes to {actual!r}",
    )
    if embedded is not None:
        _require(
            embedded == declared,
            f"oracle.py _ORACLE_HASH constant ({embedded!r}) disagrees with manifest oracle_hash ({declared!r})",
        )


def _validate_dag_consistency(manifest: Dict[str, Any], manifest_path: Path) -> None:
    paths_block = manifest.get("paths") if isinstance(manifest.get("paths"), dict) else {}
    dag_path = _resolve_relative_path(manifest_path, paths_block, "dag", "dag.json")
    if not dag_path.is_file():
        return  # dag.json is optional; absence is allowed for legacy decompositions
    try:
        dag = json.loads(dag_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ManifestError(f"dag.json is not valid JSON: {dag_path} ({exc})") from exc
    nodes = dag.get("nodes") if isinstance(dag, dict) else None
    _require(isinstance(nodes, list) and nodes, f"dag.json must contain a non-empty 'nodes' list: {dag_path}")
    dag_node_ids: List[str] = []
    for idx, node in enumerate(nodes):
        _require(
            isinstance(node, dict) and isinstance(node.get("id"), str),
            f"dag.json node[{idx}] must be an object with string id",
        )
        dag_node_ids.append(str(node["id"]))
    manifest_sub_names = [str(sub.get("name")) for sub in manifest.get("subkernels", [])]
    missing_in_dag = sorted(set(manifest_sub_names) - set(dag_node_ids))
    _require(
        not missing_in_dag,
        f"dag.json is missing nodes for manifest subkernels: {missing_in_dag} (dag={dag_path})",
    )
    extra_in_dag = sorted(set(dag_node_ids) - set(manifest_sub_names))
    _require(
        not extra_in_dag,
        f"dag.json has nodes that are not in manifest.subkernels: {extra_in_dag} (dag={dag_path})",
    )


def _validate_compose_consistency(manifest: Dict[str, Any], manifest_path: Path) -> None:
    paths_block = manifest.get("paths") if isinstance(manifest.get("paths"), dict) else {}
    compose_path = _resolve_relative_path(manifest_path, paths_block, "compose", "compose.py")
    if not compose_path.is_file():
        return  # compose.py is optional; legacy decompositions may not have it
    body = compose_path.read_text(encoding="utf-8")
    imported = set(COMPOSE_IMPORT_RE.findall(body))
    manifest_sub_names = {str(sub.get("name")) for sub in manifest.get("subkernels", [])}
    missing = sorted(manifest_sub_names - imported)
    _require(not missing, f"compose.py does not import every sub-kernel: missing {missing} (compose={compose_path})")


def validate_manifest(manifest: Dict[str, Any], manifest_path: Path, allow_missing_paths: bool = False) -> None:
    schema_version = manifest.get("schema_version")
    _require(schema_version == 1, f"unsupported schema_version: {schema_version!r}")
    hw_target = manifest.get("hw_target")
    _require(
        hw_target in SUPPORTED_HW_TARGETS,
        f"hw_target must be one of {sorted(SUPPORTED_HW_TARGETS)}, got {hw_target!r}",
    )
    candidate_id = manifest.get("candidate_id")
    _require(isinstance(candidate_id, str) and candidate_id, "candidate_id must be a non-empty string")
    precision = _as_dict(manifest.get("precision_policy"), "precision_policy")
    for field in ("mode", "atol", "rtol"):
        _require(field in precision, f"precision_policy.{field} is required")
    lowerability = _as_dict(manifest.get("lowerability", {"dsl_supported": True}), "lowerability")
    dsl_supported = lowerability.get("dsl_supported")
    _require(isinstance(dsl_supported, bool), "lowerability.dsl_supported must be bool")
    _require(dsl_supported, "lowerability.dsl_supported is false; candidate is not ready for DSL scaffold generation")
    workspace_policy = _as_dict(manifest.get("workspace_policy", {}), "workspace_policy")
    zero_owner = workspace_policy.get("zero_initialization_owner", "none")
    _require(isinstance(zero_owner, str), "workspace_policy.zero_initialization_owner must be a string when present")
    subkernels = _as_list(manifest.get("subkernels"), "subkernels")
    _require(subkernels, "subkernels must not be empty")
    candidate_dir = manifest_path.resolve().parent
    seen_names: Set[str] = set()
    for idx, raw_sub in enumerate(subkernels):
        sub = _as_dict(raw_sub, f"subkernels[{idx}]")
        sub_name = str(sub.get("name", ""))
        _require(sub_name not in seen_names, f"duplicate subkernel name: {sub_name}")
        seen_names.add(sub_name)
        _validate_subkernel(sub, candidate_dir, allow_missing_paths)
    if not allow_missing_paths:
        _validate_oracle_hash(manifest, manifest_path)
        _validate_dag_consistency(manifest, manifest_path)
        _validate_compose_consistency(manifest, manifest_path)


def _merged_test_shapes(sub: Dict[str, Any]) -> Dict[str, Dict[str, int]]:
    raw = sub.get("test_shapes")
    if raw is None:
        raw = sub.get("sample_shapes", {})
    if not isinstance(raw, dict):
        return {}
    result: Dict[str, Dict[str, int]] = {}
    for case_name, dims in raw.items():
        if isinstance(case_name, str) and isinstance(dims, dict):
            result[case_name] = {str(k): int(v) for k, v in dims.items() if isinstance(v, int)}
    return result


def _json_literal(value: Any) -> str:
    """Render a manifest value as a Python source literal.

    JSON null/true/false would be a NameError when imported; pprint emits
    None/True/False directly, and dict keys come out as Python strings.
    """
    return pprint.pformat(value, indent=4, width=88, sort_dicts=True)


def _collect_tensor_specs(sub: Dict[str, Any]) -> List[Dict[str, Any]]:
    io = sub["io"]
    specs_by_name: Dict[str, Dict[str, Any]] = {}
    for spec in io.get("op_args", []):
        if spec.get("kind") in TENSOR_KINDS:
            specs_by_name[str(spec["name"])] = {
                "name": spec["name"],
                "kind": spec["kind"],
                "dtype": spec["dtype"],
                "shape": spec["shape"],
            }
    for spec in io.get("ref_args", []):
        name = str(spec["name"])
        if name not in specs_by_name:
            specs_by_name[name] = {
                "name": name,
                "kind": "input",
                "dtype": spec.get("dtype", "torch.float32"),
                "shape": spec.get("shape", []),
            }
    return list(specs_by_name.values())


def _render_kernel_signature(sub: Dict[str, Any]) -> str:
    params = []
    for spec in sub["io"]["op_args"]:
        kind = spec["kind"]
        annotation = "GMTensor" if kind in TENSOR_KINDS else "Var"
        params.append(f"{spec['name']}: {annotation}")
    if len(params) <= 4:
        params_text = ", ".join(params)
        return f"def {sub['name']}_kernel({params_text}):"
    lines = [f"def {sub['name']}_kernel("]
    for param in params:
        lines.append(f"    {param},")
    lines.append("):")
    return "\n".join(lines)


def _render_return(sub: Dict[str, Any]) -> str:
    names = [str(spec["name"]) for spec in sub["io"]["returns"]]
    if len(names) == 1:
        return f"    return {names[0]}"
    return "    return " + ", ".join(names)


def _tile_hint_block(sub: Dict[str, Any]) -> Tuple[str, List[Dict[str, Any]]]:
    hints = sub.get("tile_hints") or []
    if not isinstance(hints, list):
        hints = []
    if not hints:
        return ("# (no tile_hints in manifest; pick TILE_M/N/K from estimate_strategy)", hints)
    primary = hints[0]
    lines = [
        "# Pre-loaded from manifest tile_hints[0]; revisit during makespan iteration.",
        f"TILE_M = {int(primary['tile_m'])}",
        f"TILE_N = {int(primary['tile_n'])}",
        f"TILE_K = {int(primary['tile_k'])}",
    ]
    if primary.get("split_k") is not None:
        lines.append(f"SPLIT_K = {int(primary['split_k'])}")
    if primary.get("split_n") is not None:
        lines.append(f"SPLIT_N = {int(primary['split_n'])}")
    return ("\n".join(lines), hints)


def render_kernel_file(manifest: Dict[str, Any], sub: Dict[str, Any], manifest_path: Path) -> str:
    name = str(sub["name"])
    hw_target = str(manifest["hw_target"])
    candidate_id = str(manifest["candidate_id"])
    function_name = str(manifest.get("function_name", "unknown"))
    precision = manifest["precision_policy"]
    default_core_count = 32 if hw_target == "a5" else 20
    test_shapes = _merged_test_shapes(sub)
    tensor_specs = _collect_tensor_specs(sub)
    ref_arg_names = [str(spec["name"]) for spec in sub["io"]["ref_args"]]
    op_arg_specs = sub["io"]["op_args"]
    shape_bindings = sub["io"].get("shape_bindings", {})
    return_names = [str(spec["name"]) for spec in sub["io"]["returns"]]
    manifest_ref = str(manifest_path)
    kernel_signature = _render_kernel_signature(sub)
    kernel_return = _render_return(sub)
    tile_block, tile_hints = _tile_hint_block(sub)
    input_distributions = sub.get("input_distribution_assumptions") or []
    if not isinstance(input_distributions, list):
        input_distributions = []

    return f'''"""Generated scaffold for sub-kernel `{name}` of candidate `{candidate_id}`.

Source manifest:
  {manifest_ref}

This file is intentionally generated only up to the validation shell. Fill the
DSL kernel body, then run this script with the simulator. Regenerate the file
only before manual edits, or use --overwrite intentionally.
"""

import json
import os
import sys
from pathlib import Path

import torch

from easyasc.{hw_target} import *


FUNCTION_NAME = {function_name!r}
CANDIDATE_ID = {candidate_id!r}
SUB_NAME = {name!r}
ATOL = {precision["atol"]!r}
RTOL = {precision["rtol"]!r}
DEFAULT_CORE_COUNT = {default_core_count}

SAMPLE_SHAPES = {_json_literal(test_shapes)}
TENSOR_SPECS = {_json_literal(tensor_specs)}
REF_ARG_NAMES = {_json_literal(ref_arg_names)}
OP_ARG_SPECS = {_json_literal(op_arg_specs)}
RETURN_NAMES = {_json_literal(return_names)}
_SHAPE_BINDINGS_JSON = {_json_literal(shape_bindings)}
SHAPE_BINDINGS = {{int(k): v for k, v in _SHAPE_BINDINGS_JSON.items()}}
TILE_HINTS = {_json_literal(tile_hints)}
INPUT_DISTRIBUTIONS = {_json_literal(input_distributions)}

# -----------------------------------------------------------------------------
# Tile parameters (from manifest tile_hints; override during makespan iteration)
# -----------------------------------------------------------------------------
{tile_block}


@kernel()
{kernel_signature}
    # TODO(author): implement the DSL body from plan.md / dag.json.
    # Keep user-visible input dtype semantics from the manifest; lossy casts
    # belong inside the kernel body, not in _build_case().
{kernel_return}


def _import_subkernel_reference():
    manifest_path = Path({manifest_ref!r}).resolve()
    candidate_refs = manifest_path.parent / "refs"
    sys.path.insert(0, str(candidate_refs))
    from {name} import subkernel as ref_fn
    return ref_fn


def _torch_dtype(dtype_name):
    attr = dtype_name.split(".", 1)[1] if dtype_name.startswith("torch.") else dtype_name
    if not hasattr(torch, attr):
        raise TypeError("unsupported torch dtype in manifest: " + dtype_name)
    return getattr(torch, attr)


def _shape_from_spec(shape_spec, dims):
    shape = []
    for dim in shape_spec:
        if isinstance(dim, int):
            shape.append(dim)
        elif isinstance(dim, str):
            if dim not in dims:
                raise KeyError("missing symbolic dim in sample shape: " + dim)
            shape.append(int(dims[dim]))
        else:
            raise TypeError("shape entries must be int or str")
    return tuple(shape)


_INPUT_DISTRIBUTION_BY_NAME = {{str(entry["tensor"]): entry for entry in INPUT_DISTRIBUTIONS}}


def _sample_from_distribution(spec, shape):
    kind = spec.get("kind", "normal")
    if kind == "normal":
        mean = float(spec.get("mean", 0.0))
        std = float(spec.get("std", 1.0))
        return torch.randn(shape, dtype=torch.float32) * std + mean
    if kind == "uniform":
        low = float(spec["low"])
        high = float(spec["high"])
        return torch.rand(shape, dtype=torch.float32) * (high - low) + low
    raise ValueError("unsupported input distribution kind: " + str(kind))


def _rand_tensor(name, dtype_name, shape):
    dtype = _torch_dtype(dtype_name)
    distribution = _INPUT_DISTRIBUTION_BY_NAME.get(name)
    if dtype in (torch.float16, torch.float32, torch.float64, torch.bfloat16):
        if distribution is not None:
            return _sample_from_distribution(distribution, shape).to(dtype)
        return (torch.randn(shape, dtype=torch.float32) * 4.0).to(dtype)
    if hasattr(torch, "float8_e4m3fn") and dtype is torch.float8_e4m3fn:
        if distribution is not None:
            return _sample_from_distribution(distribution, shape).to(dtype)
        return (torch.randn(shape, dtype=torch.float32) * 2.0).to(dtype)
    if hasattr(torch, "float8_e5m2") and dtype is torch.float8_e5m2:
        if distribution is not None:
            return _sample_from_distribution(distribution, shape).to(dtype)
        return (torch.randn(shape, dtype=torch.float32) * 2.0).to(dtype)
    if dtype is torch.bool:
        return torch.randint(0, 2, shape, dtype=torch.int8).bool()
    if distribution is not None and distribution.get("kind") == "uniform":
        low = int(distribution["low"])
        high = int(distribution["high"])
        return torch.randint(low, high + 1, shape, dtype=dtype)
    return torch.randint(-8, 8, shape, dtype=dtype)


def _empty_tensor(dtype_name, shape):
    return torch.empty(shape, dtype=_torch_dtype(dtype_name))


def _resolve_var(spec, dims):
    value_from = spec.get("value_from", "shape:" + spec["name"])
    if isinstance(value_from, int):
        return value_from
    if isinstance(value_from, str) and value_from.startswith("shape:"):
        dim_name = value_from.split(":", 1)[1]
        if dim_name not in dims:
            raise KeyError("missing scalar dim in sample shape: " + dim_name)
        return int(dims[dim_name])
    if spec["name"] in dims:
        return int(dims[spec["name"]])
    raise KeyError("cannot resolve scalar var from manifest: " + spec["name"])


def _build_case(case_name="aligned"):
    if case_name not in SAMPLE_SHAPES:
        raise KeyError("unknown case: " + case_name)
    dims = SAMPLE_SHAPES[case_name]
    values = {{}}
    for spec in TENSOR_SPECS:
        shape = _shape_from_spec(spec.get("shape", []), dims)
        if spec.get("kind") == "output":
            values[spec["name"]] = _empty_tensor(spec["dtype"], shape)
        else:
            values[spec["name"]] = _rand_tensor(spec["name"], spec["dtype"], shape)

    ref_args = tuple(values[name] for name in REF_ARG_NAMES)
    op_args = []
    for spec in OP_ARG_SPECS:
        kind = spec["kind"]
        if kind in ("input", "output"):
            op_args.append(values[spec["name"]])
        elif kind == "var":
            op_args.append(_resolve_var(spec, dims))
        else:
            raise ValueError("unsupported op arg kind: " + str(kind))
    return ref_args, tuple(op_args), SHAPE_BINDINGS


def _as_tuple(value):
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return (value,)


def _assert_outputs_close(actual, expected):
    actual_items = _as_tuple(actual)
    expected_items = _as_tuple(expected)
    if len(actual_items) != len(expected_items):
        raise AssertionError(f"output arity mismatch: actual={{len(actual_items)}} expected={{len(expected_items)}}")
    max_abs = 0.0
    max_rel = 0.0
    for idx, (actual_tensor, expected_tensor) in enumerate(zip(actual_items, expected_items)):
        diff = (actual_tensor.float() - expected_tensor.float()).abs()
        max_abs = max(max_abs, float(diff.max()))
        denom = expected_tensor.float().abs().clamp_min(1e-12)
        max_rel = max(max_rel, float((diff / denom).max()))
        torch.testing.assert_close(
            actual_tensor.float(), expected_tensor.float(),
            rtol=RTOL, atol=ATOL, msg=f"output #{{idx}} exceeded tolerance",
        )
    return max_abs, max_rel


def _trace_makespan(trace_path):
    with open(trace_path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    events = [event for event in payload.get("traceEvents", []) if event.get("ph") == "X"]
    if not events:
        raise ValueError("trace contains no timed events: " + trace_path)
    return max(float(event.get("ts", 0.0)) + float(event.get("dur", 0.0)) for event in events)


def _run_one(version="final", case_name="aligned"):
    from easyasc.simulator import SimulatorConfig
    from easyasc import globvars

    here = Path(__file__).resolve().parent
    trace_dir = here / "traces"
    trace_dir.mkdir(parents=True, exist_ok=True)
    trace_path = str(trace_dir / (SUB_NAME + "_" + version + "_" + case_name + ".json"))

    ref_fn = _import_subkernel_reference()
    ref_args, op_args, shape_bindings = _build_case(case_name=case_name)
    y_ref = ref_fn(*ref_args)

    saved_trace_event = getattr(globvars, "trace_event", False)
    saved_sim_config = getattr({name}_kernel, "_simulator_config", None)
    globvars.trace_event = False
    {name}_kernel._simulator_config = SimulatorConfig(
        core_count=int(getattr(globvars, "core_num", DEFAULT_CORE_COUNT)),
        execution_timeout_s=float(os.environ.get("EASYASC_SIM_TIMEOUT_S", "180.0")),
        trace_enabled=True,
    )
    try:
        y_kernel = OpExec({name}_kernel, simulator=True, trace=trace_path)(*op_args, shape_bindings=shape_bindings)
    finally:
        globvars.trace_event = saved_trace_event
        if saved_sim_config is None:
            try:
                delattr({name}_kernel, "_simulator_config")
            except AttributeError:
                pass
        else:
            {name}_kernel._simulator_config = saved_sim_config

    max_abs, max_rel = _assert_outputs_close(y_kernel, y_ref)
    makespan = _trace_makespan(trace_path)
    print(
        f"{{SUB_NAME}}: case={{case_name}} max_abs={{max_abs:.3e}} max_rel={{max_rel:.3e}} "
        f"(budget atol={{ATOL}}, rtol={{RTOL}}) makespan={{makespan:.1f}} trace={{trace_path}}",
        flush=True,
    )
    return makespan


if __name__ == "__main__":
    torch.manual_seed(42)
    selected_case = os.environ.get("CASE", "")
    cases = [selected_case] if selected_case else list(SAMPLE_SHAPES.keys())
    for case_name in cases:
        _run_one(version=os.environ.get("VERSION", "final"), case_name=case_name)
    print("OK", flush=True)
'''


def _select_subkernels(manifest: Dict[str, Any], names: Optional[Sequence[str]]) -> List[Dict[str, Any]]:
    subs = list(manifest.get("subkernels", []))
    if not names:
        return subs
    name_set = set(names)
    selected = [sub for sub in subs if sub.get("name") in name_set]
    missing = sorted(name_set - {str(sub.get("name")) for sub in selected})
    if missing:
        raise ManifestError("requested sub-kernel(s) not found: " + ", ".join(missing))
    return selected


def _resolve_out_dir(out_arg: str) -> Path:
    path = Path(out_arg)
    return path if path.is_absolute() else ROOT / path


def _output_path(out_dir: Path, sub: Dict[str, Any]) -> Path:
    return out_dir / (str(sub["name"]) + ".py")


try:
    from _logutil import configure_tool_logging
except ImportError:  # imported as agent.scripts.<tool> rather than as a script
    from ._logutil import configure_tool_logging

LOG = logging.getLogger("gen_kernel_from_manifest")

def _emit_rendered_files(
    rendered: Sequence[Tuple[Path, str]], out_dir: Path, overwrite: bool, dry_run: bool,
) -> None:
    if not LOG.handlers:
        configure_tool_logging(LOG)
    if dry_run:
        for path, content in rendered:
            LOG.info("===== %s =====", path)
            LOG.info(content)
        return
    out_dir.mkdir(parents=True, exist_ok=True)
    for path, content in rendered:
        if path.exists() and not overwrite:
            raise FileExistsError(f"refusing to overwrite existing file without --overwrite: {path}")
        path.write_text(content, encoding="utf-8")
        LOG.info(path)


def write_outputs(
    manifest: Dict[str, Any], manifest_path: Path, out_dir: Path,
    subs: Sequence[Dict[str, Any]], overwrite: bool, dry_run: bool,
) -> None:
    rendered: List[Tuple[Path, str]] = []
    for sub in subs:
        rendered.append((_output_path(out_dir, sub), render_kernel_file(manifest, sub, manifest_path)))
    _emit_rendered_files(rendered, out_dir, overwrite, dry_run)


# ---------------------------------------------------------------------------
# Plan-delivery kernel scaffold (self-contained, no refs dependency)
# ---------------------------------------------------------------------------

KERNEL_BODY_MARKER = "# === KERNEL_BODY_PLACEHOLDER ===\n"


def _render_delivery_constants(sub: Dict[str, Any]) -> str:
    lines = [
        "DEFAULT_CORE_COUNT = 32",
        "DEFAULT_SIM_TIMEOUT_S = 180.0",
    ]
    tile_hints = sub.get("tile_hints")
    if tile_hints and isinstance(tile_hints, list) and tile_hints:
        primary = tile_hints[0]
        lines.append("")
        lines.append(f"TILE_M = {int(primary['tile_m'])}")
        lines.append(f"TILE_N = {int(primary['tile_n'])}")
        lines.append(f"TILE_K = {int(primary['tile_k'])}")
        if primary.get("split_k") is not None:
            lines.append(f"SPLIT_K = {int(primary['split_k'])}")
        if primary.get("split_n") is not None:
            lines.append(f"SPLIT_N = {int(primary['split_n'])}")
    return "\n".join(lines)


def _render_delivery_shape_bindings(sub: Dict[str, Any]) -> str:
    bindings = sub["io"].get("shape_bindings", {})
    lines = ["SHAPE_BINDINGS = {"]
    for k, v in bindings.items():
        lines.append(f"    {int(k)}: {v},")
    lines.append("}")
    return "\n".join(lines)


def _delivery_input_tensor_names(sub: Dict[str, Any]) -> List[str]:
    """Return the names of input tensors in op_args order."""
    return [str(spec["name"]) for spec in sub["io"]["op_args"] if spec.get("kind") == "input"]


def _delivery_output_specs(sub: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return specs for output tensors in op_args order."""
    return [spec for spec in sub["io"]["op_args"] if spec.get("kind") == "output"]


def _delivery_return_names(sub: Dict[str, Any]) -> List[str]:
    return [str(spec["name"]) for spec in sub["io"]["returns"]]


def _delivery_scalar_vars(sub: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return scalar Var specs in op_args order."""
    return [spec for spec in sub["io"]["op_args"] if spec.get("kind") == "var"]


def _delivery_derive_scalars(sub: Dict[str, Any]) -> str:
    """Generate code to derive scalar vars from input tensor shapes.

    For each scalar var, looks up shape_bindings to find which input tensor
    supplies that dim, then generates B = int(q_i.shape[0]) style lines.
    """
    op_args = sub["io"]["op_args"]
    scalar_vars = [(i, spec) for i, spec in enumerate(op_args) if spec.get("kind") == "var"]
    if not scalar_vars:
        return ""
    tensor_count = sum(1 for spec in op_args if spec.get("kind") in TENSOR_KINDS)
    shape_bindings_raw = sub["io"].get("shape_bindings", {})

    parsed: Dict[int, List[Any]] = {}
    for k, v in shape_bindings_raw.items():
        parsed[int(k)] = v

    var_to_source: Dict[int, Tuple[str, int, str]] = {}
    for t_idx in range(tensor_count):
        binding = parsed.get(t_idx)
        if binding is None:
            continue
        tensor_name = str([spec for spec in op_args if spec.get("kind") in TENSOR_KINDS][t_idx]["name"])
        for dim_idx, scalar_idx in enumerate(binding):
            if scalar_idx is None:
                continue
            if isinstance(scalar_idx, int) and scalar_idx not in var_to_source:
                var_to_source[scalar_idx] = (tensor_name, dim_idx, tensor_name)

    lines = []
    var_idx = 0
    for _, spec in scalar_vars:
        var_name = str(spec["name"])
        if var_idx in var_to_source:
            src_name, src_dim, _ = var_to_source[var_idx]
            lines.append(f"    {var_name} = int({src_name}.shape[{src_dim}])")
        var_idx += 1
    return "\n".join(lines)


def _delivery_create_outputs(sub: Dict[str, Any], indent: str = "    ") -> str:
    """Generate code to create output placeholder tensors."""
    op_args = sub["io"]["op_args"]
    shape_bindings_raw = sub["io"].get("shape_bindings", {})
    parsed: Dict[int, List[Any]] = {}
    for k, v in shape_bindings_raw.items():
        parsed[int(k)] = v

    var_names = [str(spec["name"]) for spec in op_args if spec.get("kind") == "var"]
    first_input = next((spec for spec in op_args if spec.get("kind") == "input"), None)
    device_ref = str(first_input["name"]) if first_input else "0"

    lines = []
    t_idx = 0
    for spec in op_args:
        if spec.get("kind") != "output":
            if spec.get("kind") in TENSOR_KINDS:
                t_idx += 1
            continue
        name = str(spec["name"])
        dtype = spec.get("dtype", "torch.float32")
        shape_spec = spec.get("shape", [])
        binding = parsed.get(t_idx)

        shape_parts: List[str] = []
        for dim_i, dim_entry in enumerate(shape_spec):
            if isinstance(dim_entry, int):
                shape_parts.append(str(dim_entry))
            elif isinstance(dim_entry, str):
                if binding is not None and dim_i < len(binding) and binding[dim_i] is not None:
                    shape_parts.append(var_names[int(binding[dim_i])])
                else:
                    shape_parts.append("0")
            else:
                shape_parts.append("0")
        shape_str = "(" + ", ".join(shape_parts) + ")"
        lines.append(f"{indent}{name} = torch.empty({shape_str}, dtype={dtype}, device={device_ref}.device)")
        t_idx += 1
    return "\n".join(lines)


def _delivery_opexec_args(sub: Dict[str, Any], indent: str = "    ") -> str:
    """Generate the OpExec call arguments: tensor names, then scalar vars."""
    op_args = sub["io"]["op_args"]
    tensor_names = [str(spec["name"]) for spec in op_args if spec.get("kind") in TENSOR_KINDS]
    var_names = [str(spec["name"]) for spec in op_args if spec.get("kind") == "var"]
    all_args = tensor_names + var_names
    return indent + ", ".join(all_args)


def _delivery_return_stmt(sub: Dict[str, Any]) -> str:
    names = _delivery_return_names(sub)
    if len(names) == 1:
        return f"    return {names[0]}"
    return "    return " + ", ".join(names)


def _delivery_opexec_result_name(sub: Dict[str, Any]) -> str:
    """Variable name to assign OpExec result to in run()."""
    names = _delivery_return_names(sub)
    if len(names) == 1:
        return names[0]
    return "(" + ", ".join(names) + ")"


def _extract_sandbox_kernel_body(sandbox_path: Path) -> Optional[str]:
    """Extract the kernel body from a sandbox file.

    Finds content from the first @vf/@func/@kernel decorator through
    the last line of the @kernel function definition, stopping before
    validation helpers like _import_subkernel_reference or _build_case.
    """
    if not sandbox_path.is_file():
        return None
    content = sandbox_path.read_text(encoding="utf-8")
    lines = content.split("\n")

    start_line = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("@vf(") or stripped.startswith("@func(") or stripped.startswith("@kernel("):
            start_line = i
            break

    if start_line is None:
        return None

    # Find end: last line before validation helpers
    end_markers = [
        "def _import_subkernel_reference",
        "def _build_case",
        "def _torch_dtype",
        "def _shape_from_spec",
        "def _rand_tensor",
        "def _empty_tensor",
        "def _resolve_var",
        "def _as_tuple",
        "def _assert_outputs_close",
        "def _trace_makespan",
        "def _run_one",
        "if __name__",
    ]
    end_line = len(lines)
    for marker in end_markers:
        for i in range(start_line + 1, len(lines)):
            if lines[i].strip().startswith(marker):
                end_line = min(end_line, i)
                break

    if end_line <= start_line:
        end_line = len(lines)

    body_lines = lines[start_line:end_line]
    while body_lines and body_lines[-1].strip() == "":
        body_lines.pop()

    return "\n".join(body_lines)


def _extract_sandbox_header_constants(sandbox_path: Path) -> str:
    """Extract module-level shape/tile constants from sandbox file header.

    Collects lines between imports and the first decorator that look like
    simple constant assignments (UPPER_CASE = value), excluding the
    generated manifest-mirror constants like FUNCTION_NAME, ATOL, etc.
    """
    if not sandbox_path.is_file():
        return ""
    content = sandbox_path.read_text(encoding="utf-8")
    lines = content.split("\n")

    # Skip generated manifest-mirror constants
    skip_prefixes = (
        "FUNCTION_NAME", "CANDIDATE_ID", "SUB_NAME", "ATOL", "RTOL",
        "DEFAULT_CORE_COUNT", "SAMPLE_SHAPES", "TENSOR_SPECS",
        "REF_ARG_NAMES", "OP_ARG_SPECS", "RETURN_NAMES",
        "_SHAPE_BINDINGS_JSON", "SHAPE_BINDINGS", "TILE_HINTS",
        "INPUT_DISTRIBUTIONS",
    )

    in_header = False
    constants: List[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("from easyasc."):
            in_header = True
            continue
        if stripped.startswith("@vf(") or stripped.startswith("@func(") or stripped.startswith("@kernel("):
            break
        if in_header and stripped and not stripped.startswith("#"):
            if "=" in stripped and not stripped.startswith(("def ", "import ", "from ")):
                name = stripped.split("=")[0].strip()
                if name and name[0].isupper() and name not in skip_prefixes:
                    constants.append(line)

    return "\n".join(constants).strip()


def _graft_delivery_from_sandbox(sub: Dict[str, Any], sandbox_dir: Path) -> str:
    """Read sandbox file and extract kernel body for grafting into delivery scaffold.

    Returns the combined header constants + kernel body, or empty string if the
    sandbox file doesn't exist or can't be parsed.
    """
    name = str(sub["name"])
    sandbox_path = sandbox_dir / f"{name}.py"
    if not sandbox_path.is_file():
        return ""

    header = _extract_sandbox_header_constants(sandbox_path)
    body = _extract_sandbox_kernel_body(sandbox_path)
    if not body:
        return ""

    parts = []
    if header:
        parts.append(header)
    parts.append(body)
    return "\n\n".join(parts)


def _render_delivery_trace_path() -> str:
    return '''def _trace_path(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = out_dir if out_dir else os.path.join("tmp", "chunk_delta_traces")
        os.makedirs(trace_dir, exist_ok=True)
        return os.path.join(trace_dir, name + ".json")
    return trace'''


def render_kernel_delivery_file(
    manifest: Dict[str, Any],
    sub: Dict[str, Any],
    manifest_path: Path,
    kernel_body: str = "",
) -> str:
    """Generate a self-contained plan-delivery kernel file."""
    name = str(sub["name"])
    hw_target = str(manifest["hw_target"])

    constants_block = _render_delivery_constants(sub)
    shape_bindings_block = _render_delivery_shape_bindings(sub)
    derive_scalars = _delivery_derive_scalars(sub)
    create_outputs = _delivery_create_outputs(sub)
    return_stmt = _delivery_return_stmt(sub)
    result_name = _delivery_opexec_result_name(sub)
    trace_path_fn = _render_delivery_trace_path()

    kernel_body_block = kernel_body if kernel_body else KERNEL_BODY_MARKER

    return f'''import os
import sys
from pathlib import Path

import torch

_REPO_ROOT = Path(__file__).resolve().parents[4]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from easyasc.{hw_target} import *
from easyasc.simulator import SimulatorConfig


{constants_block}

{shape_bindings_block}


{kernel_body_block}


{trace_path_fn}


def run(
    {', '.join(_delivery_input_tensor_names(sub))},
    simulator=True,
    trace=None,
    gen_only=False,
    out_dir="",
    skip_compile=False,
):
{derive_scalars}
{create_outputs}
    trace_path = _trace_path(trace, out_dir, "{name}")

    saved_sim_config = getattr({name}_kernel, "_simulator_config", None)
    if simulator:
        {name}_kernel._simulator_config = SimulatorConfig(
            core_count=DEFAULT_CORE_COUNT,
            execution_timeout_s=DEFAULT_SIM_TIMEOUT_S,
            trace_enabled=trace_path is not None,
        )

    try:
        {result_name} = OpExec(
            {name}_kernel,
            out_dir=out_dir,
            simulator=simulator,
            trace=trace_path,
            gen_only=gen_only,
            skip_compile=skip_compile,
        )(
{_delivery_opexec_args(sub, indent="            ")},
            shape_bindings=SHAPE_BINDINGS,
        )
    finally:
        if simulator:
            if saved_sim_config is None:
                try:
                    delattr({name}_kernel, "_simulator_config")
                except AttributeError:
                    pass
            else:
                {name}_kernel._simulator_config = saved_sim_config

{return_stmt}


if __name__ == "__main__":
    torch.manual_seed(42)
    B, H = 2, 4
    # TODO(author): generate appropriate input tensors for smoke test
    print("{name}: todo - implement smoke test")
'''


def _chain_order_from_dag(manifest_path: Path) -> List[str]:
    """Return sub-kernel names in execution order from dag.json edges (topological sort)."""
    manifest_dir = manifest_path.parent
    dag_path = manifest_dir / "dag.json"
    if not dag_path.is_file():
        return []

    try:
        dag = json.loads(dag_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []

    nodes = dag.get("nodes", [])
    edges = dag.get("edges", [])

    node_ids = {str(n["id"]) for n in nodes}
    in_degree: Dict[str, int] = {nid: 0 for nid in node_ids}
    adjacency: Dict[str, List[str]] = {nid: [] for nid in node_ids}

    for edge in edges:
        src = str(edge.get("src", ""))
        dst = str(edge.get("dst", ""))
        if src in node_ids and dst in node_ids:
            adjacency.setdefault(src, []).append(dst)
            in_degree[dst] = in_degree.get(dst, 0) + 1

    queue = [nid for nid, deg in in_degree.items() if deg == 0]
    result: List[str] = []
    while queue:
        node = queue.pop(0)
        result.append(node)
        for neighbor in adjacency.get(node, []):
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if len(result) != len(node_ids):
        return sorted(node_ids)
    return result


def _collect_all_user_inputs(manifest: Dict[str, Any], manifest_path: Path) -> List[Dict[str, Any]]:
    """Collect all unique user input tensor specs across all sub-kernels.

    Returns list of {name, dtype, shape} deduplicated by name.
    """
    seen: Dict[str, Dict[str, Any]] = {}
    for sub in manifest.get("subkernels", []):
        for spec in sub["io"]["op_args"]:
            if spec.get("kind") != "input":
                continue
            name = str(spec["name"])
            if name not in seen:
                seen[name] = {
                    "name": name,
                    "dtype": spec.get("dtype", "torch.float32"),
                    "shape": spec.get("shape", []),
                }
    return list(seen.values())


def _dag_intermediate_edges(manifest_path: Path) -> List[Dict[str, Any]]:
    """Return workspace-GM edges from dag.json."""
    dag_path = manifest_path.parent / "dag.json"
    if not dag_path.is_file():
        return []
    try:
        dag = json.loads(dag_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    return [e for e in dag.get("edges", []) if e.get("via") == "workspace-GM"]


def render_kernel_compose_file(
    manifest: Dict[str, Any],
    manifest_path: Path,
    kernel_body: str = "",
) -> str:
    """Generate kernel_compose.py that chains sub-kernel run() calls."""
    hw_target = str(manifest["hw_target"])
    chain_order = _chain_order_from_dag(manifest_path)
    if not chain_order:
        chain_order = [str(sub["name"]) for sub in manifest.get("subkernels", [])]

    # Build import lines
    import_lines = [f"from {name} import run as run_{name}" for name in chain_order]
    compose_inputs = _collect_all_user_inputs(manifest, manifest_path)
    compose_input_names = sorted(set(i["name"] for i in compose_inputs))

    # Build per-sub input maps from manifest
    sub_input_map: Dict[str, List[str]] = {}
    sub_output_names: Dict[str, List[str]] = {}
    for sub in manifest.get("subkernels", []):
        name = str(sub["name"])
        sub_input_map[name] = [str(s["name"]) for s in sub["io"]["op_args"] if s.get("kind") == "input"]
        sub_output_names[name] = [str(s["name"]) for s in sub["io"]["returns"]]

    # All user input names (union across all subs)
    all_input_names: List[str] = compose_input_names

    # Generate run() chain body
    chain_lines: List[str] = []
    intermediate_vars: Dict[str, str] = {}

    for node in chain_order:
        input_names = sub_input_map.get(node, [])
        outputs = sub_output_names.get(node, [])

        args: List[str] = []
        for inp in input_names:
            if inp in intermediate_vars:
                args.append(intermediate_vars[inp])
            else:
                args.append(inp)

        out_vars: List[str] = []
        for out_name in outputs:
            var_name = out_name
            out_vars.append(var_name)

        if len(outputs) == 1:
            chain_lines.append(f"    {outputs[0]} = run_{node}(")
            intermediate_vars[outputs[0]] = outputs[0]
        else:
            chain_lines.append(f"    ({', '.join(outputs)}) = run_{node}(")
            for o in outputs:
                intermediate_vars[o] = o

        chain_lines.append(f"        {', '.join(args)},")
        chain_lines.append("        simulator=simulator,")
        chain_lines.append(f'        trace=_child_trace(trace, out_dir, "{node}"),')
        chain_lines.append("        gen_only=gen_only,")
        chain_lines.append("        out_dir=out_dir,")
        chain_lines.append("        skip_compile=skip_compile,")
        chain_lines.append("    )")

    chain_body = "\n".join(chain_lines)

    # Determine final return types
    final_node = chain_order[-1] if chain_order else ""
    final_outputs = sub_output_names.get(final_node, [])
    if len(final_outputs) == 1:
        return_stmt = f"    return {final_outputs[0]}"
    else:
        return_stmt = "    return " + ", ".join(final_outputs)

    compose_params = all_input_names + [
        "simulator=True",
        "trace=None",
        "gen_only=False",
        "out_dir=\"\"",
        "skip_compile=False",
    ]

    return f'''import os
import sys
from pathlib import Path

import torch


_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

{chr(10).join(import_lines)}


L = 64
D = 128


def _child_trace(trace, out_dir, name):
    if trace is None or trace is False:
        return None
    if trace is True:
        trace_dir = Path(out_dir) / "traces" if out_dir else Path("tmp") / "chunk_delta_traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        return str(trace_dir / (name + ".json"))

    trace_path = Path(trace)
    if trace_path.suffix:
        return str(trace_path.with_name(trace_path.stem + "_" + name + trace_path.suffix))
    trace_path.mkdir(parents=True, exist_ok=True)
    return str(trace_path / (name + ".json"))


def run(
    {', '.join(compose_params)},
):
{chain_body}

{return_stmt}


if __name__ == "__main__":
    torch.manual_seed(42)
    B, H = 2, 4
    # TODO(author): generate appropriate input tensors for smoke test
    print("{hw_target} kernel_compose: todo - implement smoke test")
'''


def _write_plan_delivery_outputs(
    manifest: Dict[str, Any],
    manifest_path: Path,
    out_dir: Path,
    subs: Sequence[Dict[str, Any]],
    sandbox_dir: Optional[Path],
    overwrite: bool,
    dry_run: bool,
) -> None:
    """Write plan-delivery kernel files + kernel_compose.py."""
    rendered: List[Tuple[Path, str]] = []

    for sub in subs:
        name = str(sub["name"])
        kernel_body = ""
        if sandbox_dir is not None:
            grafted = _graft_delivery_from_sandbox(sub, sandbox_dir)
            if grafted:
                kernel_body = grafted
        if not kernel_body:
            kernel_body = KERNEL_BODY_MARKER

        content = render_kernel_delivery_file(manifest, sub, manifest_path, kernel_body=kernel_body)
        rendered.append((out_dir / f"{name}.py", content))

    compose_content = render_kernel_compose_file(manifest, manifest_path)
    rendered.append((out_dir / "kernel_compose.py", compose_content))

    _emit_rendered_files(rendered, out_dir, overwrite, dry_run)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Legacy helper: generate DSL kernel scaffolds from author_manifest.json."
    )
    parser.add_argument("--manifest", required=True, help="Path to legacy candidate author_manifest.json.")
    parser.add_argument("--out", help="Output directory. Required when generating files; ignored with --validate-only.")
    parser.add_argument(
        "--sub", action="append", default=[],
        help="Sub-kernel name to generate. Repeatable. Defaults to all.",
    )
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing generated files.")
    parser.add_argument("--dry-run", action="store_true", help="Print generated files instead of writing them.")
    parser.add_argument("--validate-only", action="store_true", help="Validate the manifest without generating files.")
    parser.add_argument(
        "--allow-missing-paths", action="store_true",
        help="Skip reference/check path existence checks, useful for template validation only.",
    )
    parser.add_argument("--mode", choices=["sandbox", "plan_delivery"], default="sandbox",
                        help="Generation mode: 'sandbox' (default) produces validation-oriented scaffolds; "
                             "'plan_delivery' produces self-contained plan-delivery kernel files.")
    parser.add_argument("--sandbox", help="Path to sandbox directory containing authored kernel files. "
                                          "When provided in plan_delivery mode, kernel bodies are grafted "
                                          "from sandbox files into delivery scaffolds.")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    configure_tool_logging(LOG)
    parser = build_parser()
    args = parser.parse_args(argv)
    manifest_path = Path(args.manifest)
    if not manifest_path.is_absolute():
        manifest_path = ROOT / manifest_path
    try:
        manifest = _load_manifest(manifest_path)
        is_delivery = args.mode == "plan_delivery"
        validate_manifest(manifest, manifest_path, allow_missing_paths=args.allow_missing_paths)
        subs = _select_subkernels(manifest, args.sub)
        if args.validate_only:
            LOG.info("OK: %s (%d sub-kernel(s) selected)", manifest_path, len(subs))
            return 0
        if not args.out:
            raise ManifestError("--out is required when generating files (no default; pass an explicit path)")
        out_dir = _resolve_out_dir(args.out)
        sandbox_dir = None
        if args.sandbox:
            sandbox_dir = _resolve_out_dir(args.sandbox)
            if not sandbox_dir.is_dir():
                raise ManifestError(f"--sandbox directory does not exist: {sandbox_dir}")
        if is_delivery:
            _write_plan_delivery_outputs(
                manifest, manifest_path, out_dir, subs,
                sandbox_dir=sandbox_dir, overwrite=args.overwrite, dry_run=args.dry_run,
            )
        else:
            write_outputs(manifest, manifest_path, out_dir, subs, overwrite=args.overwrite, dry_run=args.dry_run)
    except (ManifestError, OSError) as exc:
        LOG.error("ERROR: %s", exc)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
