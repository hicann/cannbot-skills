#!/usr/bin/env python3
# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Select relevant kernel examples by dataflow pattern and task evidence."""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

ROOT = Path(__file__).resolve().parent.parent.parent
KERNEL_INDEX = ROOT / "agent" / "index" / "kernels.json"

TOPOLOGY_CHOICES = [
    "cube-only",
    "cube->vec",
    "vec->cube",
    "vec->cube->vec",
    "cube->vec->cube->vec",
    "vec-only",
    "micro-only",
]
TAG_CHOICES = [
    "splitk",
    "splitn",
    "fp8",
    "dual-output",
    "delayed-stage",
    "rowwise-norm",
    "quant",
]
FEATURE_CHOICES = [
    "vec-postprocess",
    "vec-preprocess",
    "atomic-add",
    "two-pass",
]
DEVICE_CHOICES = ["a2", "a5", "a5pr"]
WORD_RE = re.compile(r"[a-z0-9]+")


def _flatten_text(value: Any) -> str:
    if isinstance(value, list):
        return " ".join(_flatten_text(item) for item in value)
    if value is None:
        return ""
    return str(value)


def _normalize_text(text: str) -> str:
    text = text.lower().replace("`", "")
    text = text.replace("→", "->")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _tokenize(text: str) -> List[str]:
    return WORD_RE.findall(_normalize_text(text))


def _expand_query_tokens(tokens: Sequence[str]) -> List[str]:
    expanded = []
    seen = set()
    for token in tokens:
        candidates = [token]
        if token.startswith("add") and any(ch.isdigit() for ch in token[3:]):
            candidates.append("add")
        if token == "quant":
            candidates.append("quantized")
        if token == "norm":
            candidates.extend(["normalize", "normalization"])
        for candidate in candidates:
            if candidate in seen:
                continue
            seen.add(candidate)
            expanded.append(candidate)
    return expanded


def _canonical_topology(text: str) -> str:
    normalized = _normalize_text(text).replace(" ", "")
    if "cube->vec->cube->vec" in normalized:
        return "cube->vec->cube->vec"
    if "vec->cube->vec" in normalized:
        return "vec->cube->vec"
    if "vec->cube" in normalized:
        return "vec->cube"
    if "cube->vec" in normalized:
        return "cube->vec"
    if "cube-only" in normalized or normalized == "cubeonly":
        return "cube-only"
    if "vec-only" in normalized or normalized == "veconly":
        return "vec-only"
    if "micro-only" in normalized or normalized == "microonly":
        return "micro-only"
    return _normalize_text(text)


def _collect_entry_text(entry: Dict[str, Any], include_negative_guidance: bool = False) -> str:
    parts = [
        _flatten_text(entry.get("name", "")),
        _flatten_text(entry.get("path", "")),
        _flatten_text(entry.get("category", "")),
        _flatten_text(entry.get("formula", "")),
        _flatten_text(entry.get("topology", "")),
        _flatten_text(entry.get("patterns", [])),
        _flatten_text(entry.get("study_for", [])),
    ]
    if include_negative_guidance:
        parts.append(_flatten_text(entry.get("do_not_copy_when", [])))
    return _normalize_text(" ".join(part for part in parts if part))


def _explicit_targets(entry: Dict[str, Any]) -> Optional[Set[str]]:
    if "targets" not in entry:
        return None
    raw_targets = entry["targets"]
    path = str(entry.get("path", "<unknown>"))
    if not isinstance(raw_targets, list) or not raw_targets:
        raise ValueError(
            "%s: targets must be a non-empty list containing a2, a5, or a5pr" % path
        )
    normalized = []
    for target in raw_targets:
        if not isinstance(target, str):
            raise ValueError("%s: every targets item must be a string" % path)
        value = _normalize_text(target)
        if value not in DEVICE_CHOICES:
            raise ValueError("%s: unsupported target %r" % (path, target))
        normalized.append(value)
    if len(normalized) != len(set(normalized)):
        raise ValueError("%s: targets contains duplicate values" % path)
    return set(normalized)


def _entry_device(entry: Dict[str, Any]) -> str:
    explicit_targets = _explicit_targets(entry)
    if explicit_targets is not None and len(explicit_targets) == 1:
        return next(iter(explicit_targets))
    explicit = _normalize_text(_flatten_text(entry.get("device", "")))
    if explicit in DEVICE_CHOICES:
        return explicit
    path = "/" + str(entry.get("path", "")).strip("/") + "/"
    for device in DEVICE_CHOICES:
        if "/%s/" % device in path:
            return device
    return "either"


def _entry_targets(entry: Dict[str, Any]) -> Set[str]:
    """Return recommended targets, preserving legacy A5-family catalogs.

    Target-specific records must declare a non-empty ``targets`` list. Invalid
    or empty declarations are errors rather than permission to broaden the
    result through path inference.

    Legacy records without ``targets`` can still declare an exact ``device``.
    Existing ``agent/example/kernels/a5/`` records predate A5PR, so they are treated as
    A5-family examples unless their negative guidance explicitly says that an
    A5PR task is a reason not to copy the example.
    """
    explicit_targets = _explicit_targets(entry)
    if explicit_targets is not None:
        return explicit_targets

    explicit = _normalize_text(_flatten_text(entry.get("device", "")))
    if explicit in DEVICE_CHOICES:
        return {explicit}

    path = "/" + str(entry.get("path", "")).strip("/") + "/"
    if "/a2/" in path:
        return {"a2"}
    if "/a5pr/" in path:
        return {"a5pr"}
    if "/a5/" in path:
        targets = {"a5", "a5pr"}
        negative_guidance = _normalize_text(_flatten_text(entry.get("do_not_copy_when", [])))
        if re.search(r"\ba5pr\b", negative_guidance):
            targets.discard("a5pr")
        return targets
    return set(DEVICE_CHOICES)


def _derive_tags(entry: Dict[str, Any], entry_text: str) -> Set[str]:
    tags = set()
    text = entry_text
    if "splitk" in text or "split-k" in text:
        tags.add("splitk")
    if "splitn" in text or "split-n" in text:
        tags.add("splitn")
    if any(token in text for token in ["fp8", "float8", "e5m2", "e4m3"]):
        tags.add("fp8")
    if any(token in text for token in ["dual output", "dual-output", "two outputs", "dual-fp8-output"]):
        tags.add("dual-output")
    if any(token in text for token in ["delayed", "lookahead", "warmup and drain"]):
        tags.add("delayed-stage")
    if "rowwise" in text and any(token in text for token in ["norm", "normalize"]):
        tags.add("rowwise-norm")
    if any(token in text for token in ["quant", "quantized", "absmax", "scale = absmax"]):
        tags.add("quant")
    return tags


def _derive_features(entry: Dict[str, Any], entry_text: str, topology: str) -> Set[str]:
    features = set()
    text = entry_text
    if topology in ["cube->vec", "vec->cube->vec", "cube->vec->cube->vec"]:
        features.add("vec-postprocess")
    if topology in ["vec->cube", "vec->cube->vec"]:
        features.add("vec-preprocess")
    if "atomic" in text:
        features.add("atomic-add")
    if "two-pass" in text:
        features.add("two-pass")
    return features


def _field_token_sets(entry: Dict[str, Any]) -> Dict[str, Set[str]]:
    return {
        "name": set(_tokenize(entry.get("name", ""))),
        "path": set(_tokenize(entry.get("path", ""))),
        "category": set(_tokenize(entry.get("category", ""))),
        "formula": set(_tokenize(_flatten_text(entry.get("formula", "")))),
        "patterns": set(_tokenize(_flatten_text(entry.get("patterns", [])))),
        "study_for": set(_tokenize(_flatten_text(entry.get("study_for", [])))),
    }


def _find_token_overlap(tokens: Sequence[str], token_set: Set[str]) -> Set[str]:
    overlap = set()
    for token in tokens:
        if token in token_set:
            overlap.add(token)
            continue
        if len(token) < 3:
            continue
        # Prefix matching only against candidates that are themselves >= 3 chars,
        # so a query token like "add" / "add1" does not spuriously match a
        # single-letter formula variable such as the "a" in `(a @ b.t())`.
        if any(
            len(candidate) >= 3 and (candidate.startswith(token) or token.startswith(candidate))
            for candidate in token_set
        ):
            overlap.add(token)
    return overlap


def _match_query(tokens: Sequence[str], field_tokens: Dict[str, Set[str]]) -> Tuple[int, List[str], Set[str]]:
    if not tokens:
        return 0, [], set()

    weights = {
        "name": 3,
        "path": 2,
        "formula": 3,
        "patterns": 4,
        "study_for": 2,
        "category": 1,
    }
    score = 0
    matched_fields = []
    matched_tokens = set()

    for field_name, token_set in field_tokens.items():
        overlap = _find_token_overlap(tokens, token_set)
        if not overlap:
            continue
        matched_tokens.update(overlap)
        score += len(overlap) * weights[field_name]
        matched_fields.append("%s=%s" % (field_name, ", ".join(sorted(overlap))))

    return score, matched_fields, matched_tokens


def _score_query_intent(query_tokens: Sequence[str], entry_tokens: Set[str]) -> Tuple[int, List[str]]:
    score = 0
    reasons = []
    query_token_set = set(query_tokens)

    requested_devices = query_token_set.intersection(DEVICE_CHOICES)
    for device in sorted(requested_devices):
        if device in entry_tokens:
            score += 6
            reasons.append("device intent matched: %s" % device)
        else:
            score -= 6
            reasons.append("device intent not matched: %s" % device)

    if query_token_set.intersection(["softmax", "normalized"]):
        matched = sorted(_find_token_overlap(["softmax", "normalized"], entry_tokens))
        if matched:
            score += len(matched) * 2
            reasons.append("normalized/softmax intent matched: %s" % ", ".join(matched))

    specialization_groups = [
        ("causal specialization", {"causal"}),
        ("fp8 specialization", {"fp8", "float8", "e5m2", "e4m3"}),
        ("hif8 specialization", {"hif8"}),
        ("block32 specialization", {"block32"}),
    ]
    for label, group_tokens in specialization_groups:
        if query_token_set.intersection(group_tokens):
            continue
        matched = sorted(entry_tokens.intersection(group_tokens))
        if matched:
            score -= 3
            reasons.append("%s unrequested: %s" % (label, ", ".join(matched)))

    return score, reasons


def load_index(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(
            "Kernel index not found: %s. Run `python3 agent/scripts/build_agent_index.py` first." % path
        )
    return json.loads(path.read_text(encoding="utf-8"))


def _score_tag_matches(
    requested_tags: Sequence[str], tags: Set[str], field_tokens: Dict[str, Set[str]],
) -> Optional[Tuple[int, List[str]]]:
    if any(tag not in tags for tag in requested_tags):
        return None
    score = 0
    reasons: List[str] = []
    for tag in requested_tags:
        score += 4
        reasons.append("tag matched: %s" % tag)
        # Prefer a kernel for which the requested tag is central to its
        # identity (e.g. `..._splitk.py`) over one that merely supports it as
        # one mode among several (e.g. a bias kernel that also does splitk).
        if tag in field_tokens["name"] or tag in field_tokens["path"]:
            score += 2
            reasons.append("tag central to kernel identity: %s" % tag)
    return score, reasons


def score_entries(
    entries: Iterable[Dict[str, Any]], args: argparse.Namespace,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    strong_results = []
    weak_results = []
    query_text = " ".join(part for part in [args.query, args.formula] if part)
    query_tokens = _expand_query_tokens(_tokenize(query_text))

    for entry in entries:
        device = _entry_device(entry)
        targets = _entry_targets(entry)
        if args.device and args.device not in targets:
            continue
        entry_text = _collect_entry_text(entry)
        entry_tokens = set(_tokenize(entry_text))
        entry_tokens.update(targets)
        topology = _canonical_topology(entry.get("topology", ""))
        patterns = entry.get("patterns", [])
        if isinstance(patterns, str):
            patterns = [patterns]
        patterns = [_normalize_text(pattern) for pattern in patterns]
        tags = _derive_tags(entry, entry_text)
        features = _derive_features(entry, entry_text, topology)
        field_tokens = _field_token_sets(entry)
        reasons = []
        score = 0

        if args.topology:
            requested_topology = _canonical_topology(args.topology)
            if topology != requested_topology:
                continue
            score += 10
            reasons.append("topology matched: %s" % requested_topology)

        requested_patterns = [_normalize_text(pattern) for pattern in args.pattern]
        missing_patterns = [pattern for pattern in requested_patterns if pattern not in patterns]
        if missing_patterns:
            continue
        for pattern in requested_patterns:
            score += 6
            reasons.append("pattern matched: %s" % pattern)

        tag_result = _score_tag_matches(args.tag, tags, field_tokens)
        if tag_result is None:
            continue
        score += tag_result[0]
        reasons.extend(tag_result[1])

        missing_features = [feature for feature in args.has if feature not in features]
        if missing_features:
            continue
        for feature in args.has:
            score += 3
            reasons.append("feature matched: %s" % feature)

        if args.dtype:
            dtype_token = _normalize_text(args.dtype)
            if dtype_token not in entry_text:
                continue
            score += 2
            reasons.append("dtype matched: %s" % dtype_token)

        query_score, matched_fields, matched_tokens = _match_query(query_tokens, field_tokens)
        score += query_score
        if matched_fields:
            reasons.append("query matched: %s" % "; ".join(matched_fields))

        intent_score, intent_reasons = _score_query_intent(query_tokens, entry_tokens)
        score += intent_score
        reasons.extend(intent_reasons)

        result = {
            "path": entry["path"],
            "device": device,
            "targets": sorted(targets),
            "name": entry.get("name", Path(entry["path"]).name),
            "category": entry.get("category", ""),
            "formula": entry.get("formula", ""),
            "topology": topology,
            "patterns": patterns,
            "study_for": entry.get("study_for", []),
            "deep_note": entry.get("deep_note", ""),
            "do_not_copy_when": entry.get("do_not_copy_when", []),
            "score": score,
            "why": reasons,
            "order": entry.get("order", 0),
            "tags": sorted(tags),
            "features": sorted(features),
            "matched_query_tokens": sorted(matched_tokens),
        }

        is_strong = True
        if query_tokens:
            is_strong = bool(matched_tokens)
        if is_strong:
            strong_results.append(result)
        else:
            weak_results.append(result)

    def key(item):
        return (-item["score"], item["order"], item["path"])

    strong_results.sort(key=key)
    weak_results.sort(key=key)
    return strong_results, weak_results


def _print_list_block(title: str, items: Any) -> None:
    text_items = items if isinstance(items, list) else [items]
    print("   %s:" % title)
    for item in text_items:
        print("   - %s" % item)


def print_text_results(results: List[Dict[str, Any]], args: argparse.Namespace, weak: bool = False) -> None:
    if args.path_only:
        for item in results:
            print(item["path"])
        return

    if weak:
        print("No strong match found. Showing weaker candidates:\n")

    for index, item in enumerate(results, start=1):
        print("%d. %s" % (index, item["path"]))
        print("   category: %s" % item["category"])
        print("   targets: %s" % ", ".join(item["targets"]))
        print("   topology: %s" % item["topology"])
        if item["patterns"]:
            print("   patterns: %s" % ", ".join(item["patterns"]))
        if args.show_score:
            print("   score: %s" % item["score"])
        if args.show_why:
            print("   why: %s" % (" | ".join(item["why"]) if item["why"] else "no specific match reason"))
        _print_list_block("study_for", item["study_for"])
        _print_list_block("do_not_copy_when", item["do_not_copy_when"])
        if args.catalog:
            _print_list_block("formula", item["formula"])
            if item["deep_note"]:
                print("   deep_note: %s" % item["deep_note"])
            if item["tags"]:
                print("   tags: %s" % ", ".join(item["tags"]))
            if item["features"]:
                print("   features: %s" % ", ".join(item["features"]))
        print()


def print_json_results(results: List[Dict[str, Any]], args: argparse.Namespace, weak: bool = False) -> None:
    payload = {
        "query": {
            "query": args.query,
            "formula": args.formula,
            "topology": _canonical_topology(args.topology) if args.topology else None,
            "patterns": list(args.pattern),
            "tags": list(args.tag),
            "has": list(args.has),
            "dtype": args.dtype,
            "device": args.device,
            "weak_only": weak,
        },
        "result_count": len(results),
        "results": results,
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Select relevant kernel examples by pattern, topology, and task text from agent/index/kernels.json."
    )
    parser.add_argument("--query", default="", help="Free-form task description or formula keywords.")
    parser.add_argument("--formula", default="", help="Formula-focused query text.")
    parser.add_argument("--topology", choices=TOPOLOGY_CHOICES, help="Canonical topology filter.")
    parser.add_argument("--pattern", action="append", default=[], help="Repeatable exact dataflow-pattern id filter.")
    parser.add_argument("--tag", action="append", default=[], choices=TAG_CHOICES, help="Repeatable tag filter.")
    parser.add_argument(
        "--has", action="append", default=[], choices=FEATURE_CHOICES,
        help="Repeatable feature filter.",
    )
    parser.add_argument("--dtype", default="", help="Optional dtype keyword filter.")
    parser.add_argument("--device", choices=DEVICE_CHOICES, help="Require an example for the target device.")
    parser.add_argument("--limit", type=int, default=5, help="Maximum number of results to print.")
    parser.add_argument("--json", action="store_true", help="Print JSON output.")
    parser.add_argument("--show-score", action="store_true", help="Show per-result match score in text mode.")
    parser.add_argument("--show-why", action="store_true", help="Show short reasoning in text mode.")
    parser.add_argument("--path-only", action="store_true", help="Print only ranked source paths.")
    parser.add_argument("--catalog", action="store_true", help="Print richer catalog-style fields in text mode.")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.limit <= 0:
        parser.error("--limit must be > 0")

    try:
        payload = load_index(KERNEL_INDEX)
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    try:
        strong_results, weak_results = score_entries(payload.get("entries", []), args)
    except ValueError as exc:
        print("Invalid kernel target metadata: %s" % exc, file=sys.stderr)
        return 1
    results = strong_results[: args.limit]
    weak = False

    if not results and weak_results:
        results = weak_results[: args.limit]
        weak = True

    if args.json:
        print_json_results(results, args, weak=weak)
        return 0

    if not results:
        print("No match found.")
        return 0

    print_text_results(results, args, weak=weak)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
