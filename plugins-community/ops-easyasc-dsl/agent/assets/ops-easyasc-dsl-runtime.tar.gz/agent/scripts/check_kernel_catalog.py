#!/usr/bin/env python3
# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Check kernel catalog consistency and lightweight kernel source guardrails."""

import argparse
import ast
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

TOOLS_DIR = Path(__file__).resolve().parent
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

from build_agent_index import parse_catalog

ROOT = TOOLS_DIR.parent.parent
DEFAULT_CATALOG = ROOT / "agent" / "references" / "examples" / "kernel-catalog.md"
DEFAULT_LEAN_INDEX = ROOT / "agent" / "references" / "examples" / "kernel-index.md"
DEFAULT_INDEX = ROOT / "agent" / "index" / "kernels.json"
DEFAULT_KERNEL_DIR = ROOT / "kernels"
REQUIRED_SCALAR_FIELDS = ["topology"]
REQUIRED_LIST_FIELDS = ["study_for", "do_not_copy_when"]
REQUIRED_TEXT_FIELDS = ["formula"]
UB_LOCAL_FACTORIES = {"Tensor", "DBuff", "TBuff", "QBuff"}
LEAN_KERNEL_PATH_RE = re.compile(r"`(agent/example/(?:kernels|projects)/[^`]+\.py)`")
TARGET_CHOICES = {"a2", "a5", "a5pr"}
A5PR_IMPORT_RE = re.compile(r"^\s*from\s+easyasc\.a5pr\s+import\b", re.MULTILINE)
A5_ONLY_MARKERS = (
    "intentionally A5-only",
    "supports only EASYASC_TARGET=a5",
)


def _warning(
    code: str, path: str, message: str, field: str = "", line: Optional[int] = None,
) -> Dict[str, Any]:
    payload = {
        "code": code,
        "path": path,
        "message": message,
    }
    if field:
        payload["field"] = field
    if line is not None:
        payload["line"] = line
    return payload


def _kernel_files(root: Path, kernel_dir: Path) -> List[str]:
    paths = []
    for path in kernel_dir.rglob("*.py"):
        if not path.is_file() or path.name.startswith("_"):
            continue
        if "baseline_original" in path.parts or path.name.endswith("_original.py"):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError:
            continue
        if not any(
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and any(
                _call_name(decorator.func if isinstance(decorator, ast.Call) else decorator) == "kernel"
                for decorator in node.decorator_list
            )
            for node in tree.body
        ):
            continue
        paths.append(str(path.relative_to(root)))
    return sorted(paths)


def _kernel_source_files(kernel_dir: Path) -> List[Path]:
    return sorted(path for path in kernel_dir.rglob("*.py") if path.is_file())


def _load_json(path: Path) -> Tuple[Dict[str, Any], str]:
    try:
        return json.loads(path.read_text(encoding="utf-8")), ""
    except json.JSONDecodeError as exc:
        return {}, f"Invalid JSON: {exc}"


def _lean_kernel_paths(path: Path) -> set:
    paths = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.lstrip().startswith("|"):
            continue
        paths.update(LEAN_KERNEL_PATH_RE.findall(line))
    return paths


def _dotted_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _dotted_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    return ""


def _call_name(node: ast.AST) -> str:
    name = _dotted_name(node)
    return name.rsplit(".", 1)[-1] if name else ""


def _eval_int_expr(node: ast.AST, constants: Dict[str, int]) -> Optional[int]:
    if isinstance(node, ast.Constant):
        if isinstance(node.value, bool) or not isinstance(node.value, int):
            return None
        return node.value
    if isinstance(node, ast.Name):
        return constants.get(node.id)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        value = _eval_int_expr(node.operand, constants)
        return -value if value is not None else None
    if isinstance(node, ast.BinOp):
        left = _eval_int_expr(node.left, constants)
        right = _eval_int_expr(node.right, constants)
        if left is None or right is None:
            return None
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.FloorDiv) and right != 0:
            return left // right
    return None


def _module_int_constants(tree: ast.Module) -> Dict[str, int]:
    constants: Dict[str, int] = {}
    for stmt in tree.body:
        if not isinstance(stmt, ast.Assign) or len(stmt.targets) != 1:
            continue
        target = stmt.targets[0]
        if not isinstance(target, ast.Name):
            continue
        value = _eval_int_expr(stmt.value, constants)
        if value is not None:
            constants[target.id] = value
    return constants


def _shape_arg(call: ast.Call) -> Optional[ast.AST]:
    if len(call.args) >= 2:
        return call.args[1]
    for keyword in call.keywords:
        if keyword.arg == "shape":
            return keyword.value
    return None


def _has_ub_position(call: ast.Call) -> bool:
    position_arg = call.args[2] if len(call.args) >= 3 else None
    if position_arg is not None and _dotted_name(position_arg).endswith("Position.UB"):
        return True
    for keyword in call.keywords:
        if keyword.arg in {"position", "pos"} and _dotted_name(keyword.value).endswith("Position.UB"):
            return True
    return False


def _second_dim_is_one(shape: ast.AST, constants: Dict[str, int]) -> bool:
    if not isinstance(shape, (ast.List, ast.Tuple)) or len(shape.elts) < 2:
        return False
    return _eval_int_expr(shape.elts[1], constants) == 1


def _ub_second_dim_one_warnings(root: Path, kernel_dir: Path) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    for path in _kernel_source_files(kernel_dir):
        rel_path = str(path.relative_to(root))
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=rel_path)
        except SyntaxError as exc:
            warnings.append(
                _warning(
                    "invalid-kernel-python", rel_path,
                    f"Kernel source could not be parsed: {exc}",
                    line=exc.lineno,
                )
            )
            continue

        constants = _module_int_constants(tree)
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if _call_name(node.func) not in UB_LOCAL_FACTORIES or not _has_ub_position(node):
                continue
            shape = _shape_arg(node)
            if shape is None or not _second_dim_is_one(shape, constants):
                continue
            warnings.append(
                _warning(
                    "ub-second-dim-one",
                    rel_path,
                    "UB local tensor allocation has shape[1] statically equal to 1. "
                    "Use a row-scalar layout such as [1, M] or pad the second "
                    "dimension to a 32-byte lane.",
                    line=node.lineno,
                )
            )
    return warnings


def analyze_repo(
    root: Path = ROOT,
    catalog_path: Path = DEFAULT_CATALOG,
    index_path: Path = DEFAULT_INDEX,
    kernel_dir: Path = DEFAULT_KERNEL_DIR,
    lean_index_path: Optional[Path] = None,
) -> Dict[str, Any]:
    warnings: List[Dict[str, Any]] = []

    if not catalog_path.exists():
        return {
            "warning_count": 1,
            "warnings": [_warning("missing-catalog", str(catalog_path), "Kernel catalog file does not exist.")],
            "entry_count": 0,
            "catalog_paths": [],
            "kernel_files": [],
        }

    payload = parse_catalog(catalog_path, kind="kernel", root=root)
    entries = payload["entries"]
    catalog_paths: List[str] = []
    seen_paths = set()

    for entry in entries:
        path = entry["path"]
        catalog_paths.append(path)

        if path in seen_paths:
            warnings.append(_warning(
                "duplicate-entry-path", path,
                "Catalog contains the same kernel path more than once.",
            ))
        else:
            seen_paths.add(path)

        file_path = root / path
        if not file_path.exists():
            warnings.append(_warning("missing-file", path, "Catalog entry points to a file that does not exist."))

        explicit_targets = None
        if "targets" in entry:
            raw_targets = entry["targets"]
            if not isinstance(raw_targets, list) or not raw_targets:
                warnings.append(_warning(
                    "malformed-targets", path,
                    "targets must be a non-empty list containing a2, a5, or a5pr.",
                    field="targets",
                ))
            elif any(not isinstance(target, str) or target not in TARGET_CHOICES for target in raw_targets):
                warnings.append(_warning(
                    "malformed-targets", path,
                    "targets contains a non-string or unsupported target.",
                    field="targets",
                ))
            elif len(raw_targets) != len(set(raw_targets)):
                warnings.append(_warning(
                    "malformed-targets", path,
                    "targets contains duplicate values.", field="targets",
                ))
            else:
                explicit_targets = set(raw_targets)

        if file_path.is_file():
            source_text = file_path.read_text(encoding="utf-8")
            if A5PR_IMPORT_RE.search(source_text) and explicit_targets != {"a5pr"}:
                warnings.append(_warning(
                    "target-metadata", path,
                    "A kernel importing easyasc.a5pr must declare targets: [a5pr].",
                    field="targets",
                ))
            if any(marker in source_text for marker in A5_ONLY_MARKERS) and explicit_targets != {"a5"}:
                warnings.append(_warning(
                    "target-metadata", path,
                    "An explicitly A5-only kernel must declare targets: [a5].",
                    field="targets",
                ))

        for field in REQUIRED_SCALAR_FIELDS:
            value = entry.get(field)
            if not isinstance(value, str) or not value.strip():
                warnings.append(_warning(
                    "missing-field", path,
                    "Required scalar field is missing or empty.", field=field,
                ))

        for field in REQUIRED_TEXT_FIELDS:
            value = entry.get(field)
            if isinstance(value, str):
                if not value.strip():
                    warnings.append(_warning(
                        "missing-field", path,
                        "Required text field is missing or empty.", field=field,
                    ))
            elif isinstance(value, list):
                if not value or any(not isinstance(item, str) or not item.strip() for item in value):
                    warnings.append(_warning(
                        "missing-field", path,
                        "Required text field is missing or empty.", field=field,
                    ))
            else:
                warnings.append(_warning(
                    "missing-field", path,
                    "Required text field is missing or empty.", field=field,
                ))

        for field in REQUIRED_LIST_FIELDS:
            value = entry.get(field)
            if not isinstance(value, list) or not value:
                warnings.append(_warning(
                    "missing-field", path,
                    "Required list field is missing or empty.", field=field,
                ))
            elif any(not isinstance(item, str) or not item.strip() for item in value):
                warnings.append(_warning(
                    "malformed-field", path,
                    "List field contains an empty or non-string item.", field=field,
                ))

    kernel_files = _kernel_files(root, kernel_dir)
    missing_from_catalog = sorted(set(kernel_files) - set(catalog_paths))
    for path in missing_from_catalog:
        warnings.append(_warning(
            "uncataloged-kernel", path,
            "Kernel file exists under agent/example/kernels/ but is missing from kernel-catalog.md.",
        ))

    warnings.extend(_ub_second_dim_one_warnings(root, kernel_dir))

    # ``lean_index_path`` is opt-in at the library boundary for compatibility
    # with callers that predate the human-readable index.  The CLI passes the
    # repository default explicitly, so normal repository checks still enforce
    # catalog/index parity.
    if lean_index_path is not None:
        if not lean_index_path.exists():
            warnings.append(
                _warning(
                    "missing-lean-index",
                    str(lean_index_path.relative_to(root)),
                    "Human-readable kernel index file is missing.",
                )
            )
        else:
            lean_paths = _lean_kernel_paths(lean_index_path)
            catalog_kernel_paths = {path for path in catalog_paths if path.endswith(".py")}
            for path in sorted(catalog_kernel_paths - lean_paths):
                warnings.append(
                    _warning("missing-lean-entry", path, "Cataloged kernel is missing from kernel-index.md.")
                )
            for path in sorted(lean_paths - catalog_kernel_paths):
                warnings.append(
                    _warning("orphan-lean-entry", path, "kernel-index.md path has no matching catalog entry.")
                )

    if not index_path.exists():
        warnings.append(_warning(
            "missing-index", str(index_path.relative_to(root)),
            "Generated kernel index file is missing. Run `python3 agent/scripts/build_agent_index.py`.",
        ))
    else:
        index_payload, json_error = _load_json(index_path)
        if json_error:
            warnings.append(_warning("invalid-index-json", str(index_path.relative_to(root)), json_error))
        else:
            expected_entries = payload["entries"]
            actual_entries = index_payload.get("entries")
            if actual_entries != expected_entries:
                warnings.append(
                    _warning(
                        "stale-index",
                        str(index_path.relative_to(root)),
                        "Generated kernel index does not match the current catalog. "
                        "Run `python3 agent/scripts/build_agent_index.py`.",
                    )
                )

    return {
        "warning_count": len(warnings),
        "warnings": warnings,
        "entry_count": len(entries),
        "catalog_paths": catalog_paths,
        "kernel_files": kernel_files,
    }


def print_text(result: Dict[str, Any]) -> None:
    if not result["warnings"]:
        print("No warnings found.")
        return

    for warning in result["warnings"]:
        suffix = f" | field={warning['field']}" if "field" in warning else ""
        location = f"{warning['path']}:{warning['line']}" if "line" in warning else warning["path"]
        print(f"- [{warning['code']}] {location}{suffix}")
        print(f"  {warning['message']}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Check kernel catalog consistency against repository files and generated index.",
    )
    parser.add_argument("--json", action="store_true", help="Print JSON output.")
    parser.add_argument("--fail-on-warning", action="store_true", help="Return exit code 1 if any warning is found.")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    result = analyze_repo(lean_index_path=DEFAULT_LEAN_INDEX)

    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print_text(result)

    if args.fail_on_warning and result["warning_count"] > 0:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
