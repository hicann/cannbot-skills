#!/usr/bin/env python3
# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Validate the routed agent documentation and its generated discovery views."""

import argparse
import json
import logging
import re
import shutil
import subprocess
import sys
import tarfile
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple
from urllib.parse import unquote

TOOLS_DIR = Path(__file__).resolve().parent
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

from build_agent_index import build_outputs
from check_kernel_catalog import analyze_repo as analyze_kernel_catalog


ROOT = TOOLS_DIR.parent.parent
MARKDOWN_LINK_RE = re.compile(r"(?<!!)\[[^\]]*\]\(([^)]+)\)")
INLINE_CODE_RE = re.compile(r"(?<!`)`([^`\n]+)`(?!`)")
HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$")
HTML_ANCHOR_RE = re.compile(r"<(?:a\s+name|[^>]+\sid)=[\"']([^\"']+)[\"']", re.IGNORECASE)
IP_RE = re.compile(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])")
MACHINE_PATH_RE = re.compile(
    r"(?<![A-Za-z0-9_.-])/(?:Users|data|home|root|workspace)/[^\s`'\")]+"
)
TMP_RE = re.compile(r"(?<![A-Za-z0-9_])(?:\./)?tmp(?:/([^\s`'\")]*))?")
REPO_PATH_PREFIXES = (
    "agent/", "doc/", "doc_cn/", "easyasc/", "agent/example/demo/", "agent/example/kernels/",
    "agent/example/projects/", "agent/example/testcases/", "agent/scripts/",
)
_PLAYBOOK_ROOT = "agent/playbooks/"
_REFERENCE_ROOT = "agent/references/"
LEGACY_PATHS = (
    _PLAYBOOK_ROOT + "clarify-" + "first.md",
    _PLAYBOOK_ROOT + "kernel-" + "authoring.md",
    _PLAYBOOK_ROOT + "onnx-to-" + "kernel.md",
    _REFERENCE_ROOT + "adapters/onnx-" + "contract.md",
    _PLAYBOOK_ROOT + "tool-doc-" + "authoring.md",
    _REFERENCE_ROOT + "cycle-" + "benchmarking.md",
    _REFERENCE_ROOT + "agent/example/demo/kernel-" + "practice.md",
)
REMOVED_ROLE = "libr" + "arian"
COMMON_LANGUAGE_PATH = Path("agent/common-language.md")
COMMON_LANGUAGE_MAX_LINES = 250
COMMON_LANGUAGE_MAX_BYTES = 15 * 1024
PRIVACY_FIXTURE_PATHS = {
    Path("agent/example/testcases/codegen/opexec/test_check_agent_docs.py"),
}
ARCHIVE_SUFFIXES = (".tar.gz", ".tgz")
MAKESELF_HOME_EXAMPLES = ("/home/" + "joe/", "/home/" + "tmpdir")


def _warning(code: str, path: Path, message: str, line: Optional[int] = None) -> Dict[str, Any]:
    item: Dict[str, Any] = {"code": code, "path": path.as_posix(), "message": message}
    if line is not None:
        item["line"] = line
    return item


GIT_BINARY = shutil.which("git") or "git"


def _tracked_files(root: Path) -> List[Path]:
    try:
        result = subprocess.run(
            [
                GIT_BINARY, "-C", str(root), "ls-files", "--cached", "--others",
                "--exclude-standard", "-z",
            ], check=True,
            capture_output=True,
        )
        paths = [root / item.decode("utf-8") for item in result.stdout.split(b"\0") if item]
        return sorted(path for path in paths if path.is_file())
    except (OSError, subprocess.CalledProcessError, UnicodeDecodeError):
        return sorted(
            path for path in root.rglob("*")
            if path.is_file() and ".git" not in path.parts and "tmp" not in path.parts
        )


def _line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def _fenced_ranges(text: str) -> List[Tuple[int, int]]:
    ranges: List[Tuple[int, int]] = []
    start: Optional[int] = None
    offset = 0
    for line in text.splitlines(keepends=True):
        if line.lstrip().startswith("```"):
            if start is None:
                start = offset
            else:
                ranges.append((start, offset + len(line)))
                start = None
        offset += len(line)
    if start is not None:
        ranges.append((start, len(text)))
    return ranges


def _inside_ranges(offset: int, ranges: Iterable[Tuple[int, int]]) -> bool:
    return any(start <= offset < end for start, end in ranges)


def _github_slug(text: str) -> str:
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("`", "").strip().lower()
    text = re.sub(r"[^\w\- ]", "", text, flags=re.UNICODE)
    return re.sub(r"-+", "-", text.replace(" ", "-")).strip("-")


def _anchors(path: Path, cache: Dict[Path, Set[str]]) -> Set[str]:
    if path in cache:
        return cache[path]
    anchors: Set[str] = set()
    counts: Counter = Counter()
    text = path.read_text(encoding="utf-8")
    in_fence = False
    for line in text.splitlines():
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        match = HEADING_RE.match(line)
        if match:
            base = _github_slug(match.group(1))
            if base:
                suffix = counts[base]
                counts[base] += 1
                anchors.add(base if suffix == 0 else "%s-%d" % (base, suffix))
        anchors.update(HTML_ANCHOR_RE.findall(line))
    cache[path] = anchors
    return anchors


def _split_link_target(raw: str) -> Tuple[str, str]:
    raw = raw.strip()
    if raw.startswith("<") and ">" in raw:
        raw = raw[1:raw.index(">")]
    elif " " in raw:
        raw = raw.split(None, 1)[0]
    raw = unquote(raw)
    path_part, marker, anchor = raw.partition("#")
    return path_part.split("?", 1)[0], anchor if marker else ""


def _check_markdown_links(root: Path, files: Iterable[Path]) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    anchor_cache: Dict[Path, Set[str]] = {}
    for path in files:
        text = path.read_text(encoding="utf-8")
        fences = _fenced_ranges(text)
        for match in MARKDOWN_LINK_RE.finditer(text):
            if _inside_ranges(match.start(), fences):
                continue
            target = match.group(1).strip()
            if re.match(r"^(?:https?://|mailto:|data:)", target):
                continue
            path_part, anchor = _split_link_target(target)
            resolved = path if not path_part else (path.parent / path_part).resolve()
            try:
                resolved.relative_to(root.resolve())
            except ValueError:
                warnings.append(_warning(
                    "link-outside-repo", path.relative_to(root),
                    "Local link resolves outside the repository: %s" % target,
                    _line_number(text, match.start()),
                ))
                continue
            if not resolved.exists():
                warnings.append(_warning(
                    "broken-link", path.relative_to(root),
                    "Linked path does not exist: %s" % target,
                    _line_number(text, match.start()),
                ))
                continue
            if anchor and resolved.is_file() and resolved.suffix.lower() == ".md":
                normalized = _github_slug(anchor)
                if normalized not in _anchors(resolved, anchor_cache):
                    warnings.append(_warning(
                        "broken-anchor", path.relative_to(root),
                        "Anchor #%s does not exist in %s" % (
                            anchor, resolved.relative_to(root),
                        ),
                        _line_number(text, match.start()),
                    ))
    return warnings


def _clean_repo_path(value: str) -> Optional[str]:
    value = value.strip().rstrip(".,;)")
    if not value.startswith(REPO_PATH_PREFIXES):
        return None
    if any(token in value for token in ("<", ">", "*", "{", "}", "...")):
        return None
    value = value.split("#", 1)[0]
    value = re.sub(r":\d+(?:-\d+)?$", "", value)
    return value


def _check_backticked_paths(root: Path, files: Iterable[Path]) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    for path in files:
        # This manual intentionally names paths in a different target
        # repository. Its current-repository links and hygiene are still
        # checked, but target-layout code spans are not local path claims.
        if path.relative_to(root).as_posix() == "ops-easyasc-dsl-migration-manual.md":
            continue
        text = path.read_text(encoding="utf-8")
        for match in INLINE_CODE_RE.finditer(text):
            candidate = _clean_repo_path(match.group(1))
            if not candidate or " " in candidate:
                continue
            resolved = root / candidate
            relative_resolved = path.parent / candidate
            if not resolved.exists() and relative_resolved.exists():
                resolved = relative_resolved
            if not resolved.exists() and ":" in candidate:
                resolved = root / candidate.split(":", 1)[0]
            if not resolved.exists():
                warnings.append(_warning(
                    "missing-repo-path", path.relative_to(root),
                    "Backticked repository path does not exist: %s" % candidate,
                    _line_number(text, match.start()),
                ))
    return warnings


def _check_document_hygiene(root: Path, files: Iterable[Path]) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    for path in files:
        text = path.read_text(encoding="utf-8")
        rel = path.relative_to(root)
        lower = text.lower()
        for legacy in LEGACY_PATHS:
            index = text.find(legacy)
            if index >= 0:
                warnings.append(_warning(
                    "legacy-doc-path", rel, "Removed documentation path remains: %s" % legacy,
                    _line_number(text, index),
                ))
        for match in TMP_RE.finditer(text):
            suffix = match.group(1) or ""
            if not suffix or suffix.startswith("<") or suffix.startswith("practice/"):
                continue
            warnings.append(_warning(
                "concrete-tmp-path", rel,
                "Use tmp/<task>/ (or tmp/practice/) instead of a concrete tracked tmp path: %s" % match.group(0),
                _line_number(text, match.start()),
            ))
        for match in MACHINE_PATH_RE.finditer(text):
            value = match.group(0)
            if "<" in value and ">" in value:
                continue
            warnings.append(_warning(
                "machine-path", rel, "Machine-specific absolute path is not allowed: %s" % value,
                _line_number(text, match.start()),
            ))
        for match in IP_RE.finditer(text):
            value = match.group(0)
            octets = [int(item) for item in value.split(".")]
            if any(item > 255 for item in octets) or value in ("0.0.0.0", "127.0.0.1"):
                continue
            warnings.append(_warning(
                "machine-ip", rel, "Tracked documentation must not contain a machine IP: %s" % value,
                _line_number(text, match.start()),
            ))
        if REMOVED_ROLE in lower:
            index = lower.index(REMOVED_ROLE)
            warnings.append(_warning(
                "removed-role-reference", rel,
                "Reference to the removed documentation role remains.",
                _line_number(text, index),
            ))
    return warnings


def _check_removed_role_in_text_files(root: Path, files: Iterable[Path]) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    for path in files:
        if path.suffix.lower() not in (".md", ".py", ".json", ".txt", ".toml", ".yaml", ".yml"):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        index = text.lower().find(REMOVED_ROLE)
        if index >= 0:
            warnings.append(_warning(
                "removed-role-reference", path.relative_to(root),
                "Reference to the removed documentation role remains.",
                _line_number(text, index),
            ))
    return warnings


def _check_non_markdown_privacy(root: Path, files: Iterable[Path]) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    for path in files:
        rel = path.relative_to(root)
        if rel in PRIVACY_FIXTURE_PATHS:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for match in MACHINE_PATH_RE.finditer(text):
            value = match.group(0)
            if "<" in value and ">" in value:
                continue
            warnings.append(_warning(
                "machine-path", rel,
                "Tracked text must not contain a machine-specific absolute path: %s" % value,
                _line_number(text, match.start()),
            ))
        for match in IP_RE.finditer(text):
            value = match.group(0)
            octets = [int(item) for item in value.split(".")]
            if any(item > 255 for item in octets) or value in ("0.0.0.0", "127.0.0.1"):
                continue
            warnings.append(_warning(
                "machine-ip", rel,
                "Tracked text must not contain a machine IP: %s" % value,
                _line_number(text, match.start()),
            ))
    return warnings


def _archive_path_is_allowed(member_name: str, value: str) -> bool:
    """Allow only the public Makeself examples shipped by the CANN template."""
    if "cmake/util/makeself/" not in member_name:
        return False
    return value.startswith(MAKESELF_HOME_EXAMPLES[0]) or value == MAKESELF_HOME_EXAMPLES[1]


def _member_is_generated_junk(parts, basename: str) -> bool:
    if "__pycache__" in parts or basename.startswith("._"):
        return True
    return basename in (".DS_Store", "__MACOSX") or basename.endswith((".pyc", ".pyo"))


def _member_has_nonroot_owner(member: tarfile.TarInfo) -> bool:
    if member.uid != 0 or member.gid != 0:
        return True
    return member.uname != "root" or member.gname != "root"


def _scan_archive_members(
    archive: tarfile.TarFile, rel: Path, warnings: List[Dict[str, Any]],
) -> None:
    for member in archive.getmembers():
        parts = Path(member.name).parts
        basename = Path(member.name).name
        if _member_is_generated_junk(parts, basename):
            warnings.append(_warning(
                "archive-generated-junk", rel,
                "Archive contains generated workstation metadata: %s" % member.name,
            ))
        if _member_has_nonroot_owner(member):
            warnings.append(_warning(
                "archive-owner-metadata", rel,
                "Archive member must use root:root ownership: %s" % member.name,
            ))
        if Path(member.name).name == "test_check_agent_docs.py":
            # The checker's own regression test carries deliberate
            # probe samples (RFC 5737 addresses, fake home paths) so
            # the detector itself stays tested; skip content scanning
            # for exactly that member, keeping its junk/owner checks.
            continue
        chunks = [member.name, repr(member.pax_headers)]
        if member.isfile():
            extracted = archive.extractfile(member)
            if extracted is not None:
                chunks.append(extracted.read().decode("utf-8", errors="ignore"))
        text = "\n".join(chunks)
        for match in MACHINE_PATH_RE.finditer(text):
            value = match.group(0)
            if _archive_path_is_allowed(member.name, value):
                continue
            warnings.append(_warning(
                "archive-machine-path", rel,
                "Archive member contains a machine-specific path (%s): %s"
                % (member.name, value),
            ))
        for match in IP_RE.finditer(text):
            value = match.group(0)
            octets = [int(item) for item in value.split(".")]
            if any(item > 255 for item in octets) or value in ("0.0.0.0", "127.0.0.1"):
                continue
            warnings.append(_warning(
                "archive-machine-ip", rel,
                "Archive member contains a machine IP (%s): %s" % (member.name, value),
            ))


def _check_archive_privacy(root: Path, files: Iterable[Path]) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    for path in files:
        rel = path.relative_to(root)
        if not rel.as_posix().endswith(ARCHIVE_SUFFIXES):
            continue
        try:
            with tarfile.open(path, "r:*") as archive:
                _scan_archive_members(archive, rel, warnings)
        except (OSError, tarfile.TarError) as error:
            warnings.append(_warning(
                "invalid-archive", rel, "Cannot inspect archive payload: %s" % error,
            ))
            continue
    return warnings


def _check_common_language_baseline(root: Path) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    common_path = root / COMMON_LANGUAGE_PATH
    if not common_path.exists():
        return [_warning(
            "missing-common-language", COMMON_LANGUAGE_PATH,
            "The fixed initial terminology baseline is missing.",
        )]

    raw = common_path.read_bytes()
    line_count = len(raw.decode("utf-8").splitlines())
    if line_count > COMMON_LANGUAGE_MAX_LINES:
        warnings.append(_warning(
            "common-language-line-budget", COMMON_LANGUAGE_PATH,
            "Common language has %d lines; the initial-load limit is %d."
            % (line_count, COMMON_LANGUAGE_MAX_LINES),
        ))
    if len(raw) > COMMON_LANGUAGE_MAX_BYTES:
        warnings.append(_warning(
            "common-language-byte-budget", COMMON_LANGUAGE_PATH,
            "Common language is %d bytes; the initial-load limit is %d."
            % (len(raw), COMMON_LANGUAGE_MAX_BYTES),
        ))

    agents_path = root / "AGENTS.md"
    agents_text = agents_path.read_text(encoding="utf-8") if agents_path.exists() else ""
    normalized = " ".join(agents_text.split()).lower()
    if "read `agent/common-language.md` in full" not in normalized:
        warnings.append(_warning(
            "common-language-not-baseline", Path("AGENTS.md"),
            "AGENTS.md must load agent/common-language.md in full after routing.",
        ))
    return warnings


def _check_router(root: Path) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    router = root / "agent" / "ROUTER.md"
    playbook_dir = root / "agent" / "playbooks"
    if not router.exists() or not playbook_dir.exists():
        return [_warning("missing-router", Path("agent/ROUTER.md"), "Router or playbook directory is missing.")]
    text = router.read_text(encoding="utf-8")
    routed = re.findall(r"\]\(playbooks/([^)]+\.md)(?:#[^)]+)?\)", text)
    counts = Counter(routed)
    actual = {path.name for path in playbook_dir.glob("*.md")}
    for name in sorted(actual | set(counts)):
        count = counts[name]
        if name not in actual:
            warnings.append(_warning(
                "router-missing-playbook", Path("agent/ROUTER.md"),
                "Router points to a missing playbook: %s" % name,
            ))
        elif count != 1:
            warnings.append(_warning(
                "router-cardinality", Path("agent/ROUTER.md"),
                "Playbook %s must appear exactly once as a Router workflow; found %d." % (name, count),
            ))
    return warnings


def _check_generated_views(root: Path) -> List[Dict[str, Any]]:
    warnings: List[Dict[str, Any]] = []
    if root.resolve() != ROOT.resolve():
        return warnings
    for path, expected in build_outputs().items():
        actual = path.read_text(encoding="utf-8") if path.exists() else None
        if actual != expected:
            warnings.append(_warning(
                "stale-agent-index", path.relative_to(root),
                "Generated output is stale; run `python agent/scripts/build_agent_index.py`.",
            ))
    catalog = analyze_kernel_catalog(
        lean_index_path=root / "agent" / "references" / "examples" / "kernel-index.md"
    )
    for item in catalog["warnings"]:
        warnings.append(_warning(
            "kernel-catalog-" + item["code"], Path(item["path"]), item["message"], item.get("line"),
        ))
    return warnings


def analyze_repo(root: Path = ROOT, run_generated_checks: bool = True) -> Dict[str, Any]:
    root = root.resolve()
    tracked = _tracked_files(root)
    markdown = [path for path in tracked if path.suffix.lower() == ".md"]
    warnings: List[Dict[str, Any]] = []
    warnings.extend(_check_markdown_links(root, markdown))
    warnings.extend(_check_backticked_paths(root, markdown))
    warnings.extend(_check_document_hygiene(root, markdown))
    # The hygiene check already covers Markdown; scan other tracked text files
    # for the removed role without duplicating Markdown warnings.
    warnings.extend(_check_removed_role_in_text_files(
        root, [path for path in tracked if path.suffix.lower() != ".md"]
    ))
    warnings.extend(_check_non_markdown_privacy(
        root, [path for path in tracked if path.suffix.lower() != ".md"]
    ))
    warnings.extend(_check_archive_privacy(root, tracked))
    warnings.extend(_check_common_language_baseline(root))
    warnings.extend(_check_router(root))
    if run_generated_checks:
        warnings.extend(_check_generated_views(root))
    return {"warning_count": len(warnings), "warnings": warnings}


try:
    from _logutil import configure_tool_logging
except ImportError:  # imported as agent.scripts.<tool> rather than as a script
    from ._logutil import configure_tool_logging

LOG = logging.getLogger("check_agent_docs")

def main() -> int:
    configure_tool_logging(LOG)
    parser = argparse.ArgumentParser(description="Check routed agent documentation and generated indexes.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable output.")
    args = parser.parse_args()
    result = analyze_repo()
    if args.json:
        LOG.info(json.dumps(result, indent=2, ensure_ascii=False))
    elif result["warnings"]:
        for item in result["warnings"]:
            location = item["path"] + ((":" + str(item["line"])) if "line" in item else "")
            LOG.info("- [%s] %s", item["code"], location)
            LOG.info("  %s", item["message"])
    else:
        LOG.info("Agent documentation checks passed.")
    return 1 if result["warnings"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
