#!/usr/bin/env python3
# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Check public documentation parity, navigation, and documented API surfaces.

The stub-to-codegen check deliberately verifies only that every facade-exported
stub helper appears as an exact identifier in the first column of a mapping
table.  It does not infer whether prose or a generated C++ symbol is
semantically correct; that stronger assertion requires runtime/codegen tests.
"""

import argparse
import ast
import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple
from urllib.parse import unquote


ROOT = Path(__file__).resolve().parent.parent.parent
INLINE_LINK_RE = re.compile(
    r"(?<!!)\[[^\]]*\]\(\s*(<[^>]+>|[^)\s]+)(?:\s+['\"][^)]*)?\)"
)
CONTRACT_ID_RE = re.compile(
    r"<!--\s*contract-id:\s*([A-Za-z0-9_.:/-]+)\s*-->", re.IGNORECASE
)
BACKTICK_RE = re.compile(r"`([^`]+)`")
IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

WarningDict = Dict[str, Any]


def _add_warning(
    warnings: List[WarningDict], code: str, path: str, message: str,
    line: Optional[int] = None,
) -> None:
    warning: WarningDict = {"code": code, "path": path, "message": message}
    if line is not None:
        warning["line"] = line
    warnings.append(warning)


def _repo_path(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path)


def _read_json(path: Path, root: Path, warnings: List[WarningDict]) -> Optional[Dict[str, Any]]:
    display_path = _repo_path(root, path)
    if not path.is_file():
        _add_warning(warnings, "manifest-missing", display_path, "Public documentation manifest does not exist.")
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        _add_warning(warnings, "manifest-json", display_path, "Cannot read manifest: %s" % exc)
        return None
    if not isinstance(payload, dict):
        _add_warning(warnings, "manifest-schema", display_path, "Manifest root must be a JSON object.")
        return None
    if payload.get("schema_version") != 1:
        _add_warning(warnings, "manifest-schema", display_path, "Only schema_version 1 is supported.")
        return None
    return payload


def _string_list(
    value: Any, field: str, manifest_path: str, warnings: List[WarningDict]
) -> List[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        _add_warning(warnings, "manifest-schema", manifest_path, "%s must be a list of strings." % field)
        return []
    return value


def _markdown_relpaths(root: Path, directory: str) -> Set[str]:
    base = root / directory
    if not base.is_dir():
        return set()
    return {
        path.relative_to(base).as_posix()
        for path in base.rglob("*.md")
        if path.is_file()
    }


def _check_path_parity(
    root: Path, docs: Dict[str, Any], manifest_path: str, warnings: List[WarningDict]
) -> Tuple[Set[str], Set[str], Set[str]]:
    parity = docs.get("path_parity")
    if not isinstance(parity, dict):
        _add_warning(warnings, "manifest-schema", manifest_path, "docs.path_parity must be an object.")
        parity = {}

    english = _markdown_relpaths(root, "doc")
    chinese = _markdown_relpaths(root, "doc_cn")
    english_only = set(_string_list(
        parity.get("english_only", []), "docs.path_parity.english_only", manifest_path, warnings
    ))
    chinese_only = set(_string_list(
        parity.get("chinese_only", []), "docs.path_parity.chinese_only", manifest_path, warnings
    ))

    for relpath in sorted(english_only):
        if relpath not in english:
            _add_warning(warnings, "stale-parity-allowlist", manifest_path,
                         "English-only allowlist entry does not exist in doc/: %s" % relpath)
        elif relpath in chinese:
            _add_warning(warnings, "stale-parity-allowlist", manifest_path,
                         "English-only allowlist entry now has a Chinese peer: %s" % relpath)
    for relpath in sorted(chinese_only):
        if relpath not in chinese:
            _add_warning(warnings, "stale-parity-allowlist", manifest_path,
                         "Chinese-only allowlist entry does not exist in doc_cn/: %s" % relpath)
        elif relpath in english:
            _add_warning(warnings, "stale-parity-allowlist", manifest_path,
                         "Chinese-only allowlist entry now has an English peer: %s" % relpath)

    for relpath in sorted((english - chinese) - english_only):
        _add_warning(warnings, "doc-path-parity", "doc/%s" % relpath,
                     "No matching doc_cn/%s page; add it or explicitly allowlist it." % relpath)
    for relpath in sorted((chinese - english) - chinese_only):
        _add_warning(warnings, "doc-path-parity", "doc_cn/%s" % relpath,
                     "No matching doc/%s page; add it or explicitly allowlist it." % relpath)

    paired = (english & chinese) - english_only - chinese_only
    return english, chinese, paired


def _without_fenced_code(text: str) -> str:
    output = []
    fence = None
    for line in text.splitlines():
        stripped = line.lstrip()
        marker = None
        if stripped.startswith("```"):
            marker = "```"
        elif stripped.startswith("~~~"):
            marker = "~~~"
        if marker:
            if fence is None:
                fence = marker
            elif fence == marker:
                fence = None
            output.append("")
        elif fence is None:
            output.append(line)
        else:
            output.append("")
    return "\n".join(output)


def _markdown_targets(root: Path, source: Path) -> Set[str]:
    try:
        text = source.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        return set()
    targets = set()
    for match in INLINE_LINK_RE.finditer(_without_fenced_code(text)):
        raw = match.group(1).strip()
        if raw.startswith("<") and raw.endswith(">"):
            raw = raw[1:-1]
        raw = unquote(raw).split("#", 1)[0].split("?", 1)[0]
        if not raw or raw.startswith(("http://", "https://", "mailto:", "data:")):
            continue
        if raw.startswith("/"):
            target = root / raw.lstrip("/")
        else:
            target = source.parent / raw
        try:
            targets.add(target.resolve().relative_to(root.resolve()).as_posix())
        except ValueError:
            continue
    return targets


def _reachable(graph: Dict[str, Set[str]], start: str) -> Set[str]:
    seen = set()
    pending = [start]
    while pending:
        node = pending.pop()
        if node in seen or node not in graph:
            continue
        seen.add(node)
        pending.extend(sorted(graph[node] - seen))
    return seen


def _navigation_allowlist(
    config: Dict[str, Any], field: str, doc_root: str, manifest_path: str,
    warnings: List[WarningDict], pages: Set[str],
) -> Set[str]:
    values = _string_list(config.get(field, []), "navigation.%s" % field, manifest_path, warnings)
    resolved = {"%s/%s" % (doc_root.rstrip("/"), value.lstrip("/")) for value in values}
    for path in sorted(resolved - pages):
        _add_warning(warnings, "stale-navigation-allowlist", manifest_path,
                     "%s entry does not resolve to a documentation page: %s" % (field, path))
    return resolved


def _check_navigation_orphans(
    graph: Dict[str, Set[str]], page_paths: Set[str], orphan_allowlist: Set[str],
    doc_root: str, warnings: List[WarningDict],
) -> None:
    inbound = {path: 0 for path in page_paths}
    for source, targets in graph.items():
        for target in targets:
            if target in inbound and target != source:
                inbound[target] += 1
    for path in sorted(page_paths - orphan_allowlist):
        if inbound[path] == 0:
            _add_warning(warnings, "navigation-orphan", path,
                         "Page has no inbound link from the README or another %s page." % doc_root)


def _check_navigation_language(
    root: Path, language: str, config: Dict[str, Any], manifest_path: str,
    warnings: List[WarningDict],
) -> Dict[str, int]:
    required = ["root", "index", "doc_root"]
    if any(not isinstance(config.get(field), str) for field in required):
        _add_warning(warnings, "manifest-schema", manifest_path,
                     "docs.navigation.%s requires string root, index, and doc_root fields." % language)
        return {"page_count": 0, "reachable_count": 0}

    root_page = config["root"]
    index_page = config["index"]
    doc_root = config["doc_root"].rstrip("/")
    page_paths = {
        "%s/%s" % (doc_root, relpath)
        for relpath in _markdown_relpaths(root, doc_root)
    }
    graph_nodes = set(page_paths)
    graph_nodes.add(root_page)
    graph: Dict[str, Set[str]] = {}
    for relpath in sorted(graph_nodes):
        source = root / relpath
        if not source.is_file():
            _add_warning(warnings, "navigation-missing-page", relpath,
                         "Configured navigation page does not exist.")
            graph[relpath] = set()
            continue
        graph[relpath] = _markdown_targets(root, source) & graph_nodes

    unreachable_allowlist = _navigation_allowlist(
        config, "unreachable_allowlist", doc_root, manifest_path, warnings, page_paths,
    )
    orphan_allowlist = _navigation_allowlist(
        config, "orphan_allowlist", doc_root, manifest_path, warnings, page_paths,
    )

    if root_page != index_page and index_page not in graph.get(root_page, set()):
        _add_warning(warnings, "navigation-index-not-linked", root_page,
                     "%s index must be linked directly: %s" % (language, index_page))

    root_reachable = _reachable(graph, root_page)
    index_reachable = _reachable(graph, index_page)
    for path in sorted(page_paths - root_reachable - unreachable_allowlist):
        _add_warning(warnings, "navigation-unreachable", path,
                     "Page is not reachable from %s." % root_page)
    for path in sorted(page_paths - index_reachable - unreachable_allowlist):
        _add_warning(warnings, "navigation-index-unreachable", path,
                     "Page is not reachable from %s." % index_page)

    _check_navigation_orphans(graph, page_paths, orphan_allowlist, doc_root, warnings)

    return {
        "page_count": len(page_paths),
        "reachable_count": len(page_paths & root_reachable),
        "index_reachable_count": len(page_paths & index_reachable),
    }


def _check_navigation(
    root: Path, docs: Dict[str, Any], manifest_path: str, warnings: List[WarningDict]
) -> Dict[str, Dict[str, int]]:
    navigation = docs.get("navigation")
    if not isinstance(navigation, dict):
        _add_warning(warnings, "manifest-schema", manifest_path, "docs.navigation must be an object.")
        return {}
    stats = {}
    for language in ("english", "chinese"):
        config = navigation.get(language)
        if not isinstance(config, dict):
            _add_warning(warnings, "manifest-schema", manifest_path,
                         "docs.navigation.%s must be an object." % language)
            continue
        stats[language] = _check_navigation_language(
            root, language, config, manifest_path, warnings
        )
    return stats


def _extract_contract_ids(path: Path) -> List[str]:
    try:
        return CONTRACT_ID_RE.findall(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError):
        return []


def _check_contracts(
    root: Path, docs: Dict[str, Any], paired: Set[str], manifest_path: str,
    warnings: List[WarningDict],
) -> int:
    contracts = docs.get("contracts")
    if not isinstance(contracts, dict):
        _add_warning(warnings, "manifest-schema", manifest_path, "docs.contracts must be an object.")
        return 0
    if contracts.get("id_strategy") != "relative_path":
        _add_warning(warnings, "manifest-schema", manifest_path,
                     "docs.contracts.id_strategy must be 'relative_path'.")

    overrides = contracts.get("overrides", {})
    if not isinstance(overrides, dict) or any(
        not isinstance(key, str) or not isinstance(value, str)
        for key, value in overrides.items()
    ):
        _add_warning(warnings, "manifest-schema", manifest_path,
                     "docs.contracts.overrides must map relative paths to string IDs.")
        overrides = {}
    for relpath in sorted(set(overrides) - paired):
        _add_warning(warnings, "contract-override-stale", manifest_path,
                     "Contract override does not name a paired page: %s" % relpath)

    contract_ids: Dict[str, str] = {}
    owners: Dict[str, str] = {}
    for relpath in sorted(paired):
        contract_id = overrides.get(relpath, "page:%s" % relpath[:-3])
        if not contract_id:
            _add_warning(warnings, "contract-id-empty", manifest_path,
                         "Contract ID is empty for %s." % relpath)
            continue
        if contract_id in owners:
            _add_warning(warnings, "contract-id-duplicate", manifest_path,
                         "Contract ID %s is shared by %s and %s." % (
                             contract_id, owners[contract_id], relpath
                         ))
        owners[contract_id] = relpath
        contract_ids[relpath] = contract_id

        english_ids = _extract_contract_ids(root / "doc" / relpath)
        chinese_ids = _extract_contract_ids(root / "doc_cn" / relpath)
        if len(english_ids) != len(set(english_ids)):
            _add_warning(warnings, "contract-marker-duplicate", "doc/%s" % relpath,
                         "A contract-id marker is repeated in this page.")
        if len(chinese_ids) != len(set(chinese_ids)):
            _add_warning(warnings, "contract-marker-duplicate", "doc_cn/%s" % relpath,
                         "A contract-id marker is repeated in this page.")
        if set(english_ids) != set(chinese_ids):
            _add_warning(warnings, "contract-marker-mismatch", "doc/%s" % relpath,
                         "Embedded contract IDs differ from doc_cn/%s: EN=%s CN=%s" % (
                             relpath, sorted(set(english_ids)), sorted(set(chinese_ids))
                         ))
    return len(contract_ids)


def _static_all(tree: ast.Module) -> Tuple[bool, Optional[Set[str]]]:
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if not any(isinstance(target, ast.Name) and target.id == "__all__" for target in targets):
            continue
        try:
            value = ast.literal_eval(node.value)
        except (ValueError, TypeError):
            return True, None
        if isinstance(value, (list, tuple)) and all(isinstance(item, str) for item in value):
            return True, set(value)
        return True, None
    return False, None


def _parse_module(path: Path, root: Path, warnings: List[WarningDict]) -> Optional[ast.Module]:
    display_path = _repo_path(root, path)
    if not path.is_file():
        _add_warning(warnings, "facade-source-missing", display_path, "Facade source does not exist.")
        return None
    try:
        return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except (OSError, UnicodeError, SyntaxError) as exc:
        _add_warning(warnings, "facade-source-invalid", display_path, "Cannot parse facade source: %s" % exc)
        return None


def _collect_import_from(node: ast.ImportFrom, names: Set[str], star_modules: Set[str]) -> None:
    for alias in node.names:
        if alias.name == "*":
            star_modules.add(node.module or "")
            continue
        name = alias.asname or alias.name
        if not name.startswith("_"):
            names.add(name)


def _module_exports(tree: ast.Module) -> Tuple[Set[str], Set[str], bool, bool]:
    has_all_assignment, explicit_all = _static_all(tree)
    star_modules = set()
    if explicit_all is not None:
        for node in tree.body:
            if isinstance(node, ast.ImportFrom) and any(alias.name == "*" for alias in node.names):
                star_modules.add(node.module or "")
        return explicit_all, star_modules, True, False

    names = set()
    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            _collect_import_from(node, names, star_modules)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.asname or alias.name.split(".", 1)[0]
                if not name.startswith("_"):
                    names.add(name)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if not node.name.startswith("_"):
                names.add(node.name)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for target in targets:
                if isinstance(target, ast.Name) and not target.id.startswith("_"):
                    names.add(target.id)
    return names, star_modules, False, has_all_assignment


def _facade_exclusions(
    config: Dict[str, Any], facade_name: str, manifest_path: str, warnings: List[WarningDict],
) -> Set[str]:
    return set(_string_list(
        config.get("exclude", []), "public_api.facades.%s.exclude" % facade_name,
        manifest_path, warnings,
    ))


def _check_public_api(
    root: Path, manifest: Dict[str, Any], manifest_path: str, warnings: List[WarningDict]
) -> Dict[str, int]:
    public_api = manifest.get("public_api")
    if not isinstance(public_api, dict):
        _add_warning(warnings, "manifest-schema", manifest_path, "public_api must be an object.")
        return {}
    groups = public_api.get("groups")
    facades = public_api.get("facades")
    if not isinstance(groups, dict) or not isinstance(facades, dict):
        _add_warning(warnings, "manifest-schema", manifest_path,
                     "public_api.groups and public_api.facades must be objects.")
        return {}

    required_facades = {"a2", "a3", "a5", "a5pr"}
    missing_facades = sorted(required_facades - set(facades))
    if missing_facades:
        _add_warning(warnings, "manifest-required-facade", manifest_path,
                     "public_api.facades must include: %s" % ", ".join(missing_facades))

    parsed_groups: Dict[str, Set[str]] = {}
    for group_name, value in groups.items():
        names = _string_list(value, "public_api.groups.%s" % group_name, manifest_path, warnings)
        if len(names) != len(set(names)):
            _add_warning(warnings, "manifest-surface-duplicate", manifest_path,
                         "Public API group contains duplicate names: %s" % group_name)
        parsed_groups[group_name] = set(names)

    cache: Dict[str, Set[str]] = {}
    visiting = set()

    def actual_surface(facade_name: str) -> Set[str]:
        if facade_name in cache:
            return cache[facade_name]
        if facade_name in visiting:
            _add_warning(warnings, "facade-inheritance", manifest_path,
                         "Facade inheritance cycle includes %s." % facade_name)
            return set()
        config = facades.get(facade_name)
        if not isinstance(config, dict) or not isinstance(config.get("source"), str):
            _add_warning(warnings, "manifest-schema", manifest_path,
                         "public_api.facades.%s requires a source path." % facade_name)
            return set()
        visiting.add(facade_name)
        tree = _parse_module(root / config["source"], root, warnings)
        if tree is None:
            visiting.remove(facade_name)
            return set()
        direct, star_modules, has_all, has_dynamic_all = _module_exports(tree)
        if has_dynamic_all:
            _add_warning(warnings, "facade-dynamic-all", config["source"],
                         "__all__ must be a static string list or tuple for manifest validation.")
        direct -= _facade_exclusions(config, facade_name, manifest_path, warnings)
        inherited = config.get("inherits")
        if inherited is not None and not isinstance(inherited, str):
            _add_warning(warnings, "manifest-schema", manifest_path,
                         "public_api.facades.%s.inherits must be a string." % facade_name)
            inherited = None
        if inherited:
            normalized_stars = {module.rsplit(".", 1)[-1] for module in star_modules}
            if inherited not in facades:
                _add_warning(warnings, "facade-inheritance", manifest_path,
                             "%s inherits unknown facade %s." % (facade_name, inherited))
            if inherited not in normalized_stars:
                _add_warning(warnings, "facade-inheritance", config["source"],
                             "%s must star-import its declared parent %s." % (facade_name, inherited))
            unexpected_stars = normalized_stars - {inherited}
            if unexpected_stars and not has_all:
                _add_warning(warnings, "facade-inheritance", config["source"],
                             "Unmodeled star imports affect the public surface: %s" % (
                                 ", ".join(sorted(unexpected_stars))
                             ))
            if not has_all:
                direct |= actual_surface(inherited)
        elif star_modules:
            _add_warning(warnings, "facade-inheritance", config["source"],
                         "Star imports require an explicit inherits declaration in the manifest.")
        visiting.remove(facade_name)
        cache[facade_name] = direct
        return direct

    stats = {}
    for facade_name, config in facades.items():
        if not isinstance(config, dict):
            continue
        group_names = _string_list(
            config.get("groups", []), "public_api.facades.%s.groups" % facade_name,
            manifest_path, warnings,
        )
        expected = set()
        seen_groups = set()
        for group_name in group_names:
            if group_name not in parsed_groups:
                _add_warning(warnings, "manifest-surface-group", manifest_path,
                             "%s references unknown API group %s." % (facade_name, group_name))
                continue
            overlap = seen_groups & parsed_groups[group_name]
            if overlap:
                _add_warning(warnings, "manifest-surface-duplicate", manifest_path,
                             "%s API groups overlap: %s" % (facade_name, ", ".join(sorted(overlap))))
            seen_groups |= parsed_groups[group_name]
            expected |= parsed_groups[group_name]
        actual = actual_surface(facade_name)
        missing = sorted(expected - actual)
        undocumented = sorted(actual - expected)
        if missing or undocumented:
            parts = []
            if missing:
                parts.append("manifest-only=%s" % ", ".join(missing))
            if undocumented:
                parts.append("source-only=%s" % ", ".join(undocumented))
            _add_warning(warnings, "public-surface-mismatch", config.get("source", manifest_path),
                         "%s public surface differs from the manifest: %s" % (
                             facade_name, "; ".join(parts)
                         ))
        stats[facade_name] = len(actual)
    return stats


def _stub_exports(tree: ast.Module) -> Set[str]:
    names = set()
    for node in tree.body:
        if not isinstance(node, ast.ImportFrom):
            continue
        module = node.module or ""
        if module != "stub_functions" and not module.startswith("stub_functions."):
            continue
        for alias in node.names:
            if alias.name != "*":
                names.add(alias.asname or alias.name)
    return names


def _first_column_identifiers(path: Path) -> Set[str]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError):
        return set()
    names = set()
    for line in lines:
        if not line.lstrip().startswith("|"):
            continue
        cells = re.split(r"(?<!\\)\|", line.strip())
        if len(cells) < 3:
            continue
        for value in BACKTICK_RE.findall(cells[1]):
            if IDENTIFIER_RE.match(value):
                names.add(value)
    return names


def _check_stub_maps(
    root: Path, manifest: Dict[str, Any], manifest_path: str, warnings: List[WarningDict]
) -> Dict[str, int]:
    config = manifest.get("stub_to_codegen")
    public_api = manifest.get("public_api", {})
    facade_configs = public_api.get("facades", {}) if isinstance(public_api, dict) else {}
    if not isinstance(config, dict):
        _add_warning(warnings, "manifest-schema", manifest_path, "stub_to_codegen must be an object.")
        return {}
    if config.get("mode") != "public_stub_name_presence":
        _add_warning(warnings, "manifest-schema", manifest_path,
                     "stub_to_codegen.mode must be 'public_stub_name_presence'.")
    documents = _string_list(
        config.get("documents", []), "stub_to_codegen.documents", manifest_path, warnings
    )
    facade_names = _string_list(
        config.get("facades", []), "stub_to_codegen.facades", manifest_path, warnings
    )
    required_documents = {
        "doc/12_stub_to_codegen_name_map.md",
        "doc_cn/12_stub_to_codegen_name_map.md",
    }
    missing_documents = sorted(required_documents - set(documents))
    if missing_documents:
        _add_warning(warnings, "stub-map-config", manifest_path,
                     "stub_to_codegen.documents must include: %s" % ", ".join(missing_documents))
    required_facades = {"a2", "a5"}
    missing_facades = sorted(required_facades - set(facade_names))
    if missing_facades:
        _add_warning(warnings, "stub-map-config", manifest_path,
                     "stub_to_codegen.facades must include: %s" % ", ".join(missing_facades))
    if len(documents) != len(set(documents)):
        _add_warning(warnings, "stub-map-config", manifest_path,
                     "stub_to_codegen.documents contains duplicate paths.")
    if len(facade_names) != len(set(facade_names)):
        _add_warning(warnings, "stub-map-config", manifest_path,
                     "stub_to_codegen.facades contains duplicate names.")
    exclusions = config.get("exclusions", {})
    if not isinstance(exclusions, dict):
        _add_warning(warnings, "manifest-schema", manifest_path,
                     "stub_to_codegen.exclusions must be an object.")
        exclusions = {}

    required: Dict[str, Set[str]] = {}
    for facade_name in facade_names:
        facade = facade_configs.get(facade_name) if isinstance(facade_configs, dict) else None
        if not isinstance(facade, dict) or not isinstance(facade.get("source"), str):
            _add_warning(warnings, "stub-map-config", manifest_path,
                         "Stub map references an unknown facade: %s" % facade_name)
            continue
        tree = _parse_module(root / facade["source"], root, warnings)
        if tree is None:
            continue
        excluded = set(_string_list(
            exclusions.get(facade_name, []), "stub_to_codegen.exclusions.%s" % facade_name,
            manifest_path, warnings,
        ))
        exports = _stub_exports(tree)
        stale_exclusions = excluded - exports
        if stale_exclusions:
            _add_warning(warnings, "stub-map-config", manifest_path,
                         "%s stub exclusions do not name facade imports: %s" % (
                             facade_name, ", ".join(sorted(stale_exclusions))
                         ))
        required[facade_name] = exports - excluded

    stats = {}
    documented_by_path: Dict[str, Set[str]] = {}
    for document in documents:
        path = root / document
        if not path.is_file():
            _add_warning(warnings, "stub-map-missing", document,
                         "Configured stub-to-codegen map does not exist.")
            continue
        documented = _first_column_identifiers(path)
        documented_by_path[document] = documented
        stats[document] = len(documented)
        for facade_name in sorted(required):
            missing = sorted(required[facade_name] - documented)
            if missing:
                _add_warning(warnings, "stub-map-coverage", document,
                             "%s facade stub helpers missing from table first columns: %s" % (
                                 facade_name, ", ".join(missing)
                             ))
    english_map = documented_by_path.get("doc/12_stub_to_codegen_name_map.md")
    chinese_map = documented_by_path.get("doc_cn/12_stub_to_codegen_name_map.md")
    if english_map is not None and chinese_map is not None and english_map != chinese_map:
        only_english = sorted(english_map - chinese_map)
        only_chinese = sorted(chinese_map - english_map)
        parts = []
        if only_english:
            parts.append("EN-only=%s" % ", ".join(only_english))
        if only_chinese:
            parts.append("CN-only=%s" % ", ".join(only_chinese))
        _add_warning(warnings, "stub-map-parity", manifest_path,
                     "Stub-map first-column identifiers differ: %s" % "; ".join(parts))
    return stats


def analyze_repo(root: Path = ROOT, manifest_path: Optional[Path] = None) -> Dict[str, Any]:
    """Return deterministic warnings and coverage statistics for ``root``."""
    root = root.resolve()
    manifest_file = (manifest_path or (root / "agent" / "scripts" / "data" / "public_docs_manifest.json")).resolve()
    warnings: List[WarningDict] = []
    manifest = _read_json(manifest_file, root, warnings)
    if manifest is None:
        return {"schema_version": 1, "warning_count": len(warnings), "warnings": warnings, "stats": {}}

    manifest_display = _repo_path(root, manifest_file)
    docs = manifest.get("docs")
    if not isinstance(docs, dict):
        _add_warning(warnings, "manifest-schema", manifest_display, "docs must be an object.")
        docs = {}
    english, chinese, paired = _check_path_parity(
        root, docs, manifest_display, warnings
    )
    navigation_stats = _check_navigation(root, docs, manifest_display, warnings)
    contract_count = _check_contracts(
        root, docs, paired, manifest_display, warnings
    )
    facade_stats = _check_public_api(root, manifest, manifest_display, warnings)
    stub_stats = _check_stub_maps(root, manifest, manifest_display, warnings)

    warnings.sort(key=lambda item: (
        item.get("path", ""), item.get("line", 0), item.get("code", ""), item.get("message", "")
    ))
    return {
        "schema_version": 1,
        "warning_count": len(warnings),
        "warnings": warnings,
        "stats": {
            "english_page_count": len(english),
            "chinese_page_count": len(chinese),
            "paired_contract_count": contract_count,
            "navigation": navigation_stats,
            "facade_exports": facade_stats,
            "stub_map_first_column_names": stub_stats,
            "stub_coverage_mode": "public_stub_name_presence",
        },
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Check public documentation drift gates.")
    parser.add_argument("--root", type=Path, default=ROOT, help="Repository root (default: current checkout).")
    parser.add_argument(
        "--manifest", type=Path,
        help="Manifest path (default: agent/scripts/data/public_docs_manifest.json under --root).",
    )
    parser.add_argument(
        "--fail-on-warning", action="store_true",
        help="Compatibility flag; public-document warnings are always fatal.",
    )
    parser.add_argument("--json", action="store_true", help="Print the complete report as JSON.")
    return parser


try:
    from _logutil import configure_tool_logging
except ImportError:  # imported as agent.scripts.<tool> rather than as a script
    from ._logutil import configure_tool_logging

LOG = logging.getLogger("check_public_docs")

def main(argv: Optional[Sequence[str]] = None) -> int:
    configure_tool_logging(LOG)
    args = build_parser().parse_args(argv)
    manifest_path = args.manifest
    if manifest_path is not None and not manifest_path.is_absolute():
        manifest_path = args.root / manifest_path
    result = analyze_repo(args.root, manifest_path)
    if args.json:
        LOG.info(json.dumps(result, indent=2, ensure_ascii=False))
    elif result["warnings"]:
        for warning in result["warnings"]:
            location = warning["path"]
            if "line" in warning:
                location += ":%s" % warning["line"]
            LOG.info("%s: [%s] %s", location, warning["code"], warning["message"])
        LOG.info("Public documentation checks found %d warning(s).", result["warning_count"])
    else:
        stats = result["stats"]
        LOG.info(
            "Public documentation checks passed: %d EN pages, %d CN pages, %d paired contracts.",
            stats["english_page_count"], stats["chinese_page_count"], stats["paired_contract_count"],
        )
    return 1 if result["warnings"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
