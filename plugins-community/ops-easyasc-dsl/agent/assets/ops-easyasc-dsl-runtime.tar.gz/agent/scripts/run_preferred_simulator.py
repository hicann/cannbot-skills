#!/usr/bin/env python3
# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Run a repository simulator script, preferring WSL on Windows hosts.

This wrapper is intended for simulator-first checks that are correct on both
Windows and Linux but run much faster under WSL's Linux process model.

Examples:
  python agent/scripts/run_preferred_simulator.py agent/example/projects/a5/kda_bwd/check_simulator_vs_ref.py
  python agent/scripts/run_preferred_simulator.py --backend wsl \
      agent/example/projects/a5/kda_bwd/kernels/finalize_reduce.py
  python agent/scripts/run_preferred_simulator.py \
      agent/example/projects/a5/kda_bwd/test_script/module_vs_ref.py --module leaf --upstream ref
"""

import argparse
import logging
import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Sequence, Tuple


def _find_repo_root(start: Path) -> Path:
    for path in (start,) + tuple(start.parents):
        if (path / "agent" / "ROUTER.md").exists() and (path / "easyasc" / "a5.py").exists():
            return path
    raise RuntimeError("could not locate repository root from %s" % start)


def _resolve_path(text: str, base: Path) -> Path:
    path = Path(text)
    if not path.is_absolute():
        path = base / path
    return path.resolve()


def _prepend_env_path(env: Dict[str, str], key: str, entries: Sequence[str], sep: str) -> None:
    joined = sep.join(entry for entry in entries if entry)
    if not joined:
        return
    current = env.get(key, "")
    env[key] = joined + (sep + current if current else "")


def _windows_path_to_wsl(path: Path) -> str:
    text = str(path.resolve())
    drive, tail = os.path.splitdrive(text)
    if drive:
        return "/mnt/%s%s" % (drive[0].lower(), tail.replace("\\", "/"))
    return text.replace("\\", "/")


def _conda_env_exists(output: str, env_name: str) -> bool:
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        cleaned = line.replace("*", " ")
        tokens = cleaned.split()
        if not tokens:
            continue
        if tokens[0] == env_name:
            return True
        maybe_path = tokens[-1]
        if Path(maybe_path).name == env_name:
            return True
    return False


def _run_capture(cmd: Sequence[str]) -> Tuple[int, str, str]:
    completed = subprocess.run(
        list(cmd),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    return completed.returncode, completed.stdout, completed.stderr


def _wsl_conda_env_exists(env_name: str) -> bool:
    if shutil.which("wsl.exe") is None:
        return False
    code, stdout, _stderr = _run_capture(
        ["wsl.exe", "bash", "-lic", "command -v conda >/dev/null 2>&1 && conda env list || true"]
    )
    return code == 0 and _conda_env_exists(stdout, env_name)


def _local_conda_env_exists(env_name: str) -> bool:
    if shutil.which("conda") is None:
        return False
    code, stdout, _stderr = _run_capture(["conda", "env", "list"])
    return code == 0 and _conda_env_exists(stdout, env_name)


def _quote_cmd(parts: Sequence[str]) -> str:
    return " ".join(shlex.quote(part) for part in parts)


def _build_wsl_command(
    env_name: str,
    cwd: Path,
    script_path: Path,
    script_args: Sequence[str],
    pythonpath_entries: Sequence[Path],
) -> List[str]:
    wsl_cwd = _windows_path_to_wsl(cwd)
    wsl_script = _windows_path_to_wsl(script_path)
    wsl_pythonpath = ":".join(_windows_path_to_wsl(path) for path in pythonpath_entries)
    shell_parts = [
        "cd %s" % shlex.quote(wsl_cwd),
        "export PYTHONPATH=%s${PYTHONPATH:+:$PYTHONPATH}" % shlex.quote(wsl_pythonpath),
        _quote_cmd(["conda", "run", "-n", env_name, "python", wsl_script] + list(script_args)),
    ]
    return ["wsl.exe", "bash", "-lic", " && ".join(shell_parts)]


def _build_local_command(
    env_name: str,
    script_path: Path,
    script_args: Sequence[str],
) -> List[str]:
    if _local_conda_env_exists(env_name):
        return ["conda", "run", "-n", env_name, "python", str(script_path)] + list(script_args)
    return [sys.executable, str(script_path)] + list(script_args)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run a repository simulator script, preferring WSL torch210npu on Windows hosts.",
    )
    parser.add_argument(
        "--backend",
        choices=("auto", "wsl", "local"),
        default="auto",
        help="Execution backend. 'auto' prefers WSL on Windows when the target env exists there.",
    )
    parser.add_argument(
        "--env",
        default="torch210npu",
        help="Conda environment name to use when launching the target script.",
    )
    parser.add_argument(
        "--cwd",
        default=".",
        help="Working directory for the target script. Defaults to the current directory.",
    )
    parser.add_argument(
        "--pythonpath",
        action="append",
        default=[],
        help="Additional path to prepend to PYTHONPATH. May be repeated.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the selected backend and command without executing it.",
    )
    parser.add_argument("script", help="Repository-relative or absolute Python script to execute.")
    parser.add_argument("script_args", nargs=argparse.REMAINDER, help="Arguments forwarded to the target script.")
    return parser.parse_args()


try:
    from _logutil import configure_tool_logging
except ImportError:  # imported as agent.scripts.<tool> rather than as a script
    from ._logutil import configure_tool_logging

LOG = logging.getLogger("run_preferred_simulator")

def main() -> int:
    configure_tool_logging(LOG)
    args = _parse_args()
    cwd = _resolve_path(args.cwd, Path.cwd())
    script_path = _resolve_path(args.script, Path.cwd())
    if not script_path.is_file():
        LOG.error("target script does not exist: %s", script_path)
        return 2

    repo_root = _find_repo_root(script_path.parent)
    pythonpath_entries = [repo_root]
    for entry in args.pythonpath:
        pythonpath_entries.append(_resolve_path(entry, Path.cwd()))

    on_windows = (os.name == "nt")
    if args.backend == "wsl":
        if not on_windows:
            LOG.error("--backend wsl is only available on Windows hosts.")
            return 2
        if not _wsl_conda_env_exists(args.env):
            LOG.error("WSL conda env %r was not found.", args.env)
            return 2
        backend = "wsl"
    elif args.backend == "local":
        backend = "local"
    elif on_windows and _wsl_conda_env_exists(args.env):
        backend = "wsl"
    else:
        backend = "local"

    if backend == "wsl":
        command = _build_wsl_command(args.env, cwd, script_path, args.script_args, pythonpath_entries)
        child_env = None
    else:
        command = _build_local_command(args.env, script_path, args.script_args)
        child_env = os.environ.copy()
        _prepend_env_path(child_env, "PYTHONPATH", [str(path) for path in pythonpath_entries], os.pathsep)

    LOG.info("[run_preferred_simulator] backend=%s env=%s cwd=%s", backend, args.env, cwd)
    LOG.info("[run_preferred_simulator] command=%s", _quote_cmd(command))
    if args.dry_run:
        return 0

    completed = subprocess.run(
        command,
        cwd=str(cwd),
        env=child_env,
        check=False,
    )
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())
