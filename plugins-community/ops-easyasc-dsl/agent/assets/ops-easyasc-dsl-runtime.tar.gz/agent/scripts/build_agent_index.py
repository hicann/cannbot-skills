#!/usr/bin/env python3
# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Build machine-readable agent indexes from the human-readable example catalogs."""

import argparse
import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent.parent
KERNEL_CATALOG = ROOT / "agent" / "references" / "examples" / "kernel-catalog.md"
TOOL_CATALOG = ROOT / "agent" / "references" / "examples" / "tool-catalog.md"
KERNEL_INDEX = ROOT / "agent" / "index" / "kernels.json"
TOOL_INDEX = ROOT / "agent" / "index" / "tools.json"
KERNEL_LEAN_INDEX = ROOT / "agent" / "references" / "examples" / "kernel-index.md"

HEADING_RE = re.compile(r"^###\s+`([^`]+)`\s*$")
FIELD_RE = re.compile(r"^-\s+([A-Za-z0-9_ /-]+):(?:\s*(.*))?$")
LIST_ITEM_RE = re.compile(r"^\s+-\s+(.*\S)\s*$")
INLINE_CODE_RE = re.compile(r"^`([^`]+)`$")
TARGET_CHOICES = ("a2", "a5", "a5pr")


def _normalize_field_name(name: str) -> str:
    return name.strip().lower().replace(" ", "_").replace("-", "_").replace("/", "_")


def _clean_scalar(value: str) -> str:
    value = value.strip()
    match = INLINE_CODE_RE.match(value)
    if match:
        return match.group(1)
    return value


def _finalize_entry(entry: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if entry is None:
        return None
    entry["name"] = Path(entry["path"]).name
    return entry


def parse_catalog(path: Path, kind: str, root: Path = ROOT) -> Dict[str, Any]:
    lines = path.read_text(encoding="utf-8").splitlines()
    entries: List[Dict[str, Any]] = []
    current_category: Optional[str] = None
    current_entry: Optional[Dict[str, Any]] = None
    current_field: Optional[str] = None

    for raw_line in lines:
        line = raw_line.rstrip()
        stripped = line.strip()

        if stripped.startswith("## ") and not stripped.startswith("### "):
            finalized = _finalize_entry(current_entry)
            if finalized is not None:
                entries.append(finalized)
            current_entry = None
            current_field = None
            current_category = stripped[3:].strip()
            continue

        heading_match = HEADING_RE.match(stripped)
        if heading_match:
            finalized = _finalize_entry(current_entry)
            if finalized is not None:
                entries.append(finalized)
            record_path = heading_match.group(1)
            current_entry = {
                "kind": kind,
                "path": record_path,
                "category": current_category,
            }
            current_field = None
            continue

        if current_entry is None:
            continue

        is_indented = bool(line[:1].isspace())
        field_match = None if is_indented else FIELD_RE.match(stripped)
        if field_match:
            field_name = _normalize_field_name(field_match.group(1))
            raw_value = field_match.group(2) or ""
            if raw_value:
                current_entry[field_name] = _clean_scalar(raw_value)
            else:
                current_entry[field_name] = []
            current_field = field_name
            continue

        list_item_match = LIST_ITEM_RE.match(line)
        if list_item_match and current_field:
            if is_indented:
                item_value = list_item_match.group(1).strip()
                existing_value = current_entry.get(current_field)
                if isinstance(existing_value, list):
                    existing_value.append(item_value)
                elif existing_value:
                    current_entry[current_field] = [existing_value, item_value]
                else:
                    current_entry[current_field] = [item_value]
                continue
            current_field = None

        if stripped and current_field and is_indented:
            existing_value = current_entry.get(current_field)
            if isinstance(existing_value, list):
                if existing_value:
                    existing_value[-1] = existing_value[-1] + " " + stripped
                else:
                    existing_value.append(stripped)
            elif existing_value:
                current_entry[current_field] = str(existing_value) + " " + stripped
            else:
                current_entry[current_field] = stripped
            continue

        if stripped:
            current_field = None

    finalized = _finalize_entry(current_entry)
    if finalized is not None:
        entries.append(finalized)

    for index, entry in enumerate(entries):
        entry["order"] = index

    try:
        source_path = path.relative_to(root).as_posix()
    except ValueError:
        source_path = path.as_posix()

    return {
        "schema_version": 1,
        "generated_by": "agent/scripts/build_agent_index.py",
        "source": source_path,
        "entry_count": len(entries),
        "entries": entries,
    }


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, indent=2, ensure_ascii=False) + "\n"
    path.write_text(text, encoding="utf-8")


def _flatten_text(value: Any) -> str:
    if isinstance(value, list):
        return " ".join(_flatten_text(item) for item in value)
    return "" if value is None else str(value)


def _targets_for_entry(entry: Dict[str, Any]) -> List[str]:
    raw_targets = entry.get("targets")
    path = str(entry.get("path", "<unknown>"))
    if raw_targets is not None:
        if not isinstance(raw_targets, list) or not raw_targets:
            raise ValueError(
                "%s: targets must be a non-empty list containing a2, a5, or a5pr" % path
            )
        targets = [str(target).strip().lower() for target in raw_targets]
        if any(target not in TARGET_CHOICES for target in targets):
            raise ValueError("%s: targets contains an unsupported value" % path)
        if len(targets) != len(set(targets)):
            raise ValueError("%s: targets contains duplicate values" % path)
        return targets

    normalized = "/" + path.strip("/") + "/"
    if "/a2/" in normalized:
        return ["a2"]
    if "/a5pr/" in normalized:
        return ["a5pr"]
    if "/a5/" in normalized:
        return ["a5", "a5pr"]
    return ["a2", "a5", "a5pr"]


def _markdown_cell(value: Any) -> str:
    text = " ".join(_flatten_text(value).split())
    return text.replace("|", "\\|")


def render_kernel_lean_index(payload: Dict[str, Any]) -> str:
    lines = [
        "# Kernel Index",
        "",
        "This file is generated by `agent/scripts/build_agent_index.py` from",
        "`agent/references/examples/kernel-catalog.md`; do not edit it by hand.",
        "Use it for a quick manual scan, or query the generated JSON with:",
        "",
        "```bash",
        "python agent/scripts/select_kernel_example.py --device <a2|a5|a5pr> --query \"<task>\" --limit 3",
        "```",
        "",
        "Generated entries: %d." % payload["entry_count"],
        "",
        "| Targets | Topology | Path | Formula |",
        "| --- | --- | --- | --- |",
    ]
    for entry in payload["entries"]:
        lines.append(
            "| %s | %s | `%s` | %s |" % (
                "/".join(_targets_for_entry(entry)),
                _markdown_cell(entry.get("topology", "")),
                entry["path"],
                _markdown_cell(entry.get("formula", "")),
            )
        )
    return "\n".join(lines) + "\n"


def _json_text(payload: Dict[str, Any]) -> str:
    return json.dumps(payload, indent=2, ensure_ascii=False) + "\n"


def build_outputs() -> Dict[Path, str]:
    kernel_payload = parse_catalog(KERNEL_CATALOG, kind="kernel")
    tool_payload = parse_catalog(TOOL_CATALOG, kind="tool")
    return {
        KERNEL_INDEX: _json_text(kernel_payload),
        TOOL_INDEX: _json_text(tool_payload),
        KERNEL_LEAN_INDEX: render_kernel_lean_index(kernel_payload),
    }


def build_indexes() -> None:
    for path, content in build_outputs().items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")


def check_indexes() -> List[Path]:
    stale = []
    for path, expected in build_outputs().items():
        actual = path.read_text(encoding="utf-8") if path.exists() else None
        if actual != expected:
            stale.append(path)
    return stale


try:
    from _logutil import configure_tool_logging
except ImportError:  # imported as agent.scripts.<tool> rather than as a script
    from ._logutil import configure_tool_logging

LOG = logging.getLogger("build_agent_index")

def main() -> None:
    configure_tool_logging(LOG)
    parser = argparse.ArgumentParser(description="Build machine-readable agent indexes from markdown catalogs.")
    parser.add_argument("--check", action="store_true", help="Compare generated outputs without writing files.")
    args = parser.parse_args()
    if args.check:
        stale = check_indexes()
        if stale:
            for path in stale:
                LOG.info("stale: %s", path.relative_to(ROOT))
            raise SystemExit(1)
        LOG.info("Agent indexes are current.")
        return
    build_indexes()


if __name__ == "__main__":
    main()
