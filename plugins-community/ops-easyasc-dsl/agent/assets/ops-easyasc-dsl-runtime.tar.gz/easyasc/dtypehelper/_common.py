import torch


def _require_integer_tensor(values: torch.Tensor, name: str) -> None:
    if values.dtype == torch.bool or values.is_floating_point():
        raise TypeError(f"{name} must use an integer dtype, got: {values.dtype}")


def _as_uint8_codes(codes: torch.Tensor) -> torch.Tensor:
    _require_integer_tensor(codes, "codes")
    if codes.dtype != torch.uint8 and int(codes.numel()) > 0:
        min_code = int(codes.min().item())
        max_code = int(codes.max().item())
        if min_code < 0 or max_code > 0xFF:
            raise ValueError(f"codes must be in [0, 255], got min={min_code}, max={max_code}")
    return codes.to(torch.uint8)
