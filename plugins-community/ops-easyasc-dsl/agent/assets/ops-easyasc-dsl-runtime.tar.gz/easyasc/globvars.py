from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .kernelbase.kernelbase import KernelBase
    from .micro.micromodule import MicroModule
    from .utils.datatype import DataTypeValue

active_kernel: Optional["KernelBase"] = None
active_micro: Optional["MicroModule"] = None
tmp_idx: int = 0
atomic_enabled: bool = False
atomic_type: Optional["DataTypeValue"] = None
device_type: str = "b3"
core_num: int = 20

l1_cap = 512
l0a_cap = 64 
l0b_cap = 64 
l0amx_cap = 4
l0bmx_cap = 4
l0c_cap = 128
bt_cap = 0.5  # KB, total depth-2 BT capacity (2 x 256 B slots on A2)
ub_cap = 192
trace_event: bool = False
trace_pipe_s: bool = False
