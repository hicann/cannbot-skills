import inspect
import re
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from .. import globvars
from ..utils.datatype import DataTypeValue, Datatype
from ..utils.instruction import Instruction
from ..utils.mask import MaskType
from ..utils.reg import MaskReg, Reg
from ..utils.sync_key import (
    SyncKeyGroup, collect_tensor_sync_keys, normalize_sync_key_group,
    tensor_sync_key,
)
from ..utils.Tensor import Tensor
from ..utils.var import Expr, Var, VarRef
from ..utils.positions import Position
from ..utils.castconfig import CastConfig, RegLayout
from ..utils.roundmode import RoundMode


_TMP_VAR_RE = re.compile(r"_tmp_var_[A-Za-z0-9_]*")


def _is_zero_literal(value: Any) -> bool:
    if isinstance(value, bool):
        return int(value) == 0
    if isinstance(value, int):
        return value == 0
    return False


def _is_literal_var_name(name: str) -> bool:
    try:
        float(name)
    except ValueError:
        return False
    return True


def _collect_var_names(value: Any, out: Set[str]) -> None:
    if isinstance(value, VarRef):
        index = getattr(value, "index", None)
        if index is not None:
            _collect_var_names(index, out)
        return
    if isinstance(value, Var):
        out.add(value.name)
        return
    if isinstance(value, Expr):
        out.update(_TMP_VAR_RE.findall(value.expr))
        return
    if isinstance(value, dict):
        for item in value.values():
            _collect_var_names(item, out)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _collect_var_names(item, out)
        return


def _collect_row_major_offset_var_names(shape: Any, offset: Any, out: Set[str]) -> None:
    if not isinstance(shape, (list, tuple)) or not isinstance(offset, (list, tuple)):
        return
    if len(shape) != len(offset) or len(shape) == 0:
        return
    for idx in range(len(shape) - 1):
        off = offset[idx]
        if _is_zero_literal(off):
            continue
        _collect_var_names(off, out)
        for stride_dim in shape[idx + 1:]:
            _collect_var_names(stride_dim, out)
    tail = offset[-1]
    if not _is_zero_literal(tail):
        _collect_var_names(tail, out)


def _instruction_output_var_name(inst: Instruction) -> Optional[str]:
    out = inst.kwargs.get("out", None)
    return out.name if isinstance(out, Var) else None


def _iter_instruction_input_values(inst: Instruction) -> List[Any]:
    skip_keys = set()
    if inst.opname == "create_var":
        skip_keys.add("val")
    if inst.opname == "micro_slice_tensor":
        skip_keys.add("out")
    if inst.opname == "start_micro_loop":
        skip_keys.add("var")
    if _instruction_output_var_name(inst) is not None:
        skip_keys.add("out")
    return [
        value
        for key, value in inst.kwargs.items()
        if key not in skip_keys
    ]


def _build_var_producers(instructions: List[Instruction]) -> Dict[str, Instruction]:
    producers: Dict[str, Instruction] = {}
    for inst in instructions:
        out_name = _instruction_output_var_name(inst)
        if out_name is not None:
            producers[out_name] = inst
    return producers


def _collect_var_dependency_names(
    value: Any,
    producers: Dict[str, Instruction],
    out: Set[str],
    visiting: Optional[Set[str]] = None,
) -> None:
    if visiting is None:
        visiting = set()
    if isinstance(value, VarRef):
        index = getattr(value, "index", None)
        if index is not None:
            _collect_var_dependency_names(index, producers, out, visiting)
        return
    if isinstance(value, Var):
        name = value.name
        producer = producers.get(name, None)
        if producer is None or name in visiting:
            out.add(name)
            return
        visiting.add(name)
        for item in _iter_instruction_input_values(producer):
            _collect_var_dependency_names(item, producers, out, visiting)
        visiting.remove(name)
        return
    if isinstance(value, Expr):
        for name in _TMP_VAR_RE.findall(value.expr):
            producer = producers.get(name, None)
            if producer is None or name in visiting:
                out.add(name)
                continue
            visiting.add(name)
            for item in _iter_instruction_input_values(producer):
                _collect_var_dependency_names(item, producers, out, visiting)
            visiting.remove(name)
        return
    if isinstance(value, dict):
        for item in value.values():
            _collect_var_dependency_names(item, producers, out, visiting)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _collect_var_dependency_names(item, producers, out, visiting)
        return


def _collect_row_major_offset_dependency_names(
    shape: Any,
    offset: Any,
    producers: Dict[str, Instruction],
    out: Set[str],
) -> None:
    if not isinstance(shape, (list, tuple)) or not isinstance(offset, (list, tuple)):
        return
    if len(shape) != len(offset) or len(shape) == 0:
        return
    for idx in range(len(shape) - 1):
        off = offset[idx]
        if _is_zero_literal(off):
            continue
        _collect_var_dependency_names(off, producers, out)
        for stride_dim in shape[idx + 1:]:
            _collect_var_dependency_names(stride_dim, producers, out)
    tail = offset[-1]
    if not _is_zero_literal(tail):
        _collect_var_dependency_names(tail, producers, out)


def _format_metadata_value(value: Any) -> str:
    if isinstance(value, Var):
        return value.name
    if isinstance(value, Expr):
        return value.expr
    if isinstance(value, list):
        return "[" + ", ".join(_format_metadata_value(item) for item in value) + "]"
    if isinstance(value, tuple):
        return "(" + ", ".join(_format_metadata_value(item) for item in value) + ")"
    return repr(value)


def _collect_declared_var_names(instructions: List[Instruction]) -> Set[str]:
    names: Set[str] = set()
    for inst in instructions:
        if inst.opname != "create_var":
            continue
        value = inst.kwargs.get("val", None)
        if isinstance(value, Var):
            names.add(value.name)
    return names


class TempRegStatus:
    def __init__(self, idx: int, dtype: DataTypeValue):
        self.reg = object.__new__(Reg)
        self.reg.name = f'_tmp_reg_{idx}'
        self.reg.dtype = dtype
        self.reg.reg_num = 1
        self.valid = True 
    
    def lock(self):
        self.valid = False 
    
    def release(self):
        self.valid = True 


class MicroModule:
    def __init__(self, name: str, func: Callable[..., Any]) -> None:
        self.func = func
        self.name = name
        self.instructions: List[Any] = []
        self.input_list: List[Any] = []
        self.tmp_idx = 0
        self.tmp_masks: Dict[str, MaskReg] = {}
        self.default_cast_cfg = None 
        self.default_cast_cfg_hif8 = None 
        self.default_cast_cfg_fp4_encode = None
        self.default_cast_cfg_fp4_decode = None
        self.cast_cfg_list: List[Any] = []
        self.div_cfg_list: List[Any] = []
        self.tmp_regs: Dict[str, List[TempRegStatus]] = {}
        self._declared_reg_names: Dict[str, str] = {}
        self._read_sync_keys: SyncKeyGroup = tuple()
        self._write_sync_keys: SyncKeyGroup = tuple()
        # A vf body is traced once, so its sync keys name the buffers of the
        # FIRST call.  Recording which of them came from a tensor parameter lets
        # every later call re-key them against its own arguments; the rest are
        # the vf's own locals and stay as traced.
        self._read_param_names: Tuple[str, ...] = tuple()
        self._write_param_names: Tuple[str, ...] = tuple()
        self._read_static_keys: SyncKeyGroup = tuple()
        self._write_static_keys: SyncKeyGroup = tuple()
        self._var_name_counts: Dict[str, int] = {}
        self._locked_signature: List[Tuple[str, str, str]] = []

    def get_default_cast_cfg(self, dtype: DataTypeValue):
        if dtype == Datatype.hif8:
            if self.default_cast_cfg_hif8 is not None:
                return self.default_cast_cfg_hif8
            self.default_cast_cfg_hif8 = CastConfig(name='default_castcfg_round', round_mode=RoundMode.AWAY_FROM_ZERO)
            return self.default_cast_cfg_hif8
        else:
            if self.default_cast_cfg is not None:
                return self.default_cast_cfg
            self.default_cast_cfg = CastConfig(name='default_castcfg')
            return self.default_cast_cfg

    def get_default_fp4_cast_cfg(self, encode: bool):
        attr = "default_cast_cfg_fp4_encode" if encode else "default_cast_cfg_fp4_decode"
        config = getattr(self, attr)
        if config is None:
            config = CastConfig(
                name="default_castcfg_fp4_encode" if encode else "default_castcfg_fp4_decode",
                round_mode=RoundMode.TO_EVEN if encode else RoundMode.NONE,
                reg_layout=RegLayout.ZERO,
            )
            setattr(self, attr, config)
        return config

    def get_reg(self, dtype: DataTypeValue):
        if dtype.name not in self.tmp_regs:
            self.tmp_regs[dtype.name] = []
        for i in self.tmp_regs[dtype.name]:
            if i.valid:
                i.lock()
                return i.reg 
        new_stat = TempRegStatus(self.tmp_idx, dtype)
        self.tmp_idx += 1 
        self.tmp_regs[dtype.name].append(new_stat)
        self._register_reg_name(new_stat.reg.name, "Reg")
        # Hoist temp register declaration to micro scope to keep it valid when
        # first use appears inside loop/if blocks.
        self.instructions.insert(0, Instruction("create_reg", reg=new_stat.reg))
        new_stat.lock()
        return new_stat.reg

    def release_reg(self, reg: Reg):
        for i in self.tmp_regs[reg.dtype.name]:
            if i.reg.name == reg.name:
                i.release()

    @staticmethod
    def _normalize_arg(arg: Any) -> Any:
        if type(arg) is int:
            scalar = object.__new__(Var)
            scalar.dtype = Datatype.int
            scalar.name = str(arg)
            scalar.value = arg
            scalar.idx = -1
            return scalar
        if type(arg) is float:
            scalar = object.__new__(Var)
            scalar.dtype = Datatype.float
            scalar.name = repr(arg)
            scalar.value = arg
            scalar.idx = -1
            return scalar
        return arg

    @staticmethod
    def _arg_signature(arg: Any) -> Tuple[str, str, str]:
        if isinstance(arg, Tensor):
            return ("Tensor", str(arg.dtype), str(arg.position))
        if isinstance(arg, Var):
            return ("Var", str(arg.dtype), "")
        raise TypeError(f"MicroModule only accepts Tensor or Var inputs, got: {type(arg)}")

    @staticmethod
    def _format_signature(signature: List[Tuple[str, str, str]]) -> str:
        parts = []
        for kind, dtype, position in signature:
            if kind == "Tensor":
                parts.append(f"Tensor[{dtype}, {position}]")
            else:
                parts.append(f"Var[{dtype}]")
        return "(" + ", ".join(parts) + ")"

    def _check_signature(self, signature: List[Tuple[str, str, str]]) -> None:
        if not self._locked_signature:
            return
        if signature == self._locked_signature:
            return
        expected = self._format_signature(self._locked_signature)
        current = self._format_signature(signature)
        raise TypeError(
            f"vf {self.name} was first called with signature {expected} but is now called "
            f"with {current}. Define a separate @vf for each signature."
        )

    def _validate_hidden_tensor_metadata_vars(self) -> None:
        allowed_names = _collect_declared_var_names(self.instructions)
        for arg in self.input_list:
            if isinstance(arg, Var):
                allowed_names.add(arg.name)

        producers = _build_var_producers(self.instructions)
        missing_sources: Dict[str, Set[str]] = {}
        first_slice_detail = ""
        for inst in self.instructions:
            if inst.opname != "micro_slice_tensor":
                continue
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Tensor):
                continue
            offset_refs: Set[str] = set()
            _collect_row_major_offset_var_names(
                getattr(out, "shape", None),
                inst.kwargs.get("offset", None),
                offset_refs,
            )
            _collect_row_major_offset_dependency_names(
                getattr(out, "shape", None),
                inst.kwargs.get("offset", None),
                producers,
                offset_refs,
            )
            span_refs: Set[str] = set()
            _collect_var_dependency_names(inst.kwargs.get("span", None), producers, span_refs)

            refs_by_source = {
                "offset": offset_refs,
                "span": span_refs,
            }
            current_missing: Set[str] = set()
            for source, refs in refs_by_source.items():
                for name in refs:
                    if name not in allowed_names and not _is_literal_var_name(name):
                        missing_sources.setdefault(name, set()).add(source)
                        current_missing.add(name)
            if current_missing and not first_slice_detail:
                src = inst.kwargs.get("src", None)
                src_name = getattr(src, "name", "<unknown>")
                first_slice_detail = (
                    f" First offending slice: source={src_name}, view={out.name}, "
                    f"shape={_format_metadata_value(getattr(out, 'shape', None))}, "
                    f"offset={_format_metadata_value(inst.kwargs.get('offset', None))}, "
                    f"span={_format_metadata_value(inst.kwargs.get('span', None))}."
                )

        if missing_sources:
            parts = []
            for name in sorted(missing_sources):
                sources = "/".join(sorted(missing_sources[name]))
                parts.append(f"{name} (from slice {sources})")
            missing = ", ".join(parts)
            raise ValueError(
                f"vf {self.name} uses hidden Tensor-metadata Var(s): {missing}. "
                "Tensor slices inside @vf may need Tensor shape/span/offset Vars during lowering. "
                "Pass those Vars as explicit @vf Var arguments, or use fixed Python int constants."
                f"{first_slice_detail}"
            )

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        if kwargs:
            raise TypeError("MicroModule does not support keyword arguments")
        normalized_args: Tuple[Any, ...] = tuple(self._normalize_arg(arg) for arg in args)
        for arg in normalized_args:
            if not isinstance(arg, (Tensor, Var)):
                raise TypeError(
                    f"MicroModule only accepts Tensor, Var, int, or float inputs, got: {type(arg)}"
                )
            if isinstance(arg, Tensor) and arg.position is not Position.UB:
                raise ValueError(f"MicroModule only accepts Tensor inputs in UB, current position: {arg.position}")
        sig = inspect.signature(self.func)
        try:
            bound = sig.bind(*normalized_args)
        except TypeError as exc:
            raise TypeError(f"MicroModule call argument mismatch: {exc}") from exc
        micro_args: List[Any] = []
        for name, arg in bound.arguments.items():
            if isinstance(arg, Tensor):
                cloned = object.__new__(Tensor)
                cloned.__dict__ = {
                    k: (v.copy() if isinstance(v, list) else v)
                    for k, v in arg.__dict__.items()
                }
                cloned.name = name
                # The call site passes Tensor views as their physical base pointer
                # via GetPhyAddr(); inside the VF they are a fresh pointer base.
                cloned.offset = [0 for _ in getattr(cloned, "offset", [])]
                micro_args.append(cloned)
            elif isinstance(arg, Var):
                cloned = object.__new__(Var)
                cloned.__dict__ = arg.__dict__.copy()
                cloned.name = name
                micro_args.append(cloned)
            else:
                raise TypeError(f"MicroModule only accepts Tensor or Var inputs, got: {type(arg)}")
        call_signature = [self._arg_signature(arg) for arg in micro_args]
        self._check_signature(call_signature)
        if not self.input_list:
            self.input_list = micro_args
            self._locked_signature = call_signature
            self._var_name_counts = {}
            prev_micro = globvars.active_micro
            globvars.active_micro = self
            try:
                self.func(*micro_args)
                self._validate_hidden_tensor_metadata_vars()
                for _, v in self.tmp_masks.items():
                    self.instructions.insert(0, Instruction("create_maskreg", reg=v))
                self._refresh_sync_keys()
                self._warn_missing_vf_barriers()
            finally:
                globvars.active_micro = prev_micro
        if globvars.active_kernel is not None:
            globvars.active_kernel.used_micros.add(self)
            globvars.active_kernel.instructions.append(
                Instruction(
                    "call_micro",
                    name=self.name,
                    args=list(normalized_args),
                    read_sync_keys=list(
                        self._call_sync_keys(
                            bound, self._read_param_names,
                            self._read_static_keys)),
                    write_sync_keys=list(
                        self._call_sync_keys(
                            bound, self._write_param_names,
                            self._write_static_keys)),
                )
            )

    def _call_sync_keys(self, bound, param_names, static_keys):
        keys = set(static_keys)
        for name in param_names:
            key = tensor_sync_key(bound.arguments.get(name))
            if key is not None:
                keys.add(key)
        return normalize_sync_key_group(keys) or tuple()

    def get_mask(self, dtype: DataTypeValue, reg_num: int = 1) -> MaskReg:
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        if not isinstance(reg_num, int) or isinstance(reg_num, bool):
            raise TypeError(f"reg_num must be int, got: {type(reg_num)}")
        if reg_num not in (1, 2):
            raise ValueError(f"reg_num must be 1 or 2, got: {reg_num}")
        key = f"{dtype.name}:reg{reg_num}"
        if key not in self.tmp_masks:
            mask = object.__new__(MaskReg)
            mask.dtype = dtype
            mask.init_mode = MaskType.ALL
            mask.reg_num = reg_num
            idx = self.tmp_idx
            self.tmp_idx += 1
            mask.name = f"_tmp_maskreg_{idx}"
            self.tmp_masks[key] = mask
        return self.tmp_masks[key]

    def _register_reg_name(self, name: str, kind: str) -> None:
        if not isinstance(name, str):
            raise TypeError(f"register name must be str, got: {type(name)}")
        if not isinstance(kind, str):
            raise TypeError(f"register kind must be str, got: {type(kind)}")
        prev_kind = self._declared_reg_names.get(name)
        if prev_kind is not None:
            raise ValueError(
                f"Duplicate {kind} name in vf {self.name}: {name}. "
                f"Existing declaration kind: {prev_kind}"
            )
        self._declared_reg_names[name] = kind

    def _refresh_sync_keys(self) -> None:
        read_keys = set()
        write_keys = set()
        skip_ops = {
            "create_tensor",
            "create_var",
            "create_reg",
            "create_maskreg",
            "slice_tensor",
            "micro_slice_tensor",
        }
        for inst in self.instructions:
            if inst.opname in skip_ops:
                continue
            read_keys.update(collect_tensor_sync_keys(inst.kwargs.get("src", None)))
            read_keys.update(collect_tensor_sync_keys(inst.kwargs.get("src_a", None)))
            read_keys.update(collect_tensor_sync_keys(inst.kwargs.get("src_b", None)))
            if inst.opname == "call_micro":
                read_keys.update(tuple(inst.kwargs.get("read_sync_keys", ())))
                write_keys.update(tuple(inst.kwargs.get("write_sync_keys", ())))
            write_keys.update(collect_tensor_sync_keys(inst.kwargs.get("dst", None)))

        normalized_reads = normalize_sync_key_group(read_keys)
        normalized_writes = normalize_sync_key_group(write_keys)
        self._read_sync_keys = normalized_reads or tuple()
        self._write_sync_keys = normalized_writes or tuple()
        self._split_parameter_sync_keys()

    def _split_parameter_sync_keys(self) -> None:
        """Attribute the traced keys to tensor parameters where they belong.

        Two parameters may alias one buffer at the tracing call site; attributing
        the key to both is conservative, because a later call that separates them
        then guards both, and a call that keeps them aliased produces one key.
        """
        param_keys: Dict[Any, List[str]] = {}
        for arg in self.input_list:
            key = tensor_sync_key(arg)
            if key is not None:
                param_keys.setdefault(key, []).append(arg.name)

        def _split(keys):
            names: Set[str] = set()
            static = []
            for key in keys:
                owners = param_keys.get(key)
                if owners:
                    names.update(owners)
                else:
                    static.append(key)
            return tuple(sorted(names)), tuple(static)

        self._read_param_names, self._read_static_keys = _split(
            self._read_sync_keys)
        self._write_param_names, self._write_static_keys = _split(
            self._write_sync_keys)

    def _warn_missing_vf_barriers(self) -> None:
        # Static lowering does not have reliable byte ranges after masks,
        # blk_stride, gather/scatter indices, and runtime slices are resolved.
        # Barrier warnings are therefore emitted only by the simulator's exact
        # WAW/RAW byte-range overlap tracker.
        return

    def gen_code(self, path: str) -> None:
        if not isinstance(path, str):
            raise TypeError(f"path must be str, got: {type(path)}")
        from ..parser.asc import translate
        from ..parser.asc_utils import dtype_to_cpp
        from ..parser.helper import CodeHelper
        from ..utils.castconfig import CastConfig
        from ..utils.divconfig import DivConfig

        helper = CodeHelper()
        helper("#pragma once")
        helper('#include "tensorutils.h"')
        helper()

        for cfg in self.cast_cfg_list:
            if not isinstance(cfg, CastConfig):
                continue
            sat = "SAT" if cfg.saturate else "NO_SAT"
            helper(
                "static constexpr MicroAPI::CastTrait "
                f"{cfg.name} = {{ MicroAPI::RegLayout::{cfg.reg_layout}, "
                f"MicroAPI::SatMode::{sat}, MicroAPI::MaskMergeMode::{cfg.merge_mode}, "
                f"RoundMode::{cfg.round_mode} }};"
            )
        if self.cast_cfg_list:
            helper()

        for cfg in self.div_cfg_list:
            if not isinstance(cfg, DivConfig):
                continue
            precision_mode = "true" if cfg.precision_mode else "false"
            helper(
                "static constexpr MicroAPI::DivSpecificMode "
                f"{cfg.name} = {{ MicroAPI::MaskMergeMode::ZEROING, "
                f"{precision_mode}, DivAlgo::{cfg.algo} }};"
            )
        if self.div_cfg_list:
            helper()

        args = []
        for arg in self.input_list:
            if isinstance(arg, Tensor):
                args.append(
                    f"__ubuf__ {dtype_to_cpp(arg.dtype)}* {arg.name}"
                )
            elif isinstance(arg, Var):
                args.append(
                    f"const {dtype_to_cpp(arg.dtype)} &{arg.name}"
                )
            else:
                raise TypeError(f"MicroModule only accepts Tensor or Var inputs, got: {type(arg)}")
        args_str = ", ".join(args)

        helper(f"__aicore__ inline void {self.name}({args_str}){{")
        helper.ir()
        helper("__VEC_SCOPE__")
        helper("{")
        helper.ir()

        external_var_names = [
            arg.name for arg in self.input_list
            if isinstance(arg, Var)
        ]
        try:
            code = translate(self.instructions, external_var_names=external_var_names)
        except ValueError as exc:
            raise ValueError(f"while generating vf {self.name}: {exc}") from exc
        for line in code.splitlines():
            helper(line)

        helper.il()
        helper("}")
        helper.il()
        helper("}")
        helper()

        with open(path, "w", encoding="utf-8") as f:
            f.write(str(helper))
