from typing import Callable, Any, Optional
from functools import wraps

from .kernelbase.kernelbase import KernelBase
from .micro.micromodule import MicroModule
from .pythonic import transform_kernel
from .utils.instruction import Instruction
from . import globvars


_VALID_KERNEL_MODES = ("mix", "vec", "cube")


def _build_kernel(func: Callable[..., Any], *, mode: str,
                  block_dim: Optional[str] = None) -> KernelBase:
    _validate_kernel_name(func.__name__)
    transformed = transform_kernel(func)
    return KernelBase(func.__name__, transformed, kernel_mode=mode, block_dim=block_dim)


def _build_auto_sync_kernel(func: Callable[..., Any], *, mode: str,
                            block_dim: Optional[str] = None) -> KernelBase:
    _validate_kernel_name(func.__name__)
    transformed = transform_kernel(func)
    sync = auto_sync()
    wrapped = sync._wrap(transformed)
    return KernelBase(func.__name__, wrapped, kernel_mode=mode, block_dim=block_dim)


def _validate_kernel_name(name: str) -> None:
    if any(char.isupper() for char in name):
        raise ValueError(f"kernel function name must not contain uppercase letters: {name!r}")


class kernel:
    """Decorator class that returns a KernelBase wrapper."""
    def __init__(self, func: Optional[Callable[..., Any]] = None, *, mode: str = "mix",
                 block_dim: Optional[str] = None):
        if func is not None:
            raise TypeError("kernel decorator requires parentheses; use @kernel() or @kernel(mode='mix'|'vec'|'cube')")
        if not isinstance(mode, str):
            raise TypeError(f"kernel mode must be str, got: {type(mode)}")
        if mode not in _VALID_KERNEL_MODES:
            raise ValueError(f"kernel mode must be one of {list(_VALID_KERNEL_MODES)}, got: {mode!r}")
        if block_dim is not None and not isinstance(block_dim, str):
            raise TypeError(f"kernel block_dim must be a C++ expression string, got: {type(block_dim)}")
        self._kernel: Optional[KernelBase] = None
        self._mode = mode
        self._block_dim = block_dim

    def __call__(self, *args, **kwargs):
        if self._kernel is None:
            if len(args) == 1 and callable(args[0]) and not kwargs:
                target = args[0]
                inner = getattr(target, "__auto_sync_inner__", None)
                if inner is not None and callable(inner):
                    return _build_auto_sync_kernel(inner, mode=self._mode,
                                                   block_dim=self._block_dim)
                return _build_kernel(target, mode=self._mode, block_dim=self._block_dim)
            raise TypeError("kernel decorator expects a single callable")
        return self._kernel(*args, **kwargs)

    def __getattr__(self, name):
        if self._kernel is not None:
            return getattr(self._kernel, name)
        raise AttributeError(name)


class func:
    """Decorator class that applies pythonic transform without creating a kernel."""
    def __init__(self, func: Optional[Callable[..., Any]] = None):
        self._func: Optional[Callable[..., Any]] = None
        if func is not None:
            inner = getattr(func, "__auto_sync_inner__", None)
            if inner is not None and callable(inner):
                transformed = transform_kernel(inner)
                sync = auto_sync()
                self._func = sync._wrap(transformed)
            else:
                self._func = transform_kernel(func)

    def __call__(self, *args, **kwargs):
        if self._func is None:
            if len(args) == 1 and callable(args[0]) and not kwargs:
                target = args[0]
                inner = getattr(target, "__auto_sync_inner__", None)
                if inner is not None and callable(inner):
                    transformed = transform_kernel(inner)
                    sync = auto_sync()
                    return sync._wrap(transformed)
                return transform_kernel(target)
            raise TypeError("func decorator expects a single callable")
        return self._func(*args, **kwargs)

    def __getattr__(self, name):
        if self._func is not None:
            return getattr(self._func, name)
        raise AttributeError(name)


class auto_sync:
    """Decorator/context that emits auto-sync markers around a block or call."""
    _VALID_MODES = {"conservative", "aggressive", "fix_storage", "manual_fix"}

    def __init__(self, func: Optional[Callable[..., Any]] = None, mode: str = "conservative"):
        if isinstance(func, str):
            if mode != "conservative":
                raise TypeError("auto_sync mode can be passed either positionally or by keyword, not both")
            mode = func
            func = None
        if func is not None and not callable(func):
            raise TypeError("auto_sync expects a callable or mode string")
        if not isinstance(mode, str):
            raise TypeError(f"auto_sync mode must be str, got: {type(mode)}")
        if mode not in self._VALID_MODES:
            raise ValueError(f"auto_sync mode must be one of {sorted(self._VALID_MODES)}, got: {mode!r}")
        self._func: Optional[Callable[..., Any]] = func
        self.mode = mode

    def _emit_start(self) -> None:
        if globvars.active_kernel is None:
            raise RuntimeError("auto_sync can only be used inside a kernel")
        globvars.active_kernel.instructions.append(Instruction("start_auto_sync", mode=self.mode))

    def _emit_end(self) -> None:
        if globvars.active_kernel is None:
            raise RuntimeError("auto_sync can only be used inside a kernel")
        globvars.active_kernel.instructions.append(Instruction("end_auto_sync"))

    def _wrap(self, func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapper(*args, **kwargs):
            self._emit_start()
            try:
                result = func(*args, **kwargs)
            except Exception:
                raise
            else:
                self._emit_end()
                return result
        wrapper.__auto_sync_inner__ = func  # type: ignore
        return wrapper

    def __call__(self, *args, **kwargs):
        if self._func is None:
            if len(args) == 1 and callable(args[0]) and not kwargs:
                return self._wrap(args[0])
            raise TypeError("auto_sync decorator expects a single callable")
        self._emit_start()
        try:
            result = self._func(*args, **kwargs)
        except Exception:
            raise
        else:
            self._emit_end()
            return result

    def __enter__(self):
        self._emit_start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            return False
        self._emit_end()
        return True

    def __getattr__(self, name):
        if self._func is not None:
            return getattr(self._func, name)
        raise AttributeError(name)


class vf:
    """Decorator class that creates a MicroModule wrapper."""
    def __init__(self):
        pass

    def __call__(self, func: Callable[..., Any]) -> MicroModule:
        if not callable(func):
            raise TypeError("vf decorator expects a single callable")
        transformed = transform_kernel(func)
        return MicroModule(func.__name__, transformed)


class simt:
    """Decorator class that creates a SimtModule wrapper."""

    _ALLOWED_NUM_THREADS = (128, 256, 512, 1024, 2048)

    def __init__(self, num_threads: int = 1024):
        if isinstance(num_threads, bool) or not isinstance(num_threads, int):
            raise TypeError(
                f"simt(num_threads=...) must be int, got {type(num_threads).__name__}"
            )
        if num_threads not in self._ALLOWED_NUM_THREADS:
            raise ValueError(
                "simt(num_threads=...) must be one of "
                + str(self._ALLOWED_NUM_THREADS)
                + ", got " + str(num_threads)
            )
        self.num_threads = num_threads

    def __call__(self, func: Callable[..., Any]):
        if not callable(func):
            raise TypeError("simt decorator expects a single callable")
        from .simt.simtmodule import SimtModule
        return SimtModule(func.__name__, func, num_threads=self.num_threads)
