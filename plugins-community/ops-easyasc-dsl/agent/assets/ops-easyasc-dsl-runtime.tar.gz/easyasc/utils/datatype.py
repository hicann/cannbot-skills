class DataTypeValue:
    """Data type value class representing a concrete data type."""
    def __init__(self, name: str):
        self.name = name
    
    def __repr__(self):
        return f"DataTypeValue('{self.name}')"
    
    def __str__(self):
        return self.name
    
    def __hash__(self):
        return hash(self.name)
    
    def __eq__(self, other):
        """Check whether two data types are equal."""
        if self is other:
            return True
        if not isinstance(other, DataTypeValue):
            raise TypeError(f"Cannot compare DataTypeValue with {type(other)}")
        return self.name == other.name

    @property
    def C0(self):
        if self.name == "half":
            return 16
        elif self.name == "float":
            return 8
        elif self.name == "int":
            return 8
        elif self.name == "int4":
            return 64
        elif self.name in ("fp4x2_e2m1_t", "fp4x2_e1m2_t"):
            return 64
        elif self.name == "int8_t":
            return 32
        elif self.name == "uint8_t":
            return 32
        elif self.name == "int16_t":
            return 16
        elif self.name == "uint16_t":
            return 16
        elif self.name == "float8_e4m3_t":
            return 32
        elif self.name == "float8_e5m2_t":
            return 32
        elif self.name == "mx_fp8_e4m3_t":
            return 32
        elif self.name == "mx_fp8_e5m2_t":
            return 32
        elif self.name == "hifloat8_t":
            return 32 
        elif self.name == "bfloat16_t":
            return 16
        elif self.name == "uint32_t":
            return 8
        elif self.name == "uint64_t":
            return 4
        elif self.name == "int64_t":
            return 4
        elif self.name == "complex32":
            return 8
        elif self.name == "complex64":
            return 4
        else:
            raise ValueError(f"Unknown data type: {self.name}")

    @property
    def size(self):
        if self.name == "half":
            return 2
        elif self.name == "float":
            return 4
        elif self.name == "int":
            return 4
        elif self.name == "int4":
            raise ValueError("DT.int4 is a packed int4 compute-view dtype and does not have addressable byte size")
        elif self.name in ("fp4x2_e2m1_t", "fp4x2_e1m2_t"):
            raise ValueError(
                f"DT.{self.name} is a packed FP4 compute-view dtype and does not have addressable byte size"
            )
        elif self.name == "int8_t":
            return 1
        elif self.name == "uint8_t":
            return 1
        elif self.name == "int16_t":
            return 2
        elif self.name == "uint16_t":
            return 2
        elif self.name == "float8_e4m3_t":
            return 1
        elif self.name == "float8_e5m2_t":
            return 1
        elif self.name == "mx_fp8_e4m3_t":
            return 1
        elif self.name == "mx_fp8_e5m2_t":
            return 1
        elif self.name == "hifloat8_t":
            return 1 
        elif self.name == "bfloat16_t":
            return 2
        elif self.name == "uint32_t":
            return 4
        elif self.name == "uint64_t":
            return 8
        elif self.name == "int64_t":
            return 8
        elif self.name == "complex32":
            return 4          # AscendC::Complex<half>  = 2 x fp16
        elif self.name == "complex64":
            return 8          # AscendC::Complex<float> = 2 x fp32
        else:
            raise ValueError(f"Unknown data type: {self.name}")

class Datatype:
    """Data type enum-like class containing supported members."""
    half = DataTypeValue("half")
    float = DataTypeValue("float")
    int = DataTypeValue("int")
    int4 = DataTypeValue("int4")
    fp4_e2m1 = DataTypeValue("fp4x2_e2m1_t")
    fp4_e1m2 = DataTypeValue("fp4x2_e1m2_t")
    int8 = DataTypeValue("int8_t")
    uint8 = DataTypeValue("uint8_t")
    int16 = DataTypeValue("int16_t")
    uint16 = DataTypeValue("uint16_t")
    e4m3 = DataTypeValue("float8_e4m3_t")
    e5m2 = DataTypeValue("float8_e5m2_t")
    mx_e4m3 = DataTypeValue("mx_fp8_e4m3_t")
    mx_e5m2 = DataTypeValue("mx_fp8_e5m2_t")
    bfloat16 = DataTypeValue("bfloat16_t")
    uint32 = DataTypeValue("uint32_t")
    uint64 = DataTypeValue("uint64_t")
    int64 = DataTypeValue("int64_t")
    hif8 = DataTypeValue("hifloat8_t")
    # Complex reg dtypes (a5/C310). C++ aliases: complex32 = AscendC::Complex<half>
    # (2 x fp16, 4 B), complex64 = AscendC::Complex<float> (2 x fp32, 8 B).
    complex32 = DataTypeValue("complex32")
    complex64 = DataTypeValue("complex64")


INTEGER_DTYPES = (
    Datatype.int,
    Datatype.int8,
    Datatype.uint8,
    Datatype.int16,
    Datatype.uint16,
    Datatype.uint32,
    Datatype.uint64,
    Datatype.int64,
)


def is_integer_dtype(dtype) -> bool:
    return isinstance(dtype, DataTypeValue) and dtype in INTEGER_DTYPES


COMPLEX_DTYPES = (
    Datatype.complex32,
    Datatype.complex64,
)


def is_complex_dtype(dtype) -> bool:
    return isinstance(dtype, DataTypeValue) and dtype in COMPLEX_DTYPES
