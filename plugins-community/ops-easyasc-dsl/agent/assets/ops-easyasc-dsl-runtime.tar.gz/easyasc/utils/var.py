from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Union, cast
from .datatype import DataTypeValue, Datatype
from .naming import assert_codegen_safe_identifier
from .. import globvars
from .instruction import Instruction

if TYPE_CHECKING:
    from .Tensor import GMTensor, Tensor


class Expr:
    def __init__(self, expr: str):
        self.expr = expr

    def __repr__(self):
        return f"Expr({self.expr!r})"

    def __str__(self):
        return self.expr

    def __bool__(self) -> bool:
        raise TypeError("Expr cannot be used in Python boolean context, use If/Elif/Else instead")
        return False

    def __and__(self, other):
        return Expr(f"({self}) && ({_expr_operand(other)})")

    def __rand__(self, other):
        return Expr(f"({_expr_operand(other)}) && ({self})")

    def __or__(self, other):
        return Expr(f"({self}) || ({_expr_operand(other)})")

    def __ror__(self, other):
        return Expr(f"({_expr_operand(other)}) || ({self})")

    def __invert__(self):
        return Expr(f"!({self})")


def _expr_operand(value) -> str:
    if isinstance(value, Var):
        return value.name
    if isinstance(value, Expr):
        return str(value)
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _is_integer_var_dtype(dtype: Optional[DataTypeValue]) -> bool:
    return dtype in {
        Datatype.int,
        Datatype.int8,
        Datatype.uint8,
        Datatype.int16,
        Datatype.uint16,
        Datatype.uint32,
        Datatype.uint64,
        Datatype.int64,
    }


def _dedupe_declared_var_name(name: str) -> str:
    target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
    if target is None:
        return name
    counts = getattr(target, "_var_name_counts", None)
    if counts is None:
        counts = {}
        target._var_name_counts = counts
    base = name
    seen = counts.get(base, 0)
    if seen > 0:
        name = f"{base}_{seen}"
    counts[base] = seen + 1
    return name


class Var:
    """Variable class."""
    def __init__(
        self,
        value: Union[int, float, 'Var', None] = 0,
        dtype: Optional[DataTypeValue] = None,
        name: str = "",
    ):
        """
        Initialize a variable.

        Args:
            value: Optional value, defaults to None.
            dtype: Data type, must be DataTypeValue.
            name: Name, defaults to empty string.
        """
        value_var: Optional[Var] = value if isinstance(value, Var) else None
        value_is_var = value_var is not None

        if dtype is None:
            if isinstance(value, int):
                dtype = Datatype.int
            elif isinstance(value, float):
                dtype = Datatype.float
            elif value_var is not None:
                dtype = value_var.dtype
            elif value is not None:
                raise TypeError(f"Cannot infer dtype from value type: {type(value)}")

        if dtype is not None and not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue or None, got: {type(dtype)}")
        
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")
        
        if value is not None and not isinstance(value, (int, float, Var)):
            raise TypeError(f"value must be int, float, or Var, got: {type(value)}")
        
        assert_codegen_safe_identifier(name, "Var")
        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        if name == "":
            name = f"_tmp_var_{idx}"
        else:
            name = _dedupe_declared_var_name(name)

        self.dtype: Optional[DataTypeValue] = dtype
        self.name: str = name
        if value_var is not None:
            self.value: Union[int, float, None] = value_var.value
        else:
            self.value = cast(Union[int, float, None], value)
        self.idx: int = idx

        target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
        if target is not None:
            # Snapshot the declaration initializer. Runtime reads may later
            # invalidate ``self.value`` for constant propagation, but the C++
            # declaration and simulator still need a concrete initializer.
            target.instructions.append(Instruction("create_var", val=self, init_value=self.value))
            if value_is_var:
                # Keep Var(existing_var) as a real copy; codegen folds this pair when safe.
                target.instructions.append(Instruction("var_assign", out=self, src=value_var))

    def __repr__(self):
        return (
            f"Var(name={self.name!r}, dtype={self.dtype!r}, value={self.value!r}, "
            f"idx={self.idx!r})"
        )

    def __mul__(self, other):
        from ..stub_functions.var_op import var_mul
        return var_mul(self, other)

    def __rmul__(self, other):
        from ..stub_functions.var_op import var_mul
        return var_mul(other, self)

    def __add__(self, other):
        from ..stub_functions.var_op import var_add
        return var_add(self, other)

    def __radd__(self, other):
        from ..stub_functions.var_op import var_add
        return var_add(other, self)

    def __iadd__(self, other):
        if not isinstance(other, (Var, int, float)):
            raise TypeError(f"other must be Var or numeric type, got: {type(other)}")
        if self.dtype is None:
            raise TypeError("self.dtype must be set before using +=")

        if isinstance(other, Var):
            if other.dtype is None:
                raise TypeError("other.dtype must be set when other is Var")
            if self.dtype is Datatype.float:
                if other.dtype is not Datatype.float:
                    raise TypeError(
                        f"Var(dtype={self.dtype}) only supports += Var(dtype={Datatype.float}), got: {other.dtype}"
                    )
            elif _is_integer_var_dtype(self.dtype):
                if other.dtype != self.dtype:
                    raise TypeError(
                        f"Var(dtype={self.dtype}) only supports += Var(dtype={self.dtype}), got: {other.dtype}"
                    )
            else:
                raise TypeError(f"+= is unsupported for Var dtype: {self.dtype}")
        elif isinstance(other, float):
            if self.dtype is not Datatype.float:
                raise TypeError(
                    f"Var(dtype={self.dtype}) only supports += float when self.dtype is {Datatype.float}"
                )
        else:
            if not _is_integer_var_dtype(self.dtype):
                raise TypeError(
                    f"Var(dtype={self.dtype}) only supports += int when self.dtype is an integer dtype"
                )

        target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
        if target is not None:
            target.instructions.append(
                Instruction("var_add", a=self, b=other, out=self)
            )
        return self

    def __sub__(self, other):
        from ..stub_functions.var_op import var_sub
        return var_sub(self, other)

    def __rsub__(self, other):
        from ..stub_functions.var_op import var_sub
        return var_sub(other, self)

    def __truediv__(self, other):
        from ..stub_functions.var_op import var_div
        return var_div(self, other)

    def __rtruediv__(self, other):
        from ..stub_functions.var_op import var_div
        return var_div(other, self)

    def __floordiv__(self, other):
        from ..stub_functions.var_op import var_div
        return var_div(self, other)

    def __rfloordiv__(self, other):
        from ..stub_functions.var_op import var_div
        return var_div(other, self)

    def __mod__(self, other):
        from ..stub_functions.var_op import var_mod
        return var_mod(self, other)

    def __rmod__(self, other):
        from ..stub_functions.var_op import var_mod
        return var_mod(other, self)

    def __ilshift__(self, other):
        from .Tensor import GMTensor, Tensor

        if isinstance(other, (Tensor, GMTensor)):
            return self.GetValueFrom(other)
        if isinstance(other, (Var, int, float)):
            if globvars.active_micro is not None:
                globvars.active_micro.instructions.append(
                    Instruction("var_assign", out=self, src=other)
                )
            elif globvars.active_kernel is not None:
                globvars.active_kernel.instructions.append(
                    Instruction("var_assign", out=self, src=other)
                )
            return self
        raise TypeError(f"other must be Tensor, GMTensor, Var, int, or float, got: {type(other)}")

    def __irshift__(self, other):
        from .Tensor import Tensor, GMTensor

        if isinstance(other, (Tensor, GMTensor)):
            return self.SetValueTo(other)
        raise TypeError(f"other must be Tensor or GMTensor, got: {type(other)}")

    def _cmp(self, other, op: str):
        if globvars.active_micro is not None or globvars.active_kernel is not None:
            # Keep Var-driven control flow symbolic while building DSL instructions.
            # Eagerly folding on `.value` is unsafe because ordinary Vars can later be
            # reassigned, and derived Vars can carry a stale build-time hint from the
            # first loop iteration.
            return Expr(f"{_expr_operand(self)} {op} {_expr_operand(other)}")
        lv = getattr(self, "value", None)
        rv = getattr(other, "value", other) if hasattr(other, "value") else other
        if isinstance(lv, (int, float)) and isinstance(rv, (int, float)):
            _CMP_FNS = {"<": lambda a, b: a < b, "<=": lambda a, b: a <= b,
                         ">": lambda a, b: a > b, ">=": lambda a, b: a >= b,
                         "==": lambda a, b: a == b, "!=": lambda a, b: a != b}
            fn = _CMP_FNS.get(op)
            if fn is not None:
                return fn(lv, rv)
        return Expr(f"{_expr_operand(self)} {op} {_expr_operand(other)}")

    def _as_bool_expr(self) -> "Expr":
        return Expr(_expr_operand(self))

    def __and__(self, other):
        return self._as_bool_expr() & other

    def __rand__(self, other):
        return Expr(_expr_operand(other)) & self._as_bool_expr()

    def __or__(self, other):
        return self._as_bool_expr() | other

    def __ror__(self, other):
        return Expr(_expr_operand(other)) | self._as_bool_expr()

    def __invert__(self):
        return ~self._as_bool_expr()

    def __eq__(self, other):
        return self._cmp(other, "==")

    def __ne__(self, other):
        return self._cmp(other, "!=")

    def __lt__(self, other):
        return self._cmp(other, "<")

    def __le__(self, other):
        return self._cmp(other, "<=")

    def __gt__(self, other):
        return self._cmp(other, ">")

    def __ge__(self, other):
        return self._cmp(other, ">=")

    def GetValueFrom(self, src: Union["Tensor", "GMTensor"]) -> "Var":
        from .Tensor import GMTensor, Tensor
        from .positions import Position

        if globvars.active_micro is not None:
            raise ValueError("GetValueFrom is not supported in vf context")
        if self.dtype is None:
            raise TypeError("GetValueFrom requires destination Var dtype")
        if isinstance(src, Tensor):
            if src.position is not Position.UB:
                raise ValueError(
                    f"GetValueFrom on Tensor only supports UB position, current position: {src.position}"
                )
        elif not isinstance(src, GMTensor):
            raise TypeError(f"src must be Tensor or GMTensor, got: {type(src)}")

        # A runtime tensor read invalidates any constructor-time value hint.
        # Keeping e.g. ``Var(0, dtype)`` as value==0 after this point can make
        # downstream helpers incorrectly constant-fold or reject operations
        # that consume the value loaded by GetValueFrom.
        self.value = None
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("GetValueFrom", dst=self, out=self, src=src)
            )
        return self

    def SetValueTo(self, src: Union["Tensor", "GMTensor"]) -> "Var":
        from .Tensor import GMTensor, Tensor
        from .positions import Position

        if globvars.active_micro is not None:
            raise ValueError("SetValueTo is not supported in vf context")
        if self.dtype is None:
            raise TypeError("SetValueTo requires source Var dtype")
        if isinstance(src, Tensor):
            if src.position is not Position.UB:
                raise ValueError(
                    f"SetValueTo only supports UB Tensor destination, current position: {src.position}"
                )
        elif not isinstance(src, GMTensor):
            raise TypeError(f"src must be Tensor or GMTensor, got: {type(src)}")

        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("SetValueTo", src=src, dst=self)
            )
        return self


class VarRef(Var):
    """Reference to one element inside a VarList, such as arr[3]."""

    def __init__(
        self,
        dtype: Optional[DataTypeValue],
        name: str,
        parent: Optional["VarList"] = None,
        index: Optional[Union[int, Var]] = None,
    ):
        if dtype is not None and not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue or None, got: {type(dtype)}")
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")
        if parent is not None and not isinstance(parent, VarList):
            raise TypeError(f"parent must be VarList or None, got: {type(parent)}")
        if index is not None and not isinstance(index, (int, Var)):
            raise TypeError(f"index must be int, Var, or None, got: {type(index)}")

        self.dtype = dtype
        self.name = name
        self.value = None
        self.idx = -1
        self.parent = parent
        self.index = index

    def __repr__(self):
        return (
            f"VarRef(name={self.name!r}, dtype={self.dtype!r}, "
            f"parent={getattr(self.parent, 'name', None)!r}, index={self.index!r})"
        )


class VarList:
    """One-dimensional scalar array lowered to a C++ local array declaration."""

    def __init__(self, dtype: DataTypeValue, length: int, name: str = ""):
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        if not isinstance(length, int):
            raise TypeError(f"length must be int, got: {type(length)}")
        if length <= 0:
            raise ValueError(f"length must be greater than 0, current value: {length}")
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")
        assert_codegen_safe_identifier(name, "VarList")

        if name == "":
            idx = globvars.tmp_idx
            globvars.tmp_idx += 1
            name = f"_varlist_{idx}"

        self.dtype = dtype
        self.length = length
        self.name = name

        target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
        if target is not None:
            target.instructions.append(Instruction("create_varlist", varlist=self))

    def __repr__(self):
        return (
            f"VarList(name={self.name!r}, dtype={self.dtype!r}, length={self.length!r})"
        )

    def __str__(self) -> str:
        return self.name

    def __getitem__(self, idx: Union[int, Var]) -> VarRef:
        if not isinstance(idx, (int, Var)):
            raise TypeError(f"VarList index only supports int or Var, got: {type(idx)}")
        if isinstance(idx, int):
            if idx < 0 or idx >= self.length:
                raise IndexError(f"VarList index out of range: {idx}")
            idx_text = str(idx)
        else:
            idx_text = idx.name
        return VarRef(self.dtype, f"{self.name}[{idx_text}]", parent=self, index=idx)

    def __setitem__(self, idx, value) -> None:
        # `arr[i] <<= x` triggers a follow-up `__setitem__` in Python's augmented
        # assignment protocol. The write already happened through the VarRef proxy.
        _ = idx
        _ = value
