class VfPipeType:
    """VF-local memory pipe selector for micro local-memory barriers."""

    def __init__(self, name: str):
        self.name = name

    def __repr__(self) -> str:
        return f"VfPipeType({self.name!r})"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        if self is other:
            return True
        if not isinstance(other, VfPipeType):
            raise TypeError(f"Cannot compare VfPipeType with {type(other)}")
        return self.name == other.name

    def __hash__(self) -> int:
        return hash(self.name)


class VfPipe:
    """Enum-like namespace for VF local-memory barrier endpoints.

    The scalar endpoints matter whenever UB written inside a ``@vf()`` region is
    read back through ``GetValueFrom`` (or written by ``SetValueTo`` before the
    region reads it): the VF store buffer is its own ordering domain, so
    ``PipeBarrier<PIPE_ALL>`` does *not* publish those stores to the scalar
    unit.  ``mem_bar(VST_LD)`` -- ``VfPipe.STORE -> VfPipe.SCALAR_LOAD`` -- is
    what the hardware needs.
    """

    STORE = VfPipeType("VEC_STORE")
    LOAD = VfPipeType("VEC_LOAD")
    SCALAR_STORE = VfPipeType("SCALAR_STORE")
    SCALAR_LOAD = VfPipeType("SCALAR_LOAD")
    VEC_ALL = VfPipeType("VEC_ALL")
    SCALAR_ALL = VfPipeType("SCALAR_ALL")


# Combinations MicroAPI::LocalMemBar accepts on dav_c310; anything else is a
# static_assert at build time, so reject it while tracing instead.
_SUPPORTED_MEM_BARS = frozenset({
    ("VEC_STORE", "VEC_LOAD"),
    ("VEC_LOAD", "VEC_STORE"),
    ("VEC_STORE", "VEC_STORE"),
    ("VEC_STORE", "SCALAR_LOAD"),
    ("VEC_STORE", "SCALAR_STORE"),
    ("VEC_LOAD", "SCALAR_STORE"),
    ("SCALAR_STORE", "VEC_LOAD"),
    ("SCALAR_STORE", "VEC_STORE"),
    ("SCALAR_LOAD", "VEC_STORE"),
    ("VEC_ALL", "VEC_ALL"),
    ("VEC_ALL", "SCALAR_ALL"),
    ("SCALAR_ALL", "VEC_ALL"),
})


def check_mem_bar_pair(src: VfPipeType, dst: VfPipeType) -> None:
    if (src.name, dst.name) not in _SUPPORTED_MEM_BARS:
        raise ValueError(
            "vf_barrier({}, {}) is not a LocalMemBar combination the device "
            "supports; pick one of {}".format(
                src.name, dst.name, sorted(_SUPPORTED_MEM_BARS)
            )
        )


def vf_pipe_to_cpp_mem_type(pipe: VfPipeType) -> str:
    if not isinstance(pipe, VfPipeType):
        raise TypeError(f"vf_barrier endpoint must be VfPipeType, got: {type(pipe)}")
    return pipe.name
