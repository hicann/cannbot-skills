"""Identifier-name fences for DSL objects.

Names handed to ``Tensor`` / ``GMTensor`` / ``Var`` / ``Reg`` / ... flow
verbatim into generated C++ as identifiers (e.g. ``GlobalTensor<float> new;`` or
``int32_t template = 0;``). A name that is a C++ reserved keyword therefore
produces code that does not compile. The auto-naming transform in
``pythonic.py`` reuses the Python variable / kernel-argument name as the DSL
name, so a kernel as innocent as ``new = Tensor(...)`` or
``def k(new: GMTensor)`` would silently emit broken C++.

``assert_codegen_safe_identifier`` rejects both ISO C++ keywords and non-keyword
element type names that EasyASC emits unqualified in generated device code. This
keeps names such as ``half`` from shadowing the AscendC type inside a generated
kernel function.
"""

from typing import FrozenSet

# C++ reserved keywords (ISO C++23, including the alternative-token operators
# such as ``and`` / ``bitor`` and the literal keywords ``true`` / ``false`` /
# ``nullptr``). Matching is exact and case-sensitive: C++ keywords are all
# lowercase, so capitalized DSL names (``Var``, ``Tensor``, ``Min``, ``New``)
# are never affected. Many of these are also Python keywords and so can never
# be auto-injected as a variable / parameter name, but they are kept for the
# explicit ``name=...`` path and to keep the set a faithful copy of the C++ list.
CPP_RESERVED_KEYWORDS: FrozenSet[str] = frozenset({
    "alignas", "alignof", "and", "and_eq", "asm", "atomic_cancel",
    "atomic_commit", "atomic_noexcept", "auto", "bitand", "bitor", "bool",
    "break", "case", "catch", "char", "char8_t", "char16_t", "char32_t",
    "class", "compl", "concept", "const", "consteval", "constexpr",
    "constinit", "const_cast", "continue", "co_await", "co_return", "co_yield",
    "decltype", "default", "delete", "do", "double", "dynamic_cast", "else",
    "enum", "explicit", "export", "extern", "false", "float", "for", "friend",
    "goto", "if", "inline", "int", "long", "mutable", "namespace", "new",
    "noexcept", "not", "not_eq", "nullptr", "operator", "or", "or_eq",
    "private", "protected", "public", "reflexpr", "register",
    "reinterpret_cast", "requires", "return", "short", "signed", "sizeof",
    "static", "static_assert", "static_cast", "struct", "switch", "template",
    "this", "thread_local", "throw", "true", "try", "typedef", "typeid",
    "typename", "union", "unsigned", "using", "virtual", "void", "volatile",
    "wchar_t", "while", "xor", "xor_eq",
})

# Non-keyword element type identifiers emitted verbatim by ``dtype_to_cpp``.
# A kernel parameter or DSL object with one of these names shadows the type in
# the generated function body. For example, ``def k(..., half: Var)`` becomes a
# C++ parameter ``int half`` and makes ``GlobalTensor<half>`` fail to compile.
# Keep this list aligned with the public ``Datatype`` values and the int4 codegen
# spelling in ``easyasc/parser/asc_utils.py``.
CPP_GENERATED_TYPE_IDENTIFIERS: FrozenSet[str] = frozenset({
    "half", "int4b_t", "fp4x2_e2m1_t", "fp4x2_e1m2_t",
    "int8_t", "uint8_t", "int16_t", "uint16_t", "uint32_t", "uint64_t",
    "int64_t", "float8_e4m3_t", "float8_e5m2_t", "mx_fp8_e4m3_t",
    "mx_fp8_e5m2_t", "bfloat16_t", "hifloat8_t", "complex32", "complex64",
})


def assert_not_cpp_keyword(name: str, kind: str = "identifier") -> None:
    """Reject a DSL object ``name`` that collides with a C++ reserved keyword.

    Args:
        name: The user-supplied name. Non-``str`` values and the empty string
            (which triggers auto-naming) pass through untouched; ``str`` type is
            validated separately by each caller.
        kind: Human-readable category of the named object (``"Tensor"``,
            ``"Var"``, ``"kernel argument"``, ...), used only in the error text.

    Raises:
        ValueError: If ``name`` is a C++ reserved keyword.
    """
    if not isinstance(name, str):
        return
    if name in CPP_RESERVED_KEYWORDS:
        raise ValueError(
            f"{kind} name {name!r} is a reserved C++ keyword and cannot be used "
            f"as an identifier in generated code; rename it (e.g. {name!r} -> "
            f"'{name}_')."
        )


def assert_codegen_safe_identifier(name: str, kind: str = "identifier") -> None:
    """Reject names that are unsafe when emitted verbatim into generated C++."""
    assert_not_cpp_keyword(name, kind)
    if not isinstance(name, str):
        return
    if name in CPP_GENERATED_TYPE_IDENTIFIERS:
        raise ValueError(
            f"{kind} name {name!r} collides with a generated C++ element type "
            f"and cannot be used as an identifier in generated code; rename it "
            f"(e.g. {name!r} -> '{name}_width')."
        )
