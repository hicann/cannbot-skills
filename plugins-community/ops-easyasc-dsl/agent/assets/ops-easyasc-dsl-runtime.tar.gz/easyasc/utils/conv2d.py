"""Conv2D descriptor and img2col virtual-matrix view for the load3d path.

The view turns a NC1HWC0 feature map living in L1 (a 2D easyasc Tensor of
shape [C1*H*W, C0]) plus a Conv2D descriptor into a virtual [M, K] matrix:

    M = Ho * Wo                 (m = ho * Wo + wo, W fastest)
    K = C1 * Kh * Kw * C0       (k = ((c1*Kh + kh)*Kw + kw)*C0 + c0)

Slicing the view (always [m0:m0+mExt, k0:k0+kExt]) produces an Img2colSlice
consumed by l1_to_l0a_img2col. See doc/topics/conv2d.md for the documented
constraints.
"""
from typing import Tuple, Union

from .Tensor import Tensor
from .positions import Position
from .var import Var

ShapeDim = Union[int, Var]

_MAX_FILTER = 255
_MAX_PAD = 255
_MAX_STRIDE = 63
_MAX_DILATION = 255
_MAX_L1_HW = 32767
_MAX_START = 32767
_MAX_EXT = 65535


def _check_int_range(val: int, lo: int, hi: int, label: str) -> None:
    if not isinstance(val, int) or isinstance(val, bool):
        raise TypeError(f"{label} must be int, got: {type(val)}")
    if not (lo <= val <= hi):
        raise ValueError(f"{label} must be in [{lo}, {hi}], current value: {val}")


def _check_dim(val: ShapeDim, lo: int, hi: int, label: str) -> None:
    """Static range check; Vars are accepted and validated at runtime by HW limits."""
    if isinstance(val, Var):
        return
    _check_int_range(val, lo, hi, label)


class Conv2D:
    """Compile-time conv geometry: filter / pad / stride / dilation only.

    Spatial size and channels live on the feature map, not here, so one
    descriptor serves every layer with the same filter geometry.
    pad order is (left, right, top, bottom), matching the hardware padList.
    """

    def __init__(
        self,
        kh: ShapeDim,
        kw: ShapeDim,
        pad: Tuple[ShapeDim, ShapeDim, ShapeDim, ShapeDim] = (0, 0, 0, 0),
        stride: Tuple[ShapeDim, ShapeDim] = (1, 1),
        dilation: Tuple[ShapeDim, ShapeDim] = (1, 1),
    ):
        # Every field lands in a runtime `int` argument of the load3d helper, so
        # a Var is legal wherever the geometry is only known at launch time.
        _check_dim(kh, 1, _MAX_FILTER, "kh")
        _check_dim(kw, 1, _MAX_FILTER, "kw")
        if not (isinstance(pad, (tuple, list)) and len(pad) == 4):
            raise TypeError(f"pad must be (left, right, top, bottom), got: {pad!r}")
        for v, lbl in zip(pad, ("pad left", "pad right", "pad top", "pad bottom")):
            _check_dim(v, 0, _MAX_PAD, lbl)
        if not (isinstance(stride, (tuple, list)) and len(stride) == 2):
            raise TypeError(f"stride must be (h, w), got: {stride!r}")
        for v, lbl in zip(stride, ("stride h", "stride w")):
            _check_dim(v, 1, _MAX_STRIDE, lbl)
        if not (isinstance(dilation, (tuple, list)) and len(dilation) == 2):
            raise TypeError(f"dilation must be (h, w), got: {dilation!r}")
        for v, lbl in zip(dilation, ("dilation h", "dilation w")):
            _check_dim(v, 1, _MAX_DILATION, lbl)
        self.kh = kh
        self.kw = kw
        self.pad = tuple(pad)
        self.stride = tuple(stride)
        self.dilation = tuple(dilation)

    def out_hw(self, h: ShapeDim, w: ShapeDim) -> Tuple[ShapeDim, ShapeDim]:
        pl, pr, pt, pb = self.pad
        eff_h = self.dilation[0] * (self.kh - 1) + 1
        eff_w = self.dilation[1] * (self.kw - 1) + 1
        ho = (h + pt + pb - eff_h) // self.stride[0] + 1
        wo = (w + pl + pr - eff_w) // self.stride[1] + 1
        if isinstance(ho, int) and isinstance(wo, int) and (ho <= 0 or wo <= 0):
            raise ValueError(
                f"conv window larger than padded input: Ho={ho}, Wo={wo} "
                f"(h={h}, w={w}, pad={self.pad}, kh={self.kh}, kw={self.kw})"
            )
        return ho, wo

    def __repr__(self):
        return (
            f"Conv2D(kh={self.kh}, kw={self.kw}, pad={self.pad}, "
            f"stride={self.stride}, dilation={self.dilation})"
        )


class Img2colSlice:
    """One [m0:m0+m_ext, k0:k0+k_ext] window of an Img2colView (no data)."""

    def __init__(self, view: "Img2colView", m0: ShapeDim, k0: ShapeDim,
                 m_ext: int, k_ext: int):
        self.view = view
        self.m0 = m0
        self.k0 = k0
        self.m_ext = m_ext
        self.k_ext = k_ext


class Img2colView:
    """Virtual [M, K] img2col matrix over an L1 NC1HWC0 feature map."""

    def __init__(self, fmap: Tensor, conv: Conv2D, h: ShapeDim, w: ShapeDim, c: ShapeDim):
        if not isinstance(fmap, Tensor):
            raise TypeError(f"fmap must be Tensor, got: {type(fmap)}")
        if fmap.position is not Position.L1:
            raise ValueError(f"fmap must be at L1, current position: {fmap.position}")
        if not isinstance(conv, Conv2D):
            raise TypeError(f"conv must be Conv2D, got: {type(conv)}")
        if any(off != 0 for off in fmap.offset):
            raise ValueError("img2col fmap must be a base L1 tensor (offset 0), not a slice view")
        _check_dim(h, 1, _MAX_L1_HW, "h")
        _check_dim(w, 1, _MAX_L1_HW, "w")
        _check_dim(c, 1, _MAX_EXT, "c")
        c0 = fmap.dtype.C0
        c1 = (c + c0 - 1) // c0
        expected = c1 * h * w * c0
        actual = fmap.shape[0] * fmap.shape[1]
        # Var dims: the fmap tensor is the static worst-case allocation; the
        # element-count identity can only be checked when everything is static.
        if isinstance(expected, int) and isinstance(actual, int) and actual != expected:
            raise ValueError(
                f"fmap [{fmap.shape[0]}, {fmap.shape[1]}] holds {actual} elements, but "
                f"NC1HWC0 with h={h}, w={w}, c={c} (C0={c0}) needs {expected}"
            )
        self.fmap = fmap
        self.conv = conv
        self.h = h
        self.w = w
        self.c = c
        self.c0 = c0
        self.c1 = c1
        self.ho, self.wo = conv.out_hw(h, w)
        self.M = self.ho * self.wo
        self.K = c1 * conv.kh * conv.kw * c0

    @property
    def shape(self) -> Tuple[ShapeDim, ShapeDim]:
        return (self.M, self.K)

    def window(self, m0: ShapeDim, k0: ShapeDim, m_ext: ShapeDim, k_ext: ShapeDim) -> Img2colSlice:
        """Explicit-extent slice: like view[m0:m0+m_ext, k0:k0+k_ext] but valid
        for Var starts (the slice form can't recover static extents there).

        Extents may also be Vars: load3d takes mExtension/kExtension as runtime
        values, so a K tail whose size is only known at launch stays legal. The
        16 / C0 alignment rules still hold and are then the caller's obligation.
        """
        for v, lbl in ((m0, "m start"), (k0, "k start")):
            if not isinstance(v, (int, Var)) or isinstance(v, bool):
                raise TypeError(f"{lbl} must be int or Var, got: {type(v)}")
        _check_dim(m_ext, 1, _MAX_EXT, "m extent")
        _check_dim(k_ext, 1, _MAX_EXT, "k extent")
        if isinstance(m_ext, int) and m_ext % 16 != 0:
            raise ValueError(f"m extent must be a multiple of 16, current value: {m_ext}")
        if isinstance(k_ext, int) and isinstance(self.c0, int) and k_ext % self.c0 != 0:
            raise ValueError(f"k extent must be a multiple of C0={self.c0}, current value: {k_ext}")
        if isinstance(m0, int):
            _check_int_range(m0, 0, _MAX_START, "m start")
            if m0 % 16 != 0:
                raise ValueError(f"m start must be a multiple of 16, current value: {m0}")
        if isinstance(k0, int):
            _check_int_range(k0, 0, _MAX_EXT, "k start")
            if isinstance(self.c0, int) and k0 % self.c0 != 0:
                raise ValueError(f"k start must be a multiple of C0={self.c0}, current value: {k0}")
            if isinstance(self.K, int) and isinstance(k_ext, int) and k0 + k_ext > self.K:
                raise ValueError(f"k window [{k0}, {k0 + k_ext}) exceeds K={self.K}")
        return Img2colSlice(self, m0, k0, m_ext, k_ext)

    def __getitem__(self, index) -> Img2colSlice:
        if not (isinstance(index, tuple) and len(index) == 2
                and isinstance(index[0], slice) and isinstance(index[1], slice)):
            raise TypeError("img2col view expects view[m0:m0+tile_m, k0:k0+tile_k]")
        m_idx, k_idx = index
        if (m_idx.step is not None and m_idx.step != 1) or (k_idx.step is not None and k_idx.step != 1):
            raise ValueError("img2col slice step must be 1")
        m0 = m_idx.start if m_idx.start is not None else 0
        m_stop = m_idx.stop if m_idx.stop is not None else self.M
        k0 = k_idx.start if k_idx.start is not None else 0
        k_stop = k_idx.stop if k_idx.stop is not None else self.K
        for v, lbl in ((m0, "m start"), (m_stop, "m stop"), (k0, "k start"), (k_stop, "k stop")):
            if not isinstance(v, (int, Var)) or isinstance(v, bool):
                raise TypeError(f"{lbl} must be int or Var, got: {type(v)}")
        m_ext = m_stop - m0
        k_ext = k_stop - k0
        if not isinstance(m_ext, int) or not isinstance(k_ext, int):
            raise TypeError(
                "img2col slice extents must be static ints (start may be Var); "
                "use view.window(m0, k0, m_ext, k_ext) for Var starts"
            )
        return self.window(m0, k0, m_ext, k_ext)

    def __repr__(self):
        return (
            f"Img2colView(M={self.M}, K={self.K}, h={self.h}, w={self.w}, "
            f"c={self.c}, conv={self.conv!r})"
        )


def img2col(fmap: Tensor, conv: Conv2D, h: ShapeDim, w: ShapeDim, c: ShapeDim) -> Img2colView:
    """Wrap an L1 NC1HWC0 feature map as a virtual img2col [M, K] matrix."""
    return Img2colView(fmap, conv, h, w, c)


# ---- host-side packers (numpy; pure layout, no device code) ----

def pack_nc1hwc0(x_nchw, c0: int = 16):
    """[N, C, H, W] -> [N*C1*H*W, C0] with zero channel tail."""
    import numpy as np
    x = np.asarray(x_nchw)
    n, c, h, w = x.shape
    c1 = -(-c // c0)
    xp = np.zeros((n, c1 * c0, h, w), x.dtype)
    xp[:, :c] = x
    return xp.reshape(n, c1, c0, h, w).transpose(0, 1, 3, 4, 2).reshape(n * c1 * h * w, c0).copy()


def pack_conv_weight(w_oihw, c0: int = 16):
    """[Cout, Cin, Kh, Kw] -> [Cout_p, K] ND (K order c1->kh->kw->c0, zero pads).

    Feed via `w_l1 <<= weight` (nd2nz): L1-NZ of [Cout, K] == mmad B's ZN.
    Never pack [K, N] ZN fractals — NZ/ZN block grids transpose (910B3 bisected).
    """
    import numpy as np
    w = np.asarray(w_oihw)
    cout, cin, kh, kw = w.shape
    c1 = -(-cin // c0)
    cout_p = (cout + 15) // 16 * 16
    wp = np.zeros((cout_p, c1 * c0, kh, kw), w.dtype)
    wp[:cout, :cin] = w
    return wp.reshape(cout_p, c1, c0, kh, kw).transpose(0, 1, 3, 4, 2).reshape(cout_p, c1 * kh * kw * c0).copy()
