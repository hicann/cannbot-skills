class EntireTypeValue:
    """Cache-line scope value class representing a concrete cache policy."""

    def __init__(self, name: str):
        self.name = name

    def __repr__(self):
        return f"EntireTypeValue('{self.name}')"

    def __str__(self):
        return self.name

    def __eq__(self, other):
        if self is other:
            return True
        if not isinstance(other, EntireTypeValue):
            raise TypeError(f"Cannot compare EntireTypeValue with {type(other)}")
        return self.name == other.name


class EntireType:
    """Cache-line scope enum-like class."""

    single = EntireTypeValue("SINGLE_CACHE_LINE")
    entire = EntireTypeValue("ENTIRE_DATA_CACHE")


class DcciDstType:
    """DCCI destination value class representing a concrete cache-line target."""

    def __init__(self, name: str):
        self.name = name

    def __repr__(self):
        return f"DcciDstType('{self.name}')"

    def __str__(self):
        return self.name

    def __eq__(self, other):
        if self is other:
            return True
        if not isinstance(other, DcciDstType):
            raise TypeError(f"Cannot compare DcciDstType with {type(other)}")
        return self.name == other.name


class DcciDst:
    """DCCI destination enum-like class."""

    all = DcciDstType("CACHELINE_ALL")
    ub = DcciDstType("CACHELINE_UB")
    out = DcciDstType("CACHELINE_OUT")
    atomic = DcciDstType("CACHELINE_ATOMIC")
