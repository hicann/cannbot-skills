from typing import Optional

from .. import globvars
from ..device_profile import is_a5_family, is_c220_family
from ..stub_functions.crosscore import (
    cube_ready,
    validate_crosscore_set_pipe,
    validate_crosscore_wait_pipe,
    vec_ready,
    wait_cube,
    wait_vec,
)
from .pipe import Pipe, PipeType


class CvMutex:
    def __init__(
        self,
        flag_id: int,
        depth: int = 2,
        src_start_pipe: PipeType = Pipe.S,
        dst_start_pipe: PipeType = Pipe.S,
        src_end_pipe: PipeType = Pipe.FIX,
        dst_end_pipe: Optional[PipeType] = None,
    ):
        validate_crosscore_wait_pipe("CvMutex src_start_pipe", src_start_pipe)
        validate_crosscore_wait_pipe("CvMutex dst_start_pipe", dst_start_pipe)
        validate_crosscore_set_pipe("CvMutex src_end_pipe", src_end_pipe, side="cube")
        self.flag_id = flag_id
        self.depth = depth
        self.src_start_pipe = src_start_pipe
        self.dst_start_pipe = dst_start_pipe
        self.src_end_pipe = src_end_pipe
        if dst_end_pipe is None:
            device_type = str(globvars.device_type).lower()
            if is_c220_family(device_type):
                dst_end_pipe = Pipe.MTE2
            elif is_a5_family(device_type):
                dst_end_pipe = Pipe.V
            else:
                dst_end_pipe = Pipe.MTE3
        validate_crosscore_set_pipe("CvMutex dst_end_pipe", dst_end_pipe, side="vec")
        self.dst_end_pipe = dst_end_pipe
        if globvars.active_kernel is not None:
            for mutex in globvars.active_kernel.crosscore_mutex:
                if getattr(mutex, "flag_id", None) == flag_id:
                    raise ValueError(f"crosscore_mutex already contains the same flag_id: {flag_id}")
            globvars.active_kernel.crosscore_mutex.append(self)

    def lock(self) -> None:
        wait_vec(self.flag_id, self.src_start_pipe)

    def ready(self) -> None:
        cube_ready(self.flag_id, self.src_end_pipe)

    def wait(self) -> None:
        wait_cube(self.flag_id, self.dst_start_pipe)

    def free(self) -> None:
        vec_ready(self.flag_id, self.dst_end_pipe)


class VcMutex:
    def __init__(
        self,
        flag_id: int,
        depth: int = 2,
        src_start_pipe: PipeType = Pipe.S,
        dst_start_pipe: PipeType = Pipe.S,
        src_end_pipe: PipeType = Pipe.MTE3,
        dst_end_pipe: PipeType = Pipe.FIX,
    ):
        validate_crosscore_wait_pipe("VcMutex src_start_pipe", src_start_pipe)
        validate_crosscore_wait_pipe("VcMutex dst_start_pipe", dst_start_pipe)
        validate_crosscore_set_pipe("VcMutex src_end_pipe", src_end_pipe, side="vec")
        validate_crosscore_set_pipe("VcMutex dst_end_pipe", dst_end_pipe, side="cube")
        self.flag_id = flag_id
        self.depth = depth
        self.src_start_pipe = src_start_pipe
        self.dst_start_pipe = dst_start_pipe
        self.src_end_pipe = src_end_pipe
        self.dst_end_pipe = dst_end_pipe
        if globvars.active_kernel is not None:
            for mutex in globvars.active_kernel.crosscore_mutex:
                if getattr(mutex, "flag_id", None) == flag_id:
                    raise ValueError(f"crosscore_mutex already contains the same flag_id: {flag_id}")
            globvars.active_kernel.crosscore_mutex.append(self)

    def lock(self) -> None:
        wait_cube(self.flag_id, self.src_start_pipe)

    def ready(self) -> None:
        vec_ready(self.flag_id, self.src_end_pipe)

    def wait(self) -> None:
        wait_vec(self.flag_id, self.dst_start_pipe)

    def free(self) -> None:
        cube_ready(self.flag_id, self.dst_end_pipe)
