from __future__ import annotations
from typing import TYPE_CHECKING, List, Optional, Sequence, Tuple, Union, cast
from .datatype import DataTypeValue, Datatype
from .var import Var
from .positions import Position, PositionType
from .layout import Layout, LayoutType, resolve_layout
from .pipe import Pipe, PipeType
from .naming import assert_codegen_safe_identifier
from .. import globvars
from ..device_profile import is_c220_family
from .instruction import Instruction

if TYPE_CHECKING:
    from .vecop import VecOP
    from .mutex import CvMutex, VcMutex
    from .reg import Reg, RegList
    from .regop import RegOP
    import torch


ShapeDim = Union[int, Var]
Shape2D = Sequence[ShapeDim]
ScalarIndex = Union[Var, int]
TensorIndex = Union[ScalarIndex, slice, Tuple[slice, ...]]
GMTensorDimIndex = Union[ScalarIndex, slice]
GMTensorIndex = Union[GMTensorDimIndex, Tuple[GMTensorDimIndex, ...]]
GMTensorListIndex = ScalarIndex


def _buffer_slot_key(index: ScalarIndex) -> str:
    if isinstance(index, Var):
        return f"var:{index.name}"
    return f"int:{index}"


def _copy_tensor_runtime_metadata(dst: "Tensor", src: object) -> None:
    logical_payload_shape = getattr(src, "_logical_payload_shape", None)
    if logical_payload_shape is None:
        src_span = getattr(src, "span", None)
        if isinstance(src_span, (list, tuple)) and len(src_span) >= 2:
            logical_payload_shape = [src_span[0], src_span[1]]
    if logical_payload_shape is not None:
        dst._logical_payload_shape = list(logical_payload_shape)
    elif hasattr(dst, "_logical_payload_shape"):
        delattr(dst, "_logical_payload_shape")


def _store_buffer_slot_metadata(view: "Tensor", src: object) -> None:
    _copy_tensor_runtime_metadata(view, src)
    source_buf = getattr(view, "source_buf", None)
    source_index = getattr(view, "source_index", None)
    if source_buf is None or source_index is None:
        return
    slot_meta = getattr(source_buf, "_slot_tensor_metadata", None)
    if slot_meta is None:
        slot_meta = {}
        source_buf._slot_tensor_metadata = slot_meta
    slot_meta[_buffer_slot_key(source_index)] = {
        "logical_payload_shape": getattr(view, "_logical_payload_shape", None),
    }


def _restore_buffer_slot_metadata(view: "Tensor", source_buf: object, source_index: ScalarIndex) -> None:
    slot_meta = getattr(source_buf, "_slot_tensor_metadata", None)
    if not isinstance(slot_meta, dict):
        return
    meta = slot_meta.get(_buffer_slot_key(source_index), None)
    if not isinstance(meta, dict):
        return
    logical_payload_shape = meta.get("logical_payload_shape", None)
    if logical_payload_shape is not None:
        view._logical_payload_shape = list(logical_payload_shape)


def _is_int4_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") == "int4"


def _is_fp4_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") in ("fp4x2_e2m1_t", "fp4x2_e1m2_t")


def _is_packed_compute_view_dtype(dtype: DataTypeValue) -> bool:
    return _is_int4_dtype(dtype) or _is_fp4_dtype(dtype)


def _ensure_not_packed_compute_view_dtype(dtype: DataTypeValue, owner: str) -> None:
    if _is_int4_dtype(dtype):
        raise ValueError(f"{owner} does not support DT.int4; use DT.int packed carrier tensors")
    if _is_fp4_dtype(dtype):
        raise ValueError(f"{owner} does not support {dtype}; use DT.uint8 packed carrier tensors")


def _l0c_store_has_requant_or_relu(scale, offset, hif8_hybrid, relu) -> bool:
    """True if an L0C store carries a fixpipe scalar requant or relu.

    Both ride on the fixpipe deqScalar/reluEn, which on an L0C->UB store are only available
    in the non-dual (SINGLE) mode -- so when either is set the ``<<=`` operator drives SINGLE and
    requires an explicit ``.subblk(0)``/``.subblk(1)`` (SINGLE writes only one vector subblock).
    """
    if relu or hif8_hybrid:
        return True
    if isinstance(scale, Var) or isinstance(offset, Var):
        return True
    scale_default = isinstance(scale, (int, float)) and not isinstance(scale, bool) and float(scale) == 1.0
    offset_default = isinstance(offset, int) and not isinstance(offset, bool) and int(offset) == 0
    return not (scale_default and offset_default)


class Tensor:
    """Tensor class."""
    def __init__(
        self,
        dtype: DataTypeValue,
        shape: Shape2D,
        position: PositionType = Position.L1,
        name: str = "",
        layout: LayoutType = Layout.DEFAULT,
    ):
        """
        Initialize a tensor.

        Args:
            dtype: Data type, must be DataTypeValue.
            shape: Shape, list/tuple with length 2.
            position: Position type, defaults to Position.L1.
            name: Name, defaults to empty string.
            layout: Buffer layout (Layout.NZ/ND); Layout.DEFAULT resolves per
                position (NZ for L1/L0A/L0B/L0C, ND for UB/BT).
        """
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        _ensure_not_packed_compute_view_dtype(dtype, "Tensor")
        
        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")
        
        if len(shape) != 2:
            raise ValueError(f"shape length must be 2, current length: {len(shape)}")
        
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")

        if not isinstance(position, PositionType):
            raise TypeError(f"position must be PositionType, got: {type(position)}")
        
        assert_codegen_safe_identifier(name, "Tensor")
        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        if name == "":
            name = f"_tmp_tensor_{idx}"

        self.dtype = dtype
        self.shape = shape
        self.name = name
        self.position = position
        self.idx = idx
        self.offset = [0 for _ in shape]
        self.span = list(shape)
        self.step = [1 for _ in shape]
        self.source_buf: Union[None, "DBuff", "TBuff", "QBuff"] = None
        self.source_index: Union[None, 'Var', int] = None
        self.storage_key_name = name
        self.is_transpose = False
        self._layout = resolve_layout(layout, position)
        self._is_relu = False
        self._deq_scale = 1.0
        self._deq_offset = 0
        self._deq_hif8_hybrid = False
        self._sub_block_id = None
        self.vec_copy_mode = ""

        target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
        if target is not None:
            target.instructions.append(
                Instruction("create_tensor", val=self, shape=list(self.shape))
            )

    def __repr__(self):
        return (
            f"Tensor(name={self.name!r}, dtype={self.dtype!r}, shape={self.shape!r}, "
            f"position={self.position!r}, idx={self.idx!r})"
        )

    def set_shape(self, shape: Shape2D) -> None:
        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")
        if len(shape) != 2:
            raise ValueError(f"shape length must be 2, current length: {len(shape)}")
        self.shape = list(shape)
        self.span = list(shape)

    @property
    def T(self) -> "Tensor":
        if self.position is Position.L0C:
            # l0c.T flags a transposed fixpipe store: `gm <<= l0c.T` -> l0c_to_gm_nz2dn
            # (NZ2DN / COLUMN_MAJOR). No data movement; the flag rides on the view.
            out = object.__new__(Tensor)
            out.__dict__ = self.__dict__.copy()
            out.is_transpose = True
            return out
        if self.position is not Position.L1:
            raise ValueError(f"Tensor position must be L1, current position: {self.position}")
        if _is_fp4_dtype(self.dtype) and hasattr(self, "_packed_view_carrier"):
            out = object.__new__(Tensor)
            out.__dict__ = self.__dict__.copy()
            out.is_transpose = True
            self._packed_view_consumed_by = "derived"
            root = getattr(self, "_packed_view_root", None)
            if isinstance(root, Tensor):
                root._packed_view_consumed_by = "derived"
                root._fp4_consumed_by = "derived"
            self._fp4_consumed_by = "derived"
            return out
        if _is_packed_compute_view_dtype(self.dtype) and hasattr(self, "_packed_view_carrier"):
            from ..stub_functions.misc import reinterpret
            self._packed_view_consumed_by = "derived"
            root = getattr(self, "_packed_view_root", None)
            if isinstance(root, Tensor):
                root._packed_view_consumed_by = "derived"
            if _is_int4_dtype(self.dtype):
                self._int4_consumed_by = "derived"
                if isinstance(root, Tensor):
                    root._int4_consumed_by = "derived"
            if _is_fp4_dtype(self.dtype):
                self._fp4_consumed_by = "derived"
                if isinstance(root, Tensor):
                    root._fp4_consumed_by = "derived"
            return reinterpret(self._packed_view_carrier.T, self.dtype)
        # Create a view without emitting create_tensor.
        out = object.__new__(Tensor)
        out.__dict__ = self.__dict__.copy()
        out.is_transpose = True
        return out

    def nz(self) -> "Tensor":
        out = object.__new__(Tensor)
        out.__dict__ = self.__dict__.copy()
        out._layout = Layout.NZ
        return out

    def nd(self) -> "Tensor":
        out = object.__new__(Tensor)
        out.__dict__ = self.__dict__.copy()
        out._layout = Layout.ND
        return out

    def reinterpret(self, target_dtype: DataTypeValue, name: str = "") -> "Tensor":
        from ..stub_functions.misc import reinterpret
        return reinterpret(self, target_dtype, name=name)

    def __ilshift__(self, other: Union["GMTensor", "Tensor", "VecOP", "Reg", "RegList", "RegOP"]) -> "Tensor":
        from .vecop import VecOP
        from .reg import Reg, RegList
        from .regop import RegOP
        if isinstance(other, VecOP):
            if self.position is not Position.UB:
                raise ValueError(f"VecOP only supports UB position, current position: {self.position}")
            other.emit(self)
            return self
        if isinstance(other, GMTensor):
            if getattr(other, "is_transpose", False):
                if self.position is Position.L1:
                    if self._layout is Layout.ND:
                        raise ValueError(
                            "GMTensor .T source is only supported for NZ-layout L1 destinations "
                            "(gm_to_l1_dn2nz) or ND-layout UB destinations (gm_to_ub_nd_dma)"
                        )
                    from ..stub_functions.cube import gm_to_l1_dn2nz
                    gm_to_l1_dn2nz(self, other)
                    return self
                if self.position is Position.UB:
                    if self._layout is Layout.NZ:
                        raise ValueError(
                            "GMTensor .T source to UB requires an ND-layout UB destination "
                            "(gm_to_ub_nd_dma)"
                        )
                    from ..stub_functions.vec.datamove import gm_to_ub_nd_dma_transpose
                    gm_to_ub_nd_dma_transpose(self, other)
                    return self
                raise ValueError(
                    "GMTensor .T source is only supported for NZ-layout L1 destinations "
                    "(gm_to_l1_dn2nz) or ND-layout UB destinations (gm_to_ub_nd_dma)"
                )
            if self.position is Position.UB:
                from ..stub_functions.vec.datamove import gm_to_ub_pad
                gm_to_ub_pad(self, other)
                return self
            if self.position is Position.L1:
                if self._layout is Layout.ND:
                    # Contiguous GM->L1. a5 has DataCopyPad (gm_to_l1_pad); C220 does
                    # not, so a2/a3 use the plain 32B-granular DataCopy burst (gm_to_l1).
                    # (globvars is imported at module scope.)
                    if is_c220_family(getattr(globvars, "device_type", "")):
                        from ..stub_functions.cube import gm_to_l1
                        gm_to_l1(self, other)
                    else:
                        from ..stub_functions.cube import gm_to_l1_pad
                        gm_to_l1_pad(self, other)
                else:
                    from ..stub_functions.cube import gm_to_l1_nd2nz
                    gm_to_l1_nd2nz(self, other)
                _store_buffer_slot_metadata(self, other)
                return self
            raise ValueError(f"Tensor position must be L1 or UB, current position: {self.position}")
        if isinstance(other, Tensor):
            if self.position is Position.UB and other.position is Position.UB:
                from ..stub_functions.vec.datamove import ub_to_ub
                ub_to_ub(self, other)
                return self
            if self.position is Position.L1 and other.position is Position.UB:
                if getattr(other, "_layout", Layout.ND) is Layout.NZ:
                    from ..stub_functions.vec.datamove import ub_to_l1_nz
                    ub_to_l1_nz(self, other)
                else:
                    from ..stub_functions.vec.datamove import ub_to_l1_nd2nz
                    ub_to_l1_nd2nz(self, other)
                return self
            if self.position is Position.L1 and other.position is Position.L0C:
                from ..stub_functions.cube import l0c_to_l1
                l0c_to_l1(self, other, relu=bool(getattr(other, "_is_relu", False)))
                return self
            if self.position is Position.UB and other.position is Position.L0C:
                from ..stub_functions.cube import l0c_to_ub
                relu = bool(getattr(other, "_is_relu", False))
                scale = getattr(other, "_deq_scale", 1.0)
                offset = getattr(other, "_deq_offset", 0)
                hif8_hybrid = bool(getattr(other, "_deq_hif8_hybrid", False))
                sub_block_id = getattr(other, "_sub_block_id", None)
                # requant/relu ride on the fixpipe deqScalar/reluEn, which are SINGLE-only, and a
                # SINGLE store writes exactly ONE vector subblock. There is no safe silent target --
                # defaulting to subblock 0 would drop the store meant for the other subblock -- so a
                # requant/relu rider MUST be paired with an explicit .subblk(0)/.subblk(1).
                if _l0c_store_has_requant_or_relu(scale, offset, hif8_hybrid, relu) and sub_block_id is None:
                    raise ValueError(
                        "L0C->UB store with a requant/relu rider is SINGLE-mode (one vector "
                        "subblock); pick the target explicitly with .subblk(0) or .subblk(1), e.g. "
                        "`ub <<= l0c.requant(scale=...).subblk(0)`. To fill both subblocks, issue "
                        "two stores -- one per subblock.")
                if sub_block_id is not None:
                    # an explicit subblk() (with or without a requant/relu rider) is a SINGLE store
                    # into that one subblock; a plain copy with no rider keeps the dual-lane default.
                    from .dualmode import DualMode
                    l0c_to_ub(self, other, dual_mode=DualMode.SINGLE, sub_block_id=sub_block_id,
                              relu=relu, scale=scale, offset=offset, hif8_hybrid=hif8_hybrid)
                else:
                    l0c_to_ub(self, other)
                return self
            if self.position is Position.BT and other.position is Position.L1:
                from ..stub_functions.cube import l1_to_bt
                l1_to_bt(self, other)
                return self
            if self.position not in (Position.L0A, Position.L0B):
                raise ValueError(f"Tensor position must be L0A or L0B, current position: {self.position}")
            new_shape = list(other.span) if hasattr(other, "span") else list(other.shape)
            self.set_shape(new_shape)
            _store_buffer_slot_metadata(self, other)
            from ..stub_functions.cube import l1_to_l0
            l1_to_l0(self, other)
            return self
        if isinstance(other, Reg):
            from ..stub_functions.micro.datamove import reg_to_ub_normal, reg_to_ub_pack4, reg_to_ub_downsample
            if self.dtype == other.dtype:
                reg_to_ub_normal(self, other)
            else:
                micro = globvars.active_micro
                if micro is None:
                    raise ValueError('Register related datamove must be called within vf')
                tmp = micro.get_reg(self.dtype)
                tmp <<= other.astype(self.dtype)
                if self.dtype.size==1 and other.dtype.size==4:
                    reg_to_ub_pack4(self, tmp)
                elif ((self.dtype.size==1 and other.dtype.size==2) or 
                      (self.dtype.size==2 and other.dtype.size==4)):
                    reg_to_ub_downsample(self, tmp)
                micro.release_reg(tmp)
            return self
        if isinstance(other, RegList):
            block = 256 // other.dtype.size
            for i in range(other.length):
                self[block * i] <<= other[i]
            return self
        if isinstance(other, RegOP):
            other.release_inputs()
            if other.opname in (
                "reg_to_ub",
                "reg_to_ub_continuous",
                "reg_to_ub_downsample",
                "reg_to_ub_pack4",
                "reg_to_ub_single",
                "reg_to_ub_scatter",
            ):
                other.emit(self)
                return self
            # reg_to_ub_downsample / reg_to_ub_pack4 / reg_to_ub_single RegOPs are already
            # handled by other.emit(self) in the opname tuple above; the only opnames that
            # reach here are "vcopy" and arbitrary compute RegOPs (run_regop + a plain store).
            from ..stub_functions.micro.datamove import reg_to_ub_normal
            if other.opname == "vcopy":
                src = other.inputs[0]
                if not isinstance(src, Reg):
                    raise TypeError(f"src must be Reg, got: {type(src)}")
                reg_to_ub_normal(self, src, mask=other.mask)
                return self
            tmp = other.run_regop()
            reg_to_ub_normal(self, tmp)
            micro = globvars.active_micro
            if micro is not None and tmp.name.startswith("_tmp_reg_"):
                micro.release_reg(tmp)
            return self
        raise TypeError(f"other must be GMTensor/Tensor/VecOP/Reg/RegList/RegOP, got: {type(other)}")

    def _vecop(self, op: str, other: object = None) -> "VecOP":
        if self.position is not Position.UB:
            raise ValueError(f"VecOP only supports UB position, current position: {self.position}")
        from .vecop import VecOP
        return VecOP(op, self, other)  # type: ignore[arg-type]

    def _with_vec_copy_mode(self, mode: str) -> "Tensor":
        out = object.__new__(Tensor)
        out.__dict__ = self.__dict__.copy()
        out.vec_copy_mode = mode
        return out

    def downsample(self) -> "Tensor":
        return self._with_vec_copy_mode("downsample")

    def upsample(self) -> "Tensor":
        return self._with_vec_copy_mode("upsample")

    def unpack(self) -> "Tensor":
        return self._with_vec_copy_mode("unpack")

    def unpack4(self) -> "Tensor":
        return self._with_vec_copy_mode("unpack4")

    def brcb(self) -> "Tensor":
        return self._with_vec_copy_mode("brcb")

    def single(self) -> "Tensor":
        return self._with_vec_copy_mode("single")

    def __add__(self, other):
        if isinstance(other, Tensor):
            return self._vecop("add", other)
        if isinstance(other, (int, float, Var)):
            return self._vecop("adds", other)
        return NotImplemented

    def __radd__(self, other):
        if isinstance(other, (int, float, Var)):
            return self._vecop("adds", other)
        return NotImplemented

    def __sub__(self, other):
        if isinstance(other, Tensor):
            return self._vecop("sub", other)
        if isinstance(other, (int, float)):
            return self._vecop("adds", -other)
        return NotImplemented

    def __rsub__(self, other):
        return NotImplemented

    def __mul__(self, other):
        if isinstance(other, Tensor):
            return self._vecop("mul", other)
        if isinstance(other, (int, float, Var)):
            return self._vecop("muls", other)
        return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, (int, float, Var)):
            return self._vecop("muls", other)
        return NotImplemented

    def __truediv__(self, other):
        if isinstance(other, Tensor):
            return self._vecop("div", other)
        if isinstance(other, (int, float)):
            if other == 0:
                raise ZeroDivisionError("Tensor scalar divide by zero")
            return self._vecop("muls", 1.0 / other)
        if isinstance(other, Var):
            from .datatype import Datatype

            if other.dtype is Datatype.float:
                return self._vecop("muls", 1.0 / other)
            if other.dtype is Datatype.int:
                other_float = Var(0.0)
                other_float <<= other
                return self._vecop("muls", 1.0 / other_float)
            raise TypeError(f"Tensor division only supports int/float Var scalar, got dtype: {other.dtype}")
        return NotImplemented

    def __rtruediv__(self, other):
        return NotImplemented

    def exp(self):
        return self._vecop("exp")

    def ln(self):
        return self._vecop("ln")

    def abs(self):
        return self._vecop("abs")

    def rec(self):
        return self._vecop("rec")

    def sqrt(self):
        return self._vecop("sqrt")

    def rsqrt(self):
        return self._vecop("rsqrt")

    def vnot(self):
        return self._vecop("vnot")

    def relu(self):
        if self.position is Position.L0C:
            out = object.__new__(Tensor)
            out.__dict__ = self.__dict__.copy()
            out._is_relu = True
            return out
        return self._vecop("relu")

    def requant(self, scale=1.0, offset=0, hif8_hybrid=False):
        """Tag an L0C tensor with a fixpipe scalar quant for the next store to GM or UB.

        The dst dtype selects the mode + signedness (int8->signed, uint8->unsigned,
        fp16<-int32 dequant, fp8 e4m3, hif8); ``scale``/``offset`` feed the deqScalar and
        may each be a Python constant or a ``Var``. ``hif8_hybrid`` selects the hybrid
        rounding (QF322HIF8_PRE_HYBRID) over the default half-to-away for a hif8 dst.
        Rides on the tensor like ``relu()``; apply it last, e.g. a GM store
        ``gm[...] <<= l0c.requant(scale=0.5, offset=10)``. On an L0C->UB store a requant rider is
        single-lane only (SINGLE), so it MUST be paired with an explicit ``.subblk(0)``/``.subblk(1)``
        to pick the target vector subblock, e.g. ``ub <<= l0c.requant(scale=0.5).subblk(0)`` -- there
        is no silent default (that would drop the store for the other subblock).
        """
        if self.position is not Position.L0C:
            raise ValueError(f"requant is only valid on an L0C tensor, current position: {self.position}")
        if not isinstance(hif8_hybrid, bool):
            raise TypeError(f"hif8_hybrid must be bool type, current type: {type(hif8_hybrid)}")
        out = object.__new__(Tensor)
        out.__dict__ = self.__dict__.copy()
        out._deq_scale = scale
        out._deq_offset = offset
        out._deq_hif8_hybrid = hif8_hybrid
        return out

    def subblk(self, sub_block_id):
        """Tag an L0C tensor to publish to ONE vector subblock on the next L0C->UB store.

        A subblock-targeted store is single-lane, so this forces ``dual_mode=SINGLE`` on the
        ``<<=`` operator (like ``requant()``/``relu()``) and composes with them. Issue two
        stores -- ``ub <<= l0c[0:R].subblk(0)`` then ``ub <<= l0c[R:2R].subblk(1)`` -- to fill
        both vec subblocks from the matching L0C row-slices (the plain ``ub <<= l0c`` SPLITM
        path auto-splits the rows but only carries a same-type copy, no cast/quant). Rides on
        the tensor like ``requant()``; ``sub_block_id`` is 0 or 1 (or a ``Var``). L0C-only.
        """
        if self.position is not Position.L0C:
            raise ValueError(f"subblk is only valid on an L0C tensor, current position: {self.position}")
        if isinstance(sub_block_id, bool) or not isinstance(sub_block_id, (int, Var)):
            raise TypeError(f"sub_block_id must be int or Var type, current type: {type(sub_block_id)}")
        if isinstance(sub_block_id, int) and sub_block_id not in (0, 1):
            raise ValueError(f"sub_block_id must be 0 or 1, current value: {sub_block_id}")
        out = object.__new__(Tensor)
        out.__dict__ = self.__dict__.copy()
        out._sub_block_id = sub_block_id
        return out

    def cmax(self):
        return self._vecop("cmax")

    def cgmax(self):
        return self._vecop("cgmax")

    def cmin(self):
        return self._vecop("cmin")

    def cgmin(self):
        return self._vecop("cgmin")

    def cadd(self):
        return self._vecop("cadd")

    def cgadd(self):
        return self._vecop("cgadd")

    def cpadd(self):
        return self._vecop("cpadd")

    def cast(self):
        return self._vecop("cast")

    def maximum(self, other):
        if isinstance(other, Tensor):
            return self._vecop("max", other)
        if isinstance(other, (int, float, Var)):
            return self._vecop("maxs", other)
        return NotImplemented

    def minimum(self, other):
        if isinstance(other, Tensor):
            return self._vecop("min", other)
        if isinstance(other, (int, float, Var)):
            return self._vecop("mins", other)
        return NotImplemented

    def __and__(self, other):
        if isinstance(other, Tensor):
            return self._vecop("and", other)
        return NotImplemented

    def __rand__(self, other):
        return NotImplemented

    def __or__(self, other):
        if isinstance(other, Tensor):
            return self._vecop("or", other)
        return NotImplemented

    def __ror__(self, other):
        return NotImplemented

    def __setitem__(self, *args, **kwargs):
        ...

    def __getitem__(self, index: TensorIndex) -> "Tensor":
        scalar_last_dim_offset: Optional[ScalarIndex] = None
        if isinstance(index, (Var, int)):
            scalar_last_dim_offset = index
            normalized_index: Tuple[slice, ...] = tuple(
                slice(None, None, None) for _ in self.shape
            )
        elif isinstance(index, slice):
            normalized_index = (index,)
        elif isinstance(index, tuple):
            normalized_index = index
        else:
            raise TypeError(f"Invalid index type: {type(index)}")
        if len(normalized_index) != len(self.shape):
            raise TypeError(f"Tensor index dimensions must match shape, current length: {len(normalized_index)}")

        def _parse_dim(dim_index: slice, dim_size: ShapeDim, label: str) -> Tuple[ShapeDim, ShapeDim, int]:
            if not isinstance(dim_index, slice):
                raise TypeError(f"{label} index must be slice, got: {type(dim_index)}")

            start: ShapeDim = dim_index.start if dim_index.start is not None else 0
            stop: ShapeDim = dim_index.stop if dim_index.stop is not None else dim_size
            step = dim_index.step

            if not isinstance(start, (Var, int)):
                raise TypeError(f"{label} start must be Var or int, got: {type(start)}")
            if not isinstance(stop, (Var, int)):
                raise TypeError(f"{label} stop must be Var or int, got: {type(stop)}")
            if step is not None and step != 1:
                raise ValueError("slice step must be None or 1")

            span = cast(ShapeDim, stop - start)
            return start, span, 1

        relative_offsets: List[ShapeDim] = []
        spans: List[ShapeDim] = []
        steps: List[int] = []
        for dim_idx, dim_index in enumerate(normalized_index):
            dim_size = self.span[dim_idx] if hasattr(self, "span") else self.shape[dim_idx]
            off, span, step = _parse_dim(dim_index, dim_size, f"dim{dim_idx}")
            relative_offsets.append(off)
            spans.append(span)
            steps.append(step)
        if scalar_last_dim_offset is not None:
            relative_offsets[-1] = scalar_last_dim_offset

        base_offsets = list(self.offset) if hasattr(self, "offset") else [0 for _ in self.shape]
        accumulated_offsets: List[ShapeDim] = []
        for dim_idx, rel_off in enumerate(relative_offsets):
            base_off = base_offsets[dim_idx]
            if isinstance(base_off, int) and isinstance(rel_off, int):
                accumulated_offsets.append(base_off + rel_off)
            else:
                accumulated_offsets.append(cast(ShapeDim, base_off + rel_off))

        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        name = f"_tmp_tensor_{idx}"
        out = object.__new__(Tensor)
        out.dtype = self.dtype
        out.shape = list(self.shape)
        out.name = name
        out.position = self.position
        out.idx = idx
        out.offset = accumulated_offsets
        out.span = spans
        out.step = steps
        out.source_buf = self.source_buf
        out.source_index = self.source_index
        out.storage_key_name = getattr(self, "storage_key_name", self.name)
        out.is_transpose = self.is_transpose
        out._layout = self._layout
        out._is_relu = getattr(self, "_is_relu", False)
        out._deq_scale = getattr(self, "_deq_scale", 1.0)
        out._deq_offset = getattr(self, "_deq_offset", 0)
        out._deq_hif8_hybrid = getattr(self, "_deq_hif8_hybrid", False)
        out._sub_block_id = getattr(self, "_sub_block_id", None)
        for attr in (
            "_logical_payload_shape",
            "_packed_view_carrier",
            "_packed_view_carrier_shape",
            "_packed_view_carrier_span",
            "_packed_view_axis",
            "_packed_view_root",
            "_packed_view_consumed_by",
            "_int4_carrier",
            "_int4_carrier_shape",
            "_int4_carrier_span",
            "_int4_consumed_by",
            "_fp4_carrier",
            "_fp4_carrier_shape",
            "_fp4_carrier_span",
            "_fp4_consumed_by",
        ):
            if hasattr(self, attr):
                setattr(out, attr, getattr(self, attr))
        target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
        if target is not None:
            opname = "micro_slice_tensor" if globvars.active_micro is not None else "slice_tensor"
            target.instructions.append(
                Instruction(
                    opname,
                    src=self,
                    out=out,
                    offset=relative_offsets,
                    span=spans,
                    step=steps,
                )
            )
        return out


class DBuff:
    """Data buffer class (double buffer composed of two Tensors)."""
    def __init__(
        self,
        dtype: DataTypeValue,
        shape: Shape2D,
        position: PositionType = Position.L1,
        name: str = "",
        layout: LayoutType = Layout.DEFAULT,
    ):
        """
        Initialize a data buffer.

        Args:
            dtype: Data type, must be DataTypeValue.
            shape: Shape, list/tuple with length 2.
            position: Position type, defaults to Position.L1.
            name: Name, defaults to empty string.
            layout: Layout hint (Layout.DEFAULT/NZ/ND); DEFAULT resolves to NZ
                for L1/L0A/L0B/L0C and ND for UB/BT.
        """
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        _ensure_not_packed_compute_view_dtype(dtype, "DBuff")
        
        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")
        
        if len(shape) != 2:
            raise ValueError(f"shape length must be 2, current length: {len(shape)}")
        
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")

        if not isinstance(position, PositionType):
            raise TypeError(f"position must be PositionType, got: {type(position)}")
        
        assert_codegen_safe_identifier(name, "DBuff")
        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        if name == "":
            name = f"_tmp_dbuf_{idx}"

        self.dtype = dtype
        self.shape = shape
        self.name = name
        self.position = position
        self.idx = idx
        self._layout = resolve_layout(layout, position)

        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("create_dbuf", val=self, shape=list(self.shape))
            )

    def __repr__(self):
        return (
            f"DBuff(name={self.name!r}, dtype={self.dtype!r}, shape={self.shape!r}, "
            f"position={self.position!r}, idx={self.idx!r})"
        )

    def set_shape(self, shape: Shape2D) -> None:
        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")
        if len(shape) != 2:
            raise ValueError(f"shape length must be 2, current length: {len(shape)}")
        self.shape = list(shape)

    # DBuff represents a double buffer of two Tensors; indexing returns one Tensor view.
    def __getitem__(self, index: ScalarIndex) -> "Tensor":
        if not isinstance(index, (Var, int)):
            raise TypeError(f"index must be Var or int, got: {type(index)}")

        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        name = f"_tmp_tensor_{idx}"
        out = object.__new__(Tensor)
        out.dtype = self.dtype
        out.shape = list(self.shape)
        out.name = name
        out.position = self.position
        out.idx = idx
        out.offset = [0 for _ in out.shape]
        out.span = list(out.shape)
        out.step = [1 for _ in out.shape]
        out.source_buf = None
        out.source_index = None
        out.storage_key_name = name
        out.is_transpose = False
        out._layout = self._layout
        out._is_relu = False
        out.source_buf = self
        out.source_index = index
        out.storage_key_name = self.name
        _restore_buffer_slot_metadata(out, self, index)
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("get_buf", buf=self, index=index, out=out)
            )
        return out

    def __setitem__(self, index: ScalarIndex, value: "Tensor") -> None:
        if not isinstance(index, (Var, int)):
            raise TypeError(f"index must be Var or int, got: {type(index)}")
        if not isinstance(value, Tensor):
            raise TypeError(f"value must be Tensor, got: {type(value)}")


class TBuff:
    """Data buffer class (triple buffer composed of three Tensors)."""
    def __init__(
        self,
        dtype: DataTypeValue,
        shape: Shape2D,
        position: PositionType = Position.L1,
        name: str = "",
        layout: LayoutType = Layout.DEFAULT,
    ):
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        _ensure_not_packed_compute_view_dtype(dtype, "TBuff")

        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")

        if len(shape) != 2:
            raise ValueError(f"shape length must be 2, current length: {len(shape)}")

        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")

        if not isinstance(position, PositionType):
            raise TypeError(f"position must be PositionType, got: {type(position)}")

        assert_codegen_safe_identifier(name, "TBuff")
        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        if name == "":
            name = f"_tmp_tbuf_{idx}"

        self.dtype = dtype
        self.shape = shape
        self.name = name
        self.position = position
        self.idx = idx
        self._layout = resolve_layout(layout, position)

        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("create_tbuf", val=self, shape=list(self.shape))
            )

    def __repr__(self):
        return (
            f"TBuff(name={self.name!r}, dtype={self.dtype!r}, shape={self.shape!r}, "
            f"position={self.position!r}, idx={self.idx!r})"
        )

    def set_shape(self, shape: Shape2D) -> None:
        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")
        if len(shape) != 2:
            raise ValueError(f"shape length must be 2, current length: {len(shape)}")
        self.shape = list(shape)

    def __getitem__(self, index: ScalarIndex) -> "Tensor":
        if not isinstance(index, (Var, int)):
            raise TypeError(f"index must be Var or int, got: {type(index)}")

        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        name = f"_tmp_tensor_{idx}"
        out = object.__new__(Tensor)
        out.dtype = self.dtype
        out.shape = list(self.shape)
        out.name = name
        out.position = self.position
        out.idx = idx
        out.offset = [0 for _ in out.shape]
        out.span = list(out.shape)
        out.step = [1 for _ in out.shape]
        out.source_buf = None
        out.source_index = None
        out.storage_key_name = name
        out.is_transpose = False
        out._layout = self._layout
        out._is_relu = False
        out.source_buf = self
        out.source_index = index
        out.storage_key_name = self.name
        _restore_buffer_slot_metadata(out, self, index)
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("get_buf", buf=self, index=index, out=out)
            )
        return out

    def __setitem__(self, index: ScalarIndex, value: "Tensor") -> None:
        if not isinstance(index, (Var, int)):
            raise TypeError(f"index must be Var or int, got: {type(index)}")
        if not isinstance(value, Tensor):
            raise TypeError(f"value must be Tensor, got: {type(value)}")


class QBuff:
    """Data buffer class (quad buffer composed of four Tensors)."""
    def __init__(
        self,
        dtype: DataTypeValue,
        shape: Shape2D,
        position: PositionType = Position.L1,
        name: str = "",
        layout: LayoutType = Layout.DEFAULT,
    ):
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        _ensure_not_packed_compute_view_dtype(dtype, "QBuff")

        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")

        if len(shape) != 2:
            raise ValueError(f"shape length must be 2, current length: {len(shape)}")

        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")

        if not isinstance(position, PositionType):
            raise TypeError(f"position must be PositionType, got: {type(position)}")

        assert_codegen_safe_identifier(name, "QBuff")
        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        if name == "":
            name = f"_tmp_qbuf_{idx}"

        self.dtype = dtype
        self.shape = shape
        self.name = name
        self.position = position
        self.idx = idx
        self._layout = resolve_layout(layout, position)
        self.slot_count = 4

        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("create_qbuf", val=self, shape=list(self.shape))
            )

    def __repr__(self):
        return (
            f"QBuff(name={self.name!r}, dtype={self.dtype!r}, shape={self.shape!r}, "
            f"position={self.position!r}, idx={self.idx!r})"
        )

    def set_shape(self, shape: Shape2D) -> None:
        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")
        if len(shape) != 2:
            raise ValueError(f"shape length must be 2, current length: {len(shape)}")
        self.shape = list(shape)

    def __getitem__(self, index: ScalarIndex) -> "Tensor":
        if not isinstance(index, (Var, int)):
            raise TypeError(f"index must be Var or int, got: {type(index)}")

        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        name = f"_tmp_tensor_{idx}"
        out = object.__new__(Tensor)
        out.dtype = self.dtype
        out.shape = list(self.shape)
        out.name = name
        out.position = self.position
        out.idx = idx
        out.offset = [0 for _ in out.shape]
        out.span = list(out.shape)
        out.step = [1 for _ in out.shape]
        out.source_buf = None
        out.source_index = None
        out.storage_key_name = name
        out.is_transpose = False
        out._layout = self._layout
        out._is_relu = False
        out.source_buf = self
        out.source_index = index
        out.storage_key_name = self.name
        _restore_buffer_slot_metadata(out, self, index)
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("get_buf", buf=self, index=index, out=out)
            )
        return out

    def __setitem__(self, index: ScalarIndex, value: "Tensor") -> None:
        if not isinstance(index, (Var, int)):
            raise TypeError(f"index must be Var or int, got: {type(index)}")
        if not isinstance(value, Tensor):
            raise TypeError(f"value must be Tensor, got: {type(value)}")


class GMTensor:
    """Global-memory tensor class."""
    def __init__(self, dtype: DataTypeValue, shape: Shape2D, name: str = ""):
        """
        Initialize a global-memory tensor.

        Args:
            dtype: Data type, must be DataTypeValue.
            shape: Shape, list/tuple with length 2.
            name: Name, defaults to empty string.
        """
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        _ensure_not_packed_compute_view_dtype(dtype, "GMTensor")
        
        if not isinstance(shape, (list, tuple)):
            raise TypeError(f"shape must be list/tuple, got: {type(shape)}")
        
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")
        
        assert_codegen_safe_identifier(name, "GMTensor")
        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        if name == "":
            name = f"_tmp_gmtensor_{idx}"

        self.dtype = dtype
        self.shape = shape
        self.name = name
        self.idx = idx
        self.offset = [0 for _ in shape]
        self.span = list(shape)
        self.step = [1 for _ in shape]
        self.slice_mask = [False for _ in shape]
        self._mutex: Optional[Union["CvMutex", "VcMutex"]] = None
        self.data: Optional["torch.Tensor"] = None
        
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("create_gm_tensor", val=self)
            )

    def __repr__(self):
        return (
            f"GMTensor(name={self.name!r}, dtype={self.dtype!r}, shape={self.shape!r}, "
            f"idx={self.idx!r})"
        )

    def reinterpret(self, target_dtype: DataTypeValue, name: str = "") -> "GMTensor":
        """Relabel this GM buffer as another same-byte-width dtype, sharing the buffer (no
        data movement). Mainly: view a uint8 GM carrier as hif8 for a fixpipe hif8 store,
        since torch has no hif8 dtype to bind a native hif8 GMTensor (see ReinterpretCast)."""
        if not isinstance(target_dtype, DataTypeValue):
            raise TypeError(f"target_dtype must be DataTypeValue, got: {type(target_dtype)}")
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")
        if getattr(self, "is_transpose", False):
            raise ValueError("cannot reinterpret a transposed GMTensor view; reinterpret first, then .T")
        assert_codegen_safe_identifier(name, "reinterpret view")
        if target_dtype.size != self.dtype.size:
            raise ValueError(
                f"GMTensor.reinterpret only supports a same-byte-width relabel "
                f"({self.dtype} is {self.dtype.size}B, {target_dtype} is {target_dtype.size}B)")
        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        if name == "":
            name = f"_tmp_gmtensor_{idx}"
        out = object.__new__(GMTensor)
        out.dtype = target_dtype
        out.shape = list(self.shape)
        out.name = name
        out.idx = idx
        out.offset = list(self.offset)
        out.span = list(self.span)
        out.step = list(self.step)
        out.slice_mask = list(self.slice_mask)
        out._mutex = self._mutex
        out.data = self.data
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("reinterpret", dst=out, src=self,
                            dst_shape=list(out.shape), dst_span=list(out.span),
                            packed_view_axis=None)
            )
        return out

    def is_plain_view(self) -> bool:
        offset = getattr(self, "offset", None)
        step = getattr(self, "step", None)
        slice_mask = getattr(self, "slice_mask", None)
        if not isinstance(offset, (list, tuple)) or not isinstance(step, (list, tuple)):
            return False
        if not isinstance(slice_mask, (list, tuple)):
            return False
        return all(v == 0 for v in offset) and all(v == 1 for v in step) and not any(slice_mask)

    @property
    def T(self) -> "GMTensor":
        """Transposed view: `l1 <<= gm.T` loads via gm_to_l1_dn2nz (a5 MTE2 on-the-fly
        transpose). No data movement; slice first, then transpose (`gm[a:b, c:d].T`).

        The flag is set on the already-tracked slice object (the user's
        ``gm[a:b, c:d]`` slice, or a fresh ``gm[:, :]`` for a bare tensor) so the
        dn2nz source and its ``slice_gm_tensor`` definition share one identity —
        pruning keeps it and the slice's row/col offset is preserved."""
        if len(self.shape) != 2:
            raise ValueError(f"GMTensor.T requires a 2D tensor, got shape: {self.shape}")
        if getattr(self, "is_transpose", False):
            out = object.__new__(GMTensor)
            out.__dict__ = self.__dict__.copy()
            out.is_transpose = False
            return out
        base = self if any(self.slice_mask) else self[:, :]
        base.is_transpose = True
        return base

    def reshape(self, shape: Sequence[ShapeDim], name: str = "") -> "GMTensor":
        if getattr(self, "is_transpose", False):
            raise ValueError("cannot reshape a transposed GMTensor view; reshape first, then .T")
        from ..stub_functions.misc import reshape_gm_tensor
        return reshape_gm_tensor(self, shape, name=name) # type: ignore

    def flatten(self, start_dim: int = 0, end_dim: int = -1, name: str = "") -> "GMTensor":
        if not isinstance(start_dim, int):
            raise TypeError(f"start_dim must be int, got: {type(start_dim)}")
        if not isinstance(end_dim, int):
            raise TypeError(f"end_dim must be int, got: {type(end_dim)}")

        shape = list(self.shape)
        ndim = len(shape)
        if ndim == 0:
            raise ValueError("GMTensor.flatten requires rank >= 1")

        if start_dim < 0:
            start_dim += ndim
        if end_dim < 0:
            end_dim += ndim

        if start_dim < 0 or start_dim >= ndim:
            raise ValueError(f"start_dim out of range for rank {ndim}: {start_dim}")
        if end_dim < 0 or end_dim >= ndim:
            raise ValueError(f"end_dim out of range for rank {ndim}: {end_dim}")
        if start_dim > end_dim:
            raise ValueError(f"start_dim must be <= end_dim, got: {start_dim} > {end_dim}")

        merged: ShapeDim = 1
        for dim in shape[start_dim : end_dim + 1]:
            merged = merged * dim
        new_shape = list(shape[:start_dim]) + [merged] + list(shape[end_dim + 1 :])
        return self.reshape(new_shape, name=name)

    def bind_cv_mutex(
        self,
        flag_id: int,
        depth: int = 2,
        src_start_pipe: PipeType = Pipe.S,
        dst_start_pipe: PipeType = Pipe.S,
        src_end_pipe: PipeType = Pipe.FIX,
        dst_end_pipe: Optional[PipeType] = None,
    ) -> "CvMutex":
        from .mutex import CvMutex

        mutex = CvMutex(
            flag_id,
            depth,
            src_start_pipe=src_start_pipe,
            dst_start_pipe=dst_start_pipe,
            src_end_pipe=src_end_pipe,
            dst_end_pipe=dst_end_pipe,
        )
        self._mutex = mutex
        return mutex

    def bind_vc_mutex(
        self,
        flag_id: int,
        depth: int = 2,
        src_start_pipe: PipeType = Pipe.S,
        dst_start_pipe: PipeType = Pipe.S,
        src_end_pipe: PipeType = Pipe.MTE3,
        dst_end_pipe: PipeType = Pipe.FIX,
    ) -> "VcMutex":
        from .mutex import VcMutex

        mutex = VcMutex(
            flag_id,
            depth,
            src_start_pipe=src_start_pipe,
            dst_start_pipe=dst_start_pipe,
            src_end_pipe=src_end_pipe,
            dst_end_pipe=dst_end_pipe,
        )
        self._mutex = mutex
        return mutex

    def lock(self) -> None:
        if self._mutex is None:
            raise ValueError("GMTensor has not bound a mutex yet")
        from .mutex import CvMutex, VcMutex
        if not isinstance(self._mutex, (CvMutex, VcMutex)):
            raise TypeError(f"GMTensor has invalid mutex type: {type(self._mutex)}")
        self._mutex.lock()

    def ready(self) -> None:
        if self._mutex is None:
            raise ValueError("GMTensor has not bound a mutex yet")
        from .mutex import CvMutex, VcMutex
        if not isinstance(self._mutex, (CvMutex, VcMutex)):
            raise TypeError(f"GMTensor has invalid mutex type: {type(self._mutex)}")
        self._mutex.ready()

    def wait(self) -> None:
        if self._mutex is None:
            raise ValueError("GMTensor has not bound a mutex yet")
        from .mutex import CvMutex, VcMutex
        if not isinstance(self._mutex, (CvMutex, VcMutex)):
            raise TypeError(f"GMTensor has invalid mutex type: {type(self._mutex)}")
        self._mutex.wait()

    def free(self) -> None:
        if self._mutex is None:
            raise ValueError("GMTensor has not bound a mutex yet")
        from .mutex import CvMutex, VcMutex
        if not isinstance(self._mutex, (CvMutex, VcMutex)):
            raise TypeError(f"GMTensor has invalid mutex type: {type(self._mutex)}")
        self._mutex.free()

    def __ilshift__(self, other: "Tensor") -> "GMTensor":
        if getattr(self, "is_transpose", False):
            raise ValueError("a transposed GMTensor view cannot be a store destination")
        if isinstance(other, Tensor):
            if other.position is Position.UB:
                from ..stub_functions.vec.datamove import ub_to_gm_pad
                ub_to_gm_pad(self, other)
                return self
            if other.position is Position.L0C:
                if getattr(other, "is_transpose", False):
                    # `gm <<= l0c.T` -> transposed NZ2DN store (dst is the [n, m] plane).
                    from ..stub_functions.cube import l0c_to_gm_nz2dn
                    l0c_to_gm_nz2dn(self, other, relu=bool(getattr(other, "_is_relu", False)),
                                    scale=getattr(other, "_deq_scale", 1.0),
                                    offset=getattr(other, "_deq_offset", 0),
                                    hif8_hybrid=getattr(other, "_deq_hif8_hybrid", False))
                    return self
                from ..stub_functions.cube import l0c_to_gm_nz2nd
                l0c_to_gm_nz2nd(self, other, relu=bool(getattr(other, "_is_relu", False)),
                                scale=getattr(other, "_deq_scale", 1.0),
                                offset=getattr(other, "_deq_offset", 0),
                                hif8_hybrid=getattr(other, "_deq_hif8_hybrid", False))
                return self
            raise ValueError(f"Tensor position must be L0C or UB, current position: {other.position}")
        raise TypeError(f"other must be Tensor, got: {type(other)}")

    def __getitem__(self, index: GMTensorIndex) -> "GMTensor":
        if getattr(self, "is_transpose", False):
            raise ValueError("cannot slice a transposed GMTensor view; slice first, then .T")
        if isinstance(index, tuple):
            normalized_index = index
        else:
            normalized_index = (index,)
        if len(normalized_index) != len(self.shape):
            raise TypeError(f"GMTensor index dimensions must match shape, current length: {len(normalized_index)}")

        def _parse_dim(dim_index: GMTensorDimIndex, dim_size: ShapeDim, label: str) -> Tuple[ShapeDim, ShapeDim, int]:
            if isinstance(dim_index, (Var, int)):
                return dim_index, 1, 1
            if not isinstance(dim_index, slice):
                raise TypeError(f"{label} index must be Var, int, or slice, got: {type(dim_index)}")

            start: ShapeDim = dim_index.start if dim_index.start is not None else 0
            stop: ShapeDim = dim_index.stop if dim_index.stop is not None else dim_size
            step = dim_index.step

            if not isinstance(start, (Var, int)):
                raise TypeError(f"{label} start must be Var or int, got: {type(start)}")
            if not isinstance(stop, (Var, int)):
                raise TypeError(f"{label} stop must be Var or int, got: {type(stop)}")
            if step is not None and step != 1:
                raise ValueError("slice step must be None or 1")

            span = cast(ShapeDim, stop - start)
            return start, span, 1

        slice_count = 0
        offsets: List[ShapeDim] = []
        spans: List[ShapeDim] = []
        steps: List[int] = []
        slice_mask: List[bool] = []
        for dim_idx, dim_index in enumerate(normalized_index):
            dim_size = self.span[dim_idx] if hasattr(self, "span") else self.shape[dim_idx]
            is_slice = isinstance(dim_index, slice)
            if is_slice:
                slice_count += 1
                if slice_count > 2:
                    raise TypeError("GMTensor cannot have slices on more than 2 dimensions")
            off, span, step = _parse_dim(dim_index, dim_size, f"dim{dim_idx}")
            offsets.append(off)
            spans.append(span)
            steps.append(step)
            slice_mask.append(is_slice)

        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        name = f"_tmp_gmtensor_{idx}"
        out = object.__new__(GMTensor)
        out.dtype = self.dtype
        out.shape = list(self.shape)
        out.name = name
        out.idx = idx
        out.offset = offsets
        out.span = spans
        out.step = steps
        out.slice_mask = slice_mask
        out._mutex = getattr(self, "_mutex", None)
        out.data = getattr(self, "data", None)
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction(
                    "slice_gm_tensor",
                    src=self,
                    out=out,
                    offset=offsets,
                    span=spans,
                    step=steps,
                    slice_mask=slice_mask,
                )
            )
        return out

    def __setitem__(self, index: GMTensorIndex, value: object) -> None:
        if isinstance(value, Tensor):
            if value.position is not Position.L0C:
                raise ValueError(f"Tensor position must be L0C, current position: {value.position}")
            dst = self.__getitem__(index)
            from ..stub_functions.cube import l0c_to_gm_nz2nd
            l0c_to_gm_nz2nd(dst, value, relu=bool(getattr(value, "_is_relu", False)),
                            scale=getattr(value, "_deq_scale", 1.0),
                            offset=getattr(value, "_deq_offset", 0),
                            hif8_hybrid=getattr(value, "_deq_hif8_hybrid", False))
            return
        if isinstance(value, GMTensor):
            return
        raise TypeError(f"value must be Tensor or GMTensor, got: {type(value)}")


class GMTensorList:
    """Global-memory tensor-list parameter.

    Homogeneous lists are supported: every member has the same dtype and rank,
    while concrete dimension sizes may differ between members. ``item_shape`` is
    the trace-time prototype shape. Indexing a list returns a GMTensor view-like
    object whose actual backing member is resolved at runtime. Returning a
    GMTensorList parameter marks it as a preallocated output list; otherwise it
    is an input list.
    """

    def __init__(
        self,
        dtype: DataTypeValue,
        item_shape: Sequence[ShapeDim],
        length: Optional[Union[int, Var]] = None,
        name: str = "",
        items: Optional[Sequence[GMTensor]] = None,
    ):
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        _ensure_not_packed_compute_view_dtype(dtype, "GMTensorList")
        if not isinstance(item_shape, (list, tuple)):
            raise TypeError(f"item_shape must be list/tuple, got: {type(item_shape)}")
        if length is not None and not isinstance(length, (int, Var)):
            raise TypeError(f"length must be int, Var, or None, got: {type(length)}")
        if isinstance(length, int) and length < 0:
            raise ValueError(f"length must be non-negative, current value: {length}")
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")
        assert_codegen_safe_identifier(name, "GMTensorList")

        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        if name == "":
            name = f"_tmp_gmtensor_list_{idx}"

        self.dtype = dtype
        self.item_shape = list(item_shape)
        self.shape = self.item_shape
        self.length = length
        self.name = name
        self.idx = idx
        self.items: List[GMTensor] = []
        self._size_var: Optional[Var] = None

        if items is not None:
            if not isinstance(items, (list, tuple)):
                raise TypeError(f"items must be list/tuple of GMTensor, got: {type(items)}")
            for item_idx, item in enumerate(items):
                if not isinstance(item, GMTensor):
                    raise TypeError(f"GMTensorList item #{item_idx} must be GMTensor, got: {type(item)}")
                if item.dtype != dtype:
                    raise TypeError(
                        f"GMTensorList item #{item_idx} dtype mismatch: {item.dtype} vs {dtype}"
                    )
                if len(item.shape) != len(self.item_shape):
                    raise ValueError(
                        f"GMTensorList item #{item_idx} rank mismatch: "
                        f"{len(item.shape)} vs {len(self.item_shape)}"
                    )
                self.items.append(item)
            if length is None:
                self.length = len(self.items)
            elif isinstance(length, int) and length != len(self.items):
                raise ValueError(
                    f"GMTensorList length mismatch: length={length}, item count={len(self.items)}"
                )

        self._assign_item_names()

        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("create_gm_tensor_list", val=self)
            )

    def __repr__(self):
        return (
            f"GMTensorList(name={self.name!r}, dtype={self.dtype!r}, "
            f"item_shape={self.item_shape!r}, length={self.length!r}, "
            f"items={len(self.items)!r})"
        )

    def _assign_item_names(self) -> None:
        if not self.items:
            return
        for item_idx, item in enumerate(self.items):
            item.name = f"{self.name}_item{item_idx}"

    def _bind_name(self, name: str) -> None:
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")
        assert_codegen_safe_identifier(name, "GMTensorList")
        self.name = name
        self._size_var = None
        self._assign_item_names()

    def size(self) -> Var:
        if self._size_var is not None:
            return self._size_var
        init_value = self.length if isinstance(self.length, int) else 0
        self._size_var = Var(init_value, Datatype.int, name=f"{self.name}_size")
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("tensorlist_size", tensor_list=self, out=self._size_var)
            )
        return self._size_var

    def item_numel(self, index: GMTensorListIndex) -> Var:
        """Return the runtime number of elements in one TensorList member."""
        if not isinstance(index, (int, Var)):
            raise TypeError(f"GMTensorList index only supports int or Var, got: {type(index)}")
        if isinstance(index, int):
            if index < 0:
                raise IndexError(f"GMTensorList index must be non-negative, got: {index}")
            if isinstance(self.length, int) and index >= self.length:
                raise IndexError(f"GMTensorList index out of range: {index}")
        if not self.item_shape:
            raise ValueError("GMTensorList.item_numel requires item rank >= 1")

        hint_shape = self.item_shape
        if isinstance(index, int) and index < len(self.items):
            hint_shape = self.items[index].shape
        prototype_numel = 1
        for dim in hint_shape:
            dim_value = dim.value if isinstance(dim, Var) else dim
            if not isinstance(dim_value, int):
                prototype_numel = 0
                break
            prototype_numel *= dim_value
        out = Var(prototype_numel, Datatype.int, name=f"{self.name}_item_numel")
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction(
                    "tensorlist_item_numel",
                    tensor_list=self,
                    index=index,
                    rank=len(self.item_shape),
                    out=out,
                )
            )
        return out

    def __len__(self) -> int:
        raise TypeError("GMTensorList length is dynamic in DSL; use .size() inside kernels")

    def __getitem__(self, index: GMTensorListIndex) -> GMTensor:
        if not isinstance(index, (int, Var)):
            raise TypeError(f"GMTensorList index only supports int or Var, got: {type(index)}")
        if isinstance(index, int):
            if index < 0:
                raise IndexError(f"GMTensorList index must be non-negative, got: {index}")
            if isinstance(self.length, int) and index >= self.length:
                raise IndexError(f"GMTensorList index out of range: {index}")

        idx = globvars.tmp_idx
        globvars.tmp_idx += 1
        out = object.__new__(GMTensor)
        out.dtype = self.dtype
        out.shape = list(self.item_shape)
        out.name = f"_tmp_gmtensor_{idx}"
        out.idx = idx
        out.offset = [0 for _ in self.item_shape]
        out.span = list(self.item_shape)
        out.step = [1 for _ in self.item_shape]
        out.slice_mask = [False for _ in self.item_shape]
        out._mutex = None
        out.data = None
        if isinstance(index, int) and index < len(self.items):
            out.data = self.items[index].data
        if globvars.active_kernel is not None:
            globvars.active_kernel.instructions.append(
                Instruction("get_gm_tensor_list_item", tensor_list=self, index=index, out=out)
            )
        return out
