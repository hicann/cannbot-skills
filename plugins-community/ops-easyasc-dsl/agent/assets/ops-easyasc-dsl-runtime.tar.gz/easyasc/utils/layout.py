from .positions import NZ_LOCAL_POSITIONS, PositionType


class LayoutType:
    """Layout value class: how a tensor's elements are arranged in its buffer.

    NZ = cube fractal layout (the nd2nz/zN form cube operands use); ND =
    contiguous N-dimensional layout (bias rows, scale tiles, UB data). This is a
    DSL-level dispatch hint only -- it selects which datamove the ``<<=`` operator
    emits and never reaches the generated code or simulator.
    """

    def __init__(self, name: str):
        self.name = name

    def __repr__(self) -> str:
        return f"LayoutType({self.name!r})"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        if self is other:
            return True
        if not isinstance(other, LayoutType):
            raise TypeError(f"Cannot compare LayoutType with {type(other)}")
        return self.name == other.name


class Layout:
    """Layout enum-like class.

    ``DEFAULT`` is a sentinel resolved per position at tensor construction
    (NZ for L1/L0A/L0B/L0C, ND for UB/BT); a stored layout is always a concrete
    ``NZ`` or ``ND``.
    """

    DEFAULT = LayoutType("default")
    NZ = LayoutType("nz")
    ND = LayoutType("nd")


def resolve_layout(layout: LayoutType, position: PositionType) -> LayoutType:
    """Resolve the ``DEFAULT`` sentinel to a concrete layout for ``position``."""
    if layout is Layout.DEFAULT:
        return Layout.NZ if position in NZ_LOCAL_POSITIONS else Layout.ND
    if layout is Layout.NZ or layout is Layout.ND:
        return layout
    raise TypeError(f"layout must be a Layout member, got: {layout!r}")
