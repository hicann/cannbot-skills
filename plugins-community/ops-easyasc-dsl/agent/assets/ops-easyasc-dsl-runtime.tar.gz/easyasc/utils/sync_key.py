from __future__ import annotations

from typing import Any, Iterable, Optional, Set, Tuple

from .Tensor import DBuff, QBuff, TBuff, Tensor
from .var import Var


SyncKey = Tuple[str, ...]
SyncKeyGroup = Tuple[SyncKey, ...]


def _scalar_sync_token(value: Any) -> str:
    if isinstance(value, Var):
        if value.value is not None:
            return str(value.value)
        return value.name
    if value is None:
        return ""
    return str(value)


def tensor_sync_key(tensor: Any) -> Optional[SyncKey]:
    if not isinstance(tensor, Tensor):
        return None

    source_buf = getattr(tensor, "source_buf", None)
    source_index = getattr(tensor, "source_index", None)
    if isinstance(source_buf, (DBuff, TBuff, QBuff)):
        return (
            "buffer",
            type(source_buf).__name__,
            str(getattr(source_buf, "position", "")),
            str(getattr(source_buf, "name", "")),
            _scalar_sync_token(source_index),
        )

    # Key by the underlying UB buffer identity (storage_key_name), which a slice INHERITS from
    # its parent. Keying anonymous tensors by object id (@anon+id) split a buffer from its own
    # slices: compute writes `u8_out` (dst = the buffer object) while the store reads
    # `u8_out[0:valid_q, :]` (src = a NEW slice object) -> different keys -> different auto_sync
    # event groups -> the cross-loop store->compute WAR went unbridged (gap #3). storage_key_name
    # preserves the original "same buffer across scopes lands on one slot" intent (one buffer has
    # one storage name), and additionally unifies a buffer with its slices.
    storage_name = str(getattr(tensor, "storage_key_name", "") or getattr(tensor, "name", ""))
    if not storage_name or storage_name.startswith("@"):
        return (
            "tensor",
            str(getattr(tensor, "position", "")),
            "@anon" + str(id(tensor)),
        )
    return (
        "tensor",
        str(getattr(tensor, "position", "")),
        storage_name,
    )


def collect_tensor_sync_keys(value: Any) -> Set[SyncKey]:
    result: Set[SyncKey] = set()

    def _visit(item: Any) -> None:
        key = tensor_sync_key(item)
        if key is not None:
            result.add(key)
            return
        if isinstance(item, dict):
            for child in item.values():
                _visit(child)
            return
        if isinstance(item, (list, tuple, set)):
            for child in item:
                _visit(child)

    _visit(value)
    return result


def normalize_sync_key_group(keys: Iterable[SyncKey]) -> Optional[SyncKeyGroup]:
    unique = sorted(set(keys))
    if not unique:
        return None
    return tuple(unique)
