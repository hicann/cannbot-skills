from .. import globvars


class DivAlgoValue:
    """A concrete C310 ``MicroAPI::Div`` algorithm selector."""

    def __init__(self, name: str) -> None:
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")
        self.name = name

    def __repr__(self) -> str:
        return f"DivAlgoValue({self.name!r})"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        if self is other:
            return True
        if not isinstance(other, DivAlgoValue):
            raise TypeError(f"Cannot compare DivAlgoValue with {type(other)}")
        return self.name == other.name


class DivAlgo:
    """Algorithms exposed by C310's ``MicroAPI::DivSpecificMode``."""

    INTRINSIC = DivAlgoValue("INTRINSIC")
    DIFF_COMPENSATION = DivAlgoValue("DIFF_COMPENSATION")
    PRECISION_1ULP_FTZ_TRUE = DivAlgoValue("PRECISION_1ULP_FTZ_TRUE")
    PRECISION_0ULP_FTZ_TRUE = DivAlgoValue("PRECISION_0ULP_FTZ_TRUE")
    PRECISION_0ULP_FTZ_FALSE = DivAlgoValue("PRECISION_0ULP_FTZ_FALSE")
    PRECISION_1ULP_FTZ_FALSE = DivAlgoValue("PRECISION_1ULP_FTZ_FALSE")


class DivConfig:
    """Configuration for an A5 register-register division.

    ``precision_mode`` selects CANN's compensated implementation for algorithms
    that support it.  An explicit IEEE algorithm, such as
    ``PRECISION_0ULP_FTZ_FALSE``, is honored independently of that flag.
    """

    def __init__(
        self,
        algo: DivAlgoValue = DivAlgo.INTRINSIC,
        precision_mode: bool = False,
        name: str = "",
    ) -> None:
        if not isinstance(algo, DivAlgoValue):
            raise TypeError(f"algo must be DivAlgoValue, got: {type(algo)}")
        if not isinstance(precision_mode, bool):
            raise TypeError(
                f"precision_mode must be bool, got: {type(precision_mode)}"
            )
        if not isinstance(name, str):
            raise TypeError(f"name must be str, got: {type(name)}")

        self.algo = algo
        self.precision_mode = precision_mode
        self.name = name

        micro = globvars.active_micro
        if micro is not None:
            config_list = getattr(micro, "div_cfg_list", None)
            if config_list is None:
                config_list = []
                setattr(micro, "div_cfg_list", config_list)
            if self not in config_list:
                prefix = getattr(micro, "name", micro.__class__.__name__)
                self.name = f"{prefix}_{self.name}"
                config_list.append(self)

    def __repr__(self) -> str:
        return (
            "DivConfig("
            f"algo={self.algo!r}, precision_mode={self.precision_mode!r}, "
            f"name={self.name!r})"
        )

    def __str__(self) -> str:
        return self.name
