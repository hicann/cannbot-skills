from typing import Any, Iterable, Optional


SIMT_UB_CAP_KB = 216
SIMT_UB_CAP_NOTE = "SIMT present: UB cap becomes 216 KB"
SIMT_UB_RESERVED_NOTE = "Remaining UB reserved for SIMT functionality"


def instructions_use_simt(instructions: Iterable[Any]) -> bool:
    for inst in instructions:
        if getattr(inst, "opname", "") == "call_simt":
            return True
    return False


def kernel_uses_simt(kernel: Any, instructions: Optional[Iterable[Any]] = None) -> bool:
    used_simts = getattr(kernel, "used_simts", None)
    if used_simts:
        return True
    if instructions is not None:
        return instructions_use_simt(instructions)
    kernel_insts = getattr(kernel, "instructions", None)
    if kernel_insts is not None:
        return instructions_use_simt(kernel_insts)
    return False


def effective_ub_cap_kb(default_cap_kb: int, uses_simt: bool) -> int:
    cap = int(default_cap_kb)
    if uses_simt and cap > SIMT_UB_CAP_KB:
        return SIMT_UB_CAP_KB
    return cap
