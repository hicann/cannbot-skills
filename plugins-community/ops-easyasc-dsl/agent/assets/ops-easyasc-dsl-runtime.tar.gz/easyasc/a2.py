from .utils.datatype import Datatype as DT
from .utils.Tensor import Tensor, DBuff, TBuff, QBuff, GMTensor, GMTensorList
from .utils.var import Var, VarList
from .decorators import kernel, func, auto_sync
from .scope import vec_scope, cube_scope
from .utils.positions import Position, PositionType
from .utils.conv2d import Conv2D, img2col, pack_nc1hwc0, pack_conv_weight
from .utils.layout import Layout, LayoutType
from .utils.roundmode import RoundMode, RoundModeType
from .utils.vecop import maximum, minimum
from .utils.cacheline import DcciDst, DcciDstType, EntireType, EntireTypeValue
from .utils.comparemode import CompareMode, CompareModeType
from .utils.selectmode import SelectMode, SelectModeType
from .utils.pipe import Pipe, PipeType
from .utils.events import SEvent, DEvent, TEvent, QEvent
from .utils.mutex import CvMutex, VcMutex
from .dtypehelper.int4_int32 import (
    pack_int4_to_int32,
    pack_signed_int4,
    pack_signed_int4_to_int32,
    unpack_int32_to_int4,
    unpack_int32_to_signed_int4,
    unpack_signed_int4,
)
from .stub_functions import (
    CeilDiv, GetCubeNum, GetCubeIdx, GetVecNum, GetVecIdx, GetSubBlockIdx,  # stub_functions/var_op.py
    scalar_sqrt, scalar_abs,                                                # stub_functions/var_op.py
    Align8, Align16, Align32, Align64, Align128, Align256,                  # stub_functions/var_op.py
    var_mul, var_add, var_sub, var_div, var_mod, Min, Max,                  # stub_functions/var_op.py
    gm_to_l1_nd2nz, gm_to_l1, set_constant_to_l1, l1_to_l0, l1_to_l0a_img2col, l1_to_bt, mmad, l0c_to_gm_nz2nd, l0c_to_gm_nz2nz, l0c_to_l1,  # stub_functions/cube.py
    bar_m, bar_v, bar_mte3, bar_mte2, bar_mte1, bar_fix, bar_all,           # stub_functions/barrier.py
    atomic_add, atomic_max, atomic_min,                                     # stub_functions/atomic.py
    reinterpret, split_workspace, reset_cache, set_hf32, clean_dcache, sim_print, sim_dump_tensor, kernel_print, kernel_dump_tensor, inline,  # stub_functions/misc.py
    cube_ready, vec_ready, wait_cube, wait_vec,                             # stub_functions/crosscore.py
    allcube_ready, allvec_ready, allcube_wait, allvec_wait,                 # stub_functions/crosscore.py
    intracore_allvec_ready, intracore_allvec_wait,                          # stub_functions/crosscore.py
    setflag, waitflag,                                                      # stub_functions/flags.py
    add, sub, mul, div, vmax, vmin, vand, vor, muladddst,                   # stub_functions/vec/binary.py
    exp, ln, abs, rec, sqrt, rsqrt, vnot, relu,                             # stub_functions/vec/unary.py
    adds, muls, shiftls, shiftrs, vmaxs, vmins, lrelu, axpy,                # stub_functions/vec/unaryscalar.py
    dup, brcb,                                                              # stub_functions/vec/dupbrcb.py
    transdata5hd,                                                           # stub_functions/vec/transdata.py
    gather, gather_block, scatter,                                          # stub_functions/vec/gatherscatter.py
    cmax, cgmax, cmin, cgmin, cadd, cgadd, cpadd,                           # stub_functions/vec/group.py
    sort32, mergesort4, mergesort_2seq,                                     # stub_functions/vec/sort.py
    set_mask, set_mask_normal, reset_mask, set_mask_by_count,               # stub_functions/vec/vecmask.py
    gm_to_ub_pad, ub_to_gm_pad, ub_to_ub,                                   # stub_functions/vec/datamove.py
    cast,                                                                   # stub_functions/vec/cast.py
    compare, compare_scalar,                                                # stub_functions/vec/compare.py
    select,                                                                 # stub_functions/vec/select.py
)
from .flowcontrol import range, unroll, If, Elif, Else, break_, continue_
from .torchplugin import OpExec, TorchApiManager
from .shortcuts import matmul, conv2d

from . import globvars 
globvars.device_type = 'b3'
globvars.core_num = 20
globvars.l1_cap = 512
globvars.l0a_cap = 64
globvars.l0b_cap = 64
globvars.l0amx_cap = 4
globvars.l0bmx_cap = 4
globvars.l0c_cap = 128
globvars.bt_cap = 0.5  # KB, total depth-2 BT capacity (2 x 256 B slots)
globvars.ub_cap = 192
