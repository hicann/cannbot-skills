from typing import Optional, Tuple, Union

from ..flowcontrol import If, Else, range as asc_range
from ..stub_functions import CeilDiv
from ..stub_functions import Min, mmad, reinterpret, l1_to_bt
from ..utils.Tensor import Tensor, DBuff
from ..utils.datatype import Datatype as DT
from ..utils.positions import Position
from ..utils.var import Var
from .. import globvars
from ..device_profile import is_c220_family
from ._common import (
    DimType, InitFlagType, _ensure_init_flag, _ensure_var_or_int,
    _get_kernel_bt_buffer, _get_kernel_l0_buffers, _is_transpose,
    _validate_bt_tile_width, emit_mmad_init,
)


def _is_int4_view(tensor: Tensor) -> bool:
    return getattr(tensor.dtype, "name", "") == "int4"


def _is_int_dtype(tensor: Tensor) -> bool:
    return tensor.dtype is DT.int or getattr(tensor.dtype, "name", "") == "int"


def _is_c220_device() -> bool:
    return is_c220_family(getattr(globvars, "device_type", ""))


def _carrier_tensor(tensor: Tensor) -> Tensor:
    if not _is_int4_view(tensor):
        return tensor
    carrier = getattr(tensor, "_int4_carrier", None)
    if not isinstance(carrier, Tensor):
        raise ValueError("DT.int4 matmul input must be created from a DT.int carrier via .reinterpret(DT.int4)")
    return carrier


def _uses_int4(l1a: Tensor, l1b: Tensor) -> bool:
    a_is_int4 = _is_int4_view(l1a)
    b_is_int4 = _is_int4_view(l1b)
    if a_is_int4 != b_is_int4:
        raise TypeError("int4 matmul requires both l1a and l1b to be DT.int4 views")
    return a_is_int4


def _validate_matmul_dtypes(dst: Tensor, l1a: Tensor, l1b: Tensor, int4: bool) -> None:
    if int4:
        if not _is_c220_device():
            raise ValueError("DT.int4 codegen is only supported on a2/b* devices")
        if dst.dtype is not DT.int:
            raise TypeError(f"int4 matmul requires DT.int destination, got: {dst.dtype}")
        for label, tensor in (("l1a", l1a), ("l1b", l1b)):
            carrier = _carrier_tensor(tensor)
            if carrier.dtype is not DT.int:
                raise TypeError(f"int4 matmul requires {label} to be backed by a DT.int carrier, got: {carrier.dtype}")
            tensor._int4_consumed_by = "matmul"
        return
    if _is_int_dtype(l1a) and _is_int_dtype(l1b):
        raise TypeError(
            "DT.int cube matmul is unsupported; use DT.int carriers reinterpreted as DT.int4 for int4 MMAD"
        )


def _ceil_div8(value: DimType) -> DimType:
    if isinstance(value, int):
        return (value + 7) // 8
    return CeilDiv(value, 8)


def _ensure_int4_splitk(split_k: Union[int, Var]) -> None:
    if isinstance(split_k, int) and split_k % 8 != 0:
        raise ValueError(f"int4 splitk must be a multiple of 8, got: {split_k}")
    if isinstance(split_k, Var) and isinstance(split_k.value, int) and split_k.value % 8 != 0:
        raise ValueError(f"int4 splitk must be a multiple of 8, got: {split_k.value}")


def _prepare_l0_tensors(
    l0a: DBuff,
    l0b: DBuff,
    l1a: Tensor,
    l1b: Tensor,
    l0acnt: Var,
    l0bcnt: Var,
) -> Tuple[Tensor, Tensor]:
    l0a_tmp = reinterpret(l0a[l0acnt], l1a.dtype)
    l0b_tmp = reinterpret(l0b[l0bcnt], l1b.dtype)
    return l0a_tmp, l0b_tmp


def _stage_bias_tile(
    bias_l1: Tensor,
    col0: DimType,
    valid_n: DimType,
    btbuf: DBuff,
    btbufcnt: Var,
) -> Tensor:
    """Copy ``bias_l1[:, col0:col0+valid_n]`` (a contiguous L1 row) into a fresh BT
    slot and return that slot tensor for use as ``mmad(..., bias=)``. The C2/dst is
    always loaded from slot start (offset 0) so the mmad bias read matches the
    validated single-tile layout; only the L1 source carries the per-tile offset.
    The caller advances ``btbufcnt`` *after* the consuming mmad (ping-pong)."""
    bt = btbuf[btbufcnt]
    # The auto _btbuf is declared fp32; for an int32 bias (int8@int8) reinterpret the
    # slot to int (both are 4 bytes, so this is a zero-copy view) so the l1_to_bt
    # dst/src dtypes match. This `bt` view is also what the consuming mmad reads back.
    # A *narrower* bias is the other case: MTE1 widens fp16/bf16 to the fp32 table on
    # the way in (CANN dispatches L1->C2 on the dtype pair), so the slot has to stay
    # fp32 for that path -- reinterpreting it would ask the hardware for a same-width
    # copy and hand the mmad half the row.
    if bt.dtype != bias_l1.dtype and bt.dtype.size == bias_l1.dtype.size:
        bt = reinterpret(bt, bias_l1.dtype)

    sliced = not (isinstance(col0, int) and col0 == 0)
    if sliced and bias_l1.dtype is DT.float and _is_c220_device():
        # On a2 a *float* L1 tensor slices with ZZ-fractal column addressing (offset
        # col0*16), which is wrong for the contiguous [1, N] bias row. Copy through a
        # zero-copy int32 view (4 B) so the column slice uses the contiguous NZ formula
        # (col0*1 for a 1-row tensor) -- the same path the int8/int32 bias already takes
        # -- while l1_to_bt moves the raw float bytes and the mmad still reads the slot
        # as float via `bt`. (On a5 a float L1 slice is already contiguous/NZ.)
        src = reinterpret(bias_l1, DT.int)[:, col0:col0 + valid_n]
        l1_to_bt(reinterpret(bt, DT.int), src, n=valid_n)
    else:
        src = bias_l1 if not sliced else bias_l1[:, col0:col0 + valid_n]
        l1_to_bt(bt, src, n=valid_n)
    return bt


def matmul_splitn(
    dst: Tensor,
    l1a: Tensor,
    l1b: Tensor,
    l0a: DBuff,
    l0b: DBuff,
    l0acnt: Var,
    l0bcnt: Var,
    split_n: Union[int, Var],
    is_init: InitFlagType,
    m: Optional[DimType] = None,
    n: Optional[DimType] = None,
    k: Optional[DimType] = None,
    int4: bool = False,
    bias: Optional[Tensor] = None,
    btbuf: Optional[DBuff] = None,
    btbufcnt: Optional[Var] = None,
) -> None:
    l1a_src = _carrier_tensor(l1a)
    l1b_src = _carrier_tensor(l1b)
    total_n = n if n is not None else (l1b.shape[1] if _is_transpose(l1b) else l1b.shape[0])
    for _subn in asc_range(0, total_n, split_n, name="_subn"):
        valid_n = Min(total_n - _subn, split_n)
        l0a_tmp, l0b_tmp = _prepare_l0_tensors(l0a, l0b, l1a_src, l1b_src, l0acnt, l0bcnt)

        with If(_subn == 0):
            l0a_tmp <<= l1a_src
        if _is_transpose(l1b_src):
            l0b_tmp <<= l1b_src[:, _subn : _subn + valid_n]
        else:
            l0b_tmp <<= l1b_src[_subn : _subn + valid_n, :]

        if int4:
            l0a_tmp = reinterpret(l0a_tmp, DT.int4)
            l0b_tmp = reinterpret(l0b_tmp, DT.int4)

        # Each N-tile writes a distinct dst column range (its own is_init tile), so it
        # gets its own bias slice bias[:, _subn:_subn+valid_n] staged into a BT slot.
        bias_bt = None
        if bias is not None:
            bias_bt = _stage_bias_tile(bias, _subn, valid_n, btbuf, btbufcnt)

        sub_dst = dst[:, _subn : _subn + valid_n]
        mmad_n = valid_n if n is not None else None
        emit_mmad_init(mmad, sub_dst, l0a_tmp, l0b_tmp, is_init, bias=bias_bt, M=m, N=mmad_n, K=k)

        if bias is not None:
            btbufcnt += 1
        l0bcnt += 1
    l0acnt += 1


def matmul_splitk(
    dst: Tensor,
    l1a: Tensor,
    l1b: Tensor,
    l0a: DBuff,
    l0b: DBuff,
    l0acnt: Var,
    l0bcnt: Var,
    split_k: Union[int, Var],
    is_init: InitFlagType,
    m: Optional[DimType] = None,
    n: Optional[DimType] = None,
    k: Optional[DimType] = None,
    int4: bool = False,
    bias: Optional[Tensor] = None,
    btbuf: Optional[DBuff] = None,
    btbufcnt: Optional[Var] = None,
) -> None:
    l1a_src = _carrier_tensor(l1a)
    l1b_src = _carrier_tensor(l1b)
    if int4:
        _ensure_int4_splitk(split_k)
    total_k = k if k is not None else (l1b.shape[0] if _is_transpose(l1b) else l1b.shape[1])
    # The bias does not depend on k; stage the full row once and add it only on the
    # is_init K-tile (_subk == 0). btbufcnt is advanced after the loop, so every
    # in-loop reference to the slot resolves to the value it was loaded at.
    bias_bt = None
    if bias is not None:
        total_n = n if n is not None else (l1b.shape[1] if _is_transpose(l1b) else l1b.shape[0])
        bias_bt = _stage_bias_tile(bias, 0, total_n, btbuf, btbufcnt)
    for _subk in asc_range(0, total_k, split_k, name="_subk"):
        valid_k = Min(total_k - _subk, split_k)
        l0a_tmp, l0b_tmp = _prepare_l0_tensors(l0a, l0b, l1a_src, l1b_src, l0acnt, l0bcnt)

        if int4:
            carrier_start = _subk // 8
            carrier_valid_k = _ceil_div8(valid_k)
            if _is_transpose(l1a_src):
                l0a_tmp <<= l1a_src[carrier_start : carrier_start + carrier_valid_k, :]
            else:
                l0a_tmp <<= l1a_src[:, carrier_start : carrier_start + carrier_valid_k]

            if _is_transpose(l1b_src):
                l0b_tmp <<= l1b_src[carrier_start : carrier_start + carrier_valid_k, :]
            else:
                l0b_tmp <<= l1b_src[:, carrier_start : carrier_start + carrier_valid_k]

            l0a_tmp = reinterpret(l0a_tmp, DT.int4)
            l0b_tmp = reinterpret(l0b_tmp, DT.int4)
        else:
            # The L0 loads move whole K fractals: a copy width that is not a
            # multiple of C0 desyncs the transpose load's step parameters on
            # a5 (board-corrupt results for e.g. valid_k == 1 while the
            # simulator stays clean).  Round the copy up to the fractal —
            # every legal NZ panel declares a C0-aligned K, so the slice
            # stays inside the panel — and let MMAD's k exclude the pad.
            c0_a = 32 // l1a_src.dtype.size
            c0_b = 32 // l1b_src.dtype.size
            copy_ka = CeilDiv(valid_k, c0_a) * c0_a if k is not None else valid_k
            copy_kb = CeilDiv(valid_k, c0_b) * c0_b if k is not None else valid_k
            if _is_transpose(l1a_src):
                l0a_tmp <<= l1a_src[_subk : _subk + copy_ka, :]
            else:
                l0a_tmp <<= l1a_src[:, _subk : _subk + copy_ka]

            if _is_transpose(l1b_src):
                l0b_tmp <<= l1b_src[_subk : _subk + copy_kb, :]
            else:
                l0b_tmp <<= l1b_src[:, _subk : _subk + copy_kb]

        mmad_k = valid_k if k is not None else None
        if isinstance(is_init, (bool, int)):
            if bool(is_init):
                with If(_subk == 0):
                    mmad(dst, l0a_tmp, l0b_tmp, M=m, N=n, K=mmad_k, is_init=True, bias=bias_bt)
                with Else():
                    mmad(dst, l0a_tmp, l0b_tmp, M=m, N=n, K=mmad_k, is_init=False)
            else:
                mmad(dst, l0a_tmp, l0b_tmp, M=m, N=n, K=mmad_k, is_init=False)
        else:
            with If((_subk == 0) & is_init):
                mmad(dst, l0a_tmp, l0b_tmp, M=m, N=n, K=mmad_k, is_init=True, bias=bias_bt)
            with Else():
                mmad(dst, l0a_tmp, l0b_tmp, M=m, N=n, K=mmad_k, is_init=False)

        l0acnt += 1
        l0bcnt += 1
    if bias is not None:
        btbufcnt += 1


def matmul_nosplit(
    dst: Tensor,
    l1a: Tensor,
    l1b: Tensor,
    l0a: DBuff,
    l0b: DBuff,
    l0acnt: Var,
    l0bcnt: Var,
    is_init: InitFlagType,
    m: Optional[DimType] = None,
    n: Optional[DimType] = None,
    k: Optional[DimType] = None,
    int4: bool = False,
    bias: Optional[Tensor] = None,
    btbuf: Optional[DBuff] = None,
    btbufcnt: Optional[Var] = None,
) -> None:
    l1a_src = _carrier_tensor(l1a)
    l1b_src = _carrier_tensor(l1b)
    l0a_tmp, l0b_tmp = _prepare_l0_tensors(l0a, l0b, l1a_src, l1b_src, l0acnt, l0bcnt)

    l0a_tmp <<= l1a_src
    l0b_tmp <<= l1b_src

    if int4:
        l0a_tmp = reinterpret(l0a_tmp, DT.int4)
        l0b_tmp = reinterpret(l0b_tmp, DT.int4)

    bias_bt = None
    if bias is not None:
        total_n = n if n is not None else (l1b.shape[1] if _is_transpose(l1b) else l1b.shape[0])
        bias_bt = _stage_bias_tile(bias, 0, total_n, btbuf, btbufcnt)

    emit_mmad_init(mmad, dst, l0a_tmp, l0b_tmp, is_init, bias=bias_bt, M=m, N=n, K=k)

    if bias is not None:
        btbufcnt += 1
    l0acnt += 1
    l0bcnt += 1


def matmul(
    dst: Tensor,
    l1a: Tensor,
    l1b: Tensor,
    splitn: Union[int, Var, None] = None,
    splitk: Union[int, Var, None] = None,
    m: Union[int, Var, None] = None,
    n: Union[int, Var, None] = None,
    k: Union[int, Var, None] = None,
    is_init: InitFlagType = True,
    bias: Optional[Tensor] = None,
) -> None:
    r"""Cube matmul via L1: |dst| = l1a @ l1b**T  (shape convention: [m,k] @ [n,k]^T -> [m,n]).

    * l1a is read as an [M, K] matrix (non-transposed).
    * l1b is read as an [N, K] matrix — the K dimension is the *last* axis.
      Mathematically this computes l1a @ l1b**T.
      If the caller stored l1b in [K, N] layout, append ``.T`` so the
      matmul reads it as [N, K] (a transposed view from L1).
    * dst (L0C, fp32) receives the [M, N] result.
    * splitn tiles the N dimension across L0B reloads.
    * splitk tiles the K dimension (mutually exclusive with splitn).
    * When is_init=False the result is *accumulated* into dst
      (requires same-shape previous partial matmul).
    * bias (optional, a2/910b and a5/950): a contiguous [1, N] row in L1 added on the
      init tile so |dst| = l1a @ l1b**T + bias. It is fp32 for float/half/bf16 inputs
      and int32 for int8@int8 (Mmad datatype tables 8/9). On a5 the row may also be
      fp16/bf16: the L1->C2 load widens it to the fp32 table in hardware, which saves
      a separate cast kernel when the operator's bias arrives in the input dtype.
      Stage it with a flat burst
      (``gm_to_l1`` on a2, ``gm_to_l1_pad`` on a5, or a ``layout=Layout.ND`` L1 tensor
      via ``<<=``), NOT the default nd2nz ``<<=`` (which would fractalize the row). The
      shortcut routes it through the kernel's auto-inserted BT/C2 buffer; requires
      is_init (cannot bias an accumulate-only matmul) and is not supported for int4.
    """
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor, got: {type(dst)}")
    if dst.position is not Position.L0C:
        raise ValueError(f"dst must be L0C, got: {dst.position}")
    if not isinstance(l1a, Tensor):
        raise TypeError(f"l1a must be Tensor, got: {type(l1a)}")
    if l1a.position is not Position.L1:
        raise ValueError(f"l1a must be L1, got: {l1a.position}")
    if not isinstance(l1b, Tensor):
        raise TypeError(f"l1b must be Tensor, got: {type(l1b)}")
    if l1b.position is not Position.L1:
        raise ValueError(f"l1b must be L1, got: {l1b.position}")
    if splitn is not None:
        _ensure_var_or_int(splitn, "splitn")
    if splitk is not None:
        _ensure_var_or_int(splitk, "splitk")
    if m is not None:
        _ensure_var_or_int(m, "m")
    if n is not None:
        _ensure_var_or_int(n, "n")
    if k is not None:
        _ensure_var_or_int(k, "k")
    if splitn is not None and splitk is not None:
        raise ValueError("splitn and splitk cannot both be set")
    _ensure_init_flag(is_init, "is_init")
    int4 = _uses_int4(l1a, l1b)
    _validate_matmul_dtypes(dst, l1a, l1b, int4)

    btbuf = btbufcnt = None
    if bias is not None:
        if int4:
            raise ValueError("matmul bias is not supported for int4 inputs (MMAD_BIAS is fp32/int32-only)")
        if not isinstance(bias, Tensor):
            raise TypeError(f"bias must be Tensor, got: {type(bias)}")
        if bias.position is not Position.L1:
            raise ValueError(
                f"bias must be staged contiguously in L1 (gm_to_l1 / gm_to_l1_pad), got: {bias.position}"
            )
        if bias.dtype not in (DT.float, DT.int, DT.half, DT.bfloat16):
            raise TypeError(
                "matmul bias only supports fp32 (float inputs), int32 (int8@int8), or a "
                f"fp16/bf16 row the L1->C2 load widens to fp32, got: {bias.dtype}"
            )
        if bias.dtype in (DT.half, DT.bfloat16) and _is_c220_device():
            raise TypeError(
                "a narrow (fp16/bf16) matmul bias needs the a5 L1->C2 widening load; "
                "stage an fp32 row on a2/910b"
            )
        if isinstance(is_init, (bool, int)) and not bool(is_init):
            raise ValueError(
                "matmul bias requires is_init (C = bias + A@B); an accumulate-only "
                "matmul (is_init=False) cannot add a bias"
            )
        btbuf, btbufcnt = _get_kernel_bt_buffer("matmul")
        if splitn is not None:
            _validate_bt_tile_width(splitn, btbuf, "matmul splitn")
        else:
            total_n = n if n is not None else (l1b.shape[1] if _is_transpose(l1b) else l1b.shape[0])
            _validate_bt_tile_width(total_n, btbuf, "matmul")

    l0a, l0b, l0acnt, l0bcnt = _get_kernel_l0_buffers("matmul")

    if splitn is not None:
        matmul_splitn(dst, l1a, l1b, l0a, l0b, l0acnt, l0bcnt, splitn, is_init, m, n, k, int4,
                      bias=bias, btbuf=btbuf, btbufcnt=btbufcnt)
        return
    if splitk is not None:
        matmul_splitk(dst, l1a, l1b, l0a, l0b, l0acnt, l0bcnt, splitk, is_init, m, n, k, int4,
                      bias=bias, btbuf=btbuf, btbufcnt=btbufcnt)
        return
    matmul_nosplit(dst, l1a, l1b, l0a, l0b, l0acnt, l0bcnt, is_init, m, n, k, int4,
                   bias=bias, btbuf=btbuf, btbufcnt=btbufcnt)


__all__ = ["matmul"]
