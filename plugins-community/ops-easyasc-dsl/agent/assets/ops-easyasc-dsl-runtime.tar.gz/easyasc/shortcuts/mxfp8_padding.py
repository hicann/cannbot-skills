from typing import Union

from ..stub_functions import bar_mte2, reinterpret, set_constant_to_l1
from ..stub_functions.vec.vecutils import A5_DEVICES, assert_valid_device
from ..utils.Tensor import Tensor
from ..utils.datatype import Datatype as DT
from ..utils.positions import Position
from ..utils.var import Var


def _static_numel(shape: object) -> Union[int, None]:
    if not isinstance(shape, (list, tuple)):
        return None
    numel = 1
    for dim in shape:
        if not isinstance(dim, int) or isinstance(dim, bool):
            return None
        numel *= dim
    return numel


def zero_mxfp8_l1_padding(tensor: Tensor, n_blocks: Union[int, Var, None] = None) -> None:
    """Zero an L1 byte-sized tile before copying a valid MXFP8 sub-tile into it.

    The helper is intentionally data-only: MX scale padding does not need an
    initialized value when the corresponding FP8 data lane is zero. Call this
    before writing live scale/data that could sit after the padded tile in L1;
    A5 InitConstValue has coarse L1 matrix granularity.
    """
    assert_valid_device(A5_DEVICES)
    if not isinstance(tensor, Tensor):
        raise TypeError(f"tensor must be Tensor type, current type: {type(tensor)}")
    if tensor.position is not Position.L1:
        raise ValueError(f"tensor must be at L1 position, current position: {tensor.position}")
    if bool(getattr(tensor, "is_transpose", False)):
        raise ValueError("zero_mxfp8_l1_padding expects a physical L1 tensor, not a transposed view")
    if tensor.dtype.size != 1:
        raise TypeError(f"zero_mxfp8_l1_padding expects a byte-sized tensor, got: {tensor.dtype}")

    if n_blocks is None:
        numel = _static_numel(tensor.shape)
        if numel is not None:
            if numel % 32 != 0:
                raise ValueError(
                    "zero_mxfp8_l1_padding expects the static tensor footprint to be 32B aligned, "
                    f"got {numel} bytes"
                )
            n_blocks = numel // 32

    zero_view = reinterpret(tensor, DT.uint16, name=f"{tensor.name}_zero_u16")
    set_constant_to_l1(zero_view, 0, n_blocks=n_blocks)
    bar_mte2()


__all__ = ["zero_mxfp8_l1_padding"]
