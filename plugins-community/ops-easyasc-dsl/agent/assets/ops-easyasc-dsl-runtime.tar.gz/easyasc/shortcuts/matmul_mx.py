from typing import Optional, Tuple, Union

from ..flowcontrol import If, Else, range as asc_range
from ..stub_functions import CeilDiv, Min, l1_to_l0_mx, mmad_mx, reinterpret
from ..utils.Tensor import DBuff, Tensor
from ..utils.datatype import Datatype as DT
from ..utils.positions import Position
from ..utils.var import Var
from ._common import (
    DimType, InitFlagType, _ensure_init_flag, _ensure_var_or_int,
    _get_kernel_bt_buffer, _get_kernel_l0_buffers, _is_transpose,
    _validate_bt_tile_width, emit_mmad_init,
)
from .matmul import _stage_bias_tile


def _known_int(value: object) -> Union[int, None]:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, Var) and isinstance(value.value, int) and not isinstance(value.value, bool):
        return value.value
    return None


def _is_e8m0_carrier(tensor: Tensor) -> bool:
    return tensor.dtype is DT.uint8 or getattr(tensor.dtype, "name", "") in ("uint8_t", "fp8_e8m0_t")


def _mx_dtype_for_l1(tensor: Tensor):
    if tensor.dtype is DT.e4m3 or getattr(tensor.dtype, "name", "") == "float8_e4m3_t":
        return DT.mx_e4m3
    if tensor.dtype is DT.e5m2 or getattr(tensor.dtype, "name", "") == "float8_e5m2_t":
        return DT.mx_e5m2
    if _is_fp4_l1(tensor):
        return tensor.dtype
    raise TypeError(f"matmul_mx only supports DT.e4m3/DT.e5m2/FP4 L1 inputs, got: {tensor.dtype}")


def _is_fp4_l1(tensor: Tensor) -> bool:
    return getattr(tensor.dtype, "name", "") in ("fp4x2_e2m1_t", "fp4x2_e1m2_t")


def _mx_family(tensor: Tensor) -> str:
    if _is_fp4_l1(tensor):
        return "mxfp4"
    _mx_dtype_for_l1(tensor)
    return "mxfp8"


def _ensure_mx_splitk(split_k: Union[int, Var]) -> None:
    if isinstance(split_k, int) and split_k % 64 != 0:
        raise ValueError(f"MX splitk must be a multiple of 64, got: {split_k}")
    if isinstance(split_k, Var) and isinstance(split_k.value, int) and split_k.value % 64 != 0:
        raise ValueError(f"MX splitk must be a multiple of 64, got: {split_k.value}")


def _ensure_mx_splitn(split_n: Union[int, Var]) -> None:
    if isinstance(split_n, int) and split_n % 16 != 0:
        raise ValueError(f"MX splitn must be a multiple of 16, got: {split_n}")
    if isinstance(split_n, Var) and isinstance(split_n.value, int) and split_n.value % 16 != 0:
        raise ValueError(f"MX splitn must be a multiple of 16, got: {split_n.value}")


def _ensure_mx_transpose_splitn(split_n: Union[int, Var]) -> None:
    if isinstance(split_n, int) and split_n % 32 != 0:
        raise ValueError(f"MX transposed-B splitn must be a multiple of 32, got: {split_n}")
    if isinstance(split_n, Var) and isinstance(split_n.value, int) and split_n.value % 32 != 0:
        raise ValueError(f"MX transposed-B splitn must be a multiple of 32, got: {split_n.value}")


def _b_logical_n(l1b: Tensor) -> DimType:
    return l1b.span[1] if _is_transpose(l1b) else l1b.span[0]


def _b_physical_n(l1b: Tensor) -> DimType:
    return l1b.shape[1] if _is_transpose(l1b) else l1b.shape[0]


def _a_logical_m(l1a: Tensor) -> DimType:
    return l1a.span[1] if _is_transpose(l1a) else l1a.span[0]


def _a_logical_k(l1a: Tensor) -> DimType:
    return l1a.span[0] if _is_transpose(l1a) else l1a.span[1]


def _prepare_mx_l0_tensors(
    l0a: DBuff,
    l0b: DBuff,
    l1a: Tensor,
    l1b: Tensor,
    l0acnt: Var,
    l0bcnt: Var,
) -> Tuple[Tensor, Tensor]:
    l0a_tmp = reinterpret(l0a[l0acnt], _mx_dtype_for_l1(l1a))
    l0b_tmp = reinterpret(l0b[l0bcnt], _mx_dtype_for_l1(l1b))
    return l0a_tmp, l0b_tmp


def _validate_matmul_mx_tensors(dst: Tensor, l1a: Tensor, l1b: Tensor, scale_a: Tensor, scale_b: Tensor) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor, got: {type(dst)}")
    if dst.position is not Position.L0C:
        raise ValueError(f"dst must be L0C, got: {dst.position}")
    if dst.dtype is not DT.float:
        raise TypeError(f"matmul_mx requires DT.float L0C destination, got: {dst.dtype}")
    for label, tensor in (("l1a", l1a), ("l1b", l1b), ("scale_a", scale_a), ("scale_b", scale_b)):
        if not isinstance(tensor, Tensor):
            raise TypeError(f"{label} must be Tensor, got: {type(tensor)}")
        if tensor.position is not Position.L1:
            raise ValueError(f"{label} must be L1, got: {tensor.position}")
    _mx_dtype_for_l1(l1a)
    _mx_dtype_for_l1(l1b)
    family_a = _mx_family(l1a)
    family_b = _mx_family(l1b)
    if family_a != family_b:
        raise TypeError(f"matmul_mx does not support mixed {l1a.dtype}/{l1b.dtype} families yet")
    if family_a == "mxfp4":
        for label, tensor in (("l1a", l1a), ("l1b", l1b)):
            carrier = getattr(tensor, "_fp4_carrier", None)
            if not isinstance(carrier, Tensor) or carrier.dtype is not DT.uint8:
                raise TypeError(f"matmul_mx requires FP4 {label} to be a DT.uint8 carrier reinterpret view")
    if not _is_e8m0_carrier(scale_a):
        raise TypeError(f"matmul_mx requires DT.uint8/e8m0 scale_a, got: {scale_a.dtype}")
    if not _is_e8m0_carrier(scale_b):
        raise TypeError(f"matmul_mx requires DT.uint8/e8m0 scale_b, got: {scale_b.dtype}")
    if _is_transpose(scale_a) or _is_transpose(scale_b):
        raise ValueError("matmul_mx scale tensors cannot be transposed")


def _mx_scale_cols_for_k(valid_k: DimType) -> DimType:
    return CeilDiv(valid_k, 64) * 2


def _validate_16row_mx_scale_tile(scale: Tensor, label: str) -> None:
    rows = _known_int(scale.shape[0])
    if rows is not None and rows != 16:
        raise ValueError(f"matmul_mx currently expects a 16-row MX scale tile for {label}, got {label}.shape[0]={rows}")


def _validate_transposed_b_scale_tile(scale_b: Tensor, total_n: DimType, total_k: DimType) -> None:
    scale_rows = _known_int(scale_b.shape[0])
    expected_rows = _known_int(total_n)
    if scale_rows is not None and scale_rows % 16 != 0:
        raise ValueError(f"matmul_mx transposed B expects scale_b.shape[0] to be 16-row aligned, got {scale_rows}")
    if scale_rows is not None and expected_rows is not None and scale_rows != expected_rows:
        raise ValueError(
            "matmul_mx transposed B expects scale_b.shape[0] to match logical N rows, "
            f"got {scale_rows} vs {expected_rows}"
        )
    scale_cols = _known_int(scale_b.shape[1])
    total_k_static = _known_int(total_k)
    expected_cols = None if total_k_static is None else ((total_k_static + 63) // 64) * 2
    if scale_cols is not None and expected_cols is not None and scale_cols != expected_cols:
        raise ValueError(
            "matmul_mx transposed B expects scale_b.shape[1] to be 2 * ceil(K / 64), "
            f"got {scale_cols} vs {expected_cols}"
        )


def _validate_transposed_a_scale_tile(scale_a: Tensor, total_m: DimType, total_k: DimType) -> None:
    scale_rows = _known_int(scale_a.shape[0])
    expected_rows = _known_int(total_m)
    if scale_rows is not None and scale_rows % 16 != 0:
        raise ValueError(f"matmul_mx transposed A expects scale_a.shape[0] to be 16-row aligned, got {scale_rows}")
    if scale_rows is not None and expected_rows is not None and scale_rows != expected_rows:
        raise ValueError(
            "matmul_mx transposed A expects scale_a.shape[0] to match logical M rows, "
            f"got {scale_rows} vs {expected_rows}"
        )
    scale_cols = _known_int(scale_a.shape[1])
    total_k_static = _known_int(total_k)
    expected_cols = None if total_k_static is None else ((total_k_static + 63) // 64) * 2
    if scale_cols is not None and expected_cols is not None and scale_cols != expected_cols:
        raise ValueError(
            "matmul_mx transposed A expects scale_a.shape[1] to be 2 * ceil(K / 64), "
            f"got {scale_cols} vs {expected_cols}"
        )


def _validate_splitn_mx_scale_b(scale_b: Tensor, l1b: Tensor) -> None:
    scale_rows = _known_int(scale_b.shape[0])
    b_rows = _known_int(_b_physical_n(l1b))
    if scale_rows is not None and scale_rows % 16 != 0:
        raise ValueError(f"matmul_mx splitn expects scale_b.shape[0] to be 16-row aligned, got {scale_rows}")
    if scale_rows is not None and b_rows is not None and scale_rows != b_rows:
        raise ValueError(
            "matmul_mx splitn expects scale_b.shape[0] to match the full B logical row count "
            f"so MX scale row tiles stay physically addressable, got {scale_rows} vs {b_rows}"
        )


def matmul_mx_nosplit(
    dst: Tensor,
    l1a: Tensor,
    l1b: Tensor,
    scale_a: Tensor,
    scale_b: Tensor,
    l0a: DBuff,
    l0b: DBuff,
    l0acnt: Var,
    l0bcnt: Var,
    is_init: InitFlagType,
    m: Union[int, Var, None] = None,
    n: Union[int, Var, None] = None,
    k: Union[int, Var, None] = None,
    bias: Optional[Tensor] = None,
    btbuf: Optional[DBuff] = None,
    btbufcnt: Optional[Var] = None,
) -> None:
    total_m = m if m is not None else _a_logical_m(l1a)
    total_n = n if n is not None else _b_logical_n(l1b)
    total_k = k if k is not None else _a_logical_k(l1a)
    a_is_transpose = _is_transpose(l1a)
    if a_is_transpose:
        _validate_transposed_a_scale_tile(scale_a, total_m, total_k)
    else:
        _validate_16row_mx_scale_tile(scale_a, "scale_a")
    b_is_transpose = _is_transpose(l1b)
    if b_is_transpose:
        _validate_transposed_b_scale_tile(scale_b, total_n, total_k)
    else:
        _validate_16row_mx_scale_tile(scale_b, "scale_b")

    l0a_tmp, l0b_tmp = _prepare_mx_l0_tensors(l0a, l0b, l1a, l1b, l0acnt, l0bcnt)
    if a_is_transpose:
        l1_to_l0_mx(
            l0a_tmp,
            l1a,
            scale_a,
            m_dst=total_k,
            n_dst=total_m,
            m_src=l1a.shape[0],
            n_src=l1a.shape[1],
        )
    else:
        l1_to_l0_mx(l0a_tmp, l1a, scale_a, m_dst=total_m, n_dst=total_k, m_src=l1a.shape[0], n_src=l1a.shape[1])
    if b_is_transpose:
        l1_to_l0_mx(
            l0b_tmp,
            l1b,
            scale_b,
            m_dst=total_k,
            n_dst=total_n,
            m_src=l1b.shape[0],
            n_src=l1b.shape[1],
        )
    else:
        l1_to_l0_mx(l0b_tmp, l1b, scale_b, m_dst=total_n, n_dst=total_k, m_src=l1b.shape[0], n_src=l1b.shape[1])
    bias_bt = None
    if bias is not None:
        bias_bt = _stage_bias_tile(bias, 0, total_n, btbuf, btbufcnt)
    emit_mmad_init(mmad_mx, dst, l0a_tmp, l0b_tmp, is_init, bias=bias_bt, M=total_m, N=total_n, K=total_k)
    if bias is not None:
        btbufcnt += 1
    l0acnt += 1
    l0bcnt += 1


def matmul_mx_splitn(
    dst: Tensor,
    l1a: Tensor,
    l1b: Tensor,
    scale_a: Tensor,
    scale_b: Tensor,
    l0a: DBuff,
    l0b: DBuff,
    l0acnt: Var,
    l0bcnt: Var,
    split_n: Union[int, Var],
    is_init: InitFlagType,
    m: Union[int, Var, None] = None,
    n: Union[int, Var, None] = None,
    k: Union[int, Var, None] = None,
    bias: Optional[Tensor] = None,
    btbuf: Optional[DBuff] = None,
    btbufcnt: Optional[Var] = None,
) -> None:
    total_m = m if m is not None else _a_logical_m(l1a)
    total_n = n if n is not None else _b_logical_n(l1b)
    total_k = k if k is not None else _a_logical_k(l1a)
    a_is_transpose = _is_transpose(l1a)
    if a_is_transpose:
        _validate_transposed_a_scale_tile(scale_a, total_m, total_k)
    else:
        _validate_16row_mx_scale_tile(scale_a, "scale_a")
    _validate_splitn_mx_scale_b(scale_b, l1b)
    b_is_transpose = _is_transpose(l1b)

    total_k_blocks = CeilDiv(total_k, 64)
    for _subn in asc_range(0, total_n, split_n, name="_subn"):
        valid_n = Min(total_n - _subn, split_n)
        scale_b_offset = (_subn // 16) * total_k_blocks * 32
        l0a_tmp, l0b_tmp = _prepare_mx_l0_tensors(l0a, l0b, l1a, l1b, l0acnt, l0bcnt)

        with If(_subn == 0):
            if a_is_transpose:
                l1_to_l0_mx(
                    l0a_tmp,
                    l1a,
                    scale_a,
                    m_dst=total_k,
                    n_dst=total_m,
                    m_src=l1a.shape[0],
                    n_src=l1a.shape[1],
                )
            else:
                l1_to_l0_mx(
                    l0a_tmp,
                    l1a,
                    scale_a,
                    m_dst=total_m,
                    n_dst=total_k,
                    m_src=l1a.shape[0],
                    n_src=l1a.shape[1],
                )

        if b_is_transpose:
            l1b_tile = l1b[:, _subn : _subn + valid_n]
            l1_to_l0_mx(
                l0b_tmp,
                l1b_tile,
                scale_b,
                m_dst=total_k,
                n_dst=valid_n,
                m_src=l1b.shape[0],
                n_src=l1b.shape[1],
                src_mx_offset_element=scale_b_offset,
            )
        else:
            l1b_tile = l1b[_subn : _subn + valid_n, :]
            l1_to_l0_mx(
                l0b_tmp,
                l1b_tile,
                scale_b,
                m_dst=valid_n,
                n_dst=total_k,
                m_src=l1b.shape[0],
                n_src=l1b.shape[1],
                src_mx_offset_element=scale_b_offset,
            )

        # Each N-tile writes a distinct dst column range (its own is_init tile), so it
        # gets its own bias slice bias[:, _subn:_subn+valid_n] staged into a BT slot.
        bias_bt = None
        if bias is not None:
            bias_bt = _stage_bias_tile(bias, _subn, valid_n, btbuf, btbufcnt)

        sub_dst = dst[:, _subn : _subn + valid_n]
        # splitN writes disjoint L0C columns, so the caller's init flag applies
        # to every N slice instead of depending on _subn.
        emit_mmad_init(mmad_mx, sub_dst, l0a_tmp, l0b_tmp, is_init, bias=bias_bt, M=total_m, N=valid_n, K=total_k)

        if bias is not None:
            btbufcnt += 1
        l0bcnt += 1
    l0acnt += 1


def matmul_mx_splitk(
    dst: Tensor,
    l1a: Tensor,
    l1b: Tensor,
    scale_a: Tensor,
    scale_b: Tensor,
    l0a: DBuff,
    l0b: DBuff,
    l0acnt: Var,
    l0bcnt: Var,
    split_k: Union[int, Var],
    is_init: InitFlagType,
    m: Union[int, Var, None] = None,
    n: Union[int, Var, None] = None,
    k: Union[int, Var, None] = None,
    bias: Optional[Tensor] = None,
    btbuf: Optional[DBuff] = None,
    btbufcnt: Optional[Var] = None,
) -> None:
    total_m = m if m is not None else _a_logical_m(l1a)
    total_n = n if n is not None else _b_logical_n(l1b)
    total_k = k if k is not None else _a_logical_k(l1a)
    a_is_transpose = _is_transpose(l1a)
    if a_is_transpose:
        _validate_transposed_a_scale_tile(scale_a, total_m, total_k)
    else:
        _validate_16row_mx_scale_tile(scale_a, "scale_a")
    b_is_transpose = _is_transpose(l1b)
    if b_is_transpose:
        _validate_transposed_b_scale_tile(scale_b, total_n, total_k)
    else:
        _validate_16row_mx_scale_tile(scale_b, "scale_b")

    # The bias does not depend on k; stage the full row once and add it only on the
    # is_init K-tile (_subk == 0). btbufcnt is advanced after the loop, so every
    # in-loop reference to the slot resolves to the value it was loaded at.
    bias_bt = None
    if bias is not None:
        bias_bt = _stage_bias_tile(bias, 0, total_n, btbuf, btbufcnt)

    for _subk in asc_range(0, total_k, split_k, name="_subk"):
        valid_k = Min(total_k - _subk, split_k)
        scale_col0 = _subk // 32
        scale_cols = _mx_scale_cols_for_k(valid_k)
        l0a_tmp, l0b_tmp = _prepare_mx_l0_tensors(l0a, l0b, l1a, l1b, l0acnt, l0bcnt)
        if a_is_transpose:
            l1a_tile = l1a[_subk : _subk + valid_k, :]
            scale_a_offset = (_subk // 64) * 32
            l1_to_l0_mx(
                l0a_tmp,
                l1a_tile,
                scale_a,
                m_dst=valid_k,
                n_dst=total_m,
                m_src=l1a.shape[0],
                n_src=l1a.shape[1],
                src_mx_offset_element=scale_a_offset,
            )
        else:
            l1a_tile = l1a[:, _subk : _subk + valid_k]
            scale_a_tile = scale_a[:, scale_col0 : scale_col0 + scale_cols]
            l1_to_l0_mx(
                l0a_tmp,
                l1a_tile,
                scale_a_tile,
                m_dst=total_m,
                n_dst=valid_k,
                m_src=l1a.shape[0],
                n_src=l1a.shape[1],
            )
        if b_is_transpose:
            l1b_tile = l1b[_subk : _subk + valid_k, :]
            scale_b_offset = (_subk // 64) * 32
            l1_to_l0_mx(
                l0b_tmp,
                l1b_tile,
                scale_b,
                m_dst=valid_k,
                n_dst=total_n,
                m_src=l1b.shape[0],
                n_src=l1b.shape[1],
                src_mx_offset_element=scale_b_offset,
            )
        else:
            l1b_tile = l1b[:, _subk : _subk + valid_k]
            scale_b_tile = scale_b[:, scale_col0 : scale_col0 + scale_cols]
            l1_to_l0_mx(
                l0b_tmp,
                l1b_tile,
                scale_b_tile,
                m_dst=total_n,
                n_dst=valid_k,
                m_src=l1b.shape[0],
                n_src=l1b.shape[1],
            )
        if isinstance(is_init, (bool, int)):
            if bool(is_init):
                with If(_subk == 0):
                    mmad_mx(dst, l0a_tmp, l0b_tmp, M=total_m, N=total_n, K=valid_k, is_init=True, bias=bias_bt)
                with Else():
                    mmad_mx(dst, l0a_tmp, l0b_tmp, M=total_m, N=total_n, K=valid_k, is_init=False)
            else:
                mmad_mx(dst, l0a_tmp, l0b_tmp, M=total_m, N=total_n, K=valid_k, is_init=False)
        else:
            with If((_subk == 0) & is_init):
                mmad_mx(dst, l0a_tmp, l0b_tmp, M=total_m, N=total_n, K=valid_k, is_init=True, bias=bias_bt)
            with Else():
                mmad_mx(dst, l0a_tmp, l0b_tmp, M=total_m, N=total_n, K=valid_k, is_init=False)

        l0acnt += 1
        l0bcnt += 1
    if bias is not None:
        btbufcnt += 1


def matmul_mx(
    dst: Tensor,
    l1a: Tensor,
    l1b: Tensor,
    scale_a: Tensor,
    scale_b: Tensor,
    splitk: Union[int, Var, None] = None,
    m: Union[int, Var, None] = None,
    n: Union[int, Var, None] = None,
    k: Union[int, Var, None] = None,
    is_init: InitFlagType = True,
    *,
    splitn: Union[int, Var, None] = None,
    bias: Optional[Tensor] = None,
) -> None:
    _validate_matmul_mx_tensors(dst, l1a, l1b, scale_a, scale_b)
    if splitn is not None:
        _ensure_var_or_int(splitn, "splitn")
        _ensure_mx_splitn(splitn)
        if _is_transpose(l1b):
            _ensure_mx_transpose_splitn(splitn)
    if splitk is not None:
        _ensure_var_or_int(splitk, "splitk")
        _ensure_mx_splitk(splitk)
    if splitn is not None and splitk is not None:
        raise ValueError("splitn and splitk cannot both be set")
    if m is not None:
        _ensure_var_or_int(m, "m")
    if n is not None:
        _ensure_var_or_int(n, "n")
    if k is not None:
        _ensure_var_or_int(k, "k")
    _ensure_init_flag(is_init, "is_init")

    btbuf = btbufcnt = None
    if bias is not None:
        # MX matmul-with-bias (a5/950 C2 bias table): a contiguous [1, N] fp32 row in L1
        # added on the init tile so dst = scale_a*A @ (scale_b*B)^T + bias. Stage it with a
        # flat burst (gm_to_l1_pad or a layout=Layout.ND L1 tensor via <<=), NOT the default
        # nd2nz <<= (which fractalizes the row). MX inputs always accumulate into fp32, so
        # the bias is fp32 (no int8/int32 MX path). Requires is_init.
        if not isinstance(bias, Tensor):
            raise TypeError(f"bias must be Tensor, got: {type(bias)}")
        if bias.position is not Position.L1:
            raise ValueError(
                f"bias must be staged contiguously in L1 (gm_to_l1_pad), got: {bias.position}"
            )
        if bias.dtype is not DT.float:
            raise TypeError(f"matmul_mx bias only supports fp32 (MX inputs accumulate into fp32), got: {bias.dtype}")
        if isinstance(is_init, (bool, int)) and not bool(is_init):
            raise ValueError(
                "matmul_mx bias requires is_init (C = bias + A@B); an accumulate-only "
                "matmul (is_init=False) cannot add a bias"
            )
        btbuf, btbufcnt = _get_kernel_bt_buffer("matmul_mx")
        if splitn is not None:
            _validate_bt_tile_width(splitn, btbuf, "matmul_mx splitn")
        else:
            total_n = n if n is not None else _b_logical_n(l1b)
            _validate_bt_tile_width(total_n, btbuf, "matmul_mx")

    l0a, l0b, l0acnt, l0bcnt = _get_kernel_l0_buffers("matmul_mx")
    if splitn is not None:
        matmul_mx_splitn(dst, l1a, l1b, scale_a, scale_b, l0a, l0b, l0acnt, l0bcnt, splitn, is_init, m, n, k,
                         bias=bias, btbuf=btbuf, btbufcnt=btbufcnt)
        return
    if splitk is not None:
        matmul_mx_splitk(dst, l1a, l1b, scale_a, scale_b, l0a, l0b, l0acnt, l0bcnt, splitk, is_init, m, n, k,
                         bias=bias, btbuf=btbuf, btbufcnt=btbufcnt)
        return

    matmul_mx_nosplit(dst, l1a, l1b, scale_a, scale_b, l0a, l0b, l0acnt, l0bcnt, is_init, m, n, k,
                      bias=bias, btbuf=btbuf, btbufcnt=btbufcnt)


__all__ = ["matmul_mx"]
