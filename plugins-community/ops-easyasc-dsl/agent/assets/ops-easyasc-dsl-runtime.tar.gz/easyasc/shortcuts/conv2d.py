"""conv2d shortcut over the load3d img2col path (910B3-validated layouts).

Scope matches ``matmul``: L1 -> L0 -> mmad -> L0C only, for one M tile.

- img2col window K-tiling (l1_to_l0a_img2col), weight column tiling ([Cout, K]
  L1 NZ == B ZN), K accumulate into the caller's L0C tile.
- bias: an L1 [1, cout_p] fp32 row staged by the caller (flat ``gm_to_l1`` /
  ND-layout ``<<=``); routed through the kernel BT buffer (same as matmul).
- caller owns GM->L1, the m loop / multicore split, and L0C->GM (e.g.
  ``l0c_to_gm_nz2nz`` for NC1HWC0 output, NZ2ND ``<<=`` for ND). cout-tiling
  (loop conv2d into one shared L0C, store between calls, distinct bias per tile)
  is supported directly with a single reused ``Tensor`` L0C: conv2d closes both
  HW WAR hazards itself -- a ``PipeBarrier<PIPE_M>`` after each mmad (L0C reuse)
  and a ping-pong of the BT slot via ``btbufcnt`` (bias reuse). See the notes in
  the body; both are HW-verified to 12 cout-tiles (static + runtime) on 910B3.
- ``h``/``w``/``c``/``cout``/``m0`` may be Vars (runtime shapes). With a Var
  ``c`` the contraction depth K is a Var too, so ``tile_k`` becomes mandatory
  (static, must divide every runtime K) and the K loop runs as a runtime
  ``range`` tail after a static first tile (is_init + bias).

Host packers: easyasc.utils.conv2d.pack_nc1hwc0 / pack_conv_weight.
"""
from typing import Optional, Union

from ..flowcontrol import range as dsl_range
from ..flowcontrol import unroll
from ..stub_functions import l1_to_l0, mmad, reinterpret
from ..stub_functions.barrier import barrier
from ..stub_functions.cube import l1_to_l0a_img2col
from ..utils.Tensor import Tensor
from ..utils.conv2d import Conv2D, img2col
from ..utils.pipe import Pipe
from ..utils.positions import Position
from ..utils.var import Var
from ._common import _get_kernel_bt_buffer, _get_kernel_l0_buffers, _validate_bt_tile_width

ShapeDim = Union[int, Var]


def _a16(x: int) -> int:
    return (x + 15) // 16 * 16


def _pick_tile_k(K: int, cout_p: int, dtype_size: int, slot_kb: int = 32) -> int:
    # one kernel-DBuff slot = half the bank (depth-2)
    cap = slot_kb * 1024 // (cout_p * dtype_size)
    for t in range(min(K, cap // 16 * 16), 0, -16):
        if K % t == 0:
            return t
    return 16


def conv2d(l0c: Tensor, fmap: Tensor, weight: Tensor, conv: Conv2D,
           h: ShapeDim, w: ShapeDim, c: ShapeDim, cout: ShapeDim,
           m0: ShapeDim = 0,
           tile_k: Optional[int] = None,
           bias: Optional[Tensor] = None) -> None:
    """l0c[tile_m, cout_p] = img2col(fmap)[m0:m0+tile_m, :] @ weight.T (+ bias).

    fmap: L1 NC1HWC0 ([c1*h*w, C0]); weight: L1 [cout_p, K] (from <<= of host
    pack_conv_weight output); bias: L1 [1, cout_p] fp32 row (flat-staged).
    tile_m is l0c.shape[0]; the caller loops m0 / gates cores / stores L0C.
    Var dims: l0c/weight stay the static worst case; cout only widens the
    zero-padded column tail, so mmad always runs the full l0c width.
    """
    if not isinstance(l0c, Tensor) or l0c.position is not Position.L0C:
        raise ValueError("l0c must be an L0C Tensor")
    acc = img2col(fmap, conv, h=h, w=w, c=c)
    cout_p = _a16(cout) if isinstance(cout, int) else int(l0c.shape[1])
    tile_m = int(l0c.shape[0])
    if int(l0c.shape[1]) != cout_p:
        raise ValueError(f"l0c must be [tile_m, {cout_p}], got {l0c.shape}")
    if tile_m % 16:
        raise ValueError(f"tile_m must be 16-aligned, got {tile_m}")
    if weight.shape[0] != cout_p or (isinstance(acc.K, int) and weight.shape[1] != acc.K):
        raise ValueError(
            f"weight must be [{cout_p}, {acc.K}] (pack_conv_weight output), got {weight.shape}"
        )
    if tile_k is None:
        if not isinstance(acc.K, int):
            raise ValueError("tile_k is required when c is a Var (K is dynamic)")
        tile_k = _pick_tile_k(acc.K, cout_p, fmap.dtype.size)
    slot = 32 * 1024 // fmap.dtype.size            # kernel L0 DBuff slot capacity
    if tile_m * tile_k > slot or tile_k * cout_p > slot:
        raise ValueError(
            f"tile [{tile_m}x{tile_k}] / [{tile_k}x{cout_p}] exceeds the 32KB L0 slot"
        )
    # kernel-provided L0/BT DBuffs (matmul idiom): no tensor creation here, so
    # conv2d is legal inside If gates.
    l0abuf, l0bbuf, l0acnt, l0bcnt = _get_kernel_l0_buffers("conv2d")
    bt = btbuf = btbufcnt = None
    if bias is not None:
        if bias.position is not Position.L1:
            raise ValueError("bias must be an L1 [1, cout_p] row (flat-staged); see matmul")
        btbuf, btbufcnt = _get_kernel_bt_buffer("conv2d")
        _validate_bt_tile_width(cout_p, btbuf, "conv2d")
        bt = btbuf[btbufcnt]
        from ..stub_functions import l1_to_bt
        l1_to_bt(bt, bias, n=cout_p)

    def k_tile(k0, is_init, bias_t):
        nonlocal l0acnt, l0bcnt
        l0a = reinterpret(l0abuf[l0acnt], fmap.dtype)
        l0b = reinterpret(l0bbuf[l0bcnt], fmap.dtype)
        l1_to_l0a_img2col(l0a, acc.window(m0, k0, tile_m, tile_k))
        l1_to_l0(l0b, weight[:, k0:k0 + tile_k])
        mmad(l0c, l0a, l0b, M=tile_m, N=cout_p, K=tile_k,
             is_init=is_init, bias=bias_t)
        # L0C-reuse WAR fix (HW): the mmad cube unit must settle in-pipe before it can
        # switch modes; without a wait between cout-tiles sharing one L0C it corrupts the
        # next tile (undefined HW behaviour, not an autosync bug). PipeBarrier<PIPE_M>
        # after every mmad supplies that wait -- lightest sufficient (HW-verified to 12
        # tiles, static + runtime): FIX/M *before* mmad or FIX *after* store do NOT work;
        # only "PIPE_M after mmad" (or the heavier PIPE_ALL) closes it. Needs >=2 mmads/
        # tile (K accumulate); a single MMAD_BIAS alone never triggers it. (img2col path
        # only -- matmul's plain-load splitk does not need it, HW-verified.)
        barrier(Pipe.M)
        l0acnt += 1
        l0bcnt += 1

    if isinstance(acc.K, int):
        for k0 in unroll(0, acc.K, tile_k):
            k_tile(k0, k0 == 0, bt if k0 == 0 else None)
    else:
        # Var K: static first tile carries is_init/bias; runtime tail loop
        # (empty when K == tile_k) accumulates the rest.
        k_tile(0, True, bt)
        for k0 in dsl_range(tile_k, acc.K, tile_k):
            k_tile(k0, False, None)
    if bias is not None:
        # BT-slot ping-pong (matmul idiom): advance btbufcnt AFTER the consuming
        # (is_init) mmad, so back-to-back conv2d calls with DISTINCT bias (caller-tiled
        # cout) land on alternating depth-2 _btbuf slots -- closing the bias-reuse WAR
        # the same way matmul_nosplit does. The validated cout_p must fit one
        # device-specific BT slot. (Same bias restaged per m-tile is harmless either
        # way -- identical value -- so advancing never hurts.)
        btbufcnt += 1
