from typing import Callable, Tuple, Union

from .. import globvars
from ..flowcontrol import If, Else
from ..utils.Tensor import DBuff, Tensor
from ..utils.positions import Position
from ..utils.var import Expr, Var

InitFlagType = Union[bool, int, Var, Expr]
DimType = Union[int, Var]


def _is_transpose(tensor: Tensor) -> bool:
    return bool(getattr(tensor, "is_transpose", getattr(tensor, "is_trans", False)))


def _ensure_var_or_int(value: object, label: str) -> None:
    if not isinstance(value, (Var, int)):
        raise TypeError(f"{label} must be Var or int, got: {type(value)}")


def _ensure_init_flag(value: object, label: str) -> None:
    if not isinstance(value, (bool, int, Var, Expr)):
        raise TypeError(f"{label} must be bool, int, Var, or Expr, got: {type(value)}")


def _get_kernel_l0_buffers(who: str) -> Tuple[DBuff, DBuff, Var, Var]:
    if globvars.active_kernel is None:
        raise RuntimeError(f"{who} must be called inside a kernel")
    l0acnt = getattr(globvars.active_kernel, "_l0acnt", None)
    l0bcnt = getattr(globvars.active_kernel, "_l0bcnt", None)
    l0a = getattr(globvars.active_kernel, "_l0a", None)
    l0b = getattr(globvars.active_kernel, "_l0b", None)
    if l0acnt is None or l0bcnt is None:
        raise RuntimeError("active_kernel missing _l0acnt/_l0bcnt")
    if l0a is None or l0b is None:
        raise RuntimeError("active_kernel missing _l0a/_l0b")
    if not isinstance(l0a, DBuff) or l0a.position is not Position.L0A:
        raise TypeError(f"_l0a must be L0A DBuff, got: {type(l0a)} {getattr(l0a, 'position', None)}")
    if not isinstance(l0b, DBuff) or l0b.position is not Position.L0B:
        raise TypeError(f"_l0b must be L0B DBuff, got: {type(l0b)} {getattr(l0b, 'position', None)}")
    return l0a, l0b, l0acnt, l0bcnt


def _get_kernel_bt_buffer(who: str) -> Tuple[DBuff, Var]:
    if globvars.active_kernel is None:
        raise RuntimeError(f"{who} must be called inside a kernel")
    btbuf = getattr(globvars.active_kernel, "_btbuf", None)
    btbufcnt = getattr(globvars.active_kernel, "_btbufcnt", None)
    if btbuf is None or btbufcnt is None:
        raise RuntimeError("active_kernel missing _btbuf/_btbufcnt")
    if not isinstance(btbuf, DBuff) or btbuf.position is not Position.BT:
        raise TypeError(f"_btbuf must be BT DBuff, got: {type(btbuf)} {getattr(btbuf, 'position', None)}")
    return btbuf, btbufcnt


def _bt_slot_elements(btbuf: DBuff) -> int:
    shape = getattr(btbuf, "shape", None)
    if not isinstance(shape, (list, tuple)) or len(shape) != 2:
        raise RuntimeError(f"BT DBuff must have a static rank-2 slot shape, got: {shape!r}")
    if any(isinstance(dim, bool) or not isinstance(dim, int) for dim in shape):
        raise RuntimeError(f"BT DBuff slot shape must be static, got: {shape!r}")
    return int(shape[0]) * int(shape[1])


def _validate_bt_tile_width(width: DimType, btbuf: DBuff, who: str) -> None:
    capacity = _bt_slot_elements(btbuf)
    device = str(getattr(globvars, "device_type", "unknown"))
    if isinstance(width, bool) or not isinstance(width, int):
        raise ValueError(
            f"{who} bias required width {width!r} is not statically bounded on device {device}; "
            f"one BT slot holds {capacity} fp32/int32 elements. Use a static splitn tile."
        )
    if width > capacity:
        raise ValueError(
            f"{who} bias tile width {width} exceeds one BT slot on device {device}; "
            f"maximum is {capacity} fp32/int32 elements"
        )


def emit_mmad_init(mmad_fn: Callable, dst, a, b, is_init: InitFlagType, bias=None, **dims) -> None:
    """mmad with init flag: static bool/int emits directly; Var/Expr branches.

    A non-None ``bias`` (a BT/C2 tensor) is attached only to the is_init=True
    emission (``C = bias + A@B``); accumulate emissions omit it. When ``bias`` is
    None the bias kwarg is dropped entirely, so the call is byte-identical to the
    original bias-less path and works with mmad_fns that take no ``bias`` param
    (e.g. ``mmad_mx``)."""
    init_kwargs = dict(dims)
    if bias is not None:
        init_kwargs["bias"] = bias
    if isinstance(is_init, (bool, int)):
        if bool(is_init):
            mmad_fn(dst, a, b, is_init=True, **init_kwargs)
        else:
            mmad_fn(dst, a, b, is_init=False, **dims)
    else:
        with If(is_init):
            mmad_fn(dst, a, b, is_init=True, **init_kwargs)
        with Else():
            mmad_fn(dst, a, b, is_init=False, **dims)
