from typing import Optional

from ..utils.datatype import DataTypeValue, Datatype


CAST_INT_ROUND_MODES = frozenset([
    "CAST_RINT",
    "CAST_FLOOR",
    "CAST_CEIL",
    "CAST_ROUND",
    "CAST_TRUNC",
])
CAST_NONE_ONLY = frozenset(["CAST_NONE"])
CAST_INT_ROUND_MODES_WITH_NONE = CAST_INT_ROUND_MODES | CAST_NONE_ONLY
CAST_FLOAT_REDUCE_MODES = CAST_INT_ROUND_MODES | frozenset(["CAST_ODD", "CAST_NONE"])
CAST_FLOAT8_MODES = frozenset(["CAST_NONE", "CAST_RINT"])
CAST_HIF8_ENCODE_MODES = frozenset(["CAST_ROUND", "CAST_HYBRID"])
CAST_ANY_ROUND_MODE = CAST_FLOAT_REDUCE_MODES | frozenset(["CAST_HYBRID"])


A2_CAST_ROUND_MODES = {
    (Datatype.half, Datatype.float): CAST_NONE_ONLY,
    (Datatype.half, Datatype.int): CAST_INT_ROUND_MODES,
    (Datatype.half, Datatype.int16): CAST_INT_ROUND_MODES,
    (Datatype.half, Datatype.int8): CAST_INT_ROUND_MODES_WITH_NONE,
    (Datatype.half, Datatype.uint8): CAST_INT_ROUND_MODES_WITH_NONE,
    (Datatype.half, Datatype.int4): CAST_INT_ROUND_MODES_WITH_NONE,
    (Datatype.float, Datatype.float): CAST_INT_ROUND_MODES,
    (Datatype.float, Datatype.half): CAST_FLOAT_REDUCE_MODES,
    (Datatype.float, Datatype.int): CAST_INT_ROUND_MODES,
    (Datatype.float, Datatype.int64): CAST_INT_ROUND_MODES,
    (Datatype.float, Datatype.int16): CAST_INT_ROUND_MODES,
    (Datatype.float, Datatype.bfloat16): CAST_INT_ROUND_MODES,
    (Datatype.bfloat16, Datatype.float): CAST_NONE_ONLY,
    (Datatype.bfloat16, Datatype.int): CAST_INT_ROUND_MODES,
    (Datatype.int4, Datatype.half): CAST_NONE_ONLY,
    (Datatype.uint8, Datatype.half): CAST_NONE_ONLY,
    (Datatype.int8, Datatype.half): CAST_NONE_ONLY,
    (Datatype.int16, Datatype.half): CAST_INT_ROUND_MODES_WITH_NONE,
    (Datatype.int16, Datatype.float): CAST_NONE_ONLY,
    (Datatype.int, Datatype.float): CAST_INT_ROUND_MODES_WITH_NONE,
    (Datatype.int, Datatype.int16): CAST_NONE_ONLY,
    (Datatype.int, Datatype.int64): CAST_NONE_ONLY,
    (Datatype.int64, Datatype.int): CAST_NONE_ONLY,
    (Datatype.int64, Datatype.float): CAST_INT_ROUND_MODES,
}


# 64-bit cast support is COMPLETE here and board-verified: the Ascend950 (dav_c310)
# Cast trait `SupportType` (kernel_micro_vec_vconv_impl.h) lists exactly four 64-bit
# tuples -- int32<->int64 and float<->int64 -- all inherited from the A2 table above.
# There is NO uint64 cast and no half/int16/bf16/int8 <-> int64 pair on the hardware.
A5_CAST_ROUND_MODES = {
    pair: modes
    for pair, modes in A2_CAST_ROUND_MODES.items()
    if Datatype.int4 not in pair
}
A5_CAST_ROUND_MODES.update({
    (Datatype.float, Datatype.e4m3): CAST_FLOAT8_MODES,
    (Datatype.float, Datatype.e5m2): CAST_FLOAT8_MODES,
    (Datatype.float, Datatype.hif8): CAST_HIF8_ENCODE_MODES,
    (Datatype.half, Datatype.hif8): CAST_HIF8_ENCODE_MODES,
    (Datatype.e4m3, Datatype.float): CAST_NONE_ONLY,
    (Datatype.e5m2, Datatype.float): CAST_NONE_ONLY,
    (Datatype.hif8, Datatype.float): CAST_ANY_ROUND_MODE,
    (Datatype.hif8, Datatype.half): CAST_ANY_ROUND_MODE,
    (Datatype.bfloat16, Datatype.fp4_e2m1): CAST_INT_ROUND_MODES,
    (Datatype.bfloat16, Datatype.fp4_e1m2): CAST_INT_ROUND_MODES,
    (Datatype.fp4_e2m1, Datatype.bfloat16): CAST_NONE_ONLY,
    (Datatype.fp4_e1m2, Datatype.bfloat16): CAST_NONE_ONLY,
    # Direct 16-bit float<->float casts (same 128-lane width). Round modes match the
    # same-destination fp32 casts: ->bfloat16 like (float, bfloat16), ->half like (float, half).
    (Datatype.half, Datatype.bfloat16): CAST_INT_ROUND_MODES,
    (Datatype.bfloat16, Datatype.half): CAST_FLOAT_REDUCE_MODES,
})


def round_mode_name(round_mode: object) -> str:
    return str(getattr(round_mode, "name", round_mode))


def cast_round_modes(src_dtype: DataTypeValue, dst_dtype: DataTypeValue, target: str):
    if target == "a2":
        return A2_CAST_ROUND_MODES.get((src_dtype, dst_dtype))
    if target == "a5":
        return A5_CAST_ROUND_MODES.get((src_dtype, dst_dtype))
    raise ValueError("unknown cast target: " + str(target))


def validate_cast_pair(
    src_dtype: DataTypeValue,
    dst_dtype: DataTypeValue,
    target: str,
    round_mode: Optional[object] = None,
    validate_round_mode: bool = True,
) -> None:
    modes = cast_round_modes(src_dtype, dst_dtype, target)
    if modes is None:
        if target == "a5" and Datatype.int4 in (src_dtype, dst_dtype):
            raise ValueError(
                f"A5 micro cast does not support int4-related cast pair: {src_dtype} -> {dst_dtype}"
            )
        raise ValueError(
            f"{target.upper()} cast only supports listed Cast pairs, got: {src_dtype} -> {dst_dtype}"
        )
    if round_mode is None or not validate_round_mode:
        return
    mode_name = round_mode_name(round_mode)
    if mode_name not in modes:
        raise ValueError(
            f"{src_dtype} -> {dst_dtype} cast supports round_mode in "
            + ", ".join(sorted(modes))
            + f", got: {mode_name}"
        )


def should_force_none_round_mode(src_dtype: DataTypeValue, dst_dtype: DataTypeValue, target: str) -> bool:
    modes = cast_round_modes(src_dtype, dst_dtype, target)
    if modes != CAST_NONE_ONLY:
        return False
    try:
        return dst_dtype.size > src_dtype.size
    except ValueError:
        return False
