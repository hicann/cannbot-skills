from typing import Optional

from ..utils.instruction import Instruction
from ..utils.var import Var
from ..utils.datatype import Datatype, DataTypeValue
from .. import globvars
from .vec.vecutils import A2_A5_DEVICES, assert_valid_device


class atomic_add:
    def __init__(self, cond: Optional[Var] = None, dtype: DataTypeValue = Datatype.float):
        if cond is not None:
            raise NotImplementedError("current frameworkdoes not support conditional atomic_add")
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
        if dtype is not Datatype.float:
            raise NotImplementedError("current framework only supports floatatomictype")
        self.dtype = dtype

    def __enter__(self):
        assert_valid_device(A2_A5_DEVICES)
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_add can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_add"))
        globvars.atomic_enabled = True
        globvars.atomic_type = self.dtype

    def __exit__(self, exec_type, exec_val, exec_traceback):
        assert_valid_device(A2_A5_DEVICES)
        if exec_type:
            return False
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_add can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_end"))
        globvars.atomic_enabled = False
        globvars.atomic_type = None
        return True


class atomic_max:
    def __init__(self, dtype: DataTypeValue = Datatype.float):
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
        if dtype is not Datatype.float:
            raise NotImplementedError("current framework only supports floatatomictype")
        self.dtype = dtype

    def __enter__(self):
        assert_valid_device(A2_A5_DEVICES)
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_max can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_max"))
        globvars.atomic_enabled = True
        globvars.atomic_type = self.dtype

    def __exit__(self, exec_type, exec_val, exec_traceback):
        assert_valid_device(A2_A5_DEVICES)
        if exec_type:
            return False
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_max can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_end"))
        globvars.atomic_enabled = False
        globvars.atomic_type = None
        return True


class atomic_min:
    def __init__(self, dtype: DataTypeValue = Datatype.float):
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
        if dtype is not Datatype.float:
            raise NotImplementedError("current framework only supports floatatomictype")
        self.dtype = dtype

    def __enter__(self):
        assert_valid_device(A2_A5_DEVICES)
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_min can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_min"))
        globvars.atomic_enabled = True
        globvars.atomic_type = self.dtype

    def __exit__(self, exec_type, exec_val, exec_traceback):
        assert_valid_device(A2_A5_DEVICES)
        if exec_type:
            return False
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_min can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_end"))
        globvars.atomic_enabled = False
        globvars.atomic_type = None
        return True
