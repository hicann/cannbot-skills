from ..utils.instruction import Instruction
from ..utils.pipe import PipeType, Pipe
from .. import globvars
from .vec.vecutils import A2_A5_DEVICES, assert_valid_device


def barrier(pipe: PipeType) -> None:
    """Emit a hardware pipe-ordering barrier.

    A non-ALL barrier blocks later instructions only within the selected pipe.
    Simulator pipe workers already execute their mailbox in FIFO order, so the
    simulator bridge intentionally drops those barriers: adding a simulated
    wait would invent synchronization that the hardware primitive does not
    provide. ``Pipe.ALL`` is the separate cross-pipe drain case.
    """
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(pipe, PipeType):
        raise TypeError(f"pipe must be PipeType type, current type: {type(pipe)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("barrier", pipe=pipe)
        )


def bar_m() -> None:
    assert_valid_device(A2_A5_DEVICES)
    barrier(Pipe.M)


def bar_v() -> None:
    assert_valid_device(A2_A5_DEVICES)
    barrier(Pipe.V)


def bar_mte3() -> None:
    assert_valid_device(A2_A5_DEVICES)
    barrier(Pipe.MTE3)


def bar_mte2() -> None:
    assert_valid_device(A2_A5_DEVICES)
    barrier(Pipe.MTE2)


def bar_mte1() -> None:
    assert_valid_device(A2_A5_DEVICES)
    barrier(Pipe.MTE1)


def bar_fix() -> None:
    assert_valid_device(A2_A5_DEVICES)
    barrier(Pipe.FIX)


def bar_all() -> None:
    assert_valid_device(A2_A5_DEVICES)
    barrier(Pipe.ALL)
