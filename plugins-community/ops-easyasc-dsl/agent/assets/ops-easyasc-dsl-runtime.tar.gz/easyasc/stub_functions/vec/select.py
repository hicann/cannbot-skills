from typing import Union

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ...utils.selectmode import SelectModeType
from ... import globvars
from .vecutils import (
    A2_DEVICES,
    assert_valid_device,
    ensure_repeat_mode,
    infer_repeat,
    resolve_strides,
    validate_var_or_int,
)


def _validate_selmask(selmask) -> None:
    if not isinstance(selmask, Tensor):
        raise TypeError(f"selmask must be Tensor, current type: {type(selmask)}")
    if selmask.dtype not in (Datatype.uint8,):
        raise ValueError(f"selmask data type is not supported, current type: {selmask.dtype}")


def _addr_component(value) -> str:
    if isinstance(value, Var):
        return "var:" + value.name
    return str(value)


def _same_tensor_address(lhs: Tensor, rhs: Tensor) -> bool:
    lhs_key = getattr(lhs, "storage_key_name", lhs.name)
    rhs_key = getattr(rhs, "storage_key_name", rhs.name)
    if lhs_key != rhs_key:
        return False
    lhs_index = getattr(lhs, "source_index", None)
    rhs_index = getattr(rhs, "source_index", None)
    if _addr_component(lhs_index) != _addr_component(rhs_index):
        return False
    lhs_offset = tuple(_addr_component(v) for v in getattr(lhs, "offset", []))
    rhs_offset = tuple(_addr_component(v) for v in getattr(rhs, "offset", []))
    return lhs_offset == rhs_offset


def select(
    dst: Tensor,
    selmask: Tensor,
    src1: Tensor,
    src2: Tensor,
    mode: SelectModeType,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    tmp_addr_buf: Union[Tensor, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src1, Tensor):
        raise TypeError(f"src1 must be Tensor type, current type: {type(src1)}")
    if not isinstance(src2, Tensor):
        raise TypeError(f"src2 must be Tensor type, current type: {type(src2)}")
    if not isinstance(mode, SelectModeType):
        raise TypeError(f"mode must be SelectModeType, current type: {type(mode)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src1.position is not Position.UB:
        raise ValueError(f"src1 must be at UB position, current position: {src1.position}")
    if src2.position is not Position.UB:
        raise ValueError(f"src2 must be at UB position, current position: {src2.position}")
    if dst.dtype != src1.dtype:
        raise ValueError("dst/src1 data types must match")
    if src2.dtype != dst.dtype:
        raise ValueError("src2 and dst data types must match")
    if dst.dtype not in (Datatype.float, Datatype.half, Datatype.int16, Datatype.int):
        raise ValueError(f"dst data type is not supported, current type: {dst.dtype}")
    _validate_selmask(selmask)
    if mode.name == "TENSOR_TENSOR":
        # TENSOR_TENSOR uses a per-repeat selMask (mode 2): the hardware reads the selMask
        # bits via an *address* held in the cmpmask SPR, and SetCmpMask loads that SPR from
        # UB, so the selMask address must first be staged into a UB buffer. easyasc requires
        # the caller to supply that scratch EXPLICITLY via `tmp_addr_buf`; it deliberately
        # does NOT fall back to CANN's implicit TMP_UB_OFFSET region (184-192 KB on a2),
        # because that occupies UB outside easyasc's accounting and can clobber user tensors.
        # Pass a uint32 UB buffer you own, >= one 32B block (8 uint32 lanes). The parser stages
        # the address with Duplicate's count overload (writes exactly 8 uint32), and SetCmpMask
        # reads at most a 128-bit (16 B) SPR, so 32 B is sufficient.
        if _same_tensor_address(dst, src1) or _same_tensor_address(dst, src2):
            raise ValueError("SelectMode.TENSOR_TENSOR requires dst address to differ from src1 and src2")
        if tmp_addr_buf is None:
            raise ValueError(
                "SelectMode.TENSOR_TENSOR requires an explicit `tmp_addr_buf`: a uint32 UB "
                "Tensor of >= 8 lanes (one 32 B block) to stage the selMask address. easyasc does "
                "not implicitly borrow CANN's TMP_UB_OFFSET scratch (that would occupy UB outside "
                "easyasc's allocation and risk clobbering user data)."
            )
        if not isinstance(tmp_addr_buf, Tensor):
            raise TypeError(f"tmp_addr_buf must be Tensor, current type: {type(tmp_addr_buf)}")
        if tmp_addr_buf.position is not Position.UB:
            raise ValueError(f"tmp_addr_buf must be at UB position, current position: {tmp_addr_buf.position}")
        if tmp_addr_buf.dtype != Datatype.uint32:
            raise ValueError(f"tmp_addr_buf must be uint32 dtype, current type: {tmp_addr_buf.dtype}")
        # The Duplicate count overload stages the address with exactly 8 uint32 (one 32B block);
        # a smaller buffer overflows into neighbouring UB on HW. The simulator uses `selmask`
        # directly and would NOT catch an undersized tmp_addr_buf, so enforce the size here.
        _ta_shape = list(getattr(tmp_addr_buf, "shape", []) or [])
        if _ta_shape and all(isinstance(d, int) for d in _ta_shape):
            _ta_numel = 1
            for _d in _ta_shape:
                _ta_numel *= _d
            if _ta_numel < 8:
                raise ValueError(
                    f"tmp_addr_buf must hold >= 8 uint32 (one 32B block); got {_ta_numel} "
                    "element(s). The Duplicate count overload writes 8 uint32 and a smaller "
                    "buffer overflows neighbouring UB on HW (the simulator won't catch this)."
                )
    elif tmp_addr_buf is not None:
        raise ValueError("tmp_addr_buf is only used by SelectMode.TENSOR_TENSOR")

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    ensure_repeat_mode()

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "select",
                dst=dst,
                mode=mode,
                selmask=selmask,
                src1=src1,
                src2=src2,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                src1_blk_stride=src1_blk_stride,
                src2_blk_stride=src2_blk_stride,
                dst_rep_stride=dst_rep_stride,
                src1_rep_stride=src1_rep_stride,
                src2_rep_stride=src2_rep_stride,
                tmp_addr_buf=tmp_addr_buf,
            )
        )
