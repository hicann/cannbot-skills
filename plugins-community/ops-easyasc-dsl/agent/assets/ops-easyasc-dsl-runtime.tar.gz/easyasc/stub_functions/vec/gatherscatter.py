from typing import Union

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import (
    A2_DEVICES,
    assert_valid_device,
    apply_vector_mode_transition,
    ensure_repeat_mode,
    infer_repeat,
    resolve_strides,
    validate_var_or_int,
)


_gather_unit_warning = True


def _warn_gather_byte_units() -> None:
    global _gather_unit_warning
    if _gather_unit_warning:
        print("Usage reminder: gather/scatter offset and start_idx are both in bytes.")
        _gather_unit_warning = False


def _reject_count_mode(op: str, count) -> None:
    """count-mode gather/scatter is a sim-only path: it diverges on real A2/c220.

    codegen count mode emits AscendC's Level-2 ``Gather/Scatter(dst, src, offset,
    base, count)`` overload. On c220 that overload splits ``count`` into
    ``repeat = count / 64`` full repeats plus a tail, and forwards the per-repeat
    element count (64) into the Level-0 gather's scalar ``mask`` argument -- but
    that ``mask`` is a *bitmask*, so ``64`` (0x40) activates a single lane instead
    of 64. The gather then reads/writes the wrong lanes on real hardware, while the
    simulator (which models count mode as a clean per-element loop) still passes.
    Repeat mode emits the Level-0 overload with ``VECTORFULLMASK`` (all-ones) and
    is correct, so require it here rather than silently diverge sim vs HW."""
    if count is not None:
        raise ValueError(
            op + ": count-mode (count=...) is not supported -- it silently gathers "
            "the wrong lanes on real A2/c220 while passing in the simulator. Use "
            "repeat mode instead: " + op + "(dst, src, offset, repeat=CeilDiv(N, "
            "lanes), dst_rep_stride=8), where lanes = 256 // dtype.size (64 for "
            "fp32/int32, 128 for fp16/bf16)."
        )


def gather(
    dst: Tensor,
    src: Tensor,
    offset: Tensor,
    start_idx: Union[int, Var] = 0,
    repeat: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _reject_count_mode("gather", count)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(offset, Tensor):
        raise TypeError(f"offset must be Tensor type, current type: {type(offset)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if offset.position is not Position.UB:
        raise ValueError(f"offset must be at UB position, current position: {offset.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if offset.dtype is not Datatype.uint32:
        raise ValueError(f"offset must be uint32 type, current type: {offset.dtype}")
    if repeat is None:
        repeat = infer_repeat(dst)
    if dst_rep_stride is None:
        _, dst_rep_stride = resolve_strides(dst, None, None)

    validate_var_or_int(start_idx, "start_idx")
    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")

    apply_vector_mode_transition(count)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gather",
                dst=dst,
                src=src,
                offset=offset,
                start_idx=start_idx,
                repeat=repeat,
                dst_rep_stride=dst_rep_stride,
                count=count,
            )
        )
    _warn_gather_byte_units()


def gather_block(
    dst: Tensor,
    src: Tensor,
    offset: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
) -> None:
    """Block gather (AscendC ``Gatherb``).

    Each repeat gathers 8 contiguous 32B DataBlocks selected by ``offset`` -- one
    32B-aligned byte address per block (8 offsets per repeat). Unlike element
    ``gather`` (1 offset -> 1 element), here 1 offset -> 1 whole block (``32 //
    dtype.size`` elements). The "8 blocks per repeat" is the fixed 256B hardware
    vector width, not a tunable; the only knobs are the dst strides (in 32B-block
    units): ``dst_blk_stride`` between blocks within a repeat, ``dst_rep_stride``
    between repeats. Defaults follow the dst layout (contiguous -> 1 / 8).
    """
    assert_valid_device(A2_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(offset, Tensor):
        raise TypeError(f"offset must be Tensor type, current type: {type(offset)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if offset.position is not Position.UB:
        raise ValueError(f"offset must be at UB position, current position: {offset.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if offset.dtype is not Datatype.uint32:
        raise ValueError(f"offset must be uint32 type, current type: {offset.dtype}")
    if repeat is None:
        repeat = infer_repeat(dst)
    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")

    # Gatherb is repeat-based only (no count mode); make sure the pipe is back in
    # repeat/normal mask mode before emitting, like brcb.
    ensure_repeat_mode()

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gather_block",
                dst=dst,
                src=src,
                offset=offset,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                dst_rep_stride=dst_rep_stride,
            )
        )


def scatter(
    dst: Tensor,
    src: Tensor,
    offset: Tensor,
    start_idx: Union[int, Var] = 0,
    repeat: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _reject_count_mode("scatter", count)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(offset, Tensor):
        raise TypeError(f"offset must be Tensor type, current type: {type(offset)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if offset.position is not Position.UB:
        raise ValueError(f"offset must be at UB position, current position: {offset.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if offset.dtype is not Datatype.uint32:
        raise ValueError(f"offset must be uint32 type, current type: {offset.dtype}")
    if repeat is None:
        repeat = infer_repeat(src)
    if src_rep_stride is None:
        _, src_rep_stride = resolve_strides(src, None, None)

    validate_var_or_int(start_idx, "start_idx")
    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "scatter",
                dst=dst,
                src=src,
                offset=offset,
                start_idx=start_idx,
                repeat=repeat,
                src_rep_stride=src_rep_stride,
                count=count,
            )
        )
