from typing import List, Optional, Sequence, Tuple, Union

from ...utils.Tensor import Tensor, GMTensor
from ...utils.var import Var
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from ...device_profile import is_c220_family
from .vecutils import A2_A5_DEVICES, A5_DEVICES, assert_valid_device, validate_var_or_int
from ..var_op import CeilDiv


def _dim_product(dims: List[Union[int, Var]]) -> Union[int, Var]:
    out: Union[int, Var] = 1
    for dim in dims:
        validate_var_or_int(dim, "dim")
        out = out * dim
    return out


def _same_dim(a: Union[int, Var], b: Union[int, Var]) -> bool:
    return str(a) == str(b)


def _known_int(value: object) -> Union[int, None]:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, Var) and isinstance(value.value, int):
        return value.value
    return None


def _validate_c220_datacopy_pad_n_burst(n_burst: object, opname: str) -> None:
    if not is_c220_family(globvars.device_type):
        return
    value = _known_int(n_burst)
    if value is not None and not 0 <= value <= 4095:
        raise ValueError(f"{opname} on C220 requires n_burst in [0, 4095], got {value}")


def _is_rank1_gm_view(tensor: GMTensor) -> bool:
    return len(list(tensor.shape)) == 1


def _infer_gm_transpose_transfer(
    tensor: GMTensor,
    context: str,
) -> Tuple[Union[int, Var], Union[int, Var], Union[int, Var]]:
    shape = list(tensor.shape)
    span = list(tensor.span if hasattr(tensor, "span") else tensor.shape)
    slice_mask = list(getattr(tensor, "slice_mask", [True for _ in shape]))

    if len(shape) != 2:
        raise ValueError(f"{context} requires a rank-2 GM tensor, got rank {len(shape)}")

    slice_dims = [idx for idx, flag in enumerate(slice_mask) if flag]
    if len(slice_dims) == 2:
        row_dim, col_dim = slice_dims
        if row_dim != 0 or col_dim != 1:
            raise ValueError(f"{context} requires a standard 2D row/col GM slice")
        src_rows = span[row_dim]
        src_cols = span[col_dim]
        src_row_stride = shape[col_dim]
        return src_rows, src_cols, src_row_stride

    if len(slice_dims) == 1:
        dim = slice_dims[0]
        if dim == len(shape) - 1:
            src_rows = 1
            src_cols = span[dim]
            src_row_stride = shape[dim]
            return src_rows, src_cols, src_row_stride
        src_rows = span[dim]
        src_cols = 1
        src_row_stride = shape[1]
        return src_rows, src_cols, src_row_stride

    raise ValueError(f"{context} requires at least one sliced dimension on the GM tensor")


def _infer_gm_transfer(
    tensor: GMTensor,
    context: str,
) -> Tuple[Union[int, Var], Union[int, Var], Union[int, Var]]:
    shape = list(tensor.shape)
    span = list(tensor.span if hasattr(tensor, "span") else tensor.shape)
    slice_mask = list(getattr(tensor, "slice_mask", [True for _ in shape]))

    if len(shape) == 1:
        return 1, span[0], 0

    if len(shape) == 2:
        return span[0], span[1], shape[1] - span[1]

    slice_dims = [idx for idx, flag in enumerate(slice_mask) if flag]
    if len(slice_dims) == 0:
        raise ValueError(f"{context} default inference for rank>2 requires at least one sliced dimension")
    if len(slice_dims) > 2:
        raise ValueError(f"{context} default inference supports at most 2 sliced dimensions")

    if len(slice_dims) == 1:
        outer_dim = slice_dims[0]
        if outer_dim == len(shape) - 1:
            return 1, span[outer_dim], 0
        burst_len = _dim_product(span[outer_dim + 1 :])
        dst_step = _dim_product(shape[outer_dim + 1 :])
        return span[outer_dim], burst_len, dst_step - burst_len

    outer_dim, inner_dim = slice_dims
    trailing_shape = shape[inner_dim + 1 :]
    trailing_span = span[inner_dim + 1 :]
    for shape_dim, span_dim in zip(trailing_shape, trailing_span):
        if not _same_dim(shape_dim, span_dim):
            raise ValueError(
                f"{context} default inference requires the innermost sliced dimension "
                "to cover the contiguous suffix of the GM view"
            )
    burst_len = _dim_product(span[inner_dim:])
    dst_step = _dim_product(shape[outer_dim + 1 :])
    return span[outer_dim], burst_len, dst_step - burst_len


def gm_to_ub_pad(
    dst: Tensor,
    src: GMTensor,
    n_burst: Union[int, Var, None] = None,
    burst_len_element: Union[int, Var, None] = None,
    src_stride_element: Union[int, Var, None] = None,
    dst_stride: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    is_rank1_gm_view = _is_rank1_gm_view(src)
    if n_burst is None or burst_len_element is None or src_stride_element is None:
        auto_n_burst, auto_burst_len_element, auto_src_stride_element = _infer_gm_transfer(
            src,
            "gm_to_ub_pad",
        )
    else:
        auto_n_burst = None
        auto_burst_len_element = None
        auto_src_stride_element = None
    if n_burst is None:
        n_burst = auto_n_burst
    if burst_len_element is None:
        burst_len_element = auto_burst_len_element
    if src_stride_element is None:
        src_stride_element = auto_src_stride_element
    if dst_stride is None:
        if is_rank1_gm_view:
            dst_stride = 0
        else:
            shape1 = dst.shape[1]
            validate_var_or_int(shape1, "dst.shape[1]")
            dst_stride = (shape1 - burst_len_element) // dst.dtype.C0
    if n_burst is None or burst_len_element is None or src_stride_element is None or dst_stride is None:
        raise ValueError("gm_to_ub_padparameter inference failed") 
    validate_var_or_int(n_burst, "n_burst")
    validate_var_or_int(burst_len_element, "burst_len_element")
    validate_var_or_int(src_stride_element, "src_stride_element")
    validate_var_or_int(dst_stride, "dst_stride")
    _validate_c220_datacopy_pad_n_burst(n_burst, "gm_to_ub_pad")

    burst_len_byte = burst_len_element * dst.dtype.size
    src_stride_byte = src_stride_element * dst.dtype.size

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_ub_pad",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len_byte=burst_len_byte,
                src_stride_byte=src_stride_byte,
                dst_stride=dst_stride,
            )
        )


def _normalize_nd_dma_sequence(
    values: Sequence[Union[int, Var]],
    label: str,
    dim: int,
) -> Tuple[Union[int, Var], ...]:
    seq = tuple(values)
    if len(seq) != dim:
        raise ValueError(f"{label} must have length {dim}, got {len(seq)}")
    for value in seq:
        validate_var_or_int(value, label)
    return seq


def _normalize_nd_dma_padding(
    values: Optional[Sequence[Union[int, Var]]],
    label: str,
    dim: int,
) -> Tuple[Union[int, Var], ...]:
    if values is None:
        return tuple(0 for _ in range(dim))
    return _normalize_nd_dma_sequence(values, label, dim)


def _validate_nd_dma_config_pad(value: Optional[int], label: str) -> None:
    if value is None:
        return
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{label} must be int or None, got {type(value)}")
    if value < 0 or value > 255:
        raise ValueError(f"{label} must be in [0, 255], got {value}")


def gm_to_ub_nd_dma(
    dst: Tensor,
    src: GMTensor,
    loop_src_stride: Sequence[Union[int, Var]],
    loop_dst_stride: Sequence[Union[int, Var]],
    loop_size: Sequence[Union[int, Var]],
    loop_left_pad: Optional[Sequence[Union[int, Var]]] = None,
    loop_right_pad: Optional[Sequence[Union[int, Var]]] = None,
    constant_value: Union[int, float, Var] = 0,
    nearest_value_mode: bool = False,
    config_left_pad: Optional[int] = None,
    config_right_pad: Optional[int] = None,
    asc_optimize: bool = False,
    fence: str = "all",
) -> None:
    """A5-only GM -> UB multi-dimensional DMA (AscendC NdDma / ISASI).

    The stride/size/padding arrays follow the AscendC contract: index 0 is the
    innermost dimension and index ``dim - 1`` is the outermost dimension.

    ``fence`` picks how the transfer is closed off:

    ``"all"``
        Emit ``PipeBarrier<PIPE_ALL>()`` after the copy. Conservative, and the
        default because it is what every existing caller was written against,
        but it drains the whole core and so forbids any overlap between this
        load and a neighbouring store.
    ``"mte2"``
        Emit nothing extra and let the transfer be sequenced as a normal MTE2
        load. This matches CANN's own ND DMA users: the arch35
        ``StridedSliceNDDMA`` template pairs the copy with a plain
        ``TQueBind`` ``EnQue``/``DeQue`` and ``cumsum`` with a
        ``SetFlag``/``WaitFlag<HardEvent::MTE2_V>`` pair -- neither uses a
        pipe barrier. Verify on real hardware before switching a kernel over.
    """
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if not isinstance(nearest_value_mode, bool):
        raise TypeError(f"nearest_value_mode must be bool, got {type(nearest_value_mode)}")
    if not isinstance(asc_optimize, bool):
        raise TypeError(f"asc_optimize must be bool, got {type(asc_optimize)}")
    if asc_optimize:
        raise NotImplementedError("gm_to_ub_nd_dma does not support asc_optimize=True")
    if fence not in ("all", "mte2"):
        raise ValueError(f"gm_to_ub_nd_dma fence must be 'all' or 'mte2', got {fence!r}")

    dim = len(tuple(loop_size))
    if dim < 1 or dim > 5:
        raise ValueError(f"gm_to_ub_nd_dma requires 1 <= dim <= 5, got {dim}")

    loop_src_stride = _normalize_nd_dma_sequence(loop_src_stride, "loop_src_stride", dim)
    loop_dst_stride = _normalize_nd_dma_sequence(loop_dst_stride, "loop_dst_stride", dim)
    loop_size = _normalize_nd_dma_sequence(loop_size, "loop_size", dim)
    loop_left_pad = _normalize_nd_dma_padding(loop_left_pad, "loop_left_pad", dim)
    loop_right_pad = _normalize_nd_dma_padding(loop_right_pad, "loop_right_pad", dim)
    _validate_nd_dma_config_pad(config_left_pad, "config_left_pad")
    _validate_nd_dma_config_pad(config_right_pad, "config_right_pad")

    if dst.dtype.size == 8 and nearest_value_mode:
        raise ValueError("gm_to_ub_nd_dma b64 path requires nearest_value_mode=False")
    if dst.dtype.size == 8 and constant_value not in (0, 0.0):
        raise ValueError("gm_to_ub_nd_dma b64 path requires constant_value=0")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_ub_nd_dma",
                dst=dst,
                src=src,
                dim=dim,
                loop_src_stride=loop_src_stride,
                loop_dst_stride=loop_dst_stride,
                loop_size=loop_size,
                loop_left_pad=loop_left_pad,
                loop_right_pad=loop_right_pad,
                constant_value=constant_value,
                nearest_value_mode=nearest_value_mode,
                config_left_pad=config_left_pad,
                config_right_pad=config_right_pad,
                asc_optimize=asc_optimize,
                fence=fence,
            )
        )


def gm_to_ub_nd_dma_transpose(dst: Tensor, src: GMTensor) -> None:
    """A5-only GM -> UB transpose sugar backed by ND DMA.

    The GM slice determines the moved block. A source slice `[rows, cols]` lands in
    UB as a logical `[cols, rows]` transpose starting from the destination view's
    current offset.
    """
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")

    src_rows, src_cols, src_row_stride = _infer_gm_transpose_transfer(src, "gm_to_ub_nd_dma_transpose")
    dst_row_stride = dst.shape[1]
    validate_var_or_int(dst_row_stride, "dst.shape[1]")

    gm_to_ub_nd_dma(
        dst,
        src,
        loop_src_stride=[src_row_stride, 1],
        loop_dst_stride=[1, dst_row_stride],
        loop_size=[src_rows, src_cols],
    )


def ub_to_gm_pad(
    dst: GMTensor,
    src: Tensor,
    n_burst: Union[int, Var, None] = None,
    burst_len_element: Union[int, Var, None] = None,
    src_stride: Union[int, Var, None] = None,
    dst_stride_element: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"dst must be GMTensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    is_rank1_gm_view = _is_rank1_gm_view(dst)
    if n_burst is None or burst_len_element is None or dst_stride_element is None:
        auto_n_burst, auto_burst_len, auto_dst_stride = _infer_gm_transfer(
            dst,
            "ub_to_gm_pad",
        )
    else:
        auto_n_burst = None
        auto_burst_len = None
        auto_dst_stride = None
    if n_burst is None:
        n_burst = auto_n_burst
    if burst_len_element is None:
        if auto_burst_len is None:
            raise ValueError("ub_to_gm_pad parameter inference failed for burst_len_element")
        burst_len_element = auto_burst_len
    if dst_stride_element is None:
        if auto_dst_stride is None:
            raise ValueError("ub_to_gm_pad parameter inference failed for dst_stride_element")
        dst_stride_element = auto_dst_stride
    if src_stride is None:
        if is_rank1_gm_view:
            src_stride = 0
        else:
            src_shape1 = src.shape[1]
            validate_var_or_int(src_shape1, "src.shape[1]")
            src_stride = (src_shape1 - burst_len_element) // src.dtype.C0
    if n_burst is None or burst_len_element is None or src_stride is None or dst_stride_element is None:
        raise ValueError("ub_to_gm_padparameter inference failed") 
    validate_var_or_int(n_burst, "n_burst")
    validate_var_or_int(burst_len_element, "burst_len_element")
    validate_var_or_int(src_stride, "src_stride")
    validate_var_or_int(dst_stride_element, "dst_stride_element")
    _validate_c220_datacopy_pad_n_burst(n_burst, "ub_to_gm_pad")

    burst_len_byte = burst_len_element * src.dtype.size
    dst_stride_byte = dst_stride_element * src.dtype.size

    if globvars.active_kernel is not None:
        if globvars.atomic_enabled and globvars.atomic_type is not dst.dtype:
            globvars.active_kernel.instructions.append(
                Instruction("set_atomic_type", dtype=dst.dtype)
            )
            globvars.atomic_type = dst.dtype
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_gm_pad",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len_byte=burst_len_byte,
                src_stride=src_stride,
                dst_stride_byte=dst_stride_byte,
            )
        )


def ub_to_l1_nd2nz(
    dst: Tensor,
    src: Tensor,
    m_dst: Union[int, Var, None] = None,
    n_dst: Union[int, Var, None] = None,
    m_src: Union[int, Var, None] = None,
    n_src: Union[int, Var, None] = None,
    N_src: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")

    dst_span = dst.span if hasattr(dst, "span") else dst.shape
    src_span = src.span if hasattr(src, "span") else src.shape
    if m_dst is None:
        m_dst = dst.shape[0]
    if n_dst is None:
        n_dst = dst_span[1]
    if m_src is None:
        m_src = src_span[0]
    if n_src is None:
        n_src = src_span[1]
    if N_src is None:
        N_src = src.shape[1]

    validate_var_or_int(m_dst, "m_dst")
    validate_var_or_int(n_dst, "n_dst")
    validate_var_or_int(m_src, "m_src")
    validate_var_or_int(n_src, "n_src")
    validate_var_or_int(N_src, "N_src")

    if globvars.active_kernel is not None:
        dst_row0 = dst.offset[0] if hasattr(dst, "offset") else 0
        dst_col0 = dst.offset[1] if hasattr(dst, "offset") else 0
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_l1_nd2nz",
                dst=dst,
                src=src,
                m_dst=m_dst,
                n_dst=n_dst,
                m_src=m_src,
                n_src=n_src,
                N_src=N_src,
                dst_row0=dst_row0,
                dst_col0=dst_col0,
            )
        )


def ub_to_l1_nz(
    dst: Tensor,
    src: Tensor,
    m_dst: Union[int, Var, None] = None,
    n_dst: Union[int, Var, None] = None,
    m_src: Union[int, Var, None] = None,
    n_src: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")

    dst_span = dst.span if hasattr(dst, "span") else dst.shape
    src_span = src.span if hasattr(src, "span") else src.shape
    if m_dst is None:
        m_dst = dst.shape[0]
    if n_dst is None:
        n_dst = dst_span[1]
    if m_src is None:
        m_src = src_span[0]
    if n_src is None:
        n_src = src_span[1]

    validate_var_or_int(m_dst, "m_dst")
    validate_var_or_int(n_dst, "n_dst")
    validate_var_or_int(m_src, "m_src")
    validate_var_or_int(n_src, "n_src")

    # M_src = physical fractal-row stride = src.shape[0] (unchanged by row-slicing); m_src is the
    # view span (rows actually copied). UB2L1_NZ uses srcStride = M_src - m_src to skip per-fractal
    # padding rows. Full-tile src (shape == span) -> M_src == m_src -> srcStride 0 (back-compat).
    src_shape = src.shape if hasattr(src, "shape") else src_span
    M_src = src_shape[0]
    if globvars.active_kernel is not None:
        dst_row0 = dst.offset[0] if hasattr(dst, "offset") else 0
        dst_col0 = dst.offset[1] if hasattr(dst, "offset") else 0
        # src col/row offsets (a sliced UB src like ub_p[:, 64:128]); codegen folds these into
        # src_expr, but the sim builds the src view at the parent base and needs them explicitly.
        src_row0 = src.offset[0] if hasattr(src, "offset") else 0
        src_col0 = src.offset[1] if hasattr(src, "offset") else 0
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_l1_nz",
                dst=dst,
                src=src,
                m_dst=m_dst,
                n_dst=n_dst,
                m_src=m_src,
                n_src=n_src,
                M_src=M_src,
                dst_row0=dst_row0,
                dst_col0=dst_col0,
                src_row0=src_row0,
                src_col0=src_col0,
            )
        )


def ub_to_l1(
    dst: Tensor,
    src: Tensor,
    n_burst: Union[int, Var, None] = None,
    burst_len: Union[int, Var, None] = None,
    src_stride: Union[int, Var, None] = None,
    dst_stride: Union[int, Var, None] = None,
) -> None:
    """
    Raw UB to L1 DataCopy. n_burst, burst_len, src_stride, and dst_stride use
    the hardware 32-byte block unit.
    """
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")

    dst_span = dst.span if hasattr(dst, "span") else dst.shape
    src_span = src.span if hasattr(src, "span") else src.shape
    if n_burst is None:
        n_burst = dst_span[0] if len(dst_span) > 1 else 1
    if burst_len is None:
        width = dst_span[1] if len(dst_span) > 1 else dst_span[0]
        validate_var_or_int(width, "copy width")
        burst_len = CeilDiv(width, dst.dtype.C0)
    if dst_stride is None:
        if len(dst.shape) > 1:
            dst_width = dst.shape[1]
            span_width = dst_span[1]
            validate_var_or_int(dst_width, "dst.shape[1]")
            validate_var_or_int(span_width, "dst.span[1]")
            dst_stride = CeilDiv(dst_width - span_width, dst.dtype.C0)
        else:
            dst_stride = 0
    if src_stride is None:
        if len(src.shape) > 1:
            src_width = src.shape[1]
            span_width = src_span[1]
            validate_var_or_int(src_width, "src.shape[1]")
            validate_var_or_int(span_width, "src.span[1]")
            src_stride = CeilDiv(src_width - span_width, src.dtype.C0)
        else:
            src_stride = 0
    if n_burst is None or burst_len is None or src_stride is None or dst_stride is None:
        raise ValueError("ub_to_l1 parameter inference failed")
    validate_var_or_int(n_burst, "n_burst")
    validate_var_or_int(burst_len, "burst_len")
    validate_var_or_int(src_stride, "src_stride")
    validate_var_or_int(dst_stride, "dst_stride")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_l1",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len=burst_len,
                src_stride=src_stride,
                dst_stride=dst_stride,
            )
        )


def ub_to_ub(
    dst: Tensor,
    src: Tensor,
    n_burst: Union[int, Var, None] = None,
    burst_len: Union[int, Var, None] = None,
    src_stride: Union[int, Var, None] = None,
    dst_stride: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    span = dst.span if hasattr(dst, "span") else dst.shape
    span0 = span[0]
    span1 = span[1]
    dst_shape0 = dst.shape[0]
    src_shape1 = src.shape[1]
    dst_shape1 = dst.shape[1]
    validate_var_or_int(span0, "dst.span[0]")
    validate_var_or_int(span1, "dst.span[1]")
    validate_var_or_int(dst_shape0, "dst.shape[0]")
    validate_var_or_int(src_shape1, "src.shape[1]")
    validate_var_or_int(dst_shape1, "dst.shape[1]")
    if n_burst is None:
        n_burst = span0
    if burst_len is None:
        burst_len = CeilDiv(span1, dst.dtype.C0)
    if dst_stride is None:
        dst_stride = CeilDiv(dst_shape1 - span1, dst.dtype.C0)
    if src_stride is None:
        src_stride = CeilDiv(src_shape1 - span1, src.dtype.C0)
    if n_burst is None or burst_len is None or dst_stride is None or src_stride is None:
        raise ValueError("ub_to_ubparameter inference failed") 
    validate_var_or_int(n_burst, "n_burst")
    validate_var_or_int(burst_len, "burst_len")
    validate_var_or_int(src_stride, "src_stride")
    validate_var_or_int(dst_stride, "dst_stride")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_ub",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len=burst_len,
                src_stride=src_stride,
                dst_stride=dst_stride,
            )
        )
