from typing import Optional, Union, Tuple

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype, DataTypeValue, is_integer_dtype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import (
    A2_DEVICES,
    assert_valid_device,
    finalize_count_per_rep_transition,
    infer_repeat,
    resolve_strides,
    validate_scalar,
    validate_var_or_int,
    apply_vector_mode_transition,
)


def _validate_unary_scalar_tensors(
    dst: Tensor,
    src: Tensor,
    allowed_dtypes: Tuple,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}") 
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}") 
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if dst.dtype not in allowed_dtypes:
        raise ValueError(f"does not support data type: {dst.dtype}") 

def _emit_unary_scalar_inst(
    opname: str,
    dst: Tensor,
    src: Tensor,
    val: Union[int, float, Var],
    repeat: Union[int, Var],
    dst_blk_stride: Union[int, Var],
    src_blk_stride: Union[int, Var],
    dst_rep_stride: Union[int, Var],
    src_rep_stride: Union[int, Var],
    round_en: Optional[bool] = None,
) -> None:
    if globvars.active_kernel is not None:
        kwargs = {
            "dst": dst,
            "src": src,
            "val": val,
            "repeat": repeat,
            "dst_blk_stride": dst_blk_stride,
            "src_blk_stride": src_blk_stride,
            "dst_rep_stride": dst_rep_stride,
            "src_rep_stride": src_rep_stride,
        }
        if round_en is not None:
            kwargs["round_en"] = round_en
        globvars.active_kernel.instructions.append(
            Instruction(opname, **kwargs)
        )
        finalize_count_per_rep_transition()


_SHIFT_DTYPES = (Datatype.int16, Datatype.uint16, Datatype.int, Datatype.uint32)


def _validate_shift_value(val: Union[int, Var], dtype: DataTypeValue) -> None:
    if isinstance(val, bool) or not isinstance(val, (int, Var)):
        raise TypeError(f"val must be int or Var type, current type: {type(val)}")
    if isinstance(val, Var):
        if not is_integer_dtype(val.dtype):
            raise ValueError(f"shift Var must have an integer dtype, got: {val.dtype}")
        return
    max_shift = 16 if dtype.size == 2 else 32
    if val < 0 or val > max_shift:
        raise ValueError(f"shift value for {dtype} must be in [0, {max_shift}], got: {val}")


def _shift_scalar(
    opname: str,
    dst: Tensor,
    src: Tensor,
    val: Union[int, Var],
    repeat: Union[int, Var, None],
    dst_blk_stride: Union[int, Var, None],
    src_blk_stride: Union[int, Var, None],
    dst_rep_stride: Union[int, Var, None],
    src_rep_stride: Union[int, Var, None],
    count: Union[int, Var, None],
    count_per_rep: Union[int, Var, None],
    round_en: Optional[bool],
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_unary_scalar_tensors(dst, src, _SHIFT_DTYPES)
    _validate_shift_value(val, dst.dtype)

    if round_en is not None:
        if not isinstance(round_en, bool):
            raise TypeError(f"round_en must be bool type, current type: {type(round_en)}")

    if repeat is None:
        repeat = infer_repeat(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src_blk_stride, src_rep_stride = resolve_strides(src, src_blk_stride, src_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src_blk_stride, "src_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)
    _emit_unary_scalar_inst(
        opname, dst, src, val, repeat, dst_blk_stride, src_blk_stride,
        dst_rep_stride, src_rep_stride, round_en=round_en,
    )


def adds(
    dst: Tensor,
    src: Tensor,
    val: Union[int, float, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_unary_scalar_tensors(dst, src, (Datatype.float, Datatype.half, Datatype.int))
    validate_scalar(val, "val")

    if repeat is None:
        repeat = infer_repeat(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src_blk_stride, src_rep_stride = resolve_strides(src, src_blk_stride, src_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src_blk_stride, "src_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_unary_scalar_inst(
        "adds",
        dst,
        src,
        val,
        repeat,
        dst_blk_stride,
        src_blk_stride,
        dst_rep_stride,
        src_rep_stride,
    )


def muls(
    dst: Tensor,
    src: Tensor,
    val: Union[int, float, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_unary_scalar_tensors(dst, src, (Datatype.float, Datatype.half, Datatype.int))
    validate_scalar(val, "val")

    if repeat is None:
        repeat = infer_repeat(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src_blk_stride, src_rep_stride = resolve_strides(src, src_blk_stride, src_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src_blk_stride, "src_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_unary_scalar_inst(
        "muls",
        dst,
        src,
        val,
        repeat,
        dst_blk_stride,
        src_blk_stride,
        dst_rep_stride,
        src_rep_stride,
    )


def shiftls(
    dst: Tensor,
    src: Tensor,
    val: Union[int, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _shift_scalar(
        "shiftls", dst, src, val, repeat, dst_blk_stride, src_blk_stride,
        dst_rep_stride, src_rep_stride, count, count_per_rep, round_en=None,
    )


def shiftrs(
    dst: Tensor,
    src: Tensor,
    val: Union[int, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
    round_en: bool = False,
) -> None:
    _shift_scalar(
        "shiftrs", dst, src, val, repeat, dst_blk_stride, src_blk_stride,
        dst_rep_stride, src_rep_stride, count, count_per_rep, round_en=round_en,
    )


def vmaxs(
    dst: Tensor,
    src: Tensor,
    val: Union[int, float, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_unary_scalar_tensors(dst, src, (Datatype.float, Datatype.half, Datatype.int))
    validate_scalar(val, "val")

    if repeat is None:
        repeat = infer_repeat(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src_blk_stride, src_rep_stride = resolve_strides(src, src_blk_stride, src_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src_blk_stride, "src_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_unary_scalar_inst(
        "vmaxs",
        dst,
        src,
        val,
        repeat,
        dst_blk_stride,
        src_blk_stride,
        dst_rep_stride,
        src_rep_stride,
    )


def vmins(
    dst: Tensor,
    src: Tensor,
    val: Union[int, float, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_unary_scalar_tensors(dst, src, (Datatype.float, Datatype.half, Datatype.int))
    validate_scalar(val, "val")

    if repeat is None:
        repeat = infer_repeat(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src_blk_stride, src_rep_stride = resolve_strides(src, src_blk_stride, src_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src_blk_stride, "src_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_unary_scalar_inst(
        "vmins",
        dst,
        src,
        val,
        repeat,
        dst_blk_stride,
        src_blk_stride,
        dst_rep_stride,
        src_rep_stride,
    )


def lrelu(
    dst: Tensor,
    src: Tensor,
    val: Union[int, float, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_unary_scalar_tensors(dst, src, (Datatype.float, Datatype.half))
    validate_scalar(val, "val")

    if repeat is None:
        repeat = infer_repeat(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src_blk_stride, src_rep_stride = resolve_strides(src, src_blk_stride, src_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src_blk_stride, "src_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_unary_scalar_inst(
        "lrelu",
        dst,
        src,
        val,
        repeat,
        dst_blk_stride,
        src_blk_stride,
        dst_rep_stride,
        src_rep_stride,
    )


def axpy(
    dst: Tensor,
    src: Tensor,
    val: Union[int, float, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_unary_scalar_tensors(dst, src, (Datatype.float, Datatype.half))
    validate_scalar(val, "val")

    if repeat is None:
        repeat = infer_repeat(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src_blk_stride, src_rep_stride = resolve_strides(src, src_blk_stride, src_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src_blk_stride, "src_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_unary_scalar_inst(
        "axpy",
        dst,
        src,
        val,
        repeat,
        dst_blk_stride,
        src_blk_stride,
        dst_rep_stride,
        src_rep_stride,
    )
