from typing import Union

from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import A2_A5_DEVICES, assert_valid_device


def set_mask(mask_high: Union[int, Var], mask_low: Union[int, Var]) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if isinstance(mask_high, Var) and mask_high.dtype is not Datatype.uint64:
        raise TypeError(f"mask_high must be uint64type, current type: {mask_high.dtype}")
    if isinstance(mask_low, Var) and mask_low.dtype is not Datatype.uint64:
        raise TypeError(f"mask_low must be uint64type, current type: {mask_low.dtype}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("set_mask", low=mask_low, high=mask_high)
        )


def set_mask_by_count(count: Union[int, Var]) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(count, (int, Var)):
        raise TypeError(f"count must be int or Var type, current type: {type(count)}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("set_mask_by_count", count=count)
        )


def set_mask_normal() -> None:
    """Explicitly restore normal vector-mask mode inside runtime branches."""
    assert_valid_device(A2_A5_DEVICES)
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(Instruction("set_mask_normal"))
        globvars.active_kernel.vector_mode = "repeat"


def reset_mask() -> None:
    assert_valid_device(A2_A5_DEVICES)
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("reset_mask")
        )
