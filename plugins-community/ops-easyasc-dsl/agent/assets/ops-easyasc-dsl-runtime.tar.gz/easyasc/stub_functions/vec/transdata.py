from typing import Union

from ... import globvars
from ...utils.Tensor import Tensor
from ...utils.datatype import Datatype
from ...utils.instruction import Instruction
from ...utils.positions import Position
from ...utils.var import Var
from .vecutils import (
    A2_DEVICES,
    assert_valid_device,
    ensure_repeat_mode,
    validate_var_or_int,
)


def transdata5hd(
    dst: Tensor,
    src: Tensor,
    repeat: Union[int, Var, None] = None,
    src_row_stride: Union[int, Var, None] = None,
    dst_row_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var] = 1,
    dst_rep_stride: Union[int, Var] = 16,
) -> None:
    """16x16 block transpose between UB tensors (AscendC TransDataTo5HD, b16).

    Per repeat r, the 16x16 tile gathered from rows ``src[i*src_row_stride +
    r*src_rep_stride*16 : +16]`` (i = 0..15) is transposed into ``dst[i*
    dst_row_stride + r*dst_rep_stride*16 : +16]``. Defaults walk an NCHW->5HD
    plane: src rows are 16 channel rows of padHW elements, dst is the packed
    [padHW, C0] plane. RepStrides count 32B blocks; each of the 16 row bases
    must be 32B aligned (row strides multiples of 16 b16 elements).

    a2 (910B) b16 only: half/int16/uint16 native; bf16 codegen reinterprets to
    half (pure bit moves). fp32 (16x8) / int8 (C0=32 halves) are not wired.
    """
    assert_valid_device(A2_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.UB or src.position is not Position.UB:
        raise ValueError(
            f"transdata5hd operands must be at UB, current: dst={dst.position}, src={src.position}"
        )
    if dst.dtype != src.dtype:
        raise ValueError(f"dst/src data types must match, current: dst={dst.dtype}, src={src.dtype}")
    if dst.dtype not in (Datatype.half, Datatype.bfloat16, Datatype.int16, Datatype.uint16):
        raise ValueError(f"transdata5hd supports b16 dtypes only, current: {dst.dtype}")
    if src_row_stride is None:
        src_row_stride = int(src.shape[1])
    if dst_row_stride is None:
        dst_row_stride = 16
    if repeat is None:
        if not isinstance(src.shape[1], int):
            raise ValueError("repeat is required when src row length is a Var")
        repeat = int(src.shape[1]) // 16
    for v, lbl in ((repeat, "repeat"), (src_row_stride, "src_row_stride"),
                   (dst_row_stride, "dst_row_stride"), (src_rep_stride, "src_rep_stride"),
                   (dst_rep_stride, "dst_rep_stride")):
        validate_var_or_int(v, lbl)
    if isinstance(repeat, int) and not (1 <= repeat <= 255):
        raise ValueError(f"repeat must be in [1, 255], current value: {repeat}")
    if isinstance(src_row_stride, int) and src_row_stride % 16:
        raise ValueError(f"src_row_stride must be a multiple of 16 (32B rows), got {src_row_stride}")
    if isinstance(dst_row_stride, int) and dst_row_stride % 16:
        raise ValueError(f"dst_row_stride must be a multiple of 16 (32B rows), got {dst_row_stride}")
    for v, lbl in ((src_rep_stride, "src_rep_stride"), (dst_rep_stride, "dst_rep_stride")):
        if isinstance(v, int) and not (0 <= v <= 65535):
            raise ValueError(f"{lbl} must fit uint16 blocks, got {v}")

    ensure_repeat_mode()

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "transdata5hd",
                dst=dst,
                src=src,
                repeat=repeat,
                src_row_stride=src_row_stride,
                dst_row_stride=dst_row_stride,
                src_rep_stride=src_rep_stride,
                dst_rep_stride=dst_rep_stride,
            )
        )
