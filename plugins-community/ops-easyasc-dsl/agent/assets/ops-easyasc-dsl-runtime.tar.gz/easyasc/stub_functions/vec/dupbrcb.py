from typing import Union

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import (
    A2_DEVICES,
    assert_valid_device,
    apply_vector_mode_transition,
    finalize_count_per_rep_transition,
    ensure_repeat_mode,
    infer_repeat,
    infer_repeat_brcb,
    resolve_strides,
    validate_scalar,
    validate_var_or_int,
)


def dup(
    dst: Tensor,
    value: Union[int, float, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    validate_scalar(value, "value")
    if dst.dtype not in (Datatype.float, Datatype.half, Datatype.int, Datatype.uint32):
        raise ValueError(f"does not support data type: {dst.dtype}")
    if repeat is None:
        repeat = infer_repeat(dst)

    if count is not None:
        # AscendC's counter-mode Duplicate hardwires repeat=1 + blk 1 / rep 8;
        # vector_dup walks stride fields even under SetMaskCount, so any other
        # pattern truncates on 910B3 (blk=0/rep=1 wrote 128 of 8192).
        if dst_blk_stride is None:
            dst_blk_stride = 1
        if dst_rep_stride is None:
            dst_rep_stride = 8
        if (isinstance(dst_blk_stride, int) and dst_blk_stride != 1) or (
                isinstance(dst_rep_stride, int) and dst_rep_stride != 8):
            raise ValueError(
                "dup count mode requires contiguous strides (blk=1, rep=8); "
                f"got blk={dst_blk_stride}, rep={dst_rep_stride}"
            )
    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "dup",
                dst=dst,
                src=value,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                dst_rep_stride=dst_rep_stride,
            )
        )
        finalize_count_per_rep_transition()


# NOTE: brcb does not honor count mode in the a2 simulator; ensure the pipe is
# back in repeat/normal mode before emitting.
def brcb(
    dst: Tensor,
    src: Tensor,
    dst_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    repeat: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    if repeat is None:
        repeat = infer_repeat_brcb(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")

    ensure_repeat_mode()

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "brcb",
                dst=dst,
                src=src,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                dst_rep_stride=dst_rep_stride,
            )
        )
