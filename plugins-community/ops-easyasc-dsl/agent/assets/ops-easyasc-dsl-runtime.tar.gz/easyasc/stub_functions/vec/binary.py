from typing import Union, Tuple

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import (
    A2_DEVICES,
    assert_valid_device,
    finalize_count_per_rep_transition,
    infer_repeat,
    resolve_strides,
    validate_var_or_int,
    apply_vector_mode_transition,
)


def _validate_binary_tensors(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    allowed_dtypes: Tuple,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src1, Tensor):
        raise TypeError(f"src1 must be Tensor type, current type: {type(src1)}")
    if not isinstance(src2, Tensor):
        raise TypeError(f"src2 must be Tensor type, current type: {type(src2)}") 
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src1.position is not Position.UB:
        raise ValueError(f"src1 must be at UB position, current position: {src1.position}")
    if src2.position is not Position.UB:
        raise ValueError(f"src2 must be at UB position, current position: {src2.position}") 
    if dst.dtype != src1.dtype or dst.dtype != src2.dtype:
        raise ValueError("dst/src1/src2 data types must match")
    if dst.dtype not in allowed_dtypes:
        raise ValueError(f"does not support data type: {dst.dtype}")


def _validate_muladddst_tensors(dst: Tensor, src1: Tensor, src2: Tensor) -> None:
    """Validate MulAddDst operands: dst = dst + src1 * src2.

    Per the CANN doc (Atlas A2), the dst type T and the src type U may differ.
    The two sources share one dtype U; the accepted (T, U) pairs are
    (float, float), (half, half), and (float, half) -- the last being the
    high-precision half-source / float-accumulator mode. (half, float) is
    rejected: an accumulator lower-precision than its sources is not a doc mode.
    """
    for name, t in (("dst", dst), ("src1", src1), ("src2", src2)):
        if not isinstance(t, Tensor):
            raise TypeError(f"{name} must be Tensor type, current type: {type(t)}")
        if t.position is not Position.UB:
            raise ValueError(f"{name} must be at UB position, current position: {t.position}")
    if src1.dtype != src2.dtype:
        raise ValueError("muladddst src1/src2 data types must match")
    allowed_pairs = (
        (Datatype.float, Datatype.float),
        (Datatype.half, Datatype.half),
        (Datatype.float, Datatype.half),
    )
    if (dst.dtype, src1.dtype) not in allowed_pairs:
        raise ValueError(
            "muladddst supports (dst, src) dtype pairs (float, float) / (half, half) / "
            f"(float, half); got ({dst.dtype}, {src1.dtype})"
        )


def _emit_binary_inst(
    opname: str,
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var],
    dst_blk_stride: Union[int, Var],
    src1_blk_stride: Union[int, Var],
    src2_blk_stride: Union[int, Var],
    dst_rep_stride: Union[int, Var],
    src1_rep_stride: Union[int, Var],
    src2_rep_stride: Union[int, Var],
) -> None:
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                opname,
                dst=dst,
                src1=src1,
                src2=src2,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                src1_blk_stride=src1_blk_stride,
                src2_blk_stride=src2_blk_stride,
                dst_rep_stride=dst_rep_stride,
                src1_rep_stride=src1_rep_stride,
                src2_rep_stride=src2_rep_stride,
            )
        )
        finalize_count_per_rep_transition()


def add(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "add",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def sub(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "sub",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def mul(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "mul",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def div(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "div",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def vmax(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    # Atlas A2/A3 (dav-c220) Max supports half, float, int16_t, and int32_t.
    # Keep this list aligned with CANN's MaxIntrinsicsImpl static assertion.
    _validate_binary_tensors(
        dst, src1, src2,
        (Datatype.float, Datatype.half, Datatype.int16, Datatype.int),
    )

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "vmax",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def vmin(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "vmin",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def vand(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_binary_tensors(dst, src1, src2, (Datatype.int16, Datatype.uint16))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "vand",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def vor(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_binary_tensors(dst, src1, src2, (Datatype.int16, Datatype.uint16))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "vor",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def muladddst(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_DEVICES)
    _validate_muladddst_tensors(dst, src1, src2)

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep, count_per_rep_limit=256 // dst.dtype.size)

    _emit_binary_inst(
        "muladddst",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )
