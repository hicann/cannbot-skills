from typing import Union

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import A2_A5_DEVICES, A5_DEVICES, assert_valid_device, validate_scalar, validate_var_or_int
from ..var_op import CeilDiv


def _infer_sort32_repeat(src: Tensor) -> Union[int, Var]:
    span = src.span if hasattr(src, "span") else src.shape
    dim0 = span[0]
    dim1 = span[1]
    validate_var_or_int(dim0, "shape[0]")
    validate_var_or_int(dim1, "shape[1]")
    count = dim0 * dim1
    if isinstance(count, Var):
        return CeilDiv(count, 32)
    if not isinstance(count, int):
        raise TypeError(f"repeat cannot be inferred from shape, current count type: {type(count)}")
    return CeilDiv(count, 32)


def _static_tensor_numel(tensor: Tensor):
    count = 1
    span = tensor.span if hasattr(tensor, "span") else tensor.shape
    for dim in span:
        if not isinstance(dim, int):
            return None
        count *= dim
    return count


def sort32(dst: Tensor, src: Tensor, idx: Tensor, repeat: Union[Var, int, None] = None) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(idx, Tensor):
        raise TypeError(f"idx must be Tensor type, current type: {type(idx)}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if idx.position is not Position.UB:
        raise ValueError(f"idx must be at UB position, current position: {idx.position}")
    if src.dtype != dst.dtype:
        raise ValueError("src/dst data types must match")
    if dst.dtype is not Datatype.float:
        raise ValueError(f"sort32 only supports float dtype for src/dst, current dtype: {dst.dtype}")
    if idx.dtype is not Datatype.uint32:
        raise ValueError(f"idx must be uint32 type, current type: {idx.dtype}") 
    if repeat is None:
        repeat = _infer_sort32_repeat(src)

    validate_var_or_int(repeat, "repeat")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("sort32", dst=dst, src=src, idx=idx, repeat=repeat)
        )


def mergesort4(
    dst: Tensor,
    src: Tensor,
    length_per_seq: Union[Var, int],
    repeat: Union[Var, int],
) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.dtype != dst.dtype:
        raise ValueError("src/dst data types must match")
    if dst.dtype is not Datatype.float:
        raise ValueError(
            f"mergesort4 only supports float dtype for src/dst, current dtype: {dst.dtype}"
        )
    validate_var_or_int(length_per_seq, "length_per_seq")
    validate_var_or_int(repeat, "repeat")
    if isinstance(length_per_seq, int) and length_per_seq <= 0:
        raise ValueError(f"length_per_seq must be positive, got: {length_per_seq}")
    if isinstance(repeat, int) and repeat < 0:
        raise ValueError(f"repeat must be non-negative, got: {repeat}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "mergesort4",
                dst=dst,
                src=src,
                length_per_seq=length_per_seq,
                repeat=repeat,
            )
        )


def mergesort_2seq(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    size1: Union[int, Var],
    size2: Union[int, Var],
) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src1, Tensor):
        raise TypeError(f"src1 must be Tensor type, current type: {type(src1)}")
    if not isinstance(src2, Tensor):
        raise TypeError(f"src2 must be Tensor type, current type: {type(src2)}")
    if src1.position is not Position.UB:
        raise ValueError(f"src1 must be at UB position, current position: {src1.position}")
    if src2.position is not Position.UB:
        raise ValueError(f"src2 must be at UB position, current position: {src2.position}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src1.dtype != dst.dtype or src2.dtype != dst.dtype:
        raise ValueError("src1/src2/dst data types must match")
    if dst.dtype is not Datatype.float:
        raise ValueError(
            f"mergesort_2seq only supports float dtype for src1/src2/dst, current dtype: {dst.dtype}"
        )
    validate_var_or_int(size1, "size1")
    validate_var_or_int(size2, "size2")
    if isinstance(size1, int) and size1 <= 0:
        raise ValueError(f"size1 must be positive, got: {size1}")
    if isinstance(size2, int) and size2 <= 0:
        raise ValueError(f"size2 must be positive, got: {size2}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "mergesort_2seq",
                dst=dst,
                src1=src1,
                src2=src2,
                size1=size1,
                size2=size2,
            )
        )


def topk_radix(
    dst_values: Tensor,
    dst_indices: Tensor,
    src_values: Tensor,
    src_indices: Tensor,
    tmp: Tensor,
    k: Union[int, Var],
    n: Union[int, Var],
    aligned_n: Union[int, Var],
    largest: Union[int, float, Var] = 1,
    *,
    outter: Union[int, Var] = 1,
    init_index: bool = True,
    sorted: bool = True,
) -> None:
    """Run the Ascend950 C310 radix-select TopK advanced API in UB.

    ``src_values`` contains ``outter`` rows, each padded to ``aligned_n``
    elements.  When ``init_index`` is true, one shared ``src_indices`` row
    supplies the int32 indices for every value row; otherwise the API generates
    ``0..aligned_n-1`` in scratch.  Destination rows have independent 32-byte
    strides: ``align(k, src_values.dtype.C0)`` for values and ``align(k, 8)``
    for int32 indices.  ``sorted`` and ``init_index`` are compile-time
    configurations because they select the advanced-API template instance.
    """
    assert_valid_device(A5_DEVICES)
    tensors = {
        "dst_values": dst_values,
        "dst_indices": dst_indices,
        "src_values": src_values,
        "src_indices": src_indices,
        "tmp": tmp,
    }
    for name, tensor in tensors.items():
        if not isinstance(tensor, Tensor):
            raise TypeError(
                f"{name} must be Tensor type, current type: {type(tensor)}"
            )
        if tensor.position is not Position.UB:
            raise ValueError(
                f"{name} must be at UB position, current position: {tensor.position}"
            )
    supported = (
        Datatype.uint8, Datatype.int8, Datatype.uint16, Datatype.int16,
        Datatype.half, Datatype.float, Datatype.bfloat16, Datatype.uint32,
        Datatype.int, Datatype.uint64, Datatype.int64,
    )
    if src_values.dtype not in supported:
        raise ValueError(
            "topk_radix value dtype must be an Ascend950 radix-select type, "
            f"got: {src_values.dtype}"
        )
    if dst_values.dtype is not src_values.dtype:
        raise ValueError("topk_radix src/dst value dtypes must match")
    if src_indices.dtype is not Datatype.int or dst_indices.dtype is not Datatype.int:
        raise ValueError("topk_radix indices must use int32 tensors")
    if tmp.dtype is not Datatype.uint8:
        raise ValueError("topk_radix tmp must use uint8 storage")
    validate_var_or_int(k, "k")
    validate_var_or_int(n, "n")
    validate_var_or_int(aligned_n, "aligned_n")
    validate_var_or_int(outter, "outter")
    validate_scalar(largest, "largest")
    if isinstance(k, int) and k <= 0:
        raise ValueError(f"k must be positive, got: {k}")
    if isinstance(n, int) and n <= 0:
        raise ValueError(f"n must be positive, got: {n}")
    if isinstance(outter, int) and outter <= 0:
        raise ValueError(f"outter must be positive, got: {outter}")
    if isinstance(aligned_n, int):
        if aligned_n <= 0 or aligned_n > 4096:
            raise ValueError(
                f"aligned_n must be in [1, 4096], got: {aligned_n}"
            )
        if aligned_n % 32:
            raise ValueError(
                "aligned_n must align 32 values for C310 TopK, got: "
                f"{aligned_n}"
            )
    if isinstance(n, int) and isinstance(aligned_n, int) and n > aligned_n:
        raise ValueError(f"n must not exceed aligned_n, got n={n}, aligned_n={aligned_n}")
    if isinstance(k, int) and isinstance(n, int) and k > n:
        raise ValueError(f"k must not exceed n, got k={k}, n={n}")
    if not isinstance(sorted, bool):
        raise TypeError(f"sorted must be bool, current type: {type(sorted)}")
    if not isinstance(init_index, bool):
        raise TypeError(
            f"init_index must be bool, current type: {type(init_index)}"
        )

    if all(isinstance(value, int) for value in (k, aligned_n, outter)):
        src_required = outter * aligned_n
        value_c0 = src_values.dtype.C0
        index_c0 = Datatype.int.C0
        value_dst_required = outter * ((k + value_c0 - 1) // value_c0) * value_c0
        index_dst_required = outter * ((k + index_c0 - 1) // index_c0) * index_c0
        static_requirements = (
            ("src_values", src_values, src_required),
            ("dst_values", dst_values, value_dst_required),
            ("dst_indices", dst_indices, index_dst_required),
        )
        if init_index:
            static_requirements += (("src_indices", src_indices, aligned_n),)
        for name, tensor, required in static_requirements:
            available = _static_tensor_numel(tensor)
            if available is not None and available < required:
                raise ValueError(
                    f"topk_radix {name} requires at least {required} elements, "
                    f"got: {available}"
                )

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "topk_radix",
                # The generic auto-sync layer consumes `src` and `dst` while
                # the handler/simulator use the explicitly named tensors.
                src=(src_values, src_indices, tmp),
                dst=(dst_values, dst_indices, tmp),
                dst_values=dst_values,
                dst_indices=dst_indices,
                src_values=src_values,
                src_indices=src_indices,
                tmp=tmp,
                k=k,
                n=n,
                aligned_n=aligned_n,
                largest=largest,
                outter=outter,
                init_index=init_index,
                sorted=sorted,
            )
        )
