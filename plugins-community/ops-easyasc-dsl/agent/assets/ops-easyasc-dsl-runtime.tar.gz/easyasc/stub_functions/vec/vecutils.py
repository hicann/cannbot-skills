from typing import List, Union, Tuple

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.instruction import Instruction
from ...utils.datatype import Datatype as _DT
from ... import globvars


# C220 tensor-vector instruction surface: A2/B-series plus A3/Ascend910_93.
A2_DEVICES = ["b1", "b2", "b3", "b4", "a3"]
A5_DEVICES = ["950", "950pr"]
A2_A5_DEVICES = A2_DEVICES + A5_DEVICES


_count_semantics_warning = True


def _warn_count_semantics() -> None:
    global _count_semantics_warning
    if _count_semantics_warning:
        print(
            "A2 vec reminder: count is the total element count in counter mode; "
            "repeat/strides do not define traversal. count_per_rep is the active lane "
            "count inside each repeat and does not replace repeat. Use repeat + rep_stride "
            "for multiple chunks. The two parameters are mutually exclusive. See "
            "agent/references/constraints/vec.md."
        )
        _count_semantics_warning = False


def assert_valid_device(white_list: List[str]) -> None:
    device_type = globvars.device_type
    if device_type in white_list:
        return
    raise ValueError(
        f"stub function does not support device_type {device_type!r}; "
        f"valid device_type values: {white_list}"
    )


# Bitwise vec ops (vand/vor/vxor/vnot) are integer-only on the hardware: the AscendC
# reg_compute SupportType list is bool/uint8/int8/uint16/int16/uint32/int32. DT exposes no bool
# reg dtype; int32 is DT.int. fp8/half/bf16 must be reinterpreted to a same-width int dtype first
# (otherwise the kernel only fails at board ccec with a static_assert, not in sim or codegen).
_BITWISE_DTYPES = (_DT.int8, _DT.uint8, _DT.int16, _DT.uint16, _DT.int, _DT.uint32)


def assert_bitwise_dtype(opname: str, *regs: object) -> None:
    for r in regs:
        dt = getattr(r, "dtype", None)
        if dt not in _BITWISE_DTYPES:
            raise ValueError(
                f"{opname} is a bitwise op and only supports integer dtypes "
                f"(int8/uint8/int16/uint16/int32/uint32), got: {dt}. "
                f"Reinterpret fp8/half/bf16 regs to a same-width int dtype first, "
                f"e.g. reg.reinterpret(DT.int8)."
            )


def validate_var_or_int(value: object, label: str) -> None:
    if not isinstance(value, (Var, int)):
        raise TypeError(f"{label} must be Var or int type, current type: {type(value)}")


def apply_vector_mode_transition(
    count: Union[int, Var, None],
    count_per_rep: Union[int, Var, None] = None,
    *,
    count_per_rep_limit: Union[int, None] = None,
) -> None:
    if count is not None and count_per_rep is not None:
        raise ValueError("count and count_per_rep are mutually exclusive")
    if count is not None or count_per_rep is not None:
        _warn_count_semantics()
    if count_per_rep is not None:
        validate_var_or_int(count_per_rep, "count_per_rep")
        if isinstance(count_per_rep, int) and count_per_rep_limit is not None:
            if count_per_rep < 0 or count_per_rep > count_per_rep_limit:
                raise ValueError(
                    "count_per_rep is the active lane count inside one repeat; "
                    f"valid range for this op is [0, {count_per_rep_limit}], "
                    f"got {count_per_rep}. Use repeat + rep_stride for multiple "
                    "chunks; do not pass a total tile length."
                )
    kernel = globvars.active_kernel
    if kernel is None:
        return
    if count is not None:
        validate_var_or_int(count, "count")
        # Emit the SetMaskCount() mode switch before *every* counted op, not just
        # on the first repeat->count transition. The lazy "only on transition"
        # form assumed straight-line execution: when the first counted op in
        # source order sits inside an untaken runtime branch (e.g. `if False:` /
        # the source-order-first of two `if/else` arms, or a loop that runs zero
        # times), the single SetMaskCount() lands in dead code and the taken path
        # runs the counter-mode op while the hardware is still in normal mask
        # mode -> wrong lanes. SetMaskCount() is an idempotent scalar mode write,
        # so re-emitting it per counted op is branch/loop-safe and cheap. We only
        # touch the repeat->count direction here; the count->repeat reset below is
        # unchanged so custom set_mask() sequences are never clobbered.
        kernel.instructions.append(Instruction("set_mask_count"))
        kernel.vector_mode = "count"
        kernel.instructions.append(Instruction("set_mask_counter", count=count))
        return
    if kernel.vector_mode == "count":
        kernel.instructions.append(Instruction("set_mask_normal"))
        kernel.vector_mode = "repeat"
        kernel.instructions.append(Instruction("reset_mask"))
    if count_per_rep is not None:
        kernel.instructions.append(Instruction("set_mask_by_count", count=count_per_rep))
        setattr(kernel, "_pending_count_per_rep_reset", True)


def finalize_count_per_rep_transition() -> None:
    kernel = globvars.active_kernel
    if kernel is None:
        return
    if getattr(kernel, "_pending_count_per_rep_reset", False):
        kernel.instructions.append(Instruction("reset_mask"))
        kernel._pending_count_per_rep_reset = False


def ensure_repeat_mode() -> None:
    kernel = globvars.active_kernel
    if kernel is None:
        return
    if kernel.vector_mode == "count":
        kernel.instructions.append(Instruction("set_mask_normal"))
        kernel.vector_mode = "repeat"
        kernel.instructions.append(Instruction("reset_mask"))

def validate_scalar(value: object, label: str) -> None:
    if not isinstance(value, (Var, int, float)):
        raise TypeError(f"{label} must be Var or numeric value type, current type: {type(value)}") 

def infer_repeat(tensor: Tensor) -> Union[int, Var]:
    from ..var_op import CeilDiv

    span = tensor.span if hasattr(tensor, "span") else tensor.shape
    dim0 = span[0]
    dim1 = span[1]
    validate_var_or_int(dim0, "shape[0]")
    validate_var_or_int(dim1, "shape[1]")

    count = dim0 * dim1
    denom = 256 // tensor.dtype.size
    if isinstance(count, Var):
        return CeilDiv(count, denom)
    if not isinstance(count, int):
        raise TypeError(f"repeat cannot be inferred from shape, current count type: {type(count)}")
    return CeilDiv(count, denom)


def infer_repeat_brcb(src: Tensor) -> Union[int, Var]:
    from ..var_op import CeilDiv

    span = src.span if hasattr(src, "span") else src.shape
    dim0 = span[0]
    dim1 = span[1]
    validate_var_or_int(dim0, "shape[0]")
    validate_var_or_int(dim1, "shape[1]")

    count = dim0 * dim1
    if isinstance(count, Var):
        return CeilDiv(count, 8)
    if not isinstance(count, int):
        raise TypeError(f"repeat cannot be inferred from shape, current count type: {type(count)}")
    return count // 8


def infer_rep_stride(shape1: object, c0: int) -> Union[int, Var]:
    if isinstance(shape1, Var):
        return CeilDiv(shape1, c0)
    if isinstance(shape1, int):
        return shape1 // c0
    raise TypeError(f"rep_stride cannot be inferred from shape, current shape[1] type: {type(shape1)}")

def infer_strides(tensor: Tensor) -> Tuple[Union[int, Var], Union[int, Var]]:
    span = tensor.span if hasattr(tensor, "span") else tensor.shape
    shape = tensor.shape
    span0 = span[0]
    span1 = span[1]
    c0 = tensor.dtype.C0

    blk_stride: Union[int, Var] = 1
    rep_stride: Union[int, Var] = 8
    matched = False
    if isinstance(span1, int):
        if span1 == 8 * c0:
            blk_stride = 1
            rep_stride = infer_rep_stride(shape[1], c0)
            matched = True
        elif span1 == c0:
            blk_stride = 0
            rep_stride = infer_rep_stride(shape[1], c0)
            matched = True

    if matched and isinstance(span0, int) and span0 == 1:
        rep_stride = 0

    return blk_stride, rep_stride


def resolve_strides(
    tensor: Tensor,
    blk_stride: Union[int, Var, None],
    rep_stride: Union[int, Var, None],
) -> Tuple[Union[int, Var], Union[int, Var]]:
    if blk_stride is None or rep_stride is None:
        auto_blk, auto_rep = infer_strides(tensor)
        if blk_stride is None:
            blk_stride = auto_blk
        if rep_stride is None:
            rep_stride = auto_rep
    return blk_stride, rep_stride
