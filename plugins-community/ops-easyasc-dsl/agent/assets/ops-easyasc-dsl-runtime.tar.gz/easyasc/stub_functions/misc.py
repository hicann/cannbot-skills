from typing import Any, Union

from ..utils.Tensor import Tensor, GMTensor
from ..utils.var import Var
from ..utils.datatype import DataTypeValue, Datatype
from ..utils.instruction import Instruction
from ..utils.pipe import Pipe, PipeType
from ..utils.positions import Position
from ..utils.cacheline import DcciDst, DcciDstType, EntireType, EntireTypeValue
from ..utils.naming import assert_codegen_safe_identifier
from .. import globvars
from ..device_profile import is_a5_family, is_c220_family
from .var_op import var_mul, var_div
from .vec.vecutils import A2_A5_DEVICES, assert_valid_device


def _scale_dim(value: Union[int, Var], num: int, den: int, label: str) -> Union[int, Var]:
    if isinstance(value, Var):
        if value.dtype is not None and value.dtype is not Datatype.int:
            raise TypeError(f"{label} must be DT.int Var, current type: {value.dtype}")
        if num == den:
            return value
        if num % den == 0:
            factor = num // den
            if factor == 1:
                return value
            return var_mul(value, factor)
        if den % num == 0:
            factor = den // num
            return var_div(value, factor)
        return var_div(var_mul(value, num), den)
    if isinstance(value, int):
        if num == den:
            return value
        return (value * num) // den
    raise TypeError(f"{label} must be int or Var type, current type: {type(value)}")


def _is_int4_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") == "int4"


def _is_fp4_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") in ("fp4x2_e2m1_t", "fp4x2_e1m2_t")


def _is_hif8_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") == "hifloat8_t"


def _is_packed_compute_view_dtype(dtype: DataTypeValue) -> bool:
    return _is_int4_dtype(dtype) or _is_fp4_dtype(dtype)


def _is_c220_device() -> bool:
    return is_c220_family(getattr(globvars, "device_type", ""))


def _is_a5_device() -> bool:
    return is_a5_family(getattr(globvars, "device_type", ""))


def reinterpret(src: Tensor, target_dtype: DataTypeValue, name: str = "") -> Tensor:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(target_dtype, DataTypeValue):
        raise TypeError(f"target_dtype must be DataTypeValue type, current type: {type(target_dtype)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    assert_codegen_safe_identifier(name, "reinterpret view")
    if src.position is Position.L0C:
        raise ValueError("reinterpret does not support L0C position")
    if _is_packed_compute_view_dtype(src.dtype):
        raise ValueError(f"{src.dtype} views can only be consumed by their matching cube ops")
    if _is_int4_dtype(target_dtype):
        if not _is_c220_device():
            raise ValueError("DT.int4 codegen is only supported on a2/b* devices")
        if src.dtype is not Datatype.int:
            raise TypeError(f"DT.int4 reinterpret requires a DT.int carrier tensor, got: {src.dtype}")
        if src.position not in (Position.L1, Position.L0A, Position.L0B):
            raise ValueError(f"DT.int4 reinterpret only supports L1/L0A/L0B, got: {src.position}")
    if _is_fp4_dtype(target_dtype):
        if not _is_a5_device():
            raise ValueError("DT.fp4_e2m1/DT.fp4_e1m2 codegen is only supported on a5/950 devices")
        if src.position not in (Position.L1, Position.L0A, Position.L0B):
            raise ValueError(f"FP4 reinterpret only supports L1/L0A/L0B, got: {src.position}")
        if src.position is Position.L1 and src.dtype is not Datatype.uint8:
            raise TypeError(f"FP4 L1 reinterpret requires a DT.uint8 packed carrier tensor, got: {src.dtype}")
    if _is_hif8_dtype(target_dtype) and not _is_a5_device():
        raise ValueError("DT.hif8 codegen is only supported on a5/950 devices")
    src_c0 = src.dtype.C0
    dst_c0 = target_dtype.C0

    shape = list(src.shape)
    span = list(src.span)
    pack_axis = 0 if _is_packed_compute_view_dtype(target_dtype) and src.is_transpose else 1
    shape_dim = shape[pack_axis]
    span_dim = span[pack_axis]
    if not isinstance(shape_dim, (int, Var)):
        raise TypeError(f"shape[{pack_axis}] must be int or Var type, current type: {type(shape_dim)}")
    if not isinstance(span_dim, (int, Var)):
        raise TypeError(f"span[{pack_axis}] must be int or Var type, current type: {type(span_dim)}")
    shape[pack_axis] = _scale_dim(shape_dim, dst_c0, src_c0, f"shape[{pack_axis}]")
    span[pack_axis] = _scale_dim(span_dim, dst_c0, src_c0, f"span[{pack_axis}]")

    idx = globvars.tmp_idx
    globvars.tmp_idx += 1
    if name == "":
        name = f"_tmp_tensor_{idx}"
    else:
        kernel = globvars.active_kernel
        if kernel is not None:
            counts = getattr(kernel, "_reinterpret_name_counts", None)
            if counts is None:
                counts = {}
                kernel._reinterpret_name_counts = counts
            base = name
            seen = counts.get(base, 0)
            if seen > 0:
                name = f"{base}_{seen}"
            counts[base] = seen + 1

    out = object.__new__(Tensor)
    out.dtype = target_dtype
    out.shape = shape
    out.name = name
    out.position = src.position
    out.idx = idx
    out.offset = list(src.offset)
    out.span = span
    out.step = list(src.step)
    out.source_buf = src.source_buf
    out.source_index = src.source_index
    out.storage_key_name = getattr(src, "storage_key_name", src.name)
    out.is_transpose = src.is_transpose
    out._layout = src._layout
    out._is_relu = getattr(src, "_is_relu", False)
    if hasattr(src, "_logical_payload_shape"):
        out._logical_payload_shape = list(src._logical_payload_shape)
    if _is_packed_compute_view_dtype(target_dtype):
        out._packed_view_carrier = src
        out._packed_view_carrier_shape = list(src.shape)
        out._packed_view_carrier_span = list(src.span)
        out._packed_view_axis = pack_axis
        out._packed_view_root = out
        out._packed_view_consumed_by = None
    if _is_int4_dtype(target_dtype):
        out._int4_carrier = src
        out._int4_carrier_shape = list(src.shape)
        out._int4_carrier_span = list(src.span)
        out._int4_consumed_by = None
    if _is_fp4_dtype(target_dtype):
        out._fp4_carrier = src
        out._fp4_carrier_shape = list(src.shape)
        out._fp4_carrier_span = list(src.span)
        out._fp4_consumed_by = None
    if _is_hif8_dtype(target_dtype):
        out._hif8_carrier = src
        out._hif8_carrier_shape = list(src.shape)
        out._hif8_carrier_span = list(src.span)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "reinterpret",
                dst=out,
                src=src,
                dst_shape=list(out.shape),
                dst_span=list(out.span),
                packed_view_axis=pack_axis if _is_packed_compute_view_dtype(target_dtype) else None,
            )
        )
    return out


def _shape_numel(shape: Union[list, tuple]) -> Union[int, Var]:
    numel: Union[int, Var] = 1
    for dim in shape:
        if not isinstance(dim, (int, Var)):
            raise TypeError(f"shape element must be int or Var, got: {type(dim)}")
        if isinstance(dim, int) and dim == 1:
            continue
        if isinstance(numel, int) and numel == 1:
            numel = dim
            continue
        if isinstance(numel, int) and isinstance(dim, int):
            numel *= dim
        else:
            numel = var_mul(numel, dim)
    return numel


def reshape_gm_tensor(src: GMTensor, shape: Union[list, tuple], name: str = "") -> GMTensor:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if not isinstance(shape, (list, tuple)):
        raise TypeError(f"shape must be list or tuple, got: {type(shape)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str, got: {type(name)}")
    assert_codegen_safe_identifier(name, "reshaped GMTensor")
    if len(shape) == 0:
        raise ValueError("shape must have at least 1 dimension")
    for dim in shape:
        if not isinstance(dim, (int, Var)):
            raise TypeError(f"shape element must be int or Var, got: {type(dim)}")
    if not src.is_plain_view():
        raise ValueError("GMTensor.reshape only supports plain_view GMTensor")

    src_numel = _shape_numel(src.shape)
    dst_numel = _shape_numel(shape)
    if isinstance(src_numel, int) and isinstance(dst_numel, int) and src_numel != dst_numel:
        raise ValueError(
            f"GMTensor.reshape requires same numel, got src_numel={src_numel}, dst_numel={dst_numel}"
        )

    idx = globvars.tmp_idx
    globvars.tmp_idx += 1
    if name == "":
        name = f"_tmp_gmtensor_{idx}"

    out = object.__new__(GMTensor)
    out.dtype = src.dtype
    out.shape = list(shape)
    out.name = name
    out.idx = idx
    out.offset = [0 for _ in shape]
    out.span = list(shape)
    out.step = [1 for _ in shape]
    out.slice_mask = [False for _ in shape]
    out._mutex = getattr(src, "_mutex", None)
    out.data = getattr(src, "data", None)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "reshape_gm_tensor",
                src=src,
                out=out,
                dst_shape=list(out.shape),
            )
        )
    return out


def split_workspace(dtype: DataTypeValue, shape: Union[list, tuple], name: str = "") -> GMTensor:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
    if _is_int4_dtype(dtype):
        raise ValueError("split_workspace does not support DT.int4; use DT.int packed carrier workspace instead")
    if _is_fp4_dtype(dtype):
        raise ValueError("split_workspace does not support FP4 compute-view dtypes; use DT.uint8 packed carrier workspace instead")
    if not isinstance(shape, (list, tuple)):
        raise TypeError(f"shape must be list or tuple, got: {type(shape)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str, got: {type(name)}")
    assert_codegen_safe_identifier(name, "split_workspace")
    numel = _shape_numel(shape)
    idx = globvars.tmp_idx
    globvars.tmp_idx += 1
    if name == "":
        name = f"_tmp_gmtensor_{idx}"

    out = object.__new__(GMTensor)
    out.dtype = dtype
    out.shape = shape
    out.name = name
    out.idx = idx
    out.offset = [0 for _ in shape]
    out.span = list(shape)
    out.step = [1 for _ in shape]
    out.slice_mask = [False for _ in shape]
    out._mutex = None
    out.data = None

    if globvars.active_kernel is not None:
        globvars.active_kernel.workspace_shapes.append({"shape": list(shape), "dtype": dtype})
        globvars.active_kernel.instructions.append(
            Instruction("split_workspace", val=out, dtype=dtype, numel=numel, name=name)
        )
    return out


def reset_cache() -> None:
    assert_valid_device(A2_A5_DEVICES)
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("reset_cache")
        )


def set_hf32(enable: bool = True) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(enable, bool):
        raise TypeError(f"enable must be bool type, current type: {type(enable)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("set_hf32", enable=enable)
        )


def clean_dcache(
    dst: GMTensor,
    entire_type: EntireTypeValue = EntireType.single,
    dcci_dst: DcciDstType = DcciDst.all,
    mode: str = "all",
) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"dst must be GMTensor type, current type: {type(dst)}")
    if not isinstance(entire_type, EntireTypeValue):
        raise TypeError(
            f"entire_type must be EntireTypeValue type, current type: {type(entire_type)}"
        )
    if not isinstance(dcci_dst, DcciDstType):
        raise TypeError(f"dcci_dst must be DcciDstType type, current type: {type(dcci_dst)}")
    if not isinstance(mode, str):
        raise TypeError(f"mode must be str type, current type: {type(mode)}")
    if mode not in ("all", "vec", "cube"):
        raise ValueError(f"mode must be one of ('all', 'vec', 'cube'), current value: {mode}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "clean_dcache",
                dst=dst,
                entire_type=entire_type,
                dcci_dst=dcci_dst,
                mode=mode,
            )
        )


def sim_print(*args: Any, pipe: PipeType = Pipe.S) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(pipe, PipeType):
        raise TypeError(f"pipe must be PipeType type, current type: {type(pipe)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("sim_print", payload=list(args), pipe=pipe)
        )


def kernel_print(fmt: str, *args: Any) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(fmt, str):
        raise TypeError(f"fmt must be str type, current type: {type(fmt)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("kernel_print", fmt=fmt, payload=list(args))
        )


def sim_dump_tensor(tensor: Tensor, filename: str, pipe: PipeType) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(tensor, Tensor):
        raise TypeError(f"tensor must be Tensor type, current type: {type(tensor)}")
    if not isinstance(filename, str):
        raise TypeError(f"filename must be str type, current type: {type(filename)}")
    if not isinstance(pipe, PipeType):
        raise TypeError(f"pipe must be PipeType type, current type: {type(pipe)}")
    if pipe == Pipe.ALL:
        raise ValueError("pipe cannot be Pipe.ALL")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("sim_dump_tensor", tensor=tensor, filename=filename, pipe=pipe)
        )


def kernel_dump_tensor(src: Union[GMTensor, Tensor], desc: Union[int, Var], dumpSize: Union[int, Var]) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(src, (GMTensor, Tensor)):
        raise TypeError(f"src must be GMTensor or Tensor type, current type: {type(src)}")
    if isinstance(src, Tensor) and src.position not in (Position.UB, Position.L1, Position.L0C):
        raise ValueError(
            f"kernel_dump_tensor Tensor src only supports UB/L1/L0C, current position: {src.position}"
        )
    if not isinstance(desc, (int, Var)):
        raise TypeError(f"desc must be int or Var type, current type: {type(desc)}")
    if not isinstance(dumpSize, (int, Var)):
        raise TypeError(f"dumpSize must be int or Var type, current type: {type(dumpSize)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("kernel_dump_tensor", src=src, desc=desc, dumpSize=dumpSize)
        )


def inline(code: str) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(code, str):
        raise TypeError(f"code must be str type, current type: {type(code)}")
    target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
    if target is not None:
        target.instructions.append(Instruction("inline", code=code))
