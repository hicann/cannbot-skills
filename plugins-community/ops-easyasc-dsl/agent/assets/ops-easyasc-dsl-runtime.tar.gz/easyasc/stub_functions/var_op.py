from typing import Optional, Union
import math

from ..utils.var import Var
from ..utils.datatype import Datatype, is_integer_dtype
from ..utils.instruction import Instruction
from .. import globvars


def _assert_a2_a5_device() -> None:
    from .vec.vecutils import A2_A5_DEVICES, assert_valid_device

    assert_valid_device(A2_A5_DEVICES)


def _value_of(value: Union[Var, int, float]) -> Optional[Union[int, float]]:
    if isinstance(value, Var):
        if isinstance(value.value, (int, float)):
            return value.value
        return None
    if isinstance(value, (int, float)):
        return value
    return None


def _append_instruction(inst: Instruction) -> None:
    target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
    if target is not None:
        target.instructions.append(inst)


def _varies_with_micro_loop(value) -> bool:
    if not isinstance(value, Var):
        return False
    return bool(getattr(value, "_is_micro_loop_var", False)
                or getattr(value, "_micro_loop_tainted", False))


def _carry_micro_loop_taint(out: Var, *operands) -> Var:
    """Track which scalars vary with a ``@vf`` loop counter."""
    if any(_varies_with_micro_loop(operand) for operand in operands):
        out._micro_loop_tainted = True
    return out


def _reject_micro_int_to_float(op_name: str, dtype, *operands) -> None:
    """Reject a float scalar built from a ``@vf`` loop counter.

    ``__VEC_SCOPE__`` compiles to an AIV loop whose scalar unit only does the
    integer arithmetic that computes addresses.  A loop-invariant float scalar
    hoists above the scope, but one that varies with the loop cannot, and the
    board compiler fails the build with "Unsupported scalar instruction in AIV
    loop" -- a diagnostic that carries no line number and that the simulator
    happily runs past.  Catching it here keeps the two in step.
    """
    if globvars.active_micro is None or dtype is not Datatype.float:
        return
    if not any(_varies_with_micro_loop(operand) for operand in operands):
        return
    raise TypeError(
        "{}() would build a float scalar from a @vf loop counter, which the "
        "AIV scalar unit cannot do ('Unsupported scalar instruction in AIV "
        "loop'). Keep the value in a float Reg and step it once per iteration "
        "(dup(r, 0.0) before the loop, adds(r, r, 1.0) inside), or compute it "
        "outside the @vf.".format(op_name)
    )


def _trunc_int_mod(a: int, b: int) -> int:
    """Return the C/C++ signed-integer remainder without float conversion."""
    if b == 0:
        raise ZeroDivisionError("integer modulo by zero")
    quotient = abs(a) // abs(b)
    if (a < 0) != (b < 0):
        quotient = -quotient
    return a - quotient * b


def CeilDiv(a: Union[Var, int], b: Union[Var, int], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(b, (Var, int)):
        raise TypeError(f"b must be Var or int type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    out = Var(name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None and b_val != 0:
        out.value = (a_val + b_val - 1) // b_val
    _append_instruction(Instruction("CeilDiv", a=a, b=b, out=out))
    return out


def GetCubeNum(*, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(name=name)
    _append_instruction(Instruction("GetCubeNum", out=out))
    return out


def GetCubeIdx(*, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(name=name)
    _append_instruction(Instruction("GetCubeIdx", out=out))
    return out


def GetVecNum(*, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(dtype=Datatype.int, name=name)
    _append_instruction(Instruction("GetVecNum", out=out))
    return out


def GetVecIdx(*, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(dtype=Datatype.int, name=name)
    _append_instruction(Instruction("GetVecIdx", out=out))
    return out


def GetSubBlockIdx(*, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    # Keep the value symbolic so lane-specific conditions such as
    # `if GetSubBlockIdx() == 0` are not folded at build time.
    out = Var(value=None, dtype=Datatype.int, name=name)
    _append_instruction(Instruction("GetSubBlockIdx", out=out))
    return out


def scalar_sqrt(a: Union[Var, float], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, float)):
        raise TypeError(f"a must be Var or float type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.float:
        raise TypeError("scalar_sqrt only supports float Var")
    out = Var(dtype=Datatype.float, name=name)
    a_val = _value_of(a)
    if isinstance(a_val, (int, float)):
        out.value = math.sqrt(a_val)
    _append_instruction(Instruction("scalar_sqrt", a=a, out=out))
    return out


def scalar_abs(a: Union[Var, int, float], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int, float)) or isinstance(a, bool):
        raise TypeError(f"a must be Var, int, or float type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var):
        signed_integer_dtypes = (Datatype.int8, Datatype.int16, Datatype.int, Datatype.int64)
        if a.dtype is not Datatype.float and a.dtype not in signed_integer_dtypes:
            raise TypeError(f"scalar_abs only supports signed integer or float Var, current dtype: {a.dtype}")
        out_dtype = a.dtype
    elif isinstance(a, float):
        out_dtype = Datatype.float
    else:
        out_dtype = Datatype.int
    if globvars.active_micro is not None and out_dtype is not Datatype.int:
        raise TypeError("scalar_abs inside vf only supports int")
    out = Var(dtype=out_dtype, name=name)
    a_val = _value_of(a)
    if isinstance(a_val, (int, float)):
        out.value = abs(a_val)
    _append_instruction(Instruction("scalar_abs", a=a, out=out))
    return out


def _align_value(a: Union[Var, int], align: int) -> Optional[int]:
    a_val = _value_of(a)
    if isinstance(a_val, (int, float)):
        return (int(a_val) + align - 1) // align * align
    return None


def Align8(a: Union[Var, int], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align8 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 8)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align8", a=a, out=out))
    return out


def Align16(a: Union[Var, int], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align16 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 16)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align16", a=a, out=out))
    return out


def Align32(a: Union[Var, int], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align32 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 32)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align32", a=a, out=out))
    return out


def Align64(a: Union[Var, int], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align64 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 64)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align64", a=a, out=out))
    return out


def Align128(a: Union[Var, int], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align128 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 128)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align128", a=a, out=out))
    return out


def Align256(a: Union[Var, int], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align256 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 256)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align256", a=a, out=out))
    return out


def var_mul(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    _reject_micro_int_to_float("var_mul", dtype, a, b)
    out = _carry_micro_loop_taint(Var(dtype=dtype, name=name), a, b)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = a_val * b_val
    _reject_micro_int_to_float("var_mul", dtype, a, b)
    _append_instruction(Instruction("var_mul", a=a, b=b, out=out))
    return out


def var_add(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    _reject_micro_int_to_float("var_add", dtype, a, b)
    out = _carry_micro_loop_taint(Var(dtype=dtype, name=name), a, b)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = a_val + b_val
    _reject_micro_int_to_float("var_add", dtype, a, b)
    _append_instruction(Instruction("var_add", a=a, b=b, out=out))
    return out


def var_sub(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    _reject_micro_int_to_float("var_sub", dtype, a, b)
    out = _carry_micro_loop_taint(Var(dtype=dtype, name=name), a, b)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = a_val - b_val
    _reject_micro_int_to_float("var_sub", dtype, a, b)
    _append_instruction(Instruction("var_sub", a=a, b=b, out=out))
    return out


def var_div(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    def _dtype_of(value, label: str):
        if isinstance(value, Var):
            if value.dtype is None:
                raise TypeError(f"{label}dtype is None, cannot infer")
            return value.dtype
        if isinstance(value, float):
            return Datatype.float
        if isinstance(value, int):
            return Datatype.int
        raise TypeError(f"{label} must be Var or numeric value type, current type: {type(value)}")
    dtype_a = _dtype_of(a, "a")
    dtype_b = _dtype_of(b, "b")
    if dtype_a is dtype_b:
        out_dtype = dtype_a
    elif dtype_a is Datatype.float and is_integer_dtype(dtype_b):
        out_dtype = Datatype.float
    elif dtype_b is Datatype.float and is_integer_dtype(dtype_a):
        out_dtype = Datatype.float
    else:
        raise TypeError(
            "a and b must have matching data types or mix float with an integer type, "
            f"current {dtype_a} and {dtype_b}"
        )
    out = Var(dtype=out_dtype, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None and b_val != 0:
        if is_integer_dtype(out_dtype):
            out.value = a_val // b_val
        else:
            out.value = a_val / b_val
    _append_instruction(Instruction("var_div", a=a, b=b, out=out))
    return out


def var_mod(a: Union[Var, int], b: Union[Var, int], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(b, (Var, int)):
        raise TypeError(f"b must be Var or int type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    dtype_a = a.dtype if isinstance(a, Var) else Datatype.int
    dtype_b = b.dtype if isinstance(b, Var) else Datatype.int
    if not is_integer_dtype(dtype_a):
        raise TypeError(f"a data type must be an integer for var_mod, current: {dtype_a}")
    if not is_integer_dtype(dtype_b):
        raise TypeError(f"b data type must be an integer for var_mod, current: {dtype_b}")
    if isinstance(a, Var) and isinstance(b, Var) and dtype_a is not dtype_b:
        raise TypeError(f"a and b must have matching integer data types, current: {dtype_a} and {dtype_b}")
    if isinstance(a, Var):
        out_dtype = dtype_a
    elif isinstance(b, Var):
        out_dtype = dtype_b
    else:
        out_dtype = Datatype.int

    if isinstance(b, int) and b == 0:
        raise ZeroDivisionError("var_mod divide by zero")
    out = Var(dtype=out_dtype, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    # A runtime Var carries the default placeholder value 0 until it is bound,
    # so `Var(...) == 0` cannot be read as a literal divide-by-zero here.
    # Match `var_div` / `CeilDiv`: fold only when the divisor is a known
    # non-zero, and let a literal zero (checked above) still raise.
    if isinstance(a_val, (int, float)) and isinstance(b_val, (int, float)) and int(b_val) != 0:
        out.value = _trunc_int_mod(int(a_val), int(b_val))
    _append_instruction(Instruction("var_mod", a=a, b=b, out=out))
    return out


def Min(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    _reject_micro_int_to_float("Min", dtype, a, b)
    out = _carry_micro_loop_taint(Var(dtype=dtype, name=name), a, b)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = min(a_val, b_val)
    _reject_micro_int_to_float("Min", dtype, a, b)
    _append_instruction(Instruction("Min", a=a, b=b, out=out))
    return out


def Max(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    _assert_a2_a5_device()
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    _reject_micro_int_to_float("Max", dtype, a, b)
    out = _carry_micro_loop_taint(Var(dtype=dtype, name=name), a, b)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = max(a_val, b_val)
    _reject_micro_int_to_float("Max", dtype, a, b)
    _append_instruction(Instruction("Max", a=a, b=b, out=out))
    return out
