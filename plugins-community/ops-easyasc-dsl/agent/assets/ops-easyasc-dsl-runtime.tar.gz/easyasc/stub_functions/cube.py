from typing import List, Tuple, Union

from ..utils.datatype import DataTypeValue, Datatype
from ..utils.Tensor import Tensor, GMTensor
from ..utils.dualmode import DualMode, DualModeType
from ..utils.var import Var
from ..utils.instruction import Instruction
from ..utils.positions import Position
from .. import globvars
from ..device_profile import is_a5_family, is_c220_family
from .vec.vecutils import A2_A5_DEVICES, A5_DEVICES, assert_valid_device


def _validate_var_or_int(value: object, label: str) -> None:
    if not isinstance(value, (Var, int)):
        raise TypeError(f"{label} must be Var or int type, current type: {type(value)}") 


def _validate_unit_flag(value: object, label: str = "unit_flag") -> None:
    if isinstance(value, bool) or not isinstance(value, (Var, int)):
        raise TypeError(
            f"{label} must be Var or int type, current type: {type(value)}"
        )
    if isinstance(value, int) and value not in (0, 2, 3):
        raise ValueError(f"{label} must be one of 0, 2, or 3, current value: {value}")
    if isinstance(value, Var) or value != 0:
        assert_valid_device(A5_DEVICES)


def _static_int(value: object) -> Union[int, None]:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    return None


def _known_int(value: object) -> Union[int, None]:
    static = _static_int(value)
    if static is not None:
        return static
    if isinstance(value, Var) and isinstance(value.value, int) and not isinstance(value.value, bool):
        return value.value
    return None


def _ceil_div_static(value: int, divisor: int) -> int:
    return (value + divisor - 1) // divisor


def _align16(value: int) -> int:
    return ((value + 15) // 16) * 16


def _static_numel(shape: object) -> Union[int, None]:
    if not isinstance(shape, (list, tuple)):
        return None
    numel = 1
    for dim in shape:
        value = _static_int(dim)
        if value is None:
            return None
        numel *= value
    return numel


def _dim_product(dims: List[Union[int, Var]]) -> Union[int, Var]:
    out: Union[int, Var] = 1
    for dim in dims:
        _validate_var_or_int(dim, "dim")
        out = out * dim
    return out


def _validate_gm_to_l1_pad_dst(dst: Tensor, n_burst: object, burst_len_byte: object, dst_stride: object) -> None:
    n_burst_value = _static_int(n_burst)
    burst_len_value = _static_int(burst_len_byte)
    dst_stride_value = _static_int(dst_stride)
    dst_elements = _static_numel(getattr(dst, "shape", None))
    if (
        n_burst_value is None
        or burst_len_value is None
        or dst_stride_value is None
        or dst_elements is None
    ):
        return
    if n_burst_value < 0 or burst_len_value < 0 or dst_stride_value < 0:
        raise ValueError("gm_to_l1_pad expects non-negative n_burst, burst_len_element, and dst_stride")
    if n_burst_value == 0 or burst_len_value == 0:
        return
    aligned_burst = _ceil_div_static(burst_len_value, 32) * 32
    footprint = (n_burst_value - 1) * (aligned_burst + dst_stride_value * 32) + aligned_burst
    capacity = dst_elements * dst.dtype.size
    if footprint > capacity:
        raise ValueError(
            f"gm_to_l1_pad destination footprint is {footprint} bytes after 32B burst padding, "
            f"but dst only has {capacity} bytes"
        )


def _same_dim(a: Union[int, Var], b: Union[int, Var]) -> bool:
    return str(a) == str(b)


def _infer_gm_pad_transfer(
    tensor: GMTensor,
    context: str,
) -> Tuple[Union[int, Var], Union[int, Var], Union[int, Var]]:
    shape = list(tensor.shape)
    span = list(tensor.span if hasattr(tensor, "span") else tensor.shape)
    slice_mask = list(getattr(tensor, "slice_mask", [True for _ in shape]))

    if len(shape) == 1:
        return 1, span[0], 0

    if len(shape) == 2:
        return span[0], span[1], shape[1] - span[1]

    slice_dims = [idx for idx, flag in enumerate(slice_mask) if flag]
    if len(slice_dims) == 0:
        raise ValueError(f"{context} default inference for rank>2 requires at least one sliced dimension")
    if len(slice_dims) > 2:
        raise ValueError(f"{context} default inference supports at most 2 sliced dimensions")

    if len(slice_dims) == 1:
        outer_dim = slice_dims[0]
        if outer_dim == len(shape) - 1:
            return 1, span[outer_dim], 0
        burst_len = _dim_product(span[outer_dim + 1 :])
        src_step = _dim_product(shape[outer_dim + 1 :])
        return span[outer_dim], burst_len, src_step - burst_len

    outer_dim, inner_dim = slice_dims
    trailing_shape = shape[inner_dim + 1 :]
    trailing_span = span[inner_dim + 1 :]
    for shape_dim, span_dim in zip(trailing_shape, trailing_span):
        if not _same_dim(shape_dim, span_dim):
            raise ValueError(
                f"{context} default inference requires the innermost sliced dimension "
                "to cover the contiguous suffix of the GM view"
            )
    burst_len = _dim_product(span[inner_dim:])
    src_step = _dim_product(shape[outer_dim + 1 :])
    return span[outer_dim], burst_len, src_step - burst_len


def _validate_l0c_source_footprint(opname: str, src: Tensor, M: object, N: object, M_src: object) -> None:
    m = _static_int(M)
    n = _static_int(N)
    m_src = _static_int(M_src)
    if m is not None and m_src is not None and m > m_src:
        raise ValueError(f"{opname}: M must be <= M_src, got M={m}, M_src={m_src}")
    if n is None or m_src is None:
        return

    declared = _static_numel(getattr(src, "shape", None))
    if declared is None:
        return
    required = ((n + 15) // 16) * _align16(m_src) * 16
    if required > declared:
        raise ValueError(
            f"{opname}: L0C source footprint exceeds declared src tensor storage; "
            f"M_src={m_src}, N={n} requires {required} elements, but "
            f"src shape={getattr(src, 'shape', None)} provides {declared} elements. "
            "Declare a larger L0C tensor or use a compact M_src."
        )


def _is_int4_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") == "int4"


def _is_fp4_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") in ("fp4x2_e2m1_t", "fp4x2_e1m2_t")


def _is_hif8_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") == "hifloat8_t"


def _is_int_dtype(dtype: DataTypeValue) -> bool:
    return dtype is Datatype.int or getattr(dtype, "name", "") == "int"


def _is_mx_fp8_dtype(dtype: DataTypeValue) -> bool:
    return getattr(dtype, "name", "") in ("mx_fp8_e4m3_t", "mx_fp8_e5m2_t")


def _is_mx_mmad_dtype(dtype: DataTypeValue) -> bool:
    return _is_mx_fp8_dtype(dtype) or _is_fp4_dtype(dtype)


def _mx_mmad_family(dtype: DataTypeValue) -> str:
    if _is_mx_fp8_dtype(dtype):
        return "mxfp8"
    if _is_fp4_dtype(dtype):
        return "mxfp4"
    return "unknown"


def _is_e8m0_carrier_dtype(dtype: DataTypeValue) -> bool:
    return dtype is Datatype.uint8 or getattr(dtype, "name", "") in ("uint8_t", "fp8_e8m0_t")


def _validate_mx_scale_shape(
    src_mx: Tensor,
    scale_rows: object,
    scale_k: object,
    allow_larger_physical: bool = False,
) -> None:
    m = _static_int(scale_rows)
    n = _static_int(scale_k)
    if m is None or n is None:
        return
    visible_shape = getattr(src_mx, "span", getattr(src_mx, "shape", None))
    if not isinstance(visible_shape, (list, tuple)) or len(visible_shape) != 2:
        return
    rows = _static_int(visible_shape[0])
    cols = _static_int(visible_shape[1])
    if rows is None or cols is None:
        return
    expected_rows = m
    expected_cols = _ceil_div_static(n, 64) * 2
    if rows == expected_rows and cols == expected_cols:
        return
    if (
        allow_larger_physical
        and rows >= expected_rows
        and cols >= expected_cols
        and rows % 16 == 0
        and cols % 2 == 0
    ):
        return
    if rows != expected_rows or cols != expected_cols:
        raise ValueError(
            "l1_to_l0_mx requires compact FP8 e8m0 scale shape "
            f"[scale_rows, 2 * ceil(scale_k / 64)] (for K multiple of 64 this is [scale_rows, scale_k / 32]); "
            f"got visible shape={list(visible_shape)}, scale_rows={m}, scale_k={n}"
        )


def _validate_mx_transpose_tile(m_dst: object, n_dst: object, dtype: DataTypeValue = None) -> None:
    align = 64 if _is_fp4_dtype(dtype) else 32
    family = "FP4 " if _is_fp4_dtype(dtype) else ""
    m = _known_int(m_dst)
    n = _known_int(n_dst)
    if m is not None and m % align != 0:
        raise ValueError(
            f"l1_to_l0_mx {family}NZ2ZN transpose requires the source M axis (logical K) to be {align}-element aligned; "
            f"got m_dst={m}. Pad the L1 source tile before loading to L0."
        )
    if n is not None and n % align != 0:
        raise ValueError(
            f"l1_to_l0_mx {family}NZ2ZN transpose requires the source K axis (logical N) to be {align}-element aligned; "
            f"got n_dst={n}. Pad the L1 source tile before loading to L0."
        )


def _is_c220_device() -> bool:
    return is_c220_family(getattr(globvars, "device_type", ""))


def _is_a5_device() -> bool:
    return is_a5_family(getattr(globvars, "device_type", ""))


# Acceptable (src_a, src_b, bias, dst) dtype tuples for matmul-with-bias, taken
# verbatim from the AscendC Mmad datatype tables: table 8 = Atlas A2 (= our a2 /
# 910b), table 9 = Atlas 350 (= our a5 / 950). Rule of thumb: int8@int8 -> int32
# bias/dst; every other supported same-dtype input -> float bias/dst.
_MMAD_BIAS_DTYPES_A2 = (
    (Datatype.int8, Datatype.int8, Datatype.int, Datatype.int),
    (Datatype.half, Datatype.half, Datatype.float, Datatype.float),
    (Datatype.float, Datatype.float, Datatype.float, Datatype.float),
    (Datatype.bfloat16, Datatype.bfloat16, Datatype.float, Datatype.float),
)
# a5 (table 9) is a superset; fp4x2 / mx_fp8 rows take a scale and route through
# mmad_mx (which has no bias param), and mixed fp8 (e4m3@e5m2) is blocked by mmad's
# src_a==src_b dtype check, so neither is part of this same-dtype bias fence.
_MMAD_BIAS_DTYPES_A5 = _MMAD_BIAS_DTYPES_A2 + (
    (Datatype.e4m3, Datatype.e4m3, Datatype.float, Datatype.float),
    (Datatype.e5m2, Datatype.e5m2, Datatype.float, Datatype.float),
    (Datatype.hif8, Datatype.hif8, Datatype.float, Datatype.float),
)


def _bias_dtype_for_inputs(src_dtype: DataTypeValue) -> DataTypeValue:
    """Required bias (and matmul output) dtype for a given input dtype, per the
    Mmad datatype tables: int8 inputs accumulate into int32, everything else fp32."""
    return Datatype.int if src_dtype is Datatype.int8 else Datatype.float


def _validate_mmad_bias_dtypes(src_a: Tensor, src_b: Tensor, dst: Tensor, bias: Tensor) -> None:
    """Fence the (A, B, bias, dst) datatype tuple of a matmul-with-bias against the
    device's accepted combinations (Mmad tables 8 for a2, 9 for a5)."""
    if _is_c220_device():
        allowed = _MMAD_BIAS_DTYPES_A2
        device_label = "a2/910b (Mmad table 8)"
    elif _is_a5_device():
        allowed = _MMAD_BIAS_DTYPES_A5
        device_label = "a5/950 (Mmad table 9)"
    else:
        raise ValueError(
            f"mmad bias is not supported on device_type {globvars.device_type!r}"
        )
    combo = (src_a.dtype, src_b.dtype, bias.dtype, dst.dtype)
    if combo not in allowed:
        accepted = "; ".join(f"{a}@{b}->bias {z}/dst {d}" for (a, b, z, d) in allowed)
        raise TypeError(
            f"mmad bias datatype combination src_a={src_a.dtype}, src_b={src_b.dtype}, "
            f"bias={bias.dtype}, dst={dst.dtype} is not accepted on {device_label}. "
            f"Accepted combinations: {accepted}"
        )


def _mx_dtype_for_src(dtype: DataTypeValue) -> DataTypeValue:
    if dtype is Datatype.e4m3 or getattr(dtype, "name", "") == "float8_e4m3_t":
        return Datatype.mx_e4m3
    if dtype is Datatype.e5m2 or getattr(dtype, "name", "") == "float8_e5m2_t":
        return Datatype.mx_e5m2
    if _is_fp4_dtype(dtype):
        return dtype
    raise TypeError(f"l1_to_l0_mx only supports DT.e4m3/DT.e5m2/FP4 src, current dtype: {dtype}")


def _validate_int4_mmad_operand(tensor: Tensor, label: str) -> None:
    carrier = getattr(tensor, "_int4_carrier", None)
    if not isinstance(carrier, Tensor) or carrier.dtype is not Datatype.int:
        raise TypeError(f"int4 MMAD requires {label} to be backed by a DT.int carrier")


def _mark_packed_view_consumed(tensor: Tensor, consumed_by: str) -> None:
    if not (_is_int4_dtype(tensor.dtype) or _is_fp4_dtype(tensor.dtype)):
        return
    tensor._packed_view_consumed_by = consumed_by
    root = getattr(tensor, "_packed_view_root", None)
    if isinstance(root, Tensor):
        root._packed_view_consumed_by = consumed_by
    if _is_int4_dtype(tensor.dtype):
        tensor._int4_consumed_by = consumed_by
        if isinstance(root, Tensor):
            root._int4_consumed_by = consumed_by
    if _is_fp4_dtype(tensor.dtype):
        tensor._fp4_consumed_by = consumed_by
        if isinstance(root, Tensor):
            root._fp4_consumed_by = consumed_by


def _validate_tensor_offset_zero(tensor: Tensor, label: str) -> None:
    offset = getattr(tensor, "offset", None)
    if not isinstance(offset, (list, tuple)):
        raise TypeError(f"{label}.offset must be list/tuple, current type: {type(offset)}")
    for value in offset:
        if isinstance(value, Var):
            raise ValueError(f"{label}.offset must be 0, current offset: {offset}")
        if isinstance(value, bool):
            resolved = int(value)
        elif isinstance(value, (int, float)):
            resolved = int(value)
        else:
            raise TypeError(
                f"{label}.offset values must be int/float type, current type: {type(value)}"
            )
        if resolved != 0:
            raise ValueError(f"{label}.offset must be 0, current offset: {offset}")


def _metadata_list(values: object) -> str:
    if isinstance(values, (list, tuple)):
        parts = [getattr(v, "name", repr(v)) if isinstance(v, Var) else repr(v) for v in values]
        return "[" + ", ".join(parts) + "]"
    return repr(values)


def _same_static_dim(lhs: object, rhs: object) -> bool:
    if lhs is rhs:
        return True
    if isinstance(lhs, Var) or isinstance(rhs, Var):
        return False
    try:
        result = lhs == rhs
    except TypeError:
        return False
    return result if isinstance(result, bool) else False


def _raise_sliced_view(label: str, reason: str, tensor: Tensor) -> None:
    detail = ""
    if tensor.position is Position.L0C:
        detail = (
            " A static-offset L0C sub-tile (e.g. l0c[16:32, :]) is supported so a tall L0C can "
            "be split across stores, but a dynamic (Var) base offset such as l0c[v1:, :] and "
            "strided reads are not."
        )
    raise ValueError(f"{label} does not support this sliced source tensor: {reason}.{detail}")


def _validate_l0c_slice_source(tensor: Tensor, label: str) -> None:
    """Accept a STATIC-OFFSET L0C sub-tile as the source so a tall L0C result can be split
    across several stores (e.g. l0c[0:16, :] then l0c[16:32, :], each a SINGLE-mode l0c_to_ub).

    What must be static is the fixpipe source *base offset* -- the address is a static offset
    plus the full-tile M stride, where M_src is the L0C ``shape[0]`` (the declared tile height),
    NOT the sliced ``span[0]``. A non-zero static offset and a partial span are fine; the row/col
    extents may be Var (they feed the runtime M/N, as for an unsliced store). A dynamic (Var)
    base offset (e.g. l0c[v1:, :] in a loop) and strided reads (step != 1) are rejected.
    """
    offset = getattr(tensor, "offset", None)
    step = getattr(tensor, "step", None)
    span = getattr(tensor, "span", None)
    shape = getattr(tensor, "shape", None)
    for name, seq in (("offset", offset), ("step", step), ("span", span), ("shape", shape)):
        if not isinstance(seq, (list, tuple)):
            raise TypeError(f"{label}.{name} must be list/tuple, current type: {type(seq)}")

    for off_dim, step_dim in zip(offset, step):
        if not _same_static_dim(step_dim, 1):
            _raise_sliced_view(label, f"step must be all ones, got step={_metadata_list(step)}", tensor)
        if isinstance(off_dim, Var):
            _raise_sliced_view(label, f"offset must be static, got offset={_metadata_list(offset)}", tensor)
    # a static sub-tile must lie within the declared L0C tile (offset + span <= shape)
    for off_dim, span_dim, shape_dim in zip(offset, span, shape):
        if isinstance(off_dim, int) and isinstance(span_dim, int) and isinstance(shape_dim, int):
            if off_dim < 0 or off_dim + span_dim > shape_dim:
                _raise_sliced_view(
                    label,
                    f"sub-tile out of bounds: offset={_metadata_list(offset)} + span={_metadata_list(span)} "
                    f"exceeds shape={_metadata_list(shape)}",
                    tensor,
                )


def _validate_scalar_matches_dtype(value: object, dtype: DataTypeValue) -> None:
    if isinstance(value, bool):
        raise TypeError(f"val must be Var or numeric scalar type, current type: {type(value)}")
    if isinstance(value, Var):
        if not isinstance(value.dtype, DataTypeValue):
            raise TypeError(f"val Var must include dtype, current dtype: {value.dtype}")
        if str(value.dtype) != str(dtype):
            raise TypeError(
                f"val dtype must match tensor dtype, current {value.dtype} and {dtype}"
            )
        return
    dtype_name = str(dtype)
    float_dtypes = {"half", "float", "bfloat16", "bfloat16_t", "float16_t", "float_t"}
    int_dtypes = {
        "int",
        "int8_t",
        "uint8_t",
        "int16_t",
        "uint16_t",
        "uint32_t",
        "uint64_t",
        "int32_t",
        "int64_t",
    }
    if dtype_name in float_dtypes:
        if not isinstance(value, float):
            raise TypeError(
                f"val must be float scalar for tensor dtype {dtype}, current type: {type(value)}"
            )
        return
    if dtype_name in int_dtypes:
        if not isinstance(value, int):
            raise TypeError(
                f"val must be int scalar for tensor dtype {dtype}, current type: {type(value)}"
            )
        return
    raise TypeError(f"set_constant_to_l1 does not support tensor dtype: {dtype}")


def _resolve_dual_mode_value(dual_mode: object) -> int:
    if isinstance(dual_mode, DualModeType):
        value = dual_mode.value
    elif isinstance(dual_mode, bool):
        value = int(dual_mode)
    elif isinstance(dual_mode, int):
        value = dual_mode
    else:
        raise TypeError(f"dual_mode must be DualModeType or int type, current type: {type(dual_mode)}")
    if value not in (DualMode.SINGLE.value, DualMode.SPLITM.value, DualMode.SPLITN.value):
        raise ValueError(f"dual_mode must be 0(SINGLE), 1(SPLITM), or 2(SPLITN), got: {value}")
    return value

def gm_to_l1_nd2nz(
    dst: Tensor,
    src: GMTensor,
    M: Union[int, Var, None]=None,
    N: Union[int, Var, None]=None,
    N_src: Union[int, Var, None]=None,
    M_dst: Union[int, Var, None]=None,
):
    """
    Stub function for GM to L1 copy for 2D tensors with non-zero strides.
    """
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}") 
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if M is None or N is None or N_src is None:
        if not (M is None and N is None and N_src is None):
            raise ValueError("M, N, N_src must all be None")
        slice_mask = getattr(src, "slice_mask", None)
        slice_dims = [idx for idx, flag in enumerate(slice_mask or []) if flag]
        if len(slice_dims) == 2:
            first, second = slice_dims[0], slice_dims[1]
            M = src.span[first]
            N = src.span[second]
            N_src = src.shape[second]
        elif len(slice_dims) == 1:
            dim = slice_dims[0]
            M = 1
            N = src.span[dim]
            N_src = src.shape[dim]
        else:
            raise ValueError("src must include 1 or 2 slicedimensionsto inferM/N/N_src") 
    if M_dst is None:
        M_dst = dst.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(N_src, "N_src")
    _validate_var_or_int(M_dst, "M_dst")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_l1_nd2nz",
                dst=dst,
                src=src,
                M=M,
                N=N,
                N_src=N_src,
                M_dst=M_dst,
            )
        )


def gm_to_l1_dn2nz(
    dst: Tensor,
    src: GMTensor,
    M: Union[int, Var, None]=None,
    N: Union[int, Var, None]=None,
    N_src: Union[int, Var, None]=None,
    M_dst: Union[int, Var, None]=None,
):
    """
    GM to L1 copy that transposes the GM matrix on the fly (Dn2NzParams, a5 only).

    The GM source holds the matrix transposed: GM[n, m] feeds dst NZ element [m, n].
    M / N are the destination (logical) rows / cols; N_src is the GM row stride
    (elements between consecutive dst columns), so N_src >= M.
    """
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if M is None or N is None or N_src is None:
        if not (M is None and N is None and N_src is None):
            raise ValueError("M, N, N_src must all be None")
        slice_mask = getattr(src, "slice_mask", None)
        slice_dims = [idx for idx, flag in enumerate(slice_mask or []) if flag]
        if len(slice_dims) == 2:
            first, second = slice_dims[0], slice_dims[1]
            M = src.span[second]
            N = src.span[first]
            N_src = src.shape[second]
        elif len(slice_dims) == 1:
            dim = slice_dims[0]
            M = src.span[dim]
            N = 1
            N_src = src.shape[dim]
        else:
            raise ValueError("src must include 1 or 2 slice dimensions to infer M/N/N_src")
    if M_dst is None:
        M_dst = dst.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(N_src, "N_src")
    _validate_var_or_int(M_dst, "M_dst")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_l1_dn2nz",
                dst=dst,
                src=src,
                M=M,
                N=N,
                N_src=N_src,
                M_dst=M_dst,
            )
        )


def gm_to_l1_pad(
    dst: Tensor,
    src: GMTensor,
    n_burst: Union[int, Var, None] = None,
    burst_len_element: Union[int, Var, None] = None,
    src_stride_element: Union[int, Var, None] = None,
    dst_stride: Union[int, Var, None] = None,
) -> None:
    """
    GM to L1 copy using DataCopyPad(PaddingMode::Normal).
    GM bursts may be compact/unaligned; each L1 burst footprint is rounded up to 32B.
    """
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    _validate_tensor_offset_zero(dst, "dst")

    if n_burst is None or burst_len_element is None or src_stride_element is None:
        auto_n_burst, auto_burst_len_element, auto_src_stride_element = _infer_gm_pad_transfer(
            src,
            "gm_to_l1_pad",
        )
    else:
        auto_n_burst = None
        auto_burst_len_element = None
        auto_src_stride_element = None
    if n_burst is None:
        n_burst = auto_n_burst
    if burst_len_element is None:
        burst_len_element = auto_burst_len_element
    if src_stride_element is None:
        src_stride_element = auto_src_stride_element
    if dst_stride is None:
        dst_stride = 0
    if n_burst is None or burst_len_element is None or src_stride_element is None or dst_stride is None:
        raise ValueError("gm_to_l1_pad parameter inference failed")
    _validate_var_or_int(n_burst, "n_burst")
    _validate_var_or_int(burst_len_element, "burst_len_element")
    _validate_var_or_int(src_stride_element, "src_stride_element")
    _validate_var_or_int(dst_stride, "dst_stride")

    burst_len_byte = burst_len_element * dst.dtype.size
    src_stride_byte = src_stride_element * dst.dtype.size
    _validate_gm_to_l1_pad_dst(dst, n_burst, burst_len_byte, dst_stride)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_l1_pad",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len_byte=burst_len_byte,
                src_stride_byte=src_stride_byte,
                dst_stride=dst_stride,
            )
        )


def gm_to_l1(
    dst: Tensor,
    src: GMTensor,
    n_burst: Union[int, Var, None] = None,
    burst_len: Union[int, Var, None] = None,
    src_stride: Union[int, Var, None] = None,
    dst_stride: Union[int, Var, None] = None,
) -> None:
    """Contiguous GM -> L1 copy via a plain ``DataCopy`` burst (``GM2L1``).

    Unlike :func:`gm_to_l1_pad` (``DataCopyPad``, a5/950 only), the plain ``DataCopy``
    burst is available on both a2 and a5, so this is how to stage a contiguous row --
    e.g. a ``[1, N]`` matmul bias -- in L1 on a2 (910b), which does not support
    ``DataCopyPad``. ``burst_len`` / ``src_stride`` / ``dst_stride`` are in 32-byte
    block units (``DataCopyParams.blockLen`` semantics).

    The default (all-None) inference does a single flat burst over the source's
    element span. Because ``DataCopy`` transfers whole 32-byte blocks, the copied byte
    span is rounded up to a multiple of 32 B: the GM source must therefore have at
    least ``ceil(numel*size / 32) * 32`` readable bytes (pad the row, or keep
    ``N * dtype.size`` a multiple of 32 B, e.g. N a multiple of 8 for fp32/int32)."""
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    _validate_tensor_offset_zero(dst, "dst")

    if n_burst is None and burst_len is None and src_stride is None and dst_stride is None:
        from .var_op import CeilDiv

        span = src.span if hasattr(src, "span") else src.shape
        total_elements = _dim_product(list(span))
        total_bytes = total_elements * dst.dtype.size
        n_burst = 1
        burst_len = CeilDiv(total_bytes, 32) if isinstance(total_bytes, Var) else _ceil_div_static(total_bytes, 32)
        src_stride = 0
        dst_stride = 0
    else:
        if n_burst is None:
            n_burst = 1
        if burst_len is None:
            raise ValueError("gm_to_l1 requires burst_len when n_burst/src_stride/dst_stride are given")
        if src_stride is None:
            src_stride = 0
        if dst_stride is None:
            dst_stride = 0
    _validate_var_or_int(n_burst, "n_burst")
    _validate_var_or_int(burst_len, "burst_len")
    _validate_var_or_int(src_stride, "src_stride")
    _validate_var_or_int(dst_stride, "dst_stride")

    n_burst_static = _static_int(n_burst)
    burst_len_static = _static_int(burst_len)
    if n_burst_static is not None and n_burst_static <= 0:
        raise ValueError(f"n_burst must be positive, current value: {n_burst}")
    if burst_len_static is not None and burst_len_static <= 0:
        raise ValueError(f"burst_len must be positive, current value: {burst_len}")
    dst_elements = _static_numel(getattr(dst, "shape", None))
    dst_stride_static = _static_int(dst_stride)
    if (
        n_burst_static is not None and burst_len_static is not None
        and dst_stride_static is not None and dst_elements is not None
    ):
        footprint_blocks = (n_burst_static - 1) * (burst_len_static + dst_stride_static) + burst_len_static
        capacity = dst_elements * dst.dtype.size
        if footprint_blocks * 32 > capacity:
            raise ValueError(
                f"gm_to_l1 destination footprint is {footprint_blocks * 32} bytes "
                f"({footprint_blocks} 32B blocks), but dst only has {capacity} bytes"
            )

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_l1",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len=burst_len,
                src_stride=src_stride,
                dst_stride=dst_stride,
            )
        )


def _infer_mx_scale_k_blocks_from_l1(dst: Tensor) -> Union[int, Var]:
    shape = getattr(dst, "shape", None)
    if not isinstance(shape, (list, tuple)) or len(shape) != 2:
        raise ValueError("gm_to_l1_mx_scale expects dst scale shape [16, 2 * k_blocks]")
    rows_dim, cols = shape
    _validate_var_or_int(rows_dim, "dst scale rows")
    rows = _known_int(rows_dim)
    if rows is not None and rows != 16:
        raise ValueError(f"gm_to_l1_mx_scale expects one 16-row MX scale tile in L1, got rows={rows}")
    _validate_var_or_int(cols, "dst scale columns")
    cols_static = _known_int(cols)
    if cols_static is not None:
        if cols_static % 2 != 0:
            raise ValueError(f"gm_to_l1_mx_scale expects even scale columns, got cols={cols_static}")
    return cols // 2


def _validate_mx_scale_packed_gm(src: GMTensor) -> None:
    shape = getattr(src, "shape", None)
    if not isinstance(shape, (list, tuple)) or len(shape) != 2:
        raise ValueError("gm_to_l1_mx_scale expects GM scale packed as [num_blocks, 32]")
    _validate_var_or_int(shape[0], "GM scale block count")
    _validate_var_or_int(shape[1], "GM scale block bytes")
    block_bytes = _known_int(shape[1])
    if block_bytes is not None and block_bytes != 32:
        raise ValueError(
            "gm_to_l1_mx_scale expects GM scale packed as [num_blocks, 32], "
            f"got shape={list(shape)}"
        )


def _validate_mx_scale_dense_gm(src: GMTensor) -> None:
    shape = getattr(src, "shape", None)
    if not isinstance(shape, (list, tuple)) or len(shape) != 2:
        raise ValueError("gm_to_l1_mx_scale_nd2nz expects dense GM scale shape [rows, ceil(k / 32)]")
    _validate_var_or_int(shape[0], "GM dense scale rows")
    _validate_var_or_int(shape[1], "GM dense scale k_groups")


def _infer_dense_mx_scale_transfer(
    src: GMTensor,
) -> Tuple[Union[int, Var], Union[int, Var], Union[int, Var]]:
    shape = getattr(src, "shape", None)
    span = getattr(src, "span", shape)
    if not isinstance(shape, (list, tuple)) or len(shape) != 2:
        raise ValueError("gm_to_l1_mx_scale_nd2nz expects rank-2 dense GM scale")
    if not isinstance(span, (list, tuple)) or len(span) != 2:
        raise ValueError("gm_to_l1_mx_scale_nd2nz expects rank-2 dense GM scale span")
    return span[0], span[1], shape[1]


def _validate_mx_scale_dense_dst(dst: Tensor, rows: object, k_groups: object) -> None:
    shape = getattr(dst, "shape", None)
    if not isinstance(shape, (list, tuple)) or len(shape) != 2:
        raise ValueError("gm_to_l1_mx_scale_nd2nz expects dst scale shape [rows, 2 * ceil(k_groups / 2)]")
    dst_rows, dst_cols = shape
    _validate_var_or_int(dst_rows, "dst dense scale rows")
    _validate_var_or_int(dst_cols, "dst dense scale columns")
    rows_static = _known_int(rows)
    dst_rows_static = _known_int(dst_rows)
    k_groups_static = _known_int(k_groups)
    dst_cols_static = _known_int(dst_cols)
    if rows_static is not None and rows_static <= 0:
        raise ValueError(f"gm_to_l1_mx_scale_nd2nz expects positive rows, got {rows_static}")
    if k_groups_static is not None and k_groups_static <= 0:
        raise ValueError(f"gm_to_l1_mx_scale_nd2nz expects positive k_groups, got {k_groups_static}")
    if rows_static is not None and rows_static % 16 != 0:
        raise ValueError(
            f"gm_to_l1_mx_scale_nd2nz currently requires rows to be 16-row aligned, got {rows_static}"
        )
    if dst_rows_static is not None and dst_rows_static % 16 != 0:
        raise ValueError(
            f"gm_to_l1_mx_scale_nd2nz expects dst rows to be 16-row aligned, got {dst_rows_static}"
        )
    if rows_static is not None and dst_rows_static is not None and rows_static != dst_rows_static:
        raise ValueError(
            f"gm_to_l1_mx_scale_nd2nz expects dst rows to match copied rows, got {dst_rows_static} vs {rows_static}"
        )
    if dst_cols_static is not None and dst_cols_static % 2 != 0:
        raise ValueError(
            f"gm_to_l1_mx_scale_nd2nz expects even dst columns, got {dst_cols_static}"
        )
    if k_groups_static is not None and dst_cols_static is not None:
        expected_cols = _ceil_div_static(k_groups_static, 2) * 2
        if dst_cols_static != expected_cols:
            raise ValueError(
                "gm_to_l1_mx_scale_nd2nz expects dst shape "
                f"[rows, 2 * ceil(k_groups / 2)], got cols={dst_cols_static}, k_groups={k_groups_static}"
            )


def gm_to_l1_mx_scale(
    dst: Tensor,
    src: GMTensor,
    row_tile_idx: Union[int, Var] = 0,
    k_blocks: Union[int, Var, None] = None,
    src_k_blocks: Union[int, Var, None] = None,
    k_block_idx: Union[int, Var] = 0,
) -> None:
    """
    Copy one MX FP8 e8m0 scale row tile from GM to L1.

    GM scale is packed as [row_tile, k64_block, 16, 2], flattened to
    [num_blocks, 32]. dst keeps the L1 shape expected by l1_to_l0_mx:
    [16, 2 * k_blocks].
    """
    assert_valid_device(A5_DEVICES)
    if k_blocks is None:
        k_blocks = _infer_mx_scale_k_blocks_from_l1(dst)
    if src_k_blocks is None:
        src_k_blocks = k_blocks
    _validate_var_or_int(row_tile_idx, "row_tile_idx")
    _validate_var_or_int(k_blocks, "k_blocks")
    _validate_var_or_int(src_k_blocks, "src_k_blocks")
    _validate_var_or_int(k_block_idx, "k_block_idx")
    for label, value in (
        ("row_tile_idx", row_tile_idx),
        ("k_blocks", k_blocks),
        ("src_k_blocks", src_k_blocks),
        ("k_block_idx", k_block_idx),
    ):
        value_static = _known_int(value)
        if value_static is not None and value_static < 0:
            raise ValueError(f"gm_to_l1_mx_scale expects non-negative {label}, got {value_static}")
    k_blocks_static = _known_int(k_blocks)
    src_k_blocks_static = _known_int(src_k_blocks)
    if k_blocks_static is not None and src_k_blocks_static is not None and k_blocks_static > src_k_blocks_static:
        raise ValueError(
            f"gm_to_l1_mx_scale expects k_blocks <= src_k_blocks, got {k_blocks_static} > {src_k_blocks_static}"
        )
    _validate_mx_scale_packed_gm(src)

    block_idx = row_tile_idx * src_k_blocks + k_block_idx
    gm_to_l1_pad(
        dst,
        src[block_idx : block_idx + k_blocks, 0:32],
        n_burst=k_blocks,
        burst_len_element=32,
        src_stride_element=0,
        dst_stride=0,
    )


def gm_to_l1_mx_scale_nd2nz(
    dst: Tensor,
    src: GMTensor,
    rows: Union[int, Var, None] = None,
    k_groups: Union[int, Var, None] = None,
    src_k_groups: Union[int, Var, None] = None,
) -> None:
    """
    Copy dense GM e8m0 scale `[rows, ceil(K / 32)]` into the compact L1 MX scale layout.

    The generated A5 helper reinterprets adjacent e8m0 pairs as `half` and uses
    `Dn2NzParams` to materialize the physical MX scale stream consumed by
    `l1_to_l0_mx`: `[ceil(rows / 16), ceil(k_groups / 2), 16, 2 bytes]`.
    """
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if dst.dtype is not Datatype.uint8 or src.dtype is not Datatype.uint8:
        raise TypeError("gm_to_l1_mx_scale_nd2nz requires DT.uint8 dst/src")
    _validate_tensor_offset_zero(dst, "dst")
    _validate_mx_scale_dense_gm(src)

    if rows is None or k_groups is None:
        if not (rows is None and k_groups is None and src_k_groups is None):
            raise ValueError("rows, k_groups, src_k_groups must all be omitted together for inference")
        rows, k_groups, src_k_groups = _infer_dense_mx_scale_transfer(src)
    elif src_k_groups is None:
        src_k_groups = k_groups

    _validate_var_or_int(rows, "rows")
    _validate_var_or_int(k_groups, "k_groups")
    _validate_var_or_int(src_k_groups, "src_k_groups")
    rows_static = _known_int(rows)
    k_groups_static = _known_int(k_groups)
    src_k_groups_static = _known_int(src_k_groups)
    for label, value_static in (
        ("rows", rows_static),
        ("k_groups", k_groups_static),
        ("src_k_groups", src_k_groups_static),
    ):
        if value_static is not None and value_static <= 0:
            raise ValueError(f"gm_to_l1_mx_scale_nd2nz expects positive {label}, got {value_static}")
    if (
        k_groups_static is not None
        and src_k_groups_static is not None
        and k_groups_static > src_k_groups_static
    ):
        raise ValueError(
            "gm_to_l1_mx_scale_nd2nz expects k_groups <= src_k_groups, got "
            f"{k_groups_static} > {src_k_groups_static}"
        )
    _validate_mx_scale_dense_dst(dst, rows, k_groups)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_l1_mx_scale_nd2nz",
                dst=dst,
                src=src,
                rows=rows,
                k_groups=k_groups,
                src_k_groups=src_k_groups,
            )
        )


def set_constant_to_l1(
    tensor: Tensor,
    val: Union[Var, int, float],
    n_blocks: Union[int, Var, None] = None,
) -> None:
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(tensor, Tensor):
        raise TypeError(f"tensor must be Tensor type, current type: {type(tensor)}")
    if tensor.position is not Position.L1:
        raise ValueError(f"tensor must be at L1 position, current position: {tensor.position}")
    _validate_tensor_offset_zero(tensor, "tensor")
    if not isinstance(val, (Var, int, float)) or isinstance(val, bool):
        raise TypeError(f"val must be Var or numeric scalar type, current type: {type(val)}")
    _validate_scalar_matches_dtype(val, tensor.dtype)
    if n_blocks is None:
        n_blocks = tensor.shape[0] * tensor.shape[1] // tensor.dtype.C0
    _validate_var_or_int(n_blocks, "n_blocks")
    if isinstance(n_blocks, int) and n_blocks < 0:
        raise ValueError(f"n_blocks must be non-negative, current value: {n_blocks}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "set_constant_to_l1",
                tensor=tensor,
                val=val,
                n_blocks=n_blocks,
            )
        )


def l1_to_l0(dst: Tensor, src: Tensor, m_dst: Union[int, Var, None]=None, n_dst: Union[int, Var, None]=None, m_src: Union[int, Var, None]=None, n_src: Union[int, Var, None]=None):
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position not in (Position.L0A, Position.L0B):
        raise ValueError(f"dst must be at L0A or L0B position, current position: {dst.position}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L1:
        raise ValueError(f"src must be at L1 position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if m_dst is None:
        m_dst = src.span[0] if hasattr(src, "span") else src.shape[0]
    if n_dst is None:
        n_dst = src.span[1] if hasattr(src, "span") else src.shape[1]
    if m_src is None:
        m_src = src.shape[0]
    if n_src is None:
        n_src = src.shape[1]

    _validate_var_or_int(m_dst, "m_dst")
    _validate_var_or_int(n_dst, "n_dst")
    _validate_var_or_int(m_src, "m_src")
    _validate_var_or_int(n_src, "n_src")
    dst.is_transpose = src.is_transpose
    if is_c220_family(globvars.device_type):
        if dst.position is Position.L0A:
            # Canonicalize the left operand during L1->L0A transfer so mmad can
            # always decode L0A with a single logical model on C220 devices.
            dst._sim_layout = "ZZ"
        else:
            dst._sim_layout = "ZN" if src.is_transpose else "NZ"
    else:
        dst._sim_layout = "ZN" if src.is_transpose else "NZ"

    if globvars.active_kernel is not None:
        src_row0 = src.offset[0] if hasattr(src, "offset") else 0
        src_col0 = src.offset[1] if hasattr(src, "offset") else 0
        dst_position = "L0A" if dst.position is Position.L0A else "L0B"
        globvars.active_kernel.instructions.append(
            Instruction(
                "l1_to_l0",
                dst=dst,
                src=src,
                m_dst=m_dst,
                n_dst=n_dst,
                m_src=m_src,
                n_src=n_src,
                src_row0=src_row0,
                src_col0=src_col0,
                src_is_transpose=src.is_transpose,
                dst_position=dst_position,
            )
        )


def l1_to_l0a_img2col(dst: Tensor, src) -> None:
    """Load an img2col window from an L1 NC1HWC0 feature map into L0A (load3d).

    ``src`` is an :class:`Img2colSlice` produced by slicing an
    ``img2col(fmap, conv, h, w, c)`` view: ``view[m0:m0+tm, k0:k0+tk]``.
    The destination receives the [m_ext, k_ext] window in the hardware's native
    L0A layout. On a2/b* this path is validated as a ZZ fractal; on a5/950 the
    op is currently reopened only for real-HW probing. Out-of-range
    rows/channels are zero padded by hardware (padValue=0). See doc/topics/conv2d.md
    for the documented load3d semantics.
    """
    from ..utils.conv2d import Img2colSlice

    assert_valid_device(A2_A5_DEVICES)
    # a5/950 is hardware-probe only for now: codegen/real-HW is allowed so we can
    # characterize the true load3d layout, but the Python simulator still rejects
    # the op because its current golden model is 910B3-derived and not trusted on a5.
    if not isinstance(src, Img2colSlice):
        raise TypeError(
            f"src must be an Img2colSlice (img2col(view)[m0:m0+tm, k0:k0+tk]), got: {type(src)}"
        )
    view = src.view
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L0A:
        raise ValueError(f"dst must be at L0A position, current position: {dst.position}")
    if dst.dtype != view.fmap.dtype:
        raise ValueError(
            f"dst/fmap data types must match, current: dst={dst.dtype}, fmap={view.fmap.dtype}"
        )
    tile_elems = src.m_ext * src.k_ext
    dst_capacity = dst.span[0] * dst.span[1]
    if isinstance(tile_elems, int) and isinstance(dst_capacity, int) and tile_elems > dst_capacity:
        raise ValueError(
            f"img2col window [{src.m_ext}, {src.k_ext}] needs {tile_elems} elements, "
            f"dst view holds {dst_capacity}"
        )
    elem_per_frac = 512 // dst.dtype.size
    dst_off = dst.offset[0] * dst.shape[1] + dst.offset[1] if hasattr(dst, "offset") else 0
    if isinstance(dst_off, int) and dst_off % elem_per_frac != 0:
        raise ValueError(
            f"dst offset must be 512B aligned ({elem_per_frac} elements), current: {dst_off}"
        )
    # a2/b* load3d materializes L0A as ZZ; a5/950 as NZ (real-HW validated). This
    # is metadata only -- the simulator's mmad decodes L0A by device -- but keep it
    # accurate so the layout tag matches the device.
    dst._sim_layout = "ZZ" if _is_c220_device() else "NZ"
    dst.is_transpose = False

    # Hardware channelSize only supports remainders {half/bf16: 0/4/8,
    # int8: 0/4/8/16, int4: 0/8/16/32, float/int32: 0/4} mod C0; any other
    # remainder silently corrupts (910B3-verified with C=31). The host packer
    # zero-fills the channel tail, so rounding C up inside the same C1 grid is
    # numerically identical.
    # channelSize is rounded to FULL C0 blocks. Sub-block remainders (4/8/16)
    # are nominally legal, but on 910B3 they repack the K grid (C*Kh*Kw cols
    # compact) and break the C0-grid weight pack wholesale (C=20 -> 24
    # bisected); the host packer zero-fills the tail, so full-grid rounding is
    # numerically identical. Var C rounds via Var arithmetic at runtime.
    c_hw = (view.c + view.c0 - 1) // view.c0 * view.c0

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "l1_to_l0_img2col",
                dst=dst,
                src=view.fmap,
                h=view.h,
                w=view.w,
                c=c_hw,
                c0=view.c0,
                kh=view.conv.kh,
                kw=view.conv.kw,
                pad_l=view.conv.pad[0], pad_r=view.conv.pad[1],
                pad_t=view.conv.pad[2], pad_b=view.conv.pad[3],
                stride_h=view.conv.stride[0], stride_w=view.conv.stride[1],
                dil_h=view.conv.dilation[0], dil_w=view.conv.dilation[1],
                m0=src.m0,
                k0=src.k0,
                m_ext=src.m_ext,
                k_ext=src.k_ext,
                dst_position="L0A",
            )
        )


def l1_to_bt(dst: Tensor, src: Tensor, n: Union[int, Var, None] = None) -> None:
    """Load a bias row from L1 into the BT (bias-table / AscendC TPosition::C2)
    buffer. The matmul bias path consumes it via ``mmad(..., bias=dst)`` on the
    is_init K-tile so that ``C = bias + A@B``. a2/910b and a5/950 (MTE1 pipe). The
    destination is fp32 (float/half/bf16 inputs) or int32 (int8@int8 inputs).
    For floating-point MMAD, A5 MTE1 can widen a contiguous fp16/bf16 L1 bias
    directly into the fp32 C2/BT destination.

    IMPORTANT: the L1 source must be CONTIGUOUS -- stage the bias with a flat burst
    (``gm_to_l1`` on a2, ``gm_to_l1_pad`` on a5), NOT the ``<<=`` nd2nz sugar. nd2nz
    fractalizes the [1, N] vector into 16-col blocks, so a flat L1->C2 copy would
    scatter all but the first fractal."""
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.BT:
        raise ValueError(f"dst must be at BT position, current position: {dst.position}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L1:
        raise ValueError(f"src must be at L1 position, current position: {src.position}")
    supported_dtype_pairs = {
        (Datatype.float, Datatype.float),
        (Datatype.float, Datatype.half),
        (Datatype.float, Datatype.bfloat16),
        (Datatype.int, Datatype.int),
    }
    if (dst.dtype, src.dtype) not in supported_dtype_pairs:
        raise TypeError(
            "l1_to_bt supports fp32 BT from fp32/fp16/bf16 L1 bias or int32 BT "
            f"from int32 L1 bias, current: dst={dst.dtype}, src={src.dtype}"
        )
    _validate_tensor_offset_zero(dst, "dst")
    # The L1 source may carry a contiguous column offset so the matmul shortcut can
    # stage a per-N-tile bias slice bias[:, n0:n0+valid_n]. The bias row is linear in
    # L1, so an offset is just a byte offset into the burst copy; the C2/dst side is
    # always loaded from slot start (offset 0), matching the validated single-tile path.
    if n is None:
        n = dst.shape[0] * dst.shape[1]
    _validate_var_or_int(n, "n")
    if isinstance(n, int):
        if n <= 0:
            raise ValueError(f"n must be positive, current value: {n}")
        bias_bytes = n * dst.dtype.size
        if bias_bytes > globvars.bt_cap * 1024:
            raise ValueError(
                f"bias of {n} {dst.dtype} ({bias_bytes} B) exceeds BT capacity {globvars.bt_cap} KB"
            )

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("l1_to_bt", dst=dst, src=src, n=n)
        )


def l1_to_l0_mx(
    dst: Tensor,
    src: Tensor,
    src_mx: Tensor,
    m_dst: Union[int, Var, None]=None,
    n_dst: Union[int, Var, None]=None,
    m_src: Union[int, Var, None]=None,
    n_src: Union[int, Var, None]=None,
    src_mx_offset_element: Union[int, Var, None]=None,
):
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position not in (Position.L0A, Position.L0B):
        raise ValueError(f"dst must be at L0A or L0B position, current position: {dst.position}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L1:
        raise ValueError(f"src must be at L1 position, current position: {src.position}")
    if not isinstance(src_mx, Tensor):
        raise TypeError(f"src_mx must be Tensor type, current type: {type(src_mx)}")
    if src_mx.position is not Position.L1:
        raise ValueError(f"src_mx must be at L1 position, current position: {src_mx.position}")
    expected_dst_dtype = _mx_dtype_for_src(src.dtype)
    if dst.dtype != expected_dst_dtype:
        raise ValueError(
            f"l1_to_l0_mx requires dst dtype {expected_dst_dtype} for src dtype {src.dtype}, got: {dst.dtype}"
        )
    if _is_fp4_dtype(src.dtype):
        carrier = getattr(src, "_fp4_carrier", None)
        if not isinstance(carrier, Tensor):
            raise TypeError("l1_to_l0_mx requires FP4 src to be created with DT.uint8 carrier .reinterpret(DT.fp4_*)")
        if carrier.position is Position.L1 and carrier.dtype is not Datatype.uint8:
            raise TypeError(f"l1_to_l0_mx requires FP4 L1 src carrier DT.uint8, got: {carrier.dtype}")
        dst_carrier = getattr(dst, "_fp4_carrier", None)
        if not isinstance(dst_carrier, Tensor):
            raise TypeError("l1_to_l0_mx requires FP4 dst to be a reinterpreted L0 carrier tensor")
    if not _is_e8m0_carrier_dtype(src_mx.dtype):
        raise TypeError(f"l1_to_l0_mx requires DT.uint8 scale carrier, current dtype: {src_mx.dtype}")
    src_is_transpose = bool(getattr(src, "is_transpose", False))
    if bool(getattr(src_mx, "is_transpose", False)):
        raise ValueError("l1_to_l0_mx scale tensor cannot be transposed")
    src_rows = src.span[0] if hasattr(src, "span") else src.shape[0]
    src_cols = src.span[1] if hasattr(src, "span") else src.shape[1]
    if m_dst is None:
        m_dst = src_rows
    if n_dst is None:
        n_dst = src_cols
    if m_src is None:
        m_src = src.shape[0]
    if n_src is None:
        n_src = src.shape[1]
    explicit_mx_offset = src_mx_offset_element is not None
    if src_mx_offset_element is None:
        src_mx_offset_element = 0

    _validate_var_or_int(m_dst, "m_dst")
    _validate_var_or_int(n_dst, "n_dst")
    _validate_var_or_int(m_src, "m_src")
    _validate_var_or_int(n_src, "n_src")
    _validate_var_or_int(src_mx_offset_element, "src_mx_offset_element")
    src_mx_offset_static = _known_int(src_mx_offset_element)
    if src_mx_offset_static is not None and src_mx_offset_static < 0:
        raise ValueError(f"src_mx_offset_element must be non-negative, got: {src_mx_offset_static}")
    if src_is_transpose:
        _validate_mx_transpose_tile(m_dst, n_dst, src.dtype)
        scale_rows = n_dst
        scale_k = m_dst
    else:
        scale_rows = m_src
        scale_k = n_dst
    _validate_mx_scale_shape(src_mx, scale_rows, scale_k, allow_larger_physical=explicit_mx_offset)
    dst.is_transpose = src_is_transpose
    dst._sim_layout = "ZN" if src_is_transpose else "NZ"
    if _is_fp4_dtype(src.dtype):
        _mark_packed_view_consumed(src, "l1_to_l0_mx")
        _mark_packed_view_consumed(dst, "l1_to_l0_mx")

    if globvars.active_kernel is not None:
        src_row0 = src.offset[0] if hasattr(src, "offset") else 0
        src_col0 = src.offset[1] if hasattr(src, "offset") else 0
        src_mx_row0 = src_mx.offset[0] if hasattr(src_mx, "offset") else 0
        src_mx_col0 = src_mx.offset[1] if hasattr(src_mx, "offset") else 0
        dst_position = "L0A" if dst.position is Position.L0A else "L0B"
        globvars.active_kernel.instructions.append(
            Instruction(
                "l1_to_l0_mx",
                dst=dst,
                src=src,
                src_mx=src_mx,
                m_dst=m_dst,
                n_dst=n_dst,
                m_src=m_src,
                n_src=n_src,
                src_row0=src_row0,
                src_col0=src_col0,
                src_mx_row0=src_mx_row0,
                src_mx_col0=src_mx_col0,
                src_mx_offset_element=src_mx_offset_element,
                src_is_transpose=src_is_transpose,
                dst_position=dst_position,
            )
        )


def mmad(dst: Tensor, src_a: Tensor, src_b: Tensor, M: Union[int, Var, None]=None, N: Union[int, Var, None]=None, K: Union[int, Var, None]=None, is_init: bool = True, bias: Union[Tensor, None] = None, unit_flag: Union[int, Var] = 0):
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L0C:
        raise ValueError(f"dst must be at L0C position, current position: {dst.position}")
    if not isinstance(src_a, Tensor):
        raise TypeError(f"src_a must be Tensor type, current type: {type(src_a)}")
    if src_a.position is not Position.L0A:
        raise ValueError(f"src_a must be at L0A position, current position: {src_a.position}")
    if not isinstance(src_b, Tensor):
        raise TypeError(f"src_b must be Tensor type, current type: {type(src_b)}")
    if src_b.position is not Position.L0B:
        raise ValueError(f"src_b must be at L0B position, current position: {src_b.position}") 
    src_a_is_int4 = _is_int4_dtype(src_a.dtype)
    src_b_is_int4 = _is_int4_dtype(src_b.dtype)
    src_a_is_hif8 = _is_hif8_dtype(src_a.dtype)
    src_b_is_hif8 = _is_hif8_dtype(src_b.dtype)
    if src_a_is_int4 != src_b_is_int4:
        raise TypeError("int4 MMAD requires both src_a and src_b to be DT.int4 views")
    if src_a_is_hif8 != src_b_is_hif8:
        raise TypeError("hif8 MMAD requires both src_a and src_b to be DT.hif8 views")
    if src_a.dtype != src_b.dtype:
        raise ValueError(
            f"mmad requires src_a/src_b data types to match, got: {src_a.dtype} vs {src_b.dtype}"
        )
    if src_a_is_int4:
        if not _is_c220_device():
            raise ValueError("DT.int4 codegen is only supported on a2/b* devices")
        if dst.dtype is not Datatype.int:
            raise TypeError(f"int4 MMAD requires DT.int destination, current dtype: {dst.dtype}")
        _validate_int4_mmad_operand(src_a, "src_a")
        _validate_int4_mmad_operand(src_b, "src_b")
        _mark_packed_view_consumed(src_a, "mmad")
        _mark_packed_view_consumed(src_b, "mmad")
    elif src_a_is_hif8:
        if not _is_a5_device():
            raise ValueError("DT.hif8 MMAD is only supported on a5/950 devices")
        if dst.dtype is not Datatype.float:
            raise TypeError(f"hif8 MMAD requires DT.float destination, current dtype: {dst.dtype}")
    elif _is_int_dtype(src_a.dtype) and _is_int_dtype(src_b.dtype):
        raise TypeError(
            "DT.int cube matmul is unsupported; use DT.int carriers reinterpreted as DT.int4 for int4 MMAD"
        )
    if M is None:
        M = src_a.shape[1] if src_a.is_transpose else src_a.shape[0]
    if N is None:
        N = src_b.shape[1] if src_b.is_transpose else src_b.shape[0]
    if K is None:
        K = src_a.shape[0] if src_a.is_transpose else src_a.shape[1]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(K, "K")
    _validate_unit_flag(unit_flag)

    if bias is not None:
        if not (_is_c220_device() or _is_a5_device()):
            raise ValueError("mmad bias (BT/C2 bias table) is only supported on a2/910b and a5/950 devices")
        if not isinstance(bias, Tensor):
            raise TypeError(f"bias must be Tensor type, current type: {type(bias)}")
        if bias.position is not Position.BT:
            raise ValueError(f"bias must be at BT position, current position: {bias.position}")
        # Device-aware datatype fence (Mmad tables 8/9): int8@int8 -> int32 bias/dst,
        # every other supported input -> float bias/dst.
        _validate_mmad_bias_dtypes(src_a, src_b, dst, bias)
        if not is_init:
            raise ValueError(
                "mmad bias is only valid on the is_init K-tile (C=bias+A@B); "
                "later accumulate tiles must omit bias"
            )

    if globvars.active_kernel is not None:
        src_a_carrier_cols = None
        src_b_carrier_cols = None
        src_a_logical_rows = None
        src_a_logical_carrier_cols = None
        if src_a_is_int4:
            src_a_carrier = getattr(src_a, "_int4_carrier", None)
            src_b_carrier = getattr(src_b, "_int4_carrier", None)
            if isinstance(src_a_carrier, Tensor) and len(src_a_carrier.shape) > 1:
                src_a_carrier_cols = src_a_carrier.shape[1]
            if isinstance(src_b_carrier, Tensor) and len(src_b_carrier.shape) > 1:
                src_b_carrier_cols = src_b_carrier.shape[1]
            logical_payload_shape = getattr(src_a, "_logical_payload_shape", None)
            if logical_payload_shape is None and isinstance(src_a_carrier, Tensor):
                logical_payload_shape = getattr(src_a_carrier, "_logical_payload_shape", None)
            if isinstance(logical_payload_shape, (list, tuple)) and len(logical_payload_shape) > 1:
                src_a_logical_rows = logical_payload_shape[0]
                src_a_logical_carrier_cols = logical_payload_shape[1]
        dst_row0 = dst.offset[0] if hasattr(dst, "offset") else 0
        dst_col0 = dst.offset[1] if hasattr(dst, "offset") else 0
        dst_rows = dst.shape[0]
        dst_cols = dst.shape[1] if len(dst.shape) > 1 else N
        _mmad_inst = Instruction(
            "mmad",
            dst=dst,
            src_a=src_a,
            src_b=src_b,
            M=M,
            N=N,
            K=K,
            is_init=is_init,
            dst_row0=dst_row0,
            dst_col0=dst_col0,
            dst_rows=dst_rows,
            dst_cols=dst_cols,
            src_a_carrier_cols=src_a_carrier_cols,
            src_b_carrier_cols=src_b_carrier_cols,
            src_a_logical_rows=src_a_logical_rows,
            src_a_logical_carrier_cols=src_a_logical_carrier_cols,
        )
        # Carry the bias tensor only when present so bias-less mmad Instructions
        # stay byte-identical (the simulator path is untouched for existing kernels).
        if bias is not None:
            _mmad_inst.kwargs["bias"] = bias
        if isinstance(unit_flag, Var) or unit_flag != 0:
            _mmad_inst.kwargs["unit_flag"] = unit_flag
        globvars.active_kernel.instructions.append(_mmad_inst)


def mmad_mx(dst: Tensor, src_a: Tensor, src_b: Tensor, M: Union[int, Var, None]=None, N: Union[int, Var, None]=None, K: Union[int, Var, None]=None, is_init: bool = True, bias: Union[Tensor, None] = None):
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L0C:
        raise ValueError(f"dst must be at L0C position, current position: {dst.position}")
    if dst.dtype is not Datatype.float:
        raise TypeError(f"mmad_mx requires DT.float destination, current dtype: {dst.dtype}")
    if not isinstance(src_a, Tensor):
        raise TypeError(f"src_a must be Tensor type, current type: {type(src_a)}")
    if src_a.position is not Position.L0A:
        raise ValueError(f"src_a must be at L0A position, current position: {src_a.position}")
    if not isinstance(src_b, Tensor):
        raise TypeError(f"src_b must be Tensor type, current type: {type(src_b)}")
    if src_b.position is not Position.L0B:
        raise ValueError(f"src_b must be at L0B position, current position: {src_b.position}")
    if not _is_mx_mmad_dtype(src_a.dtype):
        raise TypeError(f"mmad_mx requires MX FP8 or FP4 src_a, current dtype: {src_a.dtype}")
    if not _is_mx_mmad_dtype(src_b.dtype):
        raise TypeError(f"mmad_mx requires MX FP8 or FP4 src_b, current dtype: {src_b.dtype}")
    family_a = _mx_mmad_family(src_a.dtype)
    family_b = _mx_mmad_family(src_b.dtype)
    if family_a != family_b:
        raise TypeError(f"mmad_mx does not support mixed {src_a.dtype}/{src_b.dtype} families yet")
    if family_a == "mxfp4":
        for label, tensor in (("src_a", src_a), ("src_b", src_b)):
            carrier = getattr(tensor, "_fp4_carrier", None)
            if not isinstance(carrier, Tensor):
                raise TypeError(f"mmad_mx requires FP4 {label} to be backed by a carrier tensor")
            _mark_packed_view_consumed(tensor, "mmad_mx")
    if bias is not None:
        # MX matmul with a C2 bias table (a5/950 only; mmad_mx already gates that).
        # The bias is fp32 (MX inputs always accumulate into fp32) and consumed only
        # on the is_init K-tile so C = bias + A@B.
        if not isinstance(bias, Tensor):
            raise TypeError(f"bias must be Tensor type, current type: {type(bias)}")
        if bias.position is not Position.BT:
            raise ValueError(f"bias must be at BT position, current position: {bias.position}")
        if bias.dtype is not Datatype.float:
            raise TypeError(
                f"mmad_mx bias must be DT.float (MX inputs accumulate into fp32), "
                f"current dtype: {bias.dtype}"
            )
        if not is_init:
            raise ValueError(
                "mmad_mx bias is only valid on the is_init K-tile (C=bias+A@B); "
                "later accumulate tiles must omit bias"
            )
    if M is None:
        M = src_a.shape[1] if src_a.is_transpose else src_a.shape[0]
    if N is None:
        N = src_b.shape[1] if src_b.is_transpose else src_b.shape[0]
    if K is None:
        K = src_a.shape[0] if src_a.is_transpose else src_a.shape[1]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(K, "K")

    if globvars.active_kernel is not None:
        dst_row0 = dst.offset[0] if hasattr(dst, "offset") else 0
        dst_col0 = dst.offset[1] if hasattr(dst, "offset") else 0
        dst_rows = dst.shape[0]
        dst_cols = dst.shape[1] if len(dst.shape) > 1 else N
        _mmad_mx_inst = Instruction(
            "mmad_mx",
            dst=dst,
            src_a=src_a,
            src_b=src_b,
            M=M,
            N=N,
            K=K,
            is_init=is_init,
            dst_row0=dst_row0,
            dst_col0=dst_col0,
            dst_rows=dst_rows,
            dst_cols=dst_cols,
        )
        # Carry the bias tensor only when present so bias-less mmad_mx Instructions
        # stay byte-identical (the plain-MX simulator/codegen path is untouched).
        if bias is not None:
            _mmad_mx_inst.kwargs["bias"] = bias
        globvars.active_kernel.instructions.append(_mmad_mx_inst)


def l0c_to_gm_nz2nd(
    dst: GMTensor,
    src: Tensor,
    M: Union[int, Var, None] = None,
    N: Union[int, Var, None] = None,
    N_dst: Union[int, Var, None] = None,
    M_src: Union[int, Var, None] = None,
    relu: bool = False,
    scale: Union[int, float, Var] = 1.0,
    offset: Union[int, Var] = 0,
    hif8_hybrid: bool = False,
):
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"dst must be GMTensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L0C:
        raise ValueError(f"src must be at L0C position, current position: {src.position}")
    if src.dtype not in (Datatype.float, Datatype.int):
        raise ValueError(f"l0c_to_gm_nz2nd src only supports float/int32, current dtype: {src.dtype}")
    if dst.dtype not in (Datatype.half, Datatype.bfloat16, Datatype.float, Datatype.int,
                         Datatype.int8, Datatype.uint8, Datatype.e4m3, Datatype.hif8):
        raise ValueError(f"l0c_to_gm_nz2nd dst only supports fp16/bf16/fp32/int32/int8/uint8/fp8-e4m3/hif8, current dtype: {dst.dtype}")
    if not isinstance(relu, bool):
        raise TypeError(f"relu must be bool type, current type: {type(relu)}")
    if not isinstance(hif8_hybrid, bool):
        raise TypeError(f"hif8_hybrid must be bool type, current type: {type(hif8_hybrid)}")
    # 8-bit fixpipe scalar quant is wired on both a2/V220 and a5/C310 (dst gate above +
    # the A2_A5_DEVICES check at the top cover it).
    if isinstance(scale, bool) or not isinstance(scale, (int, float, Var)):
        raise TypeError(f"scale must be int/float/Var type, current type: {type(scale)}")
    _validate_var_or_int(offset, "offset")
    # a5-only scalar quant modes: int32->bf16 (QS322BF16_PRE) and the *scaled* fp32->float
    # casts (QF322F16/BF16/F32_PRE). Plain fp32->float casts, int32->fp16 (DEQF16) and 8-bit
    # quant stay on a2+a5; only the scaled-float path is gated to a5.
    _scaled = (isinstance(scale, Var)
               or (isinstance(scale, (int, float)) and not isinstance(scale, bool) and float(scale) != 1.0)
               or isinstance(offset, Var)
               or (isinstance(offset, int) and not isinstance(offset, bool) and offset != 0))
    if dst.dtype in (Datatype.e4m3, Datatype.hif8):
        assert_valid_device(A5_DEVICES)              # QF322FP8_PRE / QF322HIF8_PRE[_HYBRID]
    elif dst.dtype == Datatype.bfloat16 and src.dtype == Datatype.int:
        assert_valid_device(A5_DEVICES)
    elif dst.dtype in (Datatype.half, Datatype.bfloat16, Datatype.float) and src.dtype == Datatype.float and _scaled:
        assert_valid_device(A5_DEVICES)
    if M is None or N is None or N_dst is None:
        if not (M is None and N is None and N_dst is None):
            raise ValueError("M, N, N_dst must all be None")
        slice_mask = getattr(dst, "slice_mask", None)
        slice_dims = [idx for idx, flag in enumerate(slice_mask or []) if flag]
        if len(slice_dims) == 2:
            first, second = slice_dims[0], slice_dims[1]
            M = dst.span[first]
            N = dst.span[second]
            N_dst = dst.shape[second]
        elif len(slice_dims) == 1:
            dim = slice_dims[0]
            M = 1
            N = dst.span[dim]
            N_dst = dst.shape[dim]
        else:
            raise ValueError("src must include 1 or 2 slicedimensionsto inferM/N/N_src")
        
    if M_src is None:
        M_src = src.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(M_src, "M_src")
    _validate_l0c_source_footprint("l0c_to_gm_nz2nd", src, M, N, M_src)

    if globvars.active_kernel is not None:
        if globvars.atomic_enabled and globvars.atomic_type is not dst.dtype:
            globvars.active_kernel.instructions.append(
                Instruction("set_atomic_type", dtype=dst.dtype)
            )
            globvars.atomic_type = dst.dtype
        globvars.active_kernel.instructions.append(
            Instruction(
                "l0c_to_gm_nz2nd",
                dst=dst,
                src=src,
                M=M,
                N=N,
                N_dst=N_dst,
                M_src=M_src,
                relu=relu,
                scale=scale,
                offset=offset,
                hif8_hybrid=hif8_hybrid,
            )
        )


def l0c_to_gm_nz2nz(
    dst: GMTensor,
    src: Tensor,
    m_pad: Union[int, Var, None] = None,
    relu: bool = False,
    scale: Union[int, float, Var] = 1.0,
    offset: Union[int, Var] = 0,
    hif8_hybrid: bool = False,
):
    """Store an L0C [m, n] tile to GM keeping NZ (NC1HWC0-style) layout.

    ``dst`` is a [m, C0] row slice of the flat NZ plane [C1o * M_pad, C0]
    (per batch): strip c1 holds out[:, 16c1:16c1+16] as rows c1*M_pad + m.
    ``m_pad`` (rows per strip) is inferred from the dst tensor shape; pass it
    when the plane stacks several batches. n is taken from the L0C tile.
    quantPre dispatch (dst dtype + scale/offset) matches ``l0c_to_gm_nz2nd``.
    """
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"dst must be GMTensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L0C:
        raise ValueError(f"src must be at L0C position, current position: {src.position}")
    if src.dtype not in (Datatype.float, Datatype.int):
        raise ValueError(f"l0c_to_gm_nz2nz src only supports float/int32, current dtype: {src.dtype}")
    if dst.dtype not in (Datatype.half, Datatype.bfloat16, Datatype.float, Datatype.int,
                         Datatype.int8, Datatype.uint8, Datatype.e4m3, Datatype.hif8):
        raise ValueError(f"l0c_to_gm_nz2nz dst only supports fp16/bf16/fp32/int32/int8/uint8/fp8-e4m3/hif8, current dtype: {dst.dtype}")
    if not isinstance(relu, bool):
        raise TypeError(f"relu must be bool type, current type: {type(relu)}")
    if isinstance(scale, bool) or not isinstance(scale, (int, float, Var)):
        raise TypeError(f"scale must be int/float/Var type, current type: {type(scale)}")
    _validate_var_or_int(offset, "offset")
    _scaled = (isinstance(scale, Var)
               or (isinstance(scale, (int, float)) and float(scale) != 1.0)
               or isinstance(offset, Var)
               or (isinstance(offset, int) and offset != 0))
    if dst.dtype in (Datatype.e4m3, Datatype.hif8):
        assert_valid_device(A5_DEVICES)
    elif dst.dtype == Datatype.bfloat16 and src.dtype == Datatype.int:
        assert_valid_device(A5_DEVICES)
    elif dst.dtype in (Datatype.half, Datatype.bfloat16, Datatype.float) and src.dtype == Datatype.float and _scaled:
        assert_valid_device(A5_DEVICES)
    c0g = max(16, 32 // dst.dtype.size)   # dst NC1HWC0 C0: 16 for >=2B, 32 for 8-bit
    if int(dst.shape[1]) != c0g:
        raise ValueError(f"dst must be a [*, {c0g}] NZ plane for {dst.dtype}, got width {dst.shape[1]}")
    m, n = int(src.shape[0]), int(src.shape[1])
    if m % 16 or n % c0g:
        raise ValueError(f"L0C tile must be [16k, {c0g}k] for {dst.dtype} dst, got [{m}, {n}]")
    # Var-start dst slices have a Var span (stop-start does not fold); only the
    # static case is checkable here -- the FIX burst writes exactly m rows anyway.
    if isinstance(dst.span[0], int) and dst.span[0] != m:
        raise ValueError(f"dst slice rows ({dst.span[0]}) must equal L0C m ({m})")
    if m_pad is None:
        if not isinstance(dst.shape[0], int):
            raise ValueError("m_pad cannot be inferred from a Var-shaped dst plane; pass it explicitly")
        m_pad = int(dst.shape[0]) // (n // c0g)
    if isinstance(m_pad, int):
        if m_pad % 16 or m_pad < m:
            raise ValueError(f"m_pad must be 16-aligned and >= m, got {m_pad}")
    elif not isinstance(m_pad, Var):
        raise TypeError(f"m_pad must be int or Var, current type: {type(m_pad)}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "l0c_to_gm_nz2nz",
                dst=dst,
                src=src,
                M=m,
                N=n,
                M_pad=int(m_pad) if isinstance(m_pad, int) else m_pad,
                M_src=src.shape[0],
                relu=relu,
                scale=scale,
                offset=offset,
                hif8_hybrid=hif8_hybrid,
            )
        )


def l0c_to_gm_nz2dn(
    dst: GMTensor,
    src: Tensor,
    M: Union[int, Var, None] = None,
    N: Union[int, Var, None] = None,
    M_dst: Union[int, Var, None] = None,
    M_src: Union[int, Var, None] = None,
    relu: bool = False,
    scale: Union[int, float, Var] = 1.0,
    offset: Union[int, Var] = 0,
    hif8_hybrid: bool = False,
    unit_flag: Union[int, Var] = 0,
):
    """Store an L0C [m, n] tile to GM transposed (NZ2DN / COLUMN_MAJOR fixpipe).

    The result is written as its transpose: ``dst`` is an [n, m] ND plane with
    ``dst[j, i] = L0C[i, j]``. ``M``/``N`` are the L0C source dims (m rows,
    n cols, default from ``src``); ``M_dst`` is the row width / stride of the
    [n, m] dst (default ``dst.shape[-1]``, must be >= m). Sugar: ``gm <<= l0c.T``.
    a5/C310 only -- the NZ2DN fixpipe is unvalidated on a2. quantPre dispatch
    (dst dtype + scale/offset) matches ``l0c_to_gm_nz2nd``.
    """
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"dst must be GMTensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L0C:
        raise ValueError(f"src must be at L0C position, current position: {src.position}")
    if src.dtype not in (Datatype.float, Datatype.int):
        raise ValueError(f"l0c_to_gm_nz2dn src only supports float/int32, current dtype: {src.dtype}")
    if dst.dtype not in (Datatype.half, Datatype.bfloat16, Datatype.float, Datatype.int,
                         Datatype.int8, Datatype.uint8, Datatype.e4m3, Datatype.hif8):
        raise ValueError(f"l0c_to_gm_nz2dn dst only supports fp16/bf16/fp32/int32/int8/uint8/fp8-e4m3/hif8, current dtype: {dst.dtype}")
    if not isinstance(relu, bool):
        raise TypeError(f"relu must be bool type, current type: {type(relu)}")
    if not isinstance(hif8_hybrid, bool):
        raise TypeError(f"hif8_hybrid must be bool type, current type: {type(hif8_hybrid)}")
    _validate_unit_flag(unit_flag)
    if isinstance(scale, bool) or not isinstance(scale, (int, float, Var)):
        raise TypeError(f"scale must be int/float/Var type, current type: {type(scale)}")
    _validate_var_or_int(offset, "offset")
    if M is None:
        M = src.shape[0]
    if N is None:
        N = src.shape[1]
    if M_dst is None:
        M_dst = dst.shape[-1]
    if M_src is None:
        M_src = src.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(M_dst, "M_dst")
    _validate_var_or_int(M_src, "M_src")
    _validate_l0c_source_footprint("l0c_to_gm_nz2dn", src, M, N, M_src)

    if globvars.active_kernel is not None:
        if globvars.atomic_enabled and globvars.atomic_type is not dst.dtype:
            globvars.active_kernel.instructions.append(
                Instruction("set_atomic_type", dtype=dst.dtype)
            )
            globvars.atomic_type = dst.dtype
        _fixpipe_inst = Instruction(
            "l0c_to_gm_nz2dn",
            dst=dst,
            src=src,
            M=M,
            N=N,
            M_dst=M_dst,
            M_src=M_src,
            relu=relu,
            scale=scale,
            offset=offset,
            hif8_hybrid=hif8_hybrid,
        )
        if isinstance(unit_flag, Var) or unit_flag != 0:
            _fixpipe_inst.kwargs["unit_flag"] = unit_flag
        globvars.active_kernel.instructions.append(_fixpipe_inst)


def l0c_to_l1(
    dst: Tensor,
    src: Tensor,
    M: Union[int, Var, None] = None,
    N: Union[int, Var, None] = None,
    M_dst: Union[int, Var, None] = None,
    M_src: Union[int, Var, None] = None,
    relu: bool = False,
):
    assert_valid_device(A2_A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L0C:
        raise ValueError(f"src must be at L0C position, current position: {src.position}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if src.dtype is not Datatype.float:
        raise ValueError(f"l0c_to_l1 src only supports float, current dtype: {src.dtype}")
    if dst.dtype not in (Datatype.bfloat16, Datatype.half, Datatype.float):
        raise ValueError(f"l0c_to_l1 dst only supports bf16/fp16/fp32, current dtype: {dst.dtype}")
    if is_c220_family(globvars.device_type) and dst.dtype is Datatype.float:
        raise ValueError(
            "l0c_to_l1 does not support float destination on C220 devices, "
            f"current device_type: {globvars.device_type}"
        )
    if M is None:
        M = dst.span[0] if hasattr(dst, "span") else dst.shape[0]
    if N is None:
        N = dst.span[1] if hasattr(dst, "span") else dst.shape[1]
    if M_dst is None:
        M_dst = dst.shape[0]
    if M_src is None:
        M_src = src.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(M_dst, "M_dst")
    _validate_var_or_int(M_src, "M_src")
    _validate_l0c_source_footprint("l0c_to_l1", src, M, N, M_src)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "l0c_to_l1",
                dst=dst,
                src=src,
                M=M,
                N=N,
                M_dst=M_dst,
                M_src=M_src,
                relu=relu,
            )
        )


def l0c_to_ub(
    dst: Tensor,
    src: Tensor,
    M: Union[int, Var, None] = None,
    N: Union[int, Var, None] = None,
    N_dst: Union[int, Var, None] = None,
    M_src: Union[int, Var, None] = None,
    dual_mode: Union[int, DualModeType] = DualMode.SPLITM,
    sub_block_id: Union[int, Var, None] = None,
    relu: bool = False,
    scale: Union[int, float, Var] = 1.0,
    offset: Union[int, Var] = 0,
    hif8_hybrid: bool = False,
) -> None:
    assert_valid_device(A5_DEVICES)
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L0C:
        raise ValueError(f"src must be at L0C position, current position: {src.position}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    # Same (L0C src, UB dst) dtype pairs as l0c_to_gm_nz2nd -- the fixpipe quant MODE is
    # inferred from the pair (relaxed from the old dst==src cast-only rule).
    if src.dtype not in (Datatype.float, Datatype.int):
        raise ValueError(f"l0c_to_ub src only supports float/int32, current dtype: {src.dtype}")
    if dst.dtype not in (Datatype.half, Datatype.bfloat16, Datatype.float, Datatype.int,
                         Datatype.int8, Datatype.uint8, Datatype.e4m3, Datatype.hif8):
        raise ValueError(f"l0c_to_ub dst only supports fp16/bf16/fp32/int32/int8/uint8/fp8-e4m3/hif8, current dtype: {dst.dtype}")
    _validate_l0c_slice_source(src, "l0c_to_ub src")   # static L0C sub-tiles allowed (split-and-move)

    mode_value = _resolve_dual_mode_value(dual_mode)
    if sub_block_id is None:
        # SINGLE writes exactly ONE vector subblock, so the target must be chosen explicitly: a
        # silent default (subblock 0) would drop the store meant for the other subblock. The dual
        # modes (SPLITM/SPLITN) write BOTH subblocks, so the id is unused there and defaults to 0.
        if mode_value == DualMode.SINGLE.value:
            raise ValueError(
                "l0c_to_ub: dual_mode=SINGLE targets one vector subblock; pass sub_block_id=0 or 1 "
                "explicitly (no silent default). To fill both subblocks, issue two SINGLE stores.")
        sub_block_id = 0
    if not isinstance(sub_block_id, (Var, int)):
        raise TypeError(f"sub_block_id must be Var or int type, current type: {type(sub_block_id)}")
    if isinstance(sub_block_id, int) and sub_block_id not in (0, 1):
        raise ValueError(f"sub_block_id must be 0 or 1, got: {sub_block_id}")
    if not isinstance(relu, bool):
        raise TypeError(f"relu must be bool type, current type: {type(relu)}")
    if not isinstance(hif8_hybrid, bool):
        raise TypeError(f"hif8_hybrid must be bool type, current type: {type(hif8_hybrid)}")
    if isinstance(scale, bool) or not isinstance(scale, (int, float, Var)):
        raise TypeError(f"scale must be int/float/Var type, current type: {type(scale)}")
    _validate_var_or_int(offset, "offset")

    # The fixpipe scalar quant rides on the deqScalar, which is only available when the dual
    # destination control is off (SINGLE). SPLITM/SPLITN split the L0C tile across the two
    # vector subblocks and support neither relu nor any non-default requant parameter; they
    # only carry the SAME-TYPE plain copy (fp32 -> fp32 or int32 -> int32). Even the deqScalar-
    # free float downcasts (fp32 -> fp16/bf16) are NOT supported in split mode -- they require
    # dual_mode=SINGLE, like the quant/dequant modes.
    _scaled = (isinstance(scale, Var)
               or (isinstance(scale, (int, float)) and not isinstance(scale, bool) and float(scale) != 1.0)
               or isinstance(offset, Var)
               or (isinstance(offset, int) and not isinstance(offset, bool) and offset != 0))
    _requant_used = _scaled or hif8_hybrid
    if mode_value != DualMode.SINGLE.value:
        if relu:
            raise ValueError("l0c_to_ub: relu requires dual_mode=SINGLE (SPLITM/SPLITN cannot enable relu)")
        if _requant_used:
            raise ValueError("l0c_to_ub: requant parameters (scale/offset/hif8_hybrid) require dual_mode=SINGLE")
        _dual_cast_ok = ((src.dtype == Datatype.float and dst.dtype == Datatype.float)
                         or (src.dtype == Datatype.int and dst.dtype == Datatype.int))
        if not _dual_cast_ok:
            raise ValueError(
                "l0c_to_ub: dual_mode SPLITM/SPLITN only supports the same-type plain copy "
                "(fp32 -> fp32 or int32 -> int32); float downcasts (fp32 -> fp16/bf16) and "
                "quant/dequant dtypes require dual_mode=SINGLE")

    if M is None or N is None or N_dst is None:
        if not (M is None and N is None and N_dst is None):
            raise ValueError("M, N, N_dst must all be None")
        if mode_value == DualMode.SINGLE.value:
            M = dst.span[0]
            N = dst.span[1]
        elif mode_value == DualMode.SPLITM.value:
            M = dst.span[0] * 2
            N = dst.span[1]
        else:
            M = dst.span[0]
            N = dst.span[1] * 2
        N_dst = dst.shape[1]

    if M_src is None:
        # M_src is the L0C fractal row stride = the declared tile height (shape[0]), NOT the
        # sliced span[0]: a sub-tile l0c[16:32, :] still strides over the full 32-row tile.
        M_src = src.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(N_dst, "N_dst")
    _validate_var_or_int(M_src, "M_src")
    _validate_l0c_source_footprint("l0c_to_ub", src, M, N, M_src)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "l0c_to_ub",
                dst=dst,
                src=src,
                M=M,
                N=N,
                N_dst=N_dst,
                M_src=M_src,
                dual_mode=mode_value,
                sub_block_id=sub_block_id,
                relu=relu,
                scale=scale,
                offset=offset,
                hif8_hybrid=hif8_hybrid,
            )
        )
