from typing import Optional

from ...utils.datatype import Datatype, is_complex_dtype
from ...utils.reg import Reg, MaskReg
from ...utils.instruction import Instruction
from .microutils import (
    ensure_mask,
    reject_complex_dtype,
    require_bitwise_dtype,
    require_micro,
)
from ..vec.vecutils import A5_DEVICES, assert_valid_device


# |z| collapses a complex register to a real modulus of half its element width.
_COMPLEX_ABS_REAL = {
    Datatype.complex32: Datatype.half,
    Datatype.complex64: Datatype.float,
}


def _validate_unary_regs(dst: Reg, src: Reg):
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    return micro


def _unary_op(opname: str, dst: Reg, src: Reg, mask: Optional[MaskReg]) -> None:
    micro = _validate_unary_regs(dst, src)
    # Abs is the only complex-capable unary and takes its own path below; every
    # other unary (exp/ln/sqrt/relu/neg/copy/...) is real-only.
    reject_complex_dtype(opname, dst.dtype)
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(Instruction(opname, dst=dst, src=src, mask=mask))


def _bitwise_unary_op(opname: str, dst: Reg, src: Reg, mask: Optional[MaskReg]) -> None:
    micro = _validate_unary_regs(dst, src)
    require_bitwise_dtype(opname, dst.dtype)
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(Instruction(opname, dst=dst, src=src, mask=mask))


def exp(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vexp", dst, src, mask)


def abs(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if is_complex_dtype(src.dtype):
        # Complex abs is the one unary whose output dtype differs from its input:
        # |z| is real, so complex32 -> half and complex64 -> float. Mask granularity
        # follows the real output register.
        expected = _COMPLEX_ABS_REAL[src.dtype]
        if dst.dtype != expected:
            raise ValueError(
                f"complex abs of {src.dtype} must write a {expected} destination "
                f"(|z| is real), got {dst.dtype}"
            )
        # Size the mask by the complex source: |z| keeps the per-element lane count
        # of the input (a complex64 reg has 32 lanes, its real modulus also 32),
        # not the wider lane count of a full real register.
        mask = ensure_mask(mask, src.dtype, micro)
        micro.instructions.append(Instruction("micro_vabs", dst=dst, src=src, mask=mask))
        return
    _unary_op("micro_vabs", dst, src, mask)


def relu(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vrelu", dst, src, mask)


def sqrt(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vsqrt", dst, src, mask)


def ln(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vln", dst, src, mask)


def log(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vlog", dst, src, mask)


def log2(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vlog2", dst, src, mask)


def log10(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vlog10", dst, src, mask)


def neg(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vneg", dst, src, mask)


def vnot(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _bitwise_unary_op("micro_vnot", dst, src, mask)


def vcopy(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_op("micro_vcopy", dst, src, mask)
