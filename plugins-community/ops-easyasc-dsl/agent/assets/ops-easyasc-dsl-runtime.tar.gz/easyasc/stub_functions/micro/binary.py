from typing import Optional

from ...utils.datatype import Datatype as DT
from ...utils.reg import Reg, MaskReg
from ...utils.instruction import Instruction
from ...utils.divconfig import DivAlgo, DivConfig
from .microutils import (
    ensure_mask,
    reject_complex_dtype,
    require_bitwise_dtype,
    require_micro,
)
from ..vec.vecutils import A5_DEVICES, assert_valid_device


_VMAX_DTYPES = (
    DT.uint8,
    DT.int8,
    DT.uint16,
    DT.int16,
    DT.uint32,
    DT.int,
    DT.uint64,
    DT.int64,
    DT.half,
    DT.float,
    DT.bfloat16,
)


def _validate_binary_regs(dst: Reg, src1: Reg, src2: Reg):
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if not isinstance(src2, Reg):
        raise TypeError(f"src2 must be Reg type, current type: {type(src2)}")
    if dst.dtype != src1.dtype or dst.dtype != src2.dtype:
        raise ValueError("dst/src1/src2 data types must match") 
    return micro


def _binary_op(
    opname: str,
    dst: Reg,
    src1: Reg,
    src2: Reg,
    mask: Optional[MaskReg],
    allow_complex: bool = False,
) -> None:
    micro = _validate_binary_regs(dst, src1, src2)
    # Default-reject complex: only Add/Sub/Mul/Div opt in. min/prelu (and any
    # future binary op routed here) have no complex semantics.
    if not allow_complex:
        reject_complex_dtype(opname, dst.dtype)
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction(opname, dst=dst, src1=src1, src2=src2, mask=mask)
    )


def _vmax_op(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg]) -> None:
    micro = _validate_binary_regs(dst, src1, src2)
    if dst.dtype not in _VMAX_DTYPES:
        allowed = ", ".join(str(dtype) for dtype in _VMAX_DTYPES)
        raise ValueError(f"vmax only supports {allowed}, got {dst.dtype}")
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction("micro_vmax", dst=dst, src1=src1, src2=src2, mask=mask)
    )


def _bitwise_op(opname: str, dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg]) -> None:
    micro = _validate_binary_regs(dst, src1, src2)
    require_bitwise_dtype(opname, dst.dtype)
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction(opname, dst=dst, src1=src1, src2=src2, mask=mask)
    )


_SIGNED_SHIFT_DTYPES = (DT.int8, DT.int16, DT.int, DT.int64)


def _require_signed_shift_amount(opname: str, dtype) -> None:
    """C310 takes the reg-reg shift amount in a signed register only.

    ``ShiftLeftImpl`` / ``ShiftRightImpl`` in
    ``tikcpp/tikcfw/impl/micro_api/dav_c310/kernel_micro_vec_binary_impl.h``
    assert ``SupportType<ActualU, int8_t, int16_t, int32_t, int64_t>()`` on the
    amount operand while the data operand also accepts the unsigned widths.
    ``_bitwise_op`` already pins all three operands to one dtype, so the whole
    op is signed-only; an unsigned register builds in the simulator and fails
    the on-board static assert.
    """
    if dtype not in _SIGNED_SHIFT_DTYPES:
        allowed = ", ".join(str(item) for item in _SIGNED_SHIFT_DTYPES)
        raise TypeError(
            f"{opname} needs a signed shift-amount register on this device: "
            f"allowed dtypes are {allowed}; current dtype: {dtype}"
        )


def vmax(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _vmax_op(dst, src1, src2, mask)


def vmin(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _binary_op("micro_vmin", dst, src1, src2, mask)


def add(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _binary_op("micro_vadd", dst, src1, src2, mask, allow_complex=True)


def sub(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _binary_op("micro_vsub", dst, src1, src2, mask, allow_complex=True)


def mul(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _binary_op("micro_vmul", dst, src1, src2, mask, allow_complex=True)


def div(
    dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None,
    config: Optional[DivConfig] = None,
) -> None:
    assert_valid_device(A5_DEVICES)
    micro = _validate_binary_regs(dst, src1, src2)
    if config is not None and not isinstance(config, DivConfig):
        raise TypeError(f"config must be DivConfig, got: {type(config)}")
    if config is not None and config.name == "":
        raise ValueError("div config must set name")
    if config is not None:
        zero_ulp = (
            DivAlgo.PRECISION_0ULP_FTZ_TRUE,
            DivAlgo.PRECISION_0ULP_FTZ_FALSE,
        )
        if config.algo in zero_ulp and dst.dtype != DT.float:
            raise TypeError(
                "0-ULP micro div modes are supported only for float registers"
            )
        if config.precision_mode and dst.dtype != DT.float:
            raise TypeError(
                "precision-mode micro div is supported only for float registers"
            )
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction(
            "micro_vdiv", dst=dst, src1=src1, src2=src2, mask=mask,
            config=config,
        )
    )


def vand(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _bitwise_op("micro_vand", dst, src1, src2, mask)


def vor(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _bitwise_op("micro_vor", dst, src1, src2, mask)


def vxor(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _bitwise_op("micro_vxor", dst, src1, src2, mask)


def prelu(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _binary_op("micro_vprelu", dst, src1, src2, mask)


def shiftl(dst: Reg, src: Reg, shift: Reg, mask: Optional[MaskReg] = None) -> None:
    """Per-lane (reg-reg) logical left shift: dst[i] = src[i] << shift[i]
    (MicroAPI::ShiftLeft). The shift amount is a Reg (one value per lane), unlike
    ``shiftls`` whose amount is a scalar. Signed integer dtypes only; dst/src/shift
    share the dtype."""
    assert_valid_device(A5_DEVICES)
    if isinstance(dst, Reg):
        _require_signed_shift_amount("shiftl", dst.dtype)
    _bitwise_op("micro_shiftl", dst, src, shift, mask)


def shiftr(dst: Reg, src: Reg, shift: Reg, mask: Optional[MaskReg] = None) -> None:
    """Per-lane (reg-reg) right shift: dst[i] = src[i] >> shift[i]
    (MicroAPI::ShiftRight), arithmetic on the signed dtypes this op accepts. The
    shift amount is a Reg (one value per lane), unlike ``shiftrs`` whose amount is
    a scalar. Signed integer dtypes only; dst/src/shift share the dtype."""
    assert_valid_device(A5_DEVICES)
    if isinstance(dst, Reg):
        _require_signed_shift_amount("shiftr", dst.dtype)
    _bitwise_op("micro_shiftr", dst, src, shift, mask)
