"""Debug-only micro op: print a Reg/RegList's live value in the simulator.

`print_reg` is the register-level counterpart to the kernel-scope ``sim_print``.
Inside a ``@vf`` MicroModule, ``Reg``/``RegList`` values only exist as simulator
runtime state and are otherwise invisible; ``print_reg`` dumps their per-lane
values to stderr so register-level bugs can be chased directly.

It is a **no-op in codegen** (emits no device code) -- purely a simulator
debugging aid. Placed inside a micro ``for`` loop it fires once per iteration, so
you can watch a value evolve row by row.

Example::

    @vf()
    def my_vf(src_ub: Tensor, dst_ub: Tensor):
        r = Reg(DT.float)
        for i in range(L):
            r <<= src_ub[0:1, i:i + 1]
            print_reg(r, label=f"row")          # prints r every iteration
            dst_ub[0:1, i:i + 1] <<= r
"""
from typing import Union

from ...utils.reg import Reg, RegList
from ...utils.instruction import Instruction
from .microutils import require_micro


def print_reg(reg: Union[Reg, RegList], label: str = "", lanes: int = 8) -> None:
    """Print a ``Reg`` / ``RegList`` value during simulation (no-op in codegen).

    Args:
        reg:   the ``Reg``, ``RegList``, or ``RegList`` element (e.g. ``rl[0]``)
               to print.
        label: free-text tag prefixed to the output line to identify the site.
        lanes: max number of leading lane values shown per register.
    """
    micro = require_micro()
    if not isinstance(reg, (Reg, RegList)):
        raise TypeError(f"reg must be Reg or RegList, current type: {type(reg)}")
    if not isinstance(label, str):
        raise TypeError(f"label must be str, current type: {type(label)}")
    if not isinstance(lanes, int) or lanes <= 0:
        raise ValueError(f"lanes must be a positive int, current value: {lanes}")
    micro.instructions.append(
        Instruction("micro_print_reg", reg=reg, label=label, lanes=lanes)
    )
