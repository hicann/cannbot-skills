import math
from typing import Optional, Union

from ... import globvars
from ...utils.datatype import DataTypeValue, Datatype, is_complex_dtype
from ...utils.reg import MaskReg
from ...utils.var import Var
from ..vec.vecutils import A5_DEVICES, assert_valid_device


BITWISE_DTYPES = (
    Datatype.uint8,
    Datatype.int8,
    Datatype.uint16,
    Datatype.int16,
    Datatype.uint32,
    Datatype.int,
    Datatype.uint64,
    Datatype.int64,
)


def require_micro():
    assert_valid_device(A5_DEVICES)
    micro = globvars.active_micro
    if micro is None:
        raise RuntimeError("micro function can only be used in MicroModule")
    return micro


def ensure_mask(mask: Optional[MaskReg], dtype: DataTypeValue, micro, reg_num: int = 1) -> MaskReg:
    if mask is None:
        mask = micro.get_mask(dtype, reg_num)
    if not isinstance(mask, MaskReg):
        raise TypeError(f"mask must be MaskReg type, current type: {type(mask)}")
    if mask.reg_num != reg_num:
        raise ValueError(f"mask reg_num must be {reg_num}, got: {mask.reg_num}")
    return mask


def require_bitwise_dtype(opname: str, dtype: DataTypeValue) -> None:
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
    if dtype not in BITWISE_DTYPES:
        allowed = ", ".join(str(item) for item in BITWISE_DTYPES)
        raise TypeError(f"{opname} only supports integer bitwise dtypes: {allowed}; current dtype: {dtype}")


INT64_DTYPES = (Datatype.int64, Datatype.uint64)


def reject_64bit_dtype(opname: str, dtype: DataTypeValue) -> None:
    """Guard for micro ops the Ascend950 (dav_c310) does NOT implement for 64-bit
    integers, even though the API doc lists them. Verified on-board (int64 fails to
    compile with a SupportType static_assert): ``axpy`` (ternary_scalar), the block
    reduces ``cgadd``/``cgmax``/``cgmin`` (ReduceDataBlock, 32-bit int max), and the
    pairwise reduce ``cpadd`` (PairReduceElem, float/half only). Rejecting at trace
    time keeps the DSL and simulator aligned with hardware instead of surfacing the
    failure only at board build time."""
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
    if dtype in INT64_DTYPES:
        raise TypeError(
            f"{opname} does not support 64-bit integer dtypes (int64_t/uint64_t) "
            f"on the current device; current dtype: {dtype}"
        )


def reject_complex_dtype(opname: str, dtype: DataTypeValue) -> None:
    """Guard for micro ops that are undefined for complex registers.

    Complex support (complex32/complex64) is limited to the documented arithmetic
    set -- Add/Sub/Mul/Div, Adds/Muls, Abs and Duplicate. Everything else
    (compare/select, logic, shift, min/max, reductions, cast, gather, ...) has no
    complex semantics, so reject it at trace time with a clear message instead of
    letting the simulator or an on-board build fail obscurely. Mirrors
    ``reject_64bit_dtype``."""
    if isinstance(dtype, DataTypeValue) and is_complex_dtype(dtype):
        raise TypeError(
            f"{opname} does not support complex dtypes (complex32/complex64); "
            f"current dtype: {dtype}"
        )


def format_complex_scalar(value: Union[Var, int, float, complex]):
    """Resolve a complex immediate for complex Adds/Muls/Duplicate.

    A ``Var`` passes through unchanged (its dtype is validated by the caller); a
    python ``complex``/``int``/``float`` is promoted to ``complex`` and carried on
    the instruction so the simulator's ``_numc`` can consume it directly. The C++
    codegen literal for a complex immediate depends on the exact on-board complex
    type spelling and is intentionally not emitted here -- that path is gated on
    the on-board capability probe."""
    if isinstance(value, Var):
        return value
    if isinstance(value, bool):
        raise TypeError("complex scalar cannot be bool")
    if isinstance(value, (int, float, complex)):
        return complex(value)
    raise TypeError(
        f"complex scalar must be Var or numeric (int/float/complex), got {type(value)}"
    )


def dtype_scalar_family(dtype: DataTypeValue) -> Optional[str]:
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
    if dtype in (Datatype.float, Datatype.half, Datatype.bfloat16):
        return "float"
    if dtype in (
        Datatype.int,
        Datatype.int8,
        Datatype.uint8,
        Datatype.int16,
        Datatype.uint16,
        Datatype.uint32,
        Datatype.uint64,
        Datatype.int64,
    ):
        return "int"
    return None


def scalar_value_family(value: Union[Var, int, float]) -> Optional[str]:
    if isinstance(value, Var):
        if value.dtype is None:
            raise TypeError("Var scalar must have dtype inside vf scalar helpers")
        return dtype_scalar_family(value.dtype)
    if isinstance(value, bool):
        return "int"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    raise TypeError(f"value must be Var or numeric value type, current type: {type(value)}")


def _float_immediate(value: float) -> str:
    """Spell a float scalar immediate for device code.

    ``inf``/``nan`` have no plain literal form: ``f"{float(value)}f"`` renders
    them as ``inff`` / ``nanf``, which are undeclared identifiers in C++ and
    are not parseable as numbers by the simulator either. The compiler
    builtins are header-independent ``float``-typed constant expressions and
    match what ``asc_utils.float_to_cpp_literal`` already emits elsewhere.
    """
    value = float(value)
    if math.isnan(value):
        return '__builtin_nanf("")'
    if math.isinf(value):
        return "-__builtin_inff()" if value < 0 else "__builtin_inff()"
    return f"{value}f"


def format_scalar(value: Union[Var, int, float], dtype: DataTypeValue) -> Union[Var, str]:
    target_family = dtype_scalar_family(dtype)
    if target_family is None:
        raise TypeError(
            "vf scalar helpers only support float/int scalar families, "
            f"current dtype: {dtype}"
        )

    value_family = scalar_value_family(value)
    if target_family == "float" and value_family == "int":
        raise TypeError(
            "vf scalar helpers do not support implicit int-to-float conversion, "
            f"target dtype: {dtype}, value: {value!r}"
        )

    if isinstance(value, Var):
        return value
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
    dtype_name = getattr(dtype, "name", None)
    if dtype_name == "float":
        return _float_immediate(value)
    if dtype_name == "half":
        return f"(half){_float_immediate(value)}"
    if dtype_name == "bfloat16_t":
        return f"(bfloat16_t){_float_immediate(value)}"
    if isinstance(value, float):
        value = int(value)
    # 64-bit integer immediates must carry their type: MicroAPI Axpy asserts the
    # scalar type is one of {half, float, uint64_t, int64_t}, so a bare `int`
    # literal (the C++ default) fails to compile for an int64/uint64 register on
    # dav_c310. A typed literal also avoids `int` overflow for values above 2**31.
    # 8/16/32-bit integer regs keep the bare literal (verified on-board).
    if dtype_name in ("int64_t", "uint64_t"):
        return f"({dtype_name}){int(value)}"
    return f"{int(value)}"


def dtype_size(dtype: DataTypeValue) -> int:
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
    return dtype.size
