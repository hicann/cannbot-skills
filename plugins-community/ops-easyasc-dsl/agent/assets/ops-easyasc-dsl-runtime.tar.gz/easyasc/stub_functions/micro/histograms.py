"""``MicroAPI::Histograms`` -- the hardware byte histogram (``dhistv2``/``chistv2``).

One instruction bins a whole ``uint8`` register into a ``uint16`` register of
counters, which is what makes a radix select cheap: a pass over the data costs
one histogram per register group instead of one compare per bin.

The destination is **read-modify-write**: every call adds into the counters that
are already there, so a tile is accumulated by looping the instruction and the
register only has to be cleared once.

A ``uint16`` destination holds 128 counters and a byte has 256 possible values,
so a full histogram takes two calls -- ``BIN0`` bins the values ``[0, 128)`` and
``BIN1`` the values ``[128, 256)``.  The remaining bin selectors exist for the
narrower destinations other Ascend generations expose and bin nothing here.
"""

from typing import Optional

from ...utils.datatype import Datatype as DT
from ...utils.instruction import Instruction
from ...utils.reg import MaskReg, Reg
from .microutils import ensure_mask, require_micro


BIN_WIDTH = 128


class HistBinValue:
    """One 128-value window of the byte range."""

    def __init__(self, name: str, index: int) -> None:
        self.name = name
        self.index = index

    def __repr__(self) -> str:
        return self.name

    __str__ = __repr__


class HistBin:
    """``MicroAPI::HistogramsBinType``: which window of byte values is binned."""

    BIN0 = HistBinValue("BIN0", 0)
    BIN1 = HistBinValue("BIN1", 1)
    BIN2 = HistBinValue("BIN2", 2)
    BIN3 = HistBinValue("BIN3", 3)
    BIN4 = HistBinValue("BIN4", 4)
    BIN5 = HistBinValue("BIN5", 5)
    BIN6 = HistBinValue("BIN6", 6)
    BIN7 = HistBinValue("BIN7", 7)


class HistModeValue:
    """Whether a counter holds its own bin's count or a running total."""

    def __init__(self, name: str) -> None:
        self.name = name

    def __repr__(self) -> str:
        return self.name

    __str__ = __repr__


class HistMode:
    """``MicroAPI::HistogramsType``."""

    FREQUENCY = HistModeValue("FREQUENCY")    # dhistv2: per-bin count
    ACCUMULATE = HistModeValue("ACCUMULATE")  # chistv2: inclusive prefix count


def histograms(
    dst: Reg,
    src: Reg,
    bin_group: HistBinValue = HistBin.BIN0,
    mode: HistModeValue = HistMode.FREQUENCY,
    mask: Optional[MaskReg] = None,
) -> None:
    """Bin ``src``'s active bytes into ``dst``'s counters, adding to what is there.

    ``src`` is a ``uint8`` register (256 lanes) and ``dst`` a ``uint16`` register
    (128 counters).  ``mask`` selects the source lanes and is therefore a b8 mask
    -- ``update_mask`` on a ``MaskReg(DT.uint8)`` produces one, and two
    :func:`pack` calls bring a b32 lane's low byte down to the b8 lane the mask
    then selects.

    With ``HistMode.FREQUENCY`` counter ``j`` counts the bytes equal to
    ``128*bin_group + j``.  With ``HistMode.ACCUMULATE`` it counts every byte
    ``<= 128*bin_group + j``, so ``BIN0`` and ``BIN1`` concatenate into one
    256-entry inclusive prefix count over the whole byte range.
    """
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if not isinstance(bin_group, HistBinValue):
        raise TypeError(
            f"bin_group must be a HistBin value, current type: {type(bin_group)}")
    if not isinstance(mode, HistModeValue):
        raise TypeError(f"mode must be a HistMode value, current type: {type(mode)}")
    # CANN kernel_micro_histograms_impl.h asserts SupportType<src, uint8_t> and
    # SupportType<dst, uint16_t> on dav_c310; no other pair lowers.
    if src.dtype is not DT.uint8:
        raise TypeError(f"histograms src must be uint8, current dtype: {src.dtype}")
    if dst.dtype is not DT.uint16:
        raise TypeError(f"histograms dst must be uint16, current dtype: {dst.dtype}")
    if src.reg_num != 1 or dst.reg_num != 1:
        raise ValueError("histograms operates on single registers")
    mask = ensure_mask(mask, src.dtype, micro)
    micro.instructions.append(
        Instruction(
            "micro_histograms",
            dst=dst,
            src=src,
            mask=mask,
            bin_group=bin_group,
            mode=mode,
            ddst=dst.dtype,
            dsrc=src.dtype,
        )
    )
