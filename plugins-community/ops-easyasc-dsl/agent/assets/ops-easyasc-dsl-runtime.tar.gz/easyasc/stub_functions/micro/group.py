from typing import Optional

from ...utils.datatype import Datatype
from ...utils.reg import Reg, MaskReg
from ...utils.instruction import Instruction
from .microutils import ensure_mask, reject_64bit_dtype, require_micro
from ..vec.vecutils import A5_DEVICES, assert_valid_device


# dav_c310 `kernel_micro_vec_reduce_impl.h` guards every whole-register reduce
# with `SupportType<T, unsigned short, short, unsigned int, int, float, half,
# unsigned long, long>()`.  bfloat16 and the 8-bit types are absent, so a
# `Reduce` on them is a static_assert at CANN build time -- an error the
# simulator cannot see.  Reject it while tracing instead.
_REDUCE_DTYPES = frozenset((
    Datatype.uint16, Datatype.int16, Datatype.uint32, Datatype.int,
    Datatype.float, Datatype.half, Datatype.uint64, Datatype.int64,
))


def _reject_unsupported_reduce_dtype(opname: str, dtype) -> None:
    if dtype not in _REDUCE_DTYPES:
        raise ValueError(
            f"{opname} is not available for {dtype} on this device: the whole-"
            "register Reduce supports uint16/int16/uint32/int32/float/half/"
            "uint64/int64 only. Promote to float (or reduce a monotone integer "
            "key) first."
        )


# `ReduceSum` is the one whole-register reduce whose guard is a (dst, src)
# *pair*: a 16-bit integer sum has to land in a 32-bit destination, because the
# only `vcadd` overload for a 16-bit source is `__VF_VCADD(u32, u16, ...)`.
# Passing matching 16-bit types is a CANN build error, not a simulator one.
_REDUCE_SUM_PAIRS = frozenset((
    (Datatype.int, Datatype.int16),
    (Datatype.uint32, Datatype.uint16),
    (Datatype.uint32, Datatype.uint32),
    (Datatype.int, Datatype.int),
    (Datatype.half, Datatype.half),
    (Datatype.float, Datatype.float),
    (Datatype.uint64, Datatype.uint64),
    (Datatype.int64, Datatype.int64),
))

# `PairReduceSum` is float-only on dav_c310.
_PAIR_REDUCE_DTYPES = frozenset((Datatype.float, Datatype.half))


def _group_op(opname: str, dst: Reg, src: Reg, mask: Optional[MaskReg]) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    _reject_unsupported_reduce_dtype(opname, dst.dtype)
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(Instruction(opname, dst=dst, src=src, mask=mask))


def cmax(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _group_op("micro_vcmax", dst, src, mask)


def cgmax(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    if isinstance(dst, Reg):
        reject_64bit_dtype("cgmax", dst.dtype)
    _group_op("micro_vcgmax", dst, src, mask)


def cmin(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _group_op("micro_vcmin", dst, src, mask)


def cgmin(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    if isinstance(dst, Reg):
        reject_64bit_dtype("cgmin", dst.dtype)
    _group_op("micro_vcgmin", dst, src, mask)


def cadd(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if (dst.dtype, src.dtype) not in _REDUCE_SUM_PAIRS:
        raise ValueError(
            f"cadd cannot sum {src.dtype} into {dst.dtype}: ReduceSum supports "
            "int16->int32, uint16->uint32 and the same-width int32/uint32/"
            "float/half/int64/uint64 pairs only. A 16-bit sum must widen -- "
            "give the destination a 32-bit dtype."
        )
    # The mask selects source lanes, so it is sized by the source dtype: a
    # widening sum reads 128 u16 lanes and writes one u32 lane.
    mask = ensure_mask(mask, src.dtype, micro)
    micro.instructions.append(Instruction("micro_vcadd", dst=dst, src=src, mask=mask))


def cgadd(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    if isinstance(dst, Reg):
        reject_64bit_dtype("cgadd", dst.dtype)
    _group_op("micro_vcgadd", dst, src, mask)


def cpadd(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    if isinstance(dst, Reg):
        reject_64bit_dtype("cpadd", dst.dtype)
        if dst.dtype not in _PAIR_REDUCE_DTYPES:
            raise ValueError(
                f"cpadd is not available for {dst.dtype} on this device: "
                "PairReduceSum supports float and half only."
            )
    _group_op("micro_vcpadd", dst, src, mask)
