from ...utils.castconfig import CastConfig
from .arange import arange
from .barrier import vf_barrier
from .binary import vmax, vmin, add, sub, mul, div, vand, vor, vxor, prelu, shiftl, shiftr
from .cast import cast
from .compare import compare, select
from .debug import print_reg
from .datamove import (
    LoadDist,
    LoadDistValue,
    StoreDist,
    StoreDistValue,
    ub_to_reg,
    reg_to_ub,
    ub_to_reg_continuous,
    ub_to_reg_interleave,
    reg_to_ub_continuous,
    reg_to_ub_downsample,
    reg_to_ub_pack4,
    reg_to_ub_single,
    reg_to_ub_normal,
    reg_to_ub_interleave,
    ub_to_reg_normal,
    ub_to_reg_single,
    ub_to_reg_upsample,
    ub_to_reg_downsample,
    ub_to_reg_unpack,
    ub_to_reg_unpack4,
    ub_to_reg_brcb,
    ub_to_reg_gather,
    ub_to_reg_gatherb,
    ub_to_mask,
    mask_to_ub,
    reg_to_ub_scatter,
    gather,
    gather_mask,
    squeeze,
    clear_spr,
    unsqueeze,
)
from .dup import dup
from .fused import abssub, expsub, muldstadd, muladddst, mulscast
from .group import cmax, cgmax, cmin, cgmin, cadd, cgadd, cpadd
from .histograms import histograms, HistBin, HistMode
from .interleave import deinterleave, interleave
from .pack import pack, HighLowPart
from .mask import (
    mask_not,
    mask_and,
    mask_or,
    mask_xor,
    mask_mov,
    mask_interleave,
    mask_deinterleave,
    mask_sel,
    mask_pack,
    mask_unpack,
    move_mask_spr,
    update_mask,
)
from .unary import exp, abs, relu, sqrt, ln, log, log2, log10, neg, vnot, vcopy
from .unaryscalar import vmaxs, vmins, adds, muls, lrelu, shiftls, shiftrs, axpy
