from ...utils.reg import Reg, MaskReg
from ...utils.instruction import Instruction
from ... import globvars
from ...utils.castconfig import CastConfig, RegLayout
from ...utils.datatype import Datatype
from ..cast_rules import round_mode_name, validate_cast_pair
from .microutils import require_micro, ensure_mask
from typing import Optional


_FP4_DTYPES = (Datatype.fp4_e2m1, Datatype.fp4_e1m2)
_C310_DEVICES = ("950", "950pr")
_C310_BROKEN_ONE_WIDENING_PAIRS = frozenset([
    (Datatype.int8, Datatype.half),
    (Datatype.half, Datatype.float),
    (Datatype.bfloat16, Datatype.float),
    (Datatype.float, Datatype.int64),
])


def _is_bfloat16_fp4_pair(dst: Reg, src: Reg) -> bool:
    return (
        (src.dtype is Datatype.bfloat16 and dst.dtype in _FP4_DTYPES)
        or (dst.dtype is Datatype.bfloat16 and src.dtype in _FP4_DTYPES)
    )


def cast(dst: Reg, src: Reg, config: Optional[CastConfig] = None, mask: Optional[MaskReg] = None) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if config is not None and not isinstance(config, CastConfig):
        raise TypeError(f"config must be CastConfig type, current type: {type(config)}")
    validate_cast_pair(src.dtype, dst.dtype, "a5", validate_round_mode=False)
    # CANN applies a cast mask at the wider of the source/destination element
    # widths. BF16<->FP4 therefore uses a 128-lane bfloat16 mask, not a
    # 512-logical-lane FP4 mask.
    mask_dtype = Datatype.bfloat16 if _is_bfloat16_fp4_pair(dst, src) else dst.dtype
    reg_num = max(dst.reg_num, src.reg_num)
    mask = ensure_mask(mask, mask_dtype, micro, reg_num=reg_num)
    if config is None:
        if _is_bfloat16_fp4_pair(dst, src):
            config = micro.get_default_fp4_cast_cfg(encode=dst.dtype in _FP4_DTYPES)
        else:
            config = micro.get_default_cast_cfg(dst.dtype)
    # CANN 9.0 headers accept these ONE-part widening traits, but exact C310
    # hardware probes produce an all-zero ONE half. Keep this guard pair- and
    # target-specific: other layouts, cast directions, pairs, and fused APIs
    # retain their documented contracts.
    if (
        globvars.device_type in _C310_DEVICES
        and str(config.reg_layout) == str(RegLayout.ONE)
        and (src.dtype, dst.dtype) in _C310_BROKEN_ONE_WIDENING_PAIRS
    ):
        raise ValueError(
            "plain micro cast RegLayout.ONE widening is hardware-broken on "
            f"{globvars.device_type}/C310 for {src.dtype} -> {dst.dtype}; use "
            "ZERO-only Interleave widening or a trait-two RegLayout.ZERO cast"
        )
    if _is_bfloat16_fp4_pair(dst, src):
        if str(config.reg_layout) not in ("ZERO", "ONE", "TWO", "THREE"):
            raise ValueError(
                "bfloat16<->FP4 micro cast requires RegLayout.ZERO/ONE/TWO/THREE, got "
                f"RegLayout.{config.reg_layout}"
            )
        if str(config.merge_mode) != "ZEROING":
            raise ValueError("bfloat16<->FP4 micro cast only supports MaskMergeMode.ZEROING")
    # board (dav_c310): Cast MERGING is only supported for the ZERO RegLayout slot -- a board-only
    # ccec static_assert the simulator can't see (kernel_reg_compute_vec_vconv_impl.h).
    if str(getattr(getattr(config, "merge_mode", None), "name", "ZEROING")) == "MERGING" \
            and str(config.reg_layout) != "ZERO":
        raise ValueError(
            "cast MERGING is board-supported only for RegLayout.ZERO on dav_c310, got "
            f"RegLayout.{config.reg_layout}")
    mode_name = round_mode_name(config.round_mode)
    validate_hif8_encode_mode = dst.dtype == Datatype.hif8 and src.dtype in (Datatype.float, Datatype.half)
    if mode_name == "CAST_HYBRID" or validate_hif8_encode_mode or _is_bfloat16_fp4_pair(dst, src):
        validate_cast_pair(src.dtype, dst.dtype, "a5", config.round_mode)
    if not isinstance(mask, MaskReg):
        raise TypeError(f"mask must be MaskReg type, current type: {type(mask)}")
    if config.name == "":
        raise ValueError("cast config must set name")

    micro.instructions.append(
        Instruction(
            "micro_cast",
            dst=dst,
            src=src,
            config=config,
            mask=mask,
            ddst=dst.dtype,
            dsrc=src.dtype,
        )
    )
