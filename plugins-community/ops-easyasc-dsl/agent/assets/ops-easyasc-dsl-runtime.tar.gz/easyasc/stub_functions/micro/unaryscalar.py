from typing import Optional, Union

from ...utils.datatype import Datatype, is_complex_dtype
from ...utils.reg import Reg, MaskReg
from ...utils.var import Var
from ...utils.instruction import Instruction
from .microutils import (
    ensure_mask,
    format_complex_scalar,
    format_scalar,
    reject_complex_dtype,
    require_micro,
)
from ..vec.vecutils import A5_DEVICES, assert_valid_device


# MicroAPI Axpy asserts the scalar type U is one of these (dav_c310
# kernel_micro_vec_ternary_scalar_impl.h). A literal is typed by format_scalar, but
# a Var scalar keeps its own dtype -- an int32 Var (the default for a bare python
# int) would compile-fail on-board with a SupportType assertion, so validate early.
_AXPY_SCALAR_DTYPES = (Datatype.half, Datatype.float, Datatype.int64, Datatype.uint64)


def _unary_scalar_op(
    opname: str,
    dst: Reg,
    src: Reg,
    value: Union[Var, int, float, complex],
    mask: Optional[MaskReg],
    allow_complex: bool = False,
) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    complex_op = allow_complex and is_complex_dtype(src.dtype)
    allowed_types = (Var, int, float, complex) if complex_op else (Var, int, float)
    if not isinstance(value, allowed_types):
        raise TypeError(f"value must be Var or numeric value type, current type: {type(value)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    # Default-reject complex: only Adds/Muls opt in. maxs/mins/lrelu/shift/axpy
    # have no complex semantics.
    if not allow_complex:
        reject_complex_dtype(opname, src.dtype)
    mask = ensure_mask(mask, dst.dtype, micro)
    v = format_complex_scalar(value) if complex_op else format_scalar(value, src.dtype)
    micro.instructions.append(Instruction(opname, dst=dst, src=src, v=v, mask=mask))


def vmaxs(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_scalar_op("micro_vmaxs", dst, src, value, mask)


def vmins(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_scalar_op("micro_vmins", dst, src, value, mask)


def adds(dst: Reg, src: Reg, value: Union[Var, int, float, complex], mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_scalar_op("micro_vadds", dst, src, value, mask, allow_complex=True)


def muls(dst: Reg, src: Reg, value: Union[Var, int, float, complex], mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_scalar_op("micro_vmuls", dst, src, value, mask, allow_complex=True)


def lrelu(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    _unary_scalar_op("micro_vlrelu", dst, src, value, mask)


def shiftls(dst: Reg, src: Reg, value: Union[Var, int], mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    if not isinstance(value, (Var, int)):
        raise TypeError(f"value must be Var or int type, current type: {type(value)}")
    _unary_scalar_op("micro_shiftls", dst, src, value, mask)


def shiftrs(dst: Reg, src: Reg, value: Union[Var, int], mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    if not isinstance(value, (Var, int)):
        raise TypeError(f"value must be Var or int type, current type: {type(value)}")
    _unary_scalar_op("micro_shiftrs", dst, src, value, mask)


def axpy(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    # int64/uint64 axpy is supported on-board once the scalar carries its type
    # (see format_scalar): a bare `int` immediate is what previously failed the
    # MicroAPI Axpy SupportType<U, ...> assertion, not the register dtype. Literals
    # are typed automatically, but a Var scalar keeps its own dtype -- reject an
    # unsupported one (e.g. the int32 default of `Var(5)`) with a clear message.
    if isinstance(value, Var) and value.dtype is not None and value.dtype not in _AXPY_SCALAR_DTYPES:
        allowed = ", ".join(str(d) for d in _AXPY_SCALAR_DTYPES)
        raise TypeError(
            f"axpy Var scalar dtype must be one of {allowed} (MicroAPI Axpy scalar "
            f"type constraint); got {value.dtype}. Construct it as "
            f"Var(v, dtype=DT.int64) rather than the int32 default of Var(v)."
        )
    _unary_scalar_op("micro_vaxpy", dst, src, value, mask)
