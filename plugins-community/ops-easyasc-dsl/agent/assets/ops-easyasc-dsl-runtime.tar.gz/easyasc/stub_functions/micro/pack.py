from ...utils.reg import Reg
from ...utils.instruction import Instruction
from .microutils import require_micro


class HighLowPartValue:
    """Which half of dst the packed (low-bits) result lands in."""

    def __init__(self, name: str):
        self.name = name

    def __repr__(self):
        return self.name

    __str__ = __repr__


class HighLowPart:
    LOWEST = HighLowPartValue("LOWEST")     # packed result -> low half of dst
    HIGHEST = HighLowPartValue("HIGHEST")   # packed result -> high half of dst


# CANN Reg::Pack SupportType (dst<-src): dst element is half the byte width of src;
# Pack takes the low (dst-width) bits of every src element. Strings match str(dtype).
_PACK_PAIRS = {
    ("uint8_t", "uint16_t"), ("uint8_t", "int16_t"),
    ("uint16_t", "uint32_t"), ("uint16_t", "int"),
    ("uint32_t", "uint64_t"), ("uint32_t", "int64_t"),
}


def pack(dst: Reg, src: Reg, low_or_high: HighLowPartValue = HighLowPart.LOWEST) -> None:
    """Pack<T,U,part>(dst, src): take the low (dst-width) bits of every src element and write
    them contiguously into the LOW (LOWEST) or HIGH (HIGHEST) half of dst. Native `vpack` on
    dav_c310 for non-64-bit src. Compresses a stride-sparse reg into a contiguous one -- e.g.
    fp8 P-pack: a "2-of-every-4-lane" e4m3 reg, viewed as uint32, packs to contiguous uint16."""
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if not isinstance(low_or_high, HighLowPartValue):
        raise TypeError(
            f"low_or_high must be HighLowPart.LOWEST/HIGHEST, current type: {type(low_or_high)}")
    if (str(dst.dtype), str(src.dtype)) not in _PACK_PAIRS:
        raise ValueError(
            f"pack unsupported dtype pair (dst<-src): {dst.dtype}<-{src.dtype}; "
            f"supported pairs: {sorted(_PACK_PAIRS)}")
    micro.instructions.append(
        Instruction("micro_pack", dst=dst, src=src, part=low_or_high,
                    ddst=dst.dtype, dsrc=src.dtype)
    )
