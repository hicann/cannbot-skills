from typing import Optional, Union

from ...utils.comparemode import CompareModeType
from ...utils.reg import Reg, MaskReg
from ...utils.var import Var
from ...utils.instruction import Instruction
from .microutils import (
    dtype_scalar_family,
    ensure_mask,
    format_scalar,
    require_micro,
    scalar_value_family,
)


def compare(
    dst: MaskReg,
    src1: Reg,
    src2: Union[Var, int, float, Reg],
    mode: CompareModeType,
    mask: Optional[MaskReg] = None,
) -> None:
    micro = require_micro()
    if not isinstance(dst, MaskReg):
        raise TypeError(f"dst must be MaskReg type, current type: {type(dst)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if not isinstance(src2, (Var, int, float, Reg)):
        raise TypeError(f"src2 must be Reg or numeric value/Var type, current type: {type(src2)}")
    if not isinstance(mode, CompareModeType):
        raise TypeError(f"mode must be CompareModeType type, current type: {type(mode)}")
    if dst.dtype != src1.dtype:
        raise ValueError("dst/src1 data types must match") 
    mask = ensure_mask(mask, dst.dtype, micro)

    if isinstance(src2, Reg):
        if src1.dtype != src2.dtype:
            raise ValueError("src1/src2 data types must match")
        micro.instructions.append(
            Instruction(
                "micro_compare",
                dst=dst,
                src1=src1,
                src2=src2,
                dtype=dst.dtype,
                mode=mode,
                mask=mask,
            )
        )
    else:
        src1_family = dtype_scalar_family(src1.dtype)
        if src1_family is None:
            raise TypeError(
                "compare scalar only supports float/int register families, "
                f"current dtype: {src1.dtype}"
            )
        src2_family = scalar_value_family(src2)
        if src2_family != src1_family:
            raise TypeError(
                "compare scalar requires matching float/int families, "
                f"src1 dtype: {src1.dtype}, scalar: {src2!r}"
            )
        # A5 board limit: a sub-fp32 float register (fp16/bf16/fp8) compared against a
        # *runtime* (Var) scalar lowers to a CompareScalar whose float->narrow scalar
        # conversion the cce backend cannot hoist out of the enclosing loop
        # ("fatal error: error in backend: Unsupported Inst must be hoisted"), so the
        # kernel fails to build on-board even though the simulator accepts it. The
        # simulator can't model this (it's a codegen-lowering limit, not a value issue),
        # so reject it here. Lane-select compares must use an integer lane-id register --
        # int16 is 128 lanes, matching fp16. See qk_softmax_tn256_fp16_vf.py.
        if src1_family == "float" and src1.dtype.size < 4 and isinstance(src2, Var):
            raise TypeError(
                f"compare: a {src1.dtype} register vs a runtime (Var) scalar is not "
                "supported on A5 -- the cce backend cannot hoist the narrowing scalar "
                "conversion out of the loop. Use an int16 lane-id register for lane "
                "selects (int16 = 128 lanes, matches fp16); a compile-time-constant "
                "scalar is fine. See kernels/a5/attention/pfa/qk_softmax_tn256_fp16_vf.py."
            )
        v = format_scalar(src2, src1.dtype)
        micro.instructions.append(
            Instruction(
                "micro_compares",
                dst=dst,
                src1=src1,
                src2=v,
                dtype=dst.dtype,
                mode=mode,
                mask=mask,
            )
        )


def select(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if not isinstance(src2, Reg):
        raise TypeError(f"src2 must be Reg type, current type: {type(src2)}")
    if src1.dtype != src2.dtype or dst.dtype != src1.dtype:
        raise ValueError("dst/src1/src2 data types must match") 
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction("micro_select", dst=dst, src1=src1, src2=src2, mask=mask)
    )
