import warnings
from typing import Optional, Union

from ...utils.datatype import Datatype as DT
from ...utils.reg import Reg, MaskReg
from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.positions import Position
from ...utils.instruction import Instruction
from .microutils import dtype_size, ensure_mask, require_micro
from ..vec.vecutils import A5_DEVICES, assert_valid_device


class LoadDistValue:
    def __init__(self, name: str) -> None:
        self.name = name

    def __repr__(self) -> str:
        return f"LoadDistValue({self.name!r})"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        return isinstance(other, LoadDistValue) and self.name == other.name


class LoadDist:
    NORMAL = LoadDistValue("NORMAL")
    DOWNSAMPLE = LoadDistValue("DOWNSAMPLE")
    UPSAMPLE = LoadDistValue("UPSAMPLE")
    SINGLE_VALUE = LoadDistValue("SINGLE_VALUE")
    BRCB = LoadDistValue("BRCB")
    UNPACK = LoadDistValue("UNPACK")
    UNPACK4 = LoadDistValue("UNPACK4")


class StoreDistValue:
    def __init__(self, name: str) -> None:
        self.name = name

    def __repr__(self) -> str:
        return f"StoreDistValue({self.name!r})"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        return isinstance(other, StoreDistValue) and self.name == other.name


class StoreDist:
    DOWNSAMPLE = StoreDistValue("DOWNSAMPLE")
    PACK4 = StoreDistValue("PACK4")
    SINGLE_VALUE = StoreDistValue("SINGLE_VALUE")
    NORMAL = StoreDistValue("NORMAL")


def _dtype_list(dtypes) -> str:
    return " or ".join(str(dtype) for dtype in dtypes)


def _require_index_dtype(opname: str, elem_size: int, index: Reg, expected) -> None:
    if index.dtype not in expected:
        raise ValueError(
            f"{opname} index for {elem_size * 8}-bit data must be {_dtype_list(expected)}, "
            f"got {index.dtype}"
        )


def _require_block_copy_dtype(opname: str, dtype) -> None:
    size = dtype_size(dtype)
    if size not in (1, 2, 4):
        raise ValueError(
            f"{opname} DATA_BLOCK_COPY only supports b8/b16/b32, got {dtype}; "
            "use the continuous normal LoadAlign/StoreAlign path for b64"
        )


# micro register related data move
def ub_to_reg(
    dst: Reg,
    src: Tensor,
    blk_stride: Union[int, Var] = 1,
    mask: Optional[MaskReg] = None,
) -> None:
    micro = require_micro()
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    _require_block_copy_dtype("ub_to_reg", dst.dtype)
    mask = ensure_mask(mask, dst.dtype, micro, reg_num=dst.reg_num)
    micro.instructions.append(
        Instruction("micro_ub2reg", dst=dst, src=src, blk_stride=blk_stride, mask=mask)
    )


def reg_to_ub(
    dst: Tensor,
    src: Reg,
    blk_stride: Union[int, Var] = 1,
    mask: Optional[MaskReg] = None,
) -> None:
    micro = require_micro()
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    _require_block_copy_dtype("reg_to_ub", dst.dtype)
    mask = ensure_mask(mask, dst.dtype, micro, reg_num=src.reg_num)
    micro.instructions.append(
        Instruction("micro_reg2ub", dst=dst, src=src, blk_stride=blk_stride, mask=mask)
    )


def ub_to_reg_continuous(dst: Reg, src: Tensor, loaddist: LoadDistValue) -> None:
    micro = require_micro()
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(loaddist, LoadDistValue):
        raise TypeError(f"loaddist must be LoadDistValue type, current type: {type(loaddist)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    size = dtype_size(dst.dtype)
    if loaddist == LoadDist.NORMAL:
        if size in (1, 2, 4, 8):
            mode = "DIST_NORM"
        else:
            raise ValueError(f"{dst.dtype} does not support normal")
    elif loaddist == LoadDist.DOWNSAMPLE:
        if size == 1:
            mode = "DIST_DS_B8"
        elif size == 2:
            mode = "DIST_DS_B16"
        else:
            raise ValueError("downsample does not support 32-bit type")
    elif loaddist == LoadDist.UPSAMPLE:
        if size == 1:
            mode = "DIST_US_B8"
        elif size == 2:
            mode = "DIST_US_B16"
        else:
            raise ValueError("upsample does not support 32-bit type")
    elif loaddist == LoadDist.SINGLE_VALUE:
        if size == 1:
            mode = "DIST_BRC_B8"
        elif size == 2:
            mode = "DIST_BRC_B16"
        elif size == 4:
            mode = "DIST_BRC_B32"
        else:
            raise ValueError(f"{dst.dtype} does not support single_value")
    elif loaddist == LoadDist.BRCB:
        if size == 2:
            mode = "DIST_E2B_B16"
        elif size == 4:
            mode = "DIST_E2B_B32"
        else:
            raise ValueError(f"{dst.dtype} does not support brcb")
    elif loaddist == LoadDist.UNPACK:
        if size == 1:
            mode = "DIST_UNPACK_B8"
        elif size == 2:
            mode = "DIST_UNPACK_B16"
        elif size == 4:
            mode = "DIST_UNPACK_B32"
        else:
            raise ValueError(f"{dst.dtype} does not support unpack")
    elif loaddist == LoadDist.UNPACK4:
        if size == 1:
            mode = "DIST_UNPACK4_B8"
        else:
            raise ValueError("unpack4 only supports 8-bit type")
    else:
        raise ValueError(f"unknown loaddist: {loaddist}")
    micro.instructions.append(
        Instruction("micro_ub2regcont", dst=dst, src=src, mode=mode)
    )


def ub_to_reg_interleave(dst0: Reg, dst1: Reg, src: Tensor) -> None:
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst0, Reg):
        raise TypeError(f"dst0 must be Reg type, current type: {type(dst0)}")
    if not isinstance(dst1, Reg):
        raise TypeError(f"dst1 must be Reg type, current type: {type(dst1)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst0.dtype != dst1.dtype or dst0.dtype != src.dtype:
        raise ValueError("dst0/dst1/src data types must match")
    size = dtype_size(dst0.dtype)
    if size == 1:
        mode = "DIST_DINTLV_B8"
    elif size == 2:
        mode = "DIST_DINTLV_B16"
    elif size == 4:
        mode = "DIST_DINTLV_B32"
    else:
        raise ValueError(f"{dst0.dtype} does not support interleave")
    micro.instructions.append(
        Instruction("micro_ub2reginterleave", dst0=dst0, dst1=dst1, src=src, mode=mode)
    )


def reg_to_ub_interleave(
    dst: Tensor, src0: Reg, src1: Reg, mask: Optional[MaskReg] = None,
) -> None:
    """StoreAlign<T, StoreDist::DIST_INTLV_Bxx>(dst, src0, src1, mask): the dual-source
    store, the mirror of ``ub_to_reg_interleave``. It writes ``2 * VL`` elements -- 512
    bytes -- in ONE issue, interleaving the two registers: ``dst[2k] = src0[k]`` and
    ``dst[2k+1] = src1[k]``. Use it whenever a vector body already holds its results
    split even/odd (which is exactly what ``ub_to_reg_interleave`` produces), so a
    streaming kernel never pays two 256-byte stores for 512 bytes of output."""
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if not isinstance(src0, Reg):
        raise TypeError(f"src0 must be Reg type, current type: {type(src0)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if src0.dtype != src1.dtype or dst.dtype != src0.dtype:
        raise ValueError("dst/src0/src1 data types must match")
    if src0.reg_num != src1.reg_num:
        raise ValueError("src0/src1 reg_num values must match")
    size = dtype_size(dst.dtype)
    if size == 1:
        mode = "DIST_INTLV_B8"
    elif size == 2:
        mode = "DIST_INTLV_B16"
    elif size == 4:
        mode = "DIST_INTLV_B32"
    else:
        raise ValueError(f"{dst.dtype} does not support interleave store")
    mask = ensure_mask(mask, dst.dtype, micro, reg_num=src0.reg_num)
    micro.instructions.append(
        Instruction(
            "micro_reg2ubinterleave", dst=dst, src0=src0, src1=src1, mask=mask,
            mode=mode,
        )
    )


def reg_to_ub_continuous(
    dst: Tensor,
    src: Reg,
    mask: Optional[MaskReg],
    storedist: StoreDistValue,
) -> None:
    micro = require_micro()
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if not isinstance(storedist, StoreDistValue):
        raise TypeError(f"storedist must be StoreDistValue type, current type: {type(storedist)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    mask = ensure_mask(mask, dst.dtype, micro, reg_num=src.reg_num)

    size = dtype_size(dst.dtype)
    if storedist == StoreDist.DOWNSAMPLE:
        if size == 1:
            mode = "DIST_PACK_B16"
        elif size == 2:
            mode = "DIST_PACK_B32"
        elif size == 4:
            mode = "DIST_PACK_B64"
        else:
            raise ValueError("downsample does not support 64-bit type")
    elif storedist == StoreDist.PACK4:
        if size == 1:
            mode = "DIST_PACK4_B32"
        else:
            raise ValueError("pack4 only supports 8-bit type")
    elif storedist == StoreDist.SINGLE_VALUE:
        if size == 1:
            mode = "DIST_FIRST_ELEMENT_B8"
        elif size == 2:
            mode = "DIST_FIRST_ELEMENT_B16"
        elif size == 4:
            mode = "DIST_FIRST_ELEMENT_B32"
        else:
            raise ValueError(f"{dst.dtype} does not support single_value")
    elif storedist == StoreDist.NORMAL:
        if size == 1:
            mode = "DIST_NORM_B8"
        elif size == 2:
            mode = "DIST_NORM_B16"
        elif size == 4:
            mode = "DIST_NORM_B32"
        elif size == 8:
            mode = "DIST_NORM"
        else:
            raise ValueError(f"{dst.dtype} does not support normal")
    else:
        raise ValueError(f"unknown storedist: {storedist}")
    micro.instructions.append(
        Instruction("micro_reg2ubcont", dst=dst, src=src, mask=mask, mode=mode)
    )


def reg_to_ub_downsample(dst: Tensor, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    reg_to_ub_continuous(dst, src, mask, StoreDist.DOWNSAMPLE)


def reg_to_ub_pack4(dst: Tensor, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    reg_to_ub_continuous(dst, src, mask, StoreDist.PACK4)


def reg_to_ub_single(dst: Tensor, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    reg_to_ub_continuous(dst, src, mask, StoreDist.SINGLE_VALUE)


def reg_to_ub_normal(dst: Tensor, src: Reg, mask: Optional[MaskReg] = None) -> None:
    assert_valid_device(A5_DEVICES)
    reg_to_ub_continuous(dst, src, mask, StoreDist.NORMAL)


def ub_to_reg_normal(dst: Reg, src: Tensor) -> None:
    assert_valid_device(A5_DEVICES)
    ub_to_reg_continuous(dst, src, LoadDist.NORMAL)


def ub_to_reg_single(dst: Reg, src: Tensor) -> None:
    assert_valid_device(A5_DEVICES)
    ub_to_reg_continuous(dst, src, LoadDist.SINGLE_VALUE)


def ub_to_reg_upsample(dst: Reg, src: Tensor) -> None:
    assert_valid_device(A5_DEVICES)
    ub_to_reg_continuous(dst, src, LoadDist.UPSAMPLE)


def ub_to_reg_downsample(dst: Reg, src: Tensor) -> None:
    assert_valid_device(A5_DEVICES)
    ub_to_reg_continuous(dst, src, LoadDist.DOWNSAMPLE)


def ub_to_reg_unpack(dst: Reg, src: Tensor) -> None:
    assert_valid_device(A5_DEVICES)
    ub_to_reg_continuous(dst, src, LoadDist.UNPACK)


def ub_to_reg_unpack4(dst: Reg, src: Tensor) -> None:
    assert_valid_device(A5_DEVICES)
    ub_to_reg_continuous(dst, src, LoadDist.UNPACK4)


def ub_to_reg_brcb(dst: Reg, src: Tensor) -> None:
    assert_valid_device(A5_DEVICES)
    ub_to_reg_continuous(dst, src, LoadDist.BRCB)


# Gather and scatter
def ub_to_reg_gather(
    dst: Reg,
    src: Tensor,
    index: Reg,
    mask: Optional[MaskReg] = None,
) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(index, Reg):
        raise TypeError(f"index must be Reg type, current type: {type(index)}")
    # MicroAPI::DataCopyGather (vgather2) supports, keyed on the UB source byte width:
    #   b8  src -> b16 dst, u16 index   (byte zero-extend: low 8 bits = src byte,
    #                                    high 8 bits = 0 -- the ONE dst != src case)
    #   b16 src -> b16 dst, u16 index
    #   b32 src -> b32 dst, u32 index
    #   b64 src -> b64 dst, u32 | u64 index   (index in b64-element units; 32 lanes)
    # (dav_c310 kernel_micro_datacopy_impl.h DataCopyGatherImpl static_assert.)
    src_size = dtype_size(src.dtype)
    dst_size = dtype_size(dst.dtype)
    if src_size == 1:
        if dst_size != 2:
            raise ValueError(
                "ub_to_reg_gather with an 8-bit src does a b8->b16 byte zero-extend and "
                f"requires a 16-bit dst, got dst={dst.dtype} (src={src.dtype})"
            )
        _require_index_dtype("ub_to_reg_gather", src_size, index, (DT.uint16,))
    else:
        if dst.dtype != src.dtype:
            raise ValueError("dst/src data types must match")
        if src_size == 2:
            _require_index_dtype("ub_to_reg_gather", src_size, index, (DT.uint16,))
        elif src_size == 4:
            _require_index_dtype("ub_to_reg_gather", src_size, index, (DT.uint32,))
        elif src_size == 8:
            _require_index_dtype("ub_to_reg_gather", src_size, index, (DT.uint32, DT.uint64))
        else:
            raise ValueError(f"ub_to_reg_gather does not support {src_size * 8}-bit data")
    # The gather writes dst.lanes elements (b8->b16 gathers dst-many, not src-many),
    # so the active mask is sized by the destination register.
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction("micro_datacopygather", dst=dst, src=src, index=index, mask=mask)
    )


def ub_to_reg_gatherb(dst: Reg, src: Tensor, index: Reg, mask: Optional[MaskReg] = None) -> None:
    """GatherB(dst, ub_src, index, mask): gather 32-byte DATA BLOCKS from UB into a reg
    (MicroAPI::GatherB, a5 / dav_c310). Output DataBlock i (i-th 32B slice of dst) is the 32B
    block at ``ub_src`` byte offset ``index[i]`` -- the byte offset is read from index-reg LANE
    ``i`` (the first dst_bytes/32 lanes). Board-verified 2026-07-21: index is a uint32 BYTE
    offset, must be >=0 and 32B-aligned. dst/src support b8/b16/b32 and share the byte width;
    the index register is uint32. (b64 has an unresolved board index mapping -- deferred.)"""
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(index, Reg):
        raise TypeError(f"index must be Reg type, current type: {type(index)}")
    size = dtype_size(dst.dtype)
    if size not in (1, 2, 4):
        # b8/b16/b32 board-verified 2026-07-21 (gatherb_onboard 3/3). b64 gathers only the
        # first DataBlock on-board (out-block>=1 stays unwritten): its index-lane mapping
        # differs from the b8/b16/b32 "out-block i <- index lane i" rule and is deferred.
        raise ValueError(
            f"ub_to_reg_gatherb supports 8/16/32-bit data; 64-bit datablock gather has a "
            f"different (unresolved) board index mapping and is not yet supported, got {dst.dtype}"
        )
    if dtype_size(src.dtype) != size:
        raise ValueError("ub_to_reg_gatherb requires dst/src of the same byte width (32B block gather)")
    _require_index_dtype("ub_to_reg_gatherb", size, index, (DT.uint32,))
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction("micro_gatherb", dst=dst, src=src, index=index, mask=mask)
    )


def reg_to_ub_scatter(
    dst: Tensor,
    src: Reg,
    index: Reg,
    mask: Optional[MaskReg] = None,
) -> None:
    micro = require_micro()
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if not isinstance(index, Reg):
        raise TypeError(f"index must be Reg type, current type: {type(index)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    mask = ensure_mask(mask, src.dtype, micro)
    size = dtype_size(src.dtype)
    if size == 1:
        _require_index_dtype("reg_to_ub_scatter", size, index, (DT.uint16,))
    elif size == 2:
        _require_index_dtype("reg_to_ub_scatter", size, index, (DT.uint16,))
    elif size == 4:
        _require_index_dtype("reg_to_ub_scatter", size, index, (DT.uint32,))
    elif size == 8:
        _require_index_dtype("reg_to_ub_scatter", size, index, (DT.uint32, DT.uint64))
    else:
        raise ValueError(f"reg_to_ub_scatter does not support {size * 8}-bit data")
    micro.instructions.append(
        Instruction("micro_datacopyscatter", dst=dst, src=src, index=index, mask=mask)
    )


def gather(dst: Reg, src: Reg, index: Reg) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if not isinstance(index, Reg):
        raise TypeError(f"index must be Reg type, current type: {type(index)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    size = dtype_size(src.dtype)
    if size == 1:
        _require_index_dtype("gather", size, index, (DT.uint8,))
    elif size == 2:
        _require_index_dtype("gather", size, index, (DT.uint16,))
    elif size == 4:
        _require_index_dtype("gather", size, index, (DT.uint32,))
    else:
        # The reg->reg MicroAPI::Gather has no b64 overload on the Ascend950
        # (dav_c310): an int64 reg->reg gather fails to compile (board-probed with
        # both uint32 and uint64 index). b64 gather is only reachable UB-side via
        # ub_to_reg_gather / reg_to_ub_scatter (DataCopyGather b8/b16/b32/b64).
        raise ValueError(
            "gather (reg->reg MicroAPI::Gather) only supports 8/16/32-bit data; "
            "b64 is not implemented on the current device -- use ub_to_reg_gather "
            f"for a UB->reg b64 gather, got {src.dtype}"
        )
    micro.instructions.append(
        Instruction("micro_gather", dst=dst, src=src, index=index)
    )


def gather_mask(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    mask = ensure_mask(mask, src.dtype, micro)
    micro.instructions.append(
        Instruction("micro_gathermask", dst=dst, src=src, mask=mask)
    )


def squeeze(dst: Reg, src: Reg, mask: Optional[MaskReg] = None, store: bool = False) -> None:
    """Squeeze(dst, src, mask): stream-compaction. Copy the mask-selected elements of src into
    the LOW end of dst, packed contiguously low-to-high, with the remaining lanes zeroed. Maps
    to MicroAPI::Squeeze (a5 / Atlas 350). Unlike pack it does NOT narrow the dtype, so it turns
    a stride-sparse reg (e.g. an M4-masked e4m3: a valid byte every 4th lane) into a contiguous
    reg in a SINGLE instruction -- the b32->b16->b8 pack chain needs two steps for the same.

    store=True selects GatherMaskMode::STORE_REG: the compacted elements STILL land at the LOW
    end (same as the default), but the AR accumulate SPR is advanced by the valid-element count
    so a later GetSpr<AR> can read the running total (use clear_spr() to reset AR to 0). AR is a
    COUNTER, NOT a write offset -- a 2nd store=True squeeze OVERWRITES dst[0:n], it does NOT
    append/concat (cannsim-verified 2026-07-01, tmp/squeeze_probe/store_concat_probe.py). So
    store=True does NOT let two squeezes build a 128-wide [i,j] reg for one reg_to_ub."""
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    mask = ensure_mask(mask, src.dtype, micro)
    micro.instructions.append(
        Instruction("micro_squeeze", dst=dst, src=src, mask=mask, store=bool(store))
    )


def clear_spr() -> None:
    """ClearSpr<AR>: reset the AR accumulate register (the Squeeze STORE_REG output counter)
    to 0. Call before a run of store=True squeezes that should concatenate from offset 0."""
    micro = require_micro()
    micro.instructions.append(Instruction("micro_clear_spr"))


def unsqueeze(dst: Reg, mask: Optional[MaskReg] = None) -> None:
    """Unsqueeze(dst, mask): in-place EXCLUSIVE prefix-sum (scan) of the mask bits. dst[i] gets
    the number of active mask lanes STRICTLY before lane i -- i.e. the rank of lane i among the
    active lanes -- so lanes at/after the last active one all carry the total active count. The
    input dst values are IGNORED; the result is a pure function of the mask. This is the
    index-generation primitive (PrefixSumImpl) that feeds Squeeze/GatherMask addressing, despite
    the name it is NOT the inverse of squeeze. Maps to MicroAPI::Unsqueeze (a5 / dav_c310), which
    has NO src operand -- dst is written in place. Board-verified 2026-07-21."""
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(Instruction("micro_unsqueeze", dst=dst, mask=mask))


_MASK_UB_WARNED = set()  # emit the counterintuitive-packing note once per op per process


def _warn_mask_ub_packing(op: str) -> None:
    if op in _MASK_UB_WARNED:
        return
    _MASK_UB_WARNED.add(op)
    warnings.warn(
        f"{op}: MaskReg<->UB uses the A5 byte-granular vector-mask layout, which is "
        "counterintuitive (board-verified 2026-07-21): (1) LoadAlign/StoreAlign always move "
        "the FULL 32-byte (256-bit) mask register, not VL/8 bytes; (2) element-lane i's mask "
        "bit sits at bit position i*elem_size (LSB-first), so for dtype wider than 1 byte the "
        "in-between bits are 0 -- it is NOT a dense bit-per-lane array. Revisit here if the HW "
        "layout ever changes.",
        stacklevel=3,
    )


def ub_to_mask(dst: MaskReg, src: Tensor) -> None:
    """MaskReg 搬入: load a MaskReg's bits from UB. Maps to the MaskReg overload
    MicroAPI::LoadAlign(MaskReg&, __ubuf__ T*). Reads the full 32-byte (256-bit) mask register;
    element-lane i is taken from bit i*elem_size (LSB-first). Board-verified 2026-07-21."""
    _warn_mask_ub_packing("ub_to_mask")
    micro = require_micro()
    if not isinstance(dst, MaskReg):
        raise TypeError(f"dst must be MaskReg type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    micro.instructions.append(Instruction("micro_ub_to_mask", dst=dst, src=src))


def mask_to_ub(dst: Tensor, src: MaskReg) -> None:
    """MaskReg 搬出: store a MaskReg's bits to UB. Maps to the MaskReg overload
    MicroAPI::StoreAlign(__ubuf__ T*, MaskReg&). Writes the full 32-byte (256-bit) mask register;
    element-lane i lands at bit i*elem_size (LSB-first). Board-verified 2026-07-21."""
    _warn_mask_ub_packing("mask_to_ub")
    micro = require_micro()
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, MaskReg):
        raise TypeError(f"src must be MaskReg type, current type: {type(src)}")
    micro.instructions.append(Instruction("micro_mask_to_ub", dst=dst, src=src))
