from ...utils.instruction import Instruction
from ...utils.vfpipe import VfPipeType, check_mem_bar_pair
from .microutils import require_micro
from ..vec.vecutils import A5_DEVICES, assert_valid_device


def vf_barrier(src: VfPipeType, dst: VfPipeType) -> None:
    assert_valid_device(A5_DEVICES)
    if not isinstance(src, VfPipeType):
        raise TypeError(f"src must be VfPipeType, got: {type(src)}")
    if not isinstance(dst, VfPipeType):
        raise TypeError(f"dst must be VfPipeType, got: {type(dst)}")
    check_mem_bar_pair(src, dst)
    micro = require_micro()
    micro.instructions.append(Instruction("micro_vf_barrier", src=src, dst=dst))
