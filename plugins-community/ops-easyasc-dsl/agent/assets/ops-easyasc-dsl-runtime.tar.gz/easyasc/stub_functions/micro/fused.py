from typing import Optional, Union

from ...utils.reg import Reg, MaskReg
from ...utils.instruction import Instruction
from ...utils.datatype import Datatype
from ...utils.castconfig import RegLayout, RegLayoutValue
from ...utils.var import Var
from .microutils import ensure_mask, format_scalar, require_micro
from ..vec.vecutils import A5_DEVICES, assert_valid_device


def expsub(dst: Reg, src0: Reg, src1: Reg, mask: Optional[MaskReg] = None,
           layout: RegLayoutValue = RegLayout.ZERO) -> None:
    """Fused ``exp(src0 - src1)``: subtract then exponentiate in one MicroAPI op.

    Maps to ``MicroAPI::ExpSub<T, U, layout, MaskMergeMode::ZEROING>``. ``T`` (dst)
    must be float; ``U`` (src0/src1) is half or float. For a half source ``layout``
    picks which b16 lane of each 32-bit slot the elements are read from --
    ``RegLayout.ZERO`` = even lanes, ``RegLayout.ONE`` = odd lanes (a 2-of-4 read,
    identical to a cast half->float slot). Mask-off dst lanes are zeroed (ZEROING;
    the board does not yet support MERGING for ExpSub). The mask follows ``U`` like
    ``UpdateMask<U>`` -- for a half source it has twice the dst lanes and only its
    even bits are honored. a5/C310 only.
    """
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src0, Reg):
        raise TypeError(f"src0 must be Reg type, current type: {type(src0)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if dst.dtype != Datatype.float:
        raise ValueError(f"expsub dst dtype must be float, current type: {dst.dtype}")
    if src0.dtype != src1.dtype:
        raise ValueError("expsub src0/src1 data types must match")
    if src0.dtype not in (Datatype.half, Datatype.float):
        raise ValueError(f"expsub src dtype must be half or float, current type: {src0.dtype}")
    if not isinstance(layout, RegLayoutValue):
        raise TypeError(f"layout must be RegLayoutValue type, current type: {type(layout)}")
    if layout not in (RegLayout.ZERO, RegLayout.ONE):
        raise ValueError(f"expsub supports RegLayout.ZERO/ONE only, got RegLayout.{layout}")
    # A float source maps 1:1 onto the float dst (ratio 1); the high/low-half ONE slot
    # is only meaningful for a half (b16) source, so reject ONE for a float source.
    if src0.dtype == Datatype.float and layout != RegLayout.ZERO:
        raise ValueError("expsub float source supports only RegLayout.ZERO")
    mask = ensure_mask(mask, src0.dtype, micro)
    micro.instructions.append(
        Instruction(
            "micro_expsub",
            dst=dst,
            src0=src0,
            src1=src1,
            mask=mask,
            layout=layout,
            ddst=dst.dtype,
            dsrc=src0.dtype,
        )
    )


def abssub(dst: Reg, src0: Reg, src1: Reg, mask: Optional[MaskReg] = None) -> None:
    """Fused absolute difference ``dst = abs(src0 - src1)`` (AbsSub).

    Maps to ``MicroAPI::AbsSub<T, MaskMergeMode::ZEROING>``. All three operands
    share one dtype ``T`` in {half, float, int64}. Mask-off dst lanes are zeroed
    (MERGING is listed by the API but currently unsupported). a5/C310 only.
    """
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src0, Reg):
        raise TypeError(f"src0 must be Reg type, current type: {type(src0)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if dst.dtype != src0.dtype or dst.dtype != src1.dtype:
        raise ValueError("abssub dst/src0/src1 data types must match")
    if dst.dtype not in (Datatype.half, Datatype.float, Datatype.int64):
        raise ValueError(f"abssub dtype must be half/float/int64, current type: {dst.dtype}")
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction("micro_abssub", dst=dst, src1=src0, src2=src1, mask=mask)
    )


def muldstadd(dst: Reg, src0: Reg, src1: Reg, mask: Optional[MaskReg] = None) -> None:
    """Fused in-place FMA ``dst = dst * src0 + src1`` (MulDstAdd).

    Maps to ``MicroAPI::MulDstAdd<T, MaskMergeMode::ZEROING>``. ``dst`` is both an
    input and the output; all three operands share one dtype ``T`` in
    {half, bfloat16, float}. Mask-off dst lanes are zeroed (ZEROING is the only
    mode MulDstAdd supports). a5/C310 only.
    """
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src0, Reg):
        raise TypeError(f"src0 must be Reg type, current type: {type(src0)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if dst.dtype != src0.dtype or dst.dtype != src1.dtype:
        raise ValueError("muldstadd dst/src0/src1 data types must match")
    if dst.dtype not in (Datatype.half, Datatype.bfloat16, Datatype.float):
        raise ValueError(f"muldstadd dtype must be half/bfloat16/float, current type: {dst.dtype}")
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction("micro_muldstadd", dst=dst, src1=src0, src2=src1, mask=mask)
    )


def muladddst(dst: Reg, src0: Reg, src1: Reg, mask: Optional[MaskReg] = None) -> None:
    """Fused in-place multiply-add ``dst = src0 * src1 + dst`` (MulAddDst).

    Maps to ``MicroAPI::MulAddDst<T, MaskMergeMode::ZEROING>``. ``dst`` is both an
    input accumulator and the output; all three operands share one dtype ``T`` in
    {uint16, int16, uint32, int32, half, float, bfloat16, uint64, int64}.
    Mask-off dst lanes are zeroed (MERGING is not supported by the hardware doc).
    a5/C310 only.
    """
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src0, Reg):
        raise TypeError(f"src0 must be Reg type, current type: {type(src0)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if dst.dtype != src0.dtype or dst.dtype != src1.dtype:
        raise ValueError("muladddst dst/src0/src1 data types must match")
    if dst.dtype not in (
        Datatype.uint16,
        Datatype.int16,
        Datatype.uint32,
        Datatype.int,
        Datatype.half,
        Datatype.float,
        Datatype.bfloat16,
        Datatype.uint64,
        Datatype.int64,
    ):
        raise ValueError(
            "muladddst dtype must be uint16/int16/uint32/int32/half/float/"
            f"bfloat16/uint64/int64, current type: {dst.dtype}"
        )
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction("micro_muladddst", dst=dst, src1=src0, src2=src1, mask=mask)
    )


def mulscast(
    dst: Reg,
    src: Reg,
    value: Union[Var, float],
    mask: Optional[MaskReg] = None,
    layout: RegLayoutValue = RegLayout.ZERO,
) -> None:
    """Fused scalar multiply and cast ``dst = CAST_ROUND(src * value)`` (MulsCast).

    Maps to ``MicroAPI::MulsCast<half, float, float, layout>``. ``src`` must be
    float, ``dst`` must be half, and ``value`` is a float scalar or float ``Var``.
    The execution mask follows the float source lanes, matching
    ``UpdateMask<float>`` in the AscendC API. The half result is written into a
    b16 slot selected by ``layout`` (``ZERO`` = even lanes, ``ONE`` = odd lanes).
    a5/C310 only.
    """
    assert_valid_device(A5_DEVICES)
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if not isinstance(value, (Var, float)) or isinstance(value, bool):
        raise TypeError(f"value must be Var or float scalar type, current type: {type(value)}")
    if dst.dtype != Datatype.half:
        raise ValueError(f"mulscast dst dtype must be half, current type: {dst.dtype}")
    if src.dtype != Datatype.float:
        raise ValueError(f"mulscast src dtype must be float, current type: {src.dtype}")
    if not isinstance(layout, RegLayoutValue):
        raise TypeError(f"layout must be RegLayoutValue type, current type: {type(layout)}")
    if layout not in (RegLayout.ZERO, RegLayout.ONE):
        raise ValueError(f"mulscast supports RegLayout.ZERO/ONE only, got RegLayout.{layout}")
    v = format_scalar(value, Datatype.float)
    mask = ensure_mask(mask, src.dtype, micro)
    micro.instructions.append(
        Instruction(
            "micro_mulscast",
            dst=dst,
            src=src,
            v=v,
            mask=mask,
            layout=layout,
            ddst=dst.dtype,
            dsrc=src.dtype,
            scalar_dtype=Datatype.float,
        )
    )
