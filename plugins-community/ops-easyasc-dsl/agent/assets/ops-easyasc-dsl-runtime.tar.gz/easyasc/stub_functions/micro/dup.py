from typing import Optional, Union

from ...utils.datatype import is_complex_dtype
from ...utils.reg import Reg, MaskReg
from ...utils.var import Var
from ...utils.instruction import Instruction
from .microutils import ensure_mask, format_complex_scalar, format_scalar, require_micro


def dup(dst: Reg, src: Union[Reg, float, int, complex, Var], mask: Optional[MaskReg] = None) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    complex_dst = is_complex_dtype(dst.dtype)
    allowed_types = (Reg, Var, int, float, complex) if complex_dst else (Reg, Var, int, float)
    if not isinstance(src, allowed_types):
        raise TypeError(f"src must be Reg or numeric value/Var type, current type: {type(src)}")

    mask = ensure_mask(mask, dst.dtype, micro)

    if isinstance(src, Reg):
        if dst.dtype != src.dtype:
            raise ValueError("dst/src data types must match")
        v = src
    elif isinstance(src, Var):
        v = src
    elif complex_dst:
        v = format_complex_scalar(src)
    else:
        v = format_scalar(src, dst.dtype)

    micro.instructions.append(Instruction("micro_vdup", dst=dst, src=v, mask=mask))
