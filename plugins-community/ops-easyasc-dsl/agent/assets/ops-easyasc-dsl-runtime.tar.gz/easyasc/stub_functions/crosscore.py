from ..utils.instruction import Instruction
from ..utils.pipe import PipeType, Pipe
from .. import globvars
from ..device_profile import is_a5_family, is_c220_family
from .vec.vecutils import A2_A5_DEVICES, assert_valid_device


def _validate_crosscore_flag_id(flag_id: int) -> None:
    if not isinstance(flag_id, int):
        raise TypeError(f"flag_id must be inttype, current type: {type(flag_id)}")
    if flag_id < 0 or flag_id > 7:
        raise ValueError(f"flag_id must be in range [0, 7], current value: {flag_id}")


def _is_c220_device() -> bool:
    return is_c220_family(getattr(globvars, "device_type", ""))


def _is_a5_device() -> bool:
    return is_a5_family(getattr(globvars, "device_type", ""))


_A5_CROSSCORE_VEC_SET_PIPES = frozenset([
    Pipe.MTE2, Pipe.MTE1, Pipe.M, Pipe.V, Pipe.MTE3, Pipe.FIX,
])
_A5_CROSSCORE_CUBE_SET_PIPES = _A5_CROSSCORE_VEC_SET_PIPES - frozenset([Pipe.MTE3])
_A5_CROSSCORE_WAIT_PIPES = _A5_CROSSCORE_VEC_SET_PIPES | frozenset([Pipe.S])


def validate_crosscore_set_pipe(label: str, pipe: PipeType, side: str) -> None:
    if not isinstance(pipe, PipeType):
        raise TypeError(f"{label} must be PipeType type, current type: {type(pipe)}")
    if not _is_a5_device():
        return
    if side == "cube":
        allowed_pipes = _A5_CROSSCORE_CUBE_SET_PIPES
        allowed = "Pipe.MTE2, Pipe.MTE1, Pipe.M, Pipe.V, Pipe.FIX"
    elif side == "vec":
        allowed_pipes = _A5_CROSSCORE_VEC_SET_PIPES
        allowed = "Pipe.MTE2, Pipe.MTE1, Pipe.M, Pipe.V, Pipe.MTE3, Pipe.FIX"
    else:
        raise ValueError(f"{label} side must be 'cube' or 'vec', current side: {side}")
    if pipe not in allowed_pipes:
        raise ValueError(
            f"{label} must be one of {allowed} on a5/C310 devices, current pipe: Pipe.{pipe}"
        )


def validate_crosscore_wait_pipe(label: str, pipe: PipeType) -> None:
    if not isinstance(pipe, PipeType):
        raise TypeError(f"{label} must be PipeType type, current type: {type(pipe)}")
    validate_c220_wait_pipe(label, pipe)
    if _is_a5_device() and pipe not in _A5_CROSSCORE_WAIT_PIPES:
        allowed = "Pipe.S, Pipe.MTE2, Pipe.MTE1, Pipe.M, Pipe.V, Pipe.MTE3, Pipe.FIX"
        raise ValueError(
            f"{label} must be one of {allowed} on a5/C310 devices, current pipe: Pipe.{pipe}"
        )


def validate_c220_wait_pipe(label: str, pipe: PipeType) -> None:
    if not isinstance(pipe, PipeType):
        raise TypeError(f"{label} must be PipeType type, current type: {type(pipe)}")
    if _is_c220_device() and pipe != Pipe.S:
        raise ValueError(
            f"{label} must be Pipe.S on C220 devices, current pipe: Pipe.{pipe}"
        )


def cube_ready(flag_id: int = 0, pipe: PipeType = Pipe.FIX) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_set_pipe("cube_ready pipe", pipe, side="cube")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("cube_ready", flag_id=flag_id, pipe=pipe)
        )


def vec_ready(flag_id: int = 0, pipe: PipeType = Pipe.MTE3) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_set_pipe("vec_ready pipe", pipe, side="vec")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("vec_ready", flag_id=flag_id, pipe=pipe)
        )


def wait_cube(flag_id: int = 0, pipe: PipeType = Pipe.S) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_wait_pipe("wait_cube pipe", pipe)
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("wait_cube", flag_id=flag_id, pipe=pipe)
        )


def wait_vec(flag_id: int = 0, pipe: PipeType = Pipe.S) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_wait_pipe("wait_vec pipe", pipe)
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("wait_vec", flag_id=flag_id, pipe=pipe)
        )


def allcube_ready(flag_id: int = 0, pipe: PipeType = Pipe.FIX) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_set_pipe("allcube_ready pipe", pipe, side="cube")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("allcube_ready", flag_id=flag_id, pipe=pipe)
        )


def allvec_ready(flag_id: int = 0, pipe: PipeType = Pipe.MTE3) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_set_pipe("allvec_ready pipe", pipe, side="vec")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("allvec_ready", flag_id=flag_id, pipe=pipe)
        )


def intracore_allvec_ready(flag_id: int = 0, pipe: PipeType = Pipe.MTE3) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_set_pipe("intracore_allvec_ready pipe", pipe, side="vec")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("intracore_allvec_ready", flag_id=flag_id, pipe=pipe)
        )


def allcube_wait(flag_id: int = 0, pipe: PipeType = Pipe.S) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_wait_pipe("allcube_wait pipe", pipe)
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("allcube_wait", flag_id=flag_id, pipe=pipe)
        )


def allvec_wait(flag_id: int = 0, pipe: PipeType = Pipe.S) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_wait_pipe("allvec_wait pipe", pipe)
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("allvec_wait", flag_id=flag_id, pipe=pipe)
        )


def intracore_allvec_wait(flag_id: int = 0, pipe: PipeType = Pipe.S) -> None:
    assert_valid_device(A2_A5_DEVICES)
    _validate_crosscore_flag_id(flag_id)
    validate_crosscore_wait_pipe("intracore_allvec_wait pipe", pipe)
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("intracore_allvec_wait", flag_id=flag_id, pipe=pipe)
        )
