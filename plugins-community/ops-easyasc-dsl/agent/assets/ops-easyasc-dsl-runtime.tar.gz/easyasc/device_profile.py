from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class DeviceProfile:
    device_type: str
    family: str
    core_num: int
    vec_num: int
    compile_unit: str
    debug_chipset: str


_DEVICE_PROFILES: Dict[str, DeviceProfile] = {
    "b1": DeviceProfile("b1", "a2", 24, 48, "ascend910b", "Ascend910B1"),
    "b2": DeviceProfile("b2", "a2", 24, 48, "ascend910b", "Ascend910B2"),
    "b3": DeviceProfile("b3", "a2", 20, 40, "ascend910b", "Ascend910B3"),
    "b4": DeviceProfile("b4", "a2", 20, 40, "ascend910b", "Ascend910B4"),
    "a3": DeviceProfile("a3", "a2", 20, 40, "ascend910_93", "Ascend910_9362"),
    "950": DeviceProfile("950", "a5", 32, 64, "ascend950", "Ascend950"),
    "950pr": DeviceProfile("950pr", "a5", 28, 56, "ascend950", "Ascend950PR_9589"),
}


def normalize_device_type(device_type: object) -> str:
    return str(device_type).lower()


def get_device_profile(device_type: object) -> DeviceProfile:
    lowered = normalize_device_type(device_type)
    try:
        return _DEVICE_PROFILES[lowered]
    except KeyError as exc:
        raise ValueError("Unsupported device_type: " + lowered) from exc


def is_b_series(device_type: object) -> bool:
    lowered = normalize_device_type(device_type)
    return lowered.startswith("b")


def is_c220_family(device_type: object) -> bool:
    lowered = normalize_device_type(device_type)
    return lowered.startswith("b") or lowered == "a3"


def is_a5_family(device_type: object) -> bool:
    return normalize_device_type(device_type) in ("950", "950pr")


def core_num_for(device_type: object) -> int:
    return get_device_profile(device_type).core_num


def vec_num_for(device_type: object) -> int:
    return get_device_profile(device_type).vec_num


def compile_unit_for(device_type: object) -> str:
    return get_device_profile(device_type).compile_unit


def debug_chipset_for(device_type: object) -> str:
    return get_device_profile(device_type).debug_chipset
