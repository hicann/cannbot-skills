from .a5 import *

from . import globvars

globvars.device_type = "950pr"
globvars.core_num = 28
globvars.ub_cap = 256
globvars.l0amx_cap = 4
globvars.l0bmx_cap = 4
globvars.l0c_cap = 256
globvars.bt_cap = 4  # KB, total depth-2 BT capacity (2 x 2 KB slots)
