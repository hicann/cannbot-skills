from .utils.datatype import Datatype as DT
from .utils.Tensor import Tensor, DBuff, TBuff, QBuff, GMTensor, GMTensorList
from .utils.var import Var, VarList
from .decorators import kernel, func, auto_sync, vf, simt
from .simt.simtmodule import (  # SIMT module + intrinsics (a5 only)
    SimtModule, cvt, simt_fma, simt_ffs, simt_thread_barrier,
    simt_thread_id, simt_thread_num, simt_block_idx, simt_block_num,
    simt_atomic_add, simt_atomic_sub, simt_atomic_max, simt_atomic_min,
    simt_atomic_cas,
)
from .scope import vec_scope, cube_scope
from .utils.positions import Position, PositionType
from .utils.conv2d import Conv2D, img2col
from .utils.layout import Layout, LayoutType
from .utils.roundmode import RoundMode, RoundModeType
from .utils.vecop import maximum, minimum
from .utils.comparemode import CompareMode, CompareModeType
from .utils.selectmode import SelectMode, SelectModeType
from .utils.cacheline import DcciDst, DcciDstType, EntireType, EntireTypeValue
from .utils.dualmode import DualMode, DualModeType
from .utils.pipe import Pipe, PipeType
from .utils.vfpipe import VfPipe, VfPipeType
from .utils.events import SEvent, DEvent, TEvent, QEvent
from .utils.mutex import CvMutex, VcMutex
from .utils.reg import Reg, RegList, MaskReg, MaskType
from .utils.castconfig import CastConfig, RegLayout, MaskMergeMode
from .utils.divconfig import DivAlgo, DivConfig
from .dtypehelper.e8m0_fp32 import (
    E8M0_BIAS,
    E8M0_MIN_VALUE,
    e8m0_to_fp32,
    fp32_to_e8m0,
)
from .dtypehelper.fp4_fp32 import (
    FP4_E1M2_MAX_VALUE,
    FP4_E2M1_MAX_VALUE,
    fp32_to_fp4_e1m2,
    fp32_to_fp4_e2m1,
    fp4_e1m2_to_fp32,
    fp4_e2m1_to_fp32,
)
from .dtypehelper.hif8_codec import (
    HIF8_MAX_FINITE_VALUE,
    HIF8_MAX_NEGATIVE_NORMAL,
    HIF8_MAX_POSITIVE_NORMAL,
    HIF8_NAN,
    HIF8_NEGATIVE_INF,
    HIF8_OVERFLOW_THRESHOLD,
    HIF8_POSITIVE_INF,
    HIF8_POSITIVE_ZERO,
    fp16_to_hif8,
    fp16_to_hifloat8,
    fp32_to_hif8,
    fp32_to_hifloat8,
    hif8_to_fp32,
    hifloat8_to_fp32,
)
from .stub_functions import (
    CeilDiv, GetCubeNum, GetCubeIdx, GetVecNum, GetVecIdx, GetSubBlockIdx,  # stub_functions/var_op.py
    scalar_sqrt, scalar_abs,                                                # stub_functions/var_op.py
    Align8, Align16, Align32, Align64, Align128, Align256,                  # stub_functions/var_op.py
    var_mul, var_add, var_sub, var_div, var_mod, Min, Max,                  # stub_functions/var_op.py
    gm_to_l1_nd2nz, set_constant_to_l1, l1_to_l0, l1_to_l0a_img2col, l1_to_bt, l1_to_l0_mx, mmad, mmad_mx, l0c_to_gm_nz2nd, l0c_to_gm_nz2nz, l0c_to_gm_nz2dn, l0c_to_l1, l0c_to_ub,  # stub_functions/cube.py
    bar_m, bar_v, bar_mte3, bar_mte2, bar_mte1, bar_fix, bar_all,           # stub_functions/barrier.py
    atomic_add, atomic_max, atomic_min,                                     # stub_functions/atomic.py
    reinterpret, split_workspace, reset_cache, set_hf32, clean_dcache, sim_print, kernel_print, sim_dump_tensor, kernel_dump_tensor, inline,  # stub_functions/misc.py
    cube_ready, vec_ready, wait_cube, wait_vec,                             # stub_functions/crosscore.py
    allcube_ready, allvec_ready, allcube_wait, allvec_wait,                 # stub_functions/crosscore.py
    intracore_allvec_ready, intracore_allvec_wait,                          # stub_functions/crosscore.py
    setflag, waitflag,                                                      # stub_functions/flags.py
    gm_to_ub_pad, gm_to_ub_nd_dma, ub_to_gm_pad, ub_to_ub,                  # stub_functions/vec/datamove.py
    ub_to_l1, ub_to_l1_nd2nz, ub_to_l1_nz,                                  # stub_functions/vec/datamove.py
    sort32, mergesort4, mergesort_2seq, topk_radix,                         # stub_functions/vec/sort.py
    set_mask, set_mask_normal, reset_mask, set_mask_by_count,               # stub_functions/vec/vecmask.py (vec PipeS)
)
from .stub_functions import gm_to_l1_pad, gm_to_l1, gm_to_l1_mx_scale, gm_to_l1_mx_scale_nd2nz, gm_to_l1_dn2nz
from .stub_functions.micro import (
    arange,                                                                 # stub_functions/micro/arange.py
    vf_barrier,                                                             # stub_functions/micro/barrier.py
    vmax, vmin, add, sub, mul, div, vand, vor, vxor, prelu, shiftl, shiftr, # stub_functions/micro/binary.py
    cast,                                                                   # stub_functions/micro/cast.py
    compare, select,                                                        # stub_functions/micro/compare.py
    print_reg,                                                              # stub_functions/micro/debug.py
    LoadDist, LoadDistValue, StoreDist, StoreDistValue,                     # stub_functions/micro/datamove.py
    ub_to_reg, reg_to_ub, ub_to_reg_continuous, ub_to_reg_interleave, reg_to_ub_continuous,  # stub_functions/micro/datamove.py
    reg_to_ub_downsample, reg_to_ub_pack4, reg_to_ub_single, reg_to_ub_normal,  # stub_functions/micro/datamove.py
    reg_to_ub_interleave,                                                   # stub_functions/micro/datamove.py
    ub_to_reg_normal, ub_to_reg_single, ub_to_reg_upsample, ub_to_reg_downsample,  # stub_functions/micro/datamove.py
    ub_to_reg_unpack, ub_to_reg_unpack4, ub_to_reg_brcb,                    # stub_functions/micro/datamove.py
    ub_to_reg_gather, reg_to_ub_scatter, gather, gather_mask, squeeze, clear_spr,  # stub_functions/micro/datamove.py
    unsqueeze, ub_to_reg_gatherb, ub_to_mask, mask_to_ub,                  # stub_functions/micro/datamove.py
    dup,                                                                    # stub_functions/micro/dup.py
    abssub, expsub, muldstadd, muladddst, mulscast,                         # stub_functions/micro/fused.py
    cmax, cgmax, cmin, cgmin, cadd, cgadd, cpadd,                           # stub_functions/micro/group.py
    histograms, HistBin, HistMode,                                          # stub_functions/micro/histograms.py
    deinterleave, interleave,                                               # stub_functions/micro/interleave.py
    pack, HighLowPart,                                                      # stub_functions/micro/pack.py
    mask_not, mask_and, mask_or, mask_xor, mask_mov, mask_interleave,        # stub_functions/micro/mask.py
    mask_deinterleave, mask_sel, mask_pack, mask_unpack,                    # stub_functions/micro/mask.py
    move_mask_spr, update_mask,                                             # stub_functions/micro/mask.py
    exp, abs, relu, sqrt, ln, log, log2, log10, neg, vnot, vcopy,           # stub_functions/micro/unary.py
    vmaxs, vmins, adds, muls, lrelu, shiftls, shiftrs, axpy,                # stub_functions/micro/unaryscalar.py
)
from .stub_functions import micro
from .flowcontrol import range, unroll, If, Elif, Else, break_, continue_
from .torchplugin import OpExec, TorchApiManager
from .shortcuts import matmul, matmul_mx, zero_mxfp8_l1_padding, conv2d
# NOTE: the low-level img2col/load3d probe surface is exported on a5 so real-HW
# experiments can generate code and run on Ascend950. The Python simulator still
# intentionally rejects a5 l1_to_l0a_img2col because its golden model is
# 910B3-derived and not trusted on 950.

from . import globvars 
globvars.device_type = '950'
globvars.core_num = 32
globvars.ub_cap = 256
globvars.l0amx_cap = 4
globvars.l0bmx_cap = 4
globvars.l0c_cap = 256
globvars.bt_cap = 4  # KB, total depth-2 BT capacity (2 x 2 KB slots)
