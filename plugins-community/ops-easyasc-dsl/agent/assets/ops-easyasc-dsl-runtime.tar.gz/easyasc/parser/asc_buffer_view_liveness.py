from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .asc_pruning import _parse_block
from .asc_utils import is_assignment_op, is_tmp_var
from ..utils.instruction import Instruction
from ..utils.Tensor import DBuff, QBuff, TBuff, Tensor
from ..utils.var import Var, VarRef


_DERIVED_VIEW_OPS = {"slice_tensor", "micro_slice_tensor", "reinterpret"}
_CONTROL_TRANSFER_OPS = {"break_loop", "continue_loop"}


@dataclass(frozen=True)
class BufferViewDecision:
    """Codegen choice for one runtime-indexed local-buffer view."""

    mode: str
    reason: str
    use_count: int


@dataclass(frozen=True)
class _Location:
    block_path: Tuple[Tuple[str, int, int], ...]
    ordinal: int
    role: str


@dataclass(frozen=True)
class _Use:
    inst: Instruction
    nested: bool
    aliased_object: bool
    derived: bool


def _tensor_key(value: object) -> Optional[Tuple[str, int]]:
    if not isinstance(value, Tensor):
        return None
    name = getattr(value, "name", None)
    idx = getattr(value, "idx", None)
    if not isinstance(name, str) or not isinstance(idx, int):
        return None
    return name, idx


def _collect_matching_tensors(
    value: object,
    key: Tuple[str, int],
    nested: bool = False,
) -> List[Tuple[Tensor, bool]]:
    if isinstance(value, Tensor):
        return [(value, nested)] if _tensor_key(value) == key else []
    if isinstance(value, dict):
        matches: List[Tuple[Tensor, bool]] = []
        for item in value.values():
            matches.extend(_collect_matching_tensors(item, key, nested=True))
        return matches
    if isinstance(value, (list, tuple, set)):
        matches = []
        for item in value:
            matches.extend(_collect_matching_tensors(item, key, nested=True))
        return matches
    return []


def _contains_var_ref(value: object) -> bool:
    if isinstance(value, VarRef):
        return True
    if isinstance(value, dict):
        return any(_contains_var_ref(item) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return any(_contains_var_ref(item) for item in value)
    return False


def _collect_var_names(value: object, names: Set[str]) -> None:
    if isinstance(value, VarRef):
        index = getattr(value, "index", None)
        if index is not None:
            _collect_var_names(index, names)
        return
    if isinstance(value, Var):
        names.add(value.name)
        return
    if isinstance(value, dict):
        for item in value.values():
            _collect_var_names(item, names)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _collect_var_names(item, names)


def _index_dependencies(
    index: Var,
    instructions: List[Instruction],
) -> Tuple[Set[str], bool]:
    """Return the Vars that codegen will read when rendering ``index``.

    Named Vars remain named in ``build_expr_state`` and therefore depend only on
    their own reaching value. Temporary Vars are expression-inlined, so follow
    temporary-to-temporary assignments until named Vars are reached. A temporary
    expression that reads tensor memory or a VarList element is not stable enough
    to move from view-definition time to consumer time.
    """

    dependencies = {index.name}
    if not is_tmp_var(index):
        return dependencies, True

    producers: Dict[str, List[Instruction]] = {}
    for inst in instructions:
        if not is_assignment_op(inst.opname):
            continue
        out = inst.kwargs.get("out", None)
        if isinstance(out, Var) and is_tmp_var(out):
            producers.setdefault(out.name, []).append(inst)

    pending = [index.name]
    expanded: Set[str] = set()
    stable = True
    while pending:
        name = pending.pop()
        if name in expanded:
            continue
        expanded.add(name)
        name_producers = producers.get(name, [])
        if len(name_producers) > 1:
            stable = False
        for producer in name_producers:
            if producer.opname == "GetValueFrom" or any(
                _contains_var_ref(value) for value in producer.kwargs.values()
            ):
                stable = False
            producer_dependencies: Set[str] = set()
            for key, value in producer.kwargs.items():
                if key in ("out", "dst"):
                    continue
                _collect_var_names(value, producer_dependencies)
            for dependency in producer_dependencies:
                dependencies.add(dependency)
                if dependency.startswith("_tmp_var_"):
                    pending.append(dependency)
    return dependencies, stable


def _written_var_name(inst: Instruction) -> Optional[str]:
    if inst.opname in ("start_loop", "start_micro_loop"):
        value = inst.kwargs.get("var", None)
    elif inst.opname == "create_var":
        value = inst.kwargs.get("val", None)
    elif is_assignment_op(inst.opname):
        value = inst.kwargs.get("out", None)
        if value is None:
            value = inst.kwargs.get("dst", None)
    else:
        return None
    return value.name if isinstance(value, Var) else None


def _index_structured_locations(
    nodes: List[dict],
) -> Tuple[Dict[int, List[_Location]], Dict[Tuple[Tuple[str, int, int], ...], List[dict]]]:
    locations: Dict[int, List[_Location]] = {}
    blocks: Dict[Tuple[Tuple[str, int, int], ...], List[dict]] = {}

    def _record(inst: Optional[Instruction], location: _Location) -> None:
        if inst is not None:
            locations.setdefault(id(inst), []).append(location)

    def _walk(block: List[dict], path: Tuple[Tuple[str, int, int], ...]) -> None:
        blocks[path] = block
        for ordinal, node in enumerate(block):
            ntype = node["type"]
            if ntype == "inst":
                _record(node["inst"], _Location(path, ordinal, "inst"))
                continue
            if ntype == "loop":
                _record(node.get("prelude"), _Location(path, ordinal, "control"))
                _record(node["start"], _Location(path, ordinal, "control"))
                loop_path = path + (("loop", ordinal, 0),)
                _walk(node["body"], loop_path)
                _record(node["end"], _Location(path, ordinal, "control"))
                continue
            if ntype == "if":
                for branch_index, branch in enumerate(node["branches"]):
                    for prelude in branch.get("prelude", []):
                        _record(prelude, _Location(path, ordinal, "control"))
                    _record(branch["start"], _Location(path, ordinal, "control"))
                    branch_path = path + (("if", ordinal, branch_index),)
                    _walk(branch["body"], branch_path)
                _record(node["end"], _Location(path, ordinal, "control"))

    _walk(nodes, ())
    return locations, blocks


def _only_location(inst: Instruction, locations: Dict[int, List[_Location]]) -> Optional[_Location]:
    matches = locations.get(id(inst), [])
    if len(matches) != 1:
        return None
    return matches[0]


def plan_runtime_buffer_views(
    instructions: Iterable[Instruction],
) -> Dict[str, BufferViewDecision]:
    """Plan conservative expression inlining for runtime ``buffer[Var]`` views.

    The pass is intentionally pure: it neither rewrites instructions nor changes
    simulator view materialization. A runtime view is expression-inlined only when
    it has one direct material use in the same structured block and every Var read
    by its rendered index keeps the same reaching value between definition and use.
    """

    instructions = list(instructions)
    nodes, parsed = _parse_block(instructions, 0, None)
    if parsed != len(instructions):
        raise ValueError("buffer-view liveness block parsing did not fully consume instructions")
    locations, blocks = _index_structured_locations(nodes)

    definitions: List[Tuple[Instruction, Tensor, Var, Tuple[str, int]]] = []
    for inst in instructions:
        if inst.opname != "get_buf":
            continue
        out = inst.kwargs.get("out", None)
        buf = inst.kwargs.get("buf", None)
        index = inst.kwargs.get("index", None)
        key = _tensor_key(out)
        if (
            not isinstance(out, Tensor)
            or not isinstance(buf, (DBuff, TBuff, QBuff))
            or not isinstance(index, Var)
            or key is None
        ):
            continue
        definitions.append((inst, out, index, key))

    plan: Dict[str, BufferViewDecision] = {}
    for def_inst, out, index, key in definitions:
        uses: List[_Use] = []
        for inst in instructions:
            if inst is def_inst:
                continue
            for operand_name, value in inst.kwargs.items():
                matches = _collect_matching_tensors(value, key)
                for tensor, nested in matches:
                    derived = inst.opname in _DERIVED_VIEW_OPS and operand_name == "src"
                    uses.append(
                        _Use(
                            inst=inst,
                            nested=nested,
                            aliased_object=id(tensor) != id(out),
                            derived=derived,
                        )
                    )

        use_count = len(uses)
        if isinstance(index, VarRef):
            plan[out.name] = BufferViewDecision("materialize", "unsupported_index", use_count)
            continue
        if use_count == 0:
            plan[out.name] = BufferViewDecision("materialize", "no_material_consumer", 0)
            continue
        if use_count != 1:
            plan[out.name] = BufferViewDecision("materialize", "multiple_consumers", use_count)
            continue

        use = uses[0]
        if use.derived:
            plan[out.name] = BufferViewDecision("materialize", "derived_view", 1)
            continue
        if use.nested or use.aliased_object:
            plan[out.name] = BufferViewDecision("materialize", "escaped_view", 1)
            continue

        def_location = _only_location(def_inst, locations)
        use_location = _only_location(use.inst, locations)
        if def_location is None or use_location is None:
            plan[out.name] = BufferViewDecision("materialize", "ambiguous_location", 1)
            continue
        if def_location.role != "inst" or use_location.role != "inst":
            plan[out.name] = BufferViewDecision("materialize", "control_flow", 1)
            continue
        if def_location.block_path != use_location.block_path:
            plan[out.name] = BufferViewDecision("materialize", "control_flow", 1)
            continue
        if use_location.ordinal <= def_location.ordinal:
            plan[out.name] = BufferViewDecision("materialize", "not_dominated", 1)
            continue

        block = blocks[def_location.block_path]
        between = block[def_location.ordinal + 1 : use_location.ordinal]
        if any(node["type"] != "inst" for node in between):
            plan[out.name] = BufferViewDecision("materialize", "control_flow", 1)
            continue
        between_insts = [node["inst"] for node in between]
        if any(inst.opname in _CONTROL_TRANSFER_OPS for inst in between_insts):
            plan[out.name] = BufferViewDecision("materialize", "control_flow", 1)
            continue

        dependencies, stable_index_expression = _index_dependencies(index, instructions)
        if not stable_index_expression:
            plan[out.name] = BufferViewDecision("materialize", "unstable_index_expression", 1)
            continue
        writes = between_insts + [use.inst]
        if any(_written_var_name(inst) in dependencies for inst in writes):
            plan[out.name] = BufferViewDecision("materialize", "index_mutated", 1)
            continue

        plan[out.name] = BufferViewDecision("inline", "single_use_same_index_version", 1)

    return plan
