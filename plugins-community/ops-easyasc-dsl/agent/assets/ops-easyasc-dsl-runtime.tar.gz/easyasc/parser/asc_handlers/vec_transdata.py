from .common import Tensor, value_to_cpp, dtype_to_cpp


def handle_vec_transdata5hd(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"transdata5hd requires Tensor dst, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"transdata5hd requires Tensor src, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    repeat = value_to_cpp(inst.kwargs.get("repeat", None), expr_map)
    srs = value_to_cpp(inst.kwargs.get("src_row_stride", None), expr_map)
    drs = value_to_cpp(inst.kwargs.get("dst_row_stride", None), expr_map)
    srep = value_to_cpp(inst.kwargs.get("src_rep_stride", None), expr_map)
    drep = value_to_cpp(inst.kwargs.get("dst_rep_stride", None), expr_map)
    # bf16 is not in the a2 vnchwconv dtype list; pure bit moves -> half view.
    if str(dst.dtype) in ("bfloat16", "bf16") or dtype_to_cpp(dst.dtype) == "bfloat16_t":
        dst_expr = f"{dst_expr}.ReinterpretCast<half>()"
        src_expr = f"{src_expr}.ReinterpretCast<half>()"
    helper(f"TRANSDATA5HD({dst_expr}, {src_expr}, {repeat}, {srs}, {drs}, {srep}, {drep});")
