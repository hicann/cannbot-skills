from .common import Tensor, dtype_to_cpp, value_to_cpp


def handle_vec_sort32(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"Sort32 requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"Sort32 requires Tensor type, current type: {type(src)}")
    idx = inst.kwargs.get("idx", None)
    if not isinstance(idx, Tensor):
        raise TypeError(f"Sort32 requires Tensor type, current type: {type(idx)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    idx_expr = value_to_cpp(idx, expr_map)
    repeat = value_to_cpp(inst.kwargs.get("repeat", None), expr_map)
    helper(f"Sort32({dst_expr}, {src_expr}, {idx_expr}, {repeat});")


def handle_vec_mergesort4(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"Mergesort4 requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"Mergesort4 requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    length_per_seq = value_to_cpp(inst.kwargs.get("length_per_seq", None), expr_map)
    repeat = value_to_cpp(inst.kwargs.get("repeat", None), expr_map)
    helper(f"MERGESORT4({dst_expr}, {src_expr}, {length_per_seq}, {repeat});")


def handle_vec_mergesort_2seq(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"Mergesort2Seq requires Tensor type, current type: {type(dst)}")
    src1 = inst.kwargs.get("src1", None)
    if not isinstance(src1, Tensor):
        raise TypeError(f"Mergesort2Seq requires Tensor type, current type: {type(src1)}")
    src2 = inst.kwargs.get("src2", None)
    if not isinstance(src2, Tensor):
        raise TypeError(f"Mergesort2Seq requires Tensor type, current type: {type(src2)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src1_expr = value_to_cpp(src1, expr_map)
    src2_expr = value_to_cpp(src2, expr_map)
    size1 = value_to_cpp(inst.kwargs.get("size1", None), expr_map)
    size2 = value_to_cpp(inst.kwargs.get("size2", None), expr_map)
    helper(f"MERGESORT2SEQ({dst_expr}, {src1_expr}, {src2_expr}, {size1}, {size2});")


def handle_vec_topk_radix(inst, helper, expr_map) -> None:
    fields = (
        "dst_values", "dst_indices", "src_values", "src_indices", "tmp",
    )
    tensors = {}
    for field in fields:
        tensor = inst.kwargs.get(field, None)
        if not isinstance(tensor, Tensor):
            raise TypeError(
                f"topk_radix {field} requires Tensor type, current type: {type(tensor)}"
            )
        tensors[field] = tensor
    dst_values = value_to_cpp(tensors["dst_values"], expr_map)
    dst_indices = value_to_cpp(tensors["dst_indices"], expr_map)
    src_values = value_to_cpp(tensors["src_values"], expr_map)
    src_indices = value_to_cpp(tensors["src_indices"], expr_map)
    tmp = value_to_cpp(tensors["tmp"], expr_map)
    k = value_to_cpp(inst.kwargs.get("k", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("n", None), expr_map)
    aligned_n = value_to_cpp(inst.kwargs.get("aligned_n", None), expr_map)
    outter = value_to_cpp(inst.kwargs.get("outter", 1), expr_map)
    largest = value_to_cpp(inst.kwargs.get("largest", None), expr_map)
    sorted_literal = "true" if inst.kwargs.get("sorted", True) else "false"
    init_index_literal = "true" if inst.kwargs.get("init_index", True) else "false"
    dtype = dtype_to_cpp(tensors["src_values"].dtype)

    # Scope every call so kernels may invoke the API more than once in one
    # source block without colliding declaration names.
    helper("{")
    helper("    AscendC::LocalTensor<bool> easyascTopKEmptyFinish;")
    helper("    TopkTiling easyascTopKTiling;")
    helper("    AscendC::TopKInfo easyascTopKInfo;")
    helper(f"    easyascTopKInfo.outter = static_cast<int32_t>({outter});")
    helper(f"    easyascTopKInfo.inner = static_cast<int32_t>({aligned_n});")
    helper(f"    easyascTopKInfo.n = static_cast<int32_t>({n});")
    helper(
        "    static constexpr AscendC::TopKConfig easyascTopKConfig{"
        "AscendC::TopKAlgo::RADIX_SELECT, AscendC::TopKOrder::UNSET, "
        f"{sorted_literal}" + "};"
    )
    helper(
        f"    AscendC::TopK<{dtype}, {init_index_literal}, false, false, "
        "AscendC::TopKMode::TOPK_NORMAL, easyascTopKConfig>("
    )
    helper(f"        {dst_values}, {dst_indices}, {src_values}, {src_indices},")
    helper(f"        easyascTopKEmptyFinish, {tmp}, static_cast<int32_t>({k}),")
    helper(
        "        easyascTopKTiling, easyascTopKInfo, "
        f"(({largest}) > 0));"
    )
    helper("}")
