from .common import value_to_cpp


def _mask_operand_to_cpp(value, expr_map) -> str:
    if isinstance(value, int) and not isinstance(value, bool):
        # SetVectorMask operands are 64-bit mask words. Python-side mask helpers
        # may intentionally produce negative values such as `-(1 << n)`, whose
        # lower 64 bits are the actual mask pattern. Emit those literals modulo
        # 2^64 so codegen never prints an out-of-range signed integer like
        # `-18446744073709551616`.
        return f"0x{(value & ((1 << 64) - 1)):016x}ULL"
    return value_to_cpp(value, expr_map)


def handle_set_mask(inst, helper, expr_map) -> None:
    low = _mask_operand_to_cpp(inst.kwargs.get("low", None), expr_map)
    high = _mask_operand_to_cpp(inst.kwargs.get("high", None), expr_map)
    helper(f"SetVectorMask<half, MaskMode::NORMAL>({high}, {low});")


def handle_reset_mask(inst, helper, expr_map) -> None:
    helper("ResetMask();")


def handle_set_mask_count(inst, helper, expr_map) -> None:
    helper("SetMaskCount();")


def handle_set_mask_normal(inst, helper, expr_map) -> None:
    helper("SetMaskNorm();")


def handle_set_mask_counter(inst, helper, expr_map) -> None:
    count = value_to_cpp(inst.kwargs.get("count", None), expr_map)
    helper(f"SetVectorMask<half, MaskMode::COUNTER>({count});")


def handle_set_mask_by_count(inst, helper, expr_map) -> None:
    count = value_to_cpp(inst.kwargs.get("count", None), expr_map)
    helper(f"SetVectorMaskByCount({count});")
