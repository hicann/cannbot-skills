from .common import GMTensor, Tensor, Position, value_to_cpp
from ...utils.datatype import Datatype
from ...device_profile import is_a5_family, is_c220_family


def handle_gm_to_l1_nd2nz(inst, helper, expr_map) -> None:
    from ... import globvars

    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"gm_to_l1_nd2nz requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"gm_to_l1_nd2nz requires GMTensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    n_src = value_to_cpp(inst.kwargs.get("N_src", None), expr_map)
    m_dst = value_to_cpp(inst.kwargs.get("M_dst", None), expr_map)
    opname = "GM2L1_ND2ZZ" if is_c220_family(globvars.device_type) and dst.dtype is Datatype.float else "GM2L1_ND2NZ"
    helper(f"{opname}({dst_expr}, {src_expr}, {m}, {n}, {n_src}, {m_dst});")


def handle_gm_to_l1_dn2nz(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"gm_to_l1_dn2nz requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"gm_to_l1_dn2nz requires GMTensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    n_src = value_to_cpp(inst.kwargs.get("N_src", None), expr_map)
    m_dst = value_to_cpp(inst.kwargs.get("M_dst", None), expr_map)
    helper(f"GM2L1_DN2NZ({dst_expr}, {src_expr}, {m}, {n}, {n_src}, {m_dst});")


def handle_gm_to_l1_mx_scale_nd2nz(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"gm_to_l1_mx_scale_nd2nz requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"gm_to_l1_mx_scale_nd2nz requires GMTensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    rows = value_to_cpp(inst.kwargs.get("rows", None), expr_map)
    k_groups = value_to_cpp(inst.kwargs.get("k_groups", None), expr_map)
    src_k_groups = value_to_cpp(inst.kwargs.get("src_k_groups", None), expr_map)
    helper(f"GM2L1_MX_SCALE_DN2NZ({dst_expr}, {src_expr}, {rows}, {k_groups}, {src_k_groups});")


def handle_gm_to_l1_pad(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"gm_to_l1_pad requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"gm_to_l1_pad requires GMTensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    n_burst = value_to_cpp(inst.kwargs.get("n_burst", None), expr_map)
    burst_len_byte = value_to_cpp(inst.kwargs.get("burst_len_byte", None), expr_map)
    src_stride_byte = value_to_cpp(inst.kwargs.get("src_stride_byte", None), expr_map)
    dst_stride = value_to_cpp(inst.kwargs.get("dst_stride", None), expr_map)
    helper(f"GM2L1PAD({dst_expr}, {src_expr}, {n_burst}, {burst_len_byte}, {src_stride_byte}, {dst_stride});")


def handle_gm_to_l1(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"gm_to_l1 requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"gm_to_l1 requires GMTensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    n_burst = value_to_cpp(inst.kwargs.get("n_burst", None), expr_map)
    burst_len = value_to_cpp(inst.kwargs.get("burst_len", None), expr_map)
    src_stride = value_to_cpp(inst.kwargs.get("src_stride", None), expr_map)
    dst_stride = value_to_cpp(inst.kwargs.get("dst_stride", None), expr_map)
    helper(f"GM2L1({dst_expr}, {src_expr}, {n_burst}, {burst_len}, {src_stride}, {dst_stride});")


def handle_set_constant_to_l1(inst, helper, expr_map) -> None:
    tensor = inst.kwargs.get("tensor", None)
    if not isinstance(tensor, Tensor):
        raise TypeError(f"set_constant_to_l1 requires Tensor type, current type: {type(tensor)}")
    if tensor.position is not Position.L1:
        raise ValueError(
            f"set_constant_to_l1 requires L1 tensor, current position: {tensor.position}"
        )
    tensor_expr = value_to_cpp(tensor, expr_map)
    n_blocks = value_to_cpp(inst.kwargs.get("n_blocks", None), expr_map)
    val = value_to_cpp(inst.kwargs.get("val", None), expr_map)
    # repeatTimes is a uint16_t member of an aggregate initializer, so a runtime
    # n_blocks expression must be parenthesized inside the cast or the compiler
    # rejects the narrowing of the surrounding int expression.
    helper(f"InitConstValue({tensor_expr}, {{1, (uint16_t)({n_blocks}), 0, {val}}});")


def handle_l1_to_l0(inst, helper, expr_map) -> None:
    from ... import globvars
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"l1_to_l0 requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l1_to_l0 requires Tensor type, current type: {type(src)}")
    dst_pos = str(dst.position)
    src_transpose = bool(getattr(src, "is_transpose", False))
    if is_c220_family(globvars.device_type) and src.dtype is Datatype.float:
        if dst_pos == "L0A":
            opname = "L0ZZ2NN" if src_transpose else "L0ZZ2ZZ"
        elif dst_pos == "L0B":
            opname = "L0ZZ2ZN" if src_transpose else "L0ZZ2NZ"
        else:
            raise ValueError(f"l1_to_l0does not support dstposition: {dst.position}")
    elif dst_pos == "L0A" and is_c220_family(globvars.device_type):
        opname = "L0NZ2NN" if src_transpose else "L0NZ2ZZ"
    elif dst_pos == "L0B" or is_a5_family(globvars.device_type):
        opname = "L0NZ2ZN" if src_transpose else "L0NZ2NZ"
    else:
        raise ValueError(f"l1_to_l0does not support dstposition: {dst.position}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m_dst = value_to_cpp(inst.kwargs.get("m_dst", None), expr_map)
    n_dst = value_to_cpp(inst.kwargs.get("n_dst", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("m_src", None), expr_map)
    n_src = value_to_cpp(inst.kwargs.get("n_src", None), expr_map)
    helper(f"{opname}({dst_expr}, {src_expr}, {m_dst}, {n_dst}, {m_src}, {n_src});")


def handle_l1_to_l0_img2col(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"l1_to_l0_img2col requires Tensor dst, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l1_to_l0_img2col requires Tensor src, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    h = value_to_cpp(inst.kwargs.get("h", None), expr_map)
    w = value_to_cpp(inst.kwargs.get("w", None), expr_map)
    c = value_to_cpp(inst.kwargs.get("c", None), expr_map)
    kh = value_to_cpp(inst.kwargs.get("kh", None), expr_map)
    kw = value_to_cpp(inst.kwargs.get("kw", None), expr_map)
    # pad / stride / dilation land in runtime `int` arguments of the helper, so
    # they render through value_to_cpp and may be Vars just like h/w/c/kh/kw.
    pl = value_to_cpp(inst.kwargs.get("pad_l"), expr_map)
    pr = value_to_cpp(inst.kwargs.get("pad_r"), expr_map)
    pt = value_to_cpp(inst.kwargs.get("pad_t"), expr_map)
    pb = value_to_cpp(inst.kwargs.get("pad_b"), expr_map)
    sh = value_to_cpp(inst.kwargs.get("stride_h"), expr_map)
    sw = value_to_cpp(inst.kwargs.get("stride_w"), expr_map)
    dh = value_to_cpp(inst.kwargs.get("dil_h"), expr_map)
    dw = value_to_cpp(inst.kwargs.get("dil_w"), expr_map)
    m0 = value_to_cpp(inst.kwargs.get("m0", None), expr_map)
    k0 = value_to_cpp(inst.kwargs.get("k0", None), expr_map)
    m_ext = value_to_cpp(inst.kwargs.get("m_ext", None), expr_map)
    k_ext = value_to_cpp(inst.kwargs.get("k_ext", None), expr_map)
    helper(
        f"L12L0A_IMG2COL({dst_expr}, {src_expr}, {h}, {w}, {c}, {kh}, {kw}, "
        f"{pl}, {pr}, {pt}, {pb}, {sh}, {sw}, {dh}, {dw}, {k0}, {m0}, {k_ext}, {m_ext});"
    )


def handle_l1_to_bt(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"l1_to_bt requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l1_to_bt requires Tensor type, current type: {type(src)}")
    if dst.position is not Position.BT:
        raise ValueError(f"l1_to_bt requires BT dst, current position: {dst.position}")
    if src.position is not Position.L1:
        raise ValueError(f"l1_to_bt requires L1 src, current position: {src.position}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    n = value_to_cpp(inst.kwargs.get("n", None), expr_map)
    helper(f"L1_TO_BT({dst_expr}, {src_expr}, {n});")


def handle_l1_to_l0_mx(inst, helper, expr_map) -> None:
    from ... import globvars
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"l1_to_l0_mx requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l1_to_l0_mx requires Tensor type, current type: {type(src)}")
    src_mx = inst.kwargs.get("src_mx", None)
    if not isinstance(src_mx, Tensor):
        raise TypeError(f"l1_to_l0_mx requires Tensor type, current type: {type(src_mx)}")
    if not is_a5_family(globvars.device_type):
        raise ValueError("l1_to_l0_mx is only supported on a5/Atlas 350")
    if bool(getattr(src_mx, "is_transpose", False)):
        raise ValueError("l1_to_l0_mx scale tensor cannot be transposed")
    src_transpose = bool(getattr(src, "is_transpose", False))
    opname = "L0NZ2ZN_MX" if src_transpose else "L0NZ2NZ_MX"
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    src_mx_expr = value_to_cpp(src_mx, expr_map)
    src_mx_offset_element = value_to_cpp(inst.kwargs.get("src_mx_offset_element", 0), expr_map)
    if src_mx_offset_element not in ("0", "(0)"):
        src_mx_expr = f"{src_mx_expr}[{src_mx_offset_element}]"
    m_dst = value_to_cpp(inst.kwargs.get("m_dst", None), expr_map)
    n_dst = value_to_cpp(inst.kwargs.get("n_dst", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("m_src", None), expr_map)
    n_src = value_to_cpp(inst.kwargs.get("n_src", None), expr_map)
    helper(f"{opname}({dst_expr}, {src_expr}, {src_mx_expr}, {m_dst}, {n_dst}, {m_src}, {n_src});")


def handle_mmad(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"mmad requires Tensor type, current type: {type(dst)}")
    src_a = inst.kwargs.get("src_a", None)
    if not isinstance(src_a, Tensor):
        raise TypeError(f"mmad requires Tensor type, current type: {type(src_a)}")
    src_b = inst.kwargs.get("src_b", None)
    if not isinstance(src_b, Tensor):
        raise TypeError(f"mmad requires Tensor type, current type: {type(src_b)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_a_expr = value_to_cpp(src_a, expr_map)
    src_b_expr = value_to_cpp(src_b, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    k = value_to_cpp(inst.kwargs.get("K", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    unit_flag = inst.kwargs.get("unit_flag", None)
    unit_flag_expr = (
        value_to_cpp(unit_flag, expr_map) if unit_flag is not None else None
    )
    bias = inst.kwargs.get("bias", None)
    if bias is not None:
        if not isinstance(bias, Tensor):
            raise TypeError(f"mmad bias requires Tensor type, current type: {type(bias)}")
        bias_expr = value_to_cpp(bias, expr_map)
        # C = bias + A@B on the is_init tile (cmatrixInitVal=false, cmatrixSource
        # auto-derived from the bias's C2 position inside MMAD_BIAS).
        if unit_flag_expr is None:
            helper(f"MMAD_BIAS({dst_expr}, {src_a_expr}, {src_b_expr}, {bias_expr}, {m}, {k}, {n});")
        else:
            helper(f"MMAD_BIAS({dst_expr}, {src_a_expr}, {src_b_expr}, {bias_expr}, {m}, {k}, {n}, {unit_flag_expr});")
        return
    is_init = value_to_cpp(inst.kwargs.get("is_init", None), expr_map)
    if unit_flag_expr is None:
        helper(f"MMAD({dst_expr}, {src_a_expr}, {src_b_expr}, {m}, {k}, {n}, {is_init});")
    else:
        helper(f"MMAD({dst_expr}, {src_a_expr}, {src_b_expr}, {m}, {k}, {n}, {is_init}, {unit_flag_expr});")


def handle_mmad_mx(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"mmad_mx requires Tensor type, current type: {type(dst)}")
    src_a = inst.kwargs.get("src_a", None)
    if not isinstance(src_a, Tensor):
        raise TypeError(f"mmad_mx requires Tensor type, current type: {type(src_a)}")
    src_b = inst.kwargs.get("src_b", None)
    if not isinstance(src_b, Tensor):
        raise TypeError(f"mmad_mx requires Tensor type, current type: {type(src_b)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_a_expr = value_to_cpp(src_a, expr_map)
    src_b_expr = value_to_cpp(src_b, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    k = value_to_cpp(inst.kwargs.get("K", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    bias = inst.kwargs.get("bias", None)
    if bias is not None:
        if not isinstance(bias, Tensor):
            raise TypeError(f"mmad_mx bias requires Tensor type, current type: {type(bias)}")
        bias_expr = value_to_cpp(bias, expr_map)
        # C = bias + (scaled A)@(scaled B) on the is_init tile (cmatrixInitVal=false,
        # cmatrixSource auto-derived from the bias's C2 position inside MMAD_MX_BIAS).
        helper(f"MMAD_MX_BIAS({dst_expr}, {src_a_expr}, {src_b_expr}, {bias_expr}, {m}, {k}, {n});")
        return
    is_init = value_to_cpp(inst.kwargs.get("is_init", None), expr_map)
    helper(f"MMAD_MX({dst_expr}, {src_a_expr}, {src_b_expr}, {m}, {k}, {n}, {is_init});")


def handle_l0c_to_gm_nz2nd(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"l0c_to_gm_nz2nd requires GMTensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l0c_to_gm_nz2nd requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    n_dst = value_to_cpp(inst.kwargs.get("N_dst", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("M_src", None), expr_map)
    relu = value_to_cpp(inst.kwargs.get("relu", None), expr_map)
    scale = inst.kwargs.get("scale", 1.0)
    offset = inst.kwargs.get("offset", 0)
    hif8_hybrid = bool(inst.kwargs.get("hif8_hybrid", False))
    scale_is_default = isinstance(scale, (int, float)) and not isinstance(scale, bool) and float(scale) == 1.0
    offset_is_default = isinstance(offset, int) and not isinstance(offset, bool) and offset == 0
    if scale_is_default and offset_is_default and not hif8_hybrid:
        helper(f"L0C2GM_NZ2ND({dst_expr}, {src_expr}, {m}, {n}, {n_dst}, {m_src}, {relu});")
    else:
        scale_expr = value_to_cpp(scale, expr_map)
        offset_expr = value_to_cpp(offset, expr_map)
        # arg 10 `true` = scaledQuant (routes fp32->float/half/bf16 to the scaled QF322*_PRE
        # modes; ignored by the dtype-forced int8/uint8/int32->half|bf16/fp8/hif8 modes).
        # arg 11 = hif8Hybrid (QF322HIF8_PRE_HYBRID vs half-to-away for a hif8 dst).
        hybrid_expr = "true" if hif8_hybrid else "false"
        helper(f"L0C2GM_NZ2ND({dst_expr}, {src_expr}, {m}, {n}, {n_dst}, {m_src}, {relu}, {scale_expr}, {offset_expr}, true, {hybrid_expr});")


def handle_l0c_to_gm_nz2nz(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"l0c_to_gm_nz2nz requires GMTensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l0c_to_gm_nz2nz requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    m_pad = value_to_cpp(inst.kwargs.get("M_pad", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("M_src", None), expr_map)
    relu = value_to_cpp(bool(inst.kwargs.get("relu", False)), expr_map)
    scale = inst.kwargs.get("scale", 1.0)
    offset = inst.kwargs.get("offset", 0)
    hif8_hybrid = bool(inst.kwargs.get("hif8_hybrid", False))
    scale_is_default = isinstance(scale, (int, float)) and not isinstance(scale, bool) and float(scale) == 1.0
    offset_is_default = isinstance(offset, int) and not isinstance(offset, bool) and offset == 0
    if scale_is_default and offset_is_default and not hif8_hybrid:
        helper(f"L0C2GM_NZ2NZ({dst_expr}, {src_expr}, {m}, {n}, {m_pad}, {m_src}, {relu});")
    else:
        scale_expr = value_to_cpp(scale, expr_map)
        offset_expr = value_to_cpp(offset, expr_map)
        hybrid_expr = "true" if hif8_hybrid else "false"
        helper(f"L0C2GM_NZ2NZ({dst_expr}, {src_expr}, {m}, {n}, {m_pad}, {m_src}, {relu}, {scale_expr}, {offset_expr}, true, {hybrid_expr});")


def handle_l0c_to_gm_nz2dn(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"l0c_to_gm_nz2dn requires GMTensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l0c_to_gm_nz2dn requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    m_dst = value_to_cpp(inst.kwargs.get("M_dst", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("M_src", None), expr_map)
    relu = value_to_cpp(bool(inst.kwargs.get("relu", False)), expr_map)
    scale = inst.kwargs.get("scale", 1.0)
    offset = inst.kwargs.get("offset", 0)
    hif8_hybrid = bool(inst.kwargs.get("hif8_hybrid", False))
    unit_flag = inst.kwargs.get("unit_flag", None)
    unit_flag_expr = (
        value_to_cpp(unit_flag, expr_map) if unit_flag is not None else None
    )
    scale_is_default = isinstance(scale, (int, float)) and not isinstance(scale, bool) and float(scale) == 1.0
    offset_is_default = isinstance(offset, int) and not isinstance(offset, bool) and offset == 0
    if scale_is_default and offset_is_default and not hif8_hybrid:
        if unit_flag_expr is None:
            helper(f"L0C2GM_NZ2DN({dst_expr}, {src_expr}, {m}, {n}, {m_dst}, {m_src}, {relu});")
        else:
            helper(f"L0C2GM_NZ2DN({dst_expr}, {src_expr}, {m}, {n}, {m_dst}, {m_src}, {relu}, 1.0f, 0, false, false, {unit_flag_expr});")
    else:
        scale_expr = value_to_cpp(scale, expr_map)
        offset_expr = value_to_cpp(offset, expr_map)
        hybrid_expr = "true" if hif8_hybrid else "false"
        suffix = (
            f", {unit_flag_expr}" if unit_flag_expr is not None else ""
        )
        helper(f"L0C2GM_NZ2DN({dst_expr}, {src_expr}, {m}, {n}, {m_dst}, {m_src}, {relu}, {scale_expr}, {offset_expr}, true, {hybrid_expr}{suffix});")


def handle_l0c_to_l1(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"l0c_to_l1 requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l0c_to_l1 requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    m_dst = value_to_cpp(inst.kwargs.get("M_dst", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("M_src", None), expr_map)
    relu = value_to_cpp(inst.kwargs.get("relu", None), expr_map)
    helper(f"L0C2L1({dst_expr}, {src_expr}, {m}, {n}, {m_dst}, {m_src}, {relu});")


def handle_l0c_to_ub(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"l0c_to_ub requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"l0c_to_ub requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m = value_to_cpp(inst.kwargs.get("M", None), expr_map)
    n = value_to_cpp(inst.kwargs.get("N", None), expr_map)
    n_dst = value_to_cpp(inst.kwargs.get("N_dst", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("M_src", None), expr_map)
    dual_mode = value_to_cpp(inst.kwargs.get("dual_mode", None), expr_map)
    sub_block_id = value_to_cpp(inst.kwargs.get("sub_block_id", None), expr_map)
    relu = value_to_cpp(inst.kwargs.get("relu", None), expr_map)
    scale = inst.kwargs.get("scale", 1.0)
    offset = inst.kwargs.get("offset", 0)
    hif8_hybrid = bool(inst.kwargs.get("hif8_hybrid", False))
    scale_is_default = isinstance(scale, (int, float)) and not isinstance(scale, bool) and float(scale) == 1.0
    offset_is_default = isinstance(offset, int) and not isinstance(offset, bool) and offset == 0
    if scale_is_default and offset_is_default and not hif8_hybrid:
        # No requant: byte-identical to the pre-feature 9-arg cast/relu store (dual modes too).
        helper(
            f"L0C2UB_NZ2ND({dst_expr}, {src_expr}, {m}, {n}, {n_dst}, {m_src}, {dual_mode}, {sub_block_id}, {relu});"
        )
    else:
        scale_expr = value_to_cpp(scale, expr_map)
        offset_expr = value_to_cpp(offset, expr_map)
        # arg 12 `true` = scaledQuant (routes fp32->float/half/bf16 to the scaled QF322*_PRE
        # modes; ignored by the dtype-forced int8/uint8/int32->half|bf16/fp8/hif8 modes).
        # arg 13 = hif8Hybrid (QF322HIF8_PRE_HYBRID vs half-to-away for a hif8 dst).
        hybrid_expr = "true" if hif8_hybrid else "false"
        helper(
            f"L0C2UB_NZ2ND({dst_expr}, {src_expr}, {m}, {n}, {n_dst}, {m_src}, {dual_mode}, {sub_block_id}, {relu}, {scale_expr}, {offset_expr}, true, {hybrid_expr});"
        )
