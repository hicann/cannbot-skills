from .common import GMTensor, Tensor, dtype_to_cpp, value_to_cpp


def _render_array(values, expr_map, cast: str = "") -> str:
    # NdDmaLoopInfo members are uint64_t / uint32_t. A runtime Var lowers to a
    # signed int expression, and a braced initializer rejects that narrowing,
    # so every element carries an explicit cast to the member type.
    if not cast:
        return "{" + ", ".join(value_to_cpp(value, expr_map) for value in values) + "}"
    return "{" + ", ".join(
        f"({cast})({value_to_cpp(value, expr_map)})" for value in values
    ) + "}"


def _render_bool(value: bool) -> str:
    return "true" if value else "false"


def _render_config_pad(value) -> str:
    if value is None:
        return "AscendC::NdDmaConfig::unsetPad"
    return str(int(value))


def handle_vec_gm2ubpad(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"gm_to_ub_pad requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"gm_to_ub_pad requires GMTensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    n_burst = value_to_cpp(inst.kwargs.get("n_burst", None), expr_map)
    burst_len_byte = value_to_cpp(inst.kwargs.get("burst_len_byte", None), expr_map)
    src_stride_byte = value_to_cpp(inst.kwargs.get("src_stride_byte", None), expr_map)
    dst_stride = value_to_cpp(inst.kwargs.get("dst_stride", None), expr_map)
    helper(f"GM2UBPAD({dst_expr}, {src_expr}, {n_burst}, {burst_len_byte}, {src_stride_byte}, {dst_stride});")


def handle_vec_gm2ub_nd_dma(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"gm_to_ub_nd_dma requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"gm_to_ub_nd_dma requires GMTensor type, current type: {type(src)}")
    dim = int(inst.kwargs.get("dim", 0))
    uid = f"{dst.name}_{abs(id(inst))}"
    loop_info_name = f"_nd_dma_loop_info_{uid}"
    config_name = f"_nd_dma_config_{uid}"
    dtype_cpp = dtype_to_cpp(dst.dtype)
    src_expr = value_to_cpp(src, expr_map)
    dst_expr = value_to_cpp(dst, expr_map)
    # Member types of AscendC MultiCopyLoopInfo<dim> (kernel_struct_data_copy.h):
    # loopSrcStride u64, loopDstStride u32, loopSize u32, loopLpSize/loopRpSize u8.
    loop_src_stride = _render_array(inst.kwargs.get("loop_src_stride", ()), expr_map, "uint64_t")
    loop_dst_stride = _render_array(inst.kwargs.get("loop_dst_stride", ()), expr_map, "uint32_t")
    loop_size = _render_array(inst.kwargs.get("loop_size", ()), expr_map, "uint32_t")
    loop_left_pad = _render_array(inst.kwargs.get("loop_left_pad", ()), expr_map, "uint8_t")
    loop_right_pad = _render_array(inst.kwargs.get("loop_right_pad", ()), expr_map, "uint8_t")
    nearest_value_mode = _render_bool(bool(inst.kwargs.get("nearest_value_mode", False)))
    config_left_pad = _render_config_pad(inst.kwargs.get("config_left_pad", None))
    config_right_pad = _render_config_pad(inst.kwargs.get("config_right_pad", None))
    asc_optimize = _render_bool(bool(inst.kwargs.get("asc_optimize", False)))
    constant_value = value_to_cpp(inst.kwargs.get("constant_value", 0), expr_map)

    helper(f"AscendC::NdDmaLoopInfo<{dim}> {loop_info_name}{{{loop_src_stride}, {loop_dst_stride}, {loop_size}, {loop_left_pad}, {loop_right_pad}}};")
    helper(f"static constexpr AscendC::NdDmaConfig {config_name}{{{nearest_value_mode}, {config_left_pad}, {config_right_pad}, {asc_optimize}}};")
    helper(f"GM2UB_ND_DMA<{dtype_cpp}, {dim}, {config_name}>({dst_expr}, {src_expr}, {loop_info_name}, ({dtype_cpp}){constant_value});")
    # AscendC declares the NdDma DataCopy WITHOUT an __inout_pipe__ tag, so it is
    # not obviously part of the MTE2 queue and an earlier probe read a staging
    # tile up to two transfers early. PIPE_ALL is the conservative answer and
    # stays the default, but it drains the core and forbids load/store overlap.
    # ``fence="mte2"`` drops it and relies on the ordinary MTE2 sequencing, which
    # is what CANN's own ND DMA users do (arch35 StridedSliceNDDMA uses a plain
    # TQueBind EnQue/DeQue, cumsum a SetFlag/WaitFlag<HardEvent::MTE2_V> pair;
    # neither emits a pipe barrier).
    if str(inst.kwargs.get("fence", "all")) == "all":
        helper("PipeBarrier<PIPE_ALL>();")


def handle_vec_ub2gmpad(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"ub_to_gm_pad requires GMTensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"ub_to_gm_pad requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    n_burst = value_to_cpp(inst.kwargs.get("n_burst", None), expr_map)
    burst_len_byte = value_to_cpp(inst.kwargs.get("burst_len_byte", None), expr_map)
    src_stride = value_to_cpp(inst.kwargs.get("src_stride", None), expr_map)
    dst_stride_byte = value_to_cpp(inst.kwargs.get("dst_stride_byte", None), expr_map)
    helper(f"UB2GMPAD({dst_expr}, {src_expr}, {n_burst}, {burst_len_byte}, {src_stride}, {dst_stride_byte});")


def handle_vec_ub2ub(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"ub_to_ub requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"ub_to_ub requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    n_burst = value_to_cpp(inst.kwargs.get("n_burst", None), expr_map)
    burst_len = value_to_cpp(inst.kwargs.get("burst_len", None), expr_map)
    src_stride = value_to_cpp(inst.kwargs.get("src_stride", None), expr_map)
    dst_stride = value_to_cpp(inst.kwargs.get("dst_stride", None), expr_map)
    helper(f"UB2UB({dst_expr}, {src_expr}, {n_burst}, {burst_len}, {src_stride}, {dst_stride});")


def handle_vec_ub2l1(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"ub_to_l1 requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"ub_to_l1 requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    n_burst = value_to_cpp(inst.kwargs.get("n_burst", None), expr_map)
    burst_len = value_to_cpp(inst.kwargs.get("burst_len", None), expr_map)
    src_stride = value_to_cpp(inst.kwargs.get("src_stride", None), expr_map)
    dst_stride = value_to_cpp(inst.kwargs.get("dst_stride", None), expr_map)
    helper(f"UB2L1({dst_expr}, {src_expr}, {n_burst}, {burst_len}, {src_stride}, {dst_stride});")


def handle_vec_ub2l1_nd2nz(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"ub_to_l1_nd2nz requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"ub_to_l1_nd2nz requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m_dst = value_to_cpp(inst.kwargs.get("m_dst", None), expr_map)
    n_dst = value_to_cpp(inst.kwargs.get("n_dst", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("m_src", None), expr_map)
    n_src = value_to_cpp(inst.kwargs.get("n_src", None), expr_map)
    N_src = value_to_cpp(inst.kwargs.get("N_src", None), expr_map)
    helper(f"UB2L1_ND2NZ({dst_expr}, {src_expr}, {m_dst}, {n_dst}, {m_src}, {n_src}, {N_src});")


def handle_vec_ub2l1_nz(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"ub_to_l1_nz requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"ub_to_l1_nz requires Tensor type, current type: {type(src)}")
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    m_dst = value_to_cpp(inst.kwargs.get("m_dst", None), expr_map)
    n_dst = value_to_cpp(inst.kwargs.get("n_dst", None), expr_map)
    m_src = value_to_cpp(inst.kwargs.get("m_src", None), expr_map)
    n_src = value_to_cpp(inst.kwargs.get("n_src", None), expr_map)
    # M_src = physical fractal-row stride (src.shape[0]); UB2L1_NZ uses srcStride = M_src - m_src
    # to skip padding rows. Fall back to m_src for older instructions (-> srcStride 0, back-compat).
    M_src_raw = inst.kwargs.get("M_src", None)
    M_src = value_to_cpp(M_src_raw, expr_map) if M_src_raw is not None else m_src
    helper(f"UB2L1_NZ({dst_expr}, {src_expr}, {m_dst}, {n_dst}, {m_src}, {n_src}, {M_src});")
