from .common import GMTensor, Tensor, Var, dtype_to_cpp, value_to_cpp


def handle_call_simt(inst, helper, expr_map) -> None:
    name = inst.kwargs.get("name", None)
    if not isinstance(name, str):
        raise TypeError(f"call_simt requires name be str, got: {type(name)}")
    args = inst.kwargs.get("args", None)
    if args is None:
        args = []
    if not isinstance(args, (list, tuple)):
        raise TypeError(f"call_simt requires args be list/tuple, got: {type(args)}")
    num_threads = inst.kwargs.get("num_threads", 1024)
    if isinstance(num_threads, bool) or not isinstance(num_threads, int):
        raise TypeError(
            f"call_simt num_threads must be int, got: {type(num_threads)}"
        )
    arg_exprs = []
    for arg in args:
        if isinstance(arg, GMTensor):
            dtype = dtype_to_cpp(arg.dtype)
            expr = value_to_cpp(arg, expr_map)
            arg_exprs.append(f"(__gm__ {dtype}*) ({expr}).GetPhyAddr()")
        elif isinstance(arg, Tensor):
            dtype = dtype_to_cpp(arg.dtype)
            expr = value_to_cpp(arg, expr_map)
            arg_exprs.append(f"(__ubuf__ {dtype}*) ({expr}).GetPhyAddr()")
        elif isinstance(arg, Var):
            arg_exprs.append(value_to_cpp(arg, expr_map))
        else:
            raise TypeError(
                f"call_simt only supports GMTensor, Tensor, or Var; got: {type(arg)}"
            )
    helper(
        f"Simt::VF_CALL<{name}>(Simt::Dim3{{{num_threads}, 1, 1}}, {', '.join(arg_exprs)});"
    )
