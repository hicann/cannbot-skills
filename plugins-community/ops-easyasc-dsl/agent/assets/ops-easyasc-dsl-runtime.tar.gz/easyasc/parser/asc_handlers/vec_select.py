from .common import Tensor, dtype_to_cpp, value_to_cpp


def _addr_component(value) -> str:
    return getattr(value, "name", str(value))


def _same_tensor_address(lhs: Tensor, rhs: Tensor) -> bool:
    lhs_key = getattr(lhs, "storage_key_name", lhs.name)
    rhs_key = getattr(rhs, "storage_key_name", rhs.name)
    if lhs_key != rhs_key:
        return False
    lhs_index = getattr(lhs, "source_index", None)
    rhs_index = getattr(rhs, "source_index", None)
    if _addr_component(lhs_index) != _addr_component(rhs_index):
        return False
    lhs_offset = tuple(_addr_component(v) for v in getattr(lhs, "offset", []))
    rhs_offset = tuple(_addr_component(v) for v in getattr(rhs, "offset", []))
    return lhs_offset == rhs_offset


def handle_vec_select(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"select requires Tensor type, current type: {type(dst)}")
    selmask = inst.kwargs.get("selmask", None)
    if not isinstance(selmask, Tensor):
        raise TypeError(f"select requires Tensor type for selmask, current type: {type(selmask)}")
    src1 = inst.kwargs.get("src1", None)
    if not isinstance(src1, Tensor):
        raise TypeError(f"select requires Tensor type, current type: {type(src1)}")
    src2 = inst.kwargs.get("src2", None)
    if not isinstance(src2, Tensor):
        raise TypeError(f"select requires Tensor type for src2, current type: {type(src2)}")

    dst_expr = value_to_cpp(dst, expr_map)
    selmask_expr = value_to_cpp(selmask, expr_map)
    src1_expr = value_to_cpp(src1, expr_map)
    src2_expr = value_to_cpp(src2, expr_map)
    tmp_addr_buf = inst.kwargs.get("tmp_addr_buf", None)

    mode = inst.kwargs.get("mode", None)
    if mode is None:
        raise ValueError("select requires an explicit mode argument")
    mode_name = value_to_cpp(mode, expr_map)

    repeat = value_to_cpp(inst.kwargs.get("repeat", None), expr_map)
    dst_blk_stride = value_to_cpp(inst.kwargs.get("dst_blk_stride", None), expr_map)
    src1_blk_stride = value_to_cpp(inst.kwargs.get("src1_blk_stride", None), expr_map)
    src2_blk_stride = value_to_cpp(inst.kwargs.get("src2_blk_stride", None), expr_map)
    dst_rep_stride = value_to_cpp(inst.kwargs.get("dst_rep_stride", None), expr_map)
    src1_rep_stride = value_to_cpp(inst.kwargs.get("src1_rep_stride", None), expr_map)
    src2_rep_stride = value_to_cpp(inst.kwargs.get("src2_rep_stride", None), expr_map)
    dst_dtype = dtype_to_cpp(dst.dtype)

    stride_block = (
        f"{{(uint8_t){dst_blk_stride}, (uint8_t){src1_blk_stride}, (uint8_t){src2_blk_stride}, "
        f"(uint8_t){dst_rep_stride}, (uint8_t){src1_rep_stride}, (uint8_t){src2_rep_stride}}}"
    )

    if mode_name == "TENSOR_SCALAR":
        helper(f"SetCmpMask({src2_expr});")
        helper("PipeBarrier<PIPE_V>();")
        helper(
            f"Select({dst_expr}, {selmask_expr}, {src1_expr}, {repeat}, {stride_block});"
        )
    elif mode_name == "TENSOR_TENSOR":
        if _same_tensor_address(dst, src1) or _same_tensor_address(dst, src2):
            raise ValueError("SelectMode.TENSOR_TENSOR requires dst address to differ from src1 and src2")
        if tmp_addr_buf is None:
            # No implicit UB. easyasc never borrows CANN's fixed TMP_UB_OFFSET scratch
            # (184-192 KB on a2) for the selMask-address staging, because that occupies UB
            # outside easyasc's accounting and can clobber user tensors. The caller must pass
            # an explicit `tmp_addr_buf` (enforced in the stub; re-checked here defensively).
            raise ValueError(
                "SelectMode.TENSOR_TENSOR requires an explicit tmp_addr_buf to stage the "
                "selMask address; easyasc does not borrow CANN's implicit TMP_UB_OFFSET scratch"
            )
        # Per-repeat selMask (mode 2): the hardware advances 256/sizeof(T) selMask bits per
        # repeat, reading them from an *address* held in the cmpmask SPR. The simulator's
        # _select already models this per-repeat consumption. (The old SetCmpMask(selmask)
        # path loaded the selMask *contents* into the SPR and mode-2 misread those bits as an
        # address -> right only for repeat==1 on HW; that is why it passed sim but not HW.)
        # We stage the selMask address into the caller's `tmp_addr_buf` ourselves (all V-pipe,
        # like CANN's VselIntrinsicsImplPre) and call the no-selMask-tensor overload that reads
        # the SPR -- so the staging UB is accounted for by easyasc and never overlaps user
        # data. Duplicate fills the buffer with the address under the current (full) vector
        # mask; SetCmpMask loads it into the SPR; the no-mask Select then consumes per repeat.
        tmp_expr = value_to_cpp(tmp_addr_buf, expr_map)
        helper("{")
        # Duplicate's count overload writes exactly 8 uint32 (one 32B block) and manages the
        # vector mask internally, so the kernel's full mask -- which the no-mask Select below
        # relies on -- is left untouched. SetCmpMask reads at most a 128-bit (16B) SPR, so one
        # 32B block of the staged address is plenty (no need for a full 256B uint32 repeat).
        helper(
            f"    Duplicate({tmp_expr}, "
            f"(uint32_t)(uint64_t)({selmask_expr}.GetPhyAddr()), (int32_t)8);"
        )
        helper("    PipeBarrier<PIPE_V>();")
        helper(f"    SetCmpMask({tmp_expr});")
        helper("    PipeBarrier<PIPE_V>();")
        helper(
            f"    Select<{dst_dtype}, SELMODE::VSEL_{mode_name}_MODE>("
            f"{dst_expr}, {src1_expr}, {src2_expr}, (uint8_t)({repeat}), {stride_block});"
        )
        helper("}")
    else:
        raise ValueError(f"select mode must be TENSOR_SCALAR or TENSOR_TENSOR, got: {mode_name}")
