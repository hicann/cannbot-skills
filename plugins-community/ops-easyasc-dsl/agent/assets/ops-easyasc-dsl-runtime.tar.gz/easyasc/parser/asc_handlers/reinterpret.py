from .common import GMTensor, Position, Tensor, dtype_to_cpp, value_to_cpp


def handle_reinterpret(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    src = inst.kwargs.get("src", None)
    # GM-side reinterpret: relabel a GM buffer (e.g. a uint8 carrier as hif8 for a fixpipe
    # hif8 store). GlobalTensor::ReinterpretCast<U>() returns a GlobalTensor<U>.
    if isinstance(dst, GMTensor) or isinstance(src, GMTensor):
        if not (isinstance(dst, GMTensor) and isinstance(src, GMTensor)):
            raise TypeError("GM reinterpret requires GMTensor src and dst")
        dst_dtype = dtype_to_cpp(dst.dtype)
        src_expr = value_to_cpp(src, expr_map)
        helper(f"GlobalTensor<{dst_dtype}> {dst.name} = {src_expr}.ReinterpretCast<{dst_dtype}>();")
        return
    if not isinstance(dst, Tensor):
        raise TypeError(f"reinterpret requires Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"reinterpret requires Tensor type, current type: {type(src)}")
    if src.position is Position.L0C or dst.position is Position.L0C:
        raise ValueError("reinterpret does not support L0C position")
    if getattr(dst.dtype, "name", "") == "int4" and getattr(dst, "_int4_consumed_by", None) == "matmul":
        return
    dst_dtype = dtype_to_cpp(dst.dtype)
    src_expr = value_to_cpp(src, expr_map)
    helper(f"LocalTensor<{dst_dtype}> {dst.name} = {src_expr}.ReinterpretCast<{dst_dtype}>();")
