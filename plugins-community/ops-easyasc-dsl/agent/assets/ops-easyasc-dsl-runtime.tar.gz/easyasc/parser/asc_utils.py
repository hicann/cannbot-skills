import functools
import math
import re
from typing import Dict, Iterable, Mapping, Optional, Set, Tuple

from ..utils.instruction import Instruction
from ..utils.layout import Layout
from ..utils.positions import NZ_LOCAL_POSITIONS, POSITION_CPP_MAPPING, Position
from ..utils.Tensor import DBuff, GMTensor, GMTensorList, QBuff, TBuff, Tensor
from ..utils.var import Expr, Var, VarRef
from ..utils.datatype import Datatype, is_integer_dtype
from .. import globvars
from ..device_profile import is_c220_family

try:
    import sympy as sp
    from sympy.printing.str import StrPrinter
    from sympy.printing.precedence import precedence
except ImportError:
    sp = None
    StrPrinter = object  # type: ignore
    def precedence(expr):  # type: ignore
        return 0



_PRINTER = None
_CPP_PRINTER = None

class _MulPowPrinter(StrPrinter):
    def _print_Pow(self, expr):
        base, exp = expr.as_base_exp()
        if exp.is_Integer and exp > 0:
            base_str = self.parenthesize(base, precedence(expr))
            return "*".join([base_str] * int(exp))
        return super()._print_Pow(expr) # type: ignore

    def _print_Mod(self, expr):
        lhs = self._print(expr.args[0]) # type: ignore
        rhs = self._print(expr.args[1]) # type: ignore
        return f"({lhs}) % ({rhs})"

    def _print_Equality(self, expr):
        lhs = self._print(expr.lhs) # type: ignore
        rhs = self._print(expr.rhs) # type: ignore
        return f"({lhs}) == ({rhs})"

    def _print_Unequality(self, expr):
        lhs = self._print(expr.lhs) # type: ignore
        rhs = self._print(expr.rhs) # type: ignore
        return f"({lhs}) != ({rhs})"

    def _print_And(self, expr):
        parts = [self._print(arg) for arg in expr.args] # type: ignore
        parts = ["(" + p + ")" for p in parts]
        return " && ".join(parts)

    def _print_Or(self, expr):
        parts = [self._print(arg) for arg in expr.args] # type: ignore
        parts = ["(" + p + ")" for p in parts]
        return " || ".join(parts)


class _CppExprPrinter(_MulPowPrinter):
    def _print_Function(self, expr):
        name = expr.func.__name__
        if name == "IDiv" and len(expr.args) == 2:
            lhs = self._print(expr.args[0]) # type: ignore
            rhs = self._print(expr.args[1]) # type: ignore
            return f"(({lhs}) / ({rhs}))"
        if name == "IMod" and len(expr.args) == 2:
            lhs = self._print(expr.args[0]) # type: ignore
            rhs = self._print(expr.args[1]) # type: ignore
            return f"(({lhs}) % ({rhs}))"
        return super()._print_Function(expr) # type: ignore


_PRINTER = _MulPowPrinter() if sp is not None else None
_CPP_PRINTER = _CppExprPrinter() if sp is not None else None


def dtype_to_cpp(dtype) -> str:
    if dtype is None:
        return "auto"
    if dtype is Datatype.int4 or getattr(dtype, "name", "") == "int4":
        return "int4b_t"
    if dtype is Datatype.fp4_e2m1 or getattr(dtype, "name", "") == "fp4x2_e2m1_t":
        return "fp4x2_e2m1_t"
    if dtype is Datatype.fp4_e1m2 or getattr(dtype, "name", "") == "fp4x2_e1m2_t":
        return "fp4x2_e1m2_t"
    return str(dtype)


def position_to_cpp(position) -> str:
    key = str(position)
    if key not in POSITION_CPP_MAPPING:
        raise ValueError(f"not foundpositionmapping: {key}")
    return POSITION_CPP_MAPPING[key]


def _expr_to_sympy_text(expr: str) -> str:
    return expr.replace(".", "___").replace("&&", "&").replace("||", "|")



def _restore_expr_text(expr: str) -> str:
    return expr.replace("___", ".")



def _sympify_expr(expr: str):
    if sp is None:
        raise RuntimeError("sympy unavailable")
    expr_for_sympy = _expr_to_sympy_text(expr)
    names = set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", expr_for_sympy))
    func_names = set(re.findall(r"([A-Za-z_][A-Za-z0-9_]*)\s*\(", expr_for_sympy))
    locals_map = {}
    for name in names:
        if name == "true":
            locals_map[name] = sp.true
        elif name == "false":
            locals_map[name] = sp.false
        elif name in func_names:
            locals_map[name] = sp.Function(name)
        else:
            locals_map[name] = sp.Symbol(name)
    return sp.sympify(expr_for_sympy, locals=locals_map, evaluate=False)



# Memoized: `simplify_expr` is a pure (str -> str) function whose only globals
# (`sp`, `_PRINTER`) are bound once at import. expr_map expansion in
# `value_to_expr`/`build_expr_state` re-simplifies the SAME handful of subexpressions
# tens of thousands of times (e.g. the FD `for b in range(1, 32)` schedule expands to
# ~25k calls over only ~113 unique strings), and sympy.simplify dominates the split
# pass. Caching collapses that to one simplify per unique expr -> ~100x faster split.
@functools.lru_cache(maxsize=None)
def simplify_expr(expr: str) -> str:
    if sp is None or _PRINTER is None:
        return expr
    try:
        sym = _sympify_expr(expr)
        simplified = sp.simplify(sym, evaluate=False)
        result = _PRINTER.doprint(simplified)
    except Exception:
        return expr
    return _restore_expr_text(str(result))



def _split_call_args(arg_text: str) -> Tuple[str, str]:
    depth = 0
    split_idx = -1
    for idx, ch in enumerate(arg_text):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            split_idx = idx
            break
    if split_idx == -1:
        raise ValueError(f"opaque function expects two args, got: {arg_text!r}")
    return arg_text[:split_idx].strip(), arg_text[split_idx + 1 :].strip()



def _render_opaque_funcs(expr: str) -> str:
    out = []
    idx = 0
    while idx < len(expr):
        opname = None
        opchar = None
        if expr.startswith("IDiv(", idx):
            opname = "IDiv"
            opchar = "/"
        elif expr.startswith("IMod(", idx):
            opname = "IMod"
            opchar = "%"
        if opname is None or opchar is None:
            out.append(expr[idx])
            idx += 1
            continue
        start = idx + len(opname)
        depth = 0
        end = start
        while end < len(expr):
            ch = expr[end]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    break
            end += 1
        if end >= len(expr):
            out.append(expr[idx])
            idx += 1
            continue
        inner = expr[start + 1 : end]
        lhs_raw, rhs_raw = _split_call_args(inner)
        lhs = _render_opaque_funcs(lhs_raw)
        rhs = _render_opaque_funcs(rhs_raw)
        out.append(f"(({lhs}) {opchar} ({rhs}))")
        idx = end + 1
    return "".join(out)



def render_cpp_expr(expr: str) -> str:
    if "IDiv(" not in expr and "IMod(" not in expr:
        return expr
    if sp is None or _CPP_PRINTER is None:
        return _render_opaque_funcs(expr)
    try:
        sym = _sympify_expr(expr)
        result = _CPP_PRINTER.doprint(sym)
    except Exception:
        return _render_opaque_funcs(expr)
    return _restore_expr_text(str(result))



def _needs_parens(expr: str) -> bool:
    return any(token in expr for token in (" + ", " - ", " * ", " / ", " % "))


def _wrap_expr(expr: str) -> str:
    if _needs_parens(expr):
        return f"({expr})"
    return expr


def _is_zero_literal(expr: str) -> bool:
    text = expr.strip()
    if text.startswith("(") and text.endswith(")"):
        text = text[1:-1].strip()
    return text == "0"


def format_binop(op: str, left: str, right: str) -> str:
    return f"{_wrap_expr(left)} {op} {_wrap_expr(right)}"


def _preserve_slice_offset_expr(expr: str) -> str:
    """
    Keep rendered slice offsets verbatim.

    Slice builders already consume `value_to_cpp()`, which renders opaque integer
    helpers like `IDiv` into C operators. A second symbolic simplify pass here can
    collapse integer floor-division structure such as `64*((a) / (64)) / 2` into
    `a/2`, which changes indexing semantics.
    """
    return expr


def is_tmp_var(value: object) -> bool:
    return isinstance(value, Var) and value.name.startswith("_tmp_var_")


def is_tmp_tensor(value: object) -> bool:
    return isinstance(value, Tensor) and value.name.startswith("_tmp_tensor_")


def is_tmp_gmtensor(value: object) -> bool:
    return isinstance(value, GMTensor) and value.name.startswith("_tmp_gmtensor_")


def float_to_cpp_literal(value: float) -> str:
    """Render a Python float as a single-precision C++ float literal (e.g. ``5.0f``).

    DSL ``Datatype.float`` lowers to C++ ``float``, so a bare ``5.0`` is a *double*
    literal: ``v * 5.0`` promotes the whole expression to double then narrows back
    on assignment (also triggering ``-Wdouble-promotion``). Suffixing ``f`` keeps
    scalar math in single precision. ``repr`` always emits a ``.``/exponent for a
    finite float, so the suffix is well-formed.

    Non-finite values (``inf`` / ``-inf`` / ``nan``) have no plain literal spelling:
    ``repr`` yields the bare words ``inf`` / ``nan``, which are not valid C++ and
    would compile to an undeclared identifier. Emit the Clang/Bisheng compiler
    builtins instead — header-independent ``float``-typed constant expressions
    accepted in both device (AscendC) and host code, matching the ``f``-suffixed
    finite path.
    """
    if math.isnan(value):
        return '__builtin_nanf("")'
    if math.isinf(value):
        return "-__builtin_inff()" if value < 0 else "__builtin_inff()"
    return f"{repr(value)}f"


def value_to_expr(value, expr_map: Dict[str, str]) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float):
        return float_to_cpp_literal(value)
    if isinstance(value, Expr):
        expr = str(value)
        if expr_map:
            for name, mapped in expr_map.items():
                if name not in expr:
                    continue
                mapped_expr = simplify_expr(mapped)
                mapped_expr = _wrap_expr(mapped_expr)
                expr = re.sub(rf"\b{re.escape(name)}\b", mapped_expr, expr)
        return expr
    if isinstance(value, VarRef):
        parent_name = getattr(getattr(value, "parent", None), "name", None)
        index = getattr(value, "index", None)
        if isinstance(parent_name, str) and parent_name != "" and index is not None:
            return f"{parent_name}[{value_to_expr(index, expr_map)}]"
    if isinstance(value, Var):
        mapped = expr_map.get(value.name)
        if mapped is not None:
            simplified = simplify_expr(mapped)
            if simplified != mapped:
                expr_map[value.name] = simplified
            return simplified
        return value.name
    if isinstance(value, Tensor):
        mapped = expr_map.get(value.name)
        if mapped is not None:
            return mapped
        return value.name
    if isinstance(value, GMTensor):
        mapped = expr_map.get(value.name)
        if mapped is not None:
            return mapped
        return value.name
    if isinstance(value, GMTensorList):
        return value.name
    if isinstance(value, (DBuff, TBuff, QBuff)):
        return value.name
    return str(value)



def value_to_cpp(value, expr_map: Dict[str, str]) -> str:
    return render_cpp_expr(value_to_expr(value, expr_map))


def build_offset_expr(shape, offset, expr_map: Dict[str, str]) -> str:
    if shape is None or offset is None:
        raise ValueError("slice_gm_tensor requires outcontainsshape and offset")
    if len(shape) != len(offset):
        raise ValueError("slice_gm_tensorshape and offsetdimensionsnotmatch")
    if not shape:
        return "0"
    # Linearized offset: sum(off[i] * prod(shape[i+1:])) + off[last]
    terms = []
    dim = len(shape)
    for idx in range(dim - 1):
        off_raw = value_to_cpp(offset[idx], expr_map)
        if _is_zero_literal(off_raw):
            continue
        off = _wrap_expr(off_raw)
        if dim - idx - 1 == 1:
            stride_expr = _wrap_expr(value_to_cpp(shape[idx + 1], expr_map))
        else:
            strides = [_wrap_expr(value_to_cpp(shape[j], expr_map)) for j in range(idx + 1, dim)]
            stride_expr = " * ".join(strides)
        terms.append(f"{off} * {stride_expr}")
    tail = value_to_cpp(offset[-1], expr_map)
    if not _is_zero_literal(tail):
        terms.append(_wrap_expr(tail))
    if not terms:
        return "0"
    return " + ".join(terms)


def _is_fp4_dtype(dtype) -> bool:
    return getattr(dtype, "name", "") in ("fp4x2_e2m1_t", "fp4x2_e1m2_t")


def _div2_expr(expr: str) -> str:
    expr = _wrap_expr(expr)
    return f"({expr}) / (2)"


def build_offset_expr_nz(shape, offset, dtype, expr_map: Dict[str, str], position=None, tensor=None) -> str:
    if shape is None or offset is None:
        raise ValueError("slice_tensor requires outcontainsshape and offset")
    if len(shape) != 2 or len(offset) != 2:
        raise ValueError("slice_tensorshape and offset must be 2D")
    if dtype is None:
        raise ValueError("slice_tensor requires outcontainsdtype")
    if position is Position.L0C:
        c0 = 16
    elif _is_fp4_dtype(dtype):
        c0 = 32
    else:
        c0 = dtype.C0
    off0 = _wrap_expr(value_to_cpp(offset[0], expr_map))
    off1 = _wrap_expr(value_to_cpp(offset[1], expr_map))
    shape0 = _wrap_expr(value_to_cpp(shape[0], expr_map))
    if _is_fp4_dtype(dtype):
        # The expression in parentheses is the slice's CARRIER-BYTE offset in the NZ
        # layout. But a LocalTensor<fp4x2_*_t> indexes in 4-bit FP4 ELEMENTS (two per
        # carrier byte), so `lb[idx]` addresses carrier byte idx/2. The offset must
        # therefore be returned in FP4-element units, i.e. 2x the carrier-byte offset;
        # otherwise every sliced FP4 sub-tile lands at half its intended row/K (e.g.
        # matmul_mx splitn N-tile _subn read B rows _subn/2 instead of _subn). A zero
        # offset (nosplit / full tile) is unaffected, which is why only splits broke.
        # Verified on Ascend950 CANNSIM: with the 2x, splitn tile1 == A @ B[16:32]^T.
        pack_axis = getattr(tensor, "_packed_view_axis", 1)
        if pack_axis == 0:
            expr = f"({_div2_expr(off0)} * {c0} + {off1} * {_div2_expr(shape0)}) * 2"
        else:
            expr = f"({off0} * {c0} + {_div2_expr(off1)} * {shape0}) * 2"
        return expr
    expr = f"{off0} * {c0} + {off1} * {shape0}"
    return expr


def build_offset_expr_zz(shape, offset, dtype, expr_map: Dict[str, str]) -> str:
    if shape is None or offset is None:
        raise ValueError("slice_tensor requires outcontainsshape and offset")
    if len(shape) != 2 or len(offset) != 2:
        raise ValueError("slice_tensorshape and offset must be 2D")
    if dtype is None:
        raise ValueError("slice_tensor requires outcontainsdtype")
    if dtype is not Datatype.float:
        raise ValueError(f"ZZ slice offset only supports float dtype, current dtype: {dtype}")
    off0 = _wrap_expr(value_to_cpp(offset[0], expr_map))
    off1 = _wrap_expr(value_to_cpp(offset[1], expr_map))
    shape1 = _wrap_expr(value_to_cpp(shape[1], expr_map))
    expr = f"{off0} * {shape1} + {off1} * 16"
    return expr


def is_nz_local_position(position) -> bool:
    return position in NZ_LOCAL_POSITIONS


_ASSIGNMENT_OPS = {
    "GetValueFrom",
    "GetCubeNum",
    "GetCubeIdx",
    "GetVecNum",
    "GetVecIdx",
    "GetSubBlockIdx",
    "scalar_sqrt",
    "scalar_abs",
    "Align8",
    "Align16",
    "Align32",
    "Align64",
    "Align128",
    "Align256",
    "CeilDiv",
    "Min",
    "Max",
    "var_mul",
    "var_div",
    "var_add",
    "var_sub",
    "var_mod",
    "var_assign",
    "tensorlist_size",
    "tensorlist_item_numel",
}


def is_assignment_op(opname: str) -> bool:
    return opname in _ASSIGNMENT_OPS


def uses_var_in_operands(inst: Instruction, name: str) -> bool:
    if inst.opname in ("GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx"):
        return False
    if inst.opname == "var_assign":
        val = inst.kwargs.get("src", None)
        return isinstance(val, Var) and val.name == name
    if inst.opname in (
        "CeilDiv",
        "Min",
        "Max",
        "var_mul",
        "var_div",
        "var_add",
        "var_sub",
        "var_mod",
        "scalar_sqrt",
        "scalar_abs",
        "Align8",
        "Align16",
        "Align32",
        "Align64",
        "Align128",
        "Align256",
    ):
        for key in ("a", "b"):
            val = inst.kwargs.get(key, None)
            if isinstance(val, Var) and val.name == name:
                return True
    return False


def assignment_expr(inst: Instruction, expr_map: Dict[str, str], kernel_mode: str = "mix") -> str:
    def _rhs_with_float_cast_for_float_left(rhs_expr: str) -> str:
        # Float-result op (LHS is a float Var): make an integer-Var RHS's widening
        # to float explicit. A float-literal RHS already carries an `f` suffix, a
        # float-Var RHS is already float, and an int *literal* promotes cleanly on
        # its own (`vf + 2`), so only an int Var needs the documenting cast.
        left = inst.kwargs.get("a", None)
        right = inst.kwargs.get("b", None)
        left_is_float = isinstance(left, Var) and left.dtype is Datatype.float
        right_is_int_var = isinstance(right, Var) and right.dtype is Datatype.int
        if left_is_float and right_is_int_var:
            return f"(float) {rhs_expr}"
        return rhs_expr

    def _rhs_with_float_cast_for_float_division(rhs_expr: str) -> str:
        out = inst.kwargs.get("out", None)
        right = inst.kwargs.get("b", None)
        float_result = isinstance(out, Var) and out.dtype is Datatype.float
        right_is_int_var = isinstance(right, Var) and is_integer_dtype(right.dtype)
        if float_result and right_is_int_var:
            return f"(float) {rhs_expr}"
        return rhs_expr

    opname = inst.opname
    if opname == "GetValueFrom":
        out = inst.kwargs.get("out", None)
        if out is None:
            out = inst.kwargs.get("dst", None)
        if not isinstance(out, Var):
            raise TypeError(f"GetValueFrom requires Var dst/out type, got: {type(out)}")
        src = value_to_expr(inst.kwargs.get("src", None), expr_map)
        return f"({dtype_to_cpp(out.dtype)}) {src}.GetValue(0)"
    if opname == "GetCubeNum":
        return "GetBlockNum()"
    if opname == "GetCubeIdx":
        return "get_block_idx()"
    if opname == "GetVecNum":
        return "GetBlockNum()" if kernel_mode == "vec" else "GetBlockNum() * 2"
    if opname == "GetVecIdx":
        # Do NOT "fix" this into GetBlockIdx() * 2 + get_subblockid(). Bare
        # GetBlockIdx() already spans [0, GetVecNum()) on the vector side --
        # impl/basic_api/dav_c310/kernel_operator_sys_var_impl.h defines
        # GetBlockIdxImpl as get_block_idx() * get_subblockdim() +
        # get_subblockid() under ASCEND_IS_AIV. Expanding it a second time here
        # evaluates to 4c + 3s, so half the vector workers index past the end of
        # the grid and their share of the output is never written. The failure is
        # hardware-only: the simulator hands GetVecIdx the correct 2c + s
        # directly and never sees the doubled expression.
        # GetCubeIdx() is the primitive that maps to raw get_block_idx().
        return "GetBlockIdx()"
    if opname == "GetSubBlockIdx":
        return "get_subblockid()"
    if opname == "var_assign":
        src = value_to_expr(inst.kwargs.get("src", None), expr_map)
        return src
    if opname == "tensorlist_size":
        tensor_list = inst.kwargs.get("tensor_list", None)
        if not isinstance(tensor_list, GMTensorList):
            raise TypeError(f"tensorlist_size requires GMTensorList type, got: {type(tensor_list)}")
        return f"static_cast<int32_t>({tensor_list.name}_desc.GetSize())"
    if opname == "scalar_sqrt":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"sqrt({a})"
    if opname == "scalar_abs":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"abs({a})"
    if opname == "Align8":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align8B({a})"
    if opname == "Align16":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align16B({a})"
    if opname == "Align32":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align32B({a})"
    if opname == "Align64":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align64B({a})"
    if opname == "Align128":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align128B({a})"
    if opname == "Align256":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align256B({a})"
    if opname == "CeilDiv":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        return f"CeilDiv({a}, {b})"
    if opname == "Min":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        return f"Min({a}, {b})"
    if opname == "Max":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        return f"Max({a}, {b})"
    if opname == "var_mul":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        b = _rhs_with_float_cast_for_float_left(b)
        return simplify_expr(format_binop("*", a, b))
    if opname == "var_div":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        if isinstance(inst.kwargs.get("out", None), Var) and inst.kwargs.get("out", None).dtype is Datatype.int:
            return f"IDiv({a}, {b})"
        b = _rhs_with_float_cast_for_float_division(b)
        return simplify_expr(format_binop("/", a, b))
    if opname == "var_add":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        b = _rhs_with_float_cast_for_float_left(b)
        return simplify_expr(format_binop("+", a, b))
    if opname == "var_sub":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        b = _rhs_with_float_cast_for_float_left(b)
        return simplify_expr(format_binop("-", a, b))
    if opname == "var_mod":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        return f"IMod({a}, {b})"
    raise ValueError(f"unsupported assignment op: {opname}")


def build_expr_state(
    instructions: Iterable[Instruction],
    kernel_mode: str = "mix",
    buffer_view_plan: Optional[Mapping[str, object]] = None,
) -> Tuple[Dict[str, str], Set[str], Set[str], Set[str]]:
    expr_map: Dict[str, str] = {}
    tmp_var_names: Set[str] = set()
    for inst in instructions:
        opname = inst.opname
        if opname == "GetCubeNum":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "GetBlockNum()"
                tmp_var_names.add(out.name)
            continue
        if opname == "GetCubeIdx":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "get_block_idx()"
                tmp_var_names.add(out.name)
            continue
        if opname == "GetVecNum":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "GetBlockNum()" if kernel_mode == "vec" else "GetBlockNum() * 2"
                tmp_var_names.add(out.name)
            continue
        if opname == "GetVecIdx":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                # Sub-block included; see the GetVecIdx note in assignment_expr
                # before making this depend on kernel_mode.
                expr_map[out.name] = "GetBlockIdx()"
                tmp_var_names.add(out.name)
            continue
        if opname == "GetSubBlockIdx":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "get_subblockid()"
                tmp_var_names.add(out.name)
            continue
        if opname in ("GetValueFrom", "CeilDiv", "Min", "Max", "var_mul", "var_div", "var_add", "var_sub", "var_mod", "var_assign", "tensorlist_size"):
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Var) or not is_tmp_var(out):
                continue
            expr_map[out.name] = assignment_expr(inst, expr_map, kernel_mode=kernel_mode)
            tmp_var_names.add(out.name)
        if opname in ("scalar_sqrt", "scalar_abs", "Align8", "Align16", "Align32", "Align64", "Align128", "Align256"):
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Var) or not is_tmp_var(out):
                continue
            expr_map[out.name] = assignment_expr(inst, expr_map, kernel_mode=kernel_mode)
            tmp_var_names.add(out.name)

    tmp_tensor_names: Set[str] = set()
    for inst in instructions:
        if inst.opname == "get_buf":
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Tensor) or not is_tmp_tensor(out):
                continue
            buf = inst.kwargs.get("buf", None)
            if not isinstance(buf, (DBuff, TBuff, QBuff)):
                continue
            index_value = inst.kwargs.get("index", None)
            if isinstance(index_value, Var):
                # A runtime-indexed buffer access creates a value-like Tensor view.
                # Materialize by default. Final per-side translation may provide a
                # conservative liveness plan proving that this single use observes
                # the same reaching index version, making expression inlining
                # snapshot-equivalent.
                decision = None if buffer_view_plan is None else buffer_view_plan.get(out.name)
                if decision is None or getattr(decision, "mode", None) != "inline":
                    continue
            index = value_to_cpp(index_value, expr_map)
            expr_map[out.name] = f"{buf.name}.get({index})"
            tmp_tensor_names.add(out.name)
            continue
        if inst.opname == "slice_tensor":
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Tensor) or not is_tmp_tensor(out):
                continue
            src = inst.kwargs.get("src", None)
            shape = getattr(out, "shape", None)
            offset = inst.kwargs.get("offset", None)
            use_zz_l1_float = (
                out.position is Position.L1
                and is_c220_family(getattr(globvars, "device_type", ""))
                and out.dtype is Datatype.float
            )
            if use_zz_l1_float:
                offset_expr = _preserve_slice_offset_expr(build_offset_expr_zz(shape, offset, out.dtype, expr_map))
            elif is_nz_local_position(out.position) or getattr(out, "_layout", None) is Layout.NZ:
                # NZ-layout tensor (incl. a UB tensor marked .nz(), e.g. ub_p.nz()[:, c0:] holding an
                # NZ-laid-out P pack): the column slice must use the NZ fractal offset (off1*shape0),
                # not the row-major one -- mirrors the L1 dst, resolved NZ via its position.
                offset_expr = _preserve_slice_offset_expr(
                    build_offset_expr_nz(shape, offset, out.dtype, expr_map, position=out.position, tensor=out)
                )
            else:
                offset_expr = _preserve_slice_offset_expr(build_offset_expr(shape, offset, expr_map))
            src_expr = value_to_cpp(src, expr_map)
            if offset_expr == "0":
                expr_map[out.name] = f"{src_expr}"
            else:
                expr_map[out.name] = f"{src_expr}[{offset_expr}]"
            tmp_tensor_names.add(out.name)
            continue
        if inst.opname == "micro_slice_tensor":
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Tensor) or not is_tmp_tensor(out):
                continue
            src = inst.kwargs.get("src", None)
            shape = getattr(out, "shape", None)
            offset = inst.kwargs.get("offset", None)
            offset_expr = _preserve_slice_offset_expr(build_offset_expr(shape, offset, expr_map))
            src_expr = value_to_cpp(src, expr_map)
            if offset_expr == "0":
                expr_map[out.name] = f"{src_expr}"
            else:
                expr_map[out.name] = f"{src_expr} + {offset_expr}"
            tmp_tensor_names.add(out.name)
            continue

    tmp_gmtensor_names: Set[str] = set()
    for inst in instructions:
        if inst.opname not in ("slice_gm_tensor", "reshape_gm_tensor"):
            continue
        out = inst.kwargs.get("out", None)
        if not isinstance(out, GMTensor) or not is_tmp_gmtensor(out):
            continue
        src = inst.kwargs.get("src", None)
        src_expr = value_to_cpp(src, expr_map)
        if inst.opname == "reshape_gm_tensor":
            expr_map[out.name] = f"{src_expr}"
            tmp_gmtensor_names.add(out.name)
            continue
        shape = getattr(out, "shape", None)
        offset = getattr(out, "offset", None)
        offset_expr = _preserve_slice_offset_expr(build_offset_expr(shape, offset, expr_map))
        if offset_expr == "0":
            expr_map[out.name] = f"{src_expr}"
        else:
            expr_map[out.name] = f"{src_expr}[{offset_expr}]"
        tmp_gmtensor_names.add(out.name)

    return expr_map, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names


def should_skip_inst(
    inst: Instruction,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> bool:
    if inst.opname == "create_var":
        val = inst.kwargs.get("val", None)
        return isinstance(val, Var) and is_tmp_var(val) and val.name in tmp_var_names
    if inst.opname in (
        "GetValueFrom",
        "GetCubeNum",
        "GetCubeIdx",
        "GetVecNum",
        "GetVecIdx",
        "GetSubBlockIdx",
        "scalar_sqrt",
        "scalar_abs",
        "Align8",
        "Align16",
        "Align32",
        "Align64",
        "Align128",
        "Align256",
        "CeilDiv",
        "Min",
        "Max",
        "var_mul",
        "var_div",
        "var_add",
        "var_sub",
        "var_mod",
        "var_assign",
        "tensorlist_size",
    ):
        out = inst.kwargs.get("out", None)
        return isinstance(out, Var) and out.name in tmp_var_names
    if inst.opname in ("get_buf", "slice_tensor", "micro_slice_tensor", "create_tensor"):
        out = inst.kwargs.get("out", None)
        return isinstance(out, Tensor) and is_tmp_tensor(out) and out.name in tmp_tensor_names
    if inst.opname in ("slice_gm_tensor", "reshape_gm_tensor"):
        out = inst.kwargs.get("out", None)
        return isinstance(out, GMTensor) and is_tmp_gmtensor(out) and out.name in tmp_gmtensor_names
    return False
