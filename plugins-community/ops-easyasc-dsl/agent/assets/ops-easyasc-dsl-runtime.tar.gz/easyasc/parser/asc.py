from __future__ import annotations

import os
import re
import warnings
from functools import lru_cache
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .asc_handlers import build_handlers
from .asc_utils import (
    assignment_expr,
    build_expr_state,
    dtype_to_cpp,
    is_assignment_op,
    is_tmp_var,
    render_cpp_expr,
    should_skip_inst,
    uses_var_in_operands,
    value_to_cpp,
)
from .asc_pruning import (
    _collect_known_var_names,
    _collect_var_deps,
    _extract_live_names_from_value,
    _parse_block,
    prune_empty_blocks,
    prune_unused_decls,
    prune_unused_vars,
)
from .asc_autosync import insert_auto_sync
from .asc_buffer_view_liveness import plan_runtime_buffer_views
from .helper import CodeHelper
from ..utils.instruction import Instruction
from .. import globvars
from ..utils.capacity import (
    SIMT_UB_CAP_NOTE,
    SIMT_UB_RESERVED_NOTE,
    effective_ub_cap_kb,
    instructions_use_simt,
)
from ..device_profile import is_a5_family, is_c220_family
from ..utils.var import Expr, Var, VarRef
from ..utils.Tensor import Tensor, DBuff, GMTensor, GMTensorList, QBuff, TBuff
from ..utils.positions import Position
from rich import box
from rich.align import Align
from rich.console import Console
from rich.table import Table
from rich.text import Text

_EVENT_OPS = {
    "create_sevent",
    "create_devent",
    "create_tevent",
    "create_qevent",
    "event_set",
    "event_wait",
    "event_setall",
    "event_release",
}
_EVENT_CREATE_OPS = {"create_sevent", "create_devent", "create_tevent", "create_qevent"}
_EVENT_SWAP_OPS = {"event_set", "event_wait"}
_CUBE_PIPE_OPS = {"allcube_ready", "allcube_wait", "cube_ready", "wait_vec"}
_VEC_PIPE_OPS = {
    "allvec_ready", "allvec_wait",
    "intracore_allvec_ready", "intracore_allvec_wait",
    "vec_ready", "wait_cube",
}
_STRICT_VEC_ONLY_SCALAR_OPS = {"GetVecNum", "GetVecIdx", "GetSubBlockIdx", "GetSubBlockNum"}
_VEC_ONLY_SCALAR_OPS = set(_STRICT_VEC_ONLY_SCALAR_OPS)
_PIPE_CUBE_NAMES = {"M", "FIX", "MTE1"}
_PIPE_VEC_NAMES = {"V", "MTE3"}
_INSTRUCTION_RE = re.compile(r"Instruction\(\s*['\"]([A-Za-z0-9_]+)['\"]")
_BLOCK_FORBIDDEN_OPS = {
    "create_gm_tensor",
    "create_gm_tensor_list",
    "create_tensor",
    "create_dbuf",
    "create_tbuf",
    "create_qbuf",
    "create_devent",
    "create_sevent",
    "create_tevent",
    "create_qevent",
}
_IF_STARTS = ("start_if", "start_elif", "start_else")
_LOOP_STARTS = ("start_loop", "start_micro_loop")
_SCOPE_ENTER_OPS = {"enter_vec_scope": "vec", "enter_cube_scope": "cube"}
_SCOPE_END_OPS = {"end_vec_scope": "vec", "end_cube_scope": "cube"}
_HELPER_VIEW_OUT_KEYS = {
    "get_buf": "out",
    "slice_tensor": "out",
    "micro_slice_tensor": "out",
    "slice_gm_tensor": "out",
    "reshape_gm_tensor": "out",
    "get_gm_tensor_list_item": "out",
    "reinterpret": "dst",
}
_TMP_VAR_NAME_RE = re.compile(r"\b_tmp_var_\d+\b")
_DANGLING_VAR_MESSAGE = (
    "Do not create Var out of kernel scope; use a Python int constant or create Var inside @kernel/@vf."
)


def _collect_opnames_from_file(path: str) -> Set[str]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except (OSError, UnicodeDecodeError):
        return set()
    return set(_INSTRUCTION_RE.findall(text))


def _collect_opnames_from_dir(path: str) -> Set[str]:
    names: Set[str] = set()
    for root, _, files in os.walk(path):
        for filename in files:
            if filename.endswith(".py"):
                names |= _collect_opnames_from_file(os.path.join(root, filename))
    return names


@lru_cache(maxsize=1)
def _get_stub_opnames() -> Tuple[Set[str], Set[str]]:
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    cube_path = os.path.join(base_dir, "stub_functions", "cube.py")
    vec_dir = os.path.join(base_dir, "stub_functions", "vec")
    cube_ops = _collect_opnames_from_file(cube_path)
    vec_ops = _collect_opnames_from_dir(vec_dir)
    handler_map = build_handlers()
    for opname, handler in handler_map.items():
        module = getattr(handler, "__module__", "")
        if ".vec_" in module:
            vec_ops.add(opname)
        elif module.endswith(".cube"):
            cube_ops.add(opname)
    return cube_ops, vec_ops


def _event_sides(event: object) -> Tuple[bool, bool]:
    if event is None:
        return False, False
    pipes = []
    src = getattr(event, "src_pipe", None)
    dst = getattr(event, "dst_pipe", None)
    if src is not None:
        pipes.append(src)
    if dst is not None:
        pipes.append(dst)
    cube_side = any(str(pipe) in _PIPE_CUBE_NAMES for pipe in pipes)
    vec_side = any(str(pipe) in _PIPE_VEC_NAMES for pipe in pipes)
    return cube_side, vec_side


def _value_sides(value: object) -> Tuple[bool, bool]:
    if isinstance(value, (GMTensor, GMTensorList)):
        return True, True
    if isinstance(value, Tensor):
        if value.position is Position.UB:
            return False, True
        if value.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
            return True, False
        return True, True
    if isinstance(value, dict):
        cube_side = False
        vec_side = False
        for item in value.values():
            cube_item, vec_item = _value_sides(item)
            cube_side = cube_side or cube_item
            vec_side = vec_side or vec_item
        return cube_side, vec_side
    if isinstance(value, (list, tuple, set)):
        cube_side = False
        vec_side = False
        for item in value:
            cube_item, vec_item = _value_sides(item)
            cube_side = cube_side or cube_item
            vec_side = vec_side or vec_item
        return cube_side, vec_side
    return False, False


def _warn_unscoped_set_value_to(idx: int) -> None:
    warnings.warn(
        f"SetValueTo at instruction {idx} is not limited by vec_scope()/cube_scope(); "
        "a GMTensor target will be emitted to both cube and vec sides.",
        UserWarning,
        stacklevel=2,
    )


def _validate_set_value_to_side(
    inst: Instruction,
    target_side: str,
    idx: int,
    scope_info: Optional[Tuple[int, str]] = None,
) -> None:
    if inst.opname != "SetValueTo" or target_side != "cube":
        return
    src = inst.kwargs.get("src", None)
    if isinstance(src, GMTensor):
        return
    if isinstance(src, Tensor):
        scope_suffix = ""
        if scope_info is not None:
            start_idx, start_opname = scope_info
            scope_suffix = f" inside {start_opname} started at instruction {start_idx}"
        raise ValueError(
            f"Instruction 'SetValueTo' at instruction {idx} targets cube side{scope_suffix}, "
            "but cube-side SetValueTo only supports GMTensor src"
        )
    raise TypeError(f"SetValueTo requires Tensor/GMTensor src type, current type: {type(src)}")


def _infer_control_vars_from_ops(instructions: List[Instruction], source_ops: Set[str]) -> Set[str]:
    known_var_names = _collect_known_var_names(instructions)
    if not known_var_names:
        return set()
    control_vars: Set[str] = set()
    for inst in instructions:
        if inst.opname not in source_ops:
            continue
        out = inst.kwargs.get("out", None)
        if isinstance(out, Var) and out.name in known_var_names:
            control_vars.add(out.name)
    if not control_vars:
        return control_vars
    deps = _collect_var_deps(instructions, known_var_names, set())
    changed = True
    while changed:
        changed = False
        for out_name, inputs in deps.items():
            if out_name in control_vars:
                continue
            if inputs & control_vars:
                control_vars.add(out_name)
                changed = True
    return control_vars


def _infer_vec_control_vars(instructions: List[Instruction]) -> Set[str]:
    return _infer_control_vars_from_ops(instructions, _VEC_ONLY_SCALAR_OPS)


def _infer_strict_vec_vars(instructions: List[Instruction]) -> Set[str]:
    strict_vec_var_names, _ = _infer_strict_vec_provenance(instructions)
    return strict_vec_var_names


def _control_inst_is_vec_only(
    inst: Instruction,
    vec_control_vars: Set[str],
    known_var_names: Set[str],
) -> bool:
    if not vec_control_vars:
        return False
    inputs: Set[str] = set()
    if inst.opname in _LOOP_STARTS:
        var = inst.kwargs.get("var", None)
        if isinstance(var, Var) and var.name in known_var_names:
            inputs.add(var.name)
        _extract_live_names_from_value(inst.kwargs.get("start", None), known_var_names, set(), inputs, set())
        _extract_live_names_from_value(inst.kwargs.get("stop", None), known_var_names, set(), inputs, set())
        _extract_live_names_from_value(inst.kwargs.get("step", None), known_var_names, set(), inputs, set())
    elif inst.opname in ("start_if", "start_elif"):
        _extract_live_names_from_value(inst.kwargs.get("cond", None), known_var_names, set(), inputs, set())
    return bool(inputs & vec_control_vars)


def _build_control_scope_map_from_vars(instructions: List[Instruction], control_vars: Set[str]) -> Dict[int, str]:
    known_var_names = _collect_known_var_names(instructions)
    scope_map: Dict[int, str] = {}
    if not control_vars:
        return scope_map
    if_stack: List[Dict[str, object]] = []
    for inst in instructions:
        opname = inst.opname
        if opname in _LOOP_STARTS:
            scope_map[id(inst)] = "vec" if _control_inst_is_vec_only(inst, control_vars, known_var_names) else "both"
            continue
        if opname == "start_if":
            side = "vec" if _control_inst_is_vec_only(inst, control_vars, known_var_names) else "both"
            frame: Dict[str, object] = {"side": side, "starts": [id(inst)]}
            if_stack.append(frame)
            scope_map[id(inst)] = side
            continue
        if opname == "start_elif":
            if not if_stack:
                continue
            frame = if_stack[-1]
            starts = frame.setdefault("starts", [])
            if isinstance(starts, list):
                starts.append(id(inst))
            if _control_inst_is_vec_only(inst, control_vars, known_var_names):
                frame["side"] = "vec"
            side = str(frame.get("side", "both"))
            for start_id in starts if isinstance(starts, list) else []:
                scope_map[start_id] = side
            continue
        if opname == "start_else":
            if not if_stack:
                continue
            frame = if_stack[-1]
            starts = frame.setdefault("starts", [])
            if isinstance(starts, list):
                starts.append(id(inst))
            side = str(frame.get("side", "both"))
            for start_id in starts if isinstance(starts, list) else []:
                scope_map[start_id] = side
            continue
        if opname == "end_if" and if_stack:
            if_stack.pop()
    return scope_map


def _build_vec_control_scope_map(instructions: List[Instruction]) -> Dict[int, str]:
    return _build_control_scope_map_from_vars(instructions, _infer_vec_control_vars(instructions))


def _describe_split_var_reference(inst: Instruction) -> str:
    if inst.opname in ("start_if", "start_elif"):
        cond = inst.kwargs.get("cond", None)
        return f"condition {cond!s}"
    if inst.opname in _LOOP_STARTS:
        start = inst.kwargs.get("start", None)
        stop = inst.kwargs.get("stop", None)
        step = inst.kwargs.get("step", None)
        return f"loop bounds start={start!s}, stop={stop!s}, step={step!s}"
    return f"operands of {inst.opname!r}"


def _collect_control_inst_inputs(inst: Instruction, known_var_names: Set[str]) -> Set[str]:
    inputs: Set[str] = set()
    if inst.opname in _LOOP_STARTS:
        var = inst.kwargs.get("var", None)
        if isinstance(var, Var) and var.name in known_var_names:
            inputs.add(var.name)
        _extract_live_names_from_value(inst.kwargs.get("start", None), known_var_names, set(), inputs, set())
        _extract_live_names_from_value(inst.kwargs.get("stop", None), known_var_names, set(), inputs, set())
        _extract_live_names_from_value(inst.kwargs.get("step", None), known_var_names, set(), inputs, set())
        return inputs
    if inst.opname in ("start_if", "start_elif"):
        _extract_live_names_from_value(inst.kwargs.get("cond", None), known_var_names, set(), inputs, set())
    return inputs


def _collect_written_local_var_names(inst: Instruction, known_var_names: Set[str]) -> Set[str]:
    written: Set[str] = set()
    if inst.opname == "GetValueFrom":
        dst = inst.kwargs.get("dst", None)
        if isinstance(dst, Var) and dst.name in known_var_names:
            written.add(dst.name)
        return written
    if not is_assignment_op(inst.opname):
        return written
    out = inst.kwargs.get("out", None)
    if isinstance(out, Var) and out.name in known_var_names:
        written.add(out.name)
    return written


def _validate_side_local_var_references(
    instructions: List[Instruction],
    side: str,
    original_instructions: List[Instruction],
    original_local_var_names: Set[str],
    original_tmp_var_names: Set[str],
) -> None:
    tracked_local_vars = {
        name for name in original_local_var_names if name not in original_tmp_var_names
    }
    if not tracked_local_vars:
        return
    retained_local_vars = _collect_known_var_names(instructions)
    original_inst_index_by_id = {id(inst): idx for idx, inst in enumerate(original_instructions)}
    original_write_indices: Dict[str, List[int]] = {}
    retained_write_indices: Dict[str, List[int]] = {}
    for inst in original_instructions:
        original_idx = original_inst_index_by_id[id(inst)]
        for name in _collect_written_local_var_names(inst, tracked_local_vars):
            original_write_indices.setdefault(name, []).append(original_idx)
    for inst in instructions:
        original_idx = original_inst_index_by_id.get(id(inst), -1)
        if original_idx < 0:
            continue
        for name in _collect_written_local_var_names(inst, tracked_local_vars):
            retained_write_indices.setdefault(name, []).append(original_idx)
    for idx, inst in enumerate(instructions):
        referenced_vars: Set[str] = set()
        for value in inst.kwargs.values():
            _extract_live_names_from_value(
                value,
                tracked_local_vars,
                set(),
                referenced_vars,
                set(),
            )
        missing_vars = sorted(name for name in referenced_vars if name not in retained_local_vars)
        if not missing_vars:
            control_inputs = _collect_control_inst_inputs(inst, tracked_local_vars)
            if not control_inputs:
                continue
            original_idx = original_inst_index_by_id.get(id(inst), -1)
            if original_idx < 0:
                continue
            stale_inputs: List[str] = []
            for name in sorted(control_inputs):
                original_prior_writes = original_write_indices.get(name, [])
                retained_prior_writes = retained_write_indices.get(name, [])
                if not any(write_idx < original_idx for write_idx in original_prior_writes):
                    continue
                if any(write_idx < original_idx for write_idx in retained_prior_writes):
                    continue
                stale_inputs.append(name)
            if not stale_inputs:
                continue
            missing_text = ", ".join(repr(name) for name in stale_inputs)
            detail = _describe_split_var_reference(inst)
            raise ValueError(
                f"Side-split inconsistency on {side} side at instruction {idx} ({inst.opname}): "
                f"{detail} depends on local Var(s) {missing_text}, but no retained writer reaches this control point "
                f"on the {side} side. This usually means a cross-side scalar dependency leaked into shared control flow."
            )
        missing_text = ", ".join(repr(name) for name in missing_vars)
        detail = _describe_split_var_reference(inst)
        raise ValueError(
            f"Side-split inconsistency on {side} side at instruction {idx} ({inst.opname}): "
            f"{detail} references local Var(s) {missing_text}, but they were pruned from this side. "
            "This usually means a cross-side scalar dependency leaked into shared control flow."
        )


def _current_forced_side(
    explicit_scope_stack: List[Tuple[str, int, str]],
    control_scope_stack: List[Tuple[str, int, str, str]],
    idx: int,
    opname: str,
) -> Optional[Tuple[str, int, str]]:
    explicit = explicit_scope_stack[-1] if explicit_scope_stack else None
    vec_control = None
    for frame in reversed(control_scope_stack):
        if frame[0] == "vec":
            vec_control = frame
            break
    if explicit is not None and explicit[0] == "cube" and vec_control is not None:
        _, start_idx, start_opname, _ = vec_control
        raise ValueError(
            f"Instruction {opname!r} at instruction {idx} is inside cube scope but also depends on vec-only control flow "
            f"from {start_opname} started at instruction {start_idx}"
        )
    if explicit is not None:
        return explicit
    if vec_control is not None:
        side, start_idx, start_opname, _ = vec_control
        return side, start_idx, start_opname
    return None


def _helper_output_value(inst: Instruction) -> Optional[object]:
    out_key = _HELPER_VIEW_OUT_KEYS.get(inst.opname, None)
    if out_key is None:
        return None
    out = inst.kwargs.get(out_key, None)
    if inst.opname in ("slice_gm_tensor", "reshape_gm_tensor", "get_gm_tensor_list_item"):
        return out if isinstance(out, GMTensor) else None
    if inst.opname == "reinterpret":
        return out if isinstance(out, (Tensor, GMTensor)) else None
    return out if isinstance(out, Tensor) else None


def _defined_var_name(inst: Instruction) -> Optional[str]:
    if inst.opname == "create_var":
        val = inst.kwargs.get("val", None)
        return val.name if isinstance(val, Var) else None
    if is_assignment_op(inst.opname):
        out = inst.kwargs.get("out", None)
        return out.name if isinstance(out, Var) else None
    return None


def _iter_instruction_input_values(inst: Instruction) -> Iterable[object]:
    skip_keys: Set[str] = set()
    helper_out_key = _HELPER_VIEW_OUT_KEYS.get(inst.opname, None)
    if helper_out_key is not None:
        skip_keys.add(helper_out_key)
    if inst.opname == "create_var":
        skip_keys.add("val")
    if is_assignment_op(inst.opname):
        skip_keys.add("out")
    if inst.opname == "GetValueFrom":
        skip_keys.add("dst")
    if inst.opname in _LOOP_STARTS:
        skip_keys.add("var")
    if inst.opname == "reinterpret":
        skip_keys.update({"dst_shape", "dst_span"})
    for key, value in inst.kwargs.items():
        if key in skip_keys:
            continue
        yield value


def _collect_referenced_var_names(value: object, out: Set[str]) -> None:
    if isinstance(value, VarRef):
        index = getattr(value, "index", None)
        if index is not None:
            _collect_referenced_var_names(index, out)
        return
    if isinstance(value, Var):
        out.add(value.name)
        return
    if isinstance(value, Expr):
        out.update(_TMP_VAR_NAME_RE.findall(value.expr))
        return
    if isinstance(value, (Tensor, GMTensor, GMTensorList, DBuff, TBuff, QBuff)):
        return
    if isinstance(value, dict):
        for item in value.values():
            _collect_referenced_var_names(item, out)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _collect_referenced_var_names(item, out)
        return


def _is_literal_var_name(name: str) -> bool:
    try:
        float(name)
    except ValueError:
        return False
    return True


def _format_dangling_value(value: object) -> str:
    if isinstance(value, Var):
        return value.name
    if isinstance(value, Expr):
        return value.expr
    if isinstance(value, VarRef):
        parent = getattr(value, "parent", None)
        index = getattr(value, "index", None)
        parent_name = getattr(parent, "name", repr(parent))
        return f"{parent_name}[{_format_dangling_value(index)}]"
    if isinstance(value, (Tensor, GMTensor, GMTensorList, DBuff, TBuff, QBuff)):
        return getattr(value, "name", repr(value))
    if isinstance(value, dict):
        parts = [f"{key}: {_format_dangling_value(item)}" for key, item in value.items()]
        return "{" + ", ".join(parts) + "}"
    if isinstance(value, (list, tuple, set)):
        open_char, close_char = ("[", "]") if isinstance(value, list) else ("(", ")")
        parts = [_format_dangling_value(item) for item in value]
        return open_char + ", ".join(parts) + close_char
    return repr(value)


def _format_dangling_operands(inst: Instruction, missing: Iterable[str]) -> str:
    missing_set = set(missing)
    parts: List[str] = []
    for key, value in inst.kwargs.items():
        refs: Set[str] = set()
        _collect_referenced_var_names(value, refs)
        if refs & missing_set:
            parts.append(f"{key}={_format_dangling_value(value)}")
    return ", ".join(parts) if parts else "<unknown operand>"


def _collect_tracked_local_var_names(insts: List[Instruction]) -> Set[str]:
    tracked = set(_collect_known_var_names(insts))
    _, tmp_var_names, _, _ = build_expr_state(insts)
    tracked.update(tmp_var_names)
    return tracked


def _collect_instruction_local_var_refs(inst: Instruction, tracked_names: Set[str]) -> Set[str]:
    refs: Set[str] = set()
    for value in _iter_instruction_input_values(inst):
        _extract_live_names_from_value(value, tracked_names, set(), refs, set())
    return refs


def _collect_instruction_local_var_defs(inst: Instruction, tracked_names: Set[str]) -> Set[str]:
    defs: Set[str] = set()
    if inst.opname == "create_var":
        val = inst.kwargs.get("val", None)
        if isinstance(val, Var) and val.name in tracked_names:
            defs.add(val.name)
        return defs
    for key in ("out", "dst"):
        value = inst.kwargs.get(key, None)
        if isinstance(value, Var) and value.name in tracked_names:
            defs.add(value.name)
    return defs


def _make_scope_info(
    kind: str,
    start_idx: int,
    start_opname: str,
    *,
    chain_start_idx: Optional[int] = None,
) -> Dict[str, object]:
    return {
        "kind": kind,
        "start_idx": start_idx,
        "start_opname": start_opname,
        "chain_start_idx": chain_start_idx,
    }


def _scope_display_text(scope: Dict[str, object]) -> str:
    kind = str(scope.get("kind", "root"))
    start_idx = int(scope.get("start_idx", -1))
    start_opname = str(scope.get("start_opname", "<root>"))
    if kind == "if_branch":
        branch_name = {
            "start_if": "if branch",
            "start_elif": "elif branch",
            "start_else": "else branch",
        }.get(start_opname, "if/elif/else branch")
        return f"the {branch_name} started at instruction {start_idx} ({start_opname})"
    if kind == "loop":
        loop_name = "micro loop body" if start_opname == "start_micro_loop" else "loop body"
        return f"the {loop_name} started at instruction {start_idx} ({start_opname})"
    return "kernel scope"


def _scope_violation_reason(
    name: str,
    decl_info: Dict[str, object],
    use_scope: Dict[str, object],
    use_idx: int,
) -> str:
    decl_idx = int(decl_info["decl_idx"])
    decl_scope = decl_info["scope"]
    assert isinstance(decl_scope, dict)
    decl_kind = str(decl_scope.get("kind", "root"))
    if use_idx < decl_idx:
        return f"Local Var {name!r} is used before it is declared."
    if decl_kind == "if_branch":
        decl_chain_start = decl_scope.get("chain_start_idx", None)
        use_kind = str(use_scope.get("kind", "root"))
        use_chain_start = use_scope.get("chain_start_idx", None)
        if use_kind == "if_branch" and decl_chain_start == use_chain_start and decl_scope != use_scope:
            return (
                f"Local Var {name!r} is declared in one if/elif/else branch, "
                "but used from a sibling branch."
            )
        return (
            f"Local Var {name!r} is declared inside an if/elif/else branch, "
            "but used outside that branch."
        )
    if decl_kind == "loop":
        return f"Local Var {name!r} is declared inside a loop body, but used outside that loop."
    return f"Local Var {name!r} is not visible at this control point."


def _raise_local_var_scope_error(
    name: str,
    decl_info: Dict[str, object],
    use_scope: Dict[str, object],
    use_idx: int,
    inst: Instruction,
) -> None:
    decl_scope = decl_info["scope"]
    assert isinstance(decl_scope, dict)
    decl_idx = int(decl_info["decl_idx"])
    decl_opname = str(decl_info["decl_opname"])
    decl_label = "Declaration" if decl_opname == "create_var" else "First definition"
    operands = _format_dangling_operands(inst, [name])
    reason = _scope_violation_reason(name, decl_info, use_scope, use_idx)
    raise ValueError(
        f"{reason} {decl_label}: instruction {decl_idx} ({decl_opname}) in {_scope_display_text(decl_scope)}. "
        f"Illegal use: instruction {use_idx} ({inst.opname}); offending operand(s): {operands}. "
        "Hoist the Var declaration before that block, or keep all uses inside the same block."
    )


def _collect_local_var_decl_info(
    nodes: List[dict],
    tracked_names: Set[str],
    inst_idx_by_id: Dict[int, int],
    scope: Dict[str, object],
    out: Dict[str, Dict[str, object]],
) -> None:
    for node in nodes:
        node_type = node["type"]
        if node_type == "inst":
            inst = node["inst"]
            inst_idx = inst_idx_by_id[id(inst)]
            for name in sorted(_collect_instruction_local_var_defs(inst, tracked_names)):
                out.setdefault(
                    name,
                    {"decl_idx": inst_idx, "decl_opname": inst.opname, "scope": scope},
                )
            continue
        if node_type == "loop":
            start_inst = node["start"]
            loop_scope = _make_scope_info("loop", inst_idx_by_id[id(start_inst)], start_inst.opname)
            prelude = node.get("prelude", None)
            if prelude is not None:
                prelude_idx = inst_idx_by_id[id(prelude)]
                for name in sorted(_collect_instruction_local_var_defs(prelude, tracked_names)):
                    out.setdefault(
                        name,
                        {"decl_idx": prelude_idx, "decl_opname": prelude.opname, "scope": loop_scope},
                    )
            _collect_local_var_decl_info(node["body"], tracked_names, inst_idx_by_id, loop_scope, out)
            continue
        if node_type == "if":
            chain_start_inst = node["branches"][0]["start"]
            chain_start_idx = inst_idx_by_id[id(chain_start_inst)]
            for branch in node["branches"]:
                start_inst = branch["start"]
                branch_scope = _make_scope_info(
                    "if_branch",
                    inst_idx_by_id[id(start_inst)],
                    start_inst.opname,
                    chain_start_idx=chain_start_idx,
                )
                for prelude_inst in branch.get("prelude", []):
                    prelude_idx = inst_idx_by_id[id(prelude_inst)]
                    for name in sorted(_collect_instruction_local_var_defs(prelude_inst, tracked_names)):
                        out.setdefault(
                            name,
                            {"decl_idx": prelude_idx, "decl_opname": prelude_inst.opname, "scope": branch_scope},
                        )
                _collect_local_var_decl_info(
                    branch["body"],
                    tracked_names,
                    inst_idx_by_id,
                    branch_scope,
                    out,
                )


def _validate_local_var_lexical_scope_nodes(
    nodes: List[dict],
    tracked_names: Set[str],
    decl_info_by_name: Dict[str, Dict[str, object]],
    inst_idx_by_id: Dict[int, int],
    visible: Dict[str, Dict[str, object]],
    current_scope: Dict[str, object],
) -> None:
    for node in nodes:
        node_type = node["type"]
        if node_type == "inst":
            inst = node["inst"]
            inst_idx = inst_idx_by_id[id(inst)]
            for name in sorted(_collect_instruction_local_var_refs(inst, tracked_names)):
                if name in visible:
                    continue
                decl_info = decl_info_by_name.get(name, None)
                if decl_info is None:
                    continue
                _raise_local_var_scope_error(name, decl_info, current_scope, inst_idx, inst)
            for name in sorted(_collect_instruction_local_var_defs(inst, tracked_names)):
                decl_info = decl_info_by_name.get(name, None)
                if decl_info is not None:
                    visible[name] = decl_info
            continue
        if node_type == "loop":
            start_inst = node["start"]
            loop_scope = _make_scope_info("loop", inst_idx_by_id[id(start_inst)], start_inst.opname)
            loop_visible = dict(visible)
            prelude = node.get("prelude", None)
            if prelude is not None:
                prelude_idx = inst_idx_by_id[id(prelude)]
                for name in sorted(_collect_instruction_local_var_refs(prelude, tracked_names)):
                    if name in loop_visible:
                        continue
                    decl_info = decl_info_by_name.get(name, None)
                    if decl_info is None:
                        continue
                    _raise_local_var_scope_error(name, decl_info, current_scope, prelude_idx, prelude)
                for name in sorted(_collect_instruction_local_var_defs(prelude, tracked_names)):
                    decl_info = decl_info_by_name.get(name, None)
                    if decl_info is not None:
                        loop_visible[name] = decl_info
            start_idx = inst_idx_by_id[id(start_inst)]
            for name in sorted(_collect_instruction_local_var_refs(start_inst, tracked_names)):
                if name in loop_visible:
                    continue
                decl_info = decl_info_by_name.get(name, None)
                if decl_info is None:
                    continue
                _raise_local_var_scope_error(name, decl_info, loop_scope, start_idx, start_inst)
            _validate_local_var_lexical_scope_nodes(
                node["body"],
                tracked_names,
                decl_info_by_name,
                inst_idx_by_id,
                loop_visible,
                loop_scope,
            )
            continue
        if node_type == "if":
            chain_start_inst = node["branches"][0]["start"]
            chain_start_idx = inst_idx_by_id[id(chain_start_inst)]
            for branch in node["branches"]:
                start_inst = branch["start"]
                branch_scope = _make_scope_info(
                    "if_branch",
                    inst_idx_by_id[id(start_inst)],
                    start_inst.opname,
                    chain_start_idx=chain_start_idx,
                )
                start_idx = inst_idx_by_id[id(start_inst)]
                branch_visible = dict(visible)
                for prelude_inst in branch.get("prelude", []):
                    prelude_idx = inst_idx_by_id[id(prelude_inst)]
                    for name in sorted(_collect_instruction_local_var_refs(prelude_inst, tracked_names)):
                        if name in branch_visible:
                            continue
                        decl_info = decl_info_by_name.get(name, None)
                        if decl_info is None:
                            continue
                        _raise_local_var_scope_error(name, decl_info, branch_scope, prelude_idx, prelude_inst)
                    for name in sorted(_collect_instruction_local_var_defs(prelude_inst, tracked_names)):
                        decl_info = decl_info_by_name.get(name, None)
                        if decl_info is not None:
                            branch_visible[name] = decl_info
                for name in sorted(_collect_instruction_local_var_refs(start_inst, tracked_names)):
                    if name in branch_visible:
                        continue
                    decl_info = decl_info_by_name.get(name, None)
                    if decl_info is None:
                        continue
                    _raise_local_var_scope_error(name, decl_info, branch_scope, start_idx, start_inst)
                _validate_local_var_lexical_scope_nodes(
                    branch["body"],
                    tracked_names,
                    decl_info_by_name,
                    inst_idx_by_id,
                    branch_visible,
                    branch_scope,
                )


def _validate_local_var_lexical_scope(instructions: Iterable[Instruction]) -> None:
    insts = list(instructions)
    tracked_names = _collect_tracked_local_var_names(insts)
    if not tracked_names:
        return
    nodes, consumed = _parse_block(insts, 0, None)
    if consumed != len(insts):
        raise ValueError("instruction block parsing did not fully consume instructions")
    inst_idx_by_id = {id(inst): idx for idx, inst in enumerate(insts)}
    root_scope = _make_scope_info("root", -1, "<root>")
    decl_info_by_name: Dict[str, Dict[str, object]] = {}
    _collect_local_var_decl_info(nodes, tracked_names, inst_idx_by_id, root_scope, decl_info_by_name)
    _validate_local_var_lexical_scope_nodes(
        nodes,
        tracked_names,
        decl_info_by_name,
        inst_idx_by_id,
        {},
        root_scope,
    )


def _validate_no_dangling_vars(
    instructions: Iterable[Instruction],
    external_var_names: Optional[Iterable[str]] = None,
    allow_assignment_outputs: bool = False,
) -> None:
    insts = list(instructions)
    declared_names = _collect_known_var_names(insts)
    if allow_assignment_outputs:
        for inst in insts:
            defined_name = _defined_var_name(inst)
            if defined_name is not None:
                declared_names.add(defined_name)
    allowed_names = set(declared_names)
    check_all_vars = external_var_names is not None
    if external_var_names is not None:
        allowed_names.update(external_var_names)

    for idx, inst in enumerate(insts):
        refs: Set[str] = set()
        for value in _iter_instruction_input_values(inst):
            _collect_referenced_var_names(value, refs)
        if check_all_vars:
            missing = sorted(
                name for name in refs
                if name not in allowed_names and not _is_literal_var_name(name)
            )
        else:
            missing = sorted(
                name for name in refs
                if name.startswith("_tmp_var_") and name not in allowed_names
            )
        if missing:
            missing_text = ", ".join(repr(name) for name in missing)
            operands = _format_dangling_operands(inst, missing)
            raise ValueError(
                f"{_DANGLING_VAR_MESSAGE} Dangling Var(s) {missing_text} "
                f"at instruction {idx} ({inst.opname}); offending operand(s): {operands}."
            )


_DECLARATION_KEYS = {
    "create_var": "val",
    "create_varlist": "varlist",
    "create_reg": "reg",
    "create_reglist": "reglist",
    "create_maskreg": "reg",
    "create_tensor": "val",
    "create_dbuf": "val",
    "create_tbuf": "val",
    "create_qbuf": "val",
    "create_gm_tensor": "val",
    "create_gm_tensor_list": "val",
    "create_devent": "val",
    "create_sevent": "val",
    "create_tevent": "val",
    "create_qevent": "val",
    "split_workspace": "val",
    "get_gm_tensor_list_item": "out",
    "get_buf": "out",
    "slice_gm_tensor": "out",
    "reshape_gm_tensor": "out",
    "slice_tensor": "out",
    "micro_slice_tensor": "out",
    "reinterpret": "dst",
}


def _generated_declaration(inst: Instruction) -> Optional[Tuple[str, str, object]]:
    key = _DECLARATION_KEYS.get(inst.opname, None)
    if key is None:
        return None
    value = inst.kwargs.get(key, None)
    name = getattr(value, "name", None)
    if not isinstance(name, str) or not name:
        return None
    return name, inst.opname, value


def _validate_generated_identifier_collisions(
    instructions: Iterable[Instruction],
    external_var_names: Optional[Iterable[str]] = None,
) -> None:
    insts = list(instructions)
    loop_values = {
        id(inst.kwargs.get("var"))
        for inst in insts
        if inst.opname in _LOOP_STARTS and inst.kwargs.get("var", None) is not None
    }
    declarations: Dict[str, Tuple[str, int]] = {}
    for idx, inst in enumerate(insts):
        declaration = _generated_declaration(inst)
        if declaration is None:
            continue
        name, kind, value = declaration
        # range() creates a Var immediately before start_loop; that declaration is
        # the loop counter itself, not a separate conflicting object.
        if kind == "create_var" and id(value) in loop_values:
            continue
        declarations.setdefault(name, (kind, idx))
    for name in external_var_names or ():
        declarations.setdefault(str(name), ("external argument", -1))

    active_loops: List[Tuple[str, int]] = []
    for idx, inst in enumerate(insts):
        if inst.opname in _LOOP_STARTS:
            loop_var = inst.kwargs.get("var", None)
            name = getattr(loop_var, "name", None)
            if not isinstance(name, str) or not name:
                active_loops.append(("", idx))
                continue
            conflict = declarations.get(name, None)
            if conflict is not None:
                kind, decl_idx = conflict
                raise ValueError(
                    f"Loop counter {name!r} at instruction {idx} collides with generated C++ "
                    f"declaration {kind!r} at instruction {decl_idx}; use distinct names"
                )
            for active_name, active_idx in active_loops:
                if active_name == name:
                    raise ValueError(
                        f"Nested loop counter {name!r} at instruction {idx} shadows the active "
                        f"loop started at instruction {active_idx}; use distinct names"
                    )
            active_loops.append((name, idx))
        elif inst.opname == "end_loop" and active_loops:
            active_loops.pop()


def _collect_helper_output_ids_from_value(
    value: object,
    helper_output_ids: Set[int],
    out: Set[int],
) -> None:
    if isinstance(value, (Tensor, GMTensor)):
        value_id = id(value)
        if value_id in helper_output_ids:
            out.add(value_id)
        return
    if isinstance(value, dict):
        for item in value.values():
            _collect_helper_output_ids_from_value(item, helper_output_ids, out)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _collect_helper_output_ids_from_value(item, helper_output_ids, out)
        return


def _collect_helper_output_names_from_value(
    value: object,
    helper_output_ids: Set[int],
    out: Dict[int, str],
) -> None:
    if isinstance(value, (Tensor, GMTensor)):
        value_id = id(value)
        if value_id in helper_output_ids:
            name = getattr(value, "name", "")
            out[value_id] = name if isinstance(name, str) and name else f"helper@{value_id}"
        return
    if isinstance(value, dict):
        for item in value.values():
            _collect_helper_output_names_from_value(item, helper_output_ids, out)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _collect_helper_output_names_from_value(item, helper_output_ids, out)
        return


def _infer_strict_vec_provenance(instructions: List[Instruction]) -> Tuple[Set[str], Set[int]]:
    """Propagate strict vec ownership through scalar assignments and helper views."""
    known_var_names = _collect_known_var_names(instructions)
    helper_output_ids = {
        id(out)
        for inst in instructions
        for out in [_helper_output_value(inst)]
        if out is not None
    }
    strict_vec_var_names: Set[str] = set()
    strict_vec_helper_ids: Set[int] = set()

    for inst in instructions:
        if inst.opname not in _STRICT_VEC_ONLY_SCALAR_OPS:
            continue
        out = inst.kwargs.get("out", None)
        if isinstance(out, Var) and out.name in known_var_names:
            strict_vec_var_names.add(out.name)

    if not strict_vec_var_names:
        return strict_vec_var_names, strict_vec_helper_ids

    var_deps = _collect_var_deps(instructions, known_var_names, set())
    changed = True
    while changed:
        changed = False

        # Keep the existing scalar dependency behavior, including dependencies
        # introduced by enclosing loop/if control.
        for out_name, input_names in var_deps.items():
            if out_name in strict_vec_var_names or not (input_names & strict_vec_var_names):
                continue
            strict_vec_var_names.add(out_name)
            changed = True

        # Helper views are real codegen definitions. A view whose source, offset,
        # shape, or index is vec-owned is vec-owned too. Consumers such as
        # GetValueFrom then propagate that ownership to their output Var.
        for inst in instructions:
            input_var_names: Set[str] = set()
            input_helper_ids: Set[int] = set()
            for value in _iter_instruction_input_values(inst):
                _extract_live_names_from_value(
                    value,
                    known_var_names,
                    set(),
                    input_var_names,
                    set(),
                )
                _collect_helper_output_ids_from_value(value, helper_output_ids, input_helper_ids)
            has_strict_input = bool(
                (input_var_names & strict_vec_var_names)
                or (input_helper_ids & strict_vec_helper_ids)
            )
            if not has_strict_input:
                continue

            helper_out = _helper_output_value(inst)
            if helper_out is not None and id(helper_out) not in strict_vec_helper_ids:
                strict_vec_helper_ids.add(id(helper_out))
                changed = True

            out_name = _defined_var_name(inst)
            if out_name is not None and out_name not in strict_vec_var_names:
                strict_vec_var_names.add(out_name)
                changed = True

    return strict_vec_var_names, strict_vec_helper_ids


def _validate_side_helper_view_references(
    instructions: List[Instruction],
    side: str,
    original_instructions: List[Instruction],
) -> None:
    """Reject a retained helper-view consumer when its definition was pruned."""
    helper_defs: Dict[int, Instruction] = {}
    helper_names: Dict[int, str] = {}
    for inst in original_instructions:
        helper_out = _helper_output_value(inst)
        if helper_out is None:
            continue
        helper_id = id(helper_out)
        helper_defs[helper_id] = inst
        name = getattr(helper_out, "name", "")
        helper_names[helper_id] = name if isinstance(name, str) and name else f"helper@{helper_id}"
    if not helper_defs:
        return

    retained_inst_ids = {id(inst) for inst in instructions}
    original_inst_index_by_id = {id(inst): idx for idx, inst in enumerate(original_instructions)}
    helper_output_ids = set(helper_defs)
    for idx, inst in enumerate(instructions):
        referenced_helper_ids: Set[int] = set()
        for value in _iter_instruction_input_values(inst):
            _collect_helper_output_ids_from_value(value, helper_output_ids, referenced_helper_ids)
        missing_helper_ids = sorted(
            helper_id
            for helper_id in referenced_helper_ids
            if id(helper_defs[helper_id]) not in retained_inst_ids
        )
        if not missing_helper_ids:
            continue
        details = []
        for helper_id in missing_helper_ids:
            def_inst = helper_defs[helper_id]
            def_idx = original_inst_index_by_id.get(id(def_inst), -1)
            details.append(
                f"{helper_names[helper_id]!r} from {def_inst.opname} at original instruction {def_idx}"
            )
        raise ValueError(
            f"Side-split inconsistency on {side} side at instruction {idx} ({inst.opname}): "
            f"helper view(s) {', '.join(details)} have no retained definition on this side. "
            "This usually means helper-view side ownership was not propagated to its consumer."
        )


def _merge_side(existing: Optional[str], new: str) -> str:
    if existing is None or existing == new:
        return new
    if existing == "both" or new == "both":
        return "both"
    return "both"


def _control_side_from_flags(cube_has: bool, vec_has: bool) -> Optional[str]:
    if cube_has and vec_has:
        return "both"
    if cube_has:
        return "cube"
    if vec_has:
        return "vec"
    return None


def _inst_emits_material_for_control(inst: Instruction, cube_ops: Set[str], vec_ops: Set[str]) -> bool:
    if inst.opname in _LOOP_STARTS or inst.opname in ("end_loop", "start_if", "start_elif", "start_else", "end_if"):
        return False
    if inst.opname in _SCOPE_ENTER_OPS or inst.opname in _SCOPE_END_OPS:
        return False
    if inst.opname in (
        "create_var",
        "create_varlist",
        "create_gm_tensor",
        "create_gm_tensor_list",
        "create_tensor",
        "create_dbuf",
        "create_tbuf",
        "create_qbuf",
        "create_sevent",
        "create_devent",
        "create_tevent",
        "create_qevent",
        "inline",
        "reset_cache",
        "start_auto_sync",
        "end_auto_sync",
    ):
        return False
    if is_assignment_op(inst.opname):
        return False
    if inst.opname in _HELPER_VIEW_OUT_KEYS:
        return False
    return _classify_inst_base(inst, cube_ops, vec_ops) in ("cube", "vec", "both")


def _build_control_consumer_side_map(
    instructions: List[Instruction],
    cube_ops: Set[str],
    vec_ops: Set[str],
    vec_control_scope_map: Dict[int, str],
    strict_vec_control_scope_map: Dict[int, str],
) -> Dict[int, str]:
    side_map: Dict[int, str] = {}
    stack: List[Dict[str, object]] = []

    def _push_control(kind: str, inst: Instruction) -> None:
        forced = vec_control_scope_map.get(id(inst), None)
        strict_vec = strict_vec_control_scope_map.get(id(inst), None) == "vec"
        stack.append(
            {
                "kind": kind,
                "start_ids": [id(inst)],
                "cube": forced == "cube",
                "vec": forced == "vec" or strict_vec,
                "strict_vec": strict_vec,
            }
        )

    def _pop_control(kind: str) -> None:
        if not stack or stack[-1].get("kind") != kind:
            return
        frame = stack.pop()
        side = _control_side_from_flags(bool(frame.get("cube")), bool(frame.get("vec")))
        if side is None:
            return
        for start_id in frame.get("start_ids", []):
            if isinstance(start_id, int):
                side_map[start_id] = side

    for inst in instructions:
        opname = inst.opname
        if opname in _LOOP_STARTS:
            _push_control("loop", inst)
            continue
        if opname == "start_if":
            _push_control("if", inst)
            continue
        if opname in ("start_elif", "start_else"):
            if not stack or stack[-1].get("kind") != "if":
                continue
            frame = stack[-1]
            start_ids = frame.setdefault("start_ids", [])
            if isinstance(start_ids, list):
                start_ids.append(id(inst))
            forced = vec_control_scope_map.get(id(inst), None)
            if forced == "cube":
                frame["cube"] = True
            elif forced == "vec":
                frame["vec"] = True
            if strict_vec_control_scope_map.get(id(inst), None) == "vec":
                frame["vec"] = True
                frame["strict_vec"] = True
            continue
        if opname == "end_loop":
            _pop_control("loop")
            continue
        if opname == "end_if":
            _pop_control("if")
            continue
        if not _inst_emits_material_for_control(inst, cube_ops, vec_ops):
            continue
        side = _classify_inst_base(inst, cube_ops, vec_ops)
        for frame in stack:
            if side in ("cube", "both") and not bool(frame.get("strict_vec")):
                frame["cube"] = True
            if side in ("vec", "both"):
                frame["vec"] = True

    return side_map


def _classify_inst_base(inst: Instruction, cube_ops: Set[str], vec_ops: Set[str]) -> str:
    opname = inst.opname
    if opname == "SetValueTo":
        src = inst.kwargs.get("src", None)
        if isinstance(src, Tensor):
            return "vec"
        if isinstance(src, GMTensor):
            return "both"
        return "both"
    if opname == "GetValueFrom":
        src = inst.kwargs.get("src", None)
        if isinstance(src, Tensor):
            return "vec"
        if isinstance(src, GMTensor):
            return "both"
        return "both"
    if opname == "sim_dump_tensor":
        pipe_name = str(inst.kwargs.get("pipe", ""))
        if pipe_name in ("MTE1", "M", "FIX"):
            return "cube"
        if pipe_name in ("V", "MTE3"):
            return "vec"
        if pipe_name in ("MTE2", "S"):
            return "both"
        return "both"
    if opname == "kernel_dump_tensor":
        src = inst.kwargs.get("src", None)
        if isinstance(src, GMTensor):
            return "both"
        if isinstance(src, Tensor):
            if src.position is Position.UB:
                return "vec"
            if src.position in (Position.L1, Position.L0C):
                return "cube"
            return "both"
        return "both"
    if opname == "kernel_print":
        cube_side = False
        vec_side = False
        for value in inst.kwargs.values():
            cube_item, vec_item = _value_sides(value)
            cube_side = cube_side or cube_item
            vec_side = vec_side or vec_item
        if cube_side and not vec_side:
            return "cube"
        if vec_side and not cube_side:
            return "vec"
        return "both"
    if opname == "clean_dcache":
        mode = inst.kwargs.get("mode", "all")
        if mode == "vec":
            return "vec"
        if mode == "cube":
            return "cube"
        return "both"
    if opname == "barrier":
        # A PipeBarrier is a single-core instruction: route it to the core that owns the
        # pipe. PIPE_M/MTE1/FIX are cube pipes (and PipeBarrier<PIPE_M> is a *compile error*
        # on the a5 AIV core -- "range of 1st parameter must be [4,6]"); PIPE_V/MTE3 are vec
        # pipes; PIPE_ALL/MTE2/S apply to both. Without this a cube barrier defaulted to
        # "both" and emitted an illegal vec-side copy that broke a5 mix kernels. See
        # doc/api/barrier.md, "Mixed-kernel side routing".
        pipe_name = str(inst.kwargs.get("pipe", ""))
        if pipe_name in _PIPE_CUBE_NAMES:
            return "cube"
        if pipe_name in _PIPE_VEC_NAMES:
            return "vec"
        return "both"
    if opname in _CUBE_PIPE_OPS:
        return "cube"
    if opname in _VEC_PIPE_OPS:
        return "vec"
    if opname in _VEC_ONLY_SCALAR_OPS:
        return "vec"
    if opname in _EVENT_OPS:
        event = inst.kwargs.get("event")
        if event is None:
            event = inst.kwargs.get("val")
        cube_side, vec_side = _event_sides(event)
        if cube_side and not vec_side:
            return "cube"
        if vec_side and not cube_side:
            return "vec"
        return "both"
    if opname in cube_ops and opname not in vec_ops:
        return "cube"
    if opname in vec_ops and opname not in cube_ops:
        return "vec"
    if opname in cube_ops or opname in vec_ops:
        return "both"
    if opname in ("setflag", "waitflag"):
        pipes = []
        src = inst.kwargs.get("src", None)
        dst = inst.kwargs.get("dst", None)
        if src is not None:
            pipes.append(src)
        if dst is not None:
            pipes.append(dst)
        cube_side = any(str(pipe) in _PIPE_CUBE_NAMES for pipe in pipes)
        vec_side = any(str(pipe) in _PIPE_VEC_NAMES for pipe in pipes)
        if cube_side and not vec_side:
            return "cube"
        if vec_side and not cube_side:
            return "vec"
        return "both"
    return "both"


def _infer_side_routed_outputs(
    instructions: List[Instruction],
    cube_ops: Set[str],
    vec_ops: Set[str],
    control_consumer_side_map: Dict[int, str],
) -> Tuple[Dict[int, str], Dict[str, str]]:
    known_var_names = _collect_known_var_names(instructions)
    helper_output_ids: Set[int] = set()
    for inst in instructions:
        out = _helper_output_value(inst)
        if out is not None:
            helper_output_ids.add(id(out))

    helper_output_sides: Dict[int, str] = {}
    var_output_sides: Dict[str, str] = {}

    for inst in reversed(instructions):
        if inst.opname in _LOOP_STARTS or inst.opname in _IF_STARTS:
            base_side = control_consumer_side_map.get(id(inst), None)
        else:
            base_side = _classify_inst_base(inst, cube_ops, vec_ops)

        helper_out = _helper_output_value(inst)
        out_name = None if helper_out is not None else _defined_var_name(inst)
        consumer_side: Optional[str]
        if helper_out is not None:
            consumer_side = helper_output_sides.get(id(helper_out), None)
        elif out_name is not None:
            consumer_side = var_output_sides.get(out_name, None)
        else:
            consumer_side = base_side

        if consumer_side is None:
            continue

        helper_input_ids: Set[int] = set()
        used_vars: Set[str] = set()
        for value in _iter_instruction_input_values(inst):
            _collect_helper_output_ids_from_value(value, helper_output_ids, helper_input_ids)
            _extract_live_names_from_value(
                value,
                known_var_names,
                set(),
                used_vars,
                set(),
            )

        for helper_id in helper_input_ids:
            helper_output_sides[helper_id] = _merge_side(
                helper_output_sides.get(helper_id, None),
                consumer_side,
            )
        for var_name in used_vars:
            var_output_sides[var_name] = _merge_side(
                var_output_sides.get(var_name, None),
                consumer_side,
            )

    return helper_output_sides, var_output_sides


def _classify_inst(
    inst: Instruction,
    cube_ops: Set[str],
    vec_ops: Set[str],
    helper_output_sides: Optional[Dict[int, str]] = None,
    var_output_sides: Optional[Dict[str, str]] = None,
    strict_vec_var_names: Optional[Set[str]] = None,
    strict_vec_helper_ids: Optional[Set[int]] = None,
) -> str:
    if strict_vec_var_names is not None:
        out_name = _defined_var_name(inst)
        if out_name is not None and out_name in strict_vec_var_names:
            return "vec"
    if strict_vec_helper_ids is not None:
        helper_out = _helper_output_value(inst)
        if helper_out is not None and id(helper_out) in strict_vec_helper_ids:
            return "vec"
    if helper_output_sides is not None:
        helper_out = _helper_output_value(inst)
        if helper_out is not None:
            side = helper_output_sides.get(id(helper_out), None)
            if side is not None:
                return side
    if var_output_sides is not None:
        out_name = _defined_var_name(inst)
        if out_name is not None:
            side = var_output_sides.get(out_name, None)
            if side is not None:
                return side
    return _classify_inst_base(inst, cube_ops, vec_ops)


def _strict_vec_inputs(
    inst: Instruction,
    strict_vec_var_names: Set[str],
    strict_vec_helper_ids: Set[int],
) -> Tuple[Set[str], Dict[int, str]]:
    input_var_names: Set[str] = set()
    input_helper_names: Dict[int, str] = {}
    for value in _iter_instruction_input_values(inst):
        _extract_live_names_from_value(
            value,
            strict_vec_var_names,
            set(),
            input_var_names,
            set(),
        )
        _collect_helper_output_names_from_value(value, strict_vec_helper_ids, input_helper_names)
    return input_var_names, input_helper_names


def _adjust_side_for_strict_vec_inputs(
    inst: Instruction,
    idx: int,
    side: str,
    strict_vec_var_names: Set[str],
    strict_vec_helper_ids: Set[int],
) -> str:
    input_var_names, input_helper_names = _strict_vec_inputs(
        inst,
        strict_vec_var_names,
        strict_vec_helper_ids,
    )
    if not input_var_names and not input_helper_names:
        return side
    if side == "cube":
        details: List[str] = []
        if input_var_names:
            names = ", ".join(repr(name) for name in sorted(input_var_names))
            details.append(f"vec-only scalar Var(s) {names}")
        if input_helper_names:
            names = ", ".join(repr(name) for name in sorted(input_helper_names.values()))
            details.append(f"vec-only helper view(s) {names}")
        raise ValueError(
            f"Instruction {inst.opname!r} at instruction {idx} is cube-side but depends on "
            + " and ".join(details)
        )
    if side == "both":
        return "vec"
    return side


def _validate_kernel_mode_constraints(
    instructions: List[Instruction],
    kernel_mode: str,
) -> None:
    if kernel_mode == "vec":
        for idx, inst in enumerate(instructions):
            if inst.opname == "GetCubeNum":
                raise ValueError(
                    "GetCubeNum is not allowed when kernel mode is 'vec' "
                    f"(instruction {idx})"
                )


def _validate_mode_exclusive_side_usage(
    cube_insts: List[Instruction],
    vec_insts: List[Instruction],
    kernel_mode: str,
) -> None:
    if kernel_mode == "mix":
        return
    cube_ids = {id(inst) for inst in cube_insts}
    vec_ids = {id(inst) for inst in vec_insts}
    if kernel_mode == "vec":
        for idx, inst in enumerate(cube_insts):
            if id(inst) not in vec_ids:
                raise ValueError(
                    f"Instruction {inst.opname!r} is cube-only and not allowed when kernel mode is 'vec' "
                    f"(instruction {idx} on cube side)"
                )
        return
    if kernel_mode == "cube":
        for idx, inst in enumerate(vec_insts):
            if id(inst) not in cube_ids:
                raise ValueError(
                    f"Instruction {inst.opname!r} is vec-only and not allowed when kernel mode is 'cube' "
                    f"(instruction {idx} on vec side)"
                )
        return
    raise ValueError("Unsupported kernel_mode for split_instructions: " + str(kernel_mode))


def split_instructions(
    instructions: Iterable[Instruction],
    kernel_mode: str = "mix",
) -> Tuple[List[Instruction], List[Instruction]]:
    instructions = list(instructions)
    _validate_kernel_mode_constraints(instructions, kernel_mode)
    _validate_generated_identifier_collisions(instructions)
    _validate_local_var_lexical_scope(instructions)
    original_local_var_names = _collect_known_var_names(instructions)
    _, original_tmp_var_names, _, _ = build_expr_state(instructions, kernel_mode=kernel_mode)
    cube_ops, vec_ops = _get_stub_opnames()
    vec_control_scope_map = _build_vec_control_scope_map(instructions)
    strict_vec_var_names, strict_vec_helper_ids = _infer_strict_vec_provenance(instructions)
    strict_vec_control_scope_map = _build_control_scope_map_from_vars(instructions, strict_vec_var_names)
    control_consumer_side_map = _build_control_consumer_side_map(
        instructions,
        cube_ops,
        vec_ops,
        vec_control_scope_map,
        strict_vec_control_scope_map,
    )
    helper_output_sides, var_output_sides = _infer_side_routed_outputs(
        instructions,
        cube_ops,
        vec_ops,
        control_consumer_side_map,
    )
    cube_insts: List[Instruction] = []
    vec_insts: List[Instruction] = []
    explicit_scope_stack: List[Tuple[str, int, str]] = []
    control_scope_stack: List[Tuple[str, int, str, str]] = []

    def _emit_with_current_forcing(inst: Instruction, idx: int, side: str) -> bool:
        forced = _current_forced_side(explicit_scope_stack, control_scope_stack, idx, inst.opname)
        if forced is None:
            return False
        forced_side, start_idx, start_opname = forced
        _validate_set_value_to_side(inst, forced_side, idx, (start_idx, start_opname))
        if forced_side == "vec":
            if side == "cube":
                raise ValueError(
                    f"Instruction {inst.opname!r} at instruction {idx} is cube-only inside "
                    f"{start_opname} started at instruction {start_idx}"
                )
            vec_insts.append(inst)
            return True
        if side == "vec":
            raise ValueError(
                f"Instruction {inst.opname!r} at instruction {idx} is vec-only inside "
                f"{start_opname} started at instruction {start_idx}"
            )
        cube_insts.append(inst)
        return True

    for idx, inst in enumerate(instructions):
        opname = inst.opname
        enter_side = _SCOPE_ENTER_OPS.get(opname, None)
        if enter_side is not None:
            explicit_scope_stack.append((enter_side, idx, opname))
            continue
        end_side = _SCOPE_END_OPS.get(opname, None)
        if end_side is not None:
            if not explicit_scope_stack:
                raise ValueError(f"{opname} at instruction {idx} has no matching scope start")
            start_side, start_idx, start_opname = explicit_scope_stack.pop()
            if start_side != end_side:
                raise ValueError(
                    f"{opname} at instruction {idx} closes {end_side} scope, "
                    f"but the active scope started with {start_opname} at instruction {start_idx}"
                )
            continue

        if opname in _LOOP_STARTS:
            control_side = control_consumer_side_map.get(id(inst), vec_control_scope_map.get(id(inst), "both"))
            control_scope_stack.append((control_side, idx, opname, "loop"))
            if _emit_with_current_forcing(inst, idx, "both"):
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            continue
        if opname == "end_loop":
            if not control_scope_stack or control_scope_stack[-1][3] != "loop":
                raise ValueError(f"{opname} at instruction {idx} has no matching loop start")
            if _emit_with_current_forcing(inst, idx, "both"):
                control_scope_stack.pop()
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            control_scope_stack.pop()
            continue
        if opname in ("break_loop", "continue_loop"):
            if _emit_with_current_forcing(inst, idx, "both"):
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            continue
        if opname == "start_if":
            control_side = control_consumer_side_map.get(id(inst), vec_control_scope_map.get(id(inst), "both"))
            control_scope_stack.append((control_side, idx, opname, "if"))
            if _emit_with_current_forcing(inst, idx, "both"):
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            continue
        if opname in ("start_elif", "start_else"):
            if not control_scope_stack or control_scope_stack[-1][3] != "if":
                raise ValueError(f"{opname} at instruction {idx} has no matching if start")
            control_side = control_consumer_side_map.get(
                id(inst),
                vec_control_scope_map.get(id(inst), control_scope_stack[-1][0]),
            )
            _, start_idx, start_opname, kind = control_scope_stack[-1]
            control_scope_stack[-1] = (control_side, start_idx, start_opname, kind)
            if _emit_with_current_forcing(inst, idx, "both"):
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            continue
        if opname == "end_if":
            if not control_scope_stack or control_scope_stack[-1][3] != "if":
                raise ValueError(f"{opname} at instruction {idx} has no matching if start")
            if _emit_with_current_forcing(inst, idx, "both"):
                control_scope_stack.pop()
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            control_scope_stack.pop()
            continue

        side = _classify_inst(
            inst,
            cube_ops,
            vec_ops,
            helper_output_sides,
            var_output_sides,
            strict_vec_var_names,
            strict_vec_helper_ids,
        )
        side = _adjust_side_for_strict_vec_inputs(
            inst,
            idx,
            side,
            strict_vec_var_names,
            strict_vec_helper_ids,
        )
        forced = _current_forced_side(explicit_scope_stack, control_scope_stack, idx, opname)
        if forced is None and inst.opname == "SetValueTo" and side == "both":
            _warn_unscoped_set_value_to(idx)
        if _emit_with_current_forcing(inst, idx, side):
            continue

        if side in ("cube", "both"):
            _validate_set_value_to_side(inst, "cube", idx)
        if side in ("cube", "both"):
            cube_insts.append(inst)
        if side in ("vec", "both"):
            vec_insts.append(inst)

    if explicit_scope_stack:
        side, start_idx, start_opname = explicit_scope_stack[-1]
        raise ValueError(
            f"{start_opname} at instruction {start_idx} is not closed before the instruction stream ends"
        )
    if control_scope_stack:
        _, start_idx, start_opname, _ = control_scope_stack[-1]
        raise ValueError(
            f"{start_opname} at instruction {start_idx} is not closed before the instruction stream ends"
        )

    def _classify_for_prune(inst: Instruction) -> str:
        return _classify_inst(
            inst,
            cube_ops,
            vec_ops,
            helper_output_sides,
            var_output_sides,
            strict_vec_var_names,
            strict_vec_helper_ids,
        )

    cube_insts = prune_empty_blocks(cube_insts)
    vec_insts = prune_empty_blocks(vec_insts)
    cube_insts = prune_unused_decls(cube_insts, "cube")
    vec_insts = prune_unused_decls(vec_insts, "vec")
    cube_insts = prune_unused_vars(cube_insts, "cube", _classify_for_prune)
    vec_insts = prune_unused_vars(vec_insts, "vec", _classify_for_prune)
    cube_insts = prune_unused_decls(cube_insts, "cube")
    vec_insts = prune_unused_decls(vec_insts, "vec")
    cube_insts = prune_empty_blocks(cube_insts)
    vec_insts = prune_empty_blocks(vec_insts)
    _validate_side_local_var_references(
        cube_insts,
        "cube",
        instructions,
        original_local_var_names,
        original_tmp_var_names,
    )
    _validate_side_local_var_references(
        vec_insts,
        "vec",
        instructions,
        original_local_var_names,
        original_tmp_var_names,
    )
    _validate_side_helper_view_references(cube_insts, "cube", instructions)
    _validate_side_helper_view_references(vec_insts, "vec", instructions)
    _validate_mode_exclusive_side_usage(cube_insts, vec_insts, kernel_mode)
    if kernel_mode == "vec":
        cube_insts = []
    elif kernel_mode == "cube":
        vec_insts = []
    return cube_insts, vec_insts


def _event_creation_signature(inst: Instruction) -> Optional[Tuple[str, str, str, str, bool]]:
    if inst.opname not in _EVENT_CREATE_OPS:
        return None
    val = inst.kwargs.get("val", None)
    if val is None:
        raise ValueError(f"{inst.opname} requires 'val' in kwargs")
    name = getattr(val, "name", None)
    if not isinstance(name, str) or not name:
        raise ValueError(f"{inst.opname} requires event name, current value: {name!r}")
    src_pipe = str(getattr(val, "src_pipe", None))
    dst_pipe = str(getattr(val, "dst_pipe", None))
    preset = bool(getattr(val, "preset", False))
    return name, inst.opname, src_pipe, dst_pipe, preset


def eliminate_duplicated_event_creation(instructions: Iterable[Instruction]) -> List[Instruction]:
    deduped: List[Instruction] = []
    seen_by_name: Dict[str, Tuple[str, str, str, bool]] = {}
    for inst in instructions:
        signature = _event_creation_signature(inst)
        if signature is None:
            deduped.append(inst)
            continue
        name, opname, src_pipe, dst_pipe, preset = signature
        current_signature = (opname, src_pipe, dst_pipe, preset)
        previous_signature = seen_by_name.get(name, None)
        if previous_signature is None:
            seen_by_name[name] = current_signature
            deduped.append(inst)
            continue
        if previous_signature != current_signature:
            raise ValueError(
                f"Conflicting event creation for {name!r}: "
                f"{previous_signature!r} vs {current_signature!r}"
            )
    return deduped


def _next_emit_index(
    instructions: List[Instruction],
    start_idx: int,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> int:
    idx = start_idx
    while idx < len(instructions) and should_skip_inst(
        instructions[idx],
        tmp_var_names,
        tmp_tensor_names,
        tmp_gmtensor_names,
    ):
        idx += 1
    return idx


def _try_swap_create_var_with_event(
    instructions: List[Instruction],
    idx: int,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> bool:
    inst = instructions[idx]
    if inst.opname != "create_var":
        return False
    next_idx = _next_emit_index(
        instructions,
        idx + 1,
        tmp_var_names,
        tmp_tensor_names,
        tmp_gmtensor_names,
    )
    if next_idx >= len(instructions):
        return False
    next_inst = instructions[next_idx]
    if next_inst.opname not in _EVENT_SWAP_OPS:
        return False
    instructions[idx], instructions[next_idx] = instructions[next_idx], instructions[idx]
    return True


def _try_fold_loop(
    instructions: List[Instruction],
    idx: int,
    expr_map: dict,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
    helper: CodeHelper,
) -> int:
    inst = instructions[idx]
    if inst.opname != "create_var":
        return -1
    val = inst.kwargs.get("val", None)
    if not isinstance(val, Var) or is_tmp_var(val):
        return -1
    next_idx = _next_emit_index(
        instructions,
        idx + 1,
        tmp_var_names,
        tmp_tensor_names,
        tmp_gmtensor_names,
    )
    if next_idx >= len(instructions):
        return -1
    next_inst = instructions[next_idx]
    if next_inst.opname not in _LOOP_STARTS:
        return -1
    loop_var = next_inst.kwargs.get("var", None)
    if not isinstance(loop_var, Var) or loop_var.name != val.name:
        return -1
    start = value_to_cpp(next_inst.kwargs.get("start", None), expr_map)
    stop = value_to_cpp(next_inst.kwargs.get("stop", None), expr_map)
    step_value = next_inst.kwargs.get("step", None)
    step = value_to_cpp(step_value, expr_map)
    if next_inst.opname == "start_micro_loop":
        increment = (
            f"++{val.name}"
            if isinstance(step_value, int) and step_value == 1
            else f"{val.name} += (uint16_t){step}"
        )
        helper(
            f"for (uint16_t {val.name} = (uint16_t){start}; "
            f"{val.name} < (uint16_t){stop}; {increment}) {{"
        )
    else:
        dtype = dtype_to_cpp(val.dtype)
        helper(f"for ({dtype} {val.name} = {start}; {val.name} < {stop}; {val.name} += {step}) {{")
    helper.ir()
    return next_idx + 1


def _try_fold_decl_assign(
    instructions: List[Instruction],
    idx: int,
    expr_map: dict,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
    helper: CodeHelper,
) -> int:
    inst = instructions[idx]
    if inst.opname != "create_var":
        return -1
    val = inst.kwargs.get("val", None)
    if not isinstance(val, Var) or is_tmp_var(val):
        return -1
    next_idx = _next_emit_index(
        instructions,
        idx + 1,
        tmp_var_names,
        tmp_tensor_names,
        tmp_gmtensor_names,
    )
    if next_idx >= len(instructions):
        return -1
    next_inst = instructions[next_idx]
    if not is_assignment_op(next_inst.opname):
        return -1
    if next_inst.opname == "tensorlist_item_numel":
        # This lowering materializes a TensorDesc and shape buffer before the
        # scalar assignment, so it cannot be folded into one declaration RHS.
        return -1
    out = next_inst.kwargs.get("out", None)
    if not isinstance(out, Var) or out.name != val.name:
        return -1
    if uses_var_in_operands(next_inst, val.name):
        return -1
    dtype = dtype_to_cpp(val.dtype)
    expr = render_cpp_expr(assignment_expr(next_inst, expr_map, kernel_mode=helper.kernel_mode))
    helper(f"{dtype} {val.name} = {expr};")
    return next_idx + 1


def validate(
    instructions: Iterable[Instruction],
    external_var_names: Optional[Iterable[str]] = None,
    allow_assignment_outputs: bool = False,
) -> None:
    instructions = list(instructions)
    _validate_generated_identifier_collisions(instructions, external_var_names)
    _validate_no_dangling_vars(
        instructions,
        external_var_names=external_var_names,
        allow_assignment_outputs=allow_assignment_outputs,
    )
    _validate_local_var_lexical_scope(instructions)
    loop_depth = 0
    if_depth = 0
    for idx, inst in enumerate(instructions):
        op = inst.opname
        if op in _LOOP_STARTS:
            loop_depth += 1
        elif op == "end_loop":
            if loop_depth > 0:
                loop_depth -= 1
        elif op in _IF_STARTS:
            if_depth += 1
        elif op == "end_if":
            if if_depth > 0:
                if_depth -= 1
        if op in _BLOCK_FORBIDDEN_OPS and (loop_depth > 0 or if_depth > 0):
            if loop_depth > 0 and if_depth > 0:
                scope = "loop/if"
            elif loop_depth > 0:
                scope = "loop"
            else:
                scope = "if/elif/else"
            raise ValueError(f"{op} cannot be inside {scope} block (index {idx}).")


def _is_int4_tensor(value: object) -> bool:
    return isinstance(value, Tensor) and getattr(value.dtype, "name", "") == "int4"


def _is_fp4_tensor(value: object) -> bool:
    return isinstance(value, Tensor) and getattr(value.dtype, "name", "") in ("fp4x2_e2m1_t", "fp4x2_e1m2_t")


def _iter_tensors(value: object) -> Iterable[Tensor]:
    if isinstance(value, Tensor):
        yield value
        return
    if isinstance(value, dict):
        for item in value.values():
            yield from _iter_tensors(item)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            yield from _iter_tensors(item)


def _validate_int4_usage(instructions: Iterable[Instruction]) -> None:
    insts = list(instructions)
    int4_mmad_operand_ids: Set[int] = set()
    for idx, inst in enumerate(insts):
        for key, value in inst.kwargs.items():
            for tensor in _iter_tensors(value):
                if not _is_int4_tensor(tensor):
                    continue
                if inst.opname == "reinterpret" and key == "dst":
                    continue
                if inst.opname == "mmad" and key in ("src_a", "src_b"):
                    int4_mmad_operand_ids.add(id(tensor))
                    continue
                name = getattr(tensor, "name", "<unnamed>")
                raise ValueError(
                    f"DT.int4 view {name} can only be consumed by matmul/mmad; "
                    f"found in {inst.opname}.{key} at instruction {idx}"
                )

    for idx, inst in enumerate(insts):
        if inst.opname != "reinterpret":
            continue
        dst = inst.kwargs.get("dst", None)
        if not _is_int4_tensor(dst):
            continue
        consumed_by = getattr(dst, "_int4_consumed_by", None)
        if consumed_by == "derived":
            continue
        if consumed_by == "matmul" and dst.position is Position.L1:
            continue
        if consumed_by == "mmad" and dst.position in (Position.L0A, Position.L0B) and id(dst) in int4_mmad_operand_ids:
            continue
        name = getattr(dst, "name", "<unnamed>")
        raise ValueError(
            f"DT.int4 reinterpret view {name} must be consumed by matmul/mmad; "
            f"found unconsumed view at instruction {idx}"
        )


def _validate_fp4_usage(instructions: Iterable[Instruction]) -> None:
    insts = list(instructions)
    fp4_mx_load_ids: Set[int] = set()
    fp4_mmad_operand_ids: Set[int] = set()
    for idx, inst in enumerate(insts):
        for key, value in inst.kwargs.items():
            for tensor in _iter_tensors(value):
                if not _is_fp4_tensor(tensor):
                    continue
                if inst.opname == "reinterpret" and key == "dst":
                    continue
                if inst.opname == "slice_tensor" and key in ("src", "out"):
                    continue
                if inst.opname == "l1_to_l0_mx" and key in ("src", "dst"):
                    fp4_mx_load_ids.add(id(tensor))
                    continue
                if inst.opname == "mmad_mx" and key in ("src_a", "src_b"):
                    fp4_mmad_operand_ids.add(id(tensor))
                    continue
                name = getattr(tensor, "name", "<unnamed>")
                raise ValueError(
                    f"FP4 view {name} can only be consumed by l1_to_l0_mx/mmad_mx; "
                    f"found in {inst.opname}.{key} at instruction {idx}"
                )

    for idx, inst in enumerate(insts):
        if inst.opname != "reinterpret":
            continue
        dst = inst.kwargs.get("dst", None)
        if not _is_fp4_tensor(dst):
            continue
        consumed_by = getattr(dst, "_fp4_consumed_by", getattr(dst, "_packed_view_consumed_by", None))
        if consumed_by == "derived":
            continue
        if consumed_by == "l1_to_l0_mx":
            continue
        if consumed_by == "mmad_mx" and dst.position in (Position.L0A, Position.L0B):
            continue
        name = getattr(dst, "name", "<unnamed>")
        raise ValueError(
            f"FP4 reinterpret view {name} must be consumed by l1_to_l0_mx/mmad_mx; "
            f"found unconsumed view at instruction {idx}"
        )


def translate(
    instructions: Iterable[Instruction],
    external_var_names: Optional[Iterable[str]] = None,
    allow_assignment_outputs: bool = False,
    kernel_mode: str = "mix",
) -> str:
    if external_var_names is not None:
        external_var_names = tuple(external_var_names)
    instructions = list(instructions)
    validate(
        instructions,
        external_var_names=external_var_names,
        allow_assignment_outputs=allow_assignment_outputs,
    )
    _validate_int4_usage(instructions)
    _validate_fp4_usage(instructions)
    buffer_view_plan = plan_runtime_buffer_views(instructions)
    expr_map, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names = build_expr_state(
        instructions,
        kernel_mode=kernel_mode,
        buffer_view_plan=buffer_view_plan,
    )
    helper = CodeHelper(kernel_mode=kernel_mode)
    handlers = build_handlers()
    unhandled = []
    seen = set()
    idx = 0
    while idx < len(instructions):
        inst = instructions[idx]
        if should_skip_inst(inst, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names):
            idx += 1
            continue
        if _try_swap_create_var_with_event(
            instructions,
            idx,
            tmp_var_names,
            tmp_tensor_names,
            tmp_gmtensor_names,
        ):
            continue
        folded = _try_fold_loop(
            instructions,
            idx,
            expr_map,
            tmp_var_names,
            tmp_tensor_names,
            tmp_gmtensor_names,
            helper,
        )
        if folded != -1:
            idx = folded
            continue
        folded = _try_fold_decl_assign(
            instructions,
            idx,
            expr_map,
            tmp_var_names,
            tmp_tensor_names,
            tmp_gmtensor_names,
            helper,
        )
        if folded != -1:
            idx = folded
            continue
        handler = handlers.get(inst.opname)
        if handler is not None:
            handler(inst, helper, expr_map)
        else:
            opname = inst.opname
            if opname not in seen:
                seen.add(opname)
                unhandled.append(opname)
        idx += 1
    if unhandled:
        helper(f"// Untranslated instructions: {', '.join(unhandled)}")
    return str(helper)


def translate_split(
    instructions: Iterable[Instruction],
    name: Optional[str] = None,
    external_var_names: Optional[Iterable[str]] = None,
    kernel_mode: str = "mix",
) -> Tuple[str, str]:
    if external_var_names is not None:
        external_var_names = tuple(external_var_names)
    instructions = list(instructions)
    validate(instructions, external_var_names=external_var_names)
    _validate_int4_usage(instructions)
    _validate_fp4_usage(instructions)
    uses_simt = instructions_use_simt(instructions)
    cube_insts, vec_insts = split_instructions(instructions, kernel_mode=kernel_mode)
    # print('inserting auto sync instructions...')
    cube_insts = insert_auto_sync(cube_insts, mode='cube')
    cube_insts = eliminate_duplicated_event_creation(cube_insts)
    analyze_usage(cube_insts, f"{name}_cube" if name else None, uses_simt=uses_simt)
    # print('auto sync instructions inserted cuebe side.')
    vec_insts = insert_auto_sync(vec_insts, mode='vec')
    vec_insts = eliminate_duplicated_event_creation(vec_insts)
    analyze_usage(vec_insts, f"{name}_vec" if name else None, uses_simt=uses_simt)
    # print('auto sync instructions inserted vec side.')
    return (
        translate(
            cube_insts,
            external_var_names=external_var_names,
            allow_assignment_outputs=True,
            kernel_mode=kernel_mode,
        ),
        translate(
            vec_insts,
            external_var_names=external_var_names,
            allow_assignment_outputs=True,
            kernel_mode=kernel_mode,
        ),
    )


def analyze_usage(
    instructions: Iterable[Instruction],
    label: Optional[str] = None,
    uses_simt: bool = False,
) -> None:
    instructions = list(instructions)
    uses_simt = uses_simt or instructions_use_simt(instructions)
    table_width = 50
    cap_map = {
        "L1": globvars.l1_cap,
        "L0A": globvars.l0a_cap,
        "L0B": globvars.l0b_cap,
        "L0C": globvars.l0c_cap,
        "BT": globvars.bt_cap,
        "UB": effective_ub_cap_kb(globvars.ub_cap, uses_simt),
    }
    mode = None
    if label:
        if label.endswith("_cube"):
            mode = "cube"
        elif label.endswith("_vec"):
            mode = "vec"
    device_type = globvars.device_type or ""
    allowed_positions = None
    if is_c220_family(device_type):
        if mode == "cube":
            allowed_positions = ["L1", "L0C", "BT"]
        elif mode == "vec":
            allowed_positions = ["UB"]
    elif is_a5_family(device_type):
        if mode == "cube":
            allowed_positions = ["L1", "L0C", "UB", "BT"]
        elif mode == "vec":
            allowed_positions = ["UB", "L1"]

    def _fmt_num(value: float):
        if isinstance(value, float) and value.is_integer():
            return int(value)
        return value

    def _make_reset_line(width: int) -> str:
        text = "reset cache"
        content = f" {text} "
        if len(content) >= width:
            return content[:width]
        pad = width - len(content)
        left = pad // 2
        right = pad - left
        return "-" * left + content + "-" * right

    def _make_label_line(text: str, width: int) -> str:
        content = f" {text} "
        if len(content) >= width:
            return content[:width]
        pad = width - len(content)
        left = pad // 2
        right = pad - left
        return "-" * left + content + "-" * right

    def _emit_shape(val, pos_order, grouped, totals) -> None:
        if not isinstance(val, (Tensor, DBuff, TBuff, QBuff)):
            return
        shape_values = []
        for dim in val.shape:
            if isinstance(dim, Var):
                shape_values.append(dim.value)
            else:
                shape_values.append(dim)
        if isinstance(val, Tensor):
            label = "(Tensor)"
            label_style = "bright_cyan"
        elif isinstance(val, DBuff):
            label = "(DBuff)"
            label_style = "blue"
        elif isinstance(val, TBuff):
            label = "(TBuff)"
            label_style = "magenta"
        else:
            label = "(QBuff)"
            label_style = "bright_magenta"
        size_kb = "UNKNOWN KB"
        size_kb_value = None
        if len(shape_values) >= 2:
            dim0, dim1 = shape_values[0], shape_values[1]
            if isinstance(dim0, (int, float)) and isinstance(dim1, (int, float)):
                elem_size = getattr(val.dtype, "size", None)
                if isinstance(elem_size, (int, float)):
                    scale = 1
                    if isinstance(val, DBuff):
                        scale = 2
                    elif isinstance(val, TBuff):
                        scale = 3
                    elif isinstance(val, QBuff):
                        scale = 4
                    size_kb_value = (dim0 * dim1 * elem_size * scale) / 1024
                else:
                    size_kb_value = (dim0 * dim1) / 1024
                size_kb = f"{_fmt_num(size_kb_value)} KB"
        line = Text.assemble(
            (label, label_style),
            (" ", "white"),
            (val.name, "white"),
            (": ", "white"),
            (size_kb, "white"),
        )
        pos_label = str(getattr(val, "position", "UNKNOWN"))
        if allowed_positions is not None and pos_label not in allowed_positions:
            return
        if pos_label not in grouped:
            grouped[pos_label] = []
            if allowed_positions is None:
                pos_order.append(pos_label)
        grouped[pos_label].append(line)
        if size_kb_value is not None:
            totals[pos_label] = totals.get(pos_label, 0.0) + float(size_kb_value)

    def _print_table(console, pos_order, grouped, totals) -> None:
        table = Table(show_header=False, box=box.ASCII, width=table_width)
        table.add_column(justify="center")
        for pos_idx, pos_label in enumerate(pos_order):
            if pos_idx:
                table.add_section()
            table.add_row(Text(f"Position: {pos_label}", style="bright_green"))
            used_value = totals.get(pos_label, None)
            cap_value = cap_map.get(pos_label, None)
            used_str = "UNKNOWN" if used_value is None else str(_fmt_num(used_value))
            cap_str = "UNKNOWN" if cap_value is None else str(cap_value)
            for line in grouped.get(pos_label, []):
                table.add_row(line)
            if uses_simt and pos_label == "UB":
                table.add_row(Text(SIMT_UB_CAP_NOTE, style="bright_magenta"))
                table.add_row(Text(SIMT_UB_RESERVED_NOTE, style="bright_magenta"))
            table.add_row(Text(f"Usage: {used_str} KB / {cap_str} KB", style="bright_yellow"))
        console.print(Align.center(table))

    blocks: List[Tuple[str, object]] = []
    pos_order: List[str] = []
    grouped: dict[str, List[Text]] = {}
    totals: dict[str, float] = {}

    def _snapshot_table():
        if allowed_positions is not None:
            return ([pos for pos in allowed_positions if pos in grouped], grouped, totals)
        return (pos_order, grouped, totals)

    for inst in instructions:
        if inst.opname == "reset_cache":
            if grouped:
                blocks.append(("table", _snapshot_table()))
            blocks.append(("reset", None))
            pos_order = []
            grouped = {}
            totals = {}
            continue
        if inst.opname not in ("create_tensor", "create_dbuf", "create_tbuf", "create_qbuf"):
            continue
        _emit_shape(inst.kwargs.get("val", None), pos_order, grouped, totals)

    if grouped:
        blocks.append(("table", _snapshot_table()))

    if not any(kind == "table" for kind, _ in blocks):
        return

    console = Console()
    if label:
        label_width = table_width + 40
        label_line = Text(_make_label_line(label, label_width), style="bright_cyan")
        console.print(Align.center(label_line))

    pending_reset = False
    for kind, payload in blocks:
        if kind == "reset":
            pending_reset = True
            continue
        if pending_reset:
            reset_line = Text(_make_reset_line(table_width), style="bright_magenta")
            console.print(Align.center(reset_line))
            pending_reset = False
        pos_order, grouped, totals = payload  # type: ignore[misc]
        _print_table(console, pos_order, grouped, totals)
