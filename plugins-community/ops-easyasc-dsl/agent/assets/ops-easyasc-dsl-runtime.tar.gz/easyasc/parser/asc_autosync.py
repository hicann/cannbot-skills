from typing import Dict, Iterable, List, Optional, Set, Tuple, Literal, Union
from functools import lru_cache

from .asc_utils import build_expr_state, should_skip_inst
from ..utils.events import DEvent, QEvent, SEvent, TEvent
from .asc_handlers import build_handlers
from ..utils.Tensor import DBuff, QBuff, TBuff, Tensor
from ..utils.instruction import Instruction
from ..utils.pipe import Pipe, PipeType
from ..utils.positions import Position
from ..utils.sync_key import SyncKey, SyncKeyGroup, collect_tensor_sync_keys, normalize_sync_key_group
from .. import globvars
from ..device_profile import is_c220_family


_AUTO_SYNC_START = "start_auto_sync"
_AUTO_SYNC_END = "end_auto_sync"
_EXPLICIT_VEC_OPNAMES = {
    "abs",
    "add",
    "adds",
    "axpy",
    "brcb",
    "transdata5hd",
    "call_micro",
    "call_simt",
    "cadd",
    "cast",
    "cgadd",
    "cgmax",
    "cgmin",
    "cmax",
    "cmin",
    "compare",
    "compare_scalar",
    "cpadd",
    "div",
    "dup",
    "exp",
    "gather",
    "gather_block",
    "gm_to_ub_pad",
    "gm_to_ub_nd_dma",
    "ln",
    "lrelu",
    "mergesort4",
    "mergesort_2seq",
    "mul",
    "muladddst",
    "muls",
    "rec",
    "relu",
    "reset_mask",
    "rsqrt",
    "scatter",
    "select",
    "set_atomic_type",
    "set_mask",
    "shiftls",
    "shiftrs",
    "sort32",
    "topk_radix",
    "sqrt",
    "sub",
    "ub_to_l1",
    "ub_to_l1_nz",
    "ub_to_l1_nd2nz",
    "ub_to_gm_pad",
    "ub_to_ub",
    "vand",
    "vmax",
    "vmaxs",
    "vmin",
    "vmins",
    "vnot",
    "vor",
}


@lru_cache(maxsize=1)
def get_pipe_opnames() -> Dict[str, Set[str]]:
    pipe_opnames: Dict[str, Set[str]] = {
        str(Pipe.MTE2): {"gm_to_l1_nd2nz", "gm_to_l1_dn2nz", "gm_to_l1_mx_scale_nd2nz", "gm_to_l1_pad", "gm_to_l1", "set_constant_to_l1", "gm_to_ub_pad", "gm_to_ub_nd_dma"},
        str(Pipe.MTE1): {"l1_to_l0", "l1_to_l0_mx", "l1_to_l0_img2col", "l1_to_bt"},
        str(Pipe.M): {"mmad", "mmad_mx"},
        str(Pipe.FIX): {"l0c_to_gm_nz2nd", "l0c_to_gm_nz2nz", "l0c_to_gm_nz2dn", "l0c_to_l1", "l0c_to_ub"},
        str(Pipe.MTE3): {"ub_to_gm_pad", "ub_to_l1", "ub_to_l1_nd2nz", "ub_to_l1_nz"},
    }
    vec_pipe_ops = set(_EXPLICIT_VEC_OPNAMES)
    for opnames in pipe_opnames.values():
        vec_pipe_ops -= opnames
    pipe_opnames[str(Pipe.V)] = vec_pipe_ops
    return pipe_opnames


PIPE_OPNAMES = get_pipe_opnames()
_PIPE_NAME_TO_TYPE: Dict[str, PipeType] = {
    str(Pipe.MTE2): Pipe.MTE2,
    str(Pipe.MTE1): Pipe.MTE1,
    str(Pipe.M): Pipe.M,
    str(Pipe.FIX): Pipe.FIX,
    str(Pipe.MTE3): Pipe.MTE3,
    str(Pipe.V): Pipe.V,
}
_OPNAME_TO_PIPE: Dict[str, PipeType] = {
    opname: _PIPE_NAME_TO_TYPE[pipe_name]
    for pipe_name, opnames in PIPE_OPNAMES.items()
    if pipe_name in _PIPE_NAME_TO_TYPE
    for opname in opnames
}
_EVENT_TYPES = (SEvent, DEvent, TEvent, QEvent)
_VEC_READ_FIELDS = ("src", "src1", "src2", "selmask", "offset", "idx")
_AUTO_SYNC_MODES = {"conservative", "aggressive", "fix_storage", "manual_fix"}
_CONTROL_BOUNDARY_OPS = {"start_loop", "end_loop", "start_if", "start_elif", "start_else", "end_if"}


def _collect_region_pipes(instructions: List[Instruction]) -> Set[PipeType]:
    used: Set[PipeType] = set()
    for inst in instructions:
        if not isinstance(inst, Instruction):
            continue
        pipe = _OPNAME_TO_PIPE.get(inst.opname)
        if pipe is not None:
            used.add(pipe)
    return used


def _is_c220_device() -> bool:
    device_type = str(getattr(globvars, "device_type", "")).lower()
    return is_c220_family(device_type)


def _collect_tensor_keys_from_fields(inst: Instruction, fields: Iterable[str]) -> Set[SyncKey]:
    keys: Set[SyncKey] = set()
    for field in fields:
        keys.update(collect_tensor_sync_keys(inst.kwargs.get(field, None)))
    return keys


def _scalar_sync_token(value: object) -> str:
    if hasattr(value, "value") and getattr(value, "value") is not None:
        return str(getattr(value, "value"))
    if hasattr(value, "name"):
        return str(getattr(value, "name"))
    if value is None:
        return ""
    return str(value)


def _tensor_storage_sync_key(tensor: object) -> Optional[SyncKey]:
    if not isinstance(tensor, Tensor):
        return None

    source_buf = getattr(tensor, "source_buf", None)
    source_index = getattr(tensor, "source_index", None)
    if isinstance(source_buf, (DBuff, TBuff, QBuff)):
        return (
            "buffer",
            type(source_buf).__name__,
            str(getattr(source_buf, "position", "")),
            str(getattr(source_buf, "name", "")),
            _scalar_sync_token(source_index),
        )

    storage_name = str(getattr(tensor, "storage_key_name", getattr(tensor, "name", "")))
    if not storage_name:
        return None
    return (
        "tensor",
        str(getattr(tensor, "position", "")),
        storage_name,
    )


def _collect_tensor_storage_sync_keys(value: object) -> Set[SyncKey]:
    result: Set[SyncKey] = set()

    def _visit(item: object) -> None:
        key = _tensor_storage_sync_key(item)
        if key is not None:
            result.add(key)
            return
        if isinstance(item, dict):
            for child in item.values():
                _visit(child)
            return
        if isinstance(item, (list, tuple, set)):
            for child in item:
                _visit(child)

    _visit(value)
    return result


def _normalize_shared_event_family_keys(keys: Iterable[SyncKey], buf_name: str) -> Optional[SyncKeyGroup]:
    shared_keys: Set[SyncKey] = set()
    for key in keys:
        if not key:
            continue
        # The conservative l0 family is about chaining reuse of the L0 operand
        # buffers across rounds. BT bias staging participates in the same
        # MTE1->M pipe pair but should not split the family between the init
        # tile (with bias) and later accumulate-only tiles.
        if buf_name == "l0":
            if key[0] == "buffer" and len(key) >= 4 and key[2] == str(Position.BT):
                continue
            if key[0] == "tensor" and len(key) >= 3 and key[1] == str(Position.BT):
                continue
        # Collapse DBuff/TBuff/QBuff slot rotation onto one family, but keep
        # distinct local buffers separate. This preserves the intended
        # "same backing buffer across nested scopes" chaining without merging
        # unrelated UB tensors into one event stream.
        if key[0] == "buffer" and len(key) >= 5:
            shared_keys.add(key[:4])
        else:
            shared_keys.add(key)
    return normalize_sync_key_group(shared_keys)


def _collect_vec_read_keys(inst: Instruction) -> Set[SyncKey]:
    if inst.opname in ("call_micro", "call_simt"):
        return set(inst.kwargs.get("read_sync_keys", ()))
    keys: Set[SyncKey] = set()
    for field in _VEC_READ_FIELDS:
        keys.update(_collect_tensor_storage_sync_keys(inst.kwargs.get(field, None)))
    return keys


def _collect_vec_write_keys(inst: Instruction) -> Set[SyncKey]:
    if inst.opname in ("call_micro", "call_simt"):
        return set(inst.kwargs.get("write_sync_keys", ()))
    keys = set(_collect_tensor_storage_sync_keys(inst.kwargs.get("dst", None)))
    # `select` stages the selMask address into tmp_addr_buf (Duplicate writes it, SetCmpMask
    # reads it back) before the actual Select. Treat that scratch as an additional write so
    # multiple selects reusing one buffer serialize (WAW) and nothing else aliases it
    # concurrently. Other ops carry no tmp_addr_buf kwarg, so this is a no-op for them.
    keys.update(_collect_tensor_storage_sync_keys(inst.kwargs.get("tmp_addr_buf", None)))
    return keys


def _is_vec_barrier(inst: Instruction) -> bool:
    return inst.opname == "barrier" and str(inst.kwargs.get("pipe", "")) == str(Pipe.V)


def _insert_b_device_vec_barriers(instructions: List[Instruction]) -> List[Instruction]:
    if not _is_c220_device():
        return instructions

    pending_reads: Set[SyncKey] = set()
    pending_writes: Set[SyncKey] = set()
    result: List[Instruction] = []
    for inst in instructions:
        if _is_vec_barrier(inst):
            pending_reads.clear()
            pending_writes.clear()
            result.append(inst)
            continue

        inst_pipe = _OPNAME_TO_PIPE.get(inst.opname)
        if inst_pipe is Pipe.V:
            read_keys = _collect_vec_read_keys(inst)
            write_keys = _collect_vec_write_keys(inst)
            has_raw = pending_writes and pending_writes.intersection(read_keys)
            has_war = pending_reads and pending_reads.intersection(write_keys)
            has_waw = pending_writes and pending_writes.intersection(write_keys)
            if has_raw or has_war or has_waw:
                result.append(Instruction("barrier", pipe=Pipe.V))
                pending_reads.clear()
                pending_writes.clear()
            result.append(inst)
            pending_reads.update(read_keys)
            pending_writes.update(write_keys)
            continue

        result.append(inst)
    return result


def _l0_storage_event_kind(key: SyncKey) -> str:
    return "double" if key and key[0] == "buffer" else "single"


def _append_l0_aggressive_burst_groups(
    burst_keys: Set[SyncKey],
    burst_groups: List[Set[SyncKey]],
) -> None:
    if not burst_keys:
        return
    by_kind: Dict[str, Set[SyncKey]] = {}
    for key in burst_keys:
        by_kind.setdefault(_l0_storage_event_kind(key), set()).add(key)
    for group in by_kind.values():
        if group:
            burst_groups.append(group)
    burst_keys.clear()


def _collect_l0_aggressive_key_groups(instructions: Iterable[Instruction]) -> List[Set[SyncKey]]:
    burst_groups: List[Set[SyncKey]] = []
    burst_keys: Set[SyncKey] = set()
    first_seen: Dict[SyncKey, int] = {}

    def _remember(keys: Set[SyncKey]) -> None:
        for key in keys:
            if key not in first_seen:
                first_seen[key] = len(first_seen)

    for inst in instructions:
        if not isinstance(inst, Instruction):
            continue
        if inst.opname in ("l1_to_l0", "l1_to_l0_mx", "l1_to_l0_img2col"):
            keys = _collect_tensor_storage_sync_keys(inst.kwargs.get("dst", None))
            _remember(keys)
            burst_keys.update(keys)
        elif inst.opname in ("mmad", "mmad_mx"):
            _append_l0_aggressive_burst_groups(burst_keys, burst_groups)
        elif inst.opname in _CONTROL_BOUNDARY_OPS:
            _append_l0_aggressive_burst_groups(burst_keys, burst_groups)
    _append_l0_aggressive_burst_groups(burst_keys, burst_groups)

    parent: Dict[SyncKey, SyncKey] = {}

    def _find(key: SyncKey) -> SyncKey:
        parent.setdefault(key, key)
        if parent[key] != key:
            parent[key] = _find(parent[key])
        return parent[key]

    def _union(lhs: SyncKey, rhs: SyncKey) -> None:
        lhs_root = _find(lhs)
        rhs_root = _find(rhs)
        if lhs_root != rhs_root:
            parent[rhs_root] = lhs_root

    for group in burst_groups:
        ordered = sorted(group, key=lambda key: first_seen.get(key, 0))
        if not ordered:
            continue
        head = ordered[0]
        _find(head)
        for key in ordered[1:]:
            _union(head, key)

    components: Dict[SyncKey, Set[SyncKey]] = {}
    for key in first_seen:
        root = _find(key)
        components.setdefault(root, set()).add(key)

    groups = list(components.values())
    groups.sort(key=lambda group: min(first_seen[key] for key in group))
    return groups


def _insert_l0_aggressive_auto_sync(
    instructions: List[Instruction],
    key_registry: Dict[SyncKeyGroup, int],
) -> Tuple[List[Instruction], List[Instruction]]:
    event_creation: List[Instruction] = []
    key_groups = _collect_l0_aggressive_key_groups(instructions)
    for key_group in key_groups:
        instructions = AutosyncNode(
            instructions,
            Pipe.MTE1,
            Pipe.M,
            False,
            True,
            False,
            False,
            "l0",
            sync_key_filter=key_group,
            use_storage_keys=True,
            eager_consumer_release=True,
        ).assign_buf_indices(key_registry).insert_auto_sync_inst().get_instructions().create_events(event_creation)
    return instructions, event_creation


def _collect_fix_storage_key_groups(instructions: Iterable[Instruction]) -> List[Set[SyncKey]]:
    """Group M->Fix ownership by the physical L0C backing allocation.

    Conservative autosync deliberately keys nested control regions by scope.
    That can serialize unrelated L0C buffers and, conversely, fail to connect
    two runtime branches that access different views of the same DBuff.  The
    fix-storage path instead gives each backing L0C family one event lineage.
    """
    groups: Dict[SyncKey, Set[SyncKey]] = {}
    first_seen: Dict[SyncKey, int] = {}
    for inst in instructions:
        if not isinstance(inst, Instruction):
            continue
        pipe = _OPNAME_TO_PIPE.get(inst.opname)
        if pipe is Pipe.M:
            keys = _collect_tensor_storage_sync_keys(inst.kwargs.get("dst", None))
        elif pipe is Pipe.FIX:
            keys = _collect_tensor_storage_sync_keys(inst.kwargs.get("src", None))
        else:
            continue
        for key in keys:
            family = key[:4] if key and key[0] == "buffer" and len(key) >= 5 else key
            if family not in first_seen:
                first_seen[family] = len(first_seen)
            groups.setdefault(family, set()).add(key)
    return [groups[key] for key in sorted(groups, key=first_seen.__getitem__)]


def _insert_fix_storage_auto_sync(
    instructions: List[Instruction],
    key_registry: Dict[SyncKeyGroup, int],
) -> Tuple[List[Instruction], List[Instruction]]:
    event_creation: List[Instruction] = []
    for key_group in _collect_fix_storage_key_groups(instructions):
        instructions = AutosyncNode(
            instructions,
            Pipe.M,
            Pipe.FIX,
            False,
            False,
            True,
            False,
            "fix",
            sync_key_filter=key_group,
            use_storage_keys=True,
            shared_event_family=True,
        ).assign_buf_indices(key_registry).insert_auto_sync_inst().get_instructions().create_events(event_creation)
    return instructions, event_creation


class AutosyncNode:
    def __init__(
        self,
        instructions: List[Instruction],
        src_pipe: PipeType,
        dst_pipe: PipeType,
        producer_src: bool,
        producer_dst: bool,
        consumer_src: bool,
        consumer_dst: bool,
        buf_name: str,
        sync_key_filter: Optional[Set[SyncKey]] = None,
        use_storage_keys: bool = False,
        eager_consumer_release: bool = False,
        shared_event_family: bool = False,
    ):
        self.insts = list(instructions)
        self.new_insts: List[Union[Instruction, "AutosyncNode"]] = []
        self.src_pipe = src_pipe
        self.dst_pipe = dst_pipe
        self.producer_src = producer_src
        self.producer_dst = producer_dst
        self.consumer_src = consumer_src
        self.consumer_dst = consumer_dst
        self.buf_idx = 0
        self.buf_name = buf_name
        self.events_to_be_created: List[str] = []
        self.has_inst = False
        self.is_mixed_scope = False
        self.is_single_buffer = False 
        self.used_pipes: Set[PipeType] = set()
        self.local_sync_keys: Set[SyncKey] = set()
        self.local_src_sync_keys: Set[SyncKey] = set()
        self.sync_key: Optional[SyncKeyGroup] = None
        self.local_pending_valid_carry_events: Dict[str, Union[SEvent, DEvent]] = {}
        self.pending_valid_carry_events: Dict[str, Union[SEvent, DEvent]] = {}
        self.sync_key_filter = sync_key_filter
        self.use_storage_keys = use_storage_keys
        self.eager_consumer_release = eager_consumer_release
        self.shared_event_family = shared_event_family
        self.pre_process()
        self.summarize_used_pipes()

    def _configure_sync_event(self, event: Union[SEvent, DEvent], is_valid: bool) -> None:
        if is_valid:
            event.src_pipe = self.dst_pipe
            event.dst_pipe = self.src_pipe
            event.preset = True
            event.idx = 9999
        else:
            event.src_pipe = self.src_pipe
            event.dst_pipe = self.dst_pipe
            event.preset = False
            event.idx = 9998

    def _registry_sync_key(self) -> SyncKeyGroup:
        if self.shared_event_family:
            # Chain nested ownership across slot rotation of the SAME backing
            # buffer family, without collapsing unrelated tensors that happen to
            # use the same pipe pair inside one auto_sync region.
            # Use keys produced directly by this scope. A parent-preloaded buffer
            # may also be consumed inside a child that produces a DIFFERENT
            # buffer; including all child-side reads would incorrectly merge the
            # two ownership streams (for example state + per-iteration token).
            owned_keys = self.local_src_sync_keys or self.local_sync_keys
            family_keys = _normalize_shared_event_family_keys(owned_keys, self.buf_name)
            if family_keys is not None:
                return (("family", self.buf_name, str(self.src_pipe), str(self.dst_pipe)),) + family_keys
            return (("family", self.buf_name, str(self.src_pipe), str(self.dst_pipe)),)
        if self.sync_key is not None:
            return self.sync_key
        return (("scope", self.buf_name, str(id(self))),)

    def _has_split_child_roundtrip(self) -> bool:
        has_src_only = False
        has_dst_only = False
        for item in self.new_insts:
            if not isinstance(item, AutosyncNode):
                continue
            child_has_src = self.src_pipe in item.used_pipes
            child_has_dst = self.dst_pipe in item.used_pipes
            if child_has_src and not child_has_dst:
                has_src_only = True
            elif child_has_dst and not child_has_src:
                has_dst_only = True
            if has_src_only and has_dst_only:
                return True
        return False

    def assign_buf_indices(self, key_registry: Optional[Dict[SyncKeyGroup, int]] = None):
        if key_registry is None:
            key_registry = {}
        if self.is_mixed_scope:
            sync_key = self._registry_sync_key()
            if sync_key not in key_registry and self.shared_event_family and len(sync_key) > 1:
                family_tag = sync_key[0]
                local_keys = set(sync_key[1:])
                matched_idx = None
                for registered_key, registered_idx in key_registry.items():
                    if (
                        len(registered_key) > 1
                        and registered_key[0] == family_tag
                        and local_keys.intersection(registered_key[1:])
                    ):
                        matched_idx = registered_idx
                        break
                if matched_idx is not None:
                    key_registry[sync_key] = matched_idx
            if sync_key not in key_registry:
                key_registry[sync_key] = max(key_registry.values(), default=-1) + 1
            self.buf_idx = key_registry[sync_key]
        for inst in self.new_insts:
            if isinstance(inst, AutosyncNode):
                inst.assign_buf_indices(key_registry)
        return self 

    def _collect_inst_sync_keys(self, inst: Instruction, pipe: Optional[PipeType]) -> Set[SyncKey]:
        if pipe is None:
            return set()
        collect_keys = _collect_tensor_storage_sync_keys if self.use_storage_keys else collect_tensor_sync_keys
        if inst.opname in ("call_micro", "call_simt"):
            if pipe == self.src_pipe:
                if self.src_pipe == Pipe.V:
                    return set(inst.kwargs.get("write_sync_keys", ()))
                return set(inst.kwargs.get("read_sync_keys", ()))
            if pipe == self.dst_pipe:
                if self.dst_pipe == Pipe.V:
                    return set(inst.kwargs.get("read_sync_keys", ()))
                return set(inst.kwargs.get("write_sync_keys", ()))
            return set()

        if pipe == self.src_pipe:
            if pipe in (Pipe.MTE2, Pipe.MTE1, Pipe.V, Pipe.M):
                return collect_keys(inst.kwargs.get("dst", None))
            return set()

        if pipe == self.dst_pipe:
            if pipe == Pipe.M:
                keys = set()
                keys.update(collect_keys(inst.kwargs.get("src_a", None)))
                keys.update(collect_keys(inst.kwargs.get("src_b", None)))
                # mmad bias (BT/C2) is read on the M pipe; collect_keys(None) is a
                # no-op for the common bias-less mmad.
                keys.update(collect_keys(inst.kwargs.get("bias", None)))
                return keys
            if pipe == Pipe.MTE1 and inst.opname == "l1_to_l0_mx":
                keys = set()
                keys.update(collect_keys(inst.kwargs.get("src", None)))
                keys.update(collect_keys(inst.kwargs.get("src_mx", None)))
                return keys
            if pipe in (Pipe.V, Pipe.MTE1, Pipe.FIX, Pipe.MTE3):
                return collect_keys(inst.kwargs.get("src", None))
            return set()

        return set()

    def _filter_sync_keys(self, keys: Set[SyncKey]) -> Set[SyncKey]:
        if self.sync_key_filter is None:
            return keys
        return keys.intersection(self.sync_key_filter)

    def _instruction_matches_pipe(self, inst: Instruction, pipe: PipeType) -> bool:
        if self.sync_key_filter is None:
            return True
        return bool(self._filter_sync_keys(self._collect_inst_sync_keys(inst, pipe)))

    def _relevant_pipes_for_item(self, item: Union[Instruction, "AutosyncNode"]) -> Set[PipeType]:
        if isinstance(item, AutosyncNode):
            return {pipe for pipe in item.used_pipes if pipe in (self.src_pipe, self.dst_pipe)}
        pipe = _OPNAME_TO_PIPE.get(item.opname)
        if pipe is None or pipe not in (self.src_pipe, self.dst_pipe):
            return set()
        if not self._instruction_matches_pipe(item, pipe):
            return set()
        return {pipe}

    def _future_has_dst_before_src(self, start_idx: int) -> bool:
        for item in self.new_insts[start_idx:]:
            pipes = self._relevant_pipes_for_item(item)
            if self.src_pipe in pipes:
                return False
            if self.dst_pipe in pipes:
                return True
        return False

    def summarize_used_pipes(self):
        used = self.used_pipes
        op_to_pipe = _OPNAME_TO_PIPE
        src_pipe = self.src_pipe
        dst_pipe = self.dst_pipe
        producer_src = self.producer_src
        producer_dst = self.producer_dst
        consumer_src = self.consumer_src
        consumer_dst = self.consumer_dst
        is_single_buffer = self.is_single_buffer
        for inst in self.new_insts:
            if isinstance(inst, AutosyncNode):
                if inst.used_pipes:
                    used.update(inst.used_pipes)
                if inst.is_single_buffer:
                    is_single_buffer = True
                continue
            if not isinstance(inst, Instruction):
                continue
            pipe = op_to_pipe.get(inst.opname)
            if pipe is not None and pipe in [self.src_pipe, self.dst_pipe]:
                inst_sync_keys = self._filter_sync_keys(self._collect_inst_sync_keys(inst, pipe))
                if self.sync_key_filter is not None and not inst_sync_keys:
                    continue
                used.add(pipe)
                self.has_inst = True
                self.local_sync_keys.update(inst_sync_keys)
                if pipe == src_pipe:
                    self.local_src_sync_keys.update(inst_sync_keys)
                if pipe == src_pipe:
                    if producer_src:
                        src = inst.kwargs.get("src")
                        if isinstance(src, Tensor):
                            source_buf = src.source_buf
                            if source_buf is None or isinstance(source_buf, Tensor):
                                is_single_buffer = True
                    if not is_single_buffer and producer_dst:
                        dst = inst.kwargs.get("dst")
                        if isinstance(dst, Tensor):
                            source_buf = dst.source_buf
                            if source_buf is None or isinstance(source_buf, Tensor):
                                is_single_buffer = True
                elif pipe == dst_pipe:
                    if consumer_src:
                        src = inst.kwargs.get("src")
                        if isinstance(src, Tensor):
                            source_buf = src.source_buf
                            if source_buf is None or isinstance(source_buf, Tensor):
                                is_single_buffer = True
                    if not is_single_buffer and consumer_dst:
                        dst = inst.kwargs.get("dst")
                        if isinstance(dst, Tensor):
                            source_buf = dst.source_buf
                            if source_buf is None or isinstance(source_buf, Tensor):
                                is_single_buffer = True
        self.is_single_buffer = is_single_buffer
        self.sync_key = normalize_sync_key_group(self.local_sync_keys)
        self.is_mixed_scope = len(used) == 2 and (self.has_inst or self._has_split_child_roundtrip())

    def pre_process(self):
        insts = self.insts
        new_insts = self.new_insts
        n = len(insts)
        if n == 0:
            return
        start_loop = "start_loop"
        end_loop = "end_loop"
        if_starts = ("start_if",)
        end_if = "end_if"

        def _find_loop_end(idx: int) -> Optional[int]:
            depth = 1
            while idx < n:
                op = insts[idx].opname
                if op == start_loop:
                    depth += 1
                elif op == end_loop:
                    depth -= 1
                    if depth == 0:
                        return idx
                idx += 1
            return None

        def _find_if_end(idx: int) -> Optional[int]:
            depth = 1
            while idx < n:
                op = insts[idx].opname
                if op in if_starts:
                    depth += 1
                elif op == end_if:
                    depth -= 1
                    if depth == 0:
                        return idx
                idx += 1
            return None

        i = 0
        while i < n:
            if i==0 and (insts[i].opname==start_loop or insts[i].opname in if_starts):
                new_insts.append(insts[i])
                i += 1
                continue
            inst = insts[i]
            op = inst.opname
            if op == start_loop:
                end_idx = _find_loop_end(i + 1)
                if end_idx is None:
                    new_insts.extend(insts[i:])
                    break
                body = insts[i:end_idx + 1]
                sub_insts = AutosyncNode(
                    body,
                    self.src_pipe,
                    self.dst_pipe,
                    self.producer_src,
                    self.producer_dst,
                    self.consumer_src,
                    self.consumer_dst,
                    self.buf_name,
                    self.sync_key_filter,
                    self.use_storage_keys,
                    self.eager_consumer_release,
                    self.shared_event_family,
                )
                new_insts.append(sub_insts)
                i = end_idx + 1
                continue
            if op in if_starts:
                end_idx = _find_if_end(i + 1)
                if end_idx is None:
                    new_insts.extend(insts[i:])
                    break
                body = insts[i:end_idx + 1]
                sub_insts = AutosyncNode(
                    body,
                    self.src_pipe,
                    self.dst_pipe,
                    self.producer_src,
                    self.producer_dst,
                    self.consumer_src,
                    self.consumer_dst,
                    self.buf_name,
                    self.sync_key_filter,
                    self.use_storage_keys,
                    self.eager_consumer_release,
                    self.shared_event_family,
                )
                new_insts.append(sub_insts)
                i = end_idx + 1
                continue
            new_insts.append(inst)
            i += 1
    
    def insert_auto_sync_inst(self):
        self.local_pending_valid_carry_events = {}
        if not self.is_mixed_scope:
            return self

        is_control_subregion = bool(self.insts) and self.insts[0].opname in ("start_loop", "start_if")
        
        if self.is_single_buffer:
            event_valid: Union[SEvent, DEvent] = object.__new__(SEvent)
            event_valid.name = f"_tmp_sevent_valid_{self.buf_name}_{self.buf_idx}"
            self._configure_sync_event(event_valid, is_valid=True)
            self.events_to_be_created.append(event_valid.name)
            event_ready: Union[SEvent, DEvent] = object.__new__(SEvent)
            event_ready.name = f"_tmp_sevent_ready_{self.buf_name}_{self.buf_idx}"
            self._configure_sync_event(event_ready, is_valid=False)
            self.events_to_be_created.append(event_ready.name)
        else:
            event_valid: Union[SEvent, DEvent] = object.__new__(DEvent)
            event_valid.name = f"_tmp_devent_valid_{self.buf_name}_{self.buf_idx}"
            self._configure_sync_event(event_valid, is_valid=True)
            self.events_to_be_created.append(event_valid.name)
            event_ready: Union[SEvent, DEvent] = object.__new__(DEvent)
            event_ready.name = f"_tmp_devent_ready_{self.buf_name}_{self.buf_idx}"
            self._configure_sync_event(event_ready, is_valid=False)
            self.events_to_be_created.append(event_ready.name)

        valid_wait_inst = Instruction(opname="event_wait", event=event_valid)
        valid_set_inst = Instruction(opname="event_set", event=event_valid)
        ready_wait_inst = Instruction(opname="event_wait", event=event_ready)
        ready_set_inst = Instruction(opname="event_set", event=event_ready)


        declared = False 
        changed = False
        result: List[Union[Instruction, "AutosyncNode"]] = []
        for item_idx, i in enumerate(self.new_insts):
            item_consumed_dst = False
            if isinstance(i, AutosyncNode):
                child_has_src = self.src_pipe in i.used_pipes
                child_has_dst = self.dst_pipe in i.used_pipes
                if child_has_src and child_has_dst:
                    same_event_family = i.buf_idx == self.buf_idx
                    # A nested mixed-scope node already owns its internal src/dst
                    # handshake. Re-wrapping it at the parent scope can create a
                    # dangling ready/valid pair after the child loop ends.
                    #
                    # The parent may still have an outstanding producer token
                    # before entering the child. In that case the child's dst-side
                    # work closes the parent handshake, but the child remains
                    # responsible for its own internal buffering/events.
                    if same_event_family and declared and not changed:
                        result.append(ready_set_inst)
                        result.append(ready_wait_inst)
                        declared = False
                        changed = True
                        item_consumed_dst = True
                    elif not same_event_family and declared and not changed:
                        result.append(ready_set_inst)
                        result.append(ready_wait_inst)
                        declared = False
                        changed = True
                        item_consumed_dst = True
                    elif same_event_family and changed and not declared:
                        # Parent already finished a prior src->dst round, so the
                        # next producer round must republish valid before handing
                        # control to a child that owns both sides of the same
                        # event family. The child will perform the matching
                        # valid.wait for its own producer-side work.
                        result.append(valid_set_inst)
                        changed = False
                    # A both-pipe child can also PRODUCE a buffer that this parent
                    # scope consumes only AFTER the child (e.g. produced inside an
                    # if/for, stored once the block exits). That leaked producer is
                    # not balanced by the child's own internal consumer, so the
                    # child's handshake does not cover it. When a dangling consumer
                    # follows in this scope, open a parent-level producer window
                    # here so the later store is protected; the child keeps owning
                    # its own internal events.
                    if (
                        not item_consumed_dst
                        and not declared
                        and self._future_has_dst_before_src(item_idx + 1)
                    ):
                        if changed:
                            result.append(valid_set_inst)
                            changed = False
                        result.append(valid_wait_inst)
                        declared = True
                    result.append(i)
                    continue
                if child_has_src and changed and not declared:
                    result.append(valid_set_inst)
                    result.append(valid_wait_inst)
                    declared = True
                    changed = False
                elif child_has_src and not declared:
                    result.append(valid_wait_inst)
                    declared = True
                elif child_has_dst and declared and not changed:
                    result.append(ready_set_inst)
                    result.append(ready_wait_inst)
                    declared = False
                    changed = True
                    item_consumed_dst = True
                result.append(i)
            else:
                if not isinstance(i, Instruction):
                    raise TypeError("Expected Instruction or AutosyncNode")
                if i.opname in ("start_else", "start_elif") and changed and not declared:
                    result.append(valid_set_inst)
                    changed = False
                    result.append(i)
                    continue
                pipe = _OPNAME_TO_PIPE.get(i.opname)
                if pipe is not None:
                    inst_sync_keys = self._filter_sync_keys(self._collect_inst_sync_keys(i, pipe))
                    if self.sync_key_filter is not None and not inst_sync_keys:
                        result.append(i)
                        continue
                    if pipe == self.src_pipe and changed and not declared:
                        result.append(valid_set_inst)
                        result.append(valid_wait_inst)
                        declared = True
                        changed = False
                    elif pipe == self.src_pipe and not declared:
                        result.append(valid_wait_inst)
                        declared = True
                    elif pipe == self.dst_pipe and declared and not changed:
                        result.append(ready_set_inst)
                        result.append(ready_wait_inst)
                        declared = False
                        changed = True
                        item_consumed_dst = True
                result.append(i)

            if (
                self.eager_consumer_release
                and item_consumed_dst
                and changed
                and not declared
                and not self._future_has_dst_before_src(item_idx + 1)
            ):
                result.append(valid_set_inst)
                changed = False
            
        if changed:
            tail_opname = result[-1].opname if result else ""
            internal_valid_set_count = sum(
                1
                for inst in result
                if isinstance(inst, Instruction)
                and inst.opname == "event_set"
                and inst.kwargs.get("event", None) is not None
                and inst.kwargs["event"].name == event_valid.name
            )
            if (
                is_control_subregion
                and self.is_single_buffer
                and tail_opname in ("end_loop", "end_if")
                and internal_valid_set_count >= 2
            ):
                # Some single-buffer control subregions already republish valid
                # multiple times before leaving the subregion. In those cases an
                # extra tail valid.set leaves the single-event flag published
                # across control-flow re-entry and the next round's prefix
                # valid.set becomes a duplicate already-set error.
                self.local_pending_valid_carry_events[event_valid.name] = event_valid
            elif tail_opname not in ['end_loop', 'end_if']:
                result.append(valid_set_inst)
            else:
                result.insert(-1, valid_set_inst)
        if declared:
            if result[-1].opname not in ['end_loop', 'end_if']:
                result.append(ready_set_inst)
                result.append(ready_wait_inst)
                result.append(valid_set_inst)
            else:
                result.insert(-1, ready_set_inst)
                result.insert(-1, ready_wait_inst)
                result.insert(-1, valid_set_inst)
            # Nested loop/if regions often end with a producer-side carry that this
            # pass already closes by inserting a local ready/wait/valid tail. That
            # conservative auto-close is noisy but not actionable for users, so we
            # keep the synthesized closure and only warn on non-control subregions.
            if not is_control_subregion:
                print('WARNING: NOT balanced auto_sync events, please check the code logic!')
        
        self.new_insts = result
        return self

    def get_instructions(self):
        result: List[Union[Instruction, "AutosyncNode"]] = []
        child_pending_valid_carry_events: Dict[str, Union[SEvent, DEvent]] = {}

        def _insert_pending_valid_before(end_opname: str, events: Dict[str, Union[SEvent, DEvent]]) -> None:
            end_idx = None
            for idx in range(len(result) - 1, -1, -1):
                inst = result[idx]
                if isinstance(inst, Instruction) and inst.opname == end_opname:
                    end_idx = idx
                    break
            if end_idx is None:
                raise RuntimeError(f"pending control-flow carry requires {end_opname} in expanded child instructions")
            insert_pos = end_idx
            for event in events.values():
                result.insert(insert_pos, Instruction(opname="event_set", event=event))
                insert_pos += 1

        for i in self.new_insts:
            if isinstance(i, AutosyncNode):
                child = i.insert_auto_sync_inst().get_instructions()
                child_start_opname = child.insts[0].opname if child.insts else ""
                result.extend(child.new_insts)
                self.events_to_be_created.extend(child.events_to_be_created)
                if child.pending_valid_carry_events and child_start_opname == "start_if":
                    _insert_pending_valid_before("end_if", child.pending_valid_carry_events)
                elif child.pending_valid_carry_events and child_start_opname == "start_loop":
                    _insert_pending_valid_before("end_loop", child.pending_valid_carry_events)
                elif child.pending_valid_carry_events:
                    for event in child.pending_valid_carry_events.values():
                        result.append(Instruction(opname="event_set", event=event))
                else:
                    child_pending_valid_carry_events.update(child.pending_valid_carry_events)
            else:
                result.append(i)

        self.pending_valid_carry_events = dict(self.local_pending_valid_carry_events)
        self.pending_valid_carry_events.update(child_pending_valid_carry_events)
        self.new_insts = result
        return self 

    def create_events(self, full_instructions: List[Instruction]):
        # Event constructors allocate hardware event IDs in declaration order.
        # Preserve the first traced occurrence while removing duplicates; a
        # plain set makes generated source and device timing depend on
        # PYTHONHASHSEED.
        seen_event_names: Set[str] = set()
        for name in self.events_to_be_created:
            if name in seen_event_names:
                continue
            seen_event_names.add(name)
            if name.startswith("_tmp_sevent"):
                event: Union[SEvent, DEvent] = object.__new__(SEvent)
            else:
                event = object.__new__(DEvent)

            event.name = name
            self._configure_sync_event(event, is_valid=('valid' in name))

            if name.startswith("_tmp_sevent"):
                event_create_inst = Instruction(opname="create_sevent", val=event)
            else:
                event_create_inst = Instruction(opname="create_devent", val=event)
            full_instructions.append(event_create_inst)
        return self.new_insts


def _insert_autosync_node(
    instructions: List[Instruction],
    mode: Literal['cube', 'vec'],
    auto_sync_mode: str = "conservative",
    key_registries: Optional[Dict[str, Dict[SyncKeyGroup, int]]] = None,
) -> Tuple[List[Instruction], List[Instruction]]:
    if key_registries is None:
        key_registries = {}
    if auto_sync_mode not in _AUTO_SYNC_MODES:
        raise ValueError(f"auto_sync mode must be one of {sorted(_AUTO_SYNC_MODES)}, got: {auto_sync_mode!r}")
    event_creation: List[Instruction] = []
    if mode == 'vec':
        region_pipes = {
            pipe for pipe in _collect_region_pipes(instructions)
            if pipe in (Pipe.MTE2, Pipe.V, Pipe.MTE3)
        }
        if region_pipes == {Pipe.MTE2, Pipe.MTE3}:
            registry = key_registries.setdefault("ubrelay", {})
            instructions = AutosyncNode(
                instructions, Pipe.MTE2, Pipe.MTE3, False, True, True, False, 'ubrelay'
            ).assign_buf_indices(registry).insert_auto_sync_inst().get_instructions().create_events(event_creation)
        else:
            registry = key_registries.setdefault("ubin", {})
            instructions = AutosyncNode(
                instructions,
                Pipe.MTE2,
                Pipe.V,
                False,
                True,
                False,
                False,
                'ubin',
                # Nested MTE2->V ownership should stay on one UB input family
                # even when the local DBuff slot index rotates across scopes.
                shared_event_family=True,
            ).assign_buf_indices(registry).insert_auto_sync_inst().get_instructions().create_events(event_creation)
            registry = key_registries.setdefault("ubout", {})
            instructions = AutosyncNode(
                instructions, Pipe.V, Pipe.MTE3, False, False, True, False, 'ubout'
            ).assign_buf_indices(registry).insert_auto_sync_inst().get_instructions().create_events(event_creation)
    else:
        registry = key_registries.setdefault("l1", {})
        instructions = AutosyncNode(
            instructions,
            Pipe.MTE2,
            Pipe.MTE1,
            False,
            True,
            False,
            False,
            'l1',
            # A DBuff reused by an outer cube round and a nested loop still has
            # one physical two-slot ownership stream. Reuse the same event
            # family across those scopes so independent preset tokens cannot
            # let MTE2 overwrite a slot before MTE1 consumes the prior tile.
            shared_event_family=True,
        ).assign_buf_indices(registry).insert_auto_sync_inst().get_instructions().create_events(event_creation)
        registry = key_registries.setdefault("l0", {})
        if auto_sync_mode == "aggressive":
            instructions, l0_event_creation = _insert_l0_aggressive_auto_sync(instructions, registry)
            event_creation.extend(l0_event_creation)
        else:
            instructions = AutosyncNode(
                instructions,
                Pipe.MTE1,
                Pipe.M,
                False,
                True,
                False,
                False,
                'l0',
                # One conservative L0 family prevents a future outer-tile
                # producer from reusing a sibling slot before the current
                # nested M round has consumed it.
                shared_event_family=True,
            ).assign_buf_indices(registry).insert_auto_sync_inst().get_instructions().create_events(event_creation)
        if auto_sync_mode != "manual_fix":
            registry = key_registries.setdefault("fix", {})
            if auto_sync_mode in ("aggressive", "fix_storage"):
                instructions, fix_event_creation = _insert_fix_storage_auto_sync(instructions, registry)
                event_creation.extend(fix_event_creation)
            else:
                instructions = AutosyncNode(
                    instructions, Pipe.M, Pipe.FIX, False, False, True, False, 'fix'
                ).assign_buf_indices(registry).insert_auto_sync_inst().get_instructions().create_events(event_creation)
    return instructions, event_creation


def insert_auto_sync(instructions: List[Instruction], mode: Literal['cube', 'vec']) -> List[Instruction]:
    if mode not in ['cube', 'vec']:
        raise ValueError("mode must be either 'cube' or 'vec'")
    
    insts = list(instructions)
    if not insts:
        return insts
    result: List[Instruction] = []
    tmp_insts: List[Instruction] = []
    curr_inst_list = result
    key_registries: Dict[str, Dict[SyncKeyGroup, int]] = {}
    current_auto_sync_mode = "conservative"

    for i in insts:
        if i.opname==_AUTO_SYNC_START:
            curr_inst_list = tmp_insts
            current_auto_sync_mode = i.kwargs.get("mode", "conservative")
            if current_auto_sync_mode not in _AUTO_SYNC_MODES:
                raise ValueError(
                    f"auto_sync mode must be one of {sorted(_AUTO_SYNC_MODES)}, got: {current_auto_sync_mode!r}"
                )
        curr_inst_list.append(i)
        if i.opname==_AUTO_SYNC_END:
            tmp_insts_with_autosync, event_creation = _insert_autosync_node(
                tmp_insts,
                mode,
                current_auto_sync_mode,
                key_registries,
            )
            if mode == 'vec':
                tmp_insts_with_autosync = _insert_b_device_vec_barriers(tmp_insts_with_autosync)
            result.extend(tmp_insts_with_autosync)
            result = event_creation + result
            curr_inst_list = result
            tmp_insts = []
            current_auto_sync_mode = "conservative"
    return result
