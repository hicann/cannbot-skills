import builtins
from typing import Iterator, Union, Optional, Any

from .utils.var import Var
from .utils.instruction import Instruction
from . import globvars


def unroll(*args):
    return builtins.range(*args)


def _validate_range_arg(value: Union[Var, int], label: str) -> None:
    if not isinstance(value, (int, Var)):
        raise TypeError(f"{label} must be int or Var, got: {type(value)}")


def range(*args: Union[Var, int], name: str = "") -> Iterator[Var]:
    if not isinstance(name, str):
        raise TypeError(f"name must be str, got: {type(name)}")

    if len(args) == 1:
        start: Union[Var, int] = 0
        stop: Union[Var, int] = args[0]
        step: Union[Var, int] = 1
    elif len(args) == 2:
        start = args[0]
        stop = args[1]
        step = 1
    elif len(args) == 3:
        start, stop, step = args
    else:
        raise TypeError("range expected 1-3 positional arguments")

    _validate_range_arg(start, "start")
    _validate_range_arg(stop, "stop")
    _validate_range_arg(step, "step")
    if isinstance(step, int) and step == 0:
        raise ValueError("range() arg 3 must not be zero")
    if isinstance(step, Var) and isinstance(step.value, int) and step.value == 0:
        raise ValueError("range() arg 3 must not be zero")

    if isinstance(start, Var):
        start_value = start.value if not isinstance(start.value, Var) else None
        loop_var = Var(value=start_value, dtype=start.dtype, name=name)
    else:
        loop_var = Var(value=start, name=name)
    loop_var._is_loop_var = True

    target = None
    start_opname = "start_loop"
    if globvars.active_micro is not None:
        target = globvars.active_micro
        start_opname = "start_micro_loop"
        # The AIV scalar unit cannot convert this counter to float; var_op
        # tracks the taint so the trace-time check can fire where the board
        # compiler would otherwise fail with no line number.
        loop_var._is_micro_loop_var = True
    elif globvars.active_kernel is not None:
        target = globvars.active_kernel

    entry_vec_mode = _current_vector_mode()
    if target is not None:
        target.instructions.append(
            Instruction(start_opname, var=loop_var, start=start, stop=stop, step=step)
        )

    try:
        yield loop_var
    finally:
        if target is not None:
            target.instructions.append(
                Instruction("end_loop", var=loop_var)
            )
            # If the loop body switched the vec unit into count mode, restore normal
            # mode *once after the loop* (this reset is emitted after end_loop, i.e.
            # outside the loop body, so it is not paid per iteration). Without it count
            # mode leaks past the loop into external repeat-mode ops on the >=1-iter
            # path. Mirrors the if/elif/else arm-exit reset, including the entry!=count
            # guard (a pre-loop count mode is owned by external straight-line code).
            _reset_count_mode_if_triggered(entry_vec_mode)


def break_() -> None:
    target = _get_flow_target()
    if target is None:
        raise RuntimeError("break_ can only be used inside kernel or micro")
    target.instructions.append(Instruction("break_loop"))


def continue_() -> None:
    target = _get_flow_target()
    if target is None:
        raise RuntimeError("continue_ can only be used inside kernel or micro")
    target.instructions.append(Instruction("continue_loop"))


def _pop_last_end_if() -> None:
    target = _get_flow_target()
    if target is None:
        raise RuntimeError("If/Elif/Else can only be used inside kernel or micro")
    if not target.instructions:
        raise RuntimeError("Elif/Else must follow If/Elif")
    last = target.instructions[-1]
    if last.opname != "end_if":
        raise RuntimeError("Elif/Else must follow If/Elif")
    target.instructions.pop()


def _get_flow_target() -> Optional[Any]:
    if globvars.active_micro is not None:
        return globvars.active_micro
    if globvars.active_kernel is not None:
        return globvars.active_kernel
    return None


def _append_flow_instruction(opname: str, **kwargs: Any) -> None:
    target = _get_flow_target()
    if target is None:
        raise RuntimeError("If/Elif/Else can only be used inside kernel or micro")
    target.instructions.append(Instruction(opname, **kwargs))


def _current_vector_mode() -> Optional[str]:
    # The vec count/repeat mask mode is a kernel-level a2 concept; micros (a5
    # @vf) never enter count mode. Return None whenever count-mode bookkeeping
    # does not apply so the if/elif/else arms below stay a no-op there.
    if globvars.active_micro is not None:
        return None
    kernel = globvars.active_kernel
    if kernel is None:
        return None
    return getattr(kernel, "vector_mode", None)


def _reset_count_mode_if_triggered(entry_mode: Optional[str]) -> None:
    # Restore normal mask mode at an if/elif/else arm's exit, but only when the
    # arm itself switched the vec unit into count mode (entry was not "count",
    # exit is "count"). A `count=` op leaves the hardware in counter mask mode;
    # without this, on the runtime-taken arm that mode leaks past the construct
    # and the next external repeat-mode op misreads its mask. Emitting the reset
    # here keeps it *inside* the arm, so exactly one reset runs (on whichever arm
    # is taken) and arms that did not touch count mode stay untouched.
    #
    # The entry!="count" guard is essential: when count mode was already active
    # *before* the construct (leaked in from outside), resetting inside an arm
    # would move the reset that external straight-line code already emits into a
    # branch that may not be taken -> regression. In that case leave it alone.
    if entry_mode == "count":
        return
    if globvars.active_micro is not None:
        return
    kernel = globvars.active_kernel
    if kernel is None:
        return
    if getattr(kernel, "vector_mode", "repeat") == "count":
        kernel.instructions.append(Instruction("set_mask_normal"))
        kernel.vector_mode = "repeat"
        kernel.instructions.append(Instruction("reset_mask"))


def _validate_python_if_condition(cond, source_line: Optional[int]) -> None:
    if isinstance(cond, (bool, int)):
        line = "unknown" if source_line is None else str(source_line)
        raise SyntaxError(
            f"Python if/elif condition at line {line} evaluated to a compile-time constant "
            f"({cond!r}); use a runtime Var/Expr condition or define a separate @kernel/@vf"
        )


class If:
    def __init__(self, cond, *, _from_python_if: bool = False, _source_line: Optional[int] = None):
        self.cond = cond
        self._from_python_if = _from_python_if
        self._source_line = _source_line
        self._entry_vector_mode = None

    def __enter__(self):
        if self._from_python_if:
            _validate_python_if_condition(self.cond, self._source_line)
        self._entry_vector_mode = _current_vector_mode()
        _append_flow_instruction("start_if", cond=self.cond)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            return False
        _reset_count_mode_if_triggered(self._entry_vector_mode)
        _append_flow_instruction("end_if")
        return True


class Elif:
    def __init__(self, cond, *, _from_python_if: bool = False, _source_line: Optional[int] = None):
        self.cond = cond
        self._from_python_if = _from_python_if
        self._source_line = _source_line
        self._entry_vector_mode = None

    def __enter__(self):
        if _get_flow_target() is None:
            raise RuntimeError("Elif can only be used inside kernel or micro")
        _pop_last_end_if()
        self._entry_vector_mode = _current_vector_mode()
        cond = self.cond() if callable(self.cond) else self.cond
        if self._from_python_if:
            _validate_python_if_condition(cond, self._source_line)
        _append_flow_instruction("start_elif", cond=cond)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            return False
        _reset_count_mode_if_triggered(self._entry_vector_mode)
        _append_flow_instruction("end_if")
        return True


class Else:
    def __init__(self):
        self._entry_vector_mode = None

    def __enter__(self):
        if _get_flow_target() is None:
            raise RuntimeError("Else can only be used inside kernel or micro")
        _pop_last_end_if()
        self._entry_vector_mode = _current_vector_mode()
        _append_flow_instruction("start_else")

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            return False
        _reset_count_mode_if_triggered(self._entry_vector_mode)
        _append_flow_instruction("end_if")
        return True
