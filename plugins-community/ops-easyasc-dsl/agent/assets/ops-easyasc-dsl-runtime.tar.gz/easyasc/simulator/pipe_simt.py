"""SIMT runtime: mask-based vectorized interpreter for call_simt tasks.

All Python "scalars" inside the SIMT body are (T,) torch tensors where
T = thread_num (defaults to 1024). An `active` (T,) bool mask carries
through every statement; nested control flow pushes/pops on a mask stack.
break/continue maintain per-loop-frame masks. Tensor loads/stores filter
the index by `active` (last-write-wins on store collisions).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import torch

from .memory import SharedMemoryStore, torch_dtype
from .physical_alias import PhysicalAlias


SIMT_THREAD_NUM_DEFAULT = 1024


def _resolve_torch_dtype(name: str) -> torch.dtype:
    return torch_dtype(name)


def _broadcast_scalar(value: Any, dtype: torch.dtype, T: int) -> torch.Tensor:
    if isinstance(value, torch.Tensor):
        if value.shape == (T,):
            return value.to(dtype) if value.dtype != dtype else value
        if value.numel() == 1:
            return torch.full((T,), value.item(), dtype=dtype)
    if isinstance(value, bool):
        return torch.full((T,), int(value), dtype=dtype)
    if isinstance(value, (int, float)):
        return torch.full((T,), value, dtype=dtype)
    raise TypeError("cannot broadcast scalar of type " + str(type(value)))


def _simt_integer_rank(dtype: torch.dtype) -> Optional[int]:
    if dtype is torch.int32:
        return 0
    uint32 = getattr(torch, "uint32", None)
    if uint32 is not None and dtype is uint32:
        return 1
    if dtype is torch.int64:
        return 2
    uint64 = getattr(torch, "uint64", None)
    if uint64 is not None and dtype is uint64:
        return 3
    return None


def _promote_integer_torch_dtype(
    left: torch.dtype, right: torch.dtype
) -> Optional[torch.dtype]:
    left_rank = _simt_integer_rank(left)
    right_rank = _simt_integer_rank(right)
    if left_rank is None or right_rank is None:
        return None
    return left if left_rank >= right_rank else right


def _integer_compute_dtype(promoted: torch.dtype) -> torch.dtype:
    uint32 = getattr(torch, "uint32", None)
    uint64 = getattr(torch, "uint64", None)
    if promoted is uint32 or promoted is uint64:
        return torch.int64
    return promoted


def _promote_integer_operands(
    left: torch.Tensor, right: torch.Tensor
) -> Tuple[torch.Tensor, torch.Tensor, Optional[torch.dtype]]:
    promoted = _promote_integer_torch_dtype(left.dtype, right.dtype)
    if promoted is None:
        return left, right, None
    compute_dtype = _integer_compute_dtype(promoted)
    if left.dtype is not compute_dtype:
        left = left.to(compute_dtype)
    if right.dtype is not compute_dtype:
        right = right.to(compute_dtype)
    return left, right, promoted


def _restore_promoted_integer(
    value: torch.Tensor, promoted: Optional[torch.dtype]
) -> torch.Tensor:
    if promoted is None or value.dtype is promoted:
        return value
    return value.to(promoted)


def _unsigned_alias_dtype(dtype: torch.dtype) -> Optional[torch.dtype]:
    uint16 = getattr(torch, "uint16", None)
    if uint16 is not None and dtype is uint16:
        return torch.int16
    uint32 = getattr(torch, "uint32", None)
    if uint32 is not None and dtype is uint32:
        return torch.int32
    uint64 = getattr(torch, "uint64", None)
    if uint64 is not None and dtype is uint64:
        return torch.int64
    return None


def _indexable_view(value: torch.Tensor) -> torch.Tensor:
    alias_dtype = _unsigned_alias_dtype(value.dtype)
    if alias_dtype is None:
        return value
    return value.view(alias_dtype)


def _masked_select(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    view = _indexable_view(value)
    selected = view[mask]
    return selected.to(value.dtype) if view.dtype is not value.dtype else selected


def _assign_selected(dst: torch.Tensor, mask: torch.Tensor, selected: torch.Tensor) -> None:
    dst_view = _indexable_view(dst)
    selected_view = _indexable_view(selected)
    dst_view[mask] = selected_view.to(dst_view.dtype)


def _masked_assign(dst: torch.Tensor, mask: torch.Tensor, value: torch.Tensor) -> None:
    _assign_selected(dst, mask, _masked_select(value, mask))


def _indexed_load(src: torch.Tensor, idx: torch.Tensor) -> torch.Tensor:
    src_view = _indexable_view(src)
    loaded = src_view[idx]
    return loaded.to(src.dtype) if src_view.dtype is not src.dtype else loaded


def _indexed_put(
    dst: torch.Tensor, idx: torch.Tensor, value: torch.Tensor, accumulate: bool = False
) -> None:
    dst_view = _indexable_view(dst)
    value_view = _indexable_view(value)
    dst_view.index_put_((idx,), value_view.to(dst_view.dtype), accumulate=accumulate)


@dataclass
class SimtContext:
    regs: Dict[str, torch.Tensor] = field(default_factory=dict)
    active: Optional[torch.Tensor] = None
    mask_stack: List[torch.Tensor] = field(default_factory=list)
    break_masks: List[torch.Tensor] = field(default_factory=list)
    continue_masks: List[torch.Tensor] = field(default_factory=list)
    # Historical compatibility name: call_simt bindings may carry
    # PhysicalAlias descriptors, but SIMT always consumes their logical view.
    tensor_views: Dict[str, Any] = field(default_factory=dict)
    block_idx: int = 0
    block_num: int = 1
    thread_num: int = SIMT_THREAD_NUM_DEFAULT
    executed_instruction_count: int = 0


@dataclass
class SimtRuntime:
    last_instruction_count: int = 0

    def execute_call_simt(
        self,
        simt_def: Dict[str, Any],
        tensor_views: Dict[str, Any],
        var_values: Dict[str, Any],
        store: SharedMemoryStore,
        block_idx: int,
        block_num: int,
        thread_num: int,
    ) -> None:
        # Runtime boundary note: SIMT keeps logical tensor semantics even when
        # the carrier is a PhysicalAlias descriptor.
        T = int(thread_num)
        ctx = SimtContext(
            tensor_views=dict(tensor_views),
            block_idx=int(block_idx),
            block_num=int(block_num),
            thread_num=T,
        )
        ctx.active = torch.ones(T, dtype=torch.bool)
        self._bind_var_formals(simt_def, var_values, ctx)
        try:
            self._run_list(list(simt_def.get("instructions", [])), ctx, store)
        finally:
            self.last_instruction_count = int(ctx.executed_instruction_count)

    @staticmethod
    def _lookup_tensor_view(base_name: str, ctx: SimtContext) -> torch.Tensor:
        # SIMT bodies execute logical tensor indexing semantics even when the
        # binding was carried through the runtime as a PhysicalAlias descriptor.
        if base_name not in ctx.tensor_views:
            raise RuntimeError(
                "SIMT runtime: tensor base " + repr(base_name)
                + " not bound to a tensor view"
            )
        value = ctx.tensor_views[base_name]
        if isinstance(value, PhysicalAlias):
            if value.logical_view is None and int(value.byte_offset) != 0:
                raise RuntimeError(
                    "SIMT runtime: PhysicalAlias bound to "
                    + repr(base_name)
                    + " has a non-zero physical offset but no logical materialized view. "
                    + "Packed local/carrier aliases must be materialized into a logical tensor view "
                    + "before SIMT logical indexing."
                )
            if value.logical_view is value.tensor and int(value.byte_offset) != 0:
                raise RuntimeError(
                    "SIMT runtime: PhysicalAlias bound to "
                    + repr(base_name)
                    + " keeps only offset-based physical aliasing without a sliced logical view. "
                    + "Packed local/carrier aliases must be materialized before SIMT logical indexing."
                )
            return value.logical_tensor()
        if isinstance(value, torch.Tensor):
            return value
        raise RuntimeError(
            "SIMT runtime: tensor base " + repr(base_name)
            + " is not a tensor binding, got " + str(type(value))
        )

    # ------------------------------------------------------------------
    # Formal binding
    # ------------------------------------------------------------------

    def _bind_var_formals(
        self,
        simt_def: Dict[str, Any],
        var_values: Dict[str, Any],
        ctx: SimtContext,
    ) -> None:
        input_list = simt_def.get("input_list", [])
        locked_dtypes = simt_def.get("locked_dtypes", [])
        for i, formal in enumerate(input_list):
            if isinstance(formal, (list, tuple)):
                formal_name, kind = str(formal[0]), str(formal[1])
            else:
                formal_name = str(getattr(formal, "name", formal))
                kind = ""
            if kind != "Var":
                continue
            if formal_name not in var_values:
                continue
            dtype_name = locked_dtypes[i] if i < len(locked_dtypes) else "int"
            torch_dt = _resolve_torch_dtype(dtype_name)
            ctx.regs[formal_name] = _broadcast_scalar(
                var_values[formal_name], torch_dt, ctx.thread_num
            )

    # ------------------------------------------------------------------
    # Top-level instruction runner with control flow
    # ------------------------------------------------------------------

    def _run_list(
        self, instructions: List[Any], ctx: SimtContext, store: SharedMemoryStore
    ) -> None:
        pc = 0
        n = len(instructions)
        while pc < n:
            inst = instructions[pc]
            op = str(inst.opname)
            if op == "simt_for_range":
                end_pc = self._find_block_end(
                    instructions, pc, "simt_for_range", "simt_endfor"
                )
                self._run_for_range(
                    inst.kwargs, instructions, pc + 1, end_pc, ctx, store
                )
                pc = end_pc + 1
                continue
            if op == "simt_while":
                end_pc = self._find_block_end(
                    instructions, pc, "simt_while", "simt_endwhile"
                )
                self._run_while(
                    inst.kwargs, instructions, pc + 1, end_pc, ctx, store
                )
                pc = end_pc + 1
                continue
            if op == "simt_if":
                end_pc = self._find_block_end(
                    instructions, pc, "simt_if", "simt_endif"
                )
                self._run_if_chain(instructions, pc, end_pc, ctx, store)
                pc = end_pc + 1
                continue
            if op in (
                "simt_endfor", "simt_endwhile", "simt_endif",
                "simt_elif", "simt_else",
            ):
                raise RuntimeError("stray IR marker outside its block: " + op)
            self._exec_stmt(inst, ctx, store)
            pc += 1

    @staticmethod
    def _apply_loop_masks(mask: torch.Tensor, ctx: SimtContext) -> torch.Tensor:
        """Re-apply the innermost loop's break/continue masks to a restored
        active mask so that break/continue taken inside a nested if body
        also disable those threads for the rest of the enclosing loop body."""
        result = mask
        if ctx.break_masks:
            result = result & ~ctx.break_masks[-1]
        if ctx.continue_masks:
            result = result & ~ctx.continue_masks[-1]
        return result

    @staticmethod
    def _find_block_end(
        instructions: List[Any], start: int, open_op: str, close_op: str
    ) -> int:
        depth = 0
        for pc in range(start, len(instructions)):
            op = str(instructions[pc].opname)
            if op == open_op:
                depth += 1
            elif op == close_op:
                depth -= 1
                if depth == 0:
                    return pc
        raise RuntimeError(
            "unterminated " + open_op + " at " + str(start)
        )

    # ------------------------------------------------------------------
    # Loop runners
    # ------------------------------------------------------------------

    def _run_for_range(
        self,
        kwargs: Dict[str, Any],
        instructions: List[Any],
        body_start: int,
        body_end: int,
        ctx: SimtContext,
        store: SharedMemoryStore,
    ) -> None:
        T = ctx.thread_num
        var_name = str(kwargs.get("var_name", ""))
        start = self._eval_expr(kwargs.get("start"), ctx)
        stop = self._eval_expr(kwargs.get("stop"), ctx)
        step = self._eval_expr(kwargs.get("step"), ctx)
        # All loop control values are int per dtype rules; force int64 for
        # arithmetic safety.
        start = start.to(torch.int64)
        stop = stop.to(torch.int64)
        step = step.to(torch.int64)
        if bool((step <= 0).any()):
            raise NotImplementedError(
                "SIMT runtime: range() step must be positive (per-thread); got non-positive"
            )

        i = start.clone()
        ctx.regs[var_name] = i.to(torch.int32)

        break_mask = torch.zeros(T, dtype=torch.bool)
        continue_mask = torch.zeros(T, dtype=torch.bool)
        ctx.break_masks.append(break_mask)
        ctx.continue_masks.append(continue_mask)
        outer_active = ctx.active
        body = instructions[body_start:body_end]
        try:
            while True:
                cond = (i < stop) & ~ctx.break_masks[-1]
                body_active = outer_active & cond
                if not bool(body_active.any()):
                    break
                # Reset continue_mask each iteration.
                ctx.continue_masks[-1] = torch.zeros(T, dtype=torch.bool)
                ctx.mask_stack.append(ctx.active)
                ctx.active = body_active
                ctx.regs[var_name] = i.to(torch.int32)
                try:
                    self._run_list(body, ctx, store)
                finally:
                    ctx.active = ctx.mask_stack.pop()
                i = torch.where(cond, i + step, i)
        finally:
            ctx.break_masks.pop()
            ctx.continue_masks.pop()
            ctx.regs.pop(var_name, None)

    def _run_while(
        self,
        kwargs: Dict[str, Any],
        instructions: List[Any],
        body_start: int,
        body_end: int,
        ctx: SimtContext,
        store: SharedMemoryStore,
    ) -> None:
        T = ctx.thread_num
        cond_expr = kwargs.get("cond")
        break_mask = torch.zeros(T, dtype=torch.bool)
        continue_mask = torch.zeros(T, dtype=torch.bool)
        ctx.break_masks.append(break_mask)
        ctx.continue_masks.append(continue_mask)
        outer_active = ctx.active
        body = instructions[body_start:body_end]
        # Cap iterations to defend against runaway loops in incorrect tests.
        max_iters = 1 << 20
        iters = 0
        try:
            while True:
                iters += 1
                if iters > max_iters:
                    raise RuntimeError(
                        "SIMT while loop exceeded "
                        + str(max_iters)
                        + " iterations (likely runaway condition)"
                    )
                cond_val = self._eval_expr(cond_expr, ctx).to(torch.bool)
                body_active = outer_active & cond_val & ~ctx.break_masks[-1]
                if not bool(body_active.any()):
                    break
                ctx.continue_masks[-1] = torch.zeros(T, dtype=torch.bool)
                ctx.mask_stack.append(ctx.active)
                ctx.active = body_active
                try:
                    self._run_list(body, ctx, store)
                finally:
                    ctx.active = ctx.mask_stack.pop()
        finally:
            ctx.break_masks.pop()
            ctx.continue_masks.pop()

    def _run_if_chain(
        self,
        instructions: List[Any],
        if_pc: int,
        endif_pc: int,
        ctx: SimtContext,
        store: SharedMemoryStore,
    ) -> None:
        # Split the chain into top-level segments delimited by simt_if /
        # simt_elif / simt_else / simt_endif at depth 0.
        segments: List[Tuple[int, int, int]] = []
        seg_header = if_pc
        seg_body = if_pc + 1
        nested_if = 0
        nested_for = 0
        nested_while = 0
        pc = if_pc + 1
        while pc < endif_pc:
            op = str(instructions[pc].opname)
            if op == "simt_for_range":
                nested_for += 1
            elif op == "simt_endfor":
                nested_for -= 1
            elif op == "simt_while":
                nested_while += 1
            elif op == "simt_endwhile":
                nested_while -= 1
            elif op == "simt_if":
                nested_if += 1
            elif op == "simt_endif":
                nested_if -= 1
            elif (
                op in ("simt_elif", "simt_else")
                and nested_if == 0
                and nested_for == 0
                and nested_while == 0
            ):
                segments.append((seg_header, seg_body, pc))
                seg_header = pc
                seg_body = pc + 1
            pc += 1
        segments.append((seg_header, seg_body, endif_pc))

        outer_active = ctx.active
        remaining = outer_active.clone()
        for header_idx, body_start, body_end in segments:
            header = instructions[header_idx]
            header_op = str(header.opname)
            if header_op == "simt_else":
                cond_mask = remaining.clone()
                remaining = torch.zeros_like(remaining)
            else:
                cond_val = self._eval_expr(header.kwargs.get("cond"), ctx).to(torch.bool)
                cond_mask = remaining & cond_val
                remaining = remaining & ~cond_val
            if not bool(cond_mask.any()):
                continue
            ctx.mask_stack.append(ctx.active)
            ctx.active = cond_mask
            try:
                body = instructions[body_start:body_end]
                self._run_list(body, ctx, store)
            finally:
                restored = ctx.mask_stack.pop()
                ctx.active = self._apply_loop_masks(restored, ctx)

    # ------------------------------------------------------------------
    # Statement dispatch (non-control-flow)
    # ------------------------------------------------------------------

    def _exec_stmt(
        self, inst: Any, ctx: SimtContext, store: SharedMemoryStore
    ) -> None:
        op = str(inst.opname)
        kw = inst.kwargs
        if ctx.active is not None and bool(ctx.active.any()):
            ctx.executed_instruction_count += 1
        if op == "simt_assign":
            self._exec_assign(kw, ctx)
            return
        if op == "simt_aug_assign":
            self._exec_aug_assign(kw, ctx)
            return
        if op == "simt_expr":
            # Evaluate for side effects only; SIMT bodies don't have
            # call expressions other than cvt/intrinsic which are pure.
            self._eval_expr(kw.get("expr"), ctx)
            return
        if op == "simt_atomic":
            self._exec_atomic(kw, ctx, store)
            return
        if op == "simt_thread_barrier":
            if ctx.active is None or not bool(ctx.active.all()):
                raise RuntimeError(
                    "SIMT runtime: simt_thread_barrier requires every launch "
                    "thread to be active"
                )
            # The runtime executes each statement over all active lanes as one
            # vectorized phase, so a uniform barrier is already ordered.
            return
        if op == "simt_break":
            self._exec_break(ctx)
            return
        if op == "simt_continue":
            self._exec_continue(ctx)
            return
        raise NotImplementedError("SIMT runtime: unsupported op " + op)

    def _exec_assign(self, kw: Dict[str, Any], ctx: SimtContext) -> None:
        rhs = self._eval_expr(kw.get("expr"), ctx)
        target_kind = str(kw.get("target_kind", ""))
        if target_kind == "name":
            name = str(kw.get("target", ""))
            decl_dtype = kw.get("decl_dtype")
            if name not in ctx.regs:
                if decl_dtype is None:
                    # Re-assignment to undeclared register; treat the RHS
                    # dtype as the declaration so the slot exists.
                    target_dt = rhs.dtype
                else:
                    target_dt = _resolve_torch_dtype(str(decl_dtype))
                ctx.regs[name] = torch.zeros(ctx.thread_num, dtype=target_dt)
            slot = ctx.regs[name]
            value = rhs.to(slot.dtype) if rhs.dtype != slot.dtype else rhs
            mask = ctx.active
            _masked_assign(slot, mask, value)
            return
        if target_kind == "subscript":
            target = kw.get("target", {})
            self._exec_subscript_store(target, rhs, ctx)
            return
        raise NotImplementedError(
            "SIMT runtime: unsupported assign target " + target_kind
        )

    def _exec_aug_assign(self, kw: Dict[str, Any], ctx: SimtContext) -> None:
        op_sym = str(kw.get("op", ""))
        target_kind = str(kw.get("target_kind", ""))
        rhs = self._eval_expr(kw.get("expr"), ctx)
        if target_kind == "name":
            name = str(kw.get("target", ""))
            if name not in ctx.regs:
                raise RuntimeError(
                    "SIMT runtime: aug-assign to undeclared name " + name
                )
            current = ctx.regs[name]
            new_val = self._apply_binop(op_sym, current, rhs.to(current.dtype))
            _masked_assign(ctx.regs[name], ctx.active, new_val)
            return
        if target_kind == "subscript":
            target = kw.get("target", {})
            current = self._exec_subscript_load(target, ctx)
            new_val = self._apply_binop(op_sym, current, rhs.to(current.dtype))
            self._exec_subscript_store(target, new_val, ctx)
            return
        raise NotImplementedError(
            "SIMT runtime: unsupported aug-assign target " + target_kind
        )

    def _exec_break(self, ctx: SimtContext) -> None:
        if not ctx.break_masks:
            raise RuntimeError("SIMT runtime: break outside loop")
        active = ctx.active
        ctx.break_masks[-1] = ctx.break_masks[-1] | active
        ctx.active = active & ~ctx.break_masks[-1]

    def _exec_continue(self, ctx: SimtContext) -> None:
        if not ctx.continue_masks:
            raise RuntimeError("SIMT runtime: continue outside loop")
        active = ctx.active
        ctx.continue_masks[-1] = ctx.continue_masks[-1] | active
        ctx.active = active & ~ctx.continue_masks[-1]

    # ------------------------------------------------------------------
    # Subscript load / store
    # ------------------------------------------------------------------

    def _exec_subscript_load(
        self, target: Dict[str, Any], ctx: SimtContext
    ) -> torch.Tensor:
        base_name = str(target.get("base", ""))
        base = self._lookup_tensor_view(base_name, ctx)
        flat_base = base.reshape(-1) if base.dim() > 1 else base
        idx = self._eval_expr(target.get("index"), ctx).to(torch.int64)
        out = torch.zeros(ctx.thread_num, dtype=flat_base.dtype)
        mask = ctx.active
        if bool(mask.any()):
            _assign_selected(out, mask, _indexed_load(flat_base, idx[mask]))
        return out

    def _exec_subscript_store(
        self, target: Dict[str, Any], value: torch.Tensor, ctx: SimtContext
    ) -> None:
        base_name = str(target.get("base", ""))
        base = self._lookup_tensor_view(base_name, ctx)
        flat_base = base.reshape(-1) if base.dim() > 1 else base
        idx = self._eval_expr(target.get("index"), ctx).to(torch.int64)
        cast_value = value.to(flat_base.dtype) if value.dtype != flat_base.dtype else value
        mask = ctx.active
        if bool(mask.any()):
            _indexed_put(flat_base, idx[mask], _masked_select(cast_value, mask))

    def _exec_atomic(
        self, kw: Dict[str, Any], ctx: SimtContext, store: SharedMemoryStore
    ) -> None:
        op = str(kw.get("op", ""))
        base_name = str(kw.get("base", ""))
        base = self._lookup_tensor_view(base_name, ctx)
        flat_base = base.reshape(-1) if base.dim() > 1 else base
        idx = self._eval_expr(kw.get("index"), ctx).to(torch.int64)
        value = self._eval_expr(kw.get("value"), ctx)
        cast_value = (
            value.to(flat_base.dtype) if value.dtype != flat_base.dtype else value
        )
        mask = ctx.active
        if not bool(mask.any()):
            return
        sel_idx = idx[mask].contiguous()
        sel_val = _masked_select(cast_value, mask).contiguous()
        with store.atomic_lock():
            if op == "add":
                _indexed_put(flat_base, sel_idx, sel_val, accumulate=True)
            elif op == "sub":
                _indexed_put(flat_base, sel_idx, -sel_val, accumulate=True)
            elif op in ("max", "min"):
                reduce_mode = "amax" if op == "max" else "amin"
                base_view = _indexable_view(flat_base)
                sel_view = _indexable_view(sel_val)
                base_view.scatter_reduce_(
                    0, sel_idx, sel_view.to(base_view.dtype),
                    reduce=reduce_mode, include_self=True
                )
            elif op == "cas":
                compare = self._eval_expr(kw.get("compare"), ctx)
                cast_compare = (
                    compare.to(flat_base.dtype)
                    if compare.dtype != flat_base.dtype else compare
                )
                sel_compare = _masked_select(cast_compare, mask).contiguous()
                base_view = _indexable_view(flat_base)
                value_view = _indexable_view(sel_val)
                compare_view = _indexable_view(sel_compare)
                # Preserve per-lane atomic semantics when lanes collide: an
                # earlier successful CAS changes what the later lane compares.
                for lane in range(sel_idx.numel()):
                    target = int(sel_idx[lane])
                    if base_view[target] == compare_view[lane]:
                        base_view[target] = value_view[lane].to(base_view.dtype)
            else:
                raise NotImplementedError(
                    "SIMT runtime: unsupported atomic op " + repr(op)
                )

    # ------------------------------------------------------------------
    # Expression evaluator → returns a (T,) torch tensor
    # ------------------------------------------------------------------

    def _eval_expr(self, expr: Any, ctx: SimtContext) -> torch.Tensor:
        if not isinstance(expr, dict):
            raise TypeError(
                "SIMT runtime: expr must be tagged dict, got " + str(type(expr))
            )
        kind = str(expr.get("kind", ""))
        if kind == "name":
            name = str(expr.get("id", ""))
            if name not in ctx.regs:
                raise RuntimeError(
                    "SIMT runtime: unknown name " + repr(name)
                )
            return ctx.regs[name]
        if kind == "const":
            value = expr.get("value")
            dtype_name = str(expr.get("dtype", "int"))
            torch_dt = _resolve_torch_dtype(dtype_name)
            return _broadcast_scalar(value, torch_dt, ctx.thread_num)
        if kind == "intrinsic":
            return self._eval_intrinsic(str(expr.get("name", "")), ctx)
        if kind == "binop":
            left = self._eval_expr(expr.get("left"), ctx)
            right = self._eval_expr(expr.get("right"), ctx)
            return self._apply_binop(str(expr.get("op", "")), left, right)
        if kind == "unop":
            operand = self._eval_expr(expr.get("operand"), ctx)
            return self._apply_unop(str(expr.get("op", "")), operand)
        if kind == "compare":
            left = self._eval_expr(expr.get("left"), ctx)
            right = self._eval_expr(expr.get("right"), ctx)
            return self._apply_compare(str(expr.get("op", "")), left, right)
        if kind == "boolop":
            sym = str(expr.get("op", ""))
            values = expr.get("values", []) or []
            if not values:
                return torch.zeros(ctx.thread_num, dtype=torch.bool)
            acc = self._eval_expr(values[0], ctx).to(torch.bool)
            for child in values[1:]:
                v = self._eval_expr(child, ctx).to(torch.bool)
                if sym == "&&":
                    acc = acc & v
                else:
                    acc = acc | v
            return acc
        if kind == "subscript":
            return self._exec_subscript_load(expr, ctx)
        if kind == "cvt":
            inner = self._eval_expr(expr.get("expr"), ctx)
            target_dt = _resolve_torch_dtype(str(expr.get("dtype", "int")))
            return inner.to(target_dt)
        if kind == "fma":
            multiplicand0 = self._eval_expr(expr.get("multiplicand0"), ctx)
            multiplicand1 = self._eval_expr(expr.get("multiplicand1"), ctx)
            addend = self._eval_expr(expr.get("addend"), ctx)
            if not all(
                value.dtype is torch.float32
                for value in (multiplicand0, multiplicand1, addend)
            ):
                raise TypeError("SIMT runtime: fma requires three float32 operands")
            # A binary64 product plus add has ample guard precision for the
            # fp32 contraction used by A5 SIMT, followed by one fp32 rounding.
            return (
                multiplicand0.to(torch.float64)
                * multiplicand1.to(torch.float64)
                + addend.to(torch.float64)
            ).to(torch.float32)
        if kind == "minmax":
            left = self._eval_expr(expr.get("left"), ctx)
            right = self._eval_expr(expr.get("right"), ctx)
            left, right = torch.broadcast_tensors(left, right)
            if left.dtype != right.dtype:
                promoted = torch.promote_types(left.dtype, right.dtype)
                left = left.to(promoted)
                right = right.to(promoted)
            if expr.get("op") == "Min":
                return torch.minimum(left, right)
            return torch.maximum(left, right)
        if kind == "ffs":
            value = self._eval_expr(expr.get("value"), ctx)
            if value.dtype not in (torch.int32, torch.int64):
                raise TypeError(
                    "SIMT runtime: ffs requires a signed int32/int64 operand"
                )
            low_bit = value & -value
            positions = torch.log2(
                torch.abs(low_bit.to(torch.float64))
            ).to(torch.int32) + 1
            return torch.where(
                value == 0, torch.zeros_like(positions), positions,
            )
        raise NotImplementedError("SIMT runtime: unsupported expr kind " + kind)

    def _eval_intrinsic(self, name: str, ctx: SimtContext) -> torch.Tensor:
        T = ctx.thread_num
        if name == "simt_thread_id":
            return torch.arange(T, dtype=torch.int32)
        if name == "simt_thread_num":
            return torch.full((T,), T, dtype=torch.int32)
        if name == "simt_block_idx":
            return torch.full((T,), int(ctx.block_idx), dtype=torch.int32)
        if name == "simt_block_num":
            return torch.full((T,), int(ctx.block_num), dtype=torch.int32)
        raise NotImplementedError(
            "SIMT runtime: unsupported intrinsic " + name
        )

    # ------------------------------------------------------------------
    # Op application
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_binop(
        sym: str, left: torch.Tensor, right: torch.Tensor
    ) -> torch.Tensor:
        left, right, promoted = _promote_integer_operands(left, right)
        if sym == "+":
            return _restore_promoted_integer(left + right, promoted)
        if sym == "-":
            return _restore_promoted_integer(left - right, promoted)
        if sym == "*":
            return _restore_promoted_integer(left * right, promoted)
        if sym == "/":
            if left.dtype.is_floating_point:
                return left / right
            return _restore_promoted_integer(
                torch.div(left, right, rounding_mode="trunc"), promoted
            )
        if sym == "//":
            return _restore_promoted_integer(
                torch.div(left, right, rounding_mode="floor"), promoted
            )
        if sym == "%":
            return _restore_promoted_integer(torch.remainder(left, right), promoted)
        if sym == "&":
            return _restore_promoted_integer(left & right, promoted)
        if sym == "|":
            return _restore_promoted_integer(left | right, promoted)
        if sym == "^":
            return _restore_promoted_integer(left ^ right, promoted)
        if sym == "<<":
            return _restore_promoted_integer(left << right, promoted)
        if sym == ">>":
            return _restore_promoted_integer(left >> right, promoted)
        raise NotImplementedError("SIMT runtime: unsupported binop " + sym)

    @staticmethod
    def _apply_unop(sym: str, operand: torch.Tensor) -> torch.Tensor:
        if sym == "+":
            return +operand
        if sym == "-":
            return -operand
        if sym == "!":
            return ~operand.to(torch.bool)
        raise NotImplementedError("SIMT runtime: unsupported unop " + sym)

    @staticmethod
    def _apply_compare(
        sym: str, left: torch.Tensor, right: torch.Tensor
    ) -> torch.Tensor:
        left, right, promoted = _promote_integer_operands(left, right)
        uint64 = getattr(torch, "uint64", None)
        if promoted is uint64:
            # PyTorch CPU does not implement uint64 comparisons.  The compute
            # view above contains the same bits in int64; flipping the sign bit
            # maps unsigned order monotonically onto signed order.
            sign = torch.iinfo(torch.int64).min
            left = left ^ sign
            right = right ^ sign
        if sym == "<":
            return left < right
        if sym == "<=":
            return left <= right
        if sym == ">":
            return left > right
        if sym == ">=":
            return left >= right
        if sym == "==":
            return left == right
        if sym == "!=":
            return left != right
        raise NotImplementedError("SIMT runtime: unsupported compare " + sym)
