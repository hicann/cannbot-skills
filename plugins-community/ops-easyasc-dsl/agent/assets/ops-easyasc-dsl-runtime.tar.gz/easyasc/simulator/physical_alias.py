from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Dict, Iterable, Optional, Tuple

import torch


def _shape_tuple(shape: Any) -> Tuple[int, ...]:
    if shape is None:
        return ()
    return tuple(int(v) for v in shape)


def _tuple_str(values: Any) -> Tuple[str, ...]:
    if values is None:
        return ()
    return tuple(str(v) for v in values)


@dataclass
class PhysicalAlias:
    """Pointer-style simulator alias for local/GM tensor arguments.

    `tensor` is the currently bound runtime tensor/view. `byte_offset` advances
    the effective pointer relative to `tensor`'s current data address. The
    logical view is kept only for diagnostics and non-pointer compatibility.
    """

    tensor: torch.Tensor
    byte_offset: int = 0
    logical_view: Optional[torch.Tensor] = None
    logical_offset_bytes: Optional[int] = None
    name: str = ""
    storage_name: str = ""
    dtype: str = ""
    storage_num_bytes: int = 0
    logical_shape: Tuple[int, ...] = field(default_factory=tuple)
    logical_strides: Tuple[int, ...] = field(default_factory=tuple)
    role: str = ""
    tags: Tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        self.byte_offset = int(self.byte_offset)
        if self.logical_offset_bytes is not None:
            self.logical_offset_bytes = int(self.logical_offset_bytes)
        self.logical_shape = _shape_tuple(self.logical_shape)
        self.logical_strides = _shape_tuple(self.logical_strides)
        self.tags = _tuple_str(self.tags)
        if not self.storage_name:
            self.storage_name = str(self.name or "")
        if not self.logical_shape:
            view = self.logical_tensor()
            self.logical_shape = tuple(int(v) for v in getattr(view, "shape", ()))
        if not self.logical_strides:
            view = self.logical_tensor()
            if hasattr(view, "stride"):
                self.logical_strides = tuple(int(v) for v in view.stride())
        if not self.dtype:
            self.dtype = str(getattr(self.logical_tensor(), "dtype", ""))
        if not self.storage_num_bytes:
            try:
                self.storage_num_bytes = int(self.tensor.untyped_storage().nbytes())
            except Exception:
                self.storage_num_bytes = int(self.tensor.numel()) * int(self.tensor.element_size())

    def logical_tensor(self) -> torch.Tensor:
        return self.logical_view if self.logical_view is not None else self.tensor

    def with_updates(self, **kwargs: Any) -> "PhysicalAlias":
        return replace(self, **kwargs)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "storage_name": self.storage_name,
            "dtype": self.dtype,
            "byte_offset": int(self.byte_offset),
            "storage_num_bytes": int(self.storage_num_bytes),
            "logical_offset_bytes": self.logical_offset_bytes,
            "logical_shape": list(self.logical_shape),
            "logical_strides": list(self.logical_strides),
            "role": self.role,
            "tags": list(self.tags),
        }

    @classmethod
    def from_dict(
        cls,
        payload: Dict[str, Any],
        tensor: torch.Tensor,
        logical_view: Optional[torch.Tensor] = None,
    ) -> "PhysicalAlias":
        return cls(
            tensor=tensor,
            byte_offset=int(payload.get("byte_offset", 0)),
            logical_view=logical_view,
            logical_offset_bytes=payload.get("logical_offset_bytes"),
            name=str(payload.get("name", "")),
            storage_name=str(payload.get("storage_name", "")),
            dtype=str(payload.get("dtype", "")),
            storage_num_bytes=int(payload.get("storage_num_bytes", 0)),
            logical_shape=_shape_tuple(payload.get("logical_shape", ())),
            logical_strides=_shape_tuple(payload.get("logical_strides", ())),
            role=str(payload.get("role", "")),
            tags=_tuple_str(payload.get("tags", ())),
        )


def as_physical_alias(
    value,
    logical_offset_bytes: Optional[int] = None,
    name: str = "",
    storage_name: str = "",
    role: str = "",
    tags: Optional[Iterable[str]] = None,
) -> PhysicalAlias:
    if isinstance(value, PhysicalAlias):
        updates: Dict[str, Any] = {}
        if logical_offset_bytes is not None and value.logical_offset_bytes is None:
            updates["logical_offset_bytes"] = int(logical_offset_bytes)
        if name and not value.name:
            updates["name"] = str(name)
        if storage_name and not value.storage_name:
            updates["storage_name"] = str(storage_name)
        if role and not value.role:
            updates["role"] = str(role)
        if tags and not value.tags:
            updates["tags"] = tuple(str(tag) for tag in tags)
        if updates:
            return value.with_updates(**updates)
        return value
    if not isinstance(value, torch.Tensor):
        raise TypeError("PhysicalAlias requires torch.Tensor, got: " + str(type(value)))
    return PhysicalAlias(
        tensor=value,
        byte_offset=0,
        logical_view=value,
        logical_offset_bytes=logical_offset_bytes,
        name=str(name or ""),
        storage_name=str(storage_name or name or ""),
        role=str(role or ""),
        tags=tuple(str(tag) for tag in (tags or ())),
    )
