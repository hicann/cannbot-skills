from __future__ import annotations

import multiprocessing
import re
import sys
import threading
import traceback
from dataclasses import dataclass, field
from multiprocessing import shared_memory
from typing import Any, Dict, List, Optional, Tuple

from .physical_alias import PhysicalAlias, as_physical_alias


# ---------------------------------------------------------------------------
# Dtype utilities
# ---------------------------------------------------------------------------

_DTYPE_ALIASES = {
    "torch.float16": "float16", "half": "float16", "float16_t": "float16",
    "torch.float32": "float32", "float": "float32", "float_t": "float32",
    "torch.int32": "int32", "int": "int32", "int32_t": "int32",
    "torch.int64": "int64", "int64_t": "int64",
    "torch.int16": "int16", "int16_t": "int16",
    "torch.int8": "int8", "int8_t": "int8",
    "torch.uint8": "uint8", "uint8_t": "uint8",
    "torch.uint16": "uint16", "uint16_t": "uint16",
    "torch.uint32": "uint32", "uint32_t": "uint32",
    "torch.uint64": "uint64", "uint64_t": "uint64",
    "torch.bfloat16": "bfloat16", "bfloat16_t": "bfloat16",
    "torch.float8_e4m3fn": "float8_e4m3fn", "float8_e4m3_t": "float8_e4m3fn",
    "torch.float8_e5m2": "float8_e5m2", "float8_e5m2_t": "float8_e5m2",
    "mx_fp8_e4m3_t": "float8_e4m3fn", "mx_fp8_e5m2_t": "float8_e5m2",
    "hifloat8_t": "hif8",
    "fp4x2_e2m1_t": "fp4_e2m1", "fp4x2_e1m2_t": "fp4_e1m2",
    "torch.bool": "bool", "bool_t": "bool",
    "torch.complex64": "complex64", "complex64": "complex64",
    "torch.complex32": "complex32", "complex32": "complex32",
}

_DTYPE_SIZE_BYTES = {
    "float16": 2, "float32": 4, "int32": 4, "int64": 8, "int16": 2,
    "int8": 1, "uint8": 1, "uint16": 2, "uint32": 4, "uint64": 8,
    "bfloat16": 2, "float8_e4m3fn": 1, "float8_e5m2": 1, "hif8": 1, "bool": 1,
    "complex64": 8, "complex32": 4,
}

_BITWISE_ONE_INIT_ROLES = frozenset(["output", "workspace", "l1", "l0a", "l0b", "l0c", "ub"])
L0AMX_BUFFER_NAME = "__l0amx"
L0BMX_BUFFER_NAME = "__l0bmx"
L0MX_CAPACITY_BYTES = 4 * 1024
_LOCAL_BACKING_ROLES = frozenset(["l1", "l0a", "l0b", "l0amx", "l0bmx", "l0c", "ub", "bt"])
_LOCAL_BACKING_ROLE_TO_BANK = {
    "l1": "L1",
    "l0a": "L0A",
    "l0b": "L0B",
    "l0amx": "L0AMX",
    "l0bmx": "L0BMX",
    "l0c": "L0C",
    "ub": "UB",
    "bt": "BT",
}
_LOCAL_BANK_CAP_ATTR = {
    "UB0": "ub_cap",
    "UB1": "ub_cap",
    "L1": "l1_cap",
    "L0A": "l0a_cap",
    "L0B": "l0b_cap",
    "L0AMX": "l0amx_cap",
    "L0BMX": "l0bmx_cap",
    "L0C": "l0c_cap",
    "BT": "bt_cap",
}


def normalize_dtype(dtype: Any) -> str:
    if hasattr(dtype, "name"):
        dtype = getattr(dtype, "name")
    name = str(dtype).strip()
    return _DTYPE_ALIASES.get(name, name)


def torch_dtype(dtype: Any) -> Any:
    import torch
    name = normalize_dtype(dtype)
    mapping = {
        "float16": torch.float16, "float32": torch.float32,
        "int32": torch.int32, "int64": torch.int64,
        "int16": torch.int16, "int8": torch.int8, "uint8": torch.uint8,
        "bfloat16": torch.bfloat16, "hif8": torch.uint8, "bool": torch.bool,
        "fp4_e2m1": torch.uint8, "fp4_e1m2": torch.uint8,
        "complex64": torch.complex64,
    }
    if name in mapping:
        return mapping[name]
    for attr in ("uint16", "uint32", "uint64", "float8_e4m3fn", "float8_e5m2", "complex32"):
        if name == attr and hasattr(torch, attr):
            return getattr(torch, attr)
    raise TypeError("unsupported dtype: " + str(dtype))


def numpy_dtype(dtype: Any) -> Any:
    import numpy as np
    name = normalize_dtype(dtype)
    mapping = {
        "float16": np.float16, "float32": np.float32,
        "int32": np.int32, "int64": np.int64,
        "int16": np.int16, "int8": np.int8, "uint8": np.uint8,
        "uint16": np.uint16, "uint32": np.uint32, "uint64": np.uint64,
        "bfloat16": np.uint16,
        "float8_e4m3fn": np.uint8, "float8_e5m2": np.uint8,
        "hif8": np.uint8,
        "bool": np.bool_,
        # complex64 = 2 x fp32 has a native numpy dtype; complex32 (2 x fp16) has
        # none, so it is stored as a 4-byte uint32 byte-container and reinterpreted
        # to torch.complex32 when a reg is loaded/computed (see torch_dtype).
        "complex64": np.complex64,
        "complex32": np.uint32,
    }
    if name in mapping:
        return mapping[name]
    raise TypeError("unsupported numpy dtype: " + str(dtype))


def dtype_size(dtype: Any) -> int:
    name = normalize_dtype(dtype)
    size = _DTYPE_SIZE_BYTES.get(name)
    if size is None:
        raise TypeError("unknown dtype size: " + str(dtype))
    return size


def _initialize_storage_array(arr: Any, spec: "SharedTensorSpec") -> None:
    import numpy as np

    role = spec.role.lower()
    if role not in _BITWISE_ONE_INIT_ROLES:
        arr.fill(0)
        return
    if arr.size:
        arr.reshape(-1).view(np.uint8).reshape(-1)[:] = 0xFF


def _initialize_storage_tensor(tensor: Any, spec: "SharedTensorSpec") -> None:
    import torch

    role = spec.role.lower()
    byte_view = tensor.reshape(-1).view(torch.uint8)
    if role not in _BITWISE_ONE_INIT_ROLES:
        byte_view.zero_()
        return
    if tensor.numel():
        byte_view.fill_(0xFF)


# ---------------------------------------------------------------------------
# SharedTensorSpec / SharedTensorHandle
# ---------------------------------------------------------------------------

def _shape_tuple(shape: Any) -> Tuple[int, ...]:
    if shape is None:
        return ()
    return tuple(int(d) for d in shape)


@dataclass(frozen=True)
class SharedTensorSpec:
    """Specification for one tensor in the shared memory store."""

    name: str
    shape: Tuple[int, ...]
    dtype: str
    role: str = "shared"
    storage_offset: int = 0
    storage_offset_bytes: int = 0
    storage_size_bytes: int = 0
    storage_bank: str = ""
    source_name: Optional[str] = None
    view_shape: Tuple[int, ...] = ()
    view_strides: Tuple[int, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "shape", _shape_tuple(self.shape))
        object.__setattr__(self, "dtype", normalize_dtype(self.dtype))
        object.__setattr__(self, "view_shape", _shape_tuple(self.view_shape))
        object.__setattr__(self, "view_strides", _shape_tuple(self.view_strides))

    @property
    def numel(self) -> int:
        n = 1
        for d in self.shape:
            n *= d
        return n

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name, "shape": list(self.shape),
            "dtype": self.dtype, "role": self.role,
            "storage_offset": self.storage_offset,
            "storage_offset_bytes": self.storage_offset_bytes,
            "storage_size_bytes": self.storage_size_bytes,
            "storage_bank": self.storage_bank,
            "source_name": self.source_name,
            "view_shape": list(self.view_shape),
            "view_strides": list(self.view_strides),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> SharedTensorSpec:
        return cls(
            name=str(d["name"]),
            shape=_shape_tuple(d.get("shape", ())),
            dtype=str(d.get("dtype", "float32")),
            role=str(d.get("role", "shared")),
            storage_offset=int(d.get("storage_offset", 0)),
            storage_offset_bytes=int(d.get("storage_offset_bytes", 0)),
            storage_size_bytes=int(d.get("storage_size_bytes", 0)),
            storage_bank=str(d.get("storage_bank", "")),
            source_name=d.get("source_name"),
            view_shape=_shape_tuple(d.get("view_shape", ())),
            view_strides=_shape_tuple(d.get("view_strides", ())),
        )


# ---------------------------------------------------------------------------
# SharedMemoryStore — GM tensors shared across Core processes
# ---------------------------------------------------------------------------

def _detach_child_shm(shm: Any) -> None:
    """Prevent child process from unlink-ing parent-owned shared memory."""
    try:
        from multiprocessing import resource_tracker
        name = getattr(shm, "_name", None) or getattr(shm, "name", "")
        if isinstance(name, str) and not name.startswith("/"):
            name = "/" + name
        if name:
            resource_tracker.unregister(name, "shared_memory")
    except Exception:
        print(
            "[simulator] _detach_child_shm suppressed: shm=%r\n%s"
            % (shm, traceback.format_exc()),
            file=sys.stderr, flush=True,
        )


@dataclass
class SharedMemoryStore:
    """Registry and allocator for GM tensors backed by shared memory.

    Parent process creates shared memory regions. Child Core processes
    attach via snapshot/load_snapshot.

    Key: spec.name (str) everywhere.
    """

    specs: Dict[str, SharedTensorSpec] = field(default_factory=dict)
    storage: Dict[str, Any] = field(default_factory=dict, repr=False)
    aliases: Dict[str, PhysicalAlias] = field(default_factory=dict, repr=False)
    logical_offsets_bytes: Dict[str, int] = field(default_factory=dict, repr=False)
    _shm_blocks: Dict[str, Dict[str, Any]] = field(default_factory=dict, repr=False)
    _local_bank_blocks: Dict[str, Dict[str, Any]] = field(default_factory=dict, repr=False)
    _atomic_lock: Any = field(default=None, init=False, repr=False)
    _lock: threading.RLock = field(default_factory=threading.RLock, init=False, repr=False)

    def register(self, spec: SharedTensorSpec) -> None:
        with self._lock:
            if spec.name in self.specs:
                return
            self.specs[spec.name] = spec

    def allocate(self, name: str) -> Any:
        with self._lock:
            if name in self.storage:
                return self.storage[name]
            spec = self.specs[name]
            if self._is_view(spec):
                tensor = self._resolve_view(spec)
            elif self._is_local_backed(spec):
                tensor = self._alloc_local_bank_view(spec)
            else:
                tensor = self._alloc_shm(spec)
            self.storage[name] = tensor
            self.aliases.pop(name, None)
            self.logical_offsets_bytes[name] = self._logical_offset_for_spec(spec)
            return tensor

    def tensor(self, name: str) -> Any:
        with self._lock:
            if name in self.storage:
                return self.storage[name]
            return self.allocate(name)

    def contains(self, name: str) -> bool:
        with self._lock:
            return name in self.specs or name in self.storage or name in self.aliases

    def register_view(self, name: str, tensor: Any, logical_offset_bytes: Optional[int] = None) -> None:
        with self._lock:
            if isinstance(tensor, PhysicalAlias):
                alias = self._finalize_alias(name, tensor, logical_offset_bytes)
                self.aliases[name] = alias
                self.storage[name] = alias.logical_tensor()
                if alias.logical_offset_bytes is not None:
                    self.logical_offsets_bytes[name] = int(alias.logical_offset_bytes)
                else:
                    self.logical_offsets_bytes.pop(name, None)
                return
            self.aliases.pop(name, None)
            self.storage[name] = tensor
            if logical_offset_bytes is not None:
                self.logical_offsets_bytes[name] = int(logical_offset_bytes)
            else:
                self.logical_offsets_bytes.pop(name, None)

    def alias(self, name: str) -> Optional[PhysicalAlias]:
        with self._lock:
            alias = self.aliases.get(name)
            if alias is not None:
                return alias
            if name not in self.storage and name not in self.specs:
                return None
            tensor = self.storage.get(name)
            if tensor is None:
                tensor = self.allocate(name)
            logical_offset = self.logical_offsets_bytes.get(name)
            return as_physical_alias(
                tensor,
                logical_offset_bytes=logical_offset,
                name=name,
                storage_name=name,
                role=self._role_for_name(name),
            )

    def logical_offset_bytes(self, name: str) -> Optional[int]:
        with self._lock:
            alias = self.aliases.get(name)
            if alias is not None and alias.logical_offset_bytes is not None:
                return int(alias.logical_offset_bytes)
            return self.logical_offsets_bytes.get(name)

    def atomic_lock(self) -> Any:
        with self._lock:
            if self._atomic_lock is None:
                self._atomic_lock = multiprocessing.Lock()
            return self._atomic_lock

    @staticmethod
    def _is_view(spec: SharedTensorSpec) -> bool:
        src = spec.source_name
        return src is not None and src != "" and src != spec.name

    @staticmethod
    def _is_local_backed(spec: SharedTensorSpec) -> bool:
        return str(spec.role).lower() in _LOCAL_BACKING_ROLES

    def _alloc_shm(self, spec: SharedTensorSpec) -> Any:
        import numpy as np
        import torch
        np_dt = numpy_dtype(spec.dtype)
        torch_dt = torch_dtype(spec.dtype)
        itemsize = int(np.dtype(np_dt).itemsize)
        size_bytes = max(spec.numel * itemsize, 1)
        shm = shared_memory.SharedMemory(create=True, size=size_bytes)
        arr = np.ndarray(shape=spec.shape or (), dtype=np_dt, buffer=shm.buf)
        _initialize_storage_array(arr, spec)
        t = torch.from_numpy(arr)
        if t.dtype != torch_dt:
            t = t.view(torch_dt)
        self._shm_blocks[spec.name] = {"shm": shm, "owner": True}
        return t

    def _alloc_local_bank_view(self, spec: SharedTensorSpec) -> Any:
        bank_name = self._local_bank_name(spec)
        size_bytes = self._local_spec_size_bytes(spec)
        offset = int(getattr(spec, "storage_offset_bytes", 0) or 0)
        if offset < 0:
            raise ValueError("negative local storage offset for tensor: " + spec.name)
        bank = self._ensure_local_bank(bank_name)
        bank_size = int(bank["size_bytes"])
        if offset + size_bytes > bank_size:
            raise MemoryError(
                "local bank backing is too small: bank="
                + bank_name
                + " tensor="
                + spec.name
                + " offset="
                + str(offset)
                + " size="
                + str(size_bytes)
                + " bank_size="
                + str(bank_size)
            )

        base = bank["tensor"]
        byte_view = base.as_strided((size_bytes,), (1,), storage_offset=offset)
        t = byte_view.view(torch_dtype(spec.dtype))
        if spec.shape:
            t = t.view(spec.shape)
        _initialize_storage_tensor(t, spec)
        return t

    def _ensure_local_bank(self, bank_name: str) -> Dict[str, Any]:
        import numpy as np
        import torch

        bank = self._local_bank_blocks.get(bank_name)
        if bank is not None:
            return bank
        # The modeled bank capacity is a HARD cap: size the backing to exactly the
        # capacity so any tensor that overruns it errors (rather than silently
        # growing the backing). Banks with no modeled cap fall back to usage.
        cap_bytes = self._local_bank_capacity_bytes(bank_name)
        size_bytes = cap_bytes if cap_bytes > 0 else max(self._local_bank_size_bytes(bank_name), 1)
        shm = shared_memory.SharedMemory(create=True, size=size_bytes)
        arr = np.ndarray(shape=(size_bytes,), dtype=np.uint8, buffer=shm.buf)
        arr.fill(0)
        tensor = torch.from_numpy(arr)
        block = {"shm": shm, "owner": True, "size_bytes": size_bytes, "tensor": tensor}
        self._local_bank_blocks[bank_name] = block
        return block

    def _local_bank_size_bytes(self, bank_name: str) -> int:
        size = 0
        for spec in self.specs.values():
            if self._is_view(spec) or not self._is_local_backed(spec):
                continue
            if self._local_bank_name(spec) != bank_name:
                continue
            offset = int(getattr(spec, "storage_offset_bytes", 0) or 0)
            size = max(size, offset + self._local_spec_size_bytes(spec))
        return size

    @staticmethod
    def _local_bank_capacity_bytes(bank_name: str) -> int:
        try:
            from easyasc import globvars
            attr = _LOCAL_BANK_CAP_ATTR.get(bank_name)
            if not attr:
                return 0
            return int(max(float(getattr(globvars, attr, 0) or 0), 0.0) * 1024)
        except Exception:
            return 0

    @staticmethod
    def _local_spec_size_bytes(spec: SharedTensorSpec) -> int:
        size = int(getattr(spec, "storage_size_bytes", 0) or 0)
        if size > 0:
            return size
        return int(spec.numel) * dtype_size(spec.dtype)

    @staticmethod
    def _local_bank_name(spec: SharedTensorSpec) -> str:
        role = str(spec.role).lower()
        bank = str(getattr(spec, "storage_bank", "") or "")
        if not bank:
            bank = _LOCAL_BACKING_ROLE_TO_BANK.get(role, role.upper())
        if role == "ub" and bank == "UB":
            name = str(spec.name)
            if name.startswith("_vec1_") or re.match(r"^__local_c\d+_vec1__", name):
                return "UB1"
            return "UB0"
        return bank

    def _logical_offset_for_spec(self, spec: SharedTensorSpec) -> int:
        base = int(getattr(spec, "storage_offset_bytes", 0) or 0)
        if not self._is_view(spec):
            return base
        source_name = str(spec.source_name or "")
        source_offset = int(self.logical_offsets_bytes.get(source_name, 0) or 0)
        elem_offset = int(getattr(spec, "storage_offset", 0) or 0)
        if spec.dtype in ("int4", "fp4_e2m1", "fp4_e1m2"):
            # 4-bit dtypes pack two elements per carrier byte; no integer
            # dtype_size exists for them.
            return source_offset + base + elem_offset // 2
        return source_offset + base + elem_offset * dtype_size(spec.dtype)

    def _role_for_name(self, name: str) -> str:
        spec = self.specs.get(name)
        return str(getattr(spec, "role", "") or "")

    def _finalize_alias(
        self,
        name: str,
        alias: PhysicalAlias,
        logical_offset_bytes: Optional[int] = None,
    ) -> PhysicalAlias:
        updates: Dict[str, Any] = {}
        logical_view = alias.logical_tensor()
        storage_name = str(alias.storage_name or name)
        if logical_offset_bytes is not None:
            updates["logical_offset_bytes"] = int(logical_offset_bytes)
        if not alias.name:
            updates["name"] = str(name)
        if not alias.storage_name:
            updates["storage_name"] = storage_name
        if not alias.role:
            updates["role"] = self._role_for_name(storage_name or name)
        if not alias.dtype:
            updates["dtype"] = normalize_dtype(str(getattr(logical_view, "dtype", "")))
        if not alias.logical_shape:
            updates["logical_shape"] = tuple(int(v) for v in getattr(logical_view, "shape", ()))
        if not alias.logical_strides and hasattr(logical_view, "stride"):
            updates["logical_strides"] = tuple(int(v) for v in logical_view.stride())
        if not alias.storage_num_bytes:
            try:
                updates["storage_num_bytes"] = int(alias.tensor.untyped_storage().nbytes())
            except Exception:
                updates["storage_num_bytes"] = int(alias.tensor.numel()) * int(alias.tensor.element_size())
        if updates:
            alias = alias.with_updates(**updates)
        return alias

    def _resolve_view(self, spec: SharedTensorSpec) -> Any:
        source = self.tensor(spec.source_name)
        if spec.dtype in ("int4", "fp4_e2m1", "fp4_e1m2"):
            return source
        flat = source.reshape(-1)
        src_dtype = normalize_dtype(str(getattr(source, "dtype", "")))
        if src_dtype != spec.dtype:
            flat = flat.view(torch_dtype(spec.dtype))
        offset = spec.storage_offset
        vshape = spec.view_shape or spec.shape
        if spec.view_strides:
            return flat.as_strided(vshape, spec.view_strides, storage_offset=offset)
        vnumel = 1
        for d in vshape:
            vnumel *= d
        view = flat.narrow(0, offset, vnumel)
        return view.view(vshape) if vshape else view

    # -- Cross-process snapshot/restore --

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            if self._atomic_lock is None:
                self._atomic_lock = multiprocessing.Lock()
            snap_storage = {}
            for name, t in self.storage.items():
                blk = self._shm_blocks.get(name)
                if blk is not None:
                    snap_storage[name] = {"shm_name": blk["shm"].name}
                else:
                    snap_storage[name] = t
            return {
                "specs": [s.to_dict() for s in self.specs.values()],
                "storage": snap_storage,
                "aliases": {name: alias.to_dict() for name, alias in self.aliases.items()},
                "logical_offsets_bytes": dict(self.logical_offsets_bytes),
                "atomic_lock": self._atomic_lock,
            }

    def load_snapshot(self, snap: Dict[str, Any]) -> None:
        with self._lock:
            self.clear()
            self._atomic_lock = snap.get("atomic_lock")
            for item in snap.get("specs", []):
                spec = SharedTensorSpec.from_dict(item)
                self.specs[spec.name] = spec
            for name, val in snap.get("storage", {}).items():
                name = str(name)
                if isinstance(val, dict) and "shm_name" in val:
                    self.storage[name] = self._open_shm(name, val["shm_name"])
                else:
                    self.storage[name] = val
            for name, offset in snap.get("logical_offsets_bytes", {}).items():
                try:
                    self.logical_offsets_bytes[str(name)] = int(offset)
                except Exception:
                    continue
            for name, payload in snap.get("aliases", {}).items():
                if not isinstance(payload, dict):
                    continue
                alias_name = str(name)
                logical_view = self.storage.get(alias_name)
                storage_name = str(payload.get("storage_name", alias_name) or alias_name)
                tensor = self.storage.get(storage_name)
                if tensor is None and storage_name in self.specs:
                    tensor = self.tensor(storage_name)
                if tensor is None:
                    tensor = logical_view
                if tensor is None:
                    continue
                self.aliases[alias_name] = PhysicalAlias.from_dict(payload, tensor=tensor, logical_view=logical_view)

    def _open_shm(self, name: str, shm_name: str) -> Any:
        import numpy as np
        import torch
        spec = self.specs[name]
        shm = shared_memory.SharedMemory(name=shm_name)
        _detach_child_shm(shm)
        np_dt = numpy_dtype(spec.dtype)
        torch_dt = torch_dtype(spec.dtype)
        arr = np.ndarray(shape=spec.shape or (), dtype=np_dt, buffer=shm.buf)
        t = torch.from_numpy(arr)
        if t.dtype != torch_dt:
            t = t.view(torch_dt)
        self._shm_blocks[name] = {"shm": shm, "owner": False}
        return t

    def clear(self) -> None:
        with self._lock:
            for blk in self._shm_blocks.values():
                shm = blk.get("shm")
                if shm is None:
                    continue
                try:
                    shm.close()
                except Exception:
                    print(
                        "[simulator] SharedMemoryStore.clear shm.close suppressed: shm=%r\n%s"
                        % (shm, traceback.format_exc()),
                        file=sys.stderr, flush=True,
                    )
                if blk.get("owner"):
                    try:
                        shm.unlink()
                    except Exception:
                        print(
                            "[simulator] SharedMemoryStore.clear shm.unlink suppressed: shm=%r\n%s"
                            % (shm, traceback.format_exc()),
                            file=sys.stderr, flush=True,
                        )
            for blk in self._local_bank_blocks.values():
                shm = blk.get("shm")
                if shm is None:
                    continue
                try:
                    shm.close()
                except Exception:
                    print(
                        "[simulator] SharedMemoryStore.clear local shm.close suppressed: shm=%r\n%s"
                        % (shm, traceback.format_exc()),
                        file=sys.stderr, flush=True,
                    )
                if blk.get("owner"):
                    try:
                        shm.unlink()
                    except Exception:
                        print(
                            "[simulator] SharedMemoryStore.clear local shm.unlink suppressed: shm=%r\n%s"
                            % (shm, traceback.format_exc()),
                            file=sys.stderr, flush=True,
                        )
            self.specs.clear()
            self.storage.clear()
            self.aliases.clear()
            self.logical_offsets_bytes.clear()
            self._shm_blocks.clear()
            self._local_bank_blocks.clear()
            self._atomic_lock = None
