from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import struct

import torch

from .pipe import PipeBase
from .program import PipeTask
from .util import (
    align16, align_to,
    byte_storage_offset,
    decode_nz_to_nd, encode_nd_to_nz,
    decode_zz_to_nd, encode_nd_to_zz,
    gather_strided, local_slice_suffix, nz_footprint, require_burst_bytes, require_flat_elements, require_same_dtype,
    nz_tail_write_footprint,
    require_32b_aligned, require_strided_2d_elements, scatter_strided,
    zz_footprint,
)
from .memory import (
    L0AMX_BUFFER_NAME,
    L0BMX_BUFFER_NAME,
    L0MX_CAPACITY_BYTES,
    SharedTensorSpec,
    normalize_dtype,
)
from ..device_profile import is_a5_family, is_c220_family


def _int(value: Any, label: str) -> int:
    if isinstance(value, bool):
        return int(value)
    if not isinstance(value, (int, float)):
        raise TypeError(label + ": expected number, got " + str(type(value)))
    return int(value)


def _flat(tensor: torch.Tensor) -> torch.Tensor:
    return tensor.reshape(-1)


def _scalar_num(value: Any, default):
    """Resolve a possibly-Var fixpipe quant scalar to a Python number (sim args are pre-resolved)."""
    if isinstance(value, bool):
        return default
    if isinstance(value, (int, float)):
        return value
    inner = getattr(value, "value", None)
    if isinstance(inner, (int, float)) and not isinstance(inner, bool):
        return inner
    return default


def _fp19_trunc(scale: float) -> float:
    """Mirror the HW float19 scale: keep the top 19 bits of the fp32 (drop low 13 mantissa bits)."""
    bits = struct.unpack("<I", struct.pack("<f", float(scale)))[0] & 0xFFFFE000
    return struct.unpack("<f", struct.pack("<I", bits))[0]


def _apply_fixpipe_quant(decoded: torch.Tensor, dst_dtype: "torch.dtype", scale, offset) -> torch.Tensor:
    """Model a2/V220 + a5/C310 fixpipe scalar quant; non-scalar-quant dtypes pass through.

    8-bit:           s9 = clamp(round_half_even(src*scale19), -256, 255) + offset; sat s8/u8 by dtype.
    float/half/bf16: out = (dst)(src * scale19) -- covers the unscaled casts (scale=1: F322F16/
                     F322BF16/NoQuant), the int32 dequants (DEQF16, QS322BF16_PRE), and the a5 scaled
                     QF322F16/BF16/F32_PRE.
    fp8 e4m3:        QF322FP8_PRE = (float8_e4m3fn)(src * scale19).
    """
    if dst_dtype in (torch.int8, torch.uint8):
        x = decoded.to(torch.float32) * _fp19_trunc(scale)
        r = torch.round(x)                                   # round half to even
        r = torch.clamp(r, -256.0, 255.0) + float(offset)
        if dst_dtype == torch.int8:
            return torch.clamp(r, -128.0, 127.0).to(torch.int8)
        return torch.clamp(r, 0.0, 255.0).to(torch.uint8)
    _fp8 = (torch.float8_e4m3fn,) if hasattr(torch, "float8_e4m3fn") else ()
    if dst_dtype in (torch.float16, torch.bfloat16, torch.float32) + _fp8:
        return (decoded.to(torch.float32) * _fp19_trunc(scale)).to(dst_dtype)
    return decoded.to(dst_dtype)


def _logical_offset_bytes(memory_store: Any, name: str) -> Any:
    fn = getattr(memory_store, "logical_offset_bytes", None)
    if callable(fn):
        return fn(name)
    return None


def _flat_from_logical_offset(
    memory_store: Any,
    name: str,
    tensor: torch.Tensor,
    opname: str,
    role: str,
) -> torch.Tensor:
    logical_offset = _logical_offset_bytes(memory_store, name)
    byte_offset = byte_storage_offset(tensor) if logical_offset is None else int(logical_offset)
    if byte_offset % 32 != 0:
        raise RuntimeError(
            f"{opname} {role} address must be 32-byte aligned: "
            f"{name} has byte offset {byte_offset}"
        )

    if logical_offset is None:
        return _flat(tensor)

    base_offset = byte_storage_offset(tensor)
    rel_bytes = int(logical_offset) - int(base_offset)
    if rel_bytes < 0:
        raise RuntimeError(
            f"{opname} {role} logical offset is before tensor storage: "
            f"{name} logical={int(logical_offset)} base={base_offset}"
        )
    elem = int(tensor.element_size())
    if elem <= 0:
        raise RuntimeError(f"{opname} {role} has invalid element size: {elem}")
    if rel_bytes % elem != 0:
        raise RuntimeError(
            f"{opname} {role} logical offset is not element-aligned: "
            f"{name} rel_bytes={rel_bytes} elem={elem}"
        )
    elem_offset = rel_bytes // elem
    flat = _flat(tensor)
    if elem_offset > flat.numel():
        raise RuntimeError(
            f"{opname} {role} logical offset exceeds tensor storage: "
            f"{name} offset_elems={elem_offset} storage={flat.numel()}"
        )
    return flat[elem_offset:]


def _decode_nz_to_nd_window(
    src_flat: torch.Tensor,
    m: int,
    n: int,
    stride_m: int,
    c0: int,
    row0: int,
    col0: int,
) -> torch.Tensor:
    out = src_flat.new_zeros((m, n))
    if m == 0 or n == 0:
        return out
    src_col = 0
    while src_col < n:
        logical_col = col0 + src_col
        block = logical_col // c0
        within = logical_col % c0
        cols = min(c0 - within, n - src_col)
        base = block * stride_m * c0 + row0 * c0 + within
        for r in range(m):
            begin = base + r * c0
            out[r, src_col:src_col + cols].copy_(src_flat[begin:begin + cols])
        src_col += cols
    return out


def _atomic_scatter_reduce(flat: torch.Tensor, values: torch.Tensor, stride: int, mode: str) -> None:
    rows = int(values.shape[0])
    cols = int(values.shape[1]) if values.dim() >= 2 else 0
    if rows == 0 or cols == 0:
        return
    for r in range(rows):
        dst = flat[r * stride: r * stride + cols]
        src = values[r, :].to(flat.dtype)
        if mode == "atomic_add":
            dst += src
        elif mode == "atomic_max":
            dst.copy_(torch.maximum(dst, src))
        elif mode == "atomic_min":
            dst.copy_(torch.minimum(dst, src))
        else:
            raise ValueError("unsupported cube atomic mode: " + mode)


def _c0(tensor: torch.Tensor) -> int:
    return 32 // int(tensor.element_size())


def _device_type() -> str:
    from easyasc import globvars
    return str(getattr(globvars, "device_type", "")).lower()


def _is_c220_device() -> bool:
    return is_c220_family(_device_type())


def _is_a5_device() -> bool:
    return is_a5_family(_device_type())


def _is_int4_view_name(memory_store: Any, name: str) -> bool:
    if str(name).endswith(":int4"):
        return True
    specs = getattr(memory_store, "specs", {})
    spec = specs.get(name) if isinstance(specs, dict) else None
    return spec is not None and normalize_dtype(getattr(spec, "dtype", "")) == "int4"


def _fp4_view_dtype_name(memory_store: Any, name: str) -> str:
    text = str(name)
    if ":fp4_e2m1" in text:
        return "fp4_e2m1"
    if ":fp4_e1m2" in text:
        return "fp4_e1m2"
    specs = getattr(memory_store, "specs", {})
    spec = specs.get(name) if isinstance(specs, dict) else None
    dtype = normalize_dtype(getattr(spec, "dtype", "")) if spec is not None else ""
    if dtype in ("fp4_e2m1", "fp4_e1m2"):
        return dtype
    return ""


def _is_hif8_view_name(memory_store: Any, name: str) -> bool:
    text = str(name)
    if ":hif8" in text:
        return True
    specs = getattr(memory_store, "specs", {})
    if not isinstance(specs, dict):
        return False
    spec = specs.get(text)
    if spec is not None and normalize_dtype(getattr(spec, "dtype", "")) == "hif8":
        return True
    # GM slice views are named "<tmp>@<parent>:<offset>:offsets=...": the slice itself has
    # no spec (storage-only), but its parent reinterpret view (uint8 carrier -> hif8) does.
    if "@" in text:
        parent = text.split("@", 1)[1].split(":", 1)[0]
        parent_spec = specs.get(parent)
        if parent_spec is not None and normalize_dtype(getattr(parent_spec, "dtype", "")) == "hif8":
            return True
    return False


def _fp4_pack_axis_from_name(name: str) -> int:
    text = str(name)
    if ":axis0" in text:
        return 0
    return 1


def _flat_u8(tensor: torch.Tensor) -> torch.Tensor:
    return _flat(tensor).view(torch.uint8)


def _l0mx_name_for_dst_position(dst_position: str) -> str:
    if dst_position == "L0A":
        return L0AMX_BUFFER_NAME
    if dst_position == "L0B":
        return L0BMX_BUFFER_NAME
    raise ValueError("l1_to_l0_mx dst_position must be L0A or L0B, got: " + str(dst_position))


def _l0mx_operand_name(base_name: str, operand_name: str) -> str:
    return base_name + "@" + operand_name


def _select_l0mx_buffer_name(memory_store: Any, base_name: str, operand_name: str) -> str:
    scoped_name = _l0mx_operand_name(base_name, operand_name)
    if hasattr(memory_store, "contains") and memory_store.contains(scoped_name):
        return scoped_name
    return base_name


def _ensure_l0mx_buffer(memory_store: Any, name: str) -> torch.Tensor:
    if hasattr(memory_store, "contains") and memory_store.contains(name):
        return memory_store.tensor(name)
    if hasattr(memory_store, "register") and hasattr(memory_store, "allocate"):
        memory_store.register(SharedTensorSpec(name=name, shape=(L0MX_CAPACITY_BYTES,), dtype="uint8", role=name.strip("_")))
        return memory_store.allocate(name)

    tensor = torch.zeros(L0MX_CAPACITY_BYTES, dtype=torch.uint8)
    if hasattr(memory_store, "register_view"):
        memory_store.register_view(name, tensor)
        return tensor
    if hasattr(memory_store, "_tensors"):
        memory_store._tensors[name] = tensor
        return tensor
    raise KeyError("L0MX buffer is not allocated and memory store cannot create it: " + name)


def _register_l0mx_operand_snapshot(memory_store: Any, base_name: str, operand_name: str, buffer: torch.Tensor) -> None:
    snapshot_name = _l0mx_operand_name(base_name, operand_name)
    snapshot = _flat(buffer).clone()
    if hasattr(memory_store, "register_view"):
        memory_store.register_view(snapshot_name, snapshot)
        return
    if hasattr(memory_store, "_tensors"):
        memory_store._tensors[snapshot_name] = snapshot


def _mx_scale_group_count(k: int) -> int:
    return (int(k) + 31) // 32


def _mx_scale_k_blocks(k: int) -> int:
    return (int(k) + 63) // 64


def _decode_mx_scale_buffer(memory_store: Any, buffer_name: str, rows: int, k: int, opname: str) -> torch.Tensor:
    rows = int(rows)
    k = int(k)
    group_count = _mx_scale_group_count(k)
    k_blocks = _mx_scale_k_blocks(k)
    row_tiles = (rows + 15) // 16
    required = row_tiles * k_blocks * 32
    raw = _flat(_ensure_l0mx_buffer(memory_store, buffer_name)).view(torch.uint8)
    require_flat_elements(opname, "scale", buffer_name, raw, required)

    scales = torch.empty((rows, group_count), dtype=torch.float32, device=raw.device)
    for group in range(group_count):
        pair = group // 2
        subcol = group % 2
        for row_tile in range(row_tiles):
            row0 = row_tile * 16
            tile_rows = min(16, rows - row0)
            offset = (row_tile * k_blocks + pair) * 32 + subcol
            values = raw[offset:offset + tile_rows * 2:2].to(torch.float32)
            scales[row0:row0 + tile_rows, group].copy_(
                torch.pow(torch.full_like(values, 2.0), values - 127.0)
            )
    return scales


def _expand_mx_scale(scales: torch.Tensor, k: int) -> torch.Tensor:
    group_index = torch.arange(int(k), dtype=torch.long, device=scales.device) // 32
    return scales.index_select(1, group_index)


def _copy_mx_scale_blocks(
    src: torch.Tensor,
    dst: torch.Tensor,
    src_offset: int,
    rows: int,
    k: int,
    src_k: int,
) -> int:
    rows = int(rows)
    k = int(k)
    src_k = int(src_k)
    row_tiles = (rows + 15) // 16
    k_blocks = _mx_scale_k_blocks(k)
    src_k_blocks = _mx_scale_k_blocks(src_k)
    required_dst = row_tiles * k_blocks * 32
    if row_tiles == 0 or k_blocks == 0:
        return 0
    required_src = src_offset + ((row_tiles - 1) * src_k_blocks + (k_blocks - 1)) * 32 + 32
    require_flat_elements("l1_to_l0_mx", "src_mx", "src_mx", src, required_src)
    require_flat_elements("l1_to_l0_mx", "dst_mx", "dst_mx", dst, required_dst)
    dst.zero_()
    for row_tile in range(row_tiles):
        for k_block in range(k_blocks):
            src_start = src_offset + (row_tile * src_k_blocks + k_block) * 32
            dst_start = (row_tile * k_blocks + k_block) * 32
            dst[dst_start:dst_start + 32].copy_(src[src_start:src_start + 32])
    return required_dst


def _pack_dense_mx_scale(src_2d: torch.Tensor, rows: int, k_groups: int) -> torch.Tensor:
    rows = int(rows)
    k_groups = int(k_groups)
    row_tiles = (rows + 15) // 16
    half_cols = (k_groups + 1) // 2
    padded = torch.full((row_tiles * 16, half_cols * 2), 127, dtype=torch.uint8, device=src_2d.device)
    padded[:rows, :k_groups].copy_(src_2d.to(torch.uint8))
    blocks = []
    for row_tile in range(row_tiles):
        row0 = row_tile * 16
        for half_col in range(half_cols):
            col0 = half_col * 2
            blocks.append(padded[row0:row0 + 16, col0:col0 + 2].contiguous().reshape(32))
    if not blocks:
        return torch.zeros((0,), dtype=torch.uint8, device=src_2d.device)
    return torch.cat(blocks).contiguous()


def _unpack_signed_int4_cols(packed: torch.Tensor, logical_cols: int) -> torch.Tensor:
    logical_cols = int(logical_cols)
    if logical_cols < 0:
        raise ValueError("int4 logical column count must be non-negative, got " + str(logical_cols))
    rows = int(packed.shape[0])
    if logical_cols == 0:
        return torch.zeros((rows, 0), dtype=torch.int32, device=packed.device)

    carrier_cols = (logical_cols + 7) // 8
    raw = packed[:, :carrier_cols].to(torch.int64)
    shifts = torch.arange(8, dtype=torch.int64, device=raw.device) * 4
    nibbles = ((raw.unsqueeze(-1) >> shifts) & 0xF).to(torch.int32)
    signed = torch.where(nibbles >= 8, nibbles - 16, nibbles)
    return signed.reshape(rows, carrier_cols * 8)[:, :logical_cols].contiguous()


def _apply_b_device_int4_tail_transfer_quirk(
    a_nd: torch.Tensor,
    logical_m: int,
    logical_k: int,
    physical_carrier_cols: int,
) -> torch.Tensor:
    """Match the observed 910B3 wide-int4-tail transfer behavior.

    Real hardware zeroed the entire last partial 16-row block of L0A when all
    of the following were true:
    - A2/b* int4 MMAD path
    - logical K tail fits in <= 8 int32 carriers (<= 64 int4 elements)
    - the physical L1/L0A carrier width stays wide (> 8 carriers, e.g. 16)
    - M has a tail row block

    This is a transfer/decode quirk, not the mathematical MMAD contract. Keep it
    simulator-local so stable kernels can route around it explicitly.
    """
    logical_m = int(logical_m)
    logical_k = int(logical_k)
    physical_carrier_cols = int(physical_carrier_cols)
    if logical_m <= 0 or logical_k <= 0 or physical_carrier_cols <= 8:
        return a_nd
    logical_carrier_cols = (logical_k + 7) // 8
    if logical_carrier_cols > 8:
        return a_nd
    tail_rows = logical_m % 16
    if tail_rows == 0:
        return a_nd
    tail_row0 = logical_m - tail_rows
    out = a_nd.clone()
    out[tail_row0:logical_m, :].zero_()
    return out


def _unpack_fp4_nibbles(packed: torch.Tensor, logical_rows: int, logical_cols: int, pack_axis: int) -> torch.Tensor:
    logical_rows = int(logical_rows)
    logical_cols = int(logical_cols)
    if logical_rows < 0 or logical_cols < 0:
        raise ValueError("FP4 logical shape must be non-negative")
    if logical_rows == 0 or logical_cols == 0:
        return torch.zeros((logical_rows, logical_cols), dtype=torch.uint8, device=packed.device)
    raw = packed.to(torch.uint8)
    if int(pack_axis) == 0:
        carrier_rows = (logical_rows + 1) // 2
        raw = raw[:carrier_rows, :logical_cols]
        low = raw & 0x0F
        high = (raw >> 4) & 0x0F
        out = torch.empty((carrier_rows * 2, logical_cols), dtype=torch.uint8, device=raw.device)
        out[0::2, :].copy_(low)
        out[1::2, :].copy_(high)
        return out[:logical_rows, :].contiguous()

    carrier_cols = (logical_cols + 1) // 2
    raw = raw[:logical_rows, :carrier_cols]
    low = raw & 0x0F
    high = (raw >> 4) & 0x0F
    out = torch.empty((logical_rows, carrier_cols * 2), dtype=torch.uint8, device=raw.device)
    out[:, 0::2].copy_(low)
    out[:, 1::2].copy_(high)
    return out[:, :logical_cols].contiguous()


def _pack_fp4_nibbles(nibbles: torch.Tensor, pack_axis: int = 1) -> torch.Tensor:
    nibbles = nibbles.to(torch.uint8) & 0x0F
    rows = int(nibbles.shape[0])
    cols = int(nibbles.shape[1])
    if int(pack_axis) == 0:
        if rows % 2 != 0:
            pad = torch.zeros((1, cols), dtype=torch.uint8, device=nibbles.device)
            nibbles = torch.cat([nibbles, pad], dim=0)
        low = nibbles[0::2, :]
        high = nibbles[1::2, :]
        return (low | (high << 4)).contiguous()
    if cols % 2 != 0:
        pad = torch.zeros((rows, 1), dtype=torch.uint8, device=nibbles.device)
        nibbles = torch.cat([nibbles, pad], dim=1)
    low = nibbles[:, 0::2]
    high = nibbles[:, 1::2]
    return (low | (high << 4)).contiguous()


def _fp4_nibbles_to_values(nibbles: torch.Tensor, dtype_name: str) -> torch.Tensor:
    if dtype_name == "fp4_e2m1":
        table = torch.tensor([0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0], dtype=torch.float32, device=nibbles.device)
    elif dtype_name == "fp4_e1m2":
        table = torch.tensor([0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75], dtype=torch.float32, device=nibbles.device)
    else:
        raise TypeError("unknown FP4 dtype: " + str(dtype_name))
    low = (nibbles.to(torch.long) & 0x7)
    sign = (nibbles & 0x8) != 0
    values = table.index_select(0, low.reshape(-1)).reshape(nibbles.shape)
    return torch.where(sign, -values, values)


def _decode_fp4_l1_nibbles(
    src: torch.Tensor,
    src_name: str,
    logical_rows: int,
    logical_cols: int,
    pack_axis: int,
) -> torch.Tensor:
    if int(pack_axis) == 0:
        carrier_rows = (logical_rows + 1) // 2
        carrier_cols = logical_cols
    else:
        carrier_rows = logical_rows
        carrier_cols = (logical_cols + 1) // 2
    stride_m = align16(carrier_rows)
    require_flat_elements("l1_to_l0_mx", "src", src_name, src, nz_footprint(carrier_cols, stride_m, 32))
    carrier = decode_nz_to_nd(src, carrier_rows, carrier_cols, stride_m, 32)
    return _unpack_fp4_nibbles(carrier, logical_rows, logical_cols, pack_axis)


def _decode_fp4_l0_values(tensor: torch.Tensor, name: str, rows: int, cols: int, dtype_name: str) -> torch.Tensor:
    carrier_cols = (int(cols) + 1) // 2
    stride_m = align16(int(rows))
    raw = _flat_u8(tensor)
    require_flat_elements("mmad_mx", "src", name, raw, nz_footprint(carrier_cols, stride_m, 32))
    carrier = decode_nz_to_nd(raw, int(rows), carrier_cols, stride_m, 32)
    nibbles = _unpack_fp4_nibbles(carrier, int(rows), int(cols), 1)
    return _fp4_nibbles_to_values(nibbles, dtype_name)


def _decode_hif8_l0_values(tensor: torch.Tensor, name: str, rows: int, cols: int) -> torch.Tensor:
    from easyasc.dtypehelper.hif8_codec import hif8_to_fp32

    rows = int(rows)
    cols = int(cols)
    raw = _flat_u8(tensor)
    stride_m = align16(rows)
    require_flat_elements("mmad", "src", name, raw, nz_footprint(cols, stride_m, 32))
    carrier = decode_nz_to_nd(raw, rows, cols, stride_m, 32)
    return hif8_to_fp32(carrier)


# ---------------------------------------------------------------------------
# Layout rules summary:
#
# gm_to_l1 (MTE2):
#   B + float32:  ND → ZZ on L1
#   otherwise:    ND → NZ on L1
#
# l1_to_l0 (MTE1):
#   B + float32:
#     L0A: ZZ → ZZ (transpose: ZZ → NN)
#     L0B: ZZ → NZ (transpose: ZZ → ZN)
#   B + other dtype:
#     L0A: NZ → ZZ (transpose: NZ → NN)
#     L0B: NZ → NZ (transpose: NZ → ZN)
#   950:
#     L0A/L0B: NZ → NZ (transpose: NZ → ZN)
#
# mmad (M):
#   B:   L0A=ZZ, L0B=NZ
#   950: L0A=NZ, L0B=NZ
#   L0C: always NZ with c0=16
#
# l0c_to_l1 (FIX):
#   B + float32: not supported
#   L0C: always c0=16
#   L1:  c0 = 32 // elem_size
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# CubeMTE2 — GM → L1
# ---------------------------------------------------------------------------

@dataclass
class CubeMTE2Pipe(PipeBase):

    def execute(self, task: PipeTask) -> None:
        if task.opname == "gm_to_l1_nd2nz":
            self._gm_to_l1(task)
        elif task.opname == "gm_to_l1_dn2nz":
            self._gm_to_l1_dn2nz(task)
        elif task.opname == "gm_to_l1_mx_scale_nd2nz":
            self._gm_to_l1_mx_scale_nd2nz(task)
        elif task.opname == "gm_to_l1_pad":
            self._gm_to_l1_pad(task)
        elif task.opname == "gm_to_l1":
            self._gm_to_l1_contiguous(task)
        elif task.opname == "set_constant_to_l1":
            self._set_constant(task)
        else:
            raise NotImplementedError("CubeMTE2 unhandled op: " + task.opname)

    def _gm_to_l1(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("gm_to_l1_nd2nz", dst_tensor, src_tensor)
        require_32b_aligned("gm_to_l1_nd2nz", "dst", dst_name, dst_tensor)
        dst = _flat(dst_tensor)
        src = _flat(src_tensor)
        h = _int(a["M"], "M")
        w = _int(a["N"], "N")
        w_src = _int(a["N_src"], "N_src")
        h_dst = _int(a.get("M_dst", h), "M_dst")
        dst_row0 = 0
        dst_col0 = 0
        suffix = local_slice_suffix(dst_name)
        if suffix is not None:
            dst_row0, dst_col0 = suffix[0], suffix[1]

        if h == 0 or w == 0:
            raise ValueError("gm_to_l1_nd2nz requires non-zero M and N")
        if h < 0 or w < 0 or w_src < 0 or h_dst < 0:
            raise ValueError("gm_to_l1_nd2nz requires non-negative M, N, N_src, and M_dst")
        if h_dst == 0 or h > h_dst:
            raise ValueError("gm_to_l1_nd2nz requires 0 < M <= M_dst, got M=" + str(h) + ", M_dst=" + str(h_dst))
        if w > w_src:
            raise ValueError("gm_to_l1_nd2nz requires N <= N_src, got N=" + str(w) + ", N_src=" + str(w_src))
        if dst_row0 < 0 or dst_col0 < 0 or dst_row0 + h > h_dst:
            raise ValueError(
                "gm_to_l1_nd2nz destination window exceeds M_dst: "
                "dst_row0=" + str(dst_row0) + ", M=" + str(h) + ", M_dst=" + str(h_dst)
            )
        require_strided_2d_elements("gm_to_l1_nd2nz", "src", src_name, src, h, w, w_src)

        c0 = _c0(dst)
        if _is_c220_device() and dst.dtype == torch.float32:
            if dst_row0 != 0 or dst_col0 != 0:
                raise NotImplementedError("gm_to_l1_nd2nz partial ZZ destination writes are not implemented")
            n_align = align_to(w, c0)
            require_flat_elements("gm_to_l1_nd2nz", "dst", dst_name, dst, zz_footprint(h, n_align))
            dst.zero_()
            src_2d = src.as_strided((h, w), (w_src, 1))
            encode_nd_to_zz(src_2d, dst, h, w, n_align)
        else:
            stride_m = align16(h_dst)
            if h == h_dst and dst_row0 == 0 and dst_col0 == 0:
                require_flat_elements("gm_to_l1_nd2nz", "dst", dst_name, dst, nz_footprint(w, stride_m, c0))
                dst.zero_()
            else:
                require_flat_elements(
                    "gm_to_l1_nd2nz", "dst", dst_name, dst,
                    nz_tail_write_footprint(w, dst_row0, h, stride_m, c0, dst_col0),
                )
            src_2d = src.as_strided((h, w), (w_src, 1))
            encode_nd_to_nz(src_2d, dst, h, w, stride_m, c0, dst_row0, dst_col0)

    def _gm_to_l1_dn2nz(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("gm_to_l1_dn2nz", dst_tensor, src_tensor)
        require_32b_aligned("gm_to_l1_dn2nz", "dst", dst_name, dst_tensor)
        if _is_c220_device():
            raise NotImplementedError("gm_to_l1_dn2nz is a5-only")
        dst = _flat(dst_tensor)
        src = _flat(src_tensor)
        h = _int(a["M"], "M")
        w = _int(a["N"], "N")
        w_src = _int(a["N_src"], "N_src")
        h_dst = _int(a.get("M_dst", h), "M_dst")
        dst_row0 = 0
        dst_col0 = 0
        suffix = local_slice_suffix(dst_name)
        if suffix is not None:
            dst_row0, dst_col0 = suffix[0], suffix[1]

        if h == 0 or w == 0:
            raise ValueError("gm_to_l1_dn2nz requires non-zero M and N")
        if h < 0 or w < 0 or w_src < 0 or h_dst < 0:
            raise ValueError("gm_to_l1_dn2nz requires non-negative M, N, N_src, and M_dst")
        if h_dst == 0 or h > h_dst:
            raise ValueError("gm_to_l1_dn2nz requires 0 < M <= M_dst, got M=" + str(h) + ", M_dst=" + str(h_dst))
        if h > w_src:
            raise ValueError("gm_to_l1_dn2nz requires M <= N_src (GM row stride), got M=" + str(h) + ", N_src=" + str(w_src))
        if dst_row0 < 0 or dst_col0 < 0 or dst_row0 + h > h_dst:
            raise ValueError(
                "gm_to_l1_dn2nz destination window exceeds M_dst: "
                "dst_row0=" + str(dst_row0) + ", M=" + str(h) + ", M_dst=" + str(h_dst)
            )
        # GM holds the matrix transposed: rows are dst columns (w of them), each row stride w_src.
        require_strided_2d_elements("gm_to_l1_dn2nz", "src", src_name, src, w, h, w_src)

        c0 = _c0(dst)
        stride_m = align16(h_dst)
        if h == h_dst and dst_row0 == 0 and dst_col0 == 0:
            require_flat_elements("gm_to_l1_dn2nz", "dst", dst_name, dst, nz_footprint(w, stride_m, c0))
            dst.zero_()
        else:
            require_flat_elements(
                "gm_to_l1_dn2nz", "dst", dst_name, dst,
                nz_tail_write_footprint(w, dst_row0, h, stride_m, c0, dst_col0),
            )
        src_2d = src.as_strided((h, w), (1, w_src))
        encode_nd_to_nz(src_2d, dst, h, w, stride_m, c0, dst_row0, dst_col0)

    def _gm_to_l1_mx_scale_nd2nz(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("gm_to_l1_mx_scale_nd2nz", dst_tensor, src_tensor)
        require_32b_aligned("gm_to_l1_mx_scale_nd2nz", "dst", dst_name, dst_tensor)
        if _is_c220_device():
            raise NotImplementedError("gm_to_l1_mx_scale_nd2nz is a5-only")
        rows = _int(a["rows"], "rows")
        k_groups = _int(a["k_groups"], "k_groups")
        src_k_groups = _int(a["src_k_groups"], "src_k_groups")
        if rows <= 0 or k_groups <= 0 or src_k_groups <= 0:
            raise ValueError("gm_to_l1_mx_scale_nd2nz requires positive rows, k_groups, and src_k_groups")
        if rows % 16 != 0:
            raise ValueError("gm_to_l1_mx_scale_nd2nz currently requires 16-row aligned rows")
        if k_groups > src_k_groups:
            raise ValueError(
                "gm_to_l1_mx_scale_nd2nz requires k_groups <= src_k_groups, got "
                + str(k_groups) + " > " + str(src_k_groups)
            )
        dst_shape = getattr(dst_tensor, "shape", None)
        if isinstance(dst_shape, (list, tuple)) and len(dst_shape) == 2:
            if int(dst_shape[0]) != rows:
                raise ValueError(
                    "gm_to_l1_mx_scale_nd2nz requires dst rows to match rows, got "
                    + str(list(dst_shape)) + " vs rows=" + str(rows)
                )
            expected_cols = ((k_groups + 1) // 2) * 2
            if int(dst_shape[1]) != expected_cols:
                raise ValueError(
                    "gm_to_l1_mx_scale_nd2nz requires dst cols = 2 * ceil(k_groups / 2), got "
                    + str(list(dst_shape)) + " vs k_groups=" + str(k_groups)
                )
        src = _flat(src_tensor)
        dst = _flat(dst_tensor)
        require_strided_2d_elements("gm_to_l1_mx_scale_nd2nz", "src", src_name, src, rows, k_groups, src_k_groups)
        required_dst = (rows // 16) * ((k_groups + 1) // 2) * 32
        require_flat_elements("gm_to_l1_mx_scale_nd2nz", "dst", dst_name, dst, required_dst)
        src_2d = src.as_strided((rows, k_groups), (src_k_groups, 1))
        packed = _pack_dense_mx_scale(src_2d, rows, k_groups)
        dst.zero_()
        dst[:required_dst].copy_(packed)

    def _gm_to_l1_pad(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("gm_to_l1_pad", dst_tensor, src_tensor)
        require_32b_aligned("gm_to_l1_pad", "dst", dst_name, dst_tensor)
        dst = _flat(dst_tensor)
        src = _flat(src_tensor)
        n_burst = _int(a["n_burst"], "n_burst")
        burst_len = _int(a["burst_len_byte"], "burst_len_byte")
        src_stride_raw = _int(a["src_stride_byte"], "src_stride_byte")
        dst_stride_raw = _int(a["dst_stride"], "dst_stride")

        if n_burst < 0 or burst_len < 0 or src_stride_raw < 0 or dst_stride_raw < 0:
            raise ValueError(
                "gm_to_l1_pad requires non-negative n_burst, burst_len_byte, src_stride_byte, and dst_stride"
            )
        if n_burst == 0 or burst_len == 0:
            return

        aligned_burst = align_to(burst_len, 32)
        src_step = burst_len + src_stride_raw
        dst_step = aligned_burst + dst_stride_raw * 32
        src_bytes = src.view(torch.uint8)
        dst_bytes = dst.view(torch.uint8)
        require_burst_bytes("gm_to_l1_pad", "src", src_name, src_bytes, n_burst, src_step, burst_len)
        require_burst_bytes("gm_to_l1_pad", "dst", dst_name, dst_bytes, n_burst, dst_step, aligned_burst)
        for i in range(n_burst):
            sb = i * src_step
            db = i * dst_step
            dst_bytes[db:db + burst_len].copy_(src_bytes[sb:sb + burst_len])
            if aligned_burst > burst_len:
                dst_bytes[db + burst_len:db + aligned_burst].zero_()

    def _gm_to_l1_contiguous(self, task: PipeTask) -> None:
        # Plain DataCopy burst (GM2L1): blockLen / strides are in 32-byte block units
        # (no per-burst byte padding -- the unit is already a whole 32B block). Used
        # to stage a contiguous row (e.g. a matmul bias) in L1 on a2, where the pad
        # form (gm_to_l1_pad / DataCopyPad) is unavailable.
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("gm_to_l1", dst_tensor, src_tensor)
        require_32b_aligned("gm_to_l1", "dst", dst_name, dst_tensor)
        dst = _flat(dst_tensor)
        src = _flat(src_tensor)
        n_burst = _int(a["n_burst"], "n_burst")
        burst_len = _int(a["burst_len"], "burst_len")
        src_stride = _int(a["src_stride"], "src_stride")
        dst_stride = _int(a["dst_stride"], "dst_stride")
        if n_burst < 0 or burst_len < 0 or src_stride < 0 or dst_stride < 0:
            raise ValueError("gm_to_l1 requires non-negative n_burst, burst_len, src_stride, and dst_stride")
        if n_burst == 0 or burst_len == 0:
            return
        burst_bytes = burst_len * 32
        src_step = (burst_len + src_stride) * 32
        dst_step = (burst_len + dst_stride) * 32
        src_bytes = src.view(torch.uint8)
        dst_bytes = dst.view(torch.uint8)
        require_burst_bytes("gm_to_l1", "src", src_name, src_bytes, n_burst, src_step, burst_bytes)
        require_burst_bytes("gm_to_l1", "dst", dst_name, dst_bytes, n_burst, dst_step, burst_bytes)
        for i in range(n_burst):
            sb = i * src_step
            db = i * dst_step
            dst_bytes[db:db + burst_bytes].copy_(src_bytes[sb:sb + burst_bytes])

    def _set_constant(self, task: PipeTask) -> None:
        a = task.args
        name = a.get("tensor", a.get("dst"))
        tensor_name = str(name)
        tensor_raw = self.memory_store.tensor(tensor_name)
        require_32b_aligned("set_constant_to_l1", "tensor", tensor_name, tensor_raw)
        tensor = _flat(tensor_raw)
        n_blocks = _int(a["n_blocks"], "n_blocks")
        val = a.get("val", a.get("value"))
        c0 = _c0(tensor)
        if n_blocks < 0:
            raise ValueError("set_constant_to_l1 requires non-negative n_blocks, got " + str(n_blocks))
        # 8-bit fills are legal on A5: InitConstValue is a plain template over
        # the tensor dtype in the board headers, and the shipped GQA kernels
        # zero their L1 tiles through a .reinterpret(uint8) view on real
        # hardware.  Only the 64-bit widths stay rejected here.
        if _is_a5_device() and tensor.dtype not in (
            torch.float16, torch.bfloat16, torch.float32,
            torch.int8, torch.uint8,
            torch.int16, torch.uint16, torch.int32, torch.uint32,
        ):
            raise RuntimeError(
                "set_constant_to_l1 on A5 does not support tensor dtype "
                + str(tensor.dtype)
            )
        fill = n_blocks * c0
        if fill > 0:
            require_flat_elements("set_constant_to_l1", "tensor", tensor_name, tensor, fill)
            tensor[:fill].fill_(float(val))


# ---------------------------------------------------------------------------
# CubeMTE1 — L1 → L0
# ---------------------------------------------------------------------------

@dataclass
class CubeMTE1Pipe(PipeBase):

    def execute(self, task: PipeTask) -> None:
        if task.opname == "l1_to_l0":
            self._l1_to_l0(task)
        elif task.opname == "l1_to_l0_mx":
            self._l1_to_l0_mx(task)
        elif task.opname == "l1_to_l0_img2col":
            self._l1_to_l0_img2col(task)
        elif task.opname == "l1_to_bt":
            self._l1_to_bt(task)
        else:
            raise NotImplementedError("CubeMTE1 unhandled op: " + task.opname)

    def _l1_to_l0_img2col(self, task: PipeTask) -> None:
        # load3d (LOAD3Dv2) golden model: NC1HWC0 fmap in L1 -> img2col window
        # [m_ext, k_ext] -> L0A fractal. The logical img2col gather (K order: C1
        # slow, Kh, Kw, C0 fast; m = ho*Wo + wo; out-of-range reads padValue=0) is
        # identical on a2 and a5; only the L0A fractal layout differs: a2/b* = ZZ,
        # a5/950 = NZ. The a5 NZ model is real-HW-validated on Ascend950: the
        # L12L0A_IMG2COL C0-chunk loop writes one NZ K-fractal per chunk and a
        # following mmad reads L0A as NZ (matching _mmad's a5 decode_nz path).
        # Reference: the documented load3d/img2col semantics in doc/topics/conv2d.md.
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_32b_aligned("l1_to_l0_img2col", "dst", dst_name, dst_tensor)
        require_32b_aligned("l1_to_l0_img2col", "src", src_name, src_tensor)
        dst = _flat(dst_tensor)
        src = _flat(src_tensor)
        if dst.dtype != src.dtype:
            dst = dst.view(src.dtype)
            self.memory_store.register_view(dst_name, dst)

        h, w, c, c0 = (_int(a[k], k) for k in ("h", "w", "c", "c0"))
        kh, kw = _int(a["kh"], "kh"), _int(a["kw"], "kw")
        pl, pr = _int(a["pad_l"], "pad_l"), _int(a["pad_r"], "pad_r")
        pt, pb = _int(a["pad_t"], "pad_t"), _int(a["pad_b"], "pad_b")
        sh, sw = _int(a["stride_h"], "stride_h"), _int(a["stride_w"], "stride_w")
        dh, dw = _int(a["dil_h"], "dil_h"), _int(a["dil_w"], "dil_w")
        m0, k0 = _int(a["m0"], "m0"), _int(a["k0"], "k0")
        m_ext, k_ext = _int(a["m_ext"], "m_ext"), _int(a["k_ext"], "k_ext")
        c1 = (c + c0 - 1) // c0
        if m_ext <= 0 or k_ext <= 0:
            raise ValueError("l1_to_l0_img2col requires positive extents")
        if m_ext % 16 != 0 or k_ext % c0 != 0 or m0 % 16 != 0 or k0 % c0 != 0:
            raise ValueError("l1_to_l0_img2col window must be 16/C0 aligned")
        require_flat_elements("l1_to_l0_img2col", "src", src_name, src, c1 * h * w * c0)

        ho = (h + pt + pb - (dh * (kh - 1) + 1)) // sh + 1
        wo = (w + pl + pr - (dw * (kw - 1) + 1)) // sw + 1
        fm = src[: c1 * h * w * c0].reshape(c1, h, w, c0).float()
        # Vectorized img2col window: decompose the m/k index grids and gather
        # once; one mask covers the M tail, spatial padding, and channel tail
        # (all read padValue=0, matching LOAD3Dv2 with PADDING=0).
        m_idx = m0 + torch.arange(m_ext)
        k_idx = k0 + torch.arange(k_ext)
        oh, ow = m_idx // wo, m_idx % wo
        kc1, r = k_idx // (kh * kw * c0), k_idx % (kh * kw * c0)
        fkh, r = r // (kw * c0), r % (kw * c0)
        fkw, kc0 = r // c0, r % c0
        ih = (oh * sh - pt)[:, None] + (fkh * dh)[None, :]
        iw = (ow * sw - pl)[:, None] + (fkw * dw)[None, :]
        valid = ((m_idx < ho * wo)[:, None]
                 & (ih >= 0) & (ih < h) & (iw >= 0) & (iw < w)
                 & ((kc1 * c0 + kc0) < c)[None, :])
        flat = ((kc1[None, :] * h + ih.clamp(0, h - 1)) * w + iw.clamp(0, w - 1)) * c0 + kc0[None, :]
        gathered = fm.reshape(-1)[flat]
        # LOAD3Dv2 returns padValue=0 for every invalid spatial/channel cell; it
        # does not read a clamped source and then multiply by a boolean mask.
        # Multiplication is observably wrong for non-finite source data because
        # Inf * 0 becomes NaN and contaminates otherwise valid boundary rows.
        out = torch.where(valid, gathered, torch.zeros_like(gathered))
        logical = out.to(src.dtype)
        if _is_c220_device():
            n_align = align_to(k_ext, c0)
            require_flat_elements("l1_to_l0_img2col", "dst", dst_name, dst, zz_footprint(m_ext, n_align))
            dst.zero_()
            encode_nd_to_zz(logical, dst, m_ext, k_ext, n_align)
        else:
            stride_m = align16(m_ext)
            require_flat_elements("l1_to_l0_img2col", "dst", dst_name, dst, nz_footprint(k_ext, stride_m, c0))
            dst.zero_()
            encode_nd_to_nz(logical, dst, m_ext, k_ext, stride_m, c0)

    def _l1_to_l0_mx(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        src_mx_name = str(a["src_mx"])
        src_mx_tensor = self.memory_store.tensor(src_mx_name)
        require_32b_aligned("l1_to_l0_mx", "src_mx", src_mx_name, src_mx_tensor)

        m_dst = _int(a["m_dst"], "m_dst")
        n_dst = _int(a["n_dst"], "n_dst")
        m_src = _int(a["m_src"], "m_src")
        n_src = _int(a["n_src"], "n_src")
        src_is_transpose = bool(a.get("src_is_transpose", False))
        if m_dst == 0 or n_dst == 0:
            raise ValueError("l1_to_l0_mx requires non-zero m_dst and n_dst")
        if m_dst < 0 or n_dst < 0 or m_src < 0 or n_src < 0:
            raise ValueError("l1_to_l0_mx requires non-negative m_dst, n_dst, m_src, and n_src")

        if src_is_transpose:
            scale_rows = n_dst
            scale_k = m_dst
            scale_src_rows = n_src
            scale_src_k = m_src
        else:
            scale_rows = m_dst
            scale_k = n_dst
            scale_src_rows = m_src
            scale_src_k = n_src
        src_mx_offset = _int(a.get("src_mx_offset_element", 0), "src_mx_offset_element")
        src_mx_row0 = _int(a.get("src_mx_row0", 0), "src_mx_row0")
        src_mx_col0 = _int(a.get("src_mx_col0", 0), "src_mx_col0")
        if src_mx_offset < 0 or src_mx_row0 < 0 or src_mx_col0 < 0:
            raise ValueError("l1_to_l0_mx requires non-negative MX source offsets")
        src_mx_offset += src_mx_row0 * 32 + src_mx_col0 * scale_src_rows

        src_mx = _flat(src_mx_tensor).view(torch.uint8)
        mx_name = _l0mx_name_for_dst_position(str(a.get("dst_position", "")))
        mx_buffer = _flat(_ensure_l0mx_buffer(self.memory_store, mx_name)).view(torch.uint8)
        _copy_mx_scale_blocks(src_mx, mx_buffer, src_mx_offset, scale_rows, scale_k, scale_src_k)
        _register_l0mx_operand_snapshot(self.memory_store, mx_name, dst_name, mx_buffer)

        if _fp4_view_dtype_name(self.memory_store, src_name):
            self._l1_to_l0_mx_fp4(task)
            return
        self._l1_to_l0(task)

    def _l1_to_l0_mx_fp4(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_32b_aligned("l1_to_l0_mx", "dst", dst_name, dst_tensor)
        require_32b_aligned("l1_to_l0_mx", "src", src_name, src_tensor)

        m_dst = _int(a["m_dst"], "m_dst")
        n_dst = _int(a["n_dst"], "n_dst")
        m_src = _int(a["m_src"], "m_src")
        n_src = _int(a["n_src"], "n_src")
        src_row0 = _int(a.get("src_row0", 0), "src_row0")
        src_col0 = _int(a.get("src_col0", 0), "src_col0")
        src_is_transpose = bool(a.get("src_is_transpose", False))
        if src_row0 < 0 or src_col0 < 0:
            raise ValueError("l1_to_l0_mx requires non-negative FP4 source offsets")
        if src_row0 + m_dst > m_src or src_col0 + n_dst > n_src:
            raise RuntimeError(
                "l1_to_l0_mx FP4 source logical window exceeds declared source shape: "
                "rows=" + str(src_row0 + m_dst) + "/" + str(m_src)
                + ", cols=" + str(src_col0 + n_dst) + "/" + str(n_src)
            )

        src_bytes = _flat_u8(src_tensor)
        dst_bytes = _flat_u8(dst_tensor)
        src_axis = _fp4_pack_axis_from_name(src_name)
        logical_full = _decode_fp4_l1_nibbles(src_bytes, src_name, m_src, n_src, src_axis)
        logical = logical_full[src_row0:src_row0 + m_dst, src_col0:src_col0 + n_dst].contiguous()
        if src_is_transpose:
            logical = logical.transpose(0, 1).contiguous()
            out_m, out_n = n_dst, m_dst
        else:
            out_m, out_n = m_dst, n_dst

        carrier = _pack_fp4_nibbles(logical, pack_axis=1)
        carrier_cols = int(carrier.shape[1])
        stride_m = align16(out_m)
        require_flat_elements("l1_to_l0_mx", "dst", dst_name, dst_bytes, nz_footprint(carrier_cols, stride_m, 32))
        dst_bytes.zero_()
        encode_nd_to_nz(carrier, dst_bytes, out_m, carrier_cols, stride_m, 32)

    def _l1_to_l0(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_32b_aligned("l1_to_l0", "dst", dst_name, dst_tensor)
        require_32b_aligned("l1_to_l0", "src", src_name, src_tensor)
        dst = _flat(dst_tensor)
        src = _flat(src_tensor)
        if dst.dtype != src.dtype:
            dst = dst.view(src.dtype)
            self.memory_store.register_view(dst_name, dst)
        m_dst = _int(a["m_dst"], "m_dst")
        n_dst = _int(a["n_dst"], "n_dst")
        m_src = _int(a["m_src"], "m_src")
        n_src = _int(a["n_src"], "n_src")
        is_transpose = bool(a.get("src_is_transpose", False))
        src_row0 = _int(a.get("src_row0", 0), "src_row0")
        src_col0 = _int(a.get("src_col0", 0), "src_col0")
        dst_pos = str(a.get("dst_position", ""))
        is_l0a = dst_pos == "L0A"

        c0 = _c0(dst)
        b_float = _is_c220_device() and src.dtype == torch.float32
        req_rows = src_row0 + m_dst
        req_cols = src_col0 + n_dst
        if m_dst == 0 or n_dst == 0:
            raise ValueError("l1_to_l0 requires non-zero m_dst and n_dst")
        if m_dst < 0 or n_dst < 0 or m_src < 0 or n_src < 0 or src_row0 < 0 or src_col0 < 0:
            raise ValueError("l1_to_l0 requires non-negative dimensions and source offsets")
        if req_rows > m_src or req_cols > n_src:
            raise RuntimeError(
                "l1_to_l0 source logical window exceeds declared source shape: "
                "rows=" + str(req_rows) + "/" + str(m_src)
                + ", cols=" + str(req_cols) + "/" + str(n_src)
            )
        if _is_a5_device() and src.dtype in (torch.int8, torch.uint8):
            bad_col_tail = src_col0 > 0 and n_dst % c0 != 0
            bad_row_tail = src_row0 > 0 and m_dst % c0 != 0
            if bad_col_tail or bad_row_tail:
                raise RuntimeError(
                    "l1_to_l0 on A5 requires a nonzero-offset byte tail "
                    "to be C0-aligned: src_row0=" + str(src_row0)
                    + ", src_col0=" + str(src_col0)
                    + ", m_dst=" + str(m_dst) + ", n_dst=" + str(n_dst)
                    + ", C0=" + str(c0)
                )

        # --- Decode source from L1 ---
        if b_float:
            n_align = align_to(n_src, c0)
            require_flat_elements("l1_to_l0", "src", src_name, src, zz_footprint(req_rows, n_align))
            logical_full = decode_zz_to_nd(src, req_rows, req_cols, n_align)
        else:
            stride_m = align16(m_src)
            require_flat_elements("l1_to_l0", "src", src_name, src, nz_footprint(req_cols, stride_m, c0))
            logical_full = decode_nz_to_nd(src, req_rows, req_cols, stride_m, c0)

        logical = logical_full[src_row0:src_row0 + m_dst, src_col0:src_col0 + n_dst].contiguous()

        if is_transpose:
            logical = logical.transpose(0, 1).contiguous()
            out_m, out_n = n_dst, m_dst
        else:
            out_m, out_n = m_dst, n_dst

        # B-series L0A → ZZ; everything else → NZ
        if _is_c220_device() and is_l0a:
            n_align = align_to(out_n, c0)
            require_flat_elements("l1_to_l0", "dst", dst_name, dst, zz_footprint(out_m, n_align))
            dst.zero_()
            encode_nd_to_zz(logical, dst, out_m, out_n, n_align)
        else:
            stride_m = align16(out_m)
            require_flat_elements("l1_to_l0", "dst", dst_name, dst, nz_footprint(out_n, stride_m, c0))
            dst.zero_()
            encode_nd_to_nz(logical, dst, out_m, out_n, stride_m, c0)

    def _l1_to_bt(self, task: PipeTask) -> None:
        # Logical bias-table load: copy the first n bias values from the contiguous
        # L1 source into the BT (C2) buffer. The simulator models BT as a flat
        # logical [n] vector; the hardware C2 fractal / 2-slot layout is a
        # codegen-only concern, so no NZ encode is needed here.
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_32b_aligned("l1_to_bt", "dst", dst_name, dst_tensor)
        require_32b_aligned("l1_to_bt", "src", src_name, src_tensor)
        dst = _flat(dst_tensor)
        # Honor a contiguous L1 src offset (matmul shortcut stages per-N-tile bias
        # slices bias[:, n0:n0+valid_n]); a base tensor reports offset 0 here.
        src = _flat_from_logical_offset(self.memory_store, src_name, src_tensor, "l1_to_bt", "src")
        n = _int(a["n"], "n")
        if n < 0:
            raise ValueError("l1_to_bt requires non-negative n")
        require_flat_elements("l1_to_bt", "src", src_name, src, n)
        require_flat_elements("l1_to_bt", "dst", dst_name, dst, n)
        # MTE1 performs a numeric fp16/bf16 -> fp32 widening for the floating
        # bias path. Same-dtype fp32/int32 remains an ordinary logical copy.
        dst[:n].copy_(src[:n].to(dst.dtype))



# ---------------------------------------------------------------------------
# MPipe — matrix multiply accumulate
# ---------------------------------------------------------------------------

@dataclass
class MPipe(PipeBase):

    def execute(self, task: PipeTask) -> None:
        if task.opname == "mmad":
            self._mmad(task)
        elif task.opname == "mmad_mx":
            self._mmad_mx(task)
        else:
            raise NotImplementedError("MPipe unhandled op: " + task.opname)

    @staticmethod
    def _compute_dtype(dt: torch.dtype) -> torch.dtype:
        if dt in (torch.float16, torch.bfloat16):
            return torch.float32
        if dt in (torch.int8, torch.uint8, torch.int16):
            return torch.int32
        return dt

    def _mmad_mx(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_a_name = str(a["src_a"])
        src_b_name = str(a["src_b"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_a_tensor = self.memory_store.tensor(src_a_name)
        src_b_tensor = self.memory_store.tensor(src_b_name)
        require_32b_aligned("mmad_mx", "dst", dst_name, dst_tensor)
        require_32b_aligned("mmad_mx", "src_a", src_a_name, src_a_tensor)
        require_32b_aligned("mmad_mx", "src_b", src_b_name, src_b_tensor)
        if dst_tensor.dtype != torch.float32:
            raise TypeError("mmad_mx requires float32 L0C destination, got " + str(dst_tensor.dtype))
        src_a_fp4_dtype = _fp4_view_dtype_name(self.memory_store, src_a_name)
        src_b_fp4_dtype = _fp4_view_dtype_name(self.memory_store, src_b_name)
        uses_fp4 = bool(src_a_fp4_dtype or src_b_fp4_dtype)
        if uses_fp4 and not (src_a_fp4_dtype and src_b_fp4_dtype):
            raise TypeError("mmad_mx requires both sources to be FP4 views when either source is FP4")
        if not uses_fp4:
            if not str(src_a_tensor.dtype).startswith("torch.float8_"):
                raise TypeError("mmad_mx requires FP8 or FP4 L0A source, got " + str(src_a_tensor.dtype))
            if not str(src_b_tensor.dtype).startswith("torch.float8_"):
                raise TypeError("mmad_mx requires FP8 or FP4 L0B source, got " + str(src_b_tensor.dtype))

        dst = _flat(dst_tensor)
        m = _int(a["M"], "M")
        n = _int(a["N"], "N")
        k = _int(a["K"], "K")
        if m == 0 or n == 0 or k == 0:
            raise ValueError("mmad_mx requires non-zero M, N, and K")
        if m < 0 or n < 0 or k < 0:
            raise ValueError("mmad_mx requires non-negative M, N, and K")

        is_init = bool(a.get("is_init", True))
        dst_row0 = _int(a.get("dst_row0", 0), "dst_row0")
        dst_col0 = _int(a.get("dst_col0", 0), "dst_col0")
        dst_rows = _int(a.get("dst_rows", m), "dst_rows")
        dst_cols = _int(a.get("dst_cols", n), "dst_cols")
        if dst_row0 < 0 or dst_col0 < 0 or dst_rows < 0 or dst_cols < 0:
            raise ValueError("mmad_mx requires non-negative destination offsets and shape")

        c0_dst = 16
        if uses_fp4:
            a_nd = _decode_fp4_l0_values(src_a_tensor, src_a_name, m, k, src_a_fp4_dtype)
            b_nd = _decode_fp4_l0_values(src_b_tensor, src_b_name, n, k, src_b_fp4_dtype)
        else:
            src_a = _flat(src_a_tensor)
            src_b = _flat(src_b_tensor)
            c0_a = _c0(src_a)
            c0_b = _c0(src_b)
            require_flat_elements("mmad_mx", "src_a", src_a_name, src_a, nz_footprint(k, align16(m), c0_a))
            require_flat_elements("mmad_mx", "src_b", src_b_name, src_b, nz_footprint(k, align16(n), c0_b))
            a_nd = decode_nz_to_nd(src_a, m, k, align16(m), c0_a).to(torch.float32)
            b_nd = decode_nz_to_nd(src_b, n, k, align16(n), c0_b).to(torch.float32)
        scale_a_name = _select_l0mx_buffer_name(self.memory_store, L0AMX_BUFFER_NAME, src_a_name)
        scale_b_name = _select_l0mx_buffer_name(self.memory_store, L0BMX_BUFFER_NAME, src_b_name)
        scale_a = _decode_mx_scale_buffer(self.memory_store, scale_a_name, m, k, "mmad_mx")
        scale_b = _decode_mx_scale_buffer(self.memory_store, scale_b_name, n, k, "mmad_mx")
        a_scaled = a_nd * _expand_mx_scale(scale_a, k)
        b_scaled = b_nd * _expand_mx_scale(scale_b, k)
        prod = torch.matmul(a_scaled, b_scaled.transpose(0, 1))

        # Bias table (C2): C = bias + (scaled A)@(scaled B) on the is_init tile. The DSL
        # restricts bias to the is_init tile, and the simulator stores BT as a flat logical
        # [n] fp32 vector (see _l1_to_bt), so broadcast it over the m output rows.
        bias_ref = a.get("bias", None)
        if bias_ref is not None:
            bias_name = str(bias_ref)
            bias_flat = _flat(self.memory_store.tensor(bias_name))
            require_flat_elements("mmad_mx", "bias", bias_name, bias_flat, n)
            prod = prod + bias_flat[:n].to(torch.float32).view(1, n)

        logical_rows = dst_row0 + m
        logical_cols = max(dst_cols, dst_col0 + n)
        dst_stride = align16(logical_rows)
        require_flat_elements("mmad_mx", "dst", dst_name, dst, nz_footprint(logical_cols, dst_stride, c0_dst))
        logical = decode_nz_to_nd(dst, logical_rows, logical_cols, dst_stride, c0_dst)
        if not is_init:
            prev = logical[dst_row0:dst_row0 + m, dst_col0:dst_col0 + n].to(torch.float32)
            prod = prev + prod
        logical[dst_row0:dst_row0 + m, dst_col0:dst_col0 + n].copy_(prod.to(dst.dtype))
        dst.zero_()
        encode_nd_to_nz(logical, dst, logical_rows, logical_cols, dst_stride, c0_dst)

    def _mmad(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_a_name = str(a["src_a"])
        src_b_name = str(a["src_b"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_a_tensor = self.memory_store.tensor(src_a_name)
        src_b_tensor = self.memory_store.tensor(src_b_name)
        require_32b_aligned("mmad", "dst", dst_name, dst_tensor)
        require_32b_aligned("mmad", "src_a", src_a_name, src_a_tensor)
        require_32b_aligned("mmad", "src_b", src_b_name, src_b_tensor)
        dst = _flat(dst_tensor)
        src_a = _flat(src_a_tensor)
        src_b = _flat(src_b_tensor)
        m = _int(a["M"], "M")
        n = _int(a["N"], "N")
        k = _int(a["K"], "K")
        is_init = bool(a.get("is_init", True))
        dst_row0 = _int(a.get("dst_row0", 0), "dst_row0")
        dst_col0 = _int(a.get("dst_col0", 0), "dst_col0")
        dst_rows = _int(a.get("dst_rows", m), "dst_rows")
        dst_cols = _int(a.get("dst_cols", n), "dst_cols")

        c0_a = _c0(src_a)
        c0_b = _c0(src_b)
        c0_dst = 16  # L0C always c0=16

        src_a_is_int4 = _is_int4_view_name(self.memory_store, src_a_name)
        src_b_is_int4 = _is_int4_view_name(self.memory_store, src_b_name)
        if src_a_is_int4 != src_b_is_int4:
            raise TypeError("mmad: int4 views must be used for both L0A and L0B")
        src_a_is_hif8 = _is_hif8_view_name(self.memory_store, src_a_name)
        src_b_is_hif8 = _is_hif8_view_name(self.memory_store, src_b_name)
        if src_a_is_hif8 != src_b_is_hif8:
            raise TypeError("mmad: hif8 views must be used for both L0A and L0B")
        if not src_a_is_hif8 and src_a.dtype != src_b.dtype:
            raise TypeError("mmad: L0A and L0B must have the same dtype, got %s vs %s" % (src_a.dtype, src_b.dtype))

        if src_a_is_int4:
            if not _is_c220_device():
                raise ValueError("mmad: int4 compute views are only supported on a2/b* devices")
            if src_a.dtype != torch.int32 or src_b.dtype != torch.int32:
                raise TypeError("mmad: int4 compute views must be backed by int32 carrier tensors")
            if dst.dtype != torch.int32:
                raise TypeError("mmad: int4 compute requires int32 L0C destination")
            carrier_k = (k + 7) // 8
            src_a_carrier_cols_arg = a.get("src_a_carrier_cols", carrier_k)
            if src_a_carrier_cols_arg is None:
                src_a_carrier_cols_arg = carrier_k
            src_a_carrier_cols = _int(src_a_carrier_cols_arg, "src_a_carrier_cols")
            src_a_logical_rows_arg = a.get("src_a_logical_rows", m)
            if src_a_logical_rows_arg is None:
                src_a_logical_rows_arg = m
            src_a_logical_rows = _int(src_a_logical_rows_arg, "src_a_logical_rows")
            if src_a_carrier_cols < carrier_k:
                raise RuntimeError(
                    "mmad: int4 L0A carrier columns smaller than logical K footprint: "
                    + str(src_a_carrier_cols) + " < " + str(carrier_k)
                )
            src_a_n_align = align_to(src_a_carrier_cols, c0_a)
            require_flat_elements("mmad", "src_a", src_a_name, src_a, zz_footprint(m, src_a_n_align))
            a_carrier = decode_zz_to_nd(src_a, m, carrier_k, src_a_n_align)
            require_flat_elements("mmad", "src_b", src_b_name, src_b, nz_footprint(carrier_k, align16(n), c0_b))
            b_carrier = decode_nz_to_nd(src_b, n, carrier_k, align16(n), c0_b)
            a_nd = _unpack_signed_int4_cols(a_carrier, k)
            a_nd = _apply_b_device_int4_tail_transfer_quirk(a_nd, src_a_logical_rows, k, src_a_carrier_cols)
            b_nd = _unpack_signed_int4_cols(b_carrier, k)
        elif src_a_is_hif8:
            if _is_c220_device():
                raise ValueError("mmad: hif8 compute views are only supported on a5/950 devices")
            if src_a.dtype != torch.uint8 or src_b.dtype != torch.uint8:
                raise TypeError("mmad: hif8 compute views must be backed by uint8 storage")
            if dst.dtype != torch.float32:
                raise TypeError("mmad: hif8 compute requires float32 L0C destination")
            a_nd = _decode_hif8_l0_values(src_a_tensor, src_a_name, m, k)
            b_nd = _decode_hif8_l0_values(src_b_tensor, src_b_name, n, k)
        elif _is_c220_device():
            require_flat_elements("mmad", "src_a", src_a_name, src_a, zz_footprint(m, align_to(k, c0_a)))
            a_nd = decode_zz_to_nd(src_a, m, k, align_to(k, c0_a))
        else:
            require_flat_elements("mmad", "src_a", src_a_name, src_a, nz_footprint(k, align16(m), c0_a))
            a_nd = decode_nz_to_nd(src_a, m, k, align16(m), c0_a)
        if not src_a_is_int4 and not src_a_is_hif8:
            require_flat_elements("mmad", "src_b", src_b_name, src_b, nz_footprint(k, align16(n), c0_b))
            b_nd = decode_nz_to_nd(src_b, n, k, align16(n), c0_b)

        dt = self._compute_dtype(dst.dtype)
        prod = torch.matmul(a_nd.to(dt), b_nd.to(dt).transpose(0, 1))

        # Bias table (C2): C = bias + A@B on the is_init tile. The DSL restricts
        # bias to the is_init tile, and the simulator stores BT as a flat logical
        # [n] vector (see _l1_to_bt), so broadcast it over the m output rows.
        bias_ref = a.get("bias", None)
        if bias_ref is not None:
            bias_name = str(bias_ref)
            bias_flat = _flat(self.memory_store.tensor(bias_name))
            require_flat_elements("mmad", "bias", bias_name, bias_flat, n)
            prod = prod + bias_flat[:n].to(dt).view(1, n)

        # C310 MMAD writes a compact L0C tile using the operation's physical M,
        # not the declared Tensor's first dimension. A later Fixpipe read must
        # use the same compact M_src stride; otherwise hardware reads the wrong
        # column blocks. Keep dst_cols so splitn can preserve earlier N slices.
        logical_rows = dst_row0 + m
        logical_cols = max(dst_cols, dst_col0 + n)
        dst_stride = align16(logical_rows)
        require_flat_elements("mmad", "dst", dst_name, dst, nz_footprint(logical_cols, dst_stride, c0_dst))
        logical = decode_nz_to_nd(dst, logical_rows, logical_cols, dst_stride, c0_dst)
        if not is_init:
            prev = logical[dst_row0:dst_row0 + m, dst_col0:dst_col0 + n].to(dt)
            prod = prev + prod
        logical[dst_row0:dst_row0 + m, dst_col0:dst_col0 + n].copy_(prod.to(dst.dtype))
        dst.zero_()
        encode_nd_to_nz(logical, dst, logical_rows, logical_cols, dst_stride, c0_dst)


# ---------------------------------------------------------------------------
# FixPipe — L0C output (L0C always c0=16)
# ---------------------------------------------------------------------------

@dataclass
class FixPipe(PipeBase):

    def execute(self, task: PipeTask) -> None:
        if task.opname == "l0c_to_gm_nz2nd":
            self._l0c_to_gm(task)
        elif task.opname == "l0c_to_gm_nz2nz":
            self._l0c_to_gm_nz(task)
        elif task.opname == "l0c_to_gm_nz2dn":
            self._l0c_to_gm_dn(task)
        elif task.opname == "l0c_to_l1":
            self._l0c_to_l1(task)
        elif task.opname == "l0c_to_ub":
            self._l0c_to_ub(task)
        else:
            raise NotImplementedError("FixPipe unhandled op: " + task.opname)

    def _decode_l0c(self, opname: str, src_name: str, src: torch.Tensor, m: int, n: int, m_src: int) -> torch.Tensor:
        if m > m_src:
            raise RuntimeError(f"{opname}: M must be <= M_src, got M={m}, M_src={m_src}")
        stride_m = align16(m_src)
        suffix = local_slice_suffix(src_name)
        if suffix is not None:
            row0, col0, _rows, _cols = suffix
            logical_offset = _logical_offset_bytes(self.memory_store, src_name)
            if logical_offset is not None and int(logical_offset) % 32 != 0:
                raise RuntimeError(
                    f"{opname} src address must be 32-byte aligned: "
                    f"{src_name} has byte offset {int(logical_offset)}"
                )
            flat = _flat(src)
            required = nz_tail_write_footprint(n, row0, m, stride_m, 16, col0)
            try:
                require_flat_elements(opname, "src", src_name, flat, required)
            except RuntimeError as exc:
                raise RuntimeError(
                    f"{opname}: L0C source footprint exceeds tensor storage: src={src_name}, "
                    f"row0={row0}, col0={col0}, M={m}, N={n}, M_src={m_src} "
                    f"requires {required} elements, but tensor has {flat.numel()} elements"
                ) from exc
            return _decode_nz_to_nd_window(flat, m, n, stride_m, 16, row0, col0)

        flat = _flat_from_logical_offset(self.memory_store, src_name, src, opname, "src")
        required = ((n + 15) // 16) * stride_m * 16
        try:
            require_flat_elements(opname, "src", src_name, flat, required)
        except RuntimeError as exc:
            raise RuntimeError(
                f"{opname}: L0C source footprint exceeds tensor storage: src={src_name}, "
                f"M_src={m_src}, N={n} requires {required} elements, but tensor has {flat.numel()} elements"
            ) from exc
        return decode_nz_to_nd(flat, m, n, stride_m, 16)

    def _l0c_to_gm(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst = self.memory_store.tensor(dst_name)
        src = self.memory_store.tensor(src_name)
        require_32b_aligned("l0c_to_gm_nz2nd", "src", src_name, src)
        m = _int(a["M"], "M")
        n = _int(a["N"], "N")
        n_dst = _int(a["N_dst"], "N_dst")
        m_src = _int(a["M_src"], "M_src")
        relu = bool(a.get("relu", False))
        atomic = str(a.get("_atomic", ""))
        decoded = self._decode_l0c("l0c_to_gm_nz2nd", src_name, src, m, n, m_src)
        if relu:
            decoded = torch.clamp(decoded, min=0)
        scale = _scalar_num(a.get("scale", 1.0), 1.0)
        offset = int(_scalar_num(a.get("offset", 0), 0))
        if _is_hif8_view_name(self.memory_store, dst_name):
            # QF322HIF8_PRE / QF322HIF8_PRE_HYBRID: the dst is a uint8 carrier reinterpreted
            # as hif8, so encode (src * scale19) to hif8 codes rather than the int8/cast path.
            from easyasc.dtypehelper.hif8_codec import fp32_to_hif8
            hif8_hybrid = bool(a.get("hif8_hybrid", False))
            scaled = decoded.to(torch.float32) * _fp19_trunc(scale)
            logical = fp32_to_hif8(scaled, round_mode=("hybrid" if hif8_hybrid else None))
        else:
            logical = _apply_fixpipe_quant(decoded, dst.dtype, scale, offset)
        require_strided_2d_elements("l0c_to_gm_nz2nd", "dst", dst_name, _flat(dst), m, n, n_dst)
        if atomic in ("atomic_add", "atomic_max", "atomic_min"):
            with self.memory_store.atomic_lock():
                _atomic_scatter_reduce(_flat(dst), logical, n_dst, atomic)
        else:
            scatter_strided(_flat(dst), logical, n_dst)

    def _l0c_to_gm_dn(self, task: PipeTask) -> None:
        # L0C [m, n] tile -> GM transposed (NZ2DN / COLUMN_MAJOR): dst is an [n, m]
        # ND plane, dst[j, i] = L0C[i, j], rows m_dst elements apart.
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst = self.memory_store.tensor(dst_name)
        src = self.memory_store.tensor(src_name)
        require_32b_aligned("l0c_to_gm_nz2dn", "src", src_name, src)
        m = _int(a["M"], "M")
        n = _int(a["N"], "N")
        m_dst = _int(a["M_dst"], "M_dst")
        m_src = _int(a["M_src"], "M_src")
        relu = bool(a.get("relu", False))
        atomic = str(a.get("_atomic", ""))
        decoded = self._decode_l0c("l0c_to_gm_nz2dn", src_name, src, m, n, m_src)
        if relu:
            decoded = torch.clamp(decoded, min=0)
        scale = _scalar_num(a.get("scale", 1.0), 1.0)
        offset = int(_scalar_num(a.get("offset", 0), 0))
        if _is_hif8_view_name(self.memory_store, dst_name):
            from easyasc.dtypehelper.hif8_codec import fp32_to_hif8
            hif8_hybrid = bool(a.get("hif8_hybrid", False))
            scaled = decoded.to(torch.float32) * _fp19_trunc(scale)
            logical = fp32_to_hif8(scaled, round_mode=("hybrid" if hif8_hybrid else None))
        else:
            logical = _apply_fixpipe_quant(decoded, dst.dtype, scale, offset)
        # transpose [m, n] -> [n, m] and scatter n rows of m elements, stride m_dst.
        transposed = logical.transpose(0, 1).contiguous()
        require_strided_2d_elements("l0c_to_gm_nz2dn", "dst", dst_name, _flat(dst), n, m, m_dst)
        if atomic in ("atomic_add", "atomic_max", "atomic_min"):
            with self.memory_store.atomic_lock():
                _atomic_scatter_reduce(_flat(dst), transposed, m_dst, atomic)
        else:
            scatter_strided(_flat(dst), transposed, m_dst)

    def _l0c_to_gm_nz(self, task: PipeTask) -> None:
        # fp32 L0C [m, n] tile -> GM NZ strips: strip c1 (16 cols) lands m_pad rows apart;
        # dst points at the tile's rows inside strip 0.
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst = self.memory_store.tensor(dst_name)
        src = self.memory_store.tensor(src_name)
        require_32b_aligned("l0c_to_gm_nz2nz", "src", src_name, src)
        m = _int(a["M"], "M")
        n = _int(a["N"], "N")
        m_pad = _int(a["M_pad"], "M_pad")
        m_src = _int(a["M_src"], "M_src")
        logical = self._decode_l0c("l0c_to_gm_nz2nz", src_name, src, m, n, m_src)
        if bool(a.get("relu", False)):
            logical = torch.clamp(logical, min=0)
        scale = _scalar_num(a.get("scale", 1.0), 1.0)
        offset = int(_scalar_num(a.get("offset", 0), 0))
        if _is_hif8_view_name(self.memory_store, dst_name):
            from easyasc.dtypehelper.hif8_codec import fp32_to_hif8
            hh = bool(a.get("hif8_hybrid", False))
            logical = fp32_to_hif8(logical.to(torch.float32) * _fp19_trunc(scale),
                                   round_mode=("hybrid" if hh else None))
        else:
            logical = _apply_fixpipe_quant(logical, dst.dtype, scale, offset)
        # dst is a full-width [m, 16] row slice of the NZ plane: contiguous in the
        # backing storage, but other channel strips live m_pad rows further on, so
        # take a flat window from the slice start to the end of the plane storage.
        elem = int(dst.element_size())
        off = int(dst.storage_offset())
        avail = dst.untyped_storage().nbytes() // elem - off
        flat = dst.as_strided((avail,), (1,), storage_offset=off)
        c0g = max(16, 32 // elem)            # dst C0: 16 (>=2B) or 32 (8-bit)
        required = ((n // c0g - 1) * m_pad + m) * c0g
        require_flat_elements("l0c_to_gm_nz2nz", "dst", dst_name, flat, required)
        for c1 in range(n // c0g):
            base = c1 * m_pad * c0g
            flat[base:base + m * c0g] = logical[:, c1 * c0g:(c1 + 1) * c0g].reshape(-1).to(flat.dtype)

    def _l0c_to_l1(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src = self.memory_store.tensor(src_name)
        require_32b_aligned("l0c_to_l1", "dst", dst_name, dst_tensor)
        require_32b_aligned("l0c_to_l1", "src", src_name, src)
        dst = _flat(dst_tensor)
        m = _int(a["M"], "M")
        n = _int(a["N"], "N")
        m_dst = _int(a["M_dst"], "M_dst")
        m_src = _int(a["M_src"], "M_src")
        relu = bool(a.get("relu", False))

        if _is_c220_device() and dst.dtype == torch.float32:
            raise RuntimeError("l0c_to_l1 float32→float32 not supported on C220 device")

        logical = self._decode_l0c("l0c_to_l1", src_name, src, m, n, m_src).to(dst.dtype)
        if relu:
            logical = torch.clamp(logical, min=0)
        if m > 0 and n > 0:
            c0 = _c0(dst)
            require_flat_elements("l0c_to_l1", "dst", dst_name, dst, nz_footprint(n, align16(m_dst), c0))
            dst.zero_()
            encode_nd_to_nz(logical, dst, m, n, align16(m_dst), c0)

    def _l0c_to_ub(self, task: PipeTask) -> None:
        a = task.args
        dst_v0 = a.get("dst_vec0")
        dst_v1 = a.get("dst_vec1")
        has_dual = isinstance(dst_v0, str) and isinstance(dst_v1, str)
        runtime_dst_name = str(a.get("dst", ""))

        def _vec1_runtime_name(default_name: str) -> str:
            if "@" in runtime_dst_name:
                candidate = "_vec1_" + runtime_dst_name
                if self.memory_store.contains(candidate):
                    return candidate
                suffix = local_slice_suffix(runtime_dst_name)
                if suffix is not None:
                    row0, col0, rows, cols = suffix
                    suffix_text = ":" + str(row0) + "," + str(col0) + ":" + str(rows) + "," + str(cols)
                    source_name = ""
                    if runtime_dst_name.endswith(suffix_text):
                        source_name = runtime_dst_name.split("@", 1)[1][:-len(suffix_text)]
                    vec1_source = "_vec1_" + source_name if source_name else ""
                    base_name = vec1_source if vec1_source and self.memory_store.contains(vec1_source) else default_name
                    if self.memory_store.contains(base_name):
                        base = self.memory_store.tensor(base_name)
                        if base.dim() == 1:
                            row_stride = _int(a.get("N_dst", cols), "N_dst")
                            offset = row0 * row_stride + col0
                            footprint = offset + (rows - 1) * row_stride + cols
                            view = (
                                base.as_strided(
                                    (rows, cols), (row_stride, 1),
                                    storage_offset=int(base.storage_offset()) + offset,
                                )
                                if 0 <= offset and footprint <= base.numel() else None
                            )
                        elif base.dim() == 2:
                            view = base[row0:row0 + rows, col0:col0 + cols]
                        else:
                            view = None
                        if view is not None:
                            logical_offset = _logical_offset_bytes(self.memory_store, base_name)
                            if logical_offset is not None:
                                rel = (int(view.storage_offset()) - int(base.storage_offset())) * int(view.element_size())
                                logical_offset = int(logical_offset) + rel
                            self.memory_store.register_view(candidate, view, logical_offset)
                            return candidate
            return default_name

        if has_dual:
            dst_name = dst_v0
            dst = self.memory_store.tensor(dst_v0)
        else:
            dst_name = str(a["dst"])
            dst = self.memory_store.tensor(dst_name)
        src_name = str(a["src"])
        src = self.memory_store.tensor(src_name)
        require_32b_aligned("l0c_to_ub", "dst", str(dst_name), dst)
        require_32b_aligned("l0c_to_ub", "src", src_name, src)
        m = _int(a["M"], "M")
        n = _int(a["N"], "N")
        m_src = _int(a["M_src"], "M_src")
        dual_mode = _int(a.get("dual_mode", 1), "dual_mode")
        sub_block = _int(a.get("sub_block_id", 0), "sub_block_id")
        relu = bool(a.get("relu", False))
        decoded = self._decode_l0c("l0c_to_ub", src_name, src, m, n, m_src)
        if relu:
            decoded = torch.clamp(decoded, min=0)
        if dual_mode == 0:
            # SINGLE carries the full fixpipe scalar quant (mirror _l0c_to_gm); the dual-lane
            # modes only do the plain cast (the stub forbids requant/relu when splitting).
            scale = _scalar_num(a.get("scale", 1.0), 1.0)
            offset = int(_scalar_num(a.get("offset", 0), 0))
            if _is_hif8_view_name(self.memory_store, dst_name):
                from easyasc.dtypehelper.hif8_codec import fp32_to_hif8
                hif8_hybrid = bool(a.get("hif8_hybrid", False))
                scaled = decoded.to(torch.float32) * _fp19_trunc(scale)
                logical = fp32_to_hif8(scaled, round_mode=("hybrid" if hif8_hybrid else None))
            else:
                logical = _apply_fixpipe_quant(decoded, dst.dtype, scale, offset)
        else:
            logical = decoded.to(dst.dtype)

        if dual_mode == 0:
            if has_dual:
                dst_name = dst_v0 if sub_block == 0 else _vec1_runtime_name(dst_v1)
                d = self.memory_store.tensor(dst_name)
                require_32b_aligned("l0c_to_ub", "dst", str(dst_name), d)
                require_flat_elements("l0c_to_ub", "dst", str(dst_name), d, m * n)
                d.copy_(logical.reshape(d.shape))
            else:
                if sub_block == 0:
                    require_flat_elements("l0c_to_ub", "dst", str(dst_name), dst, m * n)
                    dst.copy_(logical.reshape(dst.shape))
                else:
                    vec1_name = _vec1_runtime_name("_vec1_" + str(a["dst"]))
                    if self.memory_store.contains(vec1_name):
                        d1 = self.memory_store.tensor(vec1_name)
                        require_32b_aligned("l0c_to_ub", "dst", vec1_name, d1)
                        require_flat_elements("l0c_to_ub", "dst", vec1_name, d1, m * n)
                        d1.copy_(logical.reshape(d1.shape))
        elif dual_mode == 1:
            half_m = m // 2
            if has_dual:
                # The subblock-1 mirror name carries no slice, so a sliced dst
                # (a column window of a wider UB tile) has to be re-derived the
                # same way the SINGLE path does it.
                dst_v1 = _vec1_runtime_name(dst_v1)
                d0 = self.memory_store.tensor(dst_v0)
                d1 = self.memory_store.tensor(dst_v1)
                require_32b_aligned("l0c_to_ub", "dst", dst_v0, d0)
                require_32b_aligned("l0c_to_ub", "dst", dst_v1, d1)
                require_flat_elements("l0c_to_ub", "dst", dst_v0, d0, half_m * n)
                require_flat_elements("l0c_to_ub", "dst", dst_v1, d1, (m - half_m) * n)
                d0.copy_(logical[:half_m, :].reshape(d0.shape))
                d1.copy_(logical[half_m:, :].reshape(d1.shape))
            else:
                require_flat_elements("l0c_to_ub", "dst", str(dst_name), dst, half_m * n)
                dst.copy_(logical[:half_m, :].reshape(dst.shape))
                vec1_name = _vec1_runtime_name("_vec1_" + str(a["dst"]))
                if self.memory_store.contains(vec1_name):
                    d1 = self.memory_store.tensor(vec1_name)
                    require_32b_aligned("l0c_to_ub", "dst", vec1_name, d1)
                    require_flat_elements("l0c_to_ub", "dst", vec1_name, d1, (m - half_m) * n)
                    d1.copy_(logical[half_m:, :].reshape(d1.shape))
        else:
            half_n = n // 2
            if has_dual:
                dst_v1 = _vec1_runtime_name(dst_v1)
                d0 = self.memory_store.tensor(dst_v0)
                d1 = self.memory_store.tensor(dst_v1)
                require_32b_aligned("l0c_to_ub", "dst", dst_v0, d0)
                require_32b_aligned("l0c_to_ub", "dst", dst_v1, d1)
                require_flat_elements("l0c_to_ub", "dst", dst_v0, d0, m * half_n)
                require_flat_elements("l0c_to_ub", "dst", dst_v1, d1, m * (n - half_n))
                d0.copy_(logical[:, :half_n].reshape(d0.shape))
                d1.copy_(logical[:, half_n:].reshape(d1.shape))
            else:
                require_flat_elements("l0c_to_ub", "dst", str(dst_name), dst, m * half_n)
                dst.copy_(logical[:, :half_n].reshape(dst.shape))
                vec1_name = _vec1_runtime_name("_vec1_" + str(a["dst"]))
                if self.memory_store.contains(vec1_name):
                    d1 = self.memory_store.tensor(vec1_name)
                    require_32b_aligned("l0c_to_ub", "dst", vec1_name, d1)
                    require_flat_elements("l0c_to_ub", "dst", vec1_name, d1, m * (n - half_n))
                    d1.copy_(logical[:, half_n:].reshape(d1.shape))
