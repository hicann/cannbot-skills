from __future__ import annotations

import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .config import DEFAULT_EXECUTION_TIMEOUT_S, SimulatorConfig
from .memory import SharedMemoryStore, dtype_size, normalize_dtype
from .physical_alias import PhysicalAlias, as_physical_alias
from .program import ControlInstruction, KernelProgram, LaneProgram, PipeTask, TaskStatus
from .sync import (
    BAR_ALL_MARKER,
    CrossCoreSync,
    CycleBarrier,
    IntraCoreSync,
    LocalEventBank,
    LocalSync,
    Mailbox,
    _STOP,
)
from .trace import TraceEventKind, TraceRecorder
from ..device_profile import is_c220_family


_SYNC_TASK_OPS = frozenset([
    "event_set", "event_setall", "event_wait", "event_release",
    "cube_ready", "vec_ready", "wait_vec", "wait_cube",
    "intracore_allvec_ready", "intracore_allvec_wait",
    "setflag", "waitflag",
])

_EVENT_CONTROL_OPS = frozenset([
    "event_set", "event_setall", "event_wait", "event_release",
    "create_sevent", "create_devent", "create_tevent", "create_qevent",
    "cube_ready", "vec_ready", "wait_vec", "wait_cube",
    "intracore_allvec_ready", "intracore_allvec_wait",
    "allcube_ready", "allvec_ready", "allcube_wait", "allvec_wait",
    "setflag", "waitflag",
    "bar_all",
])

_TASK_DEF_KEYS = frozenset(["micro_def", "simt_def"])


def _alias_debug_summary(alias: PhysicalAlias) -> Dict[str, Any]:
    logical = alias.logical_tensor()
    return {
        "storage_name": str(alias.storage_name or alias.name),
        "byte_offset": int(alias.byte_offset),
        "logical_offset_bytes": alias.logical_offset_bytes,
        "logical_shape": list(getattr(logical, "shape", ()) or ()),
        "dtype": str(getattr(logical, "dtype", "")),
        "role": str(alias.role or ""),
        "tags": list(alias.tags),
    }


def _is_tensor_like(value: Any) -> bool:
    return hasattr(value, "shape") and hasattr(value, "dtype") and hasattr(value, "numel")


def _tensor_debug_summary(value: Any) -> Dict[str, Any]:
    try:
        shape = [int(v) for v in getattr(value, "shape", ())]
    except Exception:
        shape = []
    try:
        numel = int(value.numel())
    except Exception:
        numel = 0
    return {
        "shape": shape,
        "dtype": str(getattr(value, "dtype", "")),
        "numel": numel,
    }


def _def_debug_summary(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {"kind": type(value).__name__}
    instructions = value.get("instructions", [])
    input_list = value.get("input_list", [])
    return {
        "input_count": len(input_list) if isinstance(input_list, list) else 0,
        "instruction_count": len(instructions) if isinstance(instructions, list) else 0,
    }


def _summarize_debug_value(value: Any) -> Any:
    if isinstance(value, PhysicalAlias):
        return _alias_debug_summary(value)
    if isinstance(value, dict):
        return {str(k): _summarize_debug_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_summarize_debug_value(v) for v in value]
    if _is_tensor_like(value):
        return _tensor_debug_summary(value)
    return value


def _summarize_task_args_for_debug(args: Any) -> Any:
    if not isinstance(args, dict):
        return args
    summarized: Dict[str, Any] = {}
    for key, value in args.items():
        if key in _TASK_DEF_KEYS:
            summarized[str(key)] = _def_debug_summary(value)
            continue
        summarized[str(key)] = _summarize_debug_value(value)
    return summarized


def _task_tensor_binding_summary(task: Optional[PipeTask]) -> Optional[Dict[str, Any]]:
    if task is None or not isinstance(getattr(task, "args", None), dict):
        return None
    tensor_views = task.args.get("tensor_views", {})
    if not isinstance(tensor_views, dict):
        return None
    summary: Dict[str, Any] = {}
    for name, value in tensor_views.items():
        if isinstance(value, PhysicalAlias):
            summary[str(name)] = _alias_debug_summary(value)
        elif _is_tensor_like(value):
            summary[str(name)] = _tensor_debug_summary(value)
    return summary or None


def _storage_tail_view(tensor: Any) -> Any:
    elem = int(tensor.element_size())
    storage_elems = int(tensor.untyped_storage().nbytes()) // elem
    offset = int(tensor.storage_offset())
    length = max(storage_elems - offset, 0)
    return tensor.as_strided((length,), (1,), storage_offset=offset)


def _intra_core_sync_latency_cycles(cycle_model: Optional[Any]) -> float:
    if cycle_model is None:
        return 0.0
    return float(max(0, int(getattr(cycle_model, "intra_core_sync_latency_cycles", 0))))


def _intra_core_sync_visible_cycle(cycle_model: Optional[Any], signal_cycle: float) -> float:
    return float(signal_cycle) + _intra_core_sync_latency_cycles(cycle_model)


def _bar_all_wait_cycle(barrier: Any, arrival_cycle: float) -> float:
    wait_cycle = getattr(barrier, "wait_cycle", None)
    if callable(wait_cycle):
        return float(wait_cycle(float(arrival_cycle)))
    barrier.wait()
    return float(arrival_cycle)


def _advance_bar_all_cycle(current_cycle: float, release_cycle: float, cycle_model: Optional[Any]) -> float:
    current_cycle = max(float(current_cycle), float(release_cycle))
    if cycle_model is None:
        return current_cycle
    cycles = max(1, int(getattr(cycle_model, "sync_marker_cycles", 1)))
    return current_cycle + cycles


def _record_intra_sync_stall(
    recorder: Optional[TraceRecorder],
    cycle_model: Optional[Any],
    lane_name: str,
    pipe_name: str,
    wait_op: str,
    flag_id: int,
    arrival_cycle: float,
    signal_cycle: float,
    visible_cycle: float,
) -> None:
    if recorder is None or cycle_model is None:
        return
    consumer_stall_cycles = max(float(visible_cycle) - float(arrival_cycle), 0.0)
    if consumer_stall_cycles <= 0.0:
        return
    latency_cycles = max(float(visible_cycle) - float(signal_cycle), 0.0)
    if latency_cycles <= 0.0:
        return
    blocked_latency_start = max(float(arrival_cycle), float(signal_cycle))
    blocked_latency_cycles = max(float(visible_cycle) - blocked_latency_start, 0.0)
    if blocked_latency_cycles <= 0.0:
        return
    pre_ready_wait_cycles = max(float(signal_cycle) - float(arrival_cycle), 0.0)
    post_ready_arrival_lag_cycles = max(float(arrival_cycle) - float(signal_cycle), 0.0)
    if wait_op == "wait_cube":
        producer_op = "cube_ready"
    elif wait_op == "intracore_allvec_wait":
        producer_op = "intracore_allvec_ready"
    else:
        producer_op = "vec_ready"
    recorder.record(
        kind=TraceEventKind.STALL,
        name="stall:" + wait_op,
        ts=blocked_latency_start,
        dur=blocked_latency_cycles,
        args={
            "lane_name": lane_name,
            "pipe_name": pipe_name,
            "opname": "stall:" + wait_op,
            "cat": "stall",
            "time_domain": "cycle",
            "cycle_model_profile": getattr(cycle_model, "profile_name", ""),
            "reason": "intra_core_sync_latency",
            "wait_op": wait_op,
            "producer_op": producer_op,
            "flag_id": int(flag_id),
            "arrival_cycle": float(arrival_cycle),
            "signal_cycle": float(signal_cycle),
            "visible_cycle": float(visible_cycle),
            "latency_cycles": latency_cycles,
            "stall_cycles": blocked_latency_cycles,
            "consumer_stall_cycles": consumer_stall_cycles,
            "blocked_latency_start_cycle": blocked_latency_start,
            "blocked_latency_cycles": blocked_latency_cycles,
            "pre_ready_wait_cycles": pre_ready_wait_cycles,
            "post_ready_arrival_lag_cycles": post_ready_arrival_lag_cycles,
        },
    )


# ---------------------------------------------------------------------------
# PipeBase — abstract pipe worker thread
# ---------------------------------------------------------------------------

@dataclass
class PipeBase:
    """Base class for pipe worker threads (MTE2, M, V, etc.).

    Each pipe thread polls its mailbox:
      - PipeTask → calls execute(task)
      - BAR_ALL_MARKER → calls bar_all_barrier.wait()
      - STOP → exits loop
    """

    core_idx: int
    lane_name: str
    pipe_name: str
    mailbox: Mailbox
    bar_all_barrier: threading.Barrier
    memory_store: SharedMemoryStore
    event_bank: Optional[Any] = None
    intra_sync: Optional[Any] = None
    trace_recorder: Optional[TraceRecorder] = None
    cycle_model: Optional[Any] = None
    hazard_tracker: Optional[Any] = None
    current_cycle: float = 0.0
    _thread: Optional[threading.Thread] = field(default=None, init=False, repr=False)
    _running: bool = field(default=False, init=False)
    _failure: Optional[str] = field(default=None, init=False)
    _current_task: Optional[PipeTask] = field(default=None, init=False, repr=False)
    _current_task_started_at: float = field(default=0.0, init=False, repr=False)
    executed_tasks: List[PipeTask] = field(default_factory=list, init=False)

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._failure = None
        self._thread = threading.Thread(
            target=self._run_loop,
            name="sim-c%d-%s-%s" % (self.core_idx, self.lane_name, self.pipe_name),
            daemon=True,
        )
        self._thread.start()

    def join(self, timeout: Optional[float] = None) -> None:
        if self._thread is None:
            return
        self._thread.join(timeout=timeout)
        if not self._thread.is_alive():
            self._thread = None

    def stop(self) -> None:
        self.mailbox.put_stop()

    def _run_loop(self) -> None:
        while self._running:
            item = self.mailbox.get(block=True, timeout=0.05)
            if item is None:
                continue
            if item is BAR_ALL_MARKER:
                bar_start = time.monotonic()
                bar_cycle_start = self.current_cycle
                try:
                    release_cycle = _bar_all_wait_cycle(self.bar_all_barrier, bar_cycle_start)
                except threading.BrokenBarrierError:
                    self._failure = self._failure or "barrier aborted by failed pipe"
                    self._running = False
                    break
                bar_end = self._advance_cycle_for_sync_marker(release_cycle)
                if self.hazard_tracker is not None:
                    self.hazard_tracker.note_barrier(self.core_idx, self.lane_name)
                self._record_event(
                    TraceEventKind.SYNC, "bar_all", bar_start, bar_cycle_start, bar_end,
                )
                continue
            if item == _STOP or item is _STOP:
                self._running = False
                break
            if not isinstance(item, PipeTask):
                continue
            task = item
            task.status = TaskStatus.RUNNING
            self._current_task = task
            self._current_task_started_at = time.monotonic()
            task.start_cycle = max(float(self.current_cycle), float(task.earliest_start_cycle))
            if self.current_cycle < task.start_cycle:
                self.current_cycle = task.start_cycle
            estimated = self._estimate_task_cycles(task)
            task.estimated_cycles = float(estimated)
            try:
                if self.hazard_tracker is not None:
                    self.hazard_tracker.check_task(
                        self.core_idx,
                        self.lane_name,
                        self.pipe_name,
                        task,
                        self.memory_store,
                        task.start_cycle,
                        task.start_cycle + float(estimated),
                    )
                if task.opname in ("event_set", "event_setall") and self.event_bank is not None:
                    ready_cycle = task.start_cycle + estimated
                    self.event_bank.set_event(
                        str(task.args.get("event_name", "")),
                        set_all=bool(task.args.get("set_all", False)),
                        ready_cycle=ready_cycle,
                    )
                    task.end_cycle = ready_cycle
                elif task.opname == "event_wait" and self.event_bank is not None:
                    timeout = float(task.args.get("timeout", DEFAULT_EXECUTION_TIMEOUT_S))
                    name = str(task.args["event_name"])
                    if not self.event_bank.wait_event(name, timeout=timeout):
                        raise RuntimeError("event_wait timeout in pipe " + self.pipe_name + ": " + str(task.args))
                    ready_cycle = self.event_bank.ready_cycle(name)
                    task.start_cycle = max(task.start_cycle, ready_cycle)
                    task.end_cycle = task.start_cycle + estimated
                elif task.opname == "event_release" and self.event_bank is not None:
                    timeout = float(task.args.get("timeout", DEFAULT_EXECUTION_TIMEOUT_S))
                    name = str(task.args["event_name"])
                    if not self.event_bank.release_event(name, timeout=timeout):
                        raise RuntimeError("event_release timeout in pipe " + self.pipe_name + ": " + str(task.args))
                    ready_cycle = self.event_bank.ready_cycle(name)
                    task.start_cycle = max(task.start_cycle, ready_cycle)
                    task.end_cycle = task.start_cycle + estimated
                elif task.opname in ("setflag", "waitflag") and self.event_bank is not None:
                    self._handle_local_flag_task(task, estimated)
                elif task.opname in (
                    "cube_ready", "vec_ready", "wait_vec", "wait_cube",
                    "intracore_allvec_ready", "intracore_allvec_wait",
                ) and self.intra_sync is not None:
                    self._handle_intra_sync_task(task)
                    task.end_cycle = self.current_cycle
                elif self._execute_sim_debug_task(task):
                    task.end_cycle = task.start_cycle + estimated
                else:
                    self.execute(task)
                    if task.opname == "call_simt" and "_simt_instruction_count" in task.args:
                        estimated = self._estimate_task_cycles(task)
                        task.estimated_cycles = float(estimated)
                    task.end_cycle = task.start_cycle + estimated
                if self.current_cycle < task.end_cycle:
                    self.current_cycle = task.end_cycle
                task.status = TaskStatus.DONE
                self.executed_tasks.append(task)
                kind = TraceEventKind.SYNC if task.opname in _SYNC_TASK_OPS else TraceEventKind.PIPE
                self._record_event(
                    kind, task.opname, self._current_task_started_at,
                    task.start_cycle, task.end_cycle,
                )
                self._current_task = None
                self._current_task_started_at = 0.0
            except Exception:
                task.status = TaskStatus.FAILED
                task.error = traceback.format_exc()
                self._failure = task.error
                print(
                    "[simulator] pipe worker failed: core=%d lane=%s pipe=%s op=%s args=%r\n%s"
                    % (
                        self.core_idx, self.lane_name, self.pipe_name,
                        task.opname, task.args, task.error,
                    ),
                    file=sys.stderr, flush=True,
                )
                self._current_task = None
                self._current_task_started_at = 0.0
                self._running = False
                if self.event_bank is not None:
                    try:
                        self.event_bank.abort(
                            "pipe " + self.pipe_name + " failed: " + task.opname
                        )
                    except Exception:
                        print(
                            "[simulator] event bank abort suppressed: core=%d lane=%s pipe=%s\n%s"
                            % (self.core_idx, self.lane_name, self.pipe_name, traceback.format_exc()),
                            file=sys.stderr, flush=True,
                        )
                try:
                    self.bar_all_barrier.abort()
                except Exception:
                    print(
                        "[simulator] barrier abort suppressed: core=%d lane=%s pipe=%s\n%s"
                        % (self.core_idx, self.lane_name, self.pipe_name, traceback.format_exc()),
                        file=sys.stderr, flush=True,
                    )
                break

    def _record_event(
        self,
        kind: TraceEventKind,
        opname: str,
        wall_start_ts: float,
        cycle_start: float = 0.0,
        cycle_end: float = 0.0,
    ) -> None:
        recorder = self.trace_recorder
        if recorder is None or wall_start_ts <= 0.0:
            return
        if kind == TraceEventKind.SYNC and not recorder.record_event:
            return
        args = {
            "lane_name": self.lane_name,
            "pipe_name": self.pipe_name,
            "opname": opname,
        }
        binding_summary = _task_tensor_binding_summary(self._current_task)
        if binding_summary is not None:
            args["tensor_bindings"] = binding_summary
        if self.cycle_model is not None:
            ts = float(cycle_start)
            dur = float(max(cycle_end - cycle_start, 0.0))
            args["time_domain"] = "cycle"
            args["cycle_model_profile"] = getattr(self.cycle_model, "profile_name", "")
        else:
            ts = wall_start_ts
            dur = time.monotonic() - wall_start_ts
            if dur < 0.0:
                dur = 0.0
        recorder.record(kind=kind, name=opname, ts=ts, dur=dur, args=args)

    def _estimate_task_cycles(self, task: PipeTask) -> float:
        model = self.cycle_model
        if model is None:
            return 0.0
        try:
            from .timing import estimate_task_cycles
            est = estimate_task_cycles(task, self.memory_store, model)
        except Exception:
            base_cycles = max(1, getattr(model, "sync_marker_cycles", 1))
            no_instruction_overhead = False
        else:
            base_cycles = getattr(est, "cycles", 0)
            details = getattr(est, "details", {})
            no_instruction_overhead = bool(
                isinstance(details, dict) and details.get("no_instruction_overhead", False)
            )
        overhead = 0
        if not no_instruction_overhead:
            overhead = max(0, int(getattr(model, "instruction_head_overhead_cycles", 0)))
        cycles = float(base_cycles + overhead)
        scaler = getattr(self.hazard_tracker, "scale_task_cycles", None)
        if callable(scaler):
            cycles = float(scaler(task, cycles))
        return cycles

    def _advance_cycle_for_sync_marker(self, release_cycle: Optional[float] = None) -> float:
        if release_cycle is not None:
            self.current_cycle = max(float(self.current_cycle), float(release_cycle))
        model = self.cycle_model
        if model is None:
            return self.current_cycle
        cycles = max(1, int(getattr(model, "sync_marker_cycles", 1)))
        self.current_cycle = self.current_cycle + cycles
        return self.current_cycle

    def _handle_intra_sync_task(self, task: PipeTask) -> None:
        flag_id = int(task.args.get("flag_id", 0))
        vec_idx = int(task.args.get("vec_idx", 0))
        timeout = float(task.args.get("timeout", DEFAULT_EXECUTION_TIMEOUT_S))
        op = task.opname
        marker = max(1, int(getattr(self.cycle_model, "sync_marker_cycles", 1))) if self.cycle_model else 0
        if op == "cube_ready":
            ready_cycle = self.current_cycle + marker
            visible_cycle = _intra_core_sync_visible_cycle(self.cycle_model, ready_cycle)
            self.intra_sync.cube_ready(flag_id, ready_cycle=ready_cycle, visible_cycle=visible_cycle)
            self.current_cycle = ready_cycle
        elif op == "vec_ready":
            ready_cycle = self.current_cycle + marker
            visible_cycle = _intra_core_sync_visible_cycle(self.cycle_model, ready_cycle)
            self.intra_sync.vec_ready(vec_idx, flag_id, ready_cycle=ready_cycle, visible_cycle=visible_cycle)
            self.current_cycle = ready_cycle
        elif op == "intracore_allvec_ready":
            ready_cycle = self.current_cycle + marker
            visible_cycle = _intra_core_sync_visible_cycle(self.cycle_model, ready_cycle)
            self.intra_sync.intracore_allvec_ready(
                vec_idx, flag_id, ready_cycle=ready_cycle, visible_cycle=visible_cycle,
            )
            self.current_cycle = ready_cycle
        elif op == "wait_vec":
            arrival_cycle = float(self.current_cycle)
            if not self.intra_sync.wait_vec(flag_id, timeout=timeout):
                raise RuntimeError("wait_vec timeout in pipe " + self.pipe_name)
            ready_cycle = self.intra_sync.vec_ready_cycle(flag_id)
            signal_cycle = self.intra_sync.vec_ready_signal_cycle(flag_id)
            _record_intra_sync_stall(
                self.trace_recorder, self.cycle_model, self.lane_name, self.pipe_name,
                op, flag_id, arrival_cycle, signal_cycle, ready_cycle,
            )
            self.current_cycle = max(self.current_cycle, ready_cycle) + marker
        elif op == "intracore_allvec_wait":
            arrival_cycle = float(self.current_cycle)
            if not self.intra_sync.intracore_allvec_wait(vec_idx, flag_id, timeout=timeout):
                raise RuntimeError("intracore_allvec_wait timeout in pipe " + self.pipe_name)
            ready_cycle = self.intra_sync.intracore_allvec_ready_cycle(vec_idx, flag_id)
            signal_cycle = self.intra_sync.intracore_allvec_ready_signal_cycle(vec_idx, flag_id)
            _record_intra_sync_stall(
                self.trace_recorder, self.cycle_model, self.lane_name, self.pipe_name,
                op, flag_id, arrival_cycle, signal_cycle, ready_cycle,
            )
            self.current_cycle = max(self.current_cycle, ready_cycle) + marker
        elif op == "wait_cube":
            arrival_cycle = float(self.current_cycle)
            if not self.intra_sync.wait_cube(vec_idx, flag_id, timeout=timeout):
                raise RuntimeError("wait_cube timeout in pipe " + self.pipe_name)
            ready_cycle = self.intra_sync.cube_ready_cycle(vec_idx, flag_id)
            signal_cycle = self.intra_sync.cube_ready_signal_cycle(vec_idx, flag_id)
            _record_intra_sync_stall(
                self.trace_recorder, self.cycle_model, self.lane_name, self.pipe_name,
                op, flag_id, arrival_cycle, signal_cycle, ready_cycle,
            )
            self.current_cycle = max(self.current_cycle, ready_cycle) + marker

    def _handle_local_flag_task(self, task: PipeTask, estimated_cycles: float) -> None:
        sync = getattr(self.event_bank, "sync", None)
        if sync is None:
            raise RuntimeError("local flag sync is unavailable in pipe " + self.pipe_name)
        src_pipe = str(task.args.get("src", ""))
        dst_pipe = str(task.args.get("dst", ""))
        event_id = int(task.args.get("event_id", 0))
        if task.opname == "setflag":
            ready_cycle = task.start_cycle + float(estimated_cycles)
            sync.set(src_pipe, dst_pipe, event_id, ready_cycle=ready_cycle)
            task.end_cycle = ready_cycle
            return
        timeout = float(task.args.get("timeout", DEFAULT_EXECUTION_TIMEOUT_S))
        if not sync.wait(src_pipe, dst_pipe, event_id, timeout=timeout):
            raise RuntimeError(
                "waitflag timeout in pipe " + self.pipe_name
                + ": src=" + src_pipe + " dst=" + dst_pipe + " event_id=" + str(event_id)
            )
        ready_cycle = sync.ready_cycle(src_pipe, dst_pipe, event_id)
        task.start_cycle = max(task.start_cycle, ready_cycle)
        task.end_cycle = task.start_cycle + float(estimated_cycles)

    @staticmethod
    def _render_sim_print_payload(memory_store: SharedMemoryStore, payload: Any) -> str:
        if not isinstance(payload, list):
            return ""
        parts: List[str] = []
        for item in payload:
            value = item
            if isinstance(item, dict):
                kind = str(item.get("kind", "literal"))
                value = item.get("value", "")
                if kind in ("gm_tensor", "local_tensor") and isinstance(value, str) and memory_store.contains(value):
                    value = memory_store.tensor(value)
            parts.append(str(value))
        return "".join(parts)

    def _execute_sim_debug_task(self, task: PipeTask) -> bool:
        if task.opname == "sim_dump_tensor":
            import torch

            tensor_name = task.args.get("tensor", "")
            filename = task.args.get("filename", "")
            if not isinstance(tensor_name, str) or tensor_name == "":
                raise ValueError("sim_dump_tensor requires non-empty tensor name")
            if not isinstance(filename, str) or filename == "":
                raise ValueError("sim_dump_tensor requires non-empty filename")
            tensor = self.memory_store.tensor(tensor_name)
            torch.save(tensor.detach().clone(), filename)
            return True
        if task.opname == "sim_print":
            message = self._render_sim_print_payload(self.memory_store, task.args.get("payload", []))
            print(
                "[sim_print][core=%d][lane=%s][pipe=%s] %s"
                % (self.core_idx, self.lane_name, self.pipe_name, message),
                file=sys.stderr,
                flush=True,
            )
            return True
        return False

    def execute(self, task: PipeTask) -> None:
        raise NotImplementedError

    def describe_inflight_task(self) -> Optional[str]:
        task = self._current_task
        if task is None:
            return None
        elapsed = max(time.monotonic() - self._current_task_started_at, 0.0)
        args_text = repr(_summarize_task_args_for_debug(task.args))
        if len(args_text) > 240:
            args_text = args_text[:237] + "..."
        return (
            self.lane_name + "/" + self.pipe_name
            + " running " + task.opname
            + " for %.3fs" % elapsed
            + " args=" + args_text
        )

    def describe_pending_tasks(self, limit: int = 3) -> List[str]:
        out: List[str] = []
        for item in self.mailbox.snapshot_items(limit=limit):
            if not isinstance(item, PipeTask):
                continue
            args_text = repr(_summarize_task_args_for_debug(item.args))
            if len(args_text) > 160:
                args_text = args_text[:157] + "..."
            out.append(
                self.lane_name + "/" + self.pipe_name
                + " pending " + item.opname
                + " args=" + args_text
            )
        return out


# ---------------------------------------------------------------------------
# PipeS — per-lane scalar pipe
#
# Each lane (cube, vec0, vec1) has its own PipeS + its own pipes.
#   cube PipeS  → MTE2, MTE1, M, FIX  (4 threads)
#   vec0 PipeS  → MTE2, V, MTE3       (3 threads, UB0)
#   vec1 PipeS  → MTE2, V, MTE3       (3 threads, UB1)
#
# bar_all is per-lane: Barrier(parties = pipe_count + 1 PipeS).
# Each PipeS has its own LocalSync + LocalEventBank.
# Cross-lane sync goes through shared IntraCoreSync.
# Cross-core sync goes through shared CrossCoreSync.
# ---------------------------------------------------------------------------

class _BreakSignal(BaseException):
    pass


class _ContinueSignal(BaseException):
    pass


PipeFactory = Callable[..., PipeBase]

CUBE_PIPES = ["MTE2", "MTE1", "M", "FIX"]
VEC_PIPES = ["MTE2", "V", "MTE3"]


@dataclass
class PipeS:
    """Per-lane scalar pipe. Interprets one LaneProgram."""

    core_idx: int
    lane_name: str
    lane_program: LaneProgram
    config: SimulatorConfig
    memory_store: SharedMemoryStore
    intra_sync: IntraCoreSync
    cross_sync: CrossCoreSync
    local_sync: LocalSync
    event_bank: LocalEventBank
    pipe_factory: PipeFactory
    kernel_mode: str = "mix"
    micro_defs: Dict[str, Any] = field(default_factory=dict)
    simt_defs: Dict[str, Any] = field(default_factory=dict)
    tensor_name_map: Dict[str, str] = field(default_factory=dict)
    trace_recorder: Optional[TraceRecorder] = None
    cycle_model: Optional[Any] = None
    hazard_tracker: Optional[Any] = None
    current_cycle: float = 0.0

    pipes: Dict[str, PipeBase] = field(default_factory=dict, init=False)
    mailboxes: Dict[str, Mailbox] = field(default_factory=dict, init=False)
    bar_all_barrier: threading.Barrier = field(init=False)
    _failure: Optional[str] = field(default=None, init=False)
    _current_inst: Optional[ControlInstruction] = field(default=None, init=False, repr=False)
    _current_inst_started_at: float = field(default=0.0, init=False, repr=False)

    def __post_init__(self) -> None:
        pipe_count = len(self.lane_program.pipe_names)
        self.bar_all_barrier = CycleBarrier(parties=pipe_count + 1)
        for pipe_name in self.lane_program.pipe_names:
            mbox = Mailbox(maxsize=self.config.queue_maxsize)
            self.mailboxes[pipe_name] = mbox
            self.pipes[pipe_name] = self.pipe_factory(
                self.core_idx, self.lane_name, pipe_name,
                mbox, self.bar_all_barrier, self.memory_store,
                self.event_bank, self.intra_sync,
                trace_recorder=self.trace_recorder,
                cycle_model=self.cycle_model,
                hazard_tracker=self.hazard_tracker,
            )

    @property
    def vec_idx(self) -> int:
        if self.lane_name.startswith("vec"):
            suffix = self.lane_name[3:]
            if suffix.isdigit():
                return int(suffix)
        return 0

    def _logical_offset_bytes(self, name: str) -> Optional[int]:
        fn = getattr(self.memory_store, "logical_offset_bytes", None)
        if callable(fn):
            return fn(name)
        return None

    def _memory_alias(self, name: str) -> Optional[PhysicalAlias]:
        fn = getattr(self.memory_store, "alias", None)
        if callable(fn):
            alias = fn(name)
            if alias is not None:
                return alias
        if not self.memory_store.contains(name):
            return None
        return as_physical_alias(
            self.memory_store.tensor(name),
            logical_offset_bytes=self._logical_offset_bytes(name),
            name=name,
            storage_name=name,
            role=self._memory_role(name),
        )

    def _memory_role(self, name: str) -> str:
        specs = getattr(self.memory_store, "specs", {})
        spec = specs.get(name) if isinstance(specs, dict) else None
        return str(getattr(spec, "role", "") or "")

    def _register_memory_view(self, name: str, view: Any, logical_offset: Optional[int] = None) -> None:
        if logical_offset is None:
            self.memory_store.register_view(name, view)
            return
        try:
            self.memory_store.register_view(name, view, logical_offset)
        except TypeError:
            self.memory_store.register_view(name, view)

    def _register_physical_view(
        self,
        name: str,
        source_name: str,
        logical_view: Any,
        logical_offset: Optional[int] = None,
        byte_offset: int = 0,
        physical_tensor: Optional[Any] = None,
        tags: Tuple[str, ...] = (),
    ) -> None:
        source_alias = self._memory_alias(source_name)
        if source_alias is not None:
            base_tensor = physical_tensor if physical_tensor is not None else source_alias.tensor
            base_byte_offset = 0 if physical_tensor is not None else int(source_alias.byte_offset)
            storage_name = str(source_alias.storage_name or source_name)
            role = str(source_alias.role or self._memory_role(storage_name))
            alias_tags = tuple(source_alias.tags)
        else:
            base_tensor = physical_tensor if physical_tensor is not None else self.memory_store.tensor(source_name)
            base_byte_offset = 0
            storage_name = str(source_name)
            role = self._memory_role(storage_name)
            alias_tags = ()
        alias = PhysicalAlias(
            tensor=base_tensor,
            byte_offset=base_byte_offset + int(byte_offset),
            logical_view=logical_view,
            logical_offset_bytes=logical_offset,
            name=name,
            storage_name=storage_name,
            dtype=normalize_dtype(str(getattr(logical_view, "dtype", ""))),
            role=role,
            tags=alias_tags + tuple(str(tag) for tag in tags),
        )
        self._register_memory_view(name, alias, logical_offset)

    @staticmethod
    def _alias_has_materialized_logical_base(alias: PhysicalAlias) -> bool:
        logical = alias.logical_view
        if logical is None:
            return False
        if alias.logical_offset_bytes is None:
            return logical is not alias.tensor or int(alias.byte_offset) == 0
        try:
            return byte_storage_offset(logical) == int(alias.logical_offset_bytes)
        except Exception:
            return False

    @staticmethod
    def _alias_scalar_head(alias: PhysicalAlias) -> Any:
        logical = alias.logical_tensor()
        logical_flat = logical.reshape(-1)
        if logical_flat.numel() == 0:
            return logical_flat
        if PipeS._alias_has_materialized_logical_base(alias):
            return logical_flat.narrow(0, 0, 1)
        if int(alias.byte_offset) == 0:
            return logical_flat.narrow(0, 0, 1)
        elem = int(alias.tensor.element_size())
        if int(alias.byte_offset) % elem != 0:
            raise RuntimeError(
                "scalar alias byte offset is not divisible by element size: "
                + str(alias.byte_offset)
            )
        elem_offset = int(alias.byte_offset) // elem
        tail = _storage_tail_view(alias.tensor)
        if elem_offset < 0 or elem_offset >= int(tail.numel()):
            return tail.narrow(0, int(tail.numel()), 0)
        head = tail.narrow(0, elem_offset, 1)
        if head.dtype != logical.dtype:
            head = head.view(logical.dtype)
        return head

    @staticmethod
    def _alias_effective_tensor(alias: PhysicalAlias) -> Any:
        logical = alias.logical_tensor()
        if PipeS._alias_has_materialized_logical_base(alias):
            return logical
        if int(alias.byte_offset) == 0:
            return logical
        elem = int(alias.tensor.element_size())
        if int(alias.byte_offset) % elem != 0:
            raise RuntimeError(
                "alias byte offset is not divisible by element size: "
                + str(alias.byte_offset)
            )
        elem_offset = int(alias.byte_offset) // elem
        tail = _storage_tail_view(alias.tensor)
        if elem_offset < 0:
            raise RuntimeError("alias element offset is negative: " + str(elem_offset))
        if elem_offset >= int(tail.numel()):
            return tail.narrow(0, int(tail.numel()), 0)
        return tail.narrow(0, elem_offset, int(tail.numel()) - elem_offset)

    # ------------------------------------------------------------------
    # Lifecycle — called from Core as a thread target
    # ------------------------------------------------------------------

    def run(self) -> None:
        for pipe in self.pipes.values():
            pipe.start()
        try:
            self._interpret()
        except BaseException as exc:
            self._failure = traceback.format_exc()
            inst_desc = self.describe_inflight_inst() or "(no inflight inst)"
            print(
                "[simulator] lane control failed: core=%d lane=%s inst=%s\n%s"
                % (self.core_idx, self.lane_name, inst_desc, self._failure),
                file=sys.stderr, flush=True,
            )
        finally:
            for pipe in self.pipes.values():
                pipe.stop()
            for pipe in self.pipes.values():
                pipe.join()
            pipe_failures = [p._failure for p in self.pipes.values() if p._failure]
            if pipe_failures and not self._failure:
                self._failure = pipe_failures[0]

    # ------------------------------------------------------------------
    # Instruction interpreter — block-based with control flow
    # ------------------------------------------------------------------

    def _interpret(self) -> None:
        self._vars: Dict[str, Any] = {}
        self._atomic_mode: str = ""
        instructions = self.lane_program.instructions
        self._exec_block(instructions, 0, len(instructions))

    def _exec_block(self, instructions: List[ControlInstruction], start: int, end: int) -> None:
        idx = start
        while idx < end:
            inst = instructions[idx]
            op = inst.opname

            if op == "break_loop":
                raise _BreakSignal()
            if op == "continue_loop":
                raise _ContinueSignal()

            if op in ("start_loop", "start_micro_loop"):
                loop_end = self._find_loop_end(instructions, idx, end)
                self._exec_loop(instructions, idx, loop_end)
                idx = loop_end + 1
                continue

            if op == "end_loop":
                return

            if op == "start_if":
                idx = self._exec_if_chain(instructions, idx, end)
                continue

            if op in ("start_elif", "start_else", "end_if"):
                return

            if op in _SCOPE_OPS:
                idx += 1
                continue

            self._exec_inst(inst)
            idx += 1

    def _exec_loop(self, instructions: List[ControlInstruction], start: int, loop_end: int) -> None:
        args = instructions[start].args
        var_name = str(args.get("var", args.get("var_name", "")))
        loop_start = self._resolve_int(args.get("start", 0))
        loop_stop = self._resolve_int(args.get("stop", 0))
        loop_step = self._resolve_int(args.get("step", 1))
        if loop_step == 0:
            raise ValueError("loop step cannot be zero")
        for value in range(loop_start, loop_stop, loop_step):
            if var_name:
                self._vars[var_name] = value
            try:
                self._exec_block(instructions, start + 1, loop_end)
            except _ContinueSignal:
                pass
            except _BreakSignal:
                break

    def _find_loop_end(self, instructions: List[ControlInstruction], start: int, end: int) -> int:
        depth = 1
        idx = start + 1
        while idx < end:
            op = instructions[idx].opname
            if op in ("start_loop", "start_micro_loop"):
                depth += 1
            elif op == "end_loop":
                depth -= 1
                if depth == 0:
                    return idx
            idx += 1
        raise ValueError("start_loop at " + str(start) + " without matching end_loop")

    def _find_if_end(self, instructions: List[ControlInstruction], start: int, end: int) -> int:
        depth = 1
        idx = start + 1
        while idx < end:
            op = instructions[idx].opname
            if op == "start_if":
                depth += 1
            elif op == "end_if":
                depth -= 1
                if depth == 0:
                    return idx
            idx += 1
        raise ValueError("start_if at " + str(start) + " without matching end_if")

    def _exec_if_chain(self, instructions: List[ControlInstruction], start: int, end: int) -> int:
        if_end = self._find_if_end(instructions, start, end)
        segments: List[tuple] = []
        seg_header = start
        seg_body = start + 1
        nested_if = 0
        nested_loop = 0
        idx = start + 1
        while idx < if_end:
            op = instructions[idx].opname
            if op in ("start_loop", "start_micro_loop"):
                nested_loop += 1
            elif op == "end_loop":
                nested_loop -= 1
            elif op == "start_if":
                nested_if += 1
            elif op == "end_if":
                nested_if -= 1
            elif op in ("start_elif", "start_else") and nested_if == 0 and nested_loop == 0:
                segments.append((seg_header, seg_body, idx))
                seg_header = idx
                seg_body = idx + 1
            idx += 1
        segments.append((seg_header, seg_body, if_end))

        for header_idx, body_start, body_end in segments:
            header = instructions[header_idx]
            if header.opname == "start_else":
                self._exec_block(instructions, body_start, body_end)
                break
            cond = header.args.get("cond")
            if self._resolve_bool(cond):
                self._exec_block(instructions, body_start, body_end)
                break
        return if_end + 1

    # ------------------------------------------------------------------
    # Single instruction dispatch
    # ------------------------------------------------------------------

    def _exec_inst(self, inst: ControlInstruction) -> None:
        self._current_inst = inst
        start_ts = time.monotonic()
        self._current_inst_started_at = start_ts
        op = inst.opname
        cycle_start = float(self.current_cycle)
        try:
            if op == "call_micro":
                self._dispatch_call_micro(inst)

            elif op == "call_simt":
                self._dispatch_call_simt(inst)

            elif op in ("sim_dump_tensor", "sim_print") and inst.is_pipe_op():
                self._dispatch_sim_debug(inst)

            elif inst.is_pipe_op():
                self._dispatch(inst, self._vars)

            elif op == "bar_all":
                self._handle_bar_all()

            elif op == "setflag":
                self._handle_setflag(inst)
            elif op == "waitflag":
                self._handle_waitflag(inst)

            elif op in _CROSS_LANE_READY:
                self._handle_cross_lane_ready(inst)
            elif op in _CROSS_LANE_WAIT:
                self._handle_cross_lane_wait(inst)
            elif op in _INTRACORE_ALLVEC_READY:
                self._handle_intracore_allvec_ready(inst)
            elif op in _INTRACORE_ALLVEC_WAIT:
                self._handle_intracore_allvec_wait(inst)
            elif op in _COLLECTIVE_READY:
                self._handle_collective_ready(inst)
            elif op in _COLLECTIVE_WAIT:
                self._handle_collective_wait(inst)

            elif op in ("atomic_add", "atomic_max", "atomic_min"):
                self._atomic_mode = op
            elif op == "atomic_end":
                self._atomic_mode = ""
            elif op == "set_atomic_type":
                pass

            elif op in _EVENT_CREATE:
                self._handle_event_create(inst)
            elif op in ("event_set", "event_setall"):
                self._handle_event_set(inst)
            elif op == "event_wait":
                self._handle_event_wait(inst)
            elif op == "event_release":
                self._handle_event_release(inst)

            elif op == "get_buf":
                self._handle_get_buf(inst)
            elif op == "slice_gm_tensor":
                self._handle_slice_gm_tensor(inst)
            elif op == "get_gm_tensor_list_item":
                self._handle_get_gm_tensor_list_item(inst)
            elif op == "reshape_gm_tensor":
                self._handle_reshape_gm_tensor(inst)
            elif op == "reinterpret":
                self._handle_reinterpret(inst)
            elif op == "slice_tensor":
                self._handle_slice_tensor(inst)

            elif op == "GetValueFrom":
                self._handle_get_value_from(inst)
            elif op == "SetValueTo":
                self._handle_set_value_to(inst)

            elif op == "sim_dump_tensor":
                self._handle_sim_dump_tensor(inst)
            elif op == "sim_print":
                self._handle_sim_print(inst)

            elif op in ("kernel_print", "kernel_dump_tensor"):
                pass

            elif op in _VAR_OPS:
                self._handle_var_op(inst, self._vars)

            else:
                raise NotImplementedError("PipeS unhandled instruction: " + op)
        finally:
            model = self.cycle_model
            if model is not None:
                marker = max(1, int(getattr(model, "sync_marker_cycles", 1)))
                if self.current_cycle < cycle_start + marker:
                    self.current_cycle = cycle_start + marker
            recorder = self.trace_recorder
            if (
                recorder is not None
                and recorder.record_pipe_s
                and (recorder.record_event or op not in _EVENT_CONTROL_OPS)
            ):
                args = {
                    "lane_name": self.lane_name,
                    "pipe_name": "S",
                    "opname": op,
                }
                if model is not None:
                    ts = cycle_start
                    dur = max(float(self.current_cycle) - cycle_start, 0.0)
                    args["time_domain"] = "cycle"
                    args["cycle_model_profile"] = getattr(model, "profile_name", "")
                else:
                    ts = start_ts
                    dur = time.monotonic() - start_ts
                    if dur < 0.0:
                        dur = 0.0
                recorder.record(
                    kind=TraceEventKind.CONTROL,
                    name=op,
                    ts=ts,
                    dur=dur,
                    args=args,
                )
            self._current_inst = None
            self._current_inst_started_at = 0.0

    def describe_inflight_inst(self) -> Optional[str]:
        inst = self._current_inst
        if inst is None:
            return None
        elapsed = max(time.monotonic() - self._current_inst_started_at, 0.0)
        args_text = repr(inst.args)
        if len(args_text) > 240:
            args_text = args_text[:237] + "..."
        return (
            self.lane_name
            + " control thread running " + inst.opname
            + " for %.3fs" % elapsed
            + " args=" + args_text
        )

    # ------------------------------------------------------------------
    # Pipe dispatch (non-blocking put into mailbox)
    # ------------------------------------------------------------------

    def _dispatch(self, inst: ControlInstruction, var_values: Dict[str, Any]) -> None:
        resolved = self._resolve_args(inst.args, var_values)
        if self._atomic_mode:
            resolved["_atomic"] = self._atomic_mode
        task = PipeTask(pipe_name=inst.pipe_name, opname=inst.opname, args=resolved)
        task.earliest_start_cycle = float(self.current_cycle)
        mbox = self.mailboxes.get(inst.pipe_name)
        if mbox is None:
            raise RuntimeError("no pipe: " + self.lane_name + "/" + inst.pipe_name)
        mbox.put(task)

    def _dispatch_call_micro(self, inst: ControlInstruction) -> None:
        # Runtime boundary note: call_micro tensor bindings carry pointer-style
        # aliases. Downstream micro datacopy resolves physical storage + offset
        # first, using logical views only for diagnostics.
        args = inst.args
        micro_name = str(args.get("name", ""))
        call_bindings = args.get("call_bindings", [])
        micro_def = self.micro_defs.get(micro_name)
        if micro_def is None:
            raise ValueError("call_micro references unknown micro: " + micro_name)
        input_list = micro_def.get("input_list", [])
        tensor_views: Dict[str, Any] = {}
        tensor_offsets_bytes: Dict[str, int] = {}
        var_values: Dict[str, Any] = {}
        for formal, binding in zip(input_list, call_bindings):
            formal_name = str(formal.name) if hasattr(formal, "name") else str(formal)
            kind = str(binding.get("kind", ""))
            if kind == "tensor":
                actual_name = str(binding.get("actual_name", ""))
                resolved_name = self._resolve_value(actual_name, self._vars)
                if isinstance(resolved_name, str) and self.memory_store.contains(resolved_name):
                    logical_offset = self._logical_offset_bytes(resolved_name)
                    alias = self._memory_alias(resolved_name)
                    if alias is not None:
                        tensor_views[formal_name] = alias
                    if logical_offset is not None:
                        tensor_offsets_bytes[formal_name] = int(logical_offset)
            elif kind == "var":
                actual_ref = binding.get("actual_ref", 0)
                var_values[formal_name] = self._resolve_value(actual_ref, self._vars)
        task = PipeTask(pipe_name=inst.pipe_name or "V", opname="call_micro", args={
            "name": micro_name,
            "tensor_views": tensor_views,
            "tensor_offsets_bytes": tensor_offsets_bytes,
            "var_values": var_values,
            "micro_def": micro_def,
        })
        task.earliest_start_cycle = float(self.current_cycle)
        mbox = self.mailboxes.get(inst.pipe_name or "V")
        if mbox is None:
            raise RuntimeError("no pipe: " + self.lane_name + "/V")
        mbox.put(task)

    def _dispatch_call_simt(self, inst: ControlInstruction) -> None:
        # Runtime boundary note: call_simt tensor bindings may also carry
        # PhysicalAlias descriptors, but SIMT execution keeps logical tensor
        # indexing semantics and therefore consumes the logical materialized
        # view from each binding.
        args = inst.args
        simt_name = str(args.get("name", ""))
        call_bindings = args.get("call_bindings", [])
        simt_def = self.simt_defs.get(simt_name)
        if simt_def is None:
            raise ValueError("call_simt references unknown simt: " + simt_name)
        input_list = simt_def.get("input_list", [])
        tensor_views: Dict[str, Any] = {}
        var_values: Dict[str, Any] = {}
        for formal, binding in zip(input_list, call_bindings):
            if isinstance(formal, (list, tuple)):
                formal_name = str(formal[0])
            else:
                formal_name = str(getattr(formal, "name", formal))
            kind = str(binding.get("kind", ""))
            if kind == "tensor":
                actual_name = str(binding.get("actual_name", ""))
                resolved_name = self._resolve_value(actual_name, self._vars)
                if isinstance(resolved_name, str) and self.memory_store.contains(resolved_name):
                    alias = self._memory_alias(resolved_name)
                    if alias is not None:
                        tensor_views[formal_name] = alias
            elif kind == "var":
                actual_ref = binding.get("actual_ref", 0)
                var_values[formal_name] = self._resolve_value(actual_ref, self._vars)
        block_idx = int(self.core_idx)
        block_num = int(self.config.core_count)
        thread_num = int(simt_def.get("num_threads", 1024))
        task = PipeTask(pipe_name=inst.pipe_name or "V", opname="call_simt", args={
            "name": simt_name,
            "tensor_views": tensor_views,
            "var_values": var_values,
            "simt_def": simt_def,
            "block_idx": block_idx,
            "block_num": block_num,
            "thread_num": thread_num,
            "_simt_defer_cycle_count": True,
        })
        task.earliest_start_cycle = float(self.current_cycle)
        mbox = self.mailboxes.get(inst.pipe_name or "V")
        if mbox is None:
            raise RuntimeError("no pipe: " + self.lane_name + "/V")
        mbox.put(task)

    def _dispatch_sim_debug(self, inst: ControlInstruction) -> None:
        if inst.opname == "sim_dump_tensor":
            tensor_name = self._resolve_value(inst.args.get("tensor", ""), self._vars)
            filename = inst.args.get("filename", "")
            task_args = {"tensor": tensor_name, "filename": filename}
        elif inst.opname == "sim_print":
            raw_payload = inst.args.get("payload", [])
            if not isinstance(raw_payload, list):
                raise TypeError("sim_print payload must be list, got: " + str(type(raw_payload)))
            payload: List[Dict[str, Any]] = []
            for item in raw_payload:
                if not isinstance(item, dict):
                    payload.append({"kind": "literal", "value": item})
                    continue
                kind = str(item.get("kind", "literal"))
                value = item.get("value", "")
                if kind in ("gm_tensor", "local_tensor", "var", "expr"):
                    value = self._resolve_value(value, self._vars)
                payload.append({"kind": kind, "value": value})
            task_args = {"payload": payload}
        else:
            raise NotImplementedError("unexpected sim debug op: " + inst.opname)

        task = PipeTask(pipe_name=inst.pipe_name, opname=inst.opname, args=task_args)
        task.earliest_start_cycle = float(self.current_cycle)
        mbox = self.mailboxes.get(inst.pipe_name)
        if mbox is None:
            raise RuntimeError("no pipe: " + self.lane_name + "/" + inst.pipe_name)
        mbox.put(task)

    # ------------------------------------------------------------------
    # bar_all: send marker to own pipes, then join barrier with all lanes
    # ------------------------------------------------------------------

    def _handle_bar_all(self) -> None:
        for mbox in self.mailboxes.values():
            mbox.put(BAR_ALL_MARKER)
        try:
            release_cycle = _bar_all_wait_cycle(self.bar_all_barrier, self.current_cycle)
        except threading.BrokenBarrierError:
            pipe_failures = [p._failure for p in self.pipes.values() if p._failure]
            if pipe_failures:
                raise RuntimeError("pipe worker failed during bar_all:\n" + pipe_failures[0])
            raise RuntimeError("bar_all barrier broken")
        self.current_cycle = _advance_bar_all_cycle(self.current_cycle, release_cycle, self.cycle_model)

    # ------------------------------------------------------------------
    # Cross-lane sync
    # ------------------------------------------------------------------

    def _handle_cross_lane_ready(self, inst: ControlInstruction) -> None:
        flag_id = int(inst.args.get("flag_id", 0))
        pipe = str(inst.args.get("pipe", "S"))
        if pipe != "S" and pipe in self.mailboxes:
            task = PipeTask(pipe_name=pipe, opname=inst.opname, args={
                "flag_id": flag_id, "vec_idx": self.vec_idx,
            })
            task.earliest_start_cycle = float(self.current_cycle)
            self.mailboxes[pipe].put(task)
        else:
            ready_cycle = float(self.current_cycle)
            visible_cycle = _intra_core_sync_visible_cycle(self.cycle_model, ready_cycle)
            if inst.opname == "cube_ready":
                self.intra_sync.cube_ready(flag_id, ready_cycle=ready_cycle, visible_cycle=visible_cycle)
            elif inst.opname == "vec_ready":
                self.intra_sync.vec_ready(self.vec_idx, flag_id, ready_cycle=ready_cycle, visible_cycle=visible_cycle)

    def _handle_cross_lane_wait(self, inst: ControlInstruction) -> None:
        flag_id = int(inst.args.get("flag_id", 0))
        pipe = str(inst.args.get("pipe", "S"))
        timeout = float(inst.args.get("timeout", self.config.execution_timeout_s))
        if pipe != "S" and pipe in self.mailboxes:
            task = PipeTask(pipe_name=pipe, opname=inst.opname, args={
                "flag_id": flag_id, "vec_idx": self.vec_idx,
                "timeout": timeout,
            })
            task.earliest_start_cycle = float(self.current_cycle)
            self.mailboxes[pipe].put(task)
        else:
            arrival_cycle = float(self.current_cycle)
            if inst.opname == "wait_vec":
                if not self.intra_sync.wait_vec(flag_id, timeout=timeout):
                    raise RuntimeError("wait_vec timeout flag_id=" + str(flag_id))
                ready_cycle = self.intra_sync.vec_ready_cycle(flag_id)
                signal_cycle = self.intra_sync.vec_ready_signal_cycle(flag_id)
                _record_intra_sync_stall(
                    self.trace_recorder, self.cycle_model, self.lane_name, "S",
                    inst.opname, flag_id, arrival_cycle, signal_cycle, ready_cycle,
                )
                if ready_cycle > self.current_cycle:
                    self.current_cycle = ready_cycle
            elif inst.opname == "wait_cube":
                if not self.intra_sync.wait_cube(self.vec_idx, flag_id, timeout=timeout):
                    raise RuntimeError("wait_cube timeout flag_id=" + str(flag_id))
                ready_cycle = self.intra_sync.cube_ready_cycle(self.vec_idx, flag_id)
                signal_cycle = self.intra_sync.cube_ready_signal_cycle(self.vec_idx, flag_id)
                _record_intra_sync_stall(
                    self.trace_recorder, self.cycle_model, self.lane_name, "S",
                    inst.opname, flag_id, arrival_cycle, signal_cycle, ready_cycle,
                )
                if ready_cycle > self.current_cycle:
                    self.current_cycle = ready_cycle

    def _handle_intracore_allvec_ready(self, inst: ControlInstruction) -> None:
        flag_id = int(inst.args.get("flag_id", 0))
        pipe = str(inst.args.get("pipe", "S"))
        if pipe != "S" and pipe in self.mailboxes:
            task = PipeTask(pipe_name=pipe, opname=inst.opname, args={
                "flag_id": flag_id, "vec_idx": self.vec_idx,
            })
            task.earliest_start_cycle = float(self.current_cycle)
            self.mailboxes[pipe].put(task)
        else:
            ready_cycle = float(self.current_cycle)
            visible_cycle = _intra_core_sync_visible_cycle(self.cycle_model, ready_cycle)
            self.intra_sync.intracore_allvec_ready(
                self.vec_idx, flag_id, ready_cycle=ready_cycle, visible_cycle=visible_cycle,
            )

    def _handle_intracore_allvec_wait(self, inst: ControlInstruction) -> None:
        flag_id = int(inst.args.get("flag_id", 0))
        pipe = str(inst.args.get("pipe", "S"))
        timeout = float(inst.args.get("timeout", self.config.execution_timeout_s))
        if pipe != "S" and pipe in self.mailboxes:
            task = PipeTask(pipe_name=pipe, opname=inst.opname, args={
                "flag_id": flag_id, "vec_idx": self.vec_idx,
                "timeout": timeout,
            })
            task.earliest_start_cycle = float(self.current_cycle)
            self.mailboxes[pipe].put(task)
        else:
            arrival_cycle = float(self.current_cycle)
            if not self.intra_sync.intracore_allvec_wait(self.vec_idx, flag_id, timeout=timeout):
                raise RuntimeError("intracore_allvec_wait timeout flag_id=" + str(flag_id))
            ready_cycle = self.intra_sync.intracore_allvec_ready_cycle(self.vec_idx, flag_id)
            signal_cycle = self.intra_sync.intracore_allvec_ready_signal_cycle(self.vec_idx, flag_id)
            _record_intra_sync_stall(
                self.trace_recorder, self.cycle_model, self.lane_name, "S",
                inst.opname, flag_id, arrival_cycle, signal_cycle, ready_cycle,
            )
            if ready_cycle > self.current_cycle:
                self.current_cycle = ready_cycle

    # ------------------------------------------------------------------
    # Collective sync (cross-core)
    # ------------------------------------------------------------------

    def _handle_collective_ready(self, inst: ControlInstruction) -> None:
        self._handle_bar_all()
        flag_id = int(inst.args.get("flag_id", 0))
        ready_cycle = float(self.current_cycle)
        if inst.opname == "allcube_ready":
            self.cross_sync.allcube_ready(self.core_idx, flag_id, ready_cycle=ready_cycle)
        elif inst.opname == "allvec_ready":
            self.cross_sync.allvec_ready(self.core_idx, self.vec_idx, flag_id, ready_cycle=ready_cycle)

    def _handle_collective_wait(self, inst: ControlInstruction) -> None:
        self._handle_bar_all()
        flag_id = int(inst.args.get("flag_id", 0))
        timeout = float(inst.args.get("timeout", self.config.execution_timeout_s))
        if inst.opname == "allcube_wait":
            if not self.cross_sync.allcube_wait(self.core_idx, flag_id, timeout=timeout):
                raise RuntimeError("allcube_wait timeout")
            ready_cycle = self.cross_sync.allcube_ready_cycle(flag_id)
            if ready_cycle > self.current_cycle:
                self.current_cycle = ready_cycle
        elif inst.opname == "allvec_wait":
            if not self.cross_sync.allvec_wait(self.core_idx, self.vec_idx, flag_id, timeout=timeout):
                raise RuntimeError("allvec_wait timeout")
            ready_cycle = self.cross_sync.allvec_ready_cycle(flag_id)
            if ready_cycle > self.current_cycle:
                self.current_cycle = ready_cycle

    # ------------------------------------------------------------------
    # Local events
    # ------------------------------------------------------------------

    def _handle_event_create(self, inst: ControlInstruction) -> None:
        name = str(inst.args.get("event_name", ""))
        kind = {
            "create_sevent": "s",
            "create_devent": "d",
            "create_tevent": "t",
            "create_qevent": "q",
        }[inst.opname]
        src = str(inst.args.get("src_pipe", ""))
        dst = str(inst.args.get("dst_pipe", ""))
        preset = bool(inst.args.get("preset", False))
        self.event_bank.create_event(name, kind, src, dst, preset=preset)

    def _handle_event_set(self, inst: ControlInstruction) -> None:
        name = str(inst.args.get("event_name", ""))
        src_pipe = str(inst.args.get("src_pipe", ""))
        set_all = inst.opname == "event_setall"
        task = PipeTask(pipe_name=src_pipe, opname=inst.opname, args={
            "event_name": name, "set_all": set_all,
        })
        task.earliest_start_cycle = float(self.current_cycle)
        mbox = self.mailboxes.get(src_pipe)
        if mbox is not None:
            mbox.put(task)
        else:
            self.event_bank.set_event(name, set_all=set_all, ready_cycle=float(self.current_cycle))

    def _handle_event_wait(self, inst: ControlInstruction) -> None:
        name = str(inst.args.get("event_name", ""))
        dst_pipe = str(inst.args.get("dst_pipe", ""))
        task = PipeTask(pipe_name=dst_pipe, opname="event_wait", args={
            "event_name": name, "timeout": self.config.execution_timeout_s,
        })
        task.earliest_start_cycle = float(self.current_cycle)
        mbox = self.mailboxes.get(dst_pipe)
        if mbox is not None:
            mbox.put(task)
        else:
            if not self.event_bank.wait_event(name, timeout=self.config.execution_timeout_s):
                raise RuntimeError("event_wait timeout: " + name)
            ready_cycle = self.event_bank.ready_cycle(name)
            if ready_cycle > self.current_cycle:
                self.current_cycle = ready_cycle

    def _handle_event_release(self, inst: ControlInstruction) -> None:
        name = str(inst.args.get("event_name", ""))
        dst_pipe = str(inst.args.get("dst_pipe", ""))
        task = PipeTask(pipe_name=dst_pipe, opname="event_release", args={
            "event_name": name, "timeout": self.config.execution_timeout_s,
        })
        task.earliest_start_cycle = float(self.current_cycle)
        mbox = self.mailboxes.get(dst_pipe)
        if mbox is not None:
            mbox.put(task)
        else:
            if not self.event_bank.release_event(name, timeout=self.config.execution_timeout_s):
                raise RuntimeError("event_release timeout: " + name)
            ready_cycle = self.event_bank.ready_cycle(name)
            if ready_cycle > self.current_cycle:
                self.current_cycle = ready_cycle

    # ------------------------------------------------------------------
    # Raw local flags
    # ------------------------------------------------------------------

    def _handle_setflag(self, inst: ControlInstruction) -> None:
        src_pipe, dst_pipe, event_id = self._local_flag_args(inst)
        task = PipeTask(pipe_name=src_pipe, opname="setflag", args={
            "src": src_pipe, "dst": dst_pipe, "event_id": event_id,
        })
        task.earliest_start_cycle = float(self.current_cycle)
        mbox = self.mailboxes.get(src_pipe)
        if mbox is None:
            raise RuntimeError("no pipe: " + self.lane_name + "/" + src_pipe)
        mbox.put(task)

    def _handle_waitflag(self, inst: ControlInstruction) -> None:
        src_pipe, dst_pipe, event_id = self._local_flag_args(inst)
        if dst_pipe != "S":
            task = PipeTask(pipe_name=dst_pipe, opname="waitflag", args={
                "src": src_pipe, "dst": dst_pipe, "event_id": event_id,
                "timeout": self.config.execution_timeout_s,
            })
            task.earliest_start_cycle = float(self.current_cycle)
            mbox = self.mailboxes.get(dst_pipe)
            if mbox is None:
                raise RuntimeError("no pipe: " + self.lane_name + "/" + dst_pipe)
            mbox.put(task)
            return

        sync = getattr(self.event_bank, "sync", self.local_sync)
        arrival_cycle = float(self.current_cycle)
        if not sync.wait(src_pipe, dst_pipe, event_id, timeout=self.config.execution_timeout_s):
            raise RuntimeError(
                "waitflag timeout: src=" + src_pipe + " dst=" + dst_pipe
                + " event_id=" + str(event_id)
            )
        ready_cycle = sync.ready_cycle(src_pipe, dst_pipe, event_id)
        if ready_cycle > self.current_cycle:
            self.current_cycle = ready_cycle
        self.current_cycle = max(self.current_cycle, arrival_cycle)

    def _local_flag_args(self, inst: ControlInstruction) -> Tuple[str, str, int]:
        resolved = self._resolve_args(inst.args, self._vars)
        src_pipe = str(resolved.get("src", ""))
        dst_pipe = str(resolved.get("dst", ""))
        event_id = int(resolved.get("event_id", 0))
        return src_pipe, dst_pipe, event_id

    # ------------------------------------------------------------------
    # Variable / scalar ops
    # ------------------------------------------------------------------

    def _handle_var_op(self, inst: ControlInstruction, var_values: Dict[str, Any]) -> None:
        op = inst.opname
        args = inst.args

        if op == "create_var":
            name = str(args.get("name", ""))
            var_values[name] = self._resolve_value(args.get("value", 0), var_values)

        elif op == "create_varlist":
            self._handle_create_varlist(args, var_values)

        elif op == "var_assign":
            value = self._resolve_value(args.get("src", 0), var_values)
            self._store_var_value(args.get("dst", ""), value, var_values)

        elif op == "tensorlist_size":
            item_names = args.get("item_names", [])
            if not isinstance(item_names, list):
                raise TypeError("tensorlist_size requires item_names list")
            self._store_var_value(args.get("dst", ""), len(item_names), var_values)

        elif op == "tensorlist_item_numel":
            item_names = args.get("item_names", [])
            if not isinstance(item_names, list) or not item_names:
                raise ValueError("tensorlist_item_numel requires a non-empty item_names list")
            index = int(self._resolve_value(args.get("index", 0), var_values))
            if index < 0 or index >= len(item_names):
                raise IndexError(
                    "TensorList index out of range: "
                    + str(index)
                    + " not in [0, "
                    + str(len(item_names))
                    + ")"
                )
            item_name = str(item_names[index])
            if item_name in self.tensor_name_map:
                item_name = self.tensor_name_map[item_name]
            if not self.memory_store.contains(item_name):
                list_name = str(args.get("list_name", ""))
                raise KeyError(
                    "TensorList item tensor not found: "
                    + item_name
                    + (" from " + list_name if list_name else "")
                )
            numel = int(self.memory_store.tensor(item_name).numel())
            self._store_var_value(args.get("dst", ""), numel, var_values)

        elif op in ("var_add", "var_sub", "var_mul", "var_div", "var_mod"):
            dst_arg = args.get("dst", "")
            a_default = self._load_var_value(dst_arg, var_values, default=0)
            a = self._resolve_value(args.get("a", a_default), var_values)
            b = self._resolve_value(args.get("b", 0), var_values)
            if op == "var_add":
                result = a + b
            elif op == "var_sub":
                result = a - b
            elif op == "var_mul":
                result = a * b
            elif op == "var_div":
                if not b:
                    raise ZeroDivisionError("var_div division by zero")
                if isinstance(a, float) or isinstance(b, float):
                    result = a / b
                else:
                    result = a // b
            else:  # var_mod
                if not b:
                    raise ZeroDivisionError("var_mod division by zero")
                a_int = int(a)
                b_int = int(b)
                quotient = abs(a_int) // abs(b_int)
                if (a_int < 0) != (b_int < 0):
                    quotient = -quotient
                result = a_int - quotient * b_int
            self._store_var_value(dst_arg, result, var_values)

        elif op == "CeilDiv":
            a = self._resolve_value(args.get("a", 0), var_values)
            b = self._resolve_value(args.get("b", 1), var_values)
            if not b:
                raise ZeroDivisionError("CeilDiv division by zero")
            self._store_var_value(args.get("dst", ""), (int(a) + int(b) - 1) // int(b), var_values)

        elif op in ("Min", "Max"):
            a = self._resolve_value(args.get("a", 0), var_values)
            b = self._resolve_value(args.get("b", 0), var_values)
            self._store_var_value(args.get("dst", ""), min(a, b) if op == "Min" else max(a, b), var_values)

        elif op == "GetCubeNum":
            var_values[str(args.get("dst", ""))] = self.config.core_count

        elif op == "GetCubeIdx":
            var_values[str(args.get("dst", ""))] = self.core_idx

        elif op == "GetVecIdx":
            self._require_vec_lane_scalar_op(op)
            if self.kernel_mode == "vec":
                var_values[str(args.get("dst", ""))] = int(self.core_idx)
            else:
                var_values[str(args.get("dst", ""))] = 2 * int(self.core_idx) + int(self.vec_idx)

        elif op == "GetSubBlockIdx":
            self._require_vec_lane_scalar_op(op)
            var_values[str(args.get("dst", ""))] = 0 if self.kernel_mode == "vec" else self.vec_idx

        elif op == "GetSubBlockNum":
            self._require_vec_lane_scalar_op(op)
            var_values[str(args.get("dst", ""))] = 1 if self.kernel_mode == "vec" else 2

        elif op.startswith("Align"):
            a = int(self._resolve_value(args.get("a", 0), var_values))
            suffix = op[5:]
            if not suffix.isdigit():
                raise ValueError("Align opcode suffix must be numeric: " + op)
            align_val = int(suffix)
            self._store_var_value(args.get("dst", ""), ((a + align_val - 1) // align_val) * align_val, var_values)

        elif op == "GetVecNum":
            self._require_vec_lane_scalar_op(op)
            multiplier = 1 if self.kernel_mode == "vec" else 2
            var_values[str(args.get("dst", ""))] = multiplier * int(self.config.core_count)

        elif op == "scalar_sqrt":
            a = float(self._resolve_value(args.get("a", 0), var_values))
            import math
            result = math.sqrt(a)
            self._store_var_value(args.get("dst", ""), result, var_values)

        elif op == "scalar_abs":
            a = self._resolve_value(args.get("a", 0), var_values)
            self._store_var_value(args.get("dst", ""), abs(a), var_values)

    # ------------------------------------------------------------------
    # VarList helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_varref_payload(value: Any) -> bool:
        return isinstance(value, dict) and bool(value.get("__varref__"))

    @staticmethod
    def _varlist_zero(dtype_name: str) -> Any:
        float_dtypes = {
            "float32", "float16", "float", "bfloat16",
            "float8_e4m3fn", "float8_e5m2",
        }
        return 0.0 if dtype_name in float_dtypes else 0

    def _handle_create_varlist(self, args: Dict[str, Any], var_values: Dict[str, Any]) -> None:
        name = str(args.get("name", ""))
        if not name:
            raise ValueError("create_varlist requires a name")
        length = int(self._resolve_value(args.get("length", 0), var_values))
        if length <= 0:
            raise ValueError("create_varlist requires length > 0, got " + str(length))
        dtype_name = str(args.get("dtype", "int32"))
        var_values[name] = [self._varlist_zero(dtype_name)] * length

    def _resolve_varref(self, payload: Dict[str, Any], var_values: Dict[str, Any]) -> Tuple[List[Any], int, str]:
        parent = str(payload.get("parent", ""))
        if not parent:
            raise ValueError("varref payload missing parent")
        arr = var_values.get(parent)
        if not isinstance(arr, list):
            raise RuntimeError(
                "varlist " + repr(parent) + " is not initialized in the simulator"
            )
        index_payload = payload.get("index", 0)
        if isinstance(index_payload, int):
            index = int(index_payload)
        else:
            resolved = self._resolve_value(index_payload, var_values)
            if isinstance(resolved, (int, float)):
                index = int(resolved)
            elif isinstance(resolved, str):
                index = int(self._eval_numeric_expr(resolved))
            else:
                raise TypeError(
                    "varref index does not resolve to a number: " + repr(index_payload)
                )
        if index < 0 or index >= len(arr):
            raise IndexError(
                "varlist " + repr(parent) + " index " + str(index)
                + " out of range [0, " + str(len(arr)) + ")"
            )
        return arr, index, parent

    def _store_var_value(self, dst_arg: Any, value: Any, var_values: Dict[str, Any]) -> None:
        if self._is_varref_payload(dst_arg):
            arr, index, _ = self._resolve_varref(dst_arg, var_values)
            arr[index] = value
            return
        var_values[str(dst_arg)] = value

    def _load_var_value(self, dst_arg: Any, var_values: Dict[str, Any], default: Any = 0) -> Any:
        if self._is_varref_payload(dst_arg):
            arr, index, _ = self._resolve_varref(dst_arg, var_values)
            return arr[index]
        key = str(dst_arg)
        return var_values.get(key, default)

    # ------------------------------------------------------------------
    # Runtime tensor aliasing (get_buf, reinterpret, slice_tensor)
    # ------------------------------------------------------------------

    def _handle_get_buf(self, inst: ControlInstruction) -> None:
        args = inst.args
        view_name = str(args.get("view_name", ""))
        slot_names = args.get("slot_names", [])
        if not view_name:
            raise ValueError("get_buf requires view_name")
        if not isinstance(slot_names, list) or not slot_names:
            raise ValueError("get_buf requires a non-empty slot_names list")
        idx = int(self._resolve_value(args.get("index", 0), self._vars))
        # get_buf intentionally wraps the requested slot index so rotating buffer
        # users can address slots with monotonically increasing counters.
        resolved_slot = slot_names[idx % len(slot_names)]
        if resolved_slot in self.tensor_name_map:
            resolved_slot = self.tensor_name_map[resolved_slot]
        self._vars[view_name] = resolved_slot

    def _handle_slice_gm_tensor(self, inst: ControlInstruction) -> None:
        args = inst.args
        view_name = str(args.get("view_name", ""))
        source_name = str(args.get("source_name", ""))
        ndim = int(self._resolve_value(args.get("ndim", 0), self._vars))
        if not view_name or not source_name:
            raise ValueError("slice_gm_tensor requires view_name and source_name")
        if ndim <= 0:
            raise ValueError("slice_gm_tensor requires ndim > 0")
        resolved_source = self._resolve_value(source_name, self._vars)
        if not isinstance(resolved_source, str):
            raise KeyError("slice_gm_tensor source alias did not resolve to a tensor name: " + source_name)
        source_name = resolved_source
        if not self.memory_store.contains(source_name):
            raise KeyError("slice_gm_tensor source tensor not found: " + source_name)
        offsets = []
        src_dims = []
        spans = []
        for i in range(ndim):
            offsets.append(int(self._resolve_value(args.get("offset_" + str(i), 0), self._vars)))
            src_dims.append(int(self._resolve_value(args.get("src_dim_" + str(i), 1), self._vars)))
            spans.append(int(self._resolve_value(args.get("span_" + str(i), 1), self._vars)))
        for i, (offset, src_dim, span) in enumerate(zip(offsets, src_dims, spans)):
            if src_dim < 0:
                raise RuntimeError(
                    "slice_gm_tensor dim %d is negative: src_dim=%d" % (i, src_dim)
                )
            if span < 0:
                raise RuntimeError(
                    "slice_gm_tensor dim %d has negative span: span=%d" % (i, span)
                )
            if offset < 0 or offset > src_dim or offset + span > src_dim:
                raise RuntimeError(
                    "slice_gm_tensor dim %d out of bounds: offset=%d, span=%d, src_dim=%d"
                    % (i, offset, span, src_dim)
                )
        flat_offset = 0
        for i in range(ndim):
            stride = 1
            for j in range(i + 1, ndim):
                stride *= src_dims[j]
            flat_offset += offsets[i] * stride
        if any(sp <= 0 for sp in spans):
            view_numel = 0
        else:
            view_numel = 1
            for i in range(ndim):
                stride = 1
                for j in range(i + 1, ndim):
                    stride *= src_dims[j]
                view_numel += (spans[i] - 1) * stride
        parent = self.memory_store.tensor(source_name).reshape(-1)
        end = flat_offset + view_numel
        if flat_offset < 0 or end > parent.numel():
            raise RuntimeError(
                "slice_gm_tensor footprint exceeds tensor storage: %s offset=%d, footprint=%d, storage=%d"
                % (source_name, flat_offset, view_numel, parent.numel())
            )
        scoped_view_name = self.tensor_name_map.get(view_name, view_name)
        snapshot_name = (
            scoped_view_name
            + "@"
            + source_name
            + ":"
            + str(flat_offset)
            + ":offsets="
            + ",".join(str(v) for v in offsets)
            + ":dims="
            + ",".join(str(v) for v in src_dims)
            + ":spans="
            + ",".join(str(v) for v in spans)
        )
        view = parent[flat_offset:end]
        logical_offset = int(self._logical_offset_bytes(source_name) or 0) + flat_offset * int(view.element_size())
        self._register_physical_view(
            snapshot_name,
            source_name,
            view,
            logical_offset=logical_offset,
            byte_offset=flat_offset * int(view.element_size()),
            tags=("runtime_view", "gm_slice"),
        )
        self._vars[view_name] = snapshot_name

    def _handle_get_gm_tensor_list_item(self, inst: ControlInstruction) -> None:
        args = inst.args
        view_name = str(args.get("view_name", ""))
        item_names = args.get("item_names", [])
        if not view_name:
            raise ValueError("get_gm_tensor_list_item requires view_name")
        if not isinstance(item_names, list) or not item_names:
            raise ValueError("get_gm_tensor_list_item requires a non-empty item_names list")
        index = int(self._resolve_value(args.get("index", 0), self._vars))
        if index < 0 or index >= len(item_names):
            raise IndexError(
                "TensorList index out of range: "
                + str(index)
                + " not in [0, "
                + str(len(item_names))
                + ")"
            )
        item_name = str(item_names[index])
        if item_name in self.tensor_name_map:
            item_name = self.tensor_name_map[item_name]
        if not self.memory_store.contains(item_name):
            list_name = str(args.get("list_name", ""))
            raise KeyError(
                "TensorList item tensor not found: " + item_name + (" from " + list_name if list_name else "")
            )
        scoped_view_name = self.tensor_name_map.get(view_name, view_name)
        self.memory_store.register_view(scoped_view_name, self.memory_store.tensor(item_name))
        self._vars[view_name] = item_name

    def _handle_reshape_gm_tensor(self, inst: ControlInstruction) -> None:
        args = inst.args
        view_name = str(args.get("view_name", ""))
        source_name = str(args.get("source_name", ""))
        ndim = int(self._resolve_value(args.get("ndim", 0), self._vars))
        if not view_name or not source_name:
            raise ValueError("reshape_gm_tensor requires view_name and source_name")
        if ndim <= 0:
            raise ValueError("reshape_gm_tensor requires ndim > 0")
        resolved_source = self._resolve_value(source_name, self._vars)
        if not isinstance(resolved_source, str):
            raise KeyError("reshape_gm_tensor source alias did not resolve to a tensor name: " + source_name)
        source_name = resolved_source
        if not self.memory_store.contains(source_name):
            raise KeyError("reshape_gm_tensor source tensor not found: " + source_name)

        shape = tuple(
            int(self._resolve_value(args.get("shape_" + str(dim_idx), 0), self._vars))
            for dim_idx in range(ndim)
        )
        if any(dim < 0 for dim in shape):
            raise RuntimeError("reshape_gm_tensor shape must be non-negative: " + repr(shape))
        source = self.memory_store.tensor(source_name)
        expected_numel = 1
        for dim in shape:
            expected_numel *= dim
        if expected_numel != int(source.numel()):
            raise RuntimeError(
                "reshape_gm_tensor requires same numel: source=%d, shape=%s"
                % (int(source.numel()), repr(shape))
            )
        view = source.reshape(shape)
        scoped_view_name = self.tensor_name_map.get(view_name, view_name)
        snapshot_name = scoped_view_name + "@" + source_name + ":reshape=" + "x".join(str(dim) for dim in shape)
        self._register_physical_view(
            snapshot_name,
            source_name,
            view,
            logical_offset=self._logical_offset_bytes(source_name),
            tags=("runtime_view", "gm_reshape"),
        )
        self._vars[view_name] = snapshot_name

    def _handle_reinterpret(self, inst: ControlInstruction) -> None:
        args = inst.args
        view_name = str(args.get("view_name", args.get("dst", args.get("out", ""))))
        source_name = str(args.get("source_name", args.get("src", "")))
        if not view_name or not source_name:
            raise ValueError("reinterpret requires view_name and source_name")
        resolved = self._resolve_value(source_name, self._vars)
        if not isinstance(resolved, str):
            raise KeyError("reinterpret source alias did not resolve to a tensor name: " + source_name)
        if not self.memory_store.contains(resolved):
            raise KeyError("reinterpret source tensor not found: " + resolved)

        specs = getattr(self.memory_store, "specs", {})
        spec = specs.get(view_name) if isinstance(specs, dict) else None
        if spec is None:
            self._vars[view_name] = resolved
            return

        from .memory import normalize_dtype, torch_dtype

        source_alias = self._memory_alias(resolved)
        if source_alias is None:
            raise KeyError("reinterpret source tensor not found: " + str(resolved))
        source = self._alias_effective_tensor(source_alias)
        source_logical_offset = source_alias.logical_offset_bytes
        if source_logical_offset is None:
            source_logical_offset = int(source_alias.byte_offset)
        dst_dtype = normalize_dtype(spec.dtype)
        if dst_dtype == "int4":
            scoped_view_name = self.tensor_name_map.get(view_name, view_name)
            snapshot_name = scoped_view_name + "@" + str(resolved) + ":int4"
            self._register_physical_view(
                snapshot_name,
                str(resolved),
                source,
                logical_offset=source_logical_offset,
                physical_tensor=source,
                tags=("runtime_view", "reinterpret", "int4"),
            )
            self._vars[view_name] = snapshot_name
            return
        if dst_dtype in ("fp4_e2m1", "fp4_e1m2"):
            scoped_view_name = self.tensor_name_map.get(view_name, view_name)
            axis = int(args.get("packed_view_axis", 1) or 1)
            snapshot_name = scoped_view_name + "@" + str(resolved) + ":" + dst_dtype + ":axis" + str(axis)
            self._register_physical_view(
                snapshot_name,
                str(resolved),
                source,
                logical_offset=source_logical_offset,
                physical_tensor=source,
                tags=("runtime_view", "reinterpret", dst_dtype),
            )
            self._vars[view_name] = snapshot_name
            return
        if dst_dtype == "hif8":
            scoped_view_name = self.tensor_name_map.get(view_name, view_name)
            elem = int(source.element_size())
            storage_elems = int(source.untyped_storage().nbytes()) // elem
            avail = storage_elems - int(source.storage_offset())
            flat = source.as_strided((avail,), (1,), storage_offset=int(source.storage_offset()))
            raw = flat.view(torch_dtype("uint8"))

            offset = int(getattr(spec, "storage_offset", 0))
            vshape = tuple(getattr(spec, "view_shape", ()) or getattr(spec, "shape", ()))
            if getattr(spec, "view_strides", ()):
                view = raw.as_strided(vshape, tuple(spec.view_strides), storage_offset=offset)
            else:
                vnumel = 1
                for dim in vshape:
                    vnumel *= int(dim)
                view = raw.narrow(0, offset, vnumel)
                if vshape:
                    view = view.view(vshape)
            snapshot_name = scoped_view_name + "@" + str(resolved) + ":hif8"
            logical_offset = int(source_logical_offset or 0) + offset * dtype_size(dst_dtype)
            self._register_physical_view(
                snapshot_name,
                str(resolved),
                view,
                logical_offset=logical_offset,
                physical_tensor=view,
                tags=("runtime_view", "reinterpret", "hif8"),
            )
            self._vars[view_name] = snapshot_name
            return

        elem = int(source.element_size())
        storage_elems = int(source.untyped_storage().nbytes()) // elem
        avail = storage_elems - int(source.storage_offset())
        flat = source.as_strided((avail,), (1,), storage_offset=int(source.storage_offset()))

        src_dtype = normalize_dtype(str(getattr(source, "dtype", "")))
        if src_dtype != dst_dtype:
            flat = flat.view(torch_dtype(dst_dtype))

        offset = int(getattr(spec, "storage_offset", 0))
        vshape = tuple(getattr(spec, "view_shape", ()) or getattr(spec, "shape", ()))
        if getattr(spec, "view_strides", ()):
            view = flat.as_strided(vshape, tuple(spec.view_strides), storage_offset=offset)
        else:
            vnumel = 1
            for dim in vshape:
                vnumel *= int(dim)
            view = flat.narrow(0, offset, vnumel)
            if vshape:
                view = view.view(vshape)

        scoped_view_name = self.tensor_name_map.get(view_name, view_name)
        snapshot_name = (
            scoped_view_name
            + "@"
            + str(resolved)
            + ":"
            + dst_dtype
        )
        logical_offset = int(source_logical_offset or 0) + offset * dtype_size(dst_dtype)
        self._register_physical_view(
            snapshot_name,
            str(resolved),
            view,
            logical_offset=logical_offset,
            physical_tensor=view,
            tags=("runtime_view", "reinterpret", dst_dtype),
        )
        self._vars[view_name] = snapshot_name

    def _handle_slice_tensor(self, inst: ControlInstruction) -> None:
        args = inst.args
        view_name = str(args.get("view_name", args.get("out", "")))
        source_name = str(args.get("source_name", args.get("src", "")))
        if not view_name or not source_name:
            raise ValueError("slice_tensor requires view_name and source_name")
        resolved = self._resolve_value(source_name, self._vars)
        if not isinstance(resolved, str):
            raise KeyError("slice_tensor source alias did not resolve to a tensor name: " + source_name)
        if not self.memory_store.contains(resolved):
            raise KeyError("slice_tensor source tensor not found: " + resolved)
        specs = getattr(self.memory_store, "specs", {})
        spec = specs.get(resolved) if isinstance(specs, dict) else None
        role = str(getattr(spec, "role", "")).lower()
        if not role:
            # `resolved` can itself be a runtime view -- a DBuff slot, say --
            # and those never get a spec entry, so the spec lookup above comes
            # back empty and a packed L1 slice would fall through to the
            # narrowing branch below.  Narrowing loses the backing storage that
            # l1_to_l0 addresses with absolute row/col offsets, so a column
            # slice of a slot reads as "footprint exceeds tensor storage".
            # The alias carries the role of the storage behind the view.
            alias = self._memory_alias(resolved)
            role = str(getattr(alias, "role", "") or "").lower()
        tensor = self.memory_store.tensor(resolved)
        ndim = int(args.get("ndim", 2))
        offsets = [self._resolve_int(args.get("offset_" + str(i), 0)) for i in range(ndim)]
        src_dims = [self._resolve_int(args.get("src_dim_" + str(i), 0)) for i in range(ndim)]
        spans = [self._resolve_int(args.get("span_" + str(i), 0)) for i in range(ndim)]
        steps = [self._resolve_int(args.get("step_" + str(i), 1)) for i in range(ndim)]
        if ndim != 2:
            raise ValueError("slice_tensor only supports 2D local tensors")
        if any(step != 1 for step in steps):
            raise ValueError("slice_tensor only supports step=1")
        if tensor.dim() == 1 and all(dim > 0 for dim in src_dims):
            tensor = tensor.reshape(src_dims)
        row0, col0 = offsets
        rows, cols = spans
        scoped_view_name = self.tensor_name_map.get(view_name, view_name)
        # Local slices may be reused across loop iterations while async pipe tasks
        # still hold the old view name. Keep each resolved source+slice mapping
        # distinct so later slice_tensor calls do not retarget an in-flight task.
        snapshot_name = (
            scoped_view_name
            + "@"
            + str(resolved)
            + ":"
            + str(row0)
            + ","
            + str(col0)
            + ":"
            + str(rows)
            + ","
            + str(cols)
        )
        resolved_text = str(resolved)
        if role in {"l1", "l0a", "l0b", "l0c"}:
            if row0 == 0 and col0 == 0 and rows == src_dims[0] and cols == src_dims[1]:
                self._vars[view_name] = resolved
                return
            dtype_name = normalize_dtype(str(getattr(tensor, "dtype", "")))
            elem = dtype_size(dtype_name)
            from easyasc import globvars
            device_type = str(getattr(globvars, "device_type", "")).lower()
            if role == "l1" and is_c220_family(device_type) and dtype_name == "float32":
                physical_offset = row0 * src_dims[1] + col0 * 16
            else:
                c0 = 16 if role == "l0c" else 32 // elem
                physical_offset = row0 * c0 + col0 * src_dims[0]
            flat = tensor.reshape(-1)
            if physical_offset < 0 or physical_offset > flat.numel():
                if not callable(getattr(self.memory_store, "logical_offset_bytes", None)):
                    self._vars[view_name] = resolved
                    return
                raise RuntimeError(
                    "slice_tensor local packed offset exceeds tensor storage: %s offset=%d storage=%d"
                    % (resolved, physical_offset, flat.numel())
                )
            # Keep packed local tensors backed by the full storage. The snapshot
            # name carries the logical window, and individual datamove ops decide
            # whether their row/col arguments are absolute or relative.
            view = tensor
            source_offset = int(self._logical_offset_bytes(resolved) or 0)
            logical_offset = source_offset + physical_offset * elem
            self._register_physical_view(
                snapshot_name,
                str(resolved),
                view,
                logical_offset=logical_offset,
                byte_offset=physical_offset * elem,
                tags=("runtime_view", "slice_tensor", "packed_local"),
            )
            self._vars[view_name] = snapshot_name
            return
        elif ":fp4_e2m1" in resolved_text or ":fp4_e1m2" in resolved_text or ":hif8" in resolved_text:
            # Packed/byte-carrier compute views keep the carrier whole; their
            # l1_to_l0 path consumes the logical window metadata from args.
            view = tensor
        else:
            view = tensor[row0:row0 + rows, col0:col0 + cols]
        source_offset = int(self._logical_offset_bytes(resolved) or 0)
        logical_offset = source_offset
        if hasattr(view, "storage_offset") and hasattr(tensor, "storage_offset"):
            elem = int(view.element_size())
            rel = (int(view.storage_offset()) - int(tensor.storage_offset())) * elem
            logical_offset = source_offset + rel
        rel_bytes = 0
        if hasattr(view, "storage_offset") and hasattr(tensor, "storage_offset"):
            rel_bytes = (int(view.storage_offset()) - int(tensor.storage_offset())) * int(view.element_size())
        self._register_physical_view(
            snapshot_name,
            str(resolved),
            view,
            logical_offset=logical_offset,
            byte_offset=rel_bytes,
            tags=("runtime_view", "slice_tensor"),
        )
        self._vars[view_name] = snapshot_name

    # ------------------------------------------------------------------
    # GetValueFrom / SetValueTo
    # ------------------------------------------------------------------

    @staticmethod
    def _cast_scalar_value(value: Any, dtype: Any) -> Any:
        dtype_name = str(dtype or "")
        if dtype_name in ("int", "int32", "int64", "int16", "int8", "uint8", "uint16", "uint32", "uint64"):
            return int(value)
        if dtype_name in ("float", "float32", "float16", "bfloat16", "half"):
            return float(value)
        if dtype_name == "bool":
            return bool(value)
        return value

    def _warn_unpublished_vf_store(self, name: str, view: Any) -> None:
        """Flag a scalar read of UB a ``@vf()`` region wrote but never published.

        ``PipeBarrier<PIPE_ALL>`` drains the vector pipe but not the VF store
        buffer towards the scalar unit -- that needs ``mem_bar(VST_LD)``, i.e.
        ``vf_barrier(VfPipe.STORE, VfPipe.SCALAR_LOAD)``.  The value simulator
        executes VF stores synchronously and would happily return the fresh
        value, so without this check the mismatch only shows up on hardware,
        as a data-dependent trickle of stale reads that grows with the number
        of stores still in flight.
        """
        import warnings

        from .pipe_micro import VfBarrierWarning

        pending = getattr(self.memory_store, "vf_unpublished_scalar_ranges", None)
        if not pending:
            return
        try:
            sid = int(view.untyped_storage().data_ptr())
            lo = int(view.data_ptr())
            hi = lo + int(view.element_size())
        except Exception:
            return
        if not any(p[0] == sid and lo < p[2] and p[1] < hi for p in pending):
            return
        warnings.warn(
            "scalar GetValueFrom on '" + name + "' reads local memory a @vf() "
            "region stored without vf_barrier(VfPipe.STORE, "
            "VfPipe.SCALAR_LOAD); PipeBarrier<PIPE_ALL> does not publish VF "
            "stores to the scalar unit, so the board reads stale data here",
            VfBarrierWarning,
            stacklevel=3,
        )

    def _handle_get_value_from(self, inst: ControlInstruction) -> None:
        import torch
        args = inst.args
        var_name = str(args.get("dst", args.get("out", "")))
        tensor_name = str(args.get("src", ""))
        if not var_name or not tensor_name:
            return
        resolved_name = self._resolve_value(tensor_name, self._vars)
        if isinstance(resolved_name, str) and self.memory_store.contains(resolved_name):
            # These helpers mirror lowered `tensor_expr.GetValue(0)` /
            # `tensor_expr.SetValue(0, ...)`: they operate on the alias base,
            # not on any separately flattened logical densification path.
            alias = self._memory_alias(resolved_name)
            if alias is None:
                return
            head = self._alias_scalar_head(alias)
            if int(head.numel()) == 0:
                raise RuntimeError("GetValueFrom source view is empty: " + resolved_name)
            self._warn_unpublished_vf_store(resolved_name, head)
            value = head.reshape(-1)[0].item()
            self._vars[var_name] = self._cast_scalar_value(value, args.get("dtype", ""))

    def _handle_set_value_to(self, inst: ControlInstruction) -> None:
        import torch
        args = inst.args
        tensor_name = str(args.get("src", ""))
        var_name = str(args.get("dst", ""))
        if not var_name or not tensor_name:
            return
        resolved_name = self._resolve_value(tensor_name, self._vars)
        value = self._cast_scalar_value(self._resolve_value(var_name, self._vars), args.get("dtype", ""))
        if isinstance(resolved_name, str) and self.memory_store.contains(resolved_name):
            alias = self._memory_alias(resolved_name)
            if alias is None:
                return
            tensor = self._alias_scalar_head(alias)
            if int(tensor.numel()) == 0:
                raise RuntimeError("SetValueTo destination view is empty: " + resolved_name)
            if isinstance(value, (int, float)):
                tensor.reshape(-1)[0] = torch.tensor(value, dtype=tensor.dtype, device=tensor.device)

    # ------------------------------------------------------------------
    # sim_dump_tensor / sim_print
    # ------------------------------------------------------------------

    def _handle_sim_dump_tensor(self, inst: ControlInstruction) -> None:
        import torch
        self._handle_bar_all()
        args = inst.args
        tensor_name = self._resolve_value(args.get("tensor", args.get("tensor_name", "")), self._vars)
        filename = str(args.get("filename", ""))
        if not isinstance(tensor_name, str) or not tensor_name or not filename:
            return
        if self.memory_store.contains(tensor_name):
            tensor = self.memory_store.tensor(tensor_name)
            torch.save(tensor.detach().clone(), filename)

    def _handle_sim_print(self, inst: ControlInstruction) -> None:
        self._handle_bar_all()
        raw_payload = inst.args.get("payload", [])
        if not isinstance(raw_payload, list):
            return
        payload: List[Dict[str, Any]] = []
        for item in raw_payload:
            if not isinstance(item, dict):
                payload.append({"kind": "literal", "value": item})
                continue
            kind = str(item.get("kind", "literal"))
            value = item.get("value", "")
            if kind in ("gm_tensor", "local_tensor", "var", "expr"):
                value = self._resolve_value(value, self._vars)
            payload.append({"kind": kind, "value": value})
        print(
            "[sim_print][core=%d][lane=%s][pipe=S] %s"
            % (self.core_idx, self.lane_name, PipeBase._render_sim_print_payload(self.memory_store, payload)),
            file=sys.stderr,
            flush=True,
        )

    # ------------------------------------------------------------------
    # Argument resolution
    # ------------------------------------------------------------------

    def _resolve_args(self, args: Dict[str, Any], var_values: Dict[str, Any]) -> Dict[str, Any]:
        return {k: self._resolve_value(v, var_values) for k, v in args.items()}

    def _resolve_value(self, value: Any, var_values: Dict[str, Any]) -> Any:
        if self._is_varref_payload(value):
            arr, index, _ = self._resolve_varref(value, var_values)
            return arr[index]
        # Instruction arguments can contain runtime expressions inside fixed
        # metadata containers.  ND DMA is the main example: each loop stride,
        # size, and pad list is emitted as a tuple.  Resolve those members at
        # dispatch time just like top-level scalar arguments so pipe workers
        # never receive unresolved variable names.
        if isinstance(value, tuple):
            return tuple(self._resolve_value(item, var_values) for item in value)
        if isinstance(value, list):
            return [self._resolve_value(item, var_values) for item in value]
        if isinstance(value, dict):
            return {
                key: self._resolve_value(item, var_values)
                for key, item in value.items()
            }
        if isinstance(value, str):
            if value in var_values:
                resolved = var_values[value]
                if isinstance(resolved, str) and resolved in self.tensor_name_map:
                    return self.tensor_name_map[resolved]
                return resolved
            if value in self.tensor_name_map:
                return self.tensor_name_map[value]
        return value

    def _resolve_int(self, value: Any) -> int:
        resolved = self._resolve_value(value, self._vars)
        if isinstance(resolved, (int, float)):
            return int(resolved)
        if isinstance(resolved, str):
            return int(self._eval_numeric_expr(resolved))
        raise TypeError("expected int, got: " + repr(value))

    def _resolve_bool(self, cond: Any) -> bool:
        if cond is None:
            raise ValueError("boolean condition is required")
        if isinstance(cond, bool):
            return cond
        if isinstance(cond, (int, float)):
            raise TypeError("boolean condition must not be a bare number: " + repr(cond))
        if isinstance(cond, str):
            resolved = self._resolve_value(cond, self._vars)
            if isinstance(resolved, bool):
                return resolved
            if isinstance(resolved, (int, float)):
                raise TypeError("boolean condition must not resolve to a bare number: " + repr(cond))
            return self._eval_cond_expr(cond)
        raise TypeError("cannot resolve boolean condition: " + repr(cond))

    _CMP_OPS = (
        ("==", lambda a, b: a == b), ("!=", lambda a, b: a != b),
        ("<=", lambda a, b: a <= b), (">=", lambda a, b: a >= b),
        ("<", lambda a, b: a < b), (">", lambda a, b: a > b),
    )

    def _require_vec_lane_scalar_op(self, op: str) -> None:
        if not self.lane_name.startswith("vec"):
            raise RuntimeError(op + " is only supported on vec lanes, current lane: " + self.lane_name)

    def _eval_cond_expr(self, expr: str) -> bool:
        e = expr.strip()
        while len(e) >= 2 and e[0] == "(" and e[-1] == ")":
            inner = e[1:-1]
            depth = 0
            valid = True
            for ch in inner:
                if ch == "(": depth += 1
                elif ch == ")": depth -= 1
                if depth < 0: valid = False; break
            if valid and depth == 0:
                e = inner.strip()
            else:
                break
        if not e:
            raise ValueError("cannot resolve boolean expression: " + repr(expr))
        or_parts = self._split_top(e, "||")
        if len(or_parts) > 1:
            return any(self._resolve_bool(p) for p in or_parts)
        and_parts = self._split_top(e, "&&")
        if len(and_parts) > 1:
            return all(self._resolve_bool(p) for p in and_parts)
        if e.startswith("!") and not e.startswith("!="):
            return not self._resolve_bool(e[1:].lstrip())
        for op, fn in self._CMP_OPS:
            pos = self._find_top(e, op)
            if pos >= 0:
                lhs = self._eval_numeric_expr(e[:pos].strip())
                rhs = self._eval_numeric_expr(e[pos + len(op):].strip())
                if isinstance(lhs, (int, float)) and isinstance(rhs, (int, float)):
                    return fn(lhs, rhs)
        resolved = self._resolve_value(e, self._vars)
        if isinstance(resolved, (int, float, bool)):
            return bool(resolved)
        raise ValueError("cannot resolve boolean expression: " + repr(expr))

    def _eval_numeric_expr(self, expr: Any) -> Any:
        if isinstance(expr, (int, float)):
            return expr
        if not isinstance(expr, str):
            resolved = self._resolve_value(expr, self._vars)
            if isinstance(resolved, (int, float)):
                return resolved
            raise ValueError("cannot resolve numeric expression: " + repr(expr))

        import ast
        import operator

        text = expr.strip()
        resolved = self._resolve_value(text, self._vars)
        if isinstance(resolved, (int, float)):
            return resolved
        try:
            return int(text)
        except ValueError:
            try:
                return float(text)
            except ValueError:
                pass

        bin_ops = {
            ast.Add: operator.add,
            ast.Sub: operator.sub,
            ast.Mult: operator.mul,
            ast.Div: operator.truediv,
            ast.FloorDiv: operator.floordiv,
            ast.Mod: operator.mod,
        }
        unary_ops = {
            ast.UAdd: operator.pos,
            ast.USub: operator.neg,
        }

        def eval_node(node):
            if isinstance(node, ast.Expression):
                return eval_node(node.body)
            if isinstance(node, ast.Constant):
                if isinstance(node.value, (int, float)):
                    return node.value
                raise ValueError("non-numeric constant in expression: " + repr(expr))
            if isinstance(node, ast.Name):
                value = self._resolve_value(node.id, self._vars)
                if isinstance(value, (int, float)):
                    return value
                raise ValueError("unknown numeric symbol in expression: " + node.id)
            if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name):
                arr = self._vars.get(node.value.id)
                if isinstance(arr, list):
                    index_node = node.slice.value if isinstance(node.slice, ast.Index) else node.slice
                    index = int(eval_node(index_node))
                    if index < 0 or index >= len(arr):
                        raise IndexError(
                            "varlist " + repr(node.value.id) + " index " + str(index)
                            + " out of range [0, " + str(len(arr)) + ")"
                        )
                    slot = arr[index]
                    if isinstance(slot, (int, float)):
                        return slot
                raise ValueError("unsupported subscript expression: " + repr(expr))
            if isinstance(node, ast.UnaryOp) and type(node.op) in unary_ops:
                return unary_ops[type(node.op)](eval_node(node.operand))
            if isinstance(node, ast.BinOp) and type(node.op) in bin_ops:
                return bin_ops[type(node.op)](eval_node(node.left), eval_node(node.right))
            raise ValueError("unsupported numeric expression: " + repr(expr))

        try:
            tree = ast.parse(text, mode="eval")
        except SyntaxError as exc:
            raise ValueError("cannot resolve numeric expression: " + repr(expr)) from exc
        return eval_node(tree)

    @staticmethod
    def _split_top(expr: str, sep: str) -> List[str]:
        parts: List[str] = []
        depth = 0
        start = 0
        i = 0
        while i < len(expr):
            if expr[i] == "(": depth += 1
            elif expr[i] == ")": depth -= 1
            elif depth == 0 and expr[i:i+len(sep)] == sep:
                parts.append(expr[start:i].strip())
                start = i + len(sep)
                i += len(sep)
                continue
            i += 1
        parts.append(expr[start:].strip())
        return parts

    @staticmethod
    def _find_top(expr: str, op: str) -> int:
        depth = 0
        i = 0
        while i < len(expr):
            if expr[i] == "(": depth += 1
            elif expr[i] == ")": depth -= 1
            elif depth == 0 and expr[i:i+len(op)] == op:
                return i
            i += 1
        return -1


# ------------------------------------------------------------------
# Op classification
# ------------------------------------------------------------------

_CROSS_LANE_READY = frozenset(["cube_ready", "vec_ready"])
_CROSS_LANE_WAIT = frozenset(["wait_vec", "wait_cube"])
_INTRACORE_ALLVEC_READY = frozenset(["intracore_allvec_ready"])
_INTRACORE_ALLVEC_WAIT = frozenset(["intracore_allvec_wait"])
_COLLECTIVE_READY = frozenset(["allcube_ready", "allvec_ready"])
_COLLECTIVE_WAIT = frozenset(["allcube_wait", "allvec_wait"])
_EVENT_CREATE = frozenset(["create_sevent", "create_devent", "create_tevent", "create_qevent"])

_VAR_OPS = frozenset([
    "create_var", "create_varlist",
    "var_assign", "tensorlist_size", "tensorlist_item_numel",
    "var_add", "var_sub", "var_mul", "var_div", "var_mod",
    "CeilDiv", "Min", "Max",
    "Align8", "Align16", "Align32", "Align64", "Align128", "Align256",
    "scalar_sqrt", "scalar_abs",
    "GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx", "GetSubBlockNum",
])

_CONTROL_FLOW_OPS = frozenset([
    "start_if", "start_elif", "start_else", "end_if",
    "start_loop", "start_micro_loop", "end_loop", "break_loop", "continue_loop",
])

_SCOPE_OPS = frozenset([
    "enter_vec_scope", "end_vec_scope", "enter_cube_scope", "end_cube_scope",
])
