from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Dict, Optional, Tuple

import torch

from ..memory import SharedMemoryStore
from ..physical_alias import PhysicalAlias
from ..program import PipeTask


_NO_OVERHEAD_SYNC_OPS = frozenset([
    "event_wait",
    "event_set",
    "event_setall",
    "event_release",
    "allcube_wait",
    "allvec_wait",
    "allcube_ready",
    "allvec_ready",
    "intracore_allvec_wait",
    "intracore_allvec_ready",
    "wait_vec",
    "wait_cube",
    "vec_ready",
    "cube_ready",
])


def _ceil_div(value: int, divisor: int) -> int:
    if divisor <= 0:
        raise ValueError("divisor must be positive, got: " + str(divisor))
    if value <= 0:
        return 0
    return (int(value) + int(divisor) - 1) // int(divisor)


def _align_to(value: int, align: int) -> int:
    if align <= 0:
        raise ValueError("align must be positive, got: " + str(align))
    return ((int(value) + align - 1) // align) * align


def _span_for_strided_rows(rows: int, row_pitch: int, active_cols: int) -> int:
    if rows <= 0 or active_cols <= 0:
        return 0
    return (int(rows) - 1) * int(row_pitch) + int(active_cols)


def _span_for_repeated_region(count: int, step: int, payload: int) -> int:
    if count <= 0 or payload <= 0:
        return 0
    return (int(count) - 1) * int(step) + int(payload)


def _resolve_int(value: Any, default: int = 0) -> int:
    if value is None:
        return int(default)
    if isinstance(value, bool):
        return int(value)
    if not isinstance(value, (int, float)):
        raise TypeError("expected int/float-compatible value, got: " + str(type(value)))
    return int(value)


def _tensor_ref(tensor_store: SharedMemoryStore, ref: Any) -> Tuple[Optional[str], Optional[torch.Tensor]]:
    if tensor_store is None:
        return None, None
    if isinstance(ref, str) and tensor_store.contains(ref):
        tensor = tensor_store.tensor(ref)
        if isinstance(tensor, torch.Tensor):
            return ref, tensor
    return None, None


def _tensor_bytes(tensor: Optional[torch.Tensor]) -> int:
    if not isinstance(tensor, torch.Tensor):
        return 0
    return int(tensor.numel()) * int(tensor.element_size())


def _matmul_operand_bits(task: PipeTask, tensor_store: Optional[SharedMemoryStore]) -> int:
    if tensor_store is None:
        return 0
    _, src_a = _tensor_ref(tensor_store, task.args.get("src_a"))
    _, src_b = _tensor_ref(tensor_store, task.args.get("src_b"))
    sizes = [
        int(tensor.element_size())
        for tensor in (src_a, src_b)
        if isinstance(tensor, torch.Tensor)
    ]
    if not sizes:
        return 0
    return max(sizes) * 8


def _matmul_macs_per_cycle(bits: int, model: A5CycleModel) -> Tuple[int, str]:
    if bits <= 0:
        return model.mmad_macs_per_cycle, "mmad_macs_per_cycle"
    if bits <= 8:
        return model.matmul_macs_per_cycle_8bit, "matmul_macs_per_cycle_8bit"
    if bits <= 16:
        return model.matmul_macs_per_cycle_16bit, "matmul_macs_per_cycle_16bit"
    if bits <= 32:
        return model.matmul_macs_per_cycle_32bit, "matmul_macs_per_cycle_32bit"
    return model.mmad_macs_per_cycle, "mmad_macs_per_cycle"


def _matmul_c0_from_operand_bits(bits: int) -> int:
    if bits <= 0:
        return 16
    return max(1, 256 // int(bits))


def _max_tensor_bytes(task: PipeTask, tensor_store: SharedMemoryStore) -> int:
    names = ("dst", "src", "src1", "src2", "selmask", "offset", "idx")
    max_bytes = 0
    for name in names:
        _, tensor = _tensor_ref(tensor_store, task.args.get(name))
        max_bytes = max(max_bytes, _tensor_bytes(tensor))
    return max_bytes


@dataclass(frozen=True)
class A5CycleModel:
    profile_name: str
    time_domain: str
    gm_bandwidth_bytes_per_cycle: int
    l0_bandwidth_bytes_per_cycle: int
    ub_to_l1_bandwidth_bytes_per_cycle: int
    ub_to_l1_nd2nz_bandwidth_bytes_per_cycle: int
    l0c_to_ub_bandwidth_bytes_per_cycle: int
    l0c_to_gm_bandwidth_bytes_per_cycle: float
    l0c_to_l1_bandwidth_bytes_per_cycle: int
    set_constant_to_l1_bandwidth_bytes_per_cycle: float
    mmad_macs_per_cycle: float
    vpipe_bytes_per_instruction: int
    vpipe_default_instruction_cycles: int
    vpipe_instruction_cycles: Dict[str, int]
    sync_marker_cycles: int
    intra_core_sync_latency_cycles: int = 0
    vpipe_cycle_formulas: Dict[str, Dict[str, float]] = field(default_factory=dict)
    instruction_head_overhead_cycles: int = 10
    device_family: str = "a5"
    gm_to_l1_nd2nz_overhead_cycles: float = 0.0
    gm_to_l1_nd2nz_bandwidth_bytes_per_cycle: float = 0.0
    gm_to_ub_pad_overhead_cycles: float = 0.0
    gm_to_ub_pad_bandwidth_bytes_per_cycle: float = 0.0
    ub_to_gm_pad_overhead_cycles: float = 0.0
    ub_to_gm_pad_bandwidth_bytes_per_cycle: float = 0.0
    ub_to_ub_overhead_cycles: float = 0.0
    ub_to_ub_bandwidth_bytes_per_cycle: float = 0.0
    ub_to_ub_fixed_cycles: int = 0
    gather_scatter_elems_per_cycle: int = 0
    mergesort_cycles_per_element: int = 0
    set_constant_to_l1_overhead_cycles: float = 0.0
    l0c_to_gm_overhead_cycles: float = 0.0
    mmad_overhead_cycles: float = 0.0
    sort32_overhead_cycles: float = 0.0
    sort32_bandwidth_bytes_per_cycle: float = 0.0
    mergesort4_overhead_cycles: float = 0.0
    mergesort4_bandwidth_bytes_per_cycle: float = 0.0
    mergesort_2seq_overhead_cycles: float = 0.0
    mergesort_2seq_bandwidth_bytes_per_cycle: float = 0.0
    matmul_macs_per_cycle_32bit: float = 1024.0
    matmul_macs_per_cycle_16bit: float = 4096.0
    matmul_macs_per_cycle_8bit: float = 8192.0
    simt_cycles_per_instruction: int = 4
    # VF (call_micro) 4-pipe DAG scheduler parameters. When
    # vf_fixed_overhead_cycles > 0 the scheduled model is used instead of the
    # legacy serial per-instruction sum (see _estimate_call_micro).
    vf_fixed_overhead_cycles: float = 0.0
    vf_pipe_issue_interval: Dict[str, float] = field(default_factory=dict)
    vf_micro_latency: Dict[str, float] = field(default_factory=dict)
    vf_micro_default_latency: float = 6.0
    vf_su_serial_fraction: float = 1.0
    # EX-pipe issue interval scales with op latency (heavier vector ops occupy the
    # SIMD datapath longer; light ops dual-issue): II = max(floor, slope*lat + intercept).
    # Refit across 6 diverse cannsim kernels (softmax/pairpack/squeeze/half/half128/
    # e4m3/reduction) so it generalizes past the throughput-bound attention family.
    vf_ex_issue_slope: float = 0.0390
    vf_ex_issue_intercept: float = 0.5039
    vf_ex_issue_floor: float = 0.1
    # Per-op EX issue-interval OVERRIDES for ops whose real throughput does not follow the
    # latency->interval line. cannsim marginal A/B (one bench differs from another by exactly
    # one op) shows the line over-charges plain elementwise ALU (add/mul/max/cast dual-issue
    # cheaper) and under-charges the data-rearrange ops (RV_VSQZ squeeze / RV_VDINTLV
    # (de)interleave / RV_VPACK pack serialize on the vector unit). Keyed by opname; falls back
    # to the slope/intercept line for anything not listed. Measured 2026-07-02.
    vf_ex_interval_override: Dict[str, float] = field(default_factory=dict)
    # UB bank-conflict on an EXPLICIT strided reg_to_ub/ub_to_reg (micro_reg2ub /
    # micro_ub2reg): a power-of-two blk_stride aliases UB banks and raises the LD/ST issue
    # interval above the flat vf_pipe_issue_interval. Measured on cannsim (odd vs pow2 stride
    # sweep, load/store asymmetric). The contiguous `<<=` sugar (micro_ub2regcont /
    # micro_reg2ubcont) is a separate fast path and keeps the flat interval. See
    # _micro_bank_datamove_interval.
    vf_bank_conflict: bool = True
    vf_st_bank_base: float = 3.0            # micro_reg2ub interval at blk_stride<=1 (contiguous/odd)
    vf_st_bank_stride_penalty: float = 0.0  # store: odd stride>1 keeps the fast path
    vf_st_bank_per_way: float = 1.0
    vf_st_bank_banks: int = 8               # store conflict saturates at 8 ways
    vf_ld_bank_base: float = 3.5            # micro_ub2reg interval at blk_stride==1 (contiguous)
    vf_ld_bank_stride_penalty: float = 2.25 # load: any stride>1 loses the contiguous gather fast path
    vf_ld_bank_per_way: float = 2.0
    vf_ld_bank_banks: int = 4               # load conflict saturates at 4 ways
    # Bounded RAW-dependency critical-path term (grafted from the scoreboard branch): a
    # single-accumulator streaming loop (e.g. half128's 128-deep block_sum/block_max chains) is
    # latency-bound, not throughput-bound; real HW pipelines it partially. makespan =
    # max(throughput, max_op_lat, vf_crit_slack*crit_path). Calibrated to ~0.46 (chain
    # efficiency) on the one chain-bound kernel; stays below EX for the throughput-bound
    # majority so it lifts only genuine chains. dataclass default 0 (A5 json sets 0.46).
    vf_crit_slack: float = 0.0


@dataclass(frozen=True)
class CycleEstimate:
    cycles: int
    details: Dict[str, Any]


def _default_profile_path(device_type: str) -> Optional[str]:
    from ...device_profile import is_a5_family, is_c220_family

    if is_a5_family(device_type):
        return os.path.join(os.path.dirname(__file__), "a5_cycle_model.json")
    if is_c220_family(device_type):
        return os.path.join(os.path.dirname(__file__), "a2_cycle_model.json")
    return None


def _load_vpipe_cycle_formulas(raw: Any) -> Dict[str, Dict[str, float]]:
    formulas: Dict[str, Dict[str, float]] = {}
    if not isinstance(raw, dict):
        return formulas
    for key, value in raw.items():
        if not isinstance(value, dict):
            continue
        overhead = value.get("overhead_cycles", value.get("overhead", 0.0))
        bandwidth = value.get("bandwidth_bytes_per_cycle", value.get("bytes_per_cycle", 0.0))
        try:
            overhead_f = float(overhead)
            bandwidth_f = float(bandwidth)
        except (TypeError, ValueError):
            continue
        if bandwidth_f <= 0.0:
            continue
        formulas[str(key)] = {
            "overhead_cycles": overhead_f,
            "bandwidth_bytes_per_cycle": bandwidth_f,
        }
    return formulas


@lru_cache(maxsize=8)
def _load_cycle_model(path: str) -> A5CycleModel:
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    return A5CycleModel(
        profile_name=str(payload.get("profile_name", "a5_cycle_model")),
        time_domain=str(payload.get("time_domain", "cycle")),
        gm_bandwidth_bytes_per_cycle=int(payload.get("gm_bandwidth_bytes_per_cycle", 32)),
        gm_to_l1_nd2nz_overhead_cycles=float(payload.get("gm_to_l1_nd2nz_overhead_cycles", 0.0)),
        gm_to_l1_nd2nz_bandwidth_bytes_per_cycle=float(payload.get("gm_to_l1_nd2nz_bandwidth_bytes_per_cycle", 0.0)),
        gm_to_ub_pad_overhead_cycles=float(payload.get("gm_to_ub_pad_overhead_cycles", 0.0)),
        gm_to_ub_pad_bandwidth_bytes_per_cycle=float(payload.get("gm_to_ub_pad_bandwidth_bytes_per_cycle", 0.0)),
        ub_to_gm_pad_overhead_cycles=float(payload.get("ub_to_gm_pad_overhead_cycles", 0.0)),
        ub_to_gm_pad_bandwidth_bytes_per_cycle=float(payload.get("ub_to_gm_pad_bandwidth_bytes_per_cycle", 0.0)),
        l0_bandwidth_bytes_per_cycle=int(payload.get("l0_bandwidth_bytes_per_cycle", 128)),
        ub_to_l1_bandwidth_bytes_per_cycle=int(payload.get("ub_to_l1_bandwidth_bytes_per_cycle", 256)),
        ub_to_l1_nd2nz_bandwidth_bytes_per_cycle=int(
            payload.get(
                "ub_to_l1_nd2nz_bandwidth_bytes_per_cycle",
                payload.get("ub_to_l1_bandwidth_bytes_per_cycle", 256),
            )
        ),
        l0c_to_ub_bandwidth_bytes_per_cycle=int(payload.get("l0c_to_ub_bandwidth_bytes_per_cycle", 256)),
        l0c_to_gm_bandwidth_bytes_per_cycle=float(payload.get("l0c_to_gm_bandwidth_bytes_per_cycle", 128)),
        l0c_to_l1_bandwidth_bytes_per_cycle=int(payload.get("l0c_to_l1_bandwidth_bytes_per_cycle", 128)),
        set_constant_to_l1_bandwidth_bytes_per_cycle=float(payload.get("set_constant_to_l1_bandwidth_bytes_per_cycle", 32)),
        mmad_macs_per_cycle=float(payload.get("mmad_macs_per_cycle", 4096)),
        vpipe_bytes_per_instruction=int(payload.get("vpipe_bytes_per_instruction", 256)),
        vpipe_default_instruction_cycles=int(payload.get("vpipe_default_instruction_cycles", 1)),
        vpipe_instruction_cycles={str(k): int(v) for k, v in dict(payload.get("vpipe_instruction_cycles", {})).items()},
        vpipe_cycle_formulas=_load_vpipe_cycle_formulas(payload.get("vpipe_cycle_formulas", {})),
        sync_marker_cycles=int(payload.get("sync_marker_cycles", 1)),
        intra_core_sync_latency_cycles=max(0, int(payload.get("intra_core_sync_latency_cycles", 0))),
        instruction_head_overhead_cycles=max(0, int(payload.get("instruction_head_overhead_cycles", 10))),
        device_family=str(payload.get("device_family", "a5")),
        ub_to_ub_overhead_cycles=float(payload.get("ub_to_ub_overhead_cycles", 0.0)),
        ub_to_ub_bandwidth_bytes_per_cycle=float(payload.get("ub_to_ub_bandwidth_bytes_per_cycle", 0.0)),
        ub_to_ub_fixed_cycles=int(payload.get("ub_to_ub_fixed_cycles", 0)),
        gather_scatter_elems_per_cycle=int(payload.get("gather_scatter_elems_per_cycle", 0)),
        mergesort_cycles_per_element=int(payload.get("mergesort_cycles_per_element", 0)),
        set_constant_to_l1_overhead_cycles=float(payload.get("set_constant_to_l1_overhead_cycles", 0.0)),
        l0c_to_gm_overhead_cycles=float(payload.get("l0c_to_gm_overhead_cycles", 0.0)),
        mmad_overhead_cycles=float(payload.get("mmad_overhead_cycles", 0.0)),
        sort32_overhead_cycles=float(payload.get("sort32_overhead_cycles", 0.0)),
        sort32_bandwidth_bytes_per_cycle=float(payload.get("sort32_bandwidth_bytes_per_cycle", 0.0)),
        mergesort4_overhead_cycles=float(payload.get("mergesort4_overhead_cycles", 0.0)),
        mergesort4_bandwidth_bytes_per_cycle=float(payload.get("mergesort4_bandwidth_bytes_per_cycle", 0.0)),
        mergesort_2seq_overhead_cycles=float(payload.get("mergesort_2seq_overhead_cycles", 0.0)),
        mergesort_2seq_bandwidth_bytes_per_cycle=float(payload.get("mergesort_2seq_bandwidth_bytes_per_cycle", 0.0)),
        matmul_macs_per_cycle_32bit=float(payload.get("matmul_macs_per_cycle_32bit", 1024)),
        matmul_macs_per_cycle_16bit=float(payload.get("matmul_macs_per_cycle_16bit", payload.get("mmad_macs_per_cycle", 4096))),
        matmul_macs_per_cycle_8bit=float(payload.get("matmul_macs_per_cycle_8bit", 8192)),
        simt_cycles_per_instruction=max(1, int(payload.get("simt_cycles_per_instruction", 4))),
        vf_fixed_overhead_cycles=float(payload.get("vf_fixed_overhead_cycles", 0.0)),
        vf_pipe_issue_interval={str(k): float(v) for k, v in dict(payload.get("vf_pipe_issue_interval", {})).items()},
        vf_micro_latency={str(k): float(v) for k, v in dict(payload.get("vf_micro_latency", {})).items()},
        vf_micro_default_latency=float(payload.get("vf_micro_default_latency", 6.0)),
        vf_su_serial_fraction=float(payload.get("vf_su_serial_fraction", 1.0)),
        vf_ex_issue_slope=float(payload.get("vf_ex_issue_slope", 0.1878)),
        vf_ex_issue_intercept=float(payload.get("vf_ex_issue_intercept", -0.9729)),
        vf_ex_issue_floor=float(payload.get("vf_ex_issue_floor", 0.1)),
        vf_ex_interval_override={str(k): float(v) for k, v in dict(payload.get("vf_ex_interval_override", {})).items()},
        vf_bank_conflict=bool(payload.get("vf_bank_conflict", True)),
        vf_st_bank_base=max(0.0, float(payload.get("vf_st_bank_base", 3.0))),
        vf_st_bank_stride_penalty=max(0.0, float(payload.get("vf_st_bank_stride_penalty", 0.0))),
        vf_st_bank_per_way=max(0.0, float(payload.get("vf_st_bank_per_way", 1.0))),
        vf_st_bank_banks=max(1, int(payload.get("vf_st_bank_banks", 8))),
        vf_ld_bank_base=max(0.0, float(payload.get("vf_ld_bank_base", 3.5))),
        vf_ld_bank_stride_penalty=max(0.0, float(payload.get("vf_ld_bank_stride_penalty", 2.25))),
        vf_ld_bank_per_way=max(0.0, float(payload.get("vf_ld_bank_per_way", 2.0))),
        vf_ld_bank_banks=max(1, int(payload.get("vf_ld_bank_banks", 4))),
        vf_crit_slack=max(0.0, float(payload.get("vf_crit_slack", 0.0))),
    )


def load_cycle_model_for_device(device_type: str, profile_path: str = "") -> Optional[A5CycleModel]:
    chosen_path = profile_path or _default_profile_path(device_type)
    if not chosen_path:
        return None
    if not os.path.isfile(chosen_path):
        raise FileNotFoundError("cycle model profile not found: " + str(chosen_path))
    return _load_cycle_model(os.path.abspath(chosen_path))


def _cycles_from_bandwidth(bytes_count: int, bytes_per_cycle: int) -> int:
    if bytes_count <= 0:
        return 0
    return max(1, _ceil_div(bytes_count, bytes_per_cycle))


def _cycles_from_linear_model(metric_count: int, bandwidth: float, overhead: float = 0.0) -> int:
    if bandwidth <= 0.0:
        return 0
    modeled = max(0.0, float(overhead)) + max(0.0, float(metric_count)) / float(bandwidth)
    if modeled <= 0.0:
        return 0
    return max(1, int(modeled + 0.5))


def _cycles_from_measured_bandwidth(metric_count: int, bandwidth: float, overhead: float = 0.0) -> int:
    if overhead > 0.0:
        return _cycles_from_linear_model(metric_count, bandwidth, overhead)
    return _cycles_from_bandwidth(metric_count, max(1, int(bandwidth)))


def _estimate_sync_marker(model: A5CycleModel, no_instruction_overhead: bool = False) -> CycleEstimate:
    cycles = max(1, model.sync_marker_cycles)
    details = {"model_kind": "sync_marker", "modeled_cycles": cycles}
    if no_instruction_overhead:
        details["no_instruction_overhead"] = True
    return CycleEstimate(cycles, details)


def _estimate_gm_to_l1_nd2nz(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "gm_to_l1_nd2nz"})
    h = _resolve_int(task.args.get("M"))
    w = _resolve_int(task.args.get("N"))
    w_src = _resolve_int(task.args.get("N_src"))
    h_dst = _resolve_int(task.args.get("M_dst"), h)
    elem_size = int(dst.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    if task.opname == "gm_to_l1_dn2nz":
        # GM holds the transpose: w GM rows of stride w_src, h active elements each.
        src_bytes = _span_for_strided_rows(w, w_src, h) * int(src.element_size())
    else:
        src_bytes = _span_for_strided_rows(h, w_src, w) * int(src.element_size())
    dst_bytes = ((w + c0 - 1) // c0) * _align_to(h_dst, 16) * c0 * elem_size
    bandwidth = model.gm_to_l1_nd2nz_bandwidth_bytes_per_cycle or model.gm_bandwidth_bytes_per_cycle
    overhead = max(0.0, float(model.gm_to_l1_nd2nz_overhead_cycles))
    cycles = _cycles_from_measured_bandwidth(src_bytes, bandwidth, overhead)
    bandwidth_source = (
        "gm_to_l1_nd2nz_bandwidth_bytes_per_cycle"
        if model.gm_to_l1_nd2nz_bandwidth_bytes_per_cycle
        else "gm_bandwidth_bytes_per_cycle"
    )
    overhead_source = (
        "gm_to_l1_nd2nz_overhead_cycles"
        if model.gm_to_l1_nd2nz_overhead_cycles
        else ""
    )
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": bandwidth_source,
            "overhead_source": overhead_source,
            "overhead_cycles": overhead,
            "payload_bytes": src_bytes,
            "layout_bytes": dst_bytes,
            "bandwidth_bytes_per_cycle": bandwidth,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead_source),
        },
    )


def _estimate_gm_to_ub_pad(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    n_burst = _resolve_int(task.args.get("n_burst"))
    burst_len_byte = _resolve_int(task.args.get("burst_len_byte"))
    payload_bytes = max(0, n_burst) * max(0, burst_len_byte)
    bandwidth = model.gm_to_ub_pad_bandwidth_bytes_per_cycle or model.gm_bandwidth_bytes_per_cycle
    overhead = max(0.0, float(model.gm_to_ub_pad_overhead_cycles))
    cycles = _cycles_from_measured_bandwidth(payload_bytes, bandwidth, overhead)
    bandwidth_source = (
        "gm_to_ub_pad_bandwidth_bytes_per_cycle"
        if model.gm_to_ub_pad_bandwidth_bytes_per_cycle
        else "gm_bandwidth_bytes_per_cycle"
    )
    overhead_source = (
        "gm_to_ub_pad_overhead_cycles"
        if model.gm_to_ub_pad_overhead_cycles
        else ""
    )
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": bandwidth_source,
            "overhead_source": overhead_source,
            "overhead_cycles": overhead,
            "payload_bytes": payload_bytes,
            "bandwidth_bytes_per_cycle": bandwidth,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead_source),
        },
    )


def _estimate_gm_to_ub_nd_dma(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    dim = int(task.args.get("dim", 0) or 0)
    loop_size = tuple(int(v) for v in task.args.get("loop_size", ()))
    loop_left_pad = tuple(int(v) for v in task.args.get("loop_left_pad", (0,) * dim))
    loop_right_pad = tuple(int(v) for v in task.args.get("loop_right_pad", (0,) * dim))
    config_left_pad = task.args.get("config_left_pad", None)
    config_right_pad = task.args.get("config_right_pad", None)
    effective_left_pad = tuple(
        (int(config_left_pad) if config_left_pad is not None else loop_left_pad[idx])
        for idx in range(dim)
    )
    effective_right_pad = tuple(
        (int(config_right_pad) if config_right_pad is not None else loop_right_pad[idx])
        for idx in range(dim)
    )

    logical_elems = 0
    if dim > 0:
        logical_elems = 1
        for idx in range(dim):
            logical_elems *= max(0, loop_size[idx] + effective_left_pad[idx] + effective_right_pad[idx])

    elem_size = 4
    dst_name = task.args.get("dst", None)
    if isinstance(dst_name, str) and tensor_store.contains(dst_name):
        elem_size = int(tensor_store.tensor(dst_name).element_size())

    payload_bytes = logical_elems * elem_size
    bandwidth = model.gm_to_ub_pad_bandwidth_bytes_per_cycle or model.gm_bandwidth_bytes_per_cycle
    overhead = max(0.0, float(model.gm_to_ub_pad_overhead_cycles))
    cycles = _cycles_from_measured_bandwidth(payload_bytes, bandwidth, overhead)
    bandwidth_source = (
        "gm_to_ub_pad_bandwidth_bytes_per_cycle"
        if model.gm_to_ub_pad_bandwidth_bytes_per_cycle
        else "gm_bandwidth_bytes_per_cycle"
    )
    overhead_source = (
        "gm_to_ub_pad_overhead_cycles"
        if model.gm_to_ub_pad_overhead_cycles
        else ""
    )
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": bandwidth_source,
            "overhead_source": overhead_source,
            "overhead_cycles": overhead,
            "payload_bytes": payload_bytes,
            "logical_elems": logical_elems,
            "bandwidth_bytes_per_cycle": bandwidth,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead_source),
        },
    )


def _estimate_ub_to_gm_pad(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    n_burst = _resolve_int(task.args.get("n_burst"))
    burst_len_byte = _resolve_int(task.args.get("burst_len_byte"))
    payload_bytes = max(0, n_burst) * max(0, burst_len_byte)
    bandwidth = model.ub_to_gm_pad_bandwidth_bytes_per_cycle or model.gm_bandwidth_bytes_per_cycle
    overhead = max(0.0, float(model.ub_to_gm_pad_overhead_cycles))
    cycles = _cycles_from_measured_bandwidth(payload_bytes, bandwidth, overhead)
    bandwidth_source = (
        "ub_to_gm_pad_bandwidth_bytes_per_cycle"
        if model.ub_to_gm_pad_bandwidth_bytes_per_cycle
        else "gm_bandwidth_bytes_per_cycle"
    )
    overhead_source = (
        "ub_to_gm_pad_overhead_cycles"
        if model.ub_to_gm_pad_overhead_cycles
        else ""
    )
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": bandwidth_source,
            "overhead_source": overhead_source,
            "overhead_cycles": overhead,
            "payload_bytes": payload_bytes,
            "bandwidth_bytes_per_cycle": bandwidth,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead_source),
        },
    )


def _estimate_set_constant_to_l1(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    tensor_name, tensor = _tensor_ref(tensor_store, task.args.get("tensor", task.args.get("dst")))
    if tensor_name is None or tensor is None:
        return CycleEstimate(0, {"model_kind": "set_constant_to_l1"})
    n_blocks = _resolve_int(task.args.get("n_blocks"))
    elem_size = int(tensor.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    payload_bytes = max(0, n_blocks) * c0 * elem_size
    overhead = max(0.0, float(model.set_constant_to_l1_overhead_cycles))
    cycles = _cycles_from_measured_bandwidth(payload_bytes, model.set_constant_to_l1_bandwidth_bytes_per_cycle, overhead)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "set_constant_to_l1_bandwidth_bytes_per_cycle",
            "overhead_source": "set_constant_to_l1_overhead_cycles" if overhead else "",
            "overhead_cycles": overhead,
            "payload_bytes": payload_bytes,
            "tensor": tensor_name,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead),
        },
    )


def _estimate_l1_to_l0(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "l1_to_l0"})
    m_dst = _resolve_int(task.args.get("m_dst"))
    n_dst = _resolve_int(task.args.get("n_dst"))
    m_src = _resolve_int(task.args.get("m_src"))
    n_src = _resolve_int(task.args.get("n_src"))
    src_is_transpose = bool(task.args.get("src_is_transpose", False))
    src_layout = str(task.args.get("src_layout", "NZ")).upper()
    dst_layout = str(task.args.get("dst_layout", "ZN" if src_is_transpose else "NZ")).upper()
    src_row0 = _resolve_int(task.args.get("src_row0"), 0)
    src_col0 = _resolve_int(task.args.get("src_col0"), 0)
    elem_size = int(dst.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    required_src_rows = src_row0 + max(m_dst, 0)
    required_src_cols = src_col0 + max(n_dst, 0)
    src_n_align = _align_to(required_src_cols, c0)
    if src_layout == "ZZ":
        src_elems = ((required_src_rows + 15) // 16) * src_n_align * 16
    else:
        src_elems = ((required_src_cols + c0 - 1) // c0) * _align_to(required_src_rows, 16) * c0
    if src_is_transpose:
        if dst_layout == "ZZ":
            out_rows = n_dst
            out_cols = m_dst
            dst_elems = ((out_rows + 15) // 16) * _align_to(out_cols, c0) * 16
        else:
            row_block = 32 if elem_size == 1 else 16
            n_align = _align_to(n_dst, 32 if elem_size == 1 else c0)
            m_blocks = (m_dst + row_block - 1) // row_block
            dst_elems = m_blocks * row_block * n_align
    elif dst_layout == "ZZ":
        dst_elems = ((m_dst + 15) // 16) * _align_to(n_dst, c0) * 16
    else:
        dst_elems = ((n_dst + c0 - 1) // c0) * _align_to(m_dst, 16) * c0
    bytes_count = max(src_elems * int(src.element_size()), dst_elems * elem_size, 0)
    cycles = _cycles_from_bandwidth(bytes_count, model.l0_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "l0_bandwidth_bytes_per_cycle",
            "src_bytes": src_elems * int(src.element_size()),
            "dst_bytes": dst_elems * elem_size,
            "src_row0": src_row0,
            "src_col0": src_col0,
            "required_src_rows": required_src_rows,
            "required_src_cols": required_src_cols,
            "src_backing_rows": m_src,
            "src_backing_cols": n_src,
            "modeled_cycles": cycles,
        },
    )


def _estimate_mmad(task: PipeTask, tensor_store: Optional[SharedMemoryStore], model: A5CycleModel) -> CycleEstimate:
    m = _resolve_int(task.args.get("M"))
    n = _resolve_int(task.args.get("N"))
    k = _resolve_int(task.args.get("K"))
    operand_bits = _matmul_operand_bits(task, tensor_store)
    k_align = _matmul_c0_from_operand_bits(operand_bits)
    m_aligned = _align_to(max(0, m), 16)
    n_aligned = _align_to(max(0, n), 16)
    k_aligned = _align_to(max(0, k), k_align)
    macs = m_aligned * n_aligned * k_aligned
    macs_per_cycle, compute_source = _matmul_macs_per_cycle(operand_bits, model)
    overhead = max(0.0, float(model.mmad_overhead_cycles))
    cycles = _cycles_from_measured_bandwidth(macs, macs_per_cycle, overhead)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "compute",
            "compute_source": compute_source,
            "overhead_source": "mmad_overhead_cycles" if overhead else "",
            "overhead_cycles": overhead,
            "operand_bits": operand_bits,
            "logical_m": m,
            "logical_n": n,
            "logical_k": k,
            "m_aligned": m_aligned,
            "n_aligned": n_aligned,
            "k_aligned": k_aligned,
            "k_align": k_align,
            "macs": macs,
            "macs_per_cycle": macs_per_cycle,
            "modeled_cycles": cycles,
            "no_instruction_overhead": True,
        },
    )


def _estimate_l0c_to_gm(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "l0c_to_gm_nz2nd"})
    m = _resolve_int(task.args.get("M"))
    n = _resolve_int(task.args.get("N"))
    m_src = _resolve_int(task.args.get("M_src"))
    src_bytes = ((n + 15) // 16) * _align_to(m_src, 16) * 16 * int(src.element_size())
    if task.opname == "l0c_to_gm_nz2dn":
        # transposed dst: n rows of m elements, rows M_dst apart.
        m_dst = _resolve_int(task.args.get("M_dst"))
        dst_bytes = _span_for_strided_rows(n, m_dst, m) * int(dst.element_size())
    else:
        n_dst = _resolve_int(task.args.get("N_dst"))
        dst_bytes = _span_for_strided_rows(m, n_dst, n) * int(dst.element_size())
    bytes_count = max(src_bytes, dst_bytes, 0)
    overhead = max(0.0, float(model.l0c_to_gm_overhead_cycles))
    cycles = _cycles_from_measured_bandwidth(bytes_count, model.l0c_to_gm_bandwidth_bytes_per_cycle, overhead)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "l0c_to_gm_bandwidth_bytes_per_cycle",
            "overhead_source": "l0c_to_gm_overhead_cycles" if overhead else "",
            "overhead_cycles": overhead,
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead),
        },
    )


def _estimate_l0c_to_l1(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "l0c_to_l1"})
    m = _resolve_int(task.args.get("M"))
    n = _resolve_int(task.args.get("N"))
    m_dst = _resolve_int(task.args.get("M_dst"))
    m_src = _resolve_int(task.args.get("M_src"))
    elem_size = int(dst.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    src_bytes = ((n + 15) // 16) * _align_to(m_src, 16) * 16 * int(src.element_size())
    dst_bytes = ((n + c0 - 1) // c0) * _align_to(m_dst, 16) * c0 * elem_size
    bytes_count = max(src_bytes, dst_bytes, 0)
    cycles = _cycles_from_bandwidth(bytes_count, model.l0c_to_l1_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "l0c_to_l1_bandwidth_bytes_per_cycle",
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "modeled_cycles": cycles,
        },
    )


def _estimate_l0c_to_ub(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    if src is None:
        return CycleEstimate(0, {"model_kind": "l0c_to_ub"})
    m = _resolve_int(task.args.get("M"))
    n = _resolve_int(task.args.get("N"))
    m_src = _resolve_int(task.args.get("M_src"))
    dual_mode = _resolve_int(task.args.get("dual_mode"), 1)
    src_bytes = ((n + 15) // 16) * _align_to(m_src, 16) * 16 * int(src.element_size())
    payload_elems = m * n
    if dual_mode == 1:
        payload_elems = (m // 2) * n
    elif dual_mode == 2:
        payload_elems = m * (n // 2)
    dst_tensor = None
    if isinstance(task.args.get("dst"), str):
        _, dst_tensor = _tensor_ref(tensor_store, task.args.get("dst"))
    elif isinstance(task.args.get("dst_vec0"), str):
        _, dst_tensor = _tensor_ref(tensor_store, task.args.get("dst_vec0"))
    dst_bytes = payload_elems * int(dst_tensor.element_size()) if dst_tensor is not None else payload_elems * 4
    bytes_count = max(src_bytes, dst_bytes, 0)
    cycles = _cycles_from_bandwidth(bytes_count, model.l0c_to_ub_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "l0c_to_ub_bandwidth_bytes_per_cycle",
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "dual_mode": dual_mode,
            "modeled_cycles": cycles,
        },
    )


def _estimate_ub_to_l1(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel, nz_mode: bool) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "ub_to_l1"})
    m_dst = _resolve_int(task.args.get("m_dst"))
    n_dst = _resolve_int(task.args.get("n_dst"))
    m_src = _resolve_int(task.args.get("m_src"))
    n_src = _resolve_int(task.args.get("n_src"))
    elem_size = int(dst.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    block_count = (n_src + c0 - 1) // c0
    if nz_mode:
        src_elems = block_count * (m_src * c0)
    else:
        src_elems = m_src * n_src
    dst_elems = _span_for_repeated_region(block_count, _align_to(m_dst, 16) * c0, m_src * c0)
    src_bytes = src_elems * int(src.element_size())
    dst_bytes = dst_elems * elem_size
    bytes_count = max(src_bytes, dst_bytes, 0)
    if task.opname == "ub_to_l1_nd2nz":
        bandwidth_source = "ub_to_l1_nd2nz_bandwidth_bytes_per_cycle"
        bytes_per_cycle = model.ub_to_l1_nd2nz_bandwidth_bytes_per_cycle
    else:
        bandwidth_source = "ub_to_l1_bandwidth_bytes_per_cycle"
        bytes_per_cycle = model.ub_to_l1_bandwidth_bytes_per_cycle
    cycles = _cycles_from_bandwidth(bytes_count, bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": bandwidth_source,
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "nz_mode": nz_mode,
            "modeled_cycles": cycles,
        },
    )


def _estimate_ub_to_l1_raw(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    n_burst = _resolve_int(task.args.get("n_burst"))
    burst_len = _resolve_int(task.args.get("burst_len"))
    bytes_count = max(0, n_burst) * max(0, burst_len) * 32
    bytes_per_cycle = model.ub_to_l1_bandwidth_bytes_per_cycle
    cycles = _cycles_from_bandwidth(bytes_count, bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "ub_to_l1_bandwidth_bytes_per_cycle",
            "payload_bytes": bytes_count,
            "modeled_cycles": cycles,
        },
    )


_MICRO_NON_EXEC_OPS = frozenset([
    "create_var",
    "var_add",
    "var_sub",
    "var_mul",
    "var_div",
    "var_mod",
    "CeilDiv",
    "Min",
    "Max",
    "start_micro_loop",
    "end_loop",
    "create_reg",
    "create_reglist",
    "create_maskreg",
    "micro_ub2reg",
    "micro_reg2ub",
    "micro_ub2regcont",
    "micro_reg2ubcont",
    "micro_reg_reinterpret",
])


def _resolve_micro_scalar(value: Any, env: Dict[str, Any]) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, str) and value in env:
        return int(env[value])
    name = getattr(value, "name", None)
    if isinstance(name, str) and name in env:
        return int(env[name])
    value_attr = getattr(value, "value", None)
    if isinstance(value_attr, (int, float)):
        return int(value_attr)
    return 0


_DTYPE_LABELS = {
    "half": "half",
    "float": "float",
    "int": "int",
    "int8_t": "int8",
    "uint8_t": "uint8",
    "int16_t": "int16",
    "uint16_t": "uint16",
    "uint32_t": "uint32",
    "uint64_t": "uint64",
    "int64_t": "int64",
    "bfloat16_t": "bfloat16",
    "float8_e4m3_t": "e4m3",
    "float8_e5m2_t": "e5m2",
    "hifloat8_t": "hif8",
    "int4": "int4",
}


def _dtype_label(dtype: Any) -> str:
    if dtype is None:
        return ""
    name = str(getattr(dtype, "name", dtype))
    return _DTYPE_LABELS.get(name, name)


def _instruction_dtype(inst: Any) -> str:
    kwargs = getattr(inst, "kwargs", {})
    dtype = kwargs.get("dtype")
    if dtype is not None:
        return _dtype_label(dtype)
    for key in ("dst", "src", "src1", "src2", "reg"):
        ref = kwargs.get(key)
        dtype = getattr(ref, "dtype", None)
        if dtype is not None:
            return _dtype_label(dtype)
    return ""


def _micro_cycle_keys(inst: Any) -> list:
    opname = str(inst.opname)
    kwargs = getattr(inst, "kwargs", {})
    if opname == "micro_cast":
        src_dtype = _dtype_label(kwargs.get("dsrc") or getattr(kwargs.get("src"), "dtype", None))
        dst_dtype = _dtype_label(kwargs.get("ddst") or kwargs.get("dtype") or getattr(kwargs.get("dst"), "dtype", None))
        keys = []
        if src_dtype and dst_dtype:
            keys.append(opname + ":" + src_dtype + "->" + dst_dtype)
        if dst_dtype:
            keys.append(opname + ":" + dst_dtype)
        keys.append(opname)
        return keys
    dtype = _instruction_dtype(inst)
    if dtype:
        return [opname + ":" + dtype, opname]
    return [opname]


def _micro_instruction_cycles(inst: Any, model: A5CycleModel) -> Tuple[int, str]:
    table = model.vpipe_instruction_cycles
    for key in _micro_cycle_keys(inst):
        if key in table:
            return max(1, int(table[key])), key
    if "call_micro" in table:
        return max(1, int(table["call_micro"])), "call_micro"
    if "default" in table:
        return max(1, int(table["default"])), "default"
    return max(1, int(model.vpipe_default_instruction_cycles)), "vpipe_default_instruction_cycles"


_VPIPE_CANONICAL_OPS = {
    "vec_v_add": "add",
    "vec_v_sub": "sub",
    "vec_v_mul": "mul",
    "vec_v_div": "div",
    "vec_v_max": "vmax",
    "vec_v_min": "vmin",
    "vec_v_abs": "abs",
    "vabs": "abs",
    "vec_v_relu": "relu",
    "vec_v_add_scalar": "adds",
    "vec_v_mul_scalar": "muls",
    "vec_v_dup": "dup",
    "vec_v_cast": "cast",
    "vec_v_exp": "exp",
    "vec_v_ln": "ln",
    "vec_v_rec": "rec",
    "vec_v_sqrt": "sqrt",
    "vec_v_rsqrt": "rsqrt",
    "vec_v_not": "vnot",
    "vec_v_and": "vand",
    "vec_v_or": "vor",
    "vec_v_cmax": "cmax",
    "vec_v_cmin": "cmin",
    "vec_v_cadd": "cadd",
    "vec_v_cgmax": "cgmax",
    "vec_v_cgmin": "cgmin",
    "vec_v_cgadd": "cgadd",
    "vec_v_brcb": "brcb",
    "vec_v_muladddst": "muladddst",
    "vec_v_compare": "compare",
    "vec_v_compare_scalar": "compare_scalar",
    "vec_v_select": "select",
    "vec_v_cpadd": "cpadd",
}


def _canonical_vpipe_op(opname: str) -> str:
    return _VPIPE_CANONICAL_OPS.get(str(opname), str(opname))


def _torch_dtype_label(dtype: Any) -> str:
    if dtype is None:
        return ""
    if dtype is torch.float16:
        return "half"
    if dtype is torch.float32:
        return "float"
    if dtype is torch.bfloat16:
        return "bfloat16"
    if dtype is torch.int8:
        return "int8"
    if dtype is torch.uint8:
        return "uint8"
    if dtype is torch.int16:
        return "int16"
    if hasattr(torch, "uint16") and dtype is getattr(torch, "uint16"):
        return "uint16"
    if dtype is torch.int32:
        return "int"
    if hasattr(torch, "uint32") and dtype is getattr(torch, "uint32"):
        return "uint32"
    if dtype is torch.int64:
        return "int64"
    if hasattr(torch, "uint64") and dtype is getattr(torch, "uint64"):
        return "uint64"
    text = str(dtype)
    if text.startswith("torch."):
        text = text[len("torch."):]
    return _DTYPE_LABELS.get(text, text)


def _dtype_formula_aliases(label: str) -> list:
    if not label:
        return []
    aliases = [label]
    if label == "int32":
        aliases.append("int")
    elif label == "uint16":
        aliases.append("int16")
    elif label == "float32":
        aliases.append("float")
    elif label == "float16":
        aliases.append("half")
    return aliases


def _tensor_dtype_label(tensor: Optional[torch.Tensor]) -> str:
    if not isinstance(tensor, torch.Tensor):
        return ""
    return _torch_dtype_label(tensor.dtype)


def _tensor_element_bits(tensor: Optional[torch.Tensor]) -> int:
    if not isinstance(tensor, torch.Tensor):
        return 0
    return int(tensor.element_size()) * 8


def _vpipe_primary_tensor_key(opname: str) -> str:
    if opname in ("compare", "compare_scalar"):
        return "src1"
    if opname in ("cmax", "cgmax", "cmin", "cgmin", "cadd", "cgadd", "cpadd"):
        return "src"
    if opname == "gather":
        return "dst"
    if opname == "scatter":
        return "src"
    return "dst"


def _vpipe_formula_keys(task: PipeTask, tensor_store: SharedMemoryStore, opname: str) -> list:
    if opname == "cast":
        _, src = _tensor_ref(tensor_store, task.args.get("src"))
        _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
        src_label = _tensor_dtype_label(src)
        dst_label = _tensor_dtype_label(dst)
        src_bits = _tensor_element_bits(src)
        dst_bits = _tensor_element_bits(dst)
        keys = []
        if src_label and dst_label:
            keys.append("cast:" + src_label + "->" + dst_label)
        if src_bits > 0 and dst_bits > 0:
            keys.append("cast:" + str(src_bits) + "->" + str(dst_bits))
        keys.append("cast")
        return keys

    primary_key = _vpipe_primary_tensor_key(opname)
    _, tensor = _tensor_ref(tensor_store, task.args.get(primary_key))
    label = _tensor_dtype_label(tensor)
    keys = [opname + ":" + alias for alias in _dtype_formula_aliases(label)]
    keys.append(opname)
    return keys


def _vpipe_metric_bytes_from_count(
    task: PipeTask, tensor_store: SharedMemoryStore, opname: str
) -> Tuple[int, str]:
    count = task.args.get("count")
    if not isinstance(count, (int, float)) or isinstance(count, bool):
        return 0, ""
    count_int = max(0, int(count))
    if opname == "cast":
        _, src = _tensor_ref(tensor_store, task.args.get("src"))
        _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
        elem_size = max(
            int(src.element_size()) if isinstance(src, torch.Tensor) else 0,
            int(dst.element_size()) if isinstance(dst, torch.Tensor) else 0,
        )
        return count_int * elem_size, "count_wide_dtype_bytes"
    primary_key = _vpipe_primary_tensor_key(opname)
    _, tensor = _tensor_ref(tensor_store, task.args.get(primary_key))
    elem_size = int(tensor.element_size()) if isinstance(tensor, torch.Tensor) else 0
    return count_int * elem_size, "count_" + primary_key + "_bytes"


def _vpipe_formula_metric_bytes(
    task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel, opname: str
) -> Tuple[int, str]:
    repeat = _resolve_int(task.args.get("repeat"), 0)
    if repeat > 0:
        return repeat * max(1, int(model.vpipe_bytes_per_instruction)), "repeat_256b_chunks"

    count_bytes, count_source = _vpipe_metric_bytes_from_count(task, tensor_store, opname)
    if count_source:
        return count_bytes, count_source

    if opname == "cast":
        _, src = _tensor_ref(tensor_store, task.args.get("src"))
        _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
        return max(_tensor_bytes(src), _tensor_bytes(dst)), "wide_tensor_bytes"

    primary_key = _vpipe_primary_tensor_key(opname)
    _, primary = _tensor_ref(tensor_store, task.args.get(primary_key))
    bytes_count = _tensor_bytes(primary)
    if bytes_count > 0:
        return bytes_count, primary_key + "_tensor_bytes"
    return _max_tensor_bytes(task, tensor_store), "max_tensor_bytes"


def _estimate_vpipe_formula(
    task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel
) -> Optional[CycleEstimate]:
    formulas = getattr(model, "vpipe_cycle_formulas", {})
    if not formulas:
        return None
    opname = _canonical_vpipe_op(task.opname)
    formula_key = ""
    formula = None
    for key in _vpipe_formula_keys(task, tensor_store, opname):
        if key in formulas:
            formula_key = key
            formula = formulas[key]
            break
    if formula is None:
        return None
    overhead = float(formula.get("overhead_cycles", 0.0))
    bandwidth = float(formula.get("bandwidth_bytes_per_cycle", 0.0))
    if bandwidth <= 0.0:
        return None
    metric_bytes, metric_source = _vpipe_formula_metric_bytes(task, tensor_store, model, opname)
    modeled = overhead + float(max(0, metric_bytes)) / bandwidth
    cycles = max(1, int(modeled + 0.5))
    return CycleEstimate(
        cycles,
        {
            "model_kind": "vpipe_formula",
            "formula_key": formula_key,
            "canonical_opname": opname,
            "overhead_cycles": overhead,
            "bandwidth_bytes_per_cycle": bandwidth,
            "metric_bytes": metric_bytes,
            "metric_source": metric_source,
            "modeled_cycles_float": modeled,
            "modeled_cycles": cycles,
            "no_instruction_overhead": True,
        },
    )


def _find_matching_end_loop(instructions: list, start_idx: int) -> int:
    depth = 0
    for idx in range(start_idx, len(instructions)):
        opname = str(instructions[idx].opname)
        if opname == "start_micro_loop":
            depth += 1
        elif opname == "end_loop":
            depth -= 1
            if depth == 0:
                return idx
    return len(instructions) - 1


def _estimate_micro_instruction_block(
    instructions: list, env: Dict[str, Any], model: A5CycleModel
) -> Tuple[int, int, Dict[str, int]]:
    instruction_count = 0
    total_cycles = 0
    cycle_key_counts: Dict[str, int] = {}
    idx = 0
    while idx < len(instructions):
        inst = instructions[idx]
        opname = str(inst.opname)
        if opname == "start_micro_loop":
            loop_end = _find_matching_end_loop(instructions, idx)
            loop_env = dict(env)
            var = inst.kwargs.get("var")
            var_name = str(getattr(var, "name", var))
            start = _resolve_micro_scalar(inst.kwargs.get("start", 0), loop_env)
            stop = _resolve_micro_scalar(inst.kwargs.get("stop", 0), loop_env)
            step = _resolve_micro_scalar(inst.kwargs.get("step", 1), loop_env)
            if step == 0:
                step = 1
            body = instructions[idx + 1 : loop_end]
            for value in range(start, stop, step):
                loop_env[var_name] = value
                nested_count, nested_cycles, nested_key_counts = _estimate_micro_instruction_block(
                    body, loop_env, model
                )
                instruction_count += nested_count
                total_cycles += nested_cycles
                for key, count in nested_key_counts.items():
                    cycle_key_counts[key] = cycle_key_counts.get(key, 0) + count
            idx = loop_end + 1
            continue
        if opname not in _MICRO_NON_EXEC_OPS:
            cycles, key = _micro_instruction_cycles(inst, model)
            instruction_count += 1
            total_cycles += cycles
            cycle_key_counts[key] = cycle_key_counts.get(key, 0) + 1
        idx += 1
    return instruction_count, total_cycles, cycle_key_counts


# ---------------------------------------------------------------------------
# VF (call_micro) 4-pipe DAG scheduler.
#
# A VF body issues micro instructions across four concurrent pipes:
#   SU  scalar/const/address arithmetic + loop control (RVECSU / RVECLP)
#   EX  vector compute (RVECEX: RV_VADD, RV_VEXPDIF, RV_VCVT_F2F, ...)
#   LD  UB->register loads         (RVECLD: RV_VLD)
#   ST  register->UB stores        (RVECST: RV_VSSTB / RV_VST)
# The steady-state per-VF cost is
#   fixed_overhead + max(  max_pipe sum(issue_interval),   dependency_critical_path )
# i.e. the classic resource / longest-path bound for a well software-pipelined
# DAG. Latencies come from measured cannsim RV_* durations; issue intervals are
# calibrated pipe throughputs. Constant-bounded loops unroll and their address
# arithmetic folds to immediates (zero SU cost); variable-bounded loops do NOT
# fold, so their address var-ops load the SU pipe and can bottleneck the VF --
# this is why constant loop bounds are preferred over `Var` bounds.
# ---------------------------------------------------------------------------

_VF_LD_OPS = frozenset([
    "micro_ub2reg", "micro_ub2regcont", "micro_ub2reginterleave",
    "micro_datacopygather", "micro_gather", "micro_gathermask",
])
# Register->UB stores. NOTE: micro_squeeze (RV_VSQZ, stream compaction) executes
# on the vector EX pipe, not the store pipe -- the store is the following reg2ub.
_VF_ST_OPS = frozenset([
    "micro_reg2ub", "micro_reg2ubcont", "micro_reg2ubinterleave", "micro_datacopyscatter",
])
_VF_SU_OPS = frozenset([
    "create_var", "var_add", "var_sub", "var_mul", "var_div", "var_mod", "CeilDiv",
    "var_assign", "Min", "Max", "scalar_abs", "scalar_sqrt",
    "tensorlist_size", "tensorlist_item_numel",
])
# Structural / zero-cost ops: register + tensor-view declarations and loop
# markers. Handled explicitly by the flattener, never scheduled.
_VF_NOCOST_OPS = frozenset([
    "create_reg", "create_reglist", "create_maskreg", "create_tensor",
    "micro_slice_tensor", "micro_reg_reinterpret", "start_micro_loop", "end_loop",
])
_VF_OUT_KEYS = ("dst", "dst0", "dst1", "out", "tensor", "reg", "reglist")
_VF_IN_KEYS = ("src", "src0", "src1", "src2", "src_a", "src_b", "a", "b",
               "mask", "selmask", "idx", "index", "offset")
_VF_SKIP_KEYS = frozenset([
    "v", "config", "layout", "ddst", "dsrc", "mode", "round_mode", "step",
    "span", "blk_stride", "name", "start", "stop", "var", "val", "bin_group",
])


def _vf_pipe_for_op(opname: str) -> Optional[str]:
    if opname in _VF_LD_OPS:
        return "LD"
    if opname in _VF_ST_OPS:
        return "ST"
    if opname in _VF_SU_OPS or opname.startswith("Align"):
        return "SU"
    if opname in _VF_NOCOST_OPS or opname == "micro_vf_barrier":
        return None
    if opname.startswith("micro_"):
        return "EX"
    return None


def _vf_micro_latency(opname: str, pipe: str, model: A5CycleModel) -> float:
    table = model.vf_micro_latency
    if opname in table:
        return max(0.0, float(table[opname]))
    if pipe == "LD":
        return float(table.get("_default_ld", 9.0))
    if pipe == "ST":
        return float(table.get("_default_st", 9.0))
    if pipe == "SU":
        return float(table.get("_default_su", 2.0))
    return max(0.0, float(model.vf_micro_default_latency))


def _micro_pow2_ways(stride: int, banks: int) -> int:
    """UB bank-conflict multiplicity of a strided c0-block datamove: cannsim scatters the
    reg's 16-lane c0-blocks with blk_stride*c0 spacing, so a power-of-two blk_stride aliases
    UB banks and serializes min(2^v2(stride), banks) ways. Odd / 1 strides = 1 (no conflict)."""
    if stride <= 1:
        return 1
    v2 = 0
    s = int(stride)
    while (s & 1) == 0:
        s >>= 1
        v2 += 1
    return min(1 << v2, max(1, int(banks)))


def _micro_bank_datamove_interval(blk_stride: Any, base: float, stride_pen: float,
                                  per_way: float, banks: int) -> float:
    """Throughput interval of an explicit strided reg2ub/ub2reg, fitted to the load/store
    stride-sweep probes: a >1 blk_stride loses the contiguous fast path (stride_pen; ~0 for
    stores, real for loads) and a power-of-two blk_stride adds per_way*(ways-1) bank conflict.
    A runtime-variable stride is unknown here, so it is treated as contiguous (no penalty)."""
    try:
        stride = max(1, int(blk_stride)) if blk_stride is not None else 1
    except (TypeError, ValueError):
        stride = 1
    ways = _micro_pow2_ways(stride, banks)
    pen = stride_pen if stride > 1 else 0.0
    return max(1.0, base + pen + per_way * (ways - 1))


def _vf_issue_interval(pipe: str, latency: float, model: A5CycleModel,
                       opname: Optional[str] = None, blk_stride: Any = None) -> float:
    """Cycles the pipe's issue port is occupied by one op (throughput term).

    EX scales with op latency (heavy vector ops occupy the datapath longer, light ops
    dual-issue). LD/ST use a fixed per-pipe interval, EXCEPT an explicit strided
    reg_to_ub/ub_to_reg (micro_reg2ub / micro_ub2reg), which pays a UB bank conflict that
    scales with the power-of-two factor of blk_stride (contiguous `<<=` cont ops keep flat)."""
    if pipe == "EX":
        override = (model.vf_ex_interval_override or {}).get(opname) if opname else None
        if override is not None:
            return max(float(model.vf_ex_issue_floor), float(override))
        return max(
            float(model.vf_ex_issue_floor),
            float(model.vf_ex_issue_slope) * float(latency) + float(model.vf_ex_issue_intercept),
        )
    if pipe in ("LD", "ST") and getattr(model, "vf_bank_conflict", False):
        if opname == "micro_reg2ub":
            return _micro_bank_datamove_interval(
                blk_stride, model.vf_st_bank_base, model.vf_st_bank_stride_penalty,
                model.vf_st_bank_per_way, model.vf_st_bank_banks)
        if opname == "micro_ub2reg":
            return _micro_bank_datamove_interval(
                blk_stride, model.vf_ld_bank_base, model.vf_ld_bank_stride_penalty,
                model.vf_ld_bank_per_way, model.vf_ld_bank_banks)
    return float((model.vf_pipe_issue_interval or {}).get(pipe, 1.0))


def _vf_operand_names(value: Any) -> list:
    """Register / maskreg / var / UB-tensor dependency identities in a kwarg."""
    names: list = []
    if value is None or isinstance(value, (int, float, bool, str)):
        return names
    if isinstance(value, (list, tuple)):
        for item in value:
            names.extend(_vf_operand_names(item))
        return names
    cls = type(value).__name__
    name = getattr(value, "name", None)
    if not isinstance(name, str) or not name:
        return names
    if cls in ("Reg", "RegList", "MaskReg"):
        names.append(name)
    elif cls == "Tensor":
        names.append("T:" + name)
    elif cls in ("Var", "VarRef"):
        names.append("V:" + name)
    return names


def _vf_reads_writes(inst: Any) -> Tuple[list, list]:
    reads: list = []
    writes: list = []
    for key, value in getattr(inst, "kwargs", {}).items():
        if key in _VF_SKIP_KEYS:
            continue
        operands = _vf_operand_names(value)
        if not operands:
            continue
        if key in _VF_OUT_KEYS:
            writes.extend(operands)
        elif key in _VF_IN_KEYS:
            reads.extend(operands)
    return reads, writes


def _vf_is_literal_int(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _vf_var_name(value: Any) -> Optional[str]:
    name = getattr(value, "name", None)
    return name if isinstance(name, str) else None


def _vf_track_su_constness(inst: Any, env: Dict[str, Any], const_env: Dict[str, bool]) -> None:
    """Update const_env/env for a scalar op so downstream folding can be decided."""
    opname = str(inst.opname)
    kwargs = getattr(inst, "kwargs", {})
    if opname == "create_var":
        return
    out = kwargs.get("out")
    out_name = _vf_var_name(out)
    if out_name is None:
        return
    all_const = True
    for key in ("a", "b"):
        operand = kwargs.get(key)
        if _vf_is_literal_int(operand):
            continue
        vname = _vf_var_name(operand)
        if vname is not None and const_env.get(vname, False):
            continue
        all_const = False
    const_env[out_name] = all_const
    a = _resolve_micro_scalar(kwargs.get("a", 0), env)
    b = _resolve_micro_scalar(kwargs.get("b", 0), env)
    if opname == "var_add":
        env[out_name] = a + b
    elif opname == "var_sub":
        env[out_name] = a - b
    elif opname == "var_mul":
        env[out_name] = a * b
    elif opname == "var_div":
        if not b:
            raise ZeroDivisionError("var_div division by zero")
        env[out_name] = a // b
    elif opname == "var_mod":
        if not b:
            raise ZeroDivisionError("var_mod division by zero")
        quotient = abs(a) // abs(b)
        if (a < 0) != (b < 0):
            quotient = -quotient
        env[out_name] = a - quotient * b
    elif opname == "CeilDiv":
        if not b:
            raise ZeroDivisionError("CeilDiv division by zero")
        env[out_name] = (a + b - 1) // b
    elif opname == "Min":
        env[out_name] = min(a, b)
    elif opname == "Max":
        env[out_name] = max(a, b)


def _vf_su_folds(inst: Any, const_env: Dict[str, bool]) -> bool:
    kwargs = getattr(inst, "kwargs", {})
    for key in ("a", "b"):
        operand = kwargs.get(key)
        if operand is None or _vf_is_literal_int(operand):
            continue
        vname = _vf_var_name(operand)
        if vname is not None and const_env.get(vname, False):
            continue
        return False
    return True


def _vf_flatten_ops(instructions: list, env: Dict[str, Any], const_env: Dict[str, bool],
                    model: A5CycleModel, out: list) -> None:
    """Expand loops and emit scheduled-op tuples (pipe, latency, reads, writes) or
    the sentinel ("BARRIER", ...). SU ops that fold to compile-time constants are
    dropped (zero cost)."""
    idx = 0
    n = len(instructions)
    while idx < n:
        inst = instructions[idx]
        opname = str(inst.opname)
        if opname == "start_micro_loop":
            loop_end = _find_matching_end_loop(instructions, idx)
            body = instructions[idx + 1:loop_end]
            var = inst.kwargs.get("var")
            var_name = str(getattr(var, "name", var))
            start_raw = inst.kwargs.get("start", 0)
            stop_raw = inst.kwargs.get("stop", 0)
            step_raw = inst.kwargs.get("step", 1)
            start = _resolve_micro_scalar(start_raw, env)
            stop = _resolve_micro_scalar(stop_raw, env)
            step = _resolve_micro_scalar(step_raw, env) or 1
            # A loop folds only when its bounds are compile-time literals. A bound
            # supplied via var_values (runtime) still unrolls for op counting but
            # keeps its address arithmetic on the SU pipe.
            const_loop = all(
                _vf_is_literal_int(v) for v in (start_raw, stop_raw, step_raw)
            )
            for value in range(int(start), int(stop), int(step)):
                loop_env = dict(env)
                loop_env[var_name] = value
                loop_const = dict(const_env)
                loop_const[var_name] = const_loop
                _vf_flatten_ops(body, loop_env, loop_const, model, out)
            idx = loop_end + 1
            continue
        if opname == "end_loop":
            idx += 1
            continue
        pipe = _vf_pipe_for_op(opname)
        if pipe == "SU":
            _vf_track_su_constness(inst, env, const_env)
            if _vf_su_folds(inst, const_env):
                idx += 1
                continue
            reads, writes = _vf_reads_writes(inst)
            out.append(("SU", _vf_micro_latency(opname, "SU", model), reads, writes, opname, None))
        elif pipe in ("EX", "LD", "ST"):
            reads, writes = _vf_reads_writes(inst)
            blk_stride = getattr(inst, "kwargs", {}).get("blk_stride", 1) if pipe in ("LD", "ST") else None
            out.append((pipe, _vf_micro_latency(opname, pipe, model), reads, writes, opname, blk_stride))
        elif opname == "micro_vf_barrier":
            out.append(("BARRIER", 0.0, [], [], opname, None))
        idx += 1


def _schedule_micro_vf(instructions: list, var_values: Dict[str, Any],
                       model: A5CycleModel) -> Tuple[float, Dict[str, Any]]:
    """Return (makespan, details) for the RVEC region of one VF via the
    resource / critical-path bound."""
    ops: list = []
    _vf_flatten_ops(list(instructions), dict(var_values), {}, model, ops)
    busy = {"SU": 0.0, "EX": 0.0, "LD": 0.0, "ST": 0.0}
    counts = {"SU": 0, "EX": 0, "LD": 0, "ST": 0}
    max_op_latency = 0.0               # slowest single op = physical makespan floor
    reg_ready: Dict[str, float] = {}   # RAW critical-path times, register operands only
    crit = 0.0
    op_stats: Dict[str, list] = {}     # "PIPE/opname" -> [Σinterval, count, latency] (VF_DIAG only)
    for pipe, latency, reads, writes, opname, blk_stride in ops:
        if pipe == "BARRIER":
            continue
        interval = _vf_issue_interval(pipe, latency, model, opname, blk_stride)
        busy[pipe] += interval
        counts[pipe] += 1
        st = op_stats.setdefault(f"{pipe}/{opname}", [0.0, 0, latency])
        st[0] += interval; st[1] += 1
        if latency > max_op_latency:
            max_op_latency = latency
        op_ready = 0.0                  # true RAW deps only: a write resets its reg (no WAR chain)
        for r in reads:
            if r[:2] in ("T:", "V:"):   # tensor/var deps are memory/scalar, not a reg RAW chain
                continue
            rr = reg_ready.get(r)
            if rr is not None and rr > op_ready:
                op_ready = rr
        done = op_ready + latency
        for w in writes:
            if w[:2] not in ("T:", "V:"):
                reg_ready[w] = done
        if done > crit:
            crit = done
    throughput = max(busy.values()) if busy else 0.0
    # Most VF bodies are written with enough unrolling/ILP that the bottleneck pipe runs
    # ~99% saturated, so the makespan is the busiest pipe's occupancy. A naive full critical
    # path over-counts (it once predicted 1723 for half128 whose true VF is 795), so instead
    # the RAW-only crit path is scaled by vf_crit_slack (chain-efficiency ~0.46, calibrated to
    # the one chain-bound calibration kernel) and taken as a floor: it lifts a genuinely
    # latency-bound VF (single-accumulator streaming softmax) while staying below the busiest
    # pipe for the throughput-bound majority, whose slack*crit < EX occupancy.
    crit_bound = max(0.0, float(getattr(model, "vf_crit_slack", 0.0))) * crit
    makespan = max(throughput, max_op_latency, crit_bound)
    _diag = os.environ.get("VF_DIAG")
    if _diag:
        try:
            with open(_diag, "a") as _fh:
                _fh.write(json.dumps({
                    "makespan": round(makespan, 2),
                    "busy": {k: round(v, 2) for k, v in busy.items()},
                    "crit": round(crit, 2), "crit_bound": round(crit_bound, 2),
                    "ops": op_stats,
                }) + "\n")
        except OSError:
            pass
    details = {
        "pipe_busy": {k: round(v, 2) for k, v in busy.items()},
        "pipe_counts": counts,
        "throughput_cycles": round(throughput, 2),
        "max_op_latency": round(max_op_latency, 2),
        "crit_path": round(crit, 2),
        "crit_bound": round(crit_bound, 2),
    }
    return makespan, details


def _estimate_call_micro(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    micro_def = task.args.get("micro_def", {})
    instructions = micro_def.get("instructions", []) if isinstance(micro_def, dict) else []
    var_values = dict(task.args.get("var_values", {}))

    if model.vf_fixed_overhead_cycles > 0.0:
        makespan, sched_details = _schedule_micro_vf(instructions, var_values, model)
        has_work = any(sched_details["pipe_counts"].values())
        cycles = int(round(model.vf_fixed_overhead_cycles + makespan)) if has_work else 0
        details = {
            "model_kind": "vpipe_micro_scheduled",
            "fixed_overhead_cycles": model.vf_fixed_overhead_cycles,
            "rvec_makespan_cycles": round(makespan, 2),
            "modeled_cycles": cycles,
        }
        details.update(sched_details)
        return CycleEstimate(cycles, details)

    inst_count, raw_cycles, cycle_key_counts = _estimate_micro_instruction_block(
        list(instructions), var_values, model
    )
    default_cycles_per_inst = int(
        model.vpipe_instruction_cycles.get(
            "call_micro",
            model.vpipe_instruction_cycles.get("default", model.vpipe_default_instruction_cycles),
        )
    )
    cycles = max(1, raw_cycles) if inst_count > 0 else 0
    return CycleEstimate(
        cycles,
        {
            "model_kind": "vpipe_micro",
            "instruction_count": inst_count,
            "cycles_per_instruction": default_cycles_per_inst,
            "default_cycles_per_instruction": default_cycles_per_inst,
            "instruction_cycle_counts": cycle_key_counts,
            "modeled_cycles": cycles,
        },
    )


def _clone_simt_tensor_views(tensor_views: Any) -> Dict[str, Any]:
    if not isinstance(tensor_views, dict):
        return {}
    cloned: Dict[str, Any] = {}
    clone_by_id: Dict[int, torch.Tensor] = {}
    for name, tensor in tensor_views.items():
        if isinstance(tensor, PhysicalAlias):
            logical = tensor.logical_tensor()
            logical_id = id(logical)
            if logical_id not in clone_by_id:
                clone_by_id[logical_id] = logical.detach().clone()
            logical_clone = clone_by_id[logical_id]
            cloned[str(name)] = tensor.with_updates(
                tensor=logical_clone,
                logical_view=logical_clone,
                byte_offset=0,
                logical_offset_bytes=0,
            )
            continue
        if not isinstance(tensor, torch.Tensor):
            continue
        tensor_id = id(tensor)
        if tensor_id not in clone_by_id:
            clone_by_id[tensor_id] = tensor.detach().clone()
        cloned[str(name)] = clone_by_id[tensor_id]
    return cloned


def _count_simt_instructions(task: PipeTask) -> int:
    runtime_count = task.args.get("_simt_instruction_count")
    if isinstance(runtime_count, bool):
        return int(runtime_count)
    if isinstance(runtime_count, (int, float)):
        return max(0, int(runtime_count))
    if bool(task.args.get("_simt_defer_cycle_count", False)):
        return 0
    simt_def = task.args.get("simt_def", {})
    if not isinstance(simt_def, dict):
        return 0
    from ..pipe_simt import SimtRuntime

    var_values_raw = task.args.get("var_values", {})
    var_values = dict(var_values_raw) if isinstance(var_values_raw, dict) else {}
    runtime = SimtRuntime()
    runtime.execute_call_simt(
        simt_def,
        _clone_simt_tensor_views(task.args.get("tensor_views", {})),
        var_values,
        SharedMemoryStore(),
        block_idx=_resolve_int(task.args.get("block_idx"), 0),
        block_num=max(1, _resolve_int(task.args.get("block_num"), 1)),
        thread_num=max(1, _resolve_int(task.args.get("thread_num"), 1024)),
    )
    return max(0, int(runtime.last_instruction_count))


def _estimate_call_simt(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    instruction_count = _count_simt_instructions(task)
    cycles_per_instruction = max(1, int(getattr(model, "simt_cycles_per_instruction", 4)))
    cycles = instruction_count * cycles_per_instruction
    return CycleEstimate(
        cycles,
        {
            "model_kind": "vpipe_simt",
            "instruction_count": instruction_count,
            "cycles_per_instruction": cycles_per_instruction,
            "modeled_cycles": cycles,
        },
    )


def _estimate_vpipe(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    if task.opname == "call_micro":
        return _estimate_call_micro(task, model)
    if task.opname == "call_simt":
        return _estimate_call_simt(task, model)
    if task.opname in _NO_OVERHEAD_SYNC_OPS:
        return _estimate_sync_marker(model, no_instruction_overhead=True)
    if task.opname in (
        "waitflag",
        "setflag",
    ):
        return _estimate_sync_marker(model)
    formula_estimate = _estimate_vpipe_formula(task, tensor_store, model)
    if formula_estimate is not None:
        return formula_estimate
    repeat = _resolve_int(task.args.get("repeat"), 0)
    count_val = task.args.get("count")
    count_int = 0
    if isinstance(count_val, (int, float)) and not isinstance(count_val, bool):
        count_int = max(0, int(count_val))
    if getattr(model, "device_family", "a5") == "a2" and count_int > 0:
        primary_key = "dst" if "dst" in task.args else ("src1" if "src1" in task.args else "src")
        _, primary_tensor = _tensor_ref(tensor_store, task.args.get(primary_key))
        elem_size = int(primary_tensor.element_size()) if primary_tensor is not None else 0
        if elem_size > 0:
            elems_per_repeat = max(1, int(model.vpipe_bytes_per_instruction) // elem_size)
            repeat = _ceil_div(count_int, elems_per_repeat)
    canonical_opname = _canonical_vpipe_op(task.opname)
    cycle_key = task.opname if task.opname in model.vpipe_instruction_cycles else canonical_opname
    cycles_per_inst = int(
        model.vpipe_instruction_cycles.get(
            cycle_key,
            model.vpipe_instruction_cycles.get("default", model.vpipe_default_instruction_cycles),
        )
    )
    if repeat > 0:
        inst_count = repeat
        processed_bytes = 0
    else:
        processed_bytes = _max_tensor_bytes(task, tensor_store)
        granularity = max(1, int(model.vpipe_bytes_per_instruction))
        inst_count = max(1, _ceil_div(processed_bytes, granularity)) if processed_bytes > 0 else 1
    cycles = max(1, inst_count * max(cycles_per_inst, 1))
    return CycleEstimate(
        cycles,
        {
            "model_kind": "vpipe_compute",
            "instruction_count": inst_count,
            "cycles_per_instruction": cycles_per_inst,
            "processed_bytes": processed_bytes,
            "modeled_cycles": cycles,
        },
    )


def _estimate_ub_to_ub(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    n_burst = _resolve_int(task.args.get("n_burst"))
    burst_len = _resolve_int(task.args.get("burst_len"))
    bytes_count = max(0, n_burst) * max(0, burst_len) * 32
    fixed_cycles = max(0, int(model.ub_to_ub_fixed_cycles))
    if fixed_cycles:
        return CycleEstimate(
            fixed_cycles,
            {
                "model_kind": "fixed",
                "fixed_source": "ub_to_ub_fixed_cycles",
                "payload_bytes": bytes_count,
                "modeled_cycles": fixed_cycles,
                "no_instruction_overhead": True,
            },
        )
    bandwidth = model.ub_to_ub_bandwidth_bytes_per_cycle or model.vpipe_bytes_per_instruction
    overhead = max(0.0, float(model.ub_to_ub_overhead_cycles))
    cycles = _cycles_from_measured_bandwidth(bytes_count, bandwidth, overhead)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "ub_to_ub_bandwidth_bytes_per_cycle",
            "overhead_source": "ub_to_ub_overhead_cycles" if overhead else "",
            "overhead_cycles": overhead,
            "payload_bytes": bytes_count,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead),
        },
    )


def _estimate_sort32(task: PipeTask, model: A5CycleModel) -> Optional[CycleEstimate]:
    bandwidth = float(model.sort32_bandwidth_bytes_per_cycle)
    if bandwidth <= 0.0:
        return None
    repeat = _resolve_int(task.args.get("repeat"))
    payload_bytes = max(0, repeat) * 32 * 4
    overhead = float(model.sort32_overhead_cycles)
    cycles = _cycles_from_linear_model(payload_bytes, bandwidth, overhead)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "sort32",
            "bandwidth_source": "sort32_bandwidth_bytes_per_cycle",
            "overhead_source": "sort32_overhead_cycles" if overhead else "",
            "overhead_cycles": overhead,
            "payload_bytes": payload_bytes,
            "bandwidth_bytes_per_cycle": bandwidth,
            "modeled_cycles": cycles,
            "no_instruction_overhead": True,
        },
    )


def _estimate_mergesort4(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    repeat = _resolve_int(task.args.get("repeat"))
    length_per_seq = _resolve_int(task.args.get("length_per_seq"))
    total_elements = max(0, repeat) * 4 * max(0, length_per_seq)
    payload_bytes = total_elements * 8
    bandwidth = float(model.mergesort4_bandwidth_bytes_per_cycle)
    overhead = max(0.0, float(model.mergesort4_overhead_cycles))
    if bandwidth > 0.0:
        cycles = _cycles_from_linear_model(payload_bytes, bandwidth, overhead)
        return CycleEstimate(
            cycles,
            {
                "model_kind": "mergesort4",
                "bandwidth_source": "mergesort4_bandwidth_bytes_per_cycle",
                "overhead_source": "mergesort4_overhead_cycles" if overhead else "",
                "overhead_cycles": overhead,
                "payload_bytes": payload_bytes,
                "total_elements": total_elements,
                "bandwidth_bytes_per_cycle": bandwidth,
                "modeled_cycles": cycles,
                "no_instruction_overhead": bool(overhead),
            },
        )
    cycles_per_elem = max(1, int(model.mergesort_cycles_per_element) or 1)
    cycles = overhead + total_elements * cycles_per_elem
    if total_elements > 0:
        cycles = max(1, int(cycles + 0.5))
    return CycleEstimate(
        cycles,
        {
            "model_kind": "mergesort4",
            "total_elements": total_elements,
            "cycles_per_element": cycles_per_elem,
            "overhead_source": "mergesort4_overhead_cycles" if overhead else "",
            "overhead_cycles": overhead,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead),
        },
    )


def _estimate_mergesort_2seq(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    size1 = _resolve_int(task.args.get("size1"))
    size2 = _resolve_int(task.args.get("size2"))
    total_elements = max(0, size1) + max(0, size2)
    payload_bytes = total_elements * 8
    bandwidth = float(model.mergesort_2seq_bandwidth_bytes_per_cycle)
    overhead = max(0.0, float(model.mergesort_2seq_overhead_cycles))
    if bandwidth > 0.0:
        cycles = _cycles_from_linear_model(payload_bytes, bandwidth, overhead)
        return CycleEstimate(
            cycles,
            {
                "model_kind": "mergesort_2seq",
                "bandwidth_source": "mergesort_2seq_bandwidth_bytes_per_cycle",
                "overhead_source": "mergesort_2seq_overhead_cycles" if overhead else "",
                "overhead_cycles": overhead,
                "payload_bytes": payload_bytes,
                "total_elements": total_elements,
                "bandwidth_bytes_per_cycle": bandwidth,
                "modeled_cycles": cycles,
                "no_instruction_overhead": bool(overhead),
            },
        )
    cycles_per_elem = max(1, int(model.mergesort_cycles_per_element) or 1)
    cycles = overhead + total_elements * cycles_per_elem
    if total_elements > 0:
        cycles = max(1, int(cycles + 0.5))
    return CycleEstimate(
        cycles,
        {
            "model_kind": "mergesort_2seq",
            "total_elements": total_elements,
            "cycles_per_element": cycles_per_elem,
            "overhead_source": "mergesort_2seq_overhead_cycles" if overhead else "",
            "overhead_cycles": overhead,
            "modeled_cycles": cycles,
            "no_instruction_overhead": bool(overhead),
        },
    )


def _estimate_gather_scatter(task: PipeTask, tensor_store: SharedMemoryStore, model: A5CycleModel) -> CycleEstimate:
    primary_key = "dst" if task.opname == "gather" else "src"
    _, primary = _tensor_ref(tensor_store, task.args.get(primary_key))
    count = task.args.get("count")
    if isinstance(count, (int, float)) and not isinstance(count, bool):
        total_elements = max(0, int(count))
    else:
        repeat = _resolve_int(task.args.get("repeat"))
        bytes_per_repeat = max(1, int(model.vpipe_bytes_per_instruction))
        elem_size = int(primary.element_size()) if primary is not None else 0
        elems_per_repeat = bytes_per_repeat // elem_size if elem_size > 0 else 0
        total_elements = max(0, repeat) * max(0, elems_per_repeat)
    elems_per_cycle = max(1, int(model.gather_scatter_elems_per_cycle) or 1)
    cycles = _ceil_div(total_elements, elems_per_cycle)
    if total_elements > 0:
        cycles = max(1, cycles)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "gather_scatter",
            "total_elements": total_elements,
            "elems_per_cycle": elems_per_cycle,
            "modeled_cycles": cycles,
        },
    )


def estimate_task_cycles(task: PipeTask, tensor_store: Optional[SharedMemoryStore], model: A5CycleModel) -> CycleEstimate:
    if task.opname in _NO_OVERHEAD_SYNC_OPS:
        return _estimate_sync_marker(model, no_instruction_overhead=True)
    if tensor_store is None:
        return CycleEstimate(0, {"model_kind": "no_tensor_store"})
    if getattr(model, "device_family", "a5") == "a2":
        if task.opname == "ub_to_ub":
            return _estimate_ub_to_ub(task, model)
        if task.opname == "sort32":
            sort_estimate = _estimate_sort32(task, model)
            if sort_estimate is not None:
                return sort_estimate
        if task.opname == "mergesort4":
            return _estimate_mergesort4(task, model)
        if task.opname == "mergesort_2seq":
            return _estimate_mergesort_2seq(task, model)
        if task.opname in ("gather", "scatter"):
            formula_estimate = _estimate_vpipe_formula(task, tensor_store, model)
            if formula_estimate is not None:
                return formula_estimate
            return _estimate_gather_scatter(task, tensor_store, model)
    if task.opname == "ub_to_ub":
        return _estimate_ub_to_ub(task, model)
    if task.opname == "sort32":
        sort_estimate = _estimate_sort32(task, model)
        if sort_estimate is not None:
            return sort_estimate
    if task.opname == "mergesort4":
        return _estimate_mergesort4(task, model)
    if task.opname == "mergesort_2seq":
        return _estimate_mergesort_2seq(task, model)
    if task.opname in ("gm_to_l1_nd2nz", "gm_to_l1_dn2nz", "gm_to_l1_mx_scale_nd2nz"):
        return _estimate_gm_to_l1_nd2nz(task, tensor_store, model)
    if task.opname == "gm_to_ub_pad":
        return _estimate_gm_to_ub_pad(task, model)
    if task.opname == "gm_to_ub_nd_dma":
        return _estimate_gm_to_ub_nd_dma(task, tensor_store, model)
    if task.opname == "ub_to_gm_pad":
        return _estimate_ub_to_gm_pad(task, model)
    if task.opname == "set_constant_to_l1":
        return _estimate_set_constant_to_l1(task, tensor_store, model)
    if task.opname in ("l1_to_l0", "l1_to_l0_mx"):
        return _estimate_l1_to_l0(task, tensor_store, model)
    if task.opname in ("mmad", "mmad_mx"):
        return _estimate_mmad(task, tensor_store, model)
    if task.opname in ("l0c_to_gm_nz2nd", "l0c_to_gm_nz2nz", "l0c_to_gm_nz2dn"):
        return _estimate_l0c_to_gm(task, tensor_store, model)
    if task.opname == "l0c_to_l1":
        return _estimate_l0c_to_l1(task, tensor_store, model)
    if task.opname == "l0c_to_ub":
        return _estimate_l0c_to_ub(task, tensor_store, model)
    if task.opname == "ub_to_l1":
        return _estimate_ub_to_l1_raw(task, model)
    if task.opname == "ub_to_l1_nd2nz":
        return _estimate_ub_to_l1(task, tensor_store, model, nz_mode=False)
    if task.opname == "ub_to_l1_nz":
        return _estimate_ub_to_l1(task, tensor_store, model, nz_mode=True)
    if task.pipe_name == "V":
        return _estimate_vpipe(task, tensor_store, model)
    return CycleEstimate(max(1, model.sync_marker_cycles), {"model_kind": "fallback", "modeled_cycles": max(1, model.sync_marker_cycles)})
