from __future__ import annotations

import threading
import warnings
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from .physical_alias import PhysicalAlias
from .util import align16, align_to, local_slice_suffix, nz_footprint, nz_tail_write_footprint


_LOCAL_ROLES = frozenset(["l1", "l0a", "l0b", "l0amx", "l0bmx", "l0c", "ub", "bt"])
_MEMORY_CYCLE_SCALE_OPS = frozenset([
    "gm_to_ub_pad",
    "gm_to_ub_nd_dma",
    "ub_to_gm_pad",
    "gm_to_l1_pad",
    "gm_to_l1_nd2nz",
    "gm_to_l1_dn2nz",
    "gm_to_l1_mx_scale_nd2nz",
    "gm_to_l1",
    "set_constant_to_l1",
    "ub_to_l1",
    "ub_to_l1_nd2nz",
    "ub_to_l1_nz",
    "l1_to_l0",
    "l1_to_l0_mx",
    "l1_to_l0_img2col",
    "l0c_to_gm_nz2nd",
    "l0c_to_gm_nz2nz",
    "l0c_to_gm_nz2dn",
    "l0c_to_l1",
    "l0c_to_ub",
])


@dataclass(frozen=True)
class _Range:
    storage_id: int
    bank: str
    lo: int
    hi: int
    tensor: str


@dataclass(frozen=True)
class _Access:
    kind: str
    rng: _Range


@dataclass(frozen=True)
class _Record:
    access: _Access
    core_idx: int
    lane_name: str
    pipe_name: str
    opname: str
    start_cycle: float
    end_cycle: float


def _int(value: Any, default: int = 0) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    try:
        return int(value)
    except Exception:
        return int(default)


def _align32(v: int) -> int:
    return align_to(int(v), 32)


def _range_overlap(a: _Range, b: _Range) -> bool:
    return a.storage_id == b.storage_id and a.lo < b.hi and b.lo < a.hi


def _cycle_overlap(a0: float, a1: float, b0: float, b1: float) -> bool:
    return float(a0) < float(b1) and float(b0) < float(a1)


def _storage_ptr(tensor: Any) -> Optional[int]:
    if isinstance(tensor, PhysicalAlias):
        tensor = tensor.tensor
    try:
        return int(tensor.untyped_storage().data_ptr())
    except Exception:
        return None


def _tensor_elem_size(tensor: Any) -> int:
    if isinstance(tensor, PhysicalAlias):
        tensor = tensor.logical_tensor()
    try:
        return int(tensor.element_size())
    except Exception:
        return 1


def _tensor_num_bytes(tensor: Any) -> int:
    if isinstance(tensor, PhysicalAlias):
        tensor = tensor.logical_tensor()
    try:
        return int(tensor.numel()) * _tensor_elem_size(tensor)
    except Exception:
        return 0


def _local_bank_for_tensor(memory_store: Any, tensor: Any) -> Optional[Tuple[str, int]]:
    ptr = _storage_ptr(tensor)
    if ptr is None:
        return None
    blocks = getattr(memory_store, "_local_bank_blocks", {})
    if not isinstance(blocks, dict):
        return None
    for bank_name, block in blocks.items():
        if not isinstance(block, dict):
            continue
        bank_tensor = block.get("tensor")
        if bank_tensor is None:
            continue
        if _storage_ptr(bank_tensor) == ptr:
            return str(bank_name), ptr
    return None


def _is_local_spec(memory_store: Any, name: str) -> bool:
    specs = getattr(memory_store, "specs", {})
    spec = specs.get(name) if isinstance(specs, dict) else None
    if spec is None:
        return False
    return str(getattr(spec, "role", "")).lower() in _LOCAL_ROLES


def _logical_offset(memory_store: Any, name: str, tensor: Any, explicit: Optional[int] = None) -> int:
    if explicit is not None:
        return int(explicit)
    if isinstance(tensor, PhysicalAlias) and tensor.logical_offset_bytes is not None:
        return int(tensor.logical_offset_bytes)
    fn = getattr(memory_store, "logical_offset_bytes", None)
    if callable(fn):
        value = fn(name)
        if value is not None:
            return int(value)
    if isinstance(tensor, PhysicalAlias):
        tensor = tensor.logical_tensor()
    try:
        return int(tensor.storage_offset()) * _tensor_elem_size(tensor)
    except Exception:
        return 0


def _range_from_tensor(
    memory_store: Any,
    name: str,
    tensor: Any,
    offset_bytes: int = 0,
    size_bytes: Optional[int] = None,
    logical_offset_bytes: Optional[int] = None,
) -> Optional[_Range]:
    logical_tensor = tensor.logical_tensor() if isinstance(tensor, PhysicalAlias) else tensor
    bank_tensor = tensor.tensor if isinstance(tensor, PhysicalAlias) else tensor
    bank = _local_bank_for_tensor(memory_store, bank_tensor)
    if bank is None:
        return None
    if size_bytes is None:
        size_bytes = _tensor_num_bytes(logical_tensor)
    size = int(size_bytes or 0)
    if size <= 0:
        return None
    base = _logical_offset(memory_store, name, tensor, logical_offset_bytes)
    lo = int(base) + int(offset_bytes)
    return _Range(storage_id=bank[1], bank=bank[0], lo=lo, hi=lo + size, tensor=str(name))


def _range_from_name(
    memory_store: Any,
    name: Any,
    offset_bytes: int = 0,
    size_bytes: Optional[int] = None,
) -> Optional[_Range]:
    if not isinstance(name, str) or not name:
        return None
    if not callable(getattr(memory_store, "contains", None)) or not memory_store.contains(name):
        return None
    tensor = memory_store.tensor(name)
    rng = _range_from_tensor(memory_store, name, tensor, offset_bytes, size_bytes)
    if rng is not None:
        return rng
    # Exact non-view local tensors may not have created their local-bank block yet
    # in unusual direct tests. In normal kernel runs allocation happens before
    # pipe launch; keep this role guard as a conservative fallback.
    if not _is_local_spec(memory_store, name):
        return None
    return None


def _slice_source_name(name: str) -> Optional[str]:
    import re

    match = re.search(r"@(.+):-?\d+,-?\d+:-?\d+,-?\d+$", str(name))
    if match is None:
        return None
    return str(match.group(1))


def _spec_role(memory_store: Any, name: str) -> str:
    specs = getattr(memory_store, "specs", {})
    spec = specs.get(name) if isinstance(specs, dict) else None
    return str(getattr(spec, "role", "")).lower() if spec is not None else ""


def _spec_shape(memory_store: Any, name: str) -> Tuple[int, ...]:
    specs = getattr(memory_store, "specs", {})
    spec = specs.get(name) if isinstance(specs, dict) else None
    shape = getattr(spec, "shape", ()) if spec is not None else ()
    try:
        return tuple(int(v) for v in shape)
    except Exception:
        return ()


def _packed_slice_ranges(memory_store: Any, name: str) -> List[_Range]:
    suffix = local_slice_suffix(str(name))
    if suffix is None:
        return []
    row0, col0, rows, cols = suffix
    if rows <= 0 or cols <= 0:
        return []
    source_name = _slice_source_name(str(name)) or str(name)
    if not callable(getattr(memory_store, "contains", None)) or not memory_store.contains(source_name):
        return []
    role = _spec_role(memory_store, source_name)
    if role not in ("l1", "l0a", "l0b", "l0c"):
        return []
    tensor = memory_store.tensor(source_name)
    bank = _local_bank_for_tensor(memory_store, tensor)
    if bank is None:
        return []
    elem = _tensor_elem_size(tensor)
    c0 = 16 if role == "l0c" else 32 // max(elem, 1)
    shape = _spec_shape(memory_store, source_name)
    # A rank-1 spec is a flattened reinterpret view; its length is NOT the NZ
    # row count, and using it as the block stride fabricates ranges far past
    # the tensor.  Fall back to the slice's own row extent.
    m_src = int(shape[0]) if len(shape) >= 2 else row0 + rows
    stride_m = align16(m_src)
    base = _logical_offset(memory_store, source_name, tensor)
    ranges: List[_Range] = []
    src_col = 0
    while src_col < cols:
        dst_col = col0 + src_col
        block = dst_col // c0
        within = dst_col % c0
        block_cols = min(c0 - within, cols - src_col)
        off_elems = block * stride_m * c0 + row0 * c0 + within
        size_elems = (rows - 1) * c0 + block_cols
        ranges.append(
            _Range(
                storage_id=bank[1],
                bank=bank[0],
                lo=base + off_elems * elem,
                hi=base + (off_elems + size_elems) * elem,
                tensor=str(name),
            )
        )
        src_col += block_cols
    return ranges


def _ranges_from_name(
    memory_store: Any,
    name: Any,
    offset_bytes: int = 0,
    size_bytes: Optional[int] = None,
) -> List[_Range]:
    if isinstance(name, str) and offset_bytes == 0:
        packed = _packed_slice_ranges(memory_store, name)
        if packed:
            return packed
    rng = _range_from_name(memory_store, name, offset_bytes, size_bytes)
    return [] if rng is None else [rng]


def _add_access(
    accesses: List[_Access],
    memory_store: Any,
    kind: str,
    name: Any,
    offset_bytes: int = 0,
    size_bytes: Optional[int] = None,
) -> None:
    for rng in _ranges_from_name(memory_store, name, offset_bytes, size_bytes):
        accesses.append(_Access(kind=kind, rng=rng))


def _add_burst_access(
    accesses: List[_Access],
    memory_store: Any,
    kind: str,
    name: Any,
    n_burst: int,
    chunk_bytes: int,
    step_bytes: int,
) -> None:
    if n_burst <= 0 or chunk_bytes <= 0:
        return
    for i in range(int(n_burst)):
        _add_access(accesses, memory_store, kind, name, int(i) * int(step_bytes), int(chunk_bytes))


def _add_micro_accesses(accesses: List[_Access], memory_store: Any, task_args: Dict[str, Any]) -> None:
    tensor_views = task_args.get("tensor_views", {})
    tensor_offsets = task_args.get("tensor_offsets_bytes", {})
    if not isinstance(tensor_views, dict):
        return
    if not isinstance(tensor_offsets, dict):
        tensor_offsets = {}
    for formal_name, tensor in tensor_views.items():
        name = str(formal_name)
        logical = tensor_offsets.get(name)
        logical_offset = None
        if isinstance(tensor, PhysicalAlias) and tensor.logical_offset_bytes is not None:
            logical_offset = int(tensor.logical_offset_bytes)
        elif isinstance(logical, (int, float)):
            logical_offset = int(logical)
        rng = _range_from_tensor(memory_store, name, tensor, logical_offset_bytes=logical_offset)
        if rng is None:
            continue
        # VF signatures do not currently expose read/write intent to the pipe
        # dispatcher. Treat each local tensor operand as both sides so the
        # ownership checker catches producer reuse while a paired consumer is
        # still active.
        accesses.append(_Access(kind="read", rng=rng))
        accesses.append(_Access(kind="write", rng=rng))


def _add_full_tensor_args(
    accesses: List[_Access],
    memory_store: Any,
    args: Dict[str, Any],
    read_keys: Tuple[str, ...],
    write_keys: Tuple[str, ...],
) -> None:
    for key in read_keys:
        _add_access(accesses, memory_store, "read", args.get(key))
    for key in write_keys:
        _add_access(accesses, memory_store, "write", args.get(key))


def task_memory_accesses(task: Any, memory_store: Any) -> List[_Access]:
    args = task.args if isinstance(getattr(task, "args", None), dict) else {}
    op = str(getattr(task, "opname", ""))
    pipe = str(getattr(task, "pipe_name", ""))
    accesses: List[_Access] = []

    if op == "call_micro":
        _add_micro_accesses(accesses, memory_store, args)
        return accesses

    if op == "call_simt":
        # SIMT bodies are ordinary local-memory consumers/producers from the
        # simulator pipe's point of view, but the lowered body does not expose
        # a cheap static read/write set here. Approximate tensor operands as
        # both to keep the checker conservative when explicitly enabled.
        tensor_views = args.get("tensor_views", {})
        if isinstance(tensor_views, dict):
            for name, tensor in tensor_views.items():
                rng = _range_from_tensor(memory_store, str(name), tensor)
                if rng is not None:
                    accesses.append(_Access(kind="read", rng=rng))
                    accesses.append(_Access(kind="write", rng=rng))
        return accesses

    if op == "gm_to_ub_pad":
        burst_len = _int(args.get("burst_len_byte"))
        aligned = _align32(burst_len)
        step = aligned + _int(args.get("dst_stride")) * 32
        _add_burst_access(accesses, memory_store, "write", args.get("dst"), _int(args.get("n_burst")), aligned, step)
        return accesses

    if op == "gm_to_ub_nd_dma":
        dst = args.get("dst")
        dst_tensor = memory_store.tensor(dst) if isinstance(dst, str) and memory_store.contains(dst) else None
        if dst_tensor is None:
            return accesses
        dim = _int(args.get("dim"))
        loop_size = tuple(_int(v) for v in args.get("loop_size", ()))
        loop_dst_stride = tuple(_int(v) for v in args.get("loop_dst_stride", ()))
        loop_left_pad = tuple(_int(v) for v in args.get("loop_left_pad", (0,) * dim))
        loop_right_pad = tuple(_int(v) for v in args.get("loop_right_pad", (0,) * dim))
        config_left_pad = args.get("config_left_pad", None)
        config_right_pad = args.get("config_right_pad", None)
        effective_left_pad = tuple(
            _int(config_left_pad) if config_left_pad is not None else loop_left_pad[idx]
            for idx in range(dim)
        )
        effective_right_pad = tuple(
            _int(config_right_pad) if config_right_pad is not None else loop_right_pad[idx]
            for idx in range(dim)
        )
        total_sizes = [loop_size[idx] + effective_left_pad[idx] + effective_right_pad[idx] for idx in range(dim)]
        if not total_sizes or any(size <= 0 for size in total_sizes):
            return accesses
        max_element_offset = sum((total_sizes[idx] - 1) * loop_dst_stride[idx] for idx in range(dim))
        _add_access(accesses, memory_store, "write", dst, 0, (max_element_offset + 1) * _tensor_elem_size(dst_tensor))
        return accesses

    if op == "ub_to_gm_pad":
        burst_len = _int(args.get("burst_len_byte"))
        aligned = _align32(burst_len)
        step = aligned + _int(args.get("src_stride")) * 32
        _add_burst_access(accesses, memory_store, "read", args.get("src"), _int(args.get("n_burst")), burst_len, step)
        return accesses

    if op == "gm_to_l1_pad":
        burst_len = _int(args.get("burst_len_byte"))
        aligned = _align32(burst_len)
        step = aligned + _int(args.get("dst_stride")) * 32
        _add_burst_access(accesses, memory_store, "write", args.get("dst"), _int(args.get("n_burst")), aligned, step)
        return accesses

    if op == "gm_to_l1":
        # Plain DataCopy burst: burst_len / strides are in 32-byte block units.
        n_burst = _int(args.get("n_burst"))
        burst_bytes = _int(args.get("burst_len")) * 32
        src_step = (_int(args.get("burst_len")) + _int(args.get("src_stride"))) * 32
        dst_step = (_int(args.get("burst_len")) + _int(args.get("dst_stride"))) * 32
        _add_burst_access(accesses, memory_store, "read", args.get("src"), n_burst, burst_bytes, src_step)
        _add_burst_access(accesses, memory_store, "write", args.get("dst"), n_burst, burst_bytes, dst_step)
        return accesses

    if op in ("gm_to_l1_nd2nz", "gm_to_l1_dn2nz", "gm_to_l1_mx_scale_nd2nz"):
        dst = args.get("dst")
        dst_tensor = memory_store.tensor(dst) if isinstance(dst, str) and memory_store.contains(dst) else None
        if dst_tensor is None:
            return accesses
        elem = _tensor_elem_size(dst_tensor)
        m = _int(args.get("M"))
        n = _int(args.get("N"))
        m_dst = _int(args.get("M_dst", m), m)
        stride_m = align16(m_dst)
        c0 = 32 // max(elem, 1)
        size = nz_footprint(n, stride_m, c0) * elem
        _add_access(accesses, memory_store, "write", dst, 0, size)
        return accesses

    if op == "set_constant_to_l1":
        name = args.get("tensor", args.get("dst"))
        tensor = memory_store.tensor(name) if isinstance(name, str) and memory_store.contains(name) else None
        if tensor is None:
            return accesses
        c0 = 32 // max(_tensor_elem_size(tensor), 1)
        _add_access(accesses, memory_store, "write", name, 0, _int(args.get("n_blocks")) * c0 * _tensor_elem_size(tensor))
        return accesses

    if op == "ub_to_l1":
        burst_bytes = _int(args.get("burst_len")) * 32
        src_step = (_int(args.get("burst_len")) + _int(args.get("src_stride"))) * 32
        dst_step = (_int(args.get("burst_len")) + _int(args.get("dst_stride"))) * 32
        n_burst = _int(args.get("n_burst"))
        _add_burst_access(accesses, memory_store, "read", args.get("src"), n_burst, burst_bytes, src_step)
        _add_burst_access(accesses, memory_store, "write", args.get("dst"), n_burst, burst_bytes, dst_step)
        return accesses

    if op in ("ub_to_l1_nd2nz", "ub_to_l1_nz"):
        src = args.get("src")
        dst = args.get("dst")
        src_tensor = memory_store.tensor(src) if isinstance(src, str) and memory_store.contains(src) else None
        dst_tensor = memory_store.tensor(dst) if isinstance(dst, str) and memory_store.contains(dst) else None
        m_src = _int(args.get("m_src"))
        n_src = _int(args.get("n_src"))
        if src_tensor is not None:
            elem = _tensor_elem_size(src_tensor)
            n_full = _int(args.get("N_src", n_src), n_src)
            for r in range(max(m_src, 0)):
                _add_access(accesses, memory_store, "read", src, r * n_full * elem, n_src * elem)
        if dst_tensor is not None:
            elem = _tensor_elem_size(dst_tensor)
            m_dst = _int(args.get("m_dst"))
            dst_row0 = _int(args.get("dst_row0"))
            c0 = 32 // max(elem, 1)
            size = nz_tail_write_footprint(n_src, dst_row0, m_src, align16(m_dst), c0) * elem
            _add_access(accesses, memory_store, "write", dst, 0, size)
        return accesses

    if op in ("l1_to_l0", "l1_to_l0_mx", "l1_to_l0_img2col", "l1_to_bt"):
        _add_full_tensor_args(accesses, memory_store, args, ("src", "src_mx"), ("dst",))
        return accesses

    if op in ("mmad", "mmad_mx"):
        _add_full_tensor_args(accesses, memory_store, args, ("src_a", "src_b", "bias"), ("dst",))
        return accesses

    if op == "l0c_to_gm_nz2nd":
        src = args.get("src")
        if isinstance(src, str) and local_slice_suffix(src) is not None:
            _add_access(accesses, memory_store, "read", src)
        else:
            contains = getattr(memory_store, "contains", None)
            tensor = memory_store.tensor(src) if isinstance(src, str) and callable(contains) and contains(src) else None
            elem = _tensor_elem_size(tensor) if tensor is not None else 1
            n = _int(args.get("N"))
            m_src = _int(args.get("M_src"))
            size = nz_footprint(n, align16(m_src), 16) * elem
            _add_access(accesses, memory_store, "read", src, 0, size)
        return accesses

    if op == "l0c_to_gm_nz2nz":
        _add_access(accesses, memory_store, "read", args.get("src"))
        n = _int(args.get("N"))
        m = _int(args.get("M"))
        m_pad = _int(args.get("M_pad"))
        dst = args.get("dst")
        contains = getattr(memory_store, "contains", None)
        tensor = memory_store.tensor(dst) if isinstance(dst, str) and callable(contains) and contains(dst) else None
        elem = _tensor_elem_size(tensor) if tensor is not None else 4
        c0g = max(16, 32 // max(elem, 1))   # dst C0: 16 (>=2B) or 32 (8-bit)
        size = ((max(n // c0g, 1) - 1) * m_pad + m) * c0g * elem  # strips m_pad rows apart
        _add_access(accesses, memory_store, "write", dst, 0, size)
        return accesses

    if op == "l0c_to_gm_nz2dn":
        src = args.get("src")
        if isinstance(src, str) and local_slice_suffix(src) is not None:
            _add_access(accesses, memory_store, "read", src)
        else:
            contains = getattr(memory_store, "contains", None)
            tensor = memory_store.tensor(src) if isinstance(src, str) and callable(contains) and contains(src) else None
            elem = _tensor_elem_size(tensor) if tensor is not None else 1
            n = _int(args.get("N"))
            m_src = _int(args.get("M_src"))
            size = nz_footprint(n, align16(m_src), 16) * elem
            _add_access(accesses, memory_store, "read", src, 0, size)
        # transposed [n, m] dst: n rows of m elements, rows m_dst apart.
        n = _int(args.get("N"))
        m = _int(args.get("M"))
        m_dst = _int(args.get("M_dst"))
        dst = args.get("dst")
        contains = getattr(memory_store, "contains", None)
        tensor = memory_store.tensor(dst) if isinstance(dst, str) and callable(contains) and contains(dst) else None
        elem = _tensor_elem_size(tensor) if tensor is not None else 4
        size = (max(n - 1, 0) * m_dst + m) * elem
        _add_access(accesses, memory_store, "write", dst, 0, size)
        return accesses

    if op == "l0c_to_l1":
        _add_full_tensor_args(accesses, memory_store, args, ("src",), ("dst",))
        return accesses

    if op == "l0c_to_ub":
        _add_access(accesses, memory_store, "read", args.get("src"))
        for key in ("dst", "dst_vec0", "dst_vec1"):
            _add_access(accesses, memory_store, "write", args.get(key))
        return accesses

    if op == "ub_to_ub":
        _add_full_tensor_args(accesses, memory_store, args, ("src",), ("dst",))
        return accesses

    if op == "transdata5hd":
        # 16 strided rows on each side: row i covers [(i*row_stride .. + rep span)].
        src = args.get("src")
        dst = args.get("dst")
        contains = getattr(memory_store, "contains", None)
        tensor = memory_store.tensor(src) if isinstance(src, str) and callable(contains) and contains(src) else None
        elem = _tensor_elem_size(tensor) if tensor is not None else 2
        repeat = max(_int(args.get("repeat"), 1), 1)
        srs = _int(args.get("src_row_stride"))
        drs = _int(args.get("dst_row_stride"), 16)
        srep = _int(args.get("src_rep_stride"), 1)
        drep = _int(args.get("dst_rep_stride"), 16)
        src_span = ((repeat - 1) * srep * 16 + 16) * elem
        dst_span = ((repeat - 1) * drep * 16 + 16) * elem
        for i in range(16):
            _add_access(accesses, memory_store, "read", src, i * srs * elem, src_span)
            _add_access(accesses, memory_store, "write", dst, i * drs * elem, dst_span)
        return accesses

    if pipe == "V":
        read_keys = ("src", "src1", "src2")
        write_keys = ("dst",)
        _add_full_tensor_args(accesses, memory_store, args, read_keys, write_keys)
        if op in ("axpy", "muladddst"):
            _add_access(accesses, memory_store, "read", args.get("dst"))
        return accesses

    return accesses


def _merge_accesses(accesses: List[_Access]) -> List[_Access]:
    if len(accesses) <= 1:
        return accesses
    groups: Dict[Tuple[str, int, str], List[_Range]] = {}
    for access in accesses:
        key = (access.kind, access.rng.storage_id, access.rng.bank)
        groups.setdefault(key, []).append(access.rng)

    merged: List[_Access] = []
    for (kind, _storage_id, _bank), ranges in groups.items():
        ordered = sorted(ranges, key=lambda r: (r.lo, r.hi))
        cur = ordered[0]
        merged_names = 1
        for rng in ordered[1:]:
            if rng.lo <= cur.hi:
                cur = _Range(
                    storage_id=cur.storage_id,
                    bank=cur.bank,
                    lo=cur.lo,
                    hi=max(cur.hi, rng.hi),
                    tensor=cur.tensor,
                )
                merged_names += 1
                continue
            label = cur.tensor if merged_names == 1 else cur.tensor + "+"
            merged.append(_Access(kind=kind, rng=_Range(
                storage_id=cur.storage_id, bank=cur.bank, lo=cur.lo, hi=cur.hi, tensor=label,
            )))
            cur = rng
            merged_names = 1
        label = cur.tensor if merged_names == 1 else cur.tensor + "+"
        merged.append(_Access(kind=kind, rng=_Range(
            storage_id=cur.storage_id, bank=cur.bank, lo=cur.lo, hi=cur.hi, tensor=label,
        )))
    return merged


def _bank_is_ub(rec: _Record) -> bool:
    return rec.access.rng.bank.startswith("UB")


def _bank_is_l1(rec: _Record) -> bool:
    return rec.access.rng.bank == "L1"


def _is_v_ub_producer(rec: _Record) -> bool:
    return rec.pipe_name == "V" and rec.access.kind == "write" and _bank_is_ub(rec)


def _is_mte3_ub_consumer(rec: _Record) -> bool:
    return rec.pipe_name == "MTE3" and rec.access.kind == "read" and _bank_is_ub(rec)


def _is_mte3_l1_producer(rec: _Record) -> bool:
    return rec.pipe_name == "MTE3" and rec.access.kind == "write" and _bank_is_l1(rec)


def _is_mte2_l1_producer(rec: _Record) -> bool:
    return rec.pipe_name == "MTE2" and rec.access.kind == "write" and _bank_is_l1(rec)


def _is_mte1_l1_consumer(rec: _Record) -> bool:
    return rec.pipe_name == "MTE1" and rec.access.kind == "read" and _bank_is_l1(rec)


_L1_DMA_WRITE_OPS = frozenset([
    "gm_to_l1", "gm_to_l1_pad", "gm_to_l1_nd2nz", "gm_to_l1_dn2nz",
    "gm_to_l1_mx_scale_nd2nz",
    "ub_to_l1", "ub_to_l1_nd2nz", "ub_to_l1_nz",
])


def _is_l1_fill(rec: _Record) -> bool:
    return (rec.opname == "set_constant_to_l1"
            and rec.access.kind == "write" and _bank_is_l1(rec))


def _is_l1_dma_write(rec: _Record) -> bool:
    return (rec.opname in _L1_DMA_WRITE_OPS
            and rec.access.kind == "write" and _bank_is_l1(rec))


def _is_fix_ub_producer(rec: _Record) -> bool:
    return rec.pipe_name == "FIX" and rec.access.kind == "write" and _bank_is_ub(rec)


def _is_v_ub_consumer(rec: _Record) -> bool:
    return rec.pipe_name == "V" and _bank_is_ub(rec)


def _match_pair(
    name: str,
    producer_pred: Any,
    consumer_pred: Any,
    prev: _Record,
    curr: _Record,
) -> Optional[str]:
    if producer_pred(prev) and consumer_pred(curr):
        return name
    if consumer_pred(prev) and producer_pred(curr):
        return name
    return None


def _ownership_pair(prev: _Record, curr: _Record) -> Optional[str]:
    for name, producer_pred, consumer_pred in (
        ("UB V->MTE3", _is_v_ub_producer, _is_mte3_ub_consumer),
        ("L1 MTE3->MTE1", _is_mte3_l1_producer, _is_mte1_l1_consumer),
        # The GM -> L1 side of the same ownership edge. An nd2nz or an
        # InitConstValue that overwrites a staging tile while the previous
        # tile's L1 -> L0 relay is still reading it corrupts the operand on
        # hardware, and without this pair nothing on the vector side reports it.
        ("L1 MTE2->MTE1", _is_mte2_l1_producer, _is_mte1_l1_consumer),
        ("UB FIX->V", _is_fix_ub_producer, _is_v_ub_consumer),
    ):
        match = _match_pair(name, producer_pred, consumer_pred, prev, curr)
        if match is not None:
            return match
    return None


class LocalMemoryHazardTracker:
    def __init__(
        self,
        mode: str = "off",
        memory_cycle_scale: float = 1.0,
    ) -> None:
        self.mode = str(mode or "off").lower()
        self.memory_cycle_scale = max(1.0, float(memory_cycle_scale))
        self._records: List[_Record] = []
        # set_constant_to_l1 is nominally the same pipe as the L1 DMAs, so the
        # per-pipe program order would make it look ordered.  On the A5 board it
        # is not: the fill can retire after a gm_to_l1_* into the same tile and
        # wipe rows the DMA already landed.  These records therefore survive
        # until an explicit barrier rather than until their cycles have passed.
        self._l1_fills: Dict[Tuple[int, str, int, int, int], _Record] = {}
        self._lock = threading.Lock()

    def enabled(self) -> bool:
        return self.mode in ("warn", "error")

    def note_barrier(self, core_idx: int, lane_name: str) -> None:
        """A bar_all retires every outstanding L1 fill on that lane."""
        if not self.enabled():
            return
        with self._lock:
            for key in [
                key for key in self._l1_fills
                if key[0] == int(core_idx) and key[1] == str(lane_name)
            ]:
                del self._l1_fills[key]

    def scale_task_cycles(self, task: Any, cycles: float) -> float:
        if str(getattr(task, "opname", "")) not in _MEMORY_CYCLE_SCALE_OPS:
            return float(cycles)
        return float(cycles) * self.memory_cycle_scale

    def check_task(
        self,
        core_idx: int,
        lane_name: str,
        pipe_name: str,
        task: Any,
        memory_store: Any,
        start_cycle: float,
        end_cycle: float,
    ) -> None:
        if not self.enabled():
            return
        accesses = _merge_accesses(task_memory_accesses(task, memory_store))
        if not accesses:
            return
        start = float(start_cycle)
        end = float(end_cycle)
        if end <= start:
            return

        current_records = [
            _Record(
                access=access,
                core_idx=int(core_idx),
                lane_name=str(lane_name),
                pipe_name=str(pipe_name),
                opname=str(getattr(task, "opname", "")),
                start_cycle=start,
                end_cycle=end,
            )
            for access in accesses
        ]

        with self._lock:
            self._records = [rec for rec in self._records if rec.end_cycle > start]
            for prev in self._records:
                for curr in current_records:
                    if not _range_overlap(prev.access.rng, curr.access.rng):
                        continue
                    hazard_kind = self._classify(prev, curr)
                    if hazard_kind:
                        self._report(hazard_kind, prev, curr)
                        if self.mode == "error":
                            return
            for key, prev in list(self._l1_fills.items()):
                if key[0] != int(core_idx) or key[1] != str(lane_name):
                    continue
                for curr in current_records:
                    if not _is_l1_dma_write(curr):
                        continue
                    if not _range_overlap(prev.access.rng, curr.access.rng):
                        continue
                    self._report("L1 fill vs DMA", prev, curr)
                    if self.mode == "error":
                        return
            self._records.extend(current_records)
            # Keyed rather than appended: a fill inside a loop re-clears the
            # same tile every iteration, and one record per distinct region
            # says everything the repeats would.
            for rec in current_records:
                if _is_l1_fill(rec):
                    rng = rec.access.rng
                    self._l1_fills[(
                        rec.core_idx, rec.lane_name,
                        rng.storage_id, rng.lo, rng.hi,
                    )] = rec

    def _classify(self, prev: _Record, curr: _Record) -> str:
        pair = _ownership_pair(prev, curr)
        if pair is None:
            return ""
        if _cycle_overlap(prev.start_cycle, prev.end_cycle, curr.start_cycle, curr.end_cycle):
            return pair
        return ""

    def _report(self, hazard_kind: str, prev: _Record, curr: _Record) -> None:
        overlap_lo = max(prev.access.rng.lo, curr.access.rng.lo)
        overlap_hi = min(prev.access.rng.hi, curr.access.rng.hi)
        message = (
            "local memory " + hazard_kind + " hazard on core " + str(curr.core_idx)
            + " bank " + curr.access.rng.bank
            + " bytes [" + str(overlap_lo) + ", " + str(overlap_hi) + ")\n"
            + "  previous " + prev.access.kind + ": "
            + prev.lane_name + "/" + prev.pipe_name + " " + prev.opname
            + " tensor=" + prev.access.rng.tensor
            + " cycles=[" + ("%.1f" % prev.start_cycle) + ", " + ("%.1f" % prev.end_cycle) + ")\n"
            + "  current " + curr.access.kind + ": "
            + curr.lane_name + "/" + curr.pipe_name + " " + curr.opname
            + " tensor=" + curr.access.rng.tensor
            + " cycles=[" + ("%.1f" % curr.start_cycle) + ", " + ("%.1f" % curr.end_cycle) + ")\n"
            + "  fix: add a matching sync edge/barrier or use a non-overlapping DBuff/TBuff/QBuff slot"
        )
        if hazard_kind == "L1 fill vs DMA":
            message += (
                "\n  note: set_constant_to_l1 is not ordered against an L1 DMA"
                " into the same tile on A5, whatever pipe both are issued on."
                " Put bar_all() between them, or drop the fill if the region it"
                " clears never reaches the output."
            )
        if self.mode == "error":
            raise RuntimeError(message)
        warnings.warn(message, UserWarning, stacklevel=3)
