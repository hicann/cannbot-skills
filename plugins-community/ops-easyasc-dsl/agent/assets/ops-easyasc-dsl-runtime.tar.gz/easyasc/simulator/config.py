from __future__ import annotations

import os
from dataclasses import dataclass, field


def _default_execution_timeout_s() -> float:
    """Seconds a core may take to reach the startup barrier and to run.

    The barrier has to be met by every simulated core, so the budget is really
    a budget for the slowest of them.  On a host already running other
    simulations the fork storm alone can eat the default, and the failure --
    "startup barrier timeout after local memory initialization" -- reads like a
    kernel bug rather than contention.  ``EASYASC_SIM_TIMEOUT_S`` raises it
    without touching the source.
    """
    raw = os.environ.get("EASYASC_SIM_TIMEOUT_S", "")
    try:
        value = float(raw)
    except ValueError:
        return 40.0
    return value if value > 0 else 40.0


DEFAULT_EXECUTION_TIMEOUT_S = _default_execution_timeout_s()


def startup_timeout_s(execution_timeout_s: float, core_count: int) -> float:
    """Seconds the one-shot startup barrier may take.

    This is not the execution budget.  The barrier clears only once *every*
    simulated core has been scheduled and has allocated its local memory, so
    what it really measures is how long the host takes to get ``core_count``
    processes running at all.  On a host with fewer physical cores than the
    simulated grid that is a queue, not a stall, and charging it the per-core
    execution budget turns ordinary contention into
    "startup barrier timeout after local memory initialization" -- which reads
    exactly like a kernel deadlock and has cost real debugging time.
    """
    return max(float(execution_timeout_s), 5.0 + 1.5 * max(int(core_count), 1))


def _default_core_count() -> int:
    """Return the default core count from the active simulator device profile."""
    from .. import globvars
    from ..device_profile import core_num_for

    core_num = getattr(globvars, "core_num", None)
    if isinstance(core_num, int) and core_num > 0:
        return core_num

    return core_num_for(getattr(globvars, "device_type", "b3"))


@dataclass
class SimulatorConfig:
    core_count: int = 0
    execution_timeout_s: float = field(
        default_factory=_default_execution_timeout_s)
    process_start_method: str = "auto"
    trace_enabled: bool = False
    queue_maxsize: int = 64
    torch_num_threads: int = 1
    cycle_model_enabled: bool = True
    cycle_profile_path: str = ""
    instruction_head_overhead_cycles: int = 10
    local_memory_hazard_check: str = "off"
    local_memory_hazard_memory_cycle_scale: float = 1.0

    def __post_init__(self) -> None:
        if self.core_count == 0:
            self.core_count = _default_core_count()
        self.instruction_head_overhead_cycles = max(0, int(self.instruction_head_overhead_cycles))
        mode = str(self.local_memory_hazard_check or "off").lower()
        if mode not in ("off", "warn", "error"):
            raise ValueError("local_memory_hazard_check must be one of: off, warn, error")
        self.local_memory_hazard_check = mode
        self.local_memory_hazard_memory_cycle_scale = max(
            1.0,
            float(self.local_memory_hazard_memory_cycle_scale),
        )
