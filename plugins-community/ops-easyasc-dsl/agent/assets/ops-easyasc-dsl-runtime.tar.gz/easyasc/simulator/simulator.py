from __future__ import annotations

import sys
import time
import traceback
from dataclasses import dataclass, field
from multiprocessing.connection import wait as wait_for_connections
from typing import Dict, List, Optional

from .config import SimulatorConfig
from .core import Core, CoreState, _default_pipe_factory
from .memory import SharedMemoryStore, SharedTensorSpec
from .pipe import PipeFactory
from .program import KernelProgram
from .sync import CrossCoreSync, LocalEventBank


def _raise_runtime_error_with_stderr(message: str) -> None:
    try:
        raise RuntimeError(message)
    except RuntimeError:
        traceback.print_exc(file=sys.stderr)
        sys.stderr.flush()
        raise


@dataclass
class Simulator:
    """Top-level simulator coordinator.

    Creates shared memory for GM tensors, creates CrossCoreSync,
    spawns Core processes, waits for completion, collects results.
    """

    config: SimulatorConfig
    memory_store: SharedMemoryStore = field(default_factory=SharedMemoryStore)
    cross_sync: CrossCoreSync = field(init=False)
    cores: List[Core] = field(default_factory=list, init=False)
    pipe_factory: PipeFactory = _default_pipe_factory

    def __post_init__(self) -> None:
        self.cross_sync = CrossCoreSync(core_count=self.config.core_count)

    def run(self, program: KernelProgram) -> None:
        self._prepare(program)
        try:
            self._launch()
            self._wait(program)
        finally:
            self._collect_failures()

    def _prepare(self, program: KernelProgram) -> None:
        self._validate_local_event_budgets(program)
        self.memory_store.clear()
        _SKIP_ROLES = {"l1", "l0a", "l0b", "l0amx", "l0bmx", "l0c", "ub", "bt"}
        for spec in self._extract_specs(program):
            if spec.role in _SKIP_ROLES:
                continue
            self.memory_store.register(spec)
            if spec.source_name:
                continue
            self.memory_store.allocate(spec.name)

        self.cross_sync = CrossCoreSync(core_count=self.config.core_count)
        self.cross_sync.prepare()

        memory_snap = self.memory_store.snapshot()
        sync_snap = self.cross_sync.snapshot()

        self.cores = [
            Core(
                core_idx=i,
                config=self.config,
                program=program,
                memory_snapshot=memory_snap,
                cross_sync_snapshot=sync_snap,
                pipe_factory=self.pipe_factory,
            )
            for i in range(self.config.core_count)
        ]

    @staticmethod
    def _validate_local_event_budgets(program: KernelProgram) -> None:
        """Reject named local-event declarations that cannot fit on hardware."""
        for lane_program in program.lane_programs:
            context = "kernel {!r} lane {!r}".format(program.name, lane_program.lane_name)
            event_bank = LocalEventBank(context=context)
            for inst in lane_program.instructions:
                if inst.opname not in ("create_sevent", "create_devent", "create_tevent", "create_qevent"):
                    continue
                args = inst.args
                event_bank.create_event(
                    name=str(args.get("event_name", "")),
                    event_kind={
                        "create_sevent": "s",
                        "create_devent": "d",
                        "create_tevent": "t",
                        "create_qevent": "q",
                    }[inst.opname],
                    src_pipe=str(args.get("src_pipe", "")),
                    dst_pipe=str(args.get("dst_pipe", "")),
                    preset=False,
                )

    def _launch(self) -> None:
        for core in self.cores:
            core.start()

    def _wait(self, program: KernelProgram) -> None:
        deadline = time.monotonic() + self.config.execution_timeout_s
        while True:
            still_running = []
            for core in self.cores:
                if core.state == CoreState.RUNNING:
                    core.join(timeout=0.0)
                if core.state == CoreState.RUNNING:
                    still_running.append(core)

            if not still_running:
                break

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                for core in still_running:
                    core.join(timeout=0.5)
                still_running = [core for core in self.cores if core.state == CoreState.RUNNING]
                if not still_running:
                    break
                timed_out = [c.core_idx for c in still_running]

                failures = []
                for core in self.cores:
                    if core.failure:
                        failures.append("core " + str(core.core_idx) + ":\n" + core.failure)
                if failures:
                    for c in still_running:
                        c.terminate()
                    _raise_runtime_error_with_stderr("\n\n".join(failures))
                for c in self.cores:
                    c.terminate()
                _raise_runtime_error_with_stderr(
                    "execution timeout after " + str(self.config.execution_timeout_s)
                    + "s, cores still running: " + str(timed_out)
                )

            handles = []
            for core in still_running:
                handles.extend(core.wait_handles())
            if handles:
                wait_for_connections(handles, timeout=remaining)
            else:
                still_running[0].join(timeout=remaining)

    def _collect_failures(self) -> None:
        failures = []
        for core in self.cores:
            if core.state == CoreState.FAILED and core.failure:
                failures.append("core " + str(core.core_idx) + ":\n" + core.failure)
        if failures:
            _raise_runtime_error_with_stderr("\n\n".join(failures))

    def shutdown(self) -> None:
        for core in self.cores:
            core.terminate()
        self.memory_store.clear()

    def collect_trace_events(self) -> List["TraceEvent"]:
        from .trace import TraceEvent, merge_traces

        per_core: List[List[TraceEvent]] = []
        for core in self.cores:
            events = [TraceEvent.from_dict(d) for d in core.trace_events if isinstance(d, dict)]
            per_core.append(events)
        return merge_traces(per_core)

    @staticmethod
    def _extract_specs(program: KernelProgram) -> List[SharedTensorSpec]:
        specs_raw = program.metadata.get("tensor_specs", [])
        result = []
        for item in specs_raw:
            if isinstance(item, SharedTensorSpec):
                result.append(item)
            elif isinstance(item, dict):
                result.append(SharedTensorSpec.from_dict(item))
        return result
