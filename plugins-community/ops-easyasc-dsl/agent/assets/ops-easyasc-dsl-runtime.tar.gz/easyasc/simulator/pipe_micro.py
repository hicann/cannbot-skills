from __future__ import annotations

import re
import sys
import traceback
import warnings
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import torch

from .memory import SharedMemoryStore, normalize_dtype, torch_dtype
from .physical_alias import PhysicalAlias, as_physical_alias
from .cast_rounding import apply_cast_dtype
from .util import byte_storage_offset
from ..dtypehelper.fp4_fp32 import (
    fp32_to_fp4_e1m2,
    fp32_to_fp4_e2m1,
    fp4_e1m2_to_fp32,
    fp4_e2m1_to_fp32,
)
from ..dtypehelper.hif8_codec import fp16_to_hif8, fp32_to_hif8, hif8_to_fp32

_VL_BYTES = 256
_TYPED_LITERAL_RE = re.compile(r"^\([\w]+\)(.+)$")
# The board-validated HC=2 VF has 21 regions; the reproducibly corrupt HC=6
# shape has 61.  Warn from 32 onward so the known failure is not silent while
# keeping the smaller validated form usable without an advisory.
_VF_DYNAMIC_UB_LOOP_WARNING_THRESHOLD = 32


def _torch_dt(dt: Any) -> torch.dtype:
    if isinstance(dt, torch.dtype):
        return dt
    try:
        return torch_dtype(dt)
    except Exception:
        print(
            "[simulator] _torch_dt fallback: dt=%r\n%s"
            % (dt, traceback.format_exc()),
            file=sys.stderr, flush=True,
        )
    name = str(dt)
    mapping = {
        "half": torch.float16, "float": torch.float32,
        "int8_t": torch.int8, "uint8_t": torch.uint8,
        "int16_t": torch.int16, "int": torch.int32, "int32_t": torch.int32,
        "uint32_t": torch.int32, "int64_t": torch.int64,
        "uint64_t": getattr(torch, "uint64", torch.int64),
        "bfloat16_t": torch.bfloat16,
        "complex64": torch.complex64,
        "complex32": getattr(torch, "complex32", torch.complex64),
        # A RegTensor<fp4x2_*> physically holds packed uint8 carriers. The
        # custom cast handler below preserves its two-nibbles-per-byte logic.
        "fp4x2_e2m1_t": torch.uint8, "fp4x2_e1m2_t": torch.uint8,
    }
    if name in mapping:
        return mapping[name]
    if hasattr(torch, name):
        v = getattr(torch, name)
        if isinstance(v, torch.dtype):
            return v
    raise TypeError("cannot resolve dtype: " + repr(dt))


def _lanes(dt: torch.dtype) -> int:
    return _VL_BYTES // dt.itemsize


_UNSIGNED_TORCH_DTYPES = tuple(
    d for d in (
        torch.uint8,
        getattr(torch, "uint16", None),
        getattr(torch, "uint32", None),
        getattr(torch, "uint64", None),
    ) if d is not None
)


def _is_torch_unsigned(dt: torch.dtype) -> bool:
    return dt in _UNSIGNED_TORCH_DTYPES


def _is_normal_power_of_two_division(
    numerator: torch.Tensor, denominator: torch.Tensor,
) -> bool:
    """Return whether fp32 division is only a normal exponent shift.

    A5's approximate intrinsic cannot introduce a quotient error when every
    denominator is an exact power of two and the finite input/output values
    stay outside the subnormal domain.  ROIAlign intentionally relies on this
    for fixed sampling ratios 1/2 and sample counts 1/4.
    """
    lhs = numerator.float()
    rhs = denominator.float()
    quotient = lhs / rhs
    tiny = torch.finfo(torch.float32).tiny
    rhs_bits = rhs.abs().contiguous().view(torch.int32)
    rhs_is_normal_power_of_two = (
        ((rhs_bits & 0x007FFFFF) == 0)
        & ((rhs_bits & 0x7F800000) != 0)
        & ((rhs_bits & 0x7F800000) != 0x7F800000)
    )

    def normal_or_zero(value: torch.Tensor) -> torch.Tensor:
        return torch.isfinite(value) & (
            (value == 0) | (value.abs() >= tiny)
        )

    return bool(torch.all(
        rhs_is_normal_power_of_two
        & normal_or_zero(lhs)
        & normal_or_zero(quotient)
    ).item())


_WIDE_UNSIGNED_TO_SIGNED = {
    d: s for d, s in (
        (getattr(torch, "uint16", None), torch.int16),
        (getattr(torch, "uint32", None), torch.int32),
        (getattr(torch, "uint64", None), torch.int64),
    ) if d is not None
}


def _index_assign(dst: torch.Tensor, index, values: torch.Tensor) -> None:
    """``dst[index] = values`` that also works for uint16/uint32/uint64.

    torch CPU implements no ``index_put`` kernel for the wide unsigned dtypes, so a
    plain subscript assignment raises ``NotImplementedError`` in the simulator even
    though the generated MicroAPI code is fine on the board. The bit pattern is what
    matters here, so route the store through the same-width signed view.
    """
    signed = _WIDE_UNSIGNED_TO_SIGNED.get(dst.dtype)
    if signed is None:
        dst[index] = values
        return
    src = values if values.dtype == dst.dtype else values.to(dst.dtype)
    dst.view(signed)[index] = src.view(signed)


# Unary micro ops whose result must stay in the source integer dtype instead of
# routing through fp32: fp32 drops bits above 2**24 for b32/b64 integers and so
# diverges from the generated MicroAPI integer instruction / cannsim / hardware.
_INTEGER_UNARY_OPS = ("micro_vabs", "micro_vneg", "micro_vrelu", "micro_vcopy")


def _round_scalar_to_reg_dtype(value: float, dt: torch.dtype) -> float:
    """Round a scalar immediate to a register's precision, mirroring hardware.

    A reduced-precision vector register applies a scalar immediate at the register's
    own precision: a half `muls`/`adds` rounds the immediate to half before the op
    (half*half->half). The simulator otherwise keeps the full fp32 immediate, which
    diverges from cannsim/HW whenever the immediate is not exactly representable in
    the register dtype (e.g. SOFTMAX_SCALE = 1/sqrt(128) = 0.08838834764, nearest
    half 0.08837890625, rel diff ~1e-4). See a5-half-muls-sim-cannsim-divergence.
    """
    if dt in (torch.float16, torch.bfloat16):
        return float(torch.tensor(value, dtype=dt).item())
    return value


def _logical_dtype_name(ref: Any, fallback: Optional[torch.Tensor] = None) -> str:
    if hasattr(ref, "dtype"):
        return normalize_dtype(getattr(ref, "dtype"))
    if hasattr(ref, "name"):
        return normalize_dtype(getattr(ref, "name"))
    if fallback is not None:
        return normalize_dtype(fallback.dtype)
    return normalize_dtype(_torch_dt(ref))


def _is_fp4_logical_dtype(name: str) -> bool:
    return name in ("fp4_e2m1", "fp4_e1m2")


def _var_dtype_category(dtype: Any) -> Optional[str]:
    if dtype is None:
        return None
    name = str(dtype)
    if name in ("half", "float", "bfloat16_t") or "float" in name:
        return "float"
    if name == "int" or name.startswith("int") or name.startswith("uint"):
        return "int"
    return None


_MODE_ELEM_MAP = {
    "DIST_UNPACK_B8": 1, "DIST_UNPACK_B16": 2, "DIST_UNPACK_B32": 4,
    "DIST_UNPACK4_B8": 1, "DIST_UNPACK4_B16": 2, "DIST_UNPACK4_B32": 4,
    "DIST_US_B8": 1, "DIST_US_B16": 2,
    "DIST_DS_B8": 1, "DIST_DS_B16": 2,
    "DIST_PACK_B16": 1, "DIST_PACK_B32": 2, "DIST_PACK_B64": 4,
    "DIST_PACK4_B32": 1,
    "DIST_NORM_B8": 1, "DIST_NORM_B16": 2, "DIST_NORM_B32": 4,
    "DIST_DINTLV_B8": 1, "DIST_DINTLV_B16": 2, "DIST_DINTLV_B32": 4,
    "DIST_INTLV_B8": 1, "DIST_INTLV_B16": 2, "DIST_INTLV_B32": 4,
}


class VfBarrierWarning(UserWarning):
    """Advisory warning for missing VF ordering barriers on overlapping ranges."""


class VfPublicationWarning(UserWarning):
    """Warn when synchronous simulation can hide an A5 VF publication hazard."""


class LogicalViewAdvisoryWarning(UserWarning):
    """Advisory warning for pointer-style accesses that exceed only the logical view.

    The physical backing storage may still be large enough, so execution can
    continue, but the behavior relies on logical densification or extra padding
    not guaranteed by hardware.
    """


class MicroDivPrecisionWarning(UserWarning):
    """Warn when CPU division hides A5's approximate intrinsic rounding."""


def _effective_byte_offset(
    tensor: torch.Tensor,
    elem_offset: int = 0,
    logical_offset_bytes: Optional[int] = None,
) -> int:
    if logical_offset_bytes is None:
        return byte_storage_offset(tensor) + int(elem_offset) * int(tensor.element_size())
    return int(logical_offset_bytes) + int(elem_offset) * int(tensor.element_size())


def _require_micro_ub_base_32b_aligned(
    opname: str,
    role: str,
    name: str,
    tensor: torch.Tensor,
    logical_offset_bytes: Optional[int] = None,
) -> None:
    byte_offset = _effective_byte_offset(tensor, logical_offset_bytes=logical_offset_bytes)
    if byte_offset % 32 != 0:
        raise RuntimeError(
            f"{opname} {role} address base must be 32-byte aligned: "
            f"{name} has base byte offset {byte_offset}"
        )


def _require_micro_ub_access_32b_aligned(
    opname: str,
    role: str,
    name: str,
    tensor: torch.Tensor,
    elem_offset: int = 0,
    logical_offset_bytes: Optional[int] = None,
) -> None:
    byte_offset = _effective_byte_offset(
        tensor,
        elem_offset=elem_offset,
        logical_offset_bytes=logical_offset_bytes,
    )
    if byte_offset % 32 != 0:
        raise RuntimeError(
            f"{opname} {role} address access offset must preserve 32-byte alignment: "
            f"{name} has effective byte offset {byte_offset}"
        )


def _storage_tail_view(tensor: torch.Tensor) -> torch.Tensor:
    elem = int(tensor.element_size())
    storage_elems = int(tensor.untyped_storage().nbytes()) // elem
    offset = int(tensor.storage_offset())
    length = max(storage_elems - offset, 0)
    return tensor.as_strided((length,), (1,), storage_offset=offset)


def _ub2regcont_mode_requires_32b(mode: str) -> bool:
    return mode == "DIST_NORM" or mode.startswith((
        "DIST_DS_", "DIST_US_", "DIST_UNPACK_", "DIST_UNPACK4_", "DIST_E2B_",
    ))


def _reg2ubcont_mode_requires_32b(mode: str) -> bool:
    return mode == "DIST_NORM" or mode.startswith(("DIST_PACK_", "DIST_PACK4_", "DIST_NORM_"))


def _mask_bits_from_mode(mode: str, lanes: int) -> torch.Tensor:
    bits = torch.zeros(lanes, dtype=torch.bool)
    if mode == "ALL":
        bits.fill_(True)
        return bits
    if mode == "ALLF":
        return bits
    if mode.startswith("VL") and mode[2:].isdigit():
        bits[:min(int(mode[2:]), lanes)] = True
        return bits
    if mode == "H":
        bits[:lanes // 2] = True
        return bits
    if mode == "Q":
        bits[:lanes // 4] = True
        return bits
    if mode == "M3":
        bits[::3] = True
        return bits
    if mode == "M4":
        bits[::4] = True
        return bits
    raise ValueError("unsupported mask init_mode: " + str(mode))


# Non-finite float immediates reach device code as compiler builtins, because
# C++ has no plain literal for them (see microutils._float_immediate and
# asc_utils.float_to_cpp_literal). Resolve the same spellings here.
_BUILTIN_FLOATS = {
    "__builtin_inff()": float("inf"),
    "-__builtin_inff()": float("-inf"),
    "+__builtin_inff()": float("inf"),
    "__builtin_huge_valf()": float("inf"),
    "-__builtin_huge_valf()": float("-inf"),
    '__builtin_nanf("")': float("nan"),
    "-__builtin_nanf(\"\")": float("nan"),
}


def _strip_literal(text: str) -> str:
    m = _TYPED_LITERAL_RE.match(text)
    if m:
        text = m.group(1)
    if text in _BUILTIN_FLOATS:
        return repr(_BUILTIN_FLOATS[text])
    # The trailing 'f' is a C++ float suffix only when what precedes it is
    # already a number. "inf"/"-inf" end in the same letter, and stripping it
    # turned them into "in", so an infinite scalar immediate raised
    # ValueError instead of resolving.
    try:
        float(text)
    except ValueError:
        return text.rstrip("fF")
    return text


# ---------------------------------------------------------------------------
# MicroContext — per call_micro execution state
# ---------------------------------------------------------------------------

class _AliasRegDict(dict):
    """Reg storage that models device ``ReinterpretCast`` aliasing.

    A ``reinterpret``-derived reg is a VIEW over the source reg's bytes, not an
    independent copy: a write through *either* name must stay in sync, exactly like
    the C++ ``ReinterpretCast`` which returns an alias. So a reinterpret reg is
    stored as a virtual alias here (never its own tensor); every get/set
    reinterprets to/from the base reg's bytes. (The previous ``_reg_reinterpret``
    cloned the bytes, so a write through the view was silently dropped -- e.g.
    ``squeeze(packed.reinterpret(int8), ...)`` left ``packed`` untouched.)

    Aliases are recorded as ``alias_name -> (base, view_dtype, view_lanes,
    base_dtype, base_lanes)``; transitive aliases collapse onto the root base.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._aliases: Dict[str, tuple] = {}

    def set_alias(self, alias_name, base_name, view_dtype, view_lanes,
                  base_dtype, base_lanes):
        root = self._aliases.get(base_name)
        if root is not None:  # reinterpret of a reinterpret -> point at the root base
            base_name, base_dtype, base_lanes = root[0], root[3], root[4]
        self._aliases[alias_name] = (base_name, view_dtype, view_lanes,
                                     base_dtype, base_lanes)
        if dict.__contains__(self, alias_name):  # shadow any stale real tensor
            dict.__delitem__(self, alias_name)

    @staticmethod
    def _as(tensor, dtype, lanes):
        return tensor.contiguous().view(torch.uint8).view(dtype).reshape(lanes)

    def __setitem__(self, name, value):
        info = self._aliases.get(name)
        if info is None:
            dict.__setitem__(self, name, value)
            return
        base, _vdt, _vl, bdt, bl = info
        dict.__setitem__(self, base, self._as(value, bdt, bl))  # write back as base

    def __getitem__(self, name):
        info = self._aliases.get(name)
        if info is None:
            return dict.__getitem__(self, name)
        base, vdt, vl, _bdt, _bl = info
        return self._as(dict.__getitem__(self, base), vdt, vl)  # read base as view

    def __contains__(self, name):
        info = self._aliases.get(name)
        if info is not None:
            return dict.__contains__(self, info[0])
        return dict.__contains__(self, name)

    def get(self, name, default=None):
        try:
            return self[name]
        except KeyError:
            return default


@dataclass
class MicroContext:
    regs: Dict[str, torch.Tensor] = field(default_factory=_AliasRegDict)
    masks: Dict[str, torch.Tensor] = field(default_factory=dict)
    # Historical compatibility name: entries may be raw logical tensors or
    # PhysicalAlias descriptors depending on the binding path.
    tensor_views: Dict[str, Any] = field(default_factory=dict)
    tensor_offsets_bytes: Dict[str, int] = field(default_factory=dict)
    var_values: Dict[str, Any] = field(default_factory=dict)
    ar: int = 0  # AR accumulate register: Squeeze STORE_REG output offset (clear_spr -> 0)
    # Vector-mask SPR snapshot handed in from the vec pipe (256 byte-lanes, 0/1), read by
    # MoveMask<T>() (move_mask_spr). None when the vf was not entered from the vec runtime.
    spr_mask: Optional[torch.Tensor] = None


# ---------------------------------------------------------------------------
# MicroRuntime — register-level operation executor
# ---------------------------------------------------------------------------

@dataclass
class MicroRuntime:
    _stack: List[MicroContext] = field(default_factory=list)
    # VF local-memory hazard tracking: pending ranges (storage_ptr, lo, hi)
    # awaiting the matching barrier direction. Each VF UB read/write records one
    # or more real byte ranges; WAW/RAW warnings require overlap.
    _vf_store_to_load: List[tuple] = field(default_factory=list)
    _vf_store_to_store: List[tuple] = field(default_factory=list)
    # VF stores whose publication to the SCALAR unit is still pending. The VF
    # store buffer is its own ordering domain on A5: PipeBarrier<PIPE_ALL> does
    # not drain it towards scalar GetValue/SetValue, only mem_bar(VST_LD) /
    # mem_bar(VST_ST) do. These ranges survive the end of the region and are
    # handed to the control pipe, which warns if a scalar read hits one.
    _vf_store_to_scalar: List[tuple] = field(default_factory=list)
    # DataCopyScatter writes are synchronous in the value simulator, but A5
    # does not guarantee that a same-base dynamic gather/scatter recurrence is
    # published by LocalMemBar.  Keep a second history which barriers do not
    # clear and compare it at loop-iteration boundaries.
    _vf_scatter_history: List[tuple] = field(default_factory=list)
    _vf_publication_contexts: List[tuple] = field(default_factory=list)
    _vf_publication_warned: bool = False
    _intrinsic_div_warned: bool = False
    # Owning core index, set by the vec pipe before execute; for print_reg only.
    _core_idx: int = -1

    @property
    def _ctx(self) -> Optional[MicroContext]:
        return self._stack[-1] if self._stack else None

    def reset(self) -> None:
        self._stack.clear()
        self._vf_store_to_load.clear()
        self._vf_store_to_store.clear()
        self._vf_scatter_history.clear()
        self._vf_publication_contexts.clear()
        self._vf_publication_warned = False
        self._intrinsic_div_warned = False

    @staticmethod
    def _vf_range(view: torch.Tensor, n: int) -> tuple:
        lo = int(view.data_ptr())
        return (int(view.untyped_storage().data_ptr()), lo, lo + n * int(view.element_size()))

    def _vf_overlaps(self, rng: tuple, pending: List[tuple]) -> bool:
        sid, lo, hi = rng
        return any(p[0] == sid and lo < p[2] and p[1] < hi for p in pending)

    @staticmethod
    def _vf_warn_hazard(kind: str, prev_pipe: str, next_pipe: str, barrier_src: str, barrier_dst: str) -> None:
        warnings.warn(
            f"VF {kind} hazard: {prev_pipe} -> {next_pipe} on overlapping local buffer "
            f"range without vf_barrier(VfPipe.{barrier_src}, VfPipe.{barrier_dst})",
            VfBarrierWarning,
            stacklevel=4,
        )

    def _vf_on_store(self, view: torch.Tensor, n: int) -> None:
        self._vf_on_store_ranges([self._vf_range(view, n)])

    def _vf_on_load(self, view: torch.Tensor, n: int) -> None:
        self._vf_on_load_ranges([self._vf_range(view, n)])

    @staticmethod
    def _vf_ranges_from_indices(view: torch.Tensor, indices: torch.Tensor) -> List[tuple]:
        if int(indices.numel()) == 0:
            return []
        elem = int(view.element_size())
        sid = int(view.untyped_storage().data_ptr())
        base = int(view.data_ptr())
        sorted_indices = torch.unique(indices.to(dtype=torch.long)).cpu().tolist()
        ranges = []
        start = prev = int(sorted_indices[0])
        for raw_idx in sorted_indices[1:]:
            idx = int(raw_idx)
            if idx == prev + 1:
                prev = idx
                continue
            ranges.append((sid, base + start * elem, base + (prev + 1) * elem))
            start = prev = idx
        ranges.append((sid, base + start * elem, base + (prev + 1) * elem))
        return ranges

    def _vf_on_store_indices(self, view: torch.Tensor, indices: torch.Tensor) -> None:
        self._vf_on_store_ranges(self._vf_ranges_from_indices(view, indices))

    def _vf_on_load_indices(self, view: torch.Tensor, indices: torch.Tensor) -> None:
        self._vf_on_load_ranges(self._vf_ranges_from_indices(view, indices))

    @staticmethod
    def _vf_ref_name(ref: Any) -> str:
        return str(ref.name) if hasattr(ref, "name") else str(ref)

    @classmethod
    def _vf_loop_recurrence_tensors(cls, body: List[Any]) -> set:
        gathers = {
            cls._vf_ref_name(inst.kwargs.get("src"))
            for inst in body
            if str(inst.opname) == "micro_datacopygather"
        }
        scatters = {
            cls._vf_ref_name(inst.kwargs.get("dst"))
            for inst in body
            if str(inst.opname) == "micro_datacopyscatter"
        }
        return gathers & scatters

    @staticmethod
    def _vf_has_dynamic_tensor_offset(ref: Any) -> bool:
        offsets = getattr(ref, "offset", ())
        return any(hasattr(offset, "name") for offset in offsets)

    @classmethod
    def _vf_warn_large_dynamic_ub_access(cls, instructions: List[Any]) -> None:
        """Flag an A5 compiler shape that synchronous execution cannot model.

        CANN 9.2 accepted a VF containing many serial runtime-loop regions and
        runtime-addressed UB loads/stores, but the resulting A5 binary
        corrupted the later state planes for both block-copy and aligned forms.
        The simulator intentionally retains deterministic pointer semantics;
        this warning prevents that success from being mistaken for hardware
        validation.
        """
        loop_regions = sum(
            str(inst.opname) == "start_micro_loop" for inst in instructions
        )
        if loop_regions < _VF_DYNAMIC_UB_LOOP_WARNING_THRESHOLD:
            return
        for inst in instructions:
            op = str(inst.opname)
            if op in ("micro_ub2reg", "micro_ub2regcont", "micro_ub2reginterleave"):
                ref = inst.kwargs.get("src")
            elif op in ("micro_reg2ub", "micro_reg2ubcont", "micro_reg2ubinterleave"):
                ref = inst.kwargs.get("dst")
            else:
                continue
            if not cls._vf_has_dynamic_tensor_offset(ref):
                continue
            warnings.warn(
                "large VF with runtime-addressed UB load/store may lower "
                "incorrectly on A5: the simulator evaluates the dynamic "
                "pointer synchronously, while CANN 9.2 hardware compilation "
                "has corrupted this many-loop shape; reduce or split the VF "
                "loop regions and validate the compiled kernel on hardware",
                VfPublicationWarning,
                stacklevel=4,
            )
            return

    def _vf_record_scatter(
        self, view: torch.Tensor, indices: torch.Tensor,
    ) -> None:
        self._vf_scatter_history.extend(
            self._vf_ranges_from_indices(view, indices),
        )

    def _vf_check_gather_publication(
        self, source_name: str, view: torch.Tensor, indices: torch.Tensor,
    ) -> None:
        if self._vf_publication_warned:
            return
        ranges = self._vf_ranges_from_indices(view, indices)
        for candidate_names, prior_scatters in reversed(
            self._vf_publication_contexts
        ):
            if source_name not in candidate_names:
                continue
            if any(
                self._vf_overlaps(rng, prior_scatters) for rng in ranges
            ):
                warnings.warn(
                    "VF same-base dynamic gather/scatter recurrence may not "
                    "publish on A5: the simulator applies DataCopyScatter "
                    "synchronously, while vf_barrier does not make this "
                    "loop-carried UB update reliable on hardware; use an "
                    "immutable UB source with register state and a separate "
                    "output, or a real ownership handoff",
                    VfPublicationWarning,
                    stacklevel=5,
                )
                self._vf_publication_warned = True
                return

    def _vf_on_store_ranges(self, ranges: List[tuple]) -> None:
        if not ranges:
            return
        if any(self._vf_overlaps(rng, self._vf_store_to_store) for rng in ranges):
            self._vf_warn_hazard("WAW", "store", "store", "STORE", "STORE")
        self._vf_store_to_load.extend(ranges)
        self._vf_store_to_store.extend(ranges)
        self._vf_store_to_scalar.extend(ranges)

    def _vf_on_load_ranges(self, ranges: List[tuple]) -> None:
        if not ranges:
            return
        if any(self._vf_overlaps(rng, self._vf_store_to_load) for rng in ranges):
            self._vf_warn_hazard("RAW", "store", "load", "STORE", "LOAD")

    def _require_ctx(self, op: str) -> MicroContext:
        ctx = self._ctx
        if ctx is None:
            raise RuntimeError("micro op requires active context: " + op)
        return ctx

    @staticmethod
    def _is_float8(dtype: torch.dtype) -> bool:
        return str(dtype).startswith("torch.float8_")

    @staticmethod
    def _require_index_dtype(opname: str, elem_size: int, index_ref: Any, expected: tuple) -> None:
        actual = _logical_dtype_name(index_ref)
        if actual not in expected:
            raise ValueError(
                f"{opname} index for {elem_size * 8}-bit data must be {' or '.join(expected)}, "
                f"got {actual}"
            )

    @staticmethod
    def _gather_1d(values: torch.Tensor, indices: torch.Tensor) -> torch.Tensor:
        src_flat = values.reshape(-1)
        gather_idx = indices.to(device=src_flat.device, dtype=torch.long)
        if MicroRuntime._is_float8(src_flat.dtype):
            orig_dtype = src_flat.dtype
            return src_flat.view(torch.uint8)[gather_idx].view(orig_dtype)
        if src_flat.dtype is getattr(torch, "uint16", None):
            return src_flat.view(torch.int16)[gather_idx].view(src_flat.dtype)
        if src_flat.dtype is torch.uint32:
            return src_flat.view(torch.int32)[gather_idx].view(torch.uint32)
        if src_flat.dtype is torch.uint64:
            return src_flat.view(torch.int64)[gather_idx].view(torch.uint64)
        return src_flat[gather_idx]

    @staticmethod
    def _scatter_1d(dst: torch.Tensor, indices: torch.Tensor, values: torch.Tensor) -> None:
        dst_flat = dst.reshape(-1)
        scatter_idx = indices.to(device=dst_flat.device, dtype=torch.long)
        if MicroRuntime._is_float8(dst_flat.dtype):
            scatter_values = values.to(dtype=dst_flat.dtype, device=dst_flat.device)
            dst_flat.view(torch.uint8)[scatter_idx] = scatter_values.view(torch.uint8)
        elif dst_flat.dtype is getattr(torch, "uint16", None):
            scatter_values = values.to(dtype=dst_flat.dtype, device=dst_flat.device)
            dst_flat.view(torch.int16)[scatter_idx] = scatter_values.view(torch.int16)
        elif dst_flat.dtype is torch.uint32:
            scatter_values = values.to(dtype=dst_flat.dtype, device=dst_flat.device)
            dst_flat.view(torch.int32)[scatter_idx] = scatter_values.view(torch.int32)
        elif dst_flat.dtype is torch.uint64:
            scatter_values = values.to(dtype=dst_flat.dtype, device=dst_flat.device)
            dst_flat.view(torch.int64)[scatter_idx] = scatter_values.view(torch.int64)
        else:
            scatter_values = values.to(dtype=dst_flat.dtype, device=dst_flat.device)
            dst_flat[scatter_idx] = scatter_values

    @staticmethod
    def _require_args(op: str, **refs: Any) -> None:
        missing = [name for name, value in refs.items() if value is None]
        if missing:
            raise ValueError(op + " requires " + ", ".join(missing))

    # ------------------------------------------------------------------
    # call_micro entry
    # ------------------------------------------------------------------

    def execute_call_micro(
        self, micro_def: Dict[str, Any],
        tensor_views: Dict[str, Any],
        var_values: Dict[str, Any],
        store: SharedMemoryStore,
        tensor_offsets_bytes: Optional[Dict[str, int]] = None,
        spr_mask: Optional[torch.Tensor] = None,
    ) -> None:
        # Runtime boundary note: micro datacopy executes pointer semantics.
        # Tensor bindings here may be PhysicalAlias descriptors whose physical
        # storage + offset are authoritative on the execution path.
        ctx = MicroContext(
            tensor_views=dict(tensor_views),
            tensor_offsets_bytes=dict(tensor_offsets_bytes or {}),
            var_values=dict(var_values),
            spr_mask=None if spr_mask is None else spr_mask.clone(),
        )
        self._stack.append(ctx)
        self._vf_store_to_load.clear()
        self._vf_store_to_store.clear()
        self._vf_store_to_scalar.clear()
        self._vf_scatter_history.clear()
        self._vf_publication_contexts.clear()
        self._vf_publication_warned = False
        self._intrinsic_div_warned = False
        try:
            self._vf_warn_large_dynamic_ub_access(
                micro_def.get("instructions", []),
            )
            self._run_list(micro_def.get("instructions", []), store)
        finally:
            # Anything the region did not publish with mem_bar(VST_LD) outlives
            # it: the scalar unit may still read stale UB after the region ends.
            pending = getattr(store, "vf_unpublished_scalar_ranges", None)
            if pending is None:
                pending = []
                setattr(store, "vf_unpublished_scalar_ranges", pending)
            pending.extend(self._vf_store_to_scalar)
            self._stack.pop()

    def execute(self, opname: str, args: Dict[str, Any], store: SharedMemoryStore) -> bool:
        self._dispatch(opname, args, store)
        return True

    # ------------------------------------------------------------------
    # Instruction list runner (with loop support)
    # ------------------------------------------------------------------

    def _run_list(self, instructions: list, store: SharedMemoryStore) -> None:
        pc = 0
        while pc < len(instructions):
            inst = instructions[pc]
            op = str(inst.opname)
            if op == "start_micro_loop":
                end = self._find_end_loop(instructions, pc)
                self._run_loop(inst.kwargs, instructions, pc + 1, end, store)
                pc = end + 1
                continue
            if op == "start_if":
                end = self._find_end_if(instructions, pc)
                self._run_if_chain(instructions, pc, end, store)
                pc = end + 1
                continue
            self._dispatch(op, inst.kwargs, store)
            pc += 1

    def _find_end_loop(self, instructions: list, start: int) -> int:
        depth = 0
        for pc in range(start, len(instructions)):
            op = str(instructions[pc].opname)
            if op == "start_micro_loop":
                depth += 1
            elif op == "end_loop":
                depth -= 1
                if depth == 0:
                    return pc
        raise ValueError("start_micro_loop at index " + str(start) + " without matching end_loop")

    def _find_end_if(self, instructions: list, start: int) -> int:
        depth = 0
        for pc in range(start, len(instructions)):
            op = str(instructions[pc].opname)
            if op == "start_if":
                depth += 1
            elif op == "end_if":
                depth -= 1
                if depth == 0:
                    return pc
        raise ValueError("start_if at index " + str(start) + " without matching end_if")

    def _run_if_chain(
        self, instructions: list, start: int, if_end: int,
        store: SharedMemoryStore,
    ) -> None:
        segments = []
        header = start
        body_start = start + 1
        nested_if = 0
        nested_loop = 0
        pc = start + 1
        while pc < if_end:
            op = str(instructions[pc].opname)
            if op == "start_micro_loop":
                nested_loop += 1
            elif op == "end_loop":
                nested_loop -= 1
            elif op == "start_if":
                nested_if += 1
            elif op == "end_if":
                nested_if -= 1
            elif (
                op in ("start_elif", "start_else")
                and nested_if == 0 and nested_loop == 0
            ):
                segments.append((header, body_start, pc))
                header = pc
                body_start = pc + 1
            pc += 1
        segments.append((header, body_start, if_end))

        for header_pc, segment_start, segment_end in segments:
            header_inst = instructions[header_pc]
            if str(header_inst.opname) == "start_else":
                self._run_list(instructions[segment_start:segment_end], store)
                return
            if self._resolve_bool(header_inst.kwargs.get("cond")):
                self._run_list(instructions[segment_start:segment_end], store)
                return

    def _run_loop(self, kwargs: Dict, instructions: list, body_start: int, body_end: int, store: SharedMemoryStore) -> None:
        ctx = self._require_ctx("start_micro_loop")
        var = kwargs.get("var")
        name = str(var.name) if hasattr(var, "name") else str(var)
        start = self._num(kwargs.get("start", 0))
        stop = self._num(kwargs.get("stop", 0))
        step = self._num(kwargs.get("step", 1))
        body = instructions[body_start:body_end]
        recurrence_tensors = self._vf_loop_recurrence_tensors(body)
        for val in range(start, stop, step):
            ctx.var_values[name] = val
            self._vf_publication_contexts.append(
                (recurrence_tensors, list(self._vf_scatter_history)),
            )
            try:
                self._run_list(body, store)
            finally:
                self._vf_publication_contexts.pop()

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def _dispatch(self, op: str, kw: Dict[str, Any], store: SharedMemoryStore) -> None:
        ctx = self._ctx

        # Codegen-only escape hatch. Keep simulator behavior aligned with the
        # cube/vec lanes, where inline has no runtime effect.
        if op == "inline":
            return

        # Variable ops
        if op == "create_var":
            self._create_var(kw); return
        if op == "var_assign":
            self._var_assign(kw); return
        if op in (
            "var_add", "var_sub", "var_mul", "var_div", "var_mod",
            "CeilDiv", "Min", "Max",
        ):
            self._var_arith(op, kw); return
        if op.startswith("Align"):
            self._align(op, kw); return
        if op == "scalar_abs":
            self._scalar_abs(kw); return
        if op in (
            "start_micro_loop", "end_loop", "start_if", "start_elif",
            "start_else", "end_if",
        ):
            return
        if op == "micro_vf_barrier":
            src = str(kw.get("src", ""))
            dst = str(kw.get("dst", ""))
            if src in ("VEC_STORE", "VEC_ALL"):
                if dst in ("VEC_LOAD", "VEC_ALL"):
                    self._vf_store_to_load.clear()
                if dst in ("VEC_STORE", "VEC_ALL"):
                    self._vf_store_to_store.clear()
                if dst in ("SCALAR_LOAD", "SCALAR_STORE", "SCALAR_ALL"):
                    self._vf_store_to_scalar.clear()
            return

        # Register lifecycle
        if op == "create_reg":
            self._create_reg(kw); return
        if op == "create_reglist":
            self._create_reglist(kw); return
        if op == "create_maskreg":
            self._create_maskreg(kw); return
        if op == "micro_slice_tensor":
            self._slice_tensor(kw); return
        if op == "micro_reg_reinterpret":
            self._reg_reinterpret(kw); return

        # Data movement
        if op == "micro_ub2reg":
            self._ub2reg(kw); return
        if op == "micro_reg2ub":
            self._reg2ub(kw); return
        if op == "micro_ub2regcont":
            self._ub2regcont(kw); return
        if op == "micro_ub2reginterleave":
            self._ub2reginterleave(kw); return
        if op == "micro_reg2ubcont":
            self._reg2ubcont(kw); return
        if op == "micro_reg2ubinterleave":
            self._reg2ubinterleave(kw); return
        if op == "micro_mask_to_ub":
            self._mask_to_ub(kw); return
        if op == "micro_ub_to_mask":
            self._ub_to_mask(kw); return
        if op == "micro_arange":
            self._arange(kw); return

        # Gather / scatter
        if op == "micro_datacopygather":
            self._datacopygather(kw); return
        if op == "micro_gatherb":
            self._gatherb(kw); return
        if op == "micro_datacopyscatter":
            self._datacopyscatter(kw); return
        if op == "micro_gather":
            self._gather_reg(kw); return
        if op == "micro_gathermask":
            self._gathermask(kw); return
        if op == "micro_squeeze":
            self._squeeze(kw); return
        if op == "micro_unsqueeze":
            self._unsqueeze(kw); return
        if op == "micro_clear_spr":
            self._clear_spr(kw); return

        # Interleave
        if op in ("micro_interleave", "micro_dinterleave"):
            self._interleave(op, kw); return
        if op == "micro_pack":
            self._handle_pack(kw); return
        if op == "micro_histograms":
            self._handle_histograms(kw); return
        if op == "micro_abssub":
            self._handle_abssub(kw); return
        if op == "micro_expsub":
            self._handle_expsub(kw); return
        if op == "micro_muldstadd":
            self._handle_muldstadd(kw); return
        if op == "micro_muladddst":
            self._handle_muladddst(kw); return
        if op == "micro_mulscast":
            self._handle_mulscast(kw); return

        # Math
        if self._math(op, kw):
            return

        # Mask ops
        if op in ("micro_masknot", "micro_maskmov"):
            self._mask_unary(op, kw); return
        if op in ("micro_maskand", "micro_maskor", "micro_maskxor", "micro_masksel"):
            self._mask_binary(op, kw); return
        if op in ("micro_maskinterl", "micro_maskdeinterl"):
            self._mask_interleave(op, kw); return
        if op in ("micro_maskpack", "micro_maskunpack"):
            self._mask_pack(op, kw); return
        if op == "micro_updatemask":
            self._updatemask(kw); return
        if op == "micro_movemaskspr":
            self._move_mask(kw); return

        # Debug-only: dump a Reg/RegList's live lane values to stderr.
        if op == "micro_print_reg":
            self._print_reg(kw); return

        raise NotImplementedError("unhandled micro op: " + op)

    # ------------------------------------------------------------------
    # Variable ops
    # ------------------------------------------------------------------

    def _num(self, value: Any) -> int:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, (int, float)):
            return int(value)
        ctx = self._ctx
        if hasattr(value, "name"):
            name = str(value.name)
            if ctx and name in ctx.var_values:
                return int(ctx.var_values[name])
        if hasattr(value, "value") and isinstance(getattr(value, "value"), (int, float)):
            return int(getattr(value, "value"))
        if ctx and isinstance(value, str) and value in ctx.var_values:
            return int(ctx.var_values[value])
        if isinstance(value, str):
            cleaned = _strip_literal(value)
            try:
                return int(cleaned)
            except ValueError:
                return int(float(cleaned))
        raise TypeError("cannot resolve number: " + repr(value))

    def _number(self, value: Any) -> Any:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, (int, float)):
            return value
        ctx = self._ctx
        if hasattr(value, "name"):
            name = str(value.name)
            if ctx and name in ctx.var_values:
                resolved = ctx.var_values[name]
                if isinstance(resolved, bool):
                    return int(resolved)
                if isinstance(resolved, (int, float)):
                    return resolved
        if hasattr(value, "value") and isinstance(getattr(value, "value"), bool):
            return int(getattr(value, "value"))
        if hasattr(value, "value") and isinstance(getattr(value, "value"), (int, float)):
            return getattr(value, "value")
        if ctx and isinstance(value, str) and value in ctx.var_values:
            resolved = ctx.var_values[value]
            if isinstance(resolved, bool):
                return int(resolved)
            if isinstance(resolved, (int, float)):
                return resolved
        if isinstance(value, str):
            cleaned = _strip_literal(value)
            try:
                return int(cleaned)
            except ValueError:
                print(
                    "[simulator] _resolve_numeric int parse fallback: value=%r cleaned=%r\n%s"
                    % (value, cleaned, traceback.format_exc()),
                    file=sys.stderr, flush=True,
                )
            try:
                return float(cleaned)
            except ValueError:
                print(
                    "[simulator] _resolve_numeric float parse fallback: value=%r cleaned=%r\n%s"
                    % (value, cleaned, traceback.format_exc()),
                    file=sys.stderr, flush=True,
                )
        raise TypeError("cannot resolve numeric value: " + repr(value))

    def _resolve_bool(self, cond: Any) -> bool:
        if cond is None:
            raise ValueError("micro boolean condition is required")
        if isinstance(cond, bool):
            return cond
        if isinstance(cond, (int, float)):
            raise TypeError(
                "micro boolean condition must not be a bare number: " + repr(cond)
            )
        text = str(cond).strip()
        if not text:
            raise ValueError("cannot resolve micro boolean condition: " + repr(cond))
        return self._eval_cond_expr(text)

    _CMP_OPS = (
        ("==", lambda a, b: a == b), ("!=", lambda a, b: a != b),
        ("<=", lambda a, b: a <= b), (">=", lambda a, b: a >= b),
        ("<", lambda a, b: a < b), (">", lambda a, b: a > b),
    )

    def _eval_cond_expr(self, expr: str) -> bool:
        text = expr.strip()
        while len(text) >= 2 and text[0] == "(" and text[-1] == ")":
            inner = text[1:-1]
            depth = 0
            balanced = True
            for char in inner:
                if char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                if depth < 0:
                    balanced = False
                    break
            if not balanced or depth != 0:
                break
            text = inner.strip()
        if not text:
            raise ValueError("cannot resolve micro boolean expression: " + repr(expr))
        or_parts = self._split_top(text, "||")
        if len(or_parts) > 1:
            return any(self._eval_cond_expr(part) for part in or_parts)
        and_parts = self._split_top(text, "&&")
        if len(and_parts) > 1:
            return all(self._eval_cond_expr(part) for part in and_parts)
        if text.startswith("!") and not text.startswith("!="):
            return not self._eval_cond_expr(text[1:].lstrip())
        if text == "true":
            return True
        if text == "false":
            return False
        for opname, compare in self._CMP_OPS:
            pos = self._find_top(text, opname)
            if pos >= 0:
                lhs = self._eval_numeric_expr(text[:pos].strip())
                rhs = self._eval_numeric_expr(text[pos + len(opname):].strip())
                return bool(compare(lhs, rhs))
        ctx = self._require_ctx("start_if")
        if text in ctx.var_values:
            return bool(ctx.var_values[text])
        raise ValueError("cannot resolve micro boolean expression: " + repr(expr))

    def _eval_numeric_expr(self, expr: Any) -> Any:
        if isinstance(expr, (int, float)):
            return expr
        text = str(expr).strip()
        ctx = self._require_ctx("start_if")
        if text in ctx.var_values:
            return ctx.var_values[text]
        cleaned = _strip_literal(text)
        try:
            return int(cleaned)
        except ValueError:
            try:
                return float(cleaned)
            except ValueError:
                pass

        import ast
        import operator

        bin_ops = {
            ast.Add: operator.add,
            ast.Sub: operator.sub,
            ast.Mult: operator.mul,
            ast.Div: operator.truediv,
            ast.FloorDiv: operator.floordiv,
            ast.Mod: operator.mod,
        }
        unary_ops = {ast.UAdd: operator.pos, ast.USub: operator.neg}

        def eval_node(node: Any) -> Any:
            if isinstance(node, ast.Expression):
                return eval_node(node.body)
            if isinstance(node, ast.Constant):
                if isinstance(node.value, (int, float)):
                    return node.value
                raise ValueError(
                    "non-numeric constant in micro expression: " + repr(expr)
                )
            if isinstance(node, ast.Name):
                if node.id in ctx.var_values:
                    value = ctx.var_values[node.id]
                    if isinstance(value, (int, float)):
                        return value
                raise ValueError("unknown micro numeric symbol: " + node.id)
            if isinstance(node, ast.UnaryOp) and type(node.op) in unary_ops:
                return unary_ops[type(node.op)](eval_node(node.operand))
            if isinstance(node, ast.BinOp) and type(node.op) in bin_ops:
                return bin_ops[type(node.op)](
                    eval_node(node.left), eval_node(node.right),
                )
            raise ValueError("unsupported micro numeric expression: " + repr(expr))

        try:
            tree = ast.parse(cleaned, mode="eval")
        except SyntaxError as exc:
            raise ValueError(
                "cannot resolve micro numeric expression: " + repr(expr)
            ) from exc
        return eval_node(tree)

    @staticmethod
    def _split_top(expr: str, separator: str) -> List[str]:
        parts = []
        depth = 0
        start = 0
        index = 0
        while index < len(expr):
            if expr[index] == "(":
                depth += 1
            elif expr[index] == ")":
                depth -= 1
            elif depth == 0 and expr[index:index + len(separator)] == separator:
                parts.append(expr[start:index].strip())
                start = index + len(separator)
                index += len(separator)
                continue
            index += 1
        parts.append(expr[start:].strip())
        return parts

    @staticmethod
    def _find_top(expr: str, opname: str) -> int:
        depth = 0
        index = 0
        while index < len(expr):
            if expr[index] == "(":
                depth += 1
            elif expr[index] == ")":
                depth -= 1
            elif depth == 0 and expr[index:index + len(opname)] == opname:
                return index
            index += 1
        return -1

    def _is_scalar_operand(self, value: Any) -> bool:
        if isinstance(value, (bool, int, float)):
            return True
        if hasattr(value, "value") and isinstance(getattr(value, "value"), (bool, int, float)):
            return True
        ctx = self._ctx
        if ctx and isinstance(value, str):
            if value in ctx.regs:
                return False
            if value in ctx.var_values and isinstance(ctx.var_values[value], (bool, int, float)):
                return True
            cleaned = _strip_literal(value)
            try:
                int(cleaned)
                return True
            except ValueError:
                print(
                    "[simulator] _is_scalar_operand int parse fallback: value=%r cleaned=%r\n%s"
                    % (value, cleaned, traceback.format_exc()),
                    file=sys.stderr, flush=True,
                )
            try:
                float(cleaned)
                return True
            except ValueError:
                print(
                    "[simulator] _is_scalar_operand float parse fallback: value=%r cleaned=%r\n%s"
                    % (value, cleaned, traceback.format_exc()),
                    file=sys.stderr, flush=True,
                )
        return False

    def _is_register_operand(self, value: Any) -> bool:
        ctx = self._ctx
        if ctx and isinstance(value, str) and value in ctx.regs:
            return True
        return hasattr(value, "name") and hasattr(value, "dtype") and not hasattr(value, "value")

    def _numf(self, value: Any) -> float:
        if isinstance(value, bool):
            return float(value)
        if isinstance(value, (int, float)):
            return float(value)
        ctx = self._ctx
        if hasattr(value, "name"):
            name = str(value.name)
            if ctx and name in ctx.var_values:
                return float(ctx.var_values[name])
        if hasattr(value, "value") and isinstance(getattr(value, "value"), (int, float)):
            return float(getattr(value, "value"))
        if ctx and isinstance(value, str) and value in ctx.var_values:
            return float(ctx.var_values[value])
        if isinstance(value, str):
            cleaned = _strip_literal(value)
            try:
                return float(cleaned)
            except ValueError:
                raise ValueError(
                    "cannot resolve float immediate " + repr(value)
                    + " (cleaned to " + repr(cleaned) + ")"
                ) from None
        raise TypeError("cannot resolve float: " + repr(value))

    def _numc(self, value: Any) -> complex:
        """Resolve a complex immediate for complex Adds/Muls/Duplicate.

        Real ints/floats promote to ``complex(x, 0)``; a Python ``complex`` or a
        ``"1+2j"`` literal is taken as-is; a ``Var`` resolves through the live
        ``var_values`` map. This mirrors ``_numf`` but keeps the imaginary part
        that ``float()`` would discard.
        """
        if isinstance(value, complex):
            return value
        if isinstance(value, bool):
            return complex(float(value), 0.0)
        if isinstance(value, (int, float)):
            return complex(float(value), 0.0)
        ctx = self._ctx
        if hasattr(value, "name"):
            name = str(value.name)
            if ctx and name in ctx.var_values:
                return complex(ctx.var_values[name])
        if hasattr(value, "value") and isinstance(
            getattr(value, "value"), (int, float, complex)
        ):
            return complex(getattr(value, "value"))
        if ctx and isinstance(value, str) and value in ctx.var_values:
            return complex(ctx.var_values[value])
        if isinstance(value, str):
            return complex(_strip_literal(value))
        raise TypeError("cannot resolve complex: " + repr(value))

    def _create_var(self, kw: Dict) -> None:
        ctx = self._require_ctx("create_var")
        var = kw.get("val", kw.get("var"))
        self._require_args("create_var", var=var)
        name = str(var.name) if hasattr(var, "name") else str(var)
        # Codegen emits this as a C declaration *with an initialiser* at the
        # point it appears, so one inside a loop body re-initialises on every
        # iteration.  Initialising only on first sight diverges from the board
        # for any counter the body mutates -- `UpdateMask` decrements its
        # argument, so a loop-local mask width would collapse to an empty mask
        # after the first pass here while the board kept re-arming it.
        value = getattr(var, "value", 0)
        if isinstance(value, bool):
            ctx.var_values[name] = int(value)
        elif isinstance(value, (int, float)):
            ctx.var_values[name] = value
        else:
            raise TypeError("create_var requires numeric value, got: " + repr(value))

    def _var_assign(self, kw: Dict) -> None:
        ctx = self._require_ctx("var_assign")
        out = kw.get("out", kw.get("dst"))
        self._require_args("var_assign", out=out)
        dst_category = _var_dtype_category(getattr(out, "dtype", None))
        if dst_category is None:
            raise TypeError("var_assign requires destination Var integer/float dtype")
        src = kw.get("src", 0)
        if hasattr(src, "dtype"):
            src_category = _var_dtype_category(getattr(src, "dtype", None))
        elif isinstance(src, float):
            src_category = "float"
        elif isinstance(src, (bool, int)):
            src_category = "int"
        else:
            src_category = None
        if src_category is None:
            raise TypeError("var_assign requires source Var/int/float type")
        if dst_category != src_category:
            raise TypeError(
                f"micro var_assign does not support {src_category} -> {dst_category} conversion"
            )
        name = str(out.name) if hasattr(out, "name") else str(out)
        ctx.var_values[name] = self._number(src)

    def _var_arith(self, op: str, kw: Dict) -> None:
        ctx = self._require_ctx(op)
        a = self._number(kw.get("a", 0))
        b = self._number(kw.get("b", 0))
        out = kw.get("out")
        self._require_args(op, out=out)
        name = str(out.name) if hasattr(out, "name") else str(out)
        if op == "var_add": ctx.var_values[name] = a + b
        elif op == "var_sub": ctx.var_values[name] = a - b
        elif op == "var_mul": ctx.var_values[name] = a * b
        elif op == "var_div":
            if not b:
                raise ZeroDivisionError("var_div division by zero")
            ctx.var_values[name] = a / b if isinstance(a, float) or isinstance(b, float) else a // b
        elif op == "var_mod":
            if not b:
                raise ZeroDivisionError("var_mod division by zero")
            quotient = abs(int(a)) // abs(int(b))
            if (int(a) < 0) != (int(b) < 0):
                quotient = -quotient
            ctx.var_values[name] = int(a) - quotient * int(b)
        elif op == "CeilDiv":
            if not b:
                raise ZeroDivisionError("CeilDiv division by zero")
            ctx.var_values[name] = (int(a) + int(b) - 1) // int(b)
        elif op == "Min": ctx.var_values[name] = min(a, b)
        elif op == "Max": ctx.var_values[name] = max(a, b)

    def _align(self, op: str, kw: Dict) -> None:
        ctx = self._require_ctx(op)
        suffix = op[5:]
        if not suffix.isdigit():
            raise ValueError("Align opcode suffix must be numeric: " + op)
        align_val = int(suffix)
        if align_val <= 0:
            raise ValueError("Align opcode suffix must be positive: " + op)
        a = self._num(kw.get("a", 0))
        out = kw.get("out")
        self._require_args(op, out=out)
        name = str(out.name) if hasattr(out, "name") else str(out)
        ctx.var_values[name] = ((a + align_val - 1) // align_val) * align_val

    def _scalar_abs(self, kw: Dict) -> None:
        ctx = self._require_ctx("scalar_abs")
        a = self._number(kw.get("a", 0))
        if not isinstance(a, int) or isinstance(a, bool):
            raise TypeError(
                "scalar_abs inside vf only supports int, got "
                + type(a).__name__ + "=" + repr(a)
            )
        out = kw.get("out")
        self._require_args("scalar_abs", out=out)
        name = str(out.name) if hasattr(out, "name") else str(out)
        ctx.var_values[name] = abs(a)

    # ------------------------------------------------------------------
    # Register lifecycle
    # ------------------------------------------------------------------

    def _reg_name(self, reg: Any) -> str:
        return str(reg.name) if hasattr(reg, "name") else str(reg)

    def _reg_dtype(self, reg: Any) -> torch.dtype:
        return _torch_dt(reg.dtype) if hasattr(reg, "dtype") else torch.float32

    def _create_reg(self, kw: Dict) -> None:
        ctx = self._require_ctx("create_reg")
        reg = kw.get("reg")
        self._require_args("create_reg", reg=reg)
        dt = self._reg_dtype(reg)
        reg_num = int(getattr(reg, "reg_num", 1))
        ctx.regs[self._reg_name(reg)] = torch.zeros(_lanes(dt) * reg_num, dtype=dt)

    def _create_reglist(self, kw: Dict) -> None:
        ctx = self._require_ctx("create_reglist")
        rl = kw.get("reglist")
        self._require_args("create_reglist", reglist=rl)
        name = self._reg_name(rl)
        length = int(getattr(rl, "length", 1))
        dt = self._reg_dtype(rl)
        for i in range(length):
            ctx.regs["%s[%d]" % (name, i)] = torch.zeros(_lanes(dt), dtype=dt)

    def _create_maskreg(self, kw: Dict) -> None:
        ctx = self._require_ctx("create_maskreg")
        reg = kw.get("reg")
        self._require_args("create_maskreg", reg=reg)
        name = self._reg_name(reg)
        dt = self._reg_dtype(reg)
        logical_dtype = _logical_dtype_name(reg)
        reg_num = int(getattr(reg, "reg_num", 1))
        lanes = (512 if _is_fp4_logical_dtype(logical_dtype) else _lanes(dt)) * reg_num
        mode = str(getattr(reg, "init_mode", "ALL"))
        ctx.masks[name] = _mask_bits_from_mode(mode, lanes)

    # ------------------------------------------------------------------
    # Tensor view helpers
    # ------------------------------------------------------------------

    def _lookup_tensor(self, name: str) -> Optional[torch.Tensor]:
        ctx = self._ctx
        if ctx:
            value = ctx.tensor_views.get(name)
            if isinstance(value, PhysicalAlias):
                return value.logical_tensor()
            return value
        return None

    def _lookup_alias(self, name: str) -> Optional[PhysicalAlias]:
        ctx = self._ctx
        if not ctx:
            return None
        value = ctx.tensor_views.get(name)
        if value is None:
            return None
        logical_offset = ctx.tensor_offsets_bytes.get(name)
        return as_physical_alias(value, logical_offset_bytes=logical_offset)

    @staticmethod
    def _alias_logical_view(alias: PhysicalAlias) -> torch.Tensor:
        return alias.logical_tensor()

    @staticmethod
    def _alias_physical_tail(alias: PhysicalAlias) -> torch.Tensor:
        tail = _storage_tail_view(alias.tensor)
        if alias.byte_offset == 0:
            return tail
        elem = int(tail.element_size())
        if alias.byte_offset % elem != 0:
            raise RuntimeError(
                "physical alias byte offset is not divisible by tensor element size: "
                + str(alias.byte_offset)
            )
        elem_offset = alias.byte_offset // elem
        if elem_offset < 0:
            raise RuntimeError("physical alias element offset is negative: " + str(elem_offset))
        if elem_offset > int(tail.numel()):
            return tail.narrow(0, int(tail.numel()), 0)
        return tail.narrow(0, elem_offset, int(tail.numel()) - elem_offset)

    @staticmethod
    def _alias_logical_offset_bytes(alias: PhysicalAlias) -> Optional[int]:
        return alias.logical_offset_bytes

    @staticmethod
    def _alias_advance(alias: PhysicalAlias, elem_offset: int) -> PhysicalAlias:
        elem_offset = int(elem_offset)
        view = alias.logical_tensor().reshape(-1)
        sliced_view = view[elem_offset:] if elem_offset <= int(view.numel()) else view.narrow(0, int(view.numel()), 0)
        logical_offset = alias.logical_offset_bytes
        if logical_offset is not None:
            logical_offset = int(logical_offset) + elem_offset * int(alias.tensor.element_size())
        return PhysicalAlias(
            tensor=alias.tensor,
            byte_offset=int(alias.byte_offset) + elem_offset * int(alias.tensor.element_size()),
            logical_view=sliced_view,
            logical_offset_bytes=logical_offset,
        )

    def _get_reg(self, ref: Any) -> torch.Tensor:
        ctx = self._ctx
        name = self._reg_name(ref)
        if ctx and name in ctx.regs:
            return ctx.regs[name]
        raise KeyError("register not found: " + name)

    def _set_reg(self, ref: Any, value: torch.Tensor) -> None:
        ctx = self._ctx
        if ctx:
            ctx.regs[self._reg_name(ref)] = value

    def _print_reg(self, kw: Dict) -> None:
        """Debug-only handler for ``micro_print_reg``: dump a Reg/RegList's live
        lane values to stderr. A ``RegList`` is printed element by element; a
        ``Reg`` (including a ``RegList`` element proxy) prints its single tensor.
        Unset registers print ``<unset>`` rather than raising."""
        ctx = self._ctx
        reg = kw.get("reg")
        if ctx is None or reg is None:
            return
        label = str(kw.get("label", ""))
        lanes = int(kw.get("lanes", 8))
        core = int(getattr(self, "_core_idx", -1))
        name = self._reg_name(reg)
        length = getattr(reg, "length", None)  # RegList has .length; Reg does not

        def _fmt(t: Optional[torch.Tensor]) -> str:
            if t is None:
                return "<unset>"
            vals = t.detach().to(torch.float32).flatten().tolist()
            head = ", ".join("%.6g" % v for v in vals[:lanes])
            tail = ", ..." if len(vals) > lanes else ""
            return "[%s%s] (n=%d)" % (head, tail, len(vals))

        if length is not None:
            for i in range(int(length)):
                ename = "%s[%d]" % (name, i)
                print(
                    "[print_reg][core=%d] %s %s = %s"
                    % (core, label, ename, _fmt(ctx.regs.get(ename))),
                    file=sys.stderr, flush=True,
                )
        else:
            print(
                "[print_reg][core=%d] %s %s = %s"
                % (core, label, name, _fmt(ctx.regs.get(name))),
                file=sys.stderr, flush=True,
            )

    def _reg_reinterpret(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_reg_reinterpret")
        dst = kw.get("dst")
        src = kw.get("src")
        self._require_args("micro_reg_reinterpret", dst=dst, src=src)
        dst_dt = self._reg_dtype(dst)
        src_dt = self._reg_dtype(src)
        dst_lanes = _lanes(dst_dt)
        src_lanes = _lanes(src_dt)
        dst_bytes = dst_lanes * int(torch.empty((), dtype=dst_dt).element_size())
        src_bytes = src_lanes * int(torch.empty((), dtype=src_dt).element_size())
        if src_bytes != dst_bytes:
            raise ValueError(
                "micro_reg_reinterpret requires equal register byte width, got "
                + str(src_bytes) + " and " + str(dst_bytes)
            )
        regs = ctx.regs
        if isinstance(regs, _AliasRegDict):
            # Model C++ ReinterpretCast: dst is a LIVE two-way view over src's bytes,
            # so a later write through either name stays in sync (no clone).
            regs.set_alias(self._reg_name(dst), self._reg_name(src),
                           dst_dt, dst_lanes, src_dt, src_lanes)
        else:  # fallback for a plain dict: the historical one-way byte copy
            src_reg = self._get_reg(src)
            raw = src_reg.contiguous().view(torch.uint8).clone()
            regs[self._reg_name(dst)] = raw.view(dst_dt).reshape(dst_lanes)

    def _slice_tensor(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_slice_tensor")
        src = kw.get("src")
        out = kw.get("out")
        self._require_args("micro_slice_tensor", src=src, out=out)
        src_name = self._reg_name(src)
        alias = self._lookup_alias(src_name)
        if alias is None:
            raise KeyError("micro_slice_tensor source view not found: " + src_name)
        offset = self._resolve_offset(src, out, kw)
        out_name = self._reg_name(out)
        advanced = self._alias_advance(alias, offset)
        ctx.tensor_views[out_name] = advanced
        if advanced.logical_offset_bytes is not None:
            ctx.tensor_offsets_bytes[out_name] = int(advanced.logical_offset_bytes)

    def _resolve_offset(self, src: Any, out: Any, kw: Dict) -> int:
        offset = kw.get("offset", getattr(out, "offset", None))
        if offset is None:
            return 0
        if isinstance(offset, (int, float)):
            return int(offset)
        if isinstance(offset, (list, tuple)):
            shape = getattr(src, "shape", [])
            total = 0
            for i, off in enumerate(offset):
                stride = 1
                for j in range(i + 1, len(shape)):
                    stride *= self._num(shape[j])
                total += self._num(off) * stride
            return total
        return self._num(offset)

    # ------------------------------------------------------------------
    # Data movement
    # ------------------------------------------------------------------

    def _c0_block_indices(self, lane_indices: torch.Tensor, esize: int, blk_stride: int) -> torch.Tensor:
        c0 = 32 // esize
        indices = lane_indices.to(dtype=torch.long)
        return (indices // c0) * (blk_stride * c0) + (indices % c0)

    @staticmethod
    def _require_micro_ub_footprint(
        opname: str,
        role: str,
        access: str,
        name: str,
        limit: int,
        indices: torch.Tensor,
        scope: str,
    ) -> None:
        if int(indices.numel()) == 0:
            return
        limit = int(limit)
        indices = indices.to(dtype=torch.long)
        below = indices < 0
        above = indices >= limit
        if bool(below.any().item()) or bool(above.any().item()):
            bad = int(indices[below | above][0].item())
            limit_label = "view_elements" if scope == "tensor view" else "storage_elements"
            message = (
                f"{opname} {role} {access} past UB {scope}: "
                f"{role}={name} active_index={bad} {limit_label}={limit}"
            )
            if scope == "tensor view":
                message += (
                    ". This pointer-style access depends on logical densification not guaranteed by hardware."
                    " Suggested fix: add an explicit mask for inactive tail/NZ/stride lanes, "
                    "or place a padding buffer/dedicated scratch region after this view if the "
                    "extra hardware-width access is intentional and harmless."
                )
                # Severity policy: logical-view-only overruns stay advisory
                # warnings because the physical storage may intentionally include
                # padding or a scratch tail for the hardware-width access.
                warnings.warn(message, LogicalViewAdvisoryWarning, stacklevel=4)
                return
            # Severity policy: physical storage overruns are hard errors.
            message = (
                f"{opname} {role} {access} past UB physical storage: "
                f"{role}={name} active_index={bad} storage_elements={limit}"
            )
            raise RuntimeError(message)

    def _ub2reg(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_ub2reg")
        dst = kw.get("dst")
        src = kw.get("src")
        self._require_args("micro_ub2reg", dst=dst, src=src)
        src_name = self._reg_name(src)
        alias = self._lookup_alias(src_name)
        if alias is None:
            raise KeyError("micro_ub2reg source view not found: " + src_name)
        view = self._alias_logical_view(alias)
        _require_micro_ub_base_32b_aligned(
            "micro_ub2reg", "src", src_name, view,
            logical_offset_bytes=self._alias_logical_offset_bytes(alias),
        )
        logical_flat = view.reshape(-1)
        flat = self._alias_physical_tail(alias)
        logical_count = int(logical_flat.numel())
        storage_count = int(flat.numel())
        if logical_count == 0:
            raise ValueError("micro_ub2reg source view is empty")
        dst_name = self._reg_name(dst)
        dt = self._reg_dtype(dst)
        if dt.itemsize not in (1, 2, 4):
            raise ValueError(
                "micro_ub2reg DATA_BLOCK_COPY only supports b8/b16/b32; "
                "use micro_ub2regcont DIST_NORM for b64"
            )
        lanes = _lanes(dt)
        if dst_name not in ctx.regs:
            ctx.regs[dst_name] = torch.zeros(lanes, dtype=dt)
        dst_reg = ctx.regs[dst_name]
        blk_stride = self._num(kw.get("blk_stride", 1))
        mask = self._resolve_mask(kw.get("mask"), lanes)
        mask = self._expand_mask_c0(mask, dt.itemsize)
        if blk_stride <= 1 and bool(mask.all().item()):
            indices = torch.arange(lanes, dtype=torch.long)
            self._require_micro_ub_footprint(
                "micro_ub2reg", "src", "reads", src_name, logical_count, indices, "tensor view"
            )
            self._require_micro_ub_footprint(
                "micro_ub2reg", "src", "reads", src_name, storage_count, indices, "backing storage"
            )
            n = lanes
            self._vf_on_load(flat, n)
            dst_reg.zero_()
            dst_reg[:n].copy_(flat[:n].to(dt))
            ctx.regs[dst_name] = dst_reg
            return
        active = torch.nonzero(mask, as_tuple=False).view(-1)
        dst_reg.zero_()
        if int(active.numel()) == 0:
            raise ValueError("micro_ub2reg resolved to an empty active mask")
        src_indices = self._c0_block_indices(active, dt.itemsize, blk_stride)
        self._require_micro_ub_footprint(
            "micro_ub2reg", "src", "reads", src_name, logical_count, src_indices, "tensor view"
        )
        self._require_micro_ub_footprint(
            "micro_ub2reg", "src", "reads", src_name, storage_count, src_indices, "backing storage"
        )
        self._vf_on_load_indices(flat, src_indices)
        values = self._gather_1d(flat, src_indices).to(dtype=dt, device=dst_reg.device)
        self._scatter_1d(dst_reg, active, values)
        ctx.regs[dst_name] = dst_reg

    def _reg2ub(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_reg2ub")
        dst = kw.get("dst")
        src = kw.get("src")
        self._require_args("micro_reg2ub", dst=dst, src=src)
        dst_name = self._reg_name(dst)
        alias = self._lookup_alias(dst_name)
        if alias is None:
            raise KeyError("micro_reg2ub destination view not found: " + dst_name)
        view = self._alias_logical_view(alias)
        _require_micro_ub_base_32b_aligned(
            "micro_reg2ub", "dst", dst_name, view,
            logical_offset_bytes=self._alias_logical_offset_bytes(alias),
        )
        logical_flat = view.reshape(-1)
        flat = self._alias_physical_tail(alias)
        logical_count = int(logical_flat.numel())
        storage_count = int(flat.numel())
        if logical_count == 0:
            raise ValueError("micro_reg2ub destination view is empty")
        src_reg = self._get_reg(src)
        if src_reg.dtype.itemsize not in (1, 2, 4):
            raise ValueError(
                "micro_reg2ub DATA_BLOCK_COPY only supports b8/b16/b32; "
                "use micro_reg2ubcont DIST_NORM for b64"
            )
        lanes = int(src_reg.numel())
        blk_stride = self._num(kw.get("blk_stride", 1))
        mask = self._resolve_mask(kw.get("mask"), lanes)
        mask = self._expand_mask_c0(mask, src_reg.dtype.itemsize)
        if blk_stride <= 1 and bool(mask.all().item()):
            indices = torch.arange(lanes, dtype=torch.long)
            self._require_micro_ub_footprint(
                "micro_reg2ub", "dst", "writes", dst_name, logical_count, indices, "tensor view"
            )
            self._require_micro_ub_footprint(
                "micro_reg2ub", "dst", "writes", dst_name, storage_count, indices, "backing storage"
            )
            n = lanes
            self._vf_on_store(flat, n)
            flat[:lanes].copy_(src_reg[:lanes].to(flat.dtype))
            return
        active = torch.nonzero(mask, as_tuple=False).view(-1)
        if int(active.numel()) == 0:
            raise ValueError("micro_reg2ub resolved to an empty active mask")
        dst_indices = self._c0_block_indices(active, src_reg.dtype.itemsize, blk_stride)
        self._require_micro_ub_footprint(
            "micro_reg2ub", "dst", "writes", dst_name, logical_count, dst_indices, "tensor view"
        )
        self._require_micro_ub_footprint(
            "micro_reg2ub", "dst", "writes", dst_name, storage_count, dst_indices, "backing storage"
        )
        self._vf_on_store_indices(flat, dst_indices)
        values = self._gather_1d(src_reg, active).to(dtype=flat.dtype, device=flat.device)
        self._scatter_1d(flat, dst_indices, values)

    def _resolve_mask(self, mask_ref: Any, lanes: int) -> torch.Tensor:
        if mask_ref is None:
            raise ValueError("mask is required")
        ctx = self._require_ctx("mask resolution")
        name = self._reg_name(mask_ref) if hasattr(mask_ref, "name") else str(mask_ref)
        if name in ctx.masks:
            bits = ctx.masks[name]
            if int(bits.numel()) == lanes:
                return bits
            raise ValueError("mask register lane mismatch: " + name)
        raise KeyError("mask register not found: " + name)

    def _expand_mask_c0(self, mask: torch.Tensor, esize: int) -> torch.Tensor:
        lanes = int(mask.numel())
        c0 = 32 // esize
        if lanes % c0 != 0:
            return mask
        blocks = mask.view(lanes // c0, c0)
        return blocks.any(dim=1, keepdim=True).expand(-1, c0).reshape(-1)

    def _ub2regcont(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_ub2regcont")
        dst_ref = kw.get("dst")
        src = kw.get("src")
        self._require_args("micro_ub2regcont", dst=dst_ref, src=src)
        src_name = self._reg_name(src)
        alias = self._lookup_alias(src_name)
        if alias is None:
            raise KeyError("micro_ub2regcont source view not found: " + src_name)
        view = self._alias_logical_view(alias)
        offset = self._num(kw.get("offset", 0))
        logical_flat = view.reshape(-1)
        flat = self._alias_physical_tail(alias)
        if int(logical_flat.numel()) == 0:
            raise ValueError("micro_ub2regcont source view is empty")
        count = int(getattr(dst_ref, "length", 0))
        base_name = self._reg_name(dst_ref)
        dt = self._reg_dtype(dst_ref)
        created_reg = ctx.regs.get(base_name)
        lanes = (
            int(created_reg.numel()) if created_reg is not None
            else _lanes(dt) * int(getattr(dst_ref, "reg_num", 1))
        )

        if count > 0:
            _require_micro_ub_base_32b_aligned(
                "micro_ub2regcont", "src", src_name, view,
                logical_offset_bytes=self._alias_logical_offset_bytes(alias),
            )
            _require_micro_ub_access_32b_aligned(
                "micro_ub2regcont", "src", src_name, view, offset,
                logical_offset_bytes=self._alias_logical_offset_bytes(alias),
            )
            for i in range(count):
                name = "%s[%d]" % (base_name, i)
                start = offset + i * lanes
                data = flat[start:start + lanes]
                reg = torch.zeros(lanes, dtype=dt)
                n = min(lanes, int(data.numel()))
                if n > 0:
                    self._vf_on_load_indices(flat, torch.arange(start, start + n, dtype=torch.long))
                    reg[:n].copy_(data[:n].to(dt))
                ctx.regs[name] = reg
            return

        mode = str(kw.get("mode", "")).strip().upper()
        esize = dt.itemsize
        expected = _MODE_ELEM_MAP.get(mode)
        if expected is not None and esize != expected:
            raise ValueError(
                "micro_ub2regcont mode "
                + mode
                + " is incompatible with element size "
                + str(esize)
            )
        if _ub2regcont_mode_requires_32b(mode):
            _require_micro_ub_base_32b_aligned(
                "micro_ub2regcont", "src", src_name, view,
                logical_offset_bytes=self._alias_logical_offset_bytes(alias),
            )
            _require_micro_ub_access_32b_aligned(
                "micro_ub2regcont", "src", src_name, view, offset,
                logical_offset_bytes=self._alias_logical_offset_bytes(alias),
            )

        reg = torch.zeros(lanes, dtype=dt)
        src_flat = flat[offset:] if offset > 0 else flat

        def _to_dt(v: torch.Tensor) -> torch.Tensor:
            return v.to(dt) if v.dtype != dt else v

        if mode == "DIST_NORM":
            if esize not in (1, 2, 4, 8):
                raise ValueError(
                    "micro_ub2regcont mode DIST_NORM is incompatible with element size " + str(esize)
                )
            indices = torch.arange(offset, offset + lanes, dtype=torch.long)
            self._require_micro_ub_footprint(
                "micro_ub2regcont", "src", "reads", src_name,
                int(logical_flat.numel()), indices, "tensor view",
            )
            self._require_micro_ub_footprint(
                "micro_ub2regcont", "src", "reads", src_name,
                int(flat.numel()), indices, "backing storage",
            )
            self._vf_on_load_indices(flat, indices)
            reg.copy_(_to_dt(src_flat[:lanes]))

        elif mode.startswith("DIST_BRC_"):
            if int(src_flat.numel()) >= 1:
                self._vf_on_load_indices(flat, torch.tensor([offset], dtype=torch.long))
                reg.fill_(_to_dt(src_flat[:1])[0])

        elif mode.startswith("DIST_DS_"):
            required = lanes * 2
            n = min(required, int(src_flat.numel()))
            idx = torch.arange(min(lanes, n // 2), dtype=torch.long) * 2
            self._vf_on_load_indices(flat, idx + offset)
            _index_assign(reg, slice(0, int(idx.numel())), _to_dt(src_flat[idx]))

        elif mode.startswith("DIST_US_"):
            required = lanes // 2
            n = min(required, int(src_flat.numel()))
            if n > 0:
                self._vf_on_load_indices(flat, torch.arange(offset, offset + n, dtype=torch.long))
                reg[:n * 2].copy_(_to_dt(src_flat[:n]).repeat_interleave(2))

        elif mode.startswith("DIST_UNPACK4_"):
            required = lanes // 4
            n = min(required, int(src_flat.numel()))
            if n > 0:
                self._vf_on_load_indices(flat, torch.arange(offset, offset + n, dtype=torch.long))
                idx = torch.arange(0, n * 4, 4, dtype=torch.long)
                _index_assign(reg, idx, _to_dt(src_flat[:n]))

        elif mode.startswith("DIST_UNPACK_"):
            required = lanes // 2
            n = min(required, int(src_flat.numel()))
            if n > 0:
                self._vf_on_load_indices(flat, torch.arange(offset, offset + n, dtype=torch.long))
                idx = torch.arange(0, n * 2, 2, dtype=torch.long)
                _index_assign(reg, idx, _to_dt(src_flat[:n]))

        elif mode.startswith("DIST_E2B_"):
            c0 = 32 // esize
            block_count = lanes // c0
            n = min(block_count, int(src_flat.numel()))
            if n > 0:
                self._vf_on_load_indices(flat, torch.arange(offset, offset + n, dtype=torch.long))
                vals = _to_dt(src_flat[:n])
                reg.copy_(vals.view(n, 1).expand(n, c0).reshape(-1)[:lanes])

        else:
            raise ValueError("unsupported micro_ub2regcont mode: " + mode)

        ctx.regs[base_name] = reg

    def _ub2reginterleave(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_ub2reginterleave")
        dst0_ref = kw.get("dst0")
        dst1_ref = kw.get("dst1")
        src = kw.get("src")
        self._require_args("micro_ub2reginterleave", dst0=dst0_ref, dst1=dst1_ref, src=src)
        src_name = self._reg_name(src)
        alias = self._lookup_alias(src_name)
        if alias is None:
            raise KeyError("micro_ub2reginterleave source view not found: " + src_name)
        view = self._alias_logical_view(alias)
        offset = self._num(kw.get("offset", 0))
        logical_flat = view.reshape(-1)
        flat = self._alias_physical_tail(alias)
        if int(logical_flat.numel()) == 0:
            raise ValueError("micro_ub2reginterleave source view is empty")

        dst0_name = self._reg_name(dst0_ref)
        dst1_name = self._reg_name(dst1_ref)
        dt0 = self._reg_dtype(dst0_ref)
        dt1 = self._reg_dtype(dst1_ref)
        if dt0 != dt1:
            raise ValueError("micro_ub2reginterleave dst0/dst1 data types must match")
        lanes = _lanes(dt0)
        esize = dt0.itemsize
        mode = str(kw.get("mode", "")).strip().upper()
        if not mode.startswith("DIST_DINTLV_"):
            raise ValueError("unsupported micro_ub2reginterleave mode: " + mode)
        expected = _MODE_ELEM_MAP.get(mode)
        if expected is None:
            raise ValueError("unsupported micro_ub2reginterleave mode: " + mode)
        if esize != expected:
            raise ValueError(
                "micro_ub2reginterleave mode "
                + mode
                + " is incompatible with element size "
                + str(esize)
            )

        _require_micro_ub_base_32b_aligned(
            "micro_ub2reginterleave", "src", src_name, view,
            logical_offset_bytes=self._alias_logical_offset_bytes(alias),
        )
        _require_micro_ub_access_32b_aligned(
            "micro_ub2reginterleave", "src", src_name, view, offset,
            logical_offset_bytes=self._alias_logical_offset_bytes(alias),
        )

        read_count = lanes * 2
        indices = torch.arange(offset, offset + read_count, dtype=torch.long)
        self._require_micro_ub_footprint(
            "micro_ub2reginterleave", "src", "reads", src_name,
            int(logical_flat.numel()), indices, "tensor view",
        )
        self._require_micro_ub_footprint(
            "micro_ub2reginterleave", "src", "reads", src_name,
            int(flat.numel()), indices, "backing storage",
        )
        self._vf_on_load_indices(flat, indices)

        src_flat = flat[offset:offset + read_count]
        reg0 = torch.zeros(lanes, dtype=dt0)
        reg1 = torch.zeros(lanes, dtype=dt1)

        def _to_dt(v: torch.Tensor) -> torch.Tensor:
            return v.to(dt0) if v.dtype != dt0 else v

        reg0.copy_(_to_dt(src_flat[0::2]))
        reg1.copy_(_to_dt(src_flat[1::2]))
        ctx.regs[dst0_name] = reg0
        ctx.regs[dst1_name] = reg1

    def _reg2ubcont(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_reg2ubcont")
        dst = kw.get("dst")
        src_ref = kw.get("src")
        self._require_args("micro_reg2ubcont", dst=dst, src=src_ref)
        dst_name = self._reg_name(dst)
        alias = self._lookup_alias(dst_name)
        if alias is None:
            raise KeyError("micro_reg2ubcont destination view not found: " + dst_name)
        view = self._alias_logical_view(alias)
        offset = self._num(kw.get("offset", 0))
        logical_flat = view.reshape(-1)
        flat = self._alias_physical_tail(alias)
        if int(logical_flat.numel()) == 0:
            raise ValueError("micro_reg2ubcont destination view is empty")
        count = int(getattr(src_ref, "length", 0))
        base_name = self._reg_name(src_ref)

        if count > 0:
            dt = self._reg_dtype(src_ref)
            lanes = _lanes(dt)
            _require_micro_ub_base_32b_aligned(
                "micro_reg2ubcont", "dst", dst_name, view,
                logical_offset_bytes=self._alias_logical_offset_bytes(alias),
            )
            _require_micro_ub_access_32b_aligned(
                "micro_reg2ubcont", "dst", dst_name, view, offset,
                logical_offset_bytes=self._alias_logical_offset_bytes(alias),
            )
            for i in range(count):
                name = "%s[%d]" % (base_name, i)
                reg = ctx.regs.get(name)
                if reg is None:
                    raise KeyError("micro_reg2ubcont source register not found: " + name)
                start = offset + i * lanes
                n = min(int(reg.numel()), int(flat.numel()) - start)
                if n > 0:
                    self._vf_on_store_indices(flat, torch.arange(start, start + n, dtype=torch.long))
                    flat[start:start + n].copy_(reg[:n].to(flat.dtype))
            return

        reg = ctx.regs.get(base_name)
        if reg is None:
            raise KeyError("micro_reg2ubcont source register not found: " + base_name)
        lanes = int(reg.numel())
        esize = reg.dtype.itemsize
        mode = str(kw.get("mode", "")).strip().upper()
        if mode == "DIST_NORM" and esize != 8:
            raise ValueError(
                "micro_reg2ubcont mode DIST_NORM is reserved for 64-bit normal stores, "
                "got element size " + str(esize)
            )

        expected = _MODE_ELEM_MAP.get(mode)
        if expected is not None and esize != expected:
            raise ValueError(
                "micro_reg2ubcont mode "
                + mode
                + " is incompatible with element size "
                + str(esize)
            )
        if _reg2ubcont_mode_requires_32b(mode):
            _require_micro_ub_base_32b_aligned(
                "micro_reg2ubcont", "dst", dst_name, view,
                logical_offset_bytes=self._alias_logical_offset_bytes(alias),
            )
            _require_micro_ub_access_32b_aligned(
                "micro_reg2ubcont", "dst", dst_name, view, offset,
                logical_offset_bytes=self._alias_logical_offset_bytes(alias),
            )

        mask = self._resolve_mask(kw.get("mask"), lanes)
        if not (mode == "DIST_NORM" or mode.startswith("DIST_NORM_")):
            mask = self._expand_mask_c0(mask, esize)

        if mode == "DIST_NORM" or mode.startswith("DIST_NORM_"):
            # NORMAL: the full 256-byte register is copied contiguously to the 32B-aligned dst
            # (alignment enforced above). Check the write footprint like the plain reg2ub store
            # this replaces -- a logical-view overrun is advisory (the dst needs trailing
            # padding/scratch to absorb the full hardware-width write), a physical-storage
            # overrun is a hard error.
            src_indices = torch.arange(lanes, dtype=torch.long)
            dst_indices = src_indices.clone()
            write_idx = dst_indices + offset
            self._require_micro_ub_footprint(
                "micro_reg2ubcont", "dst", "writes", dst_name,
                int(logical_flat.numel()), write_idx, "tensor view",
            )
            self._require_micro_ub_footprint(
                "micro_reg2ubcont", "dst", "writes", dst_name,
                int(flat.numel()), write_idx, "backing storage",
            )
        elif mode.startswith("DIST_PACK4_"):
            out_count = lanes // 4
            dst_indices = torch.arange(out_count, dtype=torch.long)
            src_indices = dst_indices * 4
        elif mode.startswith("DIST_PACK_"):
            out_count = lanes // 2
            dst_indices = torch.arange(out_count, dtype=torch.long)
            src_indices = dst_indices * 2
        elif mode.startswith("DIST_FIRST_ELEMENT_"):
            src_indices = torch.zeros(1, dtype=torch.long)
            dst_indices = torch.zeros(1, dtype=torch.long)
        else:
            raise ValueError("unsupported micro_reg2ubcont mode: " + mode)

        selected = mask[src_indices]
        sel_src = src_indices[selected]
        sel_dst = dst_indices[selected] + offset
        valid = sel_dst < int(flat.numel())
        if int(valid.sum()) > 0:
            self._vf_on_store_indices(flat, sel_dst[valid])
            values = self._gather_1d(reg, sel_src[valid])
            self._scatter_1d(flat, sel_dst[valid], values)

    def _reg2ubinterleave(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_reg2ubinterleave")
        dst = kw.get("dst")
        src0_ref = kw.get("src0")
        src1_ref = kw.get("src1")
        self._require_args(
            "micro_reg2ubinterleave", dst=dst, src0=src0_ref, src1=src1_ref,
        )
        dst_name = self._reg_name(dst)
        alias = self._lookup_alias(dst_name)
        if alias is None:
            raise KeyError(
                "micro_reg2ubinterleave destination view not found: " + dst_name
            )
        view = self._alias_logical_view(alias)
        offset = self._num(kw.get("offset", 0))
        logical_flat = view.reshape(-1)
        flat = self._alias_physical_tail(alias)
        if int(logical_flat.numel()) == 0:
            raise ValueError("micro_reg2ubinterleave destination view is empty")

        src0_name = self._reg_name(src0_ref)
        src1_name = self._reg_name(src1_ref)
        reg0 = ctx.regs.get(src0_name)
        reg1 = ctx.regs.get(src1_name)
        if reg0 is None:
            raise KeyError(
                "micro_reg2ubinterleave source register not found: " + src0_name
            )
        if reg1 is None:
            raise KeyError(
                "micro_reg2ubinterleave source register not found: " + src1_name
            )
        if reg0.dtype != reg1.dtype:
            raise ValueError("micro_reg2ubinterleave src0/src1 data types must match")
        lanes = int(reg0.numel())
        if int(reg1.numel()) != lanes:
            raise ValueError("micro_reg2ubinterleave src0/src1 lane counts must match")
        esize = reg0.dtype.itemsize
        mode = str(kw.get("mode", "")).strip().upper()
        if not mode.startswith("DIST_INTLV_"):
            raise ValueError("unsupported micro_reg2ubinterleave mode: " + mode)
        expected = _MODE_ELEM_MAP.get(mode)
        if expected is None:
            raise ValueError("unsupported micro_reg2ubinterleave mode: " + mode)
        if esize != expected:
            raise ValueError(
                "micro_reg2ubinterleave mode "
                + mode
                + " is incompatible with element size "
                + str(esize)
            )

        _require_micro_ub_base_32b_aligned(
            "micro_reg2ubinterleave", "dst", dst_name, view,
            logical_offset_bytes=self._alias_logical_offset_bytes(alias),
        )
        _require_micro_ub_access_32b_aligned(
            "micro_reg2ubinterleave", "dst", dst_name, view, offset,
            logical_offset_bytes=self._alias_logical_offset_bytes(alias),
        )

        # The dual store writes 2 * VL elements: dst[2k] = src0[k], dst[2k+1] = src1[k].
        # The mask is a single VL-lane register applied to both source lanes, the same
        # way the hardware interleaves it into the two halves of the 512-byte write.
        mask = self._resolve_mask(kw.get("mask"), lanes)
        write_idx = torch.arange(lanes * 2, dtype=torch.long) + offset
        self._require_micro_ub_footprint(
            "micro_reg2ubinterleave", "dst", "writes", dst_name,
            int(logical_flat.numel()), write_idx, "tensor view",
        )
        self._require_micro_ub_footprint(
            "micro_reg2ubinterleave", "dst", "writes", dst_name,
            int(flat.numel()), write_idx, "backing storage",
        )
        lane_idx = torch.arange(lanes, dtype=torch.long)
        selected = mask[lane_idx]
        sel_lane = lane_idx[selected]
        if int(sel_lane.numel()) == 0:
            return
        dst_even = sel_lane * 2 + offset
        dst_odd = dst_even + 1
        sel_dst = torch.cat((dst_even, dst_odd))
        valid = sel_dst < int(flat.numel())
        if int(valid.sum()) == 0:
            return
        values = torch.cat((
            self._gather_1d(reg0, sel_lane), self._gather_1d(reg1, sel_lane),
        ))
        self._vf_on_store_indices(flat, sel_dst[valid])
        self._scatter_1d(flat, sel_dst[valid], values[valid])

    def _arange(self, kw: Dict) -> None:
        dst = kw.get("dst")
        dt = self._reg_dtype(dst)
        dtype_name = _logical_dtype_name(dst) if hasattr(dst, "dtype") else normalize_dtype(dt)
        allowed = ("int8", "int16", "int32", "int64", "float16", "float32")
        if dtype_name not in allowed:
            raise TypeError(
                "micro_arange only supports int8/int16/int32/int64/half/float, "
                "got " + dtype_name
            )
        lanes = _lanes(dt)
        mode = str(kw.get("mode", ""))
        if "v" in kw or mode:
            start_value = self._numf(kw.get("v", 0))
            increase = mode.endswith("INCREASE_ORDER")
            compute_dtype = torch.float64 if torch.empty((), dtype=dt).is_floating_point() else torch.int64
            indices = torch.arange(lanes, dtype=compute_dtype)
            base = float(start_value) if torch.empty((), dtype=dt).is_floating_point() else int(start_value)
            out = indices + base if increase else base - indices
            self._set_reg(dst, out.to(dt))
            return

        start = self._numf(kw.get("start", 0))
        step = self._numf(kw.get("step", 1))
        self._set_reg(dst, torch.arange(start, start + step * lanes, step, dtype=dt)[:lanes])

    # ------------------------------------------------------------------
    # Gather / scatter (register-level)
    # ------------------------------------------------------------------

    def _datacopygather(self, kw: Dict) -> None:
        self._require_ctx("micro_datacopygather")
        dst = kw.get("dst")
        src = kw.get("src")
        idx = kw.get("index", kw.get("idx"))
        self._require_args("micro_datacopygather", dst=dst, src=src, index=idx)
        src_name = self._reg_name(src)
        alias = self._lookup_alias(src_name)
        if alias is None:
            raise KeyError("micro_datacopygather source view not found: " + src_name)
        view = self._alias_physical_tail(alias)
        flat = view.reshape(-1)
        dst_reg = self._get_reg(dst)
        idx_reg = self._get_reg(idx)
        src_size = int(flat.element_size())
        dst_size = int(dst_reg.element_size())
        if src_size == 1:
            if dst_size != 2:
                raise ValueError("micro_datacopygather with 8-bit source requires a 16-bit destination register")
            self._require_index_dtype("micro_datacopygather", src_size, idx, ("uint16",))
        elif src_size == 2:
            if dst_size != 2:
                raise ValueError("micro_datacopygather requires dst/src element sizes to match for 16-bit data")
            self._require_index_dtype("micro_datacopygather", src_size, idx, ("uint16",))
        elif src_size == 4:
            if dst_size != 4:
                raise ValueError("micro_datacopygather requires dst/src element sizes to match for 32-bit data")
            self._require_index_dtype("micro_datacopygather", src_size, idx, ("uint32",))
        elif src_size == 8:
            if dst_size != 8:
                raise ValueError("micro_datacopygather requires dst/src element sizes to match for 64-bit data")
            self._require_index_dtype("micro_datacopygather", src_size, idx, ("uint32", "uint64"))
        else:
            raise ValueError("micro_datacopygather only supports 8-bit, 16-bit, 32-bit, or 64-bit data")
        indices = idx_reg.to(torch.long)
        dst_reg.zero_()
        if kw.get("mask") is None:
            mask = torch.ones(int(dst_reg.numel()), dtype=torch.bool)
        else:
            mask = self._resolve_mask(kw.get("mask"), int(dst_reg.numel()))
        active = torch.nonzero(mask, as_tuple=False).view(-1)
        if int(active.numel()) == 0:
            # Legal no-op, symmetric with the scatter above: the destination was
            # already zeroed and `DataCopyGather` reads only the active lanes, so
            # an all-zero mask leaves a zeroed register and touches no source.
            self._set_reg(dst, dst_reg)
            return
        active_indices = indices[active]
        if bool((active_indices < 0).any().item()) or bool((active_indices >= int(flat.numel())).any().item()):
            bad = int(active_indices[(active_indices < 0) | (active_indices >= int(flat.numel()))][0].item())
            raise IndexError("micro_datacopygather source index out of range: " + str(bad))
        self._vf_check_gather_publication(
            src_name, flat, active_indices,
        )
        self._vf_on_load_indices(flat, active_indices)
        values = self._gather_1d(flat, active_indices)
        if src_size == 1 and dst_size == 2:
            # b8 -> b16 gather zero-extends the source byte: low 8 bits = byte,
            # high 8 bits = 0 (board-verified 2026-07-21, NOT a numeric/sign
            # convert). Reinterpret the 0x00XX bit pattern into the dst dtype.
            zero_ext = values.reshape(-1).view(torch.uint8).to(torch.int16)
            values = zero_ext.view(dst_reg.dtype)
        elif values.dtype != dst_reg.dtype:
            values = values.to(dst_reg.dtype)
        self._scatter_1d(dst_reg, active, values)
        self._set_reg(dst, dst_reg)

    def _gatherb(self, kw: Dict) -> None:
        # MicroAPI::GatherB (vgatherb): output DataBlock i is the 32-byte block at src byte
        # offset index[i], where index[i] is read from index-reg LANE i (uint32, >=0, 32B
        # aligned). Within a block, lane l reads the l-th element. Board-verified 2026-07-21
        # (gatherb_probe lane_i_byteoff): index [0,32,64,...] -> src blocks 0,1,2,...
        self._require_ctx("micro_gatherb")
        dst = kw.get("dst")
        src = kw.get("src")
        idx = kw.get("index")
        self._require_args("micro_gatherb", dst=dst, src=src, index=idx)
        alias = self._lookup_alias(self._reg_name(src))
        if alias is None:
            raise KeyError("micro_gatherb source view not found: " + self._reg_name(src))
        flat = self._alias_physical_tail(alias).reshape(-1)
        dst_reg = self._get_reg(dst)
        idx_reg = self._get_reg(idx).to(torch.long)
        elem_size = int(dst_reg.element_size())
        if 32 % elem_size != 0:
            raise ValueError("micro_gatherb unsupported element size: " + str(elem_size))
        block_elems = 32 // elem_size            # elements per 32-byte DataBlock
        n_block = int(dst_reg.numel()) // block_elems
        out = dst_reg.clone()
        for i in range(n_block):
            byte_off = int(idx_reg[i])
            if byte_off < 0 or (byte_off % 32) != 0:
                raise ValueError("micro_gatherb byte offset must be >=0 and 32B-aligned: " + str(byte_off))
            elem_off = byte_off // elem_size
            if elem_off + block_elems > int(flat.numel()):
                raise IndexError("micro_gatherb source block out of range at byte " + str(byte_off))
            blk = flat[elem_off:elem_off + block_elems]
            if blk.dtype != out.dtype:
                blk = blk.view(out.dtype) if int(blk.element_size()) == elem_size else blk.to(out.dtype)
            out[i * block_elems:(i + 1) * block_elems] = blk
        self._set_reg(dst, self._apply_exec_mask_zero(dst, out, kw.get("mask")))

    def _datacopyscatter(self, kw: Dict) -> None:
        self._require_ctx("micro_datacopyscatter")
        dst = kw.get("dst")
        src = kw.get("src")
        idx = kw.get("index", kw.get("idx"))
        self._require_args("micro_datacopyscatter", dst=dst, src=src, index=idx)
        dst_name = self._reg_name(dst)
        alias = self._lookup_alias(dst_name)
        if alias is None:
            raise KeyError("micro_datacopyscatter destination view not found: " + dst_name)
        view = self._alias_physical_tail(alias)
        flat = view.reshape(-1)
        src_reg = self._get_reg(src)
        idx_reg = self._get_reg(idx)
        dst_size = int(flat.element_size())
        src_size = int(src_reg.element_size())
        if dst_size != src_size:
            raise ValueError("micro_datacopyscatter requires dst/src element sizes to match")
        if src_size == 1:
            self._require_index_dtype("micro_datacopyscatter", src_size, idx, ("uint16",))
        elif src_size == 2:
            self._require_index_dtype("micro_datacopyscatter", src_size, idx, ("uint16",))
        elif src_size == 4:
            self._require_index_dtype("micro_datacopyscatter", src_size, idx, ("uint32",))
        elif src_size == 8:
            self._require_index_dtype("micro_datacopyscatter", src_size, idx, ("uint32", "uint64"))
        else:
            raise ValueError("micro_datacopyscatter only supports 8-bit, 16-bit, 32-bit, or 64-bit data")
        indices = idx_reg.to(torch.long)
        if kw.get("mask") is None:
            mask = torch.ones(int(src_reg.numel()), dtype=torch.bool)
        else:
            mask = self._resolve_mask(kw.get("mask"), int(src_reg.numel()))
        # DataCopyScatter's mask is LANE-WISE - it is NOT expanded to whole C0
        # blocks the way the continuous reg <-> UB paths are, because a scatter
        # writes individual elements rather than 32-byte blocks.  Board-verified
        # on the Ascend950 (2026-07-29, kernels/a5/vec_only/scatter_mask_probe.py):
        # 5 active lanes out of an 8-lane b32 block write exactly 5 elements, and
        # an even-lane mask on a b16 register keeps the odd lanes from clobbering
        # the cast results they share an index with.
        if src_size == 1:
            # b8 scatter (u16 index): the b8 src reg holds 256 lanes but a u16 index
            # only 128, and the hardware moves ONLY the EVEN source lanes -- element k
            # writes flat[index[k]] = src[2k] for k in 0..(index_lanes-1); the odd
            # source bytes are ignored (board-verified 2026-07-21).
            n_idx = int(idx_reg.numel())
            elems = torch.arange(n_idx)
            src_lanes = 2 * elems
            keep = mask.reshape(-1)[src_lanes].bool()
            src_lanes = src_lanes[keep]
            active_indices = indices[elems[keep]]
        else:
            src_lanes = torch.nonzero(mask, as_tuple=False).view(-1)
            active_indices = indices[src_lanes]
        if int(src_lanes.numel()) == 0:
            # An all-zero mask is a legal no-op: `DataCopyScatter` writes only the
            # active lanes, so zero of them writes nothing.  A runtime-computed
            # mask reaches this state honestly -- a tail slot past the live output
            # count, or a stream-compaction group that holds no survivor -- and
            # rejecting it made the simulator stricter than the device.
            return
        if bool((active_indices < 0).any().item()) or bool((active_indices >= int(flat.numel())).any().item()):
            bad = int(active_indices[(active_indices < 0) | (active_indices >= int(flat.numel()))][0].item())
            raise IndexError("micro_datacopyscatter destination index out of range: " + str(bad))
        self._warn_scatter_past_logical(dst_name, alias, active_indices)
        self._vf_record_scatter(flat, active_indices)
        self._vf_on_store_indices(flat, active_indices)
        values = self._gather_1d(src_reg, src_lanes)
        self._scatter_1d(flat, active_indices, values)

    def _warn_scatter_past_logical(self, dst_name, alias, active_indices) -> None:
        """Report a scatter that leaves its destination tensor.

        The hardware bound is the physical UB allocation, so an index past the
        named tensor lands silently in whatever tensor follows it -- the same
        corruption the board shows, which makes it invisible in a value-only
        comparison.  The check is a warning rather than an error because the
        scatter is legal hardware, but a kernel that does it is very nearly
        always mis-sized.
        """
        logical = getattr(alias, "logical_view", None)
        if logical is None:
            return
        limit = int(logical.reshape(-1).numel())
        if limit <= 0:
            return
        worst = int(active_indices.max().item())
        if worst < limit:
            return
        seen = getattr(self, "_scatter_overrun_seen", None)
        if seen is None:
            seen = set()
            setattr(self, "_scatter_overrun_seen", seen)
        key = (str(dst_name), limit)
        if key in seen:
            return
        seen.add(key)
        sys.stderr.write(
            "[simulator] micro_datacopyscatter writes past the destination "
            "tensor: dst=" + str(dst_name) + " holds " + str(limit)
            + " elements, index reaches " + str(worst)
            + " (the overflow silently overwrites the next tensor in UB, "
            "exactly as it does on board)\n"
        )

    def _gather_reg(self, kw: Dict) -> None:
        dst = kw.get("dst")
        src = kw.get("src")
        idx = kw.get("index", kw.get("idx"))
        self._require_args("micro_gather", dst=dst, src=src, index=idx)
        src_reg = self._get_reg(src).clone()
        dst_reg = self._get_reg(dst)
        src_size = int(src_reg.element_size())
        dst_size = int(dst_reg.element_size())
        if dst_size != src_size:
            raise ValueError("micro_gather requires dst/src element sizes to match")
        if src_size == 1:
            self._require_index_dtype("micro_gather", src_size, idx, ("uint8",))
        elif src_size == 2:
            self._require_index_dtype("micro_gather", src_size, idx, ("uint16",))
        elif src_size == 4:
            self._require_index_dtype("micro_gather", src_size, idx, ("uint32",))
        else:
            raise ValueError("micro_gather only supports 8-bit, 16-bit, or 32-bit data")
        idx_reg = self._get_reg(idx)
        indices = idx_reg.to(torch.long)
        values = self._gather_1d(src_reg, indices)
        out = torch.zeros_like(dst_reg)
        n = min(int(values.numel()), int(out.numel()))
        if n > 0:
            active = torch.arange(n, dtype=torch.long)
            self._scatter_1d(out, active, values[:n])
        self._set_reg(dst, out)

    def _gathermask(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_gathermask")
        dst = kw.get("dst")
        src = kw.get("src")
        mask_ref = kw.get("mask")
        self._require_args("micro_gathermask", dst=dst, src=src)
        src_reg = self._get_reg(src).clone()
        if mask_ref is None:
            raise ValueError("micro_gathermask requires mask")
        else:
            name = self._reg_name(mask_ref) if hasattr(mask_ref, "name") else str(mask_ref)
            mask_bits = ctx.masks.get(name)
            if mask_bits is None:
                raise KeyError("mask register not found: " + name)
        sel_bits = mask_bits[:int(src_reg.numel())]
        if src_reg.element_size() == 1 and src_reg.dtype not in (torch.int8, torch.uint8, torch.bool):
            selected = src_reg.view(torch.uint8)[sel_bits].view(src_reg.dtype)  # float8 has no index_cpu
        else:
            selected = src_reg[sel_bits]
        dst_reg = self._get_reg(dst)
        dst_reg.zero_()
        selected_count = int(selected.numel())
        if selected_count > 0:
            if selected.dtype != dst_reg.dtype:
                selected = selected.to(dst_reg.dtype)
            dst_reg[:selected_count].copy_(selected)
        self._set_reg(dst, dst_reg)

    def _squeeze(self, kw: Dict) -> None:
        # MicroAPI::Squeeze: copy the mask-selected src elements into the LOW end of dst,
        # packed contiguously low-to-high, remaining lanes zeroed. Same functional model as
        # GatherMask; the device intrinsic differs (single-shot stream compaction).
        ctx = self._require_ctx("micro_squeeze")
        dst = kw.get("dst")
        src = kw.get("src")
        mask_ref = kw.get("mask")
        self._require_args("micro_squeeze", dst=dst, src=src)
        src_reg = self._get_reg(src).clone()
        if mask_ref is None:
            raise ValueError("micro_squeeze requires mask")
        name = self._reg_name(mask_ref) if hasattr(mask_ref, "name") else str(mask_ref)
        mask_bits = ctx.masks.get(name)
        if mask_bits is None:
            raise KeyError("mask register not found: " + name)
        sel_bits = mask_bits[:int(src_reg.numel())]
        if src_reg.element_size() == 1 and src_reg.dtype not in (torch.int8, torch.uint8, torch.bool):
            selected = src_reg.view(torch.uint8)[sel_bits].view(src_reg.dtype)  # float8 has no index_cpu
        else:
            selected = src_reg[sel_bits]
        dst_reg = self._get_reg(dst)
        selected_count = int(selected.numel())
        if selected.dtype != dst_reg.dtype:
            selected = selected.to(dst_reg.dtype)
        dst_reg.zero_()
        if selected_count > 0:
            dst_reg[:selected_count].copy_(selected)
        if bool(kw.get("store")):
            # STORE_REG: the DATA still lands at the LOW end (same as NO_STORE) -- AR only
            # ACCUMULATES the valid-element COUNT (readable via GetSpr), it is NOT a write
            # offset, so a 2nd store squeeze OVERWRITES dst[0:n] rather than appending.
            # cannsim-verified 2026-07-01 (tmp/squeeze_probe/store_concat_probe.py).
            ctx.ar = int(getattr(ctx, "ar", 0)) + selected_count
        self._set_reg(dst, dst_reg)

    def _unsqueeze(self, kw: Dict) -> None:
        # MicroAPI::Unsqueeze (PrefixSumImpl): in-place EXCLUSIVE prefix-sum (scan) of the mask
        # bits. dst[i] = number of active mask lanes STRICTLY before lane i (the rank of lane i
        # among the active lanes); lanes at/after the last active one all carry the total count.
        # The input dst values are IGNORED -- the result is a pure function of the mask. This is
        # the index-generation primitive that feeds Squeeze/GatherMask addressing, NOT the inverse
        # of Squeeze. Board-verified 2026-07-21 (kernels/a5/vec_only/unsqueeze_onboard.py).
        ctx = self._require_ctx("micro_unsqueeze")
        dst = kw.get("dst")
        mask_ref = kw.get("mask")
        self._require_args("micro_unsqueeze", dst=dst)
        dst_reg = self._get_reg(dst)
        n = int(dst_reg.numel())
        if mask_ref is None:
            raise ValueError("micro_unsqueeze requires mask")
        name = self._reg_name(mask_ref) if hasattr(mask_ref, "name") else str(mask_ref)
        mask_bits = ctx.masks.get(name)
        if mask_bits is None:
            raise KeyError("mask register not found: " + name)
        bits = mask_bits[:n].to(torch.int64)
        excl = torch.zeros(n, dtype=torch.int64)
        if n > 1:
            excl[1:] = torch.cumsum(bits, dim=0)[:-1]  # exclusive scan: count strictly-before
        self._set_reg(dst, excl.to(dst_reg.dtype))

    def _clear_spr(self, kw: Dict) -> None:
        # MicroAPI::ClearSpr<AR>: reset the Squeeze STORE_REG output counter to 0.
        ctx = self._require_ctx("micro_clear_spr")
        ctx.ar = 0

    def _mask_to_ub(self, kw: Dict) -> None:
        # MicroAPI::StoreAlign(__ubuf__ T*, MaskReg&): write the FULL 32-byte (256-bit) vector
        # mask register to UB. The A5 vector mask is byte-granular: element-lane i of a mask whose
        # element size is S bytes owns bit position i*S (LSB-first, little-endian); the in-between
        # bits (for S>1) and inactive lanes are 0. StoreAlign always emits 32 bytes regardless of
        # the UB tensor dtype. Board-verified 2026-07-21 (kernels/a5/vec_only/mask_probe.py).
        ctx = self._require_ctx("micro_mask_to_ub")
        dst = kw.get("dst")           # UB Tensor
        src = kw.get("src")           # MaskReg
        self._require_args("micro_mask_to_ub", dst=dst, src=src)
        mname = self._reg_name(src)
        mask_bits = ctx.masks.get(mname)
        if mask_bits is None:
            raise KeyError("micro_mask_to_ub mask register not found: " + mname)
        s = int(self._reg_dtype(src).itemsize)      # element bytes -> mask-bit stride
        vl = _VL_BYTES // s                          # lanes covered by this mask dtype
        nbytes = _VL_BYTES // 8                       # 32
        packed = torch.zeros(nbytes, dtype=torch.uint8)
        bits = mask_bits.to(torch.bool).reshape(-1)
        for i in range(min(vl, int(bits.numel()))):
            if bool(bits[i]):
                pos = i * s
                packed[pos >> 3] |= (1 << (pos & 7))
        dst_name = self._reg_name(dst)
        alias = self._lookup_alias(dst_name)
        if alias is None:
            raise KeyError("micro_mask_to_ub destination view not found: " + dst_name)
        flat = self._alias_physical_tail(alias)
        flat_u8 = flat.view(torch.uint8)             # storage-backed byte view (flat is contiguous)
        if int(flat_u8.numel()) < nbytes:
            raise IndexError("micro_mask_to_ub dst UB has fewer than 32 bytes: " + dst_name)
        esize = int(flat.element_size())
        self._vf_on_store_indices(flat, torch.arange(0, nbytes // esize, dtype=torch.long))
        flat_u8[:nbytes].copy_(packed)

    def _ub_to_mask(self, kw: Dict) -> None:
        # MicroAPI::LoadAlign(MaskReg&, __ubuf__ T*): read the FULL 32-byte (256-bit) vector mask
        # register from UB. Inverse packing of _mask_to_ub: element-lane i (mask element size S)
        # is taken from bit i*S (LSB-first); the in-between bits are ignored. Board-verified.
        ctx = self._require_ctx("micro_ub_to_mask")
        dst = kw.get("dst")           # MaskReg
        src = kw.get("src")           # UB Tensor
        self._require_args("micro_ub_to_mask", dst=dst, src=src)
        src_name = self._reg_name(src)
        alias = self._lookup_alias(src_name)
        if alias is None:
            raise KeyError("micro_ub_to_mask source view not found: " + src_name)
        flat = self._alias_physical_tail(alias)
        flat_u8 = flat.view(torch.uint8)
        nbytes = _VL_BYTES // 8                       # 32
        if int(flat_u8.numel()) < nbytes:
            raise IndexError("micro_ub_to_mask src UB has fewer than 32 bytes: " + src_name)
        esize = int(flat.element_size())
        self._vf_on_load_indices(flat, torch.arange(0, nbytes // esize, dtype=torch.long))
        packed = flat_u8[:nbytes].to(torch.int64).clone()
        s = int(self._reg_dtype(dst).itemsize)
        vl = _VL_BYTES // s
        bits = torch.zeros(vl, dtype=torch.bool)
        for i in range(vl):
            pos = i * s
            bits[i] = bool((int(packed[pos >> 3]) >> (pos & 7)) & 1)
        ctx.masks[self._reg_name(dst)] = bits

    def _move_mask(self, kw: Dict) -> None:
        # MicroAPI::MoveMask<T>(): materialize the vector-mask SPR (set by SetVectorMask / set_mask*
        # on the vec PipeS, OUTSIDE the vf) into a T-typed MaskReg the vf can use. Board-verified
        # 2026-07-21 (kernels/a5/vec_only/movemask_probe.py, codegen SetVectorMask<half> +
        # MoveMask<int>): the mapping is LANE-GRANULAR direct-index -- MaskReg lane i takes SPR
        # lane i (set_mask low/high bit i, or the first `count` lanes for set_mask_by_count), NOT
        # the byte-granular i*elem_size layout that mask_to_ub uses for its physical store.
        ctx = self._require_ctx("micro_movemaskspr")
        dst = kw.get("dst")
        self._require_args("micro_movemaskspr", dst=dst)
        spr = ctx.spr_mask
        if spr is None:
            raise RuntimeError(
                "micro_movemaskspr: no vector-mask SPR snapshot available. Call SetVectorMask / "
                "set_mask / set_mask_by_count on the vec PipeS before entering the vf, and enter "
                "the vf from the vec runtime (the SPR is not defined inside a bare MicroRuntime).")
        vl = _lanes(self._reg_dtype(dst))
        spr_bits = spr.to(torch.bool).reshape(-1)
        bits = torch.zeros(vl, dtype=torch.bool)
        n = min(vl, int(spr_bits.numel()))
        if n > 0:
            bits[:n] = spr_bits[:n]
        ctx.masks[self._reg_name(dst)] = bits

    # ------------------------------------------------------------------
    # Interleave / deinterleave
    # ------------------------------------------------------------------

    def _interleave(self, op: str, kw: Dict) -> None:
        self._require_ctx(op)
        dst0 = kw.get("dst0")
        dst1 = kw.get("dst1")
        src0 = kw.get("src0")
        src1 = kw.get("src1")
        self._require_args(op, dst0=dst0, dst1=dst1, src0=src0, src1=src1)
        s0 = self._get_reg(src0).clone()
        s1 = self._get_reg(src1).clone()
        d0 = self._get_reg(dst0)
        d1 = self._get_reg(dst1)
        lane_count = int(d0.numel())
        half = lane_count // 2
        out0 = torch.empty_like(d0)
        out1 = torch.empty_like(d1)
        if op == "micro_interleave":
            out0[0::2] = s0[:half]
            out0[1::2] = s1[:half]
            out1[0::2] = s0[half:]
            out1[1::2] = s1[half:]
        else:
            out0[:half] = s0[0::2]
            out1[:half] = s0[1::2]
            out0[half:] = s1[0::2]
            out1[half:] = s1[1::2]
        self._set_reg(dst0, out0)
        self._set_reg(dst1, out1)

    # ------------------------------------------------------------------
    # Pack: take the low (dst-width) bits of every src element -> low/high half of dst.
    # Native vpack; here modelled byte-exactly (low dst_size bytes of each src element).
    # ------------------------------------------------------------------

    def _handle_pack(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_pack")
        dst = kw.get("dst")
        src = kw.get("src")
        part = str(kw.get("part"))
        self._require_args("micro_pack", dst=dst, src=src)
        s = self._get_reg(src)
        d = self._get_reg(dst)
        dst_dt = d.dtype
        src_size = int(s.element_size())
        dst_size = int(d.element_size())
        n_elem = int(s.numel())
        src_u8 = s.contiguous().view(torch.uint8).reshape(n_elem, src_size)
        low = src_u8[:, :dst_size].reshape(-1).clone()       # low dst_size bytes of each src elem
        # vpack ZEROES the other half of dst (verified vs CANN gather_impl.h: LOWEST -> [packed, 0..],
        # HIGHEST -> [0.., packed]); two packs are combined with a vor/Select, not same-dst accumulation.
        out = torch.zeros(int(d.numel()) * dst_size, dtype=torch.uint8)
        half = n_elem * dst_size
        if part == "LOWEST":
            out[:half] = low
        elif part == "HIGHEST":
            out[half:half * 2] = low
        else:
            raise ValueError("micro_pack part must be LOWEST/HIGHEST, got: " + part)
        ctx.regs[self._reg_name(dst)] = out.view(dst_dt).reshape(int(d.numel()))

    _HIST_BIN_WIDTH = 128

    def _handle_histograms(self, kw: Dict) -> None:
        """``MicroAPI::Histograms`` -- ``dhistv2`` / ``chistv2``.

        The destination is read-modify-write: the instruction *adds* into the
        counters already in the register, which is how a tile is accumulated by
        looping it.  A ``uint16`` destination holds 128 counters and a byte has
        256 values, so ``BIN0`` covers ``[0,128)`` and ``BIN1`` ``[128,256)``.

        ``FREQUENCY`` counts the bytes equal to a bin; ``ACCUMULATE`` counts the
        bytes less than or equal to it, over the whole byte range rather than
        the window, so the two windows concatenate into one 256-entry prefix
        count.  Both conventions are board-verified -- see
        kernels/a5/vec_only/histograms_probe.py.
        """
        ctx = self._require_ctx("micro_histograms")
        dst = kw.get("dst")
        src = kw.get("src")
        self._require_args("micro_histograms", dst=dst, src=src)
        s = self._get_reg(src)
        d = self._get_reg(dst)
        if int(s.element_size()) != 1:
            raise ValueError("micro_histograms src must be an 8-bit register")
        if int(d.element_size()) != 2:
            raise ValueError("micro_histograms dst must be a 16-bit register")
        bits = self._resolve_mask(kw.get("mask"), int(s.numel()))
        bin_group = kw.get("bin_group")
        index = int(getattr(bin_group, "index", 0))
        mode = str(kw.get("mode", "FREQUENCY")).strip().upper()
        base = index * self._HIST_BIN_WIDTH
        width = int(d.numel())
        values = s.to(torch.int64)[bits.to(torch.bool)]
        counts = torch.zeros((width,), dtype=torch.int64)
        if int(values.numel()):
            if mode == "FREQUENCY":
                local = values - base
                live = local[(local >= 0) & (local < width)]
                if int(live.numel()):
                    counts += torch.bincount(live, minlength=width)[:width]
            elif mode == "ACCUMULATE":
                edges = torch.arange(base, base + width, dtype=torch.int64)
                counts += (values.view(-1, 1) <= edges.view(1, -1)).sum(dim=0)
            else:
                raise ValueError(
                    "micro_histograms mode must be FREQUENCY/ACCUMULATE, got: " + mode)
        # uint16 counters wrap; torch has no uint16 arithmetic, so add through a
        # widened view and mask back to the register's width.
        total = (d.to(torch.int64) + counts) & 0xFFFF
        ctx.regs[self._reg_name(dst)] = total.to(d.dtype)

    def _compare_tensor(self, lhs: torch.Tensor, rhs: torch.Tensor, mode: Any) -> torch.Tensor:
        mode_name = str(mode).strip().upper()
        if _is_torch_unsigned(lhs.dtype):
            # torch CPU has no ordered comparison for uint64; compare through a
            # same-width signed view with the sign bit flipped so the signed order
            # matches the unsigned order (equality is preserved by the flip too).
            signed_dtype = self._int_view_dtype(lhs, signed=True)
            sign_bit = torch.iinfo(signed_dtype).min
            lhs = lhs.view(signed_dtype) ^ sign_bit
            rhs = rhs.view(signed_dtype) ^ sign_bit
        if mode_name == "LT":
            return lhs < rhs
        if mode_name == "LE":
            return lhs <= rhs
        if mode_name == "GT":
            return lhs > rhs
        if mode_name == "GE":
            return lhs >= rhs
        if mode_name == "EQ":
            return lhs == rhs
        if mode_name == "NE":
            return lhs != rhs
        raise ValueError("unsupported micro compare mode: " + str(mode))

    def _resolve_mask_or_reg_bits(self, ref: Any, lanes: int) -> torch.Tensor:
        if ref is None:
            raise ValueError("mask/register selector is required")
        ctx = self._require_ctx("mask/register bit resolution")
        name = self._reg_name(ref) if hasattr(ref, "name") else str(ref)
        bits = ctx.masks.get(name)
        if isinstance(bits, torch.Tensor):
            if int(bits.numel()) == lanes:
                return bits
            raise ValueError("mask register lane mismatch: " + name)
        try:
            reg = self._get_reg(ref)
        except Exception:
            raise KeyError("mask/register selector not found: " + name)
        return reg[:lanes].to(torch.bool)

    def _apply_exec_mask_zero(self, dst: Any, value: torch.Tensor, mask_ref: Any) -> torch.Tensor:
        out = value.to(self._reg_dtype(dst))
        if mask_ref is None:
            return out
        lanes = int(out.numel())
        mask = self._resolve_mask_or_reg_bits(mask_ref, lanes)
        unsigned_views = {
            getattr(torch, "uint16", None): torch.int16,
            torch.uint32: torch.int32,
            torch.uint64: torch.int64,
        }
        signed_view = unsigned_views.get(out.dtype)
        if signed_view is not None:
            selected = torch.where(mask[:lanes], out.view(signed_view), torch.zeros_like(out).view(signed_view))
            return selected.view(out.dtype)
        return torch.where(mask[:lanes], out, torch.zeros_like(out))

    def _exec_mask_bits(self, kw: Dict, lanes: int):
        """Resolve a per-op execution mask to ``lanes`` bool bits, or ``None``.

        ``None`` means no mask is attached -> treat every lane as active. The
        default ``ensure_mask`` mask is ``MaskType.ALL`` (all-True), so an
        unmasked call is a no-op filter that keeps the legacy whole-register
        behavior; only an explicit non-trivial mask changes the result.
        """
        mask_ref = kw.get("mask")
        if mask_ref is None:
            return None
        return self._resolve_mask_or_reg_bits(mask_ref, lanes)[:lanes]

    def _blend_mask_exec(self, dst: Any, result: torch.Tensor, kw: Dict) -> torch.Tensor:
        """Apply preserve-semantics execution masking to a mask-register update.

        Active lanes take ``result``; inactive lanes keep the previous ``dst``
        mask bits (or ``False`` if ``dst`` had no prior value).
        """
        exec_bits = self._exec_mask_bits(kw, int(result.numel()))
        if exec_bits is None:
            return result
        prev = self._ctx.masks.get(self._reg_name(dst)) if self._ctx else None
        if isinstance(prev, torch.Tensor) and prev.numel() == result.numel():
            return torch.where(exec_bits, result, prev)
        return torch.where(exec_bits, result, torch.zeros_like(result))

    # ------------------------------------------------------------------
    # Math operations
    # ------------------------------------------------------------------

    def _math(self, op: str, kw: Dict) -> bool:
        math_ops = set(_MICRO_BINARY) | set(_MICRO_UNARY) | set(_MICRO_SCALAR) | {
            "micro_vdup",
            "micro_vaxpy",
            "micro_cast",
            "micro_compare",
            "micro_compares",
            "micro_select",
            "micro_vcmax",
            "micro_vcmin",
            "micro_vcadd",
            "micro_vcgadd",
            "micro_vcgmax",
            "micro_vcgmin",
            "micro_vcpadd",
            "micro_shiftls",
            "micro_shiftrs",
            "micro_shiftl",
            "micro_shiftr",
            "micro_vand",
            "micro_vor",
            "micro_vxor",
            "micro_vnot",
        }
        ctx = self._ctx
        if not ctx:
            if op in math_ops:
                raise RuntimeError("micro op requires active context: " + op)
            return False

        if op in _MICRO_BINARY:
            dst = kw.get("dst")
            src = kw.get("src") or kw.get("src1")
            src1 = kw.get("src1") if "src" in kw else kw.get("src2")
            self._require_args(op, dst=dst, src=src, src1=src1)
            a_raw = self._get_reg(src)
            b_raw = self._get_reg(src1)
            integer_inputs = not (
                a_raw.is_floating_point() or a_raw.is_complex() or
                b_raw.is_floating_point() or b_raw.is_complex()
            )
            if integer_inputs and a_raw.dtype != b_raw.dtype:
                raise ValueError(op + " integer source dtypes must match")
            if (
                op == "micro_vdiv"
                and not self._intrinsic_div_warned
                and not (a_raw.is_complex() or b_raw.is_complex())
                and (a_raw.is_floating_point() or b_raw.is_floating_point())
            ):
                config = kw.get("config")
                algo = getattr(getattr(config, "algo", None), "name", None)
                exact_normal_mode = (
                    algo in (
                        "PRECISION_0ULP_FTZ_TRUE",
                        "PRECISION_0ULP_FTZ_FALSE",
                    )
                )
                exact_exponent_shift = (
                    config is None
                    and _is_normal_power_of_two_division(a_raw, b_raw)
                )
                if not exact_normal_mode and not exact_exponent_shift:
                    warnings.warn(
                        "A5 default/1-ULP MicroAPI::Div may differ from "
                        "the simulator's correctly rounded CPU division; "
                        "use DivConfig with a validated 0-ULP mode when "
                        "last-bit agreement matters",
                        MicroDivPrecisionWarning,
                        stacklevel=4,
                    )
                    self._intrinsic_div_warned = True
            if a_raw.is_complex() or b_raw.is_complex():
                # Complex Add/Sub/Mul/Div: compute in complex64. ComplexHalf
                # (complex32) is experimental in torch and has no div kernel, so
                # promote both operands; _apply_exec_mask_zero demotes the result
                # to the destination register's declared complex width. max/min/
                # prelu are undefined for complex and are gated out at the DSL layer.
                result = _MICRO_BINARY[op](
                    a_raw.to(torch.complex64), b_raw.to(torch.complex64)
                )
            elif integer_inputs and op in ("micro_vadd", "micro_vsub", "micro_vmul"):
                # Keep integer RegTensor arithmetic in its native dtype. Casting
                # b64 operands to fp32 loses low bits above 2**24 and does not
                # match the generated MicroAPI integer instruction or its wrap
                # semantics.
                result = self._integer_binary(a_raw, b_raw, op)
            elif op == "micro_vmax" and integer_inputs:
                result = self._integer_maximum(a_raw, b_raw)
            elif op == "micro_vmin" and integer_inputs:
                result = self._integer_minimum(a_raw, b_raw)
            else:
                result = _MICRO_BINARY[op](a_raw.float(), b_raw.float())
            self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
            return True

        if op in _MICRO_UNARY:
            dst, src = kw.get("dst"), kw.get("src")
            self._require_args(op, dst=dst, src=src)
            a_raw = self._get_reg(src)
            if a_raw.is_complex():
                # Abs is the only documented complex unary: |z| collapses a
                # complex reg to a real modulus (half<-complex32, float<-complex64).
                # Compute in complex64 (ComplexHalf abs is experimental) and let
                # _apply_exec_mask_zero cast the real result to the dst dtype.
                result = _MICRO_UNARY[op](a_raw.to(torch.complex64))
                self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
                return True
            is_int = not (a_raw.is_floating_point() or a_raw.is_complex())
            # Integer copy always stays native; integer abs/neg/relu stay native
            # for signed dtypes (torch has no unsigned neg/abs, and those are not
            # documented as unsigned-supported anyway). fp32 would drop bits above
            # 2**24 for b32/b64 integers and diverge from hardware.
            native_int = is_int and op in _INTEGER_UNARY_OPS and not (
                _is_torch_unsigned(a_raw.dtype)
                and op in ("micro_vabs", "micro_vneg", "micro_vrelu")
            )
            operand = a_raw if native_int else a_raw.float()
            result = _MICRO_UNARY[op](operand)
            self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
            return True

        if op in _MICRO_SCALAR:
            dst, src = kw.get("dst"), kw.get("src")
            self._require_args(op, dst=dst, src=src)
            a_raw = self._get_reg(src)
            if a_raw.is_complex():
                # Complex Adds/Muls: resolve a (possibly complex) immediate and
                # compute in complex64; maxs/mins/lrelu are undefined for complex
                # and are gated out at the DSL layer.
                cscalar = self._numc(kw.get("scalar", kw.get("value", kw.get("v", 0))))
                result = _MICRO_SCALAR[op](a_raw.to(torch.complex64), cscalar)
                self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
                return True
            raw_scalar = self._numf(kw.get("scalar", kw.get("value", kw.get("v", 0))))
            is_int = not (a_raw.is_floating_point() or a_raw.is_complex())
            if is_int and op in ("micro_vadds", "micro_vmuls", "micro_vmaxs", "micro_vmins"):
                # Keep integer scalar ops in native dtype (adds/muls wrap in the
                # register width, maxs/mins compare with unsigned-aware ordering);
                # fp32 would drop bits above 2**24 for b32/b64 integers.
                result = self._integer_scalar(op, a_raw, raw_scalar)
            else:
                # Hardware applies the immediate at the operand register's precision (a half
                # muls rounds the scalar to half first); keep that to stay aligned with cannsim.
                scalar = _round_scalar_to_reg_dtype(raw_scalar, self._reg_dtype(src))
                result = _MICRO_SCALAR[op](a_raw.float(), scalar)
            self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
            return True

        if op == "micro_vdup":
            dst = kw.get("dst")
            src = kw.get("src")
            self._require_args(op, dst=dst)
            dt = self._reg_dtype(dst)
            if torch.empty((), dtype=dt).is_complex():
                # Duplicate a complex immediate (or a complex reg's lane 0) across
                # the register. Build in complex64; _apply_exec_mask_zero demotes
                # to the declared complex width (complex32/complex64).
                if src is not None:
                    try:
                        cval = complex(self._get_reg(src)[0].item())
                    except KeyError:
                        cval = self._numc(src)
                else:
                    cval = self._numc(kw.get("scalar", kw.get("value", kw.get("v", 0))))
                filled = torch.full((_lanes(dt),), cval, dtype=torch.complex64)
                self._set_reg(dst, self._apply_exec_mask_zero(dst, filled, kw.get("mask")))
                return True
            is_float_dt = torch.empty((), dtype=dt).is_floating_point()
            if src is not None:
                try:
                    s = self._get_reg(src)
                    val = s[0].item()
                except KeyError:
                    val = self._numf(src) if is_float_dt else self._num(src)
            else:
                raw = kw.get("scalar", kw.get("value", kw.get("v", 0)))
                val = self._numf(raw) if is_float_dt else self._num(raw)
            if is_float_dt:
                filled = torch.full((_lanes(dt),), val, dtype=dt)
            else:
                # Resolve the immediate as an int and fill through a signed carrier so
                # a >2**53 (float-lossy) or >2**63 (uint64) value stays bit-exact.
                filled = self._full_like_int(torch.empty(_lanes(dt), dtype=dt), val)
            self._set_reg(dst, self._apply_exec_mask_zero(dst, filled, kw.get("mask")))
            return True

        if op == "micro_vaxpy":
            src = kw.get("src", kw.get("reg"))
            dst = kw.get("dst", src)
            self._require_args(op, src=src, dst=dst)
            src_val = self._get_reg(src)
            dst_val = self._get_reg(dst)
            scalar = self._numf(kw.get("value", kw.get("v", 0)))
            is_int = not (src_val.is_floating_point() or src_val.is_complex())
            if is_int:
                # axpy = dst + src * scalar; keep it native so b32/b64 integer
                # accumulation matches hardware instead of losing bits via fp32.
                term = self._integer_scalar("micro_vmuls", src_val, scalar)
                result = self._integer_binary(dst_val, term, "micro_vadd")
            elif src_val.is_complex():
                result = dst_val + src_val * scalar
            else:
                # Board-measured on Ascend 950: MicroAPI::Axpy is a genuine fused
                # multiply-add, so the product is not rounded before the add. A
                # native `dst + src * scalar` rounds twice and disagrees with the
                # device on ~11% of fp32 lanes. Carry the product in fp64, which
                # holds an exact fp32 product, and round once on the way back.
                result = (dst_val.double() + src_val.double() * float(scalar)).to(
                    src_val.dtype
                )
            self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
            return True

        if op == "micro_cast":
            return self._handle_cast(kw)

        if op in ("micro_compare", "micro_compares"):
            ctx = self._ctx
            dst = kw.get("dst")
            self._require_args(op, dst=dst)
            if op == "micro_compares" or "src2" in kw or "value" in kw:
                lhs_ref = kw.get("src1")
                rhs_arg = kw.get("src2", kw.get("value"))
            else:
                lhs_ref = kw.get("src")
                rhs_arg = kw.get("src1")
            self._require_args(op, lhs=lhs_ref, rhs=rhs_arg)
            lhs = self._get_reg(lhs_ref)
            if op == "micro_compare":
                if self._is_scalar_operand(rhs_arg):
                    raise TypeError("micro_compare requires register rhs")
                rhs = self._get_reg(rhs_arg)
            else:
                if self._is_register_operand(rhs_arg):
                    raise TypeError("micro_compares requires scalar rhs")
                if lhs.is_floating_point():
                    rhs = torch.full_like(lhs, self._numf(rhs_arg))
                else:
                    # Resolve as int (a large/uint64 immediate is float-lossy) and
                    # build through the signed carrier _full_like_int provides.
                    rhs = self._full_like_int(lhs, self._num(rhs_arg))
            result = self._compare_tensor(lhs, rhs.to(lhs.dtype), kw.get("mode", "EQ")).to(torch.bool)
            dst_name = self._reg_name(dst)
            exec_bits = self._exec_mask_bits(kw, int(result.numel()))
            if exec_bits is not None:
                prev = ctx.masks.get(dst_name)
                if isinstance(prev, torch.Tensor) and prev.numel() == result.numel():
                    result = torch.where(exec_bits, result, prev.to(torch.bool))
                else:
                    result = torch.where(exec_bits, result, torch.zeros_like(result))
            ctx.masks[dst_name] = result.clone()
            if dst_name in ctx.regs:
                ctx.regs[dst_name] = result.to(ctx.regs[dst_name].dtype)
            return True

        if op == "micro_select":
            dst = kw.get("dst")
            self._require_args(op, dst=dst)
            if "src2" in kw or "mask" in kw or "selmask" in kw:
                src1_ref = kw.get("src1")
                src2_ref = kw.get("src2")
                mask_ref = kw.get("selmask", kw.get("mask"))
            else:
                src1_ref = kw.get("src")
                src2_ref = kw.get("src1")
                mask_ref = kw.get("sel")
            self._require_args(op, src1=src1_ref, src2=src2_ref)
            if not self._is_register_operand(dst):
                raise TypeError("micro_select requires register dst")
            if not self._is_register_operand(src1_ref):
                raise TypeError("micro_select requires register src1")
            if not self._is_register_operand(src2_ref):
                raise TypeError("micro_select requires register src2")
            src1_val = self._get_reg(src1_ref)
            src2_val = self._get_reg(src2_ref)
            mask = self._resolve_mask_or_reg_bits(mask_ref, int(src1_val.numel()))
            sel_mask = mask[:int(src1_val.numel())]
            rhs = src2_val.to(src1_val.dtype)
            if _is_torch_unsigned(src1_val.dtype):
                # torch CPU has no where() for uint64; a lane pick is bit-identical,
                # so select on the same-width signed view and view back.
                sview = self._int_view_dtype(src1_val, signed=True)
                result = torch.where(sel_mask, src1_val.view(sview), rhs.view(sview)).view(src1_val.dtype)
            else:
                result = torch.where(sel_mask, src1_val, rhs)
            self._set_reg(dst, result)
            return True

        if op in ("micro_vcmax", "micro_vcmin", "micro_vcadd"):
            dst, src = kw.get("dst"), kw.get("src")
            self._require_args(op, dst=dst, src=src)
            src_val = self._get_reg(src)
            dst_reg = self._get_reg(dst)
            dst_reg.zero_()
            red_src = src_val.to(torch.int64) if src_val.dtype is torch.uint32 else src_val
            exec_bits = self._exec_mask_bits(kw, int(red_src.numel()))
            if exec_bits is not None:
                red_src = self._masked_lanes(
                    red_src, exec_bits[:int(red_src.numel())],
                )
            if int(red_src.numel()) > 0:
                kind = {"micro_vcadd": "add", "micro_vcmax": "max", "micro_vcmin": "min"}[op]
                if red_src.is_floating_point() or red_src.is_complex():
                    reduced = {"add": red_src.sum, "max": red_src.max, "min": red_src.min}[kind]()
                    dst_reg[0] = reduced.to(dst_reg.dtype)
                else:
                    # Native integer reduce; routes uint64 through a signed view since
                    # torch CPU has no uint64 sum/max/min. Matches the board's int64/
                    # uint64 whole-register Reduce (doc 0411).
                    reduced = self._integer_reduce(kind, red_src)[0]
                    dst_reg[0] = reduced if reduced.dtype == dst_reg.dtype else reduced.to(dst_reg.dtype)
            self._set_reg(dst, dst_reg)
            return True

        if op in ("micro_vcgadd", "micro_vcgmax", "micro_vcgmin"):
            dst, src = kw.get("dst"), kw.get("src")
            self._require_args(op, dst=dst, src=src)
            src_val = self._get_reg(src)
            dst_reg = self._get_reg(dst)
            dst_reg.zero_()
            c0 = 32 // dst_reg.element_size()
            block_count = 8
            exec_bits = self._exec_mask_bits(kw, int(src_val.numel()))
            red = op.replace("micro_vcg", "")
            src_is_int = not (src_val.is_floating_point() or src_val.is_complex())
            for bi in range(block_count):
                block = src_val[bi * c0:(bi + 1) * c0]
                if exec_bits is not None:
                    block = self._masked_lanes(
                        block,
                        exec_bits[bi * c0:(bi + 1) * c0][:int(block.numel())],
                    )
                if int(block.numel()) == 0:
                    continue
                if src_is_int:
                    # Native integer group reduce; fp32 accumulation would lose
                    # bits above 2**24 and diverge from the hardware reduce.
                    dst_reg[bi] = self._integer_reduce(red, block)[0].to(dst_reg.dtype)
                else:
                    fblock = block.float()
                    if red == "add": dst_reg[bi] = fblock.sum().to(dst_reg.dtype)
                    elif red == "max": dst_reg[bi] = fblock.max().to(dst_reg.dtype)
                    elif red == "min": dst_reg[bi] = fblock.min().to(dst_reg.dtype)
            self._set_reg(dst, dst_reg)
            return True

        if op == "micro_vcpadd":
            dst, src = kw.get("dst"), kw.get("src")
            self._require_args(op, dst=dst, src=src)
            src_val = self._get_reg(src)
            dst_reg = self._get_reg(dst)
            dst_reg.zero_()
            lane_count = int(src_val.numel())
            pair_count = lane_count // 2
            exec_bits = self._exec_mask_bits(kw, lane_count)
            src_is_int = not (src_val.is_floating_point() or src_val.is_complex())
            if src_is_int:
                # Native integer pairwise add; the unsigned signed-view sum wraps
                # in the register width exactly like the hardware, and fp32 would
                # drop bits above 2**24.
                if _is_torch_unsigned(src_val.dtype):
                    work = src_val.view(self._int_view_dtype(src_val, signed=True)).clone()
                else:
                    work = src_val.clone()
                if exec_bits is not None:
                    work = torch.where(exec_bits[:lane_count], work, torch.zeros_like(work))
                pairsum = work[:pair_count * 2].view(pair_count, 2).sum(dim=1)
                if _is_torch_unsigned(src_val.dtype):
                    pairsum = pairsum.view(src_val.dtype)
                dst_reg[:pair_count] = pairsum.to(dst_reg.dtype)
            else:
                masked_src = src_val.float()
                if exec_bits is not None:
                    masked_src = torch.where(exec_bits[:lane_count], masked_src, torch.zeros_like(masked_src))
                dst_reg[:pair_count] = masked_src.view(pair_count, 2).sum(dim=1).to(dst_reg.dtype)
            self._set_reg(dst, dst_reg)
            return True

        if op in ("micro_shiftls", "micro_shiftrs"):
            src = kw.get("src", kw.get("reg"))
            dst = kw.get("dst", src)
            self._require_args(op, src=src, dst=dst)
            src_val = self._get_reg(src)
            shift = int(self._numf(kw.get("value", kw.get("v", 0))))
            result = self._shift_bits(src_val, shift, op == "micro_shiftls")
            self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
            return True

        if op in ("micro_shiftl", "micro_shiftr"):
            src1 = kw.get("src1")
            src2 = kw.get("src2")
            dst = kw.get("dst")
            self._require_args(op, dst=dst, src1=src1, src2=src2)
            data = self._get_reg(src1)
            shift = self._get_reg(src2)
            result = self._shift_bits_reg(data, shift, op == "micro_shiftl")
            self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
            return True

        if op in ("micro_vand", "micro_vor", "micro_vxor"):
            src1 = kw.get("src1")
            src2 = kw.get("src2")
            dst = kw.get("dst")
            self._require_args(op, dst=dst, src1=src1, src2=src2)
            result = self._bitwise_binary(self._get_reg(src1), self._get_reg(src2), op)
            self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
            return True

        if op == "micro_vnot":
            dst, src = kw.get("dst"), kw.get("src")
            self._require_args(op, dst=dst, src=src)
            val = self._get_reg(src)
            if val.dtype in (torch.int8, torch.int16, torch.int32, torch.int64, torch.uint8):
                result = ~val
            else:
                # torch CPU lacks bitwise_not on uint16/uint32/uint64; invert through
                # the same-width signed view (bit-identical) and view back.
                bit_dt = self._int_view_dtype(val, signed=True)
                result = (~val.view(bit_dt)).view(val.dtype)
            self._set_reg(dst, self._apply_exec_mask_zero(dst, result, kw.get("mask")))
            return True

        return False

    @staticmethod
    def _integer_binary(
        lhs: torch.Tensor, rhs: torch.Tensor, op: str,
    ) -> torch.Tensor:
        if lhs.dtype != rhs.dtype:
            raise ValueError(op + " integer source dtypes must match")
        unsigned_types = tuple(
            dtype for dtype in (
                torch.uint8,
                getattr(torch, "uint16", None),
                getattr(torch, "uint32", None),
                getattr(torch, "uint64", None),
            )
            if dtype is not None
        )
        if lhs.dtype not in unsigned_types:
            return _MICRO_BINARY[op](lhs, rhs)

        # Some torch CPU builds do not implement uint64 arithmetic. A
        # same-width signed view has the identical two's-complement bit-level
        # add/sub/mul result, including modulo-2**N wrap, and can be viewed back
        # without a value conversion.
        signed_dtype = MicroRuntime._int_view_dtype(lhs, signed=True)
        result = _MICRO_BINARY[op](
            lhs.view(signed_dtype), rhs.view(signed_dtype))
        return result.view(lhs.dtype)

    @staticmethod
    def _integer_maximum(lhs: torch.Tensor, rhs: torch.Tensor) -> torch.Tensor:
        if lhs.dtype != rhs.dtype:
            raise ValueError("micro_vmax integer source dtypes must match")
        unsigned_types = tuple(
            dtype for dtype in (
                torch.uint8,
                getattr(torch, "uint16", None),
                getattr(torch, "uint32", None),
                getattr(torch, "uint64", None),
            )
            if dtype is not None
        )
        if lhs.dtype not in unsigned_types:
            return torch.maximum(lhs, rhs)

        signed_dtype = MicroRuntime._int_view_dtype(lhs, signed=True)
        lhs_signed = lhs.view(signed_dtype)
        rhs_signed = rhs.view(signed_dtype)
        sign_bit = torch.iinfo(signed_dtype).min
        lhs_key = lhs_signed ^ sign_bit
        rhs_key = rhs_signed ^ sign_bit
        selected = torch.where(lhs_key >= rhs_key, lhs_signed, rhs_signed)
        return selected.view(lhs.dtype)

    @staticmethod
    def _integer_minimum(lhs: torch.Tensor, rhs: torch.Tensor) -> torch.Tensor:
        if lhs.dtype != rhs.dtype:
            raise ValueError("micro_vmin integer source dtypes must match")
        if not _is_torch_unsigned(lhs.dtype):
            return torch.minimum(lhs, rhs)
        # Mirror _integer_maximum for unsigned dtypes torch CPU cannot compare:
        # flipping the sign bit of a same-width signed view makes signed order
        # match the unsigned order, so pick the operand with the smaller key.
        signed_dtype = MicroRuntime._int_view_dtype(lhs, signed=True)
        lhs_signed = lhs.view(signed_dtype)
        rhs_signed = rhs.view(signed_dtype)
        sign_bit = torch.iinfo(signed_dtype).min
        lhs_key = lhs_signed ^ sign_bit
        rhs_key = rhs_signed ^ sign_bit
        selected = torch.where(lhs_key <= rhs_key, lhs_signed, rhs_signed)
        return selected.view(lhs.dtype)

    @staticmethod
    def _full_like_int(t: torch.Tensor, value: float) -> torch.Tensor:
        ivalue = int(value)
        if not _is_torch_unsigned(t.dtype):
            return torch.full_like(t, ivalue)
        # Build the immediate through a same-width signed view (two's complement)
        # because some torch CPU builds cannot fill/operate on uint64 directly.
        signed_dtype = MicroRuntime._int_view_dtype(t, signed=True)
        width = torch.iinfo(signed_dtype).bits
        wrapped = ivalue & ((1 << width) - 1)
        if wrapped >= (1 << (width - 1)):
            wrapped -= (1 << width)
        return torch.full_like(t.view(signed_dtype), wrapped).view(t.dtype)

    @staticmethod
    def _integer_scalar(op: str, tensor: torch.Tensor, scalar: float) -> torch.Tensor:
        full = MicroRuntime._full_like_int(tensor, scalar)
        if op == "micro_vadds":
            return MicroRuntime._integer_binary(tensor, full, "micro_vadd")
        if op == "micro_vmuls":
            return MicroRuntime._integer_binary(tensor, full, "micro_vmul")
        if op == "micro_vmaxs":
            return MicroRuntime._integer_maximum(tensor, full)
        if op == "micro_vmins":
            return MicroRuntime._integer_minimum(tensor, full)
        raise ValueError("unsupported integer scalar op: " + op)

    @staticmethod
    def _integer_reduce(kind: str, block: torch.Tensor) -> torch.Tensor:
        """Reduce a 1-D integer block to a 1-element tensor in ``block.dtype``.

        Unsigned dtypes reduce through a same-width signed view: add wraps in the
        register width (two's-complement identical), and max/min use the sign-bit
        flipped key so signed order matches unsigned order.
        """
        if not _is_torch_unsigned(block.dtype):
            if kind == "add":
                return block.sum().reshape(1)
            if kind == "max":
                return block.max().reshape(1)
            return block.min().reshape(1)
        signed_dtype = MicroRuntime._int_view_dtype(block, signed=True)
        sv = block.view(signed_dtype)
        if kind == "add":
            return sv.sum().reshape(1).view(block.dtype)
        sign_bit = torch.iinfo(signed_dtype).min
        key = sv ^ sign_bit
        idx = int(key.argmax() if kind == "max" else key.argmin())
        return sv[idx].reshape(1).view(block.dtype)

    @staticmethod
    def _masked_lanes(block: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """Select register lanes on torch builds without unsigned indexing.

        Some CPU torch versions reject boolean indexing for uint16/uint32/
        uint64 tensors.  Indexing their same-width signed view is bit-exact;
        viewing the compact result back preserves the hardware lane values.
        """
        if not _is_torch_unsigned(block.dtype):
            return block[mask]
        signed_dtype = MicroRuntime._int_view_dtype(block, signed=True)
        return block.view(signed_dtype)[mask].view(block.dtype)

    @staticmethod
    def _bitwise_binary(lhs: torch.Tensor, rhs: torch.Tensor, label: str) -> torch.Tensor:
        op = label.replace("micro_v", "")
        if lhs.dtype == torch.bool:
            if op == "and": return torch.logical_and(lhs, rhs)
            if op == "or": return torch.logical_or(lhs, rhs)
            return torch.logical_xor(lhs, rhs)
        bit_dtype = MicroRuntime._int_view_dtype(lhs, signed=False)
        lb = lhs.view(bit_dtype)
        rb = rhs.view(bit_dtype)
        if op == "and": out = lb & rb
        elif op == "or": out = lb | rb
        else: out = lb ^ rb
        return out.view(lhs.dtype)

    @staticmethod
    def _int_view_dtype(src: torch.Tensor, signed: bool = False) -> torch.dtype:
        elem_size = int(src.element_size())
        if signed:
            return {1: torch.int8, 2: torch.int16, 4: torch.int32, 8: torch.int64}[elem_size]
        if elem_size == 1:
            return torch.uint8
        for name, sz in (("uint16", 2), ("uint32", 4), ("uint64", 8)):
            if elem_size == sz and hasattr(torch, name):
                return getattr(torch, name)
        return {1: torch.int8, 2: torch.int16, 4: torch.int32, 8: torch.int64}[elem_size]

    @staticmethod
    def _shift_bits(src: torch.Tensor, shift: int, left: bool) -> torch.Tensor:
        if shift < 0:
            return MicroRuntime._shift_bits(src, -shift, not left)
        if src.dtype == torch.bool:
            bit_src = src.to(torch.uint8)
            out = (bit_src << shift) if left else (bit_src >> shift)
            return out.to(torch.bool)
        if src.dtype is torch.uint32:
            bit_src = src.to(torch.int64)
            out = (bit_src << shift) if left else (bit_src >> shift)
            return out.to(torch.uint32)
        # torch CPU has no shift on uint16/uint32/uint64, so operate on the
        # same-width signed view (left shift is bit-identical). A right shift is
        # arithmetic on the signed view -- correct for a signed register, but an
        # unsigned register needs a *logical* shift, so mask off the top `shift`
        # sign-extended bits afterwards.
        is_unsigned = _is_torch_unsigned(src.dtype)
        width = 8 * int(src.element_size())
        signed_dtype = MicroRuntime._int_view_dtype(src, signed=True)
        sv = src.view(signed_dtype)
        if left:
            out = sv << shift
        elif not is_unsigned:
            out = sv >> shift
        elif shift == 0:
            # Avoid materializing the full-width unsigned mask (2**64 - 1),
            # which cannot be converted to the signed int64 view used here.
            out = sv
        elif shift >= width:
            out = torch.zeros_like(sv)
        else:
            out = (sv >> shift) & ((1 << (width - shift)) - 1)
        return out.view(src.dtype)

    @staticmethod
    def _shift_bits_reg(src: torch.Tensor, shift: torch.Tensor, left: bool) -> torch.Tensor:
        # Per-lane variable shift (MicroAPI::ShiftLeft/ShiftRight): lane i shifts src[i] by
        # shift[i]. Reuse the scalar _shift_bits (correct for every width incl. 64-bit via
        # Python-int masks + the signed-view logical-shift trick) by selecting, per distinct
        # shift amount, the whole-tensor shifted result. torch.where runs on the bit-identical
        # SIGNED view so uint16/uint32/uint64 (no CPU where/shift kernel) never hit torch gaps.
        sdt = MicroRuntime._int_view_dtype(src, signed=True)
        sh = shift.reshape(-1).to(torch.int64)
        out = src.reshape(-1).view(sdt).clone()
        for s in torch.unique(sh).tolist():
            shifted = MicroRuntime._shift_bits(src.reshape(-1), int(s), left).view(sdt)
            out = torch.where(sh == s, shifted, out)
        return out.view(src.dtype).reshape(src.shape)

    # ------------------------------------------------------------------
    # Cast
    # ------------------------------------------------------------------

    @staticmethod
    def _cast_layout_slot(layout_name: str, ratio: int) -> int:
        if ratio <= 0:
            raise ValueError("micro_cast invalid layout ratio: " + str(ratio))
        mapping = {"ZERO": 0, "ONE": 1, "TWO": 2, "THREE": 3}
        normalized = layout_name.strip().upper()
        if normalized not in mapping:
            raise ValueError("micro_cast unsupported RegLayout: " + str(layout_name))
        slot = mapping[normalized]
        if slot >= ratio:
            raise ValueError(
                "micro_cast RegLayout "
                + normalized
                + " is invalid for ratio "
                + str(ratio)
            )
        return slot

    @staticmethod
    def _cast_is_float8(dtype: torch.dtype) -> bool:
        return str(dtype).startswith("torch.float8_")

    @staticmethod
    def _cast_apply_dtype(values: torch.Tensor, dst_dtype: torch.dtype, mode_name: str, saturate: bool) -> torch.Tensor:
        return apply_cast_dtype(values, dst_dtype, mode_name, "micro_cast mode", saturate=saturate)

    def _handle_cast(self, kw: Dict) -> bool:
        src_ref = kw.get("src")
        dst_ref = kw.get("dst")
        dtype_ref = kw.get("dtype", kw.get("ddst"))
        self._require_args("micro_cast", src=src_ref, dst=dst_ref)
        if dtype_ref is None:
            raise KeyError("micro_cast requires dtype or ddst")
        src_reg = self._get_reg(src_ref)
        src_snapshot = src_reg.clone()
        src_logical_dtype = _logical_dtype_name(src_ref, src_snapshot)
        dst_logical_dtype = _logical_dtype_name(dtype_ref)
        dst_dtype = _torch_dt(dtype_ref)
        dst_lanes = _lanes(dst_dtype) * int(getattr(dst_ref, "reg_num", 1))
        config = kw.get("config")

        config_mode = None
        if config is not None:
            round_mode = getattr(config, "round_mode", None)
            config_mode = getattr(round_mode, "name", round_mode)
        mode_raw = kw.get("mode", config_mode)
        mode_name = str(mode_raw).strip().upper() if mode_raw is not None else "CAST_NONE"
        saturate = bool(getattr(config, "saturate", False)) if config else False
        layout_raw = getattr(getattr(config, "reg_layout", None), "name", getattr(config, "reg_layout", "ZERO")) if config else "ZERO"
        layout_name = str(layout_raw) if layout_raw is not None else "ZERO"

        if _is_fp4_logical_dtype(dst_logical_dtype) or _is_fp4_logical_dtype(src_logical_dtype):
            merge_mode = getattr(getattr(config, "merge_mode", None), "name", "ZEROING")
            if str(merge_mode).upper() != "ZEROING":
                raise ValueError("micro_cast FP4 paths only support MaskMergeMode.ZEROING")
            layout_slots = {"ZERO": 0, "ONE": 1, "TWO": 2, "THREE": 3}
            normalized_layout = layout_name.strip().upper()
            if normalized_layout not in layout_slots:
                raise ValueError("micro_cast bfloat16<->FP4 requires RegLayout.ZERO/ONE/TWO/THREE")
            slot = layout_slots[normalized_layout]
            mask_bits = self._resolve_mask(kw.get("mask"), _lanes(torch.bfloat16))
            logical_count = int(mask_bits.numel())

            if src_logical_dtype == "bfloat16" and _is_fp4_logical_dtype(dst_logical_dtype):
                values = src_snapshot[:logical_count].to(torch.float32)
                values = torch.where(mask_bits, values, torch.zeros_like(values))
                if dst_logical_dtype == "fp4_e1m2":
                    carrier = fp32_to_fp4_e1m2(
                        values, pack_axis=-1, nan_to_zero=True, round_mode=mode_name
                    )
                else:
                    carrier = fp32_to_fp4_e2m1(
                        values, pack_axis=-1, nan_to_zero=True, round_mode=mode_name
                    )
                dst_work = torch.zeros(_lanes(torch.uint8), dtype=torch.uint8)
                carrier_flat = carrier.reshape(-1)
                dst_work[slot:slot + int(carrier_flat.numel()) * 4:4] = carrier_flat
                self._set_reg(dst_ref, dst_work)
                return True

            if _is_fp4_logical_dtype(src_logical_dtype) and dst_logical_dtype == "bfloat16":
                carrier_count = (logical_count + 1) // 2
                carrier = src_snapshot[slot:slot + carrier_count * 4:4].to(torch.uint8)
                if src_logical_dtype == "fp4_e1m2":
                    values = fp4_e1m2_to_fp32(carrier, logical_shape=(logical_count,))
                else:
                    values = fp4_e2m1_to_fp32(carrier, logical_shape=(logical_count,))
                dst_work = torch.zeros(_lanes(torch.bfloat16), dtype=torch.bfloat16)
                dst_work[:logical_count] = torch.where(
                    mask_bits, values, torch.zeros_like(values)
                ).to(torch.bfloat16)
                self._set_reg(dst_ref, dst_work)
                return True

            raise ValueError(
                "micro_cast FP4 simulator only supports bfloat16<->FP4, got "
                + src_logical_dtype + " -> " + dst_logical_dtype
            )

        mask_bits = self._resolve_mask(kw.get("mask"), dst_lanes)

        src_is_f8 = self._cast_is_float8(src_snapshot.dtype)
        src_indexable = src_snapshot
        if src_is_f8:
            src_indexable = src_snapshot.to(torch.float32)

        merge_mode = getattr(getattr(config, "merge_mode", None), "name", "ZEROING") if config else "ZEROING"
        dst_is_f8 = self._cast_is_float8(dst_dtype)
        if str(merge_mode).upper() == "MERGING":
            # MERGING: keep dst's prior value in inactive lanes (lets two complementary-slot
            # casts accumulate into one reg without a vor). Requires dst to hold a prior value.
            cur = self._get_reg(dst_ref)
            dst_work = (cur.to(torch.float32) if dst_is_f8 else cur.to(dst_dtype)).clone()
        elif dst_is_f8:
            dst_work = torch.zeros(dst_lanes, dtype=torch.float32)
        else:
            dst_work = torch.zeros(dst_lanes, dtype=dst_dtype)

        active_idx = torch.nonzero(mask_bits[:dst_lanes], as_tuple=False).view(-1)
        if int(active_idx.numel()) == 0:
            # An all-false mask is a well-defined predicated Cast on device:
            # ZEROING clears every destination lane, MERGING leaves the prior
            # value. Both already sit in ``dst_work``. A tail group whose
            # ``UpdateMask`` counter is exhausted hits this every time, so it
            # must not be an error. Mirrors ``_handle_expsub``.
            self._set_reg(dst_ref, dst_work.to(dst_dtype) if dst_is_f8 else dst_work)
            return True

        src_size = int(src_snapshot.element_size())
        dst_size = int(torch.empty((), dtype=dst_dtype).element_size())

        def _convert(values: torch.Tensor) -> torch.Tensor:
            if src_logical_dtype == "hif8" and dst_logical_dtype == "float32":
                return hif8_to_fp32(values.to(torch.uint8))
            if src_logical_dtype == "hif8" and dst_logical_dtype == "float16":
                return hif8_to_fp32(values.to(torch.uint8)).to(torch.float16)
            if src_logical_dtype == "float32" and dst_logical_dtype == "hif8":
                return fp32_to_hif8(values.to(torch.float32), saturate=saturate, round_mode=mode_name)
            if src_logical_dtype == "float16" and dst_logical_dtype == "hif8":
                return fp16_to_hif8(values.to(torch.float16), saturate=saturate, round_mode=mode_name)
            if src_is_f8 and dst_dtype == torch.float32:
                return values.to(torch.float32)
            return self._cast_apply_dtype(values, dst_dtype, mode_name, saturate)

        if int(src_indexable.numel()) == dst_lanes:
            src_idx = active_idx
            valid = src_idx < int(src_indexable.numel())
            values = src_indexable[src_idx[valid]]
            values = _convert(values)
            dst_work[active_idx[valid]] = values.to(dst_work.dtype)
        elif src_size < dst_size:
            ratio = dst_size // src_size
            slot = self._cast_layout_slot(layout_name, ratio)
            src_idx = active_idx * ratio + slot
            valid = src_idx < int(src_indexable.numel())
            values = src_indexable[src_idx[valid]]
            values = _convert(values)
            dst_work[active_idx[valid]] = values.to(dst_work.dtype)
        else:
            ratio = src_size // dst_size
            slot = self._cast_layout_slot(layout_name, ratio)
            selected = (active_idx % ratio) == slot
            if bool(selected.any().item()):
                dst_idx = active_idx[selected]
                src_idx = dst_idx // ratio
                valid = src_idx < int(src_indexable.numel())
                values = src_indexable[src_idx[valid]]
                values = _convert(values)
                dst_work[dst_idx[valid]] = values.to(dst_work.dtype)

        self._set_reg(dst_ref, dst_work.to(dst_dtype) if dst_is_f8 else dst_work)
        return True

    def _handle_expsub(self, kw: Dict) -> bool:
        """Fused exp(src0 - src1) -> float dst, ZEROING inactive lanes.

        Mirrors the cast half->float slot read: dst lane ``k`` reads src element
        ``k*ratio + slot`` (ratio = dst_size/src_size; slot from RegLayout, ZERO=0
        even / ONE=1 odd). The mask follows ``U`` (UpdateMask<U>), so a half source
        gives ``2*dst_lanes`` bits and only the even ones (``[0::ratio]``) gate dst.
        """
        dst_ref = kw.get("dst")
        src0_ref = kw.get("src0")
        src1_ref = kw.get("src1")
        self._require_args("micro_expsub", dst=dst_ref, src0=src0_ref, src1=src1_ref)
        dst_dtype = self._reg_dtype(dst_ref)
        dst_lanes = _lanes(dst_dtype)
        src0 = self._get_reg(src0_ref)
        src1 = self._get_reg(src1_ref)
        src_size = int(src0.element_size())
        dst_size = int(torch.empty((), dtype=dst_dtype).element_size())
        if src_size == dst_size:
            ratio, slot = 1, 0
        else:
            ratio = dst_size // src_size
            slot = self._cast_layout_slot(str(kw.get("layout", "ZERO")), ratio)
        src_lanes = int(src0.numel())
        mask_bits = self._resolve_mask(kw.get("mask"), src_lanes)
        dst_mask = mask_bits[0::ratio][:dst_lanes]
        active_idx = torch.nonzero(dst_mask, as_tuple=False).view(-1)
        out = torch.zeros(dst_lanes, dtype=dst_dtype)
        if int(active_idx.numel()) > 0:
            src_idx = active_idx * ratio + slot
            valid = src_idx < int(src0.numel())
            idx = src_idx[valid]
            result = torch.exp(src0.float()[idx] - src1.float()[idx])
            out[active_idx[valid]] = result.to(dst_dtype)
        self._set_reg(dst_ref, out)
        return True

    def _handle_abssub(self, kw: Dict) -> bool:
        """Fused absolute difference dst = abs(src0 - src1), ZEROING inactive lanes."""
        dst_ref = kw.get("dst")
        src0_ref = kw.get("src1")
        src1_ref = kw.get("src2")
        self._require_args("micro_abssub", dst=dst_ref, src0=src0_ref, src1=src1_ref)
        a = self._get_reg(src0_ref)
        b = self._get_reg(src1_ref)
        if self._reg_dtype(dst_ref) == torch.int64:
            result = torch.abs(a - b)
        else:
            result = torch.abs(a.float() - b.float())
        self._set_reg(dst_ref, self._apply_exec_mask_zero(dst_ref, result, kw.get("mask")))
        return True

    def _handle_muldstadd(self, kw: Dict) -> bool:
        """Fused in-place FMA dst = dst * src0 + src1, ZEROING inactive lanes.

        dst is read AND written; the stub stores src0/src1 as the src1/src2 kwargs.
        All three operands share one dtype, so there is no layout/slot read.
        """
        dst_ref = kw.get("dst")
        src0_ref = kw.get("src1")
        src1_ref = kw.get("src2")
        self._require_args("micro_muldstadd", dst=dst_ref, src0=src0_ref, src1=src1_ref)
        dst_val = self._get_reg(dst_ref).float()
        a = self._get_reg(src0_ref).float()
        b = self._get_reg(src1_ref).float()
        result = dst_val * a + b
        self._set_reg(dst_ref, self._apply_exec_mask_zero(dst_ref, result, kw.get("mask")))
        return True

    def _handle_muladddst(self, kw: Dict) -> bool:
        """Fused in-place multiply-add dst = src0 * src1 + dst, ZEROING inactive lanes."""
        dst_ref = kw.get("dst")
        src0_ref = kw.get("src1")
        src1_ref = kw.get("src2")
        self._require_args("micro_muladddst", dst=dst_ref, src0=src0_ref, src1=src1_ref)
        dst_val = self._get_reg(dst_ref)
        a = self._get_reg(src0_ref)
        b = self._get_reg(src1_ref)
        unsigned_views = {
            getattr(torch, "uint16", None): torch.int16,
            torch.uint32: torch.int32,
            torch.uint64: torch.int64,
        }
        signed_view = unsigned_views.get(dst_val.dtype)
        if signed_view is not None:
            result = (
                a.view(signed_view) * b.view(signed_view) + dst_val.view(signed_view)
            ).view(dst_val.dtype)
        elif dst_val.dtype in (torch.int16, torch.int32, torch.int64):
            result = a * b + dst_val
        elif dst_val.dtype == torch.float32:
            # MicroAPI::MulAddDst<float> is one fused operation on A5.  The
            # fp32 operands are exact in fp64, so this avoids the simulator's
            # former product-rounding step before the final fp32 rounding.
            result = (
                a.to(torch.float64) * b.to(torch.float64)
                + dst_val.to(torch.float64)
            ).to(torch.float32)
        else:
            result = a.float() * b.float() + dst_val.float()
        self._set_reg(dst_ref, self._apply_exec_mask_zero(dst_ref, result, kw.get("mask")))
        return True

    def _handle_mulscast(self, kw: Dict) -> bool:
        """Fused MulsCast: CAST_ROUND(src(float) * scalar(float)) -> half dst.

        The API uses a float execution mask (``UpdateMask<float>``). One float
        source lane produces one half value in a b16 slot: ``RegLayout.ZERO``
        writes even half lanes, and ``RegLayout.ONE`` writes odd half lanes.
        The remaining half lanes stay zero under ZEROING semantics.
        """
        dst_ref = kw.get("dst")
        src_ref = kw.get("src")
        self._require_args("micro_mulscast", dst=dst_ref, src=src_ref)
        src = self._get_reg(src_ref)
        dst_dtype = self._reg_dtype(dst_ref)
        src_dtype = self._reg_dtype(src_ref)
        if dst_dtype != torch.float16:
            raise ValueError("micro_mulscast dst dtype must be half")
        if src_dtype != torch.float32:
            raise ValueError("micro_mulscast src dtype must be float")
        src_lanes = _lanes(src_dtype)
        dst_lanes = _lanes(dst_dtype)
        slot = self._cast_layout_slot(str(kw.get("layout", "ZERO")), 2)
        mask_bits = self._resolve_mask(kw.get("mask"), src_lanes)
        active_idx = torch.nonzero(mask_bits[:src_lanes], as_tuple=False).view(-1)
        out = torch.zeros(dst_lanes, dtype=dst_dtype)
        if int(active_idx.numel()) > 0:
            scalar = self._numf(kw.get("v", kw.get("value", kw.get("scalar", 0.0))))
            values = src.float()[active_idx] * float(scalar)
            result = apply_cast_dtype(values, dst_dtype, "CAST_ROUND", "micro_mulscast mode")
            out[active_idx * 2 + slot] = result.to(dst_dtype)
        self._set_reg(dst_ref, out)
        return True

    # ------------------------------------------------------------------
    # Mask ops
    # ------------------------------------------------------------------

    def _get_mask(self, ref: Any) -> torch.Tensor:
        ctx = self._ctx
        name = self._reg_name(ref)
        if ctx and name in ctx.masks:
            return ctx.masks[name]
        raise KeyError("mask register not found: " + name)

    def _set_mask(self, ref: Any, value: torch.Tensor) -> None:
        ctx = self._ctx
        if ctx:
            ctx.masks[self._reg_name(ref)] = value

    def _mask_unary(self, op: str, kw: Dict) -> None:
        dst, src = kw.get("dst"), kw.get("src")
        bits = self._get_mask(src)
        if op == "micro_masknot":
            result = ~bits
        else:
            result = bits.clone()
        self._set_mask(dst, self._blend_mask_exec(dst, result, kw))

    def _mask_binary(self, op: str, kw: Dict) -> None:
        dst = kw.get("dst")
        src1 = kw.get("src1", kw.get("src"))
        src2 = kw.get("src2", kw.get("src1"))
        a, b = self._get_mask(src1), self._get_mask(src2)
        if op == "micro_maskand":
            result = a & b
        elif op == "micro_maskor":
            result = a | b
        elif op == "micro_maskxor":
            result = a ^ b
        elif op == "micro_masksel":
            # mask_sel's `mask`/`sel` arg is the SELECTOR, not an execution mask.
            sel_ref = kw.get("mask", kw.get("sel"))
            self._require_args(op, mask=sel_ref)
            sel = self._get_mask(sel_ref)
            self._set_mask(dst, torch.where(sel, a, b))
            return
        else:
            return
        self._set_mask(dst, self._blend_mask_exec(dst, result, kw))

    def _get_mask_or_init(self, ref: Any) -> torch.Tensor:
        ctx = self._require_ctx("mask lookup")
        name = self._reg_name(ref) if hasattr(ref, "name") else str(ref)
        if name in ctx.masks:
            return ctx.masks[name]
        raise KeyError("mask register not found: " + name)

    def _mask_interleave(self, op: str, kw: Dict) -> None:
        ctx = self._require_ctx(op)
        dst0, dst1 = kw.get("dst0"), kw.get("dst1")
        src0, src1 = kw.get("src0"), kw.get("src1")
        self._require_args(op, dst0=dst0, dst1=dst1, src0=src0, src1=src1)
        s0 = self._get_mask_or_init(src0).clone()
        s1 = self._get_mask_or_init(src1).clone()
        lanes = int(s0.numel())
        half = lanes // 2
        out0 = torch.empty_like(s0)
        out1 = torch.empty_like(s0)
        if op == "micro_maskinterl":
            out0[0::2] = s0[:half]
            out0[1::2] = s1[:half]
            out1[0::2] = s0[half:]
            out1[1::2] = s1[half:]
        else:
            out0[:half] = s0[0::2]
            out1[:half] = s0[1::2]
            out0[half:] = s1[0::2]
            out1[half:] = s1[1::2]
        ctx.masks[self._reg_name(dst0)] = out0
        ctx.masks[self._reg_name(dst1)] = out1

    def _mask_pack(self, op: str, kw: Dict) -> None:
        ctx = self._require_ctx(op)
        dst, src = kw.get("dst"), kw.get("src")
        self._require_args(op, dst=dst, src=src)
        src_val = self._get_mask_or_init(src).clone()
        lanes = int(src_val.numel())
        half = lanes // 2
        is_low = str(kw.get("mode", "")).endswith("LOWEST")
        out = torch.zeros_like(src_val)
        if op == "micro_maskpack":
            even = src_val[0::2]
            if is_low:
                out[:half] = even
            else:
                out[half:] = even
        else:
            packed = src_val[:half] if is_low else src_val[half:]
            out[0::2] = packed
        ctx.masks[self._reg_name(dst)] = out

    def _updatemask(self, kw: Dict) -> None:
        ctx = self._require_ctx("micro_updatemask")
        dst = kw.get("dst")
        self._require_args("micro_updatemask", dst=dst)
        name = self._reg_name(dst)
        cnt = kw.get("cnt")
        if cnt is not None:
            existing = ctx.masks.get(name)
            if existing is not None:
                lane_count = int(existing.numel())
            else:
                dtype_ref = getattr(dst, "dtype", torch.float16)
                lane_count = _lanes(_torch_dt(dtype_ref))
            cnt_value = self._num(cnt)
            active_count = min(max(cnt_value, 0), lane_count)
            bits = torch.zeros((lane_count,), dtype=torch.bool)
            if active_count > 0:
                bits[:active_count] = True
            ctx.masks[name] = bits
            cnt_name = str(getattr(cnt, "name", ""))
            # Codegen passes named counters to UpdateMask by reference, while
            # folded temporary Vars use a block-local copy because their inline
            # expression cannot bind to uint32_t&. Mirror that distinction.
            if cnt_name and not cnt_name.startswith("_tmp_var_"):
                ctx.var_values[cnt_name] = max(cnt_value - lane_count, 0)
            return

        src = kw.get("src")
        reg = self._get_reg(src)
        ctx.masks[name] = (reg != 0).to(torch.bool)


# ------------------------------------------------------------------
# Math dispatch tables
# ------------------------------------------------------------------

_MICRO_BINARY: Dict[str, Callable] = {
    "micro_vadd": lambda a, b: a + b,
    "micro_vsub": lambda a, b: a - b,
    "micro_vmul": lambda a, b: a * b,
    "micro_vdiv": lambda a, b: a / b,
    "micro_vmax": lambda a, b: torch.maximum(a, b),
    "micro_vmin": lambda a, b: torch.minimum(a, b),
    "micro_vprelu": lambda a, b: torch.where(a > 0, a, a * b),
}

_MICRO_UNARY: Dict[str, Callable] = {
    "micro_vabs": lambda x: torch.abs(x),
    "micro_vexp": lambda x: torch.exp(x),
    "micro_vln": lambda x: torch.log(x),
    "micro_vlog": lambda x: torch.log(x),
    "micro_vlog2": lambda x: torch.log2(x),
    "micro_vlog10": lambda x: torch.log10(x),
    "micro_vrelu": lambda x: torch.clamp(x, min=0),
    "micro_vsqrt": lambda x: torch.sqrt(x),
    "micro_vneg": lambda x: -x,
    "micro_vcopy": lambda x: x.clone(),
}

_MICRO_SCALAR: Dict[str, Callable] = {
    "micro_vadds": lambda x, s: x + s,
    "micro_vmuls": lambda x, s: x * s,
    "micro_vmaxs": lambda x, s: torch.clamp(x, min=s),
    "micro_vmins": lambda x, s: torch.clamp(x, max=s),
    "micro_vlrelu": lambda x, s: torch.where(x > 0, x, x * s),
}
