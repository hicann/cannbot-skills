from __future__ import annotations

from fractions import Fraction
from typing import Any

import torch


def cast_round_mode_name(mode: Any) -> str:
    raw = getattr(mode, "name", mode)
    if raw is None:
        return "CAST_NONE"
    return str(raw).strip().upper()


def apply_cast_round(values: torch.Tensor, mode: Any, error_label: str) -> torch.Tensor:
    mode_name = cast_round_mode_name(mode)
    if mode_name in ("CAST_NONE", "CAST_RINT"):
        return torch.round(values)
    if mode_name == "CAST_FLOOR":
        return torch.floor(values)
    if mode_name == "CAST_CEIL":
        return torch.ceil(values)
    if mode_name == "CAST_ROUND":
        return torch.sign(values) * torch.floor(torch.abs(values) + 0.5)
    if mode_name == "CAST_TRUNC":
        return torch.trunc(values)
    raise ValueError("unsupported " + error_label + ": " + str(mode_name))


def _nextafter(values: torch.Tensor, direction: float) -> torch.Tensor:
    return torch.nextafter(values, torch.full_like(values, direction))


def _float_work(values: torch.Tensor) -> torch.Tensor:
    if values.dtype == torch.float64:
        return values
    return values.to(torch.float64)


def _cast_float_round_floor(values: torch.Tensor, dst_dtype: torch.dtype) -> torch.Tensor:
    rounded = values.to(dst_dtype)
    rounded_work = rounded.to(torch.float64)
    prev_values = _nextafter(rounded, float("-inf"))
    return torch.where(rounded_work > _float_work(values), prev_values, rounded)


def _cast_float_round_ceil(values: torch.Tensor, dst_dtype: torch.dtype) -> torch.Tensor:
    rounded = values.to(dst_dtype)
    rounded_work = rounded.to(torch.float64)
    next_values = _nextafter(rounded, float("inf"))
    return torch.where(rounded_work < _float_work(values), next_values, rounded)


def _cast_float_round_trunc(values: torch.Tensor, dst_dtype: torch.dtype) -> torch.Tensor:
    rounded = values.to(dst_dtype)
    rounded_work = rounded.to(torch.float64)
    work = _float_work(values)
    prev_values = _nextafter(rounded, float("-inf"))
    next_values = _nextafter(rounded, float("inf"))
    result = torch.where((work > 0) & (rounded_work > work), prev_values, rounded)
    return torch.where((work < 0) & (rounded_work < work), next_values, result)


def _cast_float_round_nearest_away(values: torch.Tensor, dst_dtype: torch.dtype) -> torch.Tensor:
    rounded = values.to(dst_dtype)
    floor_values = _cast_float_round_floor(values, dst_dtype)
    ceil_values = _cast_float_round_ceil(values, dst_dtype)
    work = _float_work(values)
    floor_work = floor_values.to(torch.float64)
    ceil_work = ceil_values.to(torch.float64)
    tie = (
        torch.isfinite(work)
        & torch.isfinite(floor_work)
        & torch.isfinite(ceil_work)
        & (floor_values != ceil_values)
        & ((work - floor_work) == (ceil_work - work))
    )
    away = torch.where(values.to(torch.float32) >= 0, ceil_values, floor_values)
    return torch.where(tie, away, rounded)


def _cast_float_round_odd(values: torch.Tensor, dst_dtype: torch.dtype) -> torch.Tensor:
    if dst_dtype != torch.float16:
        raise ValueError("CAST_ODD is only supported for float -> half in the simulator")
    truncated = _cast_float_round_trunc(values, dst_dtype)
    work = values.to(torch.float32)
    inexact = torch.isfinite(work) & (truncated.to(torch.float32) != work)
    bits = truncated.view(torch.int16).to(torch.int32) & 0xFFFF
    odd_bits = torch.where(inexact, bits | 1, bits)
    signed = torch.where(odd_bits >= 0x8000, odd_bits - 0x10000, odd_bits).to(torch.int16)
    return signed.view(torch.float16)


def apply_cast_float_round(values: torch.Tensor, dst_dtype: torch.dtype, mode: Any, error_label: str) -> torch.Tensor:
    mode_name = cast_round_mode_name(mode)
    if mode_name in ("CAST_NONE", "CAST_RINT"):
        return values.to(dst_dtype)
    if mode_name == "CAST_FLOOR":
        return _cast_float_round_floor(values, dst_dtype)
    if mode_name == "CAST_CEIL":
        return _cast_float_round_ceil(values, dst_dtype)
    if mode_name == "CAST_ROUND":
        return _cast_float_round_nearest_away(values, dst_dtype)
    if mode_name == "CAST_TRUNC":
        return _cast_float_round_trunc(values, dst_dtype)
    if mode_name == "CAST_ODD":
        return _cast_float_round_odd(values, dst_dtype)
    raise ValueError("unsupported " + error_label + ": " + str(mode_name))


def _scalar_float_fraction(value: torch.Tensor) -> Fraction:
    numerator, denominator = float(value.item()).as_integer_ratio()
    return Fraction(numerator, denominator)


def _next_scalar_float(value: torch.Tensor, direction: float) -> torch.Tensor:
    return torch.nextafter(value, torch.tensor(direction, dtype=value.dtype))


def _int_scalar_float_bounds(value: int, dst_dtype: torch.dtype):
    target = Fraction(value, 1)
    nearest = torch.tensor(value, dtype=dst_dtype)
    nearest_frac = _scalar_float_fraction(nearest)
    if nearest_frac == target:
        return nearest, nearest
    if nearest_frac < target:
        return nearest, _next_scalar_float(nearest, float("inf"))
    return _next_scalar_float(nearest, float("-inf")), nearest


def _cast_int64_scalar_to_float(value: int, dst_dtype: torch.dtype, mode_name: str, error_label: str) -> torch.Tensor:
    if mode_name in ("CAST_NONE", "CAST_RINT"):
        return torch.tensor(value, dtype=dst_dtype)
    if mode_name == "CAST_FLOOR":
        floor_value, _ = _int_scalar_float_bounds(value, dst_dtype)
        return floor_value
    if mode_name == "CAST_CEIL":
        _, ceil_value = _int_scalar_float_bounds(value, dst_dtype)
        return ceil_value
    if mode_name == "CAST_TRUNC":
        floor_value, ceil_value = _int_scalar_float_bounds(value, dst_dtype)
        return floor_value if value >= 0 else ceil_value
    if mode_name == "CAST_ROUND":
        floor_value, ceil_value = _int_scalar_float_bounds(value, dst_dtype)
        if bool((floor_value == ceil_value).item()):
            return floor_value
        target = Fraction(value, 1)
        floor_dist = target - _scalar_float_fraction(floor_value)
        ceil_dist = _scalar_float_fraction(ceil_value) - target
        if floor_dist < ceil_dist:
            return floor_value
        if ceil_dist < floor_dist:
            return ceil_value
        return ceil_value if value >= 0 else floor_value
    raise ValueError("unsupported " + error_label + ": " + str(mode_name))


def _cast_int64_to_float_round(values: torch.Tensor, dst_dtype: torch.dtype, mode: Any, error_label: str) -> torch.Tensor:
    mode_name = cast_round_mode_name(mode)
    flat = values.reshape(-1)
    out = torch.empty(flat.shape, dtype=dst_dtype, device=values.device)
    out_flat = out.reshape(-1)
    for i in range(int(flat.numel())):
        out_flat[i] = _cast_int64_scalar_to_float(int(flat[i].item()), dst_dtype, mode_name, error_label)
    return out.reshape(values.shape)


def apply_cast_int_to_float_round(values: torch.Tensor, dst_dtype: torch.dtype, mode: Any, error_label: str) -> torch.Tensor:
    if values.dtype == torch.int64:
        return _cast_int64_to_float_round(values, dst_dtype, mode, error_label)
    return apply_cast_float_round(values.to(torch.float64), dst_dtype, mode, error_label)


def _is_narrowing_int_cast(src_dtype: torch.dtype, dst_dtype: torch.dtype) -> bool:
    """True for an integer -> narrower-integer Cast, which saturates on A5."""
    if src_dtype.is_floating_point or dst_dtype.is_floating_point:
        return False
    if src_dtype == torch.bool or dst_dtype == torch.bool:
        return False
    try:
        return torch.iinfo(dst_dtype).bits < torch.iinfo(src_dtype).bits
    except TypeError:
        return False


def apply_cast_dtype(
    values: torch.Tensor,
    dst_dtype: torch.dtype,
    mode: Any,
    error_label: str,
    saturate: bool = False,
) -> torch.Tensor:
    work = values
    dst_is_float = bool(torch.empty((), dtype=dst_dtype).is_floating_point())
    if work.dtype == torch.float32 and dst_dtype == torch.float32:
        return apply_cast_round(work, mode, error_label).to(dst_dtype)
    if work.dtype.is_floating_point and dst_is_float and work.dtype != dst_dtype:
        if saturate:
            info = torch.finfo(dst_dtype)
            work = work.to(torch.float64)
            finite = torch.isfinite(work)
            if bool(finite.any().item()):
                work[finite] = torch.clamp(work[finite], min=float(info.min), max=float(info.max))
        return apply_cast_float_round(work, dst_dtype, mode, error_label)
    if not work.dtype.is_floating_point and dst_is_float:
        return apply_cast_int_to_float_round(work, dst_dtype, mode, error_label)
    if work.dtype.is_floating_point and not dst_is_float:
        work = apply_cast_round(work.to(torch.float32), mode, error_label)
    if not saturate and _is_narrowing_int_cast(values.dtype, dst_dtype):
        # A narrowing integer Cast saturates on hardware whether or not the
        # CastConfig asks for it -- board-verified on ascend950 2026-07-30: an
        # int32 -> int16 cast of values up to 60000 clamped every one of them to
        # 32767, while this simulator was truncating to the low 16 bits. Cast
        # cannot be used to extract low bits; Reg.reinterpret is the truncating
        # operation. Clamp here so the simulator stops accepting kernels the
        # hardware silently computes differently.
        info = torch.iinfo(dst_dtype)
        work = torch.clamp(work.to(torch.int64), min=int(info.min), max=int(info.max))
        return work.to(dst_dtype)
    if not saturate:
        return work.to(dst_dtype)
    if torch.empty((), dtype=dst_dtype).is_floating_point():
        info = torch.finfo(dst_dtype)
        work = work.to(torch.float64)
        finite = torch.isfinite(work)
        if bool(finite.any().item()):
            work[finite] = torch.clamp(work[finite], min=float(info.min), max=float(info.max))
        return work.to(dst_dtype)
    info = torch.iinfo(dst_dtype)
    work = work.to(torch.float64)
    finite = torch.isfinite(work)
    if bool(finite.any().item()):
        work[finite] = torch.clamp(work[finite], min=float(info.min), max=float(info.max))
    pos_inf = work == float("inf")
    if bool(pos_inf.any().item()):
        work[pos_inf] = float(info.max)
    neg_inf = work == float("-inf")
    if bool(neg_inf.any().item()):
        work[neg_inf] = float(info.min)
    nan_mask = torch.isnan(work)
    if bool(nan_mask.any().item()):
        work[nan_mask] = 0.0
    return work.to(dst_dtype)
