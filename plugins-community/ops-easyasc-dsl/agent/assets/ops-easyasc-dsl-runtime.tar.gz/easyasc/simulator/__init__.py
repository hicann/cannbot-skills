from .config import SimulatorConfig
from .simulator import Simulator
from .program import KernelProgram, LaneProgram, ControlInstruction, PipeTask
from .bridge import build_kernel_program
from .memory import SharedTensorSpec


def build_simulator(config: SimulatorConfig = None) -> Simulator:
    if config is None:
        config = SimulatorConfig()
    return Simulator(config=config)
