from __future__ import annotations

import multiprocessing
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from .config import SimulatorConfig
from .memory import L0AMX_BUFFER_NAME, L0BMX_BUFFER_NAME, L0MX_CAPACITY_BYTES, SharedMemoryStore
from .pipe import CUBE_PIPES, VEC_PIPES, PipeBase, PipeFactory, PipeS
from .program import KernelProgram, LaneProgram, PipeTask
from .sync import CrossCoreSync, IntraCoreSync, LocalEventBank, LocalSync, Mailbox


# ---------------------------------------------------------------------------
# Pipe factory — creates correct pipe implementation per (lane, pipe_name)
# ---------------------------------------------------------------------------

from .pipe_cube import CubeMTE2Pipe, CubeMTE1Pipe, MPipe, FixPipe
from .pipe_vec import VecMTE2Pipe, VPipe, MTE3Pipe

_PIPE_CLASSES = {
    ("cube", "MTE2"): CubeMTE2Pipe,
    ("cube", "MTE1"): CubeMTE1Pipe,
    ("cube", "M"): MPipe,
    ("cube", "FIX"): FixPipe,
    ("vec", "MTE2"): VecMTE2Pipe,
    ("vec", "V"): VPipe,
    ("vec", "MTE3"): MTE3Pipe,
}


def _default_pipe_factory(
    core_idx: int, lane_name: str, pipe_name: str,
    mailbox: Mailbox, barrier: threading.Barrier, memory_store: SharedMemoryStore,
    event_bank=None, intra_sync=None, trace_recorder=None, cycle_model=None, hazard_tracker=None,
) -> PipeBase:
    prefix = "cube" if lane_name == "cube" else "vec"
    cls = _PIPE_CLASSES.get((prefix, pipe_name), PipeBase)
    return cls(
        core_idx=core_idx, lane_name=lane_name, pipe_name=pipe_name,
        mailbox=mailbox, bar_all_barrier=barrier, memory_store=memory_store,
        event_bank=event_bank, intra_sync=intra_sync,
        trace_recorder=trace_recorder, cycle_model=cycle_model,
        hazard_tracker=hazard_tracker,
    )


def _disable_child_shared_memory_tracking() -> None:
    """Core workers attach parent-owned SharedMemory; only the parent unlinks it."""
    from multiprocessing import resource_tracker as _rt

    original_register = _rt.register
    original_unregister = _rt.unregister

    def register(name: str, rtype: str) -> None:
        if rtype == "shared_memory":
            return
        original_register(name, rtype)

    def unregister(name: str, rtype: str) -> None:
        if rtype == "shared_memory":
            return
        original_unregister(name, rtype)

    _rt.register = register
    _rt.unregister = unregister


# ---------------------------------------------------------------------------
# Core — one simulated core = one OS process
# ---------------------------------------------------------------------------

class CoreState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"


def _plan_local_tensor_specs(
    program: KernelProgram,
) -> Tuple[List["SharedTensorSpec"], Dict[str, Dict[str, str]]]:
    """Expand local tensor specs into per-lane allocations plus name maps."""
    from .memory import SharedTensorSpec

    _LOCAL_ROLES = {"l1", "l0a", "l0b", "l0amx", "l0bmx", "l0c", "ub", "bt"}
    _PER_LANE_ROLES = {"ub"}

    local_specs: List[SharedTensorSpec] = []
    for spec_dict in program.metadata.get("tensor_specs", []):
        if isinstance(spec_dict, dict):
            spec = SharedTensorSpec.from_dict(spec_dict)
        else:
            continue
        if spec.role in _LOCAL_ROLES:
            local_specs.append(spec)

    vec_lane_names = [
        lp.lane_name
        for lp in program.lane_programs
        if lp.lane_name.startswith("vec") and lp.instructions
    ]
    lane_name_maps: Dict[str, Dict[str, str]] = {}
    expanded_specs: List[SharedTensorSpec] = []

    for spec in local_specs:
        if spec.role in _PER_LANE_ROLES:
            for lane_name in vec_lane_names:
                if lane_name == "vec0":
                    real_name = spec.name
                    source_name = spec.source_name
                else:
                    real_name = "_" + lane_name + "_" + spec.name
                    source_name = spec.source_name
                    if isinstance(source_name, str) and source_name:
                        source_name = "_" + lane_name + "_" + source_name
                    lane_name_maps.setdefault(lane_name, {})[spec.name] = real_name

                expanded_specs.append(
                    SharedTensorSpec(
                        name=real_name,
                        shape=spec.shape,
                        dtype=spec.dtype,
                        role=spec.role,
                        storage_offset=spec.storage_offset,
                        storage_offset_bytes=spec.storage_offset_bytes,
                        storage_size_bytes=spec.storage_size_bytes,
                        storage_bank=spec.storage_bank,
                        source_name=source_name,
                        view_shape=spec.view_shape,
                        view_strides=spec.view_strides,
                    )
                )
        else:
            expanded_specs.append(spec)

    return expanded_specs, lane_name_maps


def _core_entry(
    core_idx: int,
    config: SimulatorConfig,
    program: KernelProgram,
    memory_snapshot: Dict[str, Any],
    cross_sync_snapshot: Dict[str, Any],
    status_conn: Any,
    pipe_factory: PipeFactory,
) -> None:
    """Entry point for a Core child process."""
    def _describe_running_lanes(pipe_s_list: List[PipeS], threads: List[threading.Thread]) -> str:
        lane_status = []
        for ps, thread in zip(pipe_s_list, threads):
            inflight = []
            for pipe in ps.pipes.values():
                desc = pipe.describe_inflight_task()
                if desc:
                    inflight.append(desc)
                else:
                    inflight.extend(pipe.describe_pending_tasks())
            if inflight:
                lane_status.extend(inflight)
            else:
                inst_desc = ps.describe_inflight_inst()
                if inst_desc:
                    lane_status.append(inst_desc)
                elif thread.is_alive():
                    lane_status.append("lane thread still alive: " + thread.name)
        return "\n".join(lane_status)

    memory = None
    try:
        try:
            from multiprocessing import resource_tracker as _rt
            _rt._resource_tracker._fd = None
            _rt._resource_tracker._pid = None
            _disable_child_shared_memory_tracking()
        except Exception:
            print(
                "[simulator] resource_tracker init suppressed: core=%d\n%s"
                % (core_idx, traceback.format_exc()),
                file=sys.stderr, flush=True,
            )

        import torch
        try:
            torch.set_num_threads(config.torch_num_threads)
        except Exception:
            print(
                "[simulator] torch.set_num_threads suppressed: core=%d threads=%r\n%s"
                % (core_idx, config.torch_num_threads, traceback.format_exc()),
                file=sys.stderr, flush=True,
            )

        from easyasc import globvars
        meta = program.metadata
        for key in ("device_type", "core_num", "ub_cap", "l0c_cap", "l1_cap", "l0a_cap", "l0b_cap",
                    "l0amx_cap", "l0bmx_cap", "bt_cap",
                    "trace_event", "trace_pipe_s"):
            val = meta.get(key)
            if val is not None:
                setattr(globvars, key, val)

        memory = SharedMemoryStore()
        memory.load_snapshot(memory_snapshot)

        cross_sync = CrossCoreSync(core_count=config.core_count)
        cross_sync.load_snapshot(cross_sync_snapshot)

        # Allocate local tensors (L1, L0A, L0B, L0C, UB) per core.
        # UB tensors are per-vec-lane: vec0 uses original names, vec1 uses
        # prefixed copies. Cube and shared tensors (L1, L0) are allocated once.
        local_specs, lane_name_maps = _plan_local_tensor_specs(program)
        from .memory import SharedTensorSpec
        for name, role, cap_key in (
            (L0AMX_BUFFER_NAME, "l0amx", "l0amx_cap"),
            (L0BMX_BUFFER_NAME, "l0bmx", "l0bmx_cap"),
        ):
            cap_kb = int(program.metadata.get(cap_key, L0MX_CAPACITY_BYTES // 1024) or 0)
            if cap_kb > 0:
                local_specs.append(SharedTensorSpec(name=name, shape=(cap_kb * 1024,), dtype="uint8", role=role))
        for spec in local_specs:
            if not memory.contains(spec.name):
                memory.register(spec)
        for spec in local_specs:
            memory.allocate(spec.name)

        from .config import startup_timeout_s
        startup_budget = startup_timeout_s(
            config.execution_timeout_s, config.core_count)
        if not cross_sync.startup_wait(core_idx, timeout=startup_budget):
            raise RuntimeError(
                "startup barrier timeout after local memory initialization "
                "(%.0fs for %d cores) - if the host has fewer physical cores "
                "than the simulated grid this is contention, not a kernel "
                "hang; raise EASYASC_SIM_TIMEOUT_S"
                % (startup_budget, config.core_count))

        intra_sync = IntraCoreSync()
        hazard_tracker = None
        if str(getattr(config, "local_memory_hazard_check", "off")) != "off":
            from .hazard import LocalMemoryHazardTracker
            hazard_tracker = LocalMemoryHazardTracker(
                config.local_memory_hazard_check,
                memory_cycle_scale=config.local_memory_hazard_memory_cycle_scale,
            )

        micro_defs = program.metadata.get("micro_defs", {})
        simt_defs = program.metadata.get("simt_defs", {})

        trace_recorder = None
        if config.trace_enabled:
            from .trace import TraceRecorder
            trace_recorder = TraceRecorder(
                core_idx=core_idx,
                record_event=bool(globvars.trace_event),
                record_pipe_s=bool(globvars.trace_pipe_s),
            )

        cycle_model = None
        if config.cycle_model_enabled:
            try:
                from .timing import load_cycle_model_for_device
                cycle_model = load_cycle_model_for_device(
                    str(globvars.device_type), config.cycle_profile_path
                )
                if cycle_model is not None:
                    cycle_model = replace(
                        cycle_model,
                        instruction_head_overhead_cycles=config.instruction_head_overhead_cycles,
                    )
            except Exception:
                print(
                    "[simulator] cycle model load failed: core=%d\n%s"
                    % (core_idx, traceback.format_exc()),
                    file=sys.stderr, flush=True,
                )
                cycle_model = None

        active_lanes = [lp for lp in program.lane_programs if lp.instructions]
        pipe_s_list: List[PipeS] = []
        for lp in active_lanes:
            local_sync = LocalSync()
            pipe_s = PipeS(
                core_idx=core_idx,
                lane_name=lp.lane_name,
                lane_program=lp,
                config=config,
                memory_store=memory,
                intra_sync=intra_sync,
                cross_sync=cross_sync,
                local_sync=local_sync,
                event_bank=LocalEventBank(sync=local_sync),
                pipe_factory=pipe_factory,
                kernel_mode=str(program.metadata.get("kernel_mode", "mix")),
                micro_defs=micro_defs,
                simt_defs=simt_defs,
                tensor_name_map=lane_name_maps.get(lp.lane_name, {}),
                trace_recorder=trace_recorder,
                cycle_model=cycle_model,
                hazard_tracker=hazard_tracker,
            )
            pipe_s_list.append(pipe_s)

        threads: List[threading.Thread] = []
        errors: List[Optional[str]] = [None] * len(pipe_s_list)
        lane_wakeup = threading.Event()

        for idx, ps in enumerate(pipe_s_list):
            def _run(pipe_s=ps, ei=idx):
                try:
                    pipe_s.run()
                except BaseException:
                    errors[ei] = traceback.format_exc()
                    print(
                        "[simulator] lane wrapper failed: core=%d lane=%s\n%s"
                        % (pipe_s.core_idx, pipe_s.lane_name, errors[ei]),
                        file=sys.stderr, flush=True,
                    )
                finally:
                    if pipe_s._failure and not errors[ei]:
                        errors[ei] = pipe_s._failure
                    lane_wakeup.set()

            t = threading.Thread(
                target=_run,
                name="sim-c%d-%s-pipeS" % (core_idx, ps.lane_name),
                daemon=False,
            )
            threads.append(t)
            t.start()

        timeout_margin = min(0.5, max(config.execution_timeout_s * 0.05, 0.2))
        deadline = time.monotonic() + max(config.execution_timeout_s - timeout_margin, 0.05)
        while time.monotonic() < deadline:
            if all(not t.is_alive() for t in threads):
                break
            if any(e is not None for e in errors):
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            # Cap the wait: a lane calling set() in the window between our
            # clear() and re-entering wait() — while its thread has not yet
            # flipped is_alive() to False — would otherwise be a lost wakeup
            # that stalls this core until the deadline. The Event still
            # delivers the common-case wakeup immediately; the cap is only a
            # bounded fallback poll for that race.
            lane_wakeup.wait(timeout=min(remaining, 0.5))
            lane_wakeup.clear()
        for t in threads:
            t.join(timeout=0.1)

        real_errors = [e for e in errors if e is not None]
        still_alive = [t.name for t in threads if t.is_alive()]
        if still_alive and not real_errors:
            detail = _describe_running_lanes(pipe_s_list, threads)
            msg = "lanes still running after timeout: " + ", ".join(still_alive)
            if detail:
                msg += "\nactive pipe tasks:\n" + detail
            real_errors.append(msg)

        trace_events_payload: List[Dict[str, Any]] = []
        if trace_recorder is not None:
            trace_events_payload = [e.to_dict() for e in trace_recorder.snapshot()]

        if real_errors:
            status_conn.send({
                "core_idx": core_idx,
                "state": CoreState.FAILED.value,
                "failure": "\n\n".join(real_errors),
                "trace_events": trace_events_payload,
            })
        else:
            status_conn.send({
                "core_idx": core_idx,
                "state": CoreState.STOPPED.value,
                "failure": "",
                "trace_events": trace_events_payload,
            })

    except BaseException:
        failure = traceback.format_exc()
        print(
            "[simulator] core entry failed: core=%d\n%s" % (core_idx, failure),
            file=sys.stderr, flush=True,
        )
        status_conn.send({
            "core_idx": core_idx,
            "state": CoreState.FAILED.value,
            "failure": failure,
        })
    finally:
        if memory is not None:
            memory.clear()
        try:
            status_conn.close()
        except Exception:
            print(
                "[simulator] _core_entry status_conn.close suppressed: core=%d\n%s"
                % (core_idx, traceback.format_exc()),
                file=sys.stderr, flush=True,
            )


@dataclass
class Core:
    """One simulated core = one OS process.

    Core creates 3 PipeS threads internally:
      cube PipeS  → MTE2, MTE1, M, FIX
      vec0 PipeS  → MTE2, V, MTE3
      vec1 PipeS  → MTE2, V, MTE3
    """

    core_idx: int
    config: SimulatorConfig
    program: KernelProgram
    memory_snapshot: Dict[str, Any] = field(default_factory=dict)
    cross_sync_snapshot: Dict[str, Any] = field(default_factory=dict)
    pipe_factory: PipeFactory = _default_pipe_factory
    state: CoreState = CoreState.IDLE
    failure: Optional[str] = None
    trace_events: List[Dict[str, Any]] = field(default_factory=list)
    _process: Optional[Any] = field(default=None, init=False, repr=False)
    _status_conn: Optional[Any] = field(default=None, init=False, repr=False)

    def _resolve_context(self) -> Any:
        method = self.config.process_start_method
        if method == "auto":
            available = multiprocessing.get_all_start_methods()
            if sys.platform == "darwin":
                preferred = ["spawn", "forkserver", "fork"]
            else:
                preferred = ["fork", "spawn"]
            for c in preferred:
                if c in available:
                    method = c
                    break
            else:
                method = multiprocessing.get_start_method()
        return multiprocessing.get_context(method)

    def start(self) -> None:
        self.failure = None
        self.trace_events = []
        if self._status_conn is not None:
            try:
                self._status_conn.close()
            except Exception:
                print(
                    "[simulator] Core.start stale status_conn.close suppressed: core=%d\n%s"
                    % (self.core_idx, traceback.format_exc()),
                    file=sys.stderr, flush=True,
                )
        ctx = self._resolve_context()
        parent_conn, child_conn = ctx.Pipe(duplex=False)
        self._status_conn = parent_conn
        self._process = ctx.Process(
            target=_core_entry,
            args=(
                self.core_idx,
                self.config,
                self.program,
                self.memory_snapshot,
                self.cross_sync_snapshot,
                child_conn,
                self.pipe_factory,
            ),
            daemon=False,
        )
        self._process.start()
        child_conn.close()
        self.state = CoreState.RUNNING

    def join(self, timeout: Optional[float] = None) -> None:
        if self._process is None:
            return
        self._process.join(timeout=timeout)
        self._consume_status()
        if self._process.is_alive():
            return
        if self.state == CoreState.RUNNING:
            exitcode = self._process.exitcode
            if exitcode not in (0, None):
                self.state = CoreState.FAILED
                if not self.failure:
                    self.failure = "process exited with code " + str(exitcode)
            else:
                self.state = CoreState.STOPPED
        self._close_conn()

    def wait_handles(self) -> List[Any]:
        if self._process is None:
            return []
        handles = []
        if self._status_conn is not None:
            handles.append(self._status_conn)
        handles.append(self._process.sentinel)
        return handles

    def terminate(self) -> None:
        if self._process is None:
            return
        if self._process.is_alive():
            self._process.terminate()
            self._process.join(timeout=5.0)
        self._consume_status()
        self._close_conn()
        if self.state != CoreState.FAILED:
            self.state = CoreState.STOPPED

    def _consume_status(self) -> None:
        if self._status_conn is None:
            return
        try:
            while self._status_conn.poll():
                msg = self._status_conn.recv()
                if isinstance(msg, dict):
                    state_val = msg.get("state", "")
                    if state_val == CoreState.FAILED.value:
                        self.state = CoreState.FAILED
                        self.failure = msg.get("failure", "")
                    elif state_val == CoreState.STOPPED.value and self.state != CoreState.FAILED:
                        self.state = CoreState.STOPPED
                    events = msg.get("trace_events")
                    if isinstance(events, list) and events:
                        self.trace_events.extend(events)
        except (EOFError, OSError):
            return

    def _close_conn(self) -> None:
        if self._status_conn is not None:
            try:
                self._status_conn.close()
            except Exception:
                print(
                    "[simulator] Core._close_conn status_conn.close suppressed: core=%d\n%s"
                    % (self.core_idx, traceback.format_exc()),
                    file=sys.stderr, flush=True,
                )
            self._status_conn = None
