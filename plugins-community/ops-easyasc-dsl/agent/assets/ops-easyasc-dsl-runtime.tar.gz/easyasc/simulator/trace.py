from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Iterable, List, Optional, Tuple


# ---------------------------------------------------------------------------
# TraceEvent
# ---------------------------------------------------------------------------

class TraceEventKind(Enum):
    CONTROL = "control"
    PIPE = "pipe"
    SYNC = "sync"
    STALL = "stall"


@dataclass(frozen=True)
class TraceEvent:
    kind: TraceEventKind
    name: str
    ts: float = 0.0
    dur: float = 0.0
    args: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"kind": self.kind.value, "name": self.name, "ts": self.ts, "dur": self.dur, "args": dict(self.args)}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> TraceEvent:
        return cls(kind=TraceEventKind(d["kind"]), name=str(d["name"]),
                   ts=float(d.get("ts", 0)), dur=float(d.get("dur", 0)), args=dict(d.get("args", {})))


# ---------------------------------------------------------------------------
# TraceRecorder — thread-safe in-memory collector
# ---------------------------------------------------------------------------

@dataclass
class TraceRecorder:
    core_idx: int = -1
    record_event: bool = True
    record_pipe_s: bool = True
    events: List[TraceEvent] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def record(self, kind: TraceEventKind, name: str, dur: float = 0.0,
               args: Optional[Dict] = None, ts: Optional[float] = None) -> None:
        payload = dict(args or {})
        if self.core_idx >= 0:
            payload.setdefault("core_idx", self.core_idx)
        event = TraceEvent(kind=kind, name=name,
                           ts=time.monotonic() if ts is None else ts, dur=dur, args=payload)
        with self._lock:
            self.events.append(event)

    def snapshot(self) -> List[TraceEvent]:
        with self._lock:
            return list(self.events)


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------

def merge_traces(buffers: Iterable[List[TraceEvent]]) -> List[TraceEvent]:
    merged: List[TraceEvent] = []
    for buf in buffers:
        merged.extend(buf)
    merged.sort(key=lambda e: (e.ts, e.name))
    return merged


# ---------------------------------------------------------------------------
# Chrome trace export (chrome://tracing format)
# ---------------------------------------------------------------------------

_NS = 1_000_000_000.0
_DEFAULT_DUR = 1_000.0


def _track_label(core: int, lane: str, pipe: str) -> str:
    return "core" + str(core) + "." + lane + "." + pipe


def _track_order(core: int, lane: str, pipe: str) -> int:
    base = core * 100
    order = {
        ("cube", "S"): 0, ("cube", "MTE2"): 1, ("cube", "MTE1"): 2, ("cube", "M"): 3, ("cube", "FIX"): 4,
        ("vec0", "S"): 5, ("vec0", "MTE2"): 6, ("vec0", "V"): 7, ("vec0", "MTE3"): 8,
        ("vec1", "S"): 9, ("vec1", "MTE2"): 10, ("vec1", "V"): 11, ("vec1", "MTE3"): 12,
    }
    return base + order.get((lane, pipe), 99)


def export_chrome_trace(kernel_name: str, events: Iterable[TraceEvent]) -> Dict[str, Any]:
    trace_events: List[Dict[str, Any]] = [{
        "name": "process_name", "ph": "M", "pid": 1, "tid": 0,
        "args": {"name": "easyasc:" + kernel_name},
    }]
    ordered = sorted(events, key=lambda e: (e.ts, e.name, e.kind.value))
    if not ordered:
        return {"traceEvents": trace_events, "displayTimeUnit": "ns"}
    base_ts = min(e.ts for e in ordered)
    tid_map: Dict[Tuple[int, str, str], int] = {}
    next_tid = 1

    for event in ordered:
        args = event.args
        core = int(args.get("core_idx", -1))
        if core < 0:
            continue
        lane = str(args.get("lane_name", "runtime"))
        pipe = str(args.get("pipe_name", "S"))
        track = (core, lane, pipe)
        tid = tid_map.get(track)
        if tid is None:
            tid = next_tid
            next_tid += 1
            tid_map[track] = tid
            trace_events.append({"name": "thread_name", "ph": "M", "pid": 1, "tid": tid,
                                 "args": {"name": _track_label(core, lane, pipe)}})
            trace_events.append({"name": "thread_sort_index", "ph": "M", "pid": 1, "tid": tid,
                                 "args": {"sort_index": _track_order(core, lane, pipe)}})

        is_cycle = str(args.get("time_domain", "")) == "cycle"
        start = round(event.ts - base_ts, 3) if is_cycle else round((event.ts - base_ts) * _NS, 3)
        dur = round(event.dur if event.dur > 0 else _DEFAULT_DUR, 3)
        if not is_cycle and event.dur > 0:
            dur = round(event.dur * _NS, 3)

        name = str(args.get("opname", event.name))
        cat = str(args.get("cat", pipe))
        trace_events.append({
            "name": name, "cat": cat, "ph": "X", "pid": 1, "tid": tid,
            "ts": start, "dur": dur, "args": dict(args),
        })

    return {"traceEvents": trace_events, "displayTimeUnit": "ns"}


def dump_chrome_trace(path: str, kernel_name: str, events: Iterable[TraceEvent]) -> None:
    out_dir = os.path.dirname(os.path.abspath(path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(export_chrome_trace(kernel_name, events), f, indent=2)
        f.write("\n")
