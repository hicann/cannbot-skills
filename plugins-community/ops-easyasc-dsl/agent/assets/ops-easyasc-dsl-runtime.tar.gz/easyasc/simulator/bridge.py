"""Bridge: converts DSL Instruction list → KernelProgram.

Tensor declarations (create_gm_tensor, create_tensor) are processed at build time
to generate SharedTensorSpecs. Pipe operations become ControlInstructions with
pipe_name set. Variable ops, control flow, and sync markers pass through as
ControlInstructions for PipeS to interpret at runtime.
"""
from __future__ import annotations

import sys
import traceback
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from .memory import SharedTensorSpec, dtype_size, normalize_dtype
from .program import ControlInstruction, KernelProgram, LaneProgram
from easyasc.utils.capacity import effective_ub_cap_kb, kernel_uses_simt


# Pipe name mappings
_CUBE_PIPES = ["MTE2", "MTE1", "M", "FIX"]
_VEC_PIPES = ["MTE2", "V", "MTE3"]

_CUBE_PIPE_BY_OP = {
    "gm_to_l1_nd2nz": "MTE2", "gm_to_l1_dn2nz": "MTE2", "gm_to_l1_mx_scale_nd2nz": "MTE2", "gm_to_l1_pad": "MTE2", "gm_to_l1": "MTE2", "set_constant_to_l1": "MTE2",
    "l1_to_l0": "MTE1", "l1_to_l0_mx": "MTE1", "l1_to_l0_img2col": "MTE1", "l1_to_bt": "MTE1",
    "mmad": "M", "mmad_mx": "M",
    "l0c_to_gm_nz2nd": "FIX", "l0c_to_gm_nz2nz": "FIX", "l0c_to_gm_nz2dn": "FIX", "l0c_to_l1": "FIX", "l0c_to_ub": "FIX",
}
_VEC_PIPE_BY_OP = {
    "gm_to_ub_pad": "MTE2",
    "gm_to_ub_nd_dma": "MTE2",
    "ub_to_gm_pad": "MTE3", "ub_to_l1": "MTE3", "ub_to_l1_nd2nz": "MTE3", "ub_to_l1_nz": "MTE3",
    "ub_to_ub": "V",
    "add": "V", "sub": "V", "mul": "V", "div": "V",
    "max": "V", "min": "V", "abs": "V", "relu": "V",
    "vmax": "V", "vmin": "V", "vabs": "V", "vec_v_relu": "V",
    "dup": "V", "adds": "V", "muls": "V",
    "vmaxs": "V", "vmins": "V", "lrelu": "V", "axpy": "V",
    "shiftls": "V", "shiftrs": "V",
    "compare": "V", "compare_scalar": "V", "select": "V", "cast": "V",
    "exp": "V", "ln": "V", "rec": "V", "sqrt": "V", "rsqrt": "V",
    "vnot": "V", "vand": "V", "vor": "V",
    "cmax": "V", "cmin": "V", "cadd": "V", "brcb": "V", "transdata5hd": "V",
    "cgmax": "V", "cgmin": "V", "cgadd": "V", "cpadd": "V",
    "set_mask": "V", "reset_mask": "V", "set_mask_count": "V",
    "set_mask_normal": "V", "set_mask_counter": "V", "set_mask_by_count": "V",
    "muladddst": "V",
    "sort32": "V", "mergesort4": "V", "mergesort_2seq": "V", "topk_radix": "V",
    "gather": "V", "gather_block": "V", "scatter": "V",
    "call_micro": "V",
}
_VEC_RENAME = {"max": "vmax", "min": "vmin", "abs": "vabs", "relu": "vec_v_relu"}
_SIM_DEBUG_CUBE_ONLY_PIPES = frozenset(["MTE1", "M", "FIX"])
_SIM_DEBUG_VEC_ONLY_PIPES = frozenset(["V", "MTE3"])
_DTYPE_NAMES = {
    "half": "float16", "float": "float32", "int": "int32",
    "int8_t": "int8", "uint8_t": "uint8", "int16_t": "int16", "uint16_t": "uint16",
    "float8_e4m3_t": "float8_e4m3fn", "float8_e5m2_t": "float8_e5m2",
    "mx_fp8_e4m3_t": "float8_e4m3fn", "mx_fp8_e5m2_t": "float8_e5m2",
    "hifloat8_t": "hif8",
    "fp4x2_e2m1_t": "fp4_e2m1", "fp4x2_e1m2_t": "fp4_e1m2",
    "bfloat16_t": "bfloat16", "uint32_t": "uint32", "uint64_t": "uint64", "int64_t": "int64",
    "complex32": "complex32", "complex64": "complex64",
}

_VAR_OPS = frozenset([
    "create_var", "create_varlist", "var_add", "var_sub", "var_mul", "var_div", "var_mod",
    "var_assign", "tensorlist_size", "tensorlist_item_numel", "scalar_sqrt", "scalar_abs",
    "CeilDiv", "Min", "Max",
    "Align8", "Align16", "Align32", "Align64", "Align128", "Align256",
    "GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx", "GetSubBlockNum",
])
_VEC_LANE_SCALAR_OPS = frozenset(["GetVecNum", "GetVecIdx", "GetSubBlockIdx", "GetSubBlockNum"])

_CONTROL_FLOW_OPS = frozenset([
    "start_loop", "start_micro_loop", "end_loop", "break_loop", "continue_loop",
    "start_if", "start_elif", "start_else", "end_if",
])

_EVENT_OPS = frozenset([
    "create_sevent", "create_devent", "create_tevent", "create_qevent",
    "event_wait", "event_set", "event_setall", "event_release",
])

_SYNC_OPS = frozenset([
    "setflag", "waitflag",
    "cube_ready", "wait_vec", "vec_ready", "wait_cube",
    "intracore_allvec_ready", "intracore_allvec_wait",
    "allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait",
    "barrier", "bar_all",
])

_ALLVEC_COLLECTIVE_OPS = frozenset(["allvec_ready", "allvec_wait"])

_NOOP_OPS = frozenset([
    "reset_cache", "inline", "start_auto_sync", "end_auto_sync",
    "clean_dcache", "set_hf32",
])

_LOCAL_ROLES = frozenset(["l1", "l0a", "l0b", "l0amx", "l0bmx", "l0c", "ub", "bt"])
_LOCAL_ROLE_TO_BANK = {
    "l1": "L1",
    "l0a": "L0A",
    "l0b": "L0B",
    "l0amx": "L0AMX",
    "l0bmx": "L0BMX",
    "l0c": "L0C",
    "ub": "UB",
    "bt": "BT",
}


def _product(values: Sequence) -> int:
    n = 1
    for v in values:
        n *= int(v)
    return n


def _position_role(pos: Any) -> str:
    name = str(getattr(pos, "name", pos)).upper()
    return {"L1": "l1", "L0A": "l0a", "L0B": "l0b", "L0C": "l0c", "UB": "ub", "BT": "bt"}.get(name, "shared")


def _literal_var_value(value: Any) -> Any:
    """Return the scalar value for synthetic literal Vars, otherwise None.

    SimtModule wraps Python int/float actuals as Var-like objects with
    idx == -1 so the normal dtype/signature path can treat them as Var formals.
    They are not runtime variables and therefore must not be deferred by name.
    """
    if getattr(value, "idx", None) != -1:
        return None
    if not hasattr(value, "value"):
        return None
    literal = getattr(value, "value")
    if isinstance(literal, (int, float, bool)):
        return literal
    return None


def _deferred(value: Any) -> Any:
    """Convert DSL Var/Expr to a deferred name string for runtime resolution."""
    if value is None:
        return None
    if isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, tuple):
        return tuple(_deferred(v) for v in value)
    if isinstance(value, list):
        return [_deferred(v) for v in value]
    literal = _literal_var_value(value)
    if literal is not None:
        return literal
    if hasattr(value, "name"):
        return str(value.name)
    if hasattr(value, "value"):
        v = getattr(value, "value")
        if isinstance(v, (int, float, bool)):
            return v
    return str(value)


def _var_operand(value: Any) -> Any:
    """Like _deferred, but preserves VarList subscript structure for varref values.

    A VarRef carries a (parent, index) pair. The runtime needs both pieces to
    address the underlying varlist slot — collapsing it to its textual name
    would lose the index identity for patterns like literal/Var alias or
    `vals[i+1]`.
    """
    from easyasc.utils.var import VarRef

    literal = _literal_var_value(value)
    if literal is not None:
        return literal

    if isinstance(value, VarRef):
        parent_name = ""
        if getattr(value, "parent", None) is not None:
            parent_name = str(value.parent.name)
        index = getattr(value, "index", None)
        if isinstance(index, int):
            index_payload: Any = int(index)
        elif index is None:
            index_payload = 0
        else:
            index_payload = _deferred(index)
        return {
            "__varref__": True,
            "parent": parent_name,
            "index": index_payload,
            "name": str(value.name),
        }
    return _deferred(value)


def _resolve_dim(d: Any) -> int:
    """Resolve a shape dimension that may be a Var with a concrete value."""
    if isinstance(d, (int, float)):
        return int(d)
    if hasattr(d, "value"):
        v = getattr(d, "value")
        if isinstance(v, (int, float)):
            return int(v)
    if isinstance(d, str):
        try:
            return int(d)
        except ValueError:
            print(
                "[simulator] bridge._shape_dim int parse fallback: d=%r\n%s"
                % (d, traceback.format_exc()),
                file=sys.stderr, flush=True,
            )
    raise TypeError("cannot resolve shape dim: " + repr(d))


def _shared_dtype(dtype_val: Any) -> str:
    name = str(getattr(dtype_val, "value", dtype_val))
    return _DTYPE_NAMES.get(name, normalize_dtype(name))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_kernel_program(kernel: Any) -> KernelProgram:
    bridge = KernelBridge(kernel=kernel)
    return bridge.build()


# ---------------------------------------------------------------------------
# KernelBridge
# ---------------------------------------------------------------------------

@dataclass
class KernelBridge:
    kernel: Any
    tensor_specs: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    cube_insts: List[ControlInstruction] = field(default_factory=list)
    vec_insts: List[ControlInstruction] = field(default_factory=list)
    _scope: str = field(default="cube", init=False)
    _buffer_slot_names: Dict[str, List[str]] = field(default_factory=dict, init=False)
    _resolved_vars: Dict[str, Union[int, float]] = field(default_factory=dict, init=False)
    _local_offsets_bytes: Dict[str, int] = field(default_factory=dict, init=False)
    _workspace_offset_bytes: int = field(default=0, init=False)
    _tensor_list_items: Dict[str, List[str]] = field(default_factory=dict, init=False)
    _uses_simt: bool = field(default=False, init=False)

    def build(self) -> KernelProgram:
        instructions = list(getattr(self.kernel, "instructions", []) or [])
        kernel_mode = str(getattr(self.kernel, "kernel_mode", "mix"))
        self._validate_kernel_mode_collectives(instructions)
        self._uses_simt = kernel_uses_simt(self.kernel, instructions)
        self._emit_kernel_vars()
        self._pre_register_metadata(instructions)

        if self._has_auto_sync(instructions):
            self._build_with_autosync(instructions)
        else:
            self._build_without_autosync(instructions)

        from easyasc import globvars as _gv
        micro_defs = self._collect_micro_defs()
        simt_defs = self._collect_simt_defs()
        ub_cap = effective_ub_cap_kb(int(getattr(_gv, "ub_cap", 192)), self._uses_simt)
        metadata = {
            "kernel_mode": kernel_mode,
            "tensor_specs": list(self.tensor_specs.values()),
            "micro_defs": micro_defs,
            "simt_defs": simt_defs,
            "device_type": str(getattr(_gv, "device_type", "")),
            "core_num": int(getattr(_gv, "core_num", 20)),
            "ub_cap": ub_cap,
            "l0c_cap": int(getattr(_gv, "l0c_cap", 128)),
            "l1_cap": int(getattr(_gv, "l1_cap", 512)),
            "l0a_cap": int(getattr(_gv, "l0a_cap", 64)),
            "l0b_cap": int(getattr(_gv, "l0b_cap", 64)),
            "l0amx_cap": int(getattr(_gv, "l0amx_cap", 4)),
            "l0bmx_cap": int(getattr(_gv, "l0bmx_cap", 4)),
            "bt_cap": float(getattr(_gv, "bt_cap", 0.5)),
            "trace_event": bool(getattr(_gv, "trace_event", False)),
            "trace_pipe_s": bool(getattr(_gv, "trace_pipe_s", False)),
        }
        lane_programs = []
        if kernel_mode in ("mix", "cube"):
            lane_programs.append(
                LaneProgram(
                    lane_name="cube", pipe_names=list(_CUBE_PIPES),
                    instructions=list(self.cube_insts),
                )
            )
        if kernel_mode in ("mix", "vec"):
            lane_programs.append(
                LaneProgram(
                    lane_name="vec0", pipe_names=list(_VEC_PIPES),
                    instructions=list(self.vec_insts),
                )
            )
        if kernel_mode == "mix":
            lane_programs.append(
                LaneProgram(
                    lane_name="vec1", pipe_names=list(_VEC_PIPES),
                    instructions=self._clone(self.vec_insts),
                )
            )
        return KernelProgram(
            name=str(getattr(self.kernel, "name", "kernel")),
            core_count=0,
            lane_programs=lane_programs,
            metadata=metadata,
        )

    def _validate_kernel_mode_collectives(self, instructions: Sequence[Any]) -> None:
        if getattr(self.kernel, "kernel_mode", "mix") != "vec":
            return
        used = sorted({
            str(getattr(inst, "opname", ""))
            for inst in instructions
            if str(getattr(inst, "opname", "")) in _ALLVEC_COLLECTIVE_OPS
        })
        if used:
            raise ValueError(
                "kernel(mode='vec') cannot use {}: vec mode generates "
                "KERNEL_TYPE_AIV_ONLY, which is not a valid task type for "
                "cross-core all-vector synchronization; use kernel(mode='mix')"
                .format("/".join(used))
            )

    # ------------------------------------------------------------------
    # Kernel-level var emission
    # ------------------------------------------------------------------

    def _emit_kernel_vars(self) -> None:
        bound = getattr(self.kernel, "_last_bound_args", {})
        from easyasc.utils.var import Var
        for name, val in bound.items():
            if isinstance(val, Var):
                if isinstance(val.value, (int, float)):
                    # Keep the exact bound value (int OR float). Dim/numel readers
                    # (_resolve_int_best_effort/_resolve_numel_best_effort) int() at use,
                    # so a fractional scalar arg is no longer silently truncated here.
                    self._resolved_vars[str(val.name)] = val.value
                self._both(ControlInstruction("create_var", args={
                    "name": str(val.name), "value": _deferred(val.value),
                }))

    def _resolve_int_best_effort(self, value: Any) -> int:
        from easyasc.utils.var import Var

        if isinstance(value, (int, float)):
            return int(value)
        if isinstance(value, Var):
            if value.name in self._resolved_vars:
                return int(self._resolved_vars[value.name])
            if isinstance(value.value, (int, float)):
                return int(value.value)
            return 0
        if isinstance(value, str):
            if value in self._resolved_vars:
                return int(self._resolved_vars[value])
            try:
                return int(value)
            except ValueError:
                return 0
        return 0

    def _resolve_numel_best_effort(self, shape: Any) -> int:
        if not isinstance(shape, (list, tuple)):
            return 1
        total = 1
        for dim in shape:
            total *= max(self._resolve_int_best_effort(dim), 0)
        return total

    def _record_special_var(self, op: str, out: Any) -> None:
        if out is None or not hasattr(out, "name"):
            return
        from easyasc import globvars

        if op == "GetCubeNum":
            self._resolved_vars[str(out.name)] = int(getattr(globvars, "core_num", 20))
        elif op == "GetVecNum":
            if getattr(self.kernel, "kernel_mode", "mix") == "vec":
                from easyasc.device_profile import vec_num_for
                self._resolved_vars[str(out.name)] = vec_num_for(
                    getattr(globvars, "device_type", "")
                )
            else:
                self._resolved_vars[str(out.name)] = int(getattr(globvars, "core_num", 20)) * 2
        elif op == "GetSubBlockIdx":
            self._resolved_vars[str(out.name)] = 0
        elif op == "GetSubBlockNum":
            self._resolved_vars[str(out.name)] = (
                1 if getattr(self.kernel, "kernel_mode", "mix") == "vec" else 2
            )

    # ------------------------------------------------------------------
    # Auto-sync path
    # ------------------------------------------------------------------

    @staticmethod
    def _has_auto_sync(instructions: Sequence) -> bool:
        return any(str(inst.opname) in ("start_auto_sync", "end_auto_sync") for inst in instructions)

    def _build_with_autosync(self, instructions: Sequence) -> None:
        from easyasc.parser.asc import eliminate_duplicated_event_creation, split_instructions
        from easyasc.parser.asc_autosync import insert_auto_sync
        cube_raw, vec_raw = split_instructions(
            instructions,
            kernel_mode=str(getattr(self.kernel, "kernel_mode", "mix")),
        )
        cube_raw = eliminate_duplicated_event_creation(insert_auto_sync(cube_raw, mode="cube"))
        vec_raw = eliminate_duplicated_event_creation(insert_auto_sync(vec_raw, mode="vec"))
        for inst in cube_raw:
            self._handle_lane(inst, "cube", self.cube_insts)
        for inst in vec_raw:
            self._handle_lane(inst, "vec", self.vec_insts)

    def _pre_register_metadata(self, instructions: Sequence) -> None:
        for inst in instructions:
            op = str(inst.opname)
            if op in ("GetCubeNum", "GetVecNum", "GetVecIdx", "GetSubBlockIdx", "GetSubBlockNum"):
                self._record_special_var(op, getattr(inst, "out", None))
            elif op == "create_gm_tensor":
                self._register_gm(inst.val)
            elif op == "create_gm_tensor_list":
                self._register_gm_tensor_list(inst.val)
            elif op == "get_gm_tensor_list_item":
                self._register_gm_tensor_list_item(inst)
            elif op == "reshape_gm_tensor":
                self._register_gm_reshape(inst)
            elif op == "split_workspace":
                self._register_workspace(inst)

    def _build_without_autosync(self, instructions: Sequence) -> None:
        from easyasc.parser.asc import split_instructions
        cube_raw, vec_raw = split_instructions(
            instructions,
            kernel_mode=str(getattr(self.kernel, "kernel_mode", "mix")),
        )
        for inst in cube_raw:
            self._handle_lane(inst, "cube", self.cube_insts)
        for inst in vec_raw:
            self._handle_lane(inst, "vec", self.vec_insts)

    # ------------------------------------------------------------------
    # Main instruction handler
    # ------------------------------------------------------------------

    def _handle_lane(self, inst: Any, lane: str, target: List[ControlInstruction]) -> None:
        """Handle one instruction for a specific lane (auto-sync path)."""
        op = str(inst.opname)

        if op == "create_gm_tensor":
            self._register_gm(inst.val); return
        if op == "create_gm_tensor_list":
            self._register_gm_tensor_list(inst.val); return
        if op == "create_tensor":
            self._register_local(inst.val); return
        if op in ("create_dbuf", "create_tbuf", "create_qbuf"):
            self._register_buffer(inst.val); return
        if op == "get_buf":
            self._register_buf_tensor(inst)
            self._emit_get_buf(inst, target)
            return
        if op == "slice_gm_tensor":
            self._register_gm_slice(inst)
            self._emit_gm_slice_runtime(inst, target)
            return
        if op == "get_gm_tensor_list_item":
            self._register_gm_tensor_list_item(inst)
            self._emit_gm_tensor_list_item(inst, target)
            return
        if op == "slice_tensor":
            self._register_local_slice(inst)
            self._emit_local_slice_runtime(inst, target)
            return
        if op == "reshape_gm_tensor":
            self._register_gm_reshape(inst)
            self._emit_gm_reshape_runtime(inst, target)
            return
        if op == "reinterpret":
            self._register_reinterpret(inst)
            target.append(ControlInstruction("reinterpret", args=self._raw_kw(inst)))
            return
        if op == "split_workspace":
            self._register_workspace(inst); return
        if op in _EVENT_OPS:
            target.append(ControlInstruction(op, args=self._event_args(inst))); return
        if op in _CONTROL_FLOW_OPS:
            self._emit_lane_cf(inst, target); return
        if op in _VAR_OPS:
            self._emit_lane_var(inst, target); return
        if op == "GetValueFrom":
            self._emit_get_value_from(inst, target)
            return
        if op == "SetValueTo":
            self._emit_set_value_to(inst, target)
            return
        if op in _SYNC_OPS:
            if op in ("bar_all", "barrier"):
                # PipeBarrier<PIPE_X> for X != ALL orders only that hardware
                # pipe. Each simulator pipe mailbox is already FIFO, so there
                # is no additional observable action to model and the barrier
                # is intentionally dropped. Do not turn it into a cross-pipe
                # wait: only Pipe.ALL has drain semantics here.
                pipe = getattr(inst, "kwargs", {}).get("pipe")
                if op == "bar_all" or getattr(pipe, "name", None) == "ALL":
                    target.append(ControlInstruction("bar_all", args=self._raw_kw(inst)))
                return
            target.append(ControlInstruction(op, args=self._raw_kw(inst))); return
        if op == "reset_cache":
            self._reset_local_offsets()
            return
        if op in _NOOP_OPS:
            return

        if op == "sim_dump_tensor":
            self._emit_lane_sim_dump_tensor(inst, lane, target)
            return
        if op == "sim_print":
            self._emit_lane_sim_print(inst, lane, target)
            return

        if op == "call_micro":
            self._emit_call_micro(inst, target); return

        if op == "call_simt":
            self._emit_call_simt(inst, target)
            return

        if lane == "cube":
            pipe = _CUBE_PIPE_BY_OP.get(op)
            if pipe:
                target.append(ControlInstruction(op, pipe_name=pipe, args=self._pipe_args(inst))); return
        else:
            pipe = _VEC_PIPE_BY_OP.get(op)
            if pipe:
                target.append(ControlInstruction(_VEC_RENAME.get(op, op), pipe_name=pipe, args=self._pipe_args(inst))); return

        target.append(ControlInstruction(op, args=self._raw_kw(inst)))

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _both(self, ci: ControlInstruction) -> None:
        self.cube_insts.append(ci)
        self.vec_insts.append(ControlInstruction(ci.opname, args=dict(ci.args), pipe_name=ci.pipe_name))

    @staticmethod
    def _clone(instructions: List[ControlInstruction]) -> List[ControlInstruction]:
        return [ControlInstruction(i.opname, args=dict(i.args), pipe_name=i.pipe_name) for i in instructions]

    def _raw_kw(self, inst: Any) -> Dict[str, Any]:
        kw = getattr(inst, "kwargs", {})
        return {k: _deferred(v) for k, v in kw.items()}

    def _reset_local_offsets(self) -> None:
        self._local_offsets_bytes = {}

    def _local_capacity_bytes(self, role: str) -> int:
        from easyasc import globvars as _gv

        cap_kb = int(getattr(_gv, role + "_cap", 0) or 0)
        if role == "ub":
            cap_kb = effective_ub_cap_kb(cap_kb, self._uses_simt)
        return max(cap_kb, 0) * 1024

    def _assign_local_storage(self, spec: Dict[str, Any]) -> None:
        role = str(spec.get("role", "")).lower()
        if role not in _LOCAL_ROLES or spec.get("source_name"):
            return

        shape = spec.get("shape", ())
        size_bytes = _product(shape) * dtype_size(spec.get("dtype", "float16"))
        offset = int(self._local_offsets_bytes.get(role, 0))
        capacity = self._local_capacity_bytes(role)
        bank = _LOCAL_ROLE_TO_BANK.get(role, role.upper())
        if capacity > 0 and offset + size_bytes > capacity:
            raise RuntimeError(
                "local memory allocation exceeds bank capacity: "
                + "bank=" + bank
                + " request=" + str(size_bytes)
                + " used=" + str(offset)
                + " capacity=" + str(capacity)
                + " tensor=" + str(spec.get("name", ""))
            )
        spec["storage_bank"] = bank
        spec["storage_offset_bytes"] = offset
        spec["storage_size_bytes"] = size_bytes
        tags = list(spec.get("tags", []))
        if "storage_offset_resolved" not in tags:
            tags.append("storage_offset_resolved")
        spec["tags"] = tags
        self._local_offsets_bytes[role] = offset + size_bytes

    # ------------------------------------------------------------------
    # Tensor registration
    # ------------------------------------------------------------------

    def _register_gm(self, gm_tensor: Any) -> None:
        name = str(gm_tensor.name)
        if name in self.tensor_specs:
            return
        shape = tuple(_resolve_dim(d) for d in gm_tensor.shape)
        dtype = _shared_dtype(gm_tensor.dtype)
        # The kernel call records which GMTensors it returned, and that runs
        # before the bridge registers anything, so the set is authoritative.
        outputs = getattr(self.kernel, "_last_output_gmtensors", None)
        is_output = isinstance(outputs, (set, frozenset)) and gm_tensor in outputs
        role = "output" if is_output else "input"
        self.tensor_specs[name] = {
            "name": name, "shape": shape, "dtype": dtype, "role": role,
        }

    def _register_gm_tensor_list(self, tensor_list: Any) -> None:
        name = str(getattr(tensor_list, "name", ""))
        if not name:
            return
        item_names = self._tensor_list_items.get(name)
        if item_names is None:
            item_names = []
            self._tensor_list_items[name] = item_names
        if item_names:
            return
        items = list(getattr(tensor_list, "items", []) or [])
        item_shape = getattr(tensor_list, "item_shape", ())
        shape = tuple(_resolve_dim(d) for d in item_shape) if item_shape else ()
        dtype = _shared_dtype(getattr(tensor_list, "dtype", "float16"))
        output_lists = getattr(self.kernel, "_last_output_gmtensor_lists", set())
        role = "output" if isinstance(output_lists, set) and tensor_list in output_lists else "input"
        for item_idx, item in enumerate(items):
            item_name = str(getattr(item, "name", f"{name}_item{item_idx}"))
            item_names.append(item_name)
            item_item_shape = getattr(item, "shape", item_shape)
            item_shape_tuple = tuple(_resolve_dim(d) for d in item_item_shape) if item_item_shape else shape
            self.tensor_specs[item_name] = {
                "name": item_name,
                "shape": item_shape_tuple,
                "dtype": dtype,
                "role": role,
                "tensor_list": name,
            }

    def _register_gm_tensor_list_item(self, inst: Any) -> None:
        tensor_list = inst.kwargs.get("tensor_list", None)
        out = inst.kwargs.get("out", None)
        if tensor_list is None or out is None:
            return
        self._register_gm_tensor_list(tensor_list)
        out_name = str(getattr(out, "name", ""))
        if not out_name:
            return
        list_name = str(getattr(tensor_list, "name", ""))
        shape = tuple(_resolve_dim(d) for d in getattr(out, "shape", ()) or ())
        dtype = _shared_dtype(getattr(out, "dtype", getattr(tensor_list, "dtype", "float16")))
        self.tensor_specs[out_name] = {
            "name": out_name,
            "shape": shape,
            "dtype": dtype,
            "role": "shared",
            "tensor_list": list_name,
            "source_names": list(self._tensor_list_items.get(list_name, [])),
        }

    def _register_local(self, tensor: Any) -> None:
        name = self._local_name(tensor)
        if name in self.tensor_specs:
            return
        shape = tuple(_resolve_dim(d) for d in tensor.shape)
        dtype = _shared_dtype(tensor.dtype)
        role = _position_role(tensor.position)
        spec = {
            "name": name, "shape": shape, "dtype": dtype, "role": role,
        }
        self._assign_local_storage(spec)
        self.tensor_specs[name] = spec

    def _register_gm_slice(self, inst: Any) -> None:
        src = inst.kwargs.get("src", inst.kwargs.get("tensor"))
        out = inst.kwargs.get("out", inst.kwargs.get("dst"))
        if src is None or out is None:
            return
        out_name = str(out.name)
        src_name = str(src.name)
        shape = tuple(_resolve_dim(d) for d in out.shape) if hasattr(out, "shape") else ()
        dtype = _shared_dtype(out.dtype) if hasattr(out, "dtype") else self.tensor_specs.get(src_name, {}).get("dtype", "float16")
        self.tensor_specs[out_name] = {
            "name": out_name, "shape": shape, "dtype": dtype, "role": "shared",
            "source_name": src_name,
        }

    def _register_local_slice(self, inst: Any) -> None:
        src = inst.kwargs.get("src")
        out = inst.kwargs.get("out")
        if src is None or out is None:
            return
        src_name = self._local_name(src)
        out_name = self._local_name(out)
        shape = tuple(_resolve_dim(d) for d in out.shape) if hasattr(out, "shape") else ()
        dtype = _shared_dtype(out.dtype) if hasattr(out, "dtype") else "float16"
        role = _position_role(out.position) if hasattr(out, "position") else "shared"
        self.tensor_specs[out_name] = {
            "name": out_name, "shape": shape, "dtype": dtype, "role": role,
            "source_name": src_name,
        }

    def _register_gm_reshape(self, inst: Any) -> None:
        src = inst.kwargs.get("src")
        out = inst.kwargs.get("out")
        if src is None or out is None:
            return
        src_name = str(src.name)
        out_name = str(out.name)
        shape = tuple(_resolve_dim(d) for d in out.shape) if hasattr(out, "shape") else ()
        dtype = self.tensor_specs.get(src_name, {}).get("dtype", "float16")
        self.tensor_specs[out_name] = {
            "name": out_name, "shape": shape, "dtype": dtype, "role": "shared",
            "source_name": src_name,
        }

    def _register_buffer(self, buf: Any) -> None:
        self._ensure_buffer_slots(buf)

    def _ensure_buffer_slots(self, buf: Any, source: Any = None) -> List[str]:
        buf_name = str(buf.name)
        if buf_name in self._buffer_slot_names:
            return self._buffer_slot_names[buf_name]
        from easyasc.utils.Tensor import DBuff, TBuff
        slot_count = 2
        if isinstance(buf, TBuff):
            slot_count = 3
        elif hasattr(buf, "slot_count"):
            slot_count = int(buf.slot_count)
        if source is None:
            source = buf
        shape_raw = getattr(source, "shape", ())
        shape = tuple(_resolve_dim(d) for d in shape_raw) if shape_raw else ()
        numel = 1
        for d in shape:
            numel *= d
        dtype = _shared_dtype(source.dtype) if hasattr(source, "dtype") else "float16"
        role = _position_role(source.position) if hasattr(source, "position") else "ub"
        slot_names: List[str] = []
        for si in range(slot_count):
            slot_name = "__bufslot__%s_%d" % (buf_name, si)
            slot_names.append(slot_name)
            spec = {
                "name": slot_name, "shape": (numel,), "dtype": dtype, "role": role,
            }
            self._assign_local_storage(spec)
            self.tensor_specs[slot_name] = spec
        self._buffer_slot_names[buf_name] = slot_names
        return slot_names

    def _register_buf_tensor(self, inst: Any) -> None:
        buf = inst.kwargs.get("buf")
        out = getattr(inst, "out", inst.kwargs.get("out"))
        if buf is None or out is None:
            return
        self._ensure_buffer_slots(buf, source=out)
        tensor = out
        if tensor is None:
            return
        name = self._local_name(tensor)
        if name not in self.tensor_specs:
            shape = tuple(_resolve_dim(d) for d in tensor.shape) if hasattr(tensor, "shape") else ()
            dtype = _shared_dtype(tensor.dtype) if hasattr(tensor, "dtype") else "float16"
            role = _position_role(tensor.position) if hasattr(tensor, "position") else "ub"
            self.tensor_specs[name] = {"name": name, "shape": shape, "dtype": dtype, "role": role}

    def _emit_get_buf(self, inst: Any, target: List[ControlInstruction]) -> None:
        buf = inst.kwargs.get("buf")
        out = getattr(inst, "out", inst.kwargs.get("out"))
        if buf is None or out is None:
            return
        buf_name = str(buf.name)
        slot_names = self._buffer_slot_names.get(buf_name, [])
        view_name = str(out.name)
        target.append(ControlInstruction("get_buf", args={
            "view_name": view_name,
            "index": _deferred(inst.kwargs.get("index", 0)),
            "slot_names": list(slot_names),
        }))

    def _register_reinterpret(self, inst: Any) -> None:
        kw = getattr(inst, "kwargs", {})
        src = kw.get("src")
        out = kw.get("dst", kw.get("out"))
        if src is None or out is None:
            return
        src_name = self._local_name(src) if hasattr(src, "position") else str(getattr(src, "name", src))
        out_name = self._local_name(out) if hasattr(out, "position") else str(getattr(out, "name", out))
        dst_shape = kw.get("dst_shape")
        if dst_shape is not None:
            shape = tuple(_resolve_dim(d) for d in dst_shape)
        elif hasattr(out, "shape"):
            shape = tuple(_resolve_dim(d) for d in out.shape)
        else:
            shape = ()
        dtype = _shared_dtype(out.dtype) if hasattr(out, "dtype") else "float16"
        role = _position_role(out.position) if hasattr(out, "position") else "shared"
        self.tensor_specs[out_name] = {
            "name": out_name, "shape": shape, "dtype": dtype, "role": role,
            "source_name": src_name,
        }

    def _register_workspace(self, inst: Any) -> None:
        val = inst.kwargs.get("val")
        dtype = inst.kwargs.get("dtype")
        name = inst.kwargs.get("name", "")
        if not isinstance(name, str) or name == "":
            if hasattr(val, "name"):
                name = str(val.name)
            else:
                return
        if name in self.tensor_specs:
            return
        numel = self._resolve_int_best_effort(inst.kwargs.get("numel"))
        if numel <= 0:
            shape = getattr(val, "shape", None)
            numel = self._resolve_numel_best_effort(shape)
        resolved_numel = max(numel, 1)
        resolved_dtype = _shared_dtype(
            dtype if dtype is not None else getattr(val, "dtype", "float16")
        )
        size_bytes = resolved_numel * dtype_size(resolved_dtype)
        offset_bytes = self._workspace_offset_bytes
        self.tensor_specs[name] = {
            "name": name,
            "shape": (resolved_numel,),
            "dtype": resolved_dtype,
            "role": "workspace",
            "storage_offset_bytes": offset_bytes,
            "storage_size_bytes": size_bytes,
        }
        self._workspace_offset_bytes = offset_bytes + size_bytes

    @staticmethod
    def _local_name(tensor: Any) -> str:
        if hasattr(tensor, "sim_name"):
            return str(tensor.sim_name)
        return str(tensor.name)

    # ------------------------------------------------------------------
    # Pipe args: translate tensor refs to string names
    # ------------------------------------------------------------------

    def _pipe_args(self, inst: Any) -> Dict[str, Any]:
        kw = getattr(inst, "kwargs", {})
        out: Dict[str, Any] = {}
        for k, v in kw.items():
            if self._is_tensor_ref(v):
                out[k] = self._tensor_name(v)
            else:
                out[k] = _deferred(v)
        if str(getattr(inst, "opname", "")) == "l0c_to_ub":
            dst = kw.get("dst")
            if (
                self._is_tensor_ref(dst)
                and _position_role(getattr(dst, "position", None)) == "ub"
                and str(getattr(dst, "name", "")).startswith("_tmp_tensor_")
                and (
                    (getattr(dst, "source_buf", None) is None and getattr(dst, "source_index", None) is None)
                    or self._is_static_local_slice(dst)
                )
            ):
                dst_name = self._tensor_name(dst)
                out["dst_vec0"] = dst_name
                out["dst_vec1"] = "_vec1_" + dst_name
        return out

    @staticmethod
    def _is_tensor_ref(v: Any) -> bool:
        return hasattr(v, "shape") and hasattr(v, "dtype") and hasattr(v, "name")

    @staticmethod
    def _is_static_local_slice(tensor: Any) -> bool:
        offset = getattr(tensor, "offset", None)
        span = getattr(tensor, "span", None)
        shape = getattr(tensor, "shape", None)
        if not isinstance(offset, (list, tuple)) or not isinstance(span, (list, tuple)):
            return False
        if not isinstance(shape, (list, tuple)) or len(span) != len(shape):
            return False
        for value in offset:
            if _resolve_dim(value) != 0:
                return True
        return any(_resolve_dim(s) != _resolve_dim(d) for s, d in zip(span, shape))

    def _tensor_name(self, t: Any) -> str:
        if hasattr(t, "sim_name"):
            return str(t.sim_name)
        return str(t.name)

    # ------------------------------------------------------------------
    # Event args
    # ------------------------------------------------------------------

    def _event_args(self, inst: Any) -> Dict[str, Any]:
        kw = getattr(inst, "kwargs", {})
        event = kw.get("val", kw.get("event"))
        if event is None:
            return {}
        return {
            "event_name": str(getattr(event, "name", event)),
            "event_kind": str(getattr(event, "event_kind", "s")),
            "src_pipe": str(getattr(event, "src_pipe", "")),
            "dst_pipe": str(getattr(event, "dst_pipe", "")),
            "preset": bool(getattr(event, "preset", False)),
        }

    # ------------------------------------------------------------------
    # Control flow
    # ------------------------------------------------------------------

    def _emit_lane_cf(self, inst: Any, target: List[ControlInstruction]) -> None:
        op = str(inst.opname)
        kw = getattr(inst, "kwargs", {})
        if op in ("start_loop", "start_micro_loop"):
            var = kw.get("var")
            target.append(ControlInstruction(op, args={
                "var_name": str(var.name) if hasattr(var, "name") else "",
                "start": _deferred(kw.get("start", 0)),
                "stop": _deferred(kw.get("stop", 0)),
                "step": _deferred(kw.get("step", 1)),
            }))
        elif op in ("start_if", "start_elif"):
            target.append(ControlInstruction(op, args={"cond": _deferred(kw.get("cond"))}))
        else:
            target.append(ControlInstruction(op))

    # ------------------------------------------------------------------
    # Variable ops
    # ------------------------------------------------------------------

    def _emit_lane_var(self, inst: Any, target: List[ControlInstruction]) -> None:
        op = str(inst.opname)
        if op == "create_var":
            var = getattr(inst, "val", None)
            if var and hasattr(var, "name"):
                init_value = getattr(inst, "kwargs", {}).get("init_value", var.value)
                target.append(ControlInstruction("create_var", args={
                    "name": str(var.name), "value": _deferred(init_value),
                }))
        elif op == "create_varlist":
            varlist = getattr(inst, "varlist", None)
            if varlist is None:
                varlist = getattr(inst, "kwargs", {}).get("varlist")
            if varlist is None or not hasattr(varlist, "name"):
                return
            target.append(ControlInstruction("create_varlist", args={
                "name": str(varlist.name),
                "length": int(getattr(varlist, "length", 0)),
                "dtype": _shared_dtype(getattr(varlist, "dtype", "")),
            }))
        elif op == "var_assign":
            out = getattr(inst, "out", None)
            target.append(ControlInstruction("var_assign", args={
                "dst": _var_operand(out),
                "src": _var_operand(getattr(inst, "src", 0)),
            }))
        elif op == "tensorlist_size":
            out = getattr(inst, "out", None)
            tensor_list = getattr(inst, "tensor_list", None)
            list_name = str(getattr(tensor_list, "name", ""))
            if tensor_list is not None:
                self._register_gm_tensor_list(tensor_list)
            target.append(ControlInstruction("tensorlist_size", args={
                "dst": _var_operand(out),
                "list_name": list_name,
                "item_names": list(self._tensor_list_items.get(list_name, [])),
            }))
        elif op == "tensorlist_item_numel":
            out = getattr(inst, "out", None)
            tensor_list = getattr(inst, "tensor_list", None)
            list_name = str(getattr(tensor_list, "name", ""))
            if tensor_list is not None:
                self._register_gm_tensor_list(tensor_list)
            target.append(ControlInstruction("tensorlist_item_numel", args={
                "dst": _var_operand(out),
                "list_name": list_name,
                "index": _var_operand(getattr(inst, "index", 0)),
                "item_names": list(self._tensor_list_items.get(list_name, [])),
            }))
        elif op in ("var_add", "var_sub", "var_mul", "var_div", "var_mod", "CeilDiv", "Min", "Max"):
            out = getattr(inst, "out", None)
            target.append(ControlInstruction(op, args={
                "dst": _var_operand(out),
                "a": _var_operand(getattr(inst, "a", 0)),
                "b": _var_operand(getattr(inst, "b", 0)),
            }))
        elif op in ("scalar_sqrt", "scalar_abs"):
            out = getattr(inst, "out", None)
            target.append(ControlInstruction(op, args={
                "dst": _var_operand(out),
                "a": _var_operand(getattr(inst, "a", 0)),
            }))
        elif op.startswith("Align"):
            out = getattr(inst, "out", None)
            target.append(ControlInstruction(op, args={
                "dst": _var_operand(out),
                "a": _var_operand(getattr(inst, "a", 0)),
            }))
        elif op in ("GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx", "GetSubBlockNum"):
            out = getattr(inst, "out", None)
            self._record_special_var(op, out)
            target.append(ControlInstruction(op, args={"dst": str(out.name) if hasattr(out, "name") else ""}))

    @staticmethod
    def _var_dtype_name(var: Any) -> str:
        dtype = getattr(var, "dtype", None)
        return _shared_dtype(dtype) if dtype is not None else ""

    @staticmethod
    def _tensor_dtype_name(tensor: Any) -> str:
        dtype = getattr(tensor, "dtype", None)
        return _shared_dtype(dtype) if dtype is not None else ""

    def _emit_get_value_from(self, inst: Any, target: List[ControlInstruction]) -> None:
        kw = getattr(inst, "kwargs", {})
        dst = kw.get("dst", kw.get("out"))
        src = kw.get("src")
        target.append(ControlInstruction("GetValueFrom", args={
            "dst": str(getattr(dst, "name", dst)),
            "out": str(getattr(dst, "name", dst)),
            "src": self._tensor_name(src) if self._is_tensor_ref(src) else _deferred(src),
            "dtype": self._var_dtype_name(dst),
        }))

    def _emit_set_value_to(self, inst: Any, target: List[ControlInstruction]) -> None:
        kw = getattr(inst, "kwargs", {})
        src = kw.get("src")
        dst = kw.get("dst")
        target.append(ControlInstruction("SetValueTo", args={
            "src": self._tensor_name(src) if self._is_tensor_ref(src) else _deferred(src),
            "dst": str(getattr(dst, "name", dst)),
            "dtype": self._tensor_dtype_name(src),
        }))

    # ------------------------------------------------------------------
    # Sync
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Simulator debug ops
    # ------------------------------------------------------------------

    def _emit_lane_sim_dump_tensor(self, inst: Any, lane: str, target: List[ControlInstruction]) -> None:
        target_lane, ci = self._build_sim_dump_tensor(inst, lane)
        if target_lane == lane:
            target.append(ci)

    def _emit_lane_sim_print(self, inst: Any, lane: str, target: List[ControlInstruction]) -> None:
        target_lane, ci = self._build_sim_print(inst, lane)
        if target_lane == lane:
            target.append(ci)

    def _build_sim_dump_tensor(self, inst: Any, preferred_lane: str) -> Tuple[str, ControlInstruction]:
        from easyasc.utils.Tensor import GMTensor, Tensor
        from easyasc.utils.positions import Position

        tensor = inst.kwargs.get("tensor", None)
        filename = inst.kwargs.get("filename", "")
        pipe_name = str(inst.kwargs.get("pipe", "S"))
        if not isinstance(tensor, (Tensor, GMTensor)):
            raise TypeError("sim_dump_tensor requires Tensor/GMTensor, got: " + str(type(tensor)))
        lane = self._select_sim_debug_lane(
            pipe_name,
            needs_cube_only=isinstance(tensor, Tensor) and tensor.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C, Position.BT),
            needs_vec_only=isinstance(tensor, Tensor) and tensor.position is Position.UB,
            preferred_lane=preferred_lane,
            opname="sim_dump_tensor",
        )
        ci = ControlInstruction(
            "sim_dump_tensor",
            pipe_name="" if pipe_name == "S" else pipe_name,
            args={
                "tensor": self._tensor_name(tensor),
                "filename": filename,
            },
        )
        return lane, ci

    def _build_sim_print(self, inst: Any, preferred_lane: str) -> Tuple[str, ControlInstruction]:
        payload = inst.kwargs.get("payload", [])
        pipe_name = str(inst.kwargs.get("pipe", "S"))
        if not isinstance(payload, (list, tuple)):
            raise TypeError("sim_print payload must be list/tuple, got: " + str(type(payload)))
        encoded_payload: List[Dict[str, Any]] = []
        needs_cube_only = False
        needs_vec_only = False
        for item in payload:
            encoded_item, item_cube_only, item_vec_only = self._encode_sim_print_item(item)
            encoded_payload.append(encoded_item)
            needs_cube_only = needs_cube_only or item_cube_only
            needs_vec_only = needs_vec_only or item_vec_only
        lane = self._select_sim_debug_lane(
            pipe_name,
            needs_cube_only=needs_cube_only,
            needs_vec_only=needs_vec_only,
            preferred_lane=preferred_lane,
            opname="sim_print",
        )
        ci = ControlInstruction(
            "sim_print",
            pipe_name="" if pipe_name == "S" else pipe_name,
            args={"payload": encoded_payload},
        )
        return lane, ci

    def _encode_sim_print_item(self, item: Any) -> Tuple[Dict[str, Any], bool, bool]:
        from easyasc.utils.Tensor import GMTensor, Tensor
        from easyasc.utils.datatype import DataTypeValue
        from easyasc.utils.positions import Position
        from easyasc.utils.var import Expr, Var

        if isinstance(item, GMTensor):
            return {"kind": "gm_tensor", "value": str(item.name)}, False, False
        if isinstance(item, Tensor):
            tensor_name = self._tensor_name(item)
            if item.position is Position.UB:
                return {"kind": "local_tensor", "value": tensor_name}, False, True
            if item.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C, Position.BT):
                return {"kind": "local_tensor", "value": tensor_name}, True, False
            return {"kind": "local_tensor", "value": tensor_name}, False, False
        if isinstance(item, Var):
            return {"kind": "var", "value": str(item.name)}, False, False
        if isinstance(item, Expr):
            return {"kind": "expr", "value": str(item)}, False, False
        if isinstance(item, DataTypeValue):
            return {"kind": "literal", "value": str(item)}, False, False
        if isinstance(item, (int, float, bool, str)):
            return {"kind": "literal", "value": item}, False, False
        return {"kind": "literal", "value": str(item)}, False, False

    def _select_sim_debug_lane(
        self,
        pipe_name: str,
        needs_cube_only: bool,
        needs_vec_only: bool,
        preferred_lane: str,
        opname: str,
    ) -> str:
        if needs_cube_only and needs_vec_only:
            raise ValueError(opname + " cannot mix cube-only and vec-only local tensors in one task")
        if pipe_name in _SIM_DEBUG_CUBE_ONLY_PIPES:
            if needs_vec_only:
                raise ValueError(opname + " pipe=" + pipe_name + " cannot access vec-only local tensors")
            return "cube"
        if pipe_name in _SIM_DEBUG_VEC_ONLY_PIPES:
            if needs_cube_only:
                raise ValueError(opname + " pipe=" + pipe_name + " cannot access cube-only local tensors")
            return "vec"
        if needs_cube_only:
            return "cube"
        if needs_vec_only:
            return "vec"
        return "vec" if str(preferred_lane).startswith("vec") else "cube"

    # ------------------------------------------------------------------
    # call_micro
    # ------------------------------------------------------------------

    def _collect_micro_defs(self) -> Dict[str, Any]:
        micros = getattr(self.kernel, "used_micros", set())
        defs: Dict[str, Any] = {}
        for micro in micros:
            defs[micro.name] = {
                "instructions": list(micro.instructions),
                "input_list": list(micro.input_list),
            }
        return defs

    def _collect_simt_defs(self) -> Dict[str, Any]:
        simts = getattr(self.kernel, "used_simts", set())
        defs: Dict[str, Any] = {}
        for mod in simts:
            locked = getattr(mod, "_locked_dtypes", None) or []
            defs[mod.name] = {
                "instructions": list(mod.lower_to_ir()),
                "input_list": list(mod.input_list),
                "locked_dtypes": [
                    str(getattr(dt, "name", dt)) for dt in locked
                ],
                "num_threads": int(getattr(mod, "num_threads", 1024)),
            }
        return defs

    def _find_simt_module(self, name: str) -> Optional[Any]:
        simts = getattr(self.kernel, "used_simts", set())
        for mod in simts:
            if str(getattr(mod, "name", "")) == name:
                return mod
        return None

    def _emit_call_simt(self, inst: Any, target: List[ControlInstruction]) -> None:
        from easyasc.utils.positions import Position

        kw = getattr(inst, "kwargs", {})
        name = str(kw.get("name", ""))
        actuals = kw.get("args", [])
        if not isinstance(actuals, (list, tuple)):
            actuals = []
        simt_mod = self._find_simt_module(name)
        input_list = list(getattr(simt_mod, "input_list", []) or [])
        for (formal_name, kind), actual in zip(input_list, actuals):
            if kind == "Tensor":
                pos = getattr(actual, "position", None)
                if pos is not Position.UB:
                    raise TypeError(
                        "SimtModule " + repr(name) + ": Tensor-kind formal "
                        + repr(formal_name) + " requires UB position, got "
                        + str(getattr(pos, "name", pos))
                    )
        call_bindings: List[Dict[str, Any]] = []
        for actual in actuals:
            if self._is_tensor_ref(actual):
                call_bindings.append({
                    "kind": "tensor",
                    "actual_name": self._tensor_name(actual),
                })
            else:
                call_bindings.append({
                    "kind": "var",
                    "actual_ref": _var_operand(actual),
                })
        target.append(ControlInstruction(
            "call_simt",
            pipe_name="V",
            args={"name": name, "call_bindings": call_bindings},
        ))

    def _emit_gm_slice_runtime(self, inst: Any, target: List[ControlInstruction]) -> None:
        src = inst.kwargs.get("src", inst.kwargs.get("tensor"))
        out = inst.kwargs.get("out", inst.kwargs.get("dst"))
        if src is None or out is None:
            return
        offsets = getattr(inst, "offset", None) or [0] * len(getattr(out, "shape", []) or [])
        src_shape = getattr(src, "shape", None) or []
        spans = getattr(inst, "span", None) or list(getattr(out, "shape", []) or [])
        args: Dict[str, Any] = {
            "view_name": str(out.name),
            "source_name": str(src.name),
            "ndim": len(offsets),
        }
        for i, off in enumerate(offsets):
            args["offset_" + str(i)] = _deferred(off)
        for i, dim in enumerate(src_shape):
            args["src_dim_" + str(i)] = _deferred(dim)
        for i, sp in enumerate(spans):
            args["span_" + str(i)] = _deferred(sp)
        target.append(ControlInstruction("slice_gm_tensor", args=args))

    def _emit_gm_tensor_list_item(self, inst: Any, target: List[ControlInstruction]) -> None:
        tensor_list = inst.kwargs.get("tensor_list", None)
        out = inst.kwargs.get("out", None)
        if tensor_list is None or out is None:
            return
        list_name = str(getattr(tensor_list, "name", ""))
        self._register_gm_tensor_list(tensor_list)
        target.append(ControlInstruction("get_gm_tensor_list_item", args={
            "view_name": str(getattr(out, "name", "")),
            "list_name": list_name,
            "index": _deferred(inst.kwargs.get("index", 0)),
            "item_names": list(self._tensor_list_items.get(list_name, [])),
        }))

    def _emit_gm_reshape_runtime(self, inst: Any, target: List[ControlInstruction]) -> None:
        src = inst.kwargs.get("src", None)
        out = inst.kwargs.get("out", None)
        if src is None or out is None:
            return
        shape = inst.kwargs.get("dst_shape", None)
        if shape is None:
            shape = list(getattr(out, "shape", []) or [])
        args: Dict[str, Any] = {
            "view_name": str(getattr(out, "name", "")),
            "source_name": str(getattr(src, "name", "")),
            "ndim": len(shape),
        }
        for dim_idx, dim in enumerate(shape):
            args["shape_" + str(dim_idx)] = _deferred(dim)
        target.append(ControlInstruction("reshape_gm_tensor", args=args))

    def _emit_local_slice_runtime(self, inst: Any, target: List[ControlInstruction]) -> None:
        src = inst.kwargs.get("src", inst.kwargs.get("tensor"))
        out = inst.kwargs.get("out", inst.kwargs.get("dst"))
        if src is None or out is None:
            return
        offsets = getattr(inst, "offset", None) or [0] * len(getattr(out, "shape", []) or [])
        spans = getattr(inst, "span", None) or list(getattr(out, "shape", []) or [])
        steps = getattr(inst, "step", None) or [1] * len(offsets)
        src_shape = getattr(src, "shape", None) or []
        args: Dict[str, Any] = {
            "view_name": str(out.name),
            "source_name": self._tensor_name(src),
            "ndim": len(offsets),
        }
        for i, off in enumerate(offsets):
            args["offset_" + str(i)] = _deferred(off)
        for i, dim in enumerate(src_shape):
            args["src_dim_" + str(i)] = _deferred(dim)
        for i, sp in enumerate(spans):
            args["span_" + str(i)] = _deferred(sp)
        for i, st in enumerate(steps):
            args["step_" + str(i)] = _deferred(st)
        target.append(ControlInstruction("slice_tensor", args=args))

    def _emit_call_micro(self, inst: Any, target: List[ControlInstruction]) -> None:
        kw = getattr(inst, "kwargs", {})
        name = str(kw.get("name", ""))
        args = kw.get("args", [])
        if not isinstance(args, (list, tuple)):
            args = []
        call_bindings: List[Dict[str, Any]] = []
        for actual in args:
            if self._is_tensor_ref(actual):
                call_bindings.append({"kind": "tensor", "actual_name": self._tensor_name(actual)})
            else:
                call_bindings.append({"kind": "var", "actual_ref": _var_operand(actual)})
        target.append(ControlInstruction("call_micro", pipe_name="V", args={
            "name": name, "call_bindings": call_bindings,
        }))
