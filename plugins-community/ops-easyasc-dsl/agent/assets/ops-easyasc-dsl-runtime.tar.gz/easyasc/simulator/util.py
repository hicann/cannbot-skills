from __future__ import annotations

import re

import torch


def align16(value: int) -> int:
    return ((value + 15) // 16) * 16


def align_to(value: int, align: int) -> int:
    return ((value + align - 1) // align) * align


def flat_numel(tensor: torch.Tensor) -> int:
    return int(tensor.numel())


def flat_nbytes(tensor: torch.Tensor) -> int:
    return flat_numel(tensor) * int(tensor.element_size())


def require_flat_elements(opname: str, role: str, name: str, tensor: torch.Tensor, required: int) -> None:
    required = int(required)
    if required < 0:
        raise ValueError(f"{opname} {role} footprint must be non-negative, got {required}")
    have = flat_numel(tensor)
    if required > have:
        raise RuntimeError(
            f"{opname} {role} footprint exceeds tensor storage: "
            f"{name} requires {required} elements, but tensor has {have} elements"
        )


def require_flat_bytes(opname: str, role: str, name: str, tensor: torch.Tensor, required: int) -> None:
    required = int(required)
    if required < 0:
        raise ValueError(f"{opname} {role} byte footprint must be non-negative, got {required}")
    have = flat_nbytes(tensor)
    if required > have:
        raise RuntimeError(
            f"{opname} {role} byte footprint exceeds tensor storage: "
            f"{name} requires {required} bytes, but tensor has {have} bytes"
        )


def burst_footprint(n_burst: int, step: int, touched: int) -> int:
    n_burst = int(n_burst)
    step = int(step)
    touched = int(touched)
    if n_burst <= 0 or touched <= 0:
        return 0
    return (n_burst - 1) * step + touched


def require_burst_bytes(
    opname: str, role: str, name: str, tensor: torch.Tensor,
    n_burst: int, step: int, touched: int,
) -> None:
    require_flat_bytes(opname, role, name, tensor, burst_footprint(n_burst, step, touched))


def strided_2d_footprint(rows: int, cols: int, row_stride: int) -> int:
    rows = int(rows)
    cols = int(cols)
    row_stride = int(row_stride)
    if rows <= 0 or cols <= 0:
        return 0
    return (rows - 1) * row_stride + cols


def require_strided_2d_elements(
    opname: str, role: str, name: str, tensor: torch.Tensor,
    rows: int, cols: int, row_stride: int,
) -> None:
    require_flat_elements(opname, role, name, tensor, strided_2d_footprint(rows, cols, row_stride))


def nz_footprint(n: int, stride_m: int, c0: int) -> int:
    n = int(n)
    stride_m = int(stride_m)
    c0 = int(c0)
    if n <= 0:
        return 0
    return ((n + c0 - 1) // c0) * stride_m * c0


def nz_tail_write_footprint(n: int, row0: int, rows: int, stride_m: int, c0: int, col0: int = 0) -> int:
    n = int(n)
    row0 = int(row0)
    rows = int(rows)
    stride_m = int(stride_m)
    c0 = int(c0)
    col0 = int(col0)
    if n <= 0 or rows <= 0:
        return 0
    last = 0
    src_col = 0
    while src_col < n:
        dst_col = col0 + src_col
        block = dst_col // c0
        within = dst_col % c0
        cols = min(c0 - within, n - src_col)
        end = block * stride_m * c0 + (row0 + rows - 1) * c0 + within + cols
        last = max(last, end)
        src_col += cols
    return last


def local_slice_suffix(name: str):
    match = re.search(r":(-?\d+),(-?\d+):(-?\d+),(-?\d+)$", str(name))
    if match is None:
        return None
    return tuple(int(match.group(i)) for i in range(1, 5))


def zz_footprint(m: int, n_align: int, row_block: int = 16) -> int:
    m = int(m)
    n_align = int(n_align)
    row_block = int(row_block)
    if m <= 0 or n_align <= 0:
        return 0
    return ((m + row_block - 1) // row_block) * n_align * row_block


def require_same_dtype(opname: str, dst: torch.Tensor, src: torch.Tensor) -> None:
    if dst.dtype != src.dtype:
        raise ValueError(
            f"{opname} requires dst/src data types to match, got: {dst.dtype} vs {src.dtype}"
        )


def byte_storage_offset(tensor: torch.Tensor) -> int:
    return int(tensor.storage_offset()) * int(tensor.element_size())


def require_32b_aligned(opname: str, role: str, name: str, tensor: torch.Tensor) -> None:
    byte_offset = byte_storage_offset(tensor)
    if byte_offset % 32 != 0:
        raise RuntimeError(
            f"{opname} {role} address must be 32-byte aligned: "
            f"{name} has byte offset {byte_offset}"
        )


def require_byte_aligned(opname: str, role: str, name: str, tensor: torch.Tensor, alignment: int) -> None:
    alignment = int(alignment)
    if alignment <= 0:
        raise ValueError(f"alignment must be positive, got {alignment}")
    byte_offset = byte_storage_offset(tensor)
    if byte_offset % alignment != 0:
        raise RuntimeError(
            f"{opname} {role} address must be {alignment}-byte aligned: "
            f"{name} has byte offset {byte_offset}"
        )


def _logical_zeros(src: torch.Tensor, rows: int, cols: int) -> torch.Tensor:
    if str(src.dtype).startswith("torch.float8_"):
        return torch.zeros((rows, cols), dtype=torch.float32, device=src.device)
    return src.new_zeros((rows, cols))


def decode_nz_to_nd(
    src_flat: torch.Tensor, m: int, n: int, stride_m: int, c0: int,
) -> torch.Tensor:
    out = _logical_zeros(src_flat, m, n)
    if m == 0 or n == 0:
        return out
    blocks = (n + c0 - 1) // c0
    panel = src_flat[: blocks * stride_m * c0].reshape(blocks, stride_m, c0)
    full = n // c0
    if full > 0:
        out[:, : full * c0].copy_(panel[:full, :m, :].permute(1, 0, 2).reshape(m, full * c0))
    tail = n - full * c0
    if tail > 0:
        out[:, full * c0 : full * c0 + tail].copy_(panel[full, :m, :tail])
    return out


def encode_nd_to_nz(
    logical: torch.Tensor, dst_flat: torch.Tensor,
    m: int, n: int, stride_m: int, c0: int, row0: int = 0, col0: int = 0,
) -> None:
    if m == 0 or n == 0:
        return
    row0 = int(row0)
    col0 = int(col0)
    src_col = 0
    while src_col < n:
        dst_col = col0 + src_col
        block = dst_col // c0
        within = dst_col % c0
        cols = min(c0 - within, n - src_col)
        base = block * stride_m * c0 + row0 * c0
        panel = dst_flat[base: base + m * c0].reshape(m, c0)
        panel[:, within:within + cols].copy_(logical[:, src_col:src_col + cols])
        if col0 == 0 and src_col + cols == n and within + cols < c0:
            panel[:, within + cols:c0].zero_()
        src_col += cols


def decode_zz_to_nd(
    src_flat: torch.Tensor, m: int, n: int, n_align: int, row_block: int = 16,
) -> torch.Tensor:
    out = _logical_zeros(src_flat, m, n)
    if m == 0 or n == 0:
        return out
    bc = (m + row_block - 1) // row_block
    panel = src_flat[: bc * n_align * row_block].reshape(bc, n_align, row_block)
    for bi in range(bc):
        r0 = bi * row_block
        r1 = min(r0 + row_block, m)
        out[r0:r1, :].copy_(panel[bi, :n, : r1 - r0].transpose(0, 1))
    return out


def encode_nd_to_zz(
    logical: torch.Tensor, dst_flat: torch.Tensor,
    m: int, n: int, n_align: int, row_block: int = 16,
) -> None:
    if m == 0 or n == 0:
        return
    bc = (m + row_block - 1) // row_block
    panel = dst_flat[: bc * n_align * row_block].reshape(bc, n_align, row_block)
    for bi in range(bc):
        r0 = bi * row_block
        r1 = min(r0 + row_block, m)
        panel[bi, :n, : r1 - r0].copy_(logical[r0:r1, :].transpose(0, 1))


def gather_strided(flat: torch.Tensor, rows: int, cols: int, stride: int) -> torch.Tensor:
    out = _logical_zeros(flat, rows, cols)
    if rows == 0 or cols == 0:
        return out
    for r in range(rows):
        out[r, :].copy_(flat[r * stride : r * stride + cols])
    return out


def scatter_strided(flat: torch.Tensor, values: torch.Tensor, stride: int) -> None:
    rows = int(values.shape[0])
    cols = int(values.shape[1]) if values.dim() >= 2 else 0
    if rows == 0 or cols == 0:
        return
    for r in range(rows):
        flat[r * stride : r * stride + cols].copy_(values[r, :])
