from __future__ import annotations

import multiprocessing
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from queue import Empty, Queue
from typing import Any, Deque, Dict, List, Optional, Tuple, Union

from .program import PipeTask


# ---------------------------------------------------------------------------
# IntraCoreSync — cross-lane sync within one core (threading)
#
# Each vec lane has 8 vec_ready counters + 8 vec_wait counters.
#
#   cube_ready(flag_id):
#       vec0.wait[fid] += 1, vec1.wait[fid] += 1
#       (cube broadcasts to all vecs)
#
#   wait_cube(vec_idx, flag_id):
#       block until vec[idx].wait[fid] > 0, then -= 1
#       (each vec consumes its own copy)
#
#   vec_ready(vec_idx, flag_id):
#       vec[idx].ready[fid] += 1
#       (each vec publishes independently)
#
#   wait_vec(flag_id):
#       block until ALL vec[*].ready[fid] > 0, then each -= 1
#       (cube waits for all vecs atomically)
#
#   intracore_allvec_ready(vec_idx, flag_id):
#       vec[idx].allvec_ready[fid] += 1
#
#   intracore_allvec_wait(vec_idx, flag_id):
#       block until both vec lanes in this core have published the same phase,
#       then advance only this vec lane's wait phase
#       (same-core vec-lane barrier; no other core participates)
#
# setflag/waitflag and SEvent/DEvent share the lane-local LocalSync below.
# LocalEventBank only adds named event descriptors and automatic flag-id
# allocation on top of the same flag table.
# ---------------------------------------------------------------------------

MAX_FLAGS_PER_LANE = 8
MAX_FLAG_COUNT = 15
VEC_COUNT = 2
MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR = 8


@dataclass(frozen=True)
class _SyncCycleToken:
    signal_cycle: float
    visible_cycle: float


@dataclass
class IntraCoreSync:
    _vec_ready: List[List[int]] = field(init=False)
    _vec_wait: List[List[int]] = field(init=False)
    # FIFO of ready cycles for per-flag cube→vec signals. One deque per (vec_idx, flag_id)
    # because cube broadcasts the same signal cycle to both vecs but each vec consumes
    # independently.
    _cube_ready_cycles: List[List[Deque[_SyncCycleToken]]] = field(init=False)
    # FIFO of ready cycles for per-flag vec→cube signals. Keyed by (vec_idx, flag_id).
    # wait_vec consumes one entry from each vec's queue and advances to the max.
    _vec_ready_cycles: List[List[Deque[_SyncCycleToken]]] = field(init=False)
    # Cache of most recent consumed cycle per flag, for wait_cube/wait_vec callers.
    _cube_last_wait_cycle: List[List[float]] = field(init=False)
    _cube_last_signal_cycle: List[List[float]] = field(init=False)
    _vec_last_wait_cycle: List[float] = field(init=False)
    _vec_last_signal_cycle: List[float] = field(init=False)
    _intracore_allvec_ready: List[List[int]] = field(init=False)
    _intracore_allvec_wait: List[List[int]] = field(init=False)
    _intracore_allvec_ready_cycles: List[List[List[_SyncCycleToken]]] = field(init=False)
    _intracore_allvec_last_wait_cycle: List[List[float]] = field(init=False)
    _intracore_allvec_last_signal_cycle: List[List[float]] = field(init=False)
    _cond: threading.Condition = field(default_factory=threading.Condition, init=False, repr=False)

    def __post_init__(self) -> None:
        self._vec_ready = [[0] * MAX_FLAGS_PER_LANE for _ in range(VEC_COUNT)]
        self._vec_wait = [[0] * MAX_FLAGS_PER_LANE for _ in range(VEC_COUNT)]
        self._cube_ready_cycles = [[deque() for _ in range(MAX_FLAGS_PER_LANE)] for _ in range(VEC_COUNT)]
        self._vec_ready_cycles = [[deque() for _ in range(MAX_FLAGS_PER_LANE)] for _ in range(VEC_COUNT)]
        self._cube_last_wait_cycle = [[0.0] * MAX_FLAGS_PER_LANE for _ in range(VEC_COUNT)]
        self._cube_last_signal_cycle = [[0.0] * MAX_FLAGS_PER_LANE for _ in range(VEC_COUNT)]
        self._vec_last_wait_cycle = [0.0] * MAX_FLAGS_PER_LANE
        self._vec_last_signal_cycle = [0.0] * MAX_FLAGS_PER_LANE
        self._intracore_allvec_ready = [[0] * MAX_FLAGS_PER_LANE for _ in range(VEC_COUNT)]
        self._intracore_allvec_wait = [[0] * MAX_FLAGS_PER_LANE for _ in range(VEC_COUNT)]
        self._intracore_allvec_ready_cycles = [
            [
                [_SyncCycleToken(0.0, 0.0) for _ in range(MAX_FLAG_COUNT)]
                for _ in range(MAX_FLAGS_PER_LANE)
            ]
            for _ in range(VEC_COUNT)
        ]
        self._intracore_allvec_last_wait_cycle = [[0.0] * MAX_FLAGS_PER_LANE for _ in range(VEC_COUNT)]
        self._intracore_allvec_last_signal_cycle = [[0.0] * MAX_FLAGS_PER_LANE for _ in range(VEC_COUNT)]

    @staticmethod
    def _check(flag_id: int) -> None:
        if flag_id < 0 or flag_id >= MAX_FLAGS_PER_LANE:
            raise ValueError("flag_id must be 0~7, got " + str(flag_id))

    @staticmethod
    def _check_overflow(value: int, label: str, flag_id: int) -> None:
        if value >= MAX_FLAG_COUNT:
            raise RuntimeError(label + "[" + str(flag_id) + "] overflow: " + str(value) + " >= " + str(MAX_FLAG_COUNT))

    def cube_ready(self, flag_id: int, ready_cycle: float = 0.0, visible_cycle: Optional[float] = None) -> None:
        self._check(flag_id)
        token = _SyncCycleToken(
            signal_cycle=float(ready_cycle),
            visible_cycle=float(ready_cycle if visible_cycle is None else visible_cycle),
        )
        with self._cond:
            for vi in range(VEC_COUNT):
                self._check_overflow(self._vec_wait[vi][flag_id], "vec" + str(vi) + "_wait", flag_id)
                self._vec_wait[vi][flag_id] += 1
                self._cube_ready_cycles[vi][flag_id].append(token)
            self._cond.notify_all()

    def wait_cube(self, vec_idx: int, flag_id: int, timeout: Optional[float] = None) -> bool:
        self._check(flag_id)
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            while self._vec_wait[vec_idx][flag_id] <= 0:
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._cond.wait(timeout=remaining)
            self._vec_wait[vec_idx][flag_id] -= 1
            queue = self._cube_ready_cycles[vec_idx][flag_id]
            consumed = queue.popleft() if queue else _SyncCycleToken(0.0, 0.0)
            self._cube_last_signal_cycle[vec_idx][flag_id] = consumed.signal_cycle
            self._cube_last_wait_cycle[vec_idx][flag_id] = consumed.visible_cycle
            return True

    def cube_ready_cycle(self, vec_idx: int, flag_id: int) -> float:
        """Visible cycle of the most recently consumed cube_ready signal for this vec."""
        self._check(flag_id)
        with self._cond:
            return self._cube_last_wait_cycle[vec_idx][flag_id]

    def cube_ready_signal_cycle(self, vec_idx: int, flag_id: int) -> float:
        """Signal cycle of the most recently consumed cube_ready signal for this vec."""
        self._check(flag_id)
        with self._cond:
            return self._cube_last_signal_cycle[vec_idx][flag_id]

    def vec_ready(self, vec_idx: int, flag_id: int, ready_cycle: float = 0.0, visible_cycle: Optional[float] = None) -> None:
        self._check(flag_id)
        token = _SyncCycleToken(
            signal_cycle=float(ready_cycle),
            visible_cycle=float(ready_cycle if visible_cycle is None else visible_cycle),
        )
        with self._cond:
            self._check_overflow(self._vec_ready[vec_idx][flag_id], "vec" + str(vec_idx) + "_ready", flag_id)
            self._vec_ready[vec_idx][flag_id] += 1
            self._vec_ready_cycles[vec_idx][flag_id].append(token)
            self._cond.notify_all()

    def wait_vec(self, flag_id: int, timeout: Optional[float] = None) -> bool:
        self._check(flag_id)
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            while not all(self._vec_ready[vi][flag_id] > 0 for vi in range(VEC_COUNT)):
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._cond.wait(timeout=remaining)
            max_signal_cycle = 0.0
            max_visible_cycle = 0.0
            for vi in range(VEC_COUNT):
                self._vec_ready[vi][flag_id] -= 1
                queue = self._vec_ready_cycles[vi][flag_id]
                consumed = queue.popleft() if queue else _SyncCycleToken(0.0, 0.0)
                if consumed.visible_cycle > max_visible_cycle:
                    max_visible_cycle = consumed.visible_cycle
                    max_signal_cycle = consumed.signal_cycle
            self._vec_last_signal_cycle[flag_id] = max_signal_cycle
            self._vec_last_wait_cycle[flag_id] = max_visible_cycle
            return True

    def vec_ready_cycle(self, flag_id: int) -> float:
        """Max visible cycle across the pair of vec_ready signals most recently consumed by wait_vec."""
        self._check(flag_id)
        with self._cond:
            return self._vec_last_wait_cycle[flag_id]

    def vec_ready_signal_cycle(self, flag_id: int) -> float:
        """Signal cycle paired with the visible cycle most recently consumed by wait_vec."""
        self._check(flag_id)
        with self._cond:
            return self._vec_last_signal_cycle[flag_id]

    def intracore_allvec_ready(
        self,
        vec_idx: int,
        flag_id: int,
        ready_cycle: float = 0.0,
        visible_cycle: Optional[float] = None,
    ) -> None:
        self._check(flag_id)
        token = _SyncCycleToken(
            signal_cycle=float(ready_cycle),
            visible_cycle=float(ready_cycle if visible_cycle is None else visible_cycle),
        )
        with self._cond:
            min_wait = min(self._intracore_allvec_wait[vi][flag_id] for vi in range(VEC_COUNT))
            ready_count = self._intracore_allvec_ready[vec_idx][flag_id]
            if ready_count - min_wait >= MAX_FLAG_COUNT:
                raise RuntimeError(
                    "intracore_allvec_ready[" + str(flag_id) + "] vec " + str(vec_idx)
                    + " ahead overflow: ready=" + str(ready_count)
                    + " min_wait=" + str(min_wait)
                )
            slot = ready_count % MAX_FLAG_COUNT
            self._intracore_allvec_ready_cycles[vec_idx][flag_id][slot] = token
            self._intracore_allvec_ready[vec_idx][flag_id] += 1
            self._cond.notify_all()

    def intracore_allvec_wait(self, vec_idx: int, flag_id: int, timeout: Optional[float] = None) -> bool:
        self._check(flag_id)
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            phase = self._intracore_allvec_wait[vec_idx][flag_id]
            while not all(self._intracore_allvec_ready[vi][flag_id] > phase for vi in range(VEC_COUNT)):
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._cond.wait(timeout=remaining)
                phase = self._intracore_allvec_wait[vec_idx][flag_id]
            slot = phase % MAX_FLAG_COUNT
            max_signal_cycle = 0.0
            max_visible_cycle = 0.0
            for vi in range(VEC_COUNT):
                consumed = self._intracore_allvec_ready_cycles[vi][flag_id][slot]
                if consumed.visible_cycle > max_visible_cycle:
                    max_visible_cycle = consumed.visible_cycle
                    max_signal_cycle = consumed.signal_cycle
            self._intracore_allvec_last_signal_cycle[vec_idx][flag_id] = max_signal_cycle
            self._intracore_allvec_last_wait_cycle[vec_idx][flag_id] = max_visible_cycle
            self._intracore_allvec_wait[vec_idx][flag_id] += 1
            return True

    def intracore_allvec_ready_cycle(self, vec_idx: int, flag_id: int) -> float:
        """Max visible cycle for the most recent same-core all-vec phase consumed by this vec."""
        self._check(flag_id)
        with self._cond:
            return self._intracore_allvec_last_wait_cycle[vec_idx][flag_id]

    def intracore_allvec_ready_signal_cycle(self, vec_idx: int, flag_id: int) -> float:
        """Signal cycle paired with the visible cycle consumed by intracore_allvec_wait."""
        self._check(flag_id)
        with self._cond:
            return self._intracore_allvec_last_signal_cycle[vec_idx][flag_id]


# ---------------------------------------------------------------------------
# bar_all marker — sentinel put into pipe mailboxes
#
# bar_all uses threading.Barrier (created by Core).
# parties = total pipe threads + total PipeS count.
#
# Flow:
#   1. Each PipeS sends BAR_ALL_MARKER to its own pipes' mailboxes
#   2. Each pipe thread dequeues marker → calls barrier.wait()
#   3. Each PipeS calls barrier.wait()
#   4. Barrier auto-resets when all parties arrive
# ---------------------------------------------------------------------------

BAR_ALL_MARKER = object()


class CycleBarrier:
    """Thread barrier that also propagates the max simulated arrival cycle."""

    def __init__(self, parties: int):
        if parties <= 0:
            raise ValueError("parties must be positive")
        self.parties = int(parties)
        self._cond = threading.Condition()
        self._count = 0
        self._generation = 0
        self._arrival_max = 0.0
        self._release_cycles: Dict[int, float] = {}
        self._broken = False

    def wait_cycle(self, arrival_cycle: float) -> float:
        with self._cond:
            if self._broken:
                raise threading.BrokenBarrierError
            generation = self._generation
            self._arrival_max = max(self._arrival_max, float(arrival_cycle))
            self._count += 1
            if self._count == self.parties:
                release_cycle = self._arrival_max
                self._release_cycles[generation] = release_cycle
                self._generation += 1
                self._count = 0
                self._arrival_max = 0.0
                self._cond.notify_all()
                return release_cycle
            while generation == self._generation and not self._broken:
                self._cond.wait()
            if self._broken:
                raise threading.BrokenBarrierError
            return self._release_cycles.get(generation, float(arrival_cycle))

    def wait(self, timeout: Optional[float] = None) -> float:
        return self.wait_cycle(0.0)

    def abort(self) -> None:
        with self._cond:
            self._broken = True
            self._cond.notify_all()


# ---------------------------------------------------------------------------
# CrossCoreSync — inter-core synchronization (multiprocessing)
#
# Uses multiprocessing.Array for shared counters. No Manager.
# Parent creates, passes to child Core processes as Process args.
#
# For each named sync point:
#   - allcube_* uses one participant per core
#   - allvec_* uses one participant per vec lane per core
# ---------------------------------------------------------------------------

@dataclass
class CrossCoreSync:
    """Inter-core synchronization. flag_id 0~7.

    allcube_ready(core_idx, flag_id): core signals cube ready.
    allcube_wait(core_idx, flag_id): block until all cores' cube ready > 0, consume own.
    allvec_ready / allvec_wait: same pattern for vec.

    Uses multiprocessing.Array per flag_id. No Manager.

    Cycle propagation (for simulator's cycle model): each producer stores the
    ready_cycle of its Nth call into a per-participant ring buffer at slot
    (N mod MAX_FLAG_COUNT). When a consumer's allcube_wait unblocks for phase
    P, it reads slot (P mod MAX_FLAG_COUNT) from every producer and takes the
    max — that's the cycle of the barrier round it just consumed. The result
    is cached in a per-process dict keyed by flag_id and later returned by
    `allcube_ready_cycle`. This matches producer to consumer FIFO-wise
    instead of reading the overall max across all history (which races with
    subsequent rounds from other cores).
    """

    core_count: int = 1
    _cube_ready_flags: List[Any] = field(default_factory=list, init=False, repr=False)
    _cube_wait_flags: List[Any] = field(default_factory=list, init=False, repr=False)
    _vec_ready_flags: List[Any] = field(default_factory=list, init=False, repr=False)
    _vec_wait_flags: List[Any] = field(default_factory=list, init=False, repr=False)
    _cube_ready_cycles: List[Any] = field(default_factory=list, init=False, repr=False)
    _vec_ready_cycles: List[Any] = field(default_factory=list, init=False, repr=False)
    _startup_ready_flags: Any = field(default=None, init=False, repr=False)
    _lock: Any = field(default=None, init=False, repr=False)
    _cond: Any = field(default=None, init=False, repr=False)
    # Per-process caches: the most recent cycle returned by allcube_wait /
    # allvec_wait on this process, keyed by flag_id. Not shared — each core
    # writes to its own copy in its own allcube_wait call, then reads back in
    # allcube_ready_cycle.
    _last_cube_cycle: Dict[int, float] = field(default_factory=dict, init=False, repr=False)
    _last_vec_cycle: Dict[int, float] = field(default_factory=dict, init=False, repr=False)

    def prepare(self) -> None:
        self._lock = multiprocessing.Lock()
        self._cond = multiprocessing.Condition(self._lock)
        self._cube_ready_flags = [multiprocessing.Array("i", self.core_count) for _ in range(MAX_FLAGS_PER_LANE)]
        self._cube_wait_flags = [multiprocessing.Array("i", self.core_count) for _ in range(MAX_FLAGS_PER_LANE)]
        vec_parties = self.core_count * VEC_COUNT
        self._vec_ready_flags = [multiprocessing.Array("i", vec_parties) for _ in range(MAX_FLAGS_PER_LANE)]
        self._vec_wait_flags = [multiprocessing.Array("i", vec_parties) for _ in range(MAX_FLAGS_PER_LANE)]
        # Ring-buffered cycles: RING_SIZE = MAX_FLAG_COUNT per participant.
        self._cube_ready_cycles = [
            multiprocessing.Array("q", self.core_count * MAX_FLAG_COUNT)
            for _ in range(MAX_FLAGS_PER_LANE)
        ]
        self._vec_ready_cycles = [
            multiprocessing.Array("q", vec_parties * MAX_FLAG_COUNT)
            for _ in range(MAX_FLAGS_PER_LANE)
        ]
        self._startup_ready_flags = multiprocessing.Array("i", self.core_count)

    def startup_wait(self, core_idx: int, timeout: Optional[float] = None) -> bool:
        """One-shot barrier used after per-core local memory initialization."""
        if self.core_count <= 1 or self._startup_ready_flags is None:
            return True
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            self._startup_ready_flags[core_idx] = 1
            self._cond.notify_all()
            while not all(self._startup_ready_flags[i] > 0 for i in range(self.core_count)):
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._cond.wait(timeout=remaining)
            return True

    def allcube_ready(self, core_idx: int, flag_id: int, ready_cycle: float = 0.0) -> None:
        arr = self._cube_ready_flags[flag_id]
        wait = self._cube_wait_flags[flag_id]
        cycles = self._cube_ready_cycles[flag_id] if self._cube_ready_cycles else None
        with self._cond:
            min_wait = min(wait[i] for i in range(self.core_count))
            if arr[core_idx] - min_wait >= MAX_FLAG_COUNT:
                raise RuntimeError(
                    "allcube_ready[" + str(flag_id) + "] core " + str(core_idx)
                    + " ahead overflow: ready=" + str(arr[core_idx])
                    + " min_wait=" + str(min_wait)
                )
            if cycles is not None:
                slot = arr[core_idx] % MAX_FLAG_COUNT
                cycles[core_idx * MAX_FLAG_COUNT + slot] = int(ready_cycle)
            arr[core_idx] += 1
            self._cond.notify_all()

    def allcube_wait(self, core_idx: int, flag_id: int, timeout: Optional[float] = None) -> bool:
        ready = self._cube_ready_flags[flag_id]
        wait = self._cube_wait_flags[flag_id]
        cycles = self._cube_ready_cycles[flag_id] if self._cube_ready_cycles else None
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            while True:
                phase = wait[core_idx]
                if all(ready[i] > phase for i in range(self.core_count)):
                    max_cycle = 0
                    if cycles is not None:
                        slot = phase % MAX_FLAG_COUNT
                        for i in range(self.core_count):
                            c = cycles[i * MAX_FLAG_COUNT + slot]
                            if c > max_cycle:
                                max_cycle = c
                    self._last_cube_cycle[flag_id] = float(max_cycle)
                    wait[core_idx] += 1
                    self._cond.notify_all()
                    return True
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._cond.wait(timeout=remaining)

    def allcube_ready_cycle(self, flag_id: int) -> float:
        return float(self._last_cube_cycle.get(flag_id, 0.0))

    def _vec_participant_idx(self, core_idx: int, vec_idx: int) -> int:
        return core_idx * VEC_COUNT + vec_idx

    def allvec_ready(self, core_idx: int, vec_idx: int, flag_id: int, ready_cycle: float = 0.0) -> None:
        arr = self._vec_ready_flags[flag_id]
        wait = self._vec_wait_flags[flag_id]
        cycles = self._vec_ready_cycles[flag_id] if self._vec_ready_cycles else None
        participant_idx = self._vec_participant_idx(core_idx, vec_idx)
        vec_parties = self.core_count * VEC_COUNT
        with self._cond:
            min_wait = min(wait[i] for i in range(vec_parties))
            if arr[participant_idx] - min_wait >= MAX_FLAG_COUNT:
                raise RuntimeError(
                    "allvec_ready[" + str(flag_id) + "] participant " + str(participant_idx)
                    + " ahead overflow: ready=" + str(arr[participant_idx])
                    + " min_wait=" + str(min_wait)
                )
            if cycles is not None:
                slot = arr[participant_idx] % MAX_FLAG_COUNT
                cycles[participant_idx * MAX_FLAG_COUNT + slot] = int(ready_cycle)
            arr[participant_idx] += 1
            self._cond.notify_all()

    def allvec_wait(self, core_idx: int, vec_idx: int, flag_id: int, timeout: Optional[float] = None) -> bool:
        ready = self._vec_ready_flags[flag_id]
        wait = self._vec_wait_flags[flag_id]
        cycles = self._vec_ready_cycles[flag_id] if self._vec_ready_cycles else None
        participant_idx = self._vec_participant_idx(core_idx, vec_idx)
        vec_parties = self.core_count * VEC_COUNT
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            while True:
                phase = wait[participant_idx]
                if all(ready[i] > phase for i in range(vec_parties)):
                    max_cycle = 0
                    if cycles is not None:
                        slot = phase % MAX_FLAG_COUNT
                        for i in range(vec_parties):
                            c = cycles[i * MAX_FLAG_COUNT + slot]
                            if c > max_cycle:
                                max_cycle = c
                    self._last_vec_cycle[flag_id] = float(max_cycle)
                    wait[participant_idx] += 1
                    self._cond.notify_all()
                    return True
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._cond.wait(timeout=remaining)

    def allvec_ready_cycle(self, flag_id: int) -> float:
        return float(self._last_vec_cycle.get(flag_id, 0.0))

    def snapshot(self) -> Dict[str, Any]:
        return {
            "core_count": self.core_count,
            "cube_ready_flags": self._cube_ready_flags,
            "cube_wait_flags": self._cube_wait_flags,
            "vec_ready_flags": self._vec_ready_flags,
            "vec_wait_flags": self._vec_wait_flags,
            "cube_ready_cycles": self._cube_ready_cycles,
            "vec_ready_cycles": self._vec_ready_cycles,
            "startup_ready_flags": self._startup_ready_flags,
            "lock": self._lock,
            "cond": self._cond,
        }

    def load_snapshot(self, snap: Dict[str, Any]) -> None:
        self.core_count = snap["core_count"]
        self._cube_ready_flags = snap.get("cube_ready_flags", [])
        self._cube_wait_flags = snap.get("cube_wait_flags", [])
        self._vec_ready_flags = snap.get("vec_ready_flags", [])
        self._vec_wait_flags = snap.get("vec_wait_flags", [])
        self._cube_ready_cycles = snap.get("cube_ready_cycles", [])
        self._vec_ready_cycles = snap.get("vec_ready_cycles", [])
        self._startup_ready_flags = snap.get("startup_ready_flags", None)
        self._lock = snap["lock"]
        # Required like _lock: the Condition is shared across core processes via
        # the snapshot. Rebuilding it locally would yield a per-process object
        # whose notify never crosses processes, silently deadlocking barriers.
        self._cond = snap["cond"]


# ---------------------------------------------------------------------------
# LocalSync — low-level flag table: {(src_pipe, dst_pipe, flag_id): bool}
#
# set(): flag False→True. Error if already True.
# wait(): block until True, then True→False.
# ---------------------------------------------------------------------------

@dataclass
class LocalSync:
    _flags: Dict[Tuple[str, str, int], bool] = field(default_factory=dict)
    _flag_cycles: Dict[Tuple[str, str, int], float] = field(default_factory=dict)
    _cond: threading.Condition = field(default_factory=threading.Condition, init=False, repr=False)
    _aborted: Optional[str] = field(default=None, init=False, repr=False)

    def abort(self, reason: str) -> None:
        """Wake every waiter; further waits raise immediately (failed peer pipe)."""
        with self._cond:
            if self._aborted is None:
                self._aborted = str(reason) or "aborted"
            self._cond.notify_all()

    def set(self, src_pipe: str, dst_pipe: str, flag_id: int, ready_cycle: float = 0.0) -> None:
        key = (src_pipe, dst_pipe, flag_id)
        with self._cond:
            if self._flags.get(key, False):
                raise RuntimeError(
                    "set on already-set flag: src=" + src_pipe
                    + " dst=" + dst_pipe + " flag_id=" + str(flag_id)
                )
            self._flags[key] = True
            prev = self._flag_cycles.get(key, 0.0)
            if ready_cycle > prev:
                self._flag_cycles[key] = ready_cycle
            self._cond.notify_all()

    def wait(self, src_pipe: str, dst_pipe: str, flag_id: int, timeout: Optional[float] = None) -> bool:
        key = (src_pipe, dst_pipe, flag_id)
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            while not self._flags.get(key, False):
                if self._aborted is not None:
                    raise RuntimeError("local sync aborted: " + self._aborted)
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._cond.wait(timeout=remaining)
            self._flags[key] = False
            return True

    def ready_cycle(self, src_pipe: str, dst_pipe: str, flag_id: int) -> float:
        with self._cond:
            return self._flag_cycles.get((src_pipe, dst_pipe, flag_id), 0.0)


# ---------------------------------------------------------------------------
# LocalEventBank — s-event / d-event / t-event / q-event on LocalSync
#
# s-event: 1 flag_id.  set→wait→set→wait round-robin on 1 slot.
# d-event: 2 flag_ids. set→set can overlap with wait→wait (double-buffered).
# t-event: 3 flag_ids. Three producer results may be outstanding in FIFO order.
# q-event: 4 flag_ids. Four producer results may be outstanding in FIFO order.
# preset=True: initializes every slot at creation time.
# ---------------------------------------------------------------------------

@dataclass
class LocalEventDescriptor:
    name: str
    event_kind: str       # "s", "d", "t", or "q"
    src_pipe: str
    dst_pipe: str
    flag_ids: Tuple[int, ...]
    set_count: int = 0
    wait_count: int = 0
    last_wait_cycle: float = 0.0


@dataclass
class LocalEventBank:
    sync: LocalSync = field(default_factory=LocalSync)
    descriptors: Dict[str, LocalEventDescriptor] = field(default_factory=dict)
    _next_flag_id: Dict[Tuple[str, str], int] = field(default_factory=dict)
    context: str = ""

    def create_event(
        self, name: str, event_kind: str, src_pipe: str, dst_pipe: str, preset: bool = False,
    ) -> LocalEventDescriptor:
        if event_kind not in ("s", "d", "t", "q"):
            raise ValueError("event_kind must be 's', 'd', 't', or 'q'")
        existing = self.descriptors.get(name)
        if existing is not None:
            return existing
        pair = (src_pipe, dst_pipe)
        width = {"s": 1, "d": 2, "t": 3, "q": 4}[event_kind]
        base = self._next_flag_id.get(pair, 0)
        if base + width > MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR:
            event_type = {"s": "SEvent", "d": "DEvent", "t": "TEvent", "q": "QEvent"}[event_kind]
            context = " in " + self.context if self.context else ""
            raise RuntimeError(
                "simulator local event ID budget exceeded{} for ordered pipe pair "
                "{}->{}: {}/{} IDs are already allocated; {} {!r} requires {} more "
                "(SEvent=1, DEvent=2, TEvent=3, QEvent=4)".format(
                    context,
                    src_pipe,
                    dst_pipe,
                    base,
                    MAX_LOCAL_EVENT_IDS_PER_PIPE_PAIR,
                    event_type,
                    name,
                    width,
                )
            )
        flag_ids = tuple(range(base, base + width))
        self._next_flag_id[pair] = base + width
        desc = LocalEventDescriptor(
            name=name, event_kind=event_kind,
            src_pipe=src_pipe, dst_pipe=dst_pipe,
            flag_ids=flag_ids,
        )
        self.descriptors[name] = desc
        if preset:
            for _ in range(width):
                self._do_set(desc)
        return desc

    def abort(self, reason: str) -> None:
        self.sync.abort(reason)

    def set_event(self, name: str, set_all: bool = False, ready_cycle: float = 0.0) -> None:
        desc = self.descriptors[name]
        count = len(desc.flag_ids) if set_all else 1
        for _ in range(count):
            self._do_set(desc, ready_cycle)

    def wait_event(self, name: str, timeout: Optional[float] = None) -> bool:
        desc = self.descriptors[name]
        return self._do_wait(desc, timeout) is not None

    def release_event(self, name: str, timeout: Optional[float] = None) -> bool:
        """Wait for and consume every slot owned by the event."""
        desc = self.descriptors[name]
        max_cycle = 0.0
        for i in range(len(desc.flag_ids)):
            remaining = None
            if timeout is not None:
                remaining = max(timeout, 0.0)
                start = time.monotonic()
            cycle = self._do_wait(desc, remaining)
            if cycle is None:
                return False
            if cycle > max_cycle:
                max_cycle = cycle
            desc.last_wait_cycle = max_cycle
            if timeout is not None:
                timeout -= (time.monotonic() - start)
        return True

    def ready_cycle(self, name: str) -> float:
        """Return the cycle of the most recently consumed slot for this event."""
        desc = self.descriptors.get(name)
        if desc is None:
            return 0.0
        return float(getattr(desc, "last_wait_cycle", 0.0))

    def _do_set(self, desc: LocalEventDescriptor, ready_cycle: float = 0.0) -> None:
        slot = desc.set_count % len(desc.flag_ids)
        fid = desc.flag_ids[slot]
        self.sync.set(desc.src_pipe, desc.dst_pipe, fid, ready_cycle=ready_cycle)
        desc.set_count += 1

    def _do_wait(self, desc: LocalEventDescriptor, timeout: Optional[float] = None) -> Optional[float]:
        """Wait for the next slot in FIFO order.

        Returns the consumed slot's ready_cycle on success, None on timeout.
        """
        slot = desc.wait_count % len(desc.flag_ids)
        fid = desc.flag_ids[slot]
        if not self.sync.wait(desc.src_pipe, desc.dst_pipe, fid, timeout=timeout):
            return None
        cycle = self.sync.ready_cycle(desc.src_pipe, desc.dst_pipe, fid)
        desc.wait_count += 1
        desc.last_wait_cycle = cycle
        return cycle


# ---------------------------------------------------------------------------
# Mailbox — pipe task delivery queue (threading)
# ---------------------------------------------------------------------------

_STOP = "stop"


@dataclass
class Mailbox:
    maxsize: int = 0
    _queue: Queue = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._queue = Queue(maxsize=self.maxsize)

    def put(self, item: Union[PipeTask, object]) -> None:
        self._queue.put(item)

    def put_stop(self) -> None:
        self._queue.put(_STOP)

    def get(self, block: bool = False, timeout: Optional[float] = None) -> Optional[Any]:
        try:
            return self._queue.get(block=block, timeout=timeout) if timeout else self._queue.get(block=block)
        except Empty:
            return None

    def snapshot_items(self, limit: Optional[int] = None) -> List[Any]:
        with self._queue.mutex:
            items = list(self._queue.queue)
        if limit is not None:
            return items[:limit]
        return items
