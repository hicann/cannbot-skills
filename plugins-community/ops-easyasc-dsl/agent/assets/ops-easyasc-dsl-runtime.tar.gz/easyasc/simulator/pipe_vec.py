from __future__ import annotations

from itertools import product
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import torch

from .. import globvars
from ..device_profile import is_c220_family
from .pipe import PipeBase
from .program import PipeTask
from .cast_rounding import apply_cast_dtype
from .util import (
    align16, align_to, encode_nd_to_nz, decode_nz_to_nd,
    nz_tail_write_footprint, require_burst_bytes, require_flat_elements,
    require_same_dtype, require_32b_aligned, require_byte_aligned,
    require_strided_2d_elements,
)


def _int(value: Any, label: str) -> int:
    if isinstance(value, bool):
        return int(value)
    if not isinstance(value, (int, float)):
        raise TypeError(label + ": expected number, got " + str(type(value)))
    return int(value)


def _check_repeat_bound(repeat: int, op: str) -> None:
    # AscendC vector repeatTimes is a uint8: a repeat above 255 silently wraps on
    # real hardware. The simulator iterates the full int repeat, so without this
    # guard it would happily run a count the device cannot execute -- a
    # sim-passes / HW-wrong divergence. Callers pass the (canonical) op name.
    if repeat > 255:
        raise ValueError(
            op + ": repeat exceeds the uint8 hardware limit (repeatTimes max 255), got " + str(repeat))


def _strided_touch(mask: torch.Tensor, repeat: int, rep_stride: int, blk_stride: int, epb: int) -> int:
    """Highest element a standard 8-block strided vec access actually addresses, counting
    only mask-active lanes. Returns the required element count (highest index + 1) so a
    caller can compare it against the addressed tensor's *logical* size and catch an
    overrun into the neighbouring UB tensor.

    Why mask-aware: a predicated op (the `_masked_write` family) touches nothing in a
    disabled lane, so a narrow SetVectorMask over a tight buffer is legal and must not
    trip. Within one repeat, block b lane l maps to element b*blk_stride*epb + l and is
    live iff mask[b*epb + l]; the last repeat sits (repeat-1)*rep_stride*epb above it.
    A zero repeat or an all-disabled mask touches nothing."""
    if repeat <= 0:
        return 0
    m = mask[:8 * epb].bool().view(8, epb)
    idx = torch.nonzero(m, as_tuple=False)
    if idx.numel() == 0:
        return 0
    hi = int((idx[:, 0] * (blk_stride * epb) + idx[:, 1]).max().item())
    return (repeat - 1) * rep_stride * epb + hi + 1


def _block_touch(repeat: int, rep_stride: int, blk_stride: int, epb: int) -> int:
    """Highest element an UNpredicated whole-block access addresses. cast/cpadd/brcb write
    the full 32B block regardless of mask, so a disabled lane is still physically written
    -- use the conservative all-8-block span rather than the mask-active one."""
    if repeat <= 0:
        return 0
    return (repeat - 1) * rep_stride * epb + 7 * blk_stride * epb + epb


def _align32(v: int) -> int:
    return ((v + 31) // 32) * 32


def _validate_c220_datacopy_pad_n_burst(n_burst: int, opname: str) -> None:
    if is_c220_family(globvars.device_type) and not 0 <= n_burst <= 4095:
        raise ValueError(f"{opname} on C220 requires n_burst in [0, 4095], got {n_burst}")


def _linear_view(tensor: torch.Tensor) -> torch.Tensor:
    elem = int(tensor.element_size())
    storage_elems = int(tensor.untyped_storage().nbytes()) // elem
    avail = storage_elems - int(tensor.storage_offset())
    return tensor.as_strided((avail,), (1,), storage_offset=int(tensor.storage_offset()))


def _tensor_storage_addr(tensor: torch.Tensor) -> Tuple[int, int]:
    return (
        int(tensor.untyped_storage().data_ptr()),
        int(tensor.storage_offset()) * int(tensor.element_size()),
    )



def _require_ub_32b_aligned(op: str, role: str, name: str, tensor: torch.Tensor) -> None:
    require_32b_aligned(op, role, name, tensor)


def _compute_dtype(dt: torch.dtype) -> torch.dtype:
    if dt in (torch.float16, torch.bfloat16):
        return torch.float32
    return dt


def _signed_view_dtype(dt: torch.dtype) -> Optional[torch.dtype]:
    if hasattr(torch, "uint16") and dt == getattr(torch, "uint16"):
        return torch.int16
    if hasattr(torch, "uint32") and dt == getattr(torch, "uint32"):
        return torch.int32
    if hasattr(torch, "uint64") and dt == getattr(torch, "uint64"):
        return torch.int64
    return None


def _masked_blend(mask: torch.Tensor, on_true: torch.Tensor, on_false: torch.Tensor) -> torch.Tensor:
    signed_view = _signed_view_dtype(on_true.dtype)
    if signed_view is not None:
        blended = torch.where(mask, on_true.view(signed_view), on_false.view(signed_view))
        return blended.view(on_true.dtype)
    return torch.where(mask, on_true, on_false)


def _bitwise_not_with_fallback(src: torch.Tensor) -> torch.Tensor:
    if src.dtype == torch.uint8:
        return torch.bitwise_not(src.to(torch.int8)).to(torch.uint8)
    if hasattr(torch, "uint16") and src.dtype == getattr(torch, "uint16"):
        return torch.bitwise_not(src.to(torch.int16)).to(src.dtype)
    if hasattr(torch, "uint32") and src.dtype == getattr(torch, "uint32"):
        return torch.bitwise_not(src.to(torch.int32)).to(src.dtype)
    if src.dtype.is_floating_point:
        elem = int(src.element_size())
        if elem == 2:
            int_dt = torch.int16
        elif elem == 4:
            int_dt = torch.int32
        elif elem == 8:
            int_dt = torch.int64
        else:
            int_dt = torch.int8
        return torch.bitwise_not(src.view(int_dt)).view(src.dtype)
    return torch.bitwise_not(src)


def _pack_bits_lsb_first(bool_vec: torch.Tensor, num_bytes: int) -> torch.Tensor:
    packed = torch.zeros(num_bytes, dtype=torch.uint8)
    bits = bool_vec.to(torch.uint8).reshape(-1)
    n = int(bits.numel())
    for i in range(n):
        if bool(bits[i].item()):
            byte_idx = i // 8
            bit_idx = i % 8
            packed[byte_idx] = packed[byte_idx] | (1 << bit_idx)
    return packed


def _unpack_bits_lsb_first(byte_vec: torch.Tensor, num_bits: int) -> torch.Tensor:
    out = torch.zeros(num_bits, dtype=torch.bool)
    flat = byte_vec.reshape(-1)
    for i in range(num_bits):
        byte_idx = i // 8
        bit_idx = i % 8
        out[i] = bool(((int(flat[byte_idx].item()) >> bit_idx) & 1) == 1)
    return out


def _choose_atomic_compute_dtype(dt: torch.dtype) -> torch.dtype:
    if dt in (torch.float16, torch.bfloat16):
        return torch.float32
    if dt in (torch.int8, torch.uint8, torch.int16):
        return torch.int32
    return dt


def _bitwise_binary(op: str, a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """vand/vor helper: if the tensors have FP dtype (e.g., from a reinterpret
    that wasn't routed through the memory-view path), bit-reinterpret them into
    a same-width integer, apply the bitwise op, and view back as the original
    dtype. Matches what hardware does on raw bits regardless of DSL dtype."""
    fn = torch.bitwise_and if op == "vand" else torch.bitwise_or
    signed_view = _signed_view_dtype(a.dtype)
    if signed_view is not None:
        return fn(a.view(signed_view), b.view(signed_view)).view(a.dtype)
    if a.dtype.is_floating_point or b.dtype.is_floating_point:
        # Choose the matching integer dtype by element size
        elem = int(a.element_size())
        if elem == 2:
            int_dt = torch.int16
        elif elem == 4:
            int_dt = torch.int32
        elif elem == 8:
            int_dt = torch.int64
        else:
            int_dt = torch.int8
        return fn(a.view(int_dt), b.view(int_dt)).view(a.dtype)
    return fn(a, b)


def _shift_scalar_bits(op: str, src: torch.Tensor, shift: int, round_en: bool = False) -> torch.Tensor:
    """Model A2 ShiftLeft/ShiftRight on 16-bit and 32-bit integer tensors."""
    bits = int(src.element_size()) * 8
    if shift < 0 or shift > bits:
        raise ValueError(f"{op}: shift must be in [0, {bits}], got {shift}")

    bit_mask = (1 << bits) - 1
    sign_mask = 1 << (bits - 1)
    raw = torch.bitwise_and(src.to(torch.int64), bit_mask)
    is_unsigned = _signed_view_dtype(src.dtype) is not None

    if op == "shiftls":
        result = torch.bitwise_and(torch.bitwise_left_shift(raw, shift), bit_mask)
        if not is_unsigned:
            # Real A2 uses the full fixed-width bit pattern for signed left
            # shift as well; overflow can therefore change the sign bit.
            result = torch.where(result >= sign_mask, result - (1 << bits), result)
        return result.to(src.dtype)

    if is_unsigned:
        return torch.bitwise_right_shift(raw, shift).to(src.dtype)

    result = torch.bitwise_right_shift(src.to(torch.int64), shift)
    if round_en and shift > 0:
        round_bit = torch.bitwise_and(torch.bitwise_right_shift(src.to(torch.int64), shift - 1), 1)
        result = result + round_bit
    return result.to(src.dtype)


# ---------------------------------------------------------------------------
# VecMTE2 — GM → UB (byte-level burst copy with stride/padding)
# ---------------------------------------------------------------------------

@dataclass
class VecMTE2Pipe(PipeBase):

    def execute(self, task: PipeTask) -> None:
        if task.opname == "gm_to_ub_pad":
            self._gm_to_ub_pad(task)
        elif task.opname == "gm_to_ub_nd_dma":
            self._gm_to_ub_nd_dma(task)
        else:
            raise NotImplementedError("VecMTE2 unhandled op: " + task.opname)

    def _gm_to_ub_pad(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("gm_to_ub_pad", dst_tensor, src_tensor)
        require_32b_aligned("gm_to_ub_pad", "dst", dst_name, dst_tensor)
        dst = _linear_view(dst_tensor)
        src = _linear_view(src_tensor)
        n_burst = _int(a["n_burst"], "n_burst")
        burst_len = _int(a["burst_len_byte"], "burst_len_byte")
        src_stride_raw = _int(a["src_stride_byte"], "src_stride_byte")
        dst_stride_raw = _int(a["dst_stride"], "dst_stride")

        if n_burst < 0 or burst_len < 0 or src_stride_raw < 0 or dst_stride_raw < 0:
            raise ValueError(
                "gm_to_ub_pad requires non-negative n_burst, burst_len_byte, src_stride_byte, and dst_stride"
            )
        _validate_c220_datacopy_pad_n_burst(n_burst, "gm_to_ub_pad")
        if n_burst == 0 or burst_len == 0:
            return

        src_stride = src_stride_raw
        dst_stride = dst_stride_raw * 32

        aligned_burst = _align32(burst_len)
        src_step = burst_len + src_stride
        dst_step = aligned_burst + dst_stride

        src_bytes = src.view(torch.uint8)
        dst_bytes = dst.view(torch.uint8)
        require_burst_bytes("gm_to_ub_pad", "src", src_name, src_bytes, n_burst, src_step, burst_len)
        require_burst_bytes("gm_to_ub_pad", "dst", dst_name, dst_bytes, n_burst, dst_step, aligned_burst)
        for i in range(n_burst):
            sb = i * src_step
            db = i * dst_step
            dst_bytes[db:db + burst_len].copy_(src_bytes[sb:sb + burst_len])
            if aligned_burst > burst_len:
                # ``GM2UBPAD`` passes ``isPad=false``, so the transfer moves
                # whole 32-byte blocks and the bytes past ``burst_len`` inside
                # the last one hold what that block carried in memory, not
                # zeros.  Modelling them as zeros hides an entire class of
                # board-only defect: a kernel that stages a zero band right
                # after a row whose width is not a multiple of C0 reads the
                # dirt instead of its zeros, and only for those shapes.
                tail = aligned_burst - burst_len
                have = max(0, min(tail, int(src_bytes.numel()) - sb - burst_len))
                if have:
                    dst_bytes[db + burst_len:db + burst_len + have].copy_(
                        src_bytes[sb + burst_len:sb + burst_len + have])
                if have < tail:
                    dst_bytes[db + burst_len + have:db + aligned_burst].fill_(0x7F)

    def _gm_to_ub_nd_dma(self, task: PipeTask) -> None:
        from easyasc import globvars

        if is_c220_family(getattr(globvars, "device_type", "")):
            raise RuntimeError("gm_to_ub_nd_dma is only supported on device_type=950")

        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("gm_to_ub_nd_dma", dst_tensor, src_tensor)
        require_32b_aligned("gm_to_ub_nd_dma", "dst", dst_name, dst_tensor)

        dim = _int(a.get("dim", 0), "dim")
        if dim < 1 or dim > 5:
            raise ValueError("gm_to_ub_nd_dma requires 1 <= dim <= 5")

        def _seq(name: str, default: Optional[Tuple[int, ...]] = None) -> Tuple[int, ...]:
            raw = a.get(name, default)
            if raw is None:
                raise ValueError(f"gm_to_ub_nd_dma missing required field {name}")
            seq = tuple(_int(value, f"{name}[{idx}]") for idx, value in enumerate(raw))
            if len(seq) != dim:
                raise ValueError(f"gm_to_ub_nd_dma field {name} must have length {dim}, got {len(seq)}")
            return seq

        loop_src_stride = _seq("loop_src_stride")
        loop_dst_stride = _seq("loop_dst_stride")
        loop_size = _seq("loop_size")
        loop_left_pad = _seq("loop_left_pad", tuple(0 for _ in range(dim)))
        loop_right_pad = _seq("loop_right_pad", tuple(0 for _ in range(dim)))
        nearest_value_mode = bool(a.get("nearest_value_mode", False))
        config_left_pad = a.get("config_left_pad", None)
        config_right_pad = a.get("config_right_pad", None)
        asc_optimize = bool(a.get("asc_optimize", False))

        if asc_optimize:
            raise NotImplementedError("gm_to_ub_nd_dma asc_optimize=True is not supported in the simulator")
        if any(value < 0 for value in loop_src_stride + loop_dst_stride + loop_size + loop_left_pad + loop_right_pad):
            raise ValueError("gm_to_ub_nd_dma requires non-negative strides, sizes, and padding")

        config_left_pad_int = None if config_left_pad is None else _int(config_left_pad, "config_left_pad")
        config_right_pad_int = None if config_right_pad is None else _int(config_right_pad, "config_right_pad")
        if config_left_pad_int is not None and not 0 <= config_left_pad_int <= 255:
            raise ValueError("gm_to_ub_nd_dma requires 0 <= config_left_pad <= 255")
        if config_right_pad_int is not None and not 0 <= config_right_pad_int <= 255:
            raise ValueError("gm_to_ub_nd_dma requires 0 <= config_right_pad <= 255")

        effective_left_pad = tuple(
            config_left_pad_int if config_left_pad_int is not None else value
            for value in loop_left_pad
        )
        effective_right_pad = tuple(
            config_right_pad_int if config_right_pad_int is not None else value
            for value in loop_right_pad
        )
        total_sizes = tuple(loop_size[idx] + effective_left_pad[idx] + effective_right_pad[idx] for idx in range(dim))
        if any(size < 0 for size in total_sizes):
            raise ValueError("gm_to_ub_nd_dma requires non-negative total loop extents")

        if dst_tensor.element_size() == 8 and nearest_value_mode:
            raise ValueError("gm_to_ub_nd_dma b64 path requires nearest_value_mode=False")
        constant_value = a.get("constant_value", 0)
        if dst_tensor.element_size() == 8 and constant_value not in (0, 0.0):
            raise ValueError("gm_to_ub_nd_dma b64 path requires constant_value=0")

        dst = _linear_view(dst_tensor)
        src = _linear_view(src_tensor)
        pad_value = torch.tensor(constant_value, dtype=dst.dtype).reshape(())

        for rev_index in product(*(range(size) for size in reversed(total_sizes))):
            index = tuple(reversed(rev_index))
            dst_offset = sum(index[idx] * loop_dst_stride[idx] for idx in range(dim))
            if dst_offset < 0 or dst_offset >= dst.numel():
                raise RuntimeError(
                    "gm_to_ub_nd_dma dst element footprint exceeds allocated storage: "
                    f"offset={dst_offset}, storage={dst.numel()}"
                )

            src_index: List[int] = []
            src_valid = True
            for idx in range(dim):
                logical = index[idx] - effective_left_pad[idx]
                if logical < 0:
                    if nearest_value_mode:
                        src_index.append(0)
                    else:
                        src_valid = False
                        break
                elif logical >= loop_size[idx]:
                    if nearest_value_mode:
                        src_index.append(loop_size[idx] - 1)
                    else:
                        src_valid = False
                        break
                else:
                    src_index.append(logical)

            if src_valid:
                src_offset = sum(src_index[idx] * loop_src_stride[idx] for idx in range(dim))
                if src_offset < 0 or src_offset >= src.numel():
                    raise RuntimeError(
                        "gm_to_ub_nd_dma src element footprint exceeds allocated storage: "
                        f"offset={src_offset}, storage={src.numel()}"
                    )
                dst[dst_offset].copy_(src[src_offset])
            else:
                dst[dst_offset].copy_(pad_value)


# ---------------------------------------------------------------------------
# MTE3 — UB → GM / UB → L1
# ---------------------------------------------------------------------------

@dataclass
class MTE3Pipe(PipeBase):

    def execute(self, task: PipeTask) -> None:
        if task.opname == "ub_to_gm_pad":
            self._ub_to_gm_pad(task)
        elif task.opname == "ub_to_l1":
            self._ub_to_l1(task)
        elif task.opname == "ub_to_l1_nd2nz":
            self._ub_to_l1_nd2nz(task)
        elif task.opname == "ub_to_l1_nz":
            self._ub_to_l1_nz(task)
        else:
            raise NotImplementedError("MTE3 unhandled op: " + task.opname)

    def _ub_to_gm_pad(self, task: PipeTask) -> None:
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("ub_to_gm_pad", dst_tensor, src_tensor)
        require_32b_aligned("ub_to_gm_pad", "src", src_name, src_tensor)
        dst = _linear_view(dst_tensor)
        src = _linear_view(src_tensor)
        n_burst = _int(a["n_burst"], "n_burst")
        burst_len = _int(a["burst_len_byte"], "burst_len_byte")
        dst_stride_raw = _int(a["dst_stride_byte"], "dst_stride_byte")
        src_stride_raw = _int(a["src_stride"], "src_stride")

        atomic_mode = str(a.get("_atomic", ""))
        if atomic_mode.startswith("atomic_"):
            atomic_mode = atomic_mode[len("atomic_"):]
        if not atomic_mode and bool(a.get("atomic_enabled", False)):
            atomic_mode = str(a.get("atomic_mode", "add") or "add")

        if n_burst < 0 or burst_len < 0 or dst_stride_raw < 0 or src_stride_raw < 0:
            raise ValueError(
                "ub_to_gm_pad requires non-negative n_burst, burst_len_byte, dst_stride_byte, and src_stride"
            )
        _validate_c220_datacopy_pad_n_burst(n_burst, "ub_to_gm_pad")
        if n_burst == 0 or burst_len == 0:
            return

        dst_stride = dst_stride_raw
        src_stride = src_stride_raw * 32

        aligned_burst = _align32(burst_len)
        src_step = aligned_burst + src_stride
        dst_step = burst_len + dst_stride
        require_burst_bytes("ub_to_gm_pad", "src", src_name, src, n_burst, src_step, burst_len)
        require_burst_bytes("ub_to_gm_pad", "dst", dst_name, dst, n_burst, dst_step, burst_len)

        if atomic_mode in ("add", "max", "min"):
            elem_size = int(dst.element_size())
            burst_elems = burst_len // elem_size
            s_step_e = (aligned_burst + src_stride) // elem_size
            d_step_e = (burst_len + dst_stride) // elem_size
            compute_dtype = _choose_atomic_compute_dtype(dst.dtype)
            with self.memory_store.atomic_lock():
                for i in range(n_burst):
                    dst_slice = dst[i * d_step_e : i * d_step_e + burst_elems]
                    src_slice = src[i * s_step_e : i * s_step_e + burst_elems]
                    dst_compute = dst_slice.to(compute_dtype)
                    src_compute = src_slice.to(compute_dtype)
                    if atomic_mode == "add":
                        dst_compute = dst_compute + src_compute
                    elif atomic_mode == "max":
                        dst_compute = torch.maximum(dst_compute, src_compute)
                    else:
                        dst_compute = torch.minimum(dst_compute, src_compute)
                    dst_slice.copy_(dst_compute.to(dst.dtype))
        else:
            src_bytes = src.view(torch.uint8)
            dst_bytes = dst.view(torch.uint8)
            for i in range(n_burst):
                sb = i * src_step
                db = i * dst_step
                dst_bytes[db:db + burst_len].copy_(src_bytes[sb:sb + burst_len])

    def _ub_to_l1(self, task: PipeTask) -> None:
        from easyasc import globvars
        if is_c220_family(getattr(globvars, "device_type", "")):
            raise RuntimeError("ub_to_l1 not supported on C220 device")
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_same_dtype("ub_to_l1", dst_tensor, src_tensor)
        require_32b_aligned("ub_to_l1", "dst", dst_name, dst_tensor)
        require_32b_aligned("ub_to_l1", "src", src_name, src_tensor)
        dst = _linear_view(dst_tensor).view(torch.uint8)
        src = _linear_view(src_tensor).view(torch.uint8)
        n_burst = _int(a["n_burst"], "n_burst")
        burst_len = _int(a["burst_len"], "burst_len")
        src_stride = _int(a["src_stride"], "src_stride")
        dst_stride = _int(a["dst_stride"], "dst_stride")

        if n_burst < 0 or burst_len < 0 or src_stride < 0 or dst_stride < 0:
            raise ValueError("ub_to_l1 requires non-negative n_burst, burst_len, src_stride, and dst_stride")
        if n_burst == 0 or burst_len == 0:
            return

        burst_bytes = burst_len * 32
        src_step = (burst_len + src_stride) * 32
        dst_step = (burst_len + dst_stride) * 32
        require_burst_bytes("ub_to_l1", "src", src_name, src, n_burst, src_step, burst_bytes)
        require_burst_bytes("ub_to_l1", "dst", dst_name, dst, n_burst, dst_step, burst_bytes)
        for i in range(n_burst):
            sb = i * src_step
            db = i * dst_step
            dst[db:db + burst_bytes].copy_(src[sb:sb + burst_bytes])

    def _ub_to_l1_nd2nz(self, task: PipeTask) -> None:
        from easyasc import globvars
        if is_c220_family(getattr(globvars, "device_type", "")):
            raise RuntimeError("ub_to_l1_nd2nz not supported on C220 device")
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_32b_aligned("ub_to_l1_nd2nz", "dst", dst_name, dst_tensor)
        require_32b_aligned("ub_to_l1_nd2nz", "src", src_name, src_tensor)
        dst = _linear_view(dst_tensor)
        src = _linear_view(src_tensor)
        m_dst = _int(a["m_dst"], "m_dst")
        n_src = _int(a["n_src"], "n_src")
        m_src = _int(a["m_src"], "m_src")
        N_src = _int(a.get("N_src", n_src), "N_src")
        dst_row0 = _int(a.get("dst_row0", 0), "dst_row0")
        dst_col0 = _int(a.get("dst_col0", 0), "dst_col0")
        if m_src == 0 or n_src == 0:
            raise ValueError("ub_to_l1_nd2nz requires non-zero m_src and n_src")
        if N_src < n_src:
            raise ValueError(
                "ub_to_l1_nd2nz requires n_src <= N_src, got n_src=" + str(n_src)
                + ", N_src=" + str(N_src)
            )
        c0 = 32 // int(dst.element_size())
        stride_m = align16(m_dst)
        if m_dst <= 0 or dst_row0 < 0 or dst_row0 + m_src > m_dst:
            raise ValueError(
                "ub_to_l1_nd2nz requires 0 <= dst_row0 and dst_row0 + m_src <= m_dst, "
                "got dst_row0=" + str(dst_row0) + ", m_src=" + str(m_src) + ", m_dst=" + str(m_dst)
            )
        # A column-sliced NZ dst (e.g. l1p[:, 64:128]) has its storage_offset resolved at the
        # parent base, so the fractal column base must be added here to mirror the codegen address
        # (matches _ub_to_l1_nz / build_offset_expr_nz: off1*shape0). Without this, a subblock that
        # publishes to column offset 64 would overwrite fractal block 0 and leave its real columns
        # uninitialized -> matmul over-reads -> NaN.
        if dst_col0 % c0 != 0:
            raise ValueError(
                "ub_to_l1_nd2nz requires a fractal-aligned dst column offset (multiple of c0="
                + str(c0) + "), got dst_col0=" + str(dst_col0)
            )
        col_off = (dst_col0 // c0) * stride_m * c0
        require_strided_2d_elements("ub_to_l1_nd2nz", "src", src_name, src, m_src, n_src, N_src)
        require_flat_elements(
            "ub_to_l1_nd2nz", "dst", dst_name, dst,
            nz_tail_write_footprint(n_src, dst_row0, m_src, stride_m, c0, dst_col0),
        )
        src_2d = src.as_strided((m_src, n_src), (N_src, 1))
        blocks = (n_src + c0 - 1) // c0
        for r in range(m_src):
            row_data = src_2d[r]
            dst_r = dst_row0 + r
            for b in range(blocks):
                col0 = b * c0
                w = min(c0, n_src - col0)
                flat_off = col_off + b * stride_m * c0 + dst_r * c0
                dst[flat_off:flat_off + w].copy_(row_data[col0:col0 + w])

    def _ub_to_l1_nz(self, task: PipeTask) -> None:
        from easyasc import globvars
        if is_c220_family(getattr(globvars, "device_type", "")):
            raise RuntimeError("ub_to_l1_nz not supported on C220 device")
        a = task.args
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst_tensor = self.memory_store.tensor(dst_name)
        src_tensor = self.memory_store.tensor(src_name)
        require_32b_aligned("ub_to_l1_nz", "dst", dst_name, dst_tensor)
        require_32b_aligned("ub_to_l1_nz", "src", src_name, src_tensor)
        dst = _linear_view(dst_tensor)
        m_dst = _int(a["m_dst"], "m_dst")
        m_src = _int(a["m_src"], "m_src")
        n_src = _int(a["n_src"], "n_src")
        # M_src = physical fractal-row stride (src.shape[0]); src reads skip (M_src - m_src) padding
        # rows per fractal col. Default to m_src for older instructions (compact, back-compat).
        M_src_raw = a.get("M_src", None)
        M_src = _int(M_src_raw, "M_src") if M_src_raw is not None else m_src
        dst_row0 = _int(a.get("dst_row0", 0), "dst_row0")
        dst_col0 = _int(a.get("dst_col0", 0), "dst_col0")
        src_row0 = _int(a.get("src_row0", 0), "src_row0")
        src_col0 = _int(a.get("src_col0", 0), "src_col0")
        # The UB src's torch storage_offset bakes in the ROW-MAJOR slice offset (src_row0*N + src_col0),
        # but NZ addressing needs the FRACTAL offset (src_off0 below). Rebuild the src view at the
        # allocation (parent) base so src_off0 lands on the right fractal -- mirrors the L1 dst, which
        # is already resolved at its parent base (so a column-sliced ub_p[:, c0:] reads correctly).
        _src_st0 = int(src_tensor.stride(0)) if src_tensor.dim() >= 1 else 1
        _src_st1 = int(src_tensor.stride(1)) if src_tensor.dim() >= 2 else 1
        # Runtime HIF8 reinterpret slices deliberately keep the complete byte
        # carrier as their logical tensor; src_row0/src_col0 below provide the
        # NZ address. Do not undo a row-major slice that was never materialized.
        src_keeps_parent_base = ":hif8" in src_name
        alias_fn = getattr(self.memory_store, "alias", None)
        if callable(alias_fn):
            src_alias = alias_fn(src_name)
            src_tags = set(getattr(src_alias, "tags", ())) if src_alias is not None else set()
            src_keeps_parent_base = src_keeps_parent_base or (
                "reinterpret" in src_tags and "hif8" in src_tags
            )
        if src_keeps_parent_base:
            _src_base = int(src_tensor.storage_offset())
        else:
            _src_base = int(src_tensor.storage_offset()) - (
                src_row0 * _src_st0 + src_col0 * _src_st1
            )
        _src_total = int(src_tensor.untyped_storage().nbytes()) // int(src_tensor.element_size())
        src = src_tensor.as_strided((_src_total - _src_base,), (1,), storage_offset=_src_base)
        if m_src == 0 or n_src == 0:
            raise ValueError("ub_to_l1_nz requires non-zero m_src and n_src")
        c0 = 32 // int(dst.element_size())
        stride_m = align16(m_dst)
        if m_dst <= 0 or dst_row0 < 0 or dst_row0 + m_src > m_dst:
            raise ValueError(
                "ub_to_l1_nz requires 0 <= dst_row0 and dst_row0 + m_src <= m_dst, "
                "got dst_row0=" + str(dst_row0) + ", m_src=" + str(m_src) + ", m_dst=" + str(m_dst)
            )
        if dst_col0 % c0 != 0:
            raise ValueError(
                "ub_to_l1_nz requires a fractal-aligned dst column offset (multiple of c0="
                + str(c0) + "), got dst_col0=" + str(dst_col0)
            )
        if src_col0 % c0 != 0:
            raise ValueError(
                "ub_to_l1_nz requires a fractal-aligned src column offset (multiple of c0="
                + str(c0) + "), got src_col0=" + str(src_col0)
            )
        # NZ column (fractal) base: a [:, col0:] slice starts at fractal col0/c0. The sim view
        # is built at the parent tensor base (storage_offset ignores the column slice), so add
        # the fractal offset here to mirror the codegen address (build_offset_expr_nz: off1*shape0).
        col_off = (dst_col0 // c0) * stride_m * c0
        copy_len = m_src * c0
        src_block = M_src * c0  # physical span per fractal col in src (>= copy_len when padded)
        # src fractal/row base: same NZ logic for a sliced UB src (e.g. ub_p[:, 64:128]).
        src_off0 = (src_col0 // c0) * src_block + src_row0 * c0
        blocks = (n_src + c0 - 1) // c0
        require_flat_elements(
            "ub_to_l1_nz", "src", src_name, src, src_off0 + (blocks - 1) * src_block + copy_len)
        require_flat_elements(
            "ub_to_l1_nz", "dst", dst_name, dst,
            col_off + (blocks - 1) * stride_m * c0 + dst_row0 * c0 + copy_len,
        )
        for bi in range(blocks):
            d_off = col_off + bi * stride_m * c0 + dst_row0 * c0
            s_off = src_off0 + bi * src_block
            dst[d_off:d_off + copy_len].copy_(src[s_off:s_off + copy_len])


# ---------------------------------------------------------------------------
# VPipe — vector ALU operations with repeat-layout execution model
#
# Execution model per operation:
#   for r in range(repeat):
#     for b in range(8):                  # 8 blocks per repeat
#       dst_off = (r * dst_stride + b) * elems_per_block
#       src_off = (r * src_stride + b) * elems_per_block
#       mask_slice = current_mask[b * elems_per_block : (b+1) * elems_per_block]
#       result = op(src[src_off:...], ...)
#       dst[dst_off:...] = where(mask, result, dst[dst_off:...])
#
# elems_per_block = 32 // element_size (e.g. 8 for float32, 16 for float16)
# ---------------------------------------------------------------------------

@dataclass
class VPipe(PipeBase):
    current_mask: torch.Tensor = field(init=False)
    vector_mode: str = field(default="repeat", init=False)
    count_register: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        self.current_mask = torch.ones(256, dtype=torch.uint8)
        self.count_register = 0

    def execute(self, task: PipeTask) -> None:
        op = task.opname
        a = task.args

        # Mask ops
        if op in ("set_mask", "vec_v_set_mask"):
            self._set_mask(a); return
        if op in ("reset_mask", "vec_v_reset_mask"):
            self.current_mask.fill_(1); return
        # Count mode control
        if op == "set_mask_count":
            self.vector_mode = "count"; return
        if op == "set_mask_normal":
            self.vector_mode = "repeat"; return
        if op == "set_mask_counter":
            self.count_register = _int(a.get("count", 0), "count"); return
        if op in ("set_mask_by_count", "vec_v_set_mask_by_count"):
            count = _int(a.get("count", 0), "count")
            if count < 0 or count > 256:
                raise ValueError("set_mask_by_count count must be in [0, 256], got " + str(count))
            self.current_mask.fill_(0)
            if count > 0:
                self.current_mask[:count] = 1
            return

        # UB copy
        if op == "ub_to_ub":
            self._ub_to_ub(a); return

        # Sort ops (no mask)
        if op == "sort32":
            self._sort32(a); return
        if op == "mergesort4":
            self._mergesort4(a); return
        if op == "mergesort_2seq":
            self._mergesort_2seq(a); return
        if op == "topk_radix":
            self._topk_radix(a); return

        # Gather / scatter
        if op in ("gather",):
            self._gather(a); return
        if op in ("gather_block",):
            self._gather_block(a); return
        if op in ("scatter",):
            self._scatter(a); return

        # vnchwconv 16x16 block transpose
        if op == "transdata5hd":
            self._transdata5hd(a); return

        # call_micro
        if op == "call_micro":
            self._call_micro(a); return

        if op == "call_simt":
            self._call_simt(a); return

        # All other ops use the repeat-layout model
        self._dispatch_repeat_op(task)

    # ------------------------------------------------------------------
    # Repeat-layout framework
    # ------------------------------------------------------------------

    def _get_tensor(self, name: str) -> torch.Tensor:
        return _linear_view(self.memory_store.tensor(name))

    def _dispatch_repeat_op(self, task: PipeTask) -> None:
        op = task.opname
        a = task.args

        # Normalize vec_v_xxx → xxx
        canon = _CANONICAL_OP.get(op, op)

        dst_name = str(a["dst"])
        dst = self._get_tensor(dst_name)

        # Count mode: ignore repeat/stride/mask, operate on src[0:count] → dst[0:count]
        if self.vector_mode == "count":
            self._dispatch_count_mode(canon, a, dst)
            return

        repeat = _int(a.get("repeat", 0), "repeat")
        if repeat < 0:
            raise ValueError("repeat must be non-negative, got " + str(repeat))
        _check_repeat_bound(repeat, canon)
        dst_blk = _int(a.get("dst_blk_stride", 1), "dst_blk_stride")
        dst_rep = _int(a.get("dst_rep_stride", 8), "dst_rep_stride")
        epb = 32 // int(dst.element_size())  # elements per block

        if canon in _BINARY_OPS:
            _require_ub_32b_aligned(canon, "dst", dst_name, dst)
            src1_name = str(a["src1"])
            src2_name = str(a["src2"])
            src1 = self._get_tensor(src1_name)
            src2 = self._get_tensor(src2_name)
            _require_ub_32b_aligned(canon, "src1", src1_name, src1)
            _require_ub_32b_aligned(canon, "src2", src2_name, src2)
            src1_blk = _int(a.get("src1_blk_stride", 1), "src1_blk_stride")
            src1_rep = _int(a.get("src1_rep_stride", 8), "src1_rep_stride")
            src2_blk = _int(a.get("src2_blk_stride", 1), "src2_blk_stride")
            src2_rep = _int(a.get("src2_rep_stride", 8), "src2_rep_stride")
            fn = _BINARY_OPS[canon]
            cdt = _compute_dtype(dst.dtype)
            is_bitwise = canon in ("vand", "vor")
            m = self.current_mask
            self._guard_footprint(canon, "dst", dst_name, _strided_touch(m, repeat, dst_rep, dst_blk, epb))
            self._guard_footprint(canon, "src1", src1_name,
                                   _strided_touch(m, repeat, src1_rep, src1_blk, 32 // int(src1.element_size())))
            self._guard_footprint(canon, "src2", src2_name,
                                   _strided_touch(m, repeat, src2_rep, src2_blk, 32 // int(src2.element_size())))
            for r in range(repeat):
                for b in range(8):
                    di = (r * dst_rep + b * dst_blk) * epb
                    i1 = (r * src1_rep + b * src1_blk) * epb
                    i2 = (r * src2_rep + b * src2_blk) * epb
                    if is_bitwise:
                        result = fn(src1[i1:i1+epb], src2[i2:i2+epb])
                    else:
                        result = fn(src1[i1:i1+epb].to(cdt), src2[i2:i2+epb].to(cdt)).to(dst.dtype)
                    self._masked_write(dst, di, result, b, epb)

        elif canon in _UNARY_OPS or canon == "vnot":
            _require_ub_32b_aligned(canon, "dst", dst_name, dst)
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            _require_ub_32b_aligned(canon, "src", src_name, src)
            src_blk = _int(a.get("src_blk_stride", 1), "src_blk_stride")
            src_rep = _int(a.get("src_rep_stride", 8), "src_rep_stride")
            cdt = _compute_dtype(dst.dtype)
            m = self.current_mask
            self._guard_footprint(canon, "dst", dst_name, _strided_touch(m, repeat, dst_rep, dst_blk, epb))
            self._guard_footprint(canon, "src", src_name,
                                   _strided_touch(m, repeat, src_rep, src_blk, 32 // int(src.element_size())))
            for r in range(repeat):
                for b in range(8):
                    di = (r * dst_rep + b * dst_blk) * epb
                    si = (r * src_rep + b * src_blk) * epb
                    src_block = src[si:si+epb]
                    if canon == "vnot":
                        result = _bitwise_not_with_fallback(src_block).to(dst.dtype)
                    else:
                        result = _UNARY_OPS[canon](src_block.to(cdt)).to(dst.dtype)
                    self._masked_write(dst, di, result, b, epb)

        elif canon in _SCALAR_OPS or canon in _SHIFT_OPS or canon == "axpy":
            _require_ub_32b_aligned(canon, "dst", dst_name, dst)
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            _require_ub_32b_aligned(canon, "src", src_name, src)
            src_blk = _int(a.get("src_blk_stride", 1), "src_blk_stride")
            src_rep = _int(a.get("src_rep_stride", 8), "src_rep_stride")
            raw_val = a.get("val", a.get("value", a.get("scalar", 0)))
            val = _int(raw_val, "val") if canon in _SHIFT_OPS else float(raw_val)
            cdt = _compute_dtype(dst.dtype)
            m = self.current_mask
            self._guard_footprint(canon, "dst", dst_name, _strided_touch(m, repeat, dst_rep, dst_blk, epb))
            self._guard_footprint(canon, "src", src_name,
                                   _strided_touch(m, repeat, src_rep, src_blk, 32 // int(src.element_size())))
            for r in range(repeat):
                for b in range(8):
                    di = (r * dst_rep + b * dst_blk) * epb
                    si = (r * src_rep + b * src_blk) * epb
                    src_block = src[si:si+epb]
                    if canon == "axpy":
                        dst_snap = dst[di:di+epb].clone()
                        result = (dst_snap.to(cdt) + src_block.to(cdt) * val).to(dst.dtype)
                    elif canon in _SHIFT_OPS:
                        result = _shift_scalar_bits(
                            canon, src_block, val, round_en=bool(a.get("round_en", False))
                        )
                    else:
                        result = _SCALAR_OPS[canon](src_block.to(cdt), val).to(dst.dtype)
                    self._masked_write(dst, di, result, b, epb)

        elif canon == "dup":
            _require_ub_32b_aligned(canon, "dst", dst_name, dst)
            scalar = float(a.get("src", a.get("value", a.get("scalar", 0))))
            self._guard_footprint(canon, "dst", dst_name,
                                  _strided_touch(self.current_mask, repeat, dst_rep, dst_blk, epb))
            for r in range(repeat):
                for b in range(8):
                    di = (r * dst_rep + b * dst_blk) * epb
                    result = torch.full((epb,), scalar, dtype=dst.dtype)
                    self._masked_write(dst, di, result, b, epb)

        elif canon == "cast":
            _require_ub_32b_aligned(canon, "dst", dst_name, dst)
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            _require_ub_32b_aligned(canon, "src", src_name, src)
            mode = a.get("mode")
            mode_name = str(getattr(mode, "name", mode) or "CAST_NONE")
            src_blk_c = _int(a.get("src_blk_stride", 1), "src_blk_stride")
            src_rep_c = _int(a.get("src_rep_stride", 8), "src_rep_stride")
            dst_c0 = 32 // int(dst.element_size())
            src_c0 = 32 // int(src.element_size())
            # Cast repeat strides are addresses between repeats, not the number of
            # logical elements converted by one repeat.  The latter is fixed by the
            # wider dtype (64 lanes for bf16<->fp32).  This distinction matters for
            # high-dimensional sharding such as two active lanes in each padded 32B
            # row: src/dst rep strides may both be one block even though their C0s
            # differ.  The old model rejected that legal form by multiplying each
            # rep stride by its own C0 and requiring those products to match.
            logical_elem_size = max(int(dst.element_size()), int(src.element_size()))
            logical_elems_per_repeat = 256 // logical_elem_size
            # Keep the conservative full-repeat footprint guard.  Even with a narrow
            # mask, c220 Cast may touch storage outside the active logical lanes; a
            # padded/guarded row allocation prevents that physical footprint from
            # reaching the next UB tensor.
            src_need = ((repeat - 1) * src_rep_c * src_c0 + logical_elems_per_repeat) if repeat else 0
            dst_need = ((repeat - 1) * dst_rep * dst_c0 + logical_elems_per_repeat) if repeat else 0
            self._guard_footprint(canon, "src", src_name, src_need)
            self._guard_footprint(canon, "dst", dst_name, dst_need)
            mask_prefix = self.current_mask[:logical_elems_per_repeat].bool()
            mask_all = bool(mask_prefix.all().item())
            for r in range(repeat):
                src_begin = r * src_rep_c * src_c0
                dst_begin = r * dst_rep * dst_c0
                src_chunk = src[src_begin:src_begin + logical_elems_per_repeat].clone()
                dst_chunk = dst[dst_begin:dst_begin + logical_elems_per_repeat]
                if src.dtype == dst.dtype:
                    if src_chunk.dtype.is_floating_point:
                        result = apply_cast_dtype(
                            src_chunk, dst.dtype, mode_name, "vec_v_cast round mode"
                        )
                    else:
                        result = src_chunk
                elif src_chunk.dtype.is_floating_point and not dst.dtype.is_floating_point:
                    result = apply_cast_dtype(
                        src_chunk, dst.dtype, mode_name, "vec_v_cast round mode", saturate=True
                    )
                elif src_chunk.dtype.is_floating_point and dst.dtype.is_floating_point:
                    result = apply_cast_dtype(
                        src_chunk, dst.dtype, mode_name, "vec_v_cast round mode"
                    )
                elif not src_chunk.dtype.is_floating_point and dst.dtype.is_floating_point:
                    result = apply_cast_dtype(
                        src_chunk, dst.dtype, mode_name, "vec_v_cast round mode"
                    )
                else:
                    result = src_chunk.to(dst.dtype)
                if mask_all:
                    dst_chunk.copy_(result)
                else:
                    dst_chunk.copy_(torch.where(mask_prefix, result, dst_chunk.clone()))

        elif canon in _REDUCE_OPS:
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            whole = canon in ("cmax", "cmin", "cadd")
            dst_align = int(dst.element_size()) if whole else 8 * int(dst.element_size())
            require_byte_aligned(canon, "dst", dst_name, dst, dst_align)
            # The source is read in whole 32B blocks (src_blk_stride / src_rep_stride
            # are in units of 8-element blocks), and real HW ignores a sub-block
            # source byte offset: e.g. cmax(absf[:, 4:]) at a 16B offset collapses
            # onto the 32B-aligned read instead of starting at element 4. So the
            # source must start on a 32B boundary even when the dst is
            # element-strided. The simulator otherwise honors the offset and hides
            # this sim-passes / HW-wrong divergence.
            src_align = 32 if whole else 8 * int(dst.element_size())
            require_byte_aligned(canon, "src", src_name, src, src_align)
            src_blk = _int(a.get("src_blk_stride", 1), "src_blk_stride")
            src_rep = _int(a.get("src_rep_stride", 8), "src_rep_stride")
            # group reduce stub emits dst_rep_stride only (no dst_blk_stride);
            # dst_rep holds whatever was read, default 8 per VPipe but group stub defaults to 1.
            gr_dst_rep = _int(a.get("dst_rep_stride", 1), "dst_rep_stride")
            cdt = _compute_dtype(src.dtype)
            # Source spans 8 blocks per repeat (mask-active lanes only -- disabled lanes are
            # forced to +/-inf/0 and do not feed the result). Dst is element-strided: a whole
            # reduce writes one value per repeat; a group (cg*) reduce writes one per active
            # block. Bound both against the logical tensor size.
            if repeat > 0:
                self._guard_footprint(canon, "src", src_name,
                                      _strided_touch(self.current_mask, repeat, src_rep, src_blk, epb))
                if whole:
                    self._guard_footprint(canon, "dst", dst_name, (repeat - 1) * gr_dst_rep + 1)
                else:
                    active_blk = torch.nonzero(
                        self.current_mask[:8 * epb].bool().view(8, epb).any(dim=1), as_tuple=False)
                    if active_blk.numel():
                        self._guard_footprint(canon, "dst", dst_name,
                                              (repeat - 1) * gr_dst_rep * 8 + int(active_blk.max().item()) + 1)
            for r in range(repeat):
                src_rep_base = r * src_rep * epb
                blocks: List[torch.Tensor] = []
                block_masks: List[torch.Tensor] = []
                for b in range(8):
                    si = src_rep_base + b * src_blk * epb
                    block = src[si:si+epb].clone().to(cdt)
                    mask_block = self.current_mask[b*epb:(b+1)*epb].bool()
                    block_masks.append(mask_block)
                    if canon in ("cadd", "cgadd"):
                        block = torch.where(mask_block, block, torch.zeros_like(block))
                    elif canon in ("cmax", "cgmax"):
                        block = torch.where(mask_block, block, torch.full_like(block, float("-inf")))
                    elif canon in ("cmin", "cgmin"):
                        block = torch.where(mask_block, block, torch.full_like(block, float("inf")))
                    blocks.append(block)
                if canon in ("cmax", "cmin", "cadd"):
                    combined_mask = torch.cat(block_masks)
                    if bool(torch.any(combined_mask).item()):
                        combined = torch.cat(blocks)
                        if canon == "cmax":
                            reduced = torch.max(combined)
                        elif canon == "cmin":
                            reduced = torch.min(combined)
                        else:
                            reduced = torch.sum(combined)
                        dst[r * gr_dst_rep] = reduced.to(dst.dtype)
                else:
                    dst_base = r * gr_dst_rep * 8
                    for b, block in enumerate(blocks):
                        if bool(torch.any(block_masks[b]).item()):
                            if canon == "cgmax":
                                dst[dst_base + b] = torch.max(block).to(dst.dtype)
                            elif canon == "cgmin":
                                dst[dst_base + b] = torch.min(block).to(dst.dtype)
                            else:
                                dst[dst_base + b] = torch.sum(block).to(dst.dtype)

        elif canon == "cpadd":
            _require_ub_32b_aligned(canon, "dst", dst_name, dst)
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            _require_ub_32b_aligned(canon, "src", src_name, src)
            src_blk = _int(a.get("src_blk_stride", 1), "src_blk_stride")
            src_rep = _int(a.get("src_rep_stride", 8), "src_rep_stride")
            cp_dst_rep = _int(a.get("dst_rep_stride", 1), "dst_rep_stride")
            elems_per_repeat = epb * 8
            if (elems_per_repeat % 2) != 0:
                raise ValueError("cpadd requires even element count per repeat, got " + str(elems_per_repeat))
            out_per_repeat = elems_per_repeat // 2
            cdt = _compute_dtype(src.dtype)
            if repeat > 0:
                self._guard_footprint(canon, "src", src_name,
                                      _strided_touch(self.current_mask, repeat, src_rep, src_blk, epb))
                self._guard_footprint(canon, "dst", dst_name,
                                      (repeat - 1) * cp_dst_rep * out_per_repeat + out_per_repeat)
            for r in range(repeat):
                src_rep_base = r * src_rep * epb
                gathered: List[torch.Tensor] = []
                for b in range(8):
                    si = src_rep_base + b * src_blk * epb
                    block = src[si:si+epb].clone().to(cdt)
                    mask_block = self.current_mask[b*epb:(b+1)*epb].bool()
                    block = torch.where(mask_block, block, torch.zeros_like(block))
                    gathered.append(block)
                chunk = torch.cat(gathered)
                pair_sum = chunk.reshape(-1, 2).sum(dim=1)
                dst_base = r * cp_dst_rep * out_per_repeat
                dst[dst_base:dst_base + out_per_repeat].copy_(pair_sum.to(dst.dtype))

        elif canon == "brcb":
            _require_ub_32b_aligned(canon, "dst", dst_name, dst)
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            _require_ub_32b_aligned(canon, "src", src_name, src)
            # src is one scalar per (repeat, block); dst broadcasts each into a full 32B block
            # (unpredicated fill) -> conservative all-block span.
            self._guard_footprint(canon, "src", src_name, repeat * 8)
            if repeat > 0:
                self._guard_footprint(canon, "dst", dst_name, _block_touch(repeat, dst_rep, dst_blk, epb))
            for r in range(repeat):
                src_rep_base = r * 8
                for b in range(8):
                    di = (r * dst_rep + b * dst_blk) * epb
                    scalar = src[src_rep_base + b].item()
                    dst[di:di+epb].fill_(scalar)

        elif canon in ("compare", "compare_scalar"):
            self._compare(canon, a, dst, epb)

        elif canon == "select":
            self._select(a, dst, epb)

        elif canon == "muladddst":
            _require_ub_32b_aligned(canon, "dst", dst_name, dst)
            src1_name = str(a["src1"])
            src2_name = str(a["src2"])
            src1 = self._get_tensor(src1_name)
            src2 = self._get_tensor(src2_name)
            _require_ub_32b_aligned(canon, "src1", src1_name, src1)
            _require_ub_32b_aligned(canon, "src2", src2_name, src2)
            src1_blk = _int(a.get("src1_blk_stride", 1), "src1_blk_stride")
            src1_rep = _int(a.get("src1_rep_stride", 8), "src1_rep_stride")
            src2_blk = _int(a.get("src2_blk_stride", 1), "src2_blk_stride")
            src2_rep = _int(a.get("src2_rep_stride", 8), "src2_rep_stride")
            cdt = _compute_dtype(dst.dtype)
            m = self.current_mask
            self._guard_footprint(canon, "dst", dst_name, _strided_touch(m, repeat, dst_rep, dst_blk, epb))
            self._guard_footprint(canon, "src1", src1_name,
                                   _strided_touch(m, repeat, src1_rep, src1_blk, 32 // int(src1.element_size())))
            self._guard_footprint(canon, "src2", src2_name,
                                   _strided_touch(m, repeat, src2_rep, src2_blk, 32 // int(src2.element_size())))
            epb_s1 = 32 // int(src1.element_size())
            if epb_s1 != epb:
                # Mixed precision (e.g. MulAddDst<float, half>): one repeat is a contiguous
                # run of (8*epb) dst elements; the fp16 src spans the same element count in
                # half as many 32B datablocks (src_rep != dst_rep), so the fixed 8-datablock
                # loop below -- which assumes a shared epb -- mis-indexes it. Walk elements
                # contiguously per repeat instead. A tail repeat over-runs to the next
                # multiple of (8*epb) into scratch lanes the store never reads, so clamp to
                # the dst view. (blk_stride is 1 for the mixed form -- CANN doc {1,1,1,8,4,4}.)
                epb_s2 = 32 // int(src2.element_size())
                per_rep = 8 * epb
                nd = int(dst.numel())
                for r in range(repeat):
                    d0 = r * dst_rep * epb
                    if d0 >= nd:
                        break
                    seg = min(per_rep, nd - d0)
                    s10 = r * src1_rep * epb_s1
                    s20 = r * src2_rep * epb_s2
                    snap = dst[d0:d0 + seg].clone()
                    res = (src1[s10:s10 + seg].to(cdt) * src2[s20:s20 + seg].to(cdt) + snap.to(cdt)).to(dst.dtype)
                    dst[d0:d0 + seg].copy_(res)
            else:
                for r in range(repeat):
                    for b in range(8):
                        di = (r * dst_rep + b * dst_blk) * epb
                        i1 = (r * src1_rep + b * src1_blk) * epb
                        i2 = (r * src2_rep + b * src2_blk) * epb
                        dst_snap = dst[di:di+epb].clone()
                        result = (src1[i1:i1+epb].to(cdt) * src2[i2:i2+epb].to(cdt) + dst_snap.to(cdt)).to(dst.dtype)
                        self._masked_write(dst, di, result, b, epb)

        else:
            raise NotImplementedError(
                "VPipe unhandled op: " + canon + " (raw: " + task.opname + ")"
            )

    def _dispatch_count_mode(self, canon: str, a: Dict, dst: torch.Tensor) -> None:
        """Count mode: operate on first count_register elements, no repeat/stride/mask."""
        count = self.count_register
        if count == 0:
            raise ValueError("count-mode vector op requires count_register > 0")
        cdt = _compute_dtype(dst.dtype)

        if canon in _BINARY_OPS:
            _require_ub_32b_aligned(canon, "dst", str(a["dst"]), dst)
            src1_name = str(a["src1"])
            src2_name = str(a["src2"])
            src1 = self._get_tensor(src1_name)
            src2 = self._get_tensor(src2_name)
            _require_ub_32b_aligned(canon, "src1", src1_name, src1)
            _require_ub_32b_aligned(canon, "src2", src2_name, src2)
            self._guard_footprint(canon, "src1", src1_name, count)
            self._guard_footprint(canon, "src2", src2_name, count)
            self._guard_footprint(canon, "dst", str(a["dst"]), count)
            fn = _BINARY_OPS[canon]
            if canon in ("vand", "vor"):
                result = fn(src1[:count], src2[:count])
            else:
                result = fn(src1[:count].to(cdt), src2[:count].to(cdt)).to(dst.dtype)
            dst[:count].copy_(result)

        elif canon in _UNARY_OPS or canon == "vnot":
            _require_ub_32b_aligned(canon, "dst", str(a["dst"]), dst)
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            _require_ub_32b_aligned(canon, "src", src_name, src)
            self._guard_footprint(canon, "src", src_name, count)
            self._guard_footprint(canon, "dst", str(a["dst"]), count)
            if canon == "vnot":
                result = _bitwise_not_with_fallback(src[:count]).to(dst.dtype)
            else:
                result = _UNARY_OPS[canon](src[:count].to(cdt)).to(dst.dtype)
            dst[:count].copy_(result)

        elif canon in _SCALAR_OPS or canon in _SHIFT_OPS or canon == "axpy":
            _require_ub_32b_aligned(canon, "dst", str(a["dst"]), dst)
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            _require_ub_32b_aligned(canon, "src", src_name, src)
            raw_val = a.get("val", a.get("value", a.get("scalar", 0)))
            val = _int(raw_val, "val") if canon in _SHIFT_OPS else float(raw_val)
            self._guard_footprint(canon, "src", src_name, count)
            self._guard_footprint(canon, "dst", str(a["dst"]), count)
            if canon == "axpy":
                dst_snap = dst[:count].clone()
                result = (dst_snap.to(cdt) + src[:count].to(cdt) * val).to(dst.dtype)
            elif canon in _SHIFT_OPS:
                result = _shift_scalar_bits(
                    canon, src[:count], val, round_en=bool(a.get("round_en", False))
                )
            else:
                result = _SCALAR_OPS[canon](src[:count].to(cdt), val).to(dst.dtype)
            dst[:count].copy_(result)

        elif canon == "dup":
            _require_ub_32b_aligned(canon, "dst", str(a["dst"]), dst)
            scalar = float(a.get("src", a.get("value", a.get("scalar", 0))))
            self._guard_footprint(canon, "dst", str(a["dst"]), count)
            dst[:count].fill_(scalar)

        elif canon == "cast":
            _require_ub_32b_aligned(canon, "dst", str(a["dst"]), dst)
            src_name = str(a["src"])
            src = self._get_tensor(src_name)
            _require_ub_32b_aligned(canon, "src", src_name, src)
            self._guard_footprint(canon, "src", src_name, count)
            self._guard_footprint(canon, "dst", str(a["dst"]), count)
            mode = a.get("mode")
            mode_name = str(getattr(mode, "name", mode) or "CAST_NONE")
            src_chunk = src[:count].clone()
            if src.dtype == dst.dtype:
                if src_chunk.dtype.is_floating_point:
                    result = apply_cast_dtype(
                        src_chunk, dst.dtype, mode_name, "vec_v_cast round mode"
                    )
                else:
                    result = src_chunk
            elif src_chunk.dtype.is_floating_point and not dst.dtype.is_floating_point:
                result = apply_cast_dtype(
                    src_chunk, dst.dtype, mode_name, "vec_v_cast round mode", saturate=True
                )
            elif src_chunk.dtype.is_floating_point and dst.dtype.is_floating_point:
                result = apply_cast_dtype(
                    src_chunk, dst.dtype, mode_name, "vec_v_cast round mode"
                )
            elif not src_chunk.dtype.is_floating_point and dst.dtype.is_floating_point:
                result = apply_cast_dtype(
                    src_chunk, dst.dtype, mode_name, "vec_v_cast round mode"
                )
            else:
                result = src_chunk.to(dst.dtype)
            dst[:count].copy_(result)

        elif canon in _REDUCE_OPS or canon == "cpadd":
            raise NotImplementedError(
                "count-mode group reduction is not supported by stub (ensure_repeat_mode enforced)"
            )

        elif canon in ("compare", "compare_scalar"):
            raise NotImplementedError(
                "count-mode compare is not supported by stub (compare.py enforces ensure_repeat_mode)"
            )

        elif canon == "select":
            raise NotImplementedError(
                "count-mode select is not supported by stub (select.py enforces ensure_repeat_mode)"
            )

        elif canon == "muladddst":
            _require_ub_32b_aligned(canon, "dst", str(a["dst"]), dst)
            src1_name = str(a["src1"])
            src2_name = str(a["src2"])
            src1 = self._get_tensor(src1_name)
            src2 = self._get_tensor(src2_name)
            _require_ub_32b_aligned(canon, "src1", src1_name, src1)
            _require_ub_32b_aligned(canon, "src2", src2_name, src2)
            self._guard_footprint(canon, "src1", src1_name, count)
            self._guard_footprint(canon, "src2", src2_name, count)
            self._guard_footprint(canon, "dst", str(a["dst"]), count)
            dst_snap = dst[:count].clone()
            result = (src1[:count].to(cdt) * src2[:count].to(cdt) + dst_snap.to(cdt)).to(dst.dtype)
            dst[:count].copy_(result)

        else:
            raise NotImplementedError("VPipe count-mode unhandled op: " + canon)

    def _masked_write(self, dst: torch.Tensor, offset: int, result: torch.Tensor, blk: int, epb: int) -> None:
        n = int(result.numel())
        mask = self.current_mask[blk * epb:(blk + 1) * epb].bool()[:n]
        dst_block = dst[offset:offset + n]
        if bool(mask.all().item()):
            dst_block.copy_(result)
            return
        # torch.where is missing some unsigned CPU kernels (e.g. uint16), so
        # blend through a same-width signed view when needed.
        dst_block.copy_(_masked_blend(mask, result, dst_block.clone()))

    def _alloc_avail(self, name: str) -> int:
        """Elements from this op's start to the END OF THE ALLOCATED BUFFER -- the bound an
        overrun must not cross.

        The simulator backs all UB tensors with one shared bank, so neither obvious size
        works: the slice's own numel is too small (a full-mask scalar op legitimately
        touches all 64 lanes of a wide buffer through a narrow [0:1,0:valid] slice, so
        slice-numel would false-positive on correct code), and the _get_tensor / _linear_view
        extent is far too large (it runs to the end of the whole bank, which is exactly what
        hides an overrun into the next tensor).

        Slice tensors are named "<tmp>@<parent>@...@<root>:<dtype>:<enc>"; recover the
        outermost root buffer (the last '@' segment) and bound the footprint at the root's
        allocation end, measured in BYTES so a dtype-reinterpret view (e.g. an int16 op over
        an fp32 buffer) is handled correctly:
            avail_bytes  = (root.storage_offset + root.numel) * root.elem - op_start_byte
            avail_elems  = avail_bytes // op.elem
        A plain (non-slice) name has no '@' and its own numel already is the buffer size."""
        ms = self.memory_store
        if "@" in name:
            root = name.split("@")[-1].split(":")[0]
            if root and ms.contains(root):
                base = ms.tensor(name)
                r = ms.tensor(root)
                base_byte = int(base.storage_offset()) * int(base.element_size())
                root_end_byte = (int(r.storage_offset()) + int(r.numel())) * int(r.element_size())
                return (root_end_byte - base_byte) // int(base.element_size())
        return int(ms.tensor(name).numel())

    def _guard_footprint(self, op: str, role: str, name: str, need: int) -> None:
        """Raise if an op's addressed footprint runs past the end of the allocated buffer --
        the sim-hidden 'overrun into the neighbour UB tensor' trap (e.g. a [1,32] scalar
        buffer hit by a full-mask 64-lane op). `need` is the highest element index + 1 the
        op addresses (see _strided_touch / _block_touch / the reduce special-cases)."""
        have = self._alloc_avail(name)
        if need > have:
            raise MemoryError(
                op + " " + role + " '" + name + "' overruns its UB buffer: addresses "
                + str(need) + " elems but only " + str(have) + " left to the buffer end"
                + " (widen the buffer or narrow the vector mask)")

    # ------------------------------------------------------------------
    # Compare / Select
    # ------------------------------------------------------------------

    def _compare(self, canon: str, a: Dict, dst: torch.Tensor, epb: int) -> None:
        dst_name = str(a["dst"])
        _require_ub_32b_aligned(canon, "dst", dst_name, dst)
        if dst.dtype not in (torch.uint8, torch.int8):
            raise TypeError("compare dst must be uint8/int8, got " + str(dst.dtype))
        src1_name = str(a["src1"])
        src1 = self._get_tensor(src1_name)
        _require_ub_32b_aligned(canon, "src1", src1_name, src1)
        repeat = _int(a.get("repeat", 0), "repeat")
        if repeat < 0:
            raise ValueError("compare repeat must be non-negative, got " + str(repeat))
        _check_repeat_bound(repeat, canon)
        if repeat == 0:
            return

        mode = a.get("mode")
        mode_name = str(getattr(mode, "name", mode) or "").upper()
        cmp_fn = _CMP_MODES.get(mode_name)
        if cmp_fn is None:
            raise ValueError("unsupported vec compare mode: " + mode_name)

        src1_blk = _int(a.get("src1_blk_stride", 1), "src1_blk_stride")
        src1_rep = _int(a.get("src1_rep_stride", 8), "src1_rep_stride")

        is_scalar = canon == "compare_scalar"
        if is_scalar:
            scalar = float(a.get("src2", 0))
            src2 = None
            src2_blk = 0
            src2_rep = 0
        else:
            src2_name = str(a["src2"])
            src2 = self._get_tensor(src2_name)
            _require_ub_32b_aligned(canon, "src2", src2_name, src2)
            src2_blk = _int(a.get("src2_blk_stride", 1), "src2_blk_stride")
            src2_rep = _int(a.get("src2_rep_stride", 8), "src2_rep_stride")

        elem_size = int(src1.element_size())
        s_epb = 32 // elem_size
        elems_per_repeat = s_epb * 8
        bytes_per_repeat = elems_per_repeat // 8  # always 32

        # dst is a packed bitmask: bytes_per_repeat bytes per repeat, contiguous. src reads
        # whole blocks (compare is unpredicated -> conservative all-block span).
        self._guard_footprint(canon, "dst", dst_name, bytes_per_repeat * repeat)
        self._guard_footprint(canon, "src1", src1_name, _block_touch(repeat, src1_rep, src1_blk, s_epb))
        if not is_scalar:
            self._guard_footprint(canon, "src2", src2_name, _block_touch(repeat, src2_rep, src2_blk, s_epb))

        cdt = _compute_dtype(src1.dtype)
        for r in range(repeat):
            lhs_blocks: List[torch.Tensor] = []
            src1_rep_base = r * src1_rep * s_epb
            for b in range(8):
                i1 = src1_rep_base + b * src1_blk * s_epb
                lhs_blocks.append(src1[i1:i1+s_epb].clone())
            lhs = torch.cat(lhs_blocks).to(cdt)
            if is_scalar:
                rhs = torch.full_like(lhs, scalar)
            else:
                rhs_blocks: List[torch.Tensor] = []
                src2_rep_base = r * src2_rep * s_epb
                for b in range(8):
                    i2 = src2_rep_base + b * src2_blk * s_epb
                    rhs_blocks.append(src2[i2:i2+s_epb].clone())
                rhs = torch.cat(rhs_blocks).to(cdt)
            bool_result = cmp_fn(lhs, rhs)
            packed = _pack_bits_lsb_first(bool_result, bytes_per_repeat)
            dst_begin = r * bytes_per_repeat
            dst[dst_begin:dst_begin+bytes_per_repeat].copy_(packed.to(dst.dtype))

    def _select(self, a: Dict, dst: torch.Tensor, epb: int) -> None:
        _require_ub_32b_aligned("select", "dst", str(a["dst"]), dst)
        src1_name = str(a["src1"])
        src2_name = str(a["src2"])
        selmask_name = str(a["selmask"])
        src1 = self._get_tensor(src1_name)
        src2 = self._get_tensor(src2_name)
        selmask = self._get_tensor(selmask_name)
        _require_ub_32b_aligned("select", "src1", src1_name, src1)
        _require_ub_32b_aligned("select", "src2", src2_name, src2)
        _require_ub_32b_aligned("select", "selmask", selmask_name, selmask)
        if selmask.dtype != torch.uint8:
            raise TypeError("select requires uint8 selmask, got " + str(selmask.dtype))

        mode = a.get("mode")
        mode_name = str(getattr(mode, "name", mode) or "").upper()
        if mode_name not in ("TENSOR_TENSOR", "TENSOR_SCALAR"):
            raise ValueError("select mode must be TENSOR_TENSOR or TENSOR_SCALAR, got " + mode_name)
        if mode_name == "TENSOR_TENSOR" and (
            _tensor_storage_addr(dst) == _tensor_storage_addr(src1)
            or _tensor_storage_addr(dst) == _tensor_storage_addr(src2)
        ):
            raise ValueError("SelectMode.TENSOR_TENSOR requires dst address to differ from src1 and src2")

        repeat = _int(a.get("repeat", 0), "repeat")
        if repeat < 0:
            raise ValueError("select repeat must be non-negative, got " + str(repeat))
        _check_repeat_bound(repeat, "select")
        if repeat == 0:
            return

        dst_blk = _int(a.get("dst_blk_stride", 1), "dst_blk_stride")
        dst_rep = _int(a.get("dst_rep_stride", 8), "dst_rep_stride")
        src1_blk = _int(a.get("src1_blk_stride", 1), "src1_blk_stride")
        src1_rep = _int(a.get("src1_rep_stride", 8), "src1_rep_stride")
        src2_blk = _int(a.get("src2_blk_stride", 1), "src2_blk_stride")
        src2_rep = _int(a.get("src2_rep_stride", 8), "src2_rep_stride")

        s_epb = 32 // int(src1.element_size())
        elems_per_repeat = s_epb * 8
        bytes_per_repeat = elems_per_repeat // 8

        # selmask is a packed bitmask (bytes_per_repeat/repeat, contiguous). dst and the src
        # operands write/read whole blocks (select blends via selmask bits, not the
        # current_mask) -> conservative all-block span.
        self._guard_footprint("select", "selmask", selmask_name, bytes_per_repeat * repeat)
        self._guard_footprint("select", "dst", str(a["dst"]), _block_touch(repeat, dst_rep, dst_blk, s_epb))
        self._guard_footprint("select", "src1", src1_name, _block_touch(repeat, src1_rep, src1_blk, s_epb))
        if mode_name == "TENSOR_TENSOR":
            self._guard_footprint("select", "src2", src2_name, _block_touch(repeat, src2_rep, src2_blk, s_epb))

        scalar_rhs = None
        if mode_name == "TENSOR_SCALAR":
            scalar_rhs = float(src2.reshape(-1)[0].item())

        for r in range(repeat):
            mask_begin = r * bytes_per_repeat
            mask_bytes = selmask[mask_begin:mask_begin + bytes_per_repeat]
            bits = _unpack_bits_lsb_first(mask_bytes, elems_per_repeat)
            for b in range(8):
                bit_off = b * s_epb
                mask_block = bits[bit_off:bit_off + s_epb]
                i1 = (r * src1_rep + b * src1_blk) * s_epb
                src1_block = src1[i1:i1 + s_epb].clone()
                if mode_name == "TENSOR_SCALAR":
                    rhs_block = torch.full((s_epb,), scalar_rhs, dtype=src1.dtype)
                else:
                    i2 = (r * src2_rep + b * src2_blk) * s_epb
                    rhs_block = src2[i2:i2 + s_epb].clone()
                di = (r * dst_rep + b * dst_blk) * s_epb
                dst[di:di + s_epb].copy_(torch.where(mask_block, src1_block, rhs_block.to(src1.dtype)))

    # ------------------------------------------------------------------
    # Mask ops
    # ------------------------------------------------------------------

    def _set_mask(self, a: Dict) -> None:
        low = int(a.get("low", 0)) & ((1 << 64) - 1)
        high = int(a.get("high", 0)) & ((1 << 64) - 1)
        for bit in range(64):
            self.current_mask[bit] = (low >> bit) & 1
            self.current_mask[64 + bit] = (high >> bit) & 1

    # ------------------------------------------------------------------
    # Sort ops (operate on full payload, no mask)
    # ------------------------------------------------------------------

    def _sort32(self, a: Dict) -> None:
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        idx_name = str(a["idx"])
        dst = self._get_tensor(dst_name)
        src = self._get_tensor(src_name)
        idx = self._get_tensor(idx_name)
        require_32b_aligned("sort32", "dst", dst_name, dst)
        require_32b_aligned("sort32", "src", src_name, src)
        require_32b_aligned("sort32", "idx", idx_name, idx)
        repeat = _int(a.get("repeat", 0), "repeat")
        _check_repeat_bound(repeat, "sort32")
        if src.dtype != torch.float32:
            raise TypeError("sort32 requires float32 src, got " + str(src.dtype))
        allowed_idx = [torch.int32]
        if hasattr(torch, "uint32"):
            allowed_idx.append(getattr(torch, "uint32"))
        if idx.dtype not in tuple(allowed_idx):
            raise TypeError("sort32 requires int32/uint32 idx, got " + str(idx.dtype))
        # sort32 reads 32 contiguous src + 32 idx per repeat, writes 64 (value/idx interleaved);
        # full payload, no mask. Bound each at its buffer end.
        self._guard_footprint("sort32", "dst", dst_name, repeat * 64)
        self._guard_footprint("sort32", "src", src_name, repeat * 32)
        self._guard_footprint("sort32", "idx", idx_name, repeat * 32)
        for rep in range(repeat):
            s0, i0, d0 = rep * 32, rep * 32, rep * 64
            block = src[s0:s0+32]
            iblock = idx[i0:i0+32]
            if iblock.dtype != torch.int32:
                iblock = iblock.view(torch.int32)
            order = torch.argsort(block, descending=True)
            dst[d0:d0+64:2] = block[order]
            dst[d0+1:d0+64:2] = iblock[order].view(torch.float32)

    def _mergesort4(self, a: Dict) -> None:
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst = self._get_tensor(dst_name)
        src = self._get_tensor(src_name)
        require_32b_aligned("mergesort4", "dst", dst_name, dst)
        require_32b_aligned("mergesort4", "src", src_name, src)
        lps = _int(a["length_per_seq"], "length_per_seq")
        repeat = _int(a.get("repeat", 0), "repeat")
        _check_repeat_bound(repeat, "mergesort4")
        epr = 8 * lps
        if src.dtype != torch.float32:
            raise TypeError("mergesort4 requires float32 src, got " + str(src.dtype))
        self._guard_footprint("mergesort4", "src", src_name, repeat * epr)
        self._guard_footprint("mergesort4", "dst", dst_name, repeat * epr)
        for rep in range(repeat):
            s = rep * epr
            block = src[s:s+epr].clone()
            even = block[0::2]
            odd = block[1::2]
            order = torch.argsort(even, descending=True)
            result = torch.empty_like(block)
            result[0::2] = even[order]
            result[1::2] = odd[order]
            dst[s:s+epr] = result

    def _mergesort_2seq(self, a: Dict) -> None:
        dst_name = str(a["dst"])
        src1_name = str(a["src1"])
        src2_name = str(a["src2"])
        dst = self._get_tensor(dst_name)
        src1 = self._get_tensor(src1_name)
        src2 = self._get_tensor(src2_name)
        require_32b_aligned("mergesort_2seq", "dst", dst_name, dst)
        require_32b_aligned("mergesort_2seq", "src1", src1_name, src1)
        require_32b_aligned("mergesort_2seq", "src2", src2_name, src2)
        s1 = _int(a["size1"], "size1")
        s2 = _int(a["size2"], "size2")
        if src1.dtype != torch.float32 or src2.dtype != torch.float32:
            raise TypeError("mergesort_2seq requires float32 src1/src2")
        if int(src1.numel()) < 2 * s1:
            raise MemoryError("mergesort_2seq src1 too small: need=" + str(2 * s1))
        if int(src2.numel()) < 2 * s2:
            raise MemoryError("mergesort_2seq src2 too small: need=" + str(2 * s2))
        if int(dst.numel()) < 2 * (s1 + s2):
            raise MemoryError("mergesort_2seq dst too small: need=" + str(2 * (s1 + s2)))
        b1 = src1[:2*s1].clone()
        b2 = src2[:2*s2].clone()
        even = torch.cat((b1[0::2], b2[0::2]))
        odd = torch.cat((b1[1::2], b2[1::2]))
        order = torch.argsort(even, descending=True)
        total = 2 * (s1 + s2)
        result = torch.empty(total, dtype=dst.dtype)
        result[0::2] = even[order]
        result[1::2] = odd[order]
        dst[:total] = result

    def _topk_radix(self, a: Dict) -> None:
        dst_values_name = str(a["dst_values"])
        dst_indices_name = str(a["dst_indices"])
        src_values_name = str(a["src_values"])
        src_indices_name = str(a["src_indices"])
        tmp_name = str(a["tmp"])
        dst_values = self._get_tensor(dst_values_name)
        dst_indices = self._get_tensor(dst_indices_name)
        src_values = self._get_tensor(src_values_name)
        src_indices = self._get_tensor(src_indices_name)
        tmp = self._get_tensor(tmp_name)
        k = _int(a["k"], "k")
        n = _int(a["n"], "n")
        aligned_n = _int(a["aligned_n"], "aligned_n")
        outter = _int(a.get("outter", 1), "outter")
        init_index = bool(a.get("init_index", True))
        largest = float(a.get("largest", 1)) > 0.0
        sorted_output = bool(a.get("sorted", True))

        if src_values.dtype != dst_values.dtype:
            raise TypeError("topk_radix src/dst value dtypes must match")
        if src_indices.dtype != torch.int32 or dst_indices.dtype != torch.int32:
            raise TypeError("topk_radix indices must use int32 tensors")
        if tmp.dtype != torch.uint8:
            raise TypeError("topk_radix tmp must use uint8 storage")
        if not (1 <= n <= aligned_n <= 4096):
            raise ValueError(
                "topk_radix requires 1 <= n <= aligned_n <= 4096, got "
                f"n={n}, aligned_n={aligned_n}"
            )
        if aligned_n % 32:
            raise ValueError("topk_radix aligned_n must align 32 values")
        if not (1 <= k <= n):
            raise ValueError(f"topk_radix requires 1 <= k <= n, got k={k}, n={n}")
        if outter <= 0:
            raise ValueError(f"topk_radix outter must be positive, got {outter}")
        value_k_pad = align_to(k, 32 // int(dst_values.element_size()))
        index_k_pad = align_to(k, 8)
        if src_values.numel() < outter * aligned_n:
            raise MemoryError("topk_radix src_values is smaller than outter * aligned_n")
        if init_index and src_indices.numel() < aligned_n:
            raise MemoryError("topk_radix src_indices is smaller than aligned_n")
        if dst_values.numel() < outter * value_k_pad:
            raise MemoryError("topk_radix dst_values lacks padded output rows")
        if dst_indices.numel() < outter * index_k_pad:
            raise MemoryError("topk_radix dst_indices lacks padded output rows")
        if tmp.numel() == 0:
            raise MemoryError("topk_radix tmp tensor cannot be empty")

        generated_indices = torch.arange(n, dtype=torch.int32)
        input_indices = src_indices[:n] if init_index else generated_indices
        for row in range(outter):
            src_offset = row * aligned_n
            value_dst_offset = row * value_k_pad
            index_dst_offset = row * index_k_pad
            values, positions = torch.topk(
                src_values[src_offset:src_offset + n], k,
                largest=largest, sorted=sorted_output,
            )
            dst_values[value_dst_offset:value_dst_offset + k] = values
            dst_indices[index_dst_offset:index_dst_offset + k] = input_indices[positions]

    # ------------------------------------------------------------------
    # Gather / Scatter — byte-offset semantics
    # ------------------------------------------------------------------

    def _transdata5hd(self, a: Dict) -> None:
        # AscendC TransDataTo5HD (b16): per repeat r, transpose the 16x16 tile
        # gathered from src rows i*srs + r*srep*16 into dst rows i*drs + r*drep*16.
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst = self._get_tensor(dst_name)
        src = self._get_tensor(src_name)
        require_32b_aligned("transdata5hd", "dst", dst_name, dst)
        require_32b_aligned("transdata5hd", "src", src_name, src)
        if dst.element_size() != 2 or src.element_size() != 2:
            raise TypeError("transdata5hd supports b16 dtypes only")
        repeat = _int(a.get("repeat", 1), "repeat")
        srs = _int(a.get("src_row_stride", 0), "src_row_stride")
        drs = _int(a.get("dst_row_stride", 16), "dst_row_stride")
        srep = _int(a.get("src_rep_stride", 1), "src_rep_stride")
        drep = _int(a.get("dst_rep_stride", 16), "dst_rep_stride")
        if not (1 <= repeat <= 255):
            raise ValueError("transdata5hd repeat must be in [1, 255], got " + str(repeat))
        if srs < 0 or drs < 0 or srep < 0 or drep < 0:
            raise ValueError("transdata5hd strides must be non-negative")
        if srs % 16 or drs % 16:
            raise ValueError("transdata5hd row strides must be multiples of 16 elements (32B rows)")
        span = (repeat - 1) * 16
        src_need = 15 * srs + span * srep + 16
        dst_need = 15 * drs + span * drep + 16
        if src_need > int(src.numel()):
            raise MemoryError(
                "transdata5hd src too small: need=" + str(src_need) + ", have=" + str(int(src.numel())))
        if dst_need > int(dst.numel()):
            raise MemoryError(
                "transdata5hd dst too small: need=" + str(dst_need) + ", have=" + str(int(dst.numel())))
        u16_src = src.view(torch.uint16)
        u16_dst = dst.view(torch.uint16)
        for r in range(repeat):
            tile = torch.stack([
                u16_src[i * srs + r * srep * 16: i * srs + r * srep * 16 + 16] for i in range(16)
            ])  # [16 rows, 16 cols]
            t = tile.t().contiguous()
            for i in range(16):
                u16_dst[i * drs + r * drep * 16: i * drs + r * drep * 16 + 16] = t[i]

    def _gather(self, a: Dict) -> None:
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        offset_name = str(a["offset"])
        dst = self._get_tensor(dst_name)
        src = self._get_tensor(src_name)
        offset = self._get_tensor(offset_name)
        require_32b_aligned("gather", "dst", dst_name, dst)
        require_32b_aligned("gather", "src", src_name, src)
        require_32b_aligned("gather", "offset", offset_name, offset)
        allowed = [torch.int32]
        if hasattr(torch, "uint32"):
            allowed.append(getattr(torch, "uint32"))
        if offset.dtype not in tuple(allowed):
            raise TypeError("gather requires uint32/int32 offset, got " + str(offset.dtype))
        elem_size = int(src.element_size())
        epb = 32 // elem_size
        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            start_idx = _int(a.get("start_idx", 0), "start_idx")
            if start_idx < 0:
                raise ValueError("gather start_idx must be non-negative, got " + str(start_idx))
            self._guard_footprint("gather", "offset", offset_name, count)
            self._guard_footprint("gather", "dst", dst_name, count)
            src_avail = self._alloc_avail(src_name)
            for i in range(count):
                byte_addr = start_idx + int(offset[i].item())
                if (byte_addr % elem_size) != 0:
                    raise ValueError(
                        "gather offset byte address must align with elem_size "
                        + str(elem_size) + ", got " + str(byte_addr)
                    )
                src_index = byte_addr // elem_size
                if src_index < 0 or src_index >= src_avail:
                    raise MemoryError(
                        "gather source index out of range: src_index=" + str(src_index)
                        + ", byte_addr=" + str(byte_addr)
                    )
                dst[i] = src[src_index]
            return
        repeat = _int(a.get("repeat", 0), "repeat")
        dst_rep = _int(a.get("dst_rep_stride", 8), "dst_rep_stride")
        start_idx = _int(a.get("start_idx", 0), "start_idx")
        if repeat < 0 or dst_rep < 0 or start_idx < 0:
            raise ValueError("gather requires non-negative repeat/dst_rep_stride/start_idx")
        _check_repeat_bound(repeat, "gather")
        if repeat == 0:
            return
        elems_per_repeat = epb * 8
        offset_need = repeat * elems_per_repeat
        dst_need = (repeat - 1) * dst_rep * epb + elems_per_repeat
        self._guard_footprint("gather", "offset", offset_name, offset_need)
        self._guard_footprint("gather", "dst", dst_name, dst_need)
        src_avail = self._alloc_avail(src_name)
        for r in range(repeat):
            dst_base = r * dst_rep * epb
            off_base = r * elems_per_repeat
            for i in range(elems_per_repeat):
                byte_addr = start_idx + int(offset[off_base + i].item())
                if (byte_addr % elem_size) != 0:
                    raise ValueError(
                        "gather offset byte address must align with elem_size "
                        + str(elem_size) + ", got " + str(byte_addr)
                    )
                src_index = byte_addr // elem_size
                if src_index < 0 or src_index >= src_avail:
                    raise MemoryError(
                        "gather source index out of range: src_index=" + str(src_index)
                        + ", byte_addr=" + str(byte_addr)
                    )
                dst[dst_base + i] = src[src_index]

    def _gather_block(self, a: Dict) -> None:
        # AscendC Gatherb: each repeat gathers a fixed 8 DataBlocks (the 256B
        # hardware vector width); one 32B-aligned byte offset per block.
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        offset_name = str(a["offset"])
        dst = self._get_tensor(dst_name)
        src = self._get_tensor(src_name)
        offset = self._get_tensor(offset_name)
        require_32b_aligned("gather_block", "dst", dst_name, dst)
        require_32b_aligned("gather_block", "src", src_name, src)
        require_32b_aligned("gather_block", "offset", offset_name, offset)
        allowed = [torch.int32]
        if hasattr(torch, "uint32"):
            allowed.append(getattr(torch, "uint32"))
        if offset.dtype not in tuple(allowed):
            raise TypeError("gather_block requires uint32/int32 offset, got " + str(offset.dtype))
        elem_size = int(src.element_size())
        epb = 32 // elem_size
        blocks_per_repeat = 8
        repeat = _int(a.get("repeat", 0), "repeat")
        dst_blk = _int(a.get("dst_blk_stride", 1), "dst_blk_stride")
        dst_rep = _int(a.get("dst_rep_stride", 8), "dst_rep_stride")
        if repeat < 0 or dst_blk < 0 or dst_rep < 0:
            raise ValueError("gather_block requires non-negative repeat/dst_blk_stride/dst_rep_stride")
        _check_repeat_bound(repeat, "gather_block")
        if repeat == 0:
            return
        offset_need = repeat * blocks_per_repeat
        dst_need = ((repeat - 1) * dst_rep + (blocks_per_repeat - 1) * dst_blk + 1) * epb
        self._guard_footprint("gather_block", "offset", offset_name, offset_need)
        self._guard_footprint("gather_block", "dst", dst_name, dst_need)
        src_avail = self._alloc_avail(src_name)
        for r in range(repeat):
            for k in range(blocks_per_repeat):
                byte_addr = int(offset[r * blocks_per_repeat + k].item())
                if (byte_addr % 32) != 0:
                    raise ValueError(
                        "gather_block offset must be 32B block-aligned, got " + str(byte_addr)
                    )
                src_index = byte_addr // elem_size
                if src_index < 0 or src_index + epb > src_avail:
                    raise MemoryError(
                        "gather_block source block out of range: src_index=" + str(src_index)
                        + ", byte_addr=" + str(byte_addr)
                    )
                dst_pos = (r * dst_rep + k * dst_blk) * epb
                dst[dst_pos:dst_pos + epb] = src[src_index:src_index + epb]

    def _scatter(self, a: Dict) -> None:
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        offset_name = str(a["offset"])
        dst = self._get_tensor(dst_name)
        src = self._get_tensor(src_name)
        offset = self._get_tensor(offset_name)
        require_32b_aligned("scatter", "dst", dst_name, dst)
        require_32b_aligned("scatter", "src", src_name, src)
        require_32b_aligned("scatter", "offset", offset_name, offset)
        allowed = [torch.int32]
        if hasattr(torch, "uint32"):
            allowed.append(getattr(torch, "uint32"))
        if offset.dtype not in tuple(allowed):
            raise TypeError("scatter requires uint32/int32 offset, got " + str(offset.dtype))
        elem_size = int(src.element_size())
        epb = 32 // elem_size
        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            start_idx = _int(a.get("start_idx", 0), "start_idx")
            if start_idx < 0:
                raise ValueError("scatter start_idx must be non-negative, got " + str(start_idx))
            self._guard_footprint("scatter", "offset", offset_name, count)
            self._guard_footprint("scatter", "src", src_name, count)
            dst_avail = self._alloc_avail(dst_name)
            for i in range(count):
                byte_addr = start_idx + int(offset[i].item())
                if (byte_addr % elem_size) != 0:
                    raise ValueError(
                        "scatter offset byte address must align with elem_size "
                        + str(elem_size) + ", got " + str(byte_addr)
                    )
                dst_index = byte_addr // elem_size
                if dst_index < 0 or dst_index >= dst_avail:
                    raise MemoryError(
                        "scatter dst index out of range: dst_index=" + str(dst_index)
                        + ", byte_addr=" + str(byte_addr)
                    )
                dst[dst_index] = src[i]
            return
        repeat = _int(a.get("repeat", 0), "repeat")
        src_rep = _int(a.get("src_rep_stride", 8), "src_rep_stride")
        start_idx = _int(a.get("start_idx", 0), "start_idx")
        if repeat < 0 or src_rep < 0 or start_idx < 0:
            raise ValueError("scatter requires non-negative repeat/src_rep_stride/start_idx")
        _check_repeat_bound(repeat, "scatter")
        if repeat == 0:
            return
        elems_per_repeat = epb * 8
        offset_need = repeat * elems_per_repeat
        src_need = (repeat - 1) * src_rep * epb + elems_per_repeat
        self._guard_footprint("scatter", "offset", offset_name, offset_need)
        self._guard_footprint("scatter", "src", src_name, src_need)
        dst_avail = self._alloc_avail(dst_name)
        for r in range(repeat):
            src_base = r * src_rep * epb
            off_base = r * elems_per_repeat
            for i in range(elems_per_repeat):
                byte_addr = start_idx + int(offset[off_base + i].item())
                if (byte_addr % elem_size) != 0:
                    raise ValueError(
                        "scatter offset byte address must align with elem_size "
                        + str(elem_size) + ", got " + str(byte_addr)
                    )
                dst_index = byte_addr // elem_size
                if dst_index < 0 or dst_index >= dst_avail:
                    raise MemoryError(
                        "scatter dst index out of range: dst_index=" + str(dst_index)
                        + ", byte_addr=" + str(byte_addr)
                    )
                dst[dst_index] = src[src_base + i]

    # ------------------------------------------------------------------
    # UB → UB copy
    # ------------------------------------------------------------------

    def _ub_to_ub(self, a: Dict) -> None:
        dst_name = str(a["dst"])
        src_name = str(a["src"])
        dst = self._get_tensor(dst_name)
        src = self._get_tensor(src_name)
        require_32b_aligned("ub_to_ub", "dst", dst_name, dst)
        require_32b_aligned("ub_to_ub", "src", src_name, src)
        if int(src.element_size()) != int(dst.element_size()):
            raise ValueError(
                "ub_to_ub requires identical element size, got src="
                + str(int(src.element_size())) + ", dst=" + str(int(dst.element_size()))
            )
        n_burst = _int(a.get("n_burst", 1), "n_burst")
        burst_len = _int(a.get("burst_len", 1), "burst_len")
        src_stride = _int(a.get("src_stride", 0), "src_stride")
        dst_stride = _int(a.get("dst_stride", 0), "dst_stride")
        if n_burst < 0 or burst_len < 0 or src_stride < 0 or dst_stride < 0:
            raise ValueError("ub_to_ub requires non-negative n_burst, burst_len, src_stride, and dst_stride")
        elem = int(dst.element_size())
        burst_elems = burst_len * 32 // elem
        src_step = (burst_len + src_stride) * 32 // elem
        dst_step = (burst_len + dst_stride) * 32 // elem
        if n_burst > 0:
            src_need = (n_burst - 1) * src_step + burst_elems
            dst_need = (n_burst - 1) * dst_step + burst_elems
            require_flat_elements("ub_to_ub", "src", src_name, src, src_need)
            require_flat_elements("ub_to_ub", "dst", dst_name, dst, dst_need)
        for i in range(n_burst):
            dst[i*dst_step:i*dst_step+burst_elems].copy_(src[i*src_step:i*src_step+burst_elems])

    def _call_micro(self, a: Dict) -> None:
        from .pipe_micro import MicroRuntime
        micro_def = a.get("micro_def")
        if micro_def is None:
            raise ValueError("call_micro missing micro_def")
        # call_micro enters the pointer-semantics micro runtime.
        tensor_views = a.get("tensor_views", {})
        tensor_offsets_bytes = a.get("tensor_offsets_bytes", {})
        var_values = a.get("var_values", {})
        rt = MicroRuntime()
        rt._core_idx = getattr(self, "core_idx", -1)  # for print_reg debug output
        # Hand the current vector-mask SPR into the vf so MoveMask<T>() (move_mask_spr) can read it.
        rt.execute_call_micro(micro_def, tensor_views, var_values, self.memory_store,
                              tensor_offsets_bytes, spr_mask=self.current_mask)

    def _call_simt(self, a: Dict) -> None:
        from .pipe_simt import SimtRuntime
        simt_def = a.get("simt_def")
        if simt_def is None:
            raise ValueError("call_simt missing simt_def")
        # call_simt enters the logical-indexing SIMT runtime.
        tensor_views = a.get("tensor_views", {})
        var_values = a.get("var_values", {})
        block_idx = int(a.get("block_idx", 0))
        block_num = int(a.get("block_num", 1))
        thread_num = int(a.get("thread_num", 1024))
        rt = SimtRuntime()
        rt.execute_call_simt(
            simt_def,
            tensor_views,
            var_values,
            self.memory_store,
            block_idx=block_idx,
            block_num=block_num,
            thread_num=thread_num,
        )
        a["_simt_instruction_count"] = int(rt.last_instruction_count)


# ------------------------------------------------------------------
# Op name canonicalization (vec_v_xxx → xxx)
# ------------------------------------------------------------------

_CANONICAL_OP: Dict[str, str] = {
    "vec_v_add": "add", "vec_v_sub": "sub", "vec_v_mul": "mul", "vec_v_div": "div",
    "vec_v_max": "vmax", "vec_v_min": "vmin", "vec_v_abs": "abs", "vec_v_relu": "relu",
    "vabs": "abs",
    "vec_v_add_scalar": "adds", "vec_v_mul_scalar": "muls",
    "vec_v_dup": "dup", "vec_v_cast": "cast",
    "vec_v_exp": "exp", "vec_v_ln": "ln", "vec_v_rec": "rec",
    "vec_v_sqrt": "sqrt", "vec_v_rsqrt": "rsqrt",
    "vec_v_not": "vnot", "vec_v_and": "vand", "vec_v_or": "vor",
    "vec_v_cmax": "cmax", "vec_v_cmin": "cmin", "vec_v_cadd": "cadd",
    "vec_v_cgmax": "cgmax", "vec_v_cgmin": "cgmin", "vec_v_cgadd": "cgadd",
    "vec_v_brcb": "brcb", "vec_v_muladddst": "muladddst",
    "vec_v_set_mask": "set_mask", "vec_v_reset_mask": "reset_mask",
    "vec_v_set_mask_by_count": "set_mask_by_count",
    "vec_v_compare": "compare", "vec_v_compare_scalar": "compare_scalar",
    "vec_v_select": "select", "vec_v_cpadd": "cpadd",
}

# Binary ops: f(src1, src2) → result. vand/vor preserve dtype; others use compute dtype.
_BINARY_OPS: Dict[str, Callable] = {
    "add": lambda a, b: a + b,
    "sub": lambda a, b: a - b,
    "mul": lambda a, b: a * b,
    "div": lambda a, b: a / b,
    "vmax": lambda a, b: torch.maximum(a, b),
    "vmin": lambda a, b: torch.minimum(a, b),
    "vand": lambda a, b: _bitwise_binary("vand", a, b),
    "vor": lambda a, b: _bitwise_binary("vor", a, b),
}

# Unary ops: f(src) → result. vnot has dtype-preserving bitwise fallback; dispatched separately.
_UNARY_OPS: Dict[str, Callable] = {
    "abs": lambda x: torch.abs(x),
    "relu": lambda x: torch.clamp(x, min=0),
    "exp": lambda x: torch.exp(x),
    "ln": lambda x: torch.log(x),
    "rec": lambda x: 1.0 / x,
    "sqrt": lambda x: torch.sqrt(x),
    "rsqrt": lambda x: torch.rsqrt(x),
}

# Scalar ops: f(src, scalar) → result. axpy needs dst snapshot, dispatched separately.
_SCALAR_OPS: Dict[str, Callable] = {
    "adds": lambda x, s: x + s,
    "muls": lambda x, s: x * s,
    "vmaxs": lambda x, s: torch.clamp(x, min=s),
    "vmins": lambda x, s: torch.clamp(x, max=s),
    "lrelu": lambda x, s: torch.where(x > 0, x, x * s),
}

_SHIFT_OPS = frozenset(("shiftls", "shiftrs"))

# Reduce ops (cpadd has its own branch, not in this dict)
_REDUCE_OPS: Dict[str, Callable] = {
    "cmax": lambda x: torch.max(x),
    "cmin": lambda x: torch.min(x),
    "cadd": lambda x: torch.sum(x),
    "cgmax": lambda x: torch.max(x),
    "cgmin": lambda x: torch.min(x),
    "cgadd": lambda x: torch.sum(x),
}

# Compare modes: uppercase keys matching CompareModeType enum names; return bool (for bit-pack).
def _vec_compare_ne(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    result = a != b
    if a.dtype.is_floating_point or b.dtype.is_floating_point:
        nan_mask = torch.isnan(a) | torch.isnan(b)
        if bool(nan_mask.any().item()):
            result = result & ~nan_mask
    return result


_CMP_MODES: Dict[str, Callable] = {
    "EQ": lambda a, b: a == b,
    # Public A2 vec compare treats NaN as unordered false even for NE.
    "NE": _vec_compare_ne,
    "LT": lambda a, b: a < b,
    "LE": lambda a, b: a <= b,
    "GT": lambda a, b: a > b,
    "GE": lambda a, b: a >= b,
}
