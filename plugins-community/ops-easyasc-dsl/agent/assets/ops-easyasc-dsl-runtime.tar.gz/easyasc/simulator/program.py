from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class PipeTask:
    """Unit of work submitted to a pipe thread's mailbox."""

    pipe_name: str
    opname: str
    args: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    error: Optional[str] = None
    earliest_start_cycle: float = 0.0
    start_cycle: float = 0.0
    end_cycle: float = 0.0
    estimated_cycles: float = 0.0


@dataclass
class ControlInstruction:
    """One instruction in a lane's instruction stream.

    - Pipe ops (pipe_name != ""): PipeS converts to PipeTask and dispatches.
    - Scalar ops (create_var, var_add, ...): PipeS executes directly.
    - Control flow (start_if, start_loop, ...): PipeS interprets.
    - Sync ops (bar_all, setflag, ...): PipeS coordinates.
    """

    opname: str
    args: Dict[str, Any] = field(default_factory=dict)
    pipe_name: str = ""

    def is_pipe_op(self) -> bool:
        return self.pipe_name != ""


@dataclass
class LaneProgram:
    """Instruction stream for one lane (cube, vec0, vec1)."""

    lane_name: str
    pipe_names: List[str] = field(default_factory=list)
    instructions: List[ControlInstruction] = field(default_factory=list)


@dataclass
class KernelProgram:
    """Top-level program: what to simulate."""

    name: str
    core_count: int
    lane_programs: List[LaneProgram] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_lane_program(self, lane_name: str) -> LaneProgram:
        for lp in self.lane_programs:
            if lp.lane_name == lane_name:
                return lp
        raise KeyError("lane program not found: " + lane_name)
