import inspect
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Sequence, Union

# shape_bindings sentinel: pin a GM dimension to its literal size.
LITERAL_SHAPE_DIM = -1


if TYPE_CHECKING:
    from .kernelbase.kernelbase import KernelBase


def _tail_log_lines(log_path: str, max_lines: int = 40) -> str:
    with open(log_path, "r", encoding="utf-8", errors="replace") as log_file:
        lines = log_file.readlines()
    tail = lines[-max_lines:]
    return "".join(tail).rstrip()


def _open_progress_stream():
    import sys

    try:
        return open("/dev/tty", "w", encoding="utf-8", errors="replace"), True
    except OSError:
        if sys.stderr.isatty():
            return sys.stderr, False
    return None, False


def _print_progress(progress_file, msg: str) -> None:
    if progress_file is not None:
        print(msg, end="", file=progress_file, flush=True)


class _NpuExecLock:
    """Cross-process advisory lock serializing the on-board NPU run step (r.sh).

    Two concurrent ``OpExec(simulator=False)`` runs on the same board otherwise
    contend for the single NPU and corrupt each other's timing/results. This
    lock makes them serial by construction.

    When ``fcntl`` is available (real Linux board), the lock **fails closed**:
    if the lockfile cannot be opened or locked, a ``RuntimeError`` is raised.
    Set ``EASYASC_NPU_LOCK_ALLOW_DEGRADE=1`` to revert to the old best-effort
    behaviour.  When ``fcntl`` is unavailable (non-Unix test/dev), the lock
    degrades silently as before.

    Override the lockfile path via ``EASYASC_NPU_LOCK``.

    The wait is bounded so a hung run cannot block a board forever, but 1800 s
    is only the right bound when everyone on the box waits the same way. Other
    harnesses on this board take the *same* lockfile from the shell with
    ``flock -w 7200``, so a legitimate 40-minute sweep starves any ``OpExec``
    behind it — which surfaces as "NPU busy ... check for a hung run" pointing
    at a run that is perfectly healthy. Raise the wait with
    ``EASYASC_NPU_LOCK_TIMEOUT_S`` to match the neighbours rather than reading
    that message as a fault.
    """

    def __init__(self, timeout: float = None) -> None:
        import os

        if timeout is None:
            raw = os.environ.get("EASYASC_NPU_LOCK_TIMEOUT_S", "")
            try:
                timeout = float(raw)
            except ValueError:
                timeout = 1800.0
            if timeout <= 0:
                timeout = 1800.0
        self._timeout = timeout
        self._fd = None

    def __enter__(self):
        import os
        import time

        try:
            import fcntl
        except ImportError:
            self._fd = None
            return self
        _allow_degrade = os.environ.get("EASYASC_NPU_LOCK_ALLOW_DEGRADE", "0").strip() == "1"
        lock_path = os.environ.get("EASYASC_NPU_LOCK", "/tmp/easyasc_npu0.lock")
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o666)
        except OSError as exc:
            if _allow_degrade:
                self._fd = None
                return self
            raise RuntimeError(
                f"Failed to open NPU lockfile {lock_path}: {exc}. "
                "Set EASYASC_NPU_LOCK_ALLOW_DEGRADE=1 to skip serialization, "
                "or fix the lockfile path with EASYASC_NPU_LOCK."
            ) from exc
        start = time.time()
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.time() - start > self._timeout:
                    os.close(fd)
                    raise RuntimeError(
                        f"NPU busy: another easyasc on-board run has held {lock_path} "
                        f"for >{self._timeout:.0f}s. Serialized to avoid contaminated "
                        f"timing/results; check for a hung run."
                    )
                time.sleep(0.5)
        self._fd = fd
        return self

    def __exit__(self, *exc):
        import os

        if self._fd is not None:
            try:
                import fcntl

                fcntl.flock(self._fd, fcntl.LOCK_UN)
            finally:
                os.close(self._fd)
                self._fd = None
        return False


def _source_fingerprint(base_dir: str, aux_dirs, tag: str) -> str:
    """SHA-256 over the freshly generated kernel SOURCES (not build artifacts).

    ``generate()`` re-emits the sources every call, but a reused ``out_dir``
    keeps a stale ``build_out/`` that b.sh's incremental cmake then relinks —
    a sim-passes / HW-link-fails trap. Comparing this fingerprint to a stamp
    lets the caller force a clean rebuild only when the source actually changed.
    """
    import hashlib
    import os

    src_ext = (".cpp", ".h", ".hpp", ".cce", ".cmake")
    skip = ("build_out", "/build", "/input", "/output", "/traces", "/PROF", "CMakeFiles")
    files = []
    for root in [base_dir, *aux_dirs]:
        if not root or not os.path.isdir(root):
            continue
        for dpath, _dirs, fnames in os.walk(root):
            norm = dpath.replace(os.sep, "/")
            if any(s in norm for s in skip):
                continue
            for fn in fnames:
                if fn.endswith(src_ext) or fn == "CMakeLists.txt":
                    files.append(os.path.join(dpath, fn))
    h = hashlib.sha256()
    h.update(tag.encode())
    for p in sorted(files):
        try:
            with open(p, "rb") as fh:
                data = fh.read()
        except OSError:
            continue
        h.update(os.path.relpath(p, base_dir).replace(os.sep, "/").encode())
        h.update(b"\0")
        h.update(data)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Board-run watchdog helpers
# ---------------------------------------------------------------------------

_DEFAULT_RUN_TIMEOUT_S = 600.0
_DEFAULT_IDLE_SAMPLES = 3
_DEFAULT_IDLE_INTERVAL_S = 1.0
_SAFETY_OVERRIDE_ENV = "EASYASC_NPU_SAFETY_OVERRIDE"
_TIMEOUT_ENV = "EASYASC_NPU_RUN_TIMEOUT"
_IDLE_SAMPLES_ENV = "EASYASC_NPU_IDLE_SAMPLES"
_IDLE_INTERVAL_ENV = "EASYASC_NPU_IDLE_INTERVAL"
_CARD_ID_ENV = "EASYASC_NPU_CARD_ID"
_LOCK_OVERRIDE_ENV = "EASYASC_NPU_LOCK_ALLOW_DEGRADE"


def _terminate_process_group(pgid: int, progress_file=None) -> None:
    """Kill *pgid* process group: SIGTERM, bounded grace, then SIGKILL.

    A D-state descendant may survive SIGKILL; the caller must report that
    possibility separately.
    """
    import errno
    import os
    import signal
    import time

    _print_progress(progress_file, f"\n[watchdog] terminating process group {pgid}...\n")
    try:
        os.killpg(pgid, signal.SIGTERM)
    except OSError as exc:
        if exc.errno != errno.ESRCH:
            _print_progress(progress_file, f"[watchdog] SIGTERM failed: {exc}\n")

    grace_s = 3.0
    deadline = time.time() + grace_s
    while time.time() < deadline:
        try:
            os.killpg(pgid, 0)
        except OSError:
            _print_progress(progress_file, "[watchdog] process group exited after SIGTERM\n")
            return
        time.sleep(0.2)

    _print_progress(progress_file, f"[watchdog] SIGTERM grace expired; sending SIGKILL to pg {pgid}\n")
    try:
        os.killpg(pgid, signal.SIGKILL)
    except OSError as exc:
        if exc.errno != errno.ESRCH:
            _print_progress(progress_file, f"[watchdog] SIGKILL failed: {exc}\n")
    # At this point the group may still exist (D-state); do not claim clean.


# ---------------------------------------------------------------------------
# NPU card-id detection
# ---------------------------------------------------------------------------

def _detect_npu_card_id():
    """Return the NPU card id to use for ``npu-smi`` queries.

    Resolution order:
      1. ``EASYASC_NPU_CARD_ID`` env var (explicit).
      2. ``npu-smi info -l`` auto-detect: if exactly one card is present,
         use its id.
      3. Fail with a clear message otherwise.

    Raises ``RuntimeError`` if no card can be determined.
    """
    import os
    import subprocess
    import re

    # 1. Explicit env var
    explicit = os.environ.get(_CARD_ID_ENV, "").strip()
    if explicit:
        if not explicit.isdigit():
            raise ValueError(
                f"{_CARD_ID_ENV} must be a non-negative integer, got {explicit!r}"
            )
        return explicit

    # 2. Auto-detect
    try:
        list_out = subprocess.check_output(
            ["npu-smi", "info", "-l"],
            stderr=subprocess.STDOUT,
            timeout=10,
        ).decode("utf-8", errors="replace")
    except FileNotFoundError:
        raise RuntimeError(
            "npu-smi not found on PATH. Cannot detect NPU card id. "
            f"Set {_CARD_ID_ENV} to the card id or {_SAFETY_OVERRIDE_ENV}=1 "
            "to bypass the board-idle check entirely."
        )
    except subprocess.CalledProcessError as exc:
        output = exc.output.decode("utf-8", errors="replace") if exc.output else "(no output)"
        raise RuntimeError(
            f"npu-smi info -l failed (return code {exc.returncode}).\n{output}"
        ) from None
    except subprocess.TimeoutExpired:
        raise RuntimeError("npu-smi info -l timed out (10 s). Board may be unresponsive.")

    ids = re.findall(r"NPU\s+ID\s*:\s*(\d+)", list_out)
    if len(ids) == 1:
        return ids[0]
    if len(ids) == 0:
        raise RuntimeError(
            f"No NPU cards found in npu-smi info -l output:\n{list_out}\n"
            f"Set {_CARD_ID_ENV} to the card id."
        )
    raise RuntimeError(
        f"{len(ids)} NPU cards detected ({', '.join(ids)}); cannot auto-select. "
        f"Set {_CARD_ID_ENV} to the desired card id."
    )


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def _board_idle_config():
    """Return (timeout_s, samples, interval_s, safety_override) from env.

    Validates values and raises ``ValueError`` on invalid config.
    """
    import os

    timeout_s = float(os.environ.get(_TIMEOUT_ENV, str(_DEFAULT_RUN_TIMEOUT_S)))
    samples = int(os.environ.get(_IDLE_SAMPLES_ENV, str(_DEFAULT_IDLE_SAMPLES)))
    interval_s = float(os.environ.get(_IDLE_INTERVAL_ENV, str(_DEFAULT_IDLE_INTERVAL_S)))
    override = os.environ.get(_SAFETY_OVERRIDE_ENV, "0").strip() == "1"

    import math

    if not (math.isfinite(timeout_s) and timeout_s > 0):
        raise ValueError(
            f"{_TIMEOUT_ENV} must be a finite positive number, got {timeout_s}"
        )
    if samples < 1:
        raise ValueError(
            f"{_IDLE_SAMPLES_ENV} must be >= 1, got {samples}"
        )
    if not (math.isfinite(interval_s) and interval_s >= 0):
        raise ValueError(
            f"{_IDLE_INTERVAL_ENV} must be a finite non-negative number, got {interval_s}"
        )
    return timeout_s, samples, interval_s, override


# ---------------------------------------------------------------------------
# Board-idle precondition
# ---------------------------------------------------------------------------

def _check_board_idle(samples=3, interval_s=1.0, card_id=None):
    """Require *samples* consecutive idle ``npu-smi`` readings on *card_id*.

    "Idle" means:
      - AICore utilization is 0%.
      - The process table shows no processes owning the device.

    Two output formats are supported for the usages call:
      - Key/value (910B3):  ``Aicore Usage Rate(%) : 0``
      - Table:              ``| AICore (%)  | …`` header with pipe-delimited rows

    Process info is read from general ``npu-smi info`` output (which on
    910B3 includes a ``No running processes`` line, and on other boards
    may include per-card process tables).

    Returns ``True`` on success. Raises ``RuntimeError`` on failure.
    The ``npu-smi`` binary must be on ``PATH``.
    """
    import subprocess
    import time
    import re

    if card_id is None:
        card_id = "0"  # fallback for tests that don't detect

    for attempt in range(1, samples + 1):
        # ---- utilization ----
        try:
            usage_out = subprocess.check_output(
                ["npu-smi", "info", "-t", "usages", "-i", card_id],
                stderr=subprocess.STDOUT,
                timeout=10,
            ).decode("utf-8", errors="replace")
        except FileNotFoundError:
            raise RuntimeError(
                "npu-smi not found on PATH. Cannot perform board-idle check. "
                f"Set {_SAFETY_OVERRIDE_ENV}=1 if this environment has no npu-smi."
            )
        except subprocess.CalledProcessError as exc:
            output = exc.output.decode("utf-8", errors="replace") if exc.output else "(no output)"
            raise RuntimeError(
                f"npu-smi usages -i {card_id} failed (return code {exc.returncode}).\n{output}"
            ) from None
        except subprocess.TimeoutExpired:
            raise RuntimeError("npu-smi usages command timed out (10 s). Board may be unresponsive.")

        aicore_pct = _parse_aicore_usage(usage_out)
        if aicore_pct is None:
            raise RuntimeError(
                f"Could not parse AICore utilization from npu-smi usages output:\n{usage_out}"
            )

        # ---- process table (from general npu-smi info) ----
        try:
            info_out = subprocess.check_output(
                ["npu-smi", "info"],
                stderr=subprocess.STDOUT,
                timeout=10,
            ).decode("utf-8", errors="replace")
        except FileNotFoundError:
            raise RuntimeError(
                "npu-smi not found on PATH for process check. "
                f"Set {_SAFETY_OVERRIDE_ENV}=1 if this environment has no npu-smi."
            )
        except subprocess.CalledProcessError as exc:
            output = exc.output.decode("utf-8", errors="replace") if exc.output else "(no output)"
            raise RuntimeError(
                f"npu-smi info failed (return code {exc.returncode}).\n{output}"
            ) from None
        except subprocess.TimeoutExpired:
            raise RuntimeError("npu-smi info command timed out (10 s). Board may be unresponsive.")

        has_processes = _parse_process_table(info_out, card_id)
        if has_processes is None:
            raise RuntimeError(
                f"Could not determine process state from npu-smi info output:\n{info_out}"
            )

        if aicore_pct == 0.0 and not has_processes:
            if attempt < samples:
                time.sleep(interval_s)
            continue

        # Not idle
        evidence = [f"sample {attempt}/{samples}: AICore={aicore_pct}%"]
        if has_processes:
            evidence.append("processes present")
            evidence.append(f"npu-smi info output:\n{info_out}")
        raise RuntimeError(
            f"Board is not idle (required {samples} consecutive idle samples). "
            + "; ".join(evidence)
            + f"\nSet {_SAFETY_OVERRIDE_ENV}=1 to bypass this check."
        )

    return True


def _parse_aicore_usage(output: str):
    """Extract AICore utilization from ``npu-smi usages`` output.

    Supports two formats:
      - Key/value (910B3): ``Aicore Usage Rate(%) : 0``
      - Table: ``| AICore (%) | …`` header + pipe-delimited data rows

    Returns ``float`` or ``None``.
    """
    import re

    # Format 1: key/value line (910B3)
    m = re.search(r"Aicore\s+Usage\s+Rate\s*\(\s*%\s*\)\s*:\s*(\d+(?:\.\d+)?)", output)
    if m:
        return float(m.group(1))

    # Format 2: table
    lines = output.splitlines()
    header_col = -1
    for line in lines:
        m2 = re.search(r"AICore\b", line)
        if m2:
            prefix = line[:m2.start()]
            header_col = prefix.count("|")
            break

    if header_col < 0:
        return None

    for line in lines:
        if not line.strip().startswith("|"):
            continue
        if "+" in line and "-" in line:
            continue
        if "NPU" in line and ("AICore" in line or "Name" in line):
            continue
        cols = line.split("|")
        if len(cols) > header_col:
            val = cols[header_col].strip()
            try:
                return float(val)
            except ValueError:
                return None
    return None


def _parse_process_table(output: str, card_id: str):
    """Check whether ``npu-smi info`` output shows processes on *card_id*.

    Returns:
      ``False`` — confirmed: no processes for this card.
      ``True``  — confirmed: at least one process owns this card.
      ``None``  — output is ambiguous (cannot determine).

    Handles:
      - ``No running processes found in NPU <id>`` → False
      - Pipe-delimited rows (``| NPU Chip | Process id | ... |``) with
        the card's NPU column and a numeric PID → True
      - Plain-space rows (``<npu> <pid> <name>``) with numeric PID → True
    """
    import re

    # Quick positive: explicit "no processes" message for our card
    if re.search(
        rf"No\s+running\s+processes\s+found\s+in\s+NPU\s+{re.escape(card_id)}\b",
        output,
    ):
        return False

    # Locate the process section.  Two header styles:
    #   pipe:  | NPU Chip | Process id | Process name | ...
    #   plain: NPU   Process ID   Process Name
    lines = output.splitlines()
    in_section = False
    pipe_style = False
    for line in lines:
        stripped = line.strip()
        # Header detection
        if not in_section:
            if re.search(r"Process\s+(id|ID)", stripped):
                in_section = True
                pipe_style = "|" in line
                continue
            continue

        # Inside the process section
        if not stripped:
            continue

        # "No running processes" line anywhere in section → check if it names our card
        if "No running processes" in stripped:
            if re.search(rf"No\s+running\s+processes\s+found\s+in\s+NPU\s+{re.escape(card_id)}\b", stripped):
                return False
            continue  # mentions a different card, keep scanning for ours

        if pipe_style:
            # Pipe-delimited: | NPU Chip | Process id | ... |
            # Example: | 7 0 | 12345 | my_training | 1024 |
            if not stripped.startswith("|"):
                continue
            # Skip separator lines like |----|----|
            if "-" in stripped and stripped.count("-") > 3:
                continue
            cols = [c.strip() for c in stripped.split("|") if c.strip()]
            if len(cols) < 2:
                continue
            # First col is NPU Chip (e.g. "7 0"); extract device id
            npu_col = cols[0]
            pid_col = cols[1] if len(cols) > 1 else ""
            # NPU column may be "7 0" (chip) — extract first token
            device_id = npu_col.split()[0] if npu_col.split() else ""
            if device_id == card_id and pid_col.isdigit():
                return True
            # If it's a different card with a process, that's not ours.
            # But we shouldn't return False here because there might be
            # another row for our card later.
            continue
        else:
            # Plain-space format
            if stripped.startswith("Process") or stripped.startswith("NPU"):
                continue
            parts = stripped.split()
            if len(parts) >= 2:
                device_id = parts[0]
                pid_str = parts[1] if len(parts) > 1 else ""
                if device_id == card_id and pid_str.isdigit():
                    return True
                # Different card — continue scanning
                continue

    # If we entered the process section and found nothing for our card,
    # we cannot confirm the card is idle — fail closed.
    if in_section:
        return None

    # We never found a process section or a "no processes" message.
    # The output is ambiguous — caller must fail closed.
    return None


# ---------------------------------------------------------------------------
# NPU run orchestrator
# ---------------------------------------------------------------------------

def _run_npu_script(script_path: str, log_path: str, timeout_s=None, idle_samples=None, idle_interval_s=None) -> None:
    """Run *script_path* with bounded watchdog and board-idle precondition.

    Caller must already hold ``_NpuExecLock``.

    Completion evidence is printed only on a successful (non-timeout,
    nonzero-exit) run.  A timeout or nonzero-exit is reported via the
    ``RuntimeError`` already raised by ``_run_bash_with_progress``.
    """
    import os
    import time

    # Always read the safety override from the environment — it is an
    # escape hatch that must work regardless of explicit parameters.
    cfg_timeout, cfg_samples, cfg_interval, override = _board_idle_config()
    if timeout_s is None:
        timeout_s = cfg_timeout
    if idle_samples is None:
        idle_samples = cfg_samples
    if idle_interval_s is None:
        idle_interval_s = cfg_interval

    # Board-idle precondition — card detection and npu-smi probing only
    # when the safety override is NOT set.
    if not override:
        card_id = _detect_npu_card_id()
        _check_board_idle(samples=idle_samples, interval_s=idle_interval_s, card_id=card_id)
    else:
        print(f"[watchdog] {_SAFETY_OVERRIDE_ENV}=1: skipping board-idle check")

    start_ts = time.time()
    _run_bash_with_progress(script_path, log_path, timeout=timeout_s)
    elapsed = time.time() - start_ts
    # Completion evidence — only printed on success
    print(f"[easyasc] r.sh completed: script={script_path} elapsed={elapsed:.3f}s log={log_path}")


def _run_bash_with_progress(script_path: str, log_path: str, timeout: Optional[float] = None) -> None:
    """Execute *script_path* via ``bash`` and stream progress to tty.

    If *timeout* is given, the child is started in its own process group
    (``start_new_session=True``) and on timeout SIGTERM/SIGKILL are sent
    to the whole group, followed by a child reap attempt.
    Sets ``_run_bash_with_progress._last_pgid`` for external access.
    """
    import os
    import signal
    import subprocess
    import time

    _run_bash_with_progress._last_pgid = None

    if not os.path.exists(script_path) or not os.path.isfile(script_path):
        raise FileNotFoundError(f"{script_path} does not exist or is not a file, cannot execute")

    use_pgroup = timeout is not None
    progress_file, close_progress = _open_progress_stream()
    try:
        with open(log_path, "w", encoding="utf-8") as log_file:
            popen_kwargs: Dict[str, Any] = {}
            if use_pgroup:
                popen_kwargs["start_new_session"] = True
            proc = subprocess.Popen(
                ["bash", script_path],
                stdout=log_file,
                stderr=log_file,
                **popen_kwargs,
            )
            if use_pgroup:
                pgid = proc.pid
                _run_bash_with_progress._last_pgid = pgid
            start_ts = time.time()
            bar_width = 24
            while True:
                ret = proc.poll()
                elapsed = time.time() - start_ts
                if use_pgroup and elapsed > timeout:
                    _print_progress(progress_file, "\r" + " " * (bar_width + 40) + "\r")
                    _terminate_process_group(pgid, progress_file)
                    # Reap the immediate child after group kill; a D-state
                    # descendant in the group may still exist.
                    residual = ""
                    try:
                        proc.wait(timeout=2.0)
                    except subprocess.TimeoutExpired:
                        residual = (
                            f" The child process {proc.pid} did not exit within 2 s"
                            " after group signals — a descendant may be in D-state."
                        )
                    tail = _tail_log_lines(log_path)
                    detail = f"\nLast log lines:\n{tail}" if tail else "\nLog was empty."
                    raise RuntimeError(
                        f"bash {script_path} timed out after {elapsed:.1f}s "
                        f"(limit {timeout:.0f}s)."
                        f" Termination signals were sent to process group {pgid}."
                        f"{residual}"
                        f" Log: {log_path}{detail}"
                    )
                pos = int(elapsed * 8) % (2 * bar_width)
                if pos >= bar_width:
                    pos = 2 * bar_width - pos - 1
                bar = [" "] * bar_width
                bar[pos] = "#"
                msg = f"\r[{''.join(bar)}] bash {script_path} running... {elapsed:6.1f}s"
                _print_progress(progress_file, msg)
                if ret is not None:
                    break
                time.sleep(0.2)
            _print_progress(progress_file, "\r" + " " * (bar_width + 40) + "\r")
            if ret != 0:
                tail = _tail_log_lines(log_path)
                detail = f"\nLast log lines:\n{tail}" if tail else "\nLog was empty."
                raise RuntimeError(
                    f"bash {script_path} failed with return code {ret}. Log: {log_path}{detail}"
                )
    finally:
        if close_progress:
            progress_file.close()

    # Print out the profiled elapsed time
    for line in open(log_path, "r", encoding="utf-8", errors="replace"):
        if line.startswith('---- N_TESTS'):
            print(line)


def _run_cmd_with_progress(*args: str, log_path: str, cwd: Optional[str]=None) -> None:
    import subprocess
    import time

    progress_file, close_progress = _open_progress_stream()
    try:
        with open(log_path, "w", encoding="utf-8") as log_file:
            proc = subprocess.Popen(
                args,
                stdout=log_file,
                stderr=log_file,
                cwd=cwd,
            )
            start_ts = time.time()
            bar_width = 24
            while True:
                ret = proc.poll()
                elapsed = time.time() - start_ts
                pos = int(elapsed * 8) % (2 * bar_width)
                if pos >= bar_width:
                    pos = 2 * bar_width - pos - 1
                bar = [" "] * bar_width
                bar[pos] = "#"
                msg = f"\r[{''.join(bar)}] [{' '.join(args)}] running... {elapsed:6.1f}s"
                _print_progress(progress_file, msg)
                if ret is not None:
                    break
                time.sleep(0.2)
            _print_progress(progress_file, "\r" + " " * (bar_width + 40) + "\r")
            if ret != 0:
                tail = _tail_log_lines(log_path)
                detail = f"\nLast log lines:\n{tail}" if tail else "\nLog was empty."
                raise RuntimeError(
                    f"[{' '.join(args)}] failed with return code {ret}. Log: {log_path}{detail}"
                )
        _print_progress(progress_file, "\n")
    finally:
        if close_progress:
            progress_file.close()


class TorchApiManager:
    def __init__(
        self,
        out_dir: str = "",
        cann_path: Optional[str] = None,
        custom_op_path: Optional[str] = None,
    ) -> None:
        import os

        self._ops: Dict[str, "OpExec"] = {}
        self.out_dir = out_dir
        self.cann_path = cann_path
        if custom_op_path is None:
            custom_op_path = "./"
        if not isinstance(custom_op_path, str):
            raise TypeError(f"custom_op_path must be str, got: {type(custom_op_path)}")
        self.custom_op_path = os.path.abspath(custom_op_path)
        self.compiled = False
        self.mod = None 
        self.initialize()

    def initialize(self) -> None:
        pass

    def load_lib(self):
        import os
        import sys
        import glob
        import subprocess
        import importlib

        if self.mod is not None:
            print('Module is already loaded. Will skip compilation')
            return 

        f = os.path.abspath(self.out_dir)
        try:
            f = glob.glob(os.path.join(f, 'custop_torchapi.cpy*'))[0]
        except:
            print('No pybind library found. Need to re-compile')
            return 
        res = subprocess.run(['nm', '-D', '--defined-only', '-C', f], capture_output=True, text=True)
        res = res.stdout 
        res = res.split('\n')

        defined_fns = []
        for line in res:
            if ' T ' in line:
                name = line.split(' T ')[-1].split('(')[0]
                defined_fns.append(name)
        
        for name in self._ops:
            if name not in defined_fns:
                print('Module not in existing op. Need to re-compile')
                return 

        os.environ['ASCEND_CUSTOM_OPP_PATH'] = os.path.join(self.custom_op_path, 'vendors', 'customize')
        subprocess.check_call(f'cp -r {os.path.join(self.out_dir, "custop_torchapi.*.so")} ./', shell=True)
        # The built .so lives in out_dir; put it on sys.path so the import resolves
        # regardless of CWD (callers running from a subdir don't have CWD importable).
        so_dir = os.path.abspath(self.out_dir)
        if so_dir not in sys.path:
            sys.path.insert(0, so_dir)
        self.mod = importlib.import_module('custop_torchapi')
        self.compiled = True
        for _,op in self._ops.items():
            op.api_manager = self
        print('Custom OP torchapi loaded.')

    def compile(self) -> str:
        import os
        import sys
        import subprocess
        import importlib
        from .utils.Tensor import GMTensor, GMTensorList
        from .utils.var import Var

        if self.mod is not None:
            print('Module is already compiled. Will skip compilation')
            return ''

        if not self._ops:
            raise ValueError("TorchApiManager has no registered ops")

        resources_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "resources"))
        template_path = os.path.join(resources_dir, "torchbind_template.cpp")
        if not os.path.isfile(template_path):
            raise FileNotFoundError(f"torchbind_template.cpp not found: {template_path}")
        setup_template_path = os.path.join(resources_dir, "torchsetup.py")
        if not os.path.isfile(setup_template_path):
            raise FileNotFoundError(f"torchsetup.py not found: {setup_template_path}")

        with open(template_path, "r", encoding="utf-8") as f:
            template_lines = f.readlines()

        include_idx: Optional[int] = None
        module_idx: Optional[int] = None
        binding_idx: Optional[int] = None
        for idx, line in enumerate(template_lines):
            if "aclnn_test_xxx.h" in line:
                include_idx = idx
            if "PYBIND11_MODULE" in line:
                module_idx = idx
            if 'm.def("test_xxx", &test_xxx, "test_xxx");' in line:
                binding_idx = idx

        if include_idx is None:
            raise ValueError('Missing "aclnn_test_xxx.h" placeholder in torchbind_template.cpp')
        if module_idx is None:
            raise ValueError("Missing PYBIND11_MODULE block in torchbind_template.cpp")
        if binding_idx is None:
            raise ValueError('Missing test_xxx binding placeholder in torchbind_template.cpp')

        include_lines = []
        wrapper_lines = []
        binding_lines = []

        def _to_camel(name: str) -> str:
            parts = [part for part in name.split("_") if part]
            if not parts:
                return name
            return "".join(part[:1].upper() + part[1:] for part in parts)

        def _acl_dtype_literal(dtype: Any) -> str:
            dtype_name = getattr(dtype, "name", None)
            mapping = {
                "half": "aclDataType::ACL_FLOAT16",
                "float": "aclDataType::ACL_FLOAT",
                "int": "aclDataType::ACL_INT32",
                "int64_t": "aclDataType::ACL_INT64",
                "int8_t": "aclDataType::ACL_INT8",
                "uint8_t": "aclDataType::ACL_UINT8",
                "int16_t": "aclDataType::ACL_INT16",
                "uint16_t": "aclDataType::ACL_UINT16",
                "uint32_t": "aclDataType::ACL_UINT32",
                "uint64_t": "aclDataType::ACL_UINT64",
                "bfloat16_t": "aclDataType::ACL_BF16",
                "bool": "aclDataType::ACL_BOOL",
                "float8_e5m2_t": "aclDataType::ACL_FLOAT8_E5M2",
                "float8_e4m3_t": "aclDataType::ACL_FLOAT8_E4M3FN",
                "hif8": "aclDataType::ACL_HIFLOAT8",
                "complex32": "aclDataType::ACL_COMPLEX32",
                "complex64": "aclDataType::ACL_COMPLEX64",
            }
            if dtype_name not in mapping:
                raise TypeError(f"Unsupported GMTensor dtype for torch API binding: {dtype_name}")
            return mapping[dtype_name]

        for op_name, op_exec in self._ops.items():
            include_lines.append(
                template_lines[include_idx].replace("aclnn_test_xxx", f"aclnn_{op_name}")
            )
            bound_args = getattr(op_exec.op_func, "_last_bound_args", None)
            if not isinstance(bound_args, dict) or not bound_args:
                raise RuntimeError(
                    f"OpExec {op_name} has no bound arguments; call it once before TorchApiManager.compile()"
                )
            output_gmtensors = getattr(op_exec.op_func, "_last_output_gmtensors", None)
            if not isinstance(output_gmtensors, set):
                output_gmtensors = set()

            arg_decls = []
            tensor_arg_infos = []
            scalar_arg_names = []
            for arg_name, arg_value in bound_args.items():
                if isinstance(arg_value, GMTensor):
                    arg_decls.append(f"at::Tensor {arg_name}")
                    tensor_arg_infos.append(
                        (arg_name, _acl_dtype_literal(arg_value.dtype), arg_value in output_gmtensors)
                    )
                    continue
                if isinstance(arg_value, Var):
                    scalar_value = arg_value.value
                    if isinstance(scalar_value, float):
                        scalar_ctype = "float"
                    elif isinstance(scalar_value, (int, bool)):
                        scalar_ctype = "int"
                    else:
                        raise TypeError(
                            f"Unsupported scalar type for {op_name}.{arg_name}: {type(scalar_value)}"
                        )
                    arg_decls.append(f"{scalar_ctype} {arg_name}")
                    scalar_arg_names.append(arg_name)
                    continue
                raise TypeError(
                    f"Unsupported bound argument type for {op_name}.{arg_name}: {type(arg_value)}"
                )

            if not tensor_arg_infos:
                raise ValueError(f"OpExec {op_name} requires at least one GMTensor argument")
            first_tensor_name = tensor_arg_infos[0][0]
            input_tensor_acl_names = [
                f"{tensor_arg_name}_acl"
                for tensor_arg_name, _, is_output in tensor_arg_infos
                if not is_output
            ]
            output_tensor_acl_names = [
                f"{tensor_arg_name}_acl"
                for tensor_arg_name, _, is_output in tensor_arg_infos
                if is_output
            ]
            exec_args = input_tensor_acl_names + scalar_arg_names + output_tensor_acl_names
            camel_name = _to_camel(op_name)
            wrapper_lines.extend(
                [
                    f"void {op_name}({', '.join(arg_decls)}) {{\n",
                    "    PREPARE_OP();\n",
                    f"    int devidx = {first_tensor_name}.device().index();\n",
                    "    c10_npu::NPUStream stream = c10_npu::getCurrentNPUStream(devidx);\n",
                ]
            )
            for tensor_arg_name, acl_dtype_literal, _ in tensor_arg_infos:
                wrapper_lines.append(
                    f"    aclTensor* {tensor_arg_name}_acl = toAclTensor({tensor_arg_name}, {acl_dtype_literal});\n"
                )
            wrapper_lines.extend(
                [
                    f"    EXECOP(aclnn{camel_name}, stream, {', '.join(exec_args)});\n",
                ]
            )
            for tensor_arg_name, _, _ in tensor_arg_infos:
                wrapper_lines.append(
                    f"    aclDestroyTensor({tensor_arg_name}_acl);\n"
                )
            wrapper_lines.extend(
                [
                    "}\n",
                    "\n",
                ]
            )
            binding_lines.append(
                template_lines[binding_idx].replace("test_xxx", op_name)
            )

        output_lines = list(template_lines)
        output_lines[include_idx : include_idx + 1] = include_lines
        wrapper_insert_idx = module_idx + (len(include_lines) - 1)
        output_lines[wrapper_insert_idx:wrapper_insert_idx] = wrapper_lines
        binding_insert_idx = binding_idx + (len(include_lines) - 1)
        binding_insert_idx += len(wrapper_lines)
        output_lines[binding_insert_idx : binding_insert_idx + 1] = binding_lines

        output_dir = os.path.abspath(self.out_dir or ".")
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, "custop_torchapi.cpp")
        with open(output_path, "w", encoding="utf-8") as f:
            f.writelines(output_lines)
        with open(setup_template_path, "r", encoding="utf-8") as f:
            setup_lines = f.readlines()
        custom_op_path_literal = repr(self.custom_op_path)
        replaced_custom_op_path = False
        for idx, line in enumerate(setup_lines):
            stripped = line.lstrip()
            if stripped.startswith("custom_op_path=") or stripped.startswith("custom_op_path ="):
                setup_lines[idx] = f"custom_op_path = {custom_op_path_literal}\n"
                replaced_custom_op_path = True
                break
        if not replaced_custom_op_path:
            raise ValueError("custom_op_path config not found in torchsetup.py")
        setup_output_path = os.path.join(output_dir, "setup.py")
        with open(setup_output_path, "w", encoding="utf-8") as f:
            f.writelines(setup_lines)
        
        for op_name, op_exec in self._ops.items():
            op_base_dir = op_exec.out_dir if op_exec.out_dir else op_exec.op_func.name
            op_script_dir = os.path.abspath(f"{op_base_dir}_kernel_script")
            _run_bash_with_progress(
                os.path.join(op_script_dir, "b.sh"),
                os.path.join(op_script_dir, "b.sh.log"),
            )
        _run_cmd_with_progress(
            'python', 'setup.py', 'build_ext', '--inplace',
            log_path=os.path.join(output_dir, 'torchplugin.log'),
            cwd=self.out_dir,
        )
        subprocess.check_call(f'cp -r {os.path.join(self.out_dir, "custop_torchapi.*.so")} ./', shell=True)
        self.compiled = True
        os.environ['ASCEND_CUSTOM_OPP_PATH'] = os.path.join(self.custom_op_path, 'vendors', 'customize')
        # The built .so lives in out_dir (build_ext --inplace); put it on sys.path so
        # the import resolves regardless of CWD. A caller running from a subdirectory
        # (e.g. `python build/package.py`) would otherwise not have it importable.
        so_dir = os.path.abspath(self.out_dir or ".")
        if so_dir not in sys.path:
            sys.path.insert(0, so_dir)
        self.mod = importlib.import_module('custop_torchapi')
        for _,op in self._ops.items():
            op.api_manager = self
        return output_path

    def __setattr__(self, key: str, value: object) -> None:
        if key in {"_ops", "out_dir", "cann_path", "custom_op_path", "compiled", "mod"} or key.startswith("_"):
            if isinstance(value, OpExec):
                raise TypeError(f'(setattr) Variable name {key} cannot be OpExec. Please change a name')
            super().__setattr__(key, value)
            return

        if not isinstance(value, OpExec):
            raise TypeError(f"value must be OpExec, got: {type(value)}")

        value.out_dir = self.out_dir
        value.cann_path = self.cann_path
        value.custom_op_path = self.custom_op_path
        value.gen_only = True
        value.simulator = False
        value.skip_compile = False

        opname = getattr(value.op_func, "name", None)
        if not isinstance(opname, str):
            raise TypeError(f"OpExec.op_func.name must be str, got: {type(opname)}")
        self._ops[opname] = value
        super().__setattr__(key, value)

    def call_kernel(self, op: 'OpExec', args):
        if self.mod is None:
            raise ValueError('Pybind module is not compiled. Please run compile or load_lib first')
        eval(f'self.mod.{op.op_func.name}(*args)')


class OpExec:
    def __init__(
        self,
        op_func: Union["KernelBase", Callable[..., Any]],
        out_dir: str = "",
        cann_path: Optional[str] = None,
        custom_op_path: Optional[str] = None,
        profile: bool = False,
        gen_only: bool = False,
        simulator: bool = False,
        cannsim: bool = False,
        skip_compile: bool = False,
        trace: Optional[str] = None,
        debug: bool = False,
    ) -> None:
        import os

        self.op_func = op_func
        self.out_dir = out_dir
        self.cann_path = cann_path
        if custom_op_path is None:
            custom_op_path = "./"
        if not isinstance(custom_op_path, str):
            raise TypeError(f"custom_op_path must be str, got: {type(custom_op_path)}")
        self.custom_op_path = os.path.abspath(custom_op_path)
        self.profile = profile
        self.gen_only = gen_only
        if not isinstance(simulator, bool):
            raise TypeError(f"simulator must be bool, got: {type(simulator)}")
        self.simulator = simulator
        if not isinstance(debug, bool):
            raise TypeError(f"debug must be bool, got: {type(debug)}")
        if not isinstance(cannsim, bool):
            raise TypeError(f"cannsim must be bool, got: {type(cannsim)}")
        if self.simulator and cannsim:
            raise ValueError("cannsim is only supported when simulator is disabled")
        # cannsim is valid in both the full-project generation path and the debug path:
        # in debug mode it switches the generated b.sh/r.sh from `-r npu` to `-r sim`
        # (CANNSIM) and the scripts are then run automatically (unless gen_only).
        self.cannsim = cannsim
        if not isinstance(skip_compile, bool):
            raise TypeError(f"skip_compile must be bool, got: {type(skip_compile)}")
        self.skip_compile = skip_compile
        if trace is not None and not isinstance(trace, str):
            raise TypeError(f"trace must be str or None, got: {type(trace)}")
        if isinstance(trace, str) and trace == "":
            raise ValueError("trace must be a non-empty file path when provided")
        self.trace = trace if self.simulator else None
        self.debug = debug
        self.api_manager: Optional['TorchApiManager'] = None
        self._built = False

    def _validate_kernel_tensor_var_partition(self) -> None:
        from .kernelbase.kernelbase import KernelBase, validate_case_insensitive_kernel_param_names
        from .utils.Tensor import GMTensor, GMTensorList
        from .utils.var import Var

        if not isinstance(self.op_func, KernelBase):
            raise TypeError("op_func must be a KernelBase instance")

        sig = inspect.signature(self.op_func.func)
        validate_case_insensitive_kernel_param_names(sig, self.op_func.func.__name__)
        seen_var = False
        for name, param in sig.parameters.items():
            annotation = param.annotation
            is_tensor_param = annotation is GMTensor or annotation == "GMTensor"
            is_tensor_list_param = annotation is GMTensorList or annotation == "GMTensorList"
            is_var_param = annotation is Var or annotation == "Var"
            if is_var_param:
                seen_var = True
                continue
            if (is_tensor_param or is_tensor_list_param) and seen_var:
                tensor_kind = "GMTensorList" if is_tensor_list_param else "GMTensor"
                raise ValueError(
                    "Invalid kernel argument order for OpExec: expected "
                    "`input GMTensor/GMTensorList* -> output GMTensor/GMTensorList* -> Var*`, but found a "
                    f"{tensor_kind} "
                    f"parameter after Var parameters. Offending parameter: `{name}`."
                )

    def _validate_bound_kernel_signature(self) -> None:
        from .kernelbase.kernelbase import KernelBase
        from .utils.Tensor import GMTensor, GMTensorList
        from .utils.var import Var

        if not isinstance(self.op_func, KernelBase):
            raise TypeError("op_func must be a KernelBase instance")
        if not self.op_func._last_bound_args:
            raise ValueError("op_func has not been executed; cannot validate KernelBase arguments")

        output_gmtensors = getattr(self.op_func, "_last_output_gmtensors", None)
        if not isinstance(output_gmtensors, set):
            output_gmtensors = set()
        output_gmtensor_lists = getattr(self.op_func, "_last_output_gmtensor_lists", None)
        if not isinstance(output_gmtensor_lists, set):
            output_gmtensor_lists = set()
        output_gmtensors_ordered = getattr(self.op_func, "_last_output_gmtensors_ordered", None)
        if not isinstance(output_gmtensors_ordered, list):
            output_gmtensors_ordered = []
        output_tensorlikes_ordered = getattr(self.op_func, "_last_output_tensorlikes_ordered", None)
        if not isinstance(output_tensorlikes_ordered, list):
            output_tensorlikes_ordered = list(output_gmtensors_ordered)

        category_items: List[str] = []
        input_param_names: List[str] = []
        output_param_names: List[str] = []
        output_name_by_id: Dict[int, str] = {}
        seen_output = False
        seen_var = False

        for name, bound_val in self.op_func._last_bound_args.items():
            if isinstance(bound_val, GMTensorList):
                is_output = bound_val in output_gmtensor_lists
                if is_output:
                    seen_output = True
                    output_param_names.append(name)
                    output_name_by_id[id(bound_val)] = name
                    category_items.append(f"{name}=output_list")
                    if seen_var:
                        raise ValueError(
                            "Invalid kernel argument order for OpExec: expected "
                            "`input GMTensor/GMTensorList* -> output GMTensor/GMTensorList* -> Var*`, but found an "
                            f"output GMTensorList after Var parameters. Offending parameter: `{name}`. "
                            f"Current order: {', '.join(category_items)}"
                        )
                    continue

                input_param_names.append(name)
                category_items.append(f"{name}=input_list")
                if seen_output or seen_var:
                    raise ValueError(
                        "Invalid kernel argument order for OpExec: expected "
                        "`input GMTensor/GMTensorList* -> output GMTensor/GMTensorList* -> Var*`, but found an "
                        f"input GMTensorList after output/Var parameters. Offending parameter: `{name}`. "
                        f"Current order: {', '.join(category_items)}"
                    )
                continue

            if isinstance(bound_val, GMTensor):
                is_output = bound_val in output_gmtensors
                if is_output:
                    seen_output = True
                    output_param_names.append(name)
                    output_name_by_id[id(bound_val)] = name
                    category_items.append(f"{name}=output")
                    if seen_var:
                        raise ValueError(
                            "Invalid kernel argument order for OpExec: expected "
                            "`input GMTensor/GMTensorList* -> output GMTensor/GMTensorList* -> Var*`, but found an "
                            f"output GMTensor after Var parameters. Offending parameter: `{name}`. "
                            f"Current order: {', '.join(category_items)}"
                        )
                    continue

                input_param_names.append(name)
                category_items.append(f"{name}=input")
                if seen_output or seen_var:
                    raise ValueError(
                        "Invalid kernel argument order for OpExec: expected "
                        "`input GMTensor/GMTensorList* -> output GMTensor/GMTensorList* -> Var*`, but found an "
                        f"input GMTensor after output/Var parameters. Offending parameter: `{name}`. "
                        f"Current order: {', '.join(category_items)}"
                    )
                continue

            if isinstance(bound_val, Var):
                seen_var = True
                category_items.append(f"{name}=var")
                continue

            raise TypeError(
                f"kernel arguments must be GMTensor, GMTensorList, or Var, current {name} type: {type(bound_val)}"
            )

        # Checked in simulator runs too: these are compiler entry requirements,
        # so a signature that fails them cannot be built for the board at all.
        # Skipping them under the simulator let a kernel pass every local test
        # and then fail template generation, which is the one thing the
        # simulator exists to catch early.
        if not input_param_names:
            raise ValueError(
                "Invalid kernel signature for OpExec: every @kernel must have at least one input "
                "GMTensor or GMTensorList because the compiler requires an input tensor in the kernel entry. "
                "Add a non-returned GMTensor/GMTensorList parameter before output tensor-like parameters."
            )

        if not output_param_names:
            raise ValueError(
                "Invalid kernel signature for OpExec: every @kernel must have at least one output "
                "GMTensor or GMTensorList because the compiler requires an output tensor in the kernel entry. "
                "Return at least one GMTensor/GMTensorList parameter from the kernel."
            )

        if not seen_var:
            raise ValueError(
                "Invalid kernel signature for OpExec: every @kernel must have at least one Var "
                "argument because the compiler requires a scalar argument in the kernel entry. "
                "Add a Var parameter to the kernel signature and pass a scalar value to OpExec."
            )

        output_return_names: List[str] = []
        for out in output_tensorlikes_ordered:
            if not isinstance(out, (GMTensor, GMTensorList)):
                continue
            output_name = output_name_by_id.get(id(out))
            if output_name is None:
                raise ValueError("Output GMTensor/GMTensorList must come from kernel arguments")
            output_return_names.append(output_name)

        if output_param_names != output_return_names:
            raise ValueError(
                "Output GMTensor/GMTensorList order in function signature does not match return order: "
                f"signature outputs={output_param_names}, return outputs={output_return_names}"
            )

    def __call__(
        self,
        *args: Any,
        shape_bindings: Optional[Dict[int, Sequence[Optional[int]]]] = None,
    ) -> Any:
        from .kernelbase.kernelbase import KernelBase
        from .utils.Tensor import GMTensor, GMTensorList
        from .utils.datatype import Datatype
        from .utils.var import Var
        import os
        import time

        if self.api_manager is not None:
            self.api_manager.call_kernel(self, args)
            return 

        if not isinstance(self.op_func, KernelBase):
            raise TypeError("op_func must be a KernelBase instance")

        try:
            import torch
        except Exception as exc:
            raise ImportError("OpExec.__call__ requires torch") from exc

        tensor_args: List[Any] = []
        scalar_vars: List[Var] = []
        seen_scalar = False
        for idx, arg in enumerate(args):
            if isinstance(arg, torch.Tensor):
                if seen_scalar:
                    raise TypeError("Invalid argument order: torch.Tensor must come before int/float")
                tensor_args.append(arg)
                continue
            if isinstance(arg, (list, tuple)):
                if seen_scalar:
                    raise TypeError("Invalid argument order: TensorList arguments must come before int/float")
                if not arg:
                    raise ValueError(f"TensorList argument #{idx} must not be empty")
                if not all(isinstance(item, torch.Tensor) for item in arg):
                    raise TypeError(f"TensorList argument #{idx} must contain only torch.Tensor items")
                tensor_args.append(list(arg))
                continue
            if isinstance(arg, (int, float)):
                seen_scalar = True
                scalar_vars.append(Var(arg))
                continue
            raise TypeError(f"Invalid argument type: arg #{idx} has type {type(arg)}")

        if shape_bindings is not None and not isinstance(shape_bindings, dict):
            raise TypeError(f"shape_bindings must be dict or None, got: {type(shape_bindings)}")

        if shape_bindings is None:
            shape_bindings = {}

        def _is_shape_scalar(value: Any) -> bool:
            return isinstance(value, int) and not isinstance(value, bool)

        self._validate_kernel_tensor_var_partition()

        dtype_map = {
            torch.float16: Datatype.half,
            torch.float32: Datatype.float,
            torch.int32: Datatype.int,
            torch.int64: Datatype.int64,
            torch.int8: Datatype.int8,
            torch.uint8: Datatype.uint8,
            torch.int16: Datatype.int16,
            torch.bfloat16: Datatype.bfloat16,
        }
        if hasattr(torch, "float8_e4m3fn"):
            dtype_map[torch.float8_e4m3fn] = Datatype.e4m3  # type: ignore[attr-defined]
        if hasattr(torch, "float8_e5m2"):
            dtype_map[torch.float8_e5m2] = Datatype.e5m2  # type: ignore[attr-defined]
        if hasattr(torch, "uint16"):
            dtype_map[torch.uint16] = Datatype.uint16  # type: ignore
        if hasattr(torch, "uint32"):
            dtype_map[torch.uint32] = Datatype.uint32  # type: ignore
        if hasattr(torch, "uint64"):
            dtype_map[torch.uint64] = Datatype.uint64  # type: ignore
        if hasattr(torch, "complex64"):
            dtype_map[torch.complex64] = Datatype.complex64  # type: ignore
        if hasattr(torch, "complex32"):
            dtype_map[torch.complex32] = Datatype.complex32  # type: ignore

        def _item_shape_binding(tensor_idx: int, binding: Any) -> Any:
            if binding is None:
                return None
            if isinstance(binding, dict):
                allowed = {"item", "length"}
                extra = set(binding.keys()) - allowed
                if extra:
                    raise ValueError(
                        f"shape_bindings[{tensor_idx}] unsupported keys for TensorList: {sorted(extra)}"
                    )
                return binding.get("item")
            return binding

        def _infer_gm_shape(tensor_idx: int, tensor: Any, binding: Any, label: str) -> List[Any]:
            if binding is not None:
                if not isinstance(binding, (list, tuple)):
                    raise TypeError(
                        f"{label} shape binding must be list/tuple, got: {type(binding)}"
                    )
                if len(binding) != len(tensor.shape):
                    raise ValueError(
                        f"{label} shape binding rank must match tensor rank, "
                        f"got: {len(binding)} vs {len(tensor.shape)}"
                    )

            inferred_shape: List[Any] = []
            for dim_idx, dim in enumerate(tensor.shape):
                explicit_scalar_idx: Optional[int] = None
                if binding is not None:
                    chosen_idx = binding[dim_idx]
                    if chosen_idx is not None:
                        if not isinstance(chosen_idx, int):
                            raise TypeError(
                                f"{label}[{dim_idx}] must be int or None, "
                                f"got: {type(chosen_idx)}"
                            )
                        if chosen_idx == LITERAL_SHAPE_DIM:
                            # The kernel never reads this dimension, so pin it to
                            # its literal size instead of matching a scalar. Auto
                            # inference cannot express that: a dim whose value
                            # collides with two or more scalars is ambiguous.
                            inferred_shape.append(int(dim))
                            continue
                        if chosen_idx < 0 or chosen_idx >= len(scalar_vars):
                            raise ValueError(
                                f"{label}[{dim_idx}] out of range: "
                                f"{chosen_idx}, scalar count={len(scalar_vars)}"
                            )
                        explicit_scalar_idx = chosen_idx

                if explicit_scalar_idx is not None:
                    bound_var = scalar_vars[explicit_scalar_idx]
                    if not _is_shape_scalar(bound_var.value):
                        raise TypeError(
                            f"{label}[{dim_idx}] refers to non-int scalar "
                            f"#{explicit_scalar_idx}: {bound_var.value}"
                        )
                    if bound_var.value != dim:
                        raise ValueError(
                            f"{label}[{dim_idx}] mismatches tensor dim value: "
                            f"tensor dim={int(dim)}, scalar[{explicit_scalar_idx}]={bound_var.value}"
                        )
                    inferred_shape.append(bound_var)
                    continue

                matched_indices: List[int] = []
                for scalar_idx, scalar_var in enumerate(scalar_vars):
                    if not _is_shape_scalar(scalar_var.value):
                        continue
                    if scalar_var.value == dim:
                        matched_indices.append(scalar_idx)
                if len(matched_indices) == 0:
                    inferred_shape.append(int(dim))
                    continue
                if len(matched_indices) == 1:
                    inferred_shape.append(scalar_vars[matched_indices[0]])
                    continue
                raise ValueError(
                    f"Ambiguous scalar match for tensor #{tensor_idx} dim #{dim_idx} "
                    f"(value={int(dim)}): matches scalar indices {matched_indices}. "
                    "Please provide shape_bindings for this tensor dimension."
                )
            return inferred_shape

        kernel_tensor_args: List[Any] = []
        for tensor_idx, tensor_arg in enumerate(tensor_args):
            binding = shape_bindings.get(tensor_idx)
            if isinstance(tensor_arg, list):
                first_tensor = tensor_arg[0]
                item_binding = _item_shape_binding(tensor_idx, binding)
                for item_idx, item in enumerate(tensor_arg):
                    if item.dtype != first_tensor.dtype:
                        raise TypeError(
                            f"TensorList argument #{tensor_idx} item #{item_idx} dtype mismatch: "
                            f"{item.dtype} vs {first_tensor.dtype}"
                        )
                    if len(item.shape) != len(first_tensor.shape):
                        raise ValueError(
                            f"TensorList argument #{tensor_idx} item #{item_idx} rank mismatch: "
                            f"{len(item.shape)} vs {len(first_tensor.shape)}"
                        )
                dtype = dtype_map.get(first_tensor.dtype)
                if dtype is None:
                    raise TypeError(f"Unsupported torch dtype: {first_tensor.dtype}")
                items = []
                prototype_shape = None
                for item_idx, item in enumerate(tensor_arg):
                    inferred_item_shape = _infer_gm_shape(
                        tensor_idx,
                        item,
                        item_binding,
                        f"shape_bindings[{tensor_idx}].item (item #{item_idx})",
                    )
                    if prototype_shape is None:
                        prototype_shape = inferred_item_shape
                    gm_item = GMTensor(dtype, inferred_item_shape)
                    if self.simulator:
                        gm_item.data = item.detach().clone().contiguous().view(-1)
                    items.append(gm_item)
                if prototype_shape is None:
                    raise ValueError(f"TensorList argument #{tensor_idx} must not be empty")
                kernel_tensor_args.append(
                    GMTensorList(dtype, prototype_shape, length=len(items), items=items)
                )
                continue

            tensor = tensor_arg
            if isinstance(binding, dict):
                raise TypeError(
                    f"shape_bindings[{tensor_idx}] dict form is only valid for TensorList arguments"
                )
            dtype = dtype_map.get(tensor.dtype)
            if dtype is None:
                raise TypeError(f"Unsupported torch dtype: {tensor.dtype}")
            inferred_shape = _infer_gm_shape(
                tensor_idx,
                tensor,
                binding,
                f"shape_bindings[{tensor_idx}]",
            )
            gm_tensor = GMTensor(dtype, inferred_shape)
            if self.simulator:
                gm_tensor.data = tensor.detach().clone().contiguous().view(-1)
            kernel_tensor_args.append(gm_tensor)

        kernel_ret = self.op_func(*(kernel_tensor_args + scalar_vars))
        self._validate_bound_kernel_signature()
        if self.simulator:
            print("Starting simulation run")
            sim_start_ts = time.perf_counter()
            try:
                self.op_func.run_sim(trace=self.trace)
            finally:
                elapsed = time.perf_counter() - sim_start_ts
                print(f"Simulation run elapsed: {elapsed:.3f}s")
        else:
            generation_cann_path = self.cann_path
            if self.gen_only and generation_cann_path is None:
                generation_cann_path = os.getenv("ASCEND_HOME_PATH") or ""
            if self.debug:
                self.op_func.generate_debug(
                    self.out_dir,
                    cann_path=generation_cann_path,
                    custom_op_path=self.custom_op_path,
                    profile=self.profile,
                    cannsim=self.cannsim,
                )
            else:
                self.op_func.generate(
                    self.out_dir,
                    cann_path=generation_cann_path,
                    custom_op_path=self.custom_op_path,
                    profile=self.profile,
                    cannsim=self.cannsim,
                )

        if not self.op_func._last_bound_args:
            raise ValueError("op_func has not been executed; cannot extract IO info from KernelBase")

        output_gmtensors = self.op_func._last_output_gmtensors
        output_gmtensor_lists = getattr(self.op_func, "_last_output_gmtensor_lists", None)
        if not isinstance(output_gmtensor_lists, set):
            output_gmtensor_lists = set()
        param_names = list(self.op_func._last_bound_args.keys())
        gmtensor_param_names: List[str] = []
        tensor_list_param_names: List[str] = []
        tensor_like_param_names: List[str] = []
        for name in param_names:
            bound_val = self.op_func._last_bound_args.get(name)
            if isinstance(bound_val, GMTensor):
                gmtensor_param_names.append(name)
                tensor_like_param_names.append(name)
            elif isinstance(bound_val, GMTensorList):
                tensor_list_param_names.append(name)
                tensor_like_param_names.append(name)

        input_param_names: List[str] = []
        for name in gmtensor_param_names:
            bound_val = self.op_func._last_bound_args.get(name)
            if bound_val not in output_gmtensors:
                input_param_names.append(name)
        for name in tensor_list_param_names:
            bound_val = self.op_func._last_bound_args.get(name)
            if bound_val not in output_gmtensor_lists:
                input_param_names.append(name)

        if len(tensor_args) == len(tensor_like_param_names):
            tensor_by_name = {
                name: tensor_args[idx] for idx, name in enumerate(tensor_like_param_names)
            }
        elif len(tensor_args) == len(input_param_names):
            tensor_by_name = {
                name: tensor_args[idx] for idx, name in enumerate(input_param_names)
            }
        else:
            raise ValueError(
                "Number of tensor inputs does not match KernelBase GMTensor/GMTensorList parameters"
            )

        def _resolve_dim(value: Any, label: str) -> int:
            if isinstance(value, bool):
                return int(value)
            if isinstance(value, int):
                return value
            if isinstance(value, Var):
                raw = value.value
                if not isinstance(raw, (int, float, bool)):
                    raise TypeError(
                        f"{label} must resolve to int/float/bool from Var, got: {type(raw)}"
                    )
                return int(raw)
            if isinstance(value, float):
                return int(value)
            raise TypeError(f"{label} must resolve to int, got: {type(value)}")

        def _resolve_shape_dims(gm_tensor: GMTensor) -> List[int]:
            shape = gm_tensor.shape
            if not isinstance(shape, (list, tuple)):
                raise TypeError(
                    f"{gm_tensor.name} shape must be list/tuple, got: {type(shape)}"
                )
            shape_dims: List[int] = []
            for idx, dim in enumerate(shape):
                resolved = _resolve_dim(dim, f"{gm_tensor.name}.shape[{idx}]")
                if resolved < 0:
                    raise ValueError(
                        f"{gm_tensor.name} shape must be non-negative, got: {shape}"
                    )
                shape_dims.append(resolved)
            return shape_dims

        def _dtype_to_torch(gm_dtype: Any) -> "torch.dtype":
            name = getattr(gm_dtype, "name", None)
            mapping = {
                "half": torch.float16,
                "float": torch.float32,
                "int": torch.int32,
                "int64_t": torch.int64,
                "int8_t": torch.int8,
                "uint8_t": torch.uint8,
                "int16_t": torch.int16,
                "bfloat16_t": torch.bfloat16,
            }
            if name in mapping:
                return mapping[name]
            if name == "uint16_t" and hasattr(torch, "uint16"):
                return torch.uint16  # type: ignore[attr-defined]
            if name == "uint32_t" and hasattr(torch, "uint32"):
                return torch.uint32  # type: ignore[attr-defined]
            if name == "uint64_t" and hasattr(torch, "uint64"):
                return torch.uint64  # type: ignore[attr-defined]
            if name == "float8_e4m3_t" and hasattr(torch, "float8_e4m3fn"):
                return torch.float8_e4m3fn  # type: ignore[attr-defined]
            if name == "float8_e5m2_t" and hasattr(torch, "float8_e5m2"):
                return torch.float8_e5m2  # type: ignore[attr-defined]
            if name == "complex64" and hasattr(torch, "complex64"):
                return torch.complex64  # type: ignore[attr-defined]
            if name == "complex32" and hasattr(torch, "complex32"):
                return torch.complex32  # type: ignore[attr-defined]
            raise TypeError(f"Unsupported GMTensor dtype for torch output: {name}")

        def _zero_output_placeholder(gm_tensor: GMTensor) -> "torch.Tensor":
            shape_dims = _resolve_shape_dims(gm_tensor)
            dtype = _dtype_to_torch(gm_tensor.dtype)
            if len(shape_dims) == 0:
                return torch.zeros((), dtype=dtype)
            return torch.zeros(tuple(shape_dims), dtype=dtype)

        def _map_gen_only_outputs(value: Any) -> Any:
            if isinstance(value, GMTensor):
                return _zero_output_placeholder(value)
            if isinstance(value, GMTensorList):
                if value in output_gmtensor_lists:
                    return [_zero_output_placeholder(item) for item in value.items]
                return value
            if isinstance(value, list):
                return [_map_gen_only_outputs(item) for item in value]
            if isinstance(value, tuple):
                return tuple(_map_gen_only_outputs(item) for item in value)
            if isinstance(value, dict):
                return {key: _map_gen_only_outputs(item) for key, item in value.items()}
            return value

        if not self.simulator:
            base_dir = self.out_dir if self.out_dir else self.op_func.name
            if self.debug:
                runtime_dir = os.path.abspath(os.path.join(base_dir, "debug_workspace"))
            else:
                runtime_dir = os.path.abspath(f"{base_dir}_aclnn_test")
            input_dir = os.path.join(runtime_dir, "input")
            output_dir = os.path.join(runtime_dir, "output")
            os.makedirs(input_dir, exist_ok=True)
            os.makedirs(output_dir, exist_ok=True)

            for name in input_param_names:
                bound_val = self.op_func._last_bound_args.get(name)
                tensor_arg = tensor_by_name[name]
                if isinstance(bound_val, GMTensorList):
                    if not isinstance(tensor_arg, list):
                        raise TypeError(f"Input {name} expects a TensorList argument")
                    for item_idx, item in enumerate(tensor_arg):
                        tensor_cpu = item.detach().cpu()
                        tensor_bytes = tensor_cpu.contiguous().view(torch.uint8)
                        tensor_bytes.numpy().tofile(
                            os.path.join(input_dir, f"input_{name}_item{item_idx}.bin")
                        )
                    continue
                tensor = tensor_arg
                tensor_cpu = tensor.detach().cpu()
                tensor_bytes = tensor_cpu.contiguous().view(torch.uint8)
                tensor_bytes.numpy().tofile(os.path.join(input_dir, f"input_{name}.bin"))

            if self.gen_only:
                return _map_gen_only_outputs(kernel_ret)

            script_dir = f"{base_dir}_kernel_script"
            # Rebuild gate keyed on a source fingerprint: reusing an out_dir keeps a
            # stale build_out/ that b.sh's incremental cmake relinks when the kernel
            # source changed (sim-passes / HW-link-fails). If the generated sources
            # changed, clean the build artifacts so the next b.sh is a clean rebuild.
            stamp_path = os.path.join(script_dir, ".source_hash")
            cur_hash = _source_fingerprint(
                base_dir, [f"{base_dir}_aclnn_test"], "debug" if self.debug else "profile"
            )
            try:
                with open(stamp_path, encoding="utf-8") as _sf:
                    prev_hash = _sf.read().strip()
            except OSError:
                prev_hash = None
            src_changed = cur_hash != prev_hash
            if not self.skip_compile and (not self._built or src_changed):
                if src_changed:
                    import shutil

                    for _bd in (
                        os.path.join(base_dir, "build_out"),
                        os.path.join(base_dir, "debug_workspace", "build"),
                    ):
                        if os.path.isdir(_bd):
                            shutil.rmtree(_bd, ignore_errors=True)
                build_script = os.path.join(script_dir, "b.sh")
                build_log_path = os.path.abspath(os.path.join(script_dir, "b.sh.log"))
                _run_bash_with_progress(build_script, build_log_path)
                self._built = True
                try:
                    with open(stamp_path, "w", encoding="utf-8") as _sf:
                        _sf.write(cur_hash)
                except OSError:
                    pass
            elif self.skip_compile and src_changed:
                import warnings

                warnings.warn(
                    f"easyasc: kernel source changed but skip_compile=True; linking "
                    f"possibly-stale artifacts under {base_dir}.",
                    stacklevel=2,
                )
            run_script = os.path.join(script_dir, "r.sh")
            run_log_path = os.path.abspath(os.path.join(script_dir, "r.sh.log"))
            # Serialize the NPU-occupying step across processes (see _NpuExecLock).
            # The watchdog enforces a timeout and checks board-idle before launch.
            with _NpuExecLock():
                _run_npu_script(run_script, run_log_path)

            def _dtype_byte_size(gm_dtype: Any) -> int:
                name = getattr(gm_dtype, "name", None)
                size_map = {
                    "half": 2,
                    "float": 4,
                    "int": 4,
                    "int64_t": 8,
                    "int8_t": 1,
                    "uint8_t": 1,
                    "int16_t": 2,
                    "uint16_t": 2,
                    "uint32_t": 4,
                    "uint64_t": 8,
                    "bfloat16_t": 2,
                    "float8_e4m3_t": 1,
                    "float8_e5m2_t": 1,
                    "complex32": 4,
                    "complex64": 8,
                }
                if name not in size_map:
                    raise TypeError(f"Unsupported GMTensor dtype size for output load: {name}")
                return size_map[name]

            def _load_output_from_bin(gm_tensor: GMTensor) -> "torch.Tensor":
                shape_dims = _resolve_shape_dims(gm_tensor)
                target_numel = 1
                for dim in shape_dims:
                    target_numel *= dim
                output_path = os.path.join(output_dir, f"output_{gm_tensor.name}.bin")
                if not os.path.isfile(output_path):
                    raise FileNotFoundError(f"Missing output bin file: {output_path}")
                expected_bytes = target_numel * _dtype_byte_size(gm_tensor.dtype)
                actual_bytes = os.path.getsize(output_path)
                if actual_bytes < expected_bytes:
                    raise ValueError(
                        f"Output bin too small for {gm_tensor.name}: "
                        f"required_bytes={expected_bytes}, actual_bytes={actual_bytes}"
                    )
                dtype_name = getattr(gm_tensor.dtype, "name", None)
                if dtype_name == "bfloat16_t":
                    raw = torch.from_file(
                        output_path,
                        shared=False,
                        size=target_numel,
                        dtype=torch.int16,
                    )
                    out = raw.view(torch.bfloat16).clone()
                elif dtype_name == "float8_e4m3_t":
                    if not hasattr(torch, "float8_e4m3fn"):
                        raise TypeError("torch.float8_e4m3fn is not available in current torch")
                    raw = torch.from_file(
                        output_path,
                        shared=False,
                        size=target_numel,
                        dtype=torch.uint8,
                    )
                    out = raw.view(torch.float8_e4m3fn).clone()  # type: ignore[attr-defined]
                elif dtype_name == "float8_e5m2_t":
                    if not hasattr(torch, "float8_e5m2"):
                        raise TypeError("torch.float8_e5m2 is not available in current torch")
                    raw = torch.from_file(
                        output_path,
                        shared=False,
                        size=target_numel,
                        dtype=torch.uint8,
                    )
                    out = raw.view(torch.float8_e5m2).clone()  # type: ignore[attr-defined]
                else:
                    out = torch.from_file(
                        output_path,
                        shared=False,
                        size=target_numel,
                        dtype=_dtype_to_torch(gm_tensor.dtype),
                    ).clone()
                if len(shape_dims) == 0:
                    return out.view(())
                return out.contiguous().view(*shape_dims)

            def _map_outputs(value: Any) -> Any:
                if isinstance(value, GMTensor):
                    if value in output_gmtensors:
                        return _load_output_from_bin(value)
                    return value
                if isinstance(value, GMTensorList):
                    if value in output_gmtensor_lists:
                        return [_load_output_from_bin(item) for item in value.items]
                    return value
                if isinstance(value, list):
                    return [_map_outputs(item) for item in value]
                if isinstance(value, tuple):
                    return tuple(_map_outputs(item) for item in value)
                if isinstance(value, dict):
                    return {key: _map_outputs(item) for key, item in value.items()}
                return value

            return _map_outputs(kernel_ret)
        else:
            def _clone_gm_tensor_view(gm_tensor: GMTensor) -> "torch.Tensor":
                if gm_tensor.data is None:
                    raise ValueError(
                        f"Simulator output GMTensor {gm_tensor.name} has no data bound"
                    )
                shape_dims = _resolve_shape_dims(gm_tensor)
                target_numel = 1
                for dim in shape_dims:
                    target_numel *= dim
                gm_flat = gm_tensor.data.contiguous().view(-1)
                if int(gm_flat.numel()) < target_numel:
                    raise ValueError(
                        f"{gm_tensor.name} output numel is smaller than shape product: "
                        f"required={target_numel}, actual={int(gm_flat.numel())}"
                    )
                out = gm_flat[:target_numel].detach().clone()
                if len(shape_dims) == 0:
                    return out.view(())
                return out.contiguous().view(*shape_dims)

            def _map_outputs(value: Any) -> Any:
                if isinstance(value, GMTensor):
                    return _clone_gm_tensor_view(value)
                if isinstance(value, GMTensorList):
                    if value in output_gmtensor_lists:
                        return [_clone_gm_tensor_view(item) for item in value.items]
                    return value
                if isinstance(value, list):
                    return [_map_outputs(item) for item in value]
                if isinstance(value, tuple):
                    return tuple(_map_outputs(item) for item in value)
                if isinstance(value, dict):
                    return {key: _map_outputs(item) for key, item in value.items()}
                return value

            return _map_outputs(kernel_ret)
