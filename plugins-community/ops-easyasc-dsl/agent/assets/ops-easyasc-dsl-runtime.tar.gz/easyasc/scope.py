from typing import Optional, Type

from . import globvars
from .utils.instruction import Instruction


class _side_scope:
    enter_opname = ""
    end_opname = ""
    label = "scope"

    def _emit(self, opname: str) -> None:
        if globvars.active_kernel is None:
            raise RuntimeError(f"{self.label} can only be used inside a kernel")
        globvars.active_kernel.instructions.append(Instruction(opname))

    def __enter__(self):
        self._emit(self.enter_opname)
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc: Optional[BaseException],
        tb,
    ) -> bool:
        self._emit(self.end_opname)
        return False


class vec_scope(_side_scope):
    enter_opname = "enter_vec_scope"
    end_opname = "end_vec_scope"
    label = "vec_scope"


class cube_scope(_side_scope):
    enter_opname = "enter_cube_scope"
    end_opname = "end_cube_scope"
    label = "cube_scope"
