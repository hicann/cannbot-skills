"""Ascend A3 / 910C public facade for the Ascend910_93 C220 target."""

from .a2 import *

from . import globvars

globvars.device_type = "a3"
globvars.core_num = 20
globvars.l1_cap = 512
globvars.l0a_cap = 64
globvars.l0b_cap = 64
globvars.l0amx_cap = 4
globvars.l0bmx_cap = 4
globvars.l0c_cap = 128
globvars.bt_cap = 0.5  # KB, total depth-2 BT capacity (2 x 256 B slots)
globvars.ub_cap = 192
