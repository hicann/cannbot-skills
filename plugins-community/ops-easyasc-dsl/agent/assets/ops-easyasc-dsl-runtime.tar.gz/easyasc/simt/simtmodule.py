import ast
import inspect
import numbers
import textwrap
from typing import Any, Callable, Dict, List, Optional, Tuple

from .. import globvars
from ..device_profile import is_c220_family
from ..parser.asc_utils import dtype_to_cpp
from ..utils.datatype import Datatype, DataTypeValue
from ..utils.instruction import Instruction
from ..utils.Tensor import GMTensor, Tensor
from ..utils.var import Var


_KIND_GMTENSOR = "GMTensor"
_KIND_TENSOR = "Tensor"
_KIND_VAR = "Var"
_VALID_KINDS = (_KIND_GMTENSOR, _KIND_TENSOR, _KIND_VAR)

_BINOP_PREC = {
    ast.BitOr: 1,
    ast.BitXor: 2,
    ast.BitAnd: 3,
    ast.LShift: 4,
    ast.RShift: 4,
    ast.Add: 5,
    ast.Sub: 5,
    ast.Mult: 6,
    ast.Div: 6,
    ast.FloorDiv: 6,
    ast.Mod: 6,
}

_BINOP_SYMBOL = {
    ast.Add: "+",
    ast.Sub: "-",
    ast.Mult: "*",
    ast.Div: "/",
    ast.FloorDiv: "/",
    ast.Mod: "%",
    ast.BitOr: "|",
    ast.BitXor: "^",
    ast.BitAnd: "&",
    ast.LShift: "<<",
    ast.RShift: ">>",
}

_BINOP_IR_SYMBOL = dict(_BINOP_SYMBOL)
_BINOP_IR_SYMBOL[ast.FloorDiv] = "//"


_SIMT_NULLARY_INTRINSICS = {
    "simt_thread_id": "Simt::GetThreadIdx<0>()",
    "simt_thread_num": "Simt::GetThreadNum<0>()",
    "simt_block_idx": "Simt::GetBlockIdx()",
    "simt_block_num": "Simt::GetBlockNum()",
}


# ``Min``/``Max`` are spelled the same way as in the vector DSL so a work-split
# expression reads identically in both.  They lower to a ternary rather than to
# ``std::min`` so no host header is pulled into device code and so mixed-width
# operands keep the promotion the surrounding arithmetic already uses.
_SIMT_BINARY_INTRINSICS = ("Min", "Max")


_SIMT_ATOMIC_OPS = {
    "simt_atomic_add": ("add", "Simt::AtomicAdd"),
    "simt_atomic_sub": ("sub", "Simt::AtomicSub"),
    "simt_atomic_max": ("max", "Simt::AtomicMax"),
    "simt_atomic_min": ("min", "Simt::AtomicMin"),
    "simt_atomic_cas": ("cas", "Simt::AtomicCas"),
}


_SIMT_INTEGER_RANK = {
    Datatype.int: 0,
    Datatype.uint32: 1,
    Datatype.int64: 2,
    Datatype.uint64: 3,
}


def cvt(value, dtype):
    return value


def simt_fma(multiplicand0, multiplicand1, addend):
    """Fused ``multiplicand0 * multiplicand1 + addend`` for fp32 SIMT scalars.

    The generated expression is intentionally kept as one C++ expression and
    requires the custom-op project to compile it with ``-ffp-contract=on``.
    The simulator evaluates the product and sum in fp64 before the single fp32
    rounding.  Ordinary scalar multiply/add source is not a separately-rounded
    contract on C310; use explicit Micro ``mul`` then ``add`` in another custom
    kernel when two roundings are required.
    """
    return multiplicand0 * multiplicand1 + addend


def simt_ffs(value):
    """Return the one-based position of the least-significant set bit.

    This mirrors ``AscendC::Simt::Ffs``: signed int32/int64 inputs are
    supported and zero returns zero.  Cast an unsigned bit pattern to the
    same-width signed dtype before calling it.
    """
    return 0


def simt_thread_barrier() -> None:  # pragma: no cover - compile-time stub
    """Synchronize every thread in the current SIMT block."""
    return None


def simt_thread_id() -> int:
    return 0


def simt_thread_num() -> int:
    return 1


def simt_block_idx() -> int:
    return 0


def simt_block_num() -> int:
    return 1


def simt_atomic_add(target, value) -> None:  # pragma: no cover - compile-time stub
    return None


def simt_atomic_sub(target, value) -> None:  # pragma: no cover - compile-time stub
    return None


def simt_atomic_max(target, value) -> None:  # pragma: no cover - compile-time stub
    return None


def simt_atomic_min(target, value) -> None:  # pragma: no cover - compile-time stub
    return None


def simt_atomic_cas(target, compare, value) -> None:  # pragma: no cover
    """Atomically store ``value`` when ``target == compare``.

    The return value of AscendC ``AtomicCas`` is intentionally not exposed yet;
    callers that need a retry loop can reload the target after this statement.
    """
    return None


def _check_simt_supported() -> None:
    device = str(getattr(globvars, "device_type", "")).lower()
    if is_c220_family(device):
        raise RuntimeError(
            f"easyasc.simt is not supported on C220 devices (device_type={device!r}); "
            "switch to easyasc.a5 (e.g. via `from easyasc.a5 import *`)."
        )


_ALLOWED_NUM_THREADS = (128, 256, 512, 1024, 2048)
_SIMT_SOURCE_CONTEXT_ATTR = "_easyasc_simt_source_context"


class SimtModule:
    def __init__(
        self,
        name: str,
        func: Callable[..., Any],
        num_threads: int = 1024,
    ) -> None:
        _check_simt_supported()
        if isinstance(num_threads, bool) or not isinstance(num_threads, int):
            raise TypeError(
                f"SimtModule num_threads must be int, got {type(num_threads).__name__}"
            )
        if num_threads not in _ALLOWED_NUM_THREADS:
            raise ValueError(
                "SimtModule num_threads must be one of "
                + str(_ALLOWED_NUM_THREADS) + ", got " + str(num_threads)
            )
        self.name = name
        self.func = func
        self.num_threads = num_threads
        self.source_path, self.source_start_line, self.source_lines = (
            self._load_source(func)
        )
        self.func_def = self._parse_func_def(func, "\n".join(self.source_lines))
        self.input_list: List[Tuple[str, str]] = self._extract_inputs(self.func_def)
        self._formal_names = frozenset(name for name, _ in self.input_list)
        self._local_names = self._collect_local_names(self.func_def)
        self._locked_dtypes: Optional[List[DataTypeValue]] = None
        self._ir_instructions: Optional[List[Instruction]] = None
        self._read_formals: Optional[frozenset] = None
        self._write_formals: Optional[frozenset] = None

    def __call__(self, *args: Any, **kwargs: Any) -> None:
        _check_simt_supported()
        if kwargs:
            raise TypeError("SimtModule does not support keyword arguments")
        if len(args) != len(self.input_list):
            raise TypeError(
                f"SimtModule {self.name!r} expects {len(self.input_list)} args, "
                f"got {len(args)}"
            )
        normalized = tuple(self._normalize_arg(arg) for arg in args)
        dtypes = [
            self._validate_and_dtype(arg, kind, arg_name)
            for arg, (arg_name, kind) in zip(normalized, self.input_list)
        ]
        if self._locked_dtypes is None:
            self._locked_dtypes = dtypes
        elif dtypes != self._locked_dtypes:
            raise TypeError(
                f"SimtModule {self.name!r} signature mismatch: "
                f"locked={self._fmt_dtypes(self._locked_dtypes)}, "
                f"got={self._fmt_dtypes(dtypes)}"
            )
        if globvars.active_kernel is not None:
            globvars.active_kernel.used_simts.add(self)
            read_keys, write_keys = self._derive_call_sync_keys(normalized)
            globvars.active_kernel.instructions.append(
                Instruction(
                    "call_simt",
                    name=self.name,
                    args=list(normalized),
                    num_threads=int(self.num_threads),
                    read_sync_keys=list(read_keys),
                    write_sync_keys=list(write_keys),
                )
            )

    @staticmethod
    def _normalize_arg(arg: Any) -> Any:
        if type(arg) is int:
            scalar = object.__new__(Var)
            scalar.dtype = Datatype.int
            scalar.name = str(arg)
            scalar.value = arg
            scalar.idx = -1
            return scalar
        if type(arg) is float:
            scalar = object.__new__(Var)
            scalar.dtype = Datatype.float
            scalar.name = repr(arg)
            scalar.value = arg
            scalar.idx = -1
            return scalar
        return arg

    @staticmethod
    def _validate_and_dtype(arg: Any, kind: str, arg_name: str) -> DataTypeValue:
        if kind == _KIND_GMTENSOR:
            if not isinstance(arg, GMTensor):
                raise TypeError(
                    f"arg {arg_name!r} expected GMTensor, got {type(arg).__name__}"
                )
            return arg.dtype
        if kind == _KIND_TENSOR:
            if not isinstance(arg, Tensor):
                raise TypeError(
                    f"arg {arg_name!r} expected Tensor, got {type(arg).__name__}"
                )
            return arg.dtype
        if kind == _KIND_VAR:
            if isinstance(arg, Var):
                if arg.dtype is None:
                    raise TypeError(f"arg {arg_name!r}: Var has no dtype set")
                return arg.dtype
            if isinstance(arg, bool):
                return Datatype.int
            if isinstance(arg, int):
                return Datatype.int
            if isinstance(arg, float):
                return Datatype.float
            raise TypeError(
                f"arg {arg_name!r} expected Var/int/float, got {type(arg).__name__}"
            )
        raise AssertionError(f"unknown kind: {kind}")

    @staticmethod
    def _fmt_dtypes(dtypes: List[DataTypeValue]) -> str:
        return "(" + ", ".join(str(d) for d in dtypes) + ")"

    @staticmethod
    def _load_source(func: Callable[..., Any]) -> Tuple[str, int, List[str]]:
        try:
            source_lines, start_line = inspect.getsourcelines(func)
        except (OSError, TypeError) as exc:
            raise RuntimeError(
                f"SimtModule cannot retrieve source for {func.__name__!r}"
            ) from exc
        source_path = inspect.getsourcefile(func) or inspect.getfile(func)
        source = textwrap.dedent("".join(source_lines))
        return source_path, start_line, source.splitlines()

    @staticmethod
    def _parse_func_def(func: Callable[..., Any], source: str) -> ast.FunctionDef:
        tree = ast.parse(source, filename=inspect.getsourcefile(func) or "<unknown>")
        for node in tree.body:
            if isinstance(node, ast.FunctionDef):
                return node
        raise ValueError(
            f"SimtModule expected a function definition for {func.__name__!r}"
        )

    def _extract_inputs(self, func_def: ast.FunctionDef) -> List[Tuple[str, str]]:
        args = func_def.args
        if args.kwonlyargs or args.posonlyargs or args.vararg or args.kwarg or args.defaults:
            raise self._source_error(
                TypeError(
                    f"SimtModule {func_def.name!r}: only positional args without defaults are supported"
                ),
                func_def,
            )
        inputs: List[Tuple[str, str]] = []
        for arg in args.args:
            ann = arg.annotation
            if not isinstance(ann, ast.Name):
                raise self._source_error(
                    TypeError(
                        f"SimtModule arg {arg.arg!r} requires a simple type annotation "
                        f"(GMTensor, Tensor, or Var)"
                    ),
                    ann or arg,
                )
            if ann.id not in _VALID_KINDS:
                raise self._source_error(
                    TypeError(
                        f"SimtModule arg {arg.arg!r} has unsupported annotation {ann.id!r}; "
                        f"expected one of {_VALID_KINDS}"
                    ),
                    ann,
                )
            inputs.append((arg.arg, ann.id))
        return inputs

    def _source_error(self, exc: Exception, node: Optional[ast.AST]) -> Exception:
        return self._wrap_source_error(exc, node)

    def _wrap_source_error(
        self, exc: Exception, node: Optional[ast.AST]
    ) -> Exception:
        if getattr(exc, _SIMT_SOURCE_CONTEXT_ATTR, False):
            return exc
        message = self._format_source_error(exc, node)
        try:
            wrapped = type(exc)(message)
        except Exception:
            wrapped = RuntimeError(message)
        setattr(wrapped, _SIMT_SOURCE_CONTEXT_ATTR, True)
        return wrapped

    def _format_source_error(
        self, exc: Exception, node: Optional[ast.AST]
    ) -> str:
        line_no = self._source_line_no(node)
        if line_no is None:
            location = self.source_path
        else:
            location = f"{self.source_path}:{line_no}"
        source_line = self._source_line_text(node)
        if source_line:
            return (
                f"{exc}\n"
                f"  SIMT source line: {location} in @{self.name}\n"
                f"  >> {source_line.strip()}"
            )
        return f"{exc}\n  SIMT source line: {location} in @{self.name}"

    def _source_line_no(self, node: Optional[ast.AST]) -> Optional[int]:
        if node is None:
            return None
        lineno = getattr(node, "lineno", None)
        if not isinstance(lineno, int):
            return None
        return self.source_start_line + lineno - 1

    def _source_line_text(self, node: Optional[ast.AST]) -> str:
        if node is None:
            return ""
        lineno = getattr(node, "lineno", None)
        if not isinstance(lineno, int):
            return ""
        index = lineno - 1
        if index < 0 or index >= len(self.source_lines):
            return ""
        return self.source_lines[index]

    def render(self) -> str:
        if self._locked_dtypes is None:
            raise RuntimeError(
                f"SimtModule {self.name!r}: dtype signature not locked; "
                f"call the module once with concrete args first"
            )
        args_str = ", ".join(
            self._format_arg(name, kind, dtype)
            for (name, kind), dtype in zip(self.input_list, self._locked_dtypes)
        )
        dtype_env: Dict[str, DataTypeValue] = {
            name: dtype
            for (name, _), dtype in zip(self.input_list, self._locked_dtypes)
        }
        body_lines = self._emit_block_body(self.func_def.body, dtype_env)
        body = "\n".join("    " + line if line else "" for line in body_lines)
        return (
            "#pragma once\n\n"
            f"__simt_vf__ __launch_bounds__({self.num_threads})"
            f" inline void {self.name}({args_str}){{\n{body}\n}}\n"
        )

    def gen_code(self, path: str) -> None:
        if not isinstance(path, str):
            raise TypeError(f"path must be str, got: {type(path)}")
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.render())

    @staticmethod
    def _format_arg(name: str, kind: str, dtype: DataTypeValue) -> str:
        cpp = dtype_to_cpp(dtype)
        if kind == _KIND_GMTENSOR:
            return f"__gm__ {cpp}* {name}"
        if kind == _KIND_TENSOR:
            return f"__ubuf__ {cpp}* {name}"
        if kind == _KIND_VAR:
            return f"{cpp} {name}"
        raise AssertionError(f"unknown kind: {kind}")

    @classmethod
    def _collect_local_names(cls, func_def: ast.FunctionDef) -> frozenset:
        names = set()
        for node in ast.walk(func_def):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    names.update(cls._store_names(target))
            elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
                names.update(cls._store_names(node.target))
            elif isinstance(node, (ast.For, ast.AsyncFor)):
                names.update(cls._store_names(node.target))
        return frozenset(names)

    @classmethod
    def _store_names(cls, node: ast.AST) -> List[str]:
        if isinstance(node, ast.Name):
            return [node.id]
        if isinstance(node, (ast.Tuple, ast.List)):
            out: List[str] = []
            for elt in node.elts:
                out.extend(cls._store_names(elt))
            return out
        return []

    def _literal_global_value(self, name: str) -> Optional[Any]:
        if name in self._formal_names or name in self._local_names:
            return None
        if name not in self.func.__globals__:
            return None
        value = self.func.__globals__[name]
        if isinstance(value, bool):
            return value
        if isinstance(value, numbers.Integral):
            return int(value)
        if isinstance(value, numbers.Real):
            return float(value)
        return None

    def _emit_block_body(
        self, stmts: List[ast.stmt], dtype_env: Dict[str, DataTypeValue]
    ) -> List[str]:
        snapshot = set(dtype_env)
        out: List[str] = []
        for stmt in stmts:
            try:
                out.extend(self._emit_stmt(stmt, dtype_env))
            except Exception as exc:
                raise self._wrap_source_error(exc, stmt) from exc
        for name in list(dtype_env):
            if name not in snapshot:
                del dtype_env[name]
        return out

    @staticmethod
    def _indent_lines(lines: List[str]) -> List[str]:
        return ["    " + ln if ln else "" for ln in lines]

    def _emit_stmt(
        self, stmt: ast.stmt, dtype_env: Dict[str, DataTypeValue]
    ) -> List[str]:
        if isinstance(stmt, ast.Assign):
            if len(stmt.targets) != 1:
                raise NotImplementedError(
                    "SimtModule supports only single-target assignment"
                )
            target = stmt.targets[0]
            value_text = self._emit_expr(stmt.value)
            value_dtype = self._infer_expr_dtype(stmt.value, dtype_env)
            if isinstance(target, ast.Name):
                if target.id in dtype_env:
                    self._require_same_dtype(
                        dtype_env[target.id], value_dtype, f"assign to {target.id!r}"
                    )
                    return [f"{target.id} = {value_text};"]
                dtype_env[target.id] = value_dtype
                return [f"{dtype_to_cpp(value_dtype)} {target.id} = {value_text};"]
            if isinstance(target, ast.Subscript):
                target_dtype = self._infer_expr_dtype(target, dtype_env)
                self._require_same_dtype(
                    target_dtype, value_dtype, "subscript assign"
                )
                return [f"{self._emit_expr(target)} = {value_text};"]
            raise NotImplementedError(
                f"Unsupported assignment target: {type(target).__name__}"
            )
        if isinstance(stmt, ast.AugAssign):
            target_dtype = self._infer_expr_dtype(stmt.target, dtype_env)
            value_dtype = self._infer_expr_dtype(stmt.value, dtype_env)
            self._require_same_dtype(target_dtype, value_dtype, "augmented assign")
            target_text = self._emit_expr(stmt.target)
            value_text = self._emit_expr(stmt.value)
            return [f"{target_text} {self._binop_symbol(stmt.op)}= {value_text};"]
        if isinstance(stmt, ast.Expr):
            # Skip docstrings / bare string statements that have no codegen.
            if isinstance(stmt.value, ast.Constant) and isinstance(
                stmt.value.value, str
            ):
                return []
            if isinstance(stmt.value, ast.Call):
                if self._is_atomic_call(stmt.value):
                    return [self._emit_atomic_stmt(stmt.value, dtype_env)]
                if self._is_thread_barrier_call(stmt.value):
                    self._validate_thread_barrier_call(stmt.value)
                    return ["Simt::ThreadBarrier();"]
            return [f"{self._emit_expr(stmt.value)};"]
        if isinstance(stmt, ast.For):
            return self._emit_for(stmt, dtype_env)
        if isinstance(stmt, ast.While):
            return self._emit_while(stmt, dtype_env)
        if isinstance(stmt, ast.If):
            return self._emit_if(stmt, dtype_env)
        if isinstance(stmt, ast.Break):
            return ["break;"]
        if isinstance(stmt, ast.Continue):
            return ["continue;"]
        raise NotImplementedError(f"Unsupported statement: {type(stmt).__name__}")

    def _emit_for(
        self, stmt: ast.For, dtype_env: Dict[str, DataTypeValue]
    ) -> List[str]:
        if stmt.orelse:
            raise NotImplementedError("for-else is not supported")
        if not isinstance(stmt.target, ast.Name):
            raise NotImplementedError(
                "for loop only supports a single Name target"
            )
        if not (
            isinstance(stmt.iter, ast.Call)
            and isinstance(stmt.iter.func, ast.Name)
            and stmt.iter.func.id == "range"
        ):
            raise NotImplementedError(
                "for loop only supports `range(...)` as the iterable"
            )
        if stmt.iter.keywords:
            raise TypeError("range() does not accept keyword arguments")
        range_args = stmt.iter.args
        if not 1 <= len(range_args) <= 3:
            raise TypeError(
                f"range() expects 1, 2, or 3 args, got {len(range_args)}"
            )
        for arg in range_args:
            arg_dt = self._infer_expr_dtype(arg, dtype_env)
            if arg_dt != Datatype.int:
                raise TypeError(
                    f"range() args must be int, got {arg_dt}"
                )
        if len(range_args) == 1:
            start_text, stop_text, step_text = "0", self._emit_expr(range_args[0]), "1"
        elif len(range_args) == 2:
            start_text = self._emit_expr(range_args[0])
            stop_text = self._emit_expr(range_args[1])
            step_text = "1"
        else:
            start_text = self._emit_expr(range_args[0])
            stop_text = self._emit_expr(range_args[1])
            step_text = self._emit_expr(range_args[2])
        var = stmt.target.id
        if var in dtype_env:
            raise NameError(
                f"SimtModule {self.name!r}: loop variable {var!r} shadows existing name"
            )
        dtype_env[var] = Datatype.int
        try:
            body_lines = self._emit_block_body(stmt.body, dtype_env)
        finally:
            dtype_env.pop(var, None)
        if step_text == "1":
            header = f"for (int {var} = {start_text}; {var} < {stop_text}; {var}++) {{"
        else:
            header = f"for (int {var} = {start_text}; {var} < {stop_text}; {var} += {step_text}) {{"
        return [header] + self._indent_lines(body_lines) + ["}"]

    def _emit_while(
        self, stmt: ast.While, dtype_env: Dict[str, DataTypeValue]
    ) -> List[str]:
        if stmt.orelse:
            raise NotImplementedError("while-else is not supported")
        cond_text = self._emit_expr(stmt.test)
        body_lines = self._emit_block_body(stmt.body, dtype_env)
        return [f"while ({cond_text}) {{"] + self._indent_lines(body_lines) + ["}"]

    def _emit_if(
        self, stmt: ast.If, dtype_env: Dict[str, DataTypeValue]
    ) -> List[str]:
        cond_text = self._emit_expr(stmt.test)
        then_lines = self._emit_block_body(stmt.body, dtype_env)
        out: List[str] = [f"if ({cond_text}) {{"] + self._indent_lines(then_lines) + ["}"]
        orelse = stmt.orelse
        while orelse:
            if len(orelse) == 1 and isinstance(orelse[0], ast.If):
                elif_stmt = orelse[0]
                cond_text = self._emit_expr(elif_stmt.test)
                then_lines = self._emit_block_body(elif_stmt.body, dtype_env)
                out[-1] = f"}} else if ({cond_text}) {{"
                out.extend(self._indent_lines(then_lines))
                out.append("}")
                orelse = elif_stmt.orelse
            else:
                else_lines = self._emit_block_body(orelse, dtype_env)
                out[-1] = "} else {"
                out.extend(self._indent_lines(else_lines))
                out.append("}")
                orelse = []
        return out

    def _emit_expr(self, node: ast.AST) -> str:
        if isinstance(node, ast.Name):
            literal = self._literal_global_value(node.id)
            if literal is not None:
                return self._format_constant(literal)
            return node.id
        if isinstance(node, ast.Constant):
            return self._format_constant(node.value)
        if isinstance(node, ast.Subscript):
            base = self._emit_expr(node.value)
            index = self._emit_expr(self._unwrap_index(node.slice))
            return f"{base}[{index}]"
        if isinstance(node, ast.BinOp):
            left = self._emit_binop_operand(node, node.left, is_right=False)
            right = self._emit_binop_operand(node, node.right, is_right=True)
            return f"{left} {self._binop_symbol(node.op)} {right}"
        if isinstance(node, ast.UnaryOp):
            return f"{self._unary_symbol(node.op)}{self._emit_unary_operand(node.operand)}"
        if isinstance(node, ast.Compare):
            if len(node.ops) != 1 or len(node.comparators) != 1:
                raise NotImplementedError(
                    "chained comparisons are not supported; split into && expressions"
                )
            left = self._emit_compare_operand(node.left)
            right = self._emit_compare_operand(node.comparators[0])
            return f"{left} {self._compare_symbol(node.ops[0])} {right}"
        if isinstance(node, ast.BoolOp):
            sym = "&&" if isinstance(node.op, ast.And) else "||"
            parts = [self._emit_boolop_operand(child) for child in node.values]
            return f" {sym} ".join(parts)
        if isinstance(node, ast.Call):
            return self._emit_call(node)
        raise NotImplementedError(f"Unsupported expression: {type(node).__name__}")

    def _emit_boolop_operand(self, child: ast.AST) -> str:
        text = self._emit_expr(child)
        if isinstance(child, (ast.BoolOp, ast.Compare, ast.BinOp, ast.UnaryOp)):
            return f"({text})"
        return text

    def _emit_compare_operand(self, child: ast.AST) -> str:
        """Keep Python comparison operands grouped in generated C++.

        C++ equality/relational operators bind more tightly than bitwise AND,
        XOR, and OR.  Without the explicit grouping, Python expressions such
        as ``(raw & mask) != 0`` were emitted as ``raw & mask != 0`` and thus
        changed meaning only in device code while the simulator stayed right.
        """
        text = self._emit_expr(child)
        if isinstance(child, (ast.BinOp, ast.BoolOp, ast.Compare)):
            return f"({text})"
        return text

    def _emit_call(self, call: ast.Call) -> str:
        if self._is_cvt_call(call):
            dt = self._resolve_cvt_dtype(call)
            inner = self._emit_expr(call.args[0])
            return f"({dtype_to_cpp(dt)})({inner})"
        if self._is_fma_call(call):
            self._validate_fma_call(call)
            lhs = self._emit_expr(call.args[0])
            rhs = self._emit_expr(call.args[1])
            addend = self._emit_expr(call.args[2])
            return f"(({lhs}) * ({rhs}) + ({addend}))"
        if self._is_ffs_call(call):
            self._validate_ffs_call(call)
            value = self._emit_expr(call.args[0])
            return f"Simt::Ffs({value})"
        if self._is_minmax_call(call):
            self._validate_minmax_call(call)
            left = self._emit_expr(call.args[0])
            right = self._emit_expr(call.args[1])
            sym = "<" if call.func.id == "Min" else ">"
            return f"((({left}) {sym} ({right})) ? ({left}) : ({right}))"
        intrinsic = self._intrinsic_template(call)
        if intrinsic is not None:
            return intrinsic
        raise NotImplementedError(
            f"SimtModule {self.name!r}: unsupported call {self._call_repr(call)}"
        )

    def _intrinsic_template(self, call: ast.Call) -> Optional[str]:
        if not isinstance(call.func, ast.Name):
            return None
        template = _SIMT_NULLARY_INTRINSICS.get(call.func.id)
        if template is None:
            return None
        if call.args or call.keywords:
            raise TypeError(
                f"SimtModule {self.name!r}: {call.func.id}() takes no arguments"
            )
        return template

    @staticmethod
    def _is_atomic_call(call: ast.Call) -> bool:
        return (
            isinstance(call.func, ast.Name)
            and call.func.id in _SIMT_ATOMIC_OPS
        )

    def _formal_kind(self, name: str) -> Optional[str]:
        for formal_name, kind in self.input_list:
            if formal_name == name:
                return kind
        return None

    def _resolve_atomic_target(
        self, call: ast.Call, dtype_env: Dict[str, DataTypeValue]
    ) -> Tuple[str, Optional[ast.AST], DataTypeValue]:
        op_name = call.func.id  # type: ignore[attr-defined]
        arg_count = 3 if op_name == "simt_atomic_cas" else 2
        if call.keywords or len(call.args) != arg_count:
            raise TypeError(
                f"SimtModule {self.name!r}: {op_name} requires exactly "
                f"{arg_count} positional args"
            )
        target_node = call.args[0]
        if isinstance(target_node, ast.Subscript):
            base_node = target_node.value
            if not isinstance(base_node, ast.Name):
                raise TypeError(
                    f"SimtModule {self.name!r}: {op_name} target subscript base "
                    f"must be a Name (got {type(base_node).__name__})"
                )
            base_name = base_node.id
            index_node = self._unwrap_index(target_node.slice)
        elif isinstance(target_node, ast.Name):
            base_name = target_node.id
            index_node = None
        else:
            raise TypeError(
                f"SimtModule {self.name!r}: {op_name} target must be a tensor "
                f"name or tensor[index] expression "
                f"(got {type(target_node).__name__})"
            )
        kind = self._formal_kind(base_name)
        if kind not in (_KIND_GMTENSOR, _KIND_TENSOR):
            raise TypeError(
                f"SimtModule {self.name!r}: {op_name} target {base_name!r} "
                f"must be a GMTensor or Tensor formal parameter"
            )
        if base_name not in dtype_env:
            raise NameError(
                f"SimtModule {self.name!r}: unknown name {base_name!r}"
            )
        return base_name, index_node, dtype_env[base_name]

    def _emit_atomic_stmt(
        self, call: ast.Call, dtype_env: Dict[str, DataTypeValue]
    ) -> str:
        op_name = call.func.id  # type: ignore[attr-defined]
        _, cpp_name = _SIMT_ATOMIC_OPS[op_name]
        base_name, index_node, base_dtype = self._resolve_atomic_target(
            call, dtype_env
        )
        compare_node = call.args[1] if op_name == "simt_atomic_cas" else None
        value_node = call.args[2] if compare_node is not None else call.args[1]
        if compare_node is not None:
            compare_dtype = self._infer_expr_dtype(compare_node, dtype_env)
            self._require_same_dtype(
                base_dtype, compare_dtype,
                f"{op_name} compare vs tensor element",
            )
        value_dtype = self._infer_expr_dtype(value_node, dtype_env)
        self._require_same_dtype(
            base_dtype, value_dtype, f"{op_name} value vs tensor element"
        )
        value_text = self._emit_expr(value_node)
        if index_node is None:
            target_text = base_name
        else:
            self._require_index_expr(index_node, dtype_env, op_name)
            index_text = self._emit_expr(index_node)
            target_text = f"{base_name} + ({index_text})"
        if compare_node is not None:
            compare_text = self._emit_expr(compare_node)
            return f"{cpp_name}({target_text}, {compare_text}, {value_text});"
        return f"{cpp_name}({target_text}, {value_text});"

    @staticmethod
    def _is_cvt_call(call: ast.Call) -> bool:
        return isinstance(call.func, ast.Name) and call.func.id == "cvt"

    @staticmethod
    def _is_fma_call(call: ast.Call) -> bool:
        return isinstance(call.func, ast.Name) and call.func.id == "simt_fma"

    @staticmethod
    def _is_ffs_call(call: ast.Call) -> bool:
        return isinstance(call.func, ast.Name) and call.func.id == "simt_ffs"

    @staticmethod
    def _is_thread_barrier_call(call: ast.Call) -> bool:
        return (
            isinstance(call.func, ast.Name)
            and call.func.id == "simt_thread_barrier"
        )

    def _validate_thread_barrier_call(self, call: ast.Call) -> None:
        if call.args or call.keywords:
            raise TypeError(
                f"SimtModule {self.name!r}: simt_thread_barrier() takes no arguments"
            )

    @staticmethod
    def _is_minmax_call(call: ast.Call) -> bool:
        return (
            isinstance(call.func, ast.Name)
            and call.func.id in _SIMT_BINARY_INTRINSICS
        )

    def _validate_minmax_call(
        self, call: ast.Call,
        dtype_env: Optional[Dict[str, DataTypeValue]] = None,
    ) -> DataTypeValue:
        name = call.func.id
        if call.keywords or len(call.args) != 2:
            raise TypeError(
                f"SimtModule {self.name!r}: {name}() expects exactly 2 "
                f"positional args, got {self._call_repr(call)}"
            )
        for arg in call.args:
            # The ternary evaluates the winning operand twice, which is free for
            # scalar arithmetic but would issue a second memory access.
            for node in ast.walk(arg):
                if isinstance(node, ast.Subscript):
                    raise TypeError(
                        f"SimtModule {self.name!r}: {name}() operands must be "
                        "scalar expressions, not tensor reads; hoist the read "
                        "into a local first"
                    )
        if dtype_env is None:
            return Datatype.int
        left = self._infer_expr_dtype(call.args[0], dtype_env)
        right = self._infer_expr_dtype(call.args[1], dtype_env)
        return self._infer_binary_dtype(left, right, name)

    def _validate_ffs_call(
        self, call: ast.Call,
        dtype_env: Optional[Dict[str, DataTypeValue]] = None,
    ) -> DataTypeValue:
        if call.keywords or len(call.args) != 1:
            raise TypeError(
                f"SimtModule {self.name!r}: simt_ffs() expects exactly 1 "
                f"positional arg, got {self._call_repr(call)}"
            )
        if dtype_env is not None:
            dtype = self._infer_expr_dtype(call.args[0], dtype_env)
            if dtype not in (Datatype.int, Datatype.int64):
                raise TypeError(
                    f"SimtModule {self.name!r}: simt_ffs() supports signed "
                    f"int32/int64 operands, got {dtype}"
                )
        return Datatype.int

    def _validate_fma_call(
        self, call: ast.Call, dtype_env: Optional[Dict[str, DataTypeValue]] = None
    ) -> DataTypeValue:
        if call.keywords or len(call.args) != 3:
            raise TypeError(
                f"SimtModule {self.name!r}: simt_fma() expects exactly 3 "
                f"positional args, got {self._call_repr(call)}"
            )
        if dtype_env is None:
            return Datatype.float
        dtypes = [self._infer_expr_dtype(arg, dtype_env) for arg in call.args]
        if any(dtype != Datatype.float for dtype in dtypes):
            raise TypeError(
                f"SimtModule {self.name!r}: simt_fma() supports three fp32 "
                f"operands, got {dtypes}"
            )
        return Datatype.float

    def _resolve_cvt_dtype(self, call: ast.Call) -> DataTypeValue:
        if call.keywords or len(call.args) != 2:
            raise TypeError(
                f"SimtModule {self.name!r}: cvt() expects exactly 2 positional args, "
                f"got {self._call_repr(call)}"
            )
        dtype_node = call.args[1]
        if not (isinstance(dtype_node, ast.Attribute) and isinstance(dtype_node.value, ast.Name)):
            raise TypeError(
                f"SimtModule {self.name!r}: cvt() second arg must be Datatype.X "
                f"(or DT.X if aliased), got {ast.dump(dtype_node)}"
            )
        dt = getattr(Datatype, dtype_node.attr, None)
        if not isinstance(dt, DataTypeValue):
            raise TypeError(
                f"SimtModule {self.name!r}: unknown dtype Datatype.{dtype_node.attr}"
            )
        return dt

    @staticmethod
    def _call_repr(call: ast.Call) -> str:
        if isinstance(call.func, ast.Name):
            return f"{call.func.id}(...)"
        return ast.dump(call.func)

    def _emit_binop_operand(self, parent: ast.BinOp, child: ast.AST, is_right: bool) -> str:
        text = self._emit_expr(child)
        if not isinstance(child, ast.BinOp):
            return text
        if (
            isinstance(parent.op, (ast.LShift, ast.RShift))
            and isinstance(child.op, (ast.Add, ast.Sub))
        ):
            # C++ parses the ungrouped form correctly because +/- bind more
            # tightly than shifts, but Clang's -Wshift-op-parentheses still
            # warns. Keep the arithmetic operand explicit in device code.
            return f"({text})"
        parent_p = _BINOP_PREC[type(parent.op)]
        child_p = _BINOP_PREC[type(child.op)]
        if child_p <= parent_p:
            # Equal precedence is grouped too. Float + and * are not
            # associative, so flattening `c + ((a - b) + (d - e))` into
            # `c + a - b + d - e` changes the result: compensated-summation
            # kernels lose exactly the small terms they exist to keep. The
            # simulator evaluates the Python expression as written, so an
            # ungrouped emit only ever diverged on device.
            return f"({text})"
        return text

    def _emit_unary_operand(self, child: ast.AST) -> str:
        text = self._emit_expr(child)
        if isinstance(child, (ast.BinOp, ast.UnaryOp, ast.Compare, ast.BoolOp)):
            return f"({text})"
        return text

    def _infer_expr_dtype(
        self, node: ast.AST, dtype_env: Dict[str, DataTypeValue]
    ) -> DataTypeValue:
        if isinstance(node, ast.Name):
            literal = self._literal_global_value(node.id)
            if literal is not None:
                return self._literal_dtype(literal)
            if node.id not in dtype_env:
                raise NameError(
                    f"SimtModule {self.name!r}: unknown name {node.id!r}"
                )
            return dtype_env[node.id]
        if isinstance(node, ast.Constant):
            return self._literal_dtype(node.value)
        if isinstance(node, ast.Subscript):
            self._require_index_expr(
                self._unwrap_index(node.slice), dtype_env, "subscript"
            )
            return self._infer_expr_dtype(node.value, dtype_env)
        if isinstance(node, ast.BinOp):
            left = self._infer_expr_dtype(node.left, dtype_env)
            right = self._infer_expr_dtype(node.right, dtype_env)
            return self._infer_binary_dtype(
                left, right, f"binary op {self._binop_symbol(node.op)}"
            )
        if isinstance(node, ast.UnaryOp):
            if isinstance(node.op, ast.Not):
                self._infer_expr_dtype(node.operand, dtype_env)
                return Datatype.int
            return self._infer_expr_dtype(node.operand, dtype_env)
        if isinstance(node, ast.Compare):
            if len(node.ops) != 1 or len(node.comparators) != 1:
                raise NotImplementedError(
                    "chained comparisons are not supported"
                )
            left = self._infer_expr_dtype(node.left, dtype_env)
            right = self._infer_expr_dtype(node.comparators[0], dtype_env)
            self._infer_binary_dtype(
                left, right, f"comparison {self._compare_symbol(node.ops[0])}"
            )
            return Datatype.int
        if isinstance(node, ast.BoolOp):
            for child in node.values:
                self._infer_expr_dtype(child, dtype_env)
            return Datatype.int
        if isinstance(node, ast.Call):
            if self._is_cvt_call(node):
                dt = self._resolve_cvt_dtype(node)
                self._infer_expr_dtype(node.args[0], dtype_env)
                return dt
            if self._is_fma_call(node):
                return self._validate_fma_call(node, dtype_env)
            if self._is_ffs_call(node):
                return self._validate_ffs_call(node, dtype_env)
            if self._is_minmax_call(node):
                return self._validate_minmax_call(node, dtype_env)
            if isinstance(node.func, ast.Name) and node.func.id in _SIMT_NULLARY_INTRINSICS:
                if node.args or node.keywords:
                    raise TypeError(
                        f"SimtModule {self.name!r}: {node.func.id}() takes no arguments"
                    )
                return Datatype.int
            raise NotImplementedError(
                f"SimtModule {self.name!r}: cannot infer dtype for call "
                f"{self._call_repr(node)}"
            )
        raise NotImplementedError(
            f"Cannot infer dtype for {type(node).__name__}"
        )

    @staticmethod
    def _literal_dtype(value: Any) -> DataTypeValue:
        if isinstance(value, bool):
            return Datatype.int
        if isinstance(value, int):
            # A literal too wide for int32 is int64, the same rule C++ applies
            # to an integer literal.  Calling it int32 made the emitted C++
            # right (the literal widens on its own) but the simulator wrong --
            # it built an int32 tensor from the constant and overflowed.
            if value < -2147483648 or value > 2147483647:
                return Datatype.int64
            return Datatype.int
        if isinstance(value, float):
            return Datatype.float
        raise NotImplementedError(
            f"Unsupported constant dtype: {type(value).__name__}"
        )

    def _require_same_dtype(
        self, left: DataTypeValue, right: DataTypeValue, context: str
    ) -> None:
        if left != right:
            raise TypeError(
                f"SimtModule {self.name!r}: dtype mismatch in {context}: "
                f"{left} vs {right}"
            )

    @staticmethod
    def _is_integer_dtype(dtype: DataTypeValue) -> bool:
        return dtype in _SIMT_INTEGER_RANK

    @staticmethod
    def _promote_integer_dtype(
        left: DataTypeValue, right: DataTypeValue
    ) -> Optional[DataTypeValue]:
        if left not in _SIMT_INTEGER_RANK or right not in _SIMT_INTEGER_RANK:
            return None
        return left if _SIMT_INTEGER_RANK[left] >= _SIMT_INTEGER_RANK[right] else right

    def _infer_binary_dtype(
        self, left: DataTypeValue, right: DataTypeValue, context: str
    ) -> DataTypeValue:
        if left == right:
            return left
        promoted = self._promote_integer_dtype(left, right)
        if promoted is not None:
            return promoted
        self._require_same_dtype(left, right, context)
        return left

    def _require_index_expr(
        self, node: ast.AST, dtype_env: Dict[str, DataTypeValue], context: str
    ) -> None:
        index_dtype = self._infer_expr_dtype(node, dtype_env)
        if not self._is_integer_dtype(index_dtype):
            raise TypeError(
                f"SimtModule {self.name!r}: {context} index must be int, "
                f"uint32, int64, or uint64, got {index_dtype}"
            )

    @staticmethod
    def _binop_symbol(op: ast.AST) -> str:
        symbol = _BINOP_SYMBOL.get(type(op))
        if symbol is None:
            raise NotImplementedError(
                f"Unsupported binary operator: {type(op).__name__}"
            )
        return symbol

    @staticmethod
    def _binop_ir_symbol(op: ast.AST) -> str:
        symbol = _BINOP_IR_SYMBOL.get(type(op))
        if symbol is None:
            raise NotImplementedError(
                f"Unsupported binary operator: {type(op).__name__}"
            )
        return symbol

    @staticmethod
    def _unary_symbol(op: ast.AST) -> str:
        if isinstance(op, ast.UAdd):
            return "+"
        if isinstance(op, ast.USub):
            return "-"
        if isinstance(op, ast.Not):
            return "!"
        raise NotImplementedError(f"Unsupported unary operator: {type(op).__name__}")

    @staticmethod
    def _compare_symbol(op: ast.AST) -> str:
        if isinstance(op, ast.Lt):
            return "<"
        if isinstance(op, ast.LtE):
            return "<="
        if isinstance(op, ast.Gt):
            return ">"
        if isinstance(op, ast.GtE):
            return ">="
        if isinstance(op, ast.Eq):
            return "=="
        if isinstance(op, ast.NotEq):
            return "!="
        raise NotImplementedError(
            f"Unsupported comparison operator: {type(op).__name__}"
        )

    @staticmethod
    def _format_constant(value: Any) -> str:
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            return repr(value) + "f"
        raise NotImplementedError(
            f"Unsupported constant: {type(value).__name__}"
        )

    @staticmethod
    def _unwrap_index(sl: ast.AST) -> ast.AST:
        index_cls = getattr(ast, "Index", None)
        if index_cls is not None and isinstance(sl, index_cls):
            return sl.value
        return sl

    # ------------------------------------------------------------------
    # IR lowering (parallel path to render(), used by the simulator)
    # ------------------------------------------------------------------

    def lower_to_ir(self) -> List[Instruction]:
        if self._locked_dtypes is None:
            raise RuntimeError(
                f"SimtModule {self.name!r}: dtype signature not locked; "
                f"call the module once with concrete args first"
            )
        if self._ir_instructions is not None:
            return self._ir_instructions
        dtype_env: Dict[str, DataTypeValue] = {
            name: dtype
            for (name, _), dtype in zip(self.input_list, self._locked_dtypes)
        }
        body = self._lower_block_body(self.func_def.body, dtype_env)
        self._ir_instructions = body
        return body

    def _lower_block_body(
        self, stmts: List[ast.stmt], dtype_env: Dict[str, DataTypeValue]
    ) -> List[Instruction]:
        snapshot = set(dtype_env)
        out: List[Instruction] = []
        for stmt in stmts:
            try:
                out.extend(self._lower_stmt(stmt, dtype_env))
            except Exception as exc:
                raise self._wrap_source_error(exc, stmt) from exc
        for name in list(dtype_env):
            if name not in snapshot:
                del dtype_env[name]
        return out

    def _lower_stmt(
        self, stmt: ast.stmt, dtype_env: Dict[str, DataTypeValue]
    ) -> List[Instruction]:
        if isinstance(stmt, ast.Assign):
            if len(stmt.targets) != 1:
                raise NotImplementedError(
                    "SimtModule supports only single-target assignment"
                )
            target = stmt.targets[0]
            rhs_expr = self._lower_expr(stmt.value)
            rhs_dtype = self._infer_expr_dtype(stmt.value, dtype_env)
            if isinstance(target, ast.Name):
                if target.id in dtype_env:
                    self._require_same_dtype(
                        dtype_env[target.id], rhs_dtype, f"assign to {target.id!r}"
                    )
                    return [Instruction(
                        "simt_assign",
                        target_kind="name",
                        target=target.id,
                        expr=rhs_expr,
                        decl_dtype=None,
                    )]
                dtype_env[target.id] = rhs_dtype
                return [Instruction(
                    "simt_assign",
                    target_kind="name",
                    target=target.id,
                    expr=rhs_expr,
                    decl_dtype=str(rhs_dtype.name),
                )]
            if isinstance(target, ast.Subscript):
                target_dtype = self._infer_expr_dtype(target, dtype_env)
                self._require_same_dtype(
                    target_dtype, rhs_dtype, "subscript assign"
                )
                return [Instruction(
                    "simt_assign",
                    target_kind="subscript",
                    target=self._lower_expr(target),
                    expr=rhs_expr,
                    decl_dtype=None,
                )]
            raise NotImplementedError(
                f"Unsupported assignment target: {type(target).__name__}"
            )
        if isinstance(stmt, ast.AugAssign):
            target_dtype = self._infer_expr_dtype(stmt.target, dtype_env)
            value_dtype = self._infer_expr_dtype(stmt.value, dtype_env)
            self._require_same_dtype(target_dtype, value_dtype, "augmented assign")
            target_kind = (
                "name" if isinstance(stmt.target, ast.Name) else "subscript"
            )
            target_repr = (
                stmt.target.id
                if isinstance(stmt.target, ast.Name)
                else self._lower_expr(stmt.target)
            )
            return [Instruction(
                "simt_aug_assign",
                target_kind=target_kind,
                target=target_repr,
                op=self._binop_ir_symbol(stmt.op),
                expr=self._lower_expr(stmt.value),
            )]
        if isinstance(stmt, ast.Expr):
            # A bare expression statement whose value is a string literal is
            # almost always a docstring; skip it without trying to lower a
            # string constant (which the IR cannot represent).
            if isinstance(stmt.value, ast.Constant) and isinstance(
                stmt.value.value, str
            ):
                return []
            if isinstance(stmt.value, ast.Call):
                if self._is_atomic_call(stmt.value):
                    return [self._lower_atomic_stmt(stmt.value, dtype_env)]
                if self._is_thread_barrier_call(stmt.value):
                    self._validate_thread_barrier_call(stmt.value)
                    return [Instruction("simt_thread_barrier")]
            return [Instruction("simt_expr", expr=self._lower_expr(stmt.value))]
        if isinstance(stmt, ast.For):
            return self._lower_for(stmt, dtype_env)
        if isinstance(stmt, ast.While):
            return self._lower_while(stmt, dtype_env)
        if isinstance(stmt, ast.If):
            return self._lower_if(stmt, dtype_env)
        if isinstance(stmt, ast.Break):
            return [Instruction("simt_break")]
        if isinstance(stmt, ast.Continue):
            return [Instruction("simt_continue")]
        raise NotImplementedError(f"Unsupported statement: {type(stmt).__name__}")

    def _lower_for(
        self, stmt: ast.For, dtype_env: Dict[str, DataTypeValue]
    ) -> List[Instruction]:
        if stmt.orelse:
            raise NotImplementedError("for-else is not supported")
        if not isinstance(stmt.target, ast.Name):
            raise NotImplementedError(
                "for loop only supports a single Name target"
            )
        if not (
            isinstance(stmt.iter, ast.Call)
            and isinstance(stmt.iter.func, ast.Name)
            and stmt.iter.func.id == "range"
        ):
            raise NotImplementedError(
                "for loop only supports `range(...)` as the iterable"
            )
        if stmt.iter.keywords:
            raise TypeError("range() does not accept keyword arguments")
        range_args = stmt.iter.args
        if not 1 <= len(range_args) <= 3:
            raise TypeError(
                f"range() expects 1, 2, or 3 args, got {len(range_args)}"
            )
        for arg in range_args:
            arg_dt = self._infer_expr_dtype(arg, dtype_env)
            if arg_dt != Datatype.int:
                raise TypeError(f"range() args must be int, got {arg_dt}")
        const_int = lambda v: {"kind": "const", "value": v, "dtype": "int"}
        if len(range_args) == 1:
            start_expr = const_int(0)
            stop_expr = self._lower_expr(range_args[0])
            step_expr = const_int(1)
        elif len(range_args) == 2:
            start_expr = self._lower_expr(range_args[0])
            stop_expr = self._lower_expr(range_args[1])
            step_expr = const_int(1)
        else:
            start_expr = self._lower_expr(range_args[0])
            stop_expr = self._lower_expr(range_args[1])
            step_expr = self._lower_expr(range_args[2])
        var = stmt.target.id
        if var in dtype_env:
            raise NameError(
                f"SimtModule {self.name!r}: loop variable {var!r} shadows existing name"
            )
        dtype_env[var] = Datatype.int
        try:
            body = self._lower_block_body(stmt.body, dtype_env)
        finally:
            dtype_env.pop(var, None)
        return (
            [Instruction(
                "simt_for_range",
                var_name=var,
                start=start_expr,
                stop=stop_expr,
                step=step_expr,
            )]
            + body
            + [Instruction("simt_endfor")]
        )

    def _lower_while(
        self, stmt: ast.While, dtype_env: Dict[str, DataTypeValue]
    ) -> List[Instruction]:
        if stmt.orelse:
            raise NotImplementedError("while-else is not supported")
        cond = self._lower_expr(stmt.test)
        # Track dtype for soundness even though cond evaluates to int per
        # _infer_expr_dtype's compare/boolop rules.
        self._infer_expr_dtype(stmt.test, dtype_env)
        body = self._lower_block_body(stmt.body, dtype_env)
        return (
            [Instruction("simt_while", cond=cond)]
            + body
            + [Instruction("simt_endwhile")]
        )

    def _lower_if(
        self, stmt: ast.If, dtype_env: Dict[str, DataTypeValue]
    ) -> List[Instruction]:
        out: List[Instruction] = [
            Instruction("simt_if", cond=self._lower_expr(stmt.test))
        ]
        self._infer_expr_dtype(stmt.test, dtype_env)
        out.extend(self._lower_block_body(stmt.body, dtype_env))
        orelse = stmt.orelse
        while orelse:
            if len(orelse) == 1 and isinstance(orelse[0], ast.If):
                elif_stmt = orelse[0]
                out.append(Instruction(
                    "simt_elif", cond=self._lower_expr(elif_stmt.test)
                ))
                self._infer_expr_dtype(elif_stmt.test, dtype_env)
                out.extend(self._lower_block_body(elif_stmt.body, dtype_env))
                orelse = elif_stmt.orelse
            else:
                out.append(Instruction("simt_else"))
                out.extend(self._lower_block_body(orelse, dtype_env))
                orelse = []
        out.append(Instruction("simt_endif"))
        return out

    def _lower_expr(self, node: ast.AST) -> Dict[str, Any]:
        if isinstance(node, ast.Name):
            literal = self._literal_global_value(node.id)
            if literal is not None:
                return {
                    "kind": "const",
                    "value": literal,
                    "dtype": self._lower_const_dtype_name(literal),
                }
            return {"kind": "name", "id": node.id}
        if isinstance(node, ast.Constant):
            return {
                "kind": "const",
                "value": node.value,
                "dtype": self._lower_const_dtype_name(node.value),
            }
        if isinstance(node, ast.Subscript):
            base_node = node.value
            if not isinstance(base_node, ast.Name):
                raise NotImplementedError(
                    "SimtModule IR: subscript base must be a Name "
                    f"(got {type(base_node).__name__})"
                )
            return {
                "kind": "subscript",
                "base": base_node.id,
                "index": self._lower_expr(self._unwrap_index(node.slice)),
            }
        if isinstance(node, ast.BinOp):
            return {
                "kind": "binop",
                "op": self._binop_ir_symbol(node.op),
                "left": self._lower_expr(node.left),
                "right": self._lower_expr(node.right),
            }
        if isinstance(node, ast.UnaryOp):
            return {
                "kind": "unop",
                "op": self._unary_symbol(node.op),
                "operand": self._lower_expr(node.operand),
            }
        if isinstance(node, ast.Compare):
            if len(node.ops) != 1 or len(node.comparators) != 1:
                raise NotImplementedError(
                    "chained comparisons are not supported; split into && expressions"
                )
            return {
                "kind": "compare",
                "op": self._compare_symbol(node.ops[0]),
                "left": self._lower_expr(node.left),
                "right": self._lower_expr(node.comparators[0]),
            }
        if isinstance(node, ast.BoolOp):
            sym = "&&" if isinstance(node.op, ast.And) else "||"
            return {
                "kind": "boolop",
                "op": sym,
                "values": [self._lower_expr(child) for child in node.values],
            }
        if isinstance(node, ast.Call):
            if self._is_cvt_call(node):
                dt = self._resolve_cvt_dtype(node)
                return {
                    "kind": "cvt",
                    "dtype": str(dt.name),
                    "expr": self._lower_expr(node.args[0]),
                }
            if self._is_fma_call(node):
                return {
                    "kind": "fma",
                    "multiplicand0": self._lower_expr(node.args[0]),
                    "multiplicand1": self._lower_expr(node.args[1]),
                    "addend": self._lower_expr(node.args[2]),
                }
            if self._is_ffs_call(node):
                return {
                    "kind": "ffs",
                    "value": self._lower_expr(node.args[0]),
                }
            if self._is_minmax_call(node):
                self._validate_minmax_call(node)
                return {
                    "kind": "minmax",
                    "op": node.func.id,
                    "left": self._lower_expr(node.args[0]),
                    "right": self._lower_expr(node.args[1]),
                }
            if (
                isinstance(node.func, ast.Name)
                and node.func.id in _SIMT_NULLARY_INTRINSICS
            ):
                if node.args or node.keywords:
                    raise TypeError(
                        f"SimtModule {self.name!r}: {node.func.id}() takes no arguments"
                    )
                return {"kind": "intrinsic", "name": node.func.id}
            raise NotImplementedError(
                f"SimtModule {self.name!r}: unsupported call {self._call_repr(node)}"
            )
        raise NotImplementedError(
            f"Unsupported expression: {type(node).__name__}"
        )

    def _lower_atomic_stmt(
        self, call: ast.Call, dtype_env: Dict[str, DataTypeValue]
    ) -> Instruction:
        op_name = call.func.id  # type: ignore[attr-defined]
        op_short, _ = _SIMT_ATOMIC_OPS[op_name]
        base_name, index_node, base_dtype = self._resolve_atomic_target(
            call, dtype_env
        )
        compare_node = call.args[1] if op_name == "simt_atomic_cas" else None
        value_node = call.args[2] if compare_node is not None else call.args[1]
        if compare_node is not None:
            compare_dtype = self._infer_expr_dtype(compare_node, dtype_env)
            self._require_same_dtype(
                base_dtype, compare_dtype,
                f"{op_name} compare vs tensor element",
            )
        value_dtype = self._infer_expr_dtype(value_node, dtype_env)
        self._require_same_dtype(
            base_dtype, value_dtype, f"{op_name} value vs tensor element"
        )
        if index_node is None:
            index_expr: Dict[str, Any] = {
                "kind": "const", "value": 0, "dtype": "int",
            }
        else:
            self._require_index_expr(index_node, dtype_env, op_name)
            index_expr = self._lower_expr(index_node)
        value_expr = self._lower_expr(value_node)
        kwargs = {
            "op": op_short,
            "base": base_name,
            "index": index_expr,
            "value": value_expr,
        }
        if compare_node is not None:
            kwargs["compare"] = self._lower_expr(compare_node)
        return Instruction("simt_atomic", **kwargs)

    @staticmethod
    def _lower_const_dtype_name(value: Any) -> str:
        if isinstance(value, bool):
            return "int"
        if isinstance(value, int):
            # Match _literal_dtype: a literal outside int32 is int64, so the
            # simulator builds a wide enough tensor for it.
            if value < -2147483648 or value > 2147483647:
                return "int64_t"
            return "int"
        if isinstance(value, float):
            return "float"
        raise NotImplementedError(
            f"Unsupported constant: {type(value).__name__}"
        )

    # ------------------------------------------------------------------
    # Sync-key derivation for auto_sync (parallel to MicroModule)
    # ------------------------------------------------------------------

    def _ensure_formal_io(self) -> Tuple[frozenset, frozenset]:
        if self._read_formals is not None and self._write_formals is not None:
            return self._read_formals, self._write_formals
        ir = self.lower_to_ir()
        formal_kinds = {name: kind for (name, kind) in self.input_list}
        reads: set = set()
        writes: set = set()
        for inst in ir:
            self._walk_io(inst.opname, inst.kwargs, formal_kinds, reads, writes)
        self._read_formals = frozenset(reads)
        self._write_formals = frozenset(writes)
        return self._read_formals, self._write_formals

    def _walk_io(
        self,
        op: str,
        kw: Dict[str, Any],
        formal_kinds: Dict[str, str],
        reads: set,
        writes: set,
    ) -> None:
        if op == "simt_assign":
            target_kind = str(kw.get("target_kind", ""))
            if target_kind == "subscript":
                base = str(kw.get("target", {}).get("base", ""))
                if base in formal_kinds:
                    writes.add(base)
            self._walk_expr_reads(kw.get("expr"), formal_kinds, reads)
            return
        if op == "simt_aug_assign":
            target_kind = str(kw.get("target_kind", ""))
            if target_kind == "subscript":
                base = str(kw.get("target", {}).get("base", ""))
                if base in formal_kinds:
                    reads.add(base)
                    writes.add(base)
            self._walk_expr_reads(kw.get("expr"), formal_kinds, reads)
            return
        if op == "simt_expr":
            self._walk_expr_reads(kw.get("expr"), formal_kinds, reads)
            return
        if op == "simt_atomic":
            base = str(kw.get("base", ""))
            if base in formal_kinds:
                reads.add(base)
                writes.add(base)
            self._walk_expr_reads(kw.get("index"), formal_kinds, reads)
            self._walk_expr_reads(kw.get("compare"), formal_kinds, reads)
            self._walk_expr_reads(kw.get("value"), formal_kinds, reads)
            return
        if op == "simt_for_range":
            self._walk_expr_reads(kw.get("start"), formal_kinds, reads)
            self._walk_expr_reads(kw.get("stop"), formal_kinds, reads)
            self._walk_expr_reads(kw.get("step"), formal_kinds, reads)
            return
        if op in ("simt_while", "simt_if", "simt_elif"):
            self._walk_expr_reads(kw.get("cond"), formal_kinds, reads)
            return
        # simt_else / simt_endfor / simt_endwhile / simt_endif / simt_break
        # / simt_continue carry no expressions to scan.

    def _walk_expr_reads(
        self,
        expr: Any,
        formal_kinds: Dict[str, str],
        reads: set,
    ) -> None:
        if not isinstance(expr, dict):
            return
        kind = str(expr.get("kind", ""))
        if kind == "subscript":
            base = str(expr.get("base", ""))
            if base in formal_kinds:
                reads.add(base)
            self._walk_expr_reads(expr.get("index"), formal_kinds, reads)
            return
        if kind == "binop":
            self._walk_expr_reads(expr.get("left"), formal_kinds, reads)
            self._walk_expr_reads(expr.get("right"), formal_kinds, reads)
            return
        if kind == "unop":
            self._walk_expr_reads(expr.get("operand"), formal_kinds, reads)
            return
        if kind == "compare":
            self._walk_expr_reads(expr.get("left"), formal_kinds, reads)
            self._walk_expr_reads(expr.get("right"), formal_kinds, reads)
            return
        if kind == "boolop":
            for child in expr.get("values", []) or []:
                self._walk_expr_reads(child, formal_kinds, reads)
            return
        if kind == "cvt":
            self._walk_expr_reads(expr.get("expr"), formal_kinds, reads)
            return
        if kind == "fma":
            self._walk_expr_reads(expr.get("multiplicand0"), formal_kinds, reads)
            self._walk_expr_reads(expr.get("multiplicand1"), formal_kinds, reads)
            self._walk_expr_reads(expr.get("addend"), formal_kinds, reads)
            return
        if kind == "ffs":
            self._walk_expr_reads(expr.get("value"), formal_kinds, reads)
            return
        if kind == "minmax":
            self._walk_expr_reads(expr.get("left"), formal_kinds, reads)
            self._walk_expr_reads(expr.get("right"), formal_kinds, reads)
            return
        # name / const / intrinsic carry no nested reads.

    def _derive_call_sync_keys(
        self, actuals: Tuple[Any, ...]
    ) -> Tuple[List[Any], List[Any]]:
        from ..utils.sync_key import collect_tensor_sync_keys, normalize_sync_key_group

        read_formals, write_formals = self._ensure_formal_io()
        reads: set = set()
        writes: set = set()
        for (formal_name, _), actual in zip(self.input_list, actuals):
            if formal_name in read_formals:
                reads.update(collect_tensor_sync_keys(actual))
            if formal_name in write_formals:
                writes.update(collect_tensor_sync_keys(actual))
        norm_reads = normalize_sync_key_group(reads) or tuple()
        norm_writes = normalize_sync_key_group(writes) or tuple()
        return list(norm_reads), list(norm_writes)
