# 装饰器

本页文档说明 `easyasc` 公开接口中共享的装饰器。

这些装饰器定义了框架最主要的几种编写上下文：

- kernel 入口点
- 可复用的辅助函数
- 带有 auto-sync 标记的区域
- 可复用的 micro module
- 可复用的 SIMT 模块（仅 A5 系列提供）

## 1. `kernel()`

- 作用：把一个 Python 函数包装成 kernel 入口点，并返回一个以 `KernelBase` 为后端的可调用对象。
- 参数：
  - 正常用法下不需要额外装饰器参数；通常写成 `@kernel()`
- 限制：
  - 被装饰对象必须是可调用的
  - 被装饰函数名不能包含大写字母
  - 当这个 kernel 通过框架调用时，它绑定后的参数必须能解析成 `GMTensor` 和 `Var`
  - kernel 代码应当写在被装饰函数体内部，而不是写在外面
- 示例：

```python
from easyasc.a5 import *


@kernel()
def copy_kernel(x: GMTensor, y: GMTensor, M: Var, N: Var):
    ub = Tensor(DT.float, [M, N], Position.UB)
    ub <<= x[:, :]
    y[:, :] <<= ub
    return y
```

## 2. `func()`

- 作用：应用和 `@kernel` 相同的 Python-to-DSL 变换，但保留为辅助函数，而不是 kernel 入口点。
- 参数：
  - 正常用法下不需要额外装饰器参数；通常写成 `@func()`
- 限制：
  - 适合在激活的 kernel 或 micro 上下文中编写可复用的“发射指令”辅助函数
  - 它不会创建 kernel wrapper，因此不能作为独立 kernel 执行
- 示例：

```python
@func()
def zero_l1(buf: Tensor):
    set_constant_to_l1(buf, 0.0)
```

## 3. `auto_sync()`

- 作用：为某个区域或辅助函数调用打上标记，使 parser 在后续可以插入受支持的同侧同步事件。
- 参数：
  - 正常用法下不需要额外装饰器参数；常见形式是 `@auto_sync()` 和 `with auto_sync():`
  - 可选 `mode`：`"conservative"`（默认）、`"aggressive"`、`"fix_storage"` 或 `"manual_fix"`
- 限制：
  - 只能在 kernel 代码中使用
  - 它本身不能解决 cube-to-vec 或 vec-to-cube 的 ownership 交接
  - 当前只有 `asc_autosync.py` 中硬编码的 pipe 对会被处理
  - `"aggressive"` 会改变 cube 侧 L0 分组，并按物理 L0C allocation 分组 Fix ownership
  - `"fix_storage"` 只改变 Fix 分组，保留保守的 L0 调度
  - `"manual_fix"` 保留保守的 L1/L0 调度，但不生成 `M -> FIX` 事件；kernel 必须显式提供 result-ready 和 L0C-reuse 两个方向的事件
- 示例：

```python
with auto_sync():
    l1x <<= x[:, :]
    l1y <<= y[:, :]
    matmul(l0c, l1x, l1y)
    z[:, :] <<= l0c
```

Mode override 示例：

```python
with auto_sync(mode="aggressive"):
    l0a <<= l1a
    l0b <<= l1b
    mmad(l0c, l0a, l0b, M=M, N=N, K=K)
```

当运行时分支使用同一 L0C allocation 的不同 view，但不希望改变保守的
`MTE1 -> M` 调度时，使用 `mode="fix_storage"` 让 Fix ownership 跟随 backing storage。

只有在 kernel 显式实现 `M -> FIX` 结果就绪和 `FIX -> M` L0C 复用两个方向的
握手时才能使用 `mode="manual_fix"`。遗漏任一方向都会导致 simulator 数值检查可能无法暴露的竞争。

## 4. `vf()`

- 作用：把一个函数包装成可复用的 micro module。
- 参数：
  - 没有额外装饰器参数；写法就是 `@vf()`
- 限制：
  - 只在 A5 系列 facade（`easyasc.a5` 和 `easyasc.a5pr`）中提供
  - micro 函数只接受 UB `Tensor` 输入，以及类似 `Var` 的标量输入
  - micro 代码使用的是 `Reg`、`RegList` 和 `MaskReg`，而不是 cube 侧的 `Tensor` 数学
- 示例：

```python
@vf()
def add_one(src: Tensor, dst: Tensor):
    r = Reg(DT.float)
    r <<= src[0]
    r <<= r + 1.0
    dst[0] <<= r
```

## 5. `simt(num_threads=1024)`

- 作用：把一个函数包装成可复用的 SIMT 模块。codegen 会把它下沉成一个线程并行的 `__simt_vf__` kernel；模拟器则通过自己的一套 AST 下沉规则解释执行。
- 参数：
  - `num_threads`：`int`；必须是 `(128, 256, 512, 1024, 2048)` 中的一个；默认 `1024`
- 限制：
  - 只在 A5 系列 facade（`easyasc.a5` 和 `easyasc.a5pr`）中提供；在 `b*`（a2）设备上调用 `@simt` 包装过的函数会抛 `RuntimeError`
  - 被装饰函数只能接收位置参数，并且每个参数都要标注成 `GMTensor`、`Tensor` 或 `Var`（不允许默认值、不允许 `*args`、不允许 `**kwargs`）
  - 函数体只能用一个受限的 Python AST 子集（语句、表达式、dtype 规则、可用的 intrinsic）—— 完整子集请见 [SIMT 模块](simt.md)
- 示例：

```python
@simt(num_threads=1024)
def axpy_simt(x_ub: Tensor, y_ub: Tensor, out_ub: Tensor, alpha: Var, n: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out_ub[i] = x_ub[i] * alpha + y_ub[i]
```

运行时 / codegen 约定，以及支持的 AST 子集，请见 [SIMT 模块](simt.md)。
