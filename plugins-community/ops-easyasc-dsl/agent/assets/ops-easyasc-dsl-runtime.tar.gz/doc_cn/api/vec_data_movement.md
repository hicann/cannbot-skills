# A2 与共享 Vec 数据搬运

本页文档说明 vec 侧在 `GM`、`UB`、`L1` 之间搬运数据的辅助函数。

下面的描述同时依据以下两部分：

- `easyasc/stub_functions/vec/datamove.py` 中公开的 stub 接口
- `easyasc/simulator/pipe_vec.py` 中当前模拟器的行为

可用性概览：

- 由 `easyasc.a2` 导出：`gm_to_ub_pad`、`ub_to_gm_pad`、`ub_to_ub`、`transdata5hd`
- 由 `easyasc.a5` / `easyasc.a5pr` 导出：
  本页除 `transdata5hd` 外的所有函数（`transdata5hd` 仅 a2）

相关页面：

- [a2_vec_control.md](a2_vec_control.md) 说明 vec cast、compare/select、mask 辅助以及 gather/scatter 辅助

## 1. 核心单位与寻址规则

这些 API 在模拟器里最终都作用于
展平后的指针区域。

- 经过切片之后，模拟器要求源和目标都能解析成 1D 指针视图
- 因此下面所有地址公式都以 `src_flat` 或 `dst_flat` 这样的展平数组为基准来写
- 源和目标的元素大小必须严格一致

这里会反复出现两个单位：

- `elem_size = dtype.size`
- `c0 = 32 / elem_size`

常见的 `c0` 值：

| dtype | 元素大小 | `c0` |
| --- | --- | --- |
| `int8` / `uint8` | 1 字节 | 32 |
| `half` / `bfloat16` | 2 字节 | 16 |
| `float` / `int32` | 4 字节 | 8 |

一个重要后果是：

- `gm_to_ub_pad()` 和 `ub_to_gm_pad()` 用“元素数”描述 GM 侧 stride，
  但用“额外 32 字节 block 数”描述 UB 侧 stride
- `ub_to_ub()` 和裸 `ub_to_l1()` 中，`burst_len` 和两侧 stride 都直接按
  32 字节 block 计
- `ub_to_l1_nd2nz()` 和 `ub_to_l1_nz()` 用 `c0` 与 `align16(m_dst)`
  来组织 L1 中的 NZ 布局

## 2. `gm_to_ub_pad(dst, src, n_burst=None, burst_len_element=None, src_stride_element=None, dst_stride=None)`

- 作用：把一段或多段 GM burst 复制到 UB，并把每个 UB burst 补齐到 32 字节边界。

参数含义：

- `dst`：目标 UB `Tensor`
- `src`：源 `GMTensor` 或 GM 切片
- `n_burst`：需要复制的 burst 数
- `burst_len_element`：每个 burst 的逻辑负载长度，单位是元素数
- `src_stride_element`：相邻 GM burst 之间的间隔，单位是元素数
- `dst_stride`：每个对齐后的本地 burst 之后额外插入的 UB 间隔，单位是 32 字节 block 数

A2 上解析后的 `n_burst` 必须位于 `[0, 4095]`：0 表示空传输，4095 合法，4096
会被拒绝。stub 会检查已知值，simulator 会在计算 footprint 前再次检查动态运行时值。
A5/A5PR 保持原有行为。

模拟器行为：

1. 先把逻辑尺寸换算成字节：
   - `burst_len_byte = burst_len_element * elem_size`
   - `src_stride_byte = src_stride_element * elem_size`
2. 对齐本地 UB burst 占用：
   - `aligned_burst_len_byte = align32(burst_len_byte)`
3. 计算每个 burst 的步长：
   - `src_step = burst_len_byte + src_stride_byte`
   - `dst_step = aligned_burst_len_byte + dst_stride * 32`
4. 对每个 burst `b`：
   - 复制 `src_flat_bytes[b * src_step : b * src_step + burst_len_byte]`
   - 到 `dst_flat_bytes[b * dst_step : b * dst_step + burst_len_byte]`
5. 如果 `aligned_burst_len_byte > burst_len_byte`，则把目标 burst 里多出来的补齐字节清零

这最后一条规则是它和普通 memcpy 的主要区别：

- GM 只提供逻辑负载
- UB 接收到的是“负载 + 补零后的对齐尾部”
- `dst` 必须为这个对齐后的 UB footprint 预留空间，而不只是为逻辑负载预留。
  例如加载 2 个 float bias 时，GM 负载只有 8 字节，但 UB 目标 burst 仍然会触及
  32 字节，因此 UB 行至少需要 8 个 float slot。

以 `half` 为例：

```text
burst_len_element = 20
elem_size = 2
burst_len_byte = 40
aligned_burst_len_byte = 64

for each burst:
- copy 20 half elements from GM
- write them into the first 20 half slots in UB
- zero-fill the remaining 12 half slots in that 32-byte-aligned UB burst
```

默认推导规则：

- 如果 GM 视图是 1 维：
  - `n_burst = 1`
  - `burst_len_element = span[0]`
  - GM 侧和 UB 侧的默认 stride 都是 `0`
- 如果 `src` 是一个 2D GM 视图，并且 `span = [rows, cols]`、`shape = [full_rows, full_cols]`：
  - `n_burst = rows`
  - `burst_len_element = cols`
  - `src_stride_element = full_cols - cols`
- 如果 `src` 的 rank 大于 2：
  - 默认推导只支持 1 个或 2 个被切片的维度
  - 如果只有 1 个维度被切片：
    - 若切的是最后一个维度，则它对应单个 burst
    - 否则 burst 长度等于该维度之后连续后缀的乘积
  - 如果有 2 个维度被切片：
    - 内层被切片的维度必须覆盖 GM 视图的连续后缀
    - `n_burst` 来自外层被切片维度的 span
    - `burst_len_element` 变成“内层切片 span * 未切 trailing suffix”的乘积
- `dst_stride` 的默认值是：
  - `(dst.shape[1] - burst_len_element) // dst.dtype.C0`

注意，这里的默认 `dst_stride` 用的是向下整除，而不是 `CeilDiv`。这和模拟器约定一致：本地 burst 本身已经占用了 `align32(burst_len_byte)` 字节，所以 `dst_stride` 只表达这部分之后额外增加的整 32 字节 block。

rank-3 GM 切片默认推导示例：

```python
@kernel()
def copy(inp: GMTensor):
    dst = Tensor(DT.float, [2, 512], Position.UB)
    dst <<= inp[0, 6:8, :]
    return inp
```

会推导出：

- `n_burst = 2`
- `burst_len_element = 512`
- `src_stride_element = 0`
- `dst_stride = 0`

限制与检查：

- `dst.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- 所有解析出来的传输参数都必须非负
- 展平后的 GM 源区域必须包含所有请求的字节
- 展平后的 UB 目标区域必须容纳所有对齐后的本地 burst

最简用法：

```python
ub <<= x[m:m + rows, :]
```

## 2b. `gm_to_ub_nd_dma(dst, src, loop_src_stride, loop_dst_stride, loop_size, loop_left_pad=None, loop_right_pad=None, constant_value=0, nearest_value_mode=False, config_left_pad=None, config_right_pad=None, asc_optimize=False)`（A5 系列）

- 作用：A5 系列支持的多维 GM -> UB DMA（`NdDma` / `ISASI`），适合那些很难用行式 burst
  表达的逻辑 tile。

可用性：

- 从 `easyasc.a5` 和 `easyasc.a5pr` 导出
- 仅在 `device_type in ("950", "950pr")` 时有效

参数含义：

- `dst`：位于 `Position.UB` 的目标 `Tensor`
- `src`：源 `GMTensor`
- `loop_src_stride`、`loop_dst_stride`、`loop_size`：按**最内层优先**顺序书写的逐维数组
- `loop_left_pad`、`loop_right_pad`：每一维 live source window 之前或之后的逻辑 padding
- `constant_value`：当 `nearest_value_mode=False` 时，越界位置填入的常量
- `nearest_value_mode`：为 true 时，越界源坐标会 clamp 到最近的有效位置，而不是写
  `constant_value`
- `config_left_pad`、`config_right_pad`：对所有维度生效的可选全局 left/right pad 覆盖
- `asc_optimize`：当前 stub 和 simulator 都不支持

模拟器会把这次 copy 解释成一个覆盖总逻辑目标范围的 N 维嵌套循环：

```text
total_size[d] = loop_size[d] + effective_left_pad[d] + effective_right_pad[d]
```

对每个逻辑目标索引，它会：

1. 用 `loop_dst_stride` 计算展平后的 UB 目标 offset
2. 减去 left pad，恢复逻辑源索引
3. 如果源索引在范围内，用 `loop_src_stride` 计算展平后的 GM 源 offset
4. 否则：
   - `nearest_value_mode=True` 时做 clamp
   - `nearest_value_mode=False` 时写入 `constant_value`

重要约束：

- 源与目标 dtype 必须一致
- `dst` 必须像其他 UB datamove 一样满足 32B 对齐
- `dim` 必须在 1 到 5 之间
- 所有 stride、size、pad 值都必须非负
- `asc_optimize=True` 会被拒绝
- 64-bit 元素路径要求 `nearest_value_mode=False` 且 `constant_value=0`

当 `gm_to_ub_pad()` 的表达能力太死板时，这个 helper 就是 a5 的通用解：

- 非行主序的逻辑 copy
- 按维度显式指定 padding 策略
- 往 UB 里做类似 transpose 的逻辑搬运
- GM tile 与 UB tile 故意使用不同的逻辑行跨度

## 2c. a5 上的 `ub <<= gm.T`

在 `easyasc.a5` 上，把一个转置 GM 视图赋给 UB：

```python
ub <<= gm.T
ub <<= gm[a:b, c:d].T
```

**不会**走 `gm_to_ub_pad()`。它会 lowering 到建立在
`gm_to_ub_nd_dma(...)` 之上的 ND-DMA transpose helper。

它的合同是：

- GM 切片定义了这次逻辑搬运的 live block
- 这个 block 以逻辑转置后的形状落到 UB
- 目标 UB 的行跨度仍然来自底层 UB tensor 的宽度，这一点与其他 UB datamove 完全一致

## 3. `ub_to_gm_pad(dst, src, n_burst=None, burst_len_element=None, src_stride=None, dst_stride_element=None)`

- 作用：把一段或多段 UB burst 写回 GM，并在写回时丢弃 UB 里的补齐尾部。

参数含义：

- `dst`：目标 `GMTensor` 或 GM 切片
- `src`：源 UB `Tensor`
- `n_burst`：burst 数
- `burst_len_element`：每个 burst 的逻辑负载长度，单位是元素数
- `src_stride`：每个对齐后的本地 burst 之后额外插入的 UB 间隔，单位是 32 字节 block 数
- `dst_stride_element`：相邻 GM burst 之间的间隔，单位是元素数

这里同样适用 A2 的 `n_burst` 范围 `[0, 4095]`，并同时覆盖 stub 已知值和
simulator 解析后的运行时值。A5/A5PR 不变。

模拟器行为：

1. 先把 GM 侧 stride 换算成字节：
   - `burst_len_byte = burst_len_element * elem_size`
   - `dst_stride_byte = dst_stride_element * elem_size`
2. 恢复 UB burst 的对齐占用：
   - `aligned_burst_len_byte = align32(burst_len_byte)`
3. 计算每个 burst 的步长：
   - `src_step = aligned_burst_len_byte + src_stride * 32`
   - `dst_step = burst_len_byte + dst_stride_byte`
4. 对每个 burst `b`：
   - 只读取对应 UB burst 的前 `burst_len_byte` 字节
   - 再把它们写进 GM 对应的 burst

因此 `ub_to_gm_pad()` 正好是 `gm_to_ub_pad()` 的逻辑逆操作：

- UB 里可以有对齐补齐行
- 写回 GM 时只写逻辑负载
- UB 中补齐出来的尾部会被忽略

以 `half` 为例：

```text
burst_len_element = 20
elem_size = 2
burst_len_byte = 40
aligned_burst_len_byte = 64
src_stride = 0

for each burst:
- read the first 20 half elements from a 32-half UB row footprint
- ignore the remaining 12 padded half elements
- write only those 20 logical elements to GM
```

默认推导规则：

- 如果 GM 视图是 1 维：
  - `n_burst = 1`
  - `burst_len_element = span[0]`
  - GM 侧和 UB 侧的默认 stride 都是 `0`
- 如果 `n_burst` 省略，stub 会像 `gm_to_ub_pad()` 从其 GM 源推导参数那样，从 `dst` 推导出所有 GM 侧参数
- 如果你显式给出 `n_burst`，stub 就不会再自动推导 `burst_len_element` 和 `dst_stride_element`
- `src_stride` 的默认值是：
  - `(src.shape[1] - burst_len_element) // src.dtype.C0`

因此，常见的“带补齐 UB”写回模式：

```python
out[0, 6:8, :20] <<= src_ub
```

通常会采用：

- `burst_len_element = 20`
- `src_stride = (src_ub.shape[1] - 20) // c0`
- `dst_stride_element` 由 GM 切片宽度自动推导

原子行为：

- 如果全局 atomic mode 已开启，模拟器不会直接覆盖 GM 负载
- 它会对当前 GM 区域和 UB 负载做逐元素规约
- 当前支持的模式有 `add`、`max`、`min`
- 如果模式缺失，模拟器默认退回 `add`
- 规约前，模拟器会先扩宽计算 dtype：
  - `half` / `bfloat16` -> `float32`
  - `int8` / `uint8` / `int16` -> `int32`
  - 其他 dtype 保持不变

原子对齐限制：

- `burst_len_byte` 必须按 `elem_size` 对齐
- `dst_stride_byte` 必须按 `elem_size` 对齐
- `src_stride * 32` 必须按 `elem_size` 对齐
- 由此得到的 `src_step` 和 `dst_step` 也必须按 `elem_size` 对齐

限制与检查：

- `src.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- 所有解析出来的传输参数都必须非负
- 展平后的 UB 源区域必须容纳所有对齐后的本地 burst
- 展平后的 GM 目标区域必须容纳所有逻辑 burst

最简用法：

```python
out[m:m + rows, :valid_n] <<= ub
```

## 4. `ub_to_l1(dst, src, n_burst=None, burst_len=None, src_stride=None, dst_stride=None)`

- 作用：把 UB 中的原始 burst 复制到 L1，不做 ND->NZ 转换。

可用性：

- 由 `easyasc.a5` 和 `easyasc.a5pr` 导出
- 仅在 `device_type in ("950", "950pr")` 时有效

参数含义：

- `dst`：位于 `Position.L1` 的目标 `Tensor`
- `src`：位于 `Position.UB` 的源 `Tensor`
- `n_burst`：burst 数
- `burst_len`：每个 burst 的负载长度，单位是 32 字节 block 数
- `src_stride`：源 burst 之间的间隔，单位是 32 字节 block 数
- `dst_stride`：目标 burst 之间的间隔，单位是 32 字节 block 数

这是 tensorutils 里 `UB2L1` 的裸封装。它不 padding、不转置、不重新打包。
对第 `b` 个 burst：

```text
src_begin = b * (burst_len + src_stride) * 32
dst_begin = b * (burst_len + dst_stride) * 32
copy_bytes = burst_len * 32
```

模拟器精确复制：

```text
dst_bytes[dst_begin : dst_begin + copy_bytes] =
    src_bytes[src_begin : src_begin + copy_bytes]
```

默认推导沿用 `ub_to_ub()` 的二维按行约定：

- `n_burst` 默认是可见行数；rank-1 tensor 默认是 `1`
- `burst_len` 默认是 `ceil(visible_width / c0)`
- `src_stride` / `dst_stride` 默认是行尾隐藏部分，单位为 32B block

限制与检查：

- `dst.position` 必须是 `Position.L1`
- `src.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- 四个搬运参数全部是 32B block 单位，且必须非负
- 展平后的源和目标指针区域必须容纳所有被触及的字节

最简用法：

```python
ub_to_l1(l1_tile, ub_tile, n_burst=1, burst_len=4, src_stride=0, dst_stride=0)
```

当 UB 里的字节已经是你想要的 L1 布局时，用这个 helper；如果需要发布成 L1 NZ
布局，用 `ub_to_l1_nd2nz()` 或 `ub_to_l1_nz()`。

## 5. `ub_to_l1_nd2nz(dst, src, m_dst=None, n_dst=None, m_src=None, n_src=None, N_src=None)`

- 作用：把一个逻辑 ND UB tile 读取出来，并以 NZ 布局发布到 L1。

可用性：

- 由 `easyasc.a5` 和 `easyasc.a5pr` 导出
- 仅在 `device_type in ("950", "950pr")` 时有效

参数含义：

- `dst`：位于 `Position.L1` 的目标 `Tensor`
- `src`：位于 `Position.UB` 的源 `Tensor`
- `m_dst`：用于计算 NZ 行跨度的目标逻辑高度
- `n_dst`：用于校验的目标逻辑宽度容量
- `m_src`：要发布的逻辑源行数
- `n_src`：要发布的逻辑源列数
- `N_src`：源 UB tile 的物理行跨度，即它的完整列宽。这样切片后的 UB 源（可见行之间有尾部 gap）也能被正确读取。必须满足 `N_src >= n_src`。

关键布局常量：

- `c0 = 32 / elem_size`
- `dst_stride_m = align16(m_dst)`
- `block_count = ceil(n_src / c0)`

模拟器把：

- 源看成逻辑形状为 `[m_src, n_src]` 的 2D ND tile，按物理行跨度 `N_src` 读取（这样切片后的 UB 视图也能被正确处理；常见的稠密场景下 `N_src == n_src`）
- 目标看成形状为 `[block_count, dst_stride_m, c0]` 的 NZ panel

元素映射规则：

```text
block = col // c0
lane = col % c0

dst_panel[block, row, lane] = src_nd[row, col]
```

其中：

- `0 <= row < m_src`
- `0 <= col < n_src`

重要行为细节：

- `m_src` 不能超过 `m_dst`
- `n_src` 不能超过 `n_dst`
- `n_dst` 只是逻辑容量检查；真正的 NZ block 数仍然由 `n_src` 决定
- 只有真正触及到的 NZ 位置会被覆盖
- 每个 block 中 `m_src:dst_stride_m` 这些行保持原值不变
- 如果最后一个 block 不满，那么 `tail:c0` 这些 lane 保持原值不变
- 超出 `ceil(n_src / c0)` 的 block 保持原值不变

这也是为什么测试会先用哨兵值填充 `dst`：模拟器会保留 NZ panel 中没有被写到的部分。

默认推导规则：

- `m_dst` 默认取 `dst.shape[0]`
- `n_dst` 默认取 `dst.span[1]`
- `m_src` 默认取 `src.span[0]`
- `n_src` 默认取 `src.span[1]`
- `N_src` 默认取 `src.shape[1]`

这里最容易忽略的是 `m_dst` 的规则。如果你写：

```python
dst = Tensor(DT.half, [32, 32], Position.L1)
src = Tensor(DT.half, [32, 32], Position.UB)
ub_to_l1_nd2nz(dst[4:20, 3:15], src[1:17, 2:14])
```

stub 推导出的其实是：

- `m_dst = 32`，而不是 `16`
- `n_dst = 12`
- `m_src = 16`
- `n_src = 12`

这和模拟器布局规则一致：L1 的行跨度来自完整目标分配高度，而不是切片后的可见行数。

以 `half` 为例：

```text
m_dst = 32
m_src = 16
n_src = 20
elem_size = 2
c0 = 16
dst_stride_m = 32
block_count = 2
```

结果：

- 列 `0..15` 会写到 `dst_panel[0, 0:16, 0:16]`
- 列 `16..19` 会写到 `dst_panel[1, 0:16, 0:4]`
- `dst_panel[:, 16:32, :]` 保持原值
- `dst_panel[1, :, 4:16]` 保持原值

限制与检查：

- `dst.position` 必须是 `Position.L1`
- `src.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- `elem_size` 必须整除 32
- `N_src` 必须 `>= n_src`
- 按跨度排列的 UB 源区域必须容纳 `(m_src - 1) * N_src + n_src` 个元素（源行按跨度 `N_src` 读取）
- 展平后的 L1 目标区域必须容纳 `ceil(n_src / c0) * align16(m_dst) * c0` 个元素

最简用法：

```python
l1_tile <<= ub_tile
```

## 6. `ub_to_l1_nz(dst, src, m_dst=None, n_dst=None, m_src=None, n_src=None)`

- 作用：把一个已经按紧凑 NZ 顺序打包好的 UB tile，发布到 L1 所使用的带 padding 的 NZ 布局中。

可用性：

- 由 `easyasc.a5` 和 `easyasc.a5pr` 导出
- 仅在 `device_type in ("950", "950pr")` 时有效

参数含义：

- 这些参数的逻辑意义与 `ub_to_l1_nd2nz()` 相同
- 不同点只在于源 UB 区域如何被解释

源布局规则：

- `src` 不会被当作 ND
- 它会被当作彼此紧挨的紧凑 NZ block
- 即使最后一个 `N` block 不满，每个 block 仍然贡献完整的 `m_src * c0` 个元素

目标布局规则：

- `dst` 仍然使用带 padding 的 NZ 布局，其关键量仍是：
  - `c0 = 32 / elem_size`
  - `dst_stride_m = align16(m_dst)`
  - `block_count = ceil(n_src / c0)`

对第 `b` 个 block，模拟器复制：

```text
src_begin = b * (m_src * c0)
dst_begin = b * (align16(m_dst) * c0)
copy_len  = m_src * c0
```

因此，源是紧凑排列的 block，而 L1 目标会在 block 之间插入按 `align16(m_dst)` 计算的行 padding。

以 `half` 为例：

```text
m_dst = 32
m_src = 10
n_src = 20
elem_size = 2
c0 = 16
block_count = 2
```

那么：

- 源 block 0 占据展平元素 `[0 : 160)`
- 源 block 1 占据展平元素 `[160 : 320)`
- 目标 block 0 从展平元素 `0` 开始
- 目标 block 1 从展平元素 `32 * 16 = 512` 开始

这也是为什么 `src.nz()` 是 `ub_to_l1_nz()` 最自然的生产者：源里每个 block 内已经按 `c0` 补齐好了 lane，但还不包含 L1 所要求的更大 `align16(m_dst)` 行 padding。

重要行为细节：

- 仍然要求 `m_src <= m_dst` 且 `n_src <= n_dst`
- `n_dst` 仍然只是逻辑容量检查；真正的 block 数仍由 `n_src` 决定
- 最后一个 block 仍然会从源里复制完整的 `m_src * c0` 个元素
- 因此最后一个源 block 中的尾 lane 必须已经在 UB 中补齐好
- 目标每个 block 中 `m_src:align16(m_dst)` 这些行保持原值不变
- 超过 `ceil(n_src / c0)` 的 block 保持原值不变

默认推导规则：

- 和 `ub_to_l1_nd2nz()` 完全一致
- `m_dst` 依然默认取 `dst.shape[0]`，而不是 `dst.span[0]`

限制与检查：

- `dst.position` 必须是 `Position.L1`
- `src.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- `elem_size` 必须整除 32
- 每个 block 的紧凑源区域都必须容纳 `m_src * c0` 个元素
- 每个 block 的目标区域都必须容纳 `align16(m_dst) * c0` 个元素

最简用法：

```python
l1_tile <<= ub_tile.nz()
```

## 7. `ub_to_ub(dst, src, n_burst=None, burst_len=None, src_stride=None, dst_stride=None)`

- 作用：按 32 字节 burst 单位在 UB 内部复制数据，并可在 burst 之间跳过 32 字节间隙。

参数含义：

- `dst`：目标 UB `Tensor`
- `src`：源 UB `Tensor`
- `n_burst`：burst 数
- `burst_len`：每个 burst 的负载长度，单位是 32 字节 block 数
- `src_stride`：源 burst 之间的间隔，单位是 32 字节 block 数
- `dst_stride`：目标 burst 之间的间隔，单位是 32 字节 block 数

模拟器行为：

- `burst_len_byte = burst_len * 32`
- `src_step = (burst_len + src_stride) * 32`
- `dst_step = (burst_len + dst_stride) * 32`

对每个 burst `b`：

```text
dst_flat_bytes[b * dst_step : b * dst_step + burst_len_byte] =
    src_flat_bytes[b * src_step : b * src_step + burst_len_byte]
```

和 `gm_to_ub_pad()`、`ub_to_gm_pad()` 不同：

- 这里没有额外的向上对齐步骤，因为 `burst_len` 本来就是按 32 字节 block 表示
- 这里没有补零规则
- 被复制的 footprint 总是精确的 32 字节整数倍

默认推导规则：

- `n_burst = dst.span[0]`
- `burst_len = CeilDiv(dst.span[1], dst.dtype.C0)`
- `dst_stride = CeilDiv(dst.shape[1] - dst.span[1], dst.dtype.C0)`
- `src_stride = CeilDiv(src.shape[1] - dst.span[1], src.dtype.C0)`

这里 `CeilDiv` 很关键。如果逻辑宽度不是 `c0` 的整数倍，`ub_to_ub()` 仍然会复制最后那个不完整逻辑块所对应的整 32 字节 block。

以 `float32` 为例：

```text
c0 = 8
n_burst = 2
burst_len = 2
src_stride = 1
dst_stride = 0
```

那么：

- 第 0 个目标 burst 接收 `src[0:16]`
- 第 1 个目标 burst 接收 `src[24:40]`

这正是模拟器测试覆盖到的行为。

典型用法：

```python
tmp <<= src
```

或者显式写成：

```python
ub_to_ub(tmp, src, n_burst=2, burst_len=2, src_stride=1, dst_stride=0)
```

限制与检查：

- `dst.position` 和 `src.position` 都必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- 所有解析出来的传输参数都必须非负
- 展平后的源区域必须容纳每个请求的 burst
- 展平后的目标区域必须容纳每个请求的 burst

## 8. `transdata5hd(dst, src, repeat=None, src_row_stride=None, dst_row_stride=None, src_rep_stride=1, dst_rep_stride=16)`（仅 a2）

- 作用：在两个 UB tensor 之间做 16x16 块转置（AscendC `TransDataTo5HD`，b16 路径）。

可用性：

- 只由 `easyasc.a2` 导出
- 仅支持 b16 dtype

参数含义：

- `dst`：目标 UB `Tensor`
- `src`：源 UB `Tensor`
- `repeat`：要转置的 16x16 tile 数量；默认取 `src.shape[1] // 16`
  （要求源行长是静态值，否则必须显式传 `repeat`）
- `src_row_stride`：一个 tile 内 16 个源行之间的跨度，以元素为单位；默认取 `src.shape[1]`
- `dst_row_stride`：一个 tile 内 16 个目标行之间的跨度，以元素为单位；默认 `16`
- `src_rep_stride`：每个 repeat 的源前进量，以 32 字节（16 个 b16 元素）块为单位；默认 `1`
- `dst_rep_stride`：每个 repeat 的目标前进量，以 32 字节块为单位；默认 `16`

模拟器行为：

- 对每个 repeat `r`，从源行 `src[i*src_row_stride + r*src_rep_stride*16 : +16]`（`i = 0..15`）收集 16x16 tile
- 转置这个 tile
- 写到 `dst[i*dst_row_stride + r*dst_rep_stride*16 : +16]`

默认跨度走的是 NCHW -> 5HD 平面：源行是 16 个 channel 行、每行 `padHW` 个元素，目标是打包后的 `[padHW, C0]` 平面。

限制与检查：

- `dst` 和 `src` 都必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- 只支持 b16 dtype：`half`、`bfloat16`、`int16`、`uint16`
  （在 a2/910B 上 `bfloat16` 会被 reinterpret 成 `half` 做纯比特搬运；`float` 16x8 和 `int8` C0=32 路径未接入）
- `repeat` 必须在 `[1, 255]` 区间
- `src_row_stride` 和 `dst_row_stride` 必须是 `16` 的倍数（32 字节行）
- `src_rep_stride` 和 `dst_rep_stride` 必须能放进 `uint16`（`0..65535`）

最简用法：

```python
transdata5hd(dst_ub, src_ub)
```
