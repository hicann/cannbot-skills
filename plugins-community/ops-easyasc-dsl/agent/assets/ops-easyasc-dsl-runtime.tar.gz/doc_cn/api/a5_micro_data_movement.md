# A5 Micro 数据搬运
本页文档说明 A5 系列 facade（`easyasc.a5` 和 `easyasc.a5pr`）直接导出的
micro 侧数据搬运辅助能力。

下面的描述同时依据以下两部分：

- `easyasc/stub_functions/micro/datamove.py` 中公开的 stub 接口
- `easyasc/simulator/pipe_micro.py` 中当前模拟器的行为

除了只检查 config 命名空间的情况，本页可调用 helper 都要求处在活跃的
`@vf` 上下文中。数据搬运 helper：

- 操作 `Reg`、`MaskReg` 和 UB `Tensor`
- 在计算地址时，把 UB tensor 视为展平后的 1D 视图

`clear_spr()` 是操作数规则的例外：它没有显式操作数，只在活跃 micro 上下文中
重置 AR special-purpose counter。

## 1. 这些 API 使用的寄存器几何

下面很多行为都依赖 micro 寄存器的 lane 数，
以及硬件上的 `C0` block 大小。

- `lane_count = 256 / dtype_size_in_bytes`
- `c0 = 32 / dtype_size_in_bytes`

常见情况如下：

| dtype | 元素大小 | lane 数 | `C0` 大小 |
| --- | --- | --- | --- |
| `int8` / `uint8` | 1 字节 | 256 lane | 32 lane |
| `half` / `bfloat16` | 2 字节 | 128 lane | 16 lane |
| `float` / `int32` | 4 字节 | 64 lane | 8 lane |
| `int64` / `uint64` | 8 字节 | 32 lane | 4 lane |

这很重要，因为：

- `ub_to_reg()` 和 `reg_to_ub()` 会把 `blk_stride` 解释为以 `C0` block 为单位的步长
- 这类 block copy API 会把 mask 扩展到整个 `C0` block
- `LoadDist.BRCB` 会把一个标量重复到整个 `C0` block 上
- `ub_to_reg_interleave()` 会用一次双搬入从 UB 读取两个寄存器宽度的数据

## 2. 分布模式对象

### `LoadDist`

- 作用：为 `ub_to_reg_continuous()` 选择一种行为模式。
- 参数含义：
  - `loaddist`：决定一个展平后的 UB 源流如何被展开或重排到一个寄存器里

可用值如下：

| API 值 | 模拟器模式 | 支持的元素宽度 | 行为 |
| --- | --- | --- | --- |
| `LoadDist.NORMAL` | `DIST_NORM` | 8 位、16 位、32 位、64 位 | 1:1 读取所有 lane。 |
| `LoadDist.DOWNSAMPLE` | `DIST_DS_B8`, `DIST_DS_B16` | 8 位、16 位 | 每隔一个源元素读一个。 |
| `LoadDist.UPSAMPLE` | `DIST_US_B8`, `DIST_US_B16` | 8 位、16 位 | 每个源元素重复两次。 |
| `LoadDist.SINGLE_VALUE` | `DIST_BRC_B8`, `DIST_BRC_B16`, `DIST_BRC_B32` | 8 位、16 位、32 位 | 把 `src[0]` 广播到所有寄存器 lane。 |
| `LoadDist.BRCB` | `DIST_E2B_B16`, `DIST_E2B_B32` | 16 位、32 位 | 每个源元素广播到一个完整 `C0` block。 |
| `LoadDist.UNPACK` | `DIST_UNPACK_B8`, `DIST_UNPACK_B16`, `DIST_UNPACK_B32` | 8 位、16 位、32 位 | 把源值写到偶数 lane，奇数 lane 补零。 |
| `LoadDist.UNPACK4` | `DIST_UNPACK4_B8` | 仅 8 位 | 把源值写到 `0, 4, 8, ...` 这些 lane，其余 lane 补零。 |

行为细节：

- `NORMAL`：
  - 要求源长度为 `lane_count`
  - 公式：`dst[i] = src[i]`
- `DOWNSAMPLE`：
  - 要求源长度为 `lane_count * 2`
  - 公式：`dst[i] = src[2 * i]`
- `UPSAMPLE`：
  - 要求源长度为 `lane_count / 2`
  - 要求 `lane_count` 为偶数
  - 公式：`dst[2 * i] = src[i]`，`dst[2 * i + 1] = src[i]`
- `SINGLE_VALUE`：
  - 要求源长度为 `1`
  - 公式：`dst[i] = src[0]`
- `BRCB`：
  - 要求源长度为 `lane_count / c0`
  - 要求 `lane_count % c0 == 0`
  - 公式：对 block `b`，`dst[b * c0 : (b + 1) * c0] = src[b]`
- `UNPACK`：
  - 要求源长度为 `lane_count / 2`
  - 要求 `lane_count` 为偶数
  - 公式：`dst[2 * i] = src[i]`，`dst[2 * i + 1] = 0`
- `UNPACK4`：
  - 要求源长度为 `lane_count / 4`
  - 要求 `lane_count % 4 == 0`
  - 公式：`dst[4 * i] = src[i]`，其余所有 lane 都为 `0`

双搬入 interleave 暴露为 `ub_to_reg_interleave(dst0, dst1, src)`，不作为
`LoadDist` 值暴露，因为官方 API 本身有两个目的寄存器。

简单例子：

```text
LoadDist.DOWNSAMPLE
src = [10, 11, 12, 13, 14, 15, 16, 17, ...]
dst = [10, 12, 14, 16, ...]
```

```text
LoadDist.UPSAMPLE
src = [5, 6, 7, 8]
dst = [5, 5, 6, 6, 7, 7, 8, 8]
```

```text
LoadDist.BRCB with half
lane_count = 128, c0 = 16
src = [1, 2, 3, 4, 5, 6, 7, 8]
dst[0:16]   = 1
dst[16:32]  = 2
dst[32:48]  = 3
...
dst[112:128] = 8
```

示例用法：

```python
reg = Reg(DT.half)
src = Tensor(DT.half, [1, 8], Position.UB)
ub_to_reg_continuous(reg, src, LoadDist.BRCB)
```

### `LoadDistValue`

- 作用：`LoadDist.*` 成员背后真正对应的具体值类型。
- 实际用法：
  - 通常不需要手动构造它
  - 而是传 `LoadDist.NORMAL`、`LoadDist.DOWNSAMPLE`、`LoadDist.BRCB`、`LoadDist.UNPACK`、`LoadDist.SINGLE_VALUE` 这些预定义值

它存在的原因是：

- 公开 API 通过 `LoadDist` 命名空间暴露易读的名字
- 底层 stub 和模拟器实际接收到的是这些名字背后的 `LoadDistValue`

实践规则：

- 在 kernel 代码里使用 `LoadDist.*`
- 把 `LoadDistValue` 视为实现层的值类型，它主要出现在底层文档、类型检查和调试输出里

示例：

```python
mode = LoadDist.NORMAL
ub_to_reg_continuous(dst_reg, src_ub, mode)
```

### `StoreDist`

- 作用：为 `reg_to_ub_continuous()` 选择一种行为模式。
- 参数含义：
  - `storedist`：决定寄存器 lane 如何被压缩或写入展平后的 UB 目标

可用值如下：

| API 值 | 模拟器模式 | 支持的元素宽度 | 行为 |
| --- | --- | --- | --- |
| `StoreDist.DOWNSAMPLE` | `DIST_PACK_B16`, `DIST_PACK_B32`, `DIST_PACK_B64` | 8 位、16 位、32 位 | 把源寄存器中隔一个 lane 取一个，压紧后写入目标。 |
| `StoreDist.PACK4` | `DIST_PACK4_B32` | 仅 8 位 | 每隔 4 个 lane 取一个，压紧后写入目标。 |
| `StoreDist.SINGLE_VALUE` | `DIST_FIRST_ELEMENT_B8`, `DIST_FIRST_ELEMENT_B16`, `DIST_FIRST_ELEMENT_B32` | 8 位、16 位、32 位 | 只存 lane `0`。 |
| `StoreDist.NORMAL` | `DIST_NORM_B8`, `DIST_NORM_B16`, `DIST_NORM_B32`, `DIST_NORM` | 8 位、16 位、32 位、64 位 | 1:1 存储所有 lane。 |

行为细节：

- `DOWNSAMPLE`：
  - 目标长度至少要有 `lane_count / 2`
  - 要求 `lane_count` 为偶数
  - 公式：`dst[i] = src[2 * i]`
- `PACK4`：
  - 目标长度至少要有 `lane_count / 4`
  - 要求 `lane_count % 4 == 0`
  - 公式：`dst[i] = src[4 * i]`
- `SINGLE_VALUE`：
  - 目标长度至少要有 `1`
  - 公式：`dst[0] = src[0]`
- `NORMAL`：
  - 目标长度至少要有 `lane_count`
  - 公式：`dst[i] = src[i]`

连续写回时的 mask 行为：

- `reg_to_ub_continuous()` 会先解析源 mask
- 然后把 mask 扩展到整个 `C0` block
- 之后所选的模式会从这个扩展后的 mask 上取样
- 目标中没有被选中的位置会保留原有值

示例：

```text
StoreDist.DOWNSAMPLE
src = [10, 11, 12, 13, 14, 15, 16, 17]
dst = [10, 12, 14, 16]
```

```text
StoreDist.PACK4
src = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
dst = [0, 4, 8]
```

示例用法：

```python
reg = Reg(DT.int8)
dst = Tensor(DT.int8, [1, 64], Position.UB)
reg_to_ub_continuous(dst, reg, None, StoreDist.PACK4)
```

### `StoreDistValue`

- 作用：`StoreDist.*` 成员背后真正对应的具体值类型。
- 实际用法：
  - 通常不需要手动构造它
  - 而是传 `StoreDist.NORMAL`、`StoreDist.DOWNSAMPLE`、`StoreDist.PACK4`、`StoreDist.SINGLE_VALUE` 这些预定义值

它存在的原因是：

- 公开 API 通过 `StoreDist` 命名空间提供易读的模式名
- 底层 stub 和模拟器实际接收到的是对应的 `StoreDistValue`

实践规则：

- 在 kernel 代码里使用 `StoreDist.*`
- 把 `StoreDistValue` 看作这些导出名字之下的实现层值类型

示例：

```python
mode = StoreDist.NORMAL
reg_to_ub_continuous(dst_ub, src_reg, None, mode)
```

## 3. 基础 UB / 寄存器传输

### `ub_to_reg(dst, src, blk_stride=1, mask=None)`

- 作用：把一个 UB tensor 读入一个寄存器。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 UB `Tensor`
  - `blk_stride`：展平后源视图中，相邻被拷贝 `C0` block 之间的距离
  - `mask`：可选的 `MaskReg`

寻址方式：

- 当 `blk_stride == 1` 且 mask 为全开时，模拟器会走快速的连续拷贝：
  - `dst[i] = src_flat[i]`
- 否则，地址按 `C0` 大小的 block 计算：
  - `src_index(i) = (i // c0) * (blk_stride * c0) + (i % c0)`

`blk_stride` 的解释：

- `blk_stride = 1`：复制相邻的 `C0` block
- `blk_stride = 2`：复制一个 `C0` block，跳过一个 `C0` block，再复制下一个
- `blk_stride = 3`：复制一个 `C0` block，跳过两个 `C0` block，以此类推

Mask 行为：

- 对 `ub_to_reg()` 来说，mask 会扩展到整个 `C0` block
- 只要某个 `C0` block 里任意一个 lane 被启用，整个 block 都会被复制
- 没有被 mask 选中的 lane，会在 `dst` 中被清零

示例：`half` 上的 `blk_stride`

```text
dtype = half
lane_count = 128
c0 = 16
blk_stride = 2

dst lanes   0..15  <- src lanes   0..15
dst lanes  16..31  <- src lanes  32..47
dst lanes  32..47  <- src lanes  64..79
dst lanes  48..63  <- src lanes  96..111
...
```

等价公式：

```text
src_index(i) = (i // 16) * 32 + (i % 16)
```

示例：`half` 上的 `MaskType.LOWEST1`

```text
lane_count = 128, c0 = 16
LOWEST1 initially enables only lane 0
after C0 expansion, lanes 0..15 become active

result:
dst[0:16]   = src[0:16]
dst[16:128] = 0
```

示例用法：

```python
reg = Reg(DT.half)
src = Tensor(DT.half, [1, 256], Position.UB)
mask = MaskReg(DT.half, init_mode=MaskType.ALL)
ub_to_reg(reg, src, blk_stride=2, mask=mask)
```

限制：

- `src.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- 这条 DATA_BLOCK_COPY 路径只支持 8、16 和 32 位元素；64 位数据请使用
  `ub_to_reg_continuous(..., LoadDist.NORMAL)`
- `blk_stride` 必须为正
- 展平后的源视图必须足够大，能够覆盖计算出的最高地址

### `reg_to_ub(dst, src, blk_stride=1, mask=None)`

- 作用：把一个寄存器写回 UB tensor。
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：源 `Reg`
  - `blk_stride`：展平后目标视图中，相邻被写入 `C0` block 之间的距离
  - `mask`：可选的 `MaskReg`

寻址方式：

- 当 `blk_stride == 1` 且 mask 为全开时，模拟器会走快速连续写：
  - `dst_flat[i] = src[i]`
- 否则，地址采用和 `ub_to_reg()` 相同的 `C0` block 规则：
  - `dst_index(i) = (i // c0) * (blk_stride * c0) + (i % c0)`

Mask 行为：

- mask 会扩展到整个 `C0` block
- 只有激活 lane 会被写入
- 没有被写到的目标位置会保留原有值

示例：`half` 上的 `blk_stride`

```text
dtype = half
lane_count = 128
c0 = 16
blk_stride = 2

dst lanes   0..15   <- src lanes   0..15
dst lanes  32..47   <- src lanes  16..31
dst lanes  64..79   <- src lanes  32..47
dst lanes  96..111  <- src lanes  48..63
...
```

等价公式：

```text
dst_index(i) = (i // 16) * 32 + (i % 16)
```

示例用法：

```python
reg = Reg(DT.half)
dst = Tensor(DT.half, [1, 256], Position.UB)
reg_to_ub(dst, reg, blk_stride=2)
```

限制：

- `dst.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- 这条 DATA_BLOCK_COPY 路径只支持 8、16 和 32 位元素；64 位数据请使用
  `reg_to_ub_continuous(..., StoreDist.NORMAL)`
- `blk_stride` 必须为正
- 展平后的目标视图必须足够大，能够覆盖计算出的最高地址

### `ub_to_reg_continuous(dst, src, loaddist)`

- 作用：按预定义的分布模式，把展平后的 UB 数据流加载到一个寄存器中。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 UB `Tensor`
  - `loaddist`：一个 `LoadDist` 值

行为概述：

- 这个 API 不接收 mask
- 总是从 `src_flat[0]` 开始读
- 所选的 `LoadDist` 决定要消耗多少源元素，以及这些元素如何映射到 `dst` 的 lane 上

示例：

```python
ub_to_reg_continuous(reg, src, LoadDist.NORMAL)
ub_to_reg_continuous(reg, src, LoadDist.DOWNSAMPLE)
ub_to_reg_continuous(reg, src, LoadDist.UNPACK)
ub_to_reg_continuous(reg, src, LoadDist.BRCB)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- 所选模式必须支持该 dtype 宽度
- 展平后的源数据必须提供该模式所需的元素数

### `ub_to_reg_interleave(dst0, dst1, src)`

- 作用：用双搬入 interleave 模式，把一个展平后的 UB 数据流加载到两个寄存器中。
- 参数：
  - `dst0`：第一个目的 `Reg`
  - `dst1`：第二个目的 `Reg`
  - `src`：源 UB `Tensor`

行为概述：

- 不接收 mask
- 三个操作数必须使用同一个 dtype
- `int8`/`uint8`、`half`/`bfloat16`、`float`/`int32` 会分别选择
  `DIST_DINTLV_B8`、`DIST_DINTLV_B16`、`DIST_DINTLV_B32`
- 该操作从 `src` 读取 `2 * VL` 字节
- 偶数索引源元素进入 `dst0`，奇数索引源元素进入 `dst1`

公式：

```text
dst0[i] = src[2 * i]
dst1[i] = src[2 * i + 1]
```

示例：

```python
ub_to_reg_interleave(reg0, reg1, src_ub)
```

限制：

- `src.position` 必须是 `Position.UB`
- `dst0.dtype`、`dst1.dtype`、`src.dtype` 必须一致
- dtype 宽度必须是 1、2 或 4 字节
- 源地址 base 和 access offset 必须保持 32B 对齐
- 展平后的源数据必须包含 `2 * lane_count` 个元素

### `reg_to_ub_continuous(dst, src, mask, storedist)`

- 作用：按预定义的压缩写回模式，把寄存器写到展平后的 UB 数据流中。
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：源 `Reg`
  - `mask`：可选的 `MaskReg`
  - `storedist`：一个 `StoreDist` 值

行为概述：

- 所选的 `StoreDist` 会先决定哪些源 lane 参与本次写回
- 源 mask 再应用到这些参与的 lane 上
- 被写入的目标位置会从 `dst_flat[0]` 开始按压紧后的顺序排布
- 没有被模式或 mask 选中的目标位置会保留原值

详细示例：带部分 mask 的 `StoreDist.DOWNSAMPLE`

```text
src = [10, 11, 12, 13, 14, 15, 16, 17]
mode samples lanes [0, 2, 4, 6]

if the active sampled lanes are [0, 4, 6]
then dst receives:
dst[0] = 10
dst[1] = 14
dst[2] = 16

the next compact destination position is not written at all
```

示例：

```python
reg_to_ub_continuous(dst, reg, None, StoreDist.NORMAL)
reg_to_ub_continuous(dst, reg, mask, StoreDist.DOWNSAMPLE)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- 所选模式必须支持该 dtype 宽度
- 展平后的目标必须足够大，能容纳最高的压缩写回索引

## 4. 便捷传输包装

这些包装函数只是帮你选好了一个 `LoadDist` 或 `StoreDist`。
`ub_to_reg_interleave()` 也是便捷包装，但它映射到双目的 `LoadAlign` 重载，
不是 `ub_to_reg_continuous()`。

| 包装函数 | 等价调用 |
| --- | --- |
| `reg_to_ub_downsample(dst, src, mask)` | `reg_to_ub_continuous(dst, src, mask, StoreDist.DOWNSAMPLE)` |
| `reg_to_ub_pack4(dst, src, mask)` | `reg_to_ub_continuous(dst, src, mask, StoreDist.PACK4)` |
| `reg_to_ub_single(dst, src, mask)` | `reg_to_ub_continuous(dst, src, mask, StoreDist.SINGLE_VALUE)` |
| `reg_to_ub_normal(dst, src, mask)` | `reg_to_ub_continuous(dst, src, mask, StoreDist.NORMAL)` |
| `ub_to_reg_normal(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.NORMAL)` |
| `ub_to_reg_single(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.SINGLE_VALUE)` |
| `ub_to_reg_upsample(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.UPSAMPLE)` |
| `ub_to_reg_downsample(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.DOWNSAMPLE)` |
| `ub_to_reg_unpack(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.UNPACK)` |
| `ub_to_reg_unpack4(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.UNPACK4)` |
| `ub_to_reg_brcb(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.BRCB)` |
| `ub_to_reg_interleave(dst0, dst1, src)` | 使用 `DIST_DINTLV_B8/B16/B32` 的双目的 `LoadAlign` |

示例：

```python
ub_to_reg_unpack(reg, src_ub)
reg_to_ub_single(dst_ub, reg)
```

## 5. Gather 与 Scatter

### `ub_to_reg_gather(dst, src, index, mask=None)`

- 作用：从 UB 中按任意索引 gather 到寄存器。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 UB `Tensor`
  - `index`：索引 `Reg`
  - `mask`：可选的 `MaskReg`

寻址规则：

- 模拟器会先把 `src` 展平
- 对每个激活 lane `i`，读取：
  - `dst[i] = src_flat[index[i]]`
- **8 位源（`b8 -> b16` 零扩展）**：8 位 `src` gather 到 16 位 `dst`。每个取到的字节
  放在目标元素的低 8 位，高 8 位补 0（`dst[i] = 0x00 <byte>`）——这是原始字节的**零扩展**，
  不是数值/符号转换（所以 `int8` 的 `0xFF` 得到 `255`，而不是 `-1`）。已在 Ascend950 上板验证。

Mask 行为：

- 这里的 mask 是逐 lane 的，不会扩展到 `C0` block
- `dst` 会先被清零，所以未激活 lane 在结果中为 `0`

索引行为：

- `index` 直接参与地址计算
- `index[i]` 已经是最终的展平元素下标
- 不会再额外乘元素大小、行宽或 `C0`

如果 `src` 的逻辑形状是 `[rows, cols]`，那么：

- 展平地址 `0 .. cols - 1` 对应第 `0` 行
- 展平地址 `cols .. 2 * cols - 1` 对应第 `1` 行
- 一般地：`flat_index = row * cols + col`

示例：

```text
src (flattened) = [100, 101, 102, 103, 104, 105]
index           = [4,   1,   1,   0]
mask            = VL3

dst[0] = src[4] = 104
dst[1] = src[1] = 101
dst[2] = src[1] = 101
dst[3] = 0      # masked off
```

示例用法：

```python
data = Tensor(DT.half, [4, 64], Position.UB)
index = Reg(DT.uint16)
dst = Reg(DT.half)
mask = MaskReg(DT.half, init_mode=MaskType.ALL)
ub_to_reg_gather(dst, data, index, mask=mask)
```

限制：

- `index` 的 lane 数必须等于 `dst` 的 lane 数
- 模拟器要求 `index` 是整数类型
- stub 按源字节宽度约束支持的组合（与 `dav_c310` 上 `DataCopyGather` / `vgather2` 的
  `SupportType` 一致）：

  | `src` 宽度 | `dst` | `index` | 说明 |
  |---|---|---|---|
  | 8 位  | 16 位（`dst.dtype != src.dtype`） | `uint16` | 字节零扩展（见上） |
  | 16 位 | 16 位（`dst.dtype == src.dtype`） | `uint16` | |
  | 32 位 | 32 位（`dst.dtype == src.dtype`） | `uint32` | |
  | 64 位 | 64 位（`dst.dtype == src.dtype`） | `uint32` 或 `uint64` | 索引以 b64 元素为单位；32 lane |

  - 因此 8 位 `src` 必须配 16 位 `dst`（否则抛 `ValueError`）；同宽 gather 要求
    `dst.dtype == src.dtype`。
- 每个激活索引都必须落在展平后的源范围内

### `reg_to_ub_scatter(dst, src, index, mask=None)`

- 作用：把寄存器 lane 按任意索引 scatter 到 UB 中。
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：源 `Reg`
  - `index`：索引 `Reg`
  - `mask`：可选的 `MaskReg`

寻址规则：

- 模拟器会先把 `dst` 展平
- 对每个激活 lane `i`，写入：
  - `dst_flat[index[i]] = src[i]`
- **8 位数据（仅偶数源 lane）**：b8 源寄存器有 256 个 lane，而 `uint16` 索引只有 128 个，
  因此硬件只 scatter **偶数**源 lane——元素 `k` 写入 `dst_flat[index[k]] = src[2k]`
  （`k` 取 `0..127`），奇数位字节被忽略。已在 Ascend950 上板验证。

Mask 行为：

- 这里的 mask 同样是逐 lane 的，不会扩展到 `C0`
- 未激活 lane 不会进行任何写入
- 未触及的目标位置会保留原值
- 对 8 位数据，mask 在偶数源 lane 上读取（lane `2k` 控制元素 `k`）

重复索引行为：

- 如果多个激活 lane 指向同一个目标位置，会按 lane 顺序依次写
- 最后一个激活 lane 的值生效

示例：

```text
initial dst = [0, 0, 0, 0, 0]
src         = [10, 20, 30, 40]
index       = [3,  1,  3,  0]

lane 0 writes dst[3] = 10
lane 1 writes dst[1] = 20
lane 2 writes dst[3] = 30   # overwrites lane 0
lane 3 writes dst[0] = 40

final dst = [40, 20, 0, 30, 0]
```

示例用法：

```python
dst = Tensor(DT.half, [4, 64], Position.UB)
src = Reg(DT.half)
index = Reg(DT.uint16)
reg_to_ub_scatter(dst, src, index)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- `index` 的 lane 数必须等于 `src` 的 lane 数
- 模拟器要求 `index` 是整数类型
- stub 按数据字节宽度约束索引 dtype（与 `dav_c310` 上 `DataCopyScatter` / `vscatter` 的
  `SupportType` 一致）：
  - 对 8 位数据使用 `uint16` 索引（仅偶数源 lane——见寻址规则）
  - 对 16 位数据使用 `uint16` 索引
  - 对 32 位数据使用 `uint32` 索引
  - 对 64 位数据使用 `uint32` 或 `uint64` 索引
- 每个激活索引都必须落在展平后的目标范围内

### `gather(dst, src, index)`

- 作用：在寄存器内部，从一个寄存器按索引 gather 到另一个寄存器。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 `Reg`
  - `index`：索引 `Reg`

规则：

- 对每个 lane `i`：
  - `dst[i] = src[index[i]]`

重要的 alias 行为：

- 模拟器会先对 `src` 做快照，再执行 gather
- 因此 `gather(reg, reg, index)` 的语义是“从原始寄存器内容中 gather”，而不是一边覆盖一边继续读取

示例：

```text
src   = [10, 20, 30, 40]
index = [3, 2, 1, 0]
dst   = [40, 30, 20, 10]
```

重复索引示例：

```text
src   = [10, 20, 30, 40]
index = [1, 1, 1, 1]
dst   = [20, 20, 20, 20]
```

示例用法：

```python
dst = Reg(DT.half)
src = Reg(DT.half)
index = Reg(DT.uint16)
gather(dst, src, index)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- `dst`、`src`、`index` 三者必须有相同的 lane 数
- 每个索引都必须落在源寄存器 lane 范围内

### `gather_mask(dst, src, mask=None)`

- 作用：把源寄存器中被 mask 选中的 lane 压紧到目标寄存器前部。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 `Reg`
  - `mask`：可选的 `MaskReg`

规则：

- 被选中的源 lane 会保持原有顺序复制
- 它们会被压到 `dst[0]`、`dst[1]`、`...`
- `dst` 中剩余 lane 全部补零

示例：

```text
src  = [10, 20, 30, 40, 50, 60]
mask = active at lanes [0, 2, 5]
dst  = [10, 30, 60, 0, 0, 0]
```

重要的 alias 行为：

- 模拟器会在压紧前先快照 `src`
- 因此 `gather_mask(src, src, mask)` 会使用原始源内容

示例用法：

```python
dst = Reg(DT.half)
src = Reg(DT.half)
mask = MaskReg(DT.half, init_mode=MaskType.MULTI3)
gather_mask(dst, src, mask)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- `dst` 和 `src` 必须有相同的 lane 数

### `squeeze(dst, src, mask=None, store=False)`

- 作用：用一次 `MicroAPI::Squeeze` 把 mask 选中的源 lane 压紧到 `dst`
  的低端
- 规则：被选中的 lane 保持源顺序并填入 `dst[0:n]`；所有剩余目标 lane
  变成零
- `dst` 和 `src` 必须是 dtype 相同的 `Reg`
- 模拟器会快照 `src`，因此 `squeeze(src, src, mask)` 语义明确
- `store=False` 使用普通压紧模式
- `store=True` 选择 `GatherMaskMode::STORE_REG`，并按被选中 lane 数增加
  AR special-purpose counter

AR counter 是元数据，不是目标 offset。后续使用 `store=True` 时仍然从
`dst[0]` 开始写并覆盖低位 lane，不会追加到上一次压紧结果之后。

```python
packed = Reg(DT.e4m3)
squeeze(packed, sparse, mask)
```

### `clear_spr()`

- 作用：发射 `MicroAPI::ClearSpr<AR>()`，把 `squeeze(..., store=True)` 使用的
  AR counter 清零
- 参数：无
- 它不会清空 `Reg`、`MaskReg` 或 UB 内存

```python
clear_spr()
squeeze(packed, sparse, mask, store=True)
```

### `ub_to_reg_gatherb(dst, src, index, mask=None)`

- 作用：从 UB tensor 按 32 字节数据块 gather 到寄存器（`MicroAPI::GatherB`）。
- 规则：输出 DataBlock `i`（`dst` 的第 `i` 个 32 字节切片）= UB 中字节偏移 `index[i]` 处的 32 字节
  块，其中 `index[i]` 从索引寄存器的 lane `i` 读取。
- `index` 必须是 `uint32`；每个偏移须 `>= 0` 且 32 字节对齐。`dst`/`src` 元素位宽须一致。支持
  `b8`/`b16`/`b32`；**`b64` 在板上有问题**，stub 会拒绝。
- 已上板验证 2026-07-21（`agent/example/kernels/a5/vec_only/gatherb_onboard.py`）。

```python
dst = Reg(DT.int)               # b32
src = Tensor(DT.int, [1, 128], Position.UB)
idx = Reg(DT.uint32)            # idx[i] = 输出块 i 的 32B 对齐字节偏移
ub_to_reg_gatherb(dst, src, idx)
```

### `unsqueeze(dst, mask=None)`

- 作用：对 mask 位做原地 EXCLUSIVE 前缀和（`MicroAPI::Unsqueeze`，PrefixSumImpl）。
- 规则：`dst[i]` = lane `i` 之前严格在前的 active mask lane 数（lane `i` 在 active lane 中的 rank）；
  最后一个 active lane 及其之后的所有 lane 都携带总的 active 计数。
- 输入 `dst` 被忽略——结果只是 mask 的函数。尽管名字如此，它**不是** `squeeze` 的逆；它是给
  `squeeze`/`gather_mask` 寻址提供索引的原语。已上板验证 2026-07-21。

```text
mask active lanes = {1, 3, 4}
dst (out)         = [0, 0, 1, 1, 2, 3, 3, 3, ...]   # mask 的 exclusive 前缀和
```

### `mask_to_ub(dst, src)` / `ub_to_mask(dst, src)`

- 作用：把 `MaskReg` 存到 / 从 UB 载入（`MicroAPI::StoreAlign` / `LoadAlign` 的 MaskReg 重载）。
  `mask_to_ub(ub_tensor, mask_reg)` 存储；`ub_to_mask(mask_reg, ub_tensor)` 载入。
- **反直觉、已上板验证的字节粒度布局**（2026-07-21）：两者始终搬运完整 32 字节（256-bit）向量
  mask 寄存器（不是 `VL/8` 字节），与 UB tensor dtype 无关；元素大小为 `S` 字节的 mask 的元素
  lane `i` 落在物理 bit `i*S`（LSB-first），故 `S>1` 时中间的位为 0。stub 会发一次性 `UserWarning`。
  目标 UB 至少 32 字节；`b8`/`b16`/`b32`/`b64` 都可用。
- 对同一 UB 先 `mask_to_ub`（存）后 `ub_to_mask`（载）是 RAW 冒险：中间用
  `vf_barrier(VfPipe.STORE, VfPipe.LOAD)` 隔开。

```python
m = MaskReg(DT.int)             # b32 mask
ub = Tensor(DT.uint8, [1, 256], Position.UB)
mask_to_ub(ub, m)               # StoreAlign(ub, m)：32 个 mask 字节，lane i -> bit 4i
# ... vf_barrier(VfPipe.STORE, VfPipe.LOAD) ...
ub_to_mask(m, ub)               # LoadAlign(m, ub)：逆操作
```

## 6. 寄存器打包

### `HighLowPart`

`HighLowPart` 选择 native `pack()` 结果写入目标寄存器的哪一半：

| 值 | 目标 layout |
| --- | --- |
| `HighLowPart.LOWEST` | 打包值在低半部；高半部清零 |
| `HighLowPart.HIGHEST` | 低半部清零；打包值在高半部 |

请直接使用预定义值。默认值是 `LOWEST`。

### `pack(dst, src, low_or_high=HighLowPart.LOWEST)`

- 作用：从每个源元素取目标位宽的低 bits，把紧凑值连续写入 `dst`
  的一半
- 没有 mask 参数
- 目标元素位宽必须正好是源元素位宽的一半
- 支持的 `(dst <- src)` pair：
  - `DT.uint8 <- DT.uint16` 或 `DT.int16`
  - `DT.uint16 <- DT.uint32` 或 `DT.int`
  - `DT.uint32 <- DT.uint64` 或 `DT.int64`
- `HighLowPart` 未选中的那一半会清零。两次对同一目标的调用不会累加；
  需要两半时，应显式合并两个分别打包的寄存器

```python
src16 = Reg(DT.uint16)
packed8 = Reg(DT.uint8)
pack(packed8, src16, HighLowPart.LOWEST)
```

这个 native register pack 与 `Reg.pack4()` / `reg_to_ub_pack4()` 不同；后两者是在
写 UB 时从 8-bit 寄存器中每四个 lane 选一个。

## 7. Interleave 辅助

### `interleave(dst0, dst1, src0, src1)`

- 作用：把两个源寄存器交错写入两个目标寄存器。
- 参数：
  - `dst0`、`dst1`：目标 `Reg`
  - `src0`、`src1`：源 `Reg`

规则：

- 设 `half = lane_count / 2`
- 对 `k in [0, half)`：
  - `dst0[2 * k]     = src0[k]`
  - `dst0[2 * k + 1] = src1[k]`
  - `dst1[2 * k]     = src0[half + k]`
  - `dst1[2 * k + 1] = src1[half + k]`

8 lane 示例：

```text
src0 = [a0, a1, a2, a3, a4, a5, a6, a7]
src1 = [b0, b1, b2, b3, b4, b5, b6, b7]

dst0 = [a0, b0, a1, b1, a2, b2, a3, b3]
dst1 = [a4, b4, a5, b5, a6, b6, a7, b7]
```

Alias 行为：

- 模拟器会先快照两个源
- 因此 `interleave(reg0, reg1, reg0, reg1)` 的语义是稳定的

示例用法：

```python
out0 = Reg(DT.half)
out1 = Reg(DT.half)
interleave(out0, out1, reg0, reg1)
```

限制：

- 四个寄存器的 dtype 必须一致
- 四个寄存器的 lane 数必须一致
- lane 数必须为偶数

### `deinterleave(dst0, dst1, src0, src1)`

- 作用：把 `interleave()` 的布局还原回来。
- 参数：
  - `dst0`、`dst1`：目标 `Reg`
  - `src0`、`src1`：源 `Reg`

规则：

- 设 `half = lane_count / 2`
- 对 `k in [0, half)`：
  - `dst0[k]        = src0[2 * k]`
  - `dst1[k]        = src0[2 * k + 1]`
  - `dst0[half + k] = src1[2 * k]`
  - `dst1[half + k] = src1[2 * k + 1]`

8 lane 示例：

```text
src0 = [a0, b0, a1, b1, a2, b2, a3, b3]
src1 = [a4, b4, a5, b5, a6, b6, a7, b7]

dst0 = [a0, a1, a2, a3, a4, a5, a6, a7]
dst1 = [b0, b1, b2, b3, b4, b5, b6, b7]
```

往返性质：

```text
deinterleave(*, *, *interleave(src0, src1)) == (src0, src1)
```

Alias 行为：

- 和 `interleave()` 一样，模拟器也会先快照源

示例用法：

```python
out0 = Reg(DT.half)
out1 = Reg(DT.half)
deinterleave(out0, out1, tmp0, tmp1)
```

限制：

- 四个寄存器的 dtype 必须一致
- 四个寄存器的 lane 数必须一致
- lane 数必须为偶数

## 8. VF 本地内存 barrier

### `VfPipe` 与 `VfPipeType`

`VfPipe` 是 `vf_barrier` 使用的 VF 本地内存 pipe 选择子命名空间。它只在
A5 系列 facade（`easyasc.a5` 和 `easyasc.a5pr`）中导出，并且与
[`pipe.md`](pipe.md) 里的 `Pipe` / `PipeType` 是两个独立概念：`Pipe`
限定的是跨 pipe 同步的作用域（`Pipe.V`、`Pipe.MTE2`……），而 `VfPipe`
区分的是单个 `@vf` micro 内部的本地内存 store / load 流。

可用成员：

| 公开名 | 含义 | C++ 模板实参 |
| --- | --- | --- |
| `VfPipe.STORE` | VF 本地内存的 store 流（如 `reg_to_ub*`） | `MicroAPI::MemType::VEC_STORE` |
| `VfPipe.LOAD` | VF 本地内存的 load 流（如 `ub_to_reg*`） | `MicroAPI::MemType::VEC_LOAD` |

每个成员都是一个 `VfPipeType` 单例，封装了对应的 C++ 枚举 tag 名。相等性按名字比较；与非 `VfPipeType` 比较会抛 `TypeError`。

平时直接使用预定义的 `VfPipe.STORE` 和 `VfPipe.LOAD` 即可。`VfPipeType(name)` 是框架内部构造的，不是给 kernel 作者用的。

### `vf_barrier(src, dst)`

- 作用：在一个 `@vf` micro module 内部，为 VF 本地内存访问建立顺序。
- 参数：
  - `src`：`VfPipe.STORE` 或 `VfPipe.LOAD`
  - `dst`：`VfPipe.STORE` 或 `VfPipe.LOAD`
- codegen：
  - `vf_barrier(VfPipe.STORE, VfPipe.LOAD)` 会生成
    `MicroAPI::LocalMemBar<MicroAPI::MemType::VEC_STORE, MicroAPI::MemType::VEC_LOAD>();`
  - 一般而言，两端都会下沉成上表里对应的 C++ 模板实参
- simulator：
  - 当前 micro simulator 是串行执行模型，因此会把 `vf_barrier` 当作 no-op
  - 缺失 barrier 的检查发生在 micro instruction 静态分析阶段，而不是 runtime 调度阶段

当硬件可能并行执行 VF store、load、compute 流时，需要显式使用这个 API。常见场景：

- `reg_to_ub` 后面还有一次写同一个 UB 地址的 store：插入 `vf_barrier(VfPipe.STORE, VfPipe.STORE)`
- `reg_to_ub` 后面的 `ub_to_reg` 会读取刚写过的 UB 地址：插入 `vf_barrier(VfPipe.STORE, VfPipe.LOAD)`
- 非 scan 的 UB handoff 中，后续 load 必须看到前一次 store：在依赖 load 前插入 `vf_barrier(VfPipe.STORE, VfPipe.LOAD)`

`vf_barrier` **不能**把 in-place UB scan 变成标量顺序语义。对
prefix/reverse-prefix sum、cumsum，以及类似的 VF 递推，loop-carried 状态
必须放在 `Reg` / `RegList` 里。不要在同一个 VF loop 里让一个 UB tensor 同时作为：

- 每个元素 base value 的来源；
- scan 结果的写回目标。

例如，不要依赖下面这种递推：

```python
val <<= work_ub[0:1, t:t + 1].single()
acc <<= acc + val
work_ub[0:1, t:t + 1] <<= acc.single_value()
```

优先在寄存器里直接算 base value 和 recurrence，只把每个元素的最终结果写回
UB。如果 scan 前必须先 materialize base vector，用两个不同的 UB tensor，
例如 `base_ub` 和 `out_ub`，但要对这份 exact generated code 做硬件验证。
这是硬件正确性规则，不只是 analyzer 限制：950 probe 里 separate
source/output UB round trip 在随机输入下也失败过；aliased UB reverse-scan
在全 1 输入下即使带显式 store/load barrier 仍然失败。直接寄存器累加才是稳定路径。

静态分析会保守地检查同一个 UB 基底上可能重叠的区域。对于无法静态证明不重叠的动态 slice，即使某个具体 shape 下不重叠，也可能发出 warning。

## 9. 相关阅读

与 cast 相关的 API 另见 [a5_micro_cast.md](a5_micro_cast.md)。
