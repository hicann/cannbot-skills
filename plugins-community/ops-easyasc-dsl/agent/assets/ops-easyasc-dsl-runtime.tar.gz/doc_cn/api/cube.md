# Cube 数据搬运与计算

本页文档说明从 `easyasc.a2` 与 A5 系列 facade（`easyasc.a5` 和
`easyasc.a5pr`）提供的 cube 侧数据搬运与计算辅助。

本页覆盖的 API 包括：

- `gm_to_l1_nd2nz`
- `gm_to_l1_dn2nz`
- `gm_to_l1`
- `gm_to_l1_pad`
- `gm_to_l1_mx_scale`
- `gm_to_l1_mx_scale_nd2nz`
- `set_constant_to_l1`
- `l1_to_l0`
- `l1_to_l0a_img2col`
- `l1_to_bt`
- `l1_to_l0_mx`
- `mmad`
- `mmad_mx`
- `l0c_to_gm_nz2nd`
- `l0c_to_gm_nz2nz`（写回 GM 时保持 NZ / NC1HWC0 布局）
- `l0c_to_gm_nz2dn`（仅 A5 系列；转置写回，sugar `gm <<= l0c.T`）
- `l0c_to_l1`
- `l0c_to_ub`
- `DualMode` 与 `DualModeType`

## 硬件家族说明

在阅读本页任何和设备相关的规则前，先把映射记清楚：

- `device_type in ("950", "950pr")` -> C310
- `is_c220_family(device_type)`（`b*` 或 `a3`）-> C220
- 在 `easyasc/resources/tensorutils.h` 中，`__DAV_C310__` 是 `950` 路径
- 在 `easyasc/resources/tensorutils.h` 中，`__DAV_C220_CUBE__` 是 `b*` 路径

下面不少布局选择和 lowering 分支都依赖这层映射。

## 1. 布局模型：ND、NZ、ZN 与对齐

要理解大多数 cube helper，最容易的方法，是先把同一份数据分成两种视角来看：

- 逻辑上的 `ND` 视图：
  - 就是普通二维矩阵语义，形状为 `[M, N]`
- 打包后的视图：
  - 这是 on-chip 或面向 pipeline 的物理布局，由 cube 搬运 / 计算指令实际使用

模拟器把这些打包布局规则暴露得非常清楚。

### L1 / L0A / L0B 的 NZ 风格打包

对于 `L1`、`L0A`，以及 `L0B` 的非转置路径，模拟器把打包后的存储看成：

```text
[block_n, aligned_m, C0]
```

其中：

- `block_n = ceil(N / C0)`
- `aligned_m = align16(M_stride)`
- `C0 = 32 / element_size_in_bytes`

例如：

- `half` 或 `bfloat16`：
  - 元素大小是 `2`
  - `C0 = 16`
- `float`：
  - 元素大小是 `4`
  - `C0 = 8`
- `int8` / `uint8`：
  - 元素大小是 `1`
  - `C0 = 32`

逻辑索引规则如下：

- 逻辑上的 `ND[row, col]`
- 对应的 packed block 索引是 `block = col // C0`
- 对应的 packed lane 索引是 `lane = col % C0`
- 最终存放在 `panel[block, row, lane]`

这正是模拟器辅助函数 `decode_nz_to_nd(...)` 与 `encode_nd_to_nz(...)` 所实现的规则。

### L0C 打包

`L0C` 与前面几者不同：

- 它在模拟器中的布局使用固定的 `C0 = 16`
- 这个固定的 `16` 与 dtype 无关

因此，从概念上看，`L0C` 的 packed storage 是：

```text
[block_n, align16(M_src), 16]
```

这也是为什么 `l0c_to_l1`、`l0c_to_gm_nz2nd` 和 `l0c_to_ub` 在解码源数据时，都会使用固定的 `C0 = 16`。

### `l1_to_l0` 中的 ZN 路径

`l1_to_l0` 的转置路径不会继续沿用同样的 NZ 布局。

模拟器会写出一种 ZN 风格布局，其形状取决于 dtype：

- 行块大小：
  - 对 `int8` 是 `32`
  - 对其他受支持 dtype 是 `16`
- `N` 的对齐方式是：
  - 对 `int8` 按 `32` 对齐
  - 其他情况则按 `C0` 对齐

这就是当前实现中，在不把普通二维转置真正 materialize 成 Python 空间里的新矩阵的前提下，如何表达 `L0A` / `L0B` 的转置视图。

### 为什么到处都会出现 `align16(M)`

大多数 cube 侧打包布局，即使逻辑拷贝高度更小，物理存储上也仍会把 `M` 维按 `16` 行对齐。

这意味着：

- 逻辑上的 tail 行依然是有效的
- 多出来的物理行只是 padding
- 目标容量检查时，通常使用的是 `align16(M_dst)` 或 `align16(M_src)`，而不是原始逻辑 `M`

### tail 列

当 `N` 不是 `C0` 的整数倍时：

- 完整 block 会正常拷贝
- 最后一个 tail block 只会拷贝前 `tail = N % C0` 条 lane
- 这个最后 block 中剩余的 lane，在新写入 packed buffer 时会被零填充

模拟器在很多 ND -> NZ 编码前，都会显式先把目标缓冲清零，正是为了这一点。

## 2. `gm_to_l1_nd2nz(dst, src, M=None, N=None, N_src=None, M_dst=None)`

- 作用：把一个 GM 里的逻辑 ND 窗口拷贝到 `L1` 张量中
- 来源：
  - 逻辑 ND
- 目标：
  - 默认是 L1 NZ
  - 但在 `b*` 设备上，如果目标张量 dtype 是 `float`，codegen 会改为走 L1 ZZ helper
- Pipe：
  - `MTE2`
- Codegen lowering：
  - 默认：`GM2L1_ND2NZ(dst, src, M, N, N_src, M_dst);`
  - `b*` + `float`：`GM2L1_ND2ZZ(dst, src, M, N, N_src, M_dst);`

### 参数

- `dst`：
  - 目标 `Tensor`
  - 必须位于 `Position.L1`
- `src`：
  - 来源 `GMTensor`
- `M`：
  - 逻辑拷贝的行数
- `N`：
  - 逻辑拷贝的列数
- `N_src`：
  - GM 来源矩阵的逻辑行跨度（以 element 为单位）
  - 它表示的是底层源矩阵的宽度，而不一定等于这次拷贝的宽度
- `M_dst`：
  - 目标侧在 `align16` 之前的逻辑行容量

### 限制与检查

- `dst.dtype` 必须等于 `src.dtype`；`gm_to_l1_nd2nz()` 是 layout/padding
  copy，不是 dtype 转换点。

### 自动推导

如果 `M`、`N` 和 `N_src` 全都省略，stub 会根据切片后的 `GMTensor` 视图推导它们：

- 如果有两个被切片的维度：
  - `M = src.span[first_sliced_dim]`
  - `N = src.span[second_sliced_dim]`
  - `N_src = src.shape[second_sliced_dim]`
- 如果只有一个被切片的维度：
  - 按单行拷贝处理
  - `M = 1`
  - `N = src.span[sliced_dim]`
  - `N_src = src.shape[sliced_dim]`

如果省略了 `M_dst`：

- `M_dst = dst.shape[0]`

### 模拟器执行模型

模拟器会：

1. 把 `src` 解释成指向 GM 存储的一维指针视图
2. 把逻辑源矩阵解释成一个行跨度为 `N_src` 的 ND 窗口
3. 根据目标 dtype 计算目标 `C0`：
   - `C0 = 32 / dst.element_size()`
4. 用下面这些量来分配 / 检查打包目标大小：
   - `block_count = ceil(N / C0)`
   - `aligned_M_dst = align16(M_dst)`
   - `needed = block_count * aligned_M_dst * C0`
5. 先把目标缓冲清零
6. 写入每一个完整的 `C0` block；如果有尾块，再写入尾块

### ND -> NZ 的实际含义

假设：

- `dtype = half`，因此 `C0 = 16`
- `M = 3`
- `N = 20`
- `M_dst = 5`

那么：

- `aligned_M_dst = 16`
- `block_count = ceil(20 / 16) = 2`
- 从概念上看，打包后的目标形状就是 `[2, 16, 16]`

逻辑映射关系是：

- 列 `0..15` 进入 block `0`
- 列 `16..19` 进入 block `1` 的 lane `0..3`
- block `1` 的 lane `4..15` 保持为零
- 两个 block 里的行 `3..15` 都是 padding

### 限制与报错

- `dst` 必须是 `L1`
- `src` 必须是 `GMTensor`
- `N <= N_src`
- `M <= M_dst`
- 源和目标底层视图都必须足够大，能容纳请求的逻辑形状及其打包后大小

### 示例

```python
l1x <<= x[m0:m1, k0:k1]
```

这通常会推导出：

- `M = m1 - m0`
- `N = k1 - k0`
- `N_src = x.shape[last_sliced_dim]`
- `M_dst = l1x.shape[0]`

### Normal-mode 的 L1 拷贝

`gm_to_l1(...)` 是共享的连续 GM 到 L1 helper。它会 lowering 到普通
`GM2L1` / `DataCopy` 路径，用 32 字节 block 来度量 `burst_len` 和 stride，
在 A2 上就是连续 GM->L1 路径，在 A5/A5PR 上则是不带 padding 的变体。

`gm_to_l1_pad(...)` 是仅 A5 系列支持的 padded 变体。它会 lowering 到
`GM2L1PAD` / `DataCopyPad`，把每个目的 burst padding 到 32B 边界，适合 GM
侧是紧凑数据、但 L1 存储仍需满足本地对齐的场景。

当你在 L1 上显式写 `Tensor(..., layout=Layout.ND)`，然后再写
`l1_nd <<= gm_slice` 时，DSL 会分发到同一条连续路径：

- a2：`gm_to_l1(...)`
- a5：`gm_to_l1_pad(...)`

### 连续路径：`gm_to_l1(dst, src, n_burst=None, burst_len=None, src_stride=None, dst_stride=None)`

- 作用：把连续或显式带 stride 的 GM 字节流搬进 L1，而不做 ND->NZ 分形打包
- 设备：
  - A2 与 A5 系列
- Pipe：
  - `MTE2`
- Codegen lowering：
  - `GM2L1(dst, src, n_burst, burst_len, src_stride, dst_stride);`

当逻辑源本身就已经是你想在 L1 中保留的扁平布局时，应使用这个 helper，尤其是后续
还要把 bias row 喂给 `l1_to_bt` 的场景。

MX scale 辅助 `gm_to_l1_mx_scale(...)` 建立在 `gm_to_l1_pad` 之上。它会把外部
packed e8m0 scale 从：

```text
GMTensor(DT.uint8, [num_blocks, 32])
```

搬到 L1 scale tile：

```text
Tensor(DT.uint8, [16, 2 * k_blocks], Position.L1)
```

注意：外部 GM scale 不是逻辑 `[rows, ceil(K / 32)]` 矩阵。它必须已经按
`[row_tile, k64_block, 16, 2]` 打包，并展平成 `[num_blocks, 32]`。每个 32B
block 存一个 16 行 tile 的两个 K-32 group，顺序是
`row0_g0, row0_g1, row1_g0, row1_g1, ...`。

scale 打包约定见 [MX FP8 / MXFP4 Matmul 说明](../topics/mxfp.md)。

### Dense MX scale 路径：`gm_to_l1_mx_scale_nd2nz(dst, src, rows=None, k_groups=None, src_k_groups=None)`

- 作用：把 shape 为 `[rows, ceil(K / 32)]` 的 dense GM e8m0 scale 搬到
  `l1_to_l0_mx` 消费的紧凑物理 L1 MX scale layout
- 设备：
  - 仅 A5 系列
- Pipe：
  - `MTE2`
- Codegen lowering：
  - `GM2L1_MX_SCALE_DN2NZ(dst, src, rows, k_groups, src_k_groups);`

这个 helper 面向自然持有逻辑 dense scale matrix 的调用方，不需要手工把
它预打包成 `[row_tile, k64_block, 16, 2]` GM block。

公开合同：

- `src`：`GMTensor(DT.uint8, [rows, k_groups])`
- `dst`：`Tensor(DT.uint8, [rows, 2 * ceil(k_groups / 2)], Position.L1)`
- `rows` 当前必须按 16 行对齐

生成的 A5 helper 会把相邻 e8m0 pair reinterpret 为 `half`，再用
`Dn2NzParams` 生成与 packed helper 相同的紧凑 MX 物理顺序：

```text
[ceil(rows / 16), ceil(k_groups / 2), 16, 2 bytes]
```

如果三个 shape 参数都省略，helper 会推导：

- `rows = src.span[0]`
- `k_groups = src.span[1]`
- `src_k_groups = src.shape[1]`

因此，带 slice 的 dense GM view 可以用更窄的可见 `k_groups`，同时在
`src_k_groups` 中保留原始 GM row stride。

### 转置加载：`gm_to_l1_dn2nz(dst, src, M=None, N=None, N_src=None, M_dst=None)`

- 作用：把一个以**转置形式存放**在 GM 中的矩阵加载到 `L1`，并以普通 NZ 形式落地：
  `GM[n, m]` 会喂给目标 NZ 元素 `[m, n]`。这个转置发生在 MTE2 传输过程中。
- 设备：
  - 仅 A5 系列（`Dn2NzParams` 只存在于 C310；a2 上 stub 会直接报错）
- Pipe：
  - `MTE2`
- Codegen lowering：
  - `GM2L1_DN2NZ(dst, src, M, N, N_src, M_dst);`（由 `tensorutils.h` 中的
    `__DAV_C310__` 宏门控）

参数名字跟随**目标逻辑矩阵**，与 `gm_to_l1_nd2nz` 保持一致：

- `M`：目标行数（也就是 GM 列跨度）；映射到 `Dn2NzParams.nValue`，范围 `<= 16384`
- `N`：目标列数（也就是 GM 行跨度）；映射到 `dValue`
- `N_src`：GM 行跨度（以元素计），也就是两列目标之间在源里的间隔；
  必须满足 `N_src >= M`。映射到 `srcDValue`
- `M_dst`：目标在 `align16` 之前的逻辑行容量；`align16(M_dst)` 会成为
  `dstNzC0Stride`

自动推导与 `gm_to_l1_nd2nz` 类似，但多了转置。对二维切片
`xt[n0:n1, m0:m1]`（`xt` 形状为 `[N_total, M_total]`）：

- `M = m1 - m0`
- `N = n1 - n0`
- `N_src = xt.shape[last_sliced_dim]`（即 `M_total`）
- `M_dst = dst.shape[0]`

如果只切了一个维度（即一行 GM）：

- 这会变成一个目标**单列**
- `M = span`
- `N = 1`
- `N_src = src.shape[sliced_dim]`

Sugar：`l1 <<= gm.T`（或 `l1 <<= gm[a:b, c:d].T`）会分发到 `gm_to_l1_dn2nz`。
`GMTensor.T` 会注册一个零拷贝的转置 full-window view；它要求目标 L1 是 NZ
布局，且 `.T` 视图不能再切片、reshape、reinterpret，也不能作为 store 目标
使用——先做这些变换，再加 `.T`。

典型用途：GM 里存放的是一个 matmul 操作数的转置，例如形状 `[K, M]` 的 `A^T`，
但要把它加载到形状 `[M, K]` 的 `l1a`。参考
`agent/example/kernels/a5/matmul/matmul_dn2nz_transpose_load.py`（simulator 精确通过，且在
CANNSIM 上也验证过，包括 `N_src > M` 的矩形切片场景）。

## 3. `set_constant_to_l1(tensor, val, n_blocks=None)`

- 作用：按 packed storage 布局，用一个标量常量填充 `L1` 张量
- Pipe：
  - `MTE2`
- Codegen lowering：
  - `InitConstValue(tensor, {1, n_blocks, 0, val});`

### 参数

- `tensor`：
  - 目标 `Tensor`
  - 必须位于 `Position.L1`
- `val`：
  - 标量值
  - 可以是 `Var`、`int` 或 `float`
- `n_blocks`：
  - 需要填充的 packed `C0` block 数

### dtype 规则

stub 会要求 `val` 与 `tensor.dtype` 的语义相匹配：

- 浮点风格张量 dtype 要求输入是浮点标量
- 整数风格张量 dtype 要求输入是整型标量
- 如果传的是 `Var`，它也必须带有匹配的 dtype

### 自动推导

如果省略 `n_blocks`：

```text
n_blocks = tensor.shape[0] * tensor.shape[1] // tensor.dtype.C0
```

也就是说，这个 helper 假定张量 shape 本身已经描述了一块与 packed layout 相兼容的逻辑容量。

### 模拟器执行模型

模拟器会计算：

- `C0 = 32 / tensor.element_size()`
- `fill_elements = n_blocks * C0`

然后填充底层线性 L1 指针视图中的前 `fill_elements` 个元素。

这一点很重要：

- 这是一种按 block 工作的操作
- 它不是按逻辑 `[M, N]` 坐标来理解的
- 它只是把张量底层存储前面那段 packed 区域填上常量

### 限制

- `tensor.offset` 必须为零
- `n_blocks` 必须非负
- 目标视图必须足够大，能容纳 `n_blocks * C0` 个元素

### 示例

```python
set_constant_to_l1(l1buf, 0.0)
```

典型用途：

- 在只会部分覆盖的场景中，先初始化一个 L1 staging buffer
- 先造出一块带默认填充值的 packed tile

## 4. `l1_to_l0(dst, src, m_dst=None, n_dst=None, m_src=None, n_src=None)`

- 作用：把一个 `L1` tile 搬到 `L0A` 或 `L0B`
- 来源：
  - 默认是 L1 NZ
  - 但在 `b*` 设备上，通过 `GM2L1_ND2ZZ` 加载进来的 `float` 源在 lowering 时会按 L1 ZZ 处理
- 目标：
  - L0 ZZ / NN / NZ / ZN，具体取决于转置路径、目标位置、dtype 和设备类型
- Pipe：
  - `MTE1`

### Codegen lowering

最终发射出的后端 op 取决于：

- 目标位置是 `L0A` 还是 `L0B`
- 来源视图是否带 `.T`
- 来源 dtype
- 当前设备类型

parser 会在这些 backend op 中选择：

- `L0NZ2ZZ`
- `L0NZ2NN`
- `L0NZ2NZ`
- `L0NZ2ZN`
- `L0ZZ2ZZ`
- `L0ZZ2NN`
- `L0ZZ2NZ`
- `L0ZZ2ZN`

在 `b*` 设备上，如果 `L1` 源是 `float`，lowering 会改走 `L0ZZ2*` 这一族；其他情况仍然走 `L0NZ2*`。

当前 simulator 对非转置路径的布局说明：

- 在 `b*` 上，`dst == L0A` 按 ZZ layout 建模
- 在 `b*` 上，`dst == L0B` 按 NZ layout 建模
- 在 `b*` 且 `L1` 源是 `float` 时，simulator 会先把源按 ZZ 解码，再写入目标布局

也就是说，Python DSL 表面虽然是统一的，但后端 lowering 是刻意按布局细分的。

### 参数

- `dst`：
  - 目标 `Tensor`
  - 必须位于 `Position.L0A` 或 `Position.L0B`
- `src`：
  - 来源 `Tensor`
  - 必须位于 `Position.L1`
- `m_dst`、`n_dst`：
  - 逻辑目标 tile 形状
- `m_src`、`n_src`：
  - 切片前来源的逻辑完整形状

### 自动推导

如果省略：

- `m_dst = src.span[0]`
- `n_dst = src.span[1]`
- `m_src = src.shape[0]`
- `n_src = src.shape[1]`

stub 还会继续传递：

- `dst.is_transpose = src.is_transpose`

这也是为什么 `l0a <<= l1x.T` 会改变后续 lowering 行为，而无需分配一块真正转置后的新缓冲。

### 模拟器执行模型：非转置路径

对于非转置路径，模拟器会：

1. 把来源解释成 NZ，使用：
   - `C0 = 32 / dst.element_size()`
   - 来源行跨度 `src_stride_m`
2. 支持 `l1_slice_offset=[row0, col0]`，但当前只支持切片步长为 `1`
3. 同时支持：
   - 对齐的列起点，例如 `col0 = 16`
   - 不对齐的列起点，例如 `col0 = 5`
4. 把选中的逻辑 ND 窗口重新打包成目标 NZ

这里“列起点不对齐”很关键，因为如果 `src_col0 % C0 != 0`，模拟器就不能简单地整块复制，而必须逐 lane gather。

### 模拟器执行模型：转置路径

当 `src.is_transpose` 为真时，模拟器会：

1. 解码出所请求的 L1 逻辑 ND 区域
2. 把它 padding 到一个与 ZN 兼容的缓冲中
3. 然后按下面规则写入：
   - `int8` 使用行块 `32`
   - 其他 dtype 使用行块 `16`

这条路径存在的原因是：cube 计算对不同操作数期待的 packed 方向并不相同。

### 限制

- 模拟器当前只支持 `slice_step == 1`
- 来源切片必须落在 `m_src` / `n_src` 范围内
- 目标容量检查依据的是打包后的 NZ 或 ZN 大小，而不只是逻辑 `m_dst * n_dst`

### 示例

```python
l0a <<= l1a
l0b <<= l1b.T
```

其含义是：

- 第一行保持普通 NZ 方向
- 第二行要求走转置导向的 lowering 路径

### load3d img2col：`l1_to_l0a_img2col(dst, src)`

- 作用：通过 load3d / `L12L0A_IMG2COL`，把一个逻辑 `img2col(...)` 窗口从 `L1`
  NC1HWC0 feature map materialize 到 `L0A`
- 设备：
  - A2 与 A5 系列
- Pipe：
  - `MTE1`
- Codegen lowering：
  - `L12L0A_IMG2COL(dst, src, h, w, c, kh, kw, pad_l, pad_r, pad_t, pad_b, stride_h, stride_w, dil_h, dil_w, k0, m0, k_ext, m_ext);`

### 源合同

- `src` 必须是从 `img2col(fmap, conv, h, w, c)` 切出来的 `Img2colSlice`，例如：
  `acc[m0:m0 + tm, k0:k0 + tk]`
- 底层 `fmap` 必须是以 NC1HWC0 存储的 `L1` tensor
- `dst` 必须位于 `Position.L0A`
- `dst.dtype` 必须与 `fmap.dtype` 相同

### 布局与设备行为

A2 与 A5 系列的逻辑 gather 完全一致：

- 行是输出位置 `m = oh * Wo + ow`
- 列遵循 `K = C1, Kh, Kw, C0` 顺序
- 空间越界或通道越界的读都会补零

只有最终打包后的 `L0A` 布局因设备不同而不同：

- A2 / `b*`：ZZ
- A5 / `950` 与 A5PR / `950pr`：NZ

对 A5 系列有一条关键规则：这条硬件指令**不暴露 K 向 destination stride**。当
`k_ext > C0` 时，helper 会在内部按 C0 K-fractal 分次发射 load3d，并逐步拼出
最终的 NZ `L0A` tile。DSL 表面仍然只有一条
`l1_to_l0a_img2col(...)` 调用。

### 限制与检查

- `m_ext > 0` 且 `k_ext > 0`
- `m0` 与 `m_ext` 必须是 `16` 的倍数
- `k0` 与 `k_ext` 必须是 `C0` 的倍数
- `dst` 容量必须覆盖 packed `L0A` footprint，不能只看 `m_ext * k_ext`
- `dst` offset 必须满足 512B 对齐
- 源与目标存储都必须满足后端对齐检查
- helper 在 lowering 前会把通道数取整到完整 `C0` block；host packer 会把通道尾零填充，
  因此这种取整在数值上是等价的

### 示例

```python
conv = Conv2D(kh=3, kw=3, pad=(1, 1, 1, 1))
fm = Tensor(DT.half, [C1 * H * W, C0], Position.L1)
acc = img2col(fm, conv, h=H, w=W, c=C)
l0a = Tensor(DT.half, [16, 256], Position.L0A)

l1_to_l0a_img2col(l0a, acc[0:16, 0:256])
```

回归覆盖：
`agent/example/testcases/codegen/core/test_img2col_trace.py` 与
`agent/example/testcases/codegen/core/test_img2col_a5_sim.py`。

### MX 变体：`l1_to_l0_mx(dst, src, src_mx, ...)`

`l1_to_l0_mx` 是仅 A5 系列支持的 MX FP8 / MXFP4 L1 到 L0 helper。它把 FP8 数据或
carrier-backed FP4 view 从 L1 搬到匹配的 L0A/L0B compute view，同时把匹配的
e8m0 scale 字节搬进隐藏的 L0AMX 或 L0BMX buffer。

lowering：

```text
L0NZ2NZ_MX(dst, src, src_mx, m_dst, n_dst, m_src, n_src)
L0NZ2ZN_MX(dst, src, src_mx, m_dst, n_dst, m_src, n_src)  # src.T
```

关键限制：

- `src` 必须是位于 `Position.L1` 的 `DT.e4m3` / `DT.e5m2`，或
  `DT.fp4_e2m1` / `DT.fp4_e1m2` carrier-backed view
- `dst` 必须是位于 `Position.L0A` 或 `Position.L0B` 的匹配 MX FP8 dtype，
  或匹配的 FP4 carrier-backed view
- `src_mx` 必须是位于 `Position.L1` 的 `DT.uint8`
- 非转置 `src` 走 NZ2NZ
- `Position.L0A` 与 `Position.L0B` 目标都支持 `src.T`，并走 NZ2ZN
- `src_mx` 不能转置；NZ2ZN 路径要求它已经按转置后的行序打包
- 静态 NZ2ZN tile 要求物理源两个维度对齐：FP8 按 32 个元素，FP4 按 64 个元素

详细约定见 [MX FP8 / MXFP4 Matmul 说明](../topics/mxfp.md)。

### bias-table staging：`l1_to_bt(dst, src, n=None)`

- 作用：把连续 L1 bias row 拷贝到 BT / `TPosition::C2` buffer，供 matmul bias 消费
- 设备：
  - A2 与 A5 系列
- Pipe：
  - `MTE1`
- 限制：
  - `dst` 必须位于 `Position.BT`
  - `src` 必须位于 `Position.L1`
  - `dst.dtype` 必须等于 `src.dtype`
  - 支持的 bias dtype 是 `DT.float`（float/half/bf16 输入族）和 `DT.int`
    （int8@int8）
  - BT 总容量：A2 为 512 B，A5/A5PR 为 4 KB
  - 自动 depth-2 shortcut buffer 会把总容量分成两个 slot：A2 每个 slot 为
    256 B / 64 个 fp32 或 int32 元素；A5/A5PR 每个 slot 为 2 KB / 512 个元素
  - shortcut 的 nosplit/splitk bias 必须有静态已知、且能放进一个 slot 的完整 N；
    动态总 N 必须使用静态有界的 splitn tile
  - L1 源必须是连续布局；在使用 `<<=` 前，先通过 `gm_to_l1(...)`、
    `gm_to_l1_pad(...)`，或者创建 `layout=Layout.ND` 的 L1 tensor 来完成 stage

这个 helper 是公开的桥接点，用于把 L1 bias row 送进 init K tile 上的
`mmad(..., bias=bt)` 或 `mmad_mx(..., bias=bt)`。

## 5. `mmad(dst, src_a, src_b, M=None, N=None, K=None, is_init=True, bias=None)`

- 作用：对已经准备好的 `L0A` 与 `L0B` tile 执行 cube 乘加
- Pipe：
  - `M`
- Codegen lowering：
  - `MMAD(dst, src_a, src_b, M, K, N, is_init);`
  - 带 `bias=...` 时：`MMAD_BIAS(dst, src_a, src_b, bias, M, K, N, is_init);`

### 参数

- `dst`：
  - 位于 `Position.L0C` 的 `Tensor`
- `src_a`：
  - 位于 `Position.L0A` 的 `Tensor`
- `src_b`：
  - 位于 `Position.L0B` 的 `Tensor`
- `M`、`N`、`K`：
  - 逻辑 matmul 维度
- `is_init`：
  - 这次操作是否负责初始化目标累加区
- `bias`：
  - 可选，必须是位于 `Position.BT` 的 `Tensor`
  - 只在 init K tile 上消费，因此语义是 `C = bias + A @ B`

### 自动推导

如果省略：

- `M` 来自 `src_a`
- `N` 来自 `src_b`
- `K` 来自 `src_a` 的内层维度

具体取哪一个维度，还取决于 `src_a` 或 `src_b` 是否带有转置元数据。

### 模拟器执行模型

模拟器会：

1. 把 `src_a` 从 NZ 解码成逻辑形状 `[M, K]`
2. 把 `src_b` 从 NZ 解码成逻辑形状 `[N, K]`
3. 计算：

```text
prod = a_nd @ b_nd^T
```

4. 在合适的时候使用更高计算精度：
   - `float16` / `bfloat16` 会在 `float32` 中累加
   - 小整数路径会在 `int32` 中累加
5. 如果带有 `bias`，就在写回前、且仅在 init tile 上先把 BT row 加进去
6. 再把结果写回到使用固定 `C0 = 16` 的 `L0C` NZ 中

### `is_init` 的含义

- `is_init=True`：
  - 当前结果会覆盖逻辑目标区域
- `is_init=False`：
  - 模拟器会先解码已有目标区域
  - 然后把新的乘积加到它上面

因此 `is_init=False` 表示的是真正的累加，而不只是“别先清零”。

### L0C 切片行为

模拟器还支持通过保存在元数据中的 `l0c_slice_offset` 来做逻辑目标切片：

- 先计算出一个子矩阵
- 再把它写进更大 `L0C` tile 中的某个窗口

但切片步长仍然必须是 `1`。

### 限制

- `M`、`N`、`K` 必须非负
- 源和目标视图都必须足够大，能容纳对应 packed layout
- 模拟器只接受受支持的打包 dtype
- 如果带 `bias`，它必须是 BT tensor，只能与 `is_init=True` 一起使用，并且
  dtype 必须匹配该设备对 MMAD bias table 的支持：
  `int8@int8` 走 `DT.int`，其他输入族走 `DT.float`

### 示例

```python
mmad(l0c, l0a, l0b, M=M, N=N, K=K, is_init=True)
```

典型累加循环：

```python
for k_tile in range(k_tiles):
    mmad(l0c, l0a, l0b, M=M, N=N, K=K_tile, is_init=(k_tile == 0))
```

### MX 变体：`mmad_mx(dst, src_a, src_b, M=None, N=None, K=None, is_init=True, bias=None)`

`mmad_mx` 是仅 A5 系列支持的 MX FP8 / MXFP4 compute helper。它消费 MX FP8 或
carrier-backed FP4 L0A/L0B 操作数，以及由 `l1_to_l0_mx` 写入的隐藏
L0AMX/L0BMX scale buffer。

lowering：

```text
MMAD_MX(dst, src_a, src_b, M, K, N, is_init)
MMAD_MX_BIAS(dst, src_a, src_b, bias, M, K, N, is_init)  # bias=...
```

限制：

- `dst` 必须是位于 `Position.L0C` 的 `DT.float`
- `src_a` 必须是位于 `Position.L0A` 的 `DT.mx_e4m3`、`DT.mx_e5m2`、
  `DT.fp4_e2m1` 或 `DT.fp4_e1m2`
- `src_b` 必须是位于 `Position.L0B` 的 `DT.mx_e4m3`、`DT.mx_e5m2`、
  `DT.fp4_e2m1` 或 `DT.fp4_e1m2`
- 两个 source 必须属于同一 family：FP8/FP8 或 FP4/FP4
- `is_init=False` 会累加到已有 L0C tile
- 如果带 `bias`，它必须是位于 `Position.BT` 的 `DT.float`，并且只能用于 init tile

普通 kernel 通常应该调用 `matmul_mx`，而不是手写 `l1_to_l0_mx` 和
`mmad_mx` staging。

## 6. `l0c_to_gm_nz2nd(dst, src, M=None, N=None, N_dst=None, M_src=None, relu=False, scale=1.0, offset=0, hif8_hybrid=False)`

- 作用：把一个 `L0C` tile 以逻辑 ND 的形式写回 GM
- 来源：
  - 使用固定 `C0 = 16` 的 L0C NZ
- 目标：
  - GM ND
- Pipe：
  - `FIX`
- Codegen lowering：
  - `L0C2GM_NZ2ND(dst, src, M, N, N_dst, M_src);`

### 参数

- `dst`：
  - 目标 `GMTensor`
- `src`：
  - 位于 `Position.L0C` 的来源 `Tensor`
- `M`、`N`：
  - 逻辑写回尺寸
- `N_dst`：
  - 目标行跨度（以元素为单位）
- `M_src`：
  - 在 `align16` 之前的来源逻辑行容量

### 自动推导

如果 `M`、`N` 和 `N_dst` 全都省略，stub 会从切片后的 GM 目标视图中推导：

- 如果有两个被切片的维度：
  - `M = dst.span[first_sliced_dim]`
  - `N = dst.span[second_sliced_dim]`
  - `N_dst = dst.shape[second_sliced_dim]`
- 如果只有一个被切片的维度：
  - `M = 1`
  - `N = dst.span[sliced_dim]`
  - `N_dst = dst.shape[sliced_dim]`

如果省略 `M_src`：

- `M_src = src.shape[0]`

### 模拟器执行模型

模拟器会：

1. 按下面的规则解码来源 `L0C` NZ：
   - 固定 `C0 = 16`
   - 来源行跨度 `align16(M_src)`
2. 得到逻辑 ND 形状 `[M, N]`
3. 再以行跨度 `N_dst` 的方式把它写进 GM 指针区域

与片上的 packed 格式不同，GM 被当成普通带行跨度的 ND：

- 第 `r` 行
- 从偏移 `r * N_dst` 开始

### 与原子模式的交互

如果当前处在原子上下文中，模拟器不会直接覆盖目标。
它会把解码出的逻辑 ND 区域，与现有 GM 区域按当前原子模式做组合：

- `add`
- `max`
- `min`

### 限制

- `M <= M_src`
- `N <= N_dst`
- 来源必须有足够的 packed `L0C` 存储
- 目标指针区域必须有足够的 ND 容量

### 示例

```python
z[m0:m1, n0:n1] <<= l0c
```

这通常会推导出：

- `M = m1 - m0`
- `N = n1 - n0`
- `N_dst = z.shape[last_sliced_dim]`

### Fixpipe quant 参数（`nz2nd` / `nz2nz` / `nz2dn` / `l0c_to_ub` 共用）

这四个 L0C 写回 stub 共用同一套 fixpipe 标量量化派发：

- `relu`（bool，默认 `False`）：在量化**之前**把解码后的负值 clamp 到 `0`。
- `scale`（`int` / `float` / `Var`，默认 `1.0`）：以 `src * scale19` 的形式应用，其中
  `scale19` 只保留 fp32 scale 的高 19 位（硬件 float19 截断）。
- `offset`（`int` / `Var`，默认 `0`）：仅用于 8-bit 路径——
  `clamp(round_half_even(src * scale19), -256, 255) + offset`，再 saturate 到 `int8`
  （`-128..127`）或 `uint8`（`0..255`）。
- `hif8_hybrid`（bool，默认 `False`）：仅用于 `hif8` 目标；用 hybrid round mode 把
  `src * scale19` 编码成 hif8，而不是默认模式。

按 dtype 的量化路径：

- 8-bit 目标（`int8` / `uint8`）：scale19 + round-half-even + offset + saturate。
- 浮点目标（`half` / `bfloat16` / `float`）：`out = (dst)(src * scale19)`。
- `e4m3` 目标：`(float8_e4m3fn)(src * scale19)`。
- `hif8` 目标：`fp32_to_hif8(src * scale19, hybrid?)`。

仅 A5 系列支持的量化组合（在 a2 上会被拒绝）：

- 目标 `e4m3` 或 `hif8`
- 目标 `bfloat16` 且 src 为 `int32`
- 目标 `half` / `bfloat16` / `float`、src 为 `float`，**且** `scale` / `offset` 非平凡
  （`scale != 1.0` 或 `offset != 0`）

其余路径（普通 fp32->float cast、int32->fp16 dequant、8-bit 量化）在 A2 与 A5 系列上都可用。

## 6a. `l0c_to_gm_nz2nz(dst, src, m_pad=None, relu=False, scale=1.0, offset=0, hif8_hybrid=False)`

- 作用：把一个 `L0C [m, n]` tile 写回 GM，并**保持 NZ（NC1HWC0 风格）布局**，而不是解码成
  逻辑 ND。GM 目标是扁平 NZ 平面 `[C1o * m_pad, C0]` 的一个 `[m, C0]` 行切片：strip `c1`
  把 `out[:, 16*c1 : 16*c1 + 16]` 存为第 `c1 * m_pad + m` 行。
- 设备：a2 和 A5 系列（部分量化 dtype 组合仅 A5 系列——见上面的共用说明）。
- 来源：L0C NZ，固定 `C0 = 16`。
- 目标：GM NZ 平面。
- Pipe：`FIX`。
- 代码生成 lowering：
  - `L0C2GM_NZ2NZ(dst, src, M, N, m_pad, M_src, relu);`
  - 带量化：`L0C2GM_NZ2NZ(dst, src, M, N, m_pad, M_src, relu, scale, offset, true, hybrid);`

### 参数

- `dst`：目标 `GMTensor`，一个 `[*, C0]` 的 NZ 平面（`C0 = 16` 对应 >= 2 字节 dtype，8-bit 为 `32`）。
- `src`：来源 `Tensor`，位于 `Position.L0C`；dtype 为 `float` 或 `int32`。
- `m_pad`：NZ 平面里每个 strip 的行数（16 对齐，`>= m`）。省略时按
  `dst.shape[0] // (n // C0)` 推导；当平面堆叠多个 batch 或 `dst` 是 `Var` 形状时需显式传入。
- `relu`、`scale`、`offset`、`hif8_hybrid`：共用的 fixpipe 量化，见上面的说明。

### 限制

- `src.dtype` 必须是 `float` 或 `int32`；`dst.dtype` 必须是
  `half` / `bfloat16` / `float` / `int32` / `int8` / `uint8` / `e4m3` / `hif8` 之一。
- L0C tile 必须是 `[16k, C0*k]`。
- `dst` 宽度必须等于 `C0`（>= 2 字节为 `16`，8-bit 为 `32`）。
- 原子上下文的合并方式与 `l0c_to_gm_nz2nd` 相同。

## 6b. `l0c_to_gm_nz2dn(dst, src, M=None, N=None, M_dst=None, M_src=None, relu=False, scale=1.0, offset=0, hif8_hybrid=False)`（仅 A5 系列）

- 作用：把一个 `L0C [m, n]` tile **按转置形式**写回 GM，也就是 NZ2DN
  （`CO2Layout::COLUMN_MAJOR`）fixpipe。目标是 `[n, m]` 平面，满足
  `dst[j, i] = L0C[i, j]`，因此写回时不需要额外的 vec transpose
- Sugar：`gm <<= l0c.T`（`.T` 标在 L0C 源上；GM 目标形状是 `[N, M]`）
- 设备：**仅 A5 系列 / C310。** 这条 NZ2DN fixpipe 在 a2/V220 上未验证并被门控关闭
- 源：L0C NZ，固定 `C0 = 16`（与 `nz2nd` 相同）
- 目标：GM ND，形状 `[N, M]`
- Pipe：`FIX`
- Codegen lowering：`L0C2GM_NZ2DN(dst, src, M, N, M_dst, M_src);`

### 参数

- `M`、`N`：**L0C 源**的逻辑维度（`m` 行、`n` 列），默认来自 `src.shape`
- `M_dst`：转置后目标 `[n, m]` 的行宽 / stride，默认是 `dst.shape[-1]`，必须满足
  `>= m`。如果 `dst` 是切片，这里要求的是整个底层 buffer 的宽度，而不是切片 span
- `M_src`：`align16` 之前的逻辑源行容量（也就是 NZ 的 `nz_M`），默认来自 `src.shape[0]`
- `relu`、`scale`、`offset`、`hif8_hybrid`：与 `nz2nd` 共用同一套 quant / relu
  分发（`ResolveFixpipeQuant`）；通过 `gm <<= l0c.T` 的 sugar 也会带过去

### 模拟器执行模型

模拟器会先把 L0C NZ 源解码成逻辑 `[m, n]` tile（与 `nz2nd` 完全相同），然后：

1. 转置成 `[n, m]`
2. 应用任何 quant / relu
3. 以行跨度 `M_dst` 把 `n` 行、每行 `m` 个元素 scatter 回 GM

atomic 上下文中的组合方式与 `nz2nd` 相同。

### 硬件备注（cannsim 已验证）

`L0C2GM_NZ2DN` 会设置
`FixpipeParamsC310<COLUMN_MAJOR>::params = {1, 0, 0, 1}`，也就是
`Nz2DnParams{dnNum, srcNzMatrixStride, dstDnMatrixStride, srcNzC0Stride}`。
默认构造函数会让 `srcNzC0Stride = 0`，这会把源上的 m 方向步进钉死在第 0 行，
于是每一列输出都会拿到 `src[0, n]`（转置坍缩）。把 `srcNzC0Stride` 设为 `1`
之后，转置才能按预期推进；这与 arch 3510 上 matmul adv_api 的
`FixpipeParamsUtil` 行为一致。

## 7. `l0c_to_l1(dst, src, M=None, N=None, M_dst=None, M_src=None, relu=False)`

- 作用：把一个 `L0C` tile 搬到 `L1`
- 来源：
  - 使用固定 `C0 = 16` 的 L0C NZ
- 目标：
  - 使用 `C0 = 32 / element_size` 的 L1 NZ
- Pipe：
  - `FIX`
- Codegen lowering：
  - `L0C2L1(dst, src, M, N, M_dst, M_src, relu);`

### 参数

- `dst`：
  - 位于 `Position.L1` 的目标 `Tensor`
- `src`：
  - 位于 `Position.L0C` 的来源 `Tensor`
- `M`、`N`：
  - 逻辑拷贝尺寸
- `M_dst`：
  - 在 `align16` 之前的目标逻辑行容量
- `M_src`：
  - 在 `align16` 之前的来源逻辑行容量
- `relu`：
  - 是否在写入前把负值截断为零

### 自动推导

如果省略：

- `M = dst.span[0]`
- `N = dst.span[1]`
- `M_dst = dst.shape[0]`
- `M_src = src.shape[0]`

### 模拟器执行模型

模拟器会：

1. 用下面的规则解码来源 `L0C`：
   - 固定 `C0 = 16`
   - 来源跨度 `align16(M_src)`
2. 把解码出的逻辑 ND 数据转换成 `dst.dtype`
3. 如果需要，再应用 ReLU
4. 然后按下面规则重新编码进目标 `L1` NZ：
   - `C0_dst = 32 / dst.element_size()`
   - 目标跨度 `align16(M_dst)`

因此，这个操作是真正的“重新打包”：

- 源布局规则与目标布局规则并不相同
- dtype 也可能发生变化

### 为什么这是“按 16 对齐还是按 C0 对齐”的典型例子

这个操作同时出现了两类对齐逻辑：

- 来源 `L0C`：
  - 固定 `C0 = 16`
- 目标 `L1`：
  - `C0` 由 dtype 决定，即 `32 / elem_size`
- 但两边的行容量仍然都要经过 `align16(M_*)`

### 示例

```python
l1mid <<= l0c
```

### 带 cast + ReLU 的示例

```python
l0c_to_l1(l1_out, l0c_acc, relu=True)
```

它会把 `L0C` 中的 float 累加数据解码出来，先把负值截断，再 cast 成 `l1_out.dtype`，最后重新打包写入 L1 NZ。

## 8. `DualModeType` 与 `DualMode`

`DualModeType` 是 `l0c_to_ub` 用来描述“一个 `L0C` 结果如何路由给 vec 侧消费者”的小型值类。

### `DualModeType`

- 字段：
  - `name`
  - `value`
- 行为：
  - `str(mode)` 返回诸如 `SINGLE` 或 `SPLITM` 这样的名字
  - 相等性同时比较 `name` 和数值 `value`

正常情况下不需要手工构造它。

### `DualMode`

`DualMode` 是一个枚举风格命名空间，导出三种受支持模式：

- `DualMode.SINGLE`
  - 数值是 `0`
- `DualMode.SPLITM`
  - 数值是 `1`
- `DualMode.SPLITN`
  - 数值是 `2`

stub 也接受原始整数 `0`、`1`、`2`，但在用户代码里，显式枚举名更清楚也更安全。

### 各模式的含义

`SINGLE`：

- 不做拆分
- 一个完整的逻辑 ND tile 只会发送给一个 sub-block
- 具体给 lane `0` 还是 lane `1`，由 `sub_block_id` 决定

`SPLITM`：

- 按行拆分
- 前一半行给 lane `0`
- 后一半行给 lane `1`
- 要求 `M` 是偶数

`SPLITN`：

- 按列拆分
- 左半列给 lane `0`
- 右半列给 lane `1`
- 要求 `N` 是偶数

### 为什么 `DualMode` 会存在

`l0c_to_ub` 往往正好是 cube 输出交给 vec 的那个交接点。

框架当前建模了两个 vec sub-block 消费者，因此同一个 `L0C` 结果可能需要：

- 整块送给其中一个 lane
- 按行拆给两个 lane
- 按列拆给两个 lane

`DualMode` 就是用来精确控制这件事的。

## 9. `l0c_to_ub(dst, src, M=None, N=None, N_dst=None, M_src=None, dual_mode=DualMode.SPLITM, sub_block_id=None, relu=False, scale=1.0, offset=0, hif8_hybrid=False)`

- 作用：把一个 `L0C` tile 搬到 `UB`，通常用于 cube -> vec 交接
- 设备：A5 系列（`easyasc.a5` / 950 和 `easyasc.a5pr` / 950PR）；a2 没有
  `l0c_to_ub`
- 来源：
  - 使用固定 `C0 = 16` 的 L0C NZ
- 目标：
  - 发布成逻辑 ND 负载，送给一个或两个 vec lane
- Pipe：
  - `FIX`
- Codegen lowering：
  - `L0C2UB_NZ2ND(dst, src, M, N, N_dst, M_src, dual_mode, sub_block_id, relu);`

### 参数

- `dst`：
  - 位于 `Position.UB` 的目标 `Tensor`
- `src`：
  - 位于 `Position.L0C` 的来源 `Tensor`
- `M`、`N`：
  - 拆分前的逻辑源 tile 尺寸
- `N_dst`：
  - 目标侧逻辑行跨度
- `M_src`：
  - 在 `align16` 之前的来源逻辑行容量
- `dual_mode`：
  - `DualModeType`，或原始整数 `0/1/2`
- `sub_block_id`：
  - 在 `SINGLE` 模式下表示当前 lane id
  - 默认为 `None`
  - 在 `DualMode.SINGLE` 下必须显式传 `0` 或 `1`
  - 在 `SPLITM` 或 `SPLITN` 下不使用该 id；省略值会在内部归一化为 `0`
- `relu`：
  - 发布前可选地做截断
- `scale`、`offset`、`hif8_hybrid`：
  - 与 `l0c_to_gm_nz2nd` 共用同一套 fixpipe 量化（见 §6）

### 自动推导

如果 `M`、`N` 和 `N_dst` 都省略，stub 会根据 `dst` 和 `dual_mode` 推导：

- `SINGLE`：
  - `M = dst.span[0]`
  - `N = dst.span[1]`
- `SPLITM`：
  - `M = dst.span[0] * 2`
  - `N = dst.span[1]`
- `SPLITN`：
  - `M = dst.span[0]`
  - `N = dst.span[1] * 2`

在这三种情况下：

- `N_dst = dst.shape[1]`

如果省略 `M_src`：

- `M_src = src.shape[0]`

这也是为什么默认的 `dst <<= src_l0c` 路径会选择 `SPLITM`：

- 一个 UB 视图描述的是某个 lane 的半块 tile
- 完整源 `M` 就可以被推导成这个 lane 局部高度的两倍

`DualMode.SINGLE` 刻意不提供静默 lane 默认值。省略 `sub_block_id` 会
抛 `ValueError`，因为默认到 lane 0 可能静默丢掉本应发布给 lane 1 的结果。
如果需要在 `SINGLE` 模式下填充两个 lane，应分别显式调用
`sub_block_id=0` 和 `sub_block_id=1`。

### 模拟器执行模型

模拟器会：

1. 用固定 `C0 = 16` 解码来源 `L0C` NZ
2. 把它转换成 `dst.dtype`
3. 如有需要，再应用 ReLU
4. 按 `dual_mode` 路由逻辑 ND 结果
5. 把扁平化 ND 负载发布到共享的 `L0CToUBState`

这个发布既区分 lane，也区分槽位：

- 目标张量名用于标识逻辑上的交接缓冲家族
- 如果目标来自 `DBuff` / `TBuff`，对应的 buffer slot 索引也会被保留

### 路由规则

`SINGLE`：

- 把完整的 `[M, N]` 逻辑 tile 发布给 `sub_block_id` 指定的 lane
- 另一个 lane 什么也收不到

`SPLITM`：

- 要求 `M` 是偶数
- lane `0` 拿到 `logical[:M/2, :]`
- lane `1` 拿到 `logical[M/2:, :]`

`SPLITN`：

- 要求 `N` 是偶数
- lane `0` 拿到 `logical[:, :N/2]`
- lane `1` 拿到 `logical[:, N/2:]`

### 目标容量规则

容量检查针对的是“lane 局部视图”，而不是完整源 tile：

- `SINGLE`：
  - 目标必须能容纳 `M * N`
- `SPLITM`：
  - 目标必须能容纳 `(M/2) * N`
- `SPLITN`：
  - 目标必须能容纳 `M * (N/2)`

这与 vec lane 实际消费发布负载的方式是一致的。

### 示例：默认按行拆分

```python
ub_lane <<= l0c_tile
```

如果 `ub_lane.shape == [16, 16]`，那么默认推导会得到：

- `dual_mode = SPLITM`
- `M = 32`
- `N = 16`

因此 lane `0` 与 lane `1` 各自会拿到一个 `16 x 16` 的半块，按行拆开。

### 示例：按列拆分

```python
l0c_to_ub(ub_lane, l0c_tile, dual_mode=DualMode.SPLITN)
```

如果 `ub_lane.shape == [16, 16]`，则会推导出完整源 tile 为：

- `M = 16`
- `N = 32`

lane 路由是：

- lane `0`：左边 `16` 列
- lane `1`：右边 `16` 列

### 示例：只发布到一个 lane

```python
l0c_to_ub(ub_lane, l0c_tile, dual_mode=DualMode.SINGLE, sub_block_id=1)
```

其含义是：

- 完整逻辑 tile 只会发布给 vec sub-block `1`
- sub-block `0` 在这次发布里什么也拿不到

## 10. 如何选择正确的写回路径

在下面这些情况里，使用 `l0c_to_gm_nz2nd`：

- cube 输出已经是最终结果，或者应当留在 GM
- 下游消费者期待的是普通 ND 布局

在下面这些情况里，使用 `l0c_to_l1`：

- 后面还有另一个 cube 阶段要继续消费这份数据
- 你希望在进入下一阶段前就完成 dtype 转换或 ReLU

在下面这些情况里，使用 `l0c_to_ub`：

- 下一个消费者是 vec 代码
- 结果需要被路由到一个或两个 vec sub-block

## 11. 常见坑

- 不要假设所有 packed layout 都用同样的 `C0`。`L0C` 固定是 `16`，而 `L1` / `L0A` / `L0B` 则是 `32 / element_size`
- 不要只按逻辑 `M * N` 去估计缓冲大小。容量检查通常使用的是带 `align16(M)` 与 `ceil(N / C0)` 的 packed size
- 不要把 `l1_to_l0` 与 `l0c_to_l1` 当成普通 memcpy；它们本质上是重新打包
- 使用 `DualMode.SPLITM` 时不要给奇数 `M`；使用 `DualMode.SPLITN` 时不要给奇数 `N`
- 不要以为 `l0c_to_ub` 在模拟器里就是直接写一个普通 UB 张量；它实际上是通过共享交接状态发布 lane 局部负载
