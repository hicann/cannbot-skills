# A2 向量数学

本页介绍的是由 `easyasc.a2` 直接导出的 UB 向量数学辅助。

一个重要的范围说明是：

- 这里这些名字，在 `a2` 里都是顶层函数
- 同名函数在 `a5` 中通常表示的是 micro 寄存器操作，而不是这里的 UB 向量操作

当省略 `repeat` / `*_stride` 时，大多数 A2 vec helper 会使用
`easyasc/stub_functions/vec/vecutils.py` 里的自动推导规则：

- float `span[1] == 64` -> `blk_stride=1`，`rep_stride=shape[1] // 8`
- float `span[1] == 8` -> `blk_stride=0`，`rep_stride=shape[1] // 8`
- half `span[1] == 128` -> `blk_stride=1`，`rep_stride=shape[1] // 16`
- half `span[1] == 16` -> `blk_stride=0`，`rep_stride=shape[1] // 16`
- 如果 `span[0] == 1` 且命中了上面的特殊情况，则 `rep_stride=0`

这意味着像 float `[M, 8]`、half `[M, 16]` 这样的窄 broadcast 视图，在默认
推导下并不是“物理上连续的 dense 存储”；每个 repeat 只会别名到一个 C0 block。
行标量状态应保存在 `[1, M]` 里，需要 broadcast 视图时再用 `brcb(...)`
物化。完整模型和 mixed-width 例子见 `agent/references/constraints/vec.md`。

## Mask 行为总览

在看各个 API 细节前，先记住当前模拟器里的这套规则：

- Binary / unary / unary-scalar / `dup`
  - 会在 dst 写回阶段消费当前 vec mask
  - 被 mask 掉的 lane 会保留原来的 `dst` 值
- 组规约算子
  - `cadd`、`cgadd`、`cpadd`：被 mask 掉的源元素按 `0` 参与计算
  - `cmax`、`cgmax`：被 mask 掉的源元素按 `-inf` 处理
  - `cmin`、`cgmin`：被 mask 掉的源元素按 `+inf` 处理
  - 如果某个规约域对应的 active 区间全都被 mask 掉，则对应的 `dst` 槽位不会被覆写
- `brcb`
  - 当前会忽略 vec mask 状态
- 相关 control 类算子在 A2 vec control 页说明
  - `compare`、`compare_scalar`、`select`、`gather`、`scatter` 当前都会忽略 vec mask 状态

## 1. 共享的二元 vec 参数

下面这些函数共享同一套参数形状：

- `add`
- `sub`
- `mul`
- `div`
- `vmax`
- `vmin`
- `vand`
- `vor`
- `muladddst`

共享参数包括：

- `dst`：目标 UB `Tensor`
- `src1`、`src2`：来源 UB `Tensor`
- `repeat`：可选的重复次数；如果省略，会从 `dst` 推导
- `*_blk_stride`：可选的 block stride
- `*_rep_stride`：可选的 repeat stride

共享限制包括：

- `dst`、`src1` 和 `src2` 必须全部是位于 `Position.UB` 的 `Tensor`
- 这三个张量的 dtype 必须完全一致
- 所有 stride 或 repeat 参数如果给出，必须是 `int` 或 `Var`
- 这些算子会在 dst 写回阶段消费当前 vec mask；被 mask 掉的 lane 会保留原来的 `dst` 值

### `add(dst, src1, src2, ...)`

- 作用：逐元素向量加法，`dst = src1 + src2`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int16`、`int`
- 示例：

```python
add(dst, src1, src2)
```

### `sub(dst, src1, src2, ...)`

- 作用：逐元素向量减法，`dst = src1 - src2`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
sub(dst, src1, src2)
```

### `mul(dst, src1, src2, ...)`

- 作用：逐元素向量乘法，`dst = src1 * src2`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
mul(dst, src1, src2)
```

### `div(dst, src1, src2, ...)`

- 作用：逐元素向量除法，`dst = src1 / src2`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
div(dst, src1, src2)
```

### `vmax(dst, src1, src2, ...)`

- 作用：在两个张量之间做逐元素最大值
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
vmax(dst, src1, src2)
```

### `vmin(dst, src1, src2, ...)`

- 作用：在两个张量之间做逐元素最小值
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
vmin(dst, src1, src2)
```

### `vand(dst, src1, src2, ...)`

- 作用：对向量张量做逐元素按位与
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`int16_t`、`uint16_t`
  - A2 高维 `And` 不能直接接收 `int32_t`/`uint32_t`；应先把所有操作数
    显式 reinterpret 成匹配的 16-bit 视图。该视图会把最后一个逻辑维度扩大
    两倍，因此会覆盖每个原始 32-bit 元素的两个半字
- 示例：

```python
vand(dst, src1, src2)
# 等价的表达式形式：
dst <<= src1 & src2
```

### `vor(dst, src1, src2, ...)`

- 作用：对向量张量做逐元素按位或
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`int16_t`、`uint16_t`
  - A2 高维 `Or` 不能直接接收 `int32_t`/`uint32_t`；应使用 `vand` 中说明的
    显式 16-bit reinterpret 路径
- 示例：

```python
vor(dst, src1, src2)
# 等价的表达式形式：
dst <<= src1 | src2
```

### `muladddst(dst, src1, src2, ...)`

- 作用：先把 `src1` 与 `src2` 相乘，再累加到 `dst`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
  - 只有在 `dst` 里已经预先放好了要累加进去的值时，才应该使用它
- 示例：

```python
muladddst(dst, src1, src2)
```

## 2. 共享的单目 vec 参数

下面这些函数共享同一套参数模式：

- `exp`
- `ln`
- `abs`
- `rec`
- `sqrt`
- `rsqrt`
- `vnot`
- `relu`

共享参数包括：

- `dst`：目标 UB `Tensor`
- `src`：来源 UB `Tensor`
- `repeat`：可选的重复次数
- `dst_blk_stride`、`src_blk_stride`：可选的 block stride
- `dst_rep_stride`、`src_rep_stride`：可选的 repeat stride

共享限制包括：

- `dst` 与 `src` 必须是 UB 张量
- `dst.dtype` 必须等于 `src.dtype`
- 这些算子会在 dst 写回阶段消费当前 vec mask；被 mask 掉的 lane 会保留原来的 `dst` 值

### `exp(dst, src, ...)`

- 作用：逐元素指数
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
exp(dst, src)
```

### `ln(dst, src, ...)`

- 作用：逐元素自然对数
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
ln(dst, src)
```

### `abs(dst, src, ...)`

- 作用：逐元素绝对值
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
abs(dst, src)
```

### `rec(dst, src, ...)`

- 作用：逐元素倒数
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
rec(dst, src)
```

### `sqrt(dst, src, ...)`

- 作用：逐元素平方根
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
sqrt(dst, src)
```

### `rsqrt(dst, src, ...)`

- 作用：逐元素平方根倒数
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
rsqrt(dst, src)
```

### `vnot(dst, src, ...)`

- 作用：逐元素按位取反
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`int16_t`、`uint16_t`
  - 对 `int32_t`/`uint32_t`，先把源和目标显式 reinterpret 成匹配的 16-bit
    视图，再调用 `vnot`
- 示例：

```python
vnot(dst, src)
```

### `relu(dst, src, ...)`

- 作用：逐元素 ReLU
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
relu(dst, src)
```

## 3. 共享的“单目 + 标量”vec 参数

下面这些函数共享同一套参数模式：

- `adds`
- `muls`
- `shiftls`
- `shiftrs`
- `vmaxs`
- `vmins`
- `lrelu`
- `axpy`

共享参数包括：

- `dst`：目标 UB `Tensor`
- `src`：来源 UB `Tensor`
- `val`：标量 `int`、`float` 或 `Var`
- `repeat`：可选的重复次数
- stride 参数：可选的 vec stride 元数据
- `count`：可选的 counter mode 连续前缀长度
- `count_per_rep`：可选的每个 repeat 有效 lane 数；与 `count` 互斥

共享限制包括：

- `dst` 与 `src` 必须是 UB 张量
- `dst.dtype` 必须等于 `src.dtype`
- 标量类型必须与张量 dtype 相兼容
- 这些算子会在 dst 写回阶段消费当前 vec mask；被 mask 掉的 lane 会保留原来的 `dst` 值

### `adds(dst, src, val, ...)`

- 作用：给每个元素都加上一个标量
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
adds(dst, src, 1.0)
```

### `muls(dst, src, val, ...)`

- 作用：让每个元素都乘上一个标量
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
muls(dst, src, 2.0)
```

### `shiftls(dst, src, val, ..., *, count=None, count_per_rep=None)`

- 作用：把每个整数元素左移 `val` 位
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 支持 `int16_t`、`uint16_t`、`int32_t`、`uint32_t`
  - Python `int` 会静态检查；16 位张量范围为 `[0, 16]`，32 位张量为 `[0, 32]`
  - `Var` 必须是整数 dtype；codegen 会按 AscendC 要求 cast 成张量 dtype，
    运行时值仍须满足同一范围
  - 通过 `OpExec` 绑定动态 shift count 时应使用 `DT.int`；当前生成 tiling ABI
    不保留更窄的整数 `Var` 参数类型
  - 无符号类型执行逻辑左移
- 真机说明：在已验证的 910B3/CANN 9.0 路径上，
  `ShiftLeft<int16_t, false>` 在外部管理的 count/repeat 两种 mask 模式下都会
  移动完整固定位宽 bit pattern；`0xAAAA` 左移一位得到 `0x5554`，溢出会改变
  符号位。这与当前
  [AscendC ShiftLeft 页面](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0058.html)
  的保留符号位示例不同；EasyASC 模拟器按 910B3 实测结果建模。
- 示例：

```python
shiftls(dst, src, 3, count=element_count)
```

### `shiftrs(dst, src, val, ..., *, count=None, count_per_rep=None, round_en=False)`

- 作用：把每个整数元素右移 `val` 位
- 参数：使用共享参数；`round_en` 是传给 AscendC 高维切分重载的 Python `bool`
- 限制：
  - 支持 `int16_t`、`uint16_t`、`int32_t`、`uint32_t`
  - shift 范围和 `Var` dtype 规则与 `shiftls` 相同
  - 有符号类型算术右移，无符号类型逻辑右移
  - 所有受支持 dtype 都可以传 `round_en`，但 A2 上只有有符号 int16/int32
    会实际启用舍入；算术右移后，若最高被丢弃位为 1，则结果加一
- 参考：[AscendC ShiftRight](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0059.html)
- 示例：

```python
shiftrs(dst, src, 5, count=element_count, round_en=True)
```

### `vmaxs(dst, src, val, ...)`

- 作用：把每个元素钳到至少不小于某个标量阈值
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
vmaxs(dst, src, 0.0)
```

### `vmins(dst, src, val, ...)`

- 作用：把每个元素钳到至多不大于某个标量阈值
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
vmins(dst, src, 1.0)
```

### `lrelu(dst, src, val, ...)`

- 作用：应用 leaky relu，其中标量 `val` 表示负半轴斜率
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
lrelu(dst, src, 0.1)
```

### `axpy(dst, src, val, ...)`

- 作用：执行后端支持的 vec 侧 AXPY 风格标量融合操作
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 支持的 dtype：`float`、`half`
  - 标量类型必须与张量 dtype 兼容
- 示例：

```python
axpy(dst, src, 0.5)
```

## 4. 复制与广播辅助

### `dup(dst, value, repeat=None, dst_blk_stride=None, dst_rep_stride=None, *, count=None, count_per_rep=None)`

- 作用：把一个标量值复制到 UB 张量中
- 参数：
  - `dst`：目标 UB `Tensor`
  - `value`：`int`、`float` 或 `Var`
  - `repeat`：可选重复次数
  - `dst_blk_stride`、`dst_rep_stride`：可选 stride 元数据
  - `count`：可选连续前缀长度；让这次算子进入 vec count mode
  - `count_per_rep`：可选的每个 repeat 有效元素数；保持 repeat mode，但会发射 `set_mask_by_count(count_per_rep)`
- 限制：
  - `dst` 必须位于 `Position.UB`
  - 支持的 dtype：`float`、`half`、`int`、`uint32_t`
  - `count` 与 `count_per_rep` 互斥
  - `dup()` 会在 dst 写回阶段消费当前 vec mask；被 mask 掉的 lane 会保留原来的 `dst` 值
- 示例：

```python
dup(dst, 0.0)
```

### `brcb(dst, src, dst_blk_stride=None, dst_rep_stride=None, repeat=None)`

- 作用：执行仓库里 kernel 常用的 vec 侧广播 / 重复辅助
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `dst_blk_stride`、`dst_rep_stride`、`repeat`：可选控制参数
- 限制：
  - `dst` 与 `src` 必须都是 UB 张量
  - `dst.dtype` 必须等于 `src.dtype`
  - `brcb()` 当前会忽略 vec mask 状态
- 示例：

```python
brcb(dst, src)
```

## 5. 组规约风格算子

下面这些函数共享同一套参数模式：

- `cmax`
- `cgmax`
- `cmin`
- `cgmin`
- `cadd`
- `cgadd`
- `cpadd`

共享参数包括：

- `dst`：目标 UB `Tensor`
- `src`：来源 UB `Tensor`
- `repeat`：可选重复次数
- `dst_rep_stride`：目标 repeat stride；默认值为 `1`，但不能显式传 `None`
- `src_blk_stride`、`src_rep_stride`：可选的来源 stride 元数据
- `count_per_rep`：可选的 keyword-only 参数；设置后，会在本次操作前发射
  `set_mask_by_count(count_per_rep)`，并在操作完成后用 `reset_mask()` 自动
  恢复完整 vec mask

共享限制包括：

- `dst` 与 `src` 必须都是 UB 张量
- 支持的 dtype：`float`、`half`
- `dst_rep_stride` 不能是 `None`
- `vc`、`vcg` 和 `vcp` 三个家族的目标 stride 单位并不相同；当前实现会打印一次性提醒，提示这些单位差异
- 这些算子都会消费 `set_mask()` / `reset_mask()` 设置的当前 vec mask 状态

当前模拟器对这一组算子的 mask 语义如下：

- `cadd`
  - 被 mask 掉的源元素按 `0` 参与求和
  - 如果 active prefix 上所有 mask bit 都是 `0`，则不会覆写目标标量
- `cgadd`
  - 每个 datablock 内，被 mask 掉的源元素按 `0` 参与求和
  - 如果某个 datablock 的 mask 全为 `0`，则不会覆写该 datablock 对应的目标标量
- `cpadd`
  - 在做 pairwise add 之前，被 mask 掉的源元素按 `0` 参与计算
- `cmax`、`cgmax`
  - 被 mask 掉的源元素按 `-inf` 处理
  - 对 `cmax` 来说，如果整个 active prefix 全 0，则不会覆写目标标量
  - 对 `cgmax` 来说，如果某个 datablock 的 mask 全 0，则不会覆写该 datablock 对应的目标标量
- `cmin`、`cgmin`
  - 被 mask 掉的源元素按 `+inf` 处理
  - 对 `cmin` 来说，如果整个 active prefix 全 0，则不会覆写目标标量
  - 对 `cgmin` 来说，如果某个 datablock 的 mask 全 0，则不会覆写该 datablock 对应的目标标量

### `cmax(dst, src, ...)`

- 作用：`vc` 家族里的组最大值规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vc` 家族规则
- 示例：

```python
cmax(dst, src, dst_rep_stride=1)
```

### `cgmax(dst, src, ...)`

- 作用：`vcg` 家族里的组最大值规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vcg` 家族规则
- 示例：

```python
cgmax(dst, src, dst_rep_stride=1)
```

### `cmin(dst, src, ...)`

- 作用：`vc` 家族里的组最小值规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vc` 家族规则
- 示例：

```python
cmin(dst, src, dst_rep_stride=1)
```

### `cgmin(dst, src, ...)`

- 作用：`vcg` 家族里的组最小值规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vcg` 家族规则
- 示例：

```python
cgmin(dst, src, dst_rep_stride=1)
```

### `cadd(dst, src, ...)`

- 作用：`vc` 家族里的组加法规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vc` 家族规则
- 示例：

```python
cadd(dst, src, dst_rep_stride=1)
```

### `cgadd(dst, src, ...)`

- 作用：`vcg` 家族里的组加法规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vcg` 家族规则
- 示例：

```python
cgadd(dst, src, dst_rep_stride=1)
```

### `cpadd(dst, src, ...)`

- 作用：`vcp` 家族里的 packed 加法规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vcp` 家族规则
- 示例：

```python
cpadd(dst, src, dst_rep_stride=1)
```
