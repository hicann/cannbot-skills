# A2 与共享 Vec 控制与访问辅助

本页文档描述由 `easyasc.a2` 导出的非数学向量辅助，以及与 A5 系列
facade（`easyasc.a5` 和 `easyasc.a5pr`）共享的 vec mask 状态 helper。

本页覆盖的范围包括：

- UB 向量 cast
- UB compare 与 select 辅助
- A2 与 A5 系列共享的 vec mask 状态辅助
- UB gather 与 scatter 辅助

本页的 vec cast、compare/select、gather 和 scatter 是 A2-only Tensor API；
§3 的四个函数是共享的顶层 vec `PipeS` 控制。

额外说明：

- 本页中出现的所有张量，都默认应当位于 `UB`
- `compare`、`select`、`gather` 这些名字在 A5 系列中也存在，但那边对应
  micro 寄存器 API，会单独文档化
- 在 A5 系列上，`set_mask`、`set_mask_by_count`、`set_mask_normal` 和
  `reset_mask` 控制 vec mask SPR；A5 `@vf` 可以用 `move_mask_spr` 读该状态

## 1. Vec Cast

### `cast(dst, src, repeat=None, dst_blk_stride=None, src_blk_stride=None, dst_rep_stride=None, src_rep_stride=None, round_mode=RoundMode.AWAY_FROM_ZERO)`

- 作用：在 UB 向量之间执行 dtype cast
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `repeat`：可选的重复次数
  - `dst_blk_stride`、`src_blk_stride`：block stride
  - `dst_rep_stride`、`src_rep_stride`：repeat stride
  - `round_mode`：vec cast 使用的舍入模式
- 限制：
  - 由 `a2` 导出
  - `dst` 与 `src` 必须都是 UB 张量
  - `round_mode` 必须是 `RoundModeType`
  - 当是宽化转换时，运行时会强制使用 `RoundMode.NONE`
- 当前模拟器说明：
  - cast 会忽略 `dst_blk_stride` / `src_blk_stride`；实际只看 repeat stride
  - 每个 repeat 的 cast 元素数由 `src` / `dst` 里更宽的 dtype 决定
  - 当前 vec mask 也在这个 cast-element 域上解析
  - 被 mask 掉的 cast 元素会保留原来的 `dst` 值
- 示例：

```python
cast(dst_half, src_float)
```

## 2. Vec Compare 与 Select

### `SelectModeType` 与 `SelectMode`

vec `select(...)` 这个 stub 需要显式传入 select mode。
这些 mode 对象定义在 `easyasc/utils/selectmode.py` 中。

### `SelectModeType`

- 作用：表示一种具体的 vec select lowering 模式
- 内部保存字段：
  - `name`
- 重要行为：
  - `str(mode)` 返回诸如 `TENSOR_TENSOR` 这样的名字
  - `repr(mode)` 返回诸如 `SelectModeType('TENSOR_SCALAR')` 这样的调试形式
  - 相等性按 mode 名称比较

有一个实现细节在调试 helper 代码时值得知道：

- 把 `SelectModeType` 和其他类型对象做比较时，会抛 `TypeError`
- 它不会安静地返回 `False`

### `SelectMode`

`SelectMode` 是一个枚举风格命名空间，用于 vec 侧 select：

- `SelectMode.TENSOR_TENSOR`
  - 被选中的值来自两个 UB tensor：`src1` 和 `src2`
  - `dst` 不能和任一 source 起始于同一个 UB 地址
- `SelectMode.TENSOR_SCALAR`
  - 真分支来自 `src1`，假分支则来自 `src2` 第一个元素广播出来的标量

两种模式都支持，但 `TENSOR_TENSOR` 有一个重要限制：

- `TENSOR_SCALAR`：`src2` 仍然必须是 UB tensor；它的第一个元素会被当作假分支标量值
- `TENSOR_TENSOR`：`dst` 不能 alias `src1` 或 `src2` 的起始地址；需要原地 select 时要先选到临时 buffer

如果 `dst` 会 alias source，且 dtype 有合适的中性元素，可以把表达式拆成多个 scalar-select 片段再合并，例如：

```python
select(a_part, a_mask, a_tensor, zero_tensor, SelectMode.TENSOR_SCALAR)
select(b_part, b_mask, b_tensor, zero_tensor, SelectMode.TENSOR_SCALAR)
add(dst, a_part, b_part)
```

这只有在 `a_mask` 和 `b_mask` 互补、且 `zero_tensor[0]` 是该 dtype 的加法中性元素时，才等价于 `dst = a_mask ? a_tensor : b_tensor`。

### 为什么这个类型应该放在 A2 vec 页面

`SelectMode` 是给 A2 vec `select(...)` stub 用的，不是给 A5 micro `select(...)` 用的。
把它放在这里，能避免把两个仅仅名字相同、但实际完全不相干的 API 混在一起。

### `compare(dst, src1, src2, mode, repeat=None, ...)`

- 作用：比较两个 UB 张量，并把布尔结果写进一个 UB mask 张量
- 参数：
  - `dst`：保存 compare 结果的目标 UB `Tensor`
  - `src1`、`src2`：来源 UB 张量
  - `mode`：`CompareMode`
  - 其余参数：repeat 与 stride 元数据
- 限制：
  - 由 `a2` 导出
  - `dst` 必须是 UB 上的 `int8` 或 `uint8`
  - `src1` 与 `src2` 必须是 dtype 一致的 UB 张量
  - 支持的来源 dtype：`float`、`half`、`int16`、`int`
  - `compare()` 当前会忽略 vec mask 状态
- 示例：

```python
compare(mask_buf, xub, yub, CompareMode.GT)
```

### `compare_scalar(dst, src1, src2, mode, repeat=None, ...)`

- 作用：把一个 UB 张量与一个标量做比较，并把结果写入 UB mask 张量
- 参数：
  - `dst`：保存 compare 结果的目标 UB `Tensor`
  - `src1`：来源 UB 张量
  - `src2`：标量 `int`、`float` 或 `Var`
  - `mode`：`CompareMode`
  - 其余参数：repeat 与 stride 元数据
- 限制：
  - 由 `a2` 导出
  - `dst` 必须是 UB 上的 `int8` 或 `uint8`
  - `src1` 必须是 UB 上的 `float`、`half`、`int16` 或 `int`
  - `compare_scalar()` 当前会忽略 vec mask 状态
- 示例：

```python
compare_scalar(mask_buf, xub, 0.0, CompareMode.GE)
```

### `select(dst, selmask, src1, src2, mode, repeat=None, ..., tmp_addr_buf=None)`

- 作用：根据张量形式的选择掩码，在两个 UB tensor 来源之间选值，或者在 `src1` 和一个广播标量假分支值之间选值
- 参数：
  - `dst`：目标 UB `Tensor`
  - `selmask`：mask UB `Tensor`
  - `src1`：第一个来源 UB `Tensor`
  - `src2`：第二个来源 UB `Tensor`；`TENSOR_SCALAR` 会读取 `src2[0]` 作为广播标量
  - `mode`：`SelectMode.TENSOR_SCALAR` 或 `SelectMode.TENSOR_TENSOR`
  - `tmp_addr_buf`：**`TENSOR_TENSOR` 必需，`TENSOR_SCALAR` 禁止传。** 由调用方提供的 `uint32` UB `Tensor`，`>= 8` lane（一个 32 B block），用于暂存 per-repeat 的 selMask 地址——见下面的 `TENSOR_TENSOR` 说明
  - 其余参数：repeat 与 stride 元数据
- 限制：
  - 由 `a2` 导出
  - `dst`、`src1`、`src2` 必须是 UB 张量
  - `dst`、`src1`、`src2` 的 dtype 必须一致
  - 支持的数据 dtype：`float`、`half`、`int16`、`int`
  - `selmask` 必须是 `uint8` 张量
  - `select()` 当前会忽略 vec mask 状态；选择仅由 `selmask` 决定
- lowering 模式：
  - `SelectMode.TENSOR_SCALAR` 可用
  - `SelectMode.TENSOR_TENSOR` 仅在 `dst` 和 `src1` / `src2` 起始 UB 地址不同时可用，且必须传 `tmp_addr_buf`
  - parser lowering 会在 `SetCmpMask(...)` 和后端 `Select(...)` 之间插入 `PipeBarrier<PIPE_V>();`
- `TENSOR_TENSOR` 的 per-repeat selMask（`tmp_addr_buf`）：
  - `TENSOR_TENSOR` 会 lowering 到 c220 的 mode-2 `Select`，它**每个 repeat** 都把 selMask 推进 `256/sizeof(dtype)` bit——所以多行 / `repeat > 1` 的 select 每行读取不同的 mask 切片，这正是 per-row mask 想要的行为
  - mode 2 通过 cmpmask SPR 里存的一个*地址*来读 mask bit（不是读 mask 内容），所以必须先把 selMask 地址暂存到 UB buffer。easyasc 要求你通过 `tmp_addr_buf` 显式提供这块 scratch，且**故意不**借用 CANN 隐式的 `TMP_UB_OFFSET` 区域（a2 上的 184-192 KB）——那会占用 easyasc 账本外的 UB，有覆盖用户张量的风险
  - 一个 `tmp_addr_buf` 可以在多个 select 间复用（auto_sync 会把它作为 select 的写来跟踪，从而串行化复用）
  - parser 必须让 `TENSOR_TENSOR` 的 mode-2 `Select` 与地址形式的 cmpmask 配对；若误配 mode-0 的 mask 内容，每个 `repeat > 1` 的行都会把 SPR 当成地址，只有第 0 行可能正确。当前 parser 与 simulator 都使用正确的 mode-2 语义，多行 compare/select 可用
- 示例：

```python
# TENSOR_SCALAR：不传 tmp_addr_buf
select(dst, selmask, src1, zero_tensor, SelectMode.TENSOR_SCALAR)

# TENSOR_TENSOR：传一个 uint32 UB scratch（>= 8 lane）；一个 buffer 可在多个 select 间共享
addr_buf = Tensor(DT.uint32, [1, 8], Position.UB)
select(dst_tmp, selmask, src1, src2, SelectMode.TENSOR_TENSOR, tmp_addr_buf=addr_buf)
```

## 3. Vec Mask 状态

### `set_mask(mask_high, mask_low)`

- 作用：设置当前 vec mask 寄存器状态
- 参数：
  - `mask_high`、`mask_low`：`int` 或 `Var`
- 限制：
  - 由 `a2` 和 A5 系列 facade 导出
  - 如果传的是 `Var`，它的 dtype 必须是 `uint64`
- 当前模拟器说明：
  - `mask_low` 控制 bit `0..63`
  - `mask_high` 控制 bit `64..127`
  - `set_mask()` 不会修改 `mask[128:256]`
  - 常见 active prefix 为：
    - `float` / `int32`：`mask[0:64]`
    - `half` / `int16`：`mask[0:128]`
    - `int8` / `uint8`：`mask[0:256]`
  - 每个 repeat 都会复用同一段 mask prefix，不会随着 repeat 自动前移
- 示例：

```python
set_mask(0, 0xFFFFFFFFFFFFFFFF)
```

### `set_mask_by_count(count)`

- 作用：让每个普通 vector repeat 的前 `count` 个 lane 生效
- 参数：
  - `count`：`int` 或 `Var`
- 限制：
  - 由 `a2` 和 A5 系列 facade 导出
  - 模拟器接受的 `count` 范围是 `[0, 256]`
  - 该接口只修改 mask bit，不会进入 counter mask mode
  - 每个 repeat 都会复用同一个 active prefix
  - 如果后续操作需要默认全 mask，应在 partial-mask 区域后调用 `reset_mask()`
- 示例：

```python
set_mask_by_count(valid_lanes)
adds(dst, src, 1.0, repeat=rows)
reset_mask()
```

### `set_mask_normal()`

- 作用：显式地把向量单元从 counter mask mode 切回普通 repeat mode。
- 参数：无。
- 限制：
  - 由 `a2` 和 A5 系列 facade 导出
  - 如果控制流可能遗留 counter mode，应在普通 repeat-mode reduction 前调用
- Codegen：发射 `SetMaskNorm()`。
- 该接口只切换 mask mode；如果还需要把 mask bit 恢复成默认全 1，应继续调用 `reset_mask()`。

```python
set_mask_normal()
reset_mask()
```

### `reset_mask()`

- 作用：把 vec mask 状态恢复到默认状态
- 参数：
  - 无
- 限制：
  - 由 `a2` 和 A5 系列 facade 导出
  - 在临时 partial-mask 区域之后，应主动调用它，避免后续操作意外继承掩码
- 当前模拟器说明：
  - 会把完整的 `mask[0:256]` 全部恢复成 1
- 示例：

```python
reset_mask()
```

## 4. Gather 与 Scatter

### `gather(dst, src, offset, start_idx=0, repeat=None, dst_rep_stride=None)`

- 作用：使用一个 UB offset 张量，从 UB 来源张量中 gather 元素
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `offset`：保存字节偏移的 UB `Tensor`
  - `start_idx`：基础字节偏移
  - `repeat`：可选重复次数
  - `dst_rep_stride`：目标 repeat stride
- 限制：
  - 由 `a2` 导出
  - `offset` 必须是 UB 上的 `uint32`
  - `dst.dtype` 必须等于 `src.dtype`
  - `offset` 与 `start_idx` 都以字节为单位
  - `gather()` 当前会忽略 vec mask 状态
- 示例：

```python
gather(dst, src, offset)
```

### `gather_block(dst, src, offset, repeat=None, dst_blk_stride=None, dst_rep_stride=None)`

- 作用：块级 gather（AscendC `Gatherb`）。每个 repeat 取 8 个连续的 32B DataBlock，由 `offset` 选择。
  一个 offset 对应一整个 32B 块（`32 // dtype.size` 个元素），不同于元素级 `gather`（一个 offset 对应一个元素）。
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `offset`：保存 32B 对齐块字节地址的 UB `uint32` `Tensor`（每 repeat 8 个）
  - `repeat`：可选重复次数（默认覆盖 `dst`）
  - `dst_blk_stride`：repeat 内块间的 dst 步长，以 32B 块为单位（默认 1）
  - `dst_rep_stride`：repeat 间的 dst 步长，以 32B 块为单位（默认 8）
- 限制：
  - 由 `a2` 导出；A2-only（A5 无顶层对应）
  - `offset` 必须是 UB 上的 `uint32`，且每个值须 32B 对齐
  - `dst.dtype` 必须等于 `src.dtype`
  - “每 repeat 8 块”是固定的 256B 硬件向量宽度，不是可调参数
  - 真机上 c220 `vgatherb` 不接受 16-bit 浮点操作数：对 `half`/`bf16` 数据须在 `gather_block` 前把 `dst`/`src` reinterpret 成 `uint16`（已在 A2 验证）。模拟器不强制这一点，所以 `half` 块 gather 在 sim 能过、真机编不过（`"1st parameter maybe need a type '__ubuf__ unsigned short *'"`）
  - 降级为 `Gatherb(dst, src, offset, repeat, GatherRepeatParams(dst_blk_stride, dst_rep_stride))`
  - `gather_block()` 当前会忽略 vec mask 状态（`Gatherb` 会 reset mask）
- 示例：

```python
gather_block(dst, src, offset, repeat=4)
```

### `scatter(dst, src, offset, start_idx=0, repeat=None, src_rep_stride=None)`

- 作用：使用 offset，把 UB 来源张量中的元素散写到 UB 目标张量中
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `offset`：保存字节偏移的 UB `Tensor`
  - `start_idx`：写入目标的基础字节偏移（默认 `0`）
  - `repeat`：可选重复次数
  - `src_rep_stride`：来源 repeat stride
- 限制：
  - 由 `a2` 导出
  - `offset` 必须是 UB 上的 `uint32`
  - `dst.dtype` 必须等于 `src.dtype`
  - `scatter()` 当前会忽略 vec mask 状态
- 示例：

```python
scatter(dst, src, offset)
```
