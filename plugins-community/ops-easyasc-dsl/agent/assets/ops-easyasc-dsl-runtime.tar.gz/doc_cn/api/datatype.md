# 数据类型

本页文档说明贯穿整个 `easyasc` 的 dtype 对象。

这里有三个名字需要区分：

- `DT`：kernel 作者平时直接使用的 dtype 命名空间
- `Datatype`：`DT` 背后的底层类
- `DataTypeValue`：真正存储在 `Tensor`、`GMTensor`、`Reg`、`MaskReg` 以及许多辅助 API 上的具体 dtype 对象

在普通 kernel 代码里，你几乎总是直接写 `DT.float`、`DT.half`、`DT.int` 这类形式。

## 1. 概览

所有面向用户的 dtype 参数，最终都期待一个 `DataTypeValue`。

典型例子：

```python
ub = Tensor(DT.float, [M, N], Position.UB)
reg = Reg(DT.half)
count = Var(0, DT.int)
dst = reinterpret(src, DT.uint8)
```

这件事重要的原因是：

- Tensor 构造函数会把 `dtype` 校验成 `DataTypeValue`
- 寄存器构造函数也会把 `dtype` 校验成 `DataTypeValue`
- 标量 `Var` 常常会推断或保存 `DT.int` / `DT.float`
- cast 和 reinterpret 辅助使用的是 dtype 对象，而不是字符串

## 2. `DT`

### 它是什么

- `DT` 是 `easyasc.a2` 与 A5 系列入口（`easyasc.a5`、
  `easyasc.a5pr`）导出的公开 dtype 命名空间
- 在当前实现里，`DT` 是 `Datatype` 类的别名

因此下面这些都引用的是同一组单例 dtype 对象：

```python
from easyasc.a5 import DT
# internal equivalent:
# from easyasc.utils.datatype import Datatype

DT.float
DT.half
DT.int
```

### 为什么应优先使用 `DT.*`

- 它属于稳定的公开接口
- 能让 kernel 代码更短、更易读
- 它返回的正是框架其余部分期望的那些预定义单例 dtype 对象

推荐写法：

```python
ub = Tensor(DT.float, [128, 128], Position.UB)
idx = Reg(DT.uint16)
scale = Var(1.0, DT.float)
```

不要把 `"float"` 或 `"int8_t"` 这种原始字符串直接传给那些本来期待 dtype 对象的 API。

## 3. `Datatype`

### 它是什么

- `Datatype` 是定义在 `easyasc/utils/datatype.py` 里的底层类，风格上类似枚举
- 每个类属性都是一个预定义好的 `DataTypeValue` 单例

可用成员如下：

| 公开名称 | 后端拼写 | `size` | `C0` |
| --- | --- | --- | --- |
| `DT.half` | `half` | `2` | `16` |
| `DT.float` | `float` | `4` | `8` |
| `DT.int` | `int` | `4` | `8` |
| `DT.int4` | `int4` | 不支持 | `64` |
| `DT.fp4_e2m1` | `fp4x2_e2m1_t` | 不支持 | `64` |
| `DT.fp4_e1m2` | `fp4x2_e1m2_t` | 不支持 | `64` |
| `DT.int8` | `int8_t` | `1` | `32` |
| `DT.uint8` | `uint8_t` | `1` | `32` |
| `DT.int16` | `int16_t` | `2` | `16` |
| `DT.uint16` | `uint16_t` | `2` | `16` |
| `DT.e4m3` | `float8_e4m3_t` | `1` | `32` |
| `DT.e5m2` | `float8_e5m2_t` | `1` | `32` |
| `DT.mx_e4m3` | `mx_fp8_e4m3_t` | `1` | `32` |
| `DT.mx_e5m2` | `mx_fp8_e5m2_t` | `1` | `32` |
| `DT.bfloat16` | `bfloat16_t` | `2` | `16` |
| `DT.uint32` | `uint32_t` | `4` | `8` |
| `DT.uint64` | `uint64_t` | `8` | `4` |
| `DT.int64` | `int64_t` | `8` | `4` |
| `DT.hif8` | `hifloat8_t` | `1` | `32` |
| `DT.complex32` | `complex32` | `4` | `8` |
| `DT.complex64` | `complex64` | `8` | `4` |

### 各个 dtype 家族常见的用途

- `DT.half`、`DT.float`、`DT.bfloat16`：
  - 最常见的 tensor 和寄存器数值 dtype
- `DT.int`：
  - 整数标量运算
  - 某些按位 vec 路径中的整数 reinterpret 目标
- `DT.int4`：
  - 仅用于 a2 本地 int4 matmul/MMAD 的 compute-view marker
  - GM 和片上真实存储都使用 `DT.int` packed carrier，不能直接分配 `DT.int4`
  - 完整的 carrier / reinterpret / matmul 约定见 [`../topics/int4.md`](../topics/int4.md)
- `DT.fp4_e2m1`、`DT.fp4_e1m2`：
  - 仅用于 A5 系列 MXFP4 本地 compute-view marker
  - GM/L1 payload 使用 `DT.uint8` packed carrier；每个 carrier byte 存两个逻辑 FP4 值
  - 调用 `l1_to_l0_mx` / `matmul_mx` 前，用 `.reinterpret(DT.fp4_e2m1)` 或 `.reinterpret(DT.fp4_e1m2)` 创建视图
  - MX scale 和 FP4 carrier 完整约定见 [`../topics/mxfp.md`](../topics/mxfp.md)
- `DT.int8`、`DT.uint8`、`DT.int16`、`DT.uint16`：
  - 紧凑存储、gather/scatter 索引，以及窄位宽 micro 数据搬运
- `DT.e4m3`、`DT.e5m2`、`DT.hif8`：
  - fp8 相关路径
  - 在当前 micro cast 默认配置选择里，`DT.hif8` 还是一个特殊情况
- `DT.mx_e4m3`、`DT.mx_e5m2`：
  - 仅 A5 系列的 MX FP8 L0A/L0B 本地 compute-view dtype
  - 普通源数据仍然使用 `DT.e4m3` / `DT.e5m2`；`l1_to_l0_mx` 会生成匹配的 MX 本地视图
  - 完整 scale 布局与 matmul 约定见 [`../topics/mxfp.md`](../topics/mxfp.md)
- `DT.uint32`：
  - 经常用于计数器，比如 `update_mask` 里的 `cnt` 参数
- `DT.uint64`、`DT.int64`：
  - 目前公开示例里用得相对少
- `DT.complex32`（`2 x fp16`）、`DT.complex64`（`2 x fp32`）：
  - A5 系列“reg 矢量计算”的复数寄存器计算视图 dtype
  - 支持的 reg 算子恰为 `add`、`sub`、`mul`、`div`、`adds`、`muls`、`abs`、`dup`；
    其余 reg 算子（比较/select、逻辑、移位、min/max、reduce、cast、gather）在 trace 时拒绝复数
  - `abs` 是 复→实（`|z|`）：`complex32 -> half`、`complex64 -> float`
  - `adds`/`muls`/`dup` 接受 python `complex`（或实数）立即数
  - 模拟器在 `complex64` 里计算并降存到寄存器声明宽度；生成的板上 MicroAPI C++ 已在 Ascend950 验证（八个算子、两种宽度）

### host-side carrier / reference helper

这些 helper 是普通的 Python / Torch 工具函数，从 `easyasc.a2` 或 A5 系列
facade（`easyasc.a5`、`easyasc.a5pr`）导出。它们用于打包 host 输入、解码
carrier tensor、构造 golden reference，本身不会发射 DSL 指令。

- A2 int4 carrier helper：
  - `pack_signed_int4_to_int32`、`pack_signed_int4`、`pack_int4_to_int32`
    用于把低 nibble 优先的有符号 int4 值打包成 `DT.int` / `torch.int32`
    carrier
  - `unpack_int32_to_signed_int4`、`unpack_signed_int4`、
    `unpack_int32_to_int4` 用于把这些 carrier 解包回有符号逻辑 int4 值
- A5 e8m0 scale helper：
  - `E8M0_BIAS` 与 `E8M0_MIN_VALUE` 描述外部 e8m0 scale 格式
  - `e8m0_to_fp32` 把 scale 字节解码成 float32
  - `fp32_to_e8m0` 按 floor-log2 把正的 float32 scale 编码成 e8m0 字节
- A5 FP4 carrier helper：
  - `FP4_E2M1_MAX_VALUE` 与 `FP4_E1M2_MAX_VALUE` 是两种导出 FP4 格式的最大有限幅值
  - `fp32_to_fp4_e2m1` / `fp32_to_fp4_e1m2` 把 float32 编码成 `uint8`
    carrier
  - `fp4_e2m1_to_fp32` / `fp4_e1m2_to_fp32` 把这些 carrier 解码回 float32
- A5 HiFloat8 carrier helper：
  - `HIF8_POSITIVE_ZERO`、`HIF8_NAN`、`HIF8_POSITIVE_INF`、
    `HIF8_NEGATIVE_INF`、`HIF8_MAX_POSITIVE_NORMAL`、
    `HIF8_MAX_NEGATIVE_NORMAL`、`HIF8_MAX_FINITE_VALUE`、
    `HIF8_OVERFLOW_THRESHOLD` 描述导出的 HiFloat8 关键码点和边界
  - `fp32_to_hif8` 与 `fp16_to_hif8` 把浮点 tensor 编码成 `uint8` HiFloat8
    carrier
  - `hif8_to_fp32` 把 HiFloat8 carrier 解码成 float32
  - `fp32_to_hifloat8`、`fp16_to_hifloat8`、`hifloat8_to_fp32` 是对应
    `*hif8` helper 的兼容别名
- Conv host packer（位于与 target 无关的 `easyasc.utils.conv2d`；当前只有
  `easyasc.a2` 会重新导出）：
  - `pack_nc1hwc0(x[N, C, H, W], c0=16)` 把 NCHW host tensor 打包成
    `[N*C1*H*W, C0]` 的 NC1HWC0 布局，并对 channel 尾部补零
  - `pack_conv_weight(w[Cout, Cin, Kh, Kw], c0=16)` 把 OIHW host 权重打包成
    ND `[Cout_p, K]` 布局（K 顺序为 `c1 -> kh -> kw -> c0`，并补零）
  - 两者都是 host（numpy/torch）辅助，用于为 `conv2d` shortcut 准备 GM 输入；
    见 [conv2d.md](../topics/conv2d.md)

### 重要的单例规则

当前很多内部路径比较 dtype 时，不仅比较“值相等”，还会直接比较对象身份。

当前代码中的例子包括：

- `Var` 的算术提升里会判断 `other.dtype is Datatype.float` 和 `other.dtype is Datatype.int`
- 某些 vec 按位 lowering 路径会判断 `dst.dtype is Datatype.int`

因此安全写法是：

```python
dtype = DT.float
```

下面这种写法则不推荐：

```python
dtype = DataTypeValue("float")
```

虽然 `DataTypeValue("float") == DT.float` 为真，但它不是同一个单例对象，所以基于对象身份的分支可能不会按你预期工作。

实践规则：

- 一律使用预定义的 `DT.*` 或 `Datatype.*`
- 正常 kernel 编写时，不要手工构造新的 `DataTypeValue(...)`

## 4. `DataTypeValue`

### `DataTypeValue(name)`

- 作用：表示一个具体 dtype 对象
- 构造参数：
  - `name`：后端 dtype 的拼写，例如 `"float"` 或 `"int8_t"`

通常不需要直接实例化这个类。框架已经通过 `DT` 提供了标准实例。

### `__str__()` 和 `__repr__()`

- `str(dtype)` 返回后端拼写
- `repr(dtype)` 返回 `DataTypeValue('...')`

示例：

```python
str(DT.float)    # "float"
str(DT.e5m2)     # "float8_e5m2_t"
repr(DT.uint16)  # "DataTypeValue('uint16_t')"
```

这也是为什么生成代码、报错和调试输出里，经常会直接看到 `half`、`int8_t`、`float8_e4m3_t` 这些名字。

### 相等性与哈希

- `DataTypeValue` 是可哈希的
- 相等性按 dtype 名称比较
- 如果拿它和非 `DataTypeValue` 对象比较，会抛 `TypeError`

示例：

```python
DT.float == DT.float
DT.int8 == DT.int8
```

但：

```python
DT.float == "float"   # raises TypeError
```

这比 Python 的 enum 或字符串更严格。检查 dtype 时，应当和另一个 dtype 对象比较，而不是和字符串比较。

### `.size`

- 作用：返回每个元素占用的字节数
- 类型：整数属性

示例：

```python
DT.half.size == 2
DT.float.size == 4
DT.e4m3.size == 1
DT.uint64.size == 8
```

典型用途：

- 估算 tile 的字节大小
- 理解 `reinterpret` 或 micro `cast` 里的位宽比例
- 推导固定寄存器或内存块里能装下多少元素

### `.C0`

- 作用：返回框架中与该 dtype 对应的 `C0` 宽度
- 类型：整数属性

示例：

```python
DT.half.C0 == 16
DT.float.C0 == 8
DT.int8.C0 == 32
DT.uint64.C0 == 4
```

当数据搬运或布局逻辑需要某种 dtype 对应的硬件原生内层 block 宽度时，框架就会使用 `C0`。

常见含义包括：

- `half` / `bfloat16` 路径通常按 `16` 为一组思考
- `float` / `int` / `uint32` 路径通常按 `8` 为一组思考
- 8 位路径如 `int8`、`uint8`、`e4m3`、`e5m2`、`hif8`，通常按 `32` 为一组思考

### 不受支持的名称

如果你手工构造了一个框架不认识的 `DataTypeValue`，那么像 `.size` 或 `.C0` 这样的操作会抛出 `ValueError`。

这也是为什么应优先使用预定义的 `DT.*`，而不是自己拼一个 dtype 对象。

## 5. 实用示例

### Tensor、寄存器和标量声明

```python
ub = Tensor(DT.float, [M, N], Position.UB)
acc = Reg(DT.float)
idx = Reg(DT.uint16)
count = Var(0, DT.int)
```

### Reinterpret 与 Cast 的区别

```python
src_i32 = reinterpret(src_f32, DT.int)
dst_h <<= src_f.astype(DT.half)
```

第一个例子改变的是“同一段字节如何被解释”。第二个例子改变的是“数值类型如何通过 micro cast 逻辑真正转换”。

### 带 size 意识的心算

```python
tile_bytes = DT.half.C0 * DT.half.size   # 16 * 2 = 32 bytes
```

这种快速估算会反复出现在对 lane 分组、block stride 和打包比例的推理中。

## 6. 实用建议

- 在普通 kernel 代码里直接使用 `DT.*`。
- 把 `Datatype` 看作 `DT` 背后的底层实现命名空间。
- 预期构造函数报错和错误信息里会出现 `DataTypeValue` 这个名字。
- 当你关心字节数时，使用 `.size`。
- 当你关心 dtype 原生 block 宽度时，使用 `.C0`。
- 除非你正在扩展框架内部、并且明确知道所有需要学习这个新 dtype 的代码路径，否则不要手工构造 `DataTypeValue(...)`。
