# 存储位置

本页文档说明贯穿 `easyasc` 各处的本地内存位置对象。

这里有两个名字需要区分：

- `Position`：kernel 作者平时直接使用的公开命名空间
- `PositionType`：实际存储在 `Tensor`、`DBuff`、`TBuff`、`QBuff` 上的具体值对象

在普通 kernel 代码里，你几乎总是直接写 `Position.L1`、`Position.L0C`、`Position.UB` 或 `Position.BT`。

## 1. 概览

`Position` 描述的是一个本地张量或本地缓冲在片上的存储位置。

典型例子：

```python
l1 = Tensor(DT.half, [M, K], Position.L1)
l0c = DBuff(DT.float, [M, N], Position.L0C)
ub = TBuff(DT.float, [64, 64], Position.UB)
```

会用到 `Position` 的地方包括：

- `Tensor(dtype, shape, position=...)`
- `DBuff(dtype, shape, position=...)`
- `TBuff(dtype, shape, position=...)`
- `QBuff(dtype, shape, position=...)`

不会用 `Position` 的地方是：

- `GMTensor`

`GMTensor` 表示全局内存，因此它不接受 `PositionType`。如果你操作的是 GM 输入输出，请用 `GMTensor`，而不是去想象一个 `Position.GM`。

## 2. `Position`

### 它是什么

- `Position` 是由 `easyasc.a2` 与 A5 系列入口（`easyasc.a5`、
  `easyasc.a5pr`）导出的公开枚举风格命名空间
- 每个成员都是一个预定义的 `PositionType` 单例

可用成员如下：

| 公开名称 | 含义 | C++ 映射 | 常见角色 |
| --- | --- | --- | --- |
| `Position.L1` | 片上 L1 张量存储 | `TPosition::A1` | cube staging 与可转置的 L1 视图 |
| `Position.L0A` | cube 输入缓冲 A | `TPosition::A2` | matmul 左输入 staging |
| `Position.L0B` | cube 输入缓冲 B | `TPosition::B2` | matmul 右输入 staging |
| `Position.L0C` | cube 输出 / 累加缓冲 | `TPosition::CO1` | matmul 累加器或 cube 结果 tile |
| `Position.UB` | vec 或 micro 统一缓冲 | `TPosition::VECCALC` | vec 操作、micro 操作，以及 vec 侧 staging |
| `Position.BT` | bias-table / C2 缓冲 | `TPosition::C2` | 在 `mmad(..., bias=...)` 前存放 matmul bias |

### 为什么应优先使用 `Position.*`

- 它属于稳定的公开接口
- 它提供了框架其余部分期待的那组单例对象
- 当前很多内部检查是按对象身份判断，而不仅仅是按值比较

当前代码中的例子包括：

- `Tensor.T` 要求 `self.position is Position.L1`
- `@vf` 会拒绝那些 `position is not Position.UB` 的张量输入

因此安全写法是：

```python
pos = Position.UB
```

而下面这种写法不推荐：

```python
pos = PositionType("UB")
```

虽然 `PositionType("UB") == Position.UB` 为真，但它不是同一个单例对象，所以那些依赖对象身份的检查未必会如你所愿。

## 3. `PositionType`

### `PositionType(name)`

- 作用：表示一个具体的本地内存位置值
- 构造参数：
  - `name`：位置名称，例如 `"L1"` 或 `"UB"`

通常不需要直接实例化这个类。标准实例已经通过 `Position` 提供。

### `__str__()` 和 `__repr__()`

- `str(position)` 返回纯位置名
- `repr(position)` 返回 `PositionType('...')`

示例：

```python
str(Position.L0C)    # "L0C"
repr(Position.UB)    # "PositionType('UB')"
```

### 相等性

- 相等按位置名比较
- 和非 `PositionType` 对象比较会抛出 `TypeError`

示例：

```python
Position.L1 == Position.L1
```

但：

```python
Position.L1 == "L1"   # raises TypeError
```

### `.cpp`

- 作用：返回这个位置在后端 C++ 中对应的 `TPosition::*` 拼写
- 类型：字符串属性

示例：

```python
Position.L1.cpp == "TPosition::A1"
Position.L0A.cpp == "TPosition::A2"
Position.L0B.cpp == "TPosition::B2"
Position.L0C.cpp == "TPosition::CO1"
Position.UB.cpp == "TPosition::VECCALC"
Position.BT.cpp == "TPosition::C2"
```

parser lowering 与 codegen 最终就是靠这个属性来生成缓冲声明与本地张量操作的。

如果你手工构造了一个不受支持的 `PositionType`，那么 `.cpp` 会失败，因为不存在对应的映射。这也是为什么应优先使用预定义的 `Position.*`。

## 4. 各个位置的实际语义

### `Position.L1`

- 本地 L1 staging 空间
- 常作为 cube 数据搬运的源或目标
- 当前实现里，只有它支持 `Tensor.T`

示例：

```python
l1x = Tensor(DT.half, [128, K], Position.L1)
l1x_t = l1x.T
```

### `Position.L0A` 与 `Position.L0B`

- cube 输入位置
- 最常见的用途是作为 `mmad` 或 `matmul` 流程中的两个输入
- 一般由 L1 经过 cube 侧搬运进入

示例：

```python
l0a = Tensor(DT.half, [128, 128], Position.L0A)
l0b = Tensor(DT.half, [128, 128], Position.L0B)
```

### `Position.L0C`

- cube 累加或结果位置
- 常用于在写回或 vec 后处理之前暂存 float 累加结果或 cube 输出

示例：

```python
l0c = DBuff(DT.float, [128, 128], Position.L0C)
```

### `Position.UB`

- vec 侧与 micro 侧的主要工作空间
- 逐元素操作、gather/scatter、micro 寄存器装载/写回，以及 vec 后处理大多都发生在这里
- 当前 `@vf` micro helper 只接受 `Position.UB` 上的张量输入

示例：

```python
ub = Tensor(DT.float, [64, 64], Position.UB)
```

### `Position.BT`

- 用于 cube matmul bias 路径的 bias-table / `TPosition::C2` 存储
- A2/910B 与 A5 系列（`a5`/950、`a5pr`/950PR）都支持
- 总容量：A2 为 512 B，A5/A5PR 为 4 KB；自动 depth-2 shortcut buffer 在 A2
  使用两个 256 B slot，在 A5/A5PR 使用两个 2 KB slot
- 通常先用 `l1_to_bt(...)` 把一行连续的 L1 bias 搬进去，再在 init tile 上用
  `mmad(..., bias=bt)` 或 `mmad_mx(..., bias=bt)` 消费

示例：

```python
bt = DBuff(DT.float, [1, N], Position.BT)
```

## 5. 实际使用中，Position 什么时候重要

### 张量与缓冲构造函数

`Tensor`、`DBuff`、`TBuff`、`QBuff` 都会检查 `position` 是否为 `PositionType`。

示例：

```python
tmp = Tensor(DT.float, [32, 32], Position.UB)
stage = DBuff(DT.half, [128, K], Position.L1)
pipe_buf = TBuff(DT.float, [64, 64], Position.UB)
```

### 与位置强相关的 API 行为

有些 API 关心的不是 shape 或 dtype，而是“你到底放在了哪个位置”。

当前实现中的典型例子有：

- `Tensor.T` 只支持 `Position.L1`
- 很多 vec API 要求源和目标张量都在 `Position.UB`
- `@vf` micro module 只接受 `Position.UB` 上的 `Tensor`
- cube staging 流水通常是 `L1 -> L0A/L0B -> L0C`

### parser 与 codegen 层面的意义

位置还会直接影响本地张量在生成 C++ 时如何声明。

例如：

```python
Position.L1.cpp   -> TPosition::A1
Position.L0C.cpp  -> TPosition::CO1
Position.UB.cpp   -> TPosition::VECCALC
```

所以位置绝不是“无关紧要的元数据”，它会改变张量属于哪条流水、哪类本地内存域。

## 6. 实用建议

- 在普通 kernel 代码里统一使用预定义的 `Position.*`。
- 除非你在扩展框架内部，否则不要手工构造 `PositionType(...)`。
- vec 与 micro 的工作张量使用 `Position.UB`。
- cube staging 张量与需要转置的本地视图使用 `Position.L1`。
- 只有在你明确在搭 cube 流水时，才使用 `Position.L0A`、`Position.L0B`、`Position.L0C`。
- GM 输入输出请使用 `GMTensor`；本地位置命名空间里并不存在 `Position.GM`。
