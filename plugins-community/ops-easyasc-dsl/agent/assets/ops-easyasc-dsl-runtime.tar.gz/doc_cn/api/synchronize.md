# 同步

本页说明 `easyasc.a2` 与 A5 系列入口（`easyasc.a5`、`easyasc.a5pr`）
导出的显式同步原语：

- `CvMutex`
- `VcMutex`
- `cube_ready`、`vec_ready`、`wait_cube`、`wait_vec`
- `allcube_ready`、`allvec_ready`、`allcube_wait`、`allvec_wait`
- `intracore_allvec_ready`、`intracore_allvec_wait`
- `setflag`、`waitflag`
- `SEvent`
- `DEvent`
- `TEvent`
- `QEvent`

这里实际上有几类不同机制：

- `CvMutex` / `VcMutex`：cube 与 vec 两侧之间的 ownership 交接
- 原始的跨侧 / 全核 flag 操作：更底层的 cube/vec 与 collective 同步
- 同 core vec-lane barrier：同一个 core 内两个 vec lane 之间的 rendezvous
- 原始 pipe flag：基于 `(src, dst, event_id)` 的本地 pipe-to-pipe 同步
- `SEvent` / `DEvent` / `TEvent` / `QEvent`：单个执行实体内部一槽、两槽、三槽或四槽的本地 pipe-to-pipe 顺序约束

理解时先按这个区分来：

- 如果 ownership 在 cube 和 vec 之间流转，用 mutex
- 如果你想直接使用同一套 token 机制，但不想包成 mutex 对象，用原始跨侧 / 全核操作
- 如果只需要同一个 core 内两个 vec lane rendezvous，用 `intracore_allvec_ready/wait`
- 如果你想显式指定 pipe 到 pipe 的 flag，而不想定义事件对象，用 `setflag` / `waitflag`
- 如果你只需要像 `MTE2 -> V` 或 `V -> MTE3` 这类本地 pipe 之间的顺序约束，用 event

关于更高层的 mixed pipeline 讨论，请参考 [../04_mixed_pipeline_and_sync.md](../04_mixed_pipeline_and_sync.md)。

## 1. `CvMutex`

### `CvMutex(flag_id, depth=2, src_start_pipe=Pipe.S, dst_start_pipe=Pipe.S, src_end_pipe=Pipe.FIX, dst_end_pipe=None)`

- 作用：表示“cube 生产、vec 消费”的 ownership 握手。
- 典型使用场景：
  - cube 写出或发布一个 tile
  - vec 等待这个 tile
  - vec 处理完成后把槽位归还

### 参数

- `flag_id`：
  - 逻辑上的跨侧 flag id
  - 必须映射到硬件支持的 flag id
  - 当前 emitter 要求它是 `0..7` 范围内的整数
- `depth`：
  - 预期的逻辑槽位深度，最常见是 `2`，对应 ping-pong 双缓冲
  - 这个值会存到 mutex 对象里，也会记录到 kernel 元数据里
  - 会在 kernel **构建（build）** 阶段被消费：构建时会预先注入 `depth` 个初始许可信号（头部的 `cube_ready`/`vec_ready`，由匹配的尾部 `wait` 抽干）。这些会成为 simulator 跨侧计数信号量（`simulator/sync.py`）的初始额度，因此 `depth` 限制了生产者能领先多远，并且**会在 simulation 中被强制约束**——把它设得过小（相对于 workspace ring / lookahead）时，在 Python sim 里同样会出错（只要 shape 大到足以让 ring 回绕），并不只在硬件上才暴露。（sync *运行时* 没有一个字面叫 `depth` 的字段，它跟踪的是这些构建期许可所建立的额度。）
- `src_start_pipe`：
  - `lock()` 使用的 pipe
  - 默认值是 `Pipe.S`
- `dst_start_pipe`：
  - vec 侧 `wait()` 使用的 pipe
  - 默认值是 `Pipe.S`
- `src_end_pipe`：
  - cube 侧 `ready()` 使用的 pipe
  - 默认值是 `Pipe.FIX`
- `dst_end_pipe`：
  - vec 侧 `free()` 使用的 pipe
  - 如果传入 `None`，构造函数会按设备选择默认值：
    - `b*` 设备 -> `Pipe.MTE2`
    - 设备 `950` -> `Pipe.V`
    - 其他设备 -> `Pipe.MTE3`

### 注册与限制

- 如果对象创建时正处于一个激活的 kernel 中，它会被注册到 `active_kernel.crosscore_mutex`
- 一个 kernel 内不能注册两个拥有相同 `flag_id` 的 mutex 对象
- `CvMutex` 用于 cube/vec 跨侧 ownership；它既不是 `SEvent` / `DEvent` / `TEvent` / `QEvent` 那套机制，也不是 `auto_sync()` 处理同侧 staging 时使用的机制

### 方法

#### `lock()`

- 发射：`wait_vec(flag_id, src_start_pipe)`
- 角色：cube 侧 acquire
- 在 simulator 中的含义：
  - cube 会一直等待，直到所有 vec lane 都为这个 `flag_id` 发布过一个“归还 token”
  - 只有当所有 vec lane 都把这个槽位归还后，cube 才能再次复用它

#### `ready()`

- 发射：`cube_ready(flag_id, src_end_pipe)`
- 角色：cube 侧 publish
- 在 simulator 中的含义：
  - 一次调用会向每个 vec lane 都发布一个 token
  - 之后每个 vec lane 都可以独立消费自己那份被发布出来的 tile

#### `wait()`

- 发射：`wait_cube(flag_id, dst_start_pipe)`
- 角色：vec 侧 consume wait
- 在 simulator 中的含义：
  - 当前 vec lane 等待属于自己的一枚已发布 token
  - lane `0` 消费了，不代表 lane `1` 也一并消费了

#### `free()`

- 发射：`vec_ready(flag_id, dst_end_pipe)`
- 角色：vec 侧 release
- 在 simulator 中的含义：
  - 当前 vec lane 向 cube 归还一个 token
  - 在所有 vec lane 都归还前，cube 的 `lock()` 都不会通过

### 运行时机制

当前 simulator 会为每个模拟 core 维护一份共享的跨侧 token 状态：

- `cube_ready(flag_id)`：为每个 vec lane 的 `cube -> vec` token 各加 `1`
- `wait_cube(flag_id)`：只消费当前 vec lane 的一枚 `cube -> vec` token
- `vec_ready(flag_id)`：只给当前 vec lane 的 `vec -> cube` token 加 `1`
- `wait_vec(flag_id)`：只有当每个 vec lane 都至少拥有一枚 `vec -> cube` token 时才成功，并且会从每个 lane 各消费一枚

因此，`CvMutex` 的生命周期可以具体理解成：

1. cube `lock()`，等待所有 vec lane 告诉它“旧槽位已经空出来了”
2. cube 填充这个槽位
3. cube `ready()`，向所有 vec lane 广播“新数据到了”
4. 每个 vec lane 分别执行自己的 `wait()`
5. 每个 vec lane 处理这个槽位
6. 每个 vec lane 分别执行自己的 `free()`
7. 只有当所有 lane 都完成归还后，cube 才能再次 `lock()`

所以 `CvMutex` 的本质不是一个单纯的布尔 flag，而是一个 ownership 交接协议。

### 示例：cube 发布，vec 消费

```python
cv = CvMutex(
    0,
    depth=2,
    src_end_pipe=Pipe.FIX,
    dst_end_pipe=Pipe.V,
)

cv.lock()                 # cube waits until both vec sub-blocks have returned the slot
xbuf[cnt] <<= l0c[cnt]    # publish data into the shared handoff buffer
cv.ready()                # cube broadcasts one ready token to each vec lane

cv.wait()                 # current vec lane waits for its own ready token
simple_micro(xbuf[cnt], outbuf[cnt], ...)
cv.free()                 # this vec lane returns its token to cube
```

如果有两个 vec sub-block，那么 token 流如下：

- `cv.ready()` 之后：lane0 为 `1`，lane1 为 `1`
- lane0 调用 `cv.wait()` 之后：lane0 为 `0`，lane1 为 `1`
- lane1 调用 `cv.wait()` 之后：lane0 为 `0`，lane1 为 `0`
- lane0 调用 `cv.free()` 之后：cube 仍然不能重新获取，因为 lane1 还没归还
- lane1 调用 `cv.free()` 之后：cube 的 `lock()` 才能再次成功

### 示例：通过 `GMTensor` 绑定

`GMTensor.bind_cv_mutex()` 只是对同一个对象的便利封装：

```python
z.bind_cv_mutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

z.lock()
z <<= ub_tile
z.ready()

z.wait()
z.free()
```

`GMTensor` 上的这些方法会直接转发给绑定好的 mutex。关于 tensor 侧 API，请见 [tensor_buffer.md](tensor_buffer.md)。

## 2. `VcMutex`

### `VcMutex(flag_id, depth=2, src_start_pipe=Pipe.S, dst_start_pipe=Pipe.S, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)`

- 作用：表示“vec 生产、cube 消费”的 ownership 握手。
- 典型使用场景：
  - vec 先准备或重排一个 tile
  - cube 等待这个 tile
  - cube 消费完成后再归还这个槽位

它和 `CvMutex` 刚好是反向关系。

### 参数

- `flag_id`：
  - 逻辑上的跨侧 flag id
  - 当前 emitter 要求在 `0..7` 范围内
- `depth`：
  - 预期的逻辑槽位深度，通常与你的 `DBuff` / `TBuff` 槽位数一致
  - 与 `CvMutex.depth` 一样会被 kernel 构建消费（头部 `ready` 额度，由尾部 `wait` 抽干）：它设定跨侧计数信号量的初始额度，并且**会在 simulation 中被强制约束**。参见上面 `CvMutex` 的 `depth` 说明。
- `src_start_pipe`：
  - vec 侧 `lock()` 使用的 pipe
  - 默认 `Pipe.S`
- `dst_start_pipe`：
  - cube 侧 `wait()` 使用的 pipe
  - 默认 `Pipe.S`
- `src_end_pipe`：
  - vec 侧 `ready()` 使用的 pipe
  - 默认 `Pipe.MTE3`
- `dst_end_pipe`：
  - cube 侧 `free()` 使用的 pipe
  - 默认 `Pipe.FIX`

### 注册与限制

- kernel 内的注册规则与 `CvMutex` 相同
- 一个 kernel 内如果 `flag_id` 重复，会被拒绝

### 方法

#### `lock()`

- 发射：`wait_cube(flag_id, src_start_pipe)`
- 角色：vec 侧 acquire
- 在 simulator 中的含义：
  - 当前 vec lane 一直等待，直到 cube 把这个槽位归还给它

#### `ready()`

- 发射：`vec_ready(flag_id, src_end_pipe)`
- 角色：vec 侧 publish
- 在 simulator 中的含义：
  - 当前 vec lane 向 cube 发布一枚 token

#### `wait()`

- 发射：`wait_vec(flag_id, dst_start_pipe)`
- 角色：cube 侧 consume wait
- 在 simulator 中的含义：
  - cube 会等待，直到每个 vec lane 都各自发布了一枚 token
  - 然后 cube 会一次性从每个 lane 各消费一枚

#### `free()`

- 发射：`cube_ready(flag_id, dst_end_pipe)`
- 角色：cube 侧 release
- 在 simulator 中的含义：
  - cube 向所有 vec lane 广播一枚归还 token

### 运行时机制

`VcMutex` 和 `CvMutex` 使用的是同一套跨侧 token 存储，只是方向正好相反：

1. 每个 vec lane `lock()`，等待 cube 归还一个可复用槽位
2. 每个 vec lane 各自填充或发布自己的那一部分
3. 每个 vec lane 调用 `ready()`
4. cube `wait()`，直到所有 lane 都已发布完成
5. cube 消费整个 tile
6. cube `free()`，向每个 vec lane 广播归还 token

因此，当 cube 必须等待所有 vec sub-block 都完成各自工作后才能继续时，`VcMutex` 就是最合适的工具。

### 示例：vec 预处理，cube 消费

```python
vc = VcMutex(
    1,
    depth=2,
    src_end_pipe=Pipe.MTE3,
    dst_end_pipe=Pipe.FIX,
)

vc.lock()                        # each vec lane waits for cube to return a slot
preprocess_micro(ub_in, ub_tmp)  # vec work
ub_to_l1_nd2nz(l1_tile, ub_tmp, valid_m, valid_k, tile_k, l1_rows)
vc.ready()                       # each vec lane publishes its completion token

vc.wait()                        # cube waits until every vec lane is ready
matmul(l0c, l1a_tile, l1b_tile)
vc.free()                        # cube returns the slot to every vec lane
```

## 3. 跨侧与全核同步

这些 API 是 mutex 封装背后所依赖的底层同步指令。

可以把它们分成两层来理解：

- 本仓库里所谓 cross-core，在命名上其实更接近“同一个模拟 core 内，cube 与 vec 两侧之间”的同步
- all-core 则表示某一类参与者整体上的 collective 同步
- intracore all-vec 表示同一个模拟 core 内两个 vec lane 之间的 barrier

这个命名一开始容易让人误解，因为 `cube_ready` / `wait_cube` 并不是在同步不同的物理 cube core。它们同步的是共享同一个 `flag_id` 的 cube 与 vec 参与方。

### 共享参数规则

这些 helper 具有相同的两个参数：

- `flag_id`：
  - 逻辑 token 命名空间
  - 必须是 `0..7` 范围内的整数
  - 超出范围时，helper 会在发射指令前直接拒绝
- `pipe`：
  - token 的 ready 或 wait 附着在哪个 pipe 上
  - 必须是 `PipeType`

设备侧校验规则：

- b-series wait API 只接受 `Pipe.S`：`wait_cube`、`wait_vec`、
  `allcube_wait`、`allvec_wait` 和 `intracore_allvec_wait`
- A5 系列/C310 set/ready API 必须挂在真实 pipe queue 上，不能用 `Pipe.S` 或
  `Pipe.ALL`
- A5 系列/C310 cube 侧 set/ready API（`cube_ready`、`allcube_ready`，以及 mutex
  里 cube-end pipe）还会拒绝 `Pipe.MTE3`
- A5 系列/C310 vec 侧 set/ready API（`vec_ready`、`allvec_ready` 和
  `intracore_allvec_ready`）可以使用 `Pipe.MTE3`
- A5 系列/C310 wait API 仍然可以使用 `Pipe.S`

这里 `pipe` 的含义是：

- 在 `*_ready` 上，它标识发布 token 的生产者 pipe
- 在 `*_wait` 上，它标识阻塞等待 token 的消费者 pipe，或主调度循环

如果 `pipe is Pipe.S`，simulator 会在主调度循环中直接执行这个 wait/ready；否则它会把指令分发到对应的 pipe 队列中。

### 3.1 跨侧单 core token 操作

下面四个 helper 都作用在一个模拟 core 的共享 `CrossCoreSyncState` 上。

simulator 内部维护两张以 `(flag_id, vec_lane)` 为键的 token 表：

- `cube -> vec`
- `vec -> cube`

这也是 `CvMutex` 与 `VcMutex` 所使用的底层机制。

#### `cube_ready(flag_id=0, pipe=Pipe.FIX)`

- 作用：为给定 `flag_id` 向所有 vec lane 各发布一枚 cube-to-vec token。
- 发射：`cube_ready`
- simulator 效果：
  - 对每个 vec lane，都执行一次 `cube_to_vec[(flag_id, lane)] += 1`
- 典型使用场景：
  - cube 已经完成一个共享 tile 的生产
  - 现在每个 vec lane 都可以去消费自己对这个 tile 的视图

示例：

```python
cube_ready(flag_id=0, pipe=Pipe.FIX)
```

#### `wait_cube(flag_id=0, pipe=Pipe.S)`

- 作用：让当前 vec lane 阻塞，直到 cube 为这个 lane 发布了一枚 token。
- 发射：`wait_cube`
- simulator 效果：
  - 检查 `cube_to_vec[(flag_id, current_lane)]`
  - 如果可用，就只消费当前 vec lane 的一枚 token
  - lane `0` 和 lane `1` 各自独立等待
- 理解方式：
  - 这是按 lane 独立消费的 wait，不是 vec 全体一起过的 collective wait

示例：

```python
wait_cube(flag_id=0, pipe=Pipe.S)
```

#### `vec_ready(flag_id=0, pipe=Pipe.MTE3)`

- 作用：由当前 vec lane 向 cube 发布一枚 vec-to-cube 的归还 token。
- 发射：`vec_ready`
- simulator 效果：
  - 执行 `vec_to_cube[(flag_id, current_lane)] += 1`
- 典型使用场景：
  - 当前 vec lane 已经完成自己那一部分的消费或生产
  - 但 cube 必须等所有 lane 都发布完成后才能继续

示例：

```python
vec_ready(flag_id=0, pipe=Pipe.MTE3)
```

#### `wait_vec(flag_id=0, pipe=Pipe.S)`

- 作用：让 cube 一直阻塞，直到每个 vec lane 都为这个 `flag_id` 发布过一枚 token。
- 发射：`wait_vec`
- simulator 效果：
  - 检查对每个 vec lane 是否都满足 `vec_to_cube[(flag_id, lane)] > 0`
  - 如果满足，就从每个 lane 一起消费一枚 token
- 理解方式：
  - `wait_vec` 是同一 core 内对各 vec lane 的一次汇聚式等待
  - 只要有任一 vec lane 尚未完成，cube 都不能继续

示例：

```python
wait_vec(flag_id=0, pipe=Pipe.S)
```

### 3.2 同 core vec-lane barrier

当同一个 core 上两个 vec lane 必须 rendezvous，且没有 cube 侧参与者时，使用
`intracore_allvec_ready(flag_id=0, pipe=Pipe.MTE3)` 和
`intracore_allvec_wait(flag_id=0, pipe=Pipe.S)`。

典型场景：

- lane 0 要读取完整的 staging row / matrix，而这份数据的两半分别由 lane 0
  和 lane 1 产生；
- 一个 vec lane 必须先读完临时 GM slot，另一个 lane 才能覆盖自己的那一半；
- 同一个 GM slot 先承载 intermediate，后面又被复用成 final output。

不要用 `vec_ready/wait_vec` 干这个事。`vec_ready/wait_vec` 是 vec→cube
token：vec 侧发布，cube 侧汇聚等待。它不是 lane-to-lane signal。

对复用的 GM slot，要把 read-done 和 final-overwrite 当成两个不同生命周期点。
“临时值已经读完”的 barrier 保护旧值；后面“final output 写出已经 drain”的
barrier 保护下一个 tile 不会看到延迟写或覆盖仍然 live 的流量。

### 跨侧 token 的生命周期

以一个拥有两个 vec lane 的模拟 core 为例：

1. cube 调用 `cube_ready(3)`
2. simulator 执行：
   - lane0 的 `cube_to_vec[(3, 0)] += 1`
   - lane1 的 `cube_to_vec[(3, 1)] += 1`
3. vec lane0 调用 `wait_cube(3)`，只消费自己的 token
4. vec lane1 调用 `wait_cube(3)`，也只消费自己的 token
5. 各 vec lane 之后各自调用 `vec_ready(3)`
6. cube 调用 `wait_vec(3)`，只有当 lane0 和 lane1 都已经贡献归还 token 时才成功

所以这组原始 API 天生就是非对称的：

- `cube_ready` 向所有 vec lane 广播
- `wait_cube` 由各 vec lane 分别消费
- `vec_ready` 由各 vec lane 分别发布
- `wait_vec` 由 cube 从所有 vec lane 汇聚式等待

正是这种非对称设计，才让 `CvMutex` 和 `VcMutex` 得以成立。

### 示例：不使用 `CvMutex`，手工完成一次 cube -> vec 交接

```python
cube_ready(flag_id=2, pipe=Pipe.FIX)
wait_cube(flag_id=2, pipe=Pipe.S)

# vec-side work happens here

vec_ready(flag_id=2, pipe=Pipe.V)
wait_vec(flag_id=2, pipe=Pipe.S)
```

这比 `CvMutex` 更底层：

- 交接协议需要你自己手动管理
- 没有 `lock()/ready()/wait()/free()` 这层命名帮助
- 也没有对象层面编码出来的 ownership 意图

当你需要直接控制时，用原始操作；当模式本身就是 ownership 交接时，用 `CvMutex` / `VcMutex` 往往更清晰。

### 3.3 全核 collective 操作

下面四个 helper 作用于 simulator 的共享 `AllCoreSyncState`。

它们并不是用一个全局布尔 flag 来实现，而是使用“按参与者分别计数”的 ready/wait 计数器，因此它们是带 phase 概念、可复用的 collective barrier。

参与者分别是：

- `allcube_*`：所有模拟 cube core，以 `core_idx` 为键
- `allvec_*`：所有模拟 vec 参与者，以全局 vec 索引为键

对 vec 来说，simulator 会计算：

- `global_vec_idx = core_id * 2 + sub_block_idx`

因此，`allvec_*` 表示的是“所有 core 上所有 vec lane”的 collective，而不仅是同一个 core 里的两个 lane。

#### `allcube_ready(flag_id=0, pipe=Pipe.FIX)`

- 作用：声明当前 cube core 已经到达 `flag_id` 对应 collective 的第 `k` 个 phase。
- 发射：`allcube_ready`
- simulator 效果：
  - `allcube_ready[(flag_id, core_idx)] += 1`

#### `allcube_wait(flag_id=0, pipe=Pipe.S)`

- 作用：让当前 cube core 阻塞，直到所有 cube core 都到达了相同的 collective phase。
- 发射：`allcube_wait`
- simulator 效果：
  - 读取当前本地 wait 计数 `phase = allcube_wait[(flag_id, core_idx)]`
  - 只有当每个 core 的 ready 计数都严格大于这个 `phase` 时，等待才会成功
  - 成功后，再把当前 core 的 wait 计数加一，表示它进入下一个 phase

因此，`allcube_wait` 的行为是一个可反复使用的 barrier，而不是一次性的 latch。

#### `allvec_ready(flag_id=0, pipe=Pipe.MTE3)`

- 作用：声明当前全局 vec 参与者已经到达 `flag_id` 对应 collective 的第 `k` 个 phase。
- 发射：`allvec_ready`
- simulator 效果：
  - `allvec_ready[(flag_id, global_vec_idx)] += 1`

#### `allvec_wait(flag_id=0, pipe=Pipe.S)`

- 作用：让当前全局 vec 参与者阻塞，直到所有 vec 参与者都到达同一 phase。
- 发射：`allvec_wait`
- simulator 效果：
  - 逻辑与 `allcube_wait` 相同，只不过作用范围是所有全局 vec 参与者

### 为什么全核 wait 是按 phase 计数的

假设有四个 cube core，每个 core 都执行：

```python
allcube_ready(flag_id=1)
allcube_wait(flag_id=1)
allcube_ready(flag_id=1)
allcube_wait(flag_id=1)
```

simulator 不会把前后两次 barrier 搞混。

对某个 core `i` 来说，第一次 `allcube_wait` 检查的是：每个 core 的 `ready_count` 是否都大于 `0`。  
第一次 wait 成功后，这个 core 会记录 `wait_count = 1`。  
第二次 `allcube_wait` 检查的就变成了：每个 core 的 `ready_count` 是否都大于 `1`。

也正因如此，在循环里重复使用同一个 `flag_id` 时，不必每一轮都换一个新的 `flag_id`。

### 示例：可复用的 all-cube barrier

```python
for stage in range(num_stage):
    # local cube work
    allcube_ready(flag_id=1, pipe=Pipe.FIX)
    allcube_wait(flag_id=1, pipe=Pipe.S)
```

含义是：

- 每个 core 都发布“我这一 stage 做完了”
- 只有当所有 core 都发布完同一 stage 后，任何 core 才能进入下一 stage

### 示例：可复用的 all-vec barrier

```python
allvec_ready(flag_id=4, pipe=Pipe.MTE3)
allvec_wait(flag_id=4, pipe=Pipe.S)
```

含义是：

- 每个全局 vec 参与者都必须发布一次 ready
- 只有这样，任何参与者才能通过本 phase 的 wait

### simulator 执行说明

- all-core 操作会触发 simulator 的并行执行模式，因为如果按严格串行的 per-core 顺序执行，collective wait 很容易死锁
- 如果有某个应当参与的 peer 永远没有发布 ready token，simulator 会为 `allcube_wait` 或 `allvec_wait` 抛出死锁错误
- 当 `pipe=Pipe.S` 时，等待在主循环执行；其他允许的 pipe 则进入对应 pipe 队列
- 当外层 kernel 使用 `@kernel(mode="vec")` 时，`allvec_ready` /
  `allvec_wait` 会被拒绝。这个模式会生成 `KERNEL_TYPE_AIV_ONLY`，它不是
  A2 cross-core collective 的有效 task declaration。请使用 `@kernel(mode="mix")`；
  A2 的 1:2 task ratio 会让每个 core 的两个 vec lane 都保持常驻。这个限制
  不适用于同一 core 内的 `intracore_allvec_ready/wait`

### 与 mutex 和 event 的关系

- 原始跨侧操作与 `CvMutex` / `VcMutex` 使用的是同一套跨侧 token 存储
- all-core 操作则是另一套独立的 collective 机制，不由 mutex 类封装
- `SEvent` / `DEvent` / `TEvent` / `QEvent` 属于本地、按执行实体隔离的 pipe 顺序原语，不参与这些全局 token 存储

## 4. Flag Helper

`setflag` 和 `waitflag` 是 DSL 中最底层的一对显式本地同步 helper。

与 `cube_ready` / `wait_vec` 不同：

- 它们不负责 cube 与 vec 两侧之间的同步
- 它们不使用跨侧 token 存储
- 它们只在同一个执行实体内部，让一个本地 source pipe 与一个本地 destination pipe 之间建立同步

在生成代码时，它们会直接 lower 到：

- `SetFlag<src, dst>(event_id)`
- `WaitFlag<src, dst>(event_id)`

因此，如果你想显式指定 pipe 对，而不是创建 `SEvent` / `DEvent` / `TEvent` / `QEvent` 对象，那么它们就是最原始的形式。

### `setflag(src, dst, event_id)`

- 作用：从 `src` 向 `dst` 发布一枚本地 pipe flag。
- 参数：
  - `src`：源 `PipeType`
  - `dst`：目标 `PipeType`
  - `event_id`：`int` 或 `Var`
- 校验规则：
  - `src` 必须是 `PipeType`
  - `dst` 必须是 `PipeType`
  - `src` 不能是 `Pipe.S`
  - `src` 不能是 `Pipe.ALL`
  - `dst` 不能是 `Pipe.ALL`
  - `event_id` 必须在 `0..7` 范围内
- 指令发射：
  - 发射 `Instruction("setflag", src=..., dst=..., event_id=...)`
- simulator 效果：
  - 指令执行时，simulator 会在下面这个键下存储一枚布尔 token：

```python
("flag", str(src), str(dst), event_id)
```

  - 这枚 token 会被置为 `True`

### `waitflag(src, dst, event_id)`

- 作用：等待并消费一枚从 `src` 发往 `dst` 的本地 pipe flag。
- 参数：
  - 含义与校验规则和 `setflag` 完全相同
- 指令发射：
  - 发射 `Instruction("waitflag", src=..., dst=..., event_id=...)`
- simulator 效果：
  - 会等待直到下面这个键：

```python
("flag", str(src), str(dst), event_id)
```

  变为 `True`
  - wait 一旦成功，这枚 token 就会被消费回 `False`

### Token 模型

simulator 会把 pipe flag 当成“作用域在单个执行实体内部的一枚单 token latch”：

- 一个 cube core 实例有自己独立的本地 flag 存储
- 一个 vec sub-block 实例也有自己独立的本地 flag 存储

这意味着：

- cube 侧 `setflag` 只能和 cube 侧 `waitflag` 对话
- vec 侧 `setflag` 只能和 vec 侧 `waitflag` 对话
- 它们不能替代跨侧 ownership 同步

核心理解方式是：

- `src` 表示未来会发布这个 flag 的生产者 pipe
- `dst` 表示等待这个 flag 的消费者 pipe，或主循环
- `event_id` 用来区分同一对 source/destination 之间的多条独立 flag 流

### source 与 destination 的限制

为什么 `src` 不能是 `Pipe.S`：

- `Pipe.S` 代表主调度循环，不是一个真正的生产者 pipe 队列
- simulator 与 codegen 只支持由“具体生产者 pipe”发起 `setflag`

为什么 `Pipe.ALL` 会被拒绝：

- `Pipe.ALL` 表示 barrier 语义，不是一个合法的 flag 端点
- “来自所有 pipe”或“发往所有 pipe”不存在一枚有意义的单 flag token

为什么 `dst` 可以是 `Pipe.S`：

- 当在 `Pipe.S` 上等待时，表示主循环自己阻塞，直到源 pipe 发布 token
- 这在后续调度决策不能抢跑生产者 pipe 时很有用

### 两种执行模式

`waitflag` 会根据 `dst` 是否为 `Pipe.S` 而表现不同。

#### 情况 1：`dst != Pipe.S`

- 这条指令会被派发到目标 pipe 的队列中
- 该 pipe 的执行循环会在运行这个 wait 前检查 token
- 一旦 token 出现，wait 会消费掉它，然后 pipe 继续向前执行

这是最自然的“pipe A 给 pipe B 发信号”的路径。

#### 情况 2：`dst == Pipe.S`

- wait 不在 pipe 队列中运行，而是在主循环上执行
- 阻塞期间，主循环会不断尝试推进一条待执行的 pipe 指令，以期制造进展
- 如果始终没有任何指令能推进，而 token 也迟迟不出现，simulator 就会抛出死锁错误

也正因如此，下面这样的代码是可运行的：

```python
setflag(Pipe.V, Pipe.S, 1)
waitflag(Pipe.V, Pipe.S, 1)
```

即便代码表面上是顺序写下来的，`Pipe.V` 侧的生产动作仍能在主循环 wait 消费 token 之前得到执行机会。

### 示例：vec pipe 通知主循环

```python
setflag(Pipe.V, Pipe.S, 1)
waitflag(Pipe.V, Pipe.S, 1)
```

含义：

- `V` pipe 最终会向主循环发布事件 `1`
- 主循环在收到这枚 `V -> S` token 之前不会继续执行
- 这枚 token 一旦被消费就会清空，因此如果你再写一次 `waitflag(Pipe.V, Pipe.S, 1)`，前面必须先有新的 `setflag`

### 示例：cube pipe 通知主循环

```python
setflag(Pipe.M, Pipe.S, 3)
waitflag(Pipe.M, Pipe.S, 3)
```

这是 cube 侧的对等例子，simulator 测试中也覆盖了这种路径。

### 示例：pipe 到 pipe 的交接

```python
setflag(Pipe.MTE2, Pipe.V, 0)
waitflag(Pipe.MTE2, Pipe.V, 0)
```

含义：

- `MTE2` 发布一枚 token
- `V` 等待的正是这枚 token
- wait 消费后，这个 `event_id` 对应的通道会再次变为空

### 与 `SEvent` 的区别

`setflag` / `waitflag` 与 `SEvent` 解决的是同一类问题，但抽象层级不同。

`setflag` / `waitflag`：

- 直接以 `src`、`dst` 和 `event_id` 为键
- 不创建具名对象
- 当你想显式看见、或显式控制 pipe 对时更合适

`SEvent` / `DEvent` / `TEvent` / `QEvent`：

- 会创建可复用、可传递的具名对象
- 可以作为缓冲协议的一部分被组织和说明
- 对结构化的 ready/valid 逻辑来说，通常更容易读

一个实用经验是：

- 一次性的、非常显式的 pipe flag -> `setflag` / `waitflag`
- 可复用的同步协议 -> `SEvent` / `DEvent` / `TEvent` / `QEvent`

## 5. `SEvent`

### `SEvent(src_pipe, dst_pipe, preset=False, name="")`

- 作用：在两个 pipe 之间创建一个本地单事件。
- 典型使用场景：
  - 为同侧的生产 pipe 和消费 pipe 之间建立顺序
  - 手工为两个 pipeline stage 建模一枚 ready token

它和 `CvMutex` / `VcMutex` 不同：event 不是 cube/vec ownership 对象，而是一个以如下键值确定的本地 pipe-to-pipe 同步对象：

- `src_pipe`
- `dst_pipe`
- `name`

### 参数

- `src_pipe`：
  - 生产者 pipe
  - 必须是 `PipeType`
- `dst_pipe`：
  - 消费者 pipe
  - 必须是 `PipeType`
- `preset`：
  - 这个 event 是否在开始时就处于 signaled 状态
  - 当第一次消费者迭代应当直接通过时，这很有用
- `name`：
  - 可选的显式事件名
  - 如果留空，运行时会自动生成 `_tmp_sevent_*`

### 构造行为

- 会校验 `src_pipe`、`dst_pipe`、`preset` 和 `name`
- 如有需要，会自动分配唯一名称
- 发射 `create_sevent`
- 如果 `preset=True`，当前 simulator 会把这个 event 初始化为“已可用”

### 方法

#### `set()`

- 发射：`event_set`
- 含义：
  - 生产者向这个 event 发出一次 signal

#### `wait()`

- 发射：`event_wait`
- 含义：
  - 消费者等待，直到 event 被 signal
  - 当前 simulator 在 wait 成功后会立刻消费掉这个 signal

#### `setall()`

- 发射：`event_setall`
- backend 含义：
  - 对 `SEvent` 而言，这和 `set()` 等价
- 当前 simulator：
  - 也按与 `event_set` 相同的行为处理

#### `release()`

- 发射：`event_release`
- backend 含义：
  - `SEvent.release()` 会通过内部执行一次 `wait()` 来把未消费的 signal 排空
- 当前 simulator：
  - 直接把本地 token 清成 `False`

### 运行时机制

当前 simulator 会为每个执行实体维护一个本地布尔 token，键为：

```python
("event", str(src_pipe), str(dst_pipe), name)
```

行为如下：

- `create_sevent(..., preset=False)` -> token 初始为 `False`
- `create_sevent(..., preset=True)` -> token 初始为 `True`
- `set()` / `setall()` -> token 变成 `True`
- `wait()` -> 阻塞直到 token 为 `True`，然后把它消费回 `False`
- `release()` -> 强制把 token 设为 `False`

因此，simulator 会把 `SEvent` 当作一枚单 token latch 来处理。

### 示例：手工实现 `MTE2 -> V` 交接

```python
ready = SEvent(Pipe.MTE2, Pipe.V, name="ub_ready")

gm_to_ub_pad(ub_tile, x[m:m + blk_m, k:k + blk_k], ...)
ready.set()           # issued on the producer side

ready.wait()          # the V pipe blocks until the MTE2-side set arrives
add(ub_out, ub_tile, 1.0)
```

虽然代码表面是顺序写的，但之所以成立，是因为：

- `gm_to_ub_pad(...)` 和 `ready.set()` 都会 lower 到生产者 pipe 序列上
- `ready.wait()` 会 lower 到消费者 pipe 序列上
- event 会阻止消费者 pipe 抢跑到生产者 pipe 前面

### 示例：单 buffer 的 ready/valid 对

```python
valid = SEvent(Pipe.MTE2, Pipe.V, preset=False, name="ub_valid")
ready = SEvent(Pipe.V, Pipe.MTE2, preset=True, name="ub_ready")

for tile in range(tile_num):
    ready.wait()                             # MTE2 may reuse the buffer immediately on tile 0
    gm_to_ub_pad(ubuf, x[..., tile], ...)
    valid.set()                             # producer publishes fresh data

    valid.wait()                            # V waits for fresh data
    add(ubout, ubuf, 1.0)
    ready.set()                             # consumer returns the one shared buffer
```

为什么 `preset=True` 放在 `ready` 上：

- 在第一次迭代开始前，这个单共享 buffer 本来就是可复用的
- 之后的每轮迭代都必须等待前一个消费者把它归还

## 6. `DEvent`

### `DEvent(src_pipe, dst_pipe, preset=False, name="")`

- 作用：创建一个带双内部 event id 的本地事件。
- 典型使用场景：
  - 双缓冲、ping-pong 风格的 pipe 同步
  - 生产者与消费者在两个逻辑 phase 之间交替推进的循环

它对外暴露的 Python API 与 `SEvent` 相同，但 backend 对象并不一样。

### 参数

- 参数含义与 `SEvent` 完全一致

### 构造行为

- 校验各项参数
- 如有需要，自动生成唯一名称
- 发射 `create_devent`
- 如果 `preset=True`，当前 simulator 会把这个 event 初始化为可用

### backend 机制

在生成后的 backend helper 类中：

- `DEvent` 会分配两个内部 event id
- `set()` 会在 `id1` 与 `id2` 之间交替写入
- `wait()` 也会在 `id1` 与 `id2` 之间交替等待
- `setall()` 会连续做两次 `set()`，因此两个内部 id 都会变成可用
- `release()` 会通过不断发起匹配的 `wait()` 把尚未平衡的 `set()` 全部排空

这种交替行为，就是 `DEvent` 特别适合双缓冲 staging 的原因。

### 当前 simulator 行为

simulator 会分配两个 flag 槽，并用独立的 FIFO set/wait 计数器在两槽间轮转。
因此，如果中间没有 `wait()`，第三次 `set()` 会触发 already-set 错误，与 backend
最多允许两个 outstanding credit 的行为一致。`preset=True`、`setall()` 和
`release()` 都会覆盖两个槽。

### 示例：DBuff 风格的 ready/valid 对

```python
valid = DEvent(Pipe.MTE2, Pipe.V, preset=False, name="dbuf_valid")
ready = DEvent(Pipe.V, Pipe.MTE2, preset=True, name="dbuf_ready")

for cnt in range(2):
    ready.wait()                              # wait for slot cnt to become reusable
    gm_to_ub_pad(ubuf[cnt], x[..., cnt], ...)
    valid.set()                              # publish slot cnt

    valid.wait()                             # consume slot cnt on the V side
    add(ubout[cnt], ubuf[cnt], 1.0)
    ready.set()                              # return slot cnt
```

backend 期望的理解方式是：

- 槽位 `0` 使用内部事件 `id1`
- 槽位 `1` 使用内部事件 `id2`
- 下一轮循环又回到 `id1`

生成后的 backend 与 simulator 都会强制这个槽位顺序。

## 7. `TEvent`

### `TEvent(src_pipe, dst_pipe, preset=False, name="")`

- 作用：创建一个在三个内部 event id 之间轮转的三槽本地事件。
- 典型使用场景：
  - 生产者最多可以提前发布三个 FIFO 有序结果
  - 三个物理 buffer 槽，或经过证明的三深度 pipeline 交接

参数和方法与 `DEvent` 相同。构造函数发射 `create_tevent`；`set()` / `wait()`
在三个 id 之间轮转；`setall()` 预置三槽；`release()` 排空所有 outstanding set。
simulator 使用相同的三槽 FIFO 模型，并按三个 id 计入该有向 pipe pair 的八-id
预算。

只有当存储生命周期和调度确实允许三个 outstanding token 时才使用 `TEvent`。
增加 credit 深度并不能让同一个物理目标安全地接受三个并发写入。

### `QEvent(src_pipe, dst_pipe, preset=False, name="")`

`QEvent` 是 `TEvent` 的四槽版本。构造函数发射 `create_qevent`；`set()` / `wait()`
在四个硬件 event id 之间轮转；`setall()` 预置四槽；`release()` 排空所有
outstanding set。simulator 强制相同的 FIFO 顺序，并按四个 id 计入该有向 pipe pair
的八-id 预算。

只有 trace 或精确生命周期失败证明可以安全存在四个 outstanding result 时才使用
`QEvent`。四个同步 credit 不会凭空创建四个物理目标，也不能让别名目标变安全。

## 8. 与 `auto_sync()` 的关系

`auto_sync()` 不使用 `CvMutex` 或 `VcMutex`。

它插入的是本地 event：

- 单 buffer 路径使用 `SEvent`
- 多 buffer 路径使用 `DEvent`

它通常会为每个 buffer 家族创建两条事件流：

- `*_valid_*`
- `*_ready_*`

这也是为什么在 lowering 后的 IR 与 trace 里，经常会看到如下名称：

- `_tmp_sevent_valid_...`
- `_tmp_sevent_ready_...`
- `_tmp_devent_valid_...`
- `_tmp_devent_ready_...`

实用上的判断规则是：

- 同侧 pipe staging -> 优先考虑 `auto_sync()` 或显式 event
- cube/vec 跨侧 ownership -> 使用 `CvMutex` 或 `VcMutex`

## 9. 如何选择合适的同步原语

在下面这些场景下使用 `CvMutex`：

- cube 是生产者
- vec 是消费者
- 每个 vec lane 都需要独立确认槽位归还

在下面这些场景下使用 `VcMutex`：

- vec 是生产者
- cube 是消费者
- cube 必须等所有 vec lane 都完成后才能继续

在下面这些场景下使用 `SEvent`：

- 你只需要两个本地 pipe 之间的一枚 ready token
- 单 phase 握手已经足够

在下面这些场景下使用 `DEvent`：

- 同一条本地同步边天然会在两个 phase 间交替
- 你的调度模型本来就是 ping-pong、DBuff 或 TBuff 风格

在下面这些场景下使用 `TEvent`：

- 同一条本地同步边有且只有三个 FIFO 有序的物理或逻辑槽
- trace 或生命周期分析证明生产者可能提前三个结果

在下面这些场景下使用 `QEvent`：

- 同一条本地同步边有且只有四个 FIFO 有序的物理或逻辑槽
- trace 或生命周期分析证明生产者可能提前四个结果

在下面这些场景下使用原始跨侧操作：

- 你想直接控制 `cube_ready` / `wait_cube` / `vec_ready` / `wait_vec`
- 这个模式本身并不适合包装成 mutex 对象

在下面这些场景下使用 all-core 操作：

- 所有 cube core，或所有全局 vec 参与者，都必须在继续前会合
- 你需要一个按 `flag_id` 复用的 collective barrier

在下面这些场景下使用 `setflag` / `waitflag`：

- 你想要一个以 `src`、`dst` 和 `event_id` 明确建模的本地 flag
- 你不需要一个具名的 `SEvent` / `DEvent` / `TEvent` / `QEvent` 对象
- 你需要 `dst=Pipe.S` 这种主循环等待形式

## 10. 常见坑

- 不要试图用 `SEvent` / `DEvent` / `TEvent` / `QEvent` 替代跨侧 ownership。event 是本地 pipe 顺序工具，不是 cube/vec ownership 工具。
- 不要把 `cube_ready` / `wait_cube` 理解成“cube 等 cube”。这些 API 是按两侧命名的，不是按同侧命名的：`cube_ready` 表示由 cube 发布，`wait_cube` 表示由 vec 等待 cube。
- 不要把 `allcube_*` 理解成 `cube_ready` / `wait_vec` 的外层封装。它们使用的是一套独立的 collective 计数模型。
- 不要把 `setflag` / `waitflag` 和跨侧同步混为一谈。它们使用本地 flag 存储，而不是跨侧 token 存储。
- 不要把 `Pipe.S` 用作 `setflag` 的 source。API 会拒绝，因为 `S` 是调度循环，不是生产者 pipe。
- 不要在 `setflag` / `waitflag` 中使用 `Pipe.ALL`。`Pipe.ALL` 只对 barrier 风格操作有意义。
- 不要把 `depth` 误读成 simulator 会忽略的、纯描述性的元数据。kernel 构建会把 `depth` 变成跨侧的初始许可额度，simulator 会以计数信号量的方式强制执行它们——`depth` 设得过小时，会在 ring 回绕的 shape 下于 Python sim 里复现，而不只在硬件上。（运行时缺少的只是一个字面叫 `depth` 的字段，它建立起来的额度是活跃生效的。）
- 不要仅为了避免较浅 event 满槽就选择 `TEvent` 或 `QEvent`；每个新增 credit 都必须对应安全的物理或逻辑槽生命周期。
- 当 `flag_id` 冲突时，kernel 构建会尽早失败，因为重复的跨侧 mutex id 在注册时就会被拒绝。
