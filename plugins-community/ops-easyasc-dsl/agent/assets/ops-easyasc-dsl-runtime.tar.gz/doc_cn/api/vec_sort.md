# 共享 Vec 排序与归并辅助

本页文档说明由 `easyasc.a2` 与两个 A5 系列入口（`easyasc.a5`、
`easyasc.a5pr`）共同导出的 vec 侧排序辅助；它们使用 `A2_A5_DEVICES`
做设备校验。

下面的描述同时依据以下两部分：
- `easyasc/stub_functions/vec/sort.py` 中公开的 stub 接口
- `easyasc/simulator/pipe_vec.py` 中当前模拟器的行为

本页所有函数都有这些共同点：

- 在 vec 侧运行
- 要求使用 `UB` 张量
- 当前只支持 `float` 数据
- lowering 成 vec 侧调用，而不是 cube 侧调用
- 在模拟器里会对展平后的 1D 指针视图执行

最后一点很重要：即使你在 DSL 中写的是 2D UB tensor，模拟器仍会把它对应的区域看成一条扁平流。

## 1. 共享数据模型

`sort32`、`mergesort4` 和 `mergesort_2seq` 都按“偶数 lane 存 value，奇数 lane 存 payload”的方式工作。

因此像下面这样的交错流：

```text
[value0, payload0, value1, payload1, value2, payload2, ...]
```

会被解释为：

- 偶数位置：排序 key
- 奇数位置：必须跟着对应 key 一起移动的 payload

模拟器总是会用和 value 相同的 `argsort` 下标去重排 payload。

一个重要后果是：
- 这些 helper 并不会把整个 tensor 当作普通标量流来处理
- 它们会把它看成嵌在同一条 `float32` 流里的 `(key, payload)` 对

对于 `sort32`，payload 来自一个独立的 `idx` tensor，并写入 `dst` 的奇数 lane。
对于 `mergesort4` 与 `mergesort_2seq`，payload 本来就嵌在源流的奇数 lane 中。

## 2. `sort32(dst, src, idx, repeat=None)`

- 作用：对每个 32 元素 value block 按降序排序，并把排序后的 value 与重排后的 index 交错写入输出。

参数含义：

- `dst`：目标 UB `Tensor`
- `src`：源 UB `Tensor`，每个 repeat 提供 32 个值
- `idx`：源 UB `Tensor`，为每个值提供一个索引 payload
- `repeat`：独立 32 元素块的个数

输入与输出布局：

- 每个 repeat 会读取：
  - `src` 里的 `32` 个 float 值
  - `idx` 里的 `32` 个整数风格索引值
- 每个 repeat 会写出：
  - `64` 个 float 元素到 `dst`
- 每个 repeat 的目标格式是：

```text
[sorted_value0, sorted_index0_bits_as_float,
 sorted_value1, sorted_index1_bits_as_float,
 ...,
 sorted_value31, sorted_index31_bits_as_float]
```

模拟器对单个 repeat 的处理过程：

1. 读取：
   - `src_block = src[rep * 32 : (rep + 1) * 32]`
   - `idx_block = idx[rep * 32 : (rep + 1) * 32]`
2. 排序 value：
   - `arg = torch.argsort(src_block, descending=True)`
   - `src_sorted = src_block[arg]`
3. 用相同置换重排索引：
   - `idx_sorted = idx_block[arg]`
4. 把索引 bit 重解释成 `float32`：
   - 模拟器会先确保它有兼容 `int32` 的视图
   - 再把 `idx_sorted.view(torch.float32)` 写到目标的奇数 lane
5. 最后交错写入 `dst`

这意味着，`dst` 不是“只有排序后的值”，而是一条交错的 `(value, index_bits)` 流。

如果要把索引再取回来：

```python
sorted_values = dst[0::2]
sorted_index_bits = dst.view(torch.int32)[1::2]
```

如果你的运行时支持 `torch.uint32`，也可以把同样这些奇数 lane 按 `uint32` 重解释回来。

默认推导规则：

- 如果省略 `repeat`，stub 会计算：
  - `repeat = CeilDiv(src.span[0] * src.span[1], 32)`

这里有个重要注意点：

- 这个推导使用向上整除（`CeilDiv`）
- 如果逻辑源 span 不是 32 的整数倍，最后一个 repeat 仍会覆盖剩余
  元素，它们不会被丢弃
- stub 不会额外做整除性检查

单个 repeat 的例子：

```text
src = [5, 1, 7, 2, ...]
idx = [0, 1, 2, 3, ...]

after descending sort:
values -> [7, 5, 2, 1, ...]
index  -> [2, 0, 3, 1, ...]

dst = [7, bits(2), 5, bits(0), 2, bits(3), 1, bits(1), ...]
```

相同 value 的 tie 行为：

- 模拟器把顺序交给 `torch.argsort(descending=True)`
- 如果两个 value 相等，它们的先后取决于当前 `torch.argsort` 的行为
- 模拟器不会额外叠加一层稳定排序规则

限制与检查：

- `src`、`dst`、`idx` 都必须是 UB tensor
- `src.dtype` 和 `dst.dtype` 都必须是 `float`
- 在 stub 层，`idx.dtype` 必须是 `uint32`
- 模拟器接受 `idx` 具有兼容 `int32` 的 tensor 视图
- 模拟器还要求：
  - `src` 大小至少有 `repeat * 32`
  - `idx` 大小至少有 `repeat * 32`
  - `dst` 大小至少有 `repeat * 64`

最简用法：

```python
sort32(sorted_pairs, values, indices)
```

## 3. `mergesort4(dst, src, length_per_seq, repeat)`

- 作用：把四段降序 key 序列做归并，并让奇数 lane 中的 payload 跟着相同置换一起移动。

参数含义：

- `dst`：目标 UB `Tensor`
- `src`：源 UB `Tensor`
- `length_per_seq`：四段降序 key 序列中每一段的逻辑长度
- `repeat`：独立 merge 组的个数

每个 repeat 的输入布局：

- 每个 repeat 的总元素数是：
  - `8 * length_per_seq`
- 去交错之后：
  - `even_val` 长度为 `4 * length_per_seq`
  - `odd_val` 长度为 `4 * length_per_seq`
- 模拟器把 `even_val` 解释成四段连续的降序 split：

```text
split 0 = even_val[0 : length_per_seq]
split 1 = even_val[length_per_seq : 2 * length_per_seq]
split 2 = even_val[2 * length_per_seq : 3 * length_per_seq]
split 3 = even_val[3 * length_per_seq : 4 * length_per_seq]
```

奇数 lane 只是 payload，不要求预排序。

模拟器对单个 repeat 的处理过程：

1. 读取一段长度为 `8 * length_per_seq` 的扁平 block
2. 去交错：
   - `even_val = block[0::2]`
   - `odd_val = block[1::2]`
3. 校验前提：
   - `even_val` 中这四段连续子序列都必须已经是降序
4. 计算：
   - `arg = torch.argsort(even_val, descending=True)`
5. 同时重排两条流：
   - `even_new = even_val[arg]`
   - `odd_new = odd_val[arg]`
6. 再把结果交错写回 `dst`

因此模拟器的行为是：

- 它不是逐步展开的树状 merge
- 而是先检查“四段降序 run”这个前提，再对所有 key 做一次整体降序重排

为什么“降序前提”很重要：

- 模拟器会显式拒绝那些某个 repeat 中四段 even-lane 子序列并非各自降序的输入
- 这体现的是 merge helper 的合约，而不是一个任意输入都能处理的通用排序器

当 `length_per_seq = 2` 时的例子：

```text
even_val before:
[90, 80, 75, 70, 60, 50, 40, 10]

interpreted as four descending runs:
[90, 80] | [75, 70] | [60, 50] | [40, 10]

odd_val before:
[a, b, c, d, e, f, g, h]

after argsort on even_val:
even_new = [90, 80, 75, 70, 60, 50, 40, 10]
odd_new  = [a, b, c, d, e, f, g, h]
```

如果四段 run 之间交错得更明显：

```text
even_val before:
[90, 30, 80, 20, 70, 10, 60, 0]

runs:
[90, 30] | [80, 20] | [70, 10] | [60, 0]

after merge:
[90, 80, 70, 60, 30, 20, 10, 0]
```

奇数 payload 也会按完全相同的方式一起重排。

tie 行为：

- 相同 key 的先后顺序遵循当前 `torch.argsort(descending=True)` 的行为
- 模拟器不会额外加上稳定排序规则

限制与检查：

- `src` 和 `dst` 都必须是 UB `float` tensor
- `length_per_seq` 必须为正
- `repeat` 必须非负
- 模拟器要求：
  - `src` 大小至少为 `repeat * 8 * length_per_seq`
  - `dst` 大小至少为 `repeat * 8 * length_per_seq`
- 对每个 repeat 而言，四段 even-lane 子序列都必须已经是降序

最简用法：

```python
mergesort4(dst, src, 32, 1)
```

## 4. `mergesort_2seq(dst, src1, src2, size1, size2)`

- 作用：把两段降序的交错 `(key, payload)` 流归并成一段降序交错输出流。

参数含义：

- `dst`：目标 UB `Tensor`
- `src1`：第一段源 UB `Tensor`
- `src2`：第二段源 UB `Tensor`
- `size1`：从 `src1` 消耗多少组 key/payload 对
- `size2`：从 `src2` 消耗多少组 key/payload 对

输入布局：

- `src1` 贡献 `2 * size1` 个 float 元素
- `src2` 贡献 `2 * size2` 个 float 元素
- 去交错之后：
  - `even_1 = src1[0::2]`
  - `odd_1 = src1[1::2]`
  - `even_2 = src2[0::2]`
  - `odd_2 = src2[1::2]`

前提：

- `even_1` 必须已经是降序
- `even_2` 也必须已经是降序

模拟器行为：

1. 从 `src1` 读取恰好 `2 * size1` 个元素，从 `src2` 读取恰好 `2 * size2` 个元素
2. 把两条流都去交错成 key 和 payload
3. 校验 `even_1` 与 `even_2` 都已经是降序
4. 拼接：
   - `even_cat = [even_1, even_2]`
   - `odd_cat = [odd_1, odd_2]`
5. 计算一次整体降序置换：
   - `arg = torch.argsort(even_cat, descending=True)`
6. 用 `arg` 同时重排拼接后的两条流
7. 再把归并结果交错写入 `dst`

和 `mergesort4` 一样，模拟器这里建模的是“先验证输入满足 merge 合约，再用整体降序重排构造最终输出”。

示例：

```text
src1 pairs: [(100, a), (90, b), (70, c), (20, d)]
src2 pairs: [(95, e), (80, f), (10, g)]

merged keys:
[100, 95, 90, 80, 70, 20, 10]

merged payload:
[a, e, b, f, c, d, g]

dst stream:
[100, a, 95, e, 90, b, 80, f, 70, c, 20, d, 10, g]
```

tie 行为：

- 相同 key 的顺序遵循当前 `torch.argsort(descending=True)` 在拼接后的 key 流上的行为
- 模拟器不保证额外的稳定 merge 规则

限制与检查：

- `dst`、`src1` 和 `src2` 都必须是 UB `float` tensor
- `size1` 和 `size2` 都必须为正
- 模拟器要求：
  - `src1` 大小至少为 `2 * size1`
  - `src2` 大小至少为 `2 * size2`
  - `dst` 大小至少为 `2 * (size1 + size2)`
- `even_1` 与 `even_2` 必须都已经是降序

最简用法：

```python
mergesort_2seq(dst, left_pairs, right_pairs, size1, size2)
```
