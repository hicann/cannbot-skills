# Var

本页文档说明 `Var`。它是整个 DSL 中通用的标量对象，用来表示维度、循环计数器、标量算术，以及张量和变量之间的标量 IO。

虽然在用户代码里，`Var` 往往看起来像普通 Python 标量，但它的大多数运算符都已经被重载，用来构建 DSL 指令，而不是执行单纯的宿主侧计算。

## 1. `Var`

### `Var(value=0, dtype=None, name="")`

- 作用：在 kernel 或 micro 代码中表示一个标量值。
- 常见用途：
  - `M`、`N`、`K` 这类形状变量
  - `cnt` 这类计数器
  - 基于循环推导出的偏移
  - 标量算术中间结果
  - 从 UB 或 GM 读出的标量
- 构造参数：
  - `value`：`int`、`float`、另一个 `Var`，或者 `None`
  - `dtype`：可选的 `DataTypeValue`
  - `name`：可选的变量名

### 构造时的推断规则

- 如果省略 `dtype`：
  - `int` 值 -> `DT.int`
  - `float` 值 -> `DT.float`
  - `Var` 值 -> 复用源 `Var.dtype`
  - `None` -> 保持 dtype 为 `None`
- 如果 `name=""`，运行时会自动创建一个临时名，例如 `_tmp_var_*`
- 如果 `value` 本身是另一个 `Var`：
  - 新对象会获得独立的 `idx` 和符号名
  - 如果省略 `dtype`，新对象会复用源 `Var.dtype`
  - 构造函数会复制源变量当前的 `value`
  - 在激活的 kernel 或 micro 上下文里，DSL 会发射一条从源 Var 到新 Var 的运行时赋值

### 指令发射

- 在激活的 `@kernel` 或 `@vf` 上下文里新建 `Var(...)`，会发射 `create_var`
- `Var(existing_var)` 会先为目标发射 `create_var`，再发射从源变量到目标变量的 `var_assign`。当目标只是表达式临时变量时，codegen 会尽量折叠这类临时 copy。

示例：

```python
cnt = Var(0)
scale = Var(3.0, DT.float, "scale")
```

## 2. 内部存储的状态

一个 `Var` 主要携带这些信息：

- `dtype`：标量 dtype，通常是 `DT.int` 或 `DT.float`
- `name`：DSL 符号名
- `value`：可选的、宿主侧已知的具体值，便于在模拟器友好的路径上做即时折叠
- `idx`：IR / 运行时内部使用的标识

实际含义是：

- 如果 `value` 已知，很多标量操作会立即算出 `out.value`
- 如果 `value` 未知，DSL 仍然会正常发射符号指令，只是把求值留到后面

## 3. 算术运算符

`Var` 会重载标量运算，并把大部分操作路由到 `easyasc.stub_functions.var_op` 中的辅助函数。

### `a * b`

- 实际调用 `var_mul(a, b)`
- 接受的操作数：
  - `Var`
  - `int`
  - `float`
- 结果 dtype：
  - 只要任一侧是 float-like，就得到 `DT.float`
  - 否则如果任一侧是 int-like，就得到 `DT.int`
- 常量折叠：
  - 如果两边的值都已知，就会立即计算 `out.value`
- 发射：
  - `var_mul`

示例：

```python
rows_per_core = tile_m * GetCubeNum()
```

### `a + b`

- 实际调用 `var_add(a, b)`
- 接受的操作数：
  - `Var`
  - `int`
  - `float`
- 结果 dtype：
  - float 优先于 int
- 常量折叠：
  - 两边值都已知时，会立即折叠
- 发射：
  - `var_add`

示例：

```python
begin = tile_m_per_core * GetCubeIdx() + 4
```

### `a - b`

- 实际调用 `var_sub(a, b)`
- 接受的操作数：
  - `Var`
  - `int`
  - `float`
- 结果 dtype：
  - float 优先于 int
- 常量折叠：
  - 两边值都已知时，会立即折叠
- 发射：
  - `var_sub`

### `a / b` 与 `a // b`

- 这两者都会路由到 `var_div(a, b)`
- 接受的操作数：
  - `Var`
  - `int`
  - `float`
- 类型提升：
  - 两个整数操作数保持原来的整数 dtype
  - 一侧为 `DT.float` 或 Python `float`、另一侧为整数类型时，结果为 `DT.float`
  - 生成的 C++ 会使用单精度字面量，并显式转换整数 `Var` 分母，因此 `1.0 / width` 会 lowering 为 `1.0f / (float) width`
- 结果行为：
  - 相同整数 dtype -> 向下取整式的整数除法
  - `DT.float` -> 浮点除法
- 常量折叠：
  - 只要两边值已知且除数非零，就会立即折叠
- 发射：
  - `var_div`

示例：

```python
tile_m = M // 128
ratio = scale / coeff
inv_width = 1.0 / width
```

### `a % b`

- 实际调用 `var_mod(a, b)`
- 接受的操作数：
  - `Var`
  - `int`
- 限制：
  - 两边都必须是整数风格
  - 如果值已知且除数为零，会直接报错
- 结果 dtype：
  - 总是 `DT.int`
- 常量折叠：
  - 两边值都已知时，会立即折叠
- 发射：
  - `var_mod`

示例：

```python
slot = cnt % 2
```

### `a += b`

- `Var` 实现了 `__iadd__`，但没有提供通用的 `-=`, `*=`, `/=`, `%=` 原地重载
- 接受的操作数：
  - `Var`
  - `int`
  - `float`
- 行为：
  - 保持 `self.dtype` 不变
  - 发射前会按 `self.dtype` 校验右侧操作数：
    - `DT.float` 只接受 Python `float` 或 `Var(dtype=DT.float)`
    - 整数类型 `Var` 接受 Python `int`
    - 整数类型 `Var` 只接受 dtype 完全相同的 `Var` 右值
  - 并以 `out=self` 的方式发射 `var_add`
- 重要说明：
  - 这仍然是 DSL 风格的标量变更，而不是普通 Python 原地算术

示例：

```python
cnt = Var(0)
cnt += 1
```

## 4. 赋值风格操作

### `var <<= other`

`Var.__ilshift__` 支持三类来源。

#### `var <<= other_var`（或 `int` / `float` 字面量）

- 作用：标量到标量赋值。
- 限制：
  - 源必须是 `Var`、`int` 或 `float`
- 行为：
  - 发射 `var_assign`
  - 目标对象本身会被复用

示例：

```python
dst <<= src
```

#### `var <<= tensor`

- 等价于 `var.GetValueFrom(tensor)`
- 支持的张量来源：
  - 位于 `Position.UB` 的 `Tensor`
  - `GMTensor`
- 限制：
  - 不支持在 `@vf` 中使用
  - 目标 `Var.dtype` 必须已经设定
- 行为：
  - 发射 `GetValueFrom`
  - 在模拟器中，会读取当前扁平化视图的第一个元素
  - 然后按 `dst.dtype` 做类型转换

示例：

```python
scalar <<= ub[0:1, 0:1]
```

### `var >>= tensor`

- 等价于 `var.SetValueTo(tensor)`
- 支持的目标：
  - 位于 `Position.UB` 的 `Tensor`
  - `GMTensor`
- 限制：
  - 不支持在 `@vf` 中使用
  - 如果目标是本地 `Tensor`，它必须位于 `Position.UB`
  - 源 `Var.dtype` 必须已经设定
- 行为：
  - 发射 `SetValueTo`
  - 在模拟器中，会解析 `Var` 当前的标量值
  - 把它写到目标视图扁平化后的第一个元素

示例：

```python
seed >>= ub
```

## 5. 显式标量 IO 方法

### `GetValueFrom(src)`

- 作用：把一个张量来源里的标量读到当前 `Var` 中。
- 参数：
  - `src`：`Tensor` 或 `GMTensor`
- 限制：
  - 不支持在 `@vf` 中使用
  - 目标 `Var.dtype` 不能是 `None`
  - 如果 `src` 是 `Tensor`，它必须位于 `Position.UB`
- 行为：
  - 发射 `GetValueFrom`
  - 清除目标 `Var` 在构造时留下的常量值提示；后续标量操作使用运行时张量读值，而不会错误地折叠构造初值
  - 原始初值仍会保留，用于生成 C++ 声明和模拟器初始化
  - 在模拟器中：
    - 读取 `src_view[0]`
    - 按 `dst.dtype` 做类型转换
    - 把转换后的结果保存为 `Var` 当前的运行时值
- 实际含义：
  - 这是从当前视图的第一个元素里抽取一个标量，而不是对整个张量做规约

示例：

```python
scalar = Var(0, DT.int)
scalar.GetValueFrom(ub)
```

GM 示例：

```python
scalar = Var(0, DT.int)
scalar.GetValueFrom(src_gm)
```

### `SetValueTo(dst_tensor)`

- 作用：把当前标量值写入某个 UB 张量视图或 `GMTensor`。
- 参数：
  - `dst_tensor`：`Tensor` 或 `GMTensor`
- 限制：
  - 不支持在 `@vf` 中使用
  - 如果目标是 `Tensor`，它必须位于 `Position.UB`
  - 源 `Var.dtype` 不能是 `None`
- 行为：
  - 发射 `SetValueTo`
  - 在模拟器中：
    - 解析当前标量运行时值
    - 按 `Var.dtype` 做转换
    - 把结果写入 `dst_tensor` 的第一个元素
- 实际含义：
  - 这是“标量 -> 第一 lane”的写回，通常和 `GetValueFrom` 配套使用

示例：

```python
seed = Var(3.75, DT.float)
seed.SetValueTo(ub)
```

GM 示例：

```python
seed = Var(3.75, DT.float)
seed.SetValueTo(dst_gm)
```

## 6. 比较运算符与 `Expr`

`Var` 上的比较运算不会产生 Python `bool`，而是产生 `Expr` 对象。

支持的操作符：

- `==`
- `!=`
- `<`
- `<=`
- `>`
- `>=`

示例：

```python
cond = (cnt < limit)
```

### `Expr` 是什么

- `Expr` 是一个轻量级的符号布尔表达式容器
- 它保存的是生成出来的表达式字符串，而不是一个具体的 Python 真值

### 重要限制

- `Expr` 不能用于普通 Python 布尔上下文
- 调用 `bool(expr)` 会抛出：
  - `TypeError("Expr cannot be used in Python boolean context, use If/Elif/Else instead")`

这也是为什么 kernel 控制流应该使用：

- `If(...)`、`Elif(...)`、`Else(...)`
- 或者在被装饰函数里直接写原生 Python `if/elif/else`，交给框架做 AST 改写

### `Expr` 的逻辑组合

- `expr_a & expr_b` -> 逻辑 `&&`
- `expr_a | expr_b` -> 逻辑 `||`
- `~expr` -> 逻辑 `!`

示例：

```python
cond = (cnt < end) & (tile_m != 0)
```

## 7. 数值折叠与符号执行

`Var` 混合了两种世界：

- 宿主侧已知的标量值，保存在 `value`
- 记录到激活 kernel 或 micro module 中的符号 IR 指令

这意味着一次 `Var` 运算可以同时做两件事：

1. 当输入值已知时，立刻算出具体的 `out.value`
2. 同时仍然发射诸如 `var_add` 或 `var_div` 这样的 DSL 指令

这种双重行为，也是为什么 `Var` 同时适合模拟器执行和符号代码生成。

## 8. `VarList`

### `VarList(dtype, length, name="")`

`VarList` 是一个固定长度的一维标量数组。它会下沉成一个 C++ 本地数组（`dtype name[length] = {};`），相当于 kernel 内部的 scratch 寄存器组。当你需要保留几个标量、而它们的下标本身是数据相关的（比如环形缓冲计数器、每次迭代的系数、注意力中间结果）时，就可以用 `VarList`。

- 构造参数：
  - `dtype`：一个 `DataTypeValue`，比如 `DT.int` 或 `DT.float`。元素 dtype 在数组生命周期内是固定的。
  - `length`：正的 Python `int`；数组长度是编译期常量。
  - `name`：可选的符号名。如果为空，会先生成一个 `_varlist_*` 占位名，AST 命名 pass 在条件允许时会把它替换成赋值目标名。
- 限制：
  - `length > 0`。
  - dtype 必须是普通的 `DataTypeValue`。不支持 `VarList(DT.int4, ...)`。
  - `length` 不能是 `Var` —— 数组长度必须是 Python int。
- 指令发射：
  - 在 `@kernel` 或 `@vf` 上下文里写 `VarList(...)` 会发射 `create_varlist`。
  - 模拟器会把每个槽位都初始化为零，对应 codegen 的 `dtype name[length] = {};`。

### 元素访问 —— `vals[idx]`

`vals[idx]` 返回一个 `VarRef`，行为上类似一个绑定到底层数组某个槽位的 `Var`。

- 索引类型：
  - Python `int`（必须落在 `[0, length)` 内）
  - `Var`（必须是整型）
  - 由 `Var` 算术得到的 `Expr`，比如 `vals[i + 1]`
- 读：`dst <<= vals[idx]` 会从槽位发射一条 `var_assign` 到 `dst`。
- 写：`vals[idx] <<= value` 会发射一条 `var_assign` 到这个槽位。后续 Python 的 `__setitem__` 故意是 no-op，因为复合赋值的写动作已经通过 `VarRef` 完成了。
- 槽位上的 in-place 算术也是允许的，比如 `vals[idx] += 1`，会发射一条 `var_add`，源和目的都是该槽位。

### 模拟器语义

- `create_varlist` 会按 varlist 名分配一块全零的数组。
- `VarRef` 会把结构化的 `(parent, index)` payload 一直传到运行时，所以模拟器是直接寻址实际槽位，而不是依赖文本 key 匹配。也就是说：
  - `vals[0] <<= 7; out <<= vals[i]` 在 `i == 0` 时返回 `7`（字面量索引和 `Var` 索引能互通）。
  - `vals[i + 1] <<= 22; out <<= vals[2]` 在 `i == 1` 时返回 `22`（索引算术也生效）。
  - 读一个从未写过的槽位会返回该 dtype 对应的零值（与 codegen 的 `arr[N] = {}` 一致）。
- 越界索引会在访问时刻抛 `IndexError`，对应 `VarList.__getitem__` 在 DSL 侧对字面整数索引的边界检查。

### codegen

- `VarList(DT.int, 4, name="arr")` 下沉为 `int arr[4] = {};`。
- `arr[idx] <<= 9` 下沉为 `arr[idx] = (int) 9;`。
- `dst <<= arr[idx]` 下沉为 `dst = (int) arr[idx];`。
- 剪枝：如果没有任何代码读取一个 `VarList` 的槽位，它会被从生成代码里删掉；只为这个被剪掉的数组喂数据的索引变量和写入也会一起被剪掉。

### 示例

```python
@kernel()
def varlist_example(dst: GMTensor, contract: Var):
    with cube_scope():
        history = VarList(DT.int, 4, name="history")
        idx = Var(0, DT.int, name="idx")
        history[idx] <<= 5
        history[idx + 1] <<= history[idx] * 2
        out = Var(0, DT.int, name="out")
        out <<= history[1]            # 模拟器和 codegen 下都是 10
        out.SetValueTo(dst)
    return dst
```

## 9. 使用说明

- 当你关心可读性时，为形状变量和循环控制变量显式指定 dtype，尤其是涉及除法和取模时。
- 计数器、循环索引和 tile 算术优先使用 `DT.int`。
- 会继续流入 float 计算的标量数学，优先使用 `DT.float`。
- 只有当你真正想表达“取当前视图的第一个元素”时，才使用 `GetValueFrom` / `SetValueTo`。
- 在 DSL 改写流程之外，不要把 `Var` 的比较结果当成普通 Python 条件。
