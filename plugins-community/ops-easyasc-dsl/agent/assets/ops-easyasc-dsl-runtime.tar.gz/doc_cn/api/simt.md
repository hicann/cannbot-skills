# SIMT 模块

本页介绍只在 A5 系列 facade（`easyasc.a5` 和 `easyasc.a5pr`）中导出的
SIMT 编写接口：

- `@simt(num_threads=1024)` —— 用来构建 `SimtModule` 的装饰器
  （见 [decorators.md §5](decorators.md)）
- `SimtModule` —— 装饰器返回的运行时对象
- `cvt(value, dtype)` —— SIMT 函数体里唯一允许的 dtype 转换 intrinsic
- `simt_fma(multiplicand0, multiplicand1, addend)` —— 融合 fp32 乘加
- `simt_thread_id()`、`simt_thread_num()`、`simt_block_idx()`、`simt_block_num()` ——
  四个无参 intrinsic，分别映射到后端的 `Simt::*` 辅助函数
- `simt_atomic_add()`、`simt_atomic_sub()`、`simt_atomic_max()` 和
  `simt_atomic_min()` —— 只能作为语句使用，对 GM 或 UB tensor 形参做 atomic 更新

SIMT 模块**不是** `@kernel`，**不是** `@vf`，也**不是** `@func`。它是一条
独立的代码生成路径，有自己的 AST 下沉规则。能在 `@kernel` 里跑的代码不一定
能在 `@simt` 里跑，反过来也是。

## 1. 什么时候用 SIMT

SIMT 在 A5 系列上是一条例外路径，不是默认性能路径。密集 contraction 优先用
cube `matmul`，规则向量工作优先用 `@vf()` / `micro`。

只在下列情况使用 `@simt`：

- 工作确实不规则，例如数据依赖的 gather/scatter、atomic 或带大量分支的
  per-element 控制流
- 有针对性的 runtime probe 本身就需要验证 SIMT 路径
- 逻辑无法干净地表达为 VF + matmul，强行这样做会让 kernel 更脆弱
- 操作数能干净地落在 `GMTensor`、UB `Tensor` 或 `Var` 参数上

**不适合**用 `@simt` 的场景：

- 密集 dot product、matrix product 或 GEMM 风格的 reduction 可以使用 cube
  `matmul`
- 规则的 elementwise、mask、按行 reduction、scan、cast 或 layout
  publish/postprocess 可以用 `@vf()` / `micro`
- 你只是想为一个 VF + matmul 拓扑已经很明确的子图快速写一个 correctness
  baseline
- 你需要 cube / `L0` / `L1` 操作（这些应该写在 `@kernel` 里）
- 你需要 `Reg` / `RegList` / `MaskReg` 这种 micro 算术（用 `@vf`）
- 你需要 `SEvent` / `DEvent` 这种命名 pipe 事件（用 `@kernel` + `auto_sync()`，
  或者显式的 mutex）

## 2. 调用约定

`@simt` 装饰过的函数从 `@kernel` 函数体里调用，调用方式和 `@vf` 完全一样。
它会发射一条 `call_simt` 指令，parser 会把它路由到 vec 侧；autosync pass
会用模块的读 / 写 sync key 把它和周围的 `MTE2 -> V -> MTE3` 边一起调度。

```python
from easyasc.a5 import *

TILE_ELEMS = 64

@simt()
def axpy_simt(x_ub: Tensor, y_ub: Tensor, out_ub: Tensor, alpha: Var, n: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out_ub[i] = x_ub[i] * alpha + y_ub[i]


@kernel()
def simt_axpy_kernel(x: GMTensor, y: GMTensor, out: GMTensor, alpha: Var, N: Var):
    x_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    y_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    out_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    n_iter = Var(TILE_ELEMS, DT.int)

    with auto_sync():
        x_ub <<= x[0:1, 0:TILE_ELEMS]
        y_ub <<= y[0:1, 0:TILE_ELEMS]
        axpy_simt(x_ub, y_ub, out_ub, alpha, n_iter)
        out[0:1, 0:TILE_ELEMS] <<= out_ub

    return out
```

这就是 `agent/example/kernels/a5/simt/simt_axpy.py`。它旁边还有这些参考样例：

- `agent/example/kernels/a5/simt/simt_atomic_add.py` —— GM 侧 `out = init;
  out[i % BINS] += x[i]`，使用 `simt_atomic_add`，并展示两种安全的 vec identity
  分片写法
- `agent/example/kernels/a5/simt/simt_matmul_transpose_contig_read.py` —— cube matmul +
  SIMT 转置，UB 端读连续
- `agent/example/kernels/a5/simt/simt_matmul_transpose_contig_write.py` —— 同样的任务，
  改成 GM 端写连续

## 3. `SimtModule` 的生命周期

`@simt` 装饰器会返回一个 `SimtModule` 实例。每个调用点都会触发：

1. 参数归一化 —— 实参里的 Python `int` / `float` 会被包装成 dtype 为
   `DT.int` 或 `DT.float` 的匿名 `Var`
2. dtype 校验 —— 每个实参都必须匹配形参的 `kind`（`GMTensor`、`Tensor`
   或 `Var`）
3. dtype 锁定 —— 第一次调用时，模块会记录这次实参的 dtype tuple；之后
   如果用了不同的 dtype tuple，会抛 `TypeError`
4. 指令发射 —— 当前激活的 kernel 会收到一条 `call_simt` 指令，里面带着
   模块名、归一化后的参数、`num_threads`，以及从函数体派生出来的读 / 写
   sync key

也就是说，一个 `@simt` 模块可以在同一个 kernel 里被多次复用，但每次调用
都得用一样的 dtype 组合。

## 4. 支持的 AST 子集

函数体会通过 Python 的 `ast` 模块解析，并下沉两次：

- 通过 `SimtModule.render()` 下沉成 C++ 源代码 —— 给 codegen 用
- 通过 `SimtModule.lower_to_ir()` 下沉成内部 IR —— 给模拟器用

两条路径接受的是同一个受限子集。

### 语句

- `Assign` —— 只能有一个目标；目标可以是裸 name（声明一个 dtype 与右侧
  一致的新局部变量），也可以是下标表达式
- `AugAssign` —— 使用已有目标的 dtype；两侧 dtype 必须一致
- 裸表达式 —— 通常是函数调用；裸字符串字面量会被当成 docstring 跳过
- `For` —— 只支持 `for <name> in range(<...>):`，不支持 `for-else`
- `While` —— 不支持 `while-else`
- `If` / `Elif` / `Else` —— 条件中的链式比较会被拒绝；请改用 `&&` / `||`
- `Break` / `Continue`

其他写法（list、dict、函数定义、import、`with`、异常处理等）都会抛
`NotImplementedError`。
渲染或下沉 SIMT 函数体时报出的错误会附带
`SIMT source line: <file>:<line> in @<name>`，并打印原始源码语句，方便直接
定位是哪一行炸了。

### 表达式

- `Name` —— 只能是事先声明过的本地变量或形参；否则抛 `NameError`
- `Constant` —— `int`、`float` 或 `bool`
- `Subscript` —— 只支持单个 index（不支持切片）；下标的 base 必须是
  name
- `BinOp` —— `+`、`-`、`*`、`/`、`%`，以及位运算 `|`、`^`、`&`、`<<`、`>>`；
  优先级和非交换分组规则与 C++ 保持一致
- `UnaryOp` —— `+`、`-`、`not`
- `Compare` —— `==`、`!=`、`<`、`<=`、`>`、`>=`；链式比较会被拒绝
- `BoolOp` —— `and` / `or` 会下沉成 C++ 的 `&&` / `||`
- `Call` —— `cvt(...)`、`simt_fma(...)` 和四个无参 intrinsic 可用作表达式；
  四个 `simt_atomic_*` 调用只能作为裸表达式语句

### dtype 规则

- 每个二元运算、比较、复合赋值和普通赋值都要求两侧 dtype 一致；想在函数体
  里改 dtype，唯一的办法就是 `cvt(value, dtype)`（见 §5）
- 下标表达式继承 base 的 dtype
- 布尔字面量会被当成 `DT.int`
- `for` 循环变量会自动赋成 `DT.int`
- `for` 循环变量不能遮蔽已存在的 name；这样写会抛 `NameError`

### `for` 内部 `range(...)` 的规则

- 1、2 或 3 个位置参数
- 不接受关键字参数
- 每个参数都必须能下沉成 `DT.int`

## 5. `cvt(value, dtype)`

- 用途：把 `value` 在 SIMT 函数体里转换成 `dtype`。这是函数体里唯一可用
  的 cast intrinsic；不会有普通的数值类型自动提升。
- 参数：
  - `value`：§4 中支持的任何表达式
  - `dtype`：`Datatype.X` 或 `DT.X` —— 必须以属性访问的形式写出，不能是
    一个运行时变量
- codegen 下沉结果：`(T)(value_expr)`
- 限制：
  - 必须正好两个位置参数
  - 不接受关键字参数
  - 第二个参数必须能解析成 `Datatype.<name>`（或通过别名 `DT.<name>`）——
    `cvt(x, DT.float)` 是合法的；`cvt(x, my_dtype)` 不合法

## 6. `simt_fma(multiplicand0, multiplicand1, addend)`

- 作用：在 SIMT 表达式中用一次融合 fp32 操作计算
  `multiplicand0 * multiplicand1 + addend`
- 参数：正好三个位置表达式，全部推导为 `DT.float`
- 返回 dtype：`DT.float`
- codegen：一个带括号的乘加表达式。生成的 SIMT 工程会启用 fp
  contraction，使后端可发射融合操作
- 模拟器：用 fp64 计算乘积与和，再只向 fp32 舍入一次，匹配 fused 语义，
  而不是分开舍入的 multiply-then-add
- 限制：
  - 不接受关键字参数
  - 拒绝 half、bfloat16、integer 和 mixed-dtype 操作数
  - 只有当 fused rounding 不属于合同时，才使用普通 `*` 再 `+`

```python
out[i] = simt_fma(x[i], y[i], out[i])
```

## 7. 无参 intrinsic

| 公开名 | 后端下沉结果 | 在函数体里的返回 dtype |
| --- | --- | --- |
| `simt_thread_id()` | `Simt::GetThreadIdx<0>()` | `DT.int` |
| `simt_thread_num()` | `Simt::GetThreadNum<0>()` | `DT.int` |
| `simt_block_idx()` | `Simt::GetBlockIdx()` | `DT.int` |
| `simt_block_num()` | `Simt::GetBlockNum()` | `DT.int` |

四个 intrinsic 都不接受参数。传任何位置参数或关键字参数都会抛 `TypeError`。

在 A5 系列硬件上，`simt_block_idx()` / `simt_block_num()` 是 cube core 的
identity/count，不是全局 vec participant 的 id/count。普通 vec 侧调用点会在每个
core 的两个 subblock 上都跑，所以 GM 全局分片时应该显式传入 vec identity：

```python
body(x, out, N, GetVecIdx(), GetVecNum())
```

或者只传 `GetSubBlockIdx()`，在 SIMT 函数体内部计算
`vec_idx = simt_block_idx() * 2 + sub_block_idx`。这两种写法在
`agent/example/kernels/a5/simt/simt_atomic_add.py` 里都有展示。直接拿 `simt_block_idx()` 做 GM
atomic 分片会变成按 cube core 分片，两个 vec subblock 很容易重复干同一份活。

它们对应的 Python stub 在 `@simt` 函数体之外被调用时会返回常量 `0` / `1`，
这样静态工具和单元测试导入这个文件时仍然能正常工作。

## 8. 原子写 intrinsic

| 公开名称 | 后端下沉 |
| --- | --- |
| `simt_atomic_add(t[i], val)` | `Simt::AtomicAdd(t + (i), val);` |
| `simt_atomic_sub(t[i], val)` | `Simt::AtomicSub(t + (i), val);` |
| `simt_atomic_max(t[i], val)` | `Simt::AtomicMax(t + (i), val);` |
| `simt_atomic_min(t[i], val)` | `Simt::AtomicMin(t + (i), val);` |

只能作为**语句**使用（裸表达式语句，没有返回值）。

- 第一个参数必须是张量形参 —— `GMTensor` 或 UB `Tensor`。下标形式
  `t[i]` 下沉为 `t + (i)`；裸名形式 `t` 下沉为 `t`（offset = 0）。
- 第二个参数必须和张量元素 dtype 完全一致。下标必须是 `DT.int`。
- 基名同时贡献读和写的 sync key，符合原子读—改—写的语义。
- 模拟器对 add/sub 走 `index_put_(..., accumulate=True)`，对 max/min 走
  `scatter_reduce_(..., reduce='amax'|'amin', include_self=True)`，并通过
  `SharedMemoryStore.atomic_lock()` 串行化跨 core 的并发更新。
- 这些 Python stub 在 `@simt` 函数体之外是空操作。

## 9. 生成的函数签名

`SimtModule.render()` 会发射：

```cpp
__simt_vf__ __launch_bounds__(<num_threads>) inline void <name>(<args>) {
    <body>
}
```

参数按形参 kind 下沉：

| 形参标注 | 生成的参数 |
| --- | --- |
| `GMTensor` | `__gm__ <T>* <name>` |
| `Tensor` | `__ubuf__ <T>* <name>` |
| `Var` | `<T> <name>` |

张量参数的 `<T>` 来自第一次调用点上锁定下来的实参 dtype。

## 10. 同步

`call_simt` 指令会带着从 SIMT 函数体派生出来的 `read_sync_keys` 和
`write_sync_keys`（由 `SimtModule._derive_call_sync_keys` 推导）：

- 函数体里被读的 `GMTensor` / `Tensor` 形参，会在调用点的对应实参上贡献
  一个读 sync key
- 函数体里被写的同一个形参，会贡献一个写 sync key
- 通过 base name 做下标写，被视作对该 base 的写入

这样 `call_simt` 调用点在 `with auto_sync():` 里就和普通 vec 侧指令一样。
你不需要在它周围手工加 `bar_all()` 或者命名事件。

如果需要在 cube 和某次 SIMT 调用之间做跨侧排序（SIMT 调用消费的是 cube
生产的 tile，或者反过来），就和包 `@vf` 调用一样，用 `CvMutex` / `VcMutex`。
cube → SIMT 的接力可以参考
`agent/example/kernels/a5/simt/simt_matmul_transpose_contig_read.py` 里 `CvMutex(...,
dst_end_pipe=Pipe.V)` 的写法。

## 11. 模拟器行为

- 模拟器会先 import 这个模块，构建 IR，然后在 vec 侧解释执行它
- 每个线程的状态都建模在同一个 vec sub-block 里；线程扇出是逻辑层面的，
  不是多进程
- 读 / 写 sync key 会进入和 `call_micro` 一样的 autosync 图
- 数值语义遵循 §4 的 dtype 规则 —— float 算术用 Python `float`，整数算术
  用 Python `int`，位运算要求位宽一致
- cycle model 按动态执行的 SIMT IR 指令计时：每条已执行的 masked
  指令计 4 cycles；分支发散时，每个有活跃 lane 的分支各计一次 masked
  执行；循环体在每个存在活跃 lane 的动态迭代中计一次
- `call_simt` 任务还会支付与 `@vf()` / `call_micro` 相同的 vec 侧指令 head
  overhead（来自当前 cycle profile 的 `instruction_head_overhead_cycles`，内置
  a5 profile 为 10 cycles）
- 普通模拟器执行使用真实 SIMT 运行时计数；单独调用
  `estimate_task_cycles(...)` 时，只会在克隆的 tensor view 上重放以供分析

`OpExec(..., simulator=True)` 走的代码路径和 codegen 构建是同一条，所以
模拟器跑通基本就意味着 SIMT 函数体也能干净地下沉成生成代码。

## 12. 常见坑

- **在 a2 上调用 `@simt`。** 装饰器和模块都会检查 `globvars.device_type`
  并抛错。请切到 `easyasc.a5` 或 `easyasc.a5pr`。
- **不同调用之间 dtype 不一致。** 第一次调用会把 dtype tuple 锁住；后面
  用不同 dtype 的调用会抛错。请在不同调用点用一致的缓冲区。
- **在函数体里不通过 `cvt` 混用 dtype。** 每个二元运算、比较、复合赋值
  和普通赋值都要求两侧 dtype 相等。
- **在 Python 条件里写链式比较。** 请拆成 `(a < b) and (b < c)`（会下沉
  成 `&&`），不要写 `a < b < c`。
- **传入关键字参数。** SIMT 模块的调用接口不接受 `**kwargs`
  （`if kwargs: raise TypeError(...)`）。
- **循环变量遮蔽形参名。** 像 `for x in range(...)` 这样写、且 `x` 又是
  形参，会抛 `NameError`。换一个新名字即可。
- **忘记 `auto_sync()`。** 如果 `call_simt` 周围没有 `auto_sync()`，它就
  不会有读 / 写 key 暗含的那套生产者 / 消费者握手；你会看到它和周围的
  MTE2 / MTE3 工作发生顺序竞争。
