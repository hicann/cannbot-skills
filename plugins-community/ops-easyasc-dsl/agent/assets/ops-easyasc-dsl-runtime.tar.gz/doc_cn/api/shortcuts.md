# Shortcut

本页文档说明一些在概念上由 `easyasc.a2` 与 A5 系列入口
（`easyasc.a5`、`easyasc.a5pr`）共同使用的公开 shortcut 风格辅助。

这些辅助属于更高层的便利入口，而不是最底层的指令原语。

## 1. Matmul Shortcut

### `matmul(dst, l1a, l1b, splitn=None, splitk=None, m=None, n=None, k=None, is_init=True, bias=None)`

- 作用：发射仓库中大多数 kernel 使用的标准 matmul 路径，并支持可选的 split-N 或 split-K staging。
- 逻辑约定：`l1a[M,K] @ l1b[N,K].T -> dst[M,N]`（`MK @ NK -> MN`）。
  如果源张量物理存成 `KM` / `KN`，在调用处传 `.T` 视图，让 shortcut 看到逻辑操作数。
- 参数：
  - `dst`：位于 `L0C` 的 `Tensor`
  - `l1a`、`l1b`：位于 `L1` 的输入 `Tensor`
  - `splitn`：可选的 N 向切分大小
  - `splitk`：可选的 K 向切分大小
  - `m`、`n`、`k`：可选的显式逻辑尺寸
  - `is_init`：目标累加是否从零开始
  - `bias`：可选的连续 `[1, N]` L1 bias 行，只在 init tile 上加入
- 限制：
  - 只能在激活的 kernel 中使用
  - `dst` 必须位于 `Position.L0C`
  - `l1a` 与 `l1b` 必须位于 `Position.L1`
  - `splitn` 与 `splitk` 不能同时设置
  - `splitn` 与 `splitk` 只在单个 core 内做 tiling，不会自动创建跨 core 分区或 host merge
  - 普通 matmul 对这两个 split 没有统一的 32 硬下限；32 只是调优搜索启发式
  - `bias` 存在时，必须先在 L1 中按连续行 staging；不要使用默认的 ND2NZ 分形化行
  - `bias` 的 dtype：float/half/bf16 输入族使用 `DT.float`，int8@int8 使用 `DT.int`；bias 要求 `is_init=True`，且当前不支持 int4
  - 自动 BT slot 在 A2 可容纳 64 个 fp32/int32 元素，在 A5/A5PR 可容纳 512 个；
    nosplit/split-K bias 要求完整 N 静态且不超过上限，动态总 N 必须使用静态有界的 split-N tile
  - 当前激活的 kernel 必须已经具备框架管理的 `_l0a`、`_l0b`、`_l0acnt`、`_l0bcnt` 缓冲
- 示例：

```python
matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
```

## 2. MX FP8 / MXFP4 Matmul Shortcut

### `matmul_mx(dst, l1a, l1b, scale_a, scale_b, splitk=None, m=None, n=None, k=None, is_init=True, *, splitn=None, bias=None)`

- 作用：发射 A5 系列支持的 MX FP8 / MXFP4 matmul 路径。
- 逻辑约定：`l1a[M,K] @ l1b[N,K].T -> dst[M,N]`。
- 参数：
  - `dst`：位于 `L0C` 的 `DT.float` `Tensor`
  - `l1a`、`l1b`：位于 `L1` 的 `DT.e4m3` / `DT.e5m2` 张量，或
    `DT.fp4_e2m1` / `DT.fp4_e1m2` carrier-backed 视图
  - `scale_a`、`scale_b`：位于 `L1` 的 `DT.uint8` e8m0 scale 张量
  - `splitk`：可选 K 切分大小；静态值必须是 `64` 的倍数
  - `splitn`：可选 N 切分大小；NZ2NZ 静态值必须是 `16` 的倍数，存在
    `l1b.T` 的 NZ2ZN 路径静态值必须满足转置加载对齐：FP8 为 `32`，FP4 为 `64`
  - `m`、`n`、`k`：可选显式逻辑尺寸
  - `is_init`：L0C 累加是否从零开始
  - `bias`：可选的连续 fp32 `[1, N]` L1 bias 行，只在 init tile 上加入
- 限制：
  - 仅 A5 系列 / `device_type in ("950", "950pr")`
  - 支持 NZ2NZ，以及通过 `l1a.T` 或 `l1b.T` 走 A/B 侧 NZ2ZN；转置 scale
    tensor 会被拒绝
  - `splitn` 与 `splitk` 不能同时设置
  - 非转置 shortcut scale 张量是 16 行物理 tile
  - 使用 `l1a.T` 时，`scale_a` 必须已经按转置后行序打包为
    `[M, 2 * ceil(K / 64)]`
  - 使用 `l1b.T` 时，`scale_b` 必须已经按转置后行序打包为
    `[N, 2 * ceil(K / 64)]`
  - 外部 GM scale 必须先按 `[num_blocks, 32]` 的 `gm_to_l1_mx_scale`
    约定搬进 L1，不能按逻辑 scale 矩阵直接传入
  - `bias` 存在时，必须先在 L1 中按连续行 staging，dtype 必须是 `DT.float`，并且要求 `is_init=True`；
    nosplit/split-K 需要静态 `N <= 512`，动态总 N 需要静态 `splitn <= 512`
- 详细约定：[MX FP8 / MXFP4 Matmul 说明](../topics/mxfp.md)。
- 示例：

```python
matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitk=64, m=M, n=N, k=K)
```

## 3. MXFP8 Padding Helper

### `zero_mxfp8_l1_padding(tensor, n_blocks=None)`

- 作用：在底层 MX transpose/NZ2ZN load 前，清零 padded 的单字节 L1 数据 tile。虽然名字里写的是 MXFP8，但这个 helper 对 FP4 的 `DT.uint8` carrier tile 也有效。
- 限制：
  - 仅 A5 系列
  - `tensor` 必须是位于 `Position.L1` 的物理 tensor，且元素大小为 1B
  - 如果省略 `n_blocks`，静态 footprint 必须 32B 对齐
- 调用顺序很重要：先调用这个 helper，再填 live scale/data。它是粒度比较粗的 L1
  常量填充，如果在数据填完后调用，可能把有用字节清掉。
- 详细约定：[MX FP8 / MXFP4 Matmul 说明](../topics/mxfp.md)。

## 3b. `conv2d(l0c, fmap, weight, conv, h, w, c, cout, m0=0, tile_k=None, bias=None)`

- 作用：发射卷积 matmul
  `l0c[tile_m, cout_p] = img2col(fmap)[m0:m0+tile_m, :] @ weight.T (+ bias)`，
  由 load3d 硬件在搬运时即时完成 img2col。
- 逻辑契约：一个 `Conv2D` 配置 + 一个 L1 `NC1HWC0` 特征图 + 一个 L1 打包权重，产出一个 `[tile_m, cout_p]` 的 L0C tile。
- 参数：
  - `l0c`：位于 `L0C` 的目标 `Tensor`（`tile_m` 即 `l0c.shape[0]`）
  - `fmap`：L1 上 `NC1HWC0` 布局的特征图（`[c1*h*w, C0]`）
  - `weight`：L1 上的打包权重 `[cout_p, K]`，通过对 host `easyasc.utils.conv2d.pack_conv_weight` 输出做 `<<=` 暂存
  - `conv`：描述 kernel size、stride、padding、dilation 的 `Conv2D` 配置对象
  - `h`、`w`、`c`：特征图的高 / 宽 / 通道维（`int` 或 `Var`）
  - `cout`：输出通道数（`int` 或 `Var`）
  - `m0`：逻辑 img2col 矩阵中的行偏移；由调用方循环 `m0`
  - `tile_k`：可选的 K 切分大小
  - `bias`：可选的连续 fp32 `[1, cout_p]` L1 bias 行，在 init K tile 上加上
- 限制：
  - A2 / 910B 与 A5 系列（`a5` / 950、`a5pr` / 950PR）
  - 仅 matmul-scope：调用方负责外层 `m0` 循环、core 门控、以及 L0C 写回
  - `fmap` / `weight` / `bias` 必须已经暂存在 L1
  - padding 后的 bias 宽度必须放进一个 BT slot：A2 最多 64 个 fp32 元素，
    A5/A5PR 最多 512 个；L0/cube 容量仍独立检查
- 详细契约：[Conv2D via load3d img2col](../topics/conv2d.md)——涵盖 host packer
  `easyasc.utils.conv2d.pack_nc1hwc0` / `pack_conv_weight`、`Conv2D` / `img2col` / `l1_to_l0a_img2col`
  接口、load3d 参数语义以及硬件约束。
- 示例：

```python
conv2d(l0c, fmap_l1, weight_l1, conv, h=H, w=W, c=C, cout=Cout, m0=m0, bias=bias_l1)
```

## 4. VecOP 便捷构造器

### `maximum(a, b)`

- 作用：构造一个 `VecOP`，表示“一个 tensor 与另一个 tensor 或标量之间的逐元素最大值”。
- 参数：
  - `a`、`b`：至少其中一个必须是 tensor，另一个可以是另一个 tensor 或标量 / `Var`
- 限制：
  - 至少有一个操作数必须是 `Tensor`
  - 返回对象必须通过 `<<=` 消费
- 示例：

```python
dst <<= maximum(src, 0.0)
```

### `minimum(a, b)`

- 作用：构造一个 `VecOP`，表示“一个 tensor 与另一个 tensor 或标量之间的逐元素最小值”。
- 参数：
  - `a`、`b`：至少其中一个必须是 tensor，另一个可以是另一个 tensor 或标量 / `Var`
- 限制：
  - 至少有一个操作数必须是 `Tensor`
  - 返回对象必须通过 `<<=` 消费
- 示例：

```python
dst <<= minimum(src1, src2)
```
