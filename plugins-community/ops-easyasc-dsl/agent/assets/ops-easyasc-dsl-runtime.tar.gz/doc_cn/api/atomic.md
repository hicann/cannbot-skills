# 原子上下文管理器

本页文档说明由 `easyasc.a2` 与 A5 系列入口（`easyasc.a5`、
`easyasc.a5pr`）共享的原子写回上下文管理器。

这些 API 定义在 `easyasc/stub_functions/atomic.py` 中。

## 1. 概览

原子辅助是上下文管理器，而不是普通的一次性函数。

典型用法：

```python
with atomic_add():
    out[:, :] <<= ub
```

它在概念上的含义是：

- 进入 block：开启一种原子写回模式
- 在 block 内发射受支持的 GM 写回指令
- 离开 block：把原子模式关闭

一个很重要的理解方式是：

- 这个上下文管理器不会让 block 里的每一条指令都自动变成原子操作
- 它只是改变后续那些“受支持的 GM-store 指令”看到的写回模式

在当前实现中，主要会消费这类原子状态的路径是：

- `l0c_to_gm_nz2nd`
- `l0c_to_gm_nz2dn`（仅 A5 系列的转置写回）
- `ub_to_gm_pad`

所以更准确地说，这些原子上下文管理器其实是“原子 GM 写回模式作用域”。

## 2. 支持的 API

### `atomic_add(cond=None, dtype=DT.float)`

- 作用：在包裹区域内启用原子加写回。
- 参数：
  - `cond`：可选的条件模式占位参数
  - `dtype`：原子操作的 dtype
- 当前限制：
  - 只能在 kernel 上下文中使用
  - `cond` 尚未实现
  - 当前只支持 `DT.float`

示例：

```python
with atomic_add():
    out[:, :] <<= ub
```

### `atomic_max(dtype=DT.float)`

- 作用：在包裹区域内启用原子 max 写回。
- 参数：
  - `dtype`：原子操作的 dtype
- 当前限制：
  - 只能在 kernel 上下文中使用
  - 当前只支持 `DT.float`

示例：

```python
with atomic_max():
    out[:, :] <<= ub
```

### `atomic_min(dtype=DT.float)`

- 作用：在包裹区域内启用原子 min 写回。
- 参数：
  - `dtype`：原子操作的 dtype
- 当前限制：
  - 只能在 kernel 上下文中使用
  - 当前只支持 `DT.float`

示例：

```python
with atomic_min():
    out[:, :] <<= ub
```

## 3. 构造与校验规则

### 通用 dtype 规则

这三个上下文管理器当前都要求：

- `dtype` 必须是 `DataTypeValue`
- `dtype` 必须严格等于 `DT.float`

因此下面这些写法在当前实现中都会被拒绝：

- `atomic_add(dtype=DT.half)`
- `atomic_max(dtype=DT.int)`
- `atomic_min(dtype=DT.bfloat16)`

### `atomic_add` 的条件参数规则

`atomic_add` 比另外两个 API 多一个参数：

- `cond`

当前行为：

- 如果 `cond is not None`，构造函数会抛出 `NotImplementedError`

因此，条件原子加目前只是体现在 API 形状里，还没有真正实现。

## 4. 运行时机制

### 进入上下文时

当你进入这些上下文管理器之一时：

- 当前激活的 kernel 会收到一条 `Instruction("atomic_add")`、`Instruction("atomic_max")` 或 `Instruction("atomic_min")`
- 全局原子状态会被更新：
  - `globvars.atomic_enabled = True`
  - `globvars.atomic_type = dtype`

这意味着，上下文管理器本身并不执行写操作。它只是切换了后续发射指令所看到的模式。

### 离开上下文时

正常退出时：

- 当前激活的 kernel 会收到 `Instruction("atomic_end")`
- 全局原子状态会被重置：
  - `globvars.atomic_enabled = False`
  - `globvars.atomic_type = None`

如果 block 因异常退出：

- `__exit__` 会返回 `False`
- 原始异常会继续向外传播

## 5. 原子状态到底在哪里被消费

真正重要的部分不是 `with` block 本身，而是后续哪些 store 指令会去查询当前原子状态。

在当前代码库中，主要会这样做的写回 stub 是：

### `l0c_to_gm_nz2nd`

当原子模式开启，而且目标 GM dtype 与当前缓存的 atomic dtype 不同时：

- stub 会发射 `Instruction("set_atomic_type", dtype=dst.dtype)`
- 然后更新缓存的 `globvars.atomic_type`

之后发射的 `l0c_to_gm_nz2nd` 指令，就会在模拟器派发时带上激活中的原子模式。

### `l0c_to_gm_nz2dn`

这个仅 A5 系列的转置写回行为与 `l0c_to_gm_nz2nd` 相同：当原子模式开启、且目标 GM dtype 与缓存的 atomic dtype 不同时，stub 会在写回前发射 `Instruction("set_atomic_type", dtype=dst.dtype)`，模拟器派发时也会应用同样的原子操作。

### `ub_to_gm_pad`

它的行为完全相同：

- 如果原子模式已开启，并且 `globvars.atomic_type is not dst.dtype`
- stub 会发射 `Instruction("set_atomic_type", dtype=dst.dtype)`
- 然后再发射 `ub_to_gm_pad`

实际含义是：

- 原子作用域只有在包住受支持的 GM 写回操作时才真正有意义
- 把无关的计算或局部操作包在里面，并不会神奇地让这些操作变成原子操作

## 6. 模拟器行为

### 主循环状态

每个模拟器 pipe（`PipeS`）只保留一个 atomic 状态字段 `_atomic_mode`；
它是字符串，未启用时为空。它会随指令变化：

- `atomic_add` -> `_atomic_mode` 变成 `"atomic_add"`
- `atomic_max` -> `_atomic_mode` 变成 `"atomic_max"`
- `atomic_min` -> `_atomic_mode` 变成 `"atomic_min"`
- `atomic_end` -> 把 `_atomic_mode` 清回 `""`

atomic *dtype* 是构建期问题（`set_atomic_type` / `globvars`），不是模拟器的
runtime 字段。当 `_atomic_mode` 非空时分发写回操作，模式字符串会作为
`_atomic` 注入该 task 的参数。

### 哪些写回路径真正应用原子行为

当前模拟器里的原子行为实现于：

- `FIXPipe` 中的 `l0c_to_gm_nz2nd` 和 `l0c_to_gm_nz2dn`（仅 A5 系列）
- `MTE3Pipe` 中的 `ub_to_gm_pad`

这些 pipe 执行器会：

- 读取 task 参数中注入的 `_atomic` 模式
- 把请求的 atomic 操作（`add` / `max` / `min`）应用到现有 GM 目标值上

模拟器当前支持的原子模式包括：

- `add`
- `max`
- `min`

如果模式缺失或无法识别，模拟器会静默退化：`ub_to_gm_pad`（vec）
默认为 `add`，而 `l0c_to_gm_nz2nd`（cube）会落到普通的非 atomic store。
两种情况都不会记录 warning。

### 数值行为

模拟器对原子更新的计算规则是：

- `add`：`dst = dst + src`
- `max`：`dst = maximum(dst, src)`
- `min`：`dst = minimum(dst, src)`

在这些原子路径中，模拟器：

- 可能会先用某种内部计算 dtype，再 cast 回目标 dtype
- 会按照该模式底层使用的 torch 运算来保留 NaN 行为

### dtype 不匹配时的行为

模拟器不会在 runtime 跟踪或校验 atomic dtype，因此即使目标 dtype 与
预期 atomic dtype 不同，也不会输出诊断。在正常框架使用中，store stub
会在构建期按需发射 `set_atomic_type`，让后端使用正确的累加 dtype。

## 7. Codegen 行为

parser 会把这些指令 lowering 成后端的原子模式设置语句：

- `atomic_add` -> `SetAtomicAdd<float>();`
- `atomic_max` -> `SetAtomicMax<float>();`
- `atomic_min` -> `SetAtomicMin<float>();`
- `set_atomic_type(dtype)` -> `SetAtomicType<...>();`
- `atomic_end` -> `SetAtomicNone();`

因此，codegen 和模拟器遵循的是同一个高层模型：

1. 进入某一种原子模式
2. 如有需要，为某次写回重新指定 atomic dtype
3. 发射写回操作
4. 结束原子模式

## 8. 示例

### vec 侧的原子加写回

```python
with atomic_add():
    out[:, :] <<= ub
```

可以这样理解：

- 在这个 block 内，如果赋值最终走的是 `ub_to_gm_pad` 这条写回路径，那么这次 GM 写回就会按原子加处理

### cube 侧的原子 max 写回

```python
with atomic_max():
    z[:, :] <<= l0c
```

可以这样理解：

- 在这个 block 内，如果赋值最终走的是 `l0c_to_gm_nz2nd` 这条写回路径，那么这次写回就会按原子 max 处理

### 自动切换 dtype

```python
with atomic_add():
    out_f32[:, :] <<= ub_f32
```

如果目标 dtype 与当前缓存的 atomic dtype 不一致，写回 stub 会在 GM store 指令之前自动插入 `set_atomic_type(dst.dtype)`。

## 9. 原子上下文管理器不能替代什么

不要把原子作用域和下面这些机制混淆：

- barrier
  - barrier 约束的是 pipe 进度顺序
- event
  - event 负责同步源 pipe 与目标 pipe
- mutex
  - mutex 负责在 cube 和 vec 之间转移 ownership

原子作用域只会改变“受支持的 GM 写回”如何和现有目标值合并。

## 10. 实用建议

- 只在真正需要原子写回的最小区域外层使用原子作用域。
- 要预期 atomic mode 只会影响受支持的 GM store 路径，而不是 block 内任意指令。
- 记住当前只支持 `DT.float`。
- 不要依赖 `atomic_add` 的 `cond` 参数；它现在还没有实现。
- 如果你的目标在 GM 上，而且多个写入方必须合并结果，那么 atomic scope 是合适的原语；如果问题本质上是顺序或 ownership，请改用 barrier、event 或 mutex。
