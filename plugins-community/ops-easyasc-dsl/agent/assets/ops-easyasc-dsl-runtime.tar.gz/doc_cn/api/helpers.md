# 杂项辅助

本页文档说明七个体量不大、但非常重要的辅助 API：

- `sim_print`
- `sim_dump_tensor`
- `kernel_print`
- `kernel_dump_tensor`
- `inline`
- `clean_dcache`
- `set_hf32`

它们被归在一起，是因为它们既不是数据搬运原语，也不是同步原语，更不是数学原语；它们主要用于调试、观测，以及作为后端逃生口。

可用性：以上七个 helper 都由 `easyasc.a2` 与两个 A5 系列入口
（`easyasc.a5`、`easyasc.a5pr`）导出。

`sim_*` 系列只在模拟器里有效（codegen handler 是 no-op）；`kernel_*` 系列只在 codegen 里有效（模拟器不会执行它们）。读这页其他部分时，请先记住这层区别。

## 1. `sim_print(*args, pipe=Pipe.S)`

- 作用：打印附着到某条 pipe 或主循环上的模拟器调试信息。
- 参数：
  - `*args`：任意需要输出的内容
  - `pipe`：`PipeType`，默认值是 `Pipe.S`
- 校验：
  - `pipe` 必须是 `PipeType`
- 指令发射：
  - 会发射 `Instruction("sim_print", payload=list(args), pipe=pipe)`

### 在模拟器模式下做什么

当模拟器执行到这条指令时：

- 传入内容会尽可能先解析成可打印的运行时值
- `Var`、`Expr` 这类 DSL 标量对象也会先被解析
- 最终消息会把所有内容项用空格拼接起来

日志前缀取决于当前执行侧：

- cube：
  - `[cube][core=<core_idx>] ...`
  - 如果 `pipe != Pipe.S`，还会额外带上 `[pipe=<pipe>]`
- vec：
  - `[vec][core=<core_idx>][subblock=<subblock_idx>] ...`
  - 如果 `pipe != Pipe.S`，同样会额外带上 `[pipe=<pipe>]`

因此像下面这样的调用：

```python
sim_print("row_count", row_count, pipe=Pipe.V)
```

概念上可能会输出一行类似：

```text
[vec][core=0][subblock=1][pipe=V] row_count 32
```

### 在 codegen 模式下做什么

`sim_print` 是一个有意设计成“只在模拟器里有效”的 API。

它对应的 parser handler 是 no-op：

- 不会发射任何后端 C++ 代码
- 也不会生成任何运行时打印辅助

这意味着：

- `sim_print` 适合本地模拟器调试
- 不应把它视作生成 kernel 可观察行为的一部分

### pipe 语义

`pipe` 决定打印附着在哪个执行域上：

- `Pipe.S`
  - 打印附着在主循环侧
  - 适合看标量状态、控制流和同步逻辑
- 非 `S` pipe
  - 打印会尽量附着到对应的 pipe 队列上
  - 适合观察某个 producer / consumer pipe 真正到达某一点的时机

一个实用理解是：

- `pipe=Pipe.S` 更适合高层调试
- `pipe=Pipe.MTE2`、`Pipe.V`、`Pipe.M`、`Pipe.FIX` 等更适合看 pipe 局部时序

### 可以打印什么

API 接受任意 Python 对象，但最有用的输出内容通常是：

- 字符串
- `int`、`float`、`bool`
- `Var` 和 `Expr`
- `PipeType`
- 较短的标量风格 tuple / list

如果你想看大张量内容，`sim_print` 并不合适；模拟器侧 dump 用 `sim_dump_tensor`，生成代码里的 dump 用 `kernel_dump_tensor`。

### 常见用途

- 查看循环计数器或推导出来的 tile 大小
- 确认哪条 pipe 先到达某个点
- 调试跨侧或事件顺序
- 查看规约或形状计算后的标量值

### 示例：控制侧调试

```python
sim_print("tile", tile_idx, "valid_m", valid_m, pipe=Pipe.S)
```

当你关心的是标量信息，而且它更属于调度器 / 主循环视角时，这种写法最合适。

### 示例：pipe 局部调试

```python
sim_print("issued gm_to_ub for tile", tile_idx, pipe=Pipe.MTE2)
sim_print("starting vec postprocess", tile_idx, pipe=Pipe.V)
```

如果你想让模拟器日志显式带上 pipe 身份，这种写法会很有帮助。

## 2. `sim_dump_tensor(tensor, filename, pipe)`

- 作用：在模拟执行期间，把某个运行时张量视图导出到磁盘。
- 参数：
  - `tensor`：源 `Tensor`
  - `filename`：输出文件名字符串
  - `pipe`：`PipeType`
- 校验：
  - `tensor` 必须是 `Tensor`
  - `filename` 必须是 `str`
  - `pipe` 必须是 `PipeType`
  - `pipe` 不能是 `Pipe.ALL`
- 指令发射：
  - 会发射 `Instruction("sim_dump_tensor", tensor=tensor, filename=filename, pipe=pipe)`

### 会导出什么

执行时，模拟器会：

- 解析当前运行时张量视图
- 克隆它
- 用 `torch.save(...)` 把它写出去

因此，文件里保存的是已经解析好的运行时张量内容，而不是一个符号 DSL 对象。

这有几个重要含义：

- 切片、reinterpret 视图、转置元数据以及当前 offset，都已经体现在运行时视图中
- 导出的数据对应的是这个程序点可见的那份张量视图
- 后续再修改张量，也不会改变已经写出的文件

### 在 codegen 模式下做什么

和 `sim_print` 一样，`sim_dump_tensor` 在 codegen 期间也是 no-op：

- parser handler 不会发射任何代码
- 生成后的后端代码里也不会包含这条操作

因此 `sim_dump_tensor` 是模拟器调试工具，而不是生成 kernel 的功能。如果你需要一个能在 codegen 后还存活下来的运行时 dump，请改用 `kernel_dump_tensor`（§4）。

### pipe 语义

`pipe` 决定这条 dump 指令在哪个执行域上执行：

- `Pipe.S`
  - dump 由主循环执行
- 非 `S` pipe
  - dump 会在支持的情况下被派发到对应的 pipe 队列

如果你想抓住“某条 pipe 真正走到这里时”的张量状态，而不是“主循环走到这里时”的状态，这个区别就很重要。

`Pipe.ALL` 会被拒绝，因为 tensor dump 是一次单独执行动作，而不是一种 all-pipe barrier。

### 模拟器里的具体行为

cube 和 vec 模拟器都支持两条路径：

- 主循环路径：
  - 如果 `pipe == Pipe.S`，模拟器会立即解析运行时张量并调用 `torch.save`
- 派发到 pipe 的路径：
  - 否则，这条指令会先进入目标 pipe 队列
  - 当该 pipe 执行到它时，再执行同样的 `torch.save(tensor.detach().clone(), filename)`

如果所选 pipe 在当前模拟器侧不受支持，会报错，例如：

- `sim_dump_tensor has unsupported pipe on cube simulator: ...`
- `sim_dump_tensor has unsupported pipe on vec simulator: ...`

### 文件名行为

`filename` 会原样传给 `torch.save`。

实用建议：

- 文件名尽量明确且唯一
- 如果会 dump 多个阶段，建议把 tile 或 stage 信息写进文件名
- 注意同一路径重复 dump 会覆盖之前的文件

### 常见用途

- 查看 vec 数学之后的中间 UB 数据
- 在同步边界附近抓取 L1 / UB 交接结果
- 把模拟器状态和 Python 参考实现做离线对比
- 调试 reinterpret 或打包搬运这类对布局很敏感的操作

### 示例：在 vec 处理后导出 UB 张量

```python
sim_dump_tensor(ub_out, "ub_out_tile0.pt", Pipe.V)
```

含义：

- 把 dump 挂到 `V` pipe
- 当 `V` pipe 真正执行到这里时，保存 `ub_out` 当前的运行时视图

### 示例：从主循环导出

```python
sim_dump_tensor(ub_mid, "ub_mid_mainloop.pt", Pipe.S)
```

当你希望 dump 和控制流对齐，而不是和某条 pipe 队列对齐时，用这种写法。

## 3. `kernel_print(fmt, *args)`

- 作用：往生成的 cube / vec C++ 输出里发射一条 `printf` 调用，用于运行时调试。
- 参数：
  - `fmt`：原样传给 `printf` 的格式字符串
  - `*args`：可选 payload，作为 `printf` 的实参插入
- 校验：
  - `fmt` 必须是 `str`
- 指令发射：
  - 会发射 `Instruction("kernel_print", fmt=fmt, payload=list(args))`

### 在 codegen 模式下做什么

parser 会把这条指令下沉成一行字面 `printf` 调用：

- `kernel_print("hello")` → `printf("hello");`
- `kernel_print("tile=%d", tile_idx)` → `printf("tile=%d", tile_idx);`

格式字符串会被编码成一个 C++ 字符串字面量。每个 payload 值都会通过标准的“表达式到 C++”流程下沉，所以 `Var`、`int`、`float` 都能正常工作。

### 在模拟器模式下做什么

模拟器不会执行 `kernel_print`。Python 侧不会有任何日志行；这次调用纯粹是后端产物。

### 什么时候用它，什么时候用 `sim_print`

- 当你只需要在模拟器时看到输出（更丰富、能感知 pipe，但生成代码里看不到）时，用 `sim_print`
- 当你需要这条 print 出现在生成后的 cube / vec 二进制 stdout 里（薄薄一层 `printf`，没有 pipe 路由）时，用 `kernel_print`

### 示例

```python
kernel_print("processing tile %d / %d\n", tile_idx, tile_count)
```

对应生成的那一行是：

```cpp
printf("processing tile %d / %d\n", tile_idx, tile_count);
```

## 4. `kernel_dump_tensor(src, desc, dumpSize)`

- 作用：发射一次后端的 `DumpTensor(...)` 调用，让运行时在真实设备上 dump 张量内容。
- 参数：
  - `src`：源 `GMTensor` 或本地 `Tensor`
  - `desc`：`int` 或 `Var`，descriptor id（按 `uint32_t` 传）
  - `dumpSize`：`int` 或 `Var`，要 dump 的元素个数（按 `uint32_t` 传）
- 校验：
  - `src` 必须是 `GMTensor` 或 `Tensor`
  - 如果 `src` 是 `Tensor`，它的 `position` 必须是 `UB`、`L1` 或 `L0C`
  - `desc` 和 `dumpSize` 都必须是 `int` 或 `Var`
- 指令发射：
  - 会发射 `Instruction("kernel_dump_tensor", src=src, desc=desc, dumpSize=dumpSize)`

### 在 codegen 模式下做什么

parser 会把这条指令下沉成一行字面 `DumpTensor` 调用：

```cpp
DumpTensor(<src_expr>, (uint32_t) <desc_expr>, (uint32_t) <dumpSize_expr>);
```

`<src_expr>` 是源 tensor 视图下沉后的表达式（global tensor、UB tensor、L1 tensor 或 L0C tensor）。`desc` 和 `dumpSize` 不管原本是 `int` 字面量还是标量 `Var`，都会被强转成 `uint32_t`。

### 在模拟器模式下做什么

模拟器不会执行 `kernel_dump_tensor`。如果你需要一次模拟器侧的 `torch.save`，请用 `sim_dump_tensor`（§2）。

### 什么时候用它，什么时候用 `sim_dump_tensor`

- 想要 Python 侧模拟器的 `torch.save`，用 `sim_dump_tensor`
- 想要后端的 `DumpTensor` 运行时辅助在生成 kernel 里真正运行，用 `kernel_dump_tensor`

### 示例

```python
kernel_dump_tensor(ub_out, 0, BLK * N)
```

含义：

- 生成的 cube / vec 代码里会出现 `DumpTensor(<ub_out>, (uint32_t) 0, (uint32_t) BLK * N);`
- 模拟器路径会跳过这条指令

## 5. `inline(code)`

- 作用：把原始后端代码直接注入到生成结果里。
- 参数：
  - `code`：包含一行或多行后端代码的字符串
- 校验：
  - `code` 必须是 `str`
  - 在 `@vf` 中使用时，`inline` 会被记录到 micro module 中
- 指令发射：
  - 会发射 `Instruction("inline", code=code)`

`inline` 和 `sim_print`、`sim_dump_tensor` 的根本区别在于：

- 它只在 codegen 模式下有意义
- 模拟器会完全忽略它

### 在 codegen 模式下做什么

parser handler 会把这个字符串逐行直接发射到生成后的后端输出中。

具体行为：

- 如果 `code == ""`，会发出一个空行
- 否则，会把 `code.splitlines()` 得到的每一行原样输出
- DSL 这一层不会做语法检查

也就是说，`inline` 真的是一个逃生口：框架会把你给的文本原样插到 lowering 后的位置。

### 在模拟器模式下做什么

cube、vec 和 micro 模拟器都会完全忽略 `inline`：

- 它不会影响运行时状态
- 不会打印任何内容
- 也不会改变调度

因此，绝不要依赖 `inline` 去产生任何模拟器可见行为。

### 常见用途

- 临时性的后端实验
- 在生成代码里插入自定义注释或标记
- 桥接一个目前还没有一等 DSL helper 的后端能力

框架内部自己也会在一些自动插入的声明附近，用 `inline` 打标记。

### 风险与限制

- 你写进去的是后端相关文本
- DSL 层不会帮你校验语义
- 模拟器也帮不了你验证行为
- 如果周围生成结构后续发生变化，注入代码也可能随之过时

这也是为什么 `inline` 应该是最后手段，而不是常规作者工具。

### 示例：插入一条后端注释

```python
inline("// custom marker before manual backend fragment")
```

这是最安全的使用方式，因为它不会改变运行时语义。

### 示例：多行注入

```python
inline(
    "int local_debug_value = 3;\n"
    "(void)local_debug_value;"
)
```

handler 会把这两行原样输出到生成结果中。

## 6. `clean_dcache(dst, entire_type=EntireType.single, dcci_dst=DcciDst.all, mode="all")`

- 作用：为某个 GM tensor 目标发射显式的后端数据缓存 clean-and-invalidate 调用。
- 参数：
  - `dst`：目标 `GMTensor`
  - `entire_type`：`EntireTypeValue`，默认值为 `EntireType.single`
  - `dcci_dst`：`DcciDstType`，默认值为 `DcciDst.all`
  - `mode`：`str`，默认值为 `"all"`，必须是 `"all"`、`"vec"`、`"cube"` 之一
- 校验：
  - `dst` 必须是 `GMTensor`
  - `entire_type` 必须是 `EntireTypeValue`
  - `dcci_dst` 必须是 `DcciDstType`
  - `mode` 必须是 `str`
  - `mode` 必须是 `"all"`、`"vec"`、`"cube"` 之一
- 指令发射：
  - 会发射 `Instruction("clean_dcache", dst=dst, entire_type=entire_type, dcci_dst=dcci_dst, mode=mode)`

### 在 codegen 模式下做什么

parser lowering 会生成如下形式的后端调用：

```text
DataCacheCleanAndInvalid<{dst_dtype}, AscendC::CacheLine::{entire_type}, AscendC::DcciDst::{dcci_dst}>({dst_expr});
```

在 A2 上维护 output cache 时，使用 output-cache 目标：

```python
clean_dcache(global_out, EntireType.single, DcciDst.out, mode="vec")
```

概念上会 lowering 成：

```text
DataCacheCleanAndInvalid<float, AscendC::CacheLine::SINGLE_CACHE_LINE, AscendC::DcciDst::CACHELINE_OUT>(global_out);
```

A2 的 cache line 是 64 字节。如果标量 GM 访问确实需要 DCCI，host wrapper
必须先分配至少 64 字节的 backing region，再暴露 scalar view，避免 cacheline
操作越出已拥有的存储区域。不要仅根据输出尺寸推断是否需要 DCCI。
Huawei 将 `CACHELINE_OUT` 定义为 output-cache 一致性目标，并把
`CACHELINE_ATOMIC` 标为保留/不支持；不要把 `DcciDst.atomic` 当作 A2 的普通
输出策略。DMA datamove 会直接访问 GM，所以应只在 scalar/DCache 一致性
边界使用 DCCI，而不是包住每次 DMA。

参考：[Huawei DataCacheCleanAndInvalid API](https://www.hiascend.com/document/detail/zh/canncommercial/850/API/ascendcopapi/atlasascendc_api_07_0177.html)。

其中 dtype 来自 `dst.dtype`，最后一个实参是 `dst` 对应的 GM tensor lowering 表达式。

`mode` 参数用于控制 backend 调用会生成到哪一侧 split 代码里：

- `mode="all"`：同时生成到 cube 和 vec 两侧
- `mode="vec"`：只生成到 vec 侧
- `mode="cube"`：只生成到 cube 侧

### 在模拟器模式下做什么

模拟器会完全忽略 `clean_dcache`：

- 不会改写 tensor 载荷
- 不会改变调度
- 不会模拟 cache 状态

因此目前 `clean_dcache` 是一个只在 codegen 中生效的 helper。

### 常见用途

- 桥接 DSL 需要显式调用的后端 cache 维护原语
- 用 `EntireType.single` 或 `EntireType.entire` 选择 cache-line 作用范围
- 用 `DcciDst.all`、`DcciDst.ub`、`DcciDst.out`、`DcciDst.atomic` 选择目标策略
- A2 输出同步优先使用 `DcciDst.out`；`DcciDst.atomic` 不是受支持的普通目标

## 7. `set_hf32(enable=True)`

- 作用：为 fp32 cube matmul 路径发射后端 HF32 模式开关。
- 参数：
  - `enable`：`bool`，默认值为 `True`
- 校验：
  - `enable` 必须是 `bool`
- 指令发射：
  - 会发射 `Instruction("set_hf32", enable=enable)`

### 在 codegen 模式下做什么

parser lowering 会生成：

```text
SetHF32Mode(true);
```

或者：

```text
SetHF32Mode(false);
```

HF32 会在硬件上开启一种特殊的 fp32 格式。它可以加速 fp32 matmul 计算，但相比常规 fp32 模式会略微降低精度。

### 在模拟器模式下做什么

模拟器会完全忽略 `set_hf32`：

- 不会改变数值行为
- 不会改变调度
- 不会发射模拟器运行时指令

因此目前 `set_hf32` 是一个只在 codegen 中生效的硬件模式 helper。

## 8. 如何在它们之间选择

在下面这些情况下使用 `sim_print`：

- 你想要轻量级的模拟器日志输出
- 你关心的内容主要是标量或文本

在下面这些情况下使用 `sim_dump_tensor`：

- 你需要在模拟期间得到真实的运行时张量内容
- 你想用 `torch.load` 离线检查数据

在下面这些情况下使用 `kernel_print`：

- 你需要一行 `printf` 出现在生成后的 cube / vec 二进制里
- 模拟器路径可以忽略这条信息

在下面这些情况下使用 `kernel_dump_tensor`：

- 你需要后端的 `DumpTensor` 辅助在真实硬件上运行
- 模拟器路径可以忽略这次 dump

在下面这些情况下使用 `inline`：

- 你在 codegen 时需要一个后端逃生口
- DSL 目前还没有暴露你所需要的操作

在下面这些情况下使用 `clean_dcache`：

- 你需要在生成后的 kernel 里显式发出 cache clean/invalidate 调用
- 你希望这个调用保持结构化，而不是手写成 `inline`

在下面这些情况下使用 `set_hf32`：

- 你希望生成后的硬件代码开启或关闭更快的 HF32 fp32 matmul 模式
- 你可以接受这种特殊 fp32 格式带来的轻微精度损失

## 9. 也请参考 —— 在别处文档化的存储类辅助

下面这些 top-level 辅助同样由 `easyasc.a2` 与两个 A5 系列入口导出，
但它们操作的是 tensor 背后的存储，并不是调试 / codegen 逃生口，因此文档放在
[`tensor_buffer.md §2`](tensor_buffer.md) 里。

- [`reset_cache()`](tensor_buffer.md) —— 丢弃 kernel 当前的本地分配记账，让后续的 `Tensor(...)` 声明复用同一片片上区域。
- [`split_workspace(dtype, shape, name="")`](tensor_buffer.md) —— 从 kernel 自有的 workspace 区域里切出一段命名 GM workspace 切片，并以 `GMTensor` 形式返回。
- [`reinterpret(src, target_dtype, name="")`](tensor_buffer.md) —— 在同一块存储上构造一个 dtype 重解释的 `Tensor` 视图，按 dtype 打包系数缩放最内维。

## 10. 常见坑

- 不要期待 `sim_print` 或 `sim_dump_tensor` 出现在生成后的后端代码里；它们在 codegen 中的 handler 都是 no-op。
- 不要期待 `kernel_print` 或 `kernel_dump_tensor` 产生模拟器输出；模拟器会完全跳过它们。
- 不要期待 `inline` 改变模拟器行为；模拟器会明确忽略它。
- 不要期待 `clean_dcache` 改变模拟器结果；它在 simulation 中会被有意跳过。
- 不要期待 `set_hf32` 改变模拟器结果；它在 simulation 中会被有意跳过。
- 不要使用 `sim_dump_tensor(..., pipe=Pipe.ALL)`；dump 是单次执行动作，不是 all-pipe barrier。
- 不要依赖 `inline` 获得可移植行为；kernel scope 和 `@vf` micro scope 里的 inline 片段都会作为原始后端文本发射。
- 不要拿 `sim_print` 去打印大张量；它适合小型调试负载，真正要看张量内容请用 `sim_dump_tensor`。
- 不要把 `sim_print` 和 `kernel_print`、或者 `sim_dump_tensor` 和 `kernel_dump_tensor` 弄混。每一对里都有一个仅模拟器 / 仅 codegen 的成员，它们之间不能互换。
