# Tensor 与 Buffer 类型

本页说明 kernel 编写者在描述片上存储、GM 视图以及按槽位轮转的缓冲区时会用到的主要张量类对象。

这些类彼此关系很紧密：

- `Tensor`：二维片上 tensor，或片上 tensor 视图
- `GMTensor`：GM tensor，或 GM tensor 视图
- `GMTensorList`：dtype/rank 同构的 GM tensor 动态列表
- `DBuff`：双缓冲家族，可返回 `Tensor` 类型的槽位视图
- `TBuff`：三缓冲家族，可返回 `Tensor` 类型的槽位视图
- `QBuff`：四缓冲家族，可返回 `Tensor` 类型的槽位视图
- `Layout` / `LayoutType`：用于决定某些 `<<=` datamove 选择的布局提示

它们的实现位于 `easyasc/utils/Tensor.py`，因此很多在用户代码里看起来像“语法糖”的行为，实际上都是这些类通过 Python 运算符重载驱动出来的。

## 1. `Tensor`

### `Tensor(dtype, shape, position=Position.L1, name="", layout=Layout.DEFAULT)`

- 作用：表示一个位于 `L1`、`L0A`、`L0B`、`L0C`、`UB` 或 `BT` 的二维本地 tensor。
- 构造参数：
  - `dtype`：`DataTypeValue`
  - `shape`：二维形状，每一维都必须是 `int` 或 `Var`
  - `position`：本地内存位置
  - `name`：可选的显式 tensor 名称
  - `layout`：`LayoutType`；`Layout.DEFAULT` 会按位置解析（`L1/L0A/L0B/L0C` 默认 `NZ`，`UB/BT` 默认 `ND`）
- 运行时行为：
  - `shape` 的 rank 必须严格等于 `2`
  - 如果 `name=""`，运行时会自动生成一个临时名，例如 `_tmp_tensor_*`
  - 构造函数会把 `create_tensor` 发射到当前激活的 kernel 或当前激活的 micro module 中
- 重要的内部元数据：
  - `shape`：声明出来的逻辑形状
  - `offset`：当前视图在每个维度上的偏移
  - `span`：当前可见视图的尺寸
  - `step`：当前每个维度的步长，目前始终为 `1`
  - `source_buf` / `source_index`：当这个 tensor 是 `DBuff`、`TBuff` 或 `QBuff` 的槽位视图时会被填入
  - `is_transpose`：标记这是否是一个 L1 转置视图
  - `_layout`：解析后的布局提示（`Layout.NZ` 或 `Layout.ND`）
  - `vec_copy_mode`：标记特殊的 UB<->Reg 载入/存储布局，例如 `single()` 或 `unpack()`

示例：

```python
ub = Tensor(DT.float, [M, N], Position.UB)
l1 = Tensor(DT.half, [128, K], Position.L1)
```

### `LayoutType` 与 `Layout`

- 作用：描述一个 tensor 视图在 DSL 层应该按什么布局提示参与 datamove 分发。
- 可用成员：
  - `Layout.DEFAULT`：构造时按位置解析的哨兵值
  - `Layout.NZ`：cube 分形布局提示
  - `Layout.ND`：连续布局提示
- 重要说明：
  - 这是 DSL 分发提示，不会作为运行时字段一路传进生成代码或 simulator task
  - 它会影响某些 `<<=` 选择哪个 helper

默认解析规则：

- `L1`、`L0A`、`L0B`、`L0C` -> `Layout.NZ`
- `UB`、`BT` -> `Layout.ND`

示例：

```python
l1_bias = Tensor(DT.float, [1, N], Position.L1, layout=Layout.ND)
```

### `set_shape(shape)`

- 作用：更新已有 tensor 对象的逻辑形状和当前 span。
- 参数：
  - `shape`：二维 `list` 或 `tuple`
- 限制：
  - rank 仍然必须严格等于 `2`
- 行为：
  - 同时更新 `shape` 与 `span`
  - 它本身不会发射新的指令
- 常见用途：
  - 在 `l1_to_l0` 之前做内部形状调整
  - 更偏向高级 helper 的内部使用，而不是用户第一时间直接调用的 API

### `.T`

- 作用：创建一个 L1 转置视图，而不分配新的 tensor。
- 限制：
  - 仅当 `position is Position.L1` 时有效
- 行为：
  - 返回一个浅拷贝视图
  - 设置 `is_transpose=True`
  - 不会发射 `create_tensor`
  - 真正的“按转置解释”会在后续 `l1_to_l0`、`mmad`、parser lowering 和 simulator 执行时被消费

示例：

```python
l0a <<= l1x.T
```

### `.nz()`

- 作用：返回一个 layout hint 为 `Layout.NZ` 的浅拷贝 tensor 视图。
- 行为：
  - 返回一个浅拷贝视图
  - 设置 `_layout=Layout.NZ`
  - 该提示会在 `Tensor.__ilshift__` 处理 `UB -> L1` 拷贝时起作用
- 效果：
  - `l1 <<= ub.nz()` 会走 `ub_to_l1_nz`
  - `l1 <<= ub` 会走 `ub_to_l1_nd2nz`

示例：

```python
l1 <<= ub_packed.nz()
```

### `.nd()`

- 作用：返回一个 layout hint 为 `Layout.ND` 的浅拷贝 tensor 视图。
- 行为：
  - 返回一个浅拷贝视图
  - 设置 `_layout=Layout.ND`
- 常见效果：
  - 对 `L1` tensor，`layout=Layout.ND` 或 `.nd()` 会选择连续 GM->L1 路径，而不是 `gm_to_l1_nd2nz`

示例：

```python
l1_bias_nd = l1_bias.nd()
```

### `reinterpret(target_dtype, name="")`

- 作用：在同一块底层存储上创建一个“按另一种 dtype 解释”的 tensor 视图。
- 参数：
  - `target_dtype`：目标 `DataTypeValue`
  - `name`：可选的视图名
- 限制：
  - 源对象必须是 `Tensor`
  - 不支持 `L0C` tensor
- 行为：
  - 保留 `offset`、`source_buf`、转置状态等存储/视图元数据
  - 按照 `target_dtype.C0 / src.dtype.C0` 的比例重缩放 `shape` 和 `span` 的第二维
  - 在 kernel 上下文里发射一条 `reinterpret` 指令
- 实际含义：
  - `reinterpret` 是布局级别的“换视角”，不是数值类型转换
  - 当底层打包数据不变、只是想用另一种元素类型去读同一块存储时，用它
- 与顶层 helper 的关系：
  - `tensor.reinterpret(...)` 只是 `reinterpret(tensor, ...)` 的一个薄封装
  - 两种写法最终都会发射相同的 `reinterpret` 指令，并创建同一种视图

示例：

```python
ub_u8 = ub_fp16.reinterpret(DT.uint8)
```

### `dst <<= other`

`Tensor.__ilshift__` 是 DSL 最核心的分发点之一。最终会选择哪条指令，取决于目标 tensor 的位置，以及 `other` 在运行时的类型。

#### `Tensor <<= VecOP`

- 作用：把一个 vec 表达式实体化到 UB 目标 tensor 中。
- 限制：
  - 目标必须是 `Position.UB`
- 行为：
  - 调用 `VecOP.emit(dst)`

示例：

```python
dst <<= src.abs() + 1.0
```

#### `Tensor <<= GMTensor`

- 作用：把 GM 数据加载到本地存储中。
- 支持的路径：
  - `UB <<= GMTensor` -> `gm_to_ub_pad`
  - `L1 <<= GMTensor` 且 `Layout.NZ` -> `gm_to_l1_nd2nz`
  - `L1 <<= GMTensor` 且 `Layout.ND` -> 连续 GM->L1（A2 走 `gm_to_l1`，A5/A5PR 走 `gm_to_l1_pad`）
- 限制：
  - 目标必须是 `UB` 或 `L1`

示例：

```python
ub <<= x_gm[mb:mb + 128, kb:kb + 128]
l1 <<= x_gm[mb:mb + 128, kb:kb + 128]
```

#### `Tensor <<= Tensor`

- 作用：在不同本地内存域之间搬运数据。
- 支持的路径：
  - `UB <<= UB` -> `ub_to_ub`
  - `L1 <<= UB` 且 `src._layout is Layout.ND` -> `ub_to_l1_nd2nz`
  - `L1 <<= UB.nz()` 或 `src._layout is Layout.NZ` -> `ub_to_l1_nz`
  - `L1 <<= L0C` -> `l0c_to_l1`
  - `UB <<= L0C` -> `l0c_to_ub`
  - `BT <<= L1` -> `l1_to_bt`
  - `L0A/L0B <<= L1` -> `l1_to_l0`
- 对于 `L0A/L0B <<= L1` 的附加行为：
  - 目标 tensor 的 `shape` 会被更新为源视图的 `span`
  - 如果目标 tensor 本身来自同 dtype 的 buffer 家族，则父 buffer 的形状也会被一并更新
  - 转置状态会沿着 `l1_to_l0` 继续传递
- 限制：
  - 不支持的位置组合会直接报错

示例：

```python
l0a <<= l1a
ub_out <<= l0c
l1_mid <<= ub_mid.nz()
```

#### `Tensor <<= Reg`

- 作用：把一个 micro 寄存器写入 UB。
- 范围：
  - 主要是 A5 micro 侧的便利路径
- 行为：
  - 如果 `dst.dtype == src.dtype`，直接发射普通的 `reg_to_ub`
  - 如果 dtype 不同，运行时会先分配一个临时寄存器，把值 cast 到目标 dtype，再根据宽度关系选择：
    - `4-byte -> 1-byte` 走 `reg_to_ub_pack4`
    - `4-byte -> 2-byte` 或 `2-byte -> 1-byte` 走 `reg_to_ub_downsample`
    - 其他情况走普通 `reg_to_ub`
- 限制：
  - 带 cast 的寄存器写回必须发生在激活的 `@vf` 上下文里

示例：

```python
ub_dst <<= reg_f32.astype(DT.half)
```

#### `Tensor <<= RegList`

- 作用：把按“行”组织的一组寄存器写入 UB。
- 行为：
  - 会把每个寄存器写入目标 tensor 中一个连续的 block 大小切片
  - block 大小是 `256 // dtype.size`

示例：

```python
ub_rows <<= reg_rows
```

#### `Tensor <<= RegOP`

- 作用：把寄存器表达式，或者显式的 reg-to-UB 数据搬运操作，实体化到 UB 中。
- 行为：
  - 类似 `reg_to_ub_scatter` 这种直接属于 reg-to-UB 的操作会直接发射
  - 其他寄存器表达式会先求值到临时寄存器，再通过 `reg_to_ub` 写回

### 复制模式视图 helper

这些方法本身不搬运数据。它们只是返回一个带有 `vec_copy_mode` 标记的浅拷贝 tensor 视图。后续在 `Reg <<= tensor_view` 或相关的 micro store/load 逻辑里，运行时会根据这个标记选择不同的数据通路。

#### `downsample()`

- 把这个 tensor 视图标记为“窄通道载入”语义。
- 常见效果：
  - `reg <<= ub.downsample()` 会路由到 `ub_to_reg_downsample`

#### `upsample()`

- 把这个 tensor 视图标记为“扩宽通道载入”语义。
- 常见效果：
  - `reg <<= ub.upsample()` 会路由到 `ub_to_reg_upsample`

#### `unpack()`

- 把这个 tensor 视图标记为“两路 unpack 载入”语义。
- 常见效果：
  - `reg <<= ub.unpack()` 会路由到 `ub_to_reg_unpack`

#### `unpack4()`

- 把这个 tensor 视图标记为“四路 unpack 载入”语义。
- 常见效果：
  - `reg <<= ub.unpack4()` 会路由到 `ub_to_reg_unpack4`

#### `brcb()`

- 把这个 tensor 视图标记为 BRCB 风格的标量广播载入语义。
- 常见效果：
  - `reg <<= ub.brcb()` 会路由到 `ub_to_reg_brcb`

#### `single()`

- 把这个 tensor 视图标记为“提取单个标量”的语义。
- 常见效果：
  - `reg <<= ub[0:1, col:col + 1].single()` 会路由到 `ub_to_reg_single`

示例：

```python
scalar_reg <<= y_ub[row:row + 1, 0:1].single()
```

### Vec 表达式构造入口

`Tensor` 也是 A2 vec 表达式的主要入口。

- 算术运算符：
  - `a + b`、`a - b`、`a * b`、`a / b`
- 标量形式：
  - `a + 1.0`、`a * alpha`
- 一元 helper：
  - `.exp()`、`.ln()`、`.abs()`、`.rec()`、`.sqrt()`、`.rsqrt()`、`.relu()`、`.vnot()`
- 组归约：
  - `.cmax()`、`.cgmax()`、`.cmin()`、`.cgmin()`、`.cadd()`、`.cgadd()`、`.cpadd()`
- 其他 helper：
  - `.cast()`
  - `.maximum(other)`
  - `.minimum(other)`
  - 按位风格的 `.__and__(other)` / `.__or__(other)`

限制：

- 这些构造器只对 `UB` tensor 有效
- 它们返回的是 `VecOP` 对象；只有在被赋值，或被传给某个 vec API 时才会真正执行

关于这些 vec 运算的数值语义，请参考 [a2_vec_math.md](a2_vec_math.md)。

### `tensor[index]`

- 作用：创建一个更新了 `offset` 和 `span` 的 tensor 视图。
- 支持的索引形式：
  - 按维度给出的 slice 元组，也就是常规二维切片
  - 单个 `int` 或 `Var`，这是一种特殊简写，表示“只平移最后一维的基址偏移”
- 限制：
  - 切片后的 rank 仍然必须和原 tensor 的 rank 一致
  - slice 的 `step` 必须是 `None` 或 `1`
- 行为：
  - 返回一个新的 tensor 视图
  - 保留 `source_buf`、`source_index`、转置状态以及 layout hint
  - 在 kernel 上下文里发射 `slice_tensor`，在 micro 上下文里发射 `micro_slice_tensor`

一个很重要的特殊情况：

- `tensor[k]` 不会降维
- 它会保留原来的二维形状，只是把最后一维的基址偏移向后平移 `k`

正因为如此，下面这种按“行块”写回的模式才成立：

```python
dst[block * i] <<= regs[i]
```

普通切片示例：

```python
tile = ub[row0:row1, col0:col1]
```

## 2. Tensor 存储辅助函数

这些 helper 也会操作 tensor 背后的存储，不过它们以顶层函数的形式暴露，因为要么会分配 GM workspace，要么会影响 kernel 的本地分配状态。

### `reinterpret(src, target_dtype, name="")`

- 作用：在同一块底层存储之上构造一个新的 `Tensor` 视图，只是按另一种 dtype 去解释每个元素。
- 参数：
  - `src`：源 `Tensor`
  - `target_dtype`：目标 `DataTypeValue`
  - `name`：可选视图名
- 限制：
  - `src` 必须是 `Tensor`
  - `target_dtype` 必须是 `DataTypeValue`
  - `src.position` 不能是 `Position.L0C`
  - 这条 reinterpret 路径假设当前视图是二维 tensor
- 会改变什么：
  - 返回的 tensor 会保留相同的物理存储、`offset`、`step`、`source_buf`、`source_index`、转置标记以及 layout hint
  - 只有逻辑 dtype，以及 `shape` / `span` 的第二维会被重缩放
- 宽度重缩放规则：
  - 代码使用 dtype 的打包因子 `C0`
  - `dst_cols = src_cols * target_dtype.C0 / src.dtype.C0`
  - 对 `span[1]` 也应用同样的公式
  - 如果维度里包含符号量 `Var`，DSL 会发射 `var_mul` / `var_div` 一类表达式，而不是在 Python 端直接折叠成整数
- 为什么是第二维变化：
  - 本地 tensor 被视为二维视图，其中内层维携带打包后的 lane 宽度
  - `reinterpret` 会按目标 dtype 的 `C0` 保持打包 lane footprint 一致
- simulator 校验：
  - simulator 执行时会根据源视图字节数重新计算目标视图应有的 span
  - 如果重缩放后的视图不能严格保持字节数一致，会直接失败，而不是静默截断
  - simulator 还会检查源视图是否足够连续，以及用户给出的 `dst_shape` 元数据是否和预期重缩放结果一致
- codegen lowering：
  - parser lowering 会把它映射成 `src.ReinterpretCast<dst_dtype>()`
  - 这里本身不发生数据搬运；后续读写只是用另一种元素类型去解释同一块字节
- 和 `cast` 的区别：
  - `reinterpret` 只改视图
  - `cast` 会产生数值转换后的新值
- 常见用途：
  - 用更窄的标量类型查看一块打包 buffer
  - 把同一块 UB/L1 分配交给另一类指令族，以其期望的 dtype 视图继续使用
  - 在更换解释方式的同时，保留槽位 buffer 的元数据

示例：`half -> uint8`

```python
ub_fp16 = Tensor(DT.half, [4, 16], Position.UB)
ub_u8 = reinterpret(ub_fp16, DT.uint8, name="ub_u8")
```

得到的逻辑视图：

- 源 `C0 = 16`，目标 `C0 = 32`
- 因此目标列数变成 `16 * 32 / 16 = 32`
- `ub_u8` 会把同一块存储看作形状 `[4, 32]`

示例：保留 buffer 槽位元数据

```python
ub_ring = DBuff(DT.half, [4, 16], Position.UB)
slot = ub_ring[stage]
slot_u8 = slot.reinterpret(DT.uint8)
```

实际效果：

- `slot_u8.source_buf is ub_ring`
- `slot_u8.source_index is stage`
- autosync 与 simulator 记账仍然知道这个视图来自哪个逻辑槽位

### `split_workspace(dtype, shape, name="")`

- 作用：从 kernel 自带的 workspace 区域中切出一个具名的 GM workspace 切片，并将其暴露为一个 `GMTensor`。
- 参数：
  - `dtype`：workspace 元素 dtype
  - `shape`：workspace tensor 形状
  - `name`：可选的显式 workspace tensor 名称
- 限制：
  - 主要用于 kernel 上下文
  - `dtype` 必须是 `DataTypeValue`
  - `shape` 中每一项都必须是 `int` 或 `Var`
- 高层模型：
  - kernel 只有一个传入的 workspace 基址指针
  - 每次调用 `split_workspace(...)`，都会从这个基址之后继续切走一段连续区域
  - 返回的 `GMTensor` 只是这段区域上的一个带类型视图
- DSL 记账行为：
  - helper 会计算 `numel`，即所有 shape 维度的乘积
  - 在 kernel 上下文里，它会把声明的 `shape` 追加到 `active_kernel.workspace_shapes`
  - 同时发射一条携带 `dtype`、`numel` 和 tensor 名称的 `split_workspace` 指令
- codegen lowering：
  - lowering 会通过 `shiftAddr<dtype>(workspace, numel, offset)` 推进 workspace 指针
  - 然后把一个 `GlobalTensor<dtype>` 视图绑定到这个新地址上
  - 换句话说，生成代码时做的是“指针切片”，而不是向 GM 发起一次分配系统调用
- simulator 行为：
  - simulator 会按 workspace 名称分配或复用一块底层 tensor
  - 如果再次遇到同名 workspace，则 dtype、shape 和 `numel` 必须完全一致
  - 当前 simulator 支持路径期望最终 workspace 视图是 rank-2，即便 Python 侧 helper 接受更一般的 shape
- 适合什么场景：
  - cube/vec 阶段之间的 GM 中转
  - 太大、放不进片上存储的临时输出
  - kernel 除显式输入/输出外，还需要持久化的 GM 临时区域
- 不适合什么场景：
  - 已经在 kernel 签名里出现的常规输入/输出
  - 临时片上存储，这种情况应使用 `Tensor`、`DBuff` 或 `TBuff`

示例：

```python
workspace_tile = split_workspace(DT.float, [M, N], name="workspace_tile")
workspace_tile <<= ub_partial
```

概念上的效果：

- 如果这是 kernel 中第一次切 workspace，那么 `workspace_tile` 指向 workspace 的起始地址
- 下一次 `split_workspace(...)` 会从 `M * N` 个 float 元素之后继续开始

示例：两个独立命名的 workspace

```python
tmp_a = split_workspace(DT.float, [M, N], name="tmp_a")
tmp_b = split_workspace(DT.float, [M, N], name="tmp_b")
```

实际效果：

- `tmp_a` 和 `tmp_b` 指向的是不同的 GM 区域
- simulator 会因为名字不同而分别追踪它们的内容

### `reset_cache()`

- 作用：在后续本地 tensor 创建或复用之前，重置 kernel 的本地分配/缓存状态。
- 参数：
  - 无
- 限制：
  - 只有在 kernel 上下文里才有实际意义
- 这里说的“cache”指什么：
  - 它不会刷新 GM，也不会清空 tensor 载荷数据
  - 它重置的是 DSL/runtime 用来跟踪本地内存分配偏移，以及本地 slice 上下文缓存的状态
- DSL 行为：
  - 在 kernel 上下文里会发射 `reset_cache`
- codegen lowering：
  - parser lowering 会先生成 `pipe_ptr->Reset();`，随后再生成 `OccupyMMTE1Events();`
  - 写出 kernel 头文件时，只有自动插入前导里的那一对会被保留并改写成 `// pipe_ptr->Reset();` 和 `// OccupyMMTE1Events();`
  - 用户自己写的 `reset_cache()` 在生成 body 里仍保持原始 helper 调用
  - 这意味着之后的本地分配会从一个全新的 pipeline 管理状态开始
- simulator 行为：
  - 会把各个 position 的本地分配偏移重置为 `0`
  - 同时清掉缓存的本地 slice-context 记录
  - 已有的 Python tensor 对象仍然存在，但之后的新分配会像从头开始布局一样运行
- 为什么需要它：
  - 有些 kernel 希望把本地分配分阶段使用，完成一个阶段后重启布局，而不是让本地 offset 一路单调增长
  - 对那些流程很长、但不同阶段复用相同片上占用的 kernel 尤其有意义
- 它不会做什么：
  - 不会改写 GM tensor
  - 不会在 simulator 中把 UB/L1/L0 的数值清零
  - 不会替代显式同步；它只重置分配/缓存记账

示例：

```python
stage0_ub = Tensor(DT.float, [64, 64], Position.UB)
# ... stage 0 work ...
reset_cache()
stage1_ub = Tensor(DT.float, [64, 64], Position.UB)
```

实际含义：

- 调用 `reset_cache()` 之后，第二个 `Tensor(...)` 可以复用 stage 0 已占用过的本地分配区域
- 如果不调用它，后面的分配会在之前的累计 offset 基础上继续往后排

## 3. `GMTensor`

### `GMTensor(dtype, shape, name="")`

- 作用：表示 kernel 签名中的 GM tensor、返回值 tensor，或者 workspace 切分出来的 tensor。
- 构造参数：
  - `dtype`：`DataTypeValue`
  - `shape`：由 `int` 或 `Var` 组成的形状
  - `name`：可选 tensor 名称
- 运行时行为：
  - 和 `Tensor` 不同，`shape` 不要求必须是二维
  - 构造函数会在 kernel 上下文里发射 `create_gm_tensor`
- 重要的内部元数据：
  - `offset`、`span`、`step`：当前 GM 视图的元数据
  - `slice_mask`：标记哪些维度是通过 `slice` 语法切出来的
  - `_mutex`：可选的绑定 `CvMutex` 或 `VcMutex`
  - `data`：由 `OpExec` 挂上的 simulator/runtime 载荷

示例：

```python
@kernel()
def my_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    return z
```

### `bind_cv_mutex(...)`

- 作用：给这个 GM tensor 绑定一个 cube 生产、vec 消费的 mutex。
- 参数：
  - `flag_id`、`depth`、`src_start_pipe`、`dst_start_pipe`、`src_end_pipe`、`dst_end_pipe`
- 行为：
  - 构造一个 `CvMutex`
  - 保存到 `self._mutex`
  - 并返回这个 mutex 对象
- 常见用途：
  - 把某个逻辑 GM 输出，或某个中转对象，和显式的跨侧 ownership 调用绑定起来
- 延伸阅读：
  - 完整的 `CvMutex` token 模型和示例请见 [synchronize.md](synchronize.md)

### `bind_vc_mutex(...)`

- 作用：给这个 GM tensor 绑定一个 vec 生产、cube 消费的 mutex。
- 参数：
  - 语义上与 `bind_cv_mutex` 相同
- 行为：
  - 构造一个 `VcMutex`
  - 保存到 `self._mutex`
  - 并返回这个 mutex 对象
- 延伸阅读：
  - 完整的 `VcMutex` token 模型和示例请见 [synchronize.md](synchronize.md)

### `lock()`、`ready()`、`wait()`、`free()`

- 作用：把同步调用转发给已绑定的 mutex。
- 限制：
  - 必须先绑定一个 mutex
- 行为：
  - `lock()`：生产者等待一个可复用槽位
  - `ready()`：生产者发布一个已经写满的槽位
  - `wait()`：消费者等待生产者
  - `free()`：消费者归还槽位

示例：

```python
z.bind_cv_mutex(0)
z.lock()
z.ready()
z.wait()
z.free()
```

### `dst_gm <<= src_tensor`

- 作用：把一个本地 tensor 写回到 GM。
- 支持的路径：
  - `GMTensor <<= UB Tensor` -> `ub_to_gm_pad`
  - `GMTensor <<= L0C Tensor` -> `l0c_to_gm_nz2nd`
- 限制：
  - 源必须在 `UB` 或 `L0C`

示例：

```python
z <<= ub_out
z <<= l0c_out
```

### `gmtensor[index]`

- 作用：创建一个 N 维 GM 视图。
- 每一维支持的索引：
  - `int`
  - `Var`
  - `slice`
- 限制：
  - 索引的 rank 必须和 GM tensor 的 rank 一致
  - 最多只能有两个维度使用 `slice`
  - slice 的 `step` 必须是 `None` 或 `1`
- 行为：
  - 返回一个新的 `GMTensor` 视图
  - `int` / `Var` 维会退化成 `span=1` 的维度
  - 使用 `slice` 的维度会记录到 `slice_mask`
  - 绑定的 mutex 与 simulator 数据载荷会被保留
  - 会发射 `slice_gm_tensor`

这正是 rank-3 或 rank-4 的 GM tensor 能被后续 lower 成二维搬运 helper 的原因，因为系统可以默认推断出一段连续切片。

示例：

```python
tile = x[b, h, m0:m1, k0:k1]
```

### `gmtensor[index] = value`

- 作用：给 GM 目标提供切片赋值的便利写法。
- 支持的值：
  - 位于 `L0C` 的 `Tensor`
  - `GMTensor`
- 行为：
  - `dst_slice = gm[...]`
  - 如果赋值源是 `l0c_tensor`，则发射 `l0c_to_gm_nz2nd`
  - 从另一个 `GMTensor` 赋值时，只是接受这种 Python 语法形式，实际是 no-op 占位

示例：

```python
z[m0:m1, n0:n1] = l0c_tile
```

## 3.5. `GMTensorList`

### `GMTensorList(dtype, item_shape, length=None, name="", items=None)`

- 作用：表示一个动态列表，列表成员的 dtype 和 rank 相同。
- 构造参数：
  - `dtype`：列表成员的元素 dtype
  - `item_shape`：trace 阶段使用的成员原型形状，由 `int` 或 `Var` 组成
  - `length`：可选的静态长度提示
  - `name`：可选的列表参数名
  - `items`：可选的具体 `GMTensor` 成员列表，用于直接 DSL 绑定以及 `OpExec`
- 运行时模型：
  - 所有成员必须有相同 dtype 和 rank
  - 不同成员的具体维度大小可以不同
  - `item_shape` 提供 trace 所需的原型 rank 和 shape 提示；如果 kernel
    需要依赖某个成员的实际范围，应使用 `.item_numel(index)`
  - `OpExec` 会拒绝空 Python list/tuple
  - kernel 内的列表长度是动态值；要使用 `.size()`，不要用 `len(xs)`
- 常见用途：
  - AddN 这类算子的公开 kernel 输入
  - 当 `GMTensorList` 参数被 kernel 返回时，表示调用者预分配的动态输出列表
  - 循环次数等于运行时列表成员数量的场景

示例：

```python
@kernel(mode="vec")
def addn_tensor_list_kernel(xs: GMTensorList, y: GMTensor, n: Var):
    acc_ub = Tensor(xs.dtype, [1, 2048], Position.UB)
    tmp_ub = Tensor(xs.dtype, [1, 2048], Position.UB)

    input_count = xs.size()
    first = xs[0]
    for item_idx in range(1, input_count):
        item = xs[item_idx]
        # item behaves like a normal GMTensor.
        # It can be sliced and loaded like any other GMTensor.
```

完整可运行示例见 `agent/example/kernels/a2/vec_only/addn_tensor_list.py`。

### `.size()`

- 作用：以 `Var` 形式返回运行时列表长度。
- 行为：
  - 在 kernel 上下文里发射 `tensorlist_size` 指令
  - 返回值可以作为循环边界
  - 同一个列表重复调用 `.size()` 会复用缓存的 `Var` 对象
- 生成的 C++：

```cpp
ListTensorDesc xs_desc((__gm__ void*) xs_);
int xs_size = static_cast<int32_t>(xs_desc.GetSize());
```

这对应 `AscendC::ListTensorDesc::GetSize()`。

真机注意：simulator 和 codegen 支持这条 lowering，但当前 A2 ACLNN
TensorList-output smoke 路径是用显式 `item_count` 标量完成真机多 item 验证的，
没有依赖 `.size()`。这次验证中，`.size()`/`GetSize()` 只驱动了 item0；
改为单独传入 `item_count` 后，`GetDataPtr<T>(item_idx)` 对所有输出 item 都能正常写回。
硬件多 item 输出示例见 `agent/example/kernels/a2/vec_only/tensor_list_output_copy.py`。

### `.item_numel(index)`

- 作用：以 `DT.int` `Var` 形式返回某个成员运行时的元素总数。
- 支持的索引：
  - 非负 `int`
  - `Var`
- 行为：
  - 在 kernel 上下文中发射 `tensorlist_item_numel`
  - 从 `ListTensorDesc` 解析所选成员的运行时 shape
  - 按原型 rank 将各维相乘
  - 只有显式调用时才解析 descriptor，因此现有等 shape TensorList
    kernel 不会增加额外开销

对于异长成员，应先用这个运行时范围 reshape 指针视图，再据此生成切片和
datamove stride：

```python
for item_idx in range(item_count):
    n = xs.item_numel(item_idx)
    item = xs[item_idx].reshape([1, n])
```

生成的 C++：

```cpp
uint64_t item_shape[2] = {};
TensorDesc<half> item_desc;
item_desc.SetShapeAddr(item_shape);
xs_desc.GetDesc(item_desc, item_idx);
int n = static_cast<int32_t>(
    item_desc.GetShape(0) * item_desc.GetShape(1));
```

返回值按 `int32` 范围表示。可能接收更大 tensor 的 host 集成必须在 launch
前拒绝元素总数超过 `INT32_MAX` 的成员。

### `xs[index]`

- 作用：把列表里的一个成员实体化成 `GMTensor`。
- 支持的索引：
  - 非负 `int`
  - `Var`
- 行为：
  - 返回一个 `GMTensor`，其 `dtype == xs.dtype` 且 `shape == xs.item_shape`
  - 这里的 `shape` 是 trace 阶段原型；异长成员应结合
    `.item_numel(index)` 和 `.reshape(...)` 后再做依赖 shape 的访问
  - 返回对象可以像普通 GM tensor 一样切片、加载或写回
  - 在 kernel 上下文里发射 `get_gm_tensor_list_item`
- 生成的 C++：

```cpp
GlobalTensor<half> item;
item.SetGlobalBuffer(xs_desc.GetDataPtr<half>(item_idx));
```

模板参数由列表成员 dtype 决定。

### Op-host 与 ACLNN 生成物

未被返回的 `GMTensorList` kernel 参数会在 op-host 定义中变成动态输入：

```cpp
this->Input("xs")
    .ParamType(DYNAMIC)
    .DataType({ge::DT_FLOAT16})
    .Format({ge::FORMAT_ND})
    .UnknownShapeFormat({ge::FORMAT_ND});
```

被返回的 `GMTensorList` kernel 参数会变成动态输出：

```cpp
this->Output("ys")
    .ParamType(DYNAMIC)
    .DataType({ge::DT_FLOAT16})
    .Format({ge::FORMAT_ND})
    .UnknownShapeFormat({ge::FORMAT_ND});
```

生成的 ACLNN smoke test 会从普通 ACL tensor 构造 `aclTensorList`。输出列表成员由调用者预分配，作为 `aclTensorList` 传入，op 执行后逐个保存：

```cpp
std::vector<const aclTensor*> xs_acl_items = {
    xs_item0_acl, xs_item1_acl, xs_item2_acl, xs_item3_acl
};
aclTensorList* xs_acl =
    aclCreateTensorList(xs_acl_items.data(), xs_acl_items.size());

std::vector<const aclTensor*> ys_acl_items = {
    ys_item0_acl, ys_item1_acl, ys_item2_acl, ys_item3_acl
};
aclTensorList* ys_acl =
    aclCreateTensorList(ys_acl_items.data(), ys_acl_items.size());

EXECOP(aclnnCopyTensorListKernel, stream, xs_acl, n, item_count, ys_acl);

ys_item0.copyToHost();
ys_item0.saveHostToBinFile("output/output_ys_item0.bin");
aclDestroyTensorList(xs_acl);
aclDestroyTensorList(ys_acl);
```

### 当前限制

- `generate_debug(...)` 暂不支持 `GMTensorList`。真机运行时请走普通生成的
  ACLNN/custom-op 路径，即 `OpExec(..., simulator=False, debug=False)`。
- 当前支持的列表要求 dtype 和 rank 同构，但不同成员的具体维度可以不同。
- TensorList 输出是预分配输出列表：运行时调用者传入一个非空 Python
  `list`/`tuple` 输出 tensor，kernel 通过返回对应 `GMTensorList` 参数来标记它是输出。
- 对真机多 item TensorList-output 循环，在 ACLNN `ListTensorDesc::GetSize()` 路径验证/修复前，
  请显式传入 `item_count` 标量。

## 4. `DBuff`

### `DBuff(dtype, shape, position=Position.L1, name="", layout=Layout.DEFAULT)`

- 作用：表示一个逻辑上的双缓冲家族。
- 构造参数：
  - 风格与 `Tensor` 相同
- 限制：
  - `shape` 的 rank 必须严格等于 `2`
  - buffer 的创建发生在 kernel 侧，而不是 micro 侧
- 行为：
  - 构造函数会发射 `create_dbuf`
  - 这个 buffer 家族拥有两个逻辑槽位
  - 槽位视图会继承这个 buffer 解析后的 layout hint

示例：

```python
l1x = DBuff(DT.half, [128, K], Position.L1)
```

### `dbuf[index]`

- 作用：取出某个槽位，并把它作为普通 `Tensor` 视图返回。
- 参数：
  - `index`：`int` 或 `Var`
- 行为：
  - 返回的 `Tensor` 视图会带上：
    - `source_buf = dbuf`
    - `source_index = index`
  - 会发射 `get_buf`
  - 返回出来的 tensor 后续可以像普通 `Tensor` 一样继续切片、赋值、加载或消费

为什么这份元数据重要：

- autosync 分组会使用 `source_buf` 和 `source_index`
- simulator 中需要感知槽位的路径，也能从这个视图恢复逻辑槽位身份

示例：

```python
l1x[cnt] <<= x[m0:m1, k0:k1]
```

### `dbuf[index] = value`

- 作用：为 Python 的增量赋值语法提供兼容钩子。
- 参数：
  - `index`：`int` 或 `Var`
  - `value`：必须是 `Tensor`
- 关键行为：
  - 这个方法本身只做类型校验
  - 真正的 DSL 指令发射，早在 `dbuf[index]` 返回的 `Tensor` 视图上就已经完成了

理解这一点很重要，因为下面的写法之所以成立：

```python
dbuf[cnt] <<= src
```

Python 实际上的求值顺序是：

1. `slot = dbuf.__getitem__(cnt)`
2. `slot.__ilshift__(src)`
3. `dbuf.__setitem__(cnt, slot)`

也就是说，真正有意义的 DSL 动作发生在第 2 步。

### 槽位身份

- `DBuff` 表示一个双槽位家族
- 当 simulator 需要一个具体槽号时，会把运行时索引按 `2` 取模
- 但 DSL 层面仍会保留未取模的原始索引 token，用于同步键分组

## 5. `TBuff`

### `TBuff(dtype, shape, position=Position.L1, name="", layout=Layout.DEFAULT)`

- 作用：表示一个逻辑上的三缓冲家族。
- 构造参数：
  - 风格与 `Tensor` 相同
- 限制：
  - `shape` 的 rank 必须严格等于 `2`
  - buffer 的创建发生在 kernel 侧，而不是 micro 侧
- 行为：
  - 构造函数会发射 `create_tbuf`
  - 这个 buffer 家族拥有三个逻辑槽位
  - 槽位视图会继承这个 buffer 解析后的 layout hint

示例：

```python
ub_stage = TBuff(DT.float, [64, 64], Position.UB)
```

### `tbuff[index]`

- 作用：取出某个槽位，并把它作为普通 `Tensor` 视图返回。
- 参数：
  - `index`：`int` 或 `Var`
- 行为：
  - 视图机制与 `DBuff.__getitem__` 相同
  - 返回的 tensor 会记住 `source_buf = tbuff` 与 `source_index = index`
  - 会发射 `get_buf`

示例：

```python
tmp = ub_stage[stage]
```

### `tbuff[index] = value`

- 作用：为 Python 的增量赋值语法提供兼容钩子。
- 参数：
  - `index`：`int` 或 `Var`
  - `value`：必须是 `Tensor`
- 行为：
  - 和 `DBuff.__setitem__` 一样，只做校验，不会额外发射新指令

### 槽位身份

- `TBuff` 表示一个三槽位家族
- 当 simulator 需要具体槽号时，会把运行时索引按 `3` 取模
- DSL 层面仍保留原始索引 token，用于同步分组

## 5.5. `QBuff`

### `QBuff(dtype, shape, position=Position.L1, name="", layout=Layout.DEFAULT)`

- 作用：表示一个四槽位的缓冲家族。
- 构造参数：
  - 与 `Tensor` 风格一致
- 限制：
  - shape 的 rank 必须正好是 `2`
  - buffer 创建发生在 kernel 侧，不在 micro 侧
  - 不接受 `DT.int4` 和 `DT.fp4*`（`fp4_e2m1` / `fp4_e1m2`）；请使用对应 carrier dtype，详见 [`../topics/int4.md`](../topics/int4.md) 与 [`../topics/mxfp.md`](../topics/mxfp.md)
- 行为：
  - 构造函数发射 `create_qbuf`
  - 该家族拥有四个逻辑槽位
  - simulator bridge 会读取 `slot_count = 4` 来分配槽位数组
  - 槽位视图会继承这个 buffer 解析后的 layout hint

示例：

```python
ub_score_group = QBuff(DT.float, [ROW_CHUNK, TILE_N], Position.UB)
```

### `qbuff[index]`

- 作用：以普通 `Tensor` 的形式获取某个槽位视图。
- 参数：
  - `index`：`int` 或 `Var`
- 行为：
  - 视图机制和 `DBuff.__getitem__` / `TBuff.__getitem__` 一样
  - 返回的 tensor 会记住 `source_buf = qbuff` 与 `source_index = index`
  - 发射 `get_buf`

示例：

```python
slot = ub_score_group[stage]
```

### `qbuff[index] = value`

- 作用：与 Python 复合赋值兼容的 hook。
- 参数：
  - `index`：`int` 或 `Var`
  - `value`：必须是一个 `Tensor`
- 行为：
  - 与 `DBuff.__setitem__` / `TBuff.__setitem__` 一样：只校验，不会额外发射新指令

### 槽位身份

- `QBuff` 表示一个四槽位家族
- 当 simulator 需要具体槽号时，会把运行时索引按 `4` 取模（`pipe.py: slot_names[idx % len(slot_names)]`）
- DSL 层面仍保留原始索引 token，用于同步分组

### codegen 下沉

`create_qbuf` 下沉为：

```cpp
QBuff<<dtype>, <position>> <name>; <name>.Init(<numel>);
```

这与 `TBuff` 的下沉是镜像关系，`numel` 等于声明的各维度大小相乘。

### 什么时候用 `QBuff`

当调度自然需要四槽轮转，而不是两槽或三槽时，就用它。仓库里的参考使用集中在带 lookahead-3 预取的 attention kernel，例如：

- `agent/example/kernels/a2/attention/block32_causal/flash_attn_full_pj_half_block32_causal_v2.py`
- `agent/example/kernels/a2/attention/block32_causal/flash_attn_full_pj_half_block32_causal_v3.py`
- `agent/example/kernels/a2/attention/block32_causal/flash_attn_full_pj_half_block32_causal_v4.py`

## 6. 实际使用建议

- `Tensor` 适合表示具体的片上存储，以及片上视图。
- `GMTensor` 适合表示位于 GM 的 kernel 输入、输出，以及 workspace 视图。
- `GMTensorList` 适合表示动态的 dtype/rank 同构 GM tensor 列表；kernel
  内用 `.size()` 取得运行时成员数量，用 `.item_numel(idx)` 取得某个成员
  的运行时元素总数，用 `xs[idx]` 取得成员并按普通 `GMTensor` 使用。返回
  列表参数即可标记为预分配输出列表。
- 当生产者/消费者在两个槽位间来回切换时，用 `DBuff`。
- 当调度需要三槽位轮转，而不是双槽位轮转时，用 `TBuff`。
- 当调度需要四槽位轮转（比如 lookahead-3 的 attention 预取）时，用 `QBuff`。
- 当你需要在 L1 中保留连续行，而不是让它被 ND2NZ 分形化时，用 `layout=Layout.ND`，典型例子就是 matmul bias staging。
- 相比手动为每个槽位创建单独 tensor，更推荐写 `buf[idx] <<= ...`；buffer 家族上的元数据对 autosync 分组和 simulator 记账都很重要。
- 要记住：`Tensor` 和 `GMTensor` 的切片大多是通过维护 `offset` 与 `span` 来保留 rank，而不是创建一个真正“物理更小”的独立对象。
