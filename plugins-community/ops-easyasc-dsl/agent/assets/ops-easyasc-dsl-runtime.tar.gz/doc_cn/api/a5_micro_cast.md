# A5 Micro Cast

本页文档说明 A5 系列 facade（`easyasc.a5` 和 `easyasc.a5pr`）导出的
micro 侧 cast 辅助能力。

这里描述的行为基于以下实现：

- `easyasc/stub_functions/micro/cast.py` 中公开给用户使用的接口
- `easyasc/utils/reg.py` 里 `Reg` 提供的便捷方法
- `easyasc/simulator/pipe_micro.py` 中当前模拟器的实现
- `agent/example/testcases/simulator/micro/` 下当前的 micro 测试

本页的 `cast()` 操作和 `Reg` cast 表达式都有这些共同点：

- 要求处在激活的 `@vf` 上下文中
- 操作对象是 `Reg` 和 `MaskReg`
- 默认使用 `MaskMergeMode.ZEROING`；显式的 `MaskMergeMode.MERGING`
  config 会保留 cast 没有写入的目标 lane

类枚举 config 值可以在 `@vf` 外检查。`CastConfig` 自动注册和 cast 指令发射
只会发生在活跃的 micro 上下文中。

## 1. Cast 基础构件

### `RoundModeType`

- 作用：表示一个具体的 micro cast 舍入模式值。
- 常见用法：
  - 一般不需要手动构造它
  - 而是直接传 `RoundMode.*` 中预定义好的值

这个类本身很小，但它仍然重要，因为 `CastConfig` 会校验 `round_mode` 是否为 `RoundModeType`。

重要行为：

- `str(mode)` 会返回后端 token 名，例如 `CAST_RINT`
- `repr(mode)` 会返回 `RoundModeType('...')`
- 相等比较按模式名进行
- 如果拿它和非 `RoundModeType` 对象比较，会抛出 `TypeError`

示例：

```python
str(RoundMode.TO_EVEN)        # "CAST_RINT"
repr(RoundMode.FLOOR)         # "RoundModeType('CAST_FLOOR')"
RoundMode.CEIL == RoundMode.CEIL
```

实践规则：

- 使用预定义的 `RoundMode.*` 成员
- 不要把 `"CAST_RINT"` 这样的原始字符串直接传给 `CastConfig`

### `RoundMode`

- 作用：为预定义的 micro cast 舍入模式提供一个类似枚举的命名空间。
- 值类型：
  - 每个成员都是一个 `RoundModeType`

可用成员如下：

| 公开名称 | 后端 token | 期望含义 |
| --- | --- | --- |
| `RoundMode.NONE` | `CAST_NONE` | 不指定额外舍入策略 |
| `RoundMode.TO_EVEN` | `CAST_RINT` | 四舍六入五成双 |
| `RoundMode.AWAY_FROM_ZERO` | `CAST_ROUND` | 四舍五入，遇到 0.5 时朝远离零方向 |
| `RoundMode.FLOOR` | `CAST_FLOOR` | 向负无穷方向取整 |
| `RoundMode.CEIL` | `CAST_CEIL` | 向正无穷方向取整 |
| `RoundMode.TRUNC` | `CAST_TRUNC` | 朝零方向截断 |
| `RoundMode.ODD` | `CAST_ODD` | Von Neumann / round-to-odd，目前用于 `float -> half` |
| `RoundMode.HYBRID` | `CAST_HYBRID` | HiFloat8 混合 TA/SSR 转换，仅用于 `float/half -> hif8` |

这里说的“期望含义”是指：

- 这些模式会作为语义选项告诉后端 C++ trait
- 当 cast 需要丢弃精度或小数信息时，它们最重要
- 常见场景包括 `float -> float`、`float -> half`、`float -> bfloat16`、
  `half -> int8`、`int16_t -> half`，以及大整数上的 `int32_t`/`int64_t -> float`

什么时候 round mode 往往几乎看不出效果：

- 源值已经能被目标类型精确表示的宽化 cast，例如 `half -> float`

当前模拟器行为：

- 模拟器会在 `CastConfig` 中保留选中的 `RoundMode` 对象
- 浮点到整数的 cast 会针对 `TO_EVEN`、`FLOOR`、`CEIL`、`AWAY_FROM_ZERO`、`TRUNC` 和 `NONE` 分别处理
- `float -> float` 会按选中的 rounding mode 处理数值，并把整数值结果仍然存成 `float`
- `float -> half` 和 `float -> bfloat16` 会按目标浮点格式可表示值做舍入；其中 `float -> half` 也支持 `ODD`
- `int16_t -> half`、`int32_t -> float` 和 `int64_t -> float` 在整数不能被目标浮点格式精确表示时，也会按目标浮点格式可表示值做舍入
- `float/half -> hif8` 在模拟器里使用 host 侧的 hif8 codec；这些编码 cast 只支持 `CAST_ROUND` 和 `CAST_HYBRID`
- `hif8 -> float/half` 接受任意 round mode 值，但模拟器会忽略它，因为这是从低精度到高精度的解码
- `config.saturate=True` 会在转换前钳位；为 `False` 时仍然是在 rounding 后跟随 `torch.Tensor.to(dtype)` 行为

当前代码生成行为：

- 选中的模式会以 `RoundMode::{token}` 的形式写入生成出的 trait
- 例如，`RoundMode.TO_EVEN` 会变成 `RoundMode::CAST_RINT`

示例：

```python
cfg_floor = CastConfig(
    round_mode=RoundMode.FLOOR,
    reg_layout=RegLayout.ZERO,
    name="cfg_floor",
)
```

再例如：

```python
cfg_trunc = CastConfig(
    round_mode=RoundMode.TRUNC,
    reg_layout=RegLayout.ZERO,
    name="cfg_trunc",
)
```

### `MaskMergeMode`

- 作用：控制 cast 活跃写入集之外的目标 lane 如何处理。
- 可用值：
  - `MaskMergeMode.ZEROING`：先把目标清零，再写入活跃转换 lane。这是默认值
  - `MaskMergeMode.MERGING`：被 mask 屏蔽的 lane，以及位宽转换中未被
    `RegLayout` 选中的 slot，都保留目标寄存器的旧值
- 硬件限制：
  - A5 系列板端的 `MERGING` 只支持 `RegLayout.ZERO`；公开 stub 会在
    codegen 前拒绝 `ONE`、`TWO` 或 `THREE`
  - bfloat16 <-> FP4 cast 只支持 `ZEROING`
- 实用要求：使用 `MERGING` cast 前先初始化 `dst`；目标旧值是该操作
  输入合同的一部分

`MaskMergeMode` 值会作为 `MicroAPI::CastTrait` 的第三个字段发射。请直接
使用预定义成员，不要手工构造原始值。

### `CastConfig(round_mode=RoundMode.TO_EVEN, reg_layout=RegLayout.ZERO, saturate=False, name="", merge_mode=MaskMergeMode.ZEROING)`

- 作用：保存一次 micro cast 应使用的策略。
- 构造参数：
  - `round_mode`：请求的 `RoundMode`
  - `reg_layout`：当源和目标元素宽度不同时，应该从哪个逻辑槽位读取或写入
  - `saturate`：溢出时是否做钳位，而不是采用默认 dtype 转换行为
  - `name`：生成 C++ 时发射出去的符号名
  - `merge_mode`：活跃写入集之外的 lane 是清零，还是保留原有 `dst` 值

每个参数的含义：

- `round_mode`：
  - 必须是 `RoundModeType`
  - 指定附着到生成 cast trait 上的 `RoundMode.*` 策略
  - 会作为 `MicroAPI::CastTrait` 的一部分进入代码生成
  - 当前模拟器说明：
    - 浮点到整数 cast、`float -> float`、`float -> half`/`float -> bfloat16`，以及 `int16_t -> half`、`int32_t`/`int64_t -> float` 这类整数到浮点精度缩减 cast 会建模这些 round mode
    - 饱和行为仍由 `saturate` 标志控制
- `reg_layout`：
  - 只有当 `src.dtype.size != dst.dtype.size` 时才有意义
  - 用来决定每个 cast ratio 分组中采用哪个 slot
- `saturate`：
  - 当为 `False` 时，模拟器不会预先钳位；上面列出的有损精度 pair 仍然会走实现好的 `round_mode` 路径
  - 当为 `True` 时，模拟器会在转换前先做钳位
- `name`：
  - 到 `cast()` 发射指令时必须非空
  - 如果你在激活的 micro 内部构造 `CastConfig`，它会自动注册到当前 micro 中，并自动加上前缀
- `merge_mode`：
  - 必须是预定义的 `MaskMergeMode` 值
  - 默认为 `ZEROING`
  - `MERGING` 要求 `RegLayout.ZERO`，且不支持 bfloat16 <-> FP4

自动注册行为：

- 当在激活的 `@vf` 内部创建 `CastConfig` 时，它会被追加到 micro module 的 `cast_cfg_list`
- 代码生成时，这个列表会变成生成 C++ 中的 `MicroAPI::CastTrait` 定义
- 这也是为什么 config 名字需要稳定且唯一

示例：

```python
cfg_zero = CastConfig(
    round_mode=RoundMode.TO_EVEN,
    reg_layout=RegLayout.ZERO,
    saturate=False,
    name="cfg_zero",
    merge_mode=MaskMergeMode.ZEROING,
)
```

默认配置行为：

- `cast(..., config=None)` 会向当前 micro module 请求一个默认配置
- 在当前实现中，大多数目标类型会使用默认的 `RoundMode.TO_EVEN`
- 当前的特殊情况是 `Datatype.hif8`，它默认使用 `RoundMode.AWAY_FROM_ZERO`
- bfloat16 <-> FP4 使用专用默认值：encode 用 `RoundMode.TO_EVEN`，
  decode 用 `RoundMode.NONE`，两者都使用 `RegLayout.ZERO` 和
  `MaskMergeMode.ZEROING`
- `float -> hif8` 和 `half -> hif8` 只支持 `RoundMode.AWAY_FROM_ZERO` / `CAST_ROUND` 和 `RoundMode.HYBRID` / `CAST_HYBRID`；hybrid 情况下 codegen 会发射 `RoundMode::CAST_HYBRID`
- `hif8 -> float` 和 `hif8 -> half` 接受任意 round mode 值。模拟器在这些解码路径上会忽略该模式

这里特别提到 `Datatype.hif8`，是因为：

- micro module 内部维护了两个缓存的默认配置
- 通用默认值是 `RoundMode.TO_EVEN`
- `hif8` 会单独使用一个以 `RoundMode.AWAY_FROM_ZERO` 创建的缓存配置
- 这会影响 `cast(..., config=None)` 在这些目标类型上的实际含义

### `RegLayout`

- 作用：描述位宽转换分组中哪一个 slot 处于激活状态。
- 可选值：
  - `RegLayout.ZERO`
  - `RegLayout.ONE`
  - `RegLayout.TWO`
  - `RegLayout.THREE`

`RegLayout` 存在的原因：

- Micro 寄存器总是有固定的字节预算
- 当源和目标元素大小不同时，一个源 lane 并不会和一个目标 lane 一一对应
- 所以 cast 实际上是在按 ratio 大小的分组工作
- `RegLayout` 用来选择每个分组里要读或要写的那个 slot
- FP4 是没有可寻址字节大小的 packed compute-view dtype；bfloat16 <-> FP4
  使用下面单独说明的四 slot carrier 映射

当前合法 slot 规则：

| Cast ratio | 含义 | 合法 layout |
| --- | --- | --- |
| `1` | 同宽 cast | 目前所有 layout 都接受，但会被忽略 |
| `2` | 16 位 <-> 32 位，或 8 位 <-> 16 位 | `ZERO`、`ONE` |
| `4` | 8 位 <-> 32 位 | `ZERO`、`ONE`、`TWO`、`THREE` |
| packed FP4 carrier | bfloat16 <-> FP4 | `ZERO`、`ONE`、`TWO`、`THREE`；仅 `ZEROING` |

如果 layout 对当前位宽 ratio 来说越界了，模拟器会报错。
`MaskMergeMode.MERGING` 会把所有非 FP4 cast 进一步限制到
`RegLayout.ZERO`，即使它的清零形式接受其他 slot。

示例：

```python
cfg_one = CastConfig(reg_layout=RegLayout.ONE, name="cfg_one")
```

## 2. 核心 API

### `cast(dst, src, config=None, mask=None)`

- 作用：把一个寄存器 cast 到另一个寄存器。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 `Reg`
  - `config`：可选的 `CastConfig`
  - `mask`：可选的 `MaskReg`

一般行为：

- 源寄存器会先做快照，所以像 `cast(reg, reg, cfg, mask)` 这样的别名写法仍然有稳定语义
- 使用 `MaskMergeMode.ZEROING` 时，会在写活跃 lane 前把 `dst` 清零
- 使用 `MaskMergeMode.MERGING` 时，会为 `dst` 的旧值做快照，并保留活跃
  写入集之外的 lane
- 执行 mask 通常按目标 lane 解析；bfloat16 <-> FP4 则按更宽的 bfloat16
  lane 几何解析

当前公开 stub 支持的 pair 由 `easyasc/stub_functions/cast_rules.py` 中的
A5 表校验；所有 `int4b_t` / `DT.int4` pair 都被排除，未列出的 pair
会在 codegen 前被拒绝。

| 源 dtype | 支持的目标 dtype |
| --- | --- |
| `DT.half` | `DT.float`、`DT.int`、`DT.int16`、`DT.int8`、`DT.uint8`、`DT.hif8`、`DT.bfloat16` |
| `DT.float` | `DT.float`、`DT.half`、`DT.int`、`DT.int64`、`DT.int16`、`DT.bfloat16`、`DT.e4m3`、`DT.e5m2`、`DT.hif8` |
| `DT.bfloat16` | `DT.float`、`DT.int`、`DT.half`、`DT.fp4_e2m1`、`DT.fp4_e1m2` |
| `DT.uint8` | `DT.half` |
| `DT.int8` | `DT.half` |
| `DT.int16` | `DT.half`、`DT.float` |
| `DT.int` | `DT.float`、`DT.int16`、`DT.int64` |
| `DT.int64` | `DT.int`、`DT.float` |
| `DT.e4m3`、`DT.e5m2` | `DT.float` |
| `DT.hif8` | `DT.float`、`DT.half` |
| `DT.fp4_e2m1`、`DT.fp4_e1m2` | `DT.bfloat16` |

round mode 集合与 pair 相关。特别是：FP8 encode 接受 `NONE` / `TO_EVEN`；
HiFloat8 encode 接受 `AWAY_FROM_ZERO` / `HYBRID`；FP4 encode 使用整数
rounding mode；对应的宽化 decode pair 使用 `NONE`。公开 stub 会在 codegen
前校验 HiFloat8 和 FP4 的特殊 mode；为其他 pair 构建显式 config 时，以
`cast_rules.py` 的 pair 表为准。

对于 `float -> fp8`，这是 ratio 为 4 的宽转窄 cast。把紧凑 fp8 流写回
UB 时，通常使用 `RegLayout.ZERO`，并在存储时接 `pack4()`。对于 `fp8 ->
float`，源 fp8 值会被解码到 float lane，不需要 `pack4()`。

对于真正的 hif8 carrier，`float -> hif8` 同样是 ratio 为 4 的操作，写回紧凑
`uint8` carrier 时应使用 `pack4()`。`half -> hif8` 是 ratio 为 2 的操作，应改用
`downsample()`。解码会镜像这个 layout：`hif8 -> float` 用 `unpack4()` 加载紧凑
carrier，而 `hif8 -> half` 用 `unpack()` 加载紧凑 carrier。

对于 bfloat16 <-> FP4，每个 carrier byte 存两个逻辑 FP4 值。encode 会把
carrier byte 放到 FP4 寄存器中每四个物理 byte 的一个；
`RegLayout.ZERO/ONE/TWO/THREE` 选择该 byte slot。decode 从同一 slot 读回
连续 bfloat16 lane。mask 按 bfloat16 lane 解析；由于 FP4 拒绝 `MERGING`，
未选中的输出始终清零。

当前模拟器注意点：

- 浮点到整数 cast、`float -> float`、`float -> half`/`float -> bfloat16`，以及 `int16_t -> half`、`int32_t`/`int64_t -> float` 这类整数到浮点精度缩减 cast 会在模拟阶段应用 `round_mode`，并且 `round_mode` 也会进入代码生成
- `float -> e4m3/e5m2` 直接使用 fp8 目标 dtype 转换；`e4m3/e5m2 -> float` 会解码源 fp8 值，不会再额外套一层 `float -> float` rounding
- `float/half -> hif8` 和 `hif8 -> float/half` 使用 hif8 carrier codec。hif8 编码只支持 `CAST_ROUND` 和 `CAST_HYBRID`；hif8 解码接受但忽略 round mode。half 的 hybrid 路径已用 CANNSIM 在全部 65536 个 half 位模式上校验过；它的 SSR 阈值来自源 half 尾数的 LSB
- simulator runtime 里可能仍有更底层的 dtype 路径，但它们不一定是公开 `micro.cast` stub pair

### 2.1 同宽 Cast

这指的是：

- `src.dtype.size == dst.dtype.size`

寻址规则：

- 对每个激活的 lane `i`：
  - `dst[i] = cast(src[i])`

说明：

- 在这种情况下，`reg_layout` 不会改变寻址映射
- 因为不需要做 slot 查找，所以同宽 cast 目前接受所有 `RegLayout` 值
- 被 mask 掉的 lane 在 `ZEROING` 下保持为零，在 `MERGING` 下保留
  原有 `dst` 值（`MERGING` 仍要求 `RegLayout.ZERO`）

示例：

```text
src  = [a0, a1, a2, a3, a4, a5, ...]
mask = active at lanes [0..7]
dst  = [cast(a0), cast(a1), ..., cast(a7), 0, 0, ...]
```

例如，`int16 -> half` 是受支持的同宽 pair。即使 config 使用
`RegLayout.THREE`，它仍会因不需要 slot lookup 而按 1:1 转换活跃 lane；
默认清零模式下，其余 lane 变成零。

### 2.2 窄转宽 Cast

这指的是：

- `src.dtype.size < dst.dtype.size`

设：

- `ratio = dst.dtype.size / src.dtype.size`
- `slot = reg_layout`

寻址规则：

- 对每个激活的目标 lane `i`：
  - `src_index = i * ratio + slot`
  - `dst[i] = cast(src[src_index])`

理解方式：

- 每个宽目标 lane 会从源寄存器中一个 ratio 大小的分组里挑一个元素
- `RegLayout.ZERO` 选每组的第一个元素
- `RegLayout.ONE` 选第二个，以此类推

#### C310 plain `Cast` 窄转宽限制

上面的 ratio 表和寻址规则描述的是 CANN 头文件合同，以及 simulator 保留的
理想 slot 语义。Ascend950 的精确真机证据覆盖了以下四种 plain
`MicroAPI::Cast` 组合，并与头文件声明不一致：

| 源 | 目标 | `950` / `950pr` 上失效的 layout |
| --- | --- | --- |
| `DT.int8` | `DT.half` | `RegLayout.ONE` |
| `DT.half` | `DT.float` | `RegLayout.ONE` |
| `DT.bfloat16` | `DT.float` | `RegLayout.ONE` |
| `DT.float` | `DT.int64` | `RegLayout.ONE` |

这些组合生成的 C++ 可能正常编译，但 ONE 半区在 C310 上会全部变成零。因此，
A5 公开 stub 会在 codegen 前只拒绝这些 plain-cast 配置。它不会拒绝 ZERO、
同宽 cast、宽转窄 cast、原生 BF16 <-> FP4 的 P0-P3 layout、其他尚未验证的
窄转宽 pair，也不会影响独立的 `ExpSub` / `MulsCast` 融合 API。simulator
仍保留理想 API slot 模型；它不会把真机产零伪装成预期数学语义。

请改用下面两种 ZERO-only 结构之一。

##### 连续 8/16 位源寄存器转成两个更宽寄存器

把连续源寄存器与零寄存器做 Interleave。两个输出寄存器的有效值都会落到
ZERO slot，因此两次 ZERO cast 可以分别恢复连续的低半区和高半区，不需要
ONE cast：

```python
src_native = Reg(DT.half)
zero_native = Reg(DT.half)
lower_even = Reg(DT.half)
upper_even = Reg(DT.half)
lower_wide = Reg(DT.float)
upper_wide = Reg(DT.float)
cfg_zero = CastConfig(
    round_mode=RoundMode.NONE,
    reg_layout=RegLayout.ZERO,
    name="half_to_float_zero_only",
)

zero_native <<= 0
interleave(lower_even, upper_even, src_native, zero_native)
cast(lower_wide, lower_even, cfg_zero)
cast(upper_wide, upper_even, cfg_zero)
```

同一寄存器结构也适用于 `int8 -> half` 和 `bfloat16 -> float`；需要使用
对应 pair 的合法 round mode 和匹配的 tail mask。A5 SwiGlu widening bridge
采用的就是这条路径。

##### 32 位源寄存器全宽转 int64

对于 `float -> int64`，使用一个 trait-two 目标寄存器、匹配的 trait-two
mask，以及一次 ZERO cast。这样可以在一次操作中保留全部 64 个源 lane：

```python
src32 = Reg(DT.float)
dst64 = Reg(DT.int64, reg_num=2)
active64 = MaskReg(DT.int64, reg_num=2)
cfg_zero = CastConfig(
    round_mode=RoundMode.TO_EVEN,
    reg_layout=RegLayout.ZERO,
    name="float_to_int64_trait2",
)
cast(dst64, src32, cfg_zero, mask=active64)
```

同一 trait-two bridge 也是 `int32 -> int64` 的全宽形式。

C310 对全宽转换有一个重要例外。若要把一个 `Reg(DT.int)` 的全部 64 个
lane 转成 int64，目标寄存器与 mask 都必须声明 `reg_num=2`。生成 C++ 会
使用 `RegTensor<int64_t, RegTraitNumTwo>`，并按 1:1 保留全部 64 个逻辑源
lane。默认的 `Reg(DT.int64)` 只有 32 个 lane，因此只代表 ZERO/ONE 中的
一个 layout 半区。

```python
src32 = Reg(DT.int)
dst64 = Reg(DT.int64, reg_num=2)
active64 = MaskReg(DT.int64, reg_num=2)
cfg = CastConfig(
    round_mode=RoundMode.NONE,
    reg_layout=RegLayout.ZERO,
    name="int32_to_int64_trait2",
)
cast(dst64, src32, cfg, mask=active64)
```

数据寄存器和 mask 的 trait 必须一致。C310 的 b64
`Interleave`/`DeInterleave` 也要求这种双寄存器形式；默认 trait-one b64
寄存器会在 codegen 前被拒绝。

示例：`half -> float`（`ratio = 2`）

```text
src = [h0, h1, h2, h3, h4, h5, ...]

RegLayout.ZERO:
dst = [float(h0), float(h2), float(h4), ...]

RegLayout.ONE:
dst = [float(h1), float(h3), float(h5), ...]
```

示例：`e4m3 -> float`（`ratio = 4`）

```text
src group 0 = [f8_0, f8_1, f8_2, f8_3]
src group 1 = [f8_4, f8_5, f8_6, f8_7]

RegLayout.ZERO -> [float(f8_0), float(f8_4), ...]
RegLayout.ONE  -> [float(f8_1), float(f8_5), ...]
RegLayout.TWO  -> [float(f8_2), float(f8_6), ...]
RegLayout.THREE-> [float(f8_3), float(f8_7), ...]
```

### 2.3 宽转窄 Cast

这指的是：

- `src.dtype.size > dst.dtype.size`

设：

- `ratio = src.dtype.size / dst.dtype.size`
- `slot = reg_layout`

寻址规则：

- 源 lane 下标为 `src_index = dst_index // ratio`
- 只有满足 `dst_index % ratio == slot` 的目标 lane 会被写入
- 其他目标 lane 在 `ZEROING` 下清零，在 `MERGING` 下保留

理解方式：

- 一个宽源 lane 会扇出到一个 ratio 大小的目标分组
- `RegLayout` 决定这个目标分组里哪一个 slot 接收转换后的值

示例：`float -> half`（`ratio = 2`）

```text
src = [f0, f1, f2, f3, ...]

RegLayout.ZERO:
dst = [half(f0), 0, half(f1), 0, half(f2), 0, ...]

RegLayout.ONE:
dst = [0, half(f0), 0, half(f1), 0, half(f2), ...]
```

示例：`float -> e4m3`（`ratio = 4`）

```text
RegLayout.ZERO:
dst[0], dst[4], dst[8], ... = cast(src[0]), cast(src[1]), cast(src[2]), ...
all other lanes remain 0
```

这正是为什么 `float -> fp8` cast 之后，通常还会接一个
`pack4()`：cast 只会在每 4 个 lane 中填一个 slot，而 `pack4()` 会把
这些 lane 压紧后再写回 UB。

### 2.4 饱和行为

当 `config.saturate == False` 时：

- 已明确支持的有损精度 cast 仍然会走实现好的 `round_mode` 路径
- 溢出、NaN，以及这些显式路径之外的行为会留给最终的 `torch.Tensor.to(dst_dtype)` 转换

当 `config.saturate == True` 时：

- 对浮点目标：
  - 有限值会先钳位到该 dtype 的有限值范围
  - `inf`、`-inf` 和 `nan` 留给最终的浮点 cast 逻辑处理
- 对整数目标：
  - 有限值会先钳位到整数范围
  - `+inf` 会变成该整数类型的最大值
  - `-inf` 会变成该整数类型的最小值
  - `nan` 会变成 `0`

示例：带饱和的 `half -> int8`（下面是 ratio-2 slot 安置前的转换值）

```text
src = [-300.0, -129.0, -128.0, 127.0, 128.0, inf, -inf, nan]

after saturation:
[-128, -128, -128, 127, 127, 127, -128, 0]
```

### 2.5 Mask 行为

对于 `cast()`：

- mask 通常按目标 lane 解析；bfloat16 <-> FP4 则使用 bfloat16 lane 几何
- 不会做 `C0` 扩展
- 没有被选中的目标 lane 在 `ZEROING` 下变成零，在 `MERGING` 下保留
  原有 `dst` 值

示例：

```text
mask = VL8
dst[0:8]   = converted values
dst[8:...] = 0                    # ZEROING
dst[8:...] = previous dst[8:...]  # MERGING
```

### 2.6 直接示例

float 到 half，两个不同 layout：

```python
src_reg = Reg(DT.float)
dst_zero = Reg(DT.half)
dst_one = Reg(DT.half)
mask = MaskReg(DT.half)

cfg_zero = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")
cfg_one = CastConfig(reg_layout=RegLayout.ONE, name="cfg_one")

cast(dst_zero, src_reg, cfg_zero, mask)
cast(dst_one, src_reg, cfg_one, mask)
```

half 到 float：

```python
src_reg = Reg(DT.half)
dst_reg = Reg(DT.float)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")
cast(dst_reg, src_reg, cfg)
```

float 到 fp8，并打包后写回 UB：

```python
src_reg = Reg(DT.float)
dst_fp8 = Reg(DT.e5m2)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

cast(dst_fp8, src_reg, cfg)
dst_ub <<= dst_fp8.pack4()
```

限制：

- `dst` 和 `src` 都必须是 `Reg`
- `config` 在默认解析完成后必须是 `CastConfig`
- `mask` 必须是 `MaskReg`
- 选择的 `RegLayout` 必须对当前位宽 ratio 合法
- `MaskMergeMode.MERGING` 要求 `RegLayout.ZERO`
- bfloat16 <-> FP4 要求 `MaskMergeMode.ZEROING`
- dtype pair 必须出现在上面的表格中

## 3. `Reg` 便捷方法

### `Reg.cast(cfg=None)`

- 作用：构造一个 `RegOP` cast 节点，输出仍保持源寄存器的逻辑 dtype。
- 常见用途：
  - 显式套用某个 cast config，同时保持寄存器 dtype 不变
  - 先构造一个 cast 节点，稍后通过赋值发射出去

重要细节：

- `Reg.cast()` 不会指定新的输出 dtype
- 所以生成出来的 `RegOP` 会保持源 dtype
- 如果你希望明确得到一个新 dtype，更适合用 `Reg.astype(...)`

示例：

```python
src = Reg(DT.half)
dst = Reg(DT.half)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg")
dst <<= src.cast(cfg)
```

### `Reg.astype(dtype, cfg=None)`

- 作用：构造一个带显式输出 dtype 的 `RegOP` cast 节点。
- 参数：
  - `dtype`：目标 `DT.*` 值
  - `cfg`：可选的 `CastConfig`

写 micro 代码时，这通常是最实用的便捷形式，
因为它同时把下面两件事表达出来了：

- 目标 dtype
- cast 策略

示例：

```python
r_h = Reg(DT.half)
r_f = Reg(DT.float)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

r_f <<= r_h.astype(DT.float, cfg)
```

### `Reg.pack4()`

- 作用：构造一个使用 `StoreDist.PACK4` 进行存储的 `RegOP`。
- 它为什么会出现在 cast 文档里：
  - 当做 ratio 为 `4` 的宽转窄 cast 时，每 4 个 lane 里只有 1 个 lane 真正带值
  - `pack4()` 会把 `0, 4, 8, ...` 这些 lane 压成连续的 UB 输出流

典型的 fp8 工作流：

1. 用 `RegLayout.ZERO` 先做 `float -> e5m2` 或 `float -> e4m3`
2. cast 会把转换后的值放在寄存器的 `0, 4, 8, ...` 这些 lane 上
3. 写回 UB 时再用 `pack4()` 把这些 lane 压紧

示例：

```python
src = Reg(DT.float)
dst = Reg(DT.e5m2)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

cast(dst, src, cfg)
packed_ub <<= dst.pack4()
```

关于 `PACK4` 存储的精确定义，请参见 [a5_micro_data_movement.md](a5_micro_data_movement.md)。

## 4. 常用理解方式

调试 cast 时，可以按这个检查顺序来：

1. 比较 `src.dtype.size` 和 `dst.dtype.size`
2. 算出位宽 ratio
3. 检查选定的 `RegLayout` 对这个 ratio 是否合法
4. 判断当前 cast 属于哪一类：
   - 从每个源分组里选一个 lane（`narrow -> wide`）
   - 或者在每个目标分组里填一个 slot（`wide -> narrow`）
5. 检查 `merge_mode`：被 mask 屏蔽和未填充的目标 lane 在 `ZEROING`
   下变成零，在 `MERGING` 下保留目标旧值
6. 如果溢出有影响，检查是否需要 `saturate=True`
7. 如果在意模拟器中的舍入行为，检查当前源/目标 pair 是否属于显式建模 round mode 的路径
