# EasyASC 中文文档

[English documentation](../doc/index.md) · [仓库概览](../README_CN.md)

这是公开行为与编写契约的权威导航页。请按任务选择入口，不需要从头到尾线性阅读
所有页面。

## 选择 target

| Facade | Target | 公开能力 |
| --- | --- | --- |
| `easyasc.a2` | Ascend A2 / B3 profile | A2 cube 与 vec API |
| `easyasc.a3` | Ascend 910C / `Ascend910_9362` | 使用 `ascend910_93` 编译单元的 A2/C220 API |
| `easyasc.a5` | Ascend 950 | A5/C310 cube、`@vf`、`@simt` 与 micro API |
| `easyasc.a5pr` | Ascend 950PR | 使用 950PR 设备 profile 的 A5/C310 API |

> **一个 Python 进程只能使用一个 facade。**facade import 会选择共享设备状态；
> Python 模块缓存不会在重新 import 时恢复旧 target，因此切换 target 必须启动
> 新进程。

“A5 系列”指 `easyasc.a5` 与 `easyasc.a5pr`。只有在明确排除 A5PR 时，页面才应
写成“仅 A5/950”。
“C220 编写系列”指 `easyasc.a2` 与 `easyasc.a3`；二者导出相同 DSL 接口，但分别
选择 B3 与 9362 构建 profile。

## 按任务选择入口

| 目标 | 从这里开始 | 接着阅读 |
| --- | --- | --- |
| 运行现有 kernel | [快速开始](01_quickstart.md) | [Kernel 示例](../agent/example/kernels/README.md) |
| 学习 DSL | [编程模型](02_programming_model.md) | [编写第一个 Kernel](03_write_your_first_kernel.md) |
| 编写混合流水线 | [混合流水线与同步](04_mixed_pipeline_and_sync.md) | [同步 API](api/synchronize.md) |
| 在模拟器中调试 | [模拟器与 Trace](05_simulator_and_trace.md) | [故障排查](10_troubleshooting.md) |
| 生成或运行产物 | [代码生成与运行时](06_codegen_and_runtime.md) | [OpExec API](api/op_exec.md) |
| 学习可复用结构 | [Kernel 模式](07_kernel_patterns.md) | [Kernel 练习](kernel_practice.md) |
| 添加回归测试 | [测试与验证](08_testing_and_validation.md) | [Testcases 指南](../agent/example/testcases/README.md) |
| 查询 API | [详细 API 参考](api/index.md) | [Stub-to-codegen 对照](12_stub_to_codegen_name_map.md) |
| 使用特定 dtype/算子 | [专题契约](topics/index.md) | 对应专题页面 |
| 修改框架 | [贡献者架构说明](11_architecture_for_contributors.md) | [Agent Router](../agent/ROUTER.md) |

## 编号页面

编号文件是稳定入口，不表示必须依次读完。

1. [快速开始](01_quickstart.md)
2. [编程模型](02_programming_model.md)
3. [编写第一个 Kernel](03_write_your_first_kernel.md)
4. [混合流水线与同步](04_mixed_pipeline_and_sync.md)
5. [模拟器与 Trace](05_simulator_and_trace.md)
6. [代码生成与运行时](06_codegen_and_runtime.md)
7. [Kernel 模式](07_kernel_patterns.md)
8. [测试与验证](08_testing_and_validation.md)
9. [API 参考兼容入口](09_api_reference.md)
10. [故障排查](10_troubleshooting.md)
11. [贡献者架构说明](11_architecture_for_contributors.md)
12. [Stub-to-codegen 名字对照](12_stub_to_codegen_name_map.md)

## 参考集合

- [详细 API 参考](api/index.md)负责公开签名、参数、target、dtype/layout 限制和
  最小示例。
- [专题契约](topics/index.md)负责 Conv2D、int4、MXFP 等聚焦契约。
- 评测报告（带 provenance 的证据快照）位于 `easyasc_cannbench_kernels`
  扩展仓库，与其描述的 CANN Bench kernel 放在一起；报告不属于教程步骤。
- [Kernel 练习](kernel_practice.md)提供公共练习；完成且经过整理的实现位于
  [`agent/example/kernels/`](../agent/example/kernels/README.md)。

## 文档所有权

- 公开行为和 API 契约属于 `README*`、`doc/`、`doc_cn/`。
- 公开 export 与 target 选择由 `easyasc/a2.py`、`easyasc/a3.py`、
  `easyasc/a5.py`、`easyasc/a5pr.py` 拥有，文档不能自行定义另一套 surface。
- Stub 校验、parser/lowering 与 simulator 行为是公开契约的实现证据。
- Agent workflow、仓库地图、实现查找和硬件事实继续由 `agent/` 管理；公共页面
  应链接 owner，不复制完整内部内容。
- 中英文可以采用不同讲解方式，但签名、target、限制、默认值和精确数值表必须
  一致。
