# API 参考

权威 API 导航与 target 说明位于[详细 API 参考](api/index.md)。

这个编号页面仅作为旧链接和书签的稳定兼容入口。API 签名、限制与示例统一维护在
`doc_cn/api/` 下，不在这里重复。

进入具体 API 页面前，请先为当前 Python 进程选择且只选择一个 facade：
`easyasc.a2`、`easyasc.a3`、`easyasc.a5` 或 `easyasc.a5pr`。
