# Stub 与 Codegen 名字对照表

这份文档用于快速查表：当你手里有一个来自 `easyasc.a2`、`easyasc.a3`、
`easyasc.a5` 或 `easyasc.a5pr` 的公开 helper 名字时，可以在这里找到它在生成代码里对应的
C++ helper、宏或内联表达式形式。

如果你需要先理解完整的 lowering 流程，建议先看 [代码生成与运行时](06_codegen_and_runtime.md)。
这份文档不解释语义、合法性约束或 simulator 行为。

`agent/scripts/check_public_docs.py` 会用 `agent/scripts/data/public_docs_manifest.json` 检查
顶层 stub export 覆盖率。本页可以手写语义说明，但不能静默漏掉 facade export。

## 适用范围

- “A2/A3” 指 `easyasc.a2` / `easyasc.a3` 共享公开接口，以及
  `is_c220_family(device_type)`（`b*` 或 `a3`）选择的 C220 codegen 路径。
- “A5” 指 `easyasc.a5` / `easyasc.a5pr` 公开接口，以及 A5 系列
  （`device_type in ("950", "950pr")`）codegen 路径。
- 下文列出的生成名字来自 `easyasc/parser/asc_handlers/`。
- 下表描述的是 `easyasc.a2` 与 A5 系列顶层模块实际导出的名字，不是
  `easyasc/stub_functions/` 目录下所有“存在但未必导出”的 helper 文件。
- 有些 helper 最终生成的是 view 声明或内联表达式，而不是单个 runtime helper 调用。
- `sim_print` 和 `sim_dump_tensor` 仅用于 simulator；它们不会生成 C++ 语句。
- A5 系列接口会在导入 `stub_functions` 之后再导入
  `stub_functions.micro`，因此有一批顶层名字会被 A5 micro helper 有意覆盖。

## 先看一个最重要的差异

同一个顶层名字，在 A2 与 A5 系列上不一定属于同一类 helper 家族。

```python
from easyasc.a2 import add   # vec Tensor helper
from easyasc.a5 import add   # micro Reg helper
```

所以看下面的对照表时，应该以“公开导入面”作为判断依据，而不是只看 `easyasc/stub_functions/` 里的原始文件名。

## 顶层同名，但 lowering 家族不同

这些名字同时存在于 `easyasc.a2` 与两个 A5 系列入口，但会走不同的 handler
家族。

| 顶层名字 | `easyasc.a2` 来源 | A2 生成符号 | `easyasc.a5` 来源 | A5 生成符号 | 说明 |
| --- | --- | --- | --- | --- | --- |
| `add`, `sub`, `mul`, `div`, `vmax`, `vmin`, `vand`, `vor` | `stub_functions.vec.binary` | `Add`, `Sub`, `Mul`, `Div`, `Max`, `Min`, `And`, `Or` | `stub_functions.micro.binary` | `MicroAPI::Add`, `MicroAPI::Sub`, `MicroAPI::Mul`, `MicroAPI::Div`, `MicroAPI::Max`, `MicroAPI::Min`, `MicroAPI::And`, `MicroAPI::Or` | A2 这一行是 vec Tensor 运算；A5 这一行是 micro Reg 运算。 |
| `exp`, `ln`, `abs`, `relu`, `sqrt`, `vnot` | `stub_functions.vec.unary` | `Exp`, `Ln`, `Abs`, `Relu`, `Sqrt`, `Not` | `stub_functions.micro.unary` | `MicroAPI::Exp`, `MicroAPI::Ln`, `MicroAPI::Abs`, `MicroAPI::Relu`, `MicroAPI::Sqrt`, `MicroAPI::Not` | 公开名字相同，但执行层不同。 |
| `adds`, `muls`, `shiftls`, `shiftrs`, `vmaxs`, `vmins`, `lrelu`, `axpy` | `stub_functions.vec.unaryscalar` | `Adds`, `Muls`, `ShiftLeft`, `ShiftRight`, `Maxs`, `Mins`, `LeakyRelu`, `Axpy` | `stub_functions.micro.unaryscalar` | `MicroAPI::Adds`, `MicroAPI::Muls`, `MicroAPI::ShiftLefts`, `MicroAPI::ShiftRights`, `MicroAPI::Maxs`, `MicroAPI::Mins`, `MicroAPI::LeakyRelu`, `MicroAPI::Axpy` | A2 shift 操作工作在整数 UB Tensor 上；A5 标量操作工作在 `Reg + MaskReg` 上。 |
| `cast` | `stub_functions.vec.cast` | `Cast<dst, src, false>(..., RoundMode::...)` | `stub_functions.micro.cast` | `MicroAPI::Cast<dst, src, config>(...)` | A5 micro cast 会带 `CastConfig` 模板参数。 |
| `compare`, `select` | `stub_functions.vec.compare`, `stub_functions.vec.select` | `Compare`, `CompareScalar`, `Select` | `stub_functions.micro.compare` | `MicroAPI::Compare`, `MicroAPI::CompareScalar`, `MicroAPI::Select` | `easyasc.a5.select` 来自 micro compare 模块，不是 vec select。 |
| `dup` | `stub_functions.vec.dupbrcb` | `Duplicate` | `stub_functions.micro.dup` | `MicroAPI::Duplicate` | 名字相同，但操作数类型不同。 |
| `cadd`, `cgadd`, `cpadd`, `cmax`, `cgmax`, `cmin`, `cgmin` | `stub_functions.vec.group` | `WholeReduceSum`, `BlockReduceSum`, `PairReduceSum`, `WholeReduceMax`, `BlockReduceMax`, `WholeReduceMin`, `BlockReduceMin` | `stub_functions.micro.group` | `MicroAPI::ReduceSum`, `MicroAPI::ReduceSumWithDataBlock`, `MicroAPI::PairReduceSum`, `MicroAPI::ReduceMax`, `MicroAPI::ReduceMaxWithDataBlock`, `MicroAPI::ReduceMin`, `MicroAPI::ReduceMinWithDataBlock` | 公开名字一致，但 reduction 所在层级不同。 |
| `gather` | `stub_functions.vec.gatherscatter` | `Gather` | `stub_functions.micro.datamove` | `MicroAPI::Gather` | A2 的 gather 使用 vec Tensor + offset；A5 的 gather 使用 Reg + index Reg。 |
| `muladddst` | `stub_functions.vec.binary` | `MulAddDst` | `stub_functions.micro.fused` | `MicroAPI::MulAddDst` | A2 是 vec Tensor op；A5 是 micro Reg 原地累加器（`dst = src0 * src1 + dst`），mask 为 ZEROING。 |
| `gather_block` | `stub_functions.vec.gatherscatter` | `Gatherb` | — | — | A2-only 块级 gather：一个 offset 对应一个 32B 块，每 repeat 8 块；A5 无对应。 |

## 顶层共享名字

这些 helper 在 A2 和 A5 顶层上都存在，并保持相同的顶层含义。

### 标量与形状辅助

| Helper | A2 生成形式 | A5 生成形式 | 说明 |
| --- | --- | --- | --- |
| `GetCubeNum` | `GetBlockNum()` | `GetBlockNum()` | 标量 helper。 |
| `GetCubeIdx` | `get_block_idx()` | `get_block_idx()` | 标量 helper。 |
| `GetVecNum` | `GetBlockNum() * 2` | `GetBlockNum() * 2` | 当前 lowering 假设每个 cube block 对应两个 vec sub-block。 |
| `GetVecIdx` | `GetBlockIdx()` | `GetBlockIdx()` | 标量 helper。 |
| `GetSubBlockIdx` | `get_subblockid()` | `get_subblockid()` | 标量 helper。 |
| `CeilDiv` | `CeilDiv(...)` | `CeilDiv(...)` | 直接 helper 调用。 |
| `Min`, `Max` | `Min(...)`, `Max(...)` | `Min(...)`, `Max(...)` | 直接 helper 调用。 |
| `Align8`, `Align16`, `Align32`, `Align64`, `Align128`, `Align256` | `Align8B`, `Align16B`, `Align32B`, `Align64B`, `Align128B`, `Align256B` | 相同 | 这些 stub 名字会映射到带 `B` 后缀的字节对齐 helper。 |
| `scalar_sqrt` | `sqrt(...)` | `sqrt(...)` | 内联标量表达式。 |
| `scalar_abs` | `abs(...)` | `abs(...)` | 内联标量表达式；`@vf` 内拒绝 float。 |
| `var_mul`, `var_add`, `var_sub`, `var_div`, `var_mod` | 内联 `*`, `+`, `-`, `/`, `%` 表达式 | 相同 | 作为标量表达式 lowering，而不是 helper 调用。 |

### Cube 与片上数据搬运

| Helper | A2 生成符号 | A5 生成符号 | 说明 |
| --- | --- | --- | --- |
| `gm_to_l1_nd2nz` | float `L1` 目标时为 `GM2L1_ND2ZZ`，否则为 `GM2L1_ND2NZ` | `GM2L1_ND2NZ` | 这是主要的族间 cube datamove 名字差异。 |
| `gm_to_l1_dn2nz` | `easyasc.a2` 不导出 | `GM2L1_DN2NZ` | A5 转置 GM->L1 加载（`Dn2NzParams`）；GM 里存的是矩阵转置后的形状。 |
| `gm_to_l1_pad` | `easyasc.a2` 不导出 | `GM2L1PAD` | A5 normal-mode GM 到 L1 padded copy。 |
| `gm_to_l1` | `GM2L1` | `GM2L1` | 普通 32B 粒度连续 GM 到 L1 copy。 |
| `gm_to_l1_mx_scale` | `easyasc.a2` 不导出 | `GM2L1PAD` | A5 MX scale helper；从 GM 复制 packed `[num_blocks, 32]` e8m0 scale block 到 L1。 |
| `gm_to_l1_mx_scale_nd2nz` | `easyasc.a2` 不导出 | `GM2L1_MX_SCALE_DN2NZ` | A5 系列 dense MX scale helper；把 GM `[rows, ceil(K/32)]` scale 转成紧凑 L1 scale stream。 |
| `set_constant_to_l1` | `InitConstValue` | `InitConstValue` | 常量填充 helper。 |
| `l1_to_l0a_img2col` | `L12L0A_IMG2COL` | `L12L0A_IMG2COL` | 低层 Conv2D/load3d staging helper；仍受各 target 校验约束。 |
| `l1_to_l0` | float `L1`：`L0ZZ2ZZ`、`L0ZZ2NN`、`L0ZZ2NZ`、`L0ZZ2ZN`；<br>非 float `L1`：`L0NZ2ZZ`、`L0NZ2NN`、`L0NZ2NZ`、`L0NZ2ZN` | `L0NZ2NZ` 或 `L0NZ2ZN` | 在 A2 上，dtype 和 transpose 都会影响名字；在 A5 上，当前 handler 总是走 NZ-source 这一支。 |
| `l1_to_bt` | `L1_TO_BT` | `L1_TO_BT` | 把连续 fp32/int32 bias 行从 L1 搬入 BT。 |
| `l1_to_l0_mx` | `easyasc.a2` 不导出 | `L0NZ2NZ_MX` 或 `L0NZ2ZN_MX` | A5 MX FP8 / MXFP4 L1 到 L0 搬运，并把 scale 装入 L0AMX/L0BMX。`L0NZ2ZN_MX` 用于 `src.T` 到 L0A 或 L0B，scale 要提前按转置后的行序打包。 |
| `mmad` | `MMAD` | `MMAD` | 共享的 cube compute helper。 |
| `mmad_mx` | `easyasc.a2` 不导出 | `MMAD_MX` | A5 MX FP8 / MXFP4 matmul helper。 |
| `l0c_to_gm_nz2nd` | `L0C2GM_NZ2ND` | `L0C2GM_NZ2ND` | 共享写回 helper。 |
| `l0c_to_gm_nz2nz` | `L0C2GM_NZ2NZ` | `L0C2GM_NZ2NZ` | 共享 fractal 写回 helper。 |
| `l0c_to_gm_nz2dn` | `easyasc.a2` 不导出 | `L0C2GM_NZ2DN` | A5 系列转置（NZ2DN）写回；sugar 是 `gm <<= l0c.T`。 |
| `l0c_to_l1` | `L0C2L1` | `L0C2L1` | 共享片上交接 helper。 |
| `l0c_to_ub` | `easyasc.a2` 不导出 | `L0C2UB_NZ2ND` | 仅从 `easyasc.a5` / `easyasc.a5pr` 顶层可用。 |

### 共享 vec 与 UB helper

| Helper | A2 生成符号 | A5 生成符号 | 说明 |
| --- | --- | --- | --- |
| `gm_to_ub_pad`, `ub_to_gm_pad`, `ub_to_ub` | `GM2UBPAD`, `UB2GMPAD`, `UB2UB` | 相同 | 共享 vec datamove helper。 |
| `gm_to_ub_nd_dma` | `easyasc.a2` 不导出 | `GM2UB_ND_DMA` | A5 系列多维 GM->UB DMA。`ub <<= gm.T` 会 lowering 到它的转置 helper。 |
| `ub_to_l1` | `easyasc.a2` 不导出 | `UB2L1` | A5 裸 UB 到 L1 copy；`burst_len` 和两侧 stride 都以 32B block 为单位。 |

## Vec helper 与 A2-only 名字

前几行只由 A2 导出；sort 与 vec-mask helper 由 A2 和 A5 系列共同导出，因其
仍走 vec lowering family 而保留在本节。

| Helper | A2 生成符号 | 说明 |
| --- | --- | --- |
| `rec`, `rsqrt` | `Reciprocal`, `Rsqrt` | vec unary helper，但没有在 A5 系列顶层重新导出。 |
| `brcb` | `Brcb` | vec broadcast helper，只在 A2 顶层公开。 |
| `scatter` | `Scatter` | A5 导出的是 micro `reg_to_ub_scatter`，而不是顶层 vec `scatter`。 |
| `compare_scalar` | `CompareScalar` | 在 A2 上作为独立顶层 helper 保留。 |
| `transdata5hd` | `TRANSDATA5HD` | A2-only UB `vnchwconv`/5HD 转置 helper。 |
| `sort32`, `mergesort4`, `mergesort_2seq` | `Sort32`, `MERGESORT4`, `MERGESORT2SEQ` | 这些 sort helper 由 `easyasc.a2` 与两个 A5 系列入口共同导出。 |
| `set_mask`, `set_mask_by_count`, `set_mask_normal`, `reset_mask` | `SetVectorMask<half, MaskMode::NORMAL>`, `SetVectorMaskByCount`, `ResetMask` | vec-PipeS mask helper，由 `easyasc.a2` 与两个 A5 系列入口共同导出。在 A5 系列上，它们设置向量 mask SPR，供 `@vf` 内的 `move_mask_spr`（`MoveMask<T>()`）读回。 |
| `SetCmpMask` | `SetCmpMask` | 来自 `select()` lowering 的内部 codegen 产生——不是用户导出的 stub。 |

### 同步、原子与杂项 helper

| Helper | A2 生成形式 | A5 生成形式 | 说明 |
| --- | --- | --- | --- |
| `bar_m`, `bar_v`, `bar_mte3`, `bar_mte2`, `bar_mte1`, `bar_fix`, `bar_all` | `PipeBarrier<PIPE_M/V/MTE3/MTE2/MTE1/FIX/ALL>()` | 相同 | 这些公开包装最终都走一个 `barrier` 指令家族。 |
| `cube_ready`, `vec_ready`, `wait_cube`, `wait_vec`, `allcube_ready`, `allvec_ready`, `allcube_wait`, `allvec_wait` | `CUBE_READY`, `VEC_READY`, `WAIT_CUBE`, `WAIT_VEC`, `ALLCUBE_READY`, `ALLVEC_READY`, `ALLCUBE_WAIT`, `ALLVEC_WAIT` | 相同 | 跨核 flag helper。 |
| `intracore_allvec_ready`, `intracore_allvec_wait` | `INTRACORE_ALLVEC_READY`, `INTRACORE_ALLVEC_WAIT` | 相同 | 每个 core 内两个 vec lane 的 phase barrier。 |
| `setflag`, `waitflag` | `set_flag`, `wait_flag` | 相同 | 这是 pipe event 指令，不是 `SEvent` / `DEvent` 对象本身。 |
| `atomic_add`, `atomic_max`, `atomic_min` | `SetAtomicAdd<float>()`, `SetAtomicMax<float>()`, `SetAtomicMin<float>()` | 相同 | 对应 context-manager 退出时会生成 `SetAtomicNone()`。 |
| `reset_cache` | `pipe_ptr->Reset();` 和 `OccupyMMTE1Events();` | 相同 | parser lowering 先发射原始 helper 调用；生成 `_cube.h` / `_vec.h` 时只会把自动插入前导里的那一对改写成注释，用户自己写的 `reset_cache` 仍保持原始语句。 |
| `clean_dcache` | `DataCacheCleanAndInvalid<...>` | 相同 | 会生成模板化的 cache-line helper。 |
| `set_hf32` | `SetHF32Mode(true/false);` | 相同 | 开启或关闭一种特殊的硬件 fp32 格式，可以加速 fp32 matmul，但会略微降低精度；模拟器会忽略它。 |
| `split_workspace` | `shiftAddr<dtype>(workspace, ...)` 加 `SetGlobalBuffer(...)` | 相同 | 生成的是 GM workspace view，而不是单个 helper 调用。 |
| `reinterpret` | `ReinterpretCast<dst_dtype>()` | 相同 | 生成本地 tensor view。 |
| `kernel_print` | `printf(...)` | 相同 | 生成期调试打印。 |
| `kernel_dump_tensor` | `DumpTensor(...)` | 相同 | 生成期 dump hook。 |
| `inline` | 原样内联 C++ 代码 | 相同 | 没有额外 wrapper helper。 |
| `sim_print`, `sim_dump_tensor` | 不生成代码 | 不生成代码 | 仅 simulator 使用，并由两个公开 facade 导出。 |

## 仅 A5 系列顶层导出的 helper

这些名字只存在于 A5 系列顶层公开接口（`easyasc.a5` 和 `easyasc.a5pr`）。

### Micro 寄存器与 Mask 家族

| A5 系列专用 helper | A5 生成符号 | 说明 |
| --- | --- | --- |
| `arange` | `MicroAPI::Arange` | A5 系列专用 micro helper。 |
| `abssub`, `expsub`, `muldstadd`, `mulscast` | `MicroAPI::AbsSub`, `MicroAPI::ExpSub`, `MicroAPI::MulDstAdd`, `MicroAPI::MulsCast` | 来自 `stub_functions.micro.fused` 的 A5 系列专用融合 helper；`muladddst` 因为 A2 已有同名 vec helper，列在上面的同名表。 |
| `vxor`, `prelu` | `MicroAPI::Xor`, `MicroAPI::Prelu` | A2 顶层不暴露的额外 micro binary helper。 |
| `log`, `log2`, `log10`, `neg`, `vcopy` | `MicroAPI::Log`, `MicroAPI::Log2`, `MicroAPI::Log10`, `MicroAPI::Neg`, `MicroAPI::Copy` | 额外的 micro unary helper。 |
| `shiftls`, `shiftrs` | `MicroAPI::ShiftLefts`, `MicroAPI::ShiftRights` | A5 系列专用 micro scalar helper。 |
| `shiftl`, `shiftr` | `MicroAPI::ShiftLeft`, `MicroAPI::ShiftRight` | A5 系列专用 reg-reg 逐 lane 变量移位（移位量是 RegTensor），区别于上面的标量 `shiftls`/`shiftrs`；仅整型，`dst`/`src`/`shift` 位宽须一致。 |
| `deinterleave`, `interleave` | `MicroAPI::DeInterleave`, `MicroAPI::Interleave` | 寄存器 lane 重排 helper。 |
| `pack`, `HighLowPart` | `MicroAPI::Pack<..., MicroAPI::HighLowPart::...>` | `pack` 组合寄存器高/低部分；`HighLowPart` 是配置枚举，本身不发射指令。 |
| `histograms`, `HistBin`, `HistMode` | `MicroAPI::Histograms<..., MicroAPI::HistogramsBinType::BIN_n, MicroAPI::HistogramsType::...>` | 对 `uint8` 源寄存器（256 lane）做字节直方图，写入 `uint16` 目标寄存器（128 个计数器）；目标是 **read-modify-write**，因此循环调用即可累加。`HistBin.BIN0..BIN7` 选择计数器覆盖哪个 128 宽的字节窗口；`HistMode` 选 `FREQUENCY`（`dhistv2`，统计等于某个 bin 的字节）或 `ACCUMULATE`（`chistv2`，统计 `<=` 某个 bin 的字节，且统计范围是**整个字节域**而非窗口内，所以 `BIN0`+`BIN1` 可直接拼成一张 256 项的 inclusive 前缀计数表）。两个枚举都只是配置，本身不发射指令。 |
| `ub_to_l1`, `ub_to_l1_nd2nz`, `ub_to_l1_nz` | `UB2L1`, `UB2L1_ND2NZ`, `UB2L1_NZ` | 仅 A5 系列导出的 vec-to-L1 publish helper；裸 `ub_to_l1` 使用 32B block 单位。 |
| `ub_to_reg`, `reg_to_ub` | `MicroAPI::DataCopy<..., MicroAPI::DataCopyMode::DATA_BLOCK_COPY>` | A5 micro datacopy 的基础配对。 |
| `ub_to_reg_continuous`, `reg_to_ub_continuous` | `MicroAPI::LoadAlign<..., MicroAPI::LoadDist::...>` / `MicroAPI::StoreAlign<..., MicroAPI::StoreDist::...>` | 具体分发模式由 distribution mode 决定。 |
| `ub_to_reg_interleave` | `MicroAPI::LoadAlign<..., MicroAPI::LoadDist::DIST_DINTLV_B8/B16/B32>` | UB 到两个寄存器的双搬入 interleave helper。 |
| `reg_to_ub_interleave` | `MicroAPI::StoreAlign<..., MicroAPI::StoreDist::DIST_INTLV_B8/B16/B32>` | 两个寄存器到 UB 的双搬出 interleave helper，是 `ub_to_reg_interleave` 的逆：一条指令写 `2 * VL` 个元素（512 字节），`dst[2k] = src0[k]`、`dst[2k+1] = src1[k]`。 |
| `reg_to_ub_downsample`, `reg_to_ub_pack4`, `reg_to_ub_single`, `reg_to_ub_normal`, `ub_to_reg_normal`, `ub_to_reg_single`, `ub_to_reg_upsample`, `ub_to_reg_downsample`, `ub_to_reg_unpack`, `ub_to_reg_unpack4`, `ub_to_reg_brcb` | 同属 `MicroAPI::LoadAlign` / `MicroAPI::StoreAlign` 家族 | 这些 convenience wrapper 先选 `LoadDist` / `StoreDist`，再走同一套 codegen handler。 |
| `ub_to_reg_gather`, `reg_to_ub_scatter`, `gather_mask` | `MicroAPI::DataCopyGather`, `MicroAPI::DataCopyScatter`, `MicroAPI::GatherMask` | A5 系列专用 micro datamove helper。 |
| `ub_to_reg_gatherb` | `MicroAPI::GatherB` | A5 系列专用 32B 数据块 gather：输出块 `i` <- src 中字节偏移 `index[i]` 处的 32B 块（uint32 index，从 index-reg 的 lane `i` 读取，32B 对齐）；支持 b8/b16/b32（b64 在板上有问题，stub 拒绝）。 |
| `unsqueeze` | `MicroAPI::Unsqueeze` | A5 系列专用原地 EXCLUSIVE mask 前缀和（PrefixSumImpl）：`dst[i]` = lane `i` 之前的 active mask lane 数；输入 `dst` 被忽略。**不是** `squeeze` 的逆。 |
| `squeeze` | `MicroAPI::Squeeze` | 压紧 active lane；`store=True` 选择 store-register specialization。 |
| `clear_spr` | `MicroAPI::ClearSpr<AscendC::SpecialPurposeReg::AR>()` | 清除 micro 路径使用的地址特殊寄存器。 |
| `print_reg` | 不生成 device code | 仅 simulator 使用的寄存器调试 helper。 |
| `ub_to_mask`, `mask_to_ub` | `MicroAPI::LoadAlign(MaskReg&, ...)` / `MicroAPI::StoreAlign(..., MaskReg&)` | A5 系列专用 MaskReg<->UB 搬运（MaskReg 重载，无 dist 模板）：搬运完整 32 字节（256-bit）向量 mask 寄存器；元素 lane `i` 落在物理 bit `i*elem_size`（字节粒度，已上板验证）。 |
| `vf_barrier` | `MicroAPI::LocalMemBar<MicroAPI::MemType::..., MicroAPI::MemType::...>()` | A5 系列专用的 `@vf` 本地内存顺序 helper；`VfPipe.STORE` 对应 `VEC_STORE`，`VfPipe.LOAD` 对应 `VEC_LOAD`。 |
| `mask_not`, `mask_and`, `mask_or`, `mask_xor`, `mask_mov`, `mask_interleave`, `mask_deinterleave`, `mask_sel` | `MicroAPI::MaskNot`, `MaskAnd`, `MaskOr`, `MaskXor`, `MaskMov`, `MaskInterleave`, `MaskDeInterleave`, `MaskSel` | Mask 寄存器运算。 |
| `move_mask_spr`, `update_mask` | `MicroAPI::MoveMask`, `MicroAPI::UpdateMask` | 返回值会被赋给 `MaskReg`。`move_mask_spr` 读取由 vec PipeS 上 `set_mask`/`set_mask_by_count`/`SetVectorMask` 设置的向量 mask SPR（现已在 A5 启用）；映射是 lane 粒度（MaskReg lane `i` <- SPR lane `i`），不是 `mask_to_ub` 的字节粒度 `i*elem_size` 布局。 |
| `mask_pack`, `mask_unpack` | `MicroAPI::MaskPack<...>`, `MicroAPI::MaskUnPack<...>` | mode 编码在模板参数里。 |
| `LoadDist`, `LoadDistValue`, `StoreDist`, `StoreDistValue` | 自身不生成代码 | 这是 A5 micro datamove wrapper 使用的配置枚举。 |

### Vec 高阶 API helper

| 仅 A5 系列的 helper | A5 生成符号 | 说明 |
| --- | --- | --- |
| `topk_radix` | `AscendC::TopK<..., AscendC::TopKMode::TOPK_NORMAL, {AscendC::TopKAlgo::RADIX_SELECT, ...}>` | 来自 `stub_functions/vec/sort.py` 的 UB radix-select TopK 高阶 API，仅 A5 系列导出，不是 micro helper。对 `outter` 行（每行按 `aligned_n` 对齐）各自从 `n` 个元素中选出 `k` 个。`sorted` 与 `init_index` 是编译期配置，因为它们决定实例化哪个模板；`largest` 是运行期参数。Ascend950 的该 API 不接受 `aligned_n > 4096`。 |

## 需要核对或扩展时，优先看这些源文件

如果你要继续补表或确认细节，优先查这些文件：

- 公开入口：`easyasc/a2.py`、`easyasc/a3.py`、`easyasc/a5.py`、`easyasc/a5pr.py`
- handler 注册：`easyasc/parser/asc_handlers/__init__.py`
- 标量 helper：`easyasc/parser/asc_handlers/math_ops.py`
- cube helper：`easyasc/parser/asc_handlers/cube.py`
- vec helper：`easyasc/parser/asc_handlers/vec_binary.py`、`vec_unary.py`、`vec_unary_scalar.py`、`vec_group.py`、`vec_dupbrcb.py`、`vec_gatherscatter.py`、`vec_datamove.py`、`vec_cast.py`、`vec_compare.py`、`vec_select.py`、`vec_sort.py`、`vec_mask.py`
- 同步与杂项：`easyasc/parser/asc_handlers/pipe_ops.py`、`atomic.py`、`misc.py`、`core.py`、`reinterpret.py`
- A5 micro helper：`easyasc/parser/asc_handlers/vec_micro_ops.py`
