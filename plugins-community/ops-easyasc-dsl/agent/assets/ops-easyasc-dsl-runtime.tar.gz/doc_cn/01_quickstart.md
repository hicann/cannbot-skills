# 快速开始

本指南面向这样一类读者：先想把现成 kernel 跑起来，再慢慢理解框架其余部分。

## 1. 环境

这个仓库目前还不是一个可直接安装的 Python 项目。请直接使用源码仓库，并将
仓库根目录加入 `PYTHONPATH`。

如果仓库所在机器提供了配套环境，先激活它：

```bash
conda activate torch210npu
```

如果只需要新建一个模拟器环境，可以安装仓库依赖：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

如果已经在使用 CANN / `torch-npu` 环境，应保持 `torch` 与 `torch-npu`
版本匹配，只补装缺少的依赖。`requirements.txt` 不负责安装 CANN 本身。

在仓库根目录运行嵌套示例之前，先导出 import 路径：

```bash
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
```

运行 `python agent/example/kernels/.../example.py` 时，Python 自动加入 import 路径的是脚本
目录，而不是仓库根目录；因此只切换到仓库目录还不够。

基于当前源码树，至少应满足这些前提：

- `OpExec` 依赖 `torch`，因此环境里必须能导入 `torch`
- 运行 `agent/example/testcases/` 时，环境里必须能导入 `pytest`
- 运行示例时，当前工作目录应当是仓库根目录，并且根目录必须位于
  `PYTHONPATH` 中

整个 Python 进程只能选择一个 target facade。不要同时导入 `easyasc.a2`、
`easyasc.a3`、`easyasc.a5`、`easyasc.a5pr`；facade import 会选择进程级全局设备状态，因此
切换 target 时必须启动新进程。

## 2. 第一次成功运行

先运行最小的 matmul 示例：

```bash
python agent/example/kernels/a5/matmul/matmul_float_mmad.py
```

成功运行后，输出末尾会出现类似结果：

```text
max_abs_diff=0.000000e+00
```

这个文件会做这些事：

1. 从 `easyasc.a5` 导入公开 API
2. 定义一个 `@kernel`
3. 构造示例用的 PyTorch 张量
4. 通过 `OpExec(..., simulator=True)` 启动 kernel
5. 把 kernel 输出与 `x @ y.t()` 做比较

如果运行成功，说明你已经验证了：

- Python DSL 能正常构建 kernel
- 模拟器能够执行它
- 输出张量能正确回读到 PyTorch

## 3. 最小 kernel 的结构

仓库里最短的例子是 `agent/example/kernels/a5/matmul/matmul_float_mmad.py`：

```python
from easyasc.a5 import *


@kernel()
def matmul_float_mmad_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c
    return z
```

可以把这段代码理解成一张数据流图：

- `x` 和 `y` 位于全局内存
- `l1x` 和 `l1y` 是片上的 L1 张量
- `l0c` 保存的是 float 累加结果 tile
- `<<=` 会根据源和目标的组合，发射对应的数据搬运或写回指令
- `with auto_sync():` 会让 parser 自动为这段代码里出现的 `MTE2 -> MTE1`、`MTE1 -> M`、`M -> FIX` 这些同侧 pipe 组合插入握手；完整的分类规则见 `04_mixed_pipeline_and_sync.md`

## 4. 一分钟理解 `OpExec`

`OpExec` 是主要的执行入口：

```python
z_kernel = OpExec(matmul_float_mmad_kernel, simulator=True)(x, y, z, M, N, K)
```

需要记住的规则有：

- kernel 签名必须按照 `输入 tensor-like* -> 输出 tensor-like* -> Var*` 的顺序排列；tensor-like 参数可以是 `GMTensor` 或 `GMTensorList`，混着写会被 `_validate_bound_kernel_signature` 抛出 `Invalid kernel argument order for OpExec: ...`
- 每个 kernel 至少要有一个 `Var` 参数；否则 `OpExec` 会报 `every @kernel must have at least one Var argument`
- 调用时也按这个顺序传参：先传输入 tensor/list，再传输出 tensor/list 占位符，最后传标量
- 标量参数会在内部转换成 `Var` 对象
- 当 `simulator=True` 时，输入张量会被拷贝到模拟器可见的 `GMTensor.data` 中
- 返回的 `GMTensor` 输出会再转换回 PyTorch 张量，返回的 `GMTensorList` 输出会转换成 Python tensor 列表

## 5. 模拟器模式与生成模式

优先使用模拟器模式：

```python
OpExec(kernel_fn, simulator=True)(...)
```

当你需要生成产物时，再使用生成模式：

```python
OpExec(kernel_fn, out_dir="my_kernel", simulator=False, gen_only=True)(...)
```

二者的高层差别是：

- 模拟器模式会通过 `easyasc/simulator/` 下的运行时执行 kernel
- 生成模式会经由 parser 和模板路径生成 C++ 与包装层产物

## 6. 什么时候需要 `shape_bindings`

运行时会尝试推断每个张量维度对应哪个标量 `Var`。当多个标量参数在运行时恰好有相同的整数值时，这个推断就可能变得有歧义。

例如：

```python
out = OpExec(kernel_fn, simulator=True)(
    x,
    y,
    z,
    m,
    n,
    k,
    shape_bindings={
        0: [0, 2],
        1: [1, 2],
        2: [0, 1],
    },
)
```

其中每个 key 是张量参数的索引，每个 list 表示张量各维度对应的标量参数索引，也可以写成 `None`。

如果你看到类似下面的报错：

```text
Ambiguous scalar match for tensor #... dim #...
```

先补显式的 `shape_bindings`，不要急着改 kernel 主体。

## 7. 接下来该看什么

- [编程模型](02_programming_model.md)
- [编写你的第一个 Kernel](03_write_your_first_kernel.md)
- [模拟器与 Trace](05_simulator_and_trace.md)
