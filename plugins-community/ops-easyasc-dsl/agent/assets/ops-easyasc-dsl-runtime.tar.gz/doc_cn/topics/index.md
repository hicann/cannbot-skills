# 专题契约（feature / dtype）

这一组页面是针对具体算子和 dtype 的精确编写契约，**不属于**编号教程步骤。
只有当你要写对应类型的 kernel 时才需要它们，而且要在动手前完整读一遍对应页面，
而不是当背景略过。

| 页面 | 设备 | 什么时候读 |
| --- | --- | --- |
| [`conv2d.md`](conv2d.md) | A2 + A5 系列 | 写任何 Conv2D / `load3d` img2col kernel 前 |
| [`mxfp.md`](mxfp.md) | A5 系列 | 写任何 MX FP8 / MXFP4 matmul（`matmul_mx`、`l1_to_l0_mx`、`mmad_mx`）前 |
| [`int4.md`](int4.md) | 仅 a2 | 写任何 int4 matmul kernel 前 |

下面的摘要是「动手前必须知道」的要点；完整契约以各自页面为准。

## conv2d.md —— Conv2D via load3d img2col（A2 + A5 系列）

fp16 特征图 + 权重、fp32 累加；conv 被降成一次普通 matmul
（`M = Ho*Wo`、`K = C1*Kh*Kw*C0`、`N = Cout_p`），img2col 由 load3d 硬件在搬运时
即时完成。

- `conv2d()` 只覆盖 matmul 作用域：它负责一个 M tile 的 L1 -> L0 -> mmad -> L0C
  以及内部 cube 冒险；调用方负责 GM->L1（含 bias）、`m` 循环、多核 gating 和
  L0C->GM 写回。
- 逻辑 img2col 矩阵在 A2 与 A5/A5PR 上一致，只有最终 L0A 编码不同（A2 落
  ZZ，A5/A5PR 落 NZ，每个 C0 K-fractal 一次硬件 load3d）。
- Host 打包器（从 `easyasc.utils.conv2d` 导入）：特征图用 `pack_nc1hwc0`，
  权重用 `pack_conv_weight`（ND，K 顺序 `c1 -> kh -> kw -> c0`）。
  **不要自己打 `[K, N]` ZN fractal** —— NZ/ZN block
  转置会在硬件上悄悄错位。

## mxfp.md —— MX FP8 / MXFP4 matmul（A5 系列）

把 FP8/FP4 的尾数/指数数据和逐行、逐 K-group 的 e8m0 scale 流分开存放。

- `DT.e4m3` / `DT.e5m2` 是普通 FP8 数据 dtype；`DT.mx_e4m3` / `DT.mx_e5m2` 是
  L0A/L0B 上的 MX compute-view dtype。
- `DT.fp4_e2m1` / `DT.fp4_e1m2` 是 A5 系列 packed FP4 compute view，底层用
  `DT.uint8` carrier；GM/L1 payload 形状是 `[rows, K / 2]`。
- e8m0 scale 用 `DT.uint8` 承载；值 `127` 表示乘数 `1.0`。
- scale 的逻辑 `[rows, ceil(K / 32)]` 只是数学视图，**不能从它反推物理存储**。
  packed `[num_blocks, 32]` 输入使用 `gm_to_l1_mx_scale`；文档规定的 dense
  scale 输入使用 `gm_to_l1_mx_scale_nd2nz`。
- `matmul_mx` 支持不切分、split-K、split-N；目前不能同时打开 split-K 和 split-N。

## int4.md —— int4 适配（仅 a2）

一个由 `DT.int` 载体张量支撑的本地 compute-view 标记，而不是 host / GM / CPU 可
寻址的 int4 存储模型。

- `DT.int4` 是一个 DSL 阶段的标记 dtype，只有本地 compute 视图才能是 int4。
- GM 与片上载体张量都得是 `DT.int`；八个逻辑 int4 值打包进一个载体元素。
- `GMTensor(DT.int4, ...)` 和 `Tensor/DBuff/TBuff/QBuff(DT.int4, ...)` 会被直接
  拒绝。
- int4 matmul 的触发方式是
  `matmul(..., l1a.reinterpret(DT.int4), l1b.reinterpret(DT.int4), k=logical_k)`；
  普通 `DT.int` matmul 不被支持。
- 模拟器通过 packed `DT.int` carrier 实现 signed int4 MMAD；当前验证仍不等价于
  硬件数值正确性证明。
