# int4 适配说明

本文记录的是当前仅 a2 路径生效的 int4 codegen 和模拟器约定。这个特性是由
int32 载体张量承载的本地 compute 视图标记，不是 host、GM，也不是 CPU 侧的
可寻址 int4 存储模型。

## 设计概览

- `DT.int4` 是 a2 / b 系列设备 codegen 阶段使用的 DSL 标记 dtype。
- `DT.int4` 只在本地 compute 视图上映射成 AscendC 的 `int4b_t`。
- 不支持 `GMTensor(DT.int4, ...)`。GM 输入输出都使用 `DT.int` 打包载体张量。
- `Tensor`、`DBuff`、`TBuff`、`QBuff` 都不能用 `DT.int4` 分配。（`QBuff` 是
  四槽缓冲家族 —— 见 [`doc/api/tensor_buffer.md §5.5`](../api/tensor_buffer.md)。）
- 不支持 `split_workspace(DT.int4, ...)`。
- 八个逻辑 int4 值会打包成一个 `DT.int` 载体元素。
- `.reinterpret(DT.int4)` 不会做打包或解包，它只是把一个 `DT.int` 载体视图
  标记为逻辑 int4 的 matmul / MMAD 操作数。
- 不支持普通的 `DT.int` cube matmul / MMAD。
- 模拟器支持 int4 MMAD：`DT.int4` 视图会别名到底层 `DT.int` 载体，
  执行前按有符号 int4 解包列，再做 int32 matmul。

## 编写模式

GM 张量是打包好的 `DT.int` 载体张量。对于一个逻辑 `K`，载体的 K 维度应该
分配成 `CeilDiv(K, 8)`。

```python
carrier_k = CeilDiv(K, 8)
q_pack = GMTensor(DT.int, [M, carrier_k], name="q_pack")
k_pack = GMTensor(DT.int, [N, carrier_k], name="k_pack")

l1q = Tensor(DT.int, [M, carrier_k], Position.L1, name="l1q_carrier")
l1k = Tensor(DT.int, [N, carrier_k], Position.L1, name="l1k_carrier")
l0c = Tensor(DT.int, [M, N], Position.L0C, name="l0c")

gm_to_l1_nd2nz(l1q, q_pack, M=M, N=carrier_k, N_src=carrier_k, M_dst=M)
gm_to_l1_nd2nz(l1k, k_pack, M=N, N=carrier_k, N_src=carrier_k, M_dst=N)

matmul(l0c, l1q.reinterpret(DT.int4), l1k.reinterpret(DT.int4), m=M, n=N, k=K)
```

这里的 `k=K` 是逻辑 int4 的 K，而不是载体的 K。

底层 `mmad` 也是支持的，前提是 `L0A` 和 `L0B` 操作数都是显式的 int4 视图：

```python
a4 = l0a_carrier.reinterpret(DT.int4)
b4 = l0b_carrier.reinterpret(DT.int4)
mmad(l0c, a4, b4, M=M, N=N, K=logical_k)
```

## dtype 规则

`DT.int4.C0 == 64`，因为一个 256-bit 的 C0 里能装 64 个逻辑 int4 值。

`DT.int4.size` 会抛 `ValueError`。框架并没有把 int4 当成 host 侧可寻址的
dtype；模拟器存储仍然是底层 `DT.int` 载体，int4 视图只是别名这个载体。

允许：

- 在 a2 上对 `Tensor(DT.int, carrier_shape, Position.L1)` 做 `.reinterpret(DT.int4)`。
- 在 a2 上对 `Tensor(DT.int, carrier_shape, Position.L0A/L0B)` 做 `.reinterpret(DT.int4)`。
- 转置后的载体视图，例如 `l1.T.reinterpret(DT.int4)`。

不允许：

- `GMTensor(DT.int4, ...)`
- `Tensor(DT.int4, ...)`
- `DBuff(DT.int4, ...)`
- `TBuff(DT.int4, ...)`
- `QBuff(DT.int4, ...)`
- `split_workspace(DT.int4, ...)`
- 在非 `DT.int` 载体上做 `.reinterpret(DT.int4)`
- 在 `UB` 或 `L0C` 上做 `.reinterpret(DT.int4)`
- 在 A5 系列（`a5`/`950` 或 `a5pr`/`950pr`）上做 `.reinterpret(DT.int4)`
- 在 `matmul` 或 `mmad` 之外使用 int4 视图

## matmul 规则

只有当 shortcut 的两个输入都是显式 int4 视图时，才会触发 int4 matmul：

```python
matmul(l0c, l1a.reinterpret(DT.int4), l1b.reinterpret(DT.int4), splitk=split_k, m=M, n=N, k=logical_k)
```

约束：

- `dst.dtype is DT.int`
- 两个输入都必须是 `DT.int4` 视图
- 两个输入背后都必须是 `DT.int` 载体
- `k` 是逻辑 int4 K
- `splitk` 是逻辑 int4 split K
- 静态 `splitk` 值必须能被 8 整除

对于 split-k，EasyASC 会通过转换逻辑区间来切片载体张量：

```text
carrier_start = logical_start // 8
carrier_valid_k = CeilDiv(valid_k, 8)
```

`MMAD` 的 K 参数仍然是逻辑值。EasyASC 不会在生成的 C++ 里对 K 做 padding；
kernel / MMAD 这一侧会自己处理内部 padding 行为。打包后的输入数据仍然要保证
被 padding 的 nibble 对目标 kernel 来说是合法值。

## codegen 期望

只有本地 compute 视图应该出现 `int4b_t`：

```cpp
LocalTensor<int4b_t> a4 = a_carrier.ReinterpretCast<int4b_t>();
LocalTensor<int4b_t> b4 = b_carrier.ReinterpretCast<int4b_t>();
MMAD(l0c, a4, b4, m, logical_k, n, is_init);
```

生成的代码不能创建 GM 或 host 的 int4 类型：

```cpp
// 不支持
GlobalTensor<int4b_t> input;
ge::DT_INT4
aclDataType::ACL_INT4
```

## nibble 顺序

当前内置模拟器和示例 kernel 使用低 nibble 优先的有符号 int4 打包顺序。上游
pack 逻辑需要用同样的载体顺序，才能和模拟器数值对齐。如果硬件路径与模拟器
不一致，先校准目标 `int4b_t` / `MMAD` 的 nibble 顺序，再考虑改 kernel 数学。

硬件校准时可以参考的两个候选方案：

```text
逻辑 int4: [0, 1, 2, 3, 4, 5, 6, 7]
低 nibble 优先候选：0x76543210
高 nibble 优先候选：0x01234567
```

## 验证范围

当前验证覆盖 Python 侧编写规则、生成 C++ 字符串检查，以及有符号 int4
打包载体 matmul 的模拟器执行。它不验证硬件层面的数值正确性。

相关测试入口：

```bash
pytest agent/example/testcases/codegen/tensor_buffer/test_int4_codegen.py agent/example/testcases/simulator/cube/test_int4_matmul_simulator.py
```
