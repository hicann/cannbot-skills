# MX FP8 / MXFP4 Matmul 说明

本文记录当前 A5 系列的 MX FP8 / MXFP4 编写约定。使用 `matmul_mx`、`l1_to_l0_mx`
或 `mmad_mx` 前，先看这份。

适用范围：

- 设备入口：`easyasc.a5` 或 `easyasc.a5pr`，`device_type in ("950", "950pr")`（Atlas 350 / C310）
- 数据格式：`DT.e4m3` / `DT.e5m2` 输入，或 packed MXFP4 `DT.fp4_e2m1`
  / `DT.fp4_e1m2` view；e8m0 scale 用 `DT.uint8` 承载
- shortcut 布局：NZ2NZ，以及通过 `l1a.T` 或 `l1b.T` 走 A/B 侧 NZ2ZN
- 底层布局：`l1_to_l0_mx` 支持 NZ2NZ 和 L0A/L0B NZ2ZN
- 当前 shortcut：支持不切分、split-K、split-N；不支持 split-K 和 split-N 同时打开

不覆盖：

- a2 / b 系列 MX FP8
- 高层 `matmul_mx` shortcut 中的转置 scale tensor
- split-K + split-N 的混合调度
- host 侧自动 scale 量化
- 自动把紧凑 tail tile pack 成 padded transpose tile

## Scale 存放和搬运约定（先看这里）

不要从逻辑公式盲猜 scale layout。MX scale 同时有三种视图，其中只有一种是外部
GM 存放约定。

逻辑数学视图：

```text
[rows, ceil(K / 32)]
```

这只是数学上的 scale 网格，不是传给 `gm_to_l1_mx_scale` 的 GM tensor shape。

外部 GM 存放视图：

```text
[row_tile, k64_block, 16, 2] 展平成 GMTensor(DT.uint8, [num_blocks, 32])
```

每个 32B block 包含一个 16 行 tile，以及两个 K-32 scale group：

```text
row0_group0, row0_group1, row1_group0, row1_group1, ..., row15_group0, row15_group1
```

L1 staging 视图：

```text
Tensor(DT.uint8, [16, 2 * k_blocks], Position.L1)
```

L1 声明是二维 shape，但 `gm_to_l1_mx_scale` 搬进去的字节仍然保持上面的 K-64
block stream。随后 `l1_to_l0_mx` 会把这些紧凑 scale 字节搬进隐藏的 `L0AMX`
或 `L0BMX` buffer。

写 kernel 时要记住：

- 不要把逻辑 `[rows, ceil(K / 32)]` GM tensor 直接传给 `gm_to_l1_mx_scale`
- 不要用 `gm_to_l1_nd2nz` 搬 MX scale；要用 `gm_to_l1_mx_scale`
- `row_tile_idx` 选择 A 或 B scale 的 16 行 tile
- `k_block_idx` 选择该 row tile 内的 K-64 scale block
- 当前 shortcut 中，split-K 的 scale slice 必须从 K-64 边界开始
- split-N 的 B-scale slice 按 16 行 `row_tile` 前进
- scale tensor 不能转置；底层 NZ2ZN 路径要求 scale 已经按转置后的行序打包好

Online cast 也必须生成同一套 scale layout。kernel 从 float 数据现场计算
MXFP8 scale 时，每个连续 K-32 group 产出一个 e8m0 byte：

```text
scale_byte = max((float_bits & 0x7f800000) >> 23) over the 32-value group
scale      = 2 ** (scale_byte - 127)
```

FP8 payload 用 `value / scale` 之后再 cast 成 `DT.e4m3` 或 `DT.e5m2`。如果整个
group 都是 0，`scale_byte == 0`；payload normalization 里的除数要按
`2 ** -127` 处理，不能真的除 0。

生成出来的 scale byte 必须直接按物理 MX block order pack 好再发到 L1。以
`K = 64` 为例，一个 16 行 tile 正好是一个 32B block，逻辑 shape 是 `[16, 2]`，
字节顺序是 `row0_g0, row0_g1, row1_g0, row1_g1, ...`。不要先写一个普通
row-major 的逻辑 scale tensor，再拿 ND2NZ 去搬它。

## 1. 基本概念

MX FP8 matmul 把 FP8 数据和 per-row、per-K-group 的 scale 分开存储。

逻辑计算是：

```text
out[M, N] = (A[M, K] * scale_a[M, K]) @ (B[N, K] * scale_b[N, K]).T
```

scale 用 e8m0 字节表示，解释规则是：

```text
scale = 2 ** (value - 127)
```

所以：

- `127` 表示 `1.0`
- `128` 表示 `2.0`
- `126` 表示 `0.5`

scale 的粒度是每行、每 32 个 K 元素一组：

```text
logical_scale_groups = ceil(K / 32)
```

## 2. Dtype

用户侧 FP8 源数据仍然使用普通 FP8：

- `DT.e4m3`
- `DT.e5m2`

L0 compute view 使用 MX FP8 dtype：

- `DT.mx_e4m3`
- `DT.mx_e5m2`

不要把 `DT.mx_*` 用在 GM 或 L1 源数据上。它们是 `l1_to_l0_mx` 加载到
L0A/L0B 之后的 compute view dtype。

scale 张量使用 `DT.uint8` 承载。底层实现也认识 `fp8_e8m0_t` 这种后端名字，
但正常 DSL 代码里用 `DT.uint8` 即可。

MXFP4 payload 不一样：没有可按字节寻址的 FP4 tensor。用户侧 GM/L1 payload
用 `DT.uint8` carrier 存 packed 字节，每个 byte 放两个逻辑 FP4 值。逻辑
compute view 这样建：

```python
l1_u8 = Tensor(DT.uint8, [rows, K // 2], Position.L1)
l1_fp4 = l1_u8.reinterpret(DT.fp4_e2m1)  # 或 DT.fp4_e1m2
```

`DT.fp4_e2m1` / `DT.fp4_e1m2` 映射到 CANN `fp4x2_e2m1_t` /
`fp4x2_e1m2_t`。它们的 `C0 == 64`，但 `size` 不支持，因为逻辑元素只有半个
byte。不要直接用 FP4 dtype 分配 `Tensor`、`DBuff`、`TBuff`、`QBuff`、
`GMTensor` 或 workspace。

底层 MXFP4 load 的 L0 目标也必须是 carrier tensor reinterpret 出来的同 dtype
FP4 view：

```python
l0_u8 = Tensor(DT.uint8, [rows, K // 2], Position.L0A)
l0_fp4 = l0_u8.reinterpret(DT.fp4_e2m1)
l1_to_l0_mx(l0_fp4, l1_fp4, scale_l1, m_dst=rows, n_dst=K, m_src=rows, n_src=K)
```

`matmul_mx` shortcut 可以直接吃 FP4 L1 view，并复用内部 L0 scratch buffer。
`mmad_mx` 的 L0C 目标仍然要求 `DT.float`，所以自然输出路径是 fp32 GM：

```python
matmul_mx(l0c_float, l1a_fp4, l1b_fp4, scale_a, scale_b, m=M, n=N, k=K)
z_fp32[:, :] <<= l0c_float
```

当前完整验证过的 MXFP4 路径覆盖 `DT.fp4_e2m1` 与 `DT.fp4_e1m2` 之间的
四种 FP4 format pairing：e2m1/e2m1、e1m2/e1m2、e2m1/e1m2、e1m2/e2m1。
CANN 9.0 CANNSIM 已分别覆盖每种 FP4 pairing 的 12 个 shortcut 组合：
non-transpose、A-only transpose、B-only transpose、both-side transpose 分别乘上
no split、split-K、split-N。FP8/FP4 混合 MX operand 目前会拒绝。

CANN 9.0 / Ascend950 的 `MMAD_MX` 上，FP4 累加使用下面的 decode value，再
叠加 e8m0 scale：

```text
e2m1: [0, 0.5, 1, 1.5, 2, 3, 4, 6]
e1m2: [0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75]
```

sign bit 负责对 decode magnitude 取负。任一 operand 的 scale byte 加一仍然
会让该 operand 翻倍。

FP4 NZ2ZN transpose load 要求物理 FP4 source block 是 `64 x 64`。当逻辑
transpose operand 更窄时，需要先 pad L1 carrier tile，再调用
`matmul_mx(..., l1x.T, ...)` 或 `l1_to_l0_mx(..., src.T, ...)`。

## 3. Scale 布局

单个操作数的逻辑 scale shape 是：

```text
[rows, ceil(K / 32)]
```

其中：

- A scale 的 `rows` 是 `M`
- B scale 的 `rows` 是 `N`

物理搬运格式按 K-64 block 打包。每个 K-64 block 包含一个 16 行 tile 上的两组
K-32 scale：

```text
[16, 2]
```

一个 block 内部 32 个字节按行排列；同一行的两个 K-32 group 相邻。

对于一个 16 行 L1 tile，scale 张量应该写成：

```python
scale_l1 = Tensor(DT.uint8, [16, 2 * CeilDiv(K, 64)], Position.L1)
```

外部 GM scale 使用紧凑 block 流：

```text
[row_tile, k64_block, 16, 2] 展平成 [num_blocks, 32]
```

当前 helper 要求 GM 对象是：

```python
scale_gm = GMTensor(DT.uint8, [num_blocks, 32])
```

这个紧凑 `[num_blocks, 32]` GM 对象是 `gm_to_l1_mx_scale` 的强约定；它不是
逻辑 `[rows, ceil(K / 32)]` 视图。

例如：

- `K = 64` 时，一个 16 行 tile 是 `[1, 32]`
- `K = 128` 时，一个 16 行 tile 是 `[2, 32]`

如果 K-32 组数是奇数，最后一个 K-64 pair 的第二个字节从逻辑 scale 角度看是
padding。

如果调用方已经持有逻辑矩阵 `[rows, ceil(K / 32)]` 形式的 dense e8m0
scale，应使用 `gm_to_l1_mx_scale_nd2nz(...)`，而不是手工预打包
`[num_blocks, 32]`。这个 helper 会把相邻 e8m0 值 reinterpret 为 `half`，
再用 A5 `Dn2NzParams` 路径物化出同样紧凑的 L1 MX scale stream：

```text
[ceil(rows / 16), ceil(ceil(K / 32) / 2), 16, 2 bytes]
```

等价地，从字节视角看，L1 可见 shape 仍然是：

```text
[rows, 2 * ceil(ceil(K / 32) / 2)]
```

### 底层 L0 转置 / NZ2ZN

这里故意写得明显一点，因为 scale 很容易被想当然搞错：`LoadData2DMxParams`
不会 transpose scale。NZ2ZN load 里，scale tile 必须已经按转置后的逻辑操作数
行序打包好。

高层 `matmul_mx` shortcut 在调用方传 `l1a.T` 和 / 或 `l1b.T` 时支持这条
转置路径。底层 `l1_to_l0_mx` 对 `L0A` 和 `L0B` 都支持 `src.T`。

对于物理形状为 `[K, M]`、使用时当成 `A.T` 的 A 源 tile，显式数据参数仍然按
物理源顺序传：

```python
l1_to_l0_mx(l0a, l1a_km.T, scale_a, m_dst=K, n_dst=M, m_src=K, n_src=M)
```

对应的 scale tile 不是 `[K, 2 * ceil(M / 64)]`，而是：

```text
[M, 2 * ceil(K / 64)]
```

行是逻辑 A 行 / 输出 M，K group 仍然描述 reduction 轴。

对于物理形状为 `[K, N]`、使用时当成 `B.T` 的 B 源 tile，显式数据参数仍然按
物理源顺序传：

```python
l1_to_l0_mx(l0b, l1b_kn.T, scale_b, m_dst=K, n_dst=N, m_src=K, n_src=N)
```

对应的 scale tile 不是 `[K, 2 * ceil(N / 64)]`，而是：

```text
[N, 2 * ceil(K / 64)]
```

这就是转置后的行序：行是逻辑 B 行 / 输出 N。底层字节流仍然沿用上文 K-64
`[16, 2]` block 的打包约定。

静态 NZ2ZN tile 要求物理源的两个维度都按 C0 对齐：FP8 为 32 个
元素，FP4 为 64 个元素。遇到 tail 时，要先准备 padded L1 数据 tile。
`zero_mxfp8_l1_padding(tensor)` 可以清零单字节 FP8 数据 tile，也可以
清零 FP4 的 `DT.uint8` carrier tile；然后 kernel 再填 live scale/data。只要
对应 payload lane 是 0，scale padding 本身不需要初始化。

不要把 `gm_to_l1_nd2nz` 当成“紧凑 GM 到 padded transpose L1”的万能 packer。
例如把紧凑 `[K, 16]` GM tile 直接搬到 padded `[K, 32]` L1 transpose tile，
CANNSIM 验证里会出错；这个场景需要真正的 packing/copy 路径。

底层 NZ2ZN 和 tiling 组合时，要把 scale 当成物理 MX block stream，用显式
offset 切：

- split-K：任意转置操作数都保留完整的预转置 scale tile，shape 是
  `[rows, 2 * ceil(total_K / 64)]`，并传
  `src_mx_offset_element = (subk // 64) * 32`；不要用普通
  `scale[:, scale_col0:...]` 去切转置 scale。
- split-N：`l1b.T` 会按 C0 对齐的 chunk 切物理 B 数据（FP8 是 32 个元素，FP4
  是 64 个元素），B scale tile 保持完整，并传
  `src_mx_offset_element = (subn // 16) * ceil(K / 64) * 32`。`l1a.T` 在
  split-N 中只加载一次，所以 A scale 没有 N 轴 offset。

只要显式传了 `src_mx_offset_element`，`l1_to_l0_mx` 就允许更大的完整物理
scale tile，而不是强制要求可见 shape 必须等于当前小 tile。这样动态 loop 和
静态 unroll 的 split chunk 行为是一致的。

转置 B 的 split-N chunk 粒度是格式相关的：FP8 因为 `C0 == 32`，所以使用 32
元素 chunk；FP4 因为 `C0 == 64`，所以使用 64 元素物理 chunk。当前 NZ2ZN 的
B 侧列切分路径不是 16 列 tail 路径。CANNSIM 已验证覆盖的格式 / 对齐场景下的
12 种 shortcut 组合：无转置、只转置 A、只转置 B、两侧都转置，分别搭配不切分、
split-K 和 split-N。

shortcut 也完全沿用这套规则。`matmul_mx(..., l1a.T, l1b.T, ...)` 里，物理
A/B 源分别是 `[K, M]` 和 `[K, N]`，但 `scale_a` 和 `scale_b` 已经分别是
转置后行序的 `[M, 2 * ceil(K / 64)]` 与 `[N, 2 * ceil(K / 64)]`。shortcut
的 split-K 使用上面的 split-K scale offset；shortcut 的 split-N 只有在存在
`l1b.T` 时要求静态 split size 满足转置加载对齐：FP8 为 32 个元素，FP4 为 64
个元素。

## 4. 高层 Shortcut

### `matmul_mx(dst, l1a, l1b, scale_a, scale_b, splitk=None, m=None, n=None, k=None, is_init=True, *, splitn=None, bias=None)`

作用：发射 MX FP8 / MXFP4 matmul staging 路径：

```text
L1 FP8/FP4 + L1 e8m0 scale -> L0A/L0B MX operands + L0AMX/L0BMX -> MMAD_MX -> L0C
```

逻辑约定：

```text
l1a[M, K] @ l1b[N, K].T -> dst[M, N]
```

限制：

- 仅 A5 系列
- `dst` 必须是位于 `Position.L0C` 的 `DT.float`
- `l1a` 和 `l1b` 必须是位于 `Position.L1` 的 `DT.e4m3` / `DT.e5m2` tensor，
  或 `DT.fp4_e2m1` / `DT.fp4_e1m2` carrier-backed view
- `scale_a` 和 `scale_b` 必须是位于 `Position.L1` 的 `DT.uint8`
- `l1a.T` 与 `l1b.T` 分别支持物理 `[K, M]` / `[K, N]` 源，但 A/B scale
  必须已经按转置后行序打包好；转置 scale tensor 会被拒绝
- `splitn` 和 `splitk` 不能同时设置
- 静态 `splitk` 必须是 `64` 的倍数
- 静态 `splitn` 必须是 `16` 的倍数；使用 `l1b.T` 时静态 `splitn` 还必须满足
  转置加载对齐：FP8 为 32 个元素，FP4 为 64 个元素
- 如果带 `bias`，它必须是先 stage 到 L1 的连续 fp32 `[1, N]` 行；shortcut
  会把它加载到 BT / `TPosition::C2`，并且只在 init tile 上应用，所以 `bias`
  要求 `is_init=True`；A5/A5PR 自动 BT slot 每个容纳 512 个 fp32 元素，因此
  nosplit/split-K 需要静态 `N <= 512`，动态总 N 必须使用静态 `splitn <= 512`

当前行 tile 约束：

- 不切分和 split-K 路径中，非转置操作数的 scale 是 16 行物理 tile
- 对 `l1a.T`，A scale 行数是逻辑 M，shape 是 `[M, 2 * ceil(K / 64)]`
- 对 `l1b.T`，B scale 行数是逻辑 N，shape 是 `[N, 2 * ceil(K / 64)]`
- split-N 要求 `scale_a` 覆盖当前 A 行：非转置 A 是一个 16 行物理 tile；
  `l1a.T` 则是完整的转置后 M 行
- split-N 要求 `scale_b.shape[0]` 匹配完整 B 逻辑行数，这样 B scale 行 tile
  才能按 16 行块寻址

最小固定 tile 示例：

```python
@kernel()
def mx_kernel(x: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
              z: GMTensor, M: Var, N: Var, K: Var):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1)
    l1b = Tensor(DT.e4m3, [16, 64], Position.L1)
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1)
    l0c = Tensor(DT.float, [16, 16], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(l0c, l1a, l1b, scale_a, scale_b, m=M, n=N, k=K)
        z[:, :] <<= l0c
    return z
```

## 5. 底层 API

普通 kernel 优先使用 `matmul_mx`。底层 helper 更适合测试或特殊 staging 路径。

### `gm_to_l1_pad(dst, src, n_burst=None, burst_len_element=None, src_stride_element=None, dst_stride=None)`

作用：normal-mode GM 到 L1 的 padded copy。它不像 `gm_to_l1_nd2nz` 那样要求 GM
上的逻辑 burst 本身 32B 对齐；每个目的 burst 会 padding 到 32B 边界。

`gm_to_l1_mx_scale` 用它从 GM 搬紧凑 scale block。

### `gm_to_l1_mx_scale(dst, src, row_tile_idx=0, k_blocks=None, src_k_blocks=None, k_block_idx=0)`

作用：从 packed GM scale 复制一个 16 行 MX scale tile 到 L1。

参数：

- `dst`：`Tensor(DT.uint8, [16, 2 * k_blocks], Position.L1)`
- `src`：`GMTensor(DT.uint8, [num_blocks, 32])`
- `row_tile_idx`：复制第几个 16 行操作数 tile
- `k_blocks`：复制几个 K-64 scale block
- `src_k_blocks`：GM 中每个 row tile 有几个 K-64 block
- `k_block_idx`：从该 row tile 的第几个 K-64 block 开始

如果省略 `k_blocks`，会从 `dst.shape[1] // 2` 推导。如果省略 `src_k_blocks`，
默认等于 `k_blocks`。

对于超过 16 行的完整转置后 scale tile，可以发多次 row-tile copy，也可以用
`gm_to_l1_pad` 直接 stage 整个 packed block stream。物理 GM 顺序仍然是
`[row_tile, k64_block, 16, 2]` 展平成 `[num_blocks, 32]`。

### `gm_to_l1_mx_scale_nd2nz(dst, src, rows=None, k_groups=None, src_k_groups=None)`

作用：把 dense GM e8m0 scale 直接搬到紧凑 L1 MX scale layout，调用方
无需先把它手工预打包成 `[num_blocks, 32]`。

参数：

- `dst`：`Tensor(DT.uint8, [rows, 2 * ceil(k_groups / 2)], Position.L1)`
- `src`：`GMTensor(DT.uint8, [rows, k_groups])`
- `rows`：逻辑行数；当前要求按 16 行对齐
- `k_groups`：逻辑 e8m0 列数，即 `ceil(K / 32)`
- `src_k_groups`：以 e8m0 元素计的物理 GM row stride；默认等于
  `k_groups`

如果三个 shape 参数都省略，helper 会从可见 GM slice 推导：

- `rows = src.span[0]`
- `k_groups = src.span[1]`
- `src_k_groups = src.shape[1]`

lowering 会把 `src` 和 `dst` reinterpret 为 `half`，使每个 `half` 承载两个
相邻 e8m0 值，再用 `Dn2NzParams` 生成紧凑的物理目标顺序：

```text
[ceil(rows / 16), ceil(k_groups / 2), 16, 2 bytes]
```

这条路径已在 Ascend950 CANNSIM 上与底层 `l1_to_l0_mx` / `MMAD_MX`
合同匹配，覆盖：

- `rows = 16, k_groups = 4`（`K = 128`）
- `rows = 32, k_groups = 2`（`K = 64`）
- `rows = 32, k_groups = 4`（`K = 128`）

### `l1_to_l0_mx(dst, src, src_mx, m_dst=None, n_dst=None, m_src=None, n_src=None, src_mx_offset_element=0)`

作用：把 FP8 数据或 carrier-backed FP4 view 从 L1 搬到匹配的 L0A/L0B compute
view，同时把匹配的 scale 字节搬到隐藏的 L0AMX 或 L0BMX buffer。

lowering：

```text
L0NZ2NZ_MX(dst, src, src_mx, m_dst, n_dst, m_src, n_src)
L0NZ2ZN_MX(dst, src, src_mx, m_dst, n_dst, m_src, n_src)  # src.T
```

限制：

- 仅 A5 系列
- `src` 必须是位于 `Position.L1` 的 `DT.e4m3` / `DT.e5m2`，或由 `DT.uint8`
  carrier reinterpret 出来的 `DT.fp4_e2m1` / `DT.fp4_e1m2`
- `dst` 必须是位于 `Position.L0A` 或 `Position.L0B` 的匹配 MX FP8 dtype，
  或 matching FP4 carrier view
- `src_mx` 必须是位于 `Position.L1` 的 `DT.uint8`
- 非转置 `src` 走 NZ2NZ
- `Position.L0A` 与 `Position.L0B` 都支持 `src.T` 走 NZ2ZN
- `src_mx` 不能转置
- 静态 MX NZ2ZN tile 要求物理源两个维度对齐：FP8 按 32 个元素，FP4 按 64
  个元素
- MX start position 固定为 0，不从外部传入

非转置路径中，`l1_to_l0_mx` 看到的 scale shape 是：

```text
[m_src, 2 * ceil(n_dst / 64)]
```

在 matmul 中，`n_dst` 就是当前加载操作数的有效 K。

转置 A 路径中，如果物理源 shape 是 `[K, M]`，显式参数是
`m_dst=K, n_dst=M, m_src=K, n_src=M`，那么可见 scale shape 是：

```text
[M, 2 * ceil(K / 64)]
```

转置 B 路径中，如果物理源 shape 是 `[K, N]`，显式参数是
`m_dst=K, n_dst=N, m_src=K, n_src=N`，那么可见 scale shape 是：

```text
[N, 2 * ceil(K / 64)]
```

再次强调，scale 是靠存储顺序提前转置好的；MX load 不会帮你转。

### `zero_mxfp8_l1_padding(tensor, n_blocks=None)`

作用：在填充 live transpose 数据之前，先清零 padded 的单字节 L1 数据 tile。
这个 shortcut helper 由 A5 系列 facade（`easyasc.a5` 和 `easyasc.a5pr`）导出；
名字保留 FP8 标识，但同样适用于
FP4 `DT.uint8` carrier tile。

限制：

- 仅 A5 系列
- `tensor` 必须是位于 `Position.L1` 的单字节 tensor，例如 `DT.e4m3` 或
  `DT.e5m2`，或者 FP4 `DT.uint8` carrier tile
- `tensor` 必须是物理 tensor，不能是 transpose view
- 如果省略 `n_blocks`，静态 tensor footprint 必须 32B 对齐

这个 helper 要在填 live scale/data 之前调用。A5 constant fill 的粒度比较粗，
如果先填数据再调用它，可能把有用字节也清掉。

### `mmad_mx(dst, src_a, src_b, M=None, N=None, K=None, is_init=True, bias=None)`

作用：从已经加载好的 L0 操作数执行 MX FP8 / MXFP4 matmul。

lowering：

```text
MMAD_MX(dst, src_a, src_b, M, K, N, is_init)
MMAD_MX_BIAS(dst, src_a, src_b, bias, M, K, N, is_init)  # 传入 bias 时
```

限制：

- 仅 A5 系列
- `dst` 必须是位于 `Position.L0C` 的 `DT.float`
- `src_a` 必须是位于 `Position.L0A` 的 MX FP8 或 FP4 view
- `src_b` 必须是位于 `Position.L0B` 的 MX FP8 或 FP4 view
- 两个 source 必须属于同一 family：FP8/FP8 或 FP4/FP4
- 如果传入 `bias`，它必须是位于 `Position.BT` 的 `DT.float`（fp32）tensor；
  只在 `is_init` tile 上应用，并 lowering 成 `MMAD_MX_BIAS`

`is_init=False` 会累加到已有 L0C tile。split-K 在第一个 K chunk 之后就依赖这个
行为。

## 6. Split 行为

### 不切分

shortcut 加载一次 A、B、A-scale、B-scale，然后发射一个 `MMAD_MX`。

### Split-K

`splitk` 切 K 维。每个 chunk：

- A/B 数据按 K 切片
- A scale 按 K-32 group 切片
- 非转置 B scale 按 K-32 group 切片
- 每个转置操作数都保留完整的转置后 scale tile，并用
  `src_mx_offset_element = (_subk // 64) * 32` 前进
- 如果调用方 `is_init=True`，第一个 chunk 初始化 L0C
- 后续 chunk 使用 `is_init=False`

静态 `splitk` 必须能被 `64` 整除，以匹配当前 K-64 scale block 搬运模型。

### Split-N

`splitn` 切 B 行和 L0C 列。每个 N chunk：

- A 只在 `_subn == 0` 时加载一次
- B 数据按 N 切片；对于 `l1b.T`，切的是物理 B 数据列，chunk size 必须满足
  格式对应的 C0 对齐：FP8 为 32 个元素，FP4 为 64 个元素
- `l1a.T` 仍然只加载一次，因为 split-N 不切 A
- B scale 通过 16 行 tile offset 选中：

```text
scale_b_offset = (_subn // 16) * CeilDiv(K, 64) * 32
```

Split-N 写的是互不重叠的 L0C 列，因此调用方的 `is_init` 标志会作用到每个 N
slice，而不是只作用第一个 N slice。

## 7. 模拟器模型

模拟器会为每个 core 分配两个隐藏本地 buffer：

- `L0AMX`：4 KB
- `L0BMX`：4 KB

`l1_to_l0_mx` 会根据 L0 目的位置，把 scale 字节搬到其中一个 buffer。模拟器
还会为本次 L0 operand 保留一份 scale snapshot，避免 split-K 或 split-N 的后续
prefetch 覆盖已经发出去的 `mmad_mx` 所需 scale。模拟器现在覆盖 NZ2NZ 和
L0A/L0B NZ2ZN 执行路径。`mmad_mx` 随后会：

1. 把 L0A/L0B NZ FP8 解码成逻辑 `[M, K]` 和 `[N, K]`
2. 解码 L0AMX/L0BMX 中的 e8m0 scale 字节
3. 把每个 scale group 展开到 32 个 K 列
4. 做 float32 matmul
5. 用固定 `C0 = 16` 写回紧凑 L0C NZ

cycle model 中，`mmad_mx` 走和 `mmad` 相同的按位宽估算路径；MX FP8 按 8-bit
matmul 看待。

## 8. 验证范围

相关回归入口：

```bash
pytest agent/example/testcases/codegen/datamove/test_l1_to_l0_mx_codegen.py
pytest agent/example/testcases/simulator/cube/test_l1_to_l0_mx.py
```

当前模拟器测试覆盖：

- `l1_to_l0_mx` 加载 L0AMX 和 L0BMX
- identity scale（`127`）
- 非单位 scale（`126`、`128`）
- split-K 的 L0C 累加
- split-N 的 L0C 列切片
- 带外部 GM scale 的 `OpExec(..., simulator=True)` shortcut 端到端执行
- 无转置、只转置 A、只转置 B、两侧都转置分别搭配不切分、split-K、split-N
  的 12 组 shortcut simulator smoke

额外的 NZ2ZN 验证：

- `L0NZ2ZN_MX` codegen 覆盖
- `M=N=32,K=64` 和 `M=N=64,K=64` 的 CANNSIM smoke
- 非均匀 scale byte 下的 transpose+split-K 与 transpose+split-N CANNSIM smoke
- shortcut 级 12 组 transpose/split CANNSIM smoke，全部和 PyTorch reference
  对齐且 max diff 为 0
