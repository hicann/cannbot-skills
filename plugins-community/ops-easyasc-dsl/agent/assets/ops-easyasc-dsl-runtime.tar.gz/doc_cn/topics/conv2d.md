# 基于 load3d img2col 的 Conv2D

910B3 与 Ascend950 已验证的 fp16 conv 路径契约说明。使用 `Conv2D`、
`img2col`、`l1_to_l0a_img2col` 或 `conv2d` shortcut 前先读本文。

适用范围:

- 设备：`easyasc.a2`（910B / C220），或 A5 系列入口 `easyasc.a5` 与
  `easyasc.a5pr`（950 / 950PR，C310）；fp16 输入与权重，fp32 累加
- 每次调用一层 conv；pure compute 样例里的 transdata 全部在 host 完成；shortcut 路径本身不做设备侧 transdata
- 权重常驻 L1;feature map 按 batch 重新加载

## 计算流程

```text
调用方(kernel 内):                              conv2d()(与 matmul 同范围):
  GM data  -- <<= --> L1 fmap(NC1HWC0)              每个 k0 分块:
  GM weight -- <<= --> L1 [Cout_p, K](NZ≡B ZN)        L1 fmap -- l1_to_l0a_img2col --> L0A
  GM bias -- ND <<= --> L1 [1, Cout_p] f32 行          L1 权重 -- l1_to_l0(切列) --> L0B
  m 循环 / 多核 If 门                                   mmad(L0C += L0A @ L0B,
  conv2d(l0c, fm, w, conv, ..., m0, bias=b_l1)              首 K 块经 BT 加 bias)
  l0c_to_gm_nz2nz(out[m0:m0+tile_m, :], l0c)     输出:NZ 平面 [C1o*M_pad, C0](NC1HWC0)
```

`conv2d` 只负责单个 M tile 的 L1 -> L0 -> mmad -> L0C（与 `matmul` 同界）；
GM->L1（含 bias）、m 循环、多核门与 L0C->GM 全由调用方持有。
`l0c_to_gm_nz2nz` 保持 NZ：条带 c1 落在平面行 `c1*M_pad + m`；需要 ND
输出时使用 `out[...] <<= l0c`。

conv 由此化为普通 matmul：`M = Ho*Wo` 个输出点，`K = C1*Kh*Kw*C0`，
`N = Cout_p`。img2col 由 load3d 硬件即时完成，L1 中没有数据复制。

## shortcut 合同

`conv2d()` 只覆盖单个 M tile，调用方可以复用一个 `Tensor` L0C，直接做
`conv2d(...) -> store -> conv2d(...)` 的外层循环：

- helper 会在每次 mmad 后插入 `barrier(Pipe.M)`，收掉 load3d 路径上的 L0C 复用 WAR；
  这在 A2 上是必须的，在 A5/A5PR 上是无害的
- helper 会在消费 init-tile bias 的 mmad 之后，通过 kernel BT 槽位 ping-pong
  (`btbufcnt`) 收掉不同 bias tile 之间的 BT 复用问题

稳定合同是：调用方持有外层循环与写回；`conv2d()` 持有内部 cube hazard。

## A5 系列特有说明

- `easyasc.a5` 与 `easyasc.a5pr` 都导出和 `easyasc.a2` 同名的 `conv2d`
  shortcut；kernel 合同仍然是“GM->L1、`m` 循环、多核门、写回在调用方”
- A2 与 A5 系列的逻辑 img2col 矩阵完全一致，但最终的 L0A 编码不同：
  A2 load3d materialize ZZ，A5/A5PR materialize NZ
- A5 系列 load3d **没有 K 向 destination stride**。因此 helper 会在
  `L12L0A_IMG2COL` 内部按 C0 K-fractal 循环，一次发一个硬件 load3d，并在每次
  调用后推进 L0A 目标位置；DSL 调用点仍然只有一条
  `l1_to_l0a_img2col(l0a, acc.window(...))`
- A5 系列参考 pure-cube 样例位于 `agent/example/kernels/a5/conv/compute/`；A5PR 复用该实现族

## 运行时形状(Var)

`h/w/c/cout/m0` 与 `l0c_to_gm_nz2nz` 的 `m_pad` 均接受 Var。L1/L0 张量保持静态
worst-case 容量,运行时形状只对尾部做掩零(通道/Cout 尾零,超出 `Ho*Wo` 的 m 行为零)。规则:

- Var `c` 使 K 动态:此时 `tile_k` 必填(静态,且需整除所有运行时 K)。conv2d 先发
  静态首个 K 分块(is_init + bias),其余走运行时 `range` 尾循环——`K == tile_k` 时尾循环为空。
- Var 起点下 `acc[m0:m0+ext]` 切片无法折出静态长度;改用
  `view.window(m0, k0, m_ext, k_ext)`(长度保持静态 int)。
- Var C 的 channelSize 在运行时取整到整 C0 块(与静态规则一致;非整块
  channelSize 会重排 K 网格导致整体出错,见约束表)。
- m 循环:`for m0 in range(0, m_pad, TILE_M)`,`m_pad` 为 host 计算的 16 对齐 Var。
  OpExec 会把标量实参与相等的 GM 维度自动绑定——保持取值与 GM 维度两两不同,
  否则传 `shape_bindings`。

## 输入 / 输出格式(host 打包)

这两个与 target 无关的 host helper 都应从 `easyasc.utils.conv2d` 导入。
`easyasc.a2` 还会重新导出它们；当前 A5 系列 facade 不会。

`pack_nc1hwc0(x[N, C, H, W]) -> [N*C1*H*W, C0]` — 通道尾零填充。

`pack_conv_weight(w[Cout, Cin, Kh, Kw]) -> [Cout_p, K]` ND 行主序,K 序
`c1 -> kh -> kw -> c0`,C/Cout 尾零填充。通过 `w_l1 <<= weight`(nd2nz)送入;
`[Cout, K]` 的 L1 NZ 恰为 mmad B 侧的 ZN。**绝不要自行打 `[K, N]` ZN 分形**——
NZ 与 ZN 的块网格互为转置,每个 N 块会静默配错 K 块(910B3 实测,输出貌似合理实则全错)。

bias 为平铺 fp32 `[1, Cout_p]` 行,由调用方以 `layout=Layout.ND` 的 L1 张量
`<<=` 平铺搬运(与 matmul 同形),`conv2d(bias=b_l1)` 内部经 kernel BT 缓冲;
严禁用默认 `<<=`(nd2nz 会把行分形化)。

输出(NZ 存储):每 batch fp32 平面 `[C1o*m_pad, C0]` 即 NC1HWC0;host 取
`got[m, c] = out[c//16*m_pad + m, c%16]`。行 `>= Ho*Wo`、通道 `>= Cout` 为零。
仍可用 `out[...] <<= l0c` 输出 ND。

## load3d 行为逐参数(可运行 golden)

img2col 虚拟矩阵(单 batch):

- 行 `m = ho*Wo + wo` 枚举输出点(W 快变);
- 列 `k = ((c1*Kh + kh)*Kw + kw)*C0 + c0`(c0 最快);
- 窗口 `[m0:m0+m_ext) x [k0:k0+k_ext)`:m 按 16 对齐,k 按 C0 对齐;
- 越界读(M 尾、空间 pad、通道尾)返回 padValue 0。

PyTorch 模型(与硬件及 `simulator/pipe_cube.py` 一致):

```python
import torch

def load3d(fm, c, pad, stride, dil, kh, kw, k0, k_ext, m0, m_ext):
    # fm: [C1, H, W, C0];返回写入 L0A 的 [m_ext, k_ext] 分块
    c1, h, w, c0 = fm.shape
    pl, pr, pt, pb = pad; sh, sw = stride; dh, dw = dil
    ho = (h + pt + pb - (dh*(kh-1)+1)) // sh + 1
    wo = (w + pl + pr - (dw*(kw-1)+1)) // sw + 1
    m, k = m0 + torch.arange(m_ext), k0 + torch.arange(k_ext)
    oh, ow = m // wo, m % wo                      # m: W 快变光栅序
    kc1, r = k // (kh*kw*c0), k % (kh*kw*c0)      # k: c1 -> kh -> kw -> c0
    fkh, r = r // (kw*c0), r % (kw*c0)
    fkw, kc0 = r // c0, r % c0
    ih = (oh*sh - pt)[:, None] + (fkh*dh)[None, :]    # stride/pad/dilation 只移动
    iw = (ow*sw - pl)[:, None] + (fkw*dw)[None, :]    # 采样的 h/w 坐标
    ok = ((m < ho*wo)[:, None] & (ih >= 0) & (ih < h) & (iw >= 0) & (iw < w)
          & (kc1*c0 + kc0 < c)[None, :])              # 其余 = padValue 0
    flat = ((kc1[None]*h + ih.clamp(0, h-1))*w + iw.clamp(0, w-1))*c0 + kc0[None]
    return fm.reshape(-1)[flat] * ok

# 参数效果, 取 fm[c1, ih, iw, c0] = c1*1e6 + ih*1e4 + iw*100 + c0:
c1, h, w, c0 = 2, 6, 6, 16
fm = (torch.arange(c1)[:, None, None, None]*1e6 + torch.arange(h)[None, :, None, None]*1e4
      + torch.arange(w)[None, None, :, None]*100 + torch.arange(c0)).float()
def t(**kw):
    a = dict(c=32, kh=3, kw=3, pad=(1,1,1,1), stride=(1,1), dil=(1,1),
             k0=0, k_ext=288, m0=0, m_ext=16)
    a.update(kw); return load3d(fm, **a)

t()[0, :3]               # [0,0,0]      输出(0,0), k 0..2 是左上角 tap -> pad
t()[0, 64:67]            # [0,1,2]      k=64 = (kh=1,kw=1) 中心 tap = fm[0,0,0,:]
t(stride=(2,2))[1, 64]   # 200          输出(0,1) 跨 2 列 -> fm[0,0,2,0]
t(dil=(2,2))[5, 64]      # 20200        tap 拉伸: 输出(1,1) 中心 -> fm[0,2,2,0]
t(m0=16)[0, 64]          # 20400        mStartPt: 矩阵不变, 窗口移到行16 = 输出(2,4)
t(k0=144, k_ext=144)[7, 0]  # 1000000   kStartPt=144 从 c1=1 起 -> fm[1,0,0,0]
```

各参数的全部效果:`pad/stride/dilation` 只改变采样坐标 `(ih, iw)`;
`kh/kw/C` 决定 K 分解;`m0/k0/m_ext/k_ext` 只开窗。K 布局与
pad/stride/dilation 无关,因此任意 conv 几何共用同一权重打包。

## 约束(trace 期检查;违反则硬件静默出错数据)

| 参数 | 约束 |
| --- | --- |
| m0 / m_ext | 16 的倍数;m0 <= 32767 |
| k0 / k_ext | C0 的倍数(fp16: 16);窗口不越 K |
| stride / filter / dilation | 1..63 / 1..255 / 1..255 |
| pad | 0..255 |
| H, W | 1..32767 |
| C | fmap 按整 C1 块;通道尾 host 零填充。stub 把 channelSize 取整到整 C0 块:余数 4/8 名义合法,但会把 K 网格按 C*Kh*Kw 紧凑重排,与 C0 网格的权重打包整体错位(C=31 裸传与 C=20→24 910B3 实测均错;零尾使整块取整数学等价) |
| L1 占用 | 整 fmap + 权重常驻:C1*H*W*32B + 2*Cout_p*K B |
| dst | 仅 L0A,512B 对齐槽位 |
| 分块 | conv2d 走 kernel L0 DBuff:tile_m*tile_k 与 tile_k*cout_p 各自不得超过 32KB L0 槽 |

## 易错点

- 权重打成 `[K, N]` ZN 时,identity 权重二分的症状是输出列对到 `x[c=16..]`,
  酷似"通道最快的 K 序";真因是 NZ/ZN 块网格转置——勿改 K 序,改用
  `[Cout, K]` ND。
- 大 C·H·W 需要 L1 K 分段加载(暂不支持);大 COUT 需要 N 切分。
- 不同 bias 的 cout tiling 应依赖 shortcut 内部的 BT ping-pong；不要继续沿用
  旧的“强制只用槽0”类临时规避写法。
- bias tile 必须能放进一个设备 BT slot：A2 最多 64 个 fp32 元素，A5/A5PR
  最多 512 个；L0/cube tile 容量仍需独立满足。
- 原生 NZ fixpipe 必须显式传 CFG_NZ 模板参——默认配置是 NZ2ND,会把
  dstStride 当 ND 行宽(即此前 dump 的行交织)。CFG_NZ 下 dstStride =
  条带间隔(32B 块,fp32 即 mPad*2;copy_matrix 的 dst_M*2 习惯)——
  每 tile 一次 fixpipe,910B3 扫档验证。quantPre 与 NZ2ND 同套
  (relu/scale/offset;fp32→fp16 与 int8 量化已板验);dst 的 NC1HWC0 C0 =
  32B/sizeof(dst):fp32/fp16 为 16,int8 为 32。

样例:`agent/example/kernels/a2/conv/compute/`、`agent/example/kernels/a5/conv/compute/`。
