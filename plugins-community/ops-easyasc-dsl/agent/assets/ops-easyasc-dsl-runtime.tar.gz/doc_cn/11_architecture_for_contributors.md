# 面向贡献者的架构说明

本文面向那些需要修改框架本身的人，而不只是基于它来写 kernel 的人。

## 1. 仓库结构

主要源码区域包括：

- `easyasc/`
  - 公开 DSL 接口
  - parser 与 lowering
  - 模拟器运行时
  - 指令发射器与辅助函数
- `agent/example/kernels/`
  - 样例 kernel 与可运行验证脚本
- `agent/example/testcases/`
  - 先按断言类型、再按功能方向组织的自动化 pytest 覆盖
- `agent/scripts/`
  - 独立工具与维护脚本
- `doc/`
  - 英文项目与 API 文档
- `doc_cn/`
  - 中文文档镜像
- `agent/`
  - router-first 指导、目录索引与实现路径映射
- `agent/example/projects/`
  - 把多个 kernel 接成完整算法的多文件系统工程（例如 `agent/example/projects/a5/gdn_fwd/` 与 `agent/example/projects/a5/gdn_bwd/`）

高层 owner 文档包括：

- `README.md`、`README_CN.md`
  - 顶层项目入口
- `AGENTS.md`
  - 面向 agent 式贡献者的仓库规则
- `agent/ROUTER.md`
  - router-first 入口：把读者引导到最小够用的 playbook 或参考页，而不是一次性加载所有地图
- `agent/references/authoring-preflight.md`
  - kernel 编写流程必须读取的精简检查清单；只由 authoring workflow 加载
- `agent/references/repo-map.md`
  - 顶层布局与归属说明
- `agent/references/code-paths.md`
  - 实现路径速查
- `agent/references/facts-simulator-opexec.md`
  - 模拟器与 `OpExec` 行为速查；完整实现路径见 `agent/references/code-paths.md`
- `agent/example/testcases/README.md`
  - 测试目录的归属与边界

## 2. 设备家族映射

在阅读任何和硬件分支相关的代码前，先把这层映射记清楚：

- `device_type in ("950", "950pr")` 对应 C310 路径
- `is_c220_family(device_type)`（`b*` 或 `a3`）对应 C220 路径
- 在 `easyasc/resources/tensorutils.h` 中，`__DAV_C310__` 就是 950-family 分支
- 在 `easyasc/resources/tensorutils.h` 中，`__DAV_C220_CUBE__` 就是 `b*` 分支

很多支持性判断、helper 选择和生成代码路径都依赖这层映射。
看仓库时不要把它反过来。

Agent 文档采用刻意收窄的加载契约：

1. 从 `agent/ROUTER.md` 开始，只选择一条 route
2. 完整阅读 `agent/common-language.md`
3. 打开所选 workflow playbook
4. 编写 kernel 时，再读 `agent/references/authoring-preflight.md` 与该 workflow
   选中的一个设备事实或模式
5. 只有较小证据层不足时才检查源码

框架内部、测试、工具、catalog 与文档的维护工作由
`agent/playbooks/repository-maintenance.md` 负责。

## 3. 端到端控制流

典型的内部路径是：

1. 带装饰器的 Python 函数先被 `easyasc/pythonic.py` 转换
2. `@kernel` 把它包成 `KernelBase`
3. DSL 对象把操作发射成 `Instruction`，进入当前激活的 kernel 或 micro 上下文
4. `OpExec` 绑定运行时输入，并触发模拟器或生成流程
5. parser / lowering 路径或模拟器 bridge 路径消费这些指令
6. 模拟器运行时或生成出的运行时执行结果
7. 当多个标量值相同导致维度匹配歧义时，由 `shape_bindings` 参与消歧

关键入口模块有：

- `easyasc/decorators.py`
- `easyasc/kernelbase/kernelbase.py`
- `easyasc/torchplugin.py`

## 4. 对外接口模块

- `easyasc/a2.py`
- `easyasc/a3.py`
- `easyasc/a5.py`
- `easyasc/a5pr.py`
- `easyasc/flowcontrol.py`
- `easyasc/utils/Tensor.py`
- `easyasc/utils/var.py`

如果要修改公开 API，应先判断行为属于 A2/A3 C220 接口、A5 系列（`a5` + `a5pr`）还是
两者都需要。一个进程不要导入多个 facade：facade import 会修改共享设备状态。

## 5. parser 与 lowering

parser 栈位于 `easyasc/parser/` 下。

关键职责如下：

- `asc.py`
  - 指令拆分
  - side 分类
  - autosync 插入
  - 翻译分发
- `asc_pruning.py`
  - 清理与裁剪 pass
- `asc_autosync.py`
  - 为支持的同侧 pipe 对插入事件
- `asc_handlers/`
  - 按操作分类的 lowering handler

如果你增加了一个新指令家族，通常会碰到以下五处（vec 原语五处都要改；漏掉后两处，指令会被
路由到 `PipeS`（“unhandled instruction”）或其消费方读到未初始化的 UB）：

1. stub 接口（`easyasc/stub_functions/...`）以及一路到 `a2` / `a3` / `a5` / `a5pr`
   facade 的 re-export
2. handler 注册或分发（`asc_handlers/<area>.py` + `asc_handlers/__init__.py` 的分发字典）
3. simulator 执行（对应 `pipe_*.py` 里的 `_<op>` 方法及其分发）
4. **simulator pipe 路由表** `easyasc/simulator/bridge.py`
   （`_VEC_PIPE_BY_OP` / `_CUBE_PIPE_BY_OP`）—— 必改，非可选
5. **autosync 分类** `easyasc/parser/asc_autosync.py` —— 任何读 / 写 UB 的指令都必须加

具体清单见 `agent/references/code-paths.md`（“Adding a vec primitive”），以 `gather` /
`gather_block` 为例。

## 6. stub 接口

写 kernel 时用到的大多数 API，最终都会通过这些目录下的 stub 发射成指令：

- `easyasc/stub_functions/`
- `easyasc/stub_functions/vec/`
- `easyasc/stub_functions/micro/`

它们定义了 kernel 实际可调用的 DSL 用法边界。
当某条 DSL 语句的行为和你的预期不一致时，最应该先看这里。

## 7. 模拟器内部

当前真正生效的模拟器位于 `easyasc/simulator/`。

最值得先看的文件包括：

- bridge 选择与模拟器入口
  - `easyasc/kernelbase/kernelbase.py`
- 运行时入口与配置
  - `easyasc/simulator/__init__.py`（导出 `SimulatorConfig`、`Simulator`、`build_kernel_program`、`build_simulator`）
  - `easyasc/simulator/config.py`
  - `easyasc/simulator/simulator.py`
- 程序 bridge
  - `easyasc/simulator/bridge.py`
  - `easyasc/simulator/program.py`
- 每 core 运行时与 pipe executor
  - `easyasc/simulator/core.py`
  - `easyasc/simulator/pipe.py`
  - `easyasc/simulator/pipe_cube.py`
  - `easyasc/simulator/pipe_vec.py`
  - `easyasc/simulator/pipe_micro.py`
  - `easyasc/simulator/pipe_simt.py`
- 内存与 workspace
  - `easyasc/simulator/memory.py`
  - `easyasc/simulator/physical_alias.py`
- 同步、timing 与 trace
  - `easyasc/simulator/sync.py`
  - `easyasc/simulator/timing/`
  - `easyasc/simulator/trace.py`

当前一个很重要的事实是：

- `KernelBase.run_sim()` 直接构建并运行模拟器
- `simulator` 现在是一个严格的 `bool`：`True` 走模拟器，`False` 走生成路径；旧的字符串写法不再被接受

## 8. Bridge 模型

模拟器现在不会再“直接执行原始指令列表”，而是先构建一个 `KernelProgram`。

`KernelBase.build_simulator_program()` 的选择顺序是：

1. 显式自定义 program builder
2. 预构建好的 `KernelProgram`
3. 通过 `easyasc/simulator/bridge.py` 中的 `build_kernel_program` 自动构建

这个 bridge 遍历已发射的指令流，把 pipe 操作 lowering 成按 lane 和
pipe 分组的 `ControlInstruction`，同时注册 tensor spec，供 runtime 预先
分配 shared memory。

因此，当模拟器行为和作者预期不一致时，bridge 层通常是最值得先检查的地方。

## 9. 运行时形状

模拟器运行时的结构是：

- 一个父调度器
- 每个模拟 core 一个子运行时
- 每个活跃 lane 一个控制 actor
- lane 内每条逻辑 pipe 一个线程化的 pipe worker

顶层协调器是 `easyasc/simulator/simulator.py` 中的 `Simulator`；每个模拟 core
由 `easyasc/simulator/core.py` 中的一个 `Core` 子进程执行。每个活跃 lane
有一个 `easyasc/simulator/pipe.py` 中的 `PipeS` 控制 pipe，同一 lane 内
的逻辑 pipe 由 `PipeBase` 子类的 worker 线程执行。shared tensor 存储由
`easyasc/simulator/memory.py` 中的 `SharedMemoryStore` / `SharedTensorSpec`
管理；cross-core 和 intra-core 同步原语位于 `easyasc/simulator/sync.py`。

## 10. Micro 模块

`@vf` 函数会被 `easyasc/micro/micromodule.py` 包装。

值得注意的点有：

- micro 函数会被缓存成可复用模块
- 临时寄存器声明会被提升到 micro 作用域
- 读写 sync key 会从发射出来的 micro 指令中收集
- kernel 对 micro 的调用会发射 `call_micro` 指令
- 运行时 micro 执行走 `easyasc/simulator/pipe_micro.py`
- 任何通过 `call_micro` 流进 micro 的 float `Var` 表达式，都必须在模拟器里保持 float 语义；如果运行时把它们截成 int，
  就会静默破坏 `@vf()` 里使用的标量 scale

任何影响 micro 数据流的改动，都应该同时对照 parser lowering 和模拟器运行时去检查。

## 11. 测试与 demo

- `agent/example/testcases/` 用于自动化回归
  - `codegen/`：静态生成、工具与非运行时检查
  - `parser/`：split、pruning、autosync 与 lowering 邻近检查
  - `simulator/`：运行时语义、roundtrip、bridge 行为与模拟器不变量
  - autosync、barrier、atomic、coordination helper 等同步路径
  - bridge、trace 导出、shared-memory/runtime 管线
- `agent/example/kernels/` 可以自带完整 kernel 故事的可运行断言
  - 除非要抽出更小、更可复用的回归，否则不要在 `agent/example/testcases/` 里重复整段端到端故事
- `agent/example/projects/` 用于把多个 kernel 接成完整算法的多文件系统工程（例如 `agent/example/projects/a5/gdn_fwd/` 与 `agent/example/projects/a5/gdn_bwd/`）

如果某个根目录脚本变得重要，要么转成 `agent/example/testcases/` 下的 pytest，要么移到 `agent/example/kernels/`（单文件样例）或 `agent/example/projects/<device>/<name>/`（多文件系统工程）。

## 12. 同步模型

当前仓库的同步大体分成两层：

1. autosync
   - lowering 阶段插入的同侧握手
2. 显式跨侧 mutex 与 wait / ready 路径
   - ownership 穿过 cube / vec 边界时使用

这部分改动风险很高，因为会同时影响：

- parser lowering
- bridge 行为
- simulator 调度
- trace 输出
- 大量现有测试

所以同步相关改动一定要尽量小，并用聚焦测试验证。

## 13. 生成资源

生成路径仍然依赖 `easyasc/resources/` 下的模板和辅助文件。

如果你改变了生成代码的整体形状，也要检查 host / runtime 模板或辅助头文件是否需要一起调整。

## 14. 高层地图

优先使用最小但足够的 owner 文档：

- playbook / 参考跨层的 router-first 导航 -> `agent/ROUTER.md`
- 顶层布局或归属 -> `agent/references/repo-map.md`
- simulator / `OpExec` 行为事实 -> `agent/references/facts-simulator-opexec.md`
- 通用实现路径速查 -> `agent/references/code-paths.md`
- kernel 示例与说明 -> `agent/references/examples/kernel-catalog.md`
- 测试结构 -> `agent/example/testcases/README.md`

修改 routed 文档或 catalog 后，运行：

```bash
python agent/scripts/check_kernel_catalog.py --fail-on-warning
python agent/scripts/build_agent_index.py --check
python agent/scripts/check_agent_docs.py
python agent/scripts/check_public_docs.py --fail-on-warning
```

## 15. 贡献检查表

当你修改框架内部时，建议按这个顺序自查：

1. 明确公开 API 会受到什么影响
2. 同步更新 lowering、bridge 逻辑和 simulator runtime
3. 增加或更新一个聚焦测试
4. 刷新真正描述该区域的 owner 文档
5. 如果在 `agent/example/kernels/` 下新增了 kernel，也要更新 kernel 摘要

只有让 parser、simulator、测试、文档和示例一起演进，这个仓库才会比较容易维护。
