# 常见问题排查

本页聚焦于你在这个仓库里编写或运行 kernel 时，最可能遇到的失败模式。

## 1. `Invalid argument order` 类报错

这是两个相关的报错：一个出在运行时调用处，一个出在 kernel 签名上。

### 运行时调用：`Invalid argument order: torch.Tensor must come before int/float`

原因：

- `OpExec.__call__` 要求运行时调用先传 `torch.Tensor`，再传标量
- 它本质上是下面 kernel 签名约束在调用侧的镜像

修复办法：

- 先传运行时张量
- 把 `M`、`N`、`K` 以及其他标量参数移动到参数列表末尾

### kernel 签名：`Invalid kernel argument order for OpExec: expected input tensor-like* -> output tensor-like* -> Var*`

原因：

- `_validate_bound_kernel_signature` 对 `@kernel` 自己的参数列表有更强的约束：先所有输入 tensor-like 参数（`GMTensor`/`GMTensorList`），再所有输出 tensor-like 参数（也就是函数 return 出来的那些），最后才是所有 `Var`
- 常见错法：把输出 tensor-like 参数放在 `Var` 后面，或把输入 tensor-like 参数放在输出 tensor-like 参数后面

修复办法：

- 先把所有输入 `GMTensor` 参数放在一起
- 再放输出 `GMTensor` 参数
- 最后再放所有 `Var` 参数
- 每个 `@kernel` 至少要带一个 `Var` 参数；一个都没有的话，`OpExec` 会报 `every @kernel must have at least one Var argument`

## 2. `Ambiguous scalar match for tensor #... dim #...`

原因：

- 有两个或更多标量参数在运行时拥有相同的值
- `OpExec` 无法判断某个张量维度到底应该绑定到哪个标量

修复办法：

- 增加显式的 `shape_bindings`

例如：

```python
shape_bindings={
    0: [0, 2],
    1: [1, 2],
    2: [0, 1],
}
```

## 3. `shape_bindings[...] mismatches tensor dim value`

原因：

- 你给出的 `shape_bindings` 条目指向了一个标量，但这个标量的值与真实张量维度并不相等

修复办法：

- 逐个核对你选中的标量索引与真实张量维度是否一致

## 4. 请求的 trace 文件没有生成

原因：

- 你在 `simulator=False` 时传了 `trace=...`
- 当前运行时只会在模拟器执行中保留 trace 路径；在生成、CANNSIM 和硬件
  模式下，该值会被静默忽略

修复办法：

- 使用 `simulator=True, trace="<path>"` 运行
- 传入非空字符串；空路径会抛 `ValueError`

## 5. `VecOP only supports UB position`

原因：

- 你把 vec 操作用到了不在 `UB` 上的张量

修复办法：

- 先把数据搬到 UB 张量里，再进入 vec 阶段

## 6. `MicroModule only accepts Tensor inputs in UB`

原因：

- 你调用 `@vf` 函数时，传入的张量来自 `L1`、`L0C` 或全局内存，而不是 UB

修复办法：

- 只用 UB 张量和标量输入去调用 micro helper

## 7. `GMTensor has not bound a mutex yet`

原因：

- 你在某个 `GMTensor` 上调用了 `lock()`、`ready()`、`wait()` 或 `free()`，但它事先并没有绑定 mutex

修复办法：

- 先调用 `bind_cv_mutex(...)` 或 `bind_vc_mutex(...)`
- 或者直接显式使用 `CvMutex` / `VcMutex` 对象

## 8. kernel 能跑，但数学结果不对

检查清单：

1. 确认 PyTorch 公式本身是否精确
2. 确认 cast 顺序
3. 确认操作数布局与转置位置
4. 缩小 shape，在模拟器模式下重跑
5. 检查 tail 写回逻辑
6. 如果涉及同步，就补一个 simulator trace

在这个仓库里，数学不对最常见的原因往往是：

- cast 放错了位置
- `x @ y.t()` 对应的 `y` 布局错了
- tail slice 的 subblock 边界算错了
- 把跨侧交接错误地只交给了 `auto_sync()`

## 9. kernel 死锁或看起来卡住了

最可能的原因有：

- producer / consumer 顺序没闭合
- mutex 生命周期不平衡
- event 或 wait 挂在了错误的一侧

建议做法：

1. 缩小 shape
2. 先只保留一个 tile
3. 打开 simulator trace
4. 拿你的流水去和一个拓扑相同但更小的现有 kernel 对照

## 10. 生成模式失败，但模拟器模式正常

这通常说明问题出在以下某一层：

- parser lowering
- 生成产物所依赖的假设
- 本地构建或运行脚本
- 环境相关工具链配置

排查时不要跳过模拟器阶段。应先在模拟器里证明 kernel 逻辑没问题，再去看生成路径的特有行为。

如果在 `r.sh` 启动前或执行期间失败，先判断是哪一层保护阻止了运行：

- `NPU busy: another easyasc on-board run ...` 表示共享锁在 1800 秒内
  没有被释放；检查是否有卡住的运行，并确认所有进程都使用预期的同一条
  `EASYASC_NPU_LOCK` 路径
- 没有卡、存在多块卡，或 `npu-smi` 输出模糊，表示 fail-closed 空闲检查
  无法选择设备或证明它空闲；如果问题是 card 选择，设置
  `EASYASC_NPU_CARD_ID`
- run-timeout 错误表示 `r.sh` process group 超过了
  `EASYASC_NPU_RUN_TIMEOUT`（默认 600 秒）；增大超时前先检查 `r.sh.log`
- `EASYASC_NPU_SAFETY_OVERRIDE=1` 会跳过 card 检测和空闲检查，但不会关闭
  串行化或超时。只在有意接受丢失这部分安全证据时使用

完整环境变量表见 [代码生成与运行时](06_codegen_and_runtime.md)。

## 11. 有用的对照文件

卡住的时候，可以优先对照：

- `agent/example/kernels/a5/matmul/matmul_float_mmad.py`，最短 baseline
- `agent/example/kernels/a5/matmul/matmul_abs_add1_vf.py`，cube -> vec
- `agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul.py`，vec -> cube
- `agent/example/testcases/simulator/trace/test_trace.py`，模拟器 trace
- `agent/example/testcases/simulator/opexec/test_torchplugin_shape_bindings.py`，shape-binding 失败场景
