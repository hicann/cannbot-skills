# 代码生成与运行时

本文解释的是：kernel 发射出指令 IR 之后，接下来会发生什么。

## 1. 执行路径分流

当前框架通过 `OpExec` 支持两条主要执行路径：

- 模拟器路径
- 生成路径

两条路径的起点是一样的：

1. 绑定 `torch.Tensor` 和标量输入
2. 把它们转换成 `GMTensor` 和 `Var`
3. 执行 Python kernel 主体，发射指令

之后，两条路径才开始分叉。

## 2. 模拟器路径

当 `simulator=True` 时：

- `GMTensor.data` 会根据输入张量填充
- kernel 会通过 `KernelBase.run_sim()` 执行，该方法直接构建并运行模拟器
- kernel 会先构建一个 `KernelProgram`，再交给 `easyasc/simulator/` 执行
- 输出会从 `GMTensor.data` 回读出来
- 在这条路径上，`OpExec` 不会调用 `generate()`；即使你传了 `out_dir` 或 `gen_only=True`，也不会产生代码生成产物

在编写新 kernel 时，这条路径应当作为默认首选。

## 3. 生成路径

当 `simulator=False` 时，`OpExec` 会走生成流程：

- 输入二进制会被写到 `<base>_aclnn_test/input`
- parser lowering 会生成代码产物
- 可选地调用构建与运行脚本
- 除非设置了 `gen_only=True`，否则输出二进制会再被读回 PyTorch 张量
- 如果你只是想验证或查看生成出来的代码，可以使用 `simulator=False, gen_only=True`

这里的 base 目录是：

- 如果传了 `out_dir`，就用 `out_dir`
- 否则使用 kernel 名称

实际的运行时文件会基于这个 base 落到下面两种后缀之一里：

- 非 debug 生成（默认）：`<base>_aclnn_test/`，输入二进制位于 `<base>_aclnn_test/input/`
- debug 生成（`OpExec(..., debug=True)`）：`<base>/debug_workspace/`
- `cannsim=True` 在两条生成路径里都可用：完整工程路径会用 `cannsim record` 包住 smoke 二进制；debug 路径会把生成出的 build/run 脚本从 `-r npu` 切到 `-r sim`

## 4. `KernelBase` 负责什么

`KernelBase` 就是 `@kernel` 创建出来的包装器。

它的职责包括：

- 保存发射出来的指令
- 跟踪被使用过的 micro module
- 收集输出 `GMTensor`
- 为已注册的 mutex 插入跨侧 ready / wait 支架逻辑
- 输出生成后的 cube / vec 代码

此外，在用户代码开始之前，它还会自动插入一些框架自身需要的指令。

对于模拟器路径，`KernelBase` 还负责：

- 通过 `build_simulator_program()` 自动选择合适的 bridge
- 通过 `_simulator_program_builder` 与 `_simulator_config_builder` 接收可选的自定义 hook

## 5. parser 如何做 lowering

parser 流程从高层看主要做三件事：

1. 把指令流拆成 cube 侧和 vec 侧两条流
2. 为支持的同侧 pipe 对插入 autosync 事件
3. 用按操作分类的 handler，把各侧翻译成生成代码

关键模块包括：

- `easyasc/parser/asc.py`
- `easyasc/parser/asc_autosync.py`
- `easyasc/parser/asc_pruning.py`
- `easyasc/parser/asc_handlers/`

## 6. 生成产物

`KernelBase.dump_kernel()` 会写出：

- `<path>_cube.h`
- `<path>_vec.h`
- `<path>.cpp`

生成出的 C++ 包装层会：

- 包含张量和辅助头文件
- 在需要时包含生成出的 micro 头文件
- 调度 cube 和 vec 入口函数
- 从生成运行时数据中读取标量 tiling 值

## 7. 构建与运行脚本钩子

当生成模式不是 `gen_only` 时，`OpExec` 可以执行：

- `b.sh` 用于构建
- `r.sh` 用于运行

在默认的非 debug 生成路径里：

- `b.sh` 负责 build 和 install 生成出的 custom op 包
- `r.sh` 会先执行 `python setup_aclnn.py`，再启动 aclnn 测试二进制
- 如果使用 `OpExec(..., cannsim=True)`，`r.sh` 会运行
  `cannsim record ./test_aclnnop -s <chipset>`，而不是直接运行
  `./test_aclnnop`

在 debug 生成路径里：

- `b.sh` 与 `r.sh` 会去调用生成出来的 `debug_workspace/build.sh` 与
  `debug_workspace/run.sh`
- 当使用 `OpExec(..., debug=True, cannsim=True)` 时，这些脚本会把
  `-r npu -v <chipset>` 切换成 `-r sim -v <chipset>`

它们的日志会被写到例如：

- `b.sh.log`
- `r.sh.log`

这也是为什么生成模式默认假设你在仓库根目录工作，并且本地工具链已经准备好。

### Run-step 串行化、空闲检查和 watchdog

当前每次非模拟器、且非 `gen_only` 的 `r.sh` 启动都会经过同一个
受保护 runner，包括为 CANNSIM 配置的 `r.sh`：

1. 获取跨进程 advisory lock，避免共用同一块板卡的 EasyASC 运行重叠
2. 启动前要求连续多次 `npu-smi` 空闲样本
3. 在独立 process group 中启动 `r.sh`，并设置有界超时
4. 超时时终止整个 process group，并报告 `r.sh.log` 路径

空闲检查采用 fail-closed 策略：需要 AICore 利用率为 0%，且没有进程占用
选定卡；`npu-smi` 数据缺失或模糊时会报错。只安装一块卡时会自动检测
card id；安装零块或多块卡时，必须显式设置 `EASYASC_NPU_CARD_ID`。

| 环境变量 | 默认值 | 作用 |
| --- | --- | --- |
| `EASYASC_NPU_CARD_ID` | 只有一块卡时自动检测 | 空闲检查使用的非负 card id。 |
| `EASYASC_NPU_IDLE_SAMPLES` | `3` | 要求的连续空闲样本数；至少为 1。 |
| `EASYASC_NPU_IDLE_INTERVAL` | `1.0` | 样本间隔秒数；必须有限且非负。 |
| `EASYASC_NPU_RUN_TIMEOUT` | `600` | `r.sh` 最长运行秒数；必须有限且为正。 |
| `EASYASC_NPU_LOCK` | 系统 `/tmp` 中的 `easyasc_npu0.lock` | 使用同一块板卡的进程共享的 advisory lockfile。 |
| `EASYASC_NPU_LOCK_ALLOW_DEGRADE` | `0` | 设为 `1` 后，打不开 lockfile 时仍继续。这会弱化串行化，只应作为有意识的恢复选择。 |
| `EASYASC_NPU_SAFETY_OVERRIDE` | `0` | 设为 `1` 后跳过 card 检测和板卡空闲检查；不会关闭锁或运行超时。 |

锁最多等待 1800 秒，供另一次 EasyASC 运行释放。在 Unix 上，无法打开
lockfile 会报错，除非设置 `EASYASC_NPU_LOCK_ALLOW_DEGRADE=1`；在没有 `fcntl`
的平台上无法加锁，runner 会退化为不做串行化。

把两个 override 变量当作逃生通道，而不是日常配置。优先选择正确的 card
和 lock 路径，使并发运行或板卡忙碌仍然可被检测。

## 8. `shape_bindings`

`shape_bindings` 属于 `OpExec.__call__` 的参数，而不是 kernel 本身的一部分。

当出现这些情况时，需要它：

- 两个或更多标量参数在运行时恰好有相同的整数值
- 运行时无法确定某个张量维度到底对应哪个标量

如果某个 binding 是显式给出的，运行时还会检查：你选中的那个标量值，是否真的等于实际的张量维度；不相等就报错。

## 9. 常用的 `OpExec` 选项

- `out_dir`：输出目录前缀
- `profile`：在生成模式下请求更偏 profiling 的行为
- `gen_only`：只生成产物，不执行生成路径
- `simulator`：走模拟器，而不是生成路径
- `cannsim`：在生成模式下改用 CANNSIM，而不是直接跑 NPU；完整工程路径和 debug 路径都支持
- `skip_compile`：在生成模式下跳过 `b.sh`
- `trace`：把模拟器 trace 输出到文件；当 `simulator=False` 时，当前运行时会忽略该值，不创建 trace
- `debug`：让生成走 `KernelBase.generate_debug(...)`，运行时文件写到 `<base>/debug_workspace/`，而不是 `<base>_aclnn_test/`

## 10. 推荐使用顺序

对于新 kernel 的开发，推荐这样推进：

1. `simulator=True`
2. 如果需要看同步，再加上 `simulator=True, trace=...`
3. `simulator=False, gen_only=True`
4. 最后再走完整的生成与运行流程

这个顺序和实现结构是对齐的，也能把你同一时间要排查的变量数降到最低。
