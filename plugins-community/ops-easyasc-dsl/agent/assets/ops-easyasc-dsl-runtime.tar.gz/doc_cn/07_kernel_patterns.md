# Kernel 模式库

`agent/example/kernels/` 目录不只是示例文件夹，它其实是这个仓库里关于“合法 DSL 用法”和“稳定实现形态”的模式库。

## 1. 如何使用 kernel 目录

阅读已有 kernel，主要是为了回答这些问题：

- 最短的合法 matmul baseline 是什么样
- 一个 cube -> vec 的交接应该长什么样
- tail 写回应该怎么处理
- fp8 cast 目前是怎么建模的
- 在这个 DSL 里，多阶段流水代码通常长什么样

不要机械地把某个 kernel 的主体直接复制到新 kernel 里。正确做法是从目标公式出发，只借鉴那些确实被该公式需要的模式。

## 2. 最短正确性基线

建议先看这些文件：

- `agent/example/kernels/a5/matmul/matmul_float_mmad.py`
  - 最短的纯 cube matmul 路径
- `agent/example/kernels/a5/matmul/matmul_e5m2_shortcut.py`
  - float8 输入、float 输出的 matmul
- `agent/example/kernels/a5/matmul/matmul_kmkn_fp32_out.py`
  - 原生 `KM @ KN -> MN` 布局

## 3. cube -> vec 后处理模式

当 matmul 结果在最终写回前还需要做 vector 处理时，这组模式就很有用。

- `agent/example/kernels/a5/matmul/matmul_abs_add1_vf.py`
  - `abs(matmul) + 1`
- `agent/example/kernels/a5/matmul/matmul_rowwise_norm.py`
  - 按行规约再广播除法
- `agent/example/kernels/a5/matmul/matmul_rowwise_norm_large_nk.py`
  - 面向更大 shape 的两遍归一化

当输出变换天然更适合放在 vec 侧，而且不需要立刻重新融回 cube 时，就应该优先看这组文件。

## 4. vec -> cube 预处理模式

当公式要求某个操作数在 matmul 之前先做变换时，这组模式就很适合：

- `agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul.py`
- `agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul_nz.py`
- `agent/example/kernels/a5/gdn_legacy/recompute_wu.py`

这类模式的共同思路是：

- 先在 UB 里计算
- 如果需要，就先 cast 或重新打包
- 用 `ub_to_l1_nd2nz` 或 `ub_to_l1_nz` 发布到 L1
- 再由 cube 侧 matmul 消费

## 5. 多阶段 mixed pipeline 模式

下面这些文件展示了如何把不止一次的交接组合起来：

- `agent/example/kernels/a5/pipeline_patterns/vec_cube_vec_scale2_abs_add1_matmul.py`
  - vec 预处理 -> cube -> vec 后处理
- `agent/example/kernels/a5/pipeline_patterns/cube_vec_atomic_add_two_outputs.py`
  - 带双输出与原子写回的 mixed pipeline

当一个新公式无法被写成单一纯阶段时，就应该优先研究这些文件。

## 6. 流式与 lookahead 模式

目前文档里给出的最复杂示例是：

- `agent/example/kernels/a5/attention/test_mla_entire.py`
- `agent/example/kernels/a5/attention/mha_ifa_fp8_scale_256.py`

它展示了：

- one-tile lookahead 调度
- delayed consumer 的生命周期
- 流式 `row_max` 与 `row_sum`
- 在不把中间状态回写到 GM 的前提下，让 vec 和 cube 协作
- 带外部 `scale_q`、`scale_k`、`scale_v` 的 fp8 decode attention，以及 tail-safe 处理

建议先掌握较小的 mixed kernel，再来读这个文件。

## 7. 纯 vec 与 micro 模式

适合参考的文件有：

- `agent/example/kernels/a5/utility/chunk_row_cumsum.py`
- `agent/example/kernels/a5/utility/micro_cast_fp8_pack4_dual.py`

这些 kernel 可以回答的问题包括：

- 纯 vec kernel 应该怎么写
- 怎样通过 `single()` 做标量抽取
- 在 micro 代码里，fp8 的 `pack4` 写回到底是什么语义

## 8. 模式选择指南

如果你的目标 kernel 是：

- 最短纯 matmul：从 `matmul_float_mmad.py` 起步
- cube matmul 加 vec epilogue：从 `matmul_abs_add1_vf.py` 起步
- 先做 vec 预处理再 matmul：从 `vec_cube_abs_sqrt_matmul.py` 起步
- 两段 mixed stage：从 `vec_cube_vec_scale2_abs_add1_matmul.py` 起步
- 更高级的流式 attention 类路径：去研究 `test_mla_entire.py`
- 带 tail 处理的 fp8 decode attention：去研究 `mha_ifa_fp8_scale_256.py`

## 9. a2 专属模式

上面这些主要是 a5 风格的混合流水线。a2 (b3) 设备家族在 cube 与 vec 之间强制要求一次 GM workspace 中转，因此它有一整套独立的模式，同步、缓冲与尾部处理规则都不同。目标设备是 a2 时读下面这组。

- `agent/example/kernels/a2/matmul/qk_matmul_batched.py`
  - 最简 a2 纯 cube baseline，按 `BH` 展开成 batched
- `agent/example/kernels/a2/vec_only/to_hif8_torch.py`
  - 纯 vec 的 hif8 模拟参考
- `agent/example/kernels/a2/vec_only/sort_rows.py`
  - 纯 vec 行排序，由 `sort32` + `mergesort4` + `mergesort_2seq` + `gather` 去交错搭建而成
- `agent/example/kernels/a2/attention/flash_attn_score_pv.py`
  - a2 `cube -> vec -> cube` 带显式 GM bridge，加跨 tile 的 running state
- `agent/example/kernels/a2/attention/flash_attn_full.py`
  - a2 `cube -> vec -> cube -> vec` 归一化 online softmax 的参考；当前版本使用 `GROUP_N=4` 分组 score/P/PV 发布
- `agent/example/kernels/a2/attention/flash_attn_full_pj_hif8.py`、`flash_attn_full_pj_hif8_commonub.py`
  - scaled-hif8 概率路径的两种变体；`_commonub` 版本把 vec 侧 scratch 迁到共享 `DBuff` 家族，让 `MTE2 -> V` 的 `ubin` 排队更紧凑
- `agent/example/kernels/a2/attention/flash_attn_full_pj_hif8_causal.py`、以及 `agent/example/kernels/a2/attention/block32_causal/` 下的 block32-causal 家族（base、`_v2` … `_v6`）
  - 因果变体，包括分块 `32x32` 的对角 tile 因果 masking；`block32_causal/` 家族从 naive relay 演进到 v6 的连续跨 M-tile 流水。完整 v1→v6 设计见 `agent/example/kernels/a2/attention/block32_causal/README_CN.md`

具体的 a2 流水线拓扑与设备侧约束，请直接看对应 owner reference：
`agent/references/patterns/a2-mixed-pipeline.md` 负责流水线排程，
`agent/references/constraints/a2.md` 负责 bridge 和 UB layout 边界，
`agent/references/constraints/vec.md` 负责 vec reduction / mask 语义，
`agent/references/constraints/tail.md` 负责通用 tail 合法性，
`agent/references/patterns/online-softmax-tail.md` 负责 online-softmax 的
mask / update 组合顺序。

## 10. 配套说明

仓库里还有两个专门用来补充 kernel 模式库的文件：

- `agent/references/examples/kernel-catalog.md`
- `doc/kernel_practice.md`（英文练习目录）

当你要基于现有模式推导新 kernel 时，建议把它们和源码一起对照着看。
