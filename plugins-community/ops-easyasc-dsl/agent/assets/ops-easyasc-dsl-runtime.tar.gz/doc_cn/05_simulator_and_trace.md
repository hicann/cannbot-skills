# 模拟器与 Trace

模拟器仍然是这个仓库里最稳妥的第一执行目标。
当前真正生效的运行时位于 `easyasc/simulator/`。

## 1. 现在的模拟器覆盖了什么

当前模拟器栈覆盖了：

- 从 kernel 发射指令构建可执行程序
- 保留控制流的 lane program
- 跨模拟 core 的父/子运行时调度
- 运行时中的 cube、vec、micro 执行
- core 内同步与 collective 同步
- shared tensor / workspace 存储
- 可选的 Chrome / Perfetto 风格 trace 导出

因此它仍然适合：

- 第一轮正确性验证
- 同步问题调试
- 在测试里复现 parser / runtime 行为

## 2. 如何在模拟器模式运行

使用：

```python
out = OpExec(kernel_fn, simulator=True)(...)
```

当前真实行为：

- `simulator` 只接受 `True` 或 `False`；传字符串会直接抛 `TypeError`
- `simulator=True` 通过 `KernelBase.run_sim()` 进入模拟器运行时
- `simulator=False` 走生成路径

在模拟器模式下：

- 输入的 PyTorch 张量会先拷贝到 `GMTensor.data`
- kernel 会先构建一个 `KernelProgram`
- 运行时再把这些 payload 拷贝进 shared tensor store
- 执行结束后，结果会从运行时张量拷回 `GMTensor.data`，再映射回 PyTorch

## 3. kernel 如何变成模拟器程序

程序构建逻辑位于 `easyasc/kernelbase/kernelbase.py`。

当前选择顺序是：

1. `kernel._simulator_program_builder`
2. `kernel._simulator_program`
3. 通过 `easyasc/simulator/bridge.py::build_kernel_program` 自动构建

bridge 会遍历已发射的指令流，把 pipe 操作 lowering 成按 lane 和 pipe
分组的 `ControlInstruction`，并注册 tensor spec，供 runtime 预先分配
shared memory。

## 4. 运行时层次结构

模拟器包现在是一组扁平模块：

- 顶层协调器：`easyasc/simulator/simulator.py`（`Simulator`）
- 每个 core 的子进程 worker：`easyasc/simulator/core.py`（`Core`）
- pipe worker 线程：`easyasc/simulator/pipe.py`（`PipeBase`、`PipeS`）
- cube / vec / micro pipe 执行器：`pipe_cube.py`、`pipe_vec.py`、`pipe_micro.py`
- shared memory：`easyasc/simulator/memory.py`
- 同步原语：`easyasc/simulator/sync.py`
- trace：`easyasc/simulator/trace.py`
- program / task 模型：`easyasc/simulator/program.py`
- instruction bridge：`easyasc/simulator/bridge.py`
- config：`easyasc/simulator/config.py`

实用心智模型可以记成：

- 一个父运行时先准备 shared tensor 和 execution plan
- 每个模拟 core 启一个子进程
- 每个活跃 lane 由 `PipeS` 驱动调度
- lane 内每条逻辑 pipe 由独立的 `PipeBase` worker 驱动

## 5. core 数、lane 激活和内存

这里最关键的文件有：

- `easyasc/simulator/config.py`
- `easyasc/simulator/simulator.py`

当前行为包括：

- 当 `SimulatorConfig.core_count == 0` 时，运行时会通过 `_default_core_count()` 按下面两步推导默认值：
  1. 如果 `globvars.core_num` 已经设置且为正，就用它
  2. 否则，通过 `easyasc/device_profile.py` 查默认核数
- 导入 `easyasc.a5` 会把 `globvars.core_num` 钉到 `32`，因此 950 默认是 32 核
- 导入 `easyasc.a5pr` 会把 `globvars.core_num` 钉到 `28`，因此 950PR 默认是 28 核
- 导入 `easyasc.a2` 会把 `globvars.core_num` 钉到 `20`，对应 B3 profile
- 导入 `easyasc.a3` 会把 `globvars.core_num` 钉到 `20`，对应 `Ascend910_9362`
- 想覆盖默认值，可以显式设置 `SimulatorConfig.core_count`，或者在配置生成之前给 `globvars.core_num` 赋值
- 当程序只用到部分 cube / vec lane 时，模拟器会跳过不活跃 lane
- 运行时张量和 workspace 会通过 shared tensor store 预先准备
- mixed-lane kernel 依赖 bridge 生成的 metadata，尤其是 lane-local UB 的处理信息

标量语义提醒：

- 带控制流的 kernel 会把 `var_add`、`var_mul`、`var_div` 这类 `Var` 标量表达式保留到运行时
- 如果 DSL 里的 `Var` 是 float，这些标量运算也必须保持 float 语义，不能在运行时偷偷截成 int
- 如果你看到 kernel 的原始 `L0C -> UB` 数据是对的，但后面的 `@vf()` scale 一下子全变成 `0`，应当先检查模拟器里的 float `Var` 算术，而不是先怀疑 cube/vec 交接

## 6. 为什么这里依然提倡先跑模拟器

`agent/example/kernels/` 目录里的大多数可运行 kernel，依然通过下面这种方式自验证：

```python
OpExec(..., simulator=True)
```

原因没有变：

- 迭代 kernel 逻辑更快
- 可以直接和文件内的 PyTorch 参考对比
- 更容易观察同步和 trace 行为
- 比起生成路径，变量更少、更容易定位问题

## 7. 生成 trace

trace 只支持模拟器模式。

示例：

```python
trace_path = os.path.join(out_dir, "trace.json")
out = OpExec(kernel_fn, out_dir, simulator=True, trace=trace_path)(...)
```

当前 trace 的流转方式是：

- 每个模拟 core 分别记录自己的事件
- 父运行时在执行完成后把各 core 的 trace 合并
- 合并后的结果导出成 Chrome / Perfetto 风格的 JSON

值得参考的测试包括：

- `agent/example/testcases/simulator/trace/test_trace.py`

如果你想先在命令行里快速看一眼 trace 摘要，可以使用：

```bash
python agent/scripts/analyze_sim_trace.py tmp/<task>/trace.json
```

这个工具会基于导出的 timed events 给出总 makespan，以及按 pipe 汇总的
平均利用率和按 core 拆分的利用率。`--group-by lane-pipe` 会把 `vec0` 和
`vec1` 分开显示，`--json` 会输出同一组指标的机器可读版本。它适合做第一轮
瓶颈定位；如果需要看精确的依赖顺序，再去打开 Chrome / Perfetto trace。

## 8. trace 能帮你看什么

当你需要回答下面这些问题时，trace 很有帮助：

- 哪个 lane / pipe 先执行
- producer / consumer 的交接顺序是否符合预期
- wait、event、barrier 是否把流水卡住了
- 实际流水拓扑是否和你的设计一致

它尤其适合这些场景：

- `auto_sync()`
- 跨侧 mutex
- mixed cube / vec kernel
- one-tile lookahead 或 delayed-consumer 流

## 9. 建议的调试循环

当一个 kernel 不工作时：

1. 先把 shape 缩小
2. 用模拟器模式运行
3. 和直接写出来的 PyTorch 参考比较
4. 如果涉及同步，就打开 trace
5. 先检查 bridge / runtime 路径，再决定是否改 kernel
6. 只有在模拟器对齐之后，再去看生成路径或更贴近硬件的执行流

## 10. 值得重点查看的文件

下面按角色组织，对应 [`11_architecture_for_contributors.md §7`](11_architecture_for_contributors.md) 里贡献者地图的分类。

- 运行时入口与配置
  - `easyasc/torchplugin.py`
  - `easyasc/kernelbase/kernelbase.py`
  - `easyasc/simulator/simulator.py`
  - `easyasc/simulator/config.py`
- 程序 bridge
  - `easyasc/simulator/bridge.py`
  - `easyasc/simulator/program.py`
- 单 core 运行时
  - `easyasc/simulator/core.py`
  - `easyasc/simulator/pipe.py`
  - `easyasc/simulator/pipe_cube.py`
  - `easyasc/simulator/pipe_vec.py`
  - `easyasc/simulator/pipe_micro.py`
- 内存与同步
  - `easyasc/simulator/memory.py`
  - `easyasc/simulator/sync.py`
- trace 导出
  - `easyasc/simulator/trace.py`
- 测试与示例
  - `agent/example/testcases/simulator/`
