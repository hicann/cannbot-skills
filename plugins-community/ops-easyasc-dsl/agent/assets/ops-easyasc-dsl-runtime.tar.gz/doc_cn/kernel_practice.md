# Kernel 编写练习

[English version](../doc/kernel_practice.md)

这些练习用于积累编写经验，同时避免把未完成尝试放进仓库示例。请在
`tmp/practice/<target>/` 下工作，使用 `OpExec(..., simulator=True)`；只有当
contract、代表性测试和文档都稳定后，才把解答迁入 `agent/example/kernels/`。

一个 Python 进程只能导入一个 target facade。A2、A3、A5、A5PR 之间切换时启动
新进程。

## 使用方式

1. 先写精确 PyTorch 公式和误差阈值。
2. 先确定 tiling 与 dataflow，再补齐各计算阶段。
3. 逐阶段验证，并至少覆盖一个尾块 shape。
4. 把 warning 当成尚未解释的证据，而不是正常输出。
5. 先完成可运行草稿，再打开表中的参考实现。

Golden tensor 进入 `OpExec` 前，除非练习明确规定 host packing contract，否则
只能执行不改变值与布局的 `squeeze`、`unsqueeze`、`reshape`。

## Tier 1：vec-only 基础

| 练习 | Contract | Target | 主要训练点 | 完成后参考 |
| --- | --- | --- | --- | --- |
| `elementwise_scale_bias` | `y = x * 2 + 1`，fp32 `[M,N]` | A5 系列 | GM→UB→`@vf`→GM、核间分块、尾块 | [A5 micro math](api/a5_micro_math.md) |
| `sigmoid` | `y = 1 / (1 + exp(-x))` | A5 系列 | 寄存器表达式顺序和精度 | [`mha_ifa.py`](../agent/example/kernels/a5/attention/mha_ifa.py) |
| `row_sum` | `y = x.sum(-1, keepdim=True)` | 先 A2，再 A5 系列 | 规约与标量广播 layout | [A2 vec math](api/a2_vec_math.md)、[A5 micro math](api/a5_micro_math.md) |
| `softmax_single_tile` | 单行 tile 驻留时的 `softmax(x, dim=-1)` | 先 A5 系列，再 A2 | 稳定 max→sub→exp→sum→divide | [`mha_ifa.py`](../agent/example/kernels/a5/attention/mha_ifa.py) |

## Tier 2：cube 基线

| 练习 | Contract | Target | 主要训练点 | 完成后参考 |
| --- | --- | --- | --- | --- |
| `matmul_basic` | `z = x @ y.t()`，M/N/K 对齐 | A5 系列 | 最短 cube pipeline 与 simulator oracle | [`matmul_float_mmad.py`](../agent/example/kernels/a5/matmul/matmul_float_mmad.py) |
| `matmul_kmkn` | `x.T @ y`，`x:[K,M]`、`y:[K,N]` | A5 系列 | 调用点转置与 shape bindings | [`matmul_kmkn_fp32_out.py`](../agent/example/kernels/a5/matmul/matmul_kmkn_fp32_out.py) |
| `matmul_splitk_large_k` | 大 K 的 `x @ y.t()` | A5 系列 | 外层 tiling 与内层 split-K 累加 | [`matmul_mknk_2dgrid_splitk.py`](../agent/example/kernels/a5/matmul/matmul_mknk_2dgrid_splitk.py) |

## Tier 3：cube-to-vec 后处理

| 练习 | Contract | Target | 主要训练点 | 完成后参考 |
| --- | --- | --- | --- | --- |
| `matmul_bias_relu` | `relu(x.float() @ y.float().t() + bias)` | A5 系列 | `CvMutex`、bias 广播、vec 写回 | [`matmul_half_splitn_bias10p2_vf.py`](../agent/example/kernels/a5/matmul/matmul_half_splitn_bias10p2_vf.py) |
| `matmul_rowwise_softmax` | `softmax(x.float() @ y.float().t(), -1)` | A5 系列 | matmul 后行规约与 tile lifetime | [`mha_ifa.py`](../agent/example/kernels/a5/attention/mha_ifa.py) |
| `matmul_l2_norm` | 用 `sqrt(sum(z**2))` 归一化 matmul 行 | A5 系列 | 跨 N tile 的两遍统计 | [`matmul_rowwise_l2_norm.py`](../agent/example/kernels/a5/matmul/matmul_rowwise_l2_norm.py) |
| `matmul_blockwise_quant` | block-128 absmax scale 与 fp8 输出 | A5 系列 | scale 输出、cast 与 carrier layout | [`matmul_kmkn_blockwise_quant128.py`](../agent/example/kernels/a5/matmul/matmul_kmkn_blockwise_quant128.py) |

## Tier 4：vec-to-cube 与融合流水线

| 练习 | Contract | Target | 主要训练点 | 完成后参考 |
| --- | --- | --- | --- | --- |
| `relu_then_matmul` | `relu(x).half().float() @ y.float().t()` | A5 系列 | `VcMutex`、dtype 边界、vec→cube publish | [`vec_cube_abs_sqrt_matmul.py`](../agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul.py) |
| `fused_vec_cube_vec` | `abs((x*2).half().float() @ y.float().t()) + 1` | A5 系列 | 双向 mutex 与各阶段独立验证 | [`vec_cube_vec_scale2_abs_add1_matmul.py`](../agent/example/kernels/a5/pipeline_patterns/vec_cube_vec_scale2_abs_add1_matmul.py) |
| `flash_attn_decode` | `softmax(q @ k.T / sqrt(D)) @ v`，`L=1,D=128` | A5 系列 | lookahead、行状态、warmup/drain | [`mha_ifa.py`](../agent/example/kernels/a5/attention/mha_ifa.py) |
| `flash_attn_decode_causal` | 上一公式加 `k_pos <= q_pos` | A2 | GM bridge、因果 score mask、三次交接 | [`flash_attn_full_pj_half_block32_causal.py`](../agent/example/kernels/a2/attention/block32_causal/flash_attn_full_pj_half_block32_causal.py) |

## 完成标准

- 模拟器结果在对齐与尾块 shape 上都匹配未改值的 reference，并有合理阈值。
- 每个 cast、buffer、datamove 与同步边都有 contract 原因。
- 不保留未解释的 parser 或 `auto_sync` warning。
- 脚本能按公开环境说明从仓库根目录运行。
- 提升为正式示例后，文件自身包含 reference 计算与断言。
