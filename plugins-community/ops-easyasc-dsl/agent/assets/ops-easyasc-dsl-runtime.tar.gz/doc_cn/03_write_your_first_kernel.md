# 编写你的第一个 Kernel

这份指南会建立起和 `agent/example/kernels/` 目录里最小示例相同的思考方式。

## 1. 从精确参考开始

一定要先写出黄金参考公式：

```python
z_ref = x @ y.t()
```

这个参考不是可有可无的。它会决定：

- 操作数布局
- 累加 dtype
- 输出 dtype
- 是否需要转置视图

第一次写 kernel 时，尽量把公式保持简单，优先使用 float 输入和 float 输出。

## 2. 声明 kernel 签名

Tensor 输入输出使用 `GMTensor` 参数；动态同 dtype tensor 组使用
`GMTensorList`。标量维度使用 `Var` 参数。

```python
@kernel()
def matmul_float_mmad_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    ...
```

一个重要规则是：

- kernel 签名就是生成后算子的契约
- 每一个对用户可见的 tensor 输入输出，都必须由 `GMTensor` 或
  `GMTensorList` 参数表示

## 3. 分配片上张量

对最小的 matmul 来说，你需要：

```python
l1x = Tensor(DT.float, [M, K], Position.L1)
l1y = Tensor(DT.float, [N, K], Position.L1)
l0c = Tensor(DT.float, [M, N], Position.L0C)
```

这些语句并不会创建 Python 数组，它们会在当前激活的 kernel 里发射 DSL 侧的张量声明。

## 4. 描述数据搬运

先把全局内存中的张量搬到 L1：

```python
l1x <<= x[:, :]
l1y <<= y[:, :]
```

然后调用 matmul shortcut：

```python
matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
```

最后把结果写回：

```python
z[:, :] <<= l0c
return z
```

这些数据搬运、`matmul` 内部的 L1 到 L0 搬运、MMAD，以及最后的 L0C 写回，
属于同一个 cube 侧流水区域。要用 `with auto_sync():` 包起来，让 parser
为 `MTE2 -> MTE1`、`MTE1 -> M`、`M -> FIX` 这些同侧 pipe 关系插入握手。
不加它就是个会误导人的玩具例子：Python 源码看起来有顺序，但真正发出去的
pipe 工作需要明确 ownership。

完整的 kernel 如下：

```python
from easyasc.a5 import *


@kernel()
def matmul_float_mmad_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)

    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c
    return z
```

每个 `@kernel` 入口都必须至少包含一个 `Var` 参数。这是编译器入口限制：
即使是固定形状 kernel，也需要一个标量 `Var` 入参，通常可以命名为
`contract`，并且在 `OpExec(...)(...)` 调用中传入一个标量值。

## 5. 通过 `OpExec` 执行

运行时输入直接使用 PyTorch 张量：

```python
import torch

M = 32
N = 48
K = 16

torch.manual_seed(0)
x = torch.randn((M, K), dtype=torch.float32)
y = torch.randn((N, K), dtype=torch.float32)
z = torch.zeros((M, N), dtype=torch.float32)

z_kernel = OpExec(matmul_float_mmad_kernel, simulator=True)(x, y, z, M, N, K)
z_ref = x @ y.t()
torch.testing.assert_close(z_kernel, z_ref, rtol=1e-4, atol=1e-4)
```

即使在模拟器模式下，当前 kernel 契约依然要求你显式传入占位输出张量 `z`。

## 6. `OpExec` 实际帮你做了什么

从高层看，这句调用：

```python
OpExec(matmul_float_mmad_kernel, simulator=True)(x, y, z, M, N, K)
```

会完成这些事：

1. 按 `输入 tensor-like* -> 输出 tensor-like* -> Var*` 的顺序校验 kernel 签名（并要求至少有一个 `Var` 参数）
2. 校验运行时调用是否按相同顺序传递了输入 tensor/list、输出 tensor/list 占位符、标量
3. 把输入张量绑定到 `GMTensor` / `GMTensorList` 对象
4. 把标量值绑定成 `Var`
5. 执行 kernel 主体来发射指令
6. 在模拟器中执行这些指令
7. 把输出 `GMTensor` / `GMTensorList` 再映射回 PyTorch 张量

## 7. 从第一个 kernel 往前推进

当这个 baseline 跑通后，下一步值得做的是：

1. 用 `DBuff` 增加 tiling
2. 在 UB 上加入 vec 侧后处理
3. 分清 `auto_sync()` 到哪里就不够用了
4. 当 ownership 穿过 cube / vec 边界时，再引入显式 mutex

下一批适合继续阅读的文件有：

- `agent/example/kernels/a5/matmul/matmul_abs_add1_vf.py`
- `agent/example/kernels/a5/matmul/matmul_half_splitn_bias10p2_vf.py`
- `agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul.py`

## 8. 第一次最常犯的错误

- 在非 UB 张量上使用 vec 操作
- 忘了 kernel 参数必须是 `GMTensor`、`GMTensorList` 或 `Var`
- 在确认 PyTorch 参考之前就开始乱改 kernel 主体
- 当重复标量值让维度推导变得含糊时，却没有补 `shape_bindings`

## 9. 一个实用的成长路径

如果你刚接触这个仓库，这样的顺序通常比较顺：

1. `agent/example/kernels/a5/matmul/matmul_float_mmad.py`
2. `agent/example/kernels/a5/matmul/matmul_abs_add1_vf.py`
3. `agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul.py`
4. `agent/example/kernels/a5/pipeline_patterns/vec_cube_vec_scale2_abs_add1_matmul.py`

每一步都只在前一步的基础上多引入一个主要概念。
