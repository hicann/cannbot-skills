# int4 Adaptation Notes

This document records the current a2-only int4 codegen and simulator contract.
The feature is a local compute-view marker backed by int32 carrier tensors, not
a host, GM, or CPU-side addressable int4 storage model.

## Design Summary

- `DT.int4` is a DSL marker dtype for a2/b-device codegen.
- `DT.int4` maps to AscendC `int4b_t` only for local compute views.
- `GMTensor(DT.int4, ...)` is not supported. GM inputs and outputs use `DT.int`
  packed carrier tensors.
- `Tensor`, `DBuff`, `TBuff`, and `QBuff` cannot be allocated with `DT.int4`. (`QBuff` itself is the four-slot buffer family — see [`doc/api/tensor_buffer.md §5.5`](../api/tensor_buffer.md).)
- `split_workspace(DT.int4, ...)` is not supported.
- Eight logical int4 values are packed into one `DT.int` carrier element.
- `.reinterpret(DT.int4)` does not pack or unpack data. It only marks a
  `DT.int` carrier view as a logical int4 matmul/MMAD operand.
- Plain `DT.int` cube matmul/MMAD is not supported.
- The simulator implements int4 MMAD by aliasing `DT.int4` views to their
  `DT.int` carriers and unpacking signed int4 columns before int32 matmul.

## Authoring Pattern

GM tensors are packed `DT.int` carrier tensors. For a logical `K`, allocate the
carrier K dimension as `CeilDiv(K, 8)`.

```python
carrier_k = CeilDiv(K, 8)
q_pack = GMTensor(DT.int, [M, carrier_k], name="q_pack")
k_pack = GMTensor(DT.int, [N, carrier_k], name="k_pack")

l1q = Tensor(DT.int, [M, carrier_k], Position.L1, name="l1q_carrier")
l1k = Tensor(DT.int, [N, carrier_k], Position.L1, name="l1k_carrier")
l0c = Tensor(DT.int, [M, N], Position.L0C, name="l0c")

gm_to_l1_nd2nz(l1q, q_pack, M=M, N=carrier_k, N_src=carrier_k, M_dst=M)
gm_to_l1_nd2nz(l1k, k_pack, M=N, N=carrier_k, N_src=carrier_k, M_dst=N)

matmul(l0c, l1q.reinterpret(DT.int4), l1k.reinterpret(DT.int4), m=M, n=N, k=K)
```

Here `k=K` is the logical int4 K, not the carrier K.

Low-level `mmad` is also supported when the `L0A` and `L0B` operands are explicit
int4 views:

```python
a4 = l0a_carrier.reinterpret(DT.int4)
b4 = l0b_carrier.reinterpret(DT.int4)
mmad(l0c, a4, b4, M=M, N=N, K=logical_k)
```

## Dtype Rules

`DT.int4.C0 == 64` because one 256-bit C0 contains 64 logical int4 values.

`DT.int4.size` raises `ValueError`. The framework does not model int4 as an
addressable host dtype; simulator storage stays in the backing `DT.int` carrier
and the int4 view aliases that carrier.

Allowed:

- `Tensor(DT.int, carrier_shape, Position.L1).reinterpret(DT.int4)` on a2.
- `Tensor(DT.int, carrier_shape, Position.L0A/L0B).reinterpret(DT.int4)` on a2.
- Transposed carrier views, such as `l1.T.reinterpret(DT.int4)`.

Not allowed:

- `GMTensor(DT.int4, ...)`
- `Tensor(DT.int4, ...)`
- `DBuff(DT.int4, ...)`
- `TBuff(DT.int4, ...)`
- `QBuff(DT.int4, ...)`
- `split_workspace(DT.int4, ...)`
- `.reinterpret(DT.int4)` on non-`DT.int` carriers
- `.reinterpret(DT.int4)` on `UB` or `L0C`
- `.reinterpret(DT.int4)` on the A5 family (`a5`/`950` or `a5pr`/`950pr`)
- using an int4 view outside `matmul` or `mmad`

## Matmul Rules

Int4 matmul is triggered only when both shortcut inputs are explicit int4 views:

```python
matmul(l0c, l1a.reinterpret(DT.int4), l1b.reinterpret(DT.int4), splitk=split_k, m=M, n=N, k=logical_k)
```

Constraints:

- `dst.dtype is DT.int`
- both inputs must be `DT.int4` views
- both inputs must be backed by `DT.int` carriers
- `k` is logical int4 K
- `splitk` is logical int4 split K
- static `splitk` values must be divisible by 8

For split-k, EasyASC slices the carrier tensors by converting logical ranges:

```text
carrier_start = logical_start // 8
carrier_valid_k = CeilDiv(valid_k, 8)
```

The `MMAD` K argument remains logical. EasyASC does not pad K in generated C++;
the kernel/MMAD side is expected to handle any internal padding behavior. Packed
input data must still ensure padded nibbles are valid for the target kernel.

## Codegen Expectations

Only local compute views should mention `int4b_t`:

```cpp
LocalTensor<int4b_t> a4 = a_carrier.ReinterpretCast<int4b_t>();
LocalTensor<int4b_t> b4 = b_carrier.ReinterpretCast<int4b_t>();
MMAD(l0c, a4, b4, m, logical_k, n, is_init);
```

Generated code must not create GM or host int4 types:

```cpp
// Not supported
GlobalTensor<int4b_t> input;
ge::DT_INT4
aclDataType::ACL_INT4
```

## Nibble Order

The bundled simulator and example kernels use low-nibble-first signed int4
packing inside each int32 carrier. Upstream pack logic must produce the same
carrier order for simulator comparisons. If a hardware path disagrees with the
simulator, calibrate the target `int4b_t`/`MMAD` nibble order before changing the
kernel math.

Suggested hardware calibration candidates:

```text
logical int4: [0, 1, 2, 3, 4, 5, 6, 7]
low-nibble-first candidate:  0x76543210
high-nibble-first candidate: 0x01234567
```

## Validation Scope

Current validation covers Python-side authoring rules, generated C++ string
checks, and simulator execution for signed-int4 packed-carrier matmul. It does
not validate hardware numerical correctness.

Relevant test target:

```bash
pytest agent/example/testcases/codegen/tensor_buffer/test_int4_codegen.py agent/example/testcases/simulator/cube/test_int4_matmul_simulator.py
```
