# Conv2D via load3d img2col

Contract notes for the fp16 conv path validated on 910B3 and Ascend950. Read
before using `Conv2D`, `img2col`, `l1_to_l0a_img2col`, or the `conv2d`
shortcut.

Scope:

- device: `easyasc.a2` (910B / C220), or the A5-family facades `easyasc.a5`
  and `easyasc.a5pr` (950 / 950PR, C310); fp16 feature map and weight, fp32
  accumulate
- one conv layer per call; host does all transdata in the pure compute samples;
  no device transdata in the shortcut path itself
- weight resident in L1; feature map reloaded per batch

## Compute flow

```text
caller (kernel):                                    conv2d() (matmul-scope):
  GM data  -- <<= --> L1 fmap (NC1HWC0)               per k0 tile:
  GM weight -- <<= --> L1 [Cout_p, K] (NZ == B ZN)      L1 fmap   -- l1_to_l0a_img2col --> L0A
  GM bias -- ND <<= --> L1 [1, Cout_p] f32 row          L1 weight -- l1_to_l0 (cols)   --> L0B
  m loop / multicore If gate                            mmad(L0C += L0A @ L0B,
  conv2d(l0c, fm, w, conv, ..., m0, bias=b_l1)               bias on first k tile via BT)
  l0c_to_gm_nz2nz(out[m0:m0+tile_m, :], l0c)      out: NZ plane [C1o*M_pad, C0] (NC1HWC0)
```

`conv2d` covers L1 -> L0 -> mmad -> L0C for ONE M tile (same scope as
`matmul`); the caller owns GM->L1 (incl. bias), the m loop, multicore gating
and the L0C->GM store. `l0c_to_gm_nz2nz` keeps NZ: strip c1 holds rows
`c1*M_pad + m` of the [C1o*M_pad, C0] plane; for ND use `out[...] <<= l0c`.

## Shortcut contract

`conv2d()` is matmul-scope only. The caller may reuse one `Tensor` L0C across
multiple cout tiles and simply loop `conv2d(...) -> store -> conv2d(...)`:

- the helper closes the load3d-path L0C-reuse WAR with `barrier(Pipe.M)` after
  every mmad. This is required on A2 and harmless on A5/A5PR.
- the helper closes distinct-bias BT reuse with kernel BT-slot ping-pong via
  `btbufcnt` after the consuming init-tile mmad.

So the stable contract is: caller owns the outer loops and store; `conv2d()`
owns the internal cube hazards.

## A5-family-specific notes

- `easyasc.a5` and `easyasc.a5pr` export the same `conv2d` shortcut as
  `easyasc.a2`; the kernel contract stays "GM->L1, `m` loop, multicore gate,
  store in caller".
- The logical img2col matrix is the same on A2 and the A5 family, but the final
  L0A encoding differs: A2 load3d materializes ZZ; A5/A5PR materialize NZ.
- A5-family load3d has **no K-direction destination stride**. The helper therefore
  loops one hardware load3d per C0 K-fractal inside `L12L0A_IMG2COL`, advancing
  the L0A destination between calls. The DSL call site is still one
  `l1_to_l0a_img2col(l0a, acc.window(...))`.
- Reference pure-cube A5-family samples live under `agent/example/kernels/a5/conv/compute/`;
  A5PR reuses this implementation family.

The conv becomes a plain matmul: `M = Ho*Wo` output points, `K = C1*Kh*Kw*C0`,
`N = Cout_p`. img2col is performed by the load3d hardware on the fly; nothing
in L1 is duplicated.

## Runtime shapes (Var)

`h/w/c/cout/m0` and `l0c_to_gm_nz2nz`'s `m_pad` accept Vars. L1/L0 tensors stay
the static worst case; the runtime shape only masks tails (channel/Cout zeros,
m rows past `Ho*Wo` zeroed). Rules:

- Var `c` makes K dynamic: `tile_k` is then mandatory (static, must divide
  every runtime K). conv2d issues a static first K tile (is_init + bias) plus
  a runtime `range` tail — empty when `K == tile_k`.
- `acc[m0:m0+ext]` slices can't recover static extents from Var starts; use
  `view.window(m0, k0, m_ext, k_ext)` (extents stay static ints).
- Var C rounds channelSize to full C0 blocks at runtime (same rule as static;
  sub-block channelSize repacks the K grid and corrupts — see constraints).
- m loop: `for m0 in range(0, m_pad, TILE_M)`, `m_pad` a 16-aligned Var that
  the host computes. OpExec auto-binds scalar args to equal GM dims — keep the
  values pairwise distinct from GM dims or pass `shape_bindings`.

## Input / output formats (host packers)

Import both target-independent host helpers from `easyasc.utils.conv2d`.
`easyasc.a2` also re-exports them; the A5-family facades currently do not.

`pack_nc1hwc0(x[N, C, H, W]) -> [N*C1*H*W, C0]` — zero channel tail.

`pack_conv_weight(w[Cout, Cin, Kh, Kw]) -> [Cout_p, K]` ND, row-major, K order
`c1 -> kh -> kw -> c0`, zero C/Cout tails. Feed via `w_l1 <<= weight` (nd2nz);
L1 NZ of `[Cout, K]` is exactly mmad B's ZN. **Never pack `[K, N]` ZN fractals
yourself** — NZ and ZN block grids are transposed, every N-block silently
pairs with the wrong K-block (bisected on hardware; outputs look plausible).

Bias is a flat fp32 `[1, Cout_p]` row staged by the caller as an L1
`layout=Layout.ND` tensor via `<<=` (flat `gm_to_l1`); `conv2d(bias=b_l1)`
routes it through the kernel BT buffer (same idiom as `matmul`). Never stage
a BT source with a default `<<=` (nd2nz fractalizes the row).

Output (NZ store): fp32 plane `[C1o * m_pad, C0]` per batch == NC1HWC0; host
gathers `got[m, c] = out[c//16 * m_pad + m, c%16]`. Rows `>= Ho*Wo` / channels
`>= Cout` are zero. ND output remains available via `out[...] <<= l0c`.

## load3d behavior, parameter by parameter (runnable golden)

The img2col virtual matrix per batch is shared by A2 and A5/A5PR; only the
final L0A encoding differs by device family.

- row `m = ho*Wo + wo` enumerates output points (W fastest);
- col `k = ((c1*Kh + kh)*Kw + kw)*C0 + c0` (channel-tail slow, c0 fastest);
- window `[m0:m0+m_ext) x [k0:k0+k_ext)`: m 16-aligned, k C0-aligned;
- out-of-range reads (M tail, spatial pad, channel tail) return padValue 0.

PyTorch model (mirrors the hardware and `simulator/pipe_cube.py`):

```python
import torch

def load3d(fm, c, pad, stride, dil, kh, kw, k0, k_ext, m0, m_ext):
    # fm: [C1, H, W, C0]; returns the [m_ext, k_ext] tile written to L0A
    c1, h, w, c0 = fm.shape
    pl, pr, pt, pb = pad; sh, sw = stride; dh, dw = dil
    ho = (h + pt + pb - (dh*(kh-1)+1)) // sh + 1
    wo = (w + pl + pr - (dw*(kw-1)+1)) // sw + 1
    m, k = m0 + torch.arange(m_ext), k0 + torch.arange(k_ext)
    oh, ow = m // wo, m % wo                      # m: W-fastest raster
    kc1, r = k // (kh*kw*c0), k % (kh*kw*c0)      # k: c1 -> kh -> kw -> c0
    fkh, r = r // (kw*c0), r % (kw*c0)
    fkw, kc0 = r // c0, r % c0
    ih = (oh*sh - pt)[:, None] + (fkh*dh)[None, :]    # stride/pad/dilation move
    iw = (ow*sw - pl)[:, None] + (fkw*dw)[None, :]    # only the sampled h/w
    ok = ((m < ho*wo)[:, None] & (ih >= 0) & (ih < h) & (iw >= 0) & (iw < w)
          & (kc1*c0 + kc0 < c)[None, :])              # everything else = padValue 0
    flat = ((kc1[None]*h + ih.clamp(0, h-1))*w + iw.clamp(0, w-1))*c0 + kc0[None]
    return fm.reshape(-1)[flat] * ok

# parameter effects, with fm[c1, ih, iw, c0] = c1*1e6 + ih*1e4 + iw*100 + c0:
c1, h, w, c0 = 2, 6, 6, 16
fm = (torch.arange(c1)[:, None, None, None]*1e6 + torch.arange(h)[None, :, None, None]*1e4
      + torch.arange(w)[None, None, :, None]*100 + torch.arange(c0)).float()
def t(**kw):
    a = dict(c=32, kh=3, kw=3, pad=(1,1,1,1), stride=(1,1), dil=(1,1),
             k0=0, k_ext=288, m0=0, m_ext=16)
    a.update(kw); return load3d(fm, **a)

t()[0, :3]               # [0,0,0]      out(0,0), k 0..2 = top-left taps -> pad
t()[0, 64:67]            # [0,1,2]      k=64 = (kh=1,kw=1) center tap = fm[0,0,0,:]
t(stride=(2,2))[1, 64]   # 200          out(0,1) jumps 2 cols -> fm[0,0,2,0]
t(dil=(2,2))[5, 64]      # 20200        taps stretch: center of out(1,1) -> fm[0,2,2,0]
t(m0=16)[0, 64]          # 20400        mStartPt: same matrix, row 16 = out(2,4)
t(k0=144, k_ext=144)[7, 0]  # 1000000   kStartPt=144 starts at c1=1 -> fm[1,0,0,0]
```

Each parameter's full effect: `pad/stride/dilation` only relocate `(ih, iw)`;
`kh/kw/C` reshape the K decomposition; `m0/k0/m_ext/k_ext` only window the
matrix. K layout never depends on pad/stride/dilation, so the weight pack is
the same for every conv geometry.

## Constraints (trace-checked; hardware silently corrupts otherwise)

| param | constraint |
| --- | --- |
| m0 / m_ext | multiple of 16; m0 <= 32767 |
| k0 / k_ext | multiple of C0 (fp16: 16); window within K |
| stride / filter / dilation | 1..63 / 1..255 / 1..255 |
| pad | 0..255 |
| H, W | 1..32767 |
| C | fmap is C1 full blocks; C tail zero-padded on host. The stub rounds channelSize to FULL C0 blocks: sub-block remainders (4/8) are nominally legal but repack the K grid and break the C0-grid weight pack wholesale (C=31 raw and C=20->24 both corrupt on 910B3; zero tail keeps full-grid rounding numerically identical) |
| L1 footprint | whole fmap + weight tile resident: C1*H*W*32B + 2*Cout_p*K B |
| dst | L0A only, 512B-aligned slot |
| tiles | conv2d uses the kernel L0 DBuff: tile_m*tile_k and tile_k*cout_p each fit a 32KB L0 slot |

## Caveats

- channels-fast K decomposition mismatch: identity-weight bisect on hardware
  showed conv2d outputs matching `x[c=16..]` when weights were packed `[K, N]`
  ZN — symptom mimics a c-fast K order; real cause is NZ/ZN block transpose.
- big C·H·W needs L1 K-staging (not yet supported); large COUT needs N split.
- distinct-bias cout-tiling relies on the helper-owned BT ping-pong, so one
  bias tile must fit a device BT slot: 64 fp32 values on A2 and 512 on
  A5/A5PR. Same-bias restaging across `m` tiles is
  harmless.
- native NZ fixpipe REQUIRES the explicit CFG_NZ template config — the default
  config is NZ2ND and silently reads dstStride as an ND row width (the
  row-interleaved writes we first dumped). With CFG_NZ, dstStride =
  strip-to-strip gap in 32B blocks (mPad*2 for fp32; the copy_matrix dst_M*2
  convention) — one fixpipe per tile, 910B3 unit-scan validated. quantPre works
  like NZ2ND (relu/scale/offset; fp32->fp16 + int8 quant HW-verified); the dst
  NC1HWC0 C0 follows 32B/sizeof(dst): 16 for fp32/fp16, 32 for int8.

Samples: `agent/example/kernels/a2/conv/compute/`, `agent/example/kernels/a5/conv/compute/`.
