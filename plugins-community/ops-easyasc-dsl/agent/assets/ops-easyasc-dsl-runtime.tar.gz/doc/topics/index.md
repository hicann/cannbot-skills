# Topic Contracts (feature / dtype)

These pages are precise authoring contracts for specific operators and dtypes.
They are **not** numbered tutorial steps; reach for them only when you write
that particular kind of kernel. Read the relevant page in full before
authoring, not as background.

| page | device | read before |
| --- | --- | --- |
| [`conv2d.md`](conv2d.md) | A2 + A5 family | any Conv2D / `load3d` img2col kernel |
| [`mxfp.md`](mxfp.md) | A5 family | any MX FP8 / MXFP4 matmul (`matmul_mx`, `l1_to_l0_mx`, `mmad_mx`) |
| [`int4.md`](int4.md) | a2 only | any int4 matmul kernel |

The summaries below are the "must know before you start" facts; each page is the
full contract.

## conv2d.md — Conv2D via load3d img2col (A2 + A5 family)

fp16 feature map + weight, fp32 accumulate; conv lowered to a plain matmul
(`M = Ho*Wo`, `K = C1*Kh*Kw*C0`, `N = Cout_p`) with img2col done by the load3d
hardware on the fly.

- `conv2d()` is matmul-scope only: it owns L1 -> L0 -> mmad -> L0C for one M
  tile plus the internal cube hazards; the caller owns GM->L1 (incl. bias), the
  `m` loop, multicore gating, and the L0C->GM store.
- The logical img2col matrix is shared by A2 and A5/A5PR; only the final L0A
  encoding differs (A2 materializes ZZ, A5/A5PR materialize NZ, one hardware load3d per C0
  K-fractal).
- Host packers (import from `easyasc.utils.conv2d`): `pack_nc1hwc0` for the
  feature map, `pack_conv_weight` (ND, K order `c1 -> kh -> kw -> c0`) for the
  weight. **Never pack `[K, N]` ZN
  fractals yourself** — the NZ/ZN block transpose silently bisects on hardware.

## mxfp.md — MX FP8 / MXFP4 matmul (A5 family)

Separates FP8/FP4 mantissa/exponent data from a per-row, per-K-group e8m0 scale
stream.

- `DT.e4m3` / `DT.e5m2` are normal FP8 data dtypes; `DT.mx_e4m3` / `DT.mx_e5m2`
  are the L0A/L0B MX compute-view dtypes.
- `DT.fp4_e2m1` / `DT.fp4_e1m2` are A5-family packed FP4 compute views over
  `DT.uint8` carriers; GM/L1 payload shape is `[rows, K / 2]`.
- e8m0 scale is carried as `DT.uint8`; value `127` means multiplier `1.0`.
- Scale is logical `[rows, ceil(K / 32)]` only as a math view; **do not infer
  storage from that shape**. Use `gm_to_l1_mx_scale` for packed
  `[num_blocks, 32]` input or `gm_to_l1_mx_scale_nd2nz` for the documented
  dense scale input.
- `matmul_mx` supports no-split, split-K, and split-N; split-K and split-N
  cannot be enabled together yet.

## int4.md — int4 adaptation (a2-only)

A local compute-view marker backed by `DT.int` carrier tensors, not a host / GM /
CPU-addressable int4 storage model.

- `DT.int4` is a DSL marker dtype; only local compute views can be int4.
- GM and on-chip carriers are `DT.int`; eight logical int4 values pack into one
  carrier element.
- `GMTensor(DT.int4, ...)` and `Tensor/DBuff/TBuff/QBuff(DT.int4, ...)` are
  rejected.
- Int4 matmul is triggered by
  `matmul(..., l1a.reinterpret(DT.int4), l1b.reinterpret(DT.int4), k=logical_k)`;
  plain `DT.int` matmul is not supported.
- The simulator implements signed int4 MMAD through packed `DT.int` carriers;
  the current validation still does not prove hardware numerical correctness.
