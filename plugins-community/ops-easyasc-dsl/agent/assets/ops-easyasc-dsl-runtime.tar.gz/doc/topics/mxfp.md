# MX FP8 / MXFP4 Matmul Notes

This document records the current A5-family MX FP8 / MXFP4 authoring contract. Read it
before using `matmul_mx`, `l1_to_l0_mx`, or `mmad_mx`.

Scope:

- target device surface: `easyasc.a5` or `easyasc.a5pr`, `device_type in ("950", "950pr")` (Atlas 350 / C310)
- data formats: `DT.e4m3` / `DT.e5m2` inputs, or packed MXFP4 `DT.fp4_e2m1`
  / `DT.fp4_e1m2` views; e8m0 scale carried as `DT.uint8`
- shortcut layout: NZ2NZ, plus A-side / B-side NZ2ZN through `l1a.T` or
  `l1b.T`
- low-level layout: `l1_to_l0_mx` supports NZ2NZ and L0A/L0B NZ2ZN
- current shortcut support: no-split, split-K, or split-N, but not split-K and
  split-N together

Out of scope:

- a2 / b-series MX FP8
- transposed scale tensors in the high-level `matmul_mx` shortcut
- mixed split-K plus split-N scheduling
- host-side automatic scale quantization
- automatic compact-tail packing into padded transpose tiles

## Scale Storage and Movement Contract (Read First)

Do not guess the scale layout from the logical formula. MX scale has three
different views, and only one of them is the external GM storage contract.

Logical math view:

```text
[rows, ceil(K / 32)]
```

This is only the mathematical scale grid. It is not the GM tensor shape passed
to `gm_to_l1_mx_scale`.

External GM storage view:

```text
[row_tile, k64_block, 16, 2] flattened to GMTensor(DT.uint8, [num_blocks, 32])
```

Each 32-byte block contains one 16-row tile and two K-32 scale groups:

```text
row0_group0, row0_group1, row1_group0, row1_group1, ..., row15_group0, row15_group1
```

L1 staging view:

```text
Tensor(DT.uint8, [16, 2 * k_blocks], Position.L1)
```

The declared L1 shape is 2D, but the bytes copied by `gm_to_l1_mx_scale` retain
the same K-64 block stream described above. `l1_to_l0_mx` then copies those
compact scale bytes into the hidden `L0AMX` or `L0BMX` buffer.

Authoring rules:

- never pass a logical `[rows, ceil(K / 32)]` GM tensor directly to
  `gm_to_l1_mx_scale`
- never move MX scale through `gm_to_l1_nd2nz`; use `gm_to_l1_mx_scale`
- `row_tile_idx` selects a 16-row tile of A or B scale
- `k_block_idx` selects a K-64 scale block inside that row tile
- split-K scale slices must start on a K-64 boundary in the current shortcut
- split-N B-scale slices advance by 16-row `row_tile` blocks
- scale tensors cannot be transposed; for low-level NZ2ZN, provide scale that
  is already packed in the post-transpose row order

Online cast uses the same scale layout. When a kernel computes MXFP8 scale
from float data, each contiguous K-32 group should produce one e8m0 byte:

```text
scale_byte = max((float_bits & 0x7f800000) >> 23) over the 32-value group
scale      = 2 ** (scale_byte - 127)
```

The FP8 payload is computed from `value / scale`, then stored as `DT.e4m3` or
`DT.e5m2`. For an all-zero group, `scale_byte == 0`; the payload-normalization
path should treat the divisor as `2 ** -127` rather than zero.

The generated scale bytes must be packed directly into the physical MX block
order before publishing to L1. For `K = 64`, a 16-row tile is exactly one 32B
block with `[16, 2]` logical shape and byte order
`row0_g0, row0_g1, row1_g0, row1_g1, ...`. Do not write a normal row-major
logical scale tensor and then run an ND2NZ move on it.

## 1. Concepts

MX FP8 matmul separates the mantissa/exponent FP8 data from a per-row,
per-K-group scale stream.

Logical compute:

```text
out[M, N] = (A[M, K] * scale_a[M, K]) @ (B[N, K] * scale_b[N, K]).T
```

The scale is stored as e8m0 bytes. A byte value is interpreted as:

```text
scale = 2 ** (value - 127)
```

So:

- `127` means `1.0`
- `128` means `2.0`
- `126` means `0.5`

The scale granularity is per row and per 32 K elements. For a logical K:

```text
logical_scale_groups = ceil(K / 32)
```

## 2. Dtypes

User-visible FP8 source data starts as normal FP8:

- `DT.e4m3`
- `DT.e5m2`

The L0 compute views use MX FP8 dtypes:

- `DT.mx_e4m3`
- `DT.mx_e5m2`

Do not use `DT.mx_*` for GM or L1 source data. These dtypes are for L0A/L0B
compute views loaded by `l1_to_l0_mx`.

Scale tensors use `DT.uint8` as the carrier. The current stubs also accept the
backend name `fp8_e8m0_t` when present, but normal DSL code should use
`DT.uint8`.

MXFP4 source payload is different: there is no byte-addressable FP4 tensor.
User-visible GM and L1 payload storage is a packed `DT.uint8` carrier with two
logical FP4 values per byte. Create a logical FP4 compute view with:

```python
l1_u8 = Tensor(DT.uint8, [rows, K // 2], Position.L1)
l1_fp4 = l1_u8.reinterpret(DT.fp4_e2m1)  # or DT.fp4_e1m2
```

`DT.fp4_e2m1` and `DT.fp4_e1m2` map to CANN `fp4x2_e2m1_t` and
`fp4x2_e1m2_t`. They have `C0 == 64`, but `size` is unsupported because the
logical element is half a byte. Do not allocate `Tensor`, `DBuff`, `TBuff`,
`QBuff`, `GMTensor`, or workspace directly with FP4 dtypes.

For low-level MXFP4 loads, the L0 destination must also be a carrier tensor
reinterpreted as the same FP4 dtype:

```python
l0_u8 = Tensor(DT.uint8, [rows, K // 2], Position.L0A)
l0_fp4 = l0_u8.reinterpret(DT.fp4_e2m1)
l1_to_l0_mx(l0_fp4, l1_fp4, scale_l1, m_dst=rows, n_dst=K, m_src=rows, n_src=K)
```

The `matmul_mx` shortcut accepts FP4 L1 views and reuses its internal L0
scratch buffers. `mmad_mx` requires a `DT.float` L0C destination, so the natural
final GM output path is fp32:

```python
matmul_mx(l0c_float, l1a_fp4, l1b_fp4, scale_a, scale_b, m=M, n=N, k=K)
z_fp32[:, :] <<= l0c_float
```

All four FP4 format pairings among `DT.fp4_e2m1` and `DT.fp4_e1m2` are the
fully verified MXFP4 paths: e2m1/e2m1, e1m2/e1m2, e2m1/e1m2, and e1m2/e2m1.
CANN 9.0 CANNSIM validation covers all 12 shortcut combinations for each FP4
pairing: no transpose, A-only transpose, B-only transpose, and both-side
transpose crossed with no split, split-K, and split-N. Mixed FP8/FP4 MX
operands are rejected for now.

For CANN 9.0 / Ascend950 `MMAD_MX`, FP4 accumulation uses these decoded values
plus e8m0 scale expansion:

```text
e2m1: [0, 0.5, 1, 1.5, 2, 3, 4, 6]
e1m2: [0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75]
```

The sign bit negates the decoded magnitude. Increasing either operand scale
byte by one still doubles that operand.

FP4 NZ2ZN transpose loads require a physical `64 x 64` FP4 source block. Pad
the L1 carrier tile before calling `matmul_mx(..., l1x.T, ...)` or
`l1_to_l0_mx(..., src.T, ...)` when the logical transposed operand is narrower.

## 3. Scale Layout

The logical scale shape for one operand is:

```text
[rows, ceil(K / 32)]
```

where `rows` is:

- `M` for A scale
- `N` for B scale

The physical transfer format is packed by K-64 blocks. Each K-64 block stores
two K-32 scale groups for a 16-row tile:

```text
[16, 2]
```

The 32 bytes inside one block are ordered by row, with the two K-32 groups
adjacent for that row.

For one 16-row L1 tile, use:

```python
scale_l1 = Tensor(DT.uint8, [16, 2 * CeilDiv(K, 64)], Position.L1)
```

For external GM scale, use a compact block stream:

```text
[row_tile, k64_block, 16, 2] flattened to [num_blocks, 32]
```

The current helper expects the GM object as:

```python
scale_gm = GMTensor(DT.uint8, [num_blocks, 32])
```

This compact `[num_blocks, 32]` GM object is mandatory for
`gm_to_l1_mx_scale`; it is intentionally not the logical
`[rows, ceil(K / 32)]` view.

For `K = 64`, one 16-row tile is one GM block:

```text
[1, 32]
```

For `K = 128`, one 16-row tile is two GM blocks:

```text
[2, 32]
```

If `K` has an odd number of K-32 groups, the second byte of the final K-64 pair
is padding from the logical scale point of view.

If the caller already has dense e8m0 scale as a logical matrix
`[rows, ceil(K / 32)]`, use `gm_to_l1_mx_scale_nd2nz(...)` instead of manually
pre-packing `[num_blocks, 32]`. That helper reinterprets adjacent e8m0 values as
`half` and uses the A5 `Dn2NzParams` path to materialize the same compact L1 MX
scale stream:

```text
[ceil(rows / 16), ceil(ceil(K / 32) / 2), 16, 2 bytes]
```

Equivalently, in byte terms the L1 visible shape is still:

```text
[rows, 2 * ceil(ceil(K / 32) / 2)]
```

### Low-Level Transposed L0 Loads / NZ2ZN

This section is deliberately loud because the scale behavior is easy to get
wrong: `LoadData2DMxParams` does not transpose scale. For an NZ2ZN load, the
scale tile must already be packed in the row order of the transposed logical
operand.

The high-level `matmul_mx` shortcut supports this transpose path for both
operands when the caller passes `l1a.T` and/or `l1b.T`. The low-level
`l1_to_l0_mx` API supports `src.T` for both `L0A` and `L0B`.

For a physical A source tile shaped `[K, M]` and consumed as `A.T`, keep the
explicit data parameters in physical source order:

```python
l1_to_l0_mx(l0a, l1a_km.T, scale_a, m_dst=K, n_dst=M, m_src=K, n_src=M)
```

The matching scale tile is not `[K, 2 * ceil(M / 64)]`. It must be:

```text
[M, 2 * ceil(K / 64)]
```

Rows are logical A rows / output M, and the K groups still describe the
reduction axis.

For a physical B source tile shaped `[K, N]` and consumed as `B.T`, keep the
explicit data parameters in physical source order:

```python
l1_to_l0_mx(l0b, l1b_kn.T, scale_b, m_dst=K, n_dst=N, m_src=K, n_src=N)
```

The matching scale tile is not `[K, 2 * ceil(N / 64)]`. It must be:

```text
[N, 2 * ceil(K / 64)]
```

That is the post-transpose row order: rows are logical B rows / output N. The
packed byte stream still uses the same K-64 `[16, 2]` block contract described
above.

Static NZ2ZN tiles require both physical source dimensions to be C0-aligned:
32 elements for FP8, 64 elements for FP4. For tails, stage a padded L1 data tile
first. The helper `zero_mxfp8_l1_padding(tensor)` can clear a padded byte-sized
FP8 data tile or FP4 `DT.uint8` carrier tile, then the kernel should fill live
scale/data after that clear. Scale padding itself does not need initialization
when the corresponding payload lanes are zero.

Do not use `gm_to_l1_nd2nz` as a magic compact-to-padded transpose packer. A
compact GM tile such as `[K, 16]` copied into a padded `[K, 32]` L1 transpose
tile needs a real packing/copy path; blindly using ND2NZ produced wrong
CANNSIM results during validation.

When combining low-level NZ2ZN with tiling, treat scale as a physical MX block
stream and offset it explicitly:

- split-K: for any transposed operand, keep the full pre-transposed scale tile
  shaped `[rows, 2 * ceil(total_K / 64)]` and pass
  `src_mx_offset_element = (subk // 64) * 32`; do not use normal
  `scale[:, scale_col0:...]` slicing for transposed scale.
- split-N: `l1b.T` slices the physical B data columns in C0-aligned chunks
  (32 elements for FP8, 64 elements for FP4), keeps the full B scale tile, and
  passes
  `src_mx_offset_element = (subn // 16) * ceil(K / 64) * 32`. `l1a.T` is loaded
  once for split-N, so A scale does not receive an N-axis offset.

When `src_mx_offset_element` is supplied explicitly, `l1_to_l0_mx` allows the
larger full physical scale tile instead of requiring the sliced tile's exact
visible shape. This keeps dynamic loops and static unrolled chunks consistent.

The transposed-B split-N chunk is format-specific: FP8 uses 32-element chunks
because `C0 == 32`; FP4 uses 64-element physical chunks because `C0 == 64`.
The current NZ2ZN B-side column path is not a 16-column tail path. CANNSIM
validation passed all 12 shortcut combinations for the covered format/alignment
cases: no transpose, A-only transpose, B-only transpose, and both-side
transpose, each with no split, split-K, and split-N.

The shortcut follows exactly these rules. For `matmul_mx(..., l1a.T, l1b.T,
...)`, the physical A/B sources are `[K, M]` and `[K, N]`, but `scale_a` and
`scale_b` are already the post-transpose scale tiles `[M, 2 * ceil(K / 64)]`
and `[N, 2 * ceil(K / 64)]`. Shortcut split-K uses the split-K scale offset
above; shortcut split-N requires a transposed-load-aligned static split size
when `l1b.T` is present: 32 elements for FP8, 64 elements for FP4.

## 4. High-Level Shortcut

### `matmul_mx(dst, l1a, l1b, scale_a, scale_b, splitk=None, m=None, n=None, k=None, is_init=True, *, splitn=None, bias=None)`

Purpose: emit the MX FP8 / MXFP4 matmul staging path:

```text
L1 FP8/FP4 + L1 e8m0 scale -> L0A/L0B MX operands + L0AMX/L0BMX -> MMAD_MX -> L0C
```

Logical contract:

```text
l1a[M, K] @ l1b[N, K].T -> dst[M, N]
```

Restrictions:

- A5 family only (`easyasc.a5` / `easyasc.a5pr`)
- `dst` must be `DT.float` at `Position.L0C`
- `l1a` and `l1b` must be `DT.e4m3` / `DT.e5m2` tensors or
  `DT.fp4_e2m1` / `DT.fp4_e1m2` carrier-backed views at `Position.L1`
- `scale_a` and `scale_b` must be `DT.uint8` at `Position.L1`
- `l1a.T` and `l1b.T` are supported as physical `[K, M]` / `[K, N]` sources
  with pre-transposed A/B scale; transposed scale tensors are rejected
- `splitn` and `splitk` cannot both be set
- static `splitk` must be a multiple of `64`
- static `splitn` must be a multiple of `16`; with `l1b.T`, static `splitn`
  must satisfy the transposed-load alignment: 32 elements for FP8, 64 elements
  for FP4
- `bias`, when present, must be a contiguous fp32 `[1, N]` row staged in L1;
  the shortcut loads it into BT / `TPosition::C2` and applies it only on the
  init tile, so `bias` requires `is_init=True`; A5/A5PR holds 512 fp32 values
  per automatic BT slot, so nosplit/split-K needs static `N <= 512`, while
  dynamic total N must use a static `splitn <= 512`

Current row-tile assumptions:

- no-split and split-K paths expect 16-row scale tiles for non-transposed
  operands
- for `l1a.T`, A scale rows are logical M rows, shaped
  `[M, 2 * ceil(K / 64)]`
- for `l1b.T`, B scale rows are logical N rows, shaped
  `[N, 2 * ceil(K / 64)]`
- split-N expects `scale_a` to cover the current A rows: one 16-row physical
  tile for non-transposed A, or the full post-transpose M rows for `l1a.T`
- split-N expects `scale_b.shape[0]` to match the full B logical row count,
  with rows physically addressable in 16-row blocks

Minimal fixed-tile example:

```python
@kernel()
def mx_kernel(x: GMTensor, y: GMTensor, scale_a_gm: GMTensor, scale_b_gm: GMTensor,
              z: GMTensor, M: Var, N: Var, K: Var):
    l1a = Tensor(DT.e4m3, [16, 64], Position.L1)
    l1b = Tensor(DT.e4m3, [16, 64], Position.L1)
    scale_a = Tensor(DT.uint8, [16, 2], Position.L1)
    scale_b = Tensor(DT.uint8, [16, 2], Position.L1)
    l0c = Tensor(DT.float, [16, 16], Position.L0C)

    with auto_sync():
        l1a <<= x[:, :]
        l1b <<= y[:, :]
        gm_to_l1_mx_scale(scale_a, scale_a_gm)
        gm_to_l1_mx_scale(scale_b, scale_b_gm)
        matmul_mx(l0c, l1a, l1b, scale_a, scale_b, m=M, n=N, k=K)
        z[:, :] <<= l0c
    return z
```

## 5. Low-Level API

Use the low-level helpers when writing tests or building a custom staging path.
Normal kernels should prefer `matmul_mx`.

### `gm_to_l1_pad(dst, src, n_burst=None, burst_len_element=None, src_stride_element=None, dst_stride=None)`

Purpose: normal-mode GM to L1 padded copy. Unlike `gm_to_l1_nd2nz`, this helper
does not require the logical burst in GM to already be 32-byte aligned. Each
destination burst is padded up to a 32-byte boundary.

`gm_to_l1_mx_scale` uses this helper to copy compact scale blocks from GM.

### `gm_to_l1_mx_scale(dst, src, row_tile_idx=0, k_blocks=None, src_k_blocks=None, k_block_idx=0)`

Purpose: copy one 16-row MX scale tile from packed GM scale into L1.

Parameters:

- `dst`: `Tensor(DT.uint8, [16, 2 * k_blocks], Position.L1)`
- `src`: `GMTensor(DT.uint8, [num_blocks, 32])`
- `row_tile_idx`: which 16-row operand tile to copy
- `k_blocks`: number of K-64 scale blocks to copy
- `src_k_blocks`: number of K-64 blocks per row tile in GM
- `k_block_idx`: starting K-64 block within that row tile

If `k_blocks` is omitted, it is inferred from `dst.shape[1] // 2`. If
`src_k_blocks` is omitted, it defaults to `k_blocks`.

For full post-transpose scale tiles with more than 16 rows, either issue
multiple row-tile copies or stage the packed block stream with `gm_to_l1_pad`.
The physical GM order remains `[row_tile, k64_block, 16, 2]` flattened to
`[num_blocks, 32]`.

### `gm_to_l1_mx_scale_nd2nz(dst, src, rows=None, k_groups=None, src_k_groups=None)`

Purpose: copy dense GM e8m0 scale into the compact L1 MX scale layout without
requiring the caller to pre-pack `[num_blocks, 32]` blocks.

Parameters:

- `dst`: `Tensor(DT.uint8, [rows, 2 * ceil(k_groups / 2)], Position.L1)`
- `src`: `GMTensor(DT.uint8, [rows, k_groups])`
- `rows`: logical row count; currently expected to be 16-row aligned
- `k_groups`: logical e8m0 columns, i.e. `ceil(K / 32)`
- `src_k_groups`: physical GM row stride in e8m0 elements; defaults to `k_groups`

If all three shape arguments are omitted, the helper infers them from the
visible GM slice:

- `rows = src.span[0]`
- `k_groups = src.span[1]`
- `src_k_groups = src.shape[1]`

Lowering detail: the generated helper reinterprets `src` and `dst` as `half`
so each `half` carries two adjacent e8m0 values, then uses `Dn2NzParams` with
the compact physical target order:

```text
[ceil(rows / 16), ceil(k_groups / 2), 16, 2 bytes]
```

This path matched the low-level `l1_to_l0_mx` / `MMAD_MX` contract on Ascend950
CANNSIM for:

- `rows = 16, k_groups = 4` (`K = 128`)
- `rows = 32, k_groups = 2` (`K = 64`)
- `rows = 32, k_groups = 4` (`K = 128`)

### `l1_to_l0_mx(dst, src, src_mx, m_dst=None, n_dst=None, m_src=None, n_src=None, src_mx_offset_element=0)`

Purpose: move FP8 data or carrier-backed FP4 views from L1 into matching
L0A/L0B compute views and move the matching scale bytes into the hidden L0AMX
or L0BMX buffer.

Lowering:

```text
L0NZ2NZ_MX(dst, src, src_mx, m_dst, n_dst, m_src, n_src)
L0NZ2ZN_MX(dst, src, src_mx, m_dst, n_dst, m_src, n_src)  # src.T
```

Restrictions:

- A5 family only (`easyasc.a5` / `easyasc.a5pr`)
- `src` must be `DT.e4m3` / `DT.e5m2`, or a `DT.uint8` carrier reinterpreted
  as `DT.fp4_e2m1` / `DT.fp4_e1m2`, at `Position.L1`
- `dst` must be the matching MX FP8 dtype, or a carrier reinterpreted as the
  matching FP4 dtype, at `Position.L0A` or `Position.L0B`
- `src_mx` must be `DT.uint8` at `Position.L1`
- non-transposed `src` lowers through NZ2NZ
- `src.T` lowers through NZ2ZN for `Position.L0A` and `Position.L0B`
- `src_mx` cannot be transposed
- static MX NZ2ZN tiles require both physical source dimensions to be aligned:
  32 elements for FP8, 64 elements for FP4
- MX start position is fixed to zero; there is no public start-position argument

The non-transposed scale shape visible to `l1_to_l0_mx` is:

```text
[m_src, 2 * ceil(n_dst / 64)]
```

For matmul, `n_dst` is the active K dimension of the loaded operand.

For a transposed A path, with physical source shape `[K, M]` and explicit
parameters `m_dst=K, n_dst=M, m_src=K, n_src=M`, the visible scale shape is:

```text
[M, 2 * ceil(K / 64)]
```

For a transposed B path, with physical source shape `[K, N]` and explicit
parameters `m_dst=K, n_dst=N, m_src=K, n_src=N`, the visible scale shape is:

```text
[N, 2 * ceil(K / 64)]
```

Again, the scale is pre-transposed by storage order; the MX load does not
transpose it for you.

### `zero_mxfp8_l1_padding(tensor, n_blocks=None)`

Purpose: clear a padded byte-sized L1 data tile before filling live transpose
data. This shortcut helper is exported by both A5-family facades; despite the
historical name, it is also valid for FP4 `DT.uint8` carrier tiles.

Restrictions:

- A5 family only (`easyasc.a5` / `easyasc.a5pr`)
- `tensor` must be a byte-sized `Position.L1` tensor, such as `DT.e4m3`,
  `DT.e5m2`, or an FP4 `DT.uint8` carrier tile
- the tensor must be a physical tensor, not a transpose view
- if `n_blocks` is omitted, the static tensor footprint must be 32B aligned

Call this helper before filling live scale/data after tile. A5 constant fill is
coarse enough that calling it after filling scale/data can clear useful bytes.

### `mmad_mx(dst, src_a, src_b, M=None, N=None, K=None, is_init=True, bias=None)`

Purpose: compute MX FP8 / MXFP4 matmul from already loaded L0 operands.

Lowering:

```text
MMAD_MX(dst, src_a, src_b, M, K, N, is_init)
MMAD_MX_BIAS(dst, src_a, src_b, bias, M, K, N, is_init)   # when bias= is provided
```

Restrictions:

- A5 family only (`easyasc.a5` / `easyasc.a5pr`)
- `dst` must be `DT.float` at `Position.L0C`
- `src_a` must be MX FP8 or FP4 at `Position.L0A`
- `src_b` must be MX FP8 or FP4 at `Position.L0B`
- both sources must be from the same family: FP8/FP8 or FP4/FP4
- `bias`, when present, must be a `DT.float` (fp32) tensor at `Position.BT`, and is applied on the `is_init` tile only (lowers to `MMAD_MX_BIAS`)

`is_init=False` accumulates into the existing L0C tile. This is what split-K
uses after the first K chunk.

## 6. Split Behavior

### No split

The shortcut loads A, B, A-scale, and B-scale once, then emits one `MMAD_MX`.

### Split-K

`splitk` slices the K dimension. For each chunk:

- A and B data are sliced by K
- A scale is sliced by K-32 group
- non-transposed B scale is sliced by K-32 group
- each transposed operand keeps the full post-transpose scale tile and advances
  with `src_mx_offset_element = (_subk // 64) * 32`
- the first chunk initializes L0C if the caller's `is_init` is true
- later chunks use `is_init=False`

Static `splitk` must be divisible by `64`, matching the current K-64 physical
scale-block copy model.

### Split-N

`splitn` slices B rows and L0C columns. For each N chunk:

- A is loaded once under `_subn == 0`
- B data is sliced by N; for `l1b.T`, the physical B data columns are sliced
  and the chunk size must be aligned to the source format C0: 32 elements for
  FP8, 64 elements for FP4
- `l1a.T` is still loaded once because split-N does not slice A
- B scale is selected by 16-row tile offset:

```text
scale_b_offset = (_subn // 16) * CeilDiv(K, 64) * 32
```

Split-N writes disjoint L0C columns, so the caller's `is_init` flag applies to
every N slice.

## 7. Simulator Model

The simulator allocates two per-core hidden local buffers:

- `L0AMX`: 4 KB
- `L0BMX`: 4 KB

`l1_to_l0_mx` copies scale bytes into one of these buffers based on the L0
destination, and the simulator keeps an operand-local scale snapshot so split-K
or split-N prefetches cannot overwrite the scale used by an already-issued
`mmad_mx`. The simulator models NZ2NZ plus L0A/L0B NZ2ZN execution paths.
`mmad_mx` then:

1. decodes L0A/L0B NZ FP8 into logical `[M, K]` and `[N, K]`
2. decodes L0AMX/L0BMX e8m0 scale bytes
3. expands each scale group across 32 K columns
4. computes float32 matmul
5. writes compact L0C NZ with fixed `C0 = 16`

Cycle estimates route `mmad_mx` through the same width-based matmul estimator as
`mmad`; MX FP8 is treated as an 8-bit matmul for that model.

## 8. Validation

Relevant regression targets:

```bash
pytest agent/example/testcases/codegen/datamove/test_l1_to_l0_mx_codegen.py
pytest agent/example/testcases/simulator/cube/test_l1_to_l0_mx.py
```

The simulator test suite covers:

- `l1_to_l0_mx` loading L0AMX and L0BMX
- identity scale (`127`)
- non-unit scale (`126`, `128`)
- split-K L0C accumulation
- split-N L0C column slices
- an end-to-end `OpExec(..., simulator=True)` shortcut run with external GM scale
- simulator smokes for the 12 shortcut combinations of no transpose, A-only
  transpose, B-only transpose, and both-side transpose crossed with no split,
  split-K, and split-N

Additional NZ2ZN validation:

- codegen coverage for `L0NZ2ZN_MX`
- CANNSIM smokes for `M=N=32,K=64` and `M=N=64,K=64`
- CANNSIM smokes for transpose+split-K and transpose+split-N with non-uniform
  scale bytes
- shortcut-level CANNSIM smokes for all 12 transpose/split combinations, each
  with max diff 0 against the PyTorch reference
