# Quick Start

This guide is for readers who want to run an existing kernel first and understand the rest of the framework second.

## 1. Environment

This repository is not currently packaged as an installable Python project.
Work directly from the checkout and put the repository root on `PYTHONPATH`.

If your machine already provides the `torch210npu` environment, activate it
first:

```bash
conda activate torch210npu
```

For a fresh simulator-only environment, install the repository dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

If you already use a CANN / `torch-npu` environment, keep its `torch` and
`torch-npu` versions aligned and install only the missing dependencies. CANN is
not installed by `requirements.txt`.

From the repository root, export the import path before running a nested
example:

```bash
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
```

Running `python agent/example/kernels/.../example.py` adds the script directory to Python's
import path, not the repository root, so merely changing into the repository is
not sufficient.

Minimum expectations from the current source tree:

- `torch` must be importable for `OpExec`
- `pytest` must be importable when running `agent/example/testcases/`
- the repository root must be the working directory and be present on
  `PYTHONPATH` when running examples

Choose one target facade for the entire Python process. Do not import
`easyasc.a2`, `easyasc.a3`, `easyasc.a5`, and `easyasc.a5pr` together; start a new process
when switching targets because facade imports select process-global device
state.

## 2. First successful run

Run the smallest matmul example:

```bash
python agent/example/kernels/a5/matmul/matmul_float_mmad.py
```

A successful run ends with output similar to:

```text
max_abs_diff=0.000000e+00
```

What this file does:

1. imports the public API from `easyasc.a5`
2. defines a `@kernel`
3. constructs sample PyTorch tensors
4. launches the kernel through `OpExec(..., simulator=True)`
5. compares the kernel output with `x @ y.t()`

If the run succeeds, you have verified that:

- the Python DSL can build the kernel
- the simulator can execute it
- output tensors can be read back into PyTorch

## 3. Minimal kernel anatomy

The shortest example in the repository is `agent/example/kernels/a5/matmul/matmul_float_mmad.py`:

```python
from easyasc.a5 import *


@kernel()
def matmul_float_mmad_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)
    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]
        matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
        z[:, :] <<= l0c
    return z
```

Read this as a dataflow description:

- `x` and `y` live in global memory
- `l1x` and `l1y` are on-chip L1 tensors
- `l0c` holds the float accumulation tile
- `<<=` emits the data-move or writeback instruction for the source and destination pair
- `with auto_sync():` lets the parser insert same-side handshakes for the `MTE2 -> MTE1`, `MTE1 -> M`, and `M -> FIX` pipe pairs that this body uses; see `04_mixed_pipeline_and_sync.md` for the full classification

## 4. `OpExec` in one minute

`OpExec` is the main execution entry point:

```python
z_kernel = OpExec(matmul_float_mmad_kernel, simulator=True)(x, y, z, M, N, K)
```

Important rules:

- the kernel signature must follow `input tensor-like* -> output tensor-like* -> Var*`; tensor-like parameters are `GMTensor` or `GMTensorList`, and mixing categories raises `Invalid kernel argument order for OpExec: ...` from `_validate_bound_kernel_signature`
- every kernel must include at least one `Var` parameter; otherwise `OpExec` raises `every @kernel must have at least one Var argument`
- the runtime call mirrors that order: pass input tensors/lists, then output tensor/list placeholders, then scalars
- scalar arguments are converted into `Var` objects internally
- when `simulator=True`, input tensors are cloned into simulator-visible `GMTensor.data`
- returned `GMTensor` outputs are converted back into PyTorch tensors, and returned `GMTensorList` outputs become Python lists of tensors

## 5. Simulator mode vs generation mode

Use simulator mode first:

```python
OpExec(kernel_fn, simulator=True)(...)
```

Use generation mode when you want emitted artifacts:

```python
OpExec(kernel_fn, out_dir="my_kernel", simulator=False, gen_only=True)(...)
```

High-level difference:

- simulator mode executes the kernel through the simulator runtime under `easyasc/simulator/`
- generation mode emits C++ and wrapper artifacts through the parser and template path

## 6. When you need `shape_bindings`

The runtime tries to infer which scalar `Var` belongs to each tensor dimension. This becomes ambiguous when multiple scalar arguments have the same integer value.

Example:

```python
out = OpExec(kernel_fn, simulator=True)(
    x,
    y,
    z,
    m,
    n,
    k,
    shape_bindings={
        0: [0, 2],
        1: [1, 2],
        2: [0, 1],
    },
)
```

Each key is the tensor argument index. Each list maps tensor dimensions to scalar argument indices or `None`.

If you see an error like:

```text
Ambiguous scalar match for tensor #... dim #...
```

add explicit `shape_bindings` before changing the kernel body.

## 7. What to read next

- [Programming Model](02_programming_model.md)
- [Write Your First Kernel](03_write_your_first_kernel.md)
- [Simulator and Trace](05_simulator_and_trace.md)
