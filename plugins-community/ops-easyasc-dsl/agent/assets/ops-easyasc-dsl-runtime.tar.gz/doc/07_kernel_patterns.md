# Kernel Patterns

The `agent/example/kernels/` directory is not just a sample folder. It is the repository's pattern library for legal DSL usage and stable implementation shapes.

## 1. How to use the kernel catalog

Use existing kernels to answer questions like:

- what is the shortest legal matmul baseline
- how should a cube -> vec handoff look
- how should tail writeback be handled
- how are fp8 casts currently modeled
- what does a multi-stage pipeline look like in this DSL

Do not copy a kernel body mechanically into a new kernel. Start from the target formula and borrow only the patterns that are justified by that formula.

## 2. Shortest correctness baselines

Study these first:

- `agent/example/kernels/a5/matmul/matmul_float_mmad.py`
  - shortest pure cube matmul path
- `agent/example/kernels/a5/matmul/matmul_e5m2_shortcut.py`
  - float8 input matmul with float output
- `agent/example/kernels/a5/matmul/matmul_kmkn_fp32_out.py`
  - native `KM @ KN -> MN` layout

## 3. Cube -> vec postprocess patterns

These are useful when the matmul result needs vector work before final writeback.

- `agent/example/kernels/a5/matmul/matmul_abs_add1_vf.py`
  - `abs(matmul) + 1`
- `agent/example/kernels/a5/matmul/matmul_rowwise_norm.py`
  - rowwise reduction plus broadcast divide
- `agent/example/kernels/a5/matmul/matmul_rowwise_norm_large_nk.py`
  - two-pass normalization for larger shapes

Use these when the output transform is naturally vec-side and does not need to be fused back into cube immediately.

## 4. Vec -> cube preprocess patterns

These fit formulas where an operand must be transformed before matmul:

- `agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul.py`
- `agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul_nz.py`
- `agent/example/kernels/a5/gdn_legacy/recompute_wu.py`

Common ideas:

- compute in UB
- cast or repack if needed
- publish to L1 with `ub_to_l1_nd2nz` or `ub_to_l1_nz`
- consume from cube-side matmul

## 5. Multi-stage mixed pipeline patterns

These show how to combine more than one handoff:

- `agent/example/kernels/a5/pipeline_patterns/vec_cube_vec_scale2_abs_add1_matmul.py`
  - vec preprocess -> cube -> vec postprocess
- `agent/example/kernels/a5/pipeline_patterns/cube_vec_atomic_add_two_outputs.py`
  - mixed pipeline with dual outputs and atomics

These are the right files to study when a new formula cannot be expressed as one pure stage.

## 6. Streaming and lookahead pattern

The most advanced documented examples are:

- `agent/example/kernels/a5/attention/test_mla_entire.py`
- `agent/example/kernels/a5/attention/mha_ifa_fp8_scale_256.py`

What it demonstrates:

- one-tile lookahead scheduling
- delayed consumer lifetime
- streamed `row_max` and `row_sum`
- vec and cube cooperation without round-tripping intermediate state to GM
- tail-safe fp8 decode attention with external `scale_q`, `scale_k`, and `scale_v`

Read this file only after you are comfortable with the smaller mixed kernels.

## 7. Pure vec and micro patterns

Useful files:

- `agent/example/kernels/a5/utility/chunk_row_cumsum.py`
- `agent/example/kernels/a5/utility/micro_cast_fp8_pack4_dual.py`

These kernels answer questions such as:

- how to write a pure vec kernel
- how to work with scalar extraction via `single()`
- how fp8 pack4 writeback works in micro code

## 8. Pattern selection guide

If your target kernel is:

- shortest pure matmul: start from `matmul_float_mmad.py`
- cube matmul plus vec epilogue: start from `matmul_abs_add1_vf.py`
- vec preprocessing before matmul: start from `vec_cube_abs_sqrt_matmul.py`
- two mixed stages: start from `vec_cube_vec_scale2_abs_add1_matmul.py`
- advanced streamed attention-like path: study `test_mla_entire.py`
- fp8 decode-style streamed attention with tail handling: study `mha_ifa_fp8_scale_256.py`

## 9. a2-specific patterns

The kernels above are a5-flavored mixed pipelines. The a2 (b3) device family adds a mandatory GM workspace between cube and vec, so its patterns form a distinct family with different sync, buffering, and tail rules. Read these when the target device is a2.

- `agent/example/kernels/a2/matmul/qk_matmul_batched.py`
  - simplest a2 cube-only baseline with batched `BH` flattening
- `agent/example/kernels/a2/vec_only/to_hif8_torch.py`
  - pure-vec hif8 emulation baseline
- `agent/example/kernels/a2/vec_only/sort_rows.py`
  - pure-vec row-wise sort built from `sort32` + `mergesort4` + `mergesort_2seq` + `gather` de-interleave
- `agent/example/kernels/a2/attention/flash_attn_score_pv.py`
  - a2 `cube -> vec -> cube` with the explicit GM bridge, plus running state across tiles
- `agent/example/kernels/a2/attention/flash_attn_full.py`
  - a2 `cube -> vec -> cube -> vec` normalized online softmax reference; current version uses `GROUP_N=4` grouped score/P/PV publication
- `agent/example/kernels/a2/attention/flash_attn_full_pj_hif8.py`, `flash_attn_full_pj_hif8_commonub.py`
  - scaled-hif8 probability path variants; the `_commonub` version moves vec scratch onto shared `DBuff` lineage for better `MTE2 -> V` `ubin` queueing
- `agent/example/kernels/a2/attention/flash_attn_full_pj_hif8_causal.py`, and the block32-causal family under `agent/example/kernels/a2/attention/block32_causal/` (base, `_v2` … `_v6`)
  - causal variants, including blockwise `32x32` diagonal-tile masking; the `block32_causal/` family runs from a naive relay (base) through v6's continuous cross-M-tile pipeline (the current production kernel). See `agent/example/kernels/a2/attention/block32_causal/README.md` for the full v1->v6 optimization path and designs.

For exact a2 pipeline topologies and device-side constraints, use the owner
references directly: `agent/references/patterns/a2-mixed-pipeline.md` for
pipeline schedules, `agent/references/constraints/a2.md` for bridge and UB
layout boundaries, `agent/references/constraints/vec.md` for vec reduction /
mask semantics, `agent/references/constraints/tail.md` for generic tail
legality, and `agent/references/patterns/online-softmax-tail.md` for the
online-softmax mask/update composition.

## 10. Supporting notes

Two repository files are specifically meant to complement the kernel catalog:

- `agent/references/examples/kernel-catalog.md`
- `doc/kernel_practice.md`

Use them alongside the source files when deriving new kernels.
