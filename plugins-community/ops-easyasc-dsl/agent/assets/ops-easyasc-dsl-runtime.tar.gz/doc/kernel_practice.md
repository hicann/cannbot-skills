# Kernel Practice

[中文版本](../doc_cn/kernel_practice.md)

These exercises build authoring skill without turning unfinished attempts into
repository examples. Work in `tmp/practice/<target>/`, use
`OpExec(..., simulator=True)`, and move a solution under `agent/example/kernels/` only after
it has a stable contract, representative tests, and documentation.

Import one target facade per Python process. Start a new process when changing
between A2, A3, A5, and A5PR.

## How to use the exercises

1. Write the exact PyTorch formula and error tolerance first.
2. Choose tiling and dataflow before filling in every compute stage.
3. Validate one stage at a time, including at least one tail shape.
4. Treat warnings as unresolved evidence rather than expected output.
5. Open the linked reference only after producing a working draft.

Before the golden tensors enter `OpExec`, restrict preprocessing to
shape-only `squeeze`, `unsqueeze`, or `reshape` operations unless the exercise
explicitly defines a host-side packing contract.

## Tier 1: vec-only fundamentals

| Exercise | Contract | Target | Main practice | Study after |
| --- | --- | --- | --- | --- |
| `elementwise_scale_bias` | `y = x * 2 + 1`, fp32 `[M,N]` | A5 family | GM→UB→`@vf`→GM, per-core tiles, tails | [A5 micro math](api/a5_micro_math.md) |
| `sigmoid` | `y = 1 / (1 + exp(-x))` | A5 family | register expression order and precision | [`mha_ifa.py`](../agent/example/kernels/a5/attention/mha_ifa.py) |
| `row_sum` | `y = x.sum(-1, keepdim=True)` | A2, then A5 family | reduction and scalar broadcast layouts | [A2 vec math](api/a2_vec_math.md), [A5 micro math](api/a5_micro_math.md) |
| `softmax_single_tile` | `softmax(x, dim=-1)` with one-row tile resident | A5 family, then A2 | stable max→sub→exp→sum→divide | [`mha_ifa.py`](../agent/example/kernels/a5/attention/mha_ifa.py) |

## Tier 2: cube baselines

| Exercise | Contract | Target | Main practice | Study after |
| --- | --- | --- | --- | --- |
| `matmul_basic` | `z = x @ y.t()`, aligned M/N/K | A5 family | shortest cube pipeline and simulator oracle | [`matmul_float_mmad.py`](../agent/example/kernels/a5/matmul/matmul_float_mmad.py) |
| `matmul_kmkn` | `x.T @ y`, `x:[K,M]`, `y:[K,N]` | A5 family | transpose-at-call-site and shape bindings | [`matmul_kmkn_fp32_out.py`](../agent/example/kernels/a5/matmul/matmul_kmkn_fp32_out.py) |
| `matmul_splitk_large_k` | `x @ y.t()` with large K | A5 family | outer tiling versus inner split-K accumulation | [`matmul_mknk_2dgrid_splitk.py`](../agent/example/kernels/a5/matmul/matmul_mknk_2dgrid_splitk.py) |

## Tier 3: cube-to-vec postprocess

| Exercise | Contract | Target | Main practice | Study after |
| --- | --- | --- | --- | --- |
| `matmul_bias_relu` | `relu(x.float() @ y.float().t() + bias)` | A5 family | `CvMutex`, bias broadcast, vec writeback | [`matmul_half_splitn_bias10p2_vf.py`](../agent/example/kernels/a5/matmul/matmul_half_splitn_bias10p2_vf.py) |
| `matmul_rowwise_softmax` | `softmax(x.float() @ y.float().t(), -1)` | A5 family | post-cube row reductions and tile lifetime | [`mha_ifa.py`](../agent/example/kernels/a5/attention/mha_ifa.py) |
| `matmul_l2_norm` | normalize matmul rows by `sqrt(sum(z**2))` | A5 family | two-pass statistics across N tiles | [`matmul_rowwise_l2_norm.py`](../agent/example/kernels/a5/matmul/matmul_rowwise_l2_norm.py) |
| `matmul_blockwise_quant` | block-128 absmax scale and fp8 output | A5 family | scale output, cast, and carrier layout | [`matmul_kmkn_blockwise_quant128.py`](../agent/example/kernels/a5/matmul/matmul_kmkn_blockwise_quant128.py) |

## Tier 4: vec-to-cube and fused pipelines

| Exercise | Contract | Target | Main practice | Study after |
| --- | --- | --- | --- | --- |
| `relu_then_matmul` | `relu(x).half().float() @ y.float().t()` | A5 family | `VcMutex`, dtype boundary, vec→cube publish | [`vec_cube_abs_sqrt_matmul.py`](../agent/example/kernels/a5/pipeline_patterns/vec_cube_abs_sqrt_matmul.py) |
| `fused_vec_cube_vec` | `abs((x*2).half().float() @ y.float().t()) + 1` | A5 family | both mutex directions and independent stage validation | [`vec_cube_vec_scale2_abs_add1_matmul.py`](../agent/example/kernels/a5/pipeline_patterns/vec_cube_vec_scale2_abs_add1_matmul.py) |
| `flash_attn_decode` | `softmax(q @ k.T / sqrt(D)) @ v`, `L=1,D=128` | A5 family | lookahead, running row state, warmup/drain | [`mha_ifa.py`](../agent/example/kernels/a5/attention/mha_ifa.py) |
| `flash_attn_decode_causal` | previous contract plus `k_pos <= q_pos` | A2 | GM bridges, causal score mask, three handoffs | [`flash_attn_full_pj_half_block32_causal.py`](../agent/example/kernels/a2/attention/block32_causal/flash_attn_full_pj_half_block32_causal.py) |

## Completion checklist

- The simulator result matches the untouched reference across aligned and tail
  shapes with a justified tolerance.
- Every cast, buffer, datamove, and synchronization edge has a contract reason.
- No unexplained parser or `auto_sync` warning remains.
- The script runs from the repository root with the documented environment.
- A promoted example contains its own reference computation and assertions.
