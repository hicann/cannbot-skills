# API Reference

The authoritative API navigation and target notes live in the
[Detailed API Reference](api/index.md).

This numbered page remains only as a stable compatibility link for existing
bookmarks. API signatures, restrictions, and examples are maintained in the
pages under `doc/api/`; do not duplicate them here.

Before choosing an API page, select exactly one facade for the Python process:
`easyasc.a2`, `easyasc.a3`, `easyasc.a5`, or `easyasc.a5pr`.
