# Code Generation and Runtime

This document explains what happens after a kernel has emitted instruction IR.

## 1. The execution split

The current framework supports two major execution paths through `OpExec`:

- simulator path
- generation path

Both paths start the same way:

1. bind `torch.Tensor` and scalar inputs
2. convert them into `GMTensor` and `Var` objects
3. execute the Python kernel body to emit instructions

After that, the paths diverge.

## 2. Simulator path

When `simulator=True`:

- `GMTensor.data` is populated from the input tensors
- the kernel runs through `KernelBase.run_sim()`
- the kernel first builds a `KernelProgram`, then executes it through `easyasc/simulator/`
- outputs are read back from `GMTensor.data`
- `OpExec` does not call `generate()` on this path, so simulator runs do not emit code artifacts even if `out_dir` or `gen_only=True` is provided

This path is the recommended default while authoring new kernels.

## 3. Generation path

When `simulator=False`, `OpExec` uses the generation flow:

- input binaries are written under `<base>_aclnn_test/input`
- parser lowering emits code artifacts
- optional build and run scripts are invoked
- output binaries are loaded back into PyTorch tensors unless `gen_only=True`
- if you only want to validate or inspect emitted code, use `simulator=False, gen_only=True`

The base directory is either:

- `out_dir`, if provided
- otherwise the kernel name

The actual runtime files land under one of two suffixes on top of that base:

- non-debug generation (default): `<base>_aclnn_test/`, with input binaries under `<base>_aclnn_test/input/`
- debug generation (`OpExec(..., debug=True)`): `<base>/debug_workspace/`
- `cannsim=True` works with both paths: the full-project flow wraps the smoke binary with `cannsim record`, while the debug flow switches its generated build/run scripts from `-r npu` to `-r sim`

## 4. What `KernelBase` contributes

`KernelBase` is the wrapper created by `@kernel`.

Its responsibilities include:

- storing emitted instructions
- tracking used micro modules
- collecting output `GMTensor` objects
- inserting cross-side ready/wait scaffolding for registered mutexes
- dumping generated cube and vec code

It also auto-inserts some framework-owned instructions before the user body begins.

For simulator work specifically, `KernelBase` also owns:

- automatic bridge selection via `build_simulator_program()`
- optional custom program/config hooks through `_simulator_program_builder` and `_simulator_config_builder`

## 5. How the parser lowers code

The parser pipeline does three high-level things:

1. split the instruction stream into cube-side and vec-side streams
2. insert autosync events for supported same-side pipe pairs
3. translate each side into generated code with op-specific handlers

Key modules:

- `easyasc/parser/asc.py`
- `easyasc/parser/asc_autosync.py`
- `easyasc/parser/asc_pruning.py`
- `easyasc/parser/asc_handlers/`

## 6. Generated artifacts

`KernelBase.dump_kernel()` writes:

- `<path>_cube.h`
- `<path>_vec.h`
- `<path>.cpp`

The generated C++ wrapper:

- includes tensor and helper headers
- includes generated micro headers when needed
- dispatches to cube and vec entry functions
- reads scalar tiling values from generated runtime data

## 7. Build and run script hooks

When generation mode is not `gen_only`, `OpExec` can run:

- `b.sh` for build
- `r.sh` for runtime execution

In the default non-debug generation path:

- `b.sh` builds and installs the generated custom op package
- `r.sh` runs `python setup_aclnn.py` and then launches the aclnn smoke binary
- if `OpExec(..., cannsim=True)` is used, `r.sh` runs `cannsim record ./test_aclnnop -s <chipset>` instead of `./test_aclnnop`

In the debug generation path:

- `b.sh` and `r.sh` call the generated `debug_workspace/build.sh` and `debug_workspace/run.sh`
- with `OpExec(..., debug=True, cannsim=True)`, those scripts use `-r sim -v <chipset>` instead of `-r npu -v <chipset>`

Their logs are written to files such as:

- `b.sh.log`
- `r.sh.log`

This is why generation mode assumes you are working from the repository root and already have the relevant local toolchain setup.

### Run-step serialization, idle check, and watchdog

Every non-simulator, non-`gen_only` `r.sh` launch currently goes through the
same protected runner, including an `r.sh` configured for CANNSIM:

1. acquire a cross-process advisory lock so EasyASC runs sharing a board do not
   overlap
2. require consecutive idle `npu-smi` samples before launch
3. start `r.sh` in its own process group with a bounded timeout
4. on timeout, terminate the whole process group and report the `r.sh.log` path

The idle check fails closed. It requires 0% AICore utilization and no process
owning the selected card; missing or ambiguous `npu-smi` data is an error. When
exactly one card is installed, its id is auto-detected. With zero or multiple
cards, set `EASYASC_NPU_CARD_ID` explicitly.

Environment variables:

| Variable | Default | Effect |
| --- | --- | --- |
| `EASYASC_NPU_CARD_ID` | auto-detect exactly one card | Non-negative card id used by the idle check. |
| `EASYASC_NPU_IDLE_SAMPLES` | `3` | Required number of consecutive idle samples; must be at least 1. |
| `EASYASC_NPU_IDLE_INTERVAL` | `1.0` | Seconds between idle samples; must be finite and non-negative. |
| `EASYASC_NPU_RUN_TIMEOUT` | `600` | Maximum `r.sh` runtime in seconds; must be finite and positive. |
| `EASYASC_NPU_LOCK` | file `easyasc_npu0.lock` in system `/tmp` | Advisory lockfile shared by processes using the same board. |
| `EASYASC_NPU_LOCK_ALLOW_DEGRADE` | `0` | Set to `1` to continue if the lockfile cannot be opened. This weakens serialization and should be a deliberate recovery choice. |
| `EASYASC_NPU_SAFETY_OVERRIDE` | `0` | Set to `1` to skip card detection and the board-idle check. It does not disable the lock or run timeout. |

The lock waits up to 1800 seconds for another EasyASC run to release it. On
Unix, failure to open the lockfile is an error unless
`EASYASC_NPU_LOCK_ALLOW_DEGRADE=1`; on a platform without `fcntl`, locking is
unavailable and the runner degrades without serialization.

Treat the two override variables as escape hatches, not normal setup. Prefer
selecting the correct card and lock path so concurrent or already-busy board
runs remain detectable.

## 8. `shape_bindings`

`shape_bindings` belongs to `OpExec.__call__`, not to the kernel itself.

Use it when:

- two or more scalar arguments share the same runtime integer value
- the runtime cannot infer which scalar belongs to which tensor dimension

If a binding is explicit, the runtime checks that the chosen scalar value really matches the tensor dimension and raises an error when it does not.

## 9. Useful `OpExec` options

- `out_dir`: output directory prefix
- `profile`: request profiling-oriented behavior in generation mode
- `gen_only`: emit artifacts but do not run the generated path
- `simulator`: use the simulator instead of generation mode
- `cannsim`: in generation mode, use CANNSIM instead of direct NPU execution; this applies to both the full-project and debug flows
- `skip_compile`: skip `b.sh` in generation mode
- `trace`: emit a simulator trace to a file; when `simulator=False`, the current
  runtime ignores this value and does not create a trace
- `debug`: route generation through `KernelBase.generate_debug(...)` and write runtime files under `<base>/debug_workspace/` instead of `<base>_aclnn_test/`

`gen_only` only affects generation mode. It does not force code emission when `simulator=True`.

## 10. Recommended order of use

For new kernel work:

1. `simulator=True`
2. `simulator=True, trace=...` if synchronization needs inspection
3. `simulator=False, gen_only=True`
4. full generation and runtime flow

That progression aligns with the implementation and minimizes the number of moving parts you debug at once.
