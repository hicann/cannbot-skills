# Stub to Codegen Name Map

This file is a quick lookup when you have a public helper name from
`easyasc.a2`, `easyasc.a3`, `easyasc.a5`, or `easyasc.a5pr` and want to find the emitted C++
helper, macro, or inline form in generated code.

Read this after [Code Generation and Runtime](06_codegen_and_runtime.md) if you need the full lowering flow.
This file does not explain semantics, legality, or simulator behavior.

Coverage of top-level stub exports is checked against
`agent/scripts/data/public_docs_manifest.json` by `agent/scripts/check_public_docs.py`. Keep
semantic explanations here, but do not silently omit a facade export.

## Scope

- "A2/A3" means the shared `easyasc.a2` / `easyasc.a3` surface and the C220
  codegen path selected by `is_c220_family(device_type)` (`b*` or `a3`).
- "A5" means the `easyasc.a5` / `easyasc.a5pr` surfaces and the A5-family (`device_type in ("950", "950pr")`) codegen path.
- Generated names below come from `easyasc/parser/asc_handlers/`.
- Tables below describe names exported from the `easyasc.a2` and A5-family
  top-level modules, not every helper file that happens to exist under
  `easyasc/stub_functions/`.
- Some helpers generate a view declaration or inline expression instead of a single runtime helper call.
- `sim_print` and `sim_dump_tensor` are simulator-only; they do not emit generated C++ statements.
- The A5-family surface imports `stub_functions.micro` after `stub_functions`,
  so several top-level names are intentionally shadowed by A5 micro helpers.

## One Important Difference First

The same top-level name does not always mean the same helper family on A2 and
the A5 family.

```python
from easyasc.a2 import add   # vec Tensor helper
from easyasc.a5 import add   # micro Reg helper
```

That means the generated names below should be read against the public import surface, not just the raw file name under `easyasc/stub_functions/`.

## Same Top-Level Name, Different Lowering Family

These names exist on `easyasc.a2` and both A5-family facades, but they lower
through different handler families.

| Top-level name(s) | `easyasc.a2` source | A2 generated symbol(s) | `easyasc.a5` source | A5 generated symbol(s) | Notes |
| --- | --- | --- | --- | --- | --- |
| `add`, `sub`, `mul`, `div`, `vmax`, `vmin`, `vand`, `vor` | `stub_functions.vec.binary` | `Add`, `Sub`, `Mul`, `Div`, `Max`, `Min`, `And`, `Or` | `stub_functions.micro.binary` | `MicroAPI::Add`, `MicroAPI::Sub`, `MicroAPI::Mul`, `MicroAPI::Div`, `MicroAPI::Max`, `MicroAPI::Min`, `MicroAPI::And`, `MicroAPI::Or` | A2 row is a vec Tensor op. A5 row is a micro Reg op. |
| `exp`, `ln`, `abs`, `relu`, `sqrt`, `vnot` | `stub_functions.vec.unary` | `Exp`, `Ln`, `Abs`, `Relu`, `Sqrt`, `Not` | `stub_functions.micro.unary` | `MicroAPI::Exp`, `MicroAPI::Ln`, `MicroAPI::Abs`, `MicroAPI::Relu`, `MicroAPI::Sqrt`, `MicroAPI::Not` | Same public names, different execution layer. |
| `adds`, `muls`, `shiftls`, `shiftrs`, `vmaxs`, `vmins`, `lrelu`, `axpy` | `stub_functions.vec.unaryscalar` | `Adds`, `Muls`, `ShiftLeft`, `ShiftRight`, `Maxs`, `Mins`, `LeakyRelu`, `Axpy` | `stub_functions.micro.unaryscalar` | `MicroAPI::Adds`, `MicroAPI::Muls`, `MicroAPI::ShiftLefts`, `MicroAPI::ShiftRights`, `MicroAPI::Maxs`, `MicroAPI::Mins`, `MicroAPI::LeakyRelu`, `MicroAPI::Axpy` | A2 shift ops work on integer UB tensors; A5 scalar ops work on Reg + MaskReg. |
| `cast` | `stub_functions.vec.cast` | `Cast<dst, src, false>(..., RoundMode::...)` | `stub_functions.micro.cast` | `MicroAPI::Cast<dst, src, config>(...)` | A5 micro cast takes a `CastConfig` template argument. |
| `compare`, `select` | `stub_functions.vec.compare`, `stub_functions.vec.select` | `Compare`, `CompareScalar`, `Select` | `stub_functions.micro.compare` | `MicroAPI::Compare`, `MicroAPI::CompareScalar`, `MicroAPI::Select` | `easyasc.a5.select` comes from the micro compare module, not vec select. |
| `dup` | `stub_functions.vec.dupbrcb` | `Duplicate` | `stub_functions.micro.dup` | `MicroAPI::Duplicate` | Same name, different operand kinds. |
| `cadd`, `cgadd`, `cpadd`, `cmax`, `cgmax`, `cmin`, `cgmin` | `stub_functions.vec.group` | `WholeReduceSum`, `BlockReduceSum`, `PairReduceSum`, `WholeReduceMax`, `BlockReduceMax`, `WholeReduceMin`, `BlockReduceMin` | `stub_functions.micro.group` | `MicroAPI::ReduceSum`, `MicroAPI::ReduceSumWithDataBlock`, `MicroAPI::PairReduceSum`, `MicroAPI::ReduceMax`, `MicroAPI::ReduceMaxWithDataBlock`, `MicroAPI::ReduceMin`, `MicroAPI::ReduceMinWithDataBlock` | The public names match, but the reduction layer does not. |
| `gather` | `stub_functions.vec.gatherscatter` | `Gather` | `stub_functions.micro.datamove` | `MicroAPI::Gather` | A2 gather uses vec Tensor + offset. A5 gather uses Reg + index Reg. |
| `muladddst` | `stub_functions.vec.binary` | `MulAddDst` | `stub_functions.micro.fused` | `MicroAPI::MulAddDst` | A2 is a vec Tensor op; A5 is a micro Reg in-out accumulator (`dst = src0 * src1 + dst`) with ZEROING mask. |
| `gather_block` | `stub_functions.vec.gatherscatter` | `Gatherb` | — | — | A2-only block gather: one offset -> one 32B block, 8 blocks/repeat. No top-level A5 equivalent. |

## Shared Top-Level Names

These helpers keep the same top-level meaning across A2 and the A5 family.

### Scalar and Shape Helpers

| Helper | A2 generated form | A5 generated form | Notes |
| --- | --- | --- | --- |
| `GetCubeNum` | `GetBlockNum()` | `GetBlockNum()` | Scalar helper. |
| `GetCubeIdx` | `get_block_idx()` | `get_block_idx()` | Scalar helper. |
| `GetVecNum` | `GetBlockNum() * 2` | `GetBlockNum() * 2` | Current lowering assumes two vec sub-blocks per cube block. |
| `GetVecIdx` | `GetBlockIdx()` | `GetBlockIdx()` | Scalar helper. |
| `GetSubBlockIdx` | `get_subblockid()` | `get_subblockid()` | Scalar helper. |
| `CeilDiv` | `CeilDiv(...)` | `CeilDiv(...)` | Direct helper call. |
| `Min`, `Max` | `Min(...)`, `Max(...)` | `Min(...)`, `Max(...)` | Direct helper call. |
| `Align8`, `Align16`, `Align32`, `Align64`, `Align128`, `Align256` | `Align8B`, `Align16B`, `Align32B`, `Align64B`, `Align128B`, `Align256B` | same | The stub names map to byte-alignment helpers with `B` suffixes. |
| `scalar_sqrt` | `sqrt(...)` | `sqrt(...)` | Inline scalar expression. |
| `scalar_abs` | `abs(...)` | `abs(...)` | Inline scalar expression; float values are rejected inside `@vf`. |
| `var_mul`, `var_add`, `var_sub`, `var_div`, `var_mod` | inline `*`, `+`, `-`, `/`, `%` expressions | same | Lowered as scalar expressions, not helper calls. |

### Cube and On-Chip Data Movement

| Helper | A2 generated symbol(s) | A5 generated symbol(s) | Notes |
| --- | --- | --- | --- |
| `gm_to_l1_nd2nz` | `GM2L1_ND2ZZ` for float `L1` destinations, otherwise `GM2L1_ND2NZ` | `GM2L1_ND2NZ` | The main family-specific cube datamove name difference. |
| `gm_to_l1_dn2nz` | not exported by `easyasc.a2` | `GM2L1_DN2NZ` | A5 transposed GM->L1 load (`Dn2NzParams`); GM holds the matrix transposed. |
| `gm_to_l1_pad` | not exported by `easyasc.a2` | `GM2L1PAD` | A5 normal-mode GM to L1 padded copy. |
| `gm_to_l1` | `GM2L1` | `GM2L1` | Plain 32B-granular contiguous GM-to-L1 copy. |
| `gm_to_l1_mx_scale` | not exported by `easyasc.a2` | `GM2L1PAD` | A5 MX scale helper; copies packed `[num_blocks, 32]` e8m0 scale blocks from GM to L1. |
| `gm_to_l1_mx_scale_nd2nz` | not exported by `easyasc.a2` | `GM2L1_MX_SCALE_DN2NZ` | A5 dense MX scale helper; reinterprets adjacent e8m0 bytes as `half` and uses `Dn2NzParams` to materialize the compact L1 MX scale stream from GM `[rows, ceil(K / 32)]`. |
| `set_constant_to_l1` | `InitConstValue` | `InitConstValue` | Constant-fill helper. |
| `l1_to_l0a_img2col` | `L12L0A_IMG2COL` | `L12L0A_IMG2COL` | Low-level Conv2D/load3d staging helper; target-specific validation still applies. |
| `l1_to_l0` | float `L1`: `L0ZZ2ZZ`, `L0ZZ2NN`, `L0ZZ2NZ`, `L0ZZ2ZN`<br>non-float `L1`: `L0NZ2ZZ`, `L0NZ2NN`, `L0NZ2NZ`, `L0NZ2ZN` | `L0NZ2NZ` or `L0NZ2ZN` | On A2, dtype and transpose both affect the emitted name. On A5, the handler always uses the NZ-source family. |
| `l1_to_bt` | `L1_TO_BT` | `L1_TO_BT` | Copies a contiguous fp32/int32 bias row from L1 into BT. |
| `l1_to_l0_mx` | not exported by `easyasc.a2` | `L0NZ2NZ_MX` or `L0NZ2ZN_MX` | A5 MX FP8 / MXFP4 L1 to L0 transfer plus scale load into L0AMX/L0BMX. `L0NZ2ZN_MX` is used for `src.T` into L0A or L0B, with scale pre-packed in post-transpose row order. |
| `mmad` | `MMAD` | `MMAD` | Shared cube compute helper. |
| `mmad_mx` | not exported by `easyasc.a2` | `MMAD_MX` | A5 MX FP8 / MXFP4 matmul helper. |
| `l0c_to_gm_nz2nd` | `L0C2GM_NZ2ND` | `L0C2GM_NZ2ND` | Shared writeback helper. |
| `l0c_to_gm_nz2nz` | `L0C2GM_NZ2NZ` | `L0C2GM_NZ2NZ` | Shared fractal writeback helper. |
| `l0c_to_gm_nz2dn` | not exported by `easyasc.a2` | `L0C2GM_NZ2DN` | A5-family transposed (NZ2DN) writeback; sugar `gm <<= l0c.T`. |
| `l0c_to_l1` | `L0C2L1` | `L0C2L1` | Shared on-chip handoff helper. |
| `l0c_to_ub` | not exported by `easyasc.a2` | `L0C2UB_NZ2ND` | Available from `easyasc.a5` / `easyasc.a5pr` only. |

### Shared Vec and UB Helpers

| Helper | A2 generated symbol(s) | A5 generated symbol(s) | Notes |
| --- | --- | --- | --- |
| `gm_to_ub_pad`, `ub_to_gm_pad`, `ub_to_ub` | `GM2UBPAD`, `UB2GMPAD`, `UB2UB` | same | Shared vec datamove helpers. |
| `gm_to_ub_nd_dma` | not exported by `easyasc.a2` | `GM2UB_ND_DMA` | A5-family multi-dimensional GM->UB DMA. `ub <<= gm.T` lowers to its transpose helper. |
| `ub_to_l1` | not exported by `easyasc.a2` | `UB2L1` | A5 raw UB to L1 copy; `burst_len` and both strides are measured in 32B blocks. |

## Vec Helpers and A2-Only Names

The first rows are A2-only. Sort and vec-mask helpers are shared by A2 and the
A5 family and remain here because they use the vec lowering family.

| Helper(s) | A2 generated symbol(s) | Notes |
| --- | --- | --- |
| `rec`, `rsqrt` | `Reciprocal`, `Rsqrt` | Vec unary helpers that are not re-exported from `easyasc.a5`. |
| `brcb` | `Brcb` | Vec broadcast helper available only from the A2 top-level surface. |
| `scatter` | `Scatter` | A5 exports micro `reg_to_ub_scatter`, not top-level vec `scatter`. |
| `compare_scalar` | `CompareScalar` | Kept as a separate top-level helper on A2. |
| `transdata5hd` | `TRANSDATA5HD` | A2-only UB `vnchwconv`/5HD transpose helper. |
| `sort32`, `mergesort4`, `mergesort_2seq` | `Sort32`, `MERGESORT4`, `MERGESORT2SEQ` | Sort helpers are exported from `easyasc.a2` and both A5-family facades. |
| `set_mask`, `set_mask_by_count`, `set_mask_normal`, `reset_mask` | `SetVectorMask<half, MaskMode::NORMAL>`, `SetVectorMaskByCount`, `ResetMask` | Vec-PipeS mask helpers, exported from `easyasc.a2` and both A5-family facades. On the A5 family they set the vector-mask SPR read back inside a `@vf` by `move_mask_spr` (`MoveMask<T>()`). |
| `SetCmpMask` | `SetCmpMask` | Internal codegen emission from `select()` lowering — not a user-exported stub. |

### Synchronization, Atomic, and Misc Helpers

| Helper | A2 generated form | A5 generated form | Notes |
| --- | --- | --- | --- |
| `bar_m`, `bar_v`, `bar_mte3`, `bar_mte2`, `bar_mte1`, `bar_fix`, `bar_all` | `PipeBarrier<PIPE_M/V/MTE3/MTE2/MTE1/FIX/ALL>()` | same | The public wrappers all lower through one `barrier` instruction. |
| `cube_ready`, `vec_ready`, `wait_cube`, `wait_vec`, `allcube_ready`, `allvec_ready`, `allcube_wait`, `allvec_wait` | `CUBE_READY`, `VEC_READY`, `WAIT_CUBE`, `WAIT_VEC`, `ALLCUBE_READY`, `ALLVEC_READY`, `ALLCUBE_WAIT`, `ALLVEC_WAIT` | same | Cross-core flag helpers. |
| `intracore_allvec_ready`, `intracore_allvec_wait` | `INTRACORE_ALLVEC_READY`, `INTRACORE_ALLVEC_WAIT` | same | Per-core two-vec-lane phase barrier helpers. |
| `setflag`, `waitflag` | `set_flag`, `wait_flag` | same | Pipe event instructions, not `SEvent`/`DEvent` objects. |
| `atomic_add`, `atomic_max`, `atomic_min` | `SetAtomicAdd<float>()`, `SetAtomicMax<float>()`, `SetAtomicMin<float>()` | same | The context-manager exit emits `SetAtomicNone()`. |
| `reset_cache` | `pipe_ptr->Reset();` and `OccupyMMTE1Events();` | same | Parser lowering emits the raw helper calls; kernel header emission comments out only the auto-inserted prologue pair in generated `_cube.h` / `_vec.h`, while user-written `reset_cache` calls remain raw. |
| `clean_dcache` | `DataCacheCleanAndInvalid<...>` | same | Emits a templated cache-line helper. |
| `set_hf32` | `SetHF32Mode(true/false);` | same | Enables or disables a special hardware fp32 format that can speed up fp32 matmul with a small precision tradeoff; ignored by the simulator. |
| `split_workspace` | `shiftAddr<dtype>(workspace, ...)` plus `SetGlobalBuffer(...)` | same | Generates a GM workspace view, not a single helper call. |
| `reinterpret` | `ReinterpretCast<dst_dtype>()` | same | Generates a local tensor view. |
| `kernel_print` | `printf(...)` | same | Generation-time debug print. |
| `kernel_dump_tensor` | `DumpTensor(...)` | same | Generation-time dump hook. |
| `inline` | literal inline C++ | same | No wrapper helper; the source is emitted directly. |
| `sim_print`, `sim_dump_tensor` | no generated code | no generated code | Simulator-only helpers exported by both public facades. |

## A5-Family Top-Level Helpers

These names exist only on the A5-family top-level surfaces (`easyasc.a5` and
`easyasc.a5pr`).

### Micro Register and Mask Families

| A5-family-only helper(s) | A5 generated symbol(s) | Notes |
| --- | --- | --- |
| `arange` | `MicroAPI::Arange` | A5-family-only micro helper. |
| `abssub`, `expsub`, `muldstadd`, `mulscast` | `MicroAPI::AbsSub`, `MicroAPI::ExpSub`, `MicroAPI::MulDstAdd`, `MicroAPI::MulsCast` | A5-family-only fused micro helpers from `stub_functions.micro.fused`; `muladddst` is listed in the same-name table because A2 already has a vec helper with that public name. |
| `vxor`, `prelu` | `MicroAPI::Xor`, `MicroAPI::Prelu` | Extra micro binary helpers not exposed from `easyasc.a2`. |
| `log`, `log2`, `log10`, `neg`, `vcopy` | `MicroAPI::Log`, `MicroAPI::Log2`, `MicroAPI::Log10`, `MicroAPI::Neg`, `MicroAPI::Copy` | Extra micro unary helpers. |
| `shiftls`, `shiftrs` | `MicroAPI::ShiftLefts`, `MicroAPI::ShiftRights` | A5-family-only micro scalar helpers. |
| `shiftl`, `shiftr` | `MicroAPI::ShiftLeft`, `MicroAPI::ShiftRight` | A5-family-only reg-reg per-lane variable shift (the shift amount is a RegTensor), distinct from the scalar `shiftls`/`shiftrs` above; integer dtypes only, `dst`/`src`/`shift` widths must match. |
| `deinterleave`, `interleave` | `MicroAPI::DeInterleave`, `MicroAPI::Interleave` | Register-lane rearrangement helpers. |
| `pack`, `HighLowPart` | `MicroAPI::Pack<..., MicroAPI::HighLowPart::...>` | `pack` combines selected high/low register parts; `HighLowPart` is its configuration enum and emits no standalone instruction. |
| `histograms`, `HistBin`, `HistMode` | `MicroAPI::Histograms<..., MicroAPI::HistogramsBinType::BIN_n, MicroAPI::HistogramsType::...>` | Byte histogram of a `uint8` source (256 lanes) into a `uint16` destination (128 counters); the destination is **read-modify-write**, so looping the instruction accumulates. `HistBin.BIN0..BIN7` selects which 128-wide byte window the counters cover and `HistMode` picks `FREQUENCY` (`dhistv2`, bytes equal to a bin) or `ACCUMULATE` (`chistv2`, bytes `<=` a bin **over the whole byte range**, so `BIN0`+`BIN1` concatenate into one 256-entry inclusive prefix count). Both enums are configuration only and emit no standalone instruction. |
| `ub_to_l1`, `ub_to_l1_nd2nz`, `ub_to_l1_nz` | `UB2L1`, `UB2L1_ND2NZ`, `UB2L1_NZ` | Vec-to-L1 publish helpers exported only from `easyasc.a5` / `easyasc.a5pr`; raw `ub_to_l1` uses 32B block units. |
| `ub_to_reg`, `reg_to_ub` | `MicroAPI::DataCopy<..., MicroAPI::DataCopyMode::DATA_BLOCK_COPY>` | The base A5 micro datacopy pair. |
| `ub_to_reg_continuous`, `reg_to_ub_continuous` | `MicroAPI::LoadAlign<..., MicroAPI::LoadDist::...>` / `MicroAPI::StoreAlign<..., MicroAPI::StoreDist::...>` | Distribution mode selects the exact emitted specialization. |
| `ub_to_reg_interleave` | `MicroAPI::LoadAlign<..., MicroAPI::LoadDist::DIST_DINTLV_B8/B16/B32>` | Dual-load UB-to-two-register interleave helper. |
| `reg_to_ub_interleave` | `MicroAPI::StoreAlign<..., MicroAPI::StoreDist::DIST_INTLV_B8/B16/B32>` | Dual-store two-register-to-UB interleave helper, the exact inverse of `ub_to_reg_interleave`: writes `2 * VL` elements (512 bytes) in one issue with `dst[2k] = src0[k]`, `dst[2k+1] = src1[k]`. |
| `reg_to_ub_downsample`, `reg_to_ub_pack4`, `reg_to_ub_single`, `reg_to_ub_normal`, `ub_to_reg_normal`, `ub_to_reg_single`, `ub_to_reg_upsample`, `ub_to_reg_downsample`, `ub_to_reg_unpack`, `ub_to_reg_unpack4`, `ub_to_reg_brcb` | same `MicroAPI::LoadAlign` / `MicroAPI::StoreAlign` family as above | These are convenience wrappers that pick `LoadDist` / `StoreDist` modes before the same codegen handler runs. |
| `ub_to_reg_gather`, `reg_to_ub_scatter`, `gather_mask` | `MicroAPI::DataCopyGather`, `MicroAPI::DataCopyScatter`, `MicroAPI::GatherMask` | A5-family-only micro datamove helpers. |
| `ub_to_reg_gatherb` | `MicroAPI::GatherB` | A5-family-only 32B-datablock gather: out-block `i` <- the 32B UB block at byte offset `index[i]` (uint32 index read from index-reg lane `i`, 32B-aligned); b8/b16/b32 (b64 broken on-board, rejected by the stub). |
| `unsqueeze` | `MicroAPI::Unsqueeze` | A5-family-only in-place EXCLUSIVE prefix-sum (PrefixSumImpl) of the mask bits: `dst[i]` = number of active mask lanes strictly before lane `i`; input `dst` is ignored. NOT the inverse of `squeeze`. |
| `squeeze` | `MicroAPI::Squeeze` | Compacts active lanes; `store=True` selects the store-register specialization. |
| `clear_spr` | `MicroAPI::ClearSpr<AscendC::SpecialPurposeReg::AR>()` | Clears the address special-purpose register used by the micro path. |
| `print_reg` | no generated device code | Simulator-only register debug helper. |
| `ub_to_mask`, `mask_to_ub` | `MicroAPI::LoadAlign(MaskReg&, ...)` / `MicroAPI::StoreAlign(..., MaskReg&)` | A5-family-only MaskReg<->UB move (MaskReg overloads, no dist template): the FULL 32-byte (256-bit) vector-mask register; element-lane `i` sits at physical bit `i*elem_size` (byte-granular, board-verified). |
| `vf_barrier` | `MicroAPI::LocalMemBar<MicroAPI::MemType::..., MicroAPI::MemType::...>()` | A5-family-only VF local-memory ordering helper inside `@vf`; `VfPipe.STORE` maps to `VEC_STORE`, `VfPipe.LOAD` maps to `VEC_LOAD`. |
| `mask_not`, `mask_and`, `mask_or`, `mask_xor`, `mask_mov`, `mask_interleave`, `mask_deinterleave`, `mask_sel` | `MicroAPI::MaskNot`, `MaskAnd`, `MaskOr`, `MaskXor`, `MaskMov`, `MaskInterleave`, `MaskDeInterleave`, `MaskSel` | Mask-register operations. |
| `move_mask_spr`, `update_mask` | `MicroAPI::MoveMask`, `MicroAPI::UpdateMask` | Return values are assigned into `MaskReg` objects. `move_mask_spr` reads the vector-mask SPR set by `set_mask`/`set_mask_by_count`/`SetVectorMask` on the vec PipeS (enabled on the A5 family); the map is lane-granular (MaskReg lane `i` <- SPR lane `i`), not the byte-granular `i*elem_size` layout of `mask_to_ub`. |
| `mask_pack`, `mask_unpack` | `MicroAPI::MaskPack<...>`, `MicroAPI::MaskUnPack<...>` | Mode is encoded as a template argument. |
| `LoadDist`, `LoadDistValue`, `StoreDist`, `StoreDistValue` | no emitted code by themselves | These are configuration enums used by the A5 micro datamove wrappers. |

### Vec Advanced-API Helpers

| A5-family-only helper(s) | A5 generated symbol(s) | Notes |
| --- | --- | --- |
| `topk_radix` | `AscendC::TopK<..., AscendC::TopKMode::TOPK_NORMAL, {AscendC::TopKAlgo::RADIX_SELECT, ...}>` | A5-family-only UB radix-select TopK advanced API from `stub_functions/vec/sort.py`, not a micro helper. Selects `k` of `n` for each of `outter` rows padded to `aligned_n`. `sorted` and `init_index` are compile-time configurations because they select the template instance; `largest` is a runtime argument. The Ascend950 API rejects `aligned_n > 4096`. |

## Source Paths for Verification

Use these files when you want to confirm or extend the table:

- public surfaces: `easyasc/a2.py`, `easyasc/a3.py`, `easyasc/a5.py`, `easyasc/a5pr.py`
- handler registry: `easyasc/parser/asc_handlers/__init__.py`
- scalar helpers: `easyasc/parser/asc_handlers/math_ops.py`
- cube helpers: `easyasc/parser/asc_handlers/cube.py`
- vec helpers: `easyasc/parser/asc_handlers/vec_binary.py`, `vec_unary.py`, `vec_unary_scalar.py`, `vec_group.py`, `vec_dupbrcb.py`, `vec_gatherscatter.py`, `vec_datamove.py`, `vec_cast.py`, `vec_compare.py`, `vec_select.py`, `vec_sort.py`, `vec_mask.py`
- sync and misc: `easyasc/parser/asc_handlers/pipe_ops.py`, `atomic.py`, `misc.py`, `core.py`, `reinterpret.py`
- A5 micro helpers: `easyasc/parser/asc_handlers/vec_micro_ops.py`
