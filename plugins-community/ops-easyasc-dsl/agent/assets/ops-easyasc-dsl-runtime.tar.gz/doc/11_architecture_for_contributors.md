# Architecture for Contributors

This document is for contributors who need to change the framework itself, not only author kernels on top of it.

## 1. Repository structure

The main repository areas are:

- `easyasc/`
  - public DSL surface
  - parser and lowering
  - simulator runtime
  - instruction emitters and helpers
- `agent/example/kernels/`
  - curated kernel examples and runnable validation stories
- `agent/example/testcases/`
  - automated pytest coverage organized first by assertion type, then by feature
- `agent/scripts/`
  - standalone repository utilities and maintenance scripts
- `doc/`
  - English project and API documentation
- `doc_cn/`
  - Chinese mirror of the documentation set
- `agent/`
  - router-first guidance, catalogs, and implementation maps for repository work
- `agent/example/projects/`
  - multi-file system projects that wire several kernels into one algorithm (e.g. `agent/example/projects/a5/gdn_fwd/` and `agent/example/projects/a5/gdn_bwd/`)

High-level owner files:

- `README.md`, `README_CN.md`
  - top-level project and documentation entry points
- `AGENTS.md`
  - repository-local working rules for agent-style contributors
- `agent/ROUTER.md`
  - router-first entry point: sends you to the smallest useful playbook or reference instead of loading every map up front
- `agent/references/authoring-preflight.md`
  - compact mandatory kernel-authoring guardrails, loaded only by authoring workflows
- `agent/references/repo-map.md`
  - quick top-level layout and ownership map
- `agent/references/code-paths.md`
  - fast implementation-path lookup
- `agent/example/testcases/README.md`
  - test-suite layout and ownership map

## 2. Device family mapping

Before interpreting any hardware-specific branch, keep this mapping straight:

- `device_type in ("950", "950pr")` corresponds to the C310 path
- `is_c220_family(device_type)` (`b*` or `a3`) corresponds to the C220 path
- in `easyasc/resources/tensorutils.h`, `__DAV_C310__` is the 950-family branch
- in `easyasc/resources/tensorutils.h`, `__DAV_C220_CUBE__` is the `b*` branch

Several support checks, helper choices, and generated code paths depend on this mapping.
Do not invert it when reading the repository.

The agent documentation loading contract is deliberately narrow:

1. start at `agent/ROUTER.md` and select exactly one route
2. read `agent/common-language.md` in full
3. open the selected workflow playbook
4. for authoring, read `agent/references/authoring-preflight.md` and the one
   focused device fact or pattern selected by that workflow
5. inspect source only when the smaller evidence layers are insufficient

Repository-maintenance work, including changes to framework internals, tests,
tools, catalogs, and documentation, is owned by
`agent/playbooks/repository-maintenance.md`.

## 3. End-to-end control flow

The typical internal path is:

1. a decorated Python function is transformed by `easyasc/pythonic.py`
2. `@kernel` wraps it in `KernelBase`
3. DSL objects emit `Instruction` records into the active kernel or micro context
4. `OpExec` binds runtime inputs and triggers either simulator or generation flow
5. the parser/lowering path or the simulator bridge path consumes those instructions
6. the simulator runtime or generated runtime executes the result
7. `shape_bindings` is used when repeated scalar values make shape inference ambiguous

Key entry modules:

- `easyasc/decorators.py`
- `easyasc/kernelbase/kernelbase.py`
- `easyasc/torchplugin.py`

## 4. Public surface modules

- `easyasc/a2.py`
- `easyasc/a3.py`
- `easyasc/a5.py`
- `easyasc/a5pr.py`
- `easyasc/flowcontrol.py`
- `easyasc/utils/Tensor.py`
- `easyasc/utils/var.py`

When changing the public API, start here and determine whether the behavior
belongs to the A2/A3 C220 surface, the A5 family (`a5` + `a5pr`), or both. Do not import more than
one facade in the same process: facade imports mutate shared device state.

## 5. Parser and lowering

The parser stack lives under `easyasc/parser/`.

Important roles:

- `asc.py`
  - instruction splitting
  - side classification
  - autosync insertion
  - translation dispatch
- `asc_pruning.py`
  - cleanup and pruning passes
- `asc_buffer_view_liveness.py`
  - conservative final-side expression-inlining decisions for runtime-indexed local-buffer views
- `asc_autosync.py`
  - event insertion for supported same-side pipe pairs
- `asc_handlers/`
  - per-op lowering handlers

If you add a new instruction family, expect five implementation touch points,
followed by focused tests and public documentation. For a vec primitive, missing
the last two can route the op to `PipeS` ("unhandled instruction") or let its
consumer read uninitialized UB:

1. the stub emitter (`easyasc/stub_functions/...`) plus the re-exports up to the
   `a2` / `a3` / `a5` / `a5pr` facade
2. handler registration or dispatch (`asc_handlers/<area>.py` + the dispatch dict in
   `asc_handlers/__init__.py`)
3. simulator execution (a `_<op>` method + its dispatch in the matching `pipe_*.py`)
4. **the simulator pipe routing table** in `easyasc/simulator/bridge.py`
   (`_VEC_PIPE_BY_OP` / `_CUBE_PIPE_BY_OP`) -- required, not optional
5. **autosync classification** in `easyasc/parser/asc_autosync.py` -- required for any
   op that reads or writes UB

See `agent/references/code-paths.md` ("Adding a vec primitive") for the concrete
checklist, with `gather` / `gather_block` as the worked example.

## 6. Stub emitters

The authoring API mostly emits instructions through stubs under:

- `easyasc/stub_functions/`
- `easyasc/stub_functions/vec/`
- `easyasc/stub_functions/micro/`

These modules define the legal DSL authoring surface that kernels actually call.
They are the first place to inspect when a DSL statement does not behave the way you expected.

## 7. Simulator internals

The simulator lives under `easyasc/simulator/` as a flat module set.

The highest-value files are:

- bridge selection and simulator entry
  - `easyasc/kernelbase/kernelbase.py`
- runtime entry and configuration
  - `easyasc/simulator/__init__.py` (exports `SimulatorConfig`, `Simulator`, `build_kernel_program`, `build_simulator`)
  - `easyasc/simulator/config.py`
  - `easyasc/simulator/simulator.py`
- program bridge
  - `easyasc/simulator/bridge.py`
  - `easyasc/simulator/program.py`
- per-core runtime
  - `easyasc/simulator/core.py`
  - `easyasc/simulator/pipe.py`
  - `easyasc/simulator/pipe_cube.py`
  - `easyasc/simulator/pipe_vec.py`
  - `easyasc/simulator/pipe_micro.py`
  - `easyasc/simulator/pipe_simt.py`
- memory and workspace handling
  - `easyasc/simulator/memory.py`
  - `easyasc/simulator/physical_alias.py`
- synchronization
  - `easyasc/simulator/sync.py`
- timing model
  - `easyasc/simulator/timing/`
- trace export
  - `easyasc/simulator/trace.py`

Important current fact:

- `KernelBase.run_sim()` routes to the simulator runtime under `easyasc/simulator/`
- `simulator` is a strict `bool`: `True` enables the simulator, `False` takes the generation path; legacy string spellings are no longer accepted

## 8. Bridge model

The simulator does not execute the raw instruction list directly.
It first builds a `KernelProgram`.

Selection order in `KernelBase.build_simulator_program()`:

1. explicit custom program builder (`_simulator_program_builder`)
2. prebuilt `KernelProgram` stored as `_simulator_program`
3. automatic bridge via `easyasc/simulator/bridge.py` (`build_kernel_program`)

The bridge walks the emitted instruction stream, lowers pipe operations into
`ControlInstruction` objects grouped by lane and pipe, and registers tensor
specs so the runtime can allocate shared memory up front.

This bridge layer is often the first place to inspect when the simulator
behaves differently from a kernel author's expectation.

## 9. Runtime shape

The simulator runtime uses:

- one top-level `Simulator` coordinator (`easyasc/simulator/simulator.py`)
- one child `Core` process per simulated core (`easyasc/simulator/core.py`)
- one control pipe (`PipeS`) per active lane inside that core
- threaded pipe workers (`PipeBase` subclasses) per logical pipe in that lane

Shared tensor storage is handled by `easyasc/simulator/memory.py`
(`SharedMemoryStore`, `SharedTensorSpec`).

Cross-core and intra-core synchronization primitives live in
`easyasc/simulator/sync.py`.

## 10. Micro modules

`@vf` functions are wrapped by `easyasc/micro/micromodule.py`.

Important details:

- micro functions are cached as reusable modules
- temporary register declarations are hoisted into micro scope
- read and write sync keys are collected from the emitted micro instructions
- kernel calls to a micro emit `call_micro` instructions
- micro execution at runtime goes through `easyasc/simulator/pipe_micro.py`
- float `Var` expressions that flow through `call_micro` must keep float semantics
  in both the control pipe and the micro pipe; runtime-side int coercion will silently
  corrupt scalar scales used inside `@vf()`

Any change to micro dataflow should be checked against both parser lowering and simulator runtime behavior.

## 11. Testing and demos

- `agent/example/testcases/` is for automated regression coverage
  - `codegen/` for static generation, tool, and non-runtime checks
  - `parser/` for split, pruning, autosync, and lowering-adjacent checks
  - `simulator/` for runtime semantics, roundtrips, bridge behavior, and runtime invariants
  - synchronization paths such as autosync, barriers, atomics, and coordination helpers
  - bridge behavior, trace export, and shared-memory/runtime plumbing
- `agent/example/kernels/` may carry runnable end-to-end self-check assertions for full kernel stories
  - avoid duplicating those stories under `agent/example/testcases/` unless a smaller reusable regression is being extracted
- `agent/example/projects/` is for multi-file system projects that wire several kernels into one algorithm (e.g. `agent/example/projects/a5/gdn_fwd/` and `agent/example/projects/a5/gdn_bwd/`)

If a root-level executable script becomes important, either convert it into a pytest test under `agent/example/testcases/`, or move it under `agent/example/kernels/` (single-file sample) or `agent/example/projects/<device>/<name>/` (multi-file system project).

## 12. Synchronization model

The current repository has two synchronization layers:

1. autosync
   - same-side pipeline handshakes inserted during lowering
2. explicit cross-side mutexes and wait/ready paths
   - used when ownership crosses between cube and vec

These changes are high-risk because they affect:

- parser lowering
- bridge behavior
- simulator scheduling
- trace output
- many existing tests

Keep changes small and validate them with focused tests.

## 13. Generated resources

The generation path still depends on template and helper files under:

- `easyasc/resources/`

If you change emitted code shape, check whether host/runtime templates or helper headers also need to change.

## 14. High-level maps and summaries

Use the smallest owner file that answers the question:

- router-first navigation across playbooks and references -> `agent/ROUTER.md`
- top-level layout or ownership -> `agent/references/repo-map.md`
- generic implementation-path lookup -> `agent/references/code-paths.md`
- kernel examples and kernel-specific notes -> `agent/references/examples/kernel-catalog.md`
- test-suite structure -> `agent/example/testcases/README.md`

After changing routed documentation or a catalog, run:

```bash
python agent/scripts/check_kernel_catalog.py --fail-on-warning
python agent/scripts/build_agent_index.py --check
python agent/scripts/check_agent_docs.py
python agent/scripts/check_public_docs.py --fail-on-warning
```

## 15. Contribution checklist

When changing framework internals:

1. identify the authoring API impact
2. update lowering, bridge logic, and simulator runtime consistently
3. add or update a focused test
4. refresh the owner docs that actually describe the changed area
5. if a new kernel is added under `agent/example/kernels/`, update the kernel summaries too

This repository is easiest to maintain when parser, simulator, tests, documentation, and examples evolve together.
