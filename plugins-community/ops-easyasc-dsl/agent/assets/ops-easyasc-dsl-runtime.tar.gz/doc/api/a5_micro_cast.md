# A5 Micro Cast

This page documents the micro-side cast helpers exported by the A5-family
facades, `easyasc.a5` and `easyasc.a5pr`.

The behavior described here is based on:

- the public authoring surface in `easyasc/stub_functions/micro/cast.py`
- the `Reg` convenience methods in `easyasc/utils/reg.py`
- the current simulator implementation in `easyasc/simulator/pipe_micro.py`
- the current micro tests under `agent/example/testcases/simulator/micro/`

The `cast()` operation and `Reg` cast expressions on this page:

- require an active `@vf` context
- operate on `Reg` and `MaskReg`
- use `MaskMergeMode.ZEROING` by default; an explicit
  `MaskMergeMode.MERGING` config preserves destination lanes that the cast does
  not write

The enum-like configuration values can be inspected outside `@vf`.
`CastConfig` auto-registration and cast instruction emission happen only in an
active micro context.

## 1. Cast Building Blocks

### `RoundModeType`

- Purpose: represent one concrete micro cast rounding mode value.
- Typical use:
  - you normally do not construct it directly
  - instead, pass predefined values from `RoundMode.*`

The class is small, but it matters because `CastConfig` validates that `round_mode` is a `RoundModeType`.

Important behaviors:

- `str(mode)` returns the backend token name such as `CAST_RINT`
- `repr(mode)` returns `RoundModeType('...')`
- equality compares by mode name
- comparing against a non-`RoundModeType` raises `TypeError`

Examples:

```python
str(RoundMode.TO_EVEN)        # "CAST_RINT"
repr(RoundMode.FLOOR)         # "RoundModeType('CAST_FLOOR')"
RoundMode.CEIL == RoundMode.CEIL
```

Practical rule:

- use the predefined `RoundMode.*` members
- do not pass raw strings such as `"CAST_RINT"` into `CastConfig`

### `RoundMode`

- Purpose: enum-like namespace for the predefined micro cast rounding modes.
- Value type:
  - every member is a `RoundModeType`

Available members:

| Public name | Backend token | Intended meaning |
| --- | --- | --- |
| `RoundMode.NONE` | `CAST_NONE` | no explicit rounding policy |
| `RoundMode.TO_EVEN` | `CAST_RINT` | round to nearest, ties to even |
| `RoundMode.AWAY_FROM_ZERO` | `CAST_ROUND` | round to nearest, ties away from zero |
| `RoundMode.FLOOR` | `CAST_FLOOR` | round toward negative infinity |
| `RoundMode.CEIL` | `CAST_CEIL` | round toward positive infinity |
| `RoundMode.TRUNC` | `CAST_TRUNC` | round toward zero by truncation |
| `RoundMode.ODD` | `CAST_ODD` | Von Neumann / round-to-odd, currently for `float -> half` |
| `RoundMode.HYBRID` | `CAST_HYBRID` | HiFloat8 hybrid TA/SSR conversion, only for `float/half -> hif8` |

What "intended meaning" means here:

- these are the semantic modes the backend C++ trait is told to use
- they matter most when the cast can discard precision or fractional information
- common examples are `float -> float`, `float -> half`, `float -> bfloat16`,
  `half -> int8`, `int16_t -> half`, and large `int32_t`/`int64_t -> float`

When round mode usually has little or no observable effect:

- exact-value widening casts where the source value is already representable
  in the destination, such as `half -> float`

Current simulator behavior:

- the simulator preserves the selected `RoundMode` object in `CastConfig`
- floating-point to integer casts branch on `TO_EVEN`, `FLOOR`, `CEIL`, `AWAY_FROM_ZERO`, `TRUNC`, and `NONE`
- `float -> float` applies the selected rounding mode to the numeric value and stores the integer-valued result as `float`
- `float -> half` and `float -> bfloat16` use representable-value rounding; `float -> half` also supports `ODD`
- `float/half -> hif8` uses the host-side hif8 codec in the simulator; these encode casts support only `CAST_ROUND` and `CAST_HYBRID`
- `hif8 -> float/half` accepts any round mode value, but the simulator ignores it because this is a low-precision to higher-precision decode
- `int16_t -> half`, `int32_t -> float`, and `int64_t -> float` use representable-value rounding when the integer is not exactly representable in the destination floating-point format
- `config.saturate=True` clamps before converting; `False` still follows `torch.Tensor.to(dtype)` after rounding

Current codegen behavior:

- the selected mode is emitted into the generated trait as `RoundMode::{token}`
- for example, `RoundMode.TO_EVEN` becomes `RoundMode::CAST_RINT`

Example:

```python
cfg_floor = CastConfig(
    round_mode=RoundMode.FLOOR,
    reg_layout=RegLayout.ZERO,
    name="cfg_floor",
)
```

Another example:

```python
cfg_trunc = CastConfig(
    round_mode=RoundMode.TRUNC,
    reg_layout=RegLayout.ZERO,
    name="cfg_trunc",
)
```

### `MaskMergeMode`

- Purpose: control what happens to destination lanes outside the cast's active
  write set.
- Available values:
  - `MaskMergeMode.ZEROING` — initialize the destination to zero, then write the
    active converted lanes. This is the default.
  - `MaskMergeMode.MERGING` — preserve the destination's prior value in
    masked-off lanes and in width-conversion slots not selected by
    `RegLayout`.
- Hardware restrictions:
  - `MERGING` is supported only with `RegLayout.ZERO` on the A5-family board;
    the public stub rejects `ONE`, `TWO`, or `THREE` before code generation.
  - bfloat16 <-> FP4 casts support `ZEROING` only.
- Practical requirement: initialize `dst` before a `MERGING` cast. Its previous
  contents are part of the operation's input contract.

`MaskMergeMode` values are emitted as the third field of
`MicroAPI::CastTrait`. Pass the predefined members rather than constructing a
raw value.

### `CastConfig(round_mode=RoundMode.TO_EVEN, reg_layout=RegLayout.ZERO, saturate=False, name="", merge_mode=MaskMergeMode.ZEROING)`

- Purpose: Stores the policy that a micro cast should use.
- Constructor parameters:
  - `round_mode`: the requested `RoundMode`
  - `reg_layout`: which logical slot to read from or write to when source and destination element widths differ
  - `saturate`: whether overflow handling should clamp instead of using the default dtype-conversion behavior
  - `name`: the symbolic name emitted into generated C++
  - `merge_mode`: whether lanes outside the active write set are zeroed or
    retain the previous `dst` value

What each parameter means:

- `round_mode`:
  - must be a `RoundModeType`
  - selects which `RoundMode.*` policy is attached to the generated cast trait
  - carried into code generation as part of the `MicroAPI::CastTrait`
  - current simulator note:
    - floating-point to integer casts, `float -> float`, `float -> half`/`float -> bfloat16`, and integer-to-floating precision-reduction casts such as `int16_t -> half` and `int32_t`/`int64_t -> float` model the listed round modes
    - saturation behavior still follows the `saturate` flag
- `reg_layout`:
  - only matters when `src.dtype.size != dst.dtype.size`
  - chooses which slot inside each cast ratio group is used
- `saturate`:
  - when `False`, the simulator does not pre-clamp values; precision-changing pairs listed above still use the implemented `round_mode` path
  - when `True`, the simulator clamps values before converting
- `name`:
  - must be non-empty by the time `cast()` emits the instruction
  - if you construct `CastConfig` inside an active micro, the object is registered into that micro and its name is prefixed automatically
- `merge_mode`:
  - must be a predefined `MaskMergeMode` value
  - defaults to `ZEROING`
  - `MERGING` requires `RegLayout.ZERO` and is unavailable for bfloat16 <-> FP4

Auto-registration behavior:

- When `CastConfig` is created inside an active `@vf`, it is appended to the micro module's `cast_cfg_list`.
- During code generation, that list becomes `MicroAPI::CastTrait` definitions in the generated C++.
- This is why config names need to be stable and unique.

Example:

```python
cfg_zero = CastConfig(
    round_mode=RoundMode.TO_EVEN,
    reg_layout=RegLayout.ZERO,
    saturate=False,
    name="cfg_zero",
    merge_mode=MaskMergeMode.ZEROING,
)
```

Default-config behavior:

- `cast(..., config=None)` asks the current micro module for a default config.
- In the current implementation, most destinations use a default `RoundMode.TO_EVEN` config.
- `Datatype.hif8` is the current special case that defaults to `RoundMode.AWAY_FROM_ZERO`.
- bfloat16 <-> FP4 uses dedicated defaults: encode uses `RoundMode.TO_EVEN`,
  decode uses `RoundMode.NONE`, and both use `RegLayout.ZERO` plus
  `MaskMergeMode.ZEROING`.
- `float -> hif8` and `half -> hif8` support only `RoundMode.AWAY_FROM_ZERO` / `CAST_ROUND` and `RoundMode.HYBRID` / `CAST_HYBRID`; codegen emits `RoundMode::CAST_HYBRID` for the hybrid case.
- `hif8 -> float` and `hif8 -> half` accept any round mode value. The simulator ignores the mode on these decode paths.

Why `Datatype.hif8` is mentioned here:

- the micro module maintains two cached default configs
- the general default is `RoundMode.TO_EVEN`
- the `hif8` default is a separate cached config created with `RoundMode.AWAY_FROM_ZERO`
- this affects what `cast(..., config=None)` means for those destinations

### `RegLayout`

- Purpose: Describes which slot inside a width-conversion group is active.
- Available values:
  - `RegLayout.ZERO`
  - `RegLayout.ONE`
  - `RegLayout.TWO`
  - `RegLayout.THREE`

Why `RegLayout` exists:

- Micro registers always have a fixed byte budget.
- When source and destination element sizes differ, one source lane does not map to exactly one destination lane.
- The cast therefore works with ratio-sized groups.
- `RegLayout` chooses which slot in each group is read or written.
- FP4 is a packed compute-view dtype without an addressable byte size. Its
  bfloat16 <-> FP4 path uses a separate four-slot carrier mapping described
  below.

Current legal slot rules:

| Cast ratio | Meaning | Legal layouts |
| --- | --- | --- |
| `1` | same-width cast | all layouts are currently accepted, but the layout is ignored |
| `2` | 16-bit <-> 32-bit or 8-bit <-> 16-bit | `ZERO`, `ONE` |
| `4` | 8-bit <-> 32-bit | `ZERO`, `ONE`, `TWO`, `THREE` |
| packed FP4 carrier | bfloat16 <-> FP4 | `ZERO`, `ONE`, `TWO`, `THREE`; `ZEROING` only |

If the layout slot is out of range for the active width ratio, the simulator raises an error.
`MaskMergeMode.MERGING` further restricts all non-FP4 casts to
`RegLayout.ZERO`, even where the zeroing form accepts additional slots.

Example:

```python
cfg_one = CastConfig(reg_layout=RegLayout.ONE, name="cfg_one")
```

## 2. Core API

### `cast(dst, src, config=None, mask=None)`

- Purpose: Cast one register into another register.
- Parameters:
  - `dst`: destination `Reg`
  - `src`: source `Reg`
  - `config`: optional `CastConfig`
  - `mask`: optional `MaskReg`

General behavior:

- The source register is snapshotted first, so aliasing like `cast(reg, reg, cfg, mask)` behaves predictably.
- With `MaskMergeMode.ZEROING`, `dst` is zero-initialized before active lanes
  are written.
- With `MaskMergeMode.MERGING`, the previous `dst` value is snapshotted and
  lanes outside the active write set are retained.
- The execution mask normally follows destination lanes. For bfloat16 <-> FP4,
  it follows the wider bfloat16 lane geometry.

Current public stub-supported pairs:

- are validated against the A5 table in `easyasc/stub_functions/cast_rules.py`
- exclude all `int4b_t`/`DT.int4` pairs on the A5 family
- reject unlisted pairs before code generation

| Source dtype | Supported destination dtypes |
| --- | --- |
| `DT.half` | `DT.float`, `DT.int`, `DT.int16`, `DT.int8`, `DT.uint8`, `DT.hif8`, `DT.bfloat16` |
| `DT.float` | `DT.float`, `DT.half`, `DT.int`, `DT.int64`, `DT.int16`, `DT.bfloat16`, `DT.e4m3`, `DT.e5m2`, `DT.hif8` |
| `DT.bfloat16` | `DT.float`, `DT.int`, `DT.half`, `DT.fp4_e2m1`, `DT.fp4_e1m2` |
| `DT.uint8` | `DT.half` |
| `DT.int8` | `DT.half` |
| `DT.int16` | `DT.half`, `DT.float` |
| `DT.int` | `DT.float`, `DT.int16`, `DT.int64` |
| `DT.int64` | `DT.int`, `DT.float` |
| `DT.e4m3`, `DT.e5m2` | `DT.float` |
| `DT.hif8` | `DT.float`, `DT.half` |
| `DT.fp4_e2m1`, `DT.fp4_e1m2` | `DT.bfloat16` |

The round-mode set is pair-specific. In particular, fp8 encode accepts
`NONE`/`TO_EVEN`; hif8 encode accepts `AWAY_FROM_ZERO`/`HYBRID`; FP4 encode
uses the integer rounding modes; and the corresponding widening decode pairs
use `NONE`. The public stub validates the special hif8 and FP4 modes before
code generation; use the pair table in `cast_rules.py` when constructing an
explicit config for another pair.

For `float -> fp8`, the cast is a wide-to-narrow ratio-4 operation. Use
`RegLayout.ZERO` and write with `pack4()` when storing the compact fp8 stream
back to UB. For `fp8 -> float`, the source fp8 values decode into float lanes
and do not need `pack4()`.

For true hif8 carriers, `float -> hif8` is also ratio-4 and should use
`pack4()` for compact `uint8` carrier writeback. `half -> hif8` is ratio-2
and should use `downsample()` instead. Decode mirrors that layout:
`hif8 -> float` loads compact carriers with `unpack4()`, while `hif8 -> half`
loads compact carriers with `unpack()`.

For bfloat16 <-> FP4, each carrier byte stores two logical FP4 values. Encode
places carrier bytes in every fourth physical byte of the FP4 register;
`RegLayout.ZERO/ONE/TWO/THREE` selects that byte slot. Decode reads the same
slot back into contiguous bfloat16 lanes. The mask is bfloat16-lane based and
the unselected output is always zero because FP4 rejects `MERGING`.

Current simulator caveats:

- `round_mode` is simulated for floating-point to integer casts, `float -> float`, `float -> half`/`float -> bfloat16`, and integer-to-floating precision-reduction casts such as `int16_t -> half` and `int32_t`/`int64_t -> float`; it is also emitted to codegen.
- `float -> e4m3/e5m2` uses the fp8 destination conversion directly, and `e4m3/e5m2 -> float` decodes the source fp8 values without applying a second `float -> float` rounding pass.
- `float/half -> hif8` and `hif8 -> float/half` use the hif8 carrier codec. Hif8 encode supports only `CAST_ROUND` and `CAST_HYBRID`; hif8 decode accepts but ignores the round mode. The half hybrid path is CANNSIM-checked over all 65536 half bit patterns; its SSR threshold comes from the source half mantissa LSB.
- The simulator runtime may have lower-level dtype paths that are not public `micro.cast` stub pairs.

### 2.1 Same-Width Casts

This is the case where:

- `src.dtype.size == dst.dtype.size`

Addressing rule:

- for each active lane `i`:
  - `dst[i] = cast(src[i])`

Notes:

- `reg_layout` does not change the address mapping in this case
- all `RegLayout` values are currently accepted for same-width casts because no slot lookup is needed
- masked-off lanes are zero with `ZEROING` and retain their prior `dst` value
  with `MERGING` (`MERGING` still requires `RegLayout.ZERO`)

Example:

```text
src  = [a0, a1, a2, a3, a4, a5, ...]
mask = active at lanes [0..7]
dst  = [cast(a0), cast(a1), ..., cast(a7), 0, 0, ...]
```

For example, `int16 -> half` is a supported same-width pair. A config using
`RegLayout.THREE` still converts active lanes 1:1 because no slot lookup is
needed; under the default zeroing mode the remaining lanes become zero.

### 2.2 Narrow-to-Wide Casts

This is the case where:

- `src.dtype.size < dst.dtype.size`

Let:

- `ratio = dst.dtype.size / src.dtype.size`
- `slot = reg_layout`

Addressing rule:

- for each active destination lane `i`:
  - `src_index = i * ratio + slot`
  - `dst[i] = cast(src[src_index])`

Interpretation:

- every wide destination lane picks one element from a ratio-sized group in the source register
- `RegLayout.ZERO` picks the first element of each group
- `RegLayout.ONE` picks the second element, and so on

#### C310 restriction for plain `Cast` widening

The ratio table and addressing rules describe the CANN header contract and the
ideal slot semantics retained by the simulator. Exact Ascend950 hardware
evidence overrides that contract for four plain `MicroAPI::Cast` combinations:

| Source | Destination | Broken layout on `950` / `950pr` |
| --- | --- | --- |
| `DT.int8` | `DT.half` | `RegLayout.ONE` |
| `DT.half` | `DT.float` | `RegLayout.ONE` |
| `DT.bfloat16` | `DT.float` | `RegLayout.ONE` |
| `DT.float` | `DT.int64` | `RegLayout.ONE` |

For those combinations, the generated C++ can compile even though the ONE
part is all zero on C310. The public A5 stub therefore rejects exactly those
plain-cast configurations before code generation. It does not reject ZERO,
same-width casts, wide-to-narrow casts, native BF16 <-> FP4 P0-P3 layouts,
other unverified widening pairs, or the separate `ExpSub` / `MulsCast` fused
APIs. The simulator intentionally keeps the ideal API slot model; it does not
pretend that zero is the intended mathematical result.

Use one of these ZERO-only constructions instead.

##### Contiguous 8/16-bit source to two wider registers

Interleave a contiguous source with a zero register. Both resulting registers
place their live values in the ZERO slot, so two ZERO casts recover the lower
and upper contiguous halves without a ONE cast:

```python
src_native = Reg(DT.half)
zero_native = Reg(DT.half)
lower_even = Reg(DT.half)
upper_even = Reg(DT.half)
lower_wide = Reg(DT.float)
upper_wide = Reg(DT.float)
cfg_zero = CastConfig(
    round_mode=RoundMode.NONE,
    reg_layout=RegLayout.ZERO,
    name="half_to_float_zero_only",
)

zero_native <<= 0
interleave(lower_even, upper_even, src_native, zero_native)
cast(lower_wide, lower_even, cfg_zero)
cast(upper_wide, upper_even, cfg_zero)
```

The same register construction applies to `int8 -> half` and
`bfloat16 -> float`; use the pair's valid round mode and matching tail masks.
This is the path used by the A5 SwiGlu widening bridge.

##### Full-width 32-bit source to int64

For `float -> int64`, use one trait-two destination, a matching trait-two mask,
and one ZERO cast. This preserves all 64 source lanes in one operation:

```python
src32 = Reg(DT.float)
dst64 = Reg(DT.int64, reg_num=2)
active64 = MaskReg(DT.int64, reg_num=2)
cfg_zero = CastConfig(
    round_mode=RoundMode.TO_EVEN,
    reg_layout=RegLayout.ZERO,
    name="float_to_int64_trait2",
)
cast(dst64, src32, cfg_zero, mask=active64)
```

The same trait-two bridge is the full-width form for `int32 -> int64`.

C310 has one important full-width exception to the single-register layout
rule. To convert all 64 lanes of one `Reg(DT.int)` into int64, declare the
destination and mask with `reg_num=2`. The generated C++ then uses
`RegTensor<int64_t, RegTraitNumTwo>`, and the cast preserves all 64 logical
source lanes 1:1. A default `Reg(DT.int64)` has only 32 lanes and therefore
represents only one ZERO/ONE layout half.

```python
src32 = Reg(DT.int)
dst64 = Reg(DT.int64, reg_num=2)
active64 = MaskReg(DT.int64, reg_num=2)
cfg = CastConfig(
    round_mode=RoundMode.NONE,
    reg_layout=RegLayout.ZERO,
    name="int32_to_int64_trait2",
)
cast(dst64, src32, cfg, mask=active64)
```

The data register and mask trait must match. This is also the register form
required by C310 b64 `Interleave`/`DeInterleave`; using the default trait-one
b64 registers is rejected before code generation.

Example: `half -> float` (`ratio = 2`)

```text
src = [h0, h1, h2, h3, h4, h5, ...]

RegLayout.ZERO:
dst = [float(h0), float(h2), float(h4), ...]

RegLayout.ONE:
dst = [float(h1), float(h3), float(h5), ...]
```

Example: `e4m3 -> float` (`ratio = 4`)

```text
src group 0 = [f8_0, f8_1, f8_2, f8_3]
src group 1 = [f8_4, f8_5, f8_6, f8_7]

RegLayout.ZERO -> [float(f8_0), float(f8_4), ...]
RegLayout.ONE  -> [float(f8_1), float(f8_5), ...]
RegLayout.TWO  -> [float(f8_2), float(f8_6), ...]
RegLayout.THREE-> [float(f8_3), float(f8_7), ...]
```

### 2.3 Wide-to-Narrow Casts

This is the case where:

- `src.dtype.size > dst.dtype.size`

Let:

- `ratio = src.dtype.size / dst.dtype.size`
- `slot = reg_layout`

Addressing rule:

- the source lane index is `src_index = dst_index // ratio`
- only destination lanes whose `dst_index % ratio == slot` are written
- all other destination lanes are zeroed by `ZEROING` or retained by
  `MERGING`

Interpretation:

- one wide source lane fans out over a ratio-sized destination group
- `RegLayout` selects which slot in that destination group receives the converted value

Example: `float -> half` (`ratio = 2`)

```text
src = [f0, f1, f2, f3, ...]

RegLayout.ZERO:
dst = [half(f0), 0, half(f1), 0, half(f2), 0, ...]

RegLayout.ONE:
dst = [0, half(f0), 0, half(f1), 0, half(f2), ...]
```

Example: `float -> e4m3` (`ratio = 4`)

```text
RegLayout.ZERO:
dst[0], dst[4], dst[8], ... = cast(src[0]), cast(src[1]), cast(src[2]), ...
all other lanes remain 0
```

This is exactly why a `float -> fp8` cast is commonly followed by `pack4()`:
the cast populates only one slot out of every 4 lanes, and `pack4()` compacts those lanes for UB storage.

### 2.4 Saturation Behavior

When `config.saturate == False`:

- supported precision-changing casts still use the implemented `round_mode` path
- overflow, NaN, and behavior outside those explicit paths follow the final `torch.Tensor.to(dst_dtype)` conversion

When `config.saturate == True`:

- for floating-point destinations:
  - finite values are clamped to the dtype's finite range
  - `inf`, `-inf`, and `nan` are left to the final float cast behavior
- for integer destinations:
  - finite values are clamped to the integer range
  - `+inf` becomes the integer max
  - `-inf` becomes the integer min
  - `nan` becomes `0`

Example: saturating `half -> int8` (converted values before ratio-2 slot
placement)

```text
src = [-300.0, -129.0, -128.0, 127.0, 128.0, inf, -inf, nan]

after saturation:
[-128, -128, -128, 127, 127, 127, -128, 0]
```

### 2.5 Mask Behavior

For `cast()`:

- the mask is normally resolved on destination lanes; bfloat16 <-> FP4 uses
  bfloat16 lane geometry
- there is no `C0` expansion
- unselected destination lanes become zero with `ZEROING` and retain the prior
  `dst` value with `MERGING`

Example:

```text
mask = VL8
dst[0:8]   = converted values
dst[8:...] = 0                       # ZEROING
dst[8:...] = previous dst[8:...]     # MERGING
```

### 2.6 Direct Examples

Float to half, two layouts:

```python
src_reg = Reg(DT.float)
dst_zero = Reg(DT.half)
dst_one = Reg(DT.half)
mask = MaskReg(DT.half)

cfg_zero = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")
cfg_one = CastConfig(reg_layout=RegLayout.ONE, name="cfg_one")

cast(dst_zero, src_reg, cfg_zero, mask)
cast(dst_one, src_reg, cfg_one, mask)
```

Half to float:

```python
src_reg = Reg(DT.half)
dst_reg = Reg(DT.float)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")
cast(dst_reg, src_reg, cfg)
```

Float to fp8 with packed UB writeback:

```python
src_reg = Reg(DT.float)
dst_fp8 = Reg(DT.e5m2)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

cast(dst_fp8, src_reg, cfg)
dst_ub <<= dst_fp8.pack4()
```

Restrictions:

- `dst` and `src` must both be `Reg`
- `config` must be a `CastConfig` after default resolution
- `mask` must be a `MaskReg`
- the chosen `RegLayout` must be valid for the width ratio
- `MaskMergeMode.MERGING` requires `RegLayout.ZERO`
- bfloat16 <-> FP4 requires `MaskMergeMode.ZEROING`
- the dtype pair must appear in the table above

## 3. `Reg` Convenience Methods

### `Reg.cast(cfg=None)`

- Purpose: Build a cast `RegOP` using the same logical dtype as the source register.
- Common use:
  - apply a cast config explicitly while keeping the register dtype unchanged
  - build a cast node that will be emitted later by assignment

Important detail:

- `Reg.cast()` does not specify a new output dtype
- the resulting `RegOP` therefore keeps the source dtype
- if you want a concrete new dtype, prefer `Reg.astype(...)`

Example:

```python
src = Reg(DT.half)
dst = Reg(DT.half)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg")
dst <<= src.cast(cfg)
```

### `Reg.astype(dtype, cfg=None)`

- Purpose: Build a cast `RegOP` with an explicit output dtype.
- Parameters:
  - `dtype`: target `DT.*` value
  - `cfg`: optional `CastConfig`

This is the most useful convenience form when writing micro code because it captures both:

- the target dtype
- the cast policy

Example:

```python
r_h = Reg(DT.half)
r_f = Reg(DT.float)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

r_f <<= r_h.astype(DT.float, cfg)
```

### `Reg.pack4()`

- Purpose: Build a `RegOP` that stores the register with `StoreDist.PACK4`.
- Why it appears in cast code:
  - after a wide-to-narrow cast with ratio `4`, only one lane out of every 4 contains a real value
  - `pack4()` compacts lanes `0, 4, 8, ...` into a contiguous UB output stream

Typical fp8 workflow:

1. cast `float -> e5m2` or `float -> e4m3` with `RegLayout.ZERO`
2. the cast writes converted values into register lanes `0, 4, 8, ...`
3. `pack4()` compacts those lanes when writing to UB

Example:

```python
src = Reg(DT.float)
dst = Reg(DT.e5m2)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

cast(dst, src, cfg)
packed_ub <<= dst.pack4()
```

For the exact `PACK4` store semantics, see [a5_micro_data_movement.md](a5_micro_data_movement.md).

## 4. Common Mental Model

When debugging a cast, use this checklist:

1. compare `src.dtype.size` and `dst.dtype.size`
2. compute the width ratio
3. check whether the chosen `RegLayout` is legal for that ratio
4. decide whether the cast is:
   - selecting one lane from each source group (`narrow -> wide`)
   - or filling one slot in each destination group (`wide -> narrow`)
5. check `merge_mode`: masked-off and unfilled destination lanes become zero
   with `ZEROING`, but retain the previous destination value with `MERGING`
6. if overflow matters, check whether `saturate=True` is required
7. if simulator rounding matters, check whether the source/destination pair is one of the explicitly modeled round-mode paths
