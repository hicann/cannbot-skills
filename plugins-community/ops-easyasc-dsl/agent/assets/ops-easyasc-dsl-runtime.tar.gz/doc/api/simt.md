# SIMT Modules

This page documents the SIMT authoring surface exported only from the A5-family
facades (`easyasc.a5` and `easyasc.a5pr`):

- `@simt(num_threads=1024)` — the decorator that builds a `SimtModule`
  (see [decorators.md §5](decorators.md))
- `SimtModule` — the runtime object the decorator returns
- `cvt(value, dtype)` — the only dtype cast intrinsic allowed inside a SIMT body
- `simt_fma(multiplicand0, multiplicand1, addend)` — fused fp32 multiply-add
- `simt_thread_id()`, `simt_thread_num()`, `simt_block_idx()`, `simt_block_num()` —
  nullary intrinsics that map to backend `Simt::*` helpers
- `simt_atomic_add()`, `simt_atomic_sub()`, `simt_atomic_max()`,
  `simt_atomic_min()`, and `simt_atomic_cas()` — statement-only atomic updates
  to GM or UB tensor formals

A SIMT module is **not** a `@kernel`, **not** a `@vf`, and **not** a `@func`. It
is a separate code-generation path with its own AST lowering. Bodies that work
inside `@kernel` will not necessarily work inside `@simt`, and vice versa.

## 1. When to use SIMT

SIMT is an exception path on the A5 family, not the default performance path. Prefer cube
`matmul` for dense contractions and `@vf()` / `micro` for regular vector work.

Use `@simt` only when:

- the work is genuinely irregular: data-dependent gather/scatter, atomics, or
  branchy per-element control flow,
- a targeted runtime probe needs the SIMT path itself,
- the logic cannot be expressed cleanly as VF + matmul without making the
  kernel more fragile, and
- the operands fit cleanly into `GMTensor`, UB `Tensor`, or `Var` arguments.

Do **not** use `@simt` when:

- a dense dot product, matrix product, or GEMM-like reduction can use cube
  `matmul`,
- the work is regular elementwise, masking, row-wise reduction, scan, cast, or
  layout publish/postprocess work that fits `@vf()` / `micro`,
- you only want a quick correctness baseline for a subgraph whose VF + matmul
  topology is already clear,
- you need cube/`L0`/`L1` operations (those belong in `@kernel`)
- you need `Reg` / `RegList` / `MaskReg` micro arithmetic (use `@vf`)
- you need named pipe events such as `SEvent` / `DEvent` (use `@kernel` with
  `auto_sync()` or explicit mutexes)

## 2. Calling convention

A `@simt`-wrapped function is invoked from inside a `@kernel` body just like a
`@vf` call. It emits a `call_simt` instruction that the parser routes to the
vec side, and the autosync pass uses the module's read/write sync keys to
schedule it together with surrounding `MTE2 -> V -> MTE3` edges.

```python
from easyasc.a5 import *

TILE_ELEMS = 64

@simt()
def axpy_simt(x_ub: Tensor, y_ub: Tensor, out_ub: Tensor, alpha: Var, n: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out_ub[i] = x_ub[i] * alpha + y_ub[i]


@kernel()
def simt_axpy_kernel(x: GMTensor, y: GMTensor, out: GMTensor, alpha: Var, N: Var):
    x_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    y_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    out_ub = Tensor(DT.float, [1, TILE_ELEMS], Position.UB)
    n_iter = Var(TILE_ELEMS, DT.int)

    with auto_sync():
        x_ub <<= x[0:1, 0:TILE_ELEMS]
        y_ub <<= y[0:1, 0:TILE_ELEMS]
        axpy_simt(x_ub, y_ub, out_ub, alpha, n_iter)
        out[0:1, 0:TILE_ELEMS] <<= out_ub

    return out
```

This is `agent/example/kernels/a5/simt/simt_axpy.py`. Additional reference samples live next
to it:

- `agent/example/kernels/a5/simt/simt_atomic_add.py` — GM-side `out = init;
  out[i % BINS] += x[i]` with `simt_atomic_add`, including both safe
  vec-identity sharding forms
- `agent/example/kernels/a5/simt/simt_matmul_transpose_contig_read.py` — cube matmul +
  SIMT transpose with contiguous UB reads
- `agent/example/kernels/a5/simt/simt_matmul_transpose_contig_write.py` — same task with
  contiguous GM writes instead

## 3. `SimtModule` lifecycle

The `@simt` decorator returns a `SimtModule` instance. Each call site triggers:

1. argument normalization — Python `int` / `float` actuals are wrapped into
   anonymous `Var` objects with dtype `DT.int` or `DT.float`
2. dtype validation — every actual must match its formal `kind`
   (`GMTensor`, `Tensor`, or `Var`)
3. dtype locking — on the first call the module records the dtype tuple of
   its actuals; later calls with a different tuple raise `TypeError`
4. instruction emission — the active kernel receives a `call_simt`
   instruction carrying the module name, normalized args, `num_threads`, and
   the read/write sync keys derived from the body

So a single `@simt` module can be reused across many call sites in one
kernel, but every call must use the same dtype combination.

## 4. Supported AST subset

The body is parsed through Python's `ast` module and lowered twice:

- to C++ source via `SimtModule.render()` — used by codegen
- to an internal IR via `SimtModule.lower_to_ir()` — used by the simulator

Both lowerings accept the same restricted subset.

### Statements

- `Assign` — exactly one target; the target may be a bare name (declares a
  new local with the rhs dtype) or a subscript expression
- `AugAssign` — uses the existing target's dtype; both sides must agree
- bare expressions — typically calls; bare string literals are treated as
  docstrings and skipped
- `For` — only `for <name> in range(<...>):`; no `for-else`
- `While` — no `while-else`
- `If` / `Elif` / `Else` — chained comparisons inside the condition are
  rejected; split them into `&&` / `||`
- `Break` / `Continue`

Anything else (lists, dicts, function defs, imports, `with`, exception
handling, etc.) raises `NotImplementedError`.
Errors raised while rendering or lowering the SIMT body include a
`SIMT source line: <file>:<line> in @<name>` context line plus the original
source statement.

### Expressions

- `Name` — only previously declared locals or formal parameters; otherwise
  raises `NameError`
- `Constant` — `int`, `float`, or `bool`
- `Subscript` — single index (no slicing); subscript bases must be names
- `BinOp` — `+`, `-`, `*`, `/`, `%`, plus bitwise `|`, `^`, `&`, `<<`, `>>`;
  precedence and non-commutative grouping match C++
- `UnaryOp` — `+`, `-`, `not`
- `Compare` — `==`, `!=`, `<`, `<=`, `>`, `>=`; chained comparisons are
  rejected
- `BoolOp` — `and` / `or` lower to C++ `&&` / `||`
- `Call` — `cvt(...)`, `simt_fma(...)`, and the four nullary intrinsics may be
  used as expressions; the four `simt_atomic_*` calls are accepted only as bare
  expression statements

### dtype rules

- every binary op, comparison, augmented assign, and assignment requires
  both sides to share a dtype; the only way to change dtype inside the body
  is `cvt(value, dtype)` (see §5)
- subscript expressions take the dtype of their base
- bool literals are treated as `DT.int`
- chained `for` loop variables get `DT.int`
- a `for` loop variable cannot shadow an existing name; doing so raises
  `NameError`

### `range(...)` rules inside `for`

- 1, 2, or 3 positional arguments
- no keyword arguments
- every argument must lower to `DT.int`

## 5. `cvt(value, dtype)`

- Purpose: cast `value` to `dtype` inside a SIMT body. This is the only
  cast intrinsic available; ordinary numeric promotion does not happen.
- Parameters:
  - `value`: any expression supported in §4
  - `dtype`: `Datatype.X` or `DT.X` — must be passed as an attribute access,
    not a runtime variable
- Codegen lowering: `(T)(value_expr)`
- Restrictions:
  - exactly two positional args
  - no keyword arguments
  - the second argument must be parseable as `Datatype.<name>` (or `DT.<name>`
    via alias) — `cvt(x, DT.float)` is valid; `cvt(x, my_dtype)` is not

## 6. `simt_fma(multiplicand0, multiplicand1, addend)`

- Purpose: compute `multiplicand0 * multiplicand1 + addend` as one fused fp32
  operation inside a SIMT expression.
- Parameters: exactly three positional expressions, all inferred as `DT.float`.
- Returned dtype: `DT.float`.
- Codegen lowering: one parenthesized multiply-add expression. The generated
  project must compile it with `-ffp-contract=on` so the backend may emit the
  fused hardware operation.
- Simulator behavior: evaluate the product and sum in fp64, then round once to
  fp32, matching fused rather than separately rounded multiply-then-add
  semantics.
- Restrictions:
  - keyword arguments are not accepted
  - half, bfloat16, integer, and mixed-dtype operands are rejected
  - an ordinary SIMT `x * y + z` expression is not a separately-rounded
    multiply-then-add contract on C310; when two roundings are required, use
    explicit Micro `mul` and `add` in a suitable kernel instead

```python
out[i] = simt_fma(x[i], y[i], out[i])
```

## 7. Nullary intrinsics

| Public name | Backend lowering | Returned dtype inside the body |
| --- | --- | --- |
| `simt_thread_id()` | `Simt::GetThreadIdx<0>()` | `DT.int` |
| `simt_thread_num()` | `Simt::GetThreadNum<0>()` | `DT.int` |
| `simt_block_idx()` | `Simt::GetBlockIdx()` | `DT.int` |
| `simt_block_num()` | `Simt::GetBlockNum()` | `DT.int` |

All four take no arguments. Passing any positional or keyword argument
raises `TypeError`.

`simt_block_idx()` / `simt_block_num()` are cube-core identity/count on A5-family
hardware. They are **not** the global vec participant id/count. Because a
normal vec-side call site runs on both subblocks of each core, GM-wide SIMT
sharding should pass vec identity explicitly:

```python
body(x, out, N, GetVecIdx(), GetVecNum())
```

or pass `GetSubBlockIdx()` and compute
`vec_idx = simt_block_idx() * 2 + sub_block_idx` inside the SIMT body. See
`agent/example/kernels/a5/simt/simt_atomic_add.py` for both forms. Using
`simt_block_idx()` directly for GM atomics shards by cube core and can duplicate
work across the two vec subblocks.

The Python stubs return `0` / `1` constants when called outside a `@simt`
body, so static tools and unit-test imports of the module file still work.

## 8. Atomic write intrinsics

| Public name | Backend lowering |
| --- | --- |
| `simt_atomic_add(t[i], val)` | `Simt::AtomicAdd(t + (i), val);` |
| `simt_atomic_sub(t[i], val)` | `Simt::AtomicSub(t + (i), val);` |
| `simt_atomic_max(t[i], val)` | `Simt::AtomicMax(t + (i), val);` |
| `simt_atomic_min(t[i], val)` | `Simt::AtomicMin(t + (i), val);` |
| `simt_atomic_cas(t[i], cmp, val)` | `Simt::AtomicCas(t + (i), cmp, val);` |

Use these only as **statements** (bare expression statements, no return value).

- The first argument must be a tensor formal — either a `GMTensor` or a UB
  `Tensor`. Subscripted form `t[i]` lowers to `t + (i)`; the bare form `t`
  lowers to just `t` (offset 0).
- Every value argument must match the tensor's element dtype. For CAS, the
  second argument is the comparison value and the third is the replacement.
  The statement does not expose the backend's returned prior value; reload the
  target when implementing a retry loop. The index must be an integer dtype.
- The base name contributes both a read and a write sync key, matching the
  read-modify-write semantics of an atomic.
- The simulator implements add/sub via `index_put_(..., accumulate=True)` and
  max/min via `scatter_reduce_(..., reduce='amax'|'amin', include_self=True)`,
  guarded by `SharedMemoryStore.atomic_lock()` so concurrent updates from
  multiple cores are serialized.
- The Python stubs are no-ops when imported outside a `@simt` body.

## 9. Generated function signature

`SimtModule.render()` emits:

```cpp
__simt_vf__ __launch_bounds__(<num_threads>) inline void <name>(<args>) {
    <body>
}
```

Argument lowering by formal kind:

| Formal annotation | Generated parameter |
| --- | --- |
| `GMTensor` | `__gm__ <T>* <name>` |
| `Tensor` | `__ubuf__ <T>* <name>` |
| `Var` | `<T> <name>` |

`<T>` for tensor parameters comes from the locked dtype of the actual
passed in at the first call site.

## 10. Synchronization

`call_simt` instructions carry `read_sync_keys` and `write_sync_keys`
derived from the SIMT body (`SimtModule._derive_call_sync_keys`):

- a `GMTensor` / `Tensor` formal that is read inside the body contributes a
  read sync key on the corresponding actual at the call site
- the same formal contributes a write sync key when the body writes to it
- subscript-write through a base name is treated as a write to that base

That makes a `call_simt` site behave like a regular vec-side instruction
under `with auto_sync():`. You do not need to add manual `bar_all()` or
named events around it.

If you need cross-side ordering between cube and a SIMT call (the SIMT call
consumes a tile produced on cube, or vice versa), use `CvMutex` / `VcMutex`
exactly as you would around a `@vf` call. See
`agent/example/kernels/a5/simt/simt_matmul_transpose_contig_read.py` for the cube → SIMT
handoff with `CvMutex(..., dst_end_pipe=Pipe.V)`.

## 11. Simulator behavior

- the simulator imports the module, builds the IR, and interprets it on the
  vec side
- per-thread state is modeled inside the same vec sub-block; thread fanout
  is logical, not multi-process
- read / write sync keys feed into the same autosync graph as `call_micro`
- numeric semantics follow the dtype rules from §4 — float arithmetic is
  Python `float`, integer arithmetic is Python `int`, bitwise ops require
  matching widths
- cycle-model timing is based on dynamically executed SIMT IR instructions:
  each executed masked instruction costs 4 cycles, divergent branches count
  one masked execution for each branch that has active lanes, and loop bodies
  are counted once per dynamic iteration that executes with any active lane.
  A `call_simt` task also pays the same vec-side instruction head overhead as
  `@vf()` / `call_micro` (`instruction_head_overhead_cycles` in the active
  cycle profile, 10 cycles in the bundled a5 profile). During normal simulator
  execution the count comes from the real SIMT run; standalone
  `estimate_task_cycles(...)` calls replay on cloned tensor views for analysis
  only.

`OpExec(..., simulator=True)` runs the same code path as the codegen build,
so successful simulator runs are a strong indicator that the SIMT body will
also lower cleanly.

## 12. Common pitfalls

- **Calling `@simt` on a2.** The decorator and the module both check
  `globvars.device_type` and raise. Switch to `easyasc.a5` or `easyasc.a5pr`.
- **Mismatched dtypes between calls.** The first call locks the dtype
  tuple; later calls with different dtypes raise. Allocate consistent
  buffers across call sites.
- **Mixing dtypes inside the body without `cvt`.** Every binary op,
  comparison, augmented assign, and assignment requires equal dtypes.
- **Using a Python conditional with chained comparisons.** Split into
  `(a < b) and (b < c)` (lowers to `&&`) instead of `a < b < c`.
- **Passing keyword arguments.** SIMT modules do not accept `**kwargs` at
  call time (`if kwargs: raise TypeError(...)`).
- **Shadowing parameters with a loop variable.** `for x in range(...)`
  where `x` is also a formal raises `NameError`. Pick a fresh name.
- **Forgetting `auto_sync()`.** Without `auto_sync()` around the kernel
  region, `call_simt` will run without the producer/consumer handshakes its
  read/write keys imply, and you will see ordering races against
  surrounding MTE2 / MTE3 work.
