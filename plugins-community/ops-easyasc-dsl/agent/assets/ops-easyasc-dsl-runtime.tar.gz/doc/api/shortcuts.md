# Shortcuts

This page documents the public shortcut-style helpers shared conceptually
across `easyasc.a2` and the A5-family facades (`easyasc.a5` and
`easyasc.a5pr`).

These helpers are higher-level convenience entry points rather than low-level instruction primitives.

## 1. Matmul Shortcut

### `matmul(dst, l1a, l1b, splitn=None, splitk=None, m=None, n=None, k=None, is_init=True, bias=None)`

- Purpose: Emit the standard matmul path used by most repository kernels, including optional split-N or split-K staging.
- Logical contract: `l1a[M,K] @ l1b[N,K].T -> dst[M,N]` (`MK @ NK -> MN`).
  If source tensors are physically stored as `KM` / `KN`, pass `.T` views at the call site so the shortcut sees the logical operands.
- Parameters:
  - `dst`: `Tensor` in `L0C`
  - `l1a`, `l1b`: input `Tensor` objects in `L1`
  - `splitn`: optional split size for N-tiling
  - `splitk`: optional split size for K-tiling
  - `m`, `n`, `k`: optional explicit logical dimensions
  - `is_init`: whether the destination accumulation starts from zero
  - `bias`: optional contiguous `[1, N]` L1 bias row added on the init tile
- Restrictions:
  - only valid inside an active kernel
  - `dst` must be `Position.L0C`
  - `l1a` and `l1b` must be `Position.L1`
  - `splitn` and `splitk` cannot both be set
  - `splitn` and `splitk` tile work inside one core; they do not create a
    cross-core partition or host-side merge
  - normal matmul has no generic hard minimum of 32 for either split; 32 is a
    tuning-search heuristic
  - `bias`, when present, must be staged contiguously in L1; use a flat GM->L1
    path, not a default ND2NZ-fractalized row
  - `bias` dtype is `DT.float` for float/half/bf16 inputs, or `DT.int` for
    int8@int8; bias requires `is_init=True` and is not supported for int4
  - one automatic BT slot holds 64 fp32/int32 values on A2 or 512 on A5/A5PR;
    nosplit/split-K bias requires static full N within that limit, while
    dynamic total N requires a static split-N tile within the limit
  - the active kernel must have the framework-managed `_l0a`, `_l0b`, `_l0acnt`, and `_l0bcnt` buffers
- Example:

```python
matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
```

## 2. MX FP8 / MXFP4 Matmul Shortcut

### `matmul_mx(dst, l1a, l1b, scale_a, scale_b, splitk=None, m=None, n=None, k=None, is_init=True, *, splitn=None, bias=None)`

- Purpose: emit the A5-family MX FP8 / MXFP4 matmul path.
- Logical contract: `l1a[M,K] @ l1b[N,K].T -> dst[M,N]`.
- Parameters:
  - `dst`: `DT.float` `Tensor` in `L0C`
  - `l1a`, `l1b`: `DT.e4m3` / `DT.e5m2` tensors or `DT.fp4_e2m1` / `DT.fp4_e1m2` carrier-backed views in `L1`
  - `scale_a`, `scale_b`: `DT.uint8` e8m0 scale tensors in `L1`
  - `splitk`: optional K split size; static values must be multiples of `64`
  - `splitn`: optional N split size; static values must be multiples of `16`
    for NZ2NZ; when `l1b.T` uses NZ2ZN, static values must satisfy the
    transposed-load alignment: `32` for FP8 and `64` for FP4
  - `m`, `n`, `k`: optional explicit logical dimensions
  - `is_init`: whether L0C accumulation starts from zero
  - `bias`: optional contiguous fp32 `[1, N]` L1 bias row added on the init tile
- Restrictions:
  - a5-family / `device_type in ("950", "950pr")` only
  - NZ2NZ plus A-side / B-side NZ2ZN through `l1a.T` or `l1b.T`; transposed
    scale tensors are rejected
  - `splitn` and `splitk` cannot both be set
  - non-transposed shortcut scale tensors are 16-row physical tiles
  - with `l1a.T`, `scale_a` must already be packed in post-transpose row
    order as `[M, 2 * ceil(K / 64)]`
  - with `l1b.T`, `scale_b` must already be packed in post-transpose row
    order as `[N, 2 * ceil(K / 64)]`
  - external GM scale must be loaded through the packed `[num_blocks, 32]`
    `gm_to_l1_mx_scale` contract before calling this shortcut
  - `bias`, when present, must be staged contiguously in L1, must be `DT.float`,
    and requires `is_init=True`; nosplit/split-K needs static `N <= 512`, while
    dynamic total N needs static `splitn <= 512`
- Detailed contract: [MX FP8 / MXFP4 Matmul Notes](../topics/mxfp.md).
- Example:

```python
matmul_mx(l0c, l1a, l1b, scale_a, scale_b, splitk=64, m=M, n=N, k=K)
```

## 3. MX Payload Padding Helper

### `zero_mxfp8_l1_padding(tensor, n_blocks=None)`

- Purpose: clear a padded byte-sized L1 data tile before a low-level MX
  transpose/NZ2ZN load. Despite the historical name, this helper is also valid
  for FP4 `DT.uint8` carrier tiles.
- Restrictions:
  - A5 family only (`easyasc.a5` / `easyasc.a5pr`)
  - `tensor` must be a physical `Position.L1` tensor with 1-byte elements
  - if `n_blocks` is omitted, the static footprint must be 32B aligned
- Important order: call this helper before filling live scale/data for the tile.
  It is a coarse L1 constant fill and can clear useful bytes if called after
  the tile has been populated.
- Detailed contract: [MX FP8 / MXFP4 Matmul Notes](../topics/mxfp.md).

## 3b. `conv2d(l0c, fmap, weight, conv, h, w, c, cout, m0=0, tile_k=None, bias=None)`

- Purpose: emit the convolution matmul
  `l0c[tile_m, cout_p] = img2col(fmap)[m0:m0+tile_m, :] @ weight.T (+ bias)`,
  using the load3d hardware to perform img2col on the fly.
- Logical contract: a `Conv2D` config plus an L1 `NC1HWC0` feature map and an L1
  packed weight produce one `[tile_m, cout_p]` L0C tile.
- Parameters:
  - `l0c`: destination `Tensor` in `L0C` (`tile_m` is `l0c.shape[0]`)
  - `fmap`: L1 feature map in `NC1HWC0` layout (`[c1*h*w, C0]`)
  - `weight`: L1 packed weight `[cout_p, K]`, staged via `<<=` of the host
    `easyasc.utils.conv2d.pack_conv_weight` output
  - `conv`: a `Conv2D` config object (kernel size, stride, padding, dilation)
  - `h`, `w`, `c`: feature-map height / width / channel dims (`int` or `Var`)
  - `cout`: output channel count (`int` or `Var`)
  - `m0`: row offset into the logical img2col matrix; the caller loops `m0`
  - `tile_k`: optional K-tiling size
  - `bias`: optional contiguous fp32 `[1, cout_p]` L1 bias row, added on the init K tile
- Restrictions:
  - A2 / 910B and the A5 family (`a5` / 950, `a5pr` / 950PR)
  - matmul-scope only: the caller owns the outer `m0` loop, core gating, and the L0C store
  - `fmap` / `weight` / `bias` must already be staged in L1
  - the padded bias width must fit one BT slot: at most 64 fp32 values on A2 or
    512 on A5/A5PR; L0/cube capacity is checked independently
- Detailed contract: [Conv2D via load3d img2col](../topics/conv2d.md) — covers the host
  packers `easyasc.utils.conv2d.pack_nc1hwc0` / `pack_conv_weight`, the `Conv2D` / `img2col` /
  `l1_to_l0a_img2col` surface, load3d parameter semantics, and hardware constraints.
- Example:

```python
conv2d(l0c, fmap_l1, weight_l1, conv, h=H, w=W, c=C, cout=Cout, m0=m0, bias=bias_l1)
```

## 4. VecOP Convenience Builders

### `maximum(a, b)`

- Purpose: Build a `VecOP` representing elementwise max between a tensor and another tensor or scalar.
- Parameters:
  - `a`, `b`: one tensor plus either another tensor or a scalar/`Var`
- Restrictions:
  - at least one operand must be a `Tensor`
  - the returned object must be consumed by `<<=`
- Example:

```python
dst <<= maximum(src, 0.0)
```

### `minimum(a, b)`

- Purpose: Build a `VecOP` representing elementwise min between a tensor and another tensor or scalar.
- Parameters:
  - `a`, `b`: one tensor plus either another tensor or a scalar/`Var`
- Restrictions:
  - at least one operand must be a `Tensor`
  - the returned object must be consumed by `<<=`
- Example:

```python
dst <<= minimum(src1, src2)
```
