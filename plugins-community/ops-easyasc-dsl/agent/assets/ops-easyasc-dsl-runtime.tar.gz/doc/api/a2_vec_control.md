# A2 and Shared Vec Control and Access Helpers

This page documents the non-math vector helpers exported by `easyasc.a2`, plus
the vec mask-state helpers shared with the A5-family facades (`easyasc.a5` and
`easyasc.a5pr`).

Scope of this page:

- UB vector cast
- UB compare and select helpers
- vec mask state helpers shared by A2 and the A5 family
- UB gather and scatter helpers

Vec cast, compare/select, gather, and scatter in this page are A2-only Tensor
APIs. The four functions in §3 are shared top-level vec PipeS controls.

Notes:

- every tensor on this page is expected to live in `UB`
- several names such as `compare`, `select`, and `gather` also exist in the A5
  family, but those are micro-register APIs and are documented separately
- on the A5 family, `set_mask`, `set_mask_by_count`, `set_mask_normal`, and
  `reset_mask` control the vec mask SPR; an A5 `@vf` can read that state with
  `move_mask_spr`

## 1. Vec Cast

### `cast(dst, src, repeat=None, dst_blk_stride=None, src_blk_stride=None, dst_rep_stride=None, src_rep_stride=None, round_mode=RoundMode.AWAY_FROM_ZERO)`

- Purpose: Perform UB vector cast between dtypes.
- Parameters:
  - `dst`: destination UB `Tensor`
  - `src`: source UB `Tensor`
  - `repeat`: optional repeat count
  - `dst_blk_stride`, `src_blk_stride`: block strides
  - `dst_rep_stride`, `src_rep_stride`: repeat strides
  - `round_mode`: vec cast rounding mode
- Restrictions:
  - exported by `a2`
  - `dst` and `src` must both be UB tensors
  - `round_mode` must be `RoundModeType`
  - when widening, the runtime forces `RoundMode.NONE`
- Current simulator notes:
  - cast ignores `dst_blk_stride` / `src_blk_stride`; only repeat strides matter
  - the cast-element count per repeat is determined by the wider of `src` / `dst` dtypes
  - repeat strides are addresses between repeats, so they do not need to encode
    matching element counts across different source/destination dtypes; for
    example, padded bf16 and fp32 rows may both use a one-block repeat stride
  - the current vec mask is resolved on that cast-element domain
  - masked-off cast elements keep the previous `dst` value
  - allocate enough source/destination guard storage for the full wider-dtype
    repeat footprint even when only a few lanes are active
- Example:

```python
cast(dst_half, src_float)
```

## 2. Vec Compare and Select

### `SelectModeType` and `SelectMode`

The vec `select(...)` stub takes an explicit select mode.
Those mode objects are defined in `easyasc/utils/selectmode.py`.

### `SelectModeType`

- Purpose: represent one concrete vec select lowering mode.
- Stored field:
  - `name`
- Important behavior:
  - `str(mode)` returns names such as `TENSOR_TENSOR`
  - `repr(mode)` returns a debug-style form such as `SelectModeType('TENSOR_SCALAR')`
  - equality compares mode names

One implementation detail is worth knowing when debugging helper code:

- comparing a `SelectModeType` against an object of another type raises `TypeError`
- it does not silently return `False`

### `SelectMode`

`SelectMode` is the enum-like namespace for vec-side select forms:

- `SelectMode.TENSOR_TENSOR`
  - selected values come from two UB tensors, `src1` and `src2`
  - `dst` must not start at the same UB address as either source
- `SelectMode.TENSOR_SCALAR`
  - the true branch comes from `src1`, while the false branch uses the first element of `src2` broadcast across lanes

Both modes are supported, with one important `TENSOR_TENSOR` restriction:

- `TENSOR_SCALAR`: `src2` must still be a UB tensor; its first element is read as the scalar false-branch value
- `TENSOR_TENSOR`: `dst` may not alias the starting address of `src1` or `src2`; use a temporary destination when you need to select in place

When `dst` would alias a source and the dtype has a neutral element, split the expression into scalar-select pieces and merge, for example:

```python
select(a_part, a_mask, a_tensor, zero_tensor, SelectMode.TENSOR_SCALAR)
select(b_part, b_mask, b_tensor, zero_tensor, SelectMode.TENSOR_SCALAR)
add(dst, a_part, b_part)
```

This is equivalent to `dst = a_mask ? a_tensor : b_tensor` only when `a_mask` and `b_mask` are complementary and `zero_tensor[0]` is a valid additive identity for the dtype.

### Why this type belongs on the A2 vec page

`SelectMode` is used by the A2 vec `select(...)` stub, not by the A5 micro `select(...)` instruction.
Keeping it here avoids mixing two unrelated APIs that merely share the word "select".

### `compare(dst, src1, src2, mode, repeat=None, ...)`

- Purpose: Compare two UB tensors and write the boolean result into a UB mask tensor.
- Parameters:
  - `dst`: destination UB `Tensor` holding the compare result
  - `src1`, `src2`: source UB tensors
  - `mode`: `CompareMode`
  - remaining parameters: repeat and stride metadata
- Restrictions:
  - exported by `a2`
  - `dst` must be UB `int8` or `uint8`
  - `src1` and `src2` must be UB tensors of matching dtype
  - supported source dtypes: `float`, `half`, `int16`, `int`
  - `compare()` currently ignores the current vec mask state
- Example:

```python
compare(mask_buf, xub, yub, CompareMode.GT)
```

### `compare_scalar(dst, src1, src2, mode, repeat=None, ...)`

- Purpose: Compare a UB tensor against a scalar and write the result into a UB mask tensor.
- Parameters:
  - `dst`: destination UB `Tensor` holding the compare result
  - `src1`: source UB tensor
  - `src2`: scalar `int`, `float`, or `Var`
  - `mode`: `CompareMode`
  - remaining parameters: repeat and stride metadata
- Restrictions:
  - exported by `a2`
  - `dst` must be UB `int8` or `uint8`
  - `src1` must be UB `float`, `half`, `int16`, or `int`
  - `compare_scalar()` currently ignores the current vec mask state
- Example:

```python
compare_scalar(mask_buf, xub, 0.0, CompareMode.GE)
```

### `select(dst, selmask, src1, src2, mode, repeat=None, ..., tmp_addr_buf=None)`

- Purpose: Select between two UB tensor sources, or between `src1` and a broadcast scalar false-branch value, using a tensor selection mask.
- Parameters:
  - `dst`: destination UB `Tensor`
  - `selmask`: mask UB `Tensor`
  - `src1`: first source UB `Tensor`
  - `src2`: second source UB `Tensor`; `TENSOR_SCALAR` reads `src2[0]` as a broadcast scalar
  - `mode`: `SelectMode.TENSOR_SCALAR` or `SelectMode.TENSOR_TENSOR`
  - `tmp_addr_buf`: **required for `TENSOR_TENSOR`, rejected for `TENSOR_SCALAR`.** A caller-owned `uint32` UB `Tensor` of `>= 8` lanes (one 32 B block) used to stage the per-repeat selMask address — see the `TENSOR_TENSOR` note below.
  - remaining parameters: repeat and stride metadata
- Restrictions:
  - exported by `a2`
  - `dst`, `src1`, and `src2` must be UB tensors
  - `dst`, `src1`, and `src2` must share the same dtype
  - supported data dtypes: `float`, `half`, `int16`, `int`
  - tensor `selmask` must be `uint8`
  - `select()` currently ignores the current vec mask state; selection is controlled only by `selmask`
- Lowering modes:
  - `SelectMode.TENSOR_SCALAR` is supported
  - `SelectMode.TENSOR_TENSOR` is supported only when `dst` starts at a different UB address from `src1` and `src2`, and requires `tmp_addr_buf`
  - parser lowering emits `PipeBarrier<PIPE_V>();` between `SetCmpMask(...)` and the backend `Select(...)`
- `TENSOR_TENSOR` per-repeat selMask (`tmp_addr_buf`):
  - `TENSOR_TENSOR` lowers to the c220 mode-2 `Select`, which advances the selMask by `256/sizeof(dtype)` bits **per repeat** — so a multi-row / `repeat > 1` select reads a different mask slice per row, which is what you want for per-row masks.
  - mode 2 reads those mask bits through an *address* held in the cmpmask SPR (not the mask contents), so the selMask address must be staged into a UB buffer first. easyasc requires that scratch explicitly via `tmp_addr_buf` and deliberately does **not** borrow CANN's implicit `TMP_UB_OFFSET` region (184-192 KB on a2), which would occupy UB outside easyasc's accounting and risk clobbering your tensors.
  - one `tmp_addr_buf` can be reused across multiple selects (auto_sync tracks it as a select write, serializing reuse).
  - History: before this was wired, `TENSOR_TENSOR` ran mode-0's `SetCmpMask` (mask *contents*) but called the mode-2 `Select`, so every `repeat > 1` row misread the SPR as an address and produced garbage (only row 0 correct). The simulator modeled correct mode-2 all along — a sim-pass / HW-fail gap, now fixed in the parser. Multi-row compare/select is usable again.
- Example:

```python
# TENSOR_SCALAR: no tmp_addr_buf
select(dst, selmask, src1, zero_tensor, SelectMode.TENSOR_SCALAR)

# TENSOR_TENSOR: pass a uint32 UB scratch (>= 8 lanes); one buffer can be shared across selects
addr_buf = Tensor(DT.uint32, [1, 8], Position.UB)
select(dst_tmp, selmask, src1, src2, SelectMode.TENSOR_TENSOR, tmp_addr_buf=addr_buf)
```

## 3. Vec Mask State

### `set_mask(mask_high, mask_low)`

- Purpose: Set the current vec mask registers.
- Parameters:
  - `mask_high`, `mask_low`: `int` or `Var`
- Restrictions:
  - exported by `a2` and the A5-family facades
  - if a `Var` is used, its dtype must be `uint64`
- Current simulator notes:
  - `mask_low` controls bits `0..63`
  - `mask_high` controls bits `64..127`
  - `mask[128:256]` is not modified by `set_mask()`
  - typical active prefixes are:
    - `float` / `int32`: `mask[0:64]`
    - `half` / `int16`: `mask[0:128]`
    - `int8` / `uint8`: `mask[0:256]`
  - the same mask prefix is reused for every repeat; it does not advance automatically per repeat
- Example:

```python
set_mask(0, 0xFFFFFFFFFFFFFFFF)
```

### `set_mask_by_count(count)`

- Purpose: Activate the first `count` lanes of every normal vector repeat.
- Parameters:
  - `count`: `int` or `Var`
- Restrictions:
  - exported by `a2` and the A5-family facades
  - the simulator accepts `count` in `[0, 256]`
  - this helper changes the mask bits but does not enter counter mask mode
  - the same active prefix is reused for every repeat
  - call `reset_mask()` after the partial-mask region when later operations need the default full mask
- Example:

```python
set_mask_by_count(valid_lanes)
adds(dst, src, 1.0, repeat=rows)
reset_mask()
```

### `set_mask_normal()`

- Purpose: Explicitly switch the vector unit from counter mask mode back to normal repeat mode.
- Parameters: none.
- Restrictions:
  - exported by `a2` and the A5-family facades
  - use before a normal repeat-mode reduction when control flow may have left the vector unit in counter mode
- Codegen: emits `SetMaskNorm()`.
- This switches the mask mode only; call `reset_mask()` as well when the mask bits must return to the full default mask.

```python
set_mask_normal()
reset_mask()
```

### `reset_mask()`

- Purpose: Reset the vec mask state to the default state.
- Parameters:
  - none
- Restrictions:
  - exported by `a2` and the A5-family facades
  - use after temporary partial-mask regions to avoid surprising later ops
- Current simulator note:
  - resets the full `mask[0:256]` back to all ones
- Example:

```python
reset_mask()
```

## 4. Gather and Scatter

### `gather(dst, src, offset, start_idx=0, repeat=None, dst_rep_stride=None)`

- Purpose: Gather elements from a UB source tensor using a UB offset tensor.
- Parameters:
  - `dst`: destination UB `Tensor`
  - `src`: source UB `Tensor`
  - `offset`: UB `Tensor` of byte offsets
  - `start_idx`: base byte offset
  - `repeat`: optional repeat count
  - `dst_rep_stride`: destination repeat stride
- Restrictions:
  - exported by `a2`
  - `offset` must be UB `uint32`
  - `dst.dtype` must equal `src.dtype`
  - offsets and `start_idx` are in bytes
  - `gather()` currently ignores the current vec mask state
- Example:

```python
gather(dst, src, offset)
```

### `gather_block(dst, src, offset, repeat=None, dst_blk_stride=None, dst_rep_stride=None)`

- Purpose: Block gather (AscendC `Gatherb`). Each repeat gathers 8 contiguous 32B
  DataBlocks selected by `offset`. One offset addresses one whole 32B block
  (`32 // dtype.size` elements), unlike element `gather` (one offset -> one element).
- Parameters:
  - `dst`: destination UB `Tensor`
  - `src`: source UB `Tensor`
  - `offset`: UB `uint32` `Tensor` of 32B-aligned block byte addresses (8 per repeat)
  - `repeat`: optional repeat count (defaults to cover `dst`)
  - `dst_blk_stride`: dst stride between blocks within a repeat, in 32B blocks (default 1)
  - `dst_rep_stride`: dst stride between repeats, in 32B blocks (default 8)
- Restrictions:
  - exported by `a2`; A2-only (no top-level A5 equivalent)
  - `offset` must be UB `uint32`, and each value must be 32B-aligned
  - `dst.dtype` must equal `src.dtype`
  - the "8 blocks per repeat" is the fixed 256B hardware vector width, not a knob
  - on real HW, c220 `vgatherb` rejects 16-bit float operands: reinterpret `dst`/`src` to `uint16` before `gather_block` for `half`/`bf16` data (verified on A2). The simulator does not enforce this, so a `half` block gather passes in sim but fails to compile on HW (`"1st parameter maybe need a type '__ubuf__ unsigned short *'"`)
  - lowers to `Gatherb(dst, src, offset, repeat, GatherRepeatParams(dst_blk_stride, dst_rep_stride))`
  - `gather_block()` ignores the current vec mask state (`Gatherb` resets the mask)
- Example:

```python
gather_block(dst, src, offset, repeat=4)
```

### `scatter(dst, src, offset, start_idx=0, repeat=None, src_rep_stride=None)`

- Purpose: Scatter elements from a UB source tensor into a UB destination tensor using offsets.
- Parameters:
  - `dst`: destination UB `Tensor`
  - `src`: source UB `Tensor`
  - `offset`: UB `Tensor` of byte offsets
  - `start_idx`: base byte offset into the destination (default `0`)
  - `repeat`: optional repeat count
  - `src_rep_stride`: source repeat stride
- Restrictions:
  - exported by `a2`
  - `offset` must be UB `uint32`
  - `dst.dtype` must equal `src.dtype`
  - `scatter()` currently ignores the current vec mask state
- Example:

```python
scatter(dst, src, offset)
```
