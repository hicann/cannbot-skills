# OpExec

This page documents the public runtime-entry helper shared by `easyasc.a2` and
the A5-family facades, `easyasc.a5` and `easyasc.a5pr`.

`shape_bindings` is part of the `OpExec(...)` call-time API. It is used only on the Python runtime side, before the kernel body runs. Its job is to tell `OpExec` which runtime scalar should be reused as the symbolic shape variable for each input/output tensor dimension when plain value-based matching would be ambiguous. The same mechanism also applies to `GMTensorList` item shapes.

## 1. `OpExec`

### `OpExec(op_func, out_dir="", cann_path=None, custom_op_path=None, profile=False, gen_only=False, simulator=False, cannsim=False, skip_compile=False, trace=None, debug=False)`

- Purpose: Bind runtime inputs to a kernel, then run it through either the simulator path or the generation path.
- Parameters:
  - `op_func`: a kernel wrapper created by `@kernel`
  - `out_dir`: output directory prefix used by generation mode
  - `cann_path`: optional toolchain path override
  - `custom_op_path`: optional custom-op template path
  - `profile`: enable profile-oriented generation behavior
  - `gen_only`: in generation mode, emit artifacts without running the generated path; ignored when `simulator=True`
  - `simulator`: `bool`; when `True`, run through the simulator under `easyasc/simulator/` via `KernelBase.run_sim()`; when `False`, take the generation path
  - `cannsim`: only valid when `simulator=False`; when `True`, generation uses CANNSIM instead of direct NPU execution. In the full-project path, the generated `r.sh` runs `cannsim record ./test_aclnnop -s <chipset>`; in the debug path, the generated debug `b.sh` / `r.sh` switch from `-r npu` to `-r sim`
  - `skip_compile`: skip `b.sh` in generation mode
  - `trace`: simulator trace output path; a non-empty string is retained only
    when `simulator=True`, and is otherwise ignored
  - `debug`: when `True`, generation routes through `KernelBase.generate_debug(...)` and writes its runtime files to `<base>/debug_workspace/` instead of `<base>_aclnn_test/`
- Runtime call:

```python
OpExec(...)(*tensor_args, *scalar_args, shape_bindings=...)
```

- Restrictions:
  - `op_func` must be a `KernelBase` instance
  - the wrapped kernel's signature must follow `input tensor-like* -> output tensor-like* -> Var*`, with at least one `Var` parameter; tensor-like arguments may be `GMTensor` or `GMTensorList`, and `_validate_bound_kernel_signature` raises `Invalid kernel argument order for OpExec: ...` otherwise
  - the runtime call order mirrors that contract: pass all tensor-like values first (`torch.Tensor` inputs/outputs and Python `list`/`tuple` TensorList inputs/outputs), then scalar `int`/`float` values
  - `trace` must be `None` or a non-empty string; when `simulator=False`, the
    current runtime silently ignores it and creates no trace file
  - `cannsim` is only valid when `simulator=False`
  - repeated scalar values may require explicit `shape_bindings`
- Return value:
  - returns kernel-returned `GMTensor` outputs as `torch.Tensor`
  - returns kernel-returned `GMTensorList` outputs as Python lists of `torch.Tensor`
  - returns generated-path outputs according to the normal `OpExec` runtime contract in generation mode

For every non-simulator, non-`gen_only` run, `OpExec` serializes the `r.sh`
step with a cross-process lock, checks that the selected NPU card is idle, and
enforces a run timeout. These protections and their `EASYASC_NPU_*` environment
variables are documented in [Code Generation and Runtime §7](../06_codegen_and_runtime.md#run-step-serialization-idle-check-and-watchdog).

Example:

```python
z_out = OpExec(my_kernel, simulator=True)(
    x,
    y,
    z,
    M,
    N,
    K,
    shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1]},
)
```

## 2. `TorchApiManager`

### `TorchApiManager(out_dir="", cann_path=None, custom_op_path=None)`

- Purpose: manage a group of `OpExec` kernels and build one shared pybind Torch extension (`custop_torchapi`) for them.
- Typical use:
  - create one manager
  - assign `OpExec(...)` objects onto it as attributes
  - call each registered op once with representative arguments so its bound signature is known
  - run `compile()` or `load_lib()`
- Important registration behavior:
  - assigning `manager.some_op = OpExec(kernel)` registers the op under `kernel.name`
  - the manager rewrites that `OpExec` to `gen_only=True`, `simulator=False`, and `skip_compile=False`
  - the manager also propagates its own `out_dir`, `cann_path`, and `custom_op_path` into the registered op

### `compile()`

- Purpose: generate the grouped pybind wrapper, build the registered custom ops, build the Torch extension, and import it.
- Restrictions:
  - at least one `OpExec` must be registered
  - each registered op must have been called once already so bound tensor/scalar arguments are available
- Return value:
  - absolute path to the generated `custop_torchapi.cpp`

### `load_lib()`

- Purpose: load an existing built `custop_torchapi` module from `out_dir` when it already contains every registered op.
- Behavior:
  - if the existing module is missing any registered op symbol, the manager refuses to load it and asks for a recompile

This is an advanced packaging helper rather than the normal first-kernel workflow.
Most kernel authoring should still start with plain `OpExec(..., simulator=True)`.

## 3. `shape_bindings`

### Purpose

`shape_bindings` controls how `OpExec` reconstructs symbolic `GMTensor` shapes from runtime `torch.Tensor` shapes and runtime scalar arguments.

When you call:

```python
OpExec(my_kernel)(x, y, z, M, N, K, shape_bindings=...)
```

`OpExec` must build kernel-side objects like:

```python
GMTensor(dtype, [M, K])
GMTensor(dtype, [N, K])
GMTensor(dtype, [M, N])
```

However, at runtime it only sees concrete values such as:

```python
x.shape == (5, 5)
y.shape == (9, 5)
z.shape == (5, 9)
M == 5
N == 9
K == 5
```

In that situation, a tensor dimension with value `5` could mean either `M` or `K`. `shape_bindings` disambiguates that mapping.

### Type

```python
shape_bindings: Dict[int, Sequence[Optional[int]]]
```

For `GMTensorList` arguments, the value may also be a dictionary:

```python
shape_bindings = {
    0: {"item": [None, 0]},
}
```

`item` describes the per-item tensor shape. The list length itself is taken from the
runtime Python list/tuple. The same binding is checked independently against
every member, so a dimension bound to one scalar must have that scalar's value
in every item. Leave variable per-item dimensions unbound and query them inside
the kernel with `GMTensorList.item_numel(index)`.

### Index meaning

- Dictionary key: tensor-like argument index, counted among runtime tensor arguments
  (`torch.Tensor` and Python `list`/`tuple` TensorList inputs/outputs).
- Sequence element: scalar argument index, counted only among scalar arguments (`int` / `float`) that come after all tensors.
- `None`: do not force this tensor dimension to a specific scalar; let `OpExec` infer it automatically.

For:

```python
OpExec(my_kernel)(x, y, z, M, N, K, shape_bindings=...)
```

the indices are:

- tensor `0` -> `x`
- tensor `1` -> `y`
- tensor `2` -> `z`
- scalar `0` -> `M`
- scalar `1` -> `N`
- scalar `2` -> `K`

So:

```python
shape_bindings = {
    0: [0, 2],  # x.shape == [M, K]
    1: [1, 2],  # y.shape == [N, K]
    2: [0, 1],  # z.shape == [M, N]
}
```

means:

- bind `x.shape[0]` to scalar `M`
- bind `x.shape[1]` to scalar `K`
- bind `y.shape[0]` to scalar `N`
- bind `y.shape[1]` to scalar `K`
- bind `z.shape[0]` to scalar `M`
- bind `z.shape[1]` to scalar `N`

### TensorList arguments

If a kernel parameter is annotated as `GMTensorList`, pass a non-empty Python
`list` or `tuple` of `torch.Tensor` objects at the matching tensor-like argument
position. Returning the `GMTensorList` parameter marks it as a preallocated
dynamic output list; non-returned TensorLists are inputs.

```python
xs = [
    torch.randn((1, n), dtype=torch.float16),
    torch.randn((1, n), dtype=torch.float16),
    torch.randn((1, n), dtype=torch.float16),
]
y = torch.empty((1, n), dtype=torch.float16)

out = OpExec(addn_tensor_list_kernel, simulator=True)(
    xs,
    y,
    n,
    shape_bindings={
        0: {"item": [None, 0]},  # xs item shape is [1, n]
        1: [None, 0],            # y shape is [1, n]
    },
)
```

TensorList output uses the same call-site shape binding form:

```python
ys = [torch.empty_like(x) for x in xs]
item_count = len(xs)

outs = OpExec(copy_tensor_list_kernel, simulator=True)(
    xs,
    ys,
    n,
    item_count,
    shape_bindings={
        0: {"item": [None, 0]},
        1: {"item": [None, 0]},
    },
)
```

Rules:

- every list item must be a `torch.Tensor`
- the list must be non-empty
- all items must have the same dtype and rank
- concrete dimension sizes may differ between items
- a `shape_bindings` dictionary is valid only for TensorList arguments
- use the `item` key to bind item dimensions that are common scalar arguments;
  leave item-dependent dimensions as `None`

Inside the kernel, `xs.size()` returns a `Var`, and `xs[i]` returns a
`GMTensor`. For different-size members, `xs.item_numel(i)` returns the selected
member's runtime element count; reshape `xs[i]` with that value before deriving
slices or datamove strides. If `ys` is returned, `ys[i]` can be stored through
the same GM datamove APIs and `OpExec` maps every returned item back with its own
concrete shape. See
[tensor_buffer.md §3.5](tensor_buffer.md#35-gmtensorlist) for the DSL and
generated C++ lowering details.

```python
for item_idx in range(item_count):
    n = xs.item_numel(item_idx)
    src = xs[item_idx].reshape([1, n])
    dst = ys[item_idx].reshape([1, n])
    # Tile and transfer src/dst using n.
```

For hardware multi-item TensorList-output loops, the currently validated sample
passes an explicit `item_count` scalar and loops over that value. The simulator
supports `.size()`, but the A2 ACLNN dynamic-list output smoke path has not yet
validated `.size()`/`ListTensorDesc::GetSize()` for multi-item output loops.

When running TensorList kernels on hardware, use the normal generated ACLNN/custom-op
path (`debug=False`). The direct debug workspace path (`debug=True`) currently does
not support `GMTensorList`.

### Exact runtime behavior

For each tensor dimension, `OpExec` applies the following rules.

#### Case 1: explicit binding is provided

If `shape_bindings[tensor_idx][dim_idx]` is an integer `scalar_idx`, `OpExec`:

1. checks that `scalar_idx` is in range
2. reads that runtime scalar
3. checks that `scalar_value == tensor.shape[dim_idx]`
4. if they match, uses that scalar `Var` in the constructed `GMTensor` shape
5. if they do not match, raises an error

Example:

```python
x.shape == (5, 7)
M == 5
K == 3

shape_bindings = {
    0: [0, 2],  # tries to bind x.shape[1] to K
}
```

This fails because `x.shape[1] == 7`, but `K == 3`.

#### Case 2: no explicit binding and no scalar matches

If no scalar has the same runtime value as the tensor dimension, `OpExec` keeps that dimension as a plain integer literal.

Example:

```python
x.shape == (32, 48)
M == 32
K == 64
```

Then `x.shape[1] == 48` matches no scalar, so the constructed shape becomes effectively:

```python
[M, 48]
```

#### Case 3: no explicit binding and exactly one scalar matches

If exactly one scalar has the same runtime value as the tensor dimension, `OpExec` binds that dimension to the matching scalar automatically.

Example:

```python
x.shape == (32, 64)
M == 32
K == 64
```

Then `x` is inferred as:

```python
[M, K]
```

No `shape_bindings` entry is needed.

#### Case 4: no explicit binding and multiple scalars match

If more than one scalar has the same runtime value as the tensor dimension, `OpExec` refuses to guess and raises an ambiguity error.

Example:

```python
x.shape == (5, 5)
y.shape == (9, 5)
z.shape == (5, 9)
M == 5
N == 9
K == 5
```

Here every dimension whose value is `5` is ambiguous because both `M` and `K` equal `5`. In this situation you must bind the ambiguous dimensions explicitly.

### Why it exists

The kernel body usually uses symbolic scalar variables such as `M`, `N`, and `K` in:

- tensor declarations
- loop bounds
- tile math
- tail handling
- address calculations

`OpExec` therefore tries to reuse runtime scalar `Var` objects when building `GMTensor` shapes. That preserves the symbolic relationship between tensor dimensions and scalar parameters. `shape_bindings` exists because runtime value equality alone is sometimes not enough to recover that relationship.

### When you need it

Use `shape_bindings` when both of the following are true:

1. one or more kernel scalar arguments represent tensor dimensions
2. two or more of those scalar arguments have the same runtime value, so a tensor dimension could match multiple scalars

Typical case:

```python
M = 128
N = 256
K = 128
```

Now a dimension value of `128` could mean either `M` or `K`.

### When you do not need it

You usually do not need `shape_bindings` when:

- every tensor dimension matches at most one scalar value
- a dimension matches no scalar at all and can stay as a literal integer
- the kernel has no scalar shape arguments

Example without ambiguity:

```python
M = 64
N = 128
K = 256
x.shape == (64, 256)
y.shape == (128, 256)
z.shape == (64, 128)
```

Each dimension value matches a unique scalar, so `OpExec` can infer the symbolic mapping automatically.

### Partial bindings are allowed

You do not need to bind every tensor dimension. You only need to bind the dimensions that would otherwise be ambiguous.

Example:

```python
shape_bindings = {
    0: [0, 2],      # fully bind x
    2: [0, None],   # bind z.shape[0], infer z.shape[1]
}
```

This is valid as long as each unbound dimension is still unambiguous at runtime.

### Validation rules

`OpExec` validates `shape_bindings` strictly.

- `shape_bindings` must be a `dict`
- each value must be a `list` or `tuple`; for TensorList arguments, it may be a
  dictionary with an `item` binding
- binding rank must equal the common rank of every TensorList member
- each element must be `int` or `None`
- explicit scalar indices must be in range
- explicit bindings must match the actual runtime tensor dimension value

### Common error cases

#### Ambiguity error

If a dimension matches multiple scalar values and you did not bind it explicitly, `OpExec` raises:

```python
ValueError: Ambiguous scalar match for tensor #... dim #...
```

This means the runtime cannot decide which scalar variable should own that dimension.

#### Mismatch error

If you explicitly bind a dimension to the wrong scalar index, `OpExec` raises:

```python
ValueError: shape_bindings[...][...] mismatches tensor dim value
```

This means your declared symbolic binding disagrees with the actual runtime shape.

### Full example

Kernel signature:

```python
@kernel()
def my_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    return z
```

Runtime call:

```python
m = 5
n = 9
k = 5

x = torch.randn((m, k), dtype=torch.float16)
y = torch.randn((n, k), dtype=torch.float16)
z = torch.randn((m, n), dtype=torch.float16)

out = OpExec(my_kernel, simulator=True)(
    x,
    y,
    z,
    m,
    n,
    k,
    shape_bindings={
        0: [0, 2],
        1: [1, 2],
        2: [0, 1],
    },
)
```

Without `shape_bindings`, the dimensions whose value is `5` would be ambiguous.

### Practical rule of thumb

If your kernel takes explicit scalar shape arguments such as `M`, `N`, `K`, `B`, `H`, or `S`, and two of them might be equal at runtime, add `shape_bindings` at the `OpExec(...)` call site. It is cheap, explicit, and prevents shape inference from depending on accidental runtime uniqueness.
