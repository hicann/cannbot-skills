# Detailed API Reference

This directory contains the detailed API reference for the public `easyasc` authoring surface.

Scope of this reference:

- symbols exported from `easyasc.a2`
- the matching `easyasc.a3` surface, which re-exports A2/C220 APIs with the
  `Ascend910_9362` device profile and `ascend910_93` compile unit
- symbols exported from `easyasc.a5`
- the matching `easyasc.a5pr` surface, which re-exports A5/C310 APIs with the
  950PR device profile
- the main public helper classes that those facades expect users to work with

Out of scope:

- internal helpers whose names start with `_`
- parser-only, simulator-only, or codegen-only internals that are not part of the authoring surface

## Read This First

The same function name can mean different things in `a2` and `a5`.

Examples:

- `easyasc.a2.add`: UB vector add on `Tensor`
- `easyasc.a5.add`: micro register add on `Reg`
- `easyasc.a2.abs`: UB vector unary op
- `easyasc.a5.abs`: micro register unary op
- `easyasc.a2.compare`: vector compare that writes to a UB mask tensor
- `easyasc.a5.compare`: micro compare that writes to `MaskReg`

When reading the pages below, always keep the import surface in mind.

> Import exactly one target facade per Python process. Facade imports mutate
> process-global device configuration, and importing a cached module again does
> not restore its target. Start a new process when switching between A2, A3,
> A5, and A5PR.

## File Map

- [Decorators](decorators.md)
  - `kernel`, `func`, `auto_sync`, `vf`, and `simt`
- [SIMT Modules](simt.md)
  - `@simt`, `SimtModule`, `cvt`, `simt_fma`, the four query intrinsics, and `simt_atomic_{add,sub,max,min}`
  - A5-family thread-parallel authoring path
- [Flow Control](flow_control.md)
  - `range`, `unroll`, `break_`, `continue_`, `If`, `Elif`, `Else`, `vec_scope`, and `cube_scope`
  - native Python `if/elif/else` and `break`/`continue` rewrite notes plus side-scope routing
- [OpExec](op_exec.md)
  - `OpExec` and `TorchApiManager`
- [Shortcuts](shortcuts.md)
  - `matmul`
  - `matmul_mx`
  - `maximum` and `minimum`
- [Shared Scalar Helper Functions](scalars.md)
  - worker-query helpers such as `GetCubeIdx` and `GetVecNum`
  - arithmetic/alignment helpers such as `CeilDiv`, `Align128`, `Min`, and `Max`
- [Datatypes](datatype.md)
  - `DT`, `Datatype`, and `DataTypeValue`
  - predefined dtype members, `.size`, `.C0`, singleton usage rules, and host-side carrier/reference helpers
- [Positions](position.md)
  - `Position` and `PositionType`
  - local-memory domains, `.cpp` mappings, and singleton usage rules
- [Pipes](pipe.md)
  - `Pipe` and `PipeType`
  - local execution pipes, `S` / `ALL`, and synchronization usage rules
- [Var](var.md)
  - `Var` and `VarList`
  - scalar arithmetic, comparison `Expr`, and scalar IO helpers
- [Tensor and Buffer Types](tensor_buffer.md)
  - `Tensor`, `GMTensor`, `GMTensorList`, `DBuff`, `TBuff`, `QBuff`, `Layout`, and `LayoutType`
  - view semantics, layout hints, assignment dispatch, slicing, and slot-buffer behavior
- [Register and Mask Types](register.md)
  - `Reg`, `RegList`, `MaskReg`
  - `MaskType` and `MaskTypeValue`
  - builder methods, proxy semantics, and mask attachment
- [Synchronization](synchronize.md)
  - `CvMutex`, `VcMutex`, `cube_ready` / `vec_ready` / `wait_cube` / `wait_vec`, `allcube_ready` / `allvec_ready` / `allcube_wait` / `allvec_wait`, `setflag` / `waitflag`, `SEvent`, `DEvent`, `TEvent`, and `QEvent`
  - cross-side token flow, collective waits, local flag behavior, and local event behavior
- [Barriers](barrier.md)
  - `barrier(pipe)` and `bar_*` helpers
  - single-pipe ordering vs `Pipe.ALL` drain behavior
- [Atomic Context Managers](atomic.md)
  - `atomic_add`, `atomic_max`, and `atomic_min`
  - atomic writeback scope mechanics and supported GM-store paths
- [Miscellaneous Helpers](helpers.md)
  - `sim_print`, `sim_dump_tensor`, `kernel_print`, `kernel_dump_tensor`, `inline`, `clean_dcache`, and `set_hf32`
  - simulator-only debug helpers (`sim_*`), codegen-only debug helpers (`kernel_*`), backend escape hatches, cache maintenance, and HF32 mode control
- [Cube Data Movement and Compute](cube.md)
  - cube data movement, packed-layout conversion, contiguous GM->L1 helpers, bias-table staging, `mmad`, and MX FP8 / MXFP4 low-level staging
  - `DualMode` / `DualModeType` and `l0c_to_ub` routing
- [A2 Vector Math](a2_vec_math.md)
  - binary, unary, scalar, duplication, and group vector operators
- [A2 and Shared Vec Data Movement](vec_data_movement.md)
  - GM/UB/L1 transfer helpers
  - `gm_to_ub_pad`, `ub_to_gm_pad`, `ub_to_ub`
  - `ub_to_l1`, `ub_to_l1_nd2nz`, `ub_to_l1_nz`
- [A2 and Shared Vec Control and Access Helpers](a2_vec_control.md)
  - A2 vec cast/compare/select/gather/scatter plus shared vec mask helpers
- [Shared Vec Sort and Merge Helpers](vec_sort.md)
  - `sort32`
  - `mergesort4`
  - `mergesort_2seq`
- [A5 Micro Math](a5_micro_math.md)
  - register math, shifts, fused helpers, and reductions (compare/select live in [A5 Micro Compare and Select](a5_micro_compare_select.md))
- [A5 Micro Data Movement](a5_micro_data_movement.md)
  - UB/register transfer, `squeeze`, `clear_spr`, and `pack` / `HighLowPart`
  - gather/scatter helpers
  - interleave helpers
  - `vf_barrier`, `VfPipe`, and `VfPipeType`
- [A5 Micro Cast](a5_micro_cast.md)
  - `CastConfig`, `RegLayout`, and `MaskMergeMode`
  - `RoundMode` and `RoundModeType`
  - micro `cast()` and `Reg.astype()`
  - `pack4()` in fp8/int8 cast pipelines
- [A5 Micro Compare and Select](a5_micro_compare_select.md)
  - `compare` and `select`
  - compare modes, execution masks, and alias-safe select semantics
- [A5 Micro Mask Operations](a5_micro_mask_operations.md)
  - mask boolean ops, routing, pack/unpack, and `update_mask`

## Recommended Reading Order

If you are new to the framework:

1. read [decorators.md](decorators.md)
2. read [flow_control.md](flow_control.md)
3. read [op_exec.md](op_exec.md)
4. read [shortcuts.md](shortcuts.md)
5. read [scalars.md](scalars.md)
6. read [datatype.md](datatype.md)
7. read [position.md](position.md)
8. read [pipe.md](pipe.md)
9. read [var.md](var.md)
10. read [tensor_buffer.md](tensor_buffer.md)
11. read [register.md](register.md)
12. read [synchronize.md](synchronize.md)
13. read [barrier.md](barrier.md)
14. read [atomic.md](atomic.md)
15. read [helpers.md](helpers.md)
16. read [vec_data_movement.md](vec_data_movement.md) — shared GM/UB/L1 transfer helpers used by both surfaces (`gm_to_ub_pad`, `ub_to_gm_pad`, `ub_to_ub` are exported from both; the A5 family also adds `gm_to_ub_nd_dma`, transpose sugar `ub <<= gm.T`, and `ub_to_l1` / `ub_to_l1_nd2nz` / `ub_to_l1_nz`)
17. choose either:
   - `a2` path: [a2_vec_math.md](a2_vec_math.md), [a2_vec_control.md](a2_vec_control.md), and [vec_sort.md](vec_sort.md)
   - A5-family path: [a5_micro_math.md](a5_micro_math.md), [a5_micro_data_movement.md](a5_micro_data_movement.md), [a5_micro_cast.md](a5_micro_cast.md), [a5_micro_compare_select.md](a5_micro_compare_select.md), and [a5_micro_mask_operations.md](a5_micro_mask_operations.md)
18. return to [cube.md](cube.md) when your kernel starts crossing cube memory domains or needs exact packed-layout behavior
19. read [../topics/mxfp.md](../topics/mxfp.md) before using the A5-family MX FP8 / MXFP4 `matmul_mx` path
20. on the A5-family path, read [simt.md](simt.md) when authoring a thread-parallel `@simt` body

## Import Surface Summary

### `easyasc.a2`

Use `a2` when you want:

- kernel authoring against the A2-style architecture and instruction sequences
- direct vec function calls such as `add`, `abs`, `gather`, and `compare`
- the A2-specific public DSL surface, which is parallel to `a5` rather than a compatibility subset of it

Use `a3` for the same A2/C220 authoring API on Ascend 910C
`Ascend910_9362`; it selects 20 cube / 40 vec workers and the
`ascend910_93` compile unit.

Unless a page explicitly discusses a B-series SoC or compile unit, its
`easyasc.a2` API contract also applies to the re-exported `easyasc.a3` surface.

### A5 family: `easyasc.a5` and `easyasc.a5pr`

Use `a5` when you want:

- everything from the main kernel authoring path
- `@vf` micro helpers
- `Reg`, `RegList`, `MaskReg`, and `CastConfig`
- micro-level register and mask operations
- `ub_to_l1` / `ub_to_l1_nd2nz` / `ub_to_l1_nz`

Use `a5` for Ascend 950 and `a5pr` for Ascend 950PR. They expose the same
authoring API but select different device profiles and worker counts.

## Conventions Used In This Reference

- `UB`, `L1`, `L0A`, `L0B`, `L0C`, and `BT` refer to `Position` values.
- "Inference" means the function computes a missing parameter from the current tensor shape or slice metadata.
- "Context restriction" means the function only works inside a `@kernel`, `@vf`, or other active DSL context.
