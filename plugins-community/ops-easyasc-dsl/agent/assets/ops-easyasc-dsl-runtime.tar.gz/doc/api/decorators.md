# Decorators

This page documents the public decorators shared across the `easyasc` authoring surface.

These decorators define the main authoring contexts used by the framework:

- kernel entry points
- reusable helper functions
- auto-sync-marked regions
- reusable micro modules
- reusable SIMT modules (A5 family only: `easyasc.a5` / `easyasc.a5pr`)

## 1. `kernel()`

- Purpose: Wrap a Python function as a kernel entry point and return a `KernelBase`-backed callable.
- Parameters:
  - no required decorator arguments in normal use; the usual form is `@kernel()`
- Restrictions:
  - the decorated function must be callable
  - the decorated function name must not contain uppercase letters
  - when the kernel is invoked through the framework, its bound arguments must resolve to `GMTensor` and `Var`
  - kernel code should be written inside the decorated function body, not outside it
- Example:

```python
from easyasc.a5 import *


@kernel()
def copy_kernel(x: GMTensor, y: GMTensor, M: Var, N: Var):
    ub = Tensor(DT.float, [M, N], Position.UB)
    ub <<= x[:, :]
    y[:, :] <<= ub
    return y
```

## 2. `func()`

- Purpose: Apply the same Python-to-DSL transformation as `@kernel`, but keep the function as a helper instead of a kernel entry point.
- Parameters:
  - no required decorator arguments in normal use; the usual form is `@func()`
- Restrictions:
  - use it for reusable instruction-emitting helpers inside an active kernel or micro context
  - it does not create a kernel wrapper and cannot be executed as a standalone kernel
- Example:

```python
@func()
def zero_l1(buf: Tensor):
    set_constant_to_l1(buf, 0.0)
```

## 3. `auto_sync()`

- Purpose: Mark a region or helper call so the parser can later insert supported same-side synchronization events.
- Parameters:
  - no required decorator arguments in normal use; the usual forms are `@auto_sync()` and `with auto_sync():`
  - optional `mode`: `"conservative"` (default), `"aggressive"`, `"fix_storage"`, or `"manual_fix"`
- Restrictions:
  - only valid inside kernel code
  - does not solve cube-to-vec or vec-to-cube ownership by itself
  - only the hard-coded pipe pairs in `asc_autosync.py` are handled
  - `"aggressive"` changes cube-side L0 grouping and groups Fix ownership by the physical L0C allocation
  - `"fix_storage"` changes only the Fix grouping while retaining conservative L0 scheduling
  - `"manual_fix"` retains conservative L1/L0 scheduling but emits no `M -> FIX` events; the kernel must provide both result-ready and L0C-reuse events explicitly
- Example:

```python
with auto_sync():
    l1x <<= x[:, :]
    l1y <<= y[:, :]
    matmul(l0c, l1x, l1y)
    z[:, :] <<= l0c
```

Mode override example:

```python
with auto_sync(mode="aggressive"):
    l0a <<= l1a
    l0b <<= l1b
    mmad(l0c, l0a, l0b, M=M, N=N, K=K)
```

Use `mode="fix_storage"` when runtime branches access views of the same L0C
allocation and Fix ownership must follow that backing storage without changing
the conservative `MTE1 -> M` schedule.

Use `mode="manual_fix"` only when the kernel explicitly implements both
`M -> FIX` result readiness and `FIX -> M` L0C reuse. Missing either direction
is a race that simulator arithmetic may not expose.

## 4. `vf()`

- Purpose: Wrap a function as a reusable micro module.
- Parameters:
  - no decorator arguments; the form is `@vf()`
- Restrictions:
  - only available from the A5-family facades (`easyasc.a5` and `easyasc.a5pr`)
  - micro functions only accept UB `Tensor` inputs and `Var`-like scalar inputs
  - micro code uses `Reg`, `RegList`, and `MaskReg`, not cube-side `Tensor` math
- Example:

```python
@vf()
def add_one(src: Tensor, dst: Tensor):
    r = Reg(DT.float)
    r <<= src[0]
    r <<= r + 1.0
    dst[0] <<= r
```

## 5. `simt(num_threads=1024)`

- Purpose: Wrap a function as a reusable SIMT module that the codegen lowers to a thread-parallel `__simt_vf__` kernel and the simulator interprets through its own AST lowering.
- Parameters:
  - `num_threads`: `int`; must be one of `(128, 256, 512, 1024, 2048)`; defaults to `1024`
- Restrictions:
  - only available from the A5-family facades (`easyasc.a5` and `easyasc.a5pr`); calling a `@simt`-wrapped function on a `b*` (a2) device raises `RuntimeError`
  - the wrapped function must take only positional parameters annotated as `GMTensor`, `Tensor`, or `Var` (no defaults, no `*args`, no `**kwargs`)
  - the body uses a restricted Python AST (statements, expressions, dtype rules, supported intrinsics) — see [SIMT Modules](simt.md) for the full subset
- Example:

```python
@simt(num_threads=1024)
def axpy_simt(x_ub: Tensor, y_ub: Tensor, out_ub: Tensor, alpha: Var, n: Var):
    for i in range(simt_thread_id(), n, simt_thread_num()):
        out_ub[i] = x_ub[i] * alpha + y_ub[i]
```

For the runtime / codegen contract and the supported AST subset, see
[SIMT Modules](simt.md).
