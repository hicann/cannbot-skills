# Miscellaneous Helpers

This page documents seven small but important helper APIs:

- `sim_print`
- `sim_dump_tensor`
- `kernel_print`
- `kernel_dump_tensor`
- `inline`
- `clean_dcache`
- `set_hf32`

They are grouped together because they are not data-movement primitives, not synchronization primitives, and not math primitives. They exist mainly for debugging, instrumentation, and backend escape hatches.

Availability: all seven helpers are exported by `easyasc.a2` and both
A5-family facades (`easyasc.a5` and `easyasc.a5pr`).

`sim_*` helpers are simulator-only (their codegen handlers are no-ops). `kernel_*` helpers are codegen-only (the simulator does not execute them). Keep that distinction in mind when reading the rest of this page.

## 1. `sim_print(*args, pipe=Pipe.S)`

- Purpose: print simulator-side debug information associated with one pipe or with the main loop.
- Parameters:
  - `*args`: arbitrary payload items to print
  - `pipe`: `PipeType`, default `Pipe.S`
- Validation:
  - `pipe` must be a `PipeType`
- Instruction emission:
  - emits `Instruction("sim_print", payload=list(args), pipe=pipe)`

### What it does in simulator mode

When the simulator executes the instruction:

- payload items are resolved into printable runtime values where possible
- scalar DSL objects such as `Var` and `Expr` are resolved first
- the final message is built by joining all payload items with spaces

The log prefix depends on the execution side:

- cube:
  - `[cube][core=<core_idx>] ...`
  - if `pipe != Pipe.S`, an extra `[pipe=<pipe>]` segment is added
- vec:
  - `[vec][core=<core_idx>][subblock=<subblock_idx>] ...`
  - if `pipe != Pipe.S`, an extra `[pipe=<pipe>]` segment is added

So a call such as:

```python
sim_print("row_count", row_count, pipe=Pipe.V)
```

might produce a line conceptually like:

```text
[vec][core=0][subblock=1][pipe=V] row_count 32
```

### What it does in codegen mode

`sim_print` is intentionally simulator-only.

Its parser handler is a no-op:

- no backend C++ line is emitted
- no runtime print helper is generated

That means:

- `sim_print` is useful for local simulator debugging
- it should not be treated as part of the generated kernel's observable behavior

### Pipe semantics

`pipe` controls where the print is attached:

- `Pipe.S`:
  - print on the main loop side
  - useful for scalar state, control flow, and synchronization debugging
- non-`S` pipe:
  - print is attached to that pipe queue when possible
  - useful for seeing when a producer/consumer pipe actually reaches a point

Practical interpretation:

- `pipe=Pipe.S` is good for high-level debugging
- `pipe=Pipe.MTE2`, `Pipe.V`, `Pipe.M`, `Pipe.FIX`, and so on are better when you want pipe-local timing context

### What can be printed

The API accepts arbitrary Python objects, but the most useful payloads are:

- strings
- `int`, `float`, `bool`
- `Var` and `Expr`
- `PipeType`
- short tuples/lists of scalar-like values

Printing large tensors is not what `sim_print` is for. Use `sim_dump_tensor` for simulator-only dumps or `kernel_dump_tensor` for generated-code dumps.

### Typical use cases

- inspect loop counters or inferred tile sizes
- confirm which pipe reaches a point first
- debug cross-side or event ordering
- inspect scalar values after a reduction or shape calculation

### Example: control-side debugging

```python
sim_print("tile", tile_idx, "valid_m", valid_m, pipe=Pipe.S)
```

Use this when the interesting information is mostly scalar and belongs to the scheduler/main-loop view of the kernel.

### Example: pipe-local debugging

```python
sim_print("issued gm_to_ub for tile", tile_idx, pipe=Pipe.MTE2)
sim_print("starting vec postprocess", tile_idx, pipe=Pipe.V)
```

This is useful when you want the simulator log to carry pipe identity explicitly.

## 2. `sim_dump_tensor(tensor, filename, pipe)`

- Purpose: dump a runtime tensor view to disk during simulation.
- Parameters:
  - `tensor`: source `Tensor`
  - `filename`: output filename string
  - `pipe`: `PipeType`
- Validation:
  - `tensor` must be a `Tensor`
  - `filename` must be a `str`
  - `pipe` must be a `PipeType`
  - `pipe` cannot be `Pipe.ALL`
- Instruction emission:
  - emits `Instruction("sim_dump_tensor", tensor=tensor, filename=filename, pipe=pipe)`

### What gets dumped

At execution time, the simulator:

- resolves the current runtime tensor view
- clones it
- writes it with `torch.save(...)`

So the file contains the resolved runtime tensor contents, not a symbolic DSL object.

Important implications:

- slicing, reinterpret views, transpose metadata, and current offsets have already been applied when the runtime view is built
- the dumped data corresponds to the tensor view visible at that exact program point
- later mutations do not change an already dumped file

### What it does in codegen mode

Like `sim_print`, `sim_dump_tensor` is a no-op during code generation:

- the parser handler emits nothing
- no generated backend code is produced for it

So `sim_dump_tensor` is a simulator debugging tool, not a generated-kernel feature. If you need a runtime dump that survives codegen, use `kernel_dump_tensor` (§4) instead.

### Pipe semantics

`pipe` determines where the dump instruction executes:

- `Pipe.S`:
  - the dump happens from the main loop
- non-`S` pipe:
  - the dump is dispatched into the matching pipe queue when supported

This matters if you are trying to capture a tensor at the moment a specific pipe reaches a point, rather than when the main loop reaches that point.

`Pipe.ALL` is rejected because a tensor dump is a single execution event, not a barrier-style all-pipe operation.

### Simulator behavior details

Both cube and vec simulators support two paths:

- main-loop path:
  - if `pipe == Pipe.S`, the simulator immediately resolves the runtime tensor and calls `torch.save`
- dispatched pipe path:
  - otherwise the instruction is queued on the target pipe
  - when the pipe executes it, it performs the same `torch.save(tensor.detach().clone(), filename)`

If the chosen pipe is unsupported on that simulator side, execution raises an error such as:

- `sim_dump_tensor has unsupported pipe on cube simulator: ...`
- `sim_dump_tensor has unsupported pipe on vec simulator: ...`

### Filename behavior

`filename` is used exactly as passed to `torch.save`.

Practical guidance:

- prefer explicit, unique names
- include tile or stage information in the name when dumping multiple states
- remember that repeated dumps to the same path overwrite the earlier file

### Typical use cases

- inspect intermediate UB data after vec math
- capture L1/UB handoff results around synchronization edges
- compare simulator state against a Python reference implementation
- debug layout-sensitive operations such as reinterpretation or packed transfers

### Example: dump a UB tensor after vec processing

```python
sim_dump_tensor(ub_out, "ub_out_tile0.pt", Pipe.V)
```

Meaning:

- attach the dump to the `V` pipe
- when the `V` pipe executes that point, save the current runtime view of `ub_out`

### Example: dump from the main loop

```python
sim_dump_tensor(ub_mid, "ub_mid_mainloop.pt", Pipe.S)
```

Use this when you want the dump aligned with control flow rather than a specific pipe queue.

## 3. `kernel_print(fmt, *args)`

- Purpose: emit a `printf` call into the generated cube/vec C++ output for runtime debug.
- Parameters:
  - `fmt`: format string passed verbatim to `printf`
  - `*args`: optional payload values inserted as `printf` arguments
- Validation:
  - `fmt` must be a `str`
- Instruction emission:
  - emits `Instruction("kernel_print", fmt=fmt, payload=list(args))`

### What it does in codegen mode

The parser lowers the instruction into a literal `printf` call in the generated source:

- `kernel_print("hello")` → `printf("hello");`
- `kernel_print("tile=%d", tile_idx)` → `printf("tile=%d", tile_idx);`

The format string is encoded as a C++ string literal. Each payload value is lowered through the standard expression-to-C++ pipeline, so `Var`, `int`, and `float` arguments all work.

### What it does in simulator mode

The simulator does not execute `kernel_print`. There is no Python-side log line; the call is purely a backend artifact.

### When to use it vs `sim_print`

- use `sim_print` when you only need simulator-time visibility (it is richer and pipe-aware, but disappears from generated code)
- use `kernel_print` when you need the print to appear in the generated cube/vec binary's stdout (it is a thin `printf`, no pipe routing)

### Example

```python
kernel_print("processing tile %d / %d\n", tile_idx, tile_count)
```

The corresponding generated line is:

```cpp
printf("processing tile %d / %d\n", tile_idx, tile_count);
```

## 4. `kernel_dump_tensor(src, desc, dumpSize)`

- Purpose: emit a backend `DumpTensor(...)` call so the runtime can dump tensor contents during a real device run.
- Parameters:
  - `src`: source `GMTensor` or local `Tensor`
  - `desc`: `int` or `Var` descriptor id (passed as `uint32_t`)
  - `dumpSize`: `int` or `Var` element count to dump (passed as `uint32_t`)
- Validation:
  - `src` must be a `GMTensor` or a `Tensor`
  - if `src` is a `Tensor`, its `position` must be `UB`, `L1`, or `L0C`
  - `desc` and `dumpSize` must each be `int` or `Var`
- Instruction emission:
  - emits `Instruction("kernel_dump_tensor", src=src, desc=desc, dumpSize=dumpSize)`

### What it does in codegen mode

The parser lowers the instruction into a literal `DumpTensor` call:

```cpp
DumpTensor(<src_expr>, (uint32_t) <desc_expr>, (uint32_t) <dumpSize_expr>);
```

`<src_expr>` is the lowered expression for the source tensor view (a global tensor, a UB tensor, an L1 tensor, or an L0C tensor). `desc` and `dumpSize` are casted to `uint32_t` regardless of whether they are `int` literals or scalar `Var` values.

### What it does in simulator mode

The simulator does not execute `kernel_dump_tensor`. Use `sim_dump_tensor` (§2) when you need a simulator-side `torch.save`.

### When to use it vs `sim_dump_tensor`

- use `sim_dump_tensor` when you want a `torch.save` from the Python-side simulator
- use `kernel_dump_tensor` when you want the backend's `DumpTensor` runtime helper to run in the generated kernel

### Example

```python
kernel_dump_tensor(ub_out, 0, BLK * N)
```

Meaning:

- generated cube/vec code calls `DumpTensor(<ub_out>, (uint32_t) 0, (uint32_t) BLK * N);`
- the simulator path skips this instruction

## 5. `inline(code)`

- Purpose: inject raw backend code directly into the generated output.
- Parameters:
  - `code`: string containing one or more lines of backend code
- Validation:
  - `code` must be a `str`
  - when used inside `@vf`, `inline` is captured into the micro module
- Instruction emission:
  - emits `Instruction("inline", code=code)`

`inline` is fundamentally different from `sim_print` and `sim_dump_tensor`:

- it matters only in codegen mode
- the simulator ignores it

### What it does in codegen mode

The parser handler takes the string and emits it line by line into the generated backend output.

Behavior details:

- if `code == ""`, it emits a blank line
- otherwise each line from `code.splitlines()` is passed through directly
- no syntax checking is performed by the DSL layer

So `inline` is a true escape hatch: the framework inserts your text exactly where that instruction lands in the lowered stream.

### What it does in simulator mode

The cube, vec, and micro simulators all ignore `inline` completely:

- it does not affect runtime state
- it does not print anything
- it does not change scheduling

So never rely on `inline` for simulator-visible behavior.

### Where it is commonly used

- temporary backend experiments
- custom comments or markers in generated code
- bridging a backend feature that does not yet have a first-class DSL helper

The framework itself also uses `inline` internally for generated markers around auto-inserted declarations.

### Risks and limitations

- your string is backend-specific
- the DSL does not validate semantics
- the simulator cannot help you verify behavior
- injected code may become stale if the generated surrounding structure changes later

That is why `inline` should be a last resort rather than a normal authoring tool.

### Example: add a backend comment marker

```python
inline("// custom marker before manual backend fragment")
```

This is the safest style of use because it does not change runtime semantics.

### Example: multi-line injection

```python
inline(
    "int local_debug_value = 3;\n"
    "(void)local_debug_value;"
)
```

The handler will emit those two lines exactly into the generated output.

## 6. `clean_dcache(dst, entire_type=EntireType.single, dcci_dst=DcciDst.all, mode="all")`

- Purpose: emit an explicit backend data-cache clean-and-invalidate request for a GM tensor target.
- Parameters:
  - `dst`: destination `GMTensor`
  - `entire_type`: `EntireTypeValue`, default `EntireType.single`
  - `dcci_dst`: `DcciDstType`, default `DcciDst.all`
  - `mode`: `str`, default `"all"`, must be one of `"all"`, `"vec"`, or `"cube"`
- Validation:
  - `dst` must be a `GMTensor`
  - `entire_type` must be an `EntireTypeValue`
  - `dcci_dst` must be a `DcciDstType`
  - `mode` must be a `str`
  - `mode` must be one of `"all"`, `"vec"`, or `"cube"`
- Instruction emission:
  - emits `Instruction("clean_dcache", dst=dst, entire_type=entire_type, dcci_dst=dcci_dst, mode=mode)`

### What it does in codegen mode

The parser lowering emits a backend call in the form:

```text
DataCacheCleanAndInvalid<{dst_dtype}, AscendC::CacheLine::{entire_type}, AscendC::DcciDst::{dcci_dst}>({dst_expr});
```

For A2 output-cache maintenance, use the output-cache destination:

```python
clean_dcache(global_out, EntireType.single, DcciDst.out, mode="vec")
```

can lower conceptually to:

```text
DataCacheCleanAndInvalid<float, AscendC::CacheLine::SINGLE_CACHE_LINE, AscendC::DcciDst::CACHELINE_OUT>(global_out);
```

On A2, a cache line is 64 bytes. If a scalar GM access genuinely requires
DCCI, allocate a 64-byte backing region in the host wrapper before exposing the
scalar view, so the cacheline operation cannot extend beyond owned storage. Do
not infer that DCCI is needed from output size alone. Huawei documents
`CACHELINE_OUT` as the output-cache consistency target and marks
`CACHELINE_ATOMIC` as reserved/unsupported; do not use `DcciDst.atomic` as the
normal A2 output policy. DMA data moves access GM directly, so add DCCI for
scalar/DCache consistency boundaries rather than around every DMA.

Reference: [Huawei DataCacheCleanAndInvalid API](https://www.hiascend.com/document/detail/en/canncommercial/850/API/ascendcopapi/atlasascendc_api_07_0177.html).

The dtype comes from `dst.dtype`, and the final argument is the lowered GM tensor expression for `dst`.

The `mode` parameter controls which split-side code receives the emitted backend call:

- `mode="all"`: emit on both cube and vec sides
- `mode="vec"`: emit on vec side only
- `mode="cube"`: emit on cube side only

### What it does in simulator mode

The simulator ignores `clean_dcache` completely:

- it does not mutate tensor payloads
- it does not change scheduling
- it does not simulate cache state

So `clean_dcache` is currently a codegen-only helper.

### Typical use cases

- bridge an exposed backend cache-maintenance primitive that the DSL needs to call explicitly
- choose cache-line scope with `EntireType.single` vs `EntireType.entire`
- choose destination policy with `DcciDst.all`, `DcciDst.ub`, `DcciDst.out`, or `DcciDst.atomic`
- for A2 output synchronization, prefer `DcciDst.out`; `DcciDst.atomic` is not a supported normal target

## 7. `set_hf32(enable=True)`

- Purpose: emit a backend HF32 mode switch for fp32 cube matmul paths.
- Parameters:
  - `enable`: `bool`, default `True`
- Validation:
  - `enable` must be a `bool`
- Instruction emission:
  - emits `Instruction("set_hf32", enable=enable)`

### What it does in codegen mode

The parser lowering emits:

```text
SetHF32Mode(true);
```

or:

```text
SetHF32Mode(false);
```

HF32 enables a special fp32 format on hardware. It can speed up fp32 matmul compute, but it slightly reduces precision compared with regular fp32 mode.

### What it does in simulator mode

The simulator ignores `set_hf32` completely:

- it does not change numeric behavior
- it does not change scheduling
- it does not emit a simulator runtime instruction

So `set_hf32` is currently a codegen-only hardware mode helper.

## 8. Choosing Between Them

Use `sim_print` when:

- you want lightweight simulator log output
- the thing you care about is mostly scalar or textual

Use `sim_dump_tensor` when:

- you need the actual runtime tensor contents during simulation
- you want to inspect values offline with `torch.load`

Use `kernel_print` when:

- you need a `printf` to land in the generated cube/vec binary
- the simulator path can ignore the message

Use `kernel_dump_tensor` when:

- you need the backend `DumpTensor` helper to run on real hardware
- the simulator path can ignore the dump

Use `inline` when:

- you need a backend escape hatch during code generation
- the DSL does not already expose the operation you need

Use `clean_dcache` when:

- you need the generated kernel to emit an explicit cache clean/invalidate call
- you want that call to stay structured rather than handwritten through `inline`
- scalar-unit GM access creates an actual DCache/GM consistency boundary; a
  small DMA transfer alone is not such a boundary

Use `set_hf32` when:

- you want generated hardware code to enable or disable the faster HF32 fp32 matmul mode
- you accept the small precision tradeoff from the special fp32 format

## 9. See Also — Storage Helpers Documented Elsewhere

The following top-level helpers are exported from `easyasc.a2` and both
A5-family facades, but are documented in
[`tensor_buffer.md §2`](tensor_buffer.md) because they manipulate tensor-backed
storage rather than acting as debug/codegen escape hatches.

- [`reset_cache()`](tensor_buffer.md) — drop the kernel's local-allocation accounting so subsequent `Tensor(...)` declarations reuse the same on-chip region.
- [`split_workspace(dtype, shape, name="")`](tensor_buffer.md) — carve a named GM workspace slice from the kernel-owned workspace region and return it as a `GMTensor`.
- [`reinterpret(src, target_dtype, name="")`](tensor_buffer.md) — build a dtype-reinterpreted `Tensor` view over the same storage, rescaling the inner dimension by the dtype packing factor.

## 10. Common Pitfalls

- Do not expect `sim_print` or `sim_dump_tensor` to appear in generated backend code. Their handlers are no-ops in codegen.
- Do not expect `kernel_print` or `kernel_dump_tensor` to produce simulator output. The simulator skips them entirely.
- Do not expect `inline` to affect simulator behavior. The simulator explicitly ignores it.
- Do not expect `clean_dcache` to affect simulator results. It is intentionally skipped in simulation.
- Do not expect `set_hf32` to affect simulator results. It is intentionally skipped in simulation.
- Do not use `sim_dump_tensor(..., pipe=Pipe.ALL)`. Dumps are single execution actions, not all-pipe barriers.
- Do not rely on `inline` for portable behavior; kernel-scope and `@vf` micro-scope inline fragments are emitted as raw backend text.
- Do not use `sim_print` for large tensor payloads. It is for small debug payloads; use `sim_dump_tensor` for actual tensor data.
- Do not confuse `sim_print` with `kernel_print`, or `sim_dump_tensor` with `kernel_dump_tensor`. Each pair has a simulator-only and a codegen-only member; they are not interchangeable.
