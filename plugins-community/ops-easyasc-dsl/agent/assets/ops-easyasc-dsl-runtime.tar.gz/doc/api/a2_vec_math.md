# A2 Vector Math

This page covers the UB vector math helpers exported directly by `easyasc.a2`.

Important scope note:

- these names are top-level functions in `a2`
- the same names in `a5` usually refer to micro register operations instead

When `repeat` / `*_stride` are omitted, most A2 vec helpers use the auto-infer
rules from `easyasc/stub_functions/vec/vecutils.py`:

- float `span[1] == 64` -> `blk_stride=1`, `rep_stride=shape[1] // 8`
- float `span[1] == 8` -> `blk_stride=0`, `rep_stride=shape[1] // 8`
- half `span[1] == 128` -> `blk_stride=1`, `rep_stride=shape[1] // 16`
- half `span[1] == 16` -> `blk_stride=0`, `rep_stride=shape[1] // 16`
- if `span[0] == 1` and one of the special cases matched, `rep_stride=0`

Consequence: narrow broadcast views such as float `[M, 8]` or half `[M, 16]`
are not dense physical storage under default inference; they alias one C0 block
per repeat. Keep row-scalar state in `[1, M]`, then use `brcb(...)` to
materialize the broadcast view when needed. For the full model and mixed-width
examples, see `agent/references/constraints/vec.md`.

## Mask behavior summary

Before reading individual APIs, keep this current simulator summary in mind:

- Binary / unary / unary-scalar / `dup`
  - consume the current vec mask at dst writeback
  - masked-off lanes keep the previous `dst` value
- Group reductions
  - `cadd`, `cgadd`, `cpadd`: masked-off source slots contribute `0`
  - `cmax`, `cgmax`: masked-off source slots behave like `-inf`
  - `cmin`, `cgmin`: masked-off source slots behave like `+inf`
  - when an entire active reduction domain is masked off, the corresponding `dst` slot is not overwritten
- `brcb`
  - currently ignores the current vec mask state
- Related control ops documented on the A2 vec control page
  - `compare`, `compare_scalar`, `select`, `gather`, and `scatter` currently ignore the current vec mask state

## 1. Shared Binary Vec Parameters

The following functions share the same parameter shape:

- `add`
- `sub`
- `mul`
- `div`
- `vmax`
- `vmin`
- `vand`
- `vor`
- `muladddst`

Shared parameters:

- `dst`: destination UB `Tensor`
- `src1`, `src2`: source UB `Tensor`
- `repeat`: optional repeat count; inferred from `dst` when omitted
- `*_blk_stride`: optional block strides
- `*_rep_stride`: optional repeat strides

Shared restrictions:

- `dst`, `src1`, and `src2` must all be `Tensor` in `Position.UB`
- all three dtypes must match
- every stride or repeat parameter must be `int` or `Var` when provided
- these ops consume the current vec mask at dst writeback; masked-off lanes keep the previous `dst` value

### `add(dst, src1, src2, ...)`

- Purpose: Elementwise vector add, `dst = src1 + src2`.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int16`, `int`
- Example:

```python
add(dst, src1, src2)
```

### `sub(dst, src1, src2, ...)`

- Purpose: Elementwise vector subtract, `dst = src1 - src2`.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int`
- Example:

```python
sub(dst, src1, src2)
```

### `mul(dst, src1, src2, ...)`

- Purpose: Elementwise vector multiply, `dst = src1 * src2`.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int`
- Example:

```python
mul(dst, src1, src2)
```

### `div(dst, src1, src2, ...)`

- Purpose: Elementwise vector divide, `dst = src1 / src2`.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
div(dst, src1, src2)
```

### `vmax(dst, src1, src2, ...)`

- Purpose: Elementwise vector max between two tensors.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int`
- Example:

```python
vmax(dst, src1, src2)
```

### `vmin(dst, src1, src2, ...)`

- Purpose: Elementwise vector min between two tensors.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int`
- Example:

```python
vmin(dst, src1, src2)
```

### `vand(dst, src1, src2, ...)`

- Purpose: Elementwise bitwise and on vector tensors.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `int16_t`, `uint16_t`
  - A2 high-dimensional `And` does not accept `int32_t`/`uint32_t` directly;
    reinterpret all operands to the matching 16-bit view first. The view doubles
    the last logical dimension, so the operation covers both halves of each
    original 32-bit element.
- Example:

```python
vand(dst, src1, src2)
# Equivalent expression form:
dst <<= src1 & src2
```

### `vor(dst, src1, src2, ...)`

- Purpose: Elementwise bitwise or on vector tensors.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `int16_t`, `uint16_t`
  - A2 high-dimensional `Or` does not accept `int32_t`/`uint32_t` directly;
    use the same explicit 16-bit reinterpret path described for `vand`
- Example:

```python
vor(dst, src1, src2)
# Equivalent expression form:
dst <<= src1 | src2
```

### `muladddst(dst, src1, src2, ...)`

- Purpose: Multiply `src1` and `src2`, then accumulate into `dst`.
- Parameters: use the shared binary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
  - use it only when `dst` already contains the value you want to accumulate into
- Example:

```python
muladddst(dst, src1, src2)
```

## 2. Shared Unary Vec Parameters

The following functions share this parameter pattern:

- `exp`
- `ln`
- `abs`
- `rec`
- `sqrt`
- `rsqrt`
- `vnot`
- `relu`

Shared parameters:

- `dst`: destination UB `Tensor`
- `src`: source UB `Tensor`
- `repeat`: optional repeat count
- `dst_blk_stride`, `src_blk_stride`: optional block strides
- `dst_rep_stride`, `src_rep_stride`: optional repeat strides

Shared restrictions:

- `dst` and `src` must be UB tensors
- `dst.dtype` must equal `src.dtype`
- these ops consume the current vec mask at dst writeback; masked-off lanes keep the previous `dst` value

### `exp(dst, src, ...)`

- Purpose: Elementwise exponential.
- Parameters: use the shared unary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
exp(dst, src)
```

### `ln(dst, src, ...)`

- Purpose: Elementwise natural logarithm.
- Parameters: use the shared unary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
ln(dst, src)
```

### `abs(dst, src, ...)`

- Purpose: Elementwise absolute value.
- Parameters: use the shared unary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
abs(dst, src)
```

### `rec(dst, src, ...)`

- Purpose: Elementwise reciprocal.
- Parameters: use the shared unary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
rec(dst, src)
```

### `sqrt(dst, src, ...)`

- Purpose: Elementwise square root.
- Parameters: use the shared unary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
sqrt(dst, src)
```

### `rsqrt(dst, src, ...)`

- Purpose: Elementwise reciprocal square root.
- Parameters: use the shared unary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
rsqrt(dst, src)
```

### `vnot(dst, src, ...)`

- Purpose: Elementwise bitwise not.
- Parameters: use the shared unary vec parameter set above.
- Restrictions:
  - supported dtypes: `int16_t`, `uint16_t`
  - for `int32_t`/`uint32_t`, reinterpret source and destination to the matching
    16-bit view before calling `vnot`
- Example:

```python
vnot(dst, src)
```

### `relu(dst, src, ...)`

- Purpose: Elementwise relu.
- Parameters: use the shared unary vec parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
relu(dst, src)
```

## 3. Shared Unary-Scalar Vec Parameters

The following functions share this parameter pattern:

- `adds`
- `muls`
- `shiftls`
- `shiftrs`
- `vmaxs`
- `vmins`
- `lrelu`
- `axpy`

Shared parameters:

- `dst`: destination UB `Tensor`
- `src`: source UB `Tensor`
- `val`: scalar `int`, `float`, or `Var`
- `repeat`: optional repeat count
- stride parameters: optional vec stride metadata
- `count`: optional contiguous prefix length in counter mode
- `count_per_rep`: optional active lane count per repeat; mutually exclusive with `count`

Shared restrictions:

- `dst` and `src` must be UB tensors
- `dst.dtype` must equal `src.dtype`
- scalar type must be compatible with the tensor dtype
- these ops consume the current vec mask at dst writeback; masked-off lanes keep the previous `dst` value

### `adds(dst, src, val, ...)`

- Purpose: Add a scalar to each element.
- Parameters: use the shared unary-scalar parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int`
- Example:

```python
adds(dst, src, 1.0)
```

### `muls(dst, src, val, ...)`

- Purpose: Multiply each element by a scalar.
- Parameters: use the shared unary-scalar parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int`
- Example:

```python
muls(dst, src, 2.0)
```

### `shiftls(dst, src, val, ..., *, count=None, count_per_rep=None)`

- Purpose: Shift every integer element left by `val` bits.
- Parameters: use the shared unary-scalar parameter set above.
- Restrictions:
  - supported dtypes: `int16_t`, `uint16_t`, `int32_t`, `uint32_t`
  - a Python `int` shift is checked statically; the range is `[0, 16]` for
    16-bit tensors and `[0, 32]` for 32-bit tensors
  - a `Var` shift must have an integer dtype; codegen casts it to the tensor
    dtype required by AscendC, and its runtime value must satisfy the same range
  - use `DT.int` for an `OpExec`-bound dynamic shift count; the current generated
    tiling ABI does not preserve narrower integer `Var` parameter types
  - unsigned values use logical left shift
- Real-A2 note: on the validated 910B3/CANN 9.0 path,
  `ShiftLeft<int16_t, false>` shifted the complete fixed-width bit pattern in
  both externally managed count and repeat modes. In particular, input
  `0xAAAA` shifted by one produced `0x5554`, so overflow can change the sign
  bit. This differs from the sign-preserving worked example on the current
  [AscendC ShiftLeft page](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0058.html);
  the EasyASC simulator follows the observed 910B3 result.
- Example:

```python
shiftls(dst, src, 3, count=element_count)
```

### `shiftrs(dst, src, val, ..., *, count=None, count_per_rep=None, round_en=False)`

- Purpose: Shift every integer element right by `val` bits.
- Parameters: use the shared unary-scalar parameter set above; `round_en` is a
  Python `bool` forwarded to the AscendC high-dimensional overload.
- Restrictions:
  - supported dtypes: `int16_t`, `uint16_t`, `int32_t`, `uint32_t`
  - shift range and `Var` dtype rules are the same as `shiftls`
  - signed values use arithmetic right shift; unsigned values use logical right shift
  - `round_en` is accepted for every supported dtype, but is effective only for
    signed int16/int32 on A2; after the arithmetic shift, one is added when the
    highest discarded bit is set
- Reference: [AscendC ShiftRight](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0059.html).
- Example:

```python
shiftrs(dst, src, 5, count=element_count, round_en=True)
```

### `vmaxs(dst, src, val, ...)`

- Purpose: Clamp each element to at least a scalar threshold.
- Parameters: use the shared unary-scalar parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int`
- Example:

```python
vmaxs(dst, src, 0.0)
```

### `vmins(dst, src, val, ...)`

- Purpose: Clamp each element to at most a scalar threshold.
- Parameters: use the shared unary-scalar parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`, `int`
- Example:

```python
vmins(dst, src, 1.0)
```

### `lrelu(dst, src, val, ...)`

- Purpose: Apply leaky relu with scalar slope `val`.
- Parameters: use the shared unary-scalar parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
- Example:

```python
lrelu(dst, src, 0.1)
```

### `axpy(dst, src, val, ...)`

- Purpose: Apply the vec-side AXPY-style scalar fused op supported by the backend.
- Parameters: use the shared unary-scalar parameter set above.
- Restrictions:
  - supported dtypes: `float`, `half`
  - scalar type must be compatible with tensor dtype
- Example:

```python
axpy(dst, src, 0.5)
```

## 4. Duplication and Broadcast Helpers

### `dup(dst, value, repeat=None, dst_blk_stride=None, dst_rep_stride=None, *, count=None, count_per_rep=None)`

- Purpose: Duplicate a scalar value into a UB tensor.
- Parameters:
  - `dst`: destination UB `Tensor`
  - `value`: `int`, `float`, or `Var`
  - `repeat`: optional repeat count
  - `dst_blk_stride`, `dst_rep_stride`: optional stride metadata
  - `count`: optional contiguous prefix length; switches this op into vec count mode
  - `count_per_rep`: optional live-element count per repeat; emits `set_mask_by_count(count_per_rep)` while keeping repeat mode
- Restrictions:
  - `dst` must be `Position.UB`
  - supported dtypes: `float`, `half`, `int`, `uint32_t`
  - `count` and `count_per_rep` are mutually exclusive
  - `dup()` consumes the current vec mask at dst writeback; masked-off lanes keep the previous `dst` value
- Example:

```python
dup(dst, 0.0)
```

### `brcb(dst, src, dst_blk_stride=None, dst_rep_stride=None, repeat=None)`

- Purpose: Apply the vec-side broadcast/repeat helper used by repository kernels.
- Parameters:
  - `dst`: destination UB `Tensor`
  - `src`: source UB `Tensor`
  - `dst_blk_stride`, `dst_rep_stride`, `repeat`: optional control parameters
- Restrictions:
  - `dst` and `src` must both be UB tensors
  - `dst.dtype` must equal `src.dtype`
  - `brcb()` currently ignores the current vec mask state
- Example:

```python
brcb(dst, src)
```

## 5. Group Reduction-Style Operators

The following functions all share this parameter pattern:

- `cmax`
- `cgmax`
- `cmin`
- `cgmin`
- `cadd`
- `cgadd`
- `cpadd`

Shared parameters:

- `dst`: destination UB `Tensor`
- `src`: source UB `Tensor`
- `repeat`: optional repeat count
- `dst_rep_stride`: destination repeat stride; defaults to `1`, but passing `None` is rejected
- `src_blk_stride`, `src_rep_stride`: optional source stride metadata
- `count_per_rep`: optional, keyword-only; when set, emits `set_mask_by_count(count_per_rep)` for this op and then auto-restores the full vec mask with `reset_mask()` after the op completes

Shared restrictions:

- `dst` and `src` must be UB tensors
- supported dtypes: `float`, `half`
- `dst_rep_stride` cannot be `None`
- the destination stride units differ between `vc`, `vcg`, and `vcp` families; the implementation prints a one-time reminder about those units
- these ops consume the current vec mask state from `set_mask()` / `reset_mask()`

Current simulator mask semantics for this family:

- `cadd`
  - masked-off source slots contribute `0`
  - if all active-prefix mask bits are `0`, the destination scalar is not overwritten
- `cgadd`
  - masked-off source slots contribute `0` inside each datablock
  - if one datablock mask is entirely `0`, that datablock's destination scalar is not overwritten
- `cpadd`
  - masked-off source slots contribute `0` before pairwise add
- `cmax`, `cgmax`
  - masked-off source slots behave like `-inf`
  - if the full active prefix is all-zero for `cmax`, its destination scalar is not overwritten
  - if one datablock mask is all-zero for `cgmax`, that datablock's destination scalar is not overwritten
- `cmin`, `cgmin`
  - masked-off source slots behave like `+inf`
  - if the full active prefix is all-zero for `cmin`, its destination scalar is not overwritten
  - if one datablock mask is all-zero for `cgmin`, that datablock's destination scalar is not overwritten

### `cmax(dst, src, ...)`

- Purpose: Group max reduction in the `vc` family.
- Parameters: use the shared group parameter set above.
- Restrictions:
  - destination stride units follow the `vc` family rule
- Example:

```python
cmax(dst, src, dst_rep_stride=1)
```

### `cgmax(dst, src, ...)`

- Purpose: Group max reduction in the `vcg` family.
- Parameters: use the shared group parameter set above.
- Restrictions:
  - destination stride units follow the `vcg` family rule
- Example:

```python
cgmax(dst, src, dst_rep_stride=1)
```

### `cmin(dst, src, ...)`

- Purpose: Group min reduction in the `vc` family.
- Parameters: use the shared group parameter set above.
- Restrictions:
  - destination stride units follow the `vc` family rule
- Example:

```python
cmin(dst, src, dst_rep_stride=1)
```

### `cgmin(dst, src, ...)`

- Purpose: Group min reduction in the `vcg` family.
- Parameters: use the shared group parameter set above.
- Restrictions:
  - destination stride units follow the `vcg` family rule
- Example:

```python
cgmin(dst, src, dst_rep_stride=1)
```

### `cadd(dst, src, ...)`

- Purpose: Group add reduction in the `vc` family.
- Parameters: use the shared group parameter set above.
- Restrictions:
  - destination stride units follow the `vc` family rule
- Example:

```python
cadd(dst, src, dst_rep_stride=1)
```

### `cgadd(dst, src, ...)`

- Purpose: Group add reduction in the `vcg` family.
- Parameters: use the shared group parameter set above.
- Restrictions:
  - destination stride units follow the `vcg` family rule
- Example:

```python
cgadd(dst, src, dst_rep_stride=1)
```

### `cpadd(dst, src, ...)`

- Purpose: Group packed add reduction in the `vcp` family.
- Parameters: use the shared group parameter set above.
- Restrictions:
  - destination stride units follow the `vcp` family rule
- Example:

```python
cpadd(dst, src, dst_rep_stride=1)
```
