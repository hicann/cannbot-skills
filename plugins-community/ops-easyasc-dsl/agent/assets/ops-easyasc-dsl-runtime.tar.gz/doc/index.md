# EasyASC Documentation

[中文文档](../doc_cn/index.md) · [Repository overview](../README.md)

This is the canonical navigation page for public behavior and authoring
contracts. Start with the route that matches your task instead of reading every
page linearly.

## Target selection

| Facade | Target | Public surface |
| --- | --- | --- |
| `easyasc.a2` | Ascend A2 / B3 profile | A2 cube and vec APIs |
| `easyasc.a3` | Ascend 910C / `Ascend910_9362` | A2/C220 APIs with the `ascend910_93` compile unit |
| `easyasc.a5` | Ascend 950 | A5/C310 cube, `@vf`, `@simt`, and micro APIs |
| `easyasc.a5pr` | Ascend 950PR | The A5/C310 API with the 950PR device profile |

> **Use one facade per Python process.** A facade import selects shared device
> state. Python's module cache does not restore a previous target when that
> facade is imported again, so start a new process to switch targets.

The A5 family means `easyasc.a5` and `easyasc.a5pr`. A page should say
“A5/950 only” only when it intentionally excludes A5PR.
The C220 authoring family means `easyasc.a2` and `easyasc.a3`; they export the
same DSL surface while selecting B3 and 9362 build profiles respectively.

## Choose a route

| Goal | Start here | Continue with |
| --- | --- | --- |
| Run an existing kernel | [Quick Start](01_quickstart.md) | [Kernel examples](../agent/example/kernels/README.md) |
| Learn the DSL | [Programming Model](02_programming_model.md) | [Write Your First Kernel](03_write_your_first_kernel.md) |
| Build a mixed pipeline | [Mixed Pipeline and Synchronization](04_mixed_pipeline_and_sync.md) | [Synchronization API](api/synchronize.md) |
| Debug in simulation | [Simulator and Trace](05_simulator_and_trace.md) | [Troubleshooting](10_troubleshooting.md) |
| Generate or run artifacts | [Code Generation and Runtime](06_codegen_and_runtime.md) | [OpExec API](api/op_exec.md) |
| Study reusable structures | [Kernel Patterns](07_kernel_patterns.md) | [Kernel Practice](kernel_practice.md) |
| Add regression coverage | [Testing and Validation](08_testing_and_validation.md) | [Testcases Guide](../agent/example/testcases/README.md) |
| Look up an API | [Detailed API Reference](api/index.md) | [Stub-to-codegen map](12_stub_to_codegen_name_map.md) |
| Work with a specialized dtype/operator | [Topic Contracts](topics/index.md) | The selected topic page |
| Modify the framework | [Architecture for Contributors](11_architecture_for_contributors.md) | [Agent router](../agent/ROUTER.md) |

## Guide map

The numbered files are stable entry points, not a requirement to read every
page in order.

1. [Quick Start](01_quickstart.md)
2. [Programming Model](02_programming_model.md)
3. [Write Your First Kernel](03_write_your_first_kernel.md)
4. [Mixed Pipeline and Synchronization](04_mixed_pipeline_and_sync.md)
5. [Simulator and Trace](05_simulator_and_trace.md)
6. [Code Generation and Runtime](06_codegen_and_runtime.md)
7. [Kernel Patterns](07_kernel_patterns.md)
8. [Testing and Validation](08_testing_and_validation.md)
9. [API Reference compatibility entry](09_api_reference.md)
10. [Troubleshooting](10_troubleshooting.md)
11. [Architecture for Contributors](11_architecture_for_contributors.md)
12. [Stub-to-codegen Name Map](12_stub_to_codegen_name_map.md)

## Reference collections

- [Detailed API Reference](api/index.md) owns public signatures, parameters,
  target availability, dtype/layout restrictions, and minimal examples.
- [Topic Contracts](topics/index.md) owns focused contracts such as Conv2D,
  int4, and MXFP.
- Evaluation reports (provenance-tracked evidence snapshots) live in the
  `easyasc_cannbench_kernels` extension repository, next to the CANN Bench
  kernels they describe; reports are not tutorial steps.
- [Kernel Practice](kernel_practice.md) contains public exercises. Finished,
  curated implementations live under [`agent/example/kernels/`](../agent/example/kernels/README.md).

## Documentation ownership

- Public behavior and API contracts belong in `README*`, `doc/`, and `doc_cn/`.
- Public exports and target selection are owned by `easyasc/a2.py`,
  `easyasc/a3.py`, `easyasc/a5.py`, and `easyasc/a5pr.py`; documentation must not invent a
  separate surface.
- Stub validation, parser/lowering, and simulator behavior are implementation
  evidence for the public contract.
- Agent workflows, repository maps, implementation lookup, and hardware facts
  remain under `agent/`; public pages should link to those owners instead of
  copying their full contents.
- English and Chinese may use different explanations, but signatures, targets,
  restrictions, defaults, and exact numeric tables must agree.
